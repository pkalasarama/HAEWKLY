/* 
 * Decompiled with CFR 0_118.
 * 
 * Could not load the following classes:
 *  oracle.apps.bne.exception.BneException
 *  oracle.apps.bne.exception.BneFatalException
 *  oracle.apps.bne.framework.BneContext
 *  oracle.apps.bne.framework.BneLogger
 *  oracle.apps.bne.framework.BneWebAppsContext
 *  oracle.apps.bne.integrator.upload.BneUploadColumn
 *  oracle.apps.bne.integrator.upload.BneUploaderMessage
 *  oracle.apps.bne.integrator.validators.BneUploadValidator
 *  oracle.apps.bne.repository.BneResourceString
 *  oracle.apps.bne.utilities.BneDateUtils
 *  oracle.apps.bne.utilities.BneStringUtils
 *  oracle.apps.bne.utilities.sql.BneBaseSQL
 *  oracle.apps.bne.utilities.sql.BneCompositeSQLCriteria
 *  oracle.apps.bne.utilities.sql.BneResultSet
 *  oracle.apps.bne.utilities.sql.BneSQLStatement
 *  oracle.apps.fa.integrator.sql.FADPISSQL
 *  oracle.apps.fnd.common.AppsContext
 *  oracle.apps.fnd.common.MessageToken
 *  oracle.apps.fnd.common.VersionInfo
 *  oracle.apps.fnd.common.WebAppsContext
 */
package oracle.apps.fa.integrator.validators;

import java.sql.Connection;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import oracle.apps.bne.exception.BneException;
import oracle.apps.bne.exception.BneFatalException;
import oracle.apps.bne.framework.BneContext;
import oracle.apps.bne.framework.BneLogger;
import oracle.apps.bne.framework.BneWebAppsContext;
import oracle.apps.bne.integrator.upload.BneUploadColumn;
import oracle.apps.bne.integrator.upload.BneUploaderMessage;
import oracle.apps.bne.integrator.validators.BneUploadValidator;
import oracle.apps.bne.repository.BneResourceString;
import oracle.apps.bne.utilities.BneDateUtils;
import oracle.apps.bne.utilities.BneStringUtils;
import oracle.apps.bne.utilities.sql.BneBaseSQL;
import oracle.apps.bne.utilities.sql.BneCompositeSQLCriteria;
import oracle.apps.bne.utilities.sql.BneResultSet;
import oracle.apps.bne.utilities.sql.BneSQLStatement;
import oracle.apps.fa.integrator.sql.FADPISSQL;
import oracle.apps.fnd.common.AppsContext;
import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.common.WebAppsContext;

public class XXHAFASerialNumValidator
extends BneUploadValidator {
    public static final String RCS_ID = "$Header: XXHAFASerialNumValidator.java 120.0.12010000.3 2008/11/04 11:52:50 saalampa ship $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion((String)"$Header: XXHAFASerialNumValidator.java 120.0.12010000.3 2008/11/04 11:52:50 saalampa ship $", (String)"oracle.apps.fa.integrator.validators");
    private BneLogger m_Logger = BneLogger.getInstance();
    private Hashtable m_Statements = null;
    private FADPISSQL SQLhandle = null;

    public BneUploaderMessage[] startupValidator(BneWebAppsContext bneWebAppsContext, Hashtable hashtable, Hashtable hashtable2) {
        this.m_Logger.log(7, "XXHAFASerialNumValidator.startupValidator() Start");
        this.m_Statements = new Hashtable();
        this.m_Logger.log(7, "XXHAFASerialNumValidator.startupValidator() End");
        return new BneUploaderMessage[0];
    }

    public String[] getDomainParameters() {
        return new String[]{"ASSET_CATEGORY_ID"};
    }

    public BneResultSet getDomainValues(BneWebAppsContext bneWebAppsContext, Hashtable hashtable, BneCompositeSQLCriteria bneCompositeSQLCriteria) throws BneException {
        this.m_Logger.log(7, "XXHAFASerialNumValidator.getDomainValues() Start");
        BneSQLStatement bneSQLStatement = new BneSQLStatement();
        this.m_Logger.log(7, "XXHAFASerialNumValidator.getDomainValues() : 0");
        if (bneCompositeSQLCriteria != null) {
            bneSQLStatement = bneCompositeSQLCriteria.evaluate(bneSQLStatement);
        }
        String string = null;
        BneResultSet bneResultSet = null;
        try {
         
            string = (String)hashtable.get("ASSET_CATEGORY_ID");
            this.m_Logger.log(7, "XXHAFASerialNumValidator.getDomainValues() : 1 " + string);
            BneSQLStatement bneSQLStatement2 = new BneSQLStatement(this.SQLhandle.getQuery(), new Object[]{new String(string)});
            this.m_Logger.log(7, "XXHAFASerialNumValidator.getDomainValues() : 2");
            bneSQLStatement2.append("", bneSQLStatement.getBindValues());
            this.m_Logger.log(7, "XXHAFASerialNumValidator.getDomainValues() : 3");
            bneResultSet = this.SQLhandle.getBneResultSet(bneSQLStatement2.getBindValuesAsArray());
            this.m_Logger.log(7, "XXHAFASerialNumValidator.getDomainValues() : 4");
            return bneResultSet;
        }
        catch (Exception var7_8) {
            this.m_Logger.log(7, "XXHAFASerialNumValidator.getDomainValues() exception ");
            throw new BneFatalException(var7_8.toString());
        }
    }

    public BneUploaderMessage[] validateColumn(BneWebAppsContext bneWebAppsContext, Hashtable hashtable, Hashtable hashtable2, BneUploadColumn bneUploadColumn) 
	{
        this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() Start");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Timestamp timestamp = null;
        BneUploadColumn bneUploadColumn2 = null;
        BneUploadColumn bneUploadColumn3 = bneUploadColumn;
        BneUploadColumn bneUploadColumn4 = null;
        BneUploadColumn bneUploadColumn5 = null;
		BneUploadColumn bneUploadColumn6 = null;
		BneUploadColumn bneUploadColumn7 = null;
        String string = bneUploadColumn.getInterfaceName();
        Object var12_12 = null;
        Object var13_13 = null;
        String string2 = null;
        String string3 = "EMPTY";
        Connection connection = null;
        BneBaseSQL bneBaseSQL = null;
        BneResultSet bneResultSet = null;
        String string4 = "select segment1 from FA_CATEGORIES_B where category_id = :1";
        String string6 = "SELECT COUNT(*) AS N_COUNT FROM CSI_ITEM_INSTANCES WHERE serial_number    = :1  AND inventory_item_id IN (SELECT DISTINCT inventory_item_id FROM mtl_system_items_b WHERE segment1 IN (SELECT segment2 FROM FA_ASSET_KEYWORDS WHERE code_combination_id = :2)) AND instance_status_id   not in (select instance_status_id  From CSI_INSTANCE_STATUSES where name = 'EXPIRED')";
        String string7 = "select COUNT(*) AS N_COUNT1 from FA_ADDITIONS_B where serial_number = :1 and asset_key_ccid in  (select code_combination_id from FA_ASSET_KEYWORDS where segment2 in (select distinct segment2 from FA_ASSET_KEYWORDS where ASSET_KEY_CCID = :2))";
		String string18 = "";
		String string20 = "";
		String string23	=  "select asset_number AS N_COUNT2 from FA_ADDITIONS_B where serial_number = :1 and asset_key_ccid in  (select code_combination_id from FA_ASSET_KEYWORDS where segment2 in (select distinct segment2 from FA_ASSET_KEYWORDS where ASSET_KEY_CCID = :2)) and rownum=1";

	   
	   this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn()");
        try {
         
            bneUploadColumn4 = bneUploadColumn2 = (BneUploadColumn)hashtable2.get(BneStringUtils.concatSeperatorUnlessEmpty((String)string, (String)"ASSET_CATEGORY_ID", (String)"."));
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() tempBook " + (bneUploadColumn4 == null ? "null" : bneUploadColumn4.getColumnValue()));
            String string10 = bneUploadColumn4.getColumnValue();
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() AssetCategoryid" + string10);
            connection = bneWebAppsContext.getJDBCConnection();
            bneBaseSQL = new BneBaseSQL(connection, string4);
            bneBaseSQL.setString(1, string10);
            bneResultSet = bneBaseSQL.getBneResultSet();
            String string11 = "";
            while (bneResultSet.next()) {
				string11 = bneResultSet.getString("segment1");
                //string11 = bneResultSet.getString(1);
            }
            BneBaseSQL.closeSQL((BneBaseSQL)bneBaseSQL);
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() category_id: " + string11);
           
			  bneUploadColumn5 = (BneUploadColumn)hashtable2.get(BneStringUtils.concatSeperatorUnlessEmpty((String)string, (String)"SERIAL_NUMBER", (String)"."));
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() tempBook " + (bneUploadColumn5 == null ? "null" : bneUploadColumn5.getColumnValue()));
            String string12 = bneUploadColumn5.getColumnValue();
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() Serial number" + string12);
           // connection = bneWebAppsContext.getJDBCConnection();
			   
			  bneUploadColumn7 = (BneUploadColumn)hashtable2.get(BneStringUtils.concatSeperatorUnlessEmpty((String)string, (String)"ASSET_NUMBER", (String)"."));
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() tempBook " + (bneUploadColumn7 == null ? "null" : bneUploadColumn7.getColumnValue()));
            string20 = bneUploadColumn7.getColumnValue();
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() Asset number" + string20);
           // connection = bneWebAppsContext.getJDBCConnection();
			    			   
			
			  bneUploadColumn6 = (BneUploadColumn)hashtable2.get(BneStringUtils.concatSeperatorUnlessEmpty((String)string, (String)"ASSET_KEY_CCID", (String)"."));
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() tempBook " + (bneUploadColumn6 == null ? "null" : bneUploadColumn6.getColumnValue()));
            String string13 = bneUploadColumn6.getColumnValue();
			int int_string3 = Integer.parseInt(string13);
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() Asset Key id" + string13);
            connection = bneWebAppsContext.getJDBCConnection();
			bneBaseSQL = new BneBaseSQL(connection, string6);
			bneBaseSQL.setString(1, string12);
            bneBaseSQL.setString(2, string13);
            bneResultSet = bneBaseSQL.getBneResultSet();
           
            int int_string4 = 0;
			 String string14 = "";
            while (bneResultSet.next()) {
				string14 = bneResultSet.getString(1);
                 int_string4 = Integer.parseInt(string14);
            }
				
            BneBaseSQL.closeSQL((BneBaseSQL)bneBaseSQL);
			  this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() query count of ib validation: " + int_string4);
			
			
			connection = bneWebAppsContext.getJDBCConnection();
			bneBaseSQL = new BneBaseSQL(connection, string7);
			bneBaseSQL.setString(1, string12);
            bneBaseSQL.setString(2, string13);
            bneResultSet = bneBaseSQL.getBneResultSet();
           
            int int_string5 = 0;
			 String string16 = "";
            while (bneResultSet.next()) {
				string16 = bneResultSet.getString(1);
                 int_string5 = Integer.parseInt(string16);
            }
			
			BneBaseSQL.closeSQL((BneBaseSQL)bneBaseSQL);
			  this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() query count of fa validation: " + int_string5);
			
			
			connection = bneWebAppsContext.getJDBCConnection();
            bneBaseSQL = new BneBaseSQL(connection, string23);
           bneBaseSQL.setString(1, string12);
            bneBaseSQL.setString(2, string13);
            bneResultSet = bneBaseSQL.getBneResultSet();
            while (bneResultSet.next()) {
				string18 = bneResultSet.getString(1);
                //string11 = bneResultSet.getString(1);
            }
            BneBaseSQL.closeSQL((BneBaseSQL)bneBaseSQL);
            this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() FA Asset number: " + string18);
			
           
			
            
			 
				 if (string11.equals("Haemo Equip"))
				 {
				 this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() category segment2 is invalid ");
				  if (string12 != null) {
				 this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() serial num not null validation ");
				  
				   if (int_string4 == 0) {
				 this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() serial/item num combination already exists");
          
            string3 = "INVALIDIB";
            throw new Exception();

			}
			
			}
			}
			if (string11.equals("Haemo Equip"))
				 {
				 this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() category segment2 is invalid : fa");
				  if (string12 != null) {
				 this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn() serial num not null validation : fa ");
				  
				   if (int_string5 > 0) {
				 this.m_Logger.log(7, "XXHAFASerialNumValidator.validateColumn()invalid serial/item num combination : fa ");
          
            string3 = "INVALIDFA";
            throw new Exception();

			}
			
			}
			}
			this.m_Logger.log(7, "FADPISValidator.validateColumn() vaid combination" + string12);
			   bneUploadColumn.flagColumnAsFineGrainValid();
                    return new BneUploaderMessage[0];
           
            }
        
        catch (Exception var24_25) {
            if (string3.equals("INVALIDIB")) {
                String string15 = BneResourceString.getMessage((AppsContext)bneWebAppsContext.getWebAppsContext(), (String)"OFA", (String)"XXHA_IB_ITEM_SERIAL_MSG", (MessageToken[])new MessageToken[0]);
				//String string21 = string15 + " - Asset Number: " + string20;
                return this.uploadException(bneUploadColumn, string15, "XXHAFASerialNumValidator", (Throwable)var24_25);
            }
			if (string3.equals("INVALIDFA")) {
                String string17 = BneResourceString.getMessage((AppsContext)bneWebAppsContext.getWebAppsContext(), (String)"OFA", (String)"XXHA_FA_ITEM_SERIAL_MSG", (MessageToken[])new MessageToken[0]);
                String string22 = string17 + " - Asset Number: " + string18;
				return this.uploadException(bneUploadColumn, string22, "FADPISValidator", (Throwable)var24_25);
            }
          
            String string19 = BneResourceString.getMessage((AppsContext)bneWebAppsContext.getWebAppsContext(), (String)"OFA", (String)"XXHA_IB_ITEM_SERIAL_MSG", (MessageToken[])new MessageToken[0]);
            BneContext.getInstance();
            BneContext.getLogInstance().log(3, "XXHAFASerialNumValidator:validateColumn() Exception: " + var24_25.getMessage());
            BneContext.getInstance();
            BneContext.getLogInstance().log(3, "XXHAFASerialNumValidator:validateColumn() " + BneStringUtils.stackTrace((Throwable)var24_25));
            return this.uploadException(bneUploadColumn, string19, "XXHAFASerialNumValidator", (Throwable)var24_25);
			
	}
	
	}
    

    public BneUploaderMessage[] shutdownValidator() {
        if (this.SQLhandle != null) {
            this.SQLhandle.close();
            this.SQLhandle = null;
        }
        this.m_Logger.log(7, "XXHAFASerialNumValidator.shutdownValidator() Start");
        if (this.m_Statements != null) {
            Enumeration enumeration = this.m_Statements.keys();
            while (enumeration.hasMoreElements()) {
                Object k = enumeration.nextElement();
                Object v = this.m_Statements.get(k);
                this.m_Statements.remove(k);
            }
            this.m_Statements = null;
        }
        this.m_Logger.log(7, "XXHAFASerialNumValidator.shutdownValidator() End");
        return new BneUploaderMessage[0];
    }
}