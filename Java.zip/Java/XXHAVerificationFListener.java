//*******************************************************************************************************
//  * Object Name: XXHAVerificationFListener
//  * Object Type: Java class
//  * Description: Created Java class for Verification Requirement
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    10-JAN-2015          Initial Object Creation
//*******************************************************************************************************/

package oracle.apps.inv.wshtxn.server;

import java.sql.*;
import java.util.Vector;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.inv.lov.server.*;
import oracle.apps.mwa.beans.*;
import oracle.apps.mwa.container.MWALib;
import oracle.apps.inv.utilities.server.NumberFieldBean;
import oracle.apps.inv.utilities.server.UtilFns;
import oracle.apps.mwa.container.Session;
import oracle.apps.mwa.eventmodel.*;
import oracle.jdbc.OracleCallableStatement;

// Referenced classes of package oracle.apps.inv.wshtxn.server:
//            XXHAVerificationPage

public class XXHAVerificationFListener
    implements MWAFieldListener
{

    public XXHAVerificationFListener()
    {
        pg = null;
        mSes = null;
		mMessageData = "";
       
    }

    public void fieldEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	if(UtilFns.isTraceOn)
            UtilFns.trace("XXHAVerificationFListener : Entered field handler");
    
      
    }
	
	
public void fieldExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	UtilFns.trace("Inside Field Exited");
	 this.mSes = mwaevent.getSession();
     this.mCon = this.mSes.getConnection();
	 this.pg = ((XXHAVerificationPage)this.mSes.getCurrentPage());
	 
	String s = ((FieldBean)mwaevent.getSource()).getName();
    boolean bool = mwaevent.getAction().equals("MWA_PREVIOUSFIELD");

    UtilFns.log("XXHAVerificationPage: FieldExited = " + s);
    try {
      if (!bool)
      {
        if (s.equals(pg.getDeliveryFld().getName())) 
		{
          DeliveryExited(mwaevent);
        } 
		 else if (s.equals(pg.getMoreBtn().getName()))
		  {
                MoreExited(mwaevent);
				}  
        }
		}
      catch (Exception localException)
    {
      UtilFns.log("SQLException :  : In Field Exit = " + s);
    }
		mSes.setRefreshScreen(true);
    
	}

   void DeliveryExited(MWAEvent mwaevent)
    throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
   {
   try
   {
	   Connection connection;
Session session;
PreparedStatement preparedStatement = null;
session = mwaevent.getSession();
  long l2;
    l2 = Long.parseLong(this.pg.mDeliveryFld.getValue());
    String str2 = this.pg.mDocPrtFld.getValue();
	String str5 = "";
long l5 = 0L;
if (UtilFns.isTraceOn)
          UtilFns.trace("Getting Shipping Doc Printer name and updating it in attribute4 of wsh_delivery_details table::::: "+str2);
str5 = " UPDATE wsh_delivery_details wdd SET attribute4 = :1 where wdd.delivery_detail_id IN (SELECT wda.delivery_detail_id from wsh_delivery_assignments wda, wsh_new_deliveries wnd where wdd.delivery_detail_id = wda.delivery_detail_id and wda.delivery_id = wnd.delivery_id and wdd.released_status = 'Y' and status_code NOT IN ('CO', 'CL', 'IT') and wda.delivery_id = :2) ";
connection=session.getConnection();
preparedStatement = connection.prepareStatement(str5);
preparedStatement.setString(1,str2);
preparedStatement.setLong(2, l2);
l5 = preparedStatement.executeUpdate();
if (UtilFns.isTraceOn)
UtilFns.trace("Updated DocPrinter for no of records count: " + l5);
preparedStatement.close();
 if (l5 == 0L)
      {
        UtilFns.log(" Did not Update wsh_delivery_details table ");
      }
      else
      {
        UtilFns.log(" No. of records updated in wsh_delivery_details table = " + l5);
      }
    }
catch (Exception localException)
    {
      UtilFns.error("Ex.. in XXHAVerificationFListener.while updating wsh_delivery_details :", localException);
    }
    finally
    {
      try
      {
        if (preparedStatement!= null) preparedStatement.close();
      }
      catch (Exception localException)
      {
      }
	}
	  // if (UtilFns.isTraceOn)
//UtilFns.trace("Delivery number entered by the Shipper::::: "+l2);
//UtilFns.trace("Document printer entered by the Shipper::::: "+str2);
//UtilFns.trace("Call Submit Oracle Shipping Documents");
  //    SubmitOracleShipDocs(l2, str2, mwaevent);
//	}  
	//   catch (Exception localException)
    //{
      //UtilFns.error("Ex in DeliveryExitedfield while submitting Oracle Shipping documents", localException);
    //}
	
try
{ 
Connection connection;
Session session;
PreparedStatement preparedStatement = null;
session = mwaevent.getSession();
long l4;
l4 = Long.parseLong(this.pg.mDeliveryFld.getValue());
String LabelPrinter = this.pg.mLabelPrtFld.getValue();
String str3 = "";
long l3 = 0L;
if (UtilFns.isTraceOn)
          UtilFns.trace("Getting Label Printer name and updating it in attribute5 of wsh_delivery_details table::::: "+LabelPrinter);
str3 = " UPDATE wsh_delivery_details wdd SET attribute5 = :1 where wdd.delivery_detail_id IN (SELECT wda.delivery_detail_id from wsh_delivery_assignments wda, wsh_new_deliveries wnd where wdd.delivery_detail_id = wda.delivery_detail_id and wda.delivery_id = wnd.delivery_id and wdd.released_status = 'Y' and status_code NOT IN ('CO', 'CL', 'IT') and wda.delivery_id = :2) ";
connection=session.getConnection();
preparedStatement = connection.prepareStatement(str3);
preparedStatement.setString(1,LabelPrinter);
preparedStatement.setLong(2, l4);
l3 = preparedStatement.executeUpdate();
if (UtilFns.isTraceOn)
UtilFns.trace("Updated LabelPrinter for no of records count: " + l3);
preparedStatement.close();
 if (l3 == 0L)
      {
        UtilFns.log(" Did not Update wsh_delivery_details table ");
      }
      else
      {
        UtilFns.log(" No. of records updated in wsh_delivery_details table = " + l3);
      }
    }
catch (Exception localException)
    {
      UtilFns.error("Ex.. in XXHAVerificationFListener.while updating wsh_delivery_details :", localException);
    }
    finally
    {
      try
      {
        if (preparedStatement!= null) preparedStatement.close();
      }
      catch (Exception localException)
      {
      }
	}
try
	{
	Session session;
	session = mwaevent.getSession();
	long l1;
    l1 = Long.parseLong(this.pg.mDeliveryFld.getValue());
    if (UtilFns.isTraceOn)
    UtilFns.trace("Call Submit Shipshipment XML in Precision");
	SubmitShipshipmentXML(l1, mwaevent);
	}
	  catch(Exception localException)
       {
            UtilFns.error("Ex in DeliveryExitedfield while submitting Shipshipment XML in Precision ", localException);
        }
	}
   
 void MoreExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        if(mwaevent.getAction().equals("MWA_SUBMIT"))
        {
            XXHA_DeliveryLOV xxhadeliverylov = pg.getDeliveryFld();
            pg.clear();
            
        }
    }

public void SubmitOracleShipDocs(long l1, String s4,MWAEvent mwaevent)
    {
   if(UtilFns.isTraceOn)
   UtilFns.trace("Inside call to SubmitOracleShippingDocs");
   Session session;
   Connection connection;
   session = mwaevent.getSession();
   connection = session.getConnection();
   String s;
OracleCallableStatement oraclecallablestatement = null;
 s = "{ call     XXHA_ORACLE_SHIP_DOCS_PKG.XXHA_ORACLE_SHIP_DOCS(:1, :2 ) } ";
   try {
        
	    oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(s);
	    oraclecallablestatement.setLong(1, l1);
		oraclecallablestatement.setString(2, s4);
		oraclecallablestatement.execute();
		oraclecallablestatement.close();
        }
        catch(Exception exception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace((new StringBuilder()).append("Exception in Submitting Oracle Shipping documents:").append(exception).toString());
        }
		
    }
		
 public void SubmitShipshipmentXML(long l, MWAEvent mwaevent)
    {
	if(UtilFns.isTraceOn)
   UtilFns.trace("Inside call to SubmitShipshipmentXML");
        Connection connection;
        String s;
       OracleCallableStatement oraclecallablestatement;
        Session session = mwaevent.getSession();
        connection = session.getConnection();
        s = "{ call     XXHA_WM_SHIPMENT_XML_PKG.XXHA_WM_SHIPMENT_XML(:1) } ";
		oraclecallablestatement = null;
       try
	   {
        oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(s);
        oraclecallablestatement.setLong(1, l);
        oraclecallablestatement.execute();
        oraclecallablestatement.close();
		}
		  catch(SQLException sqlexception1)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace("SQL exception when submitting the Shipshipment XML");
        }

		}
		
		Session session;
 
    
    public static final String RCS_ID = "$Header: XXHAVerificationFListener.java 120.4 2015/01/13 04:30:22 vssrivat ship $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: XXHAVerificationFListener.java 120.4 2015/01/13 04:30:22 vssrivat ship $", "oracle.apps.inv.wshtxn.server");
    XXHAVerificationPage pg;
	PreparedStatement preparedStatement;
    Session mSes;
    Connection mCon;
    String mMessageData;
    XXHA_DeliveryLOV mDeliveryLOV;
    public static final int SUCCESS = 0;
    public static final int ERROR = 1;
    public static final int WARNING = 2;
 }
