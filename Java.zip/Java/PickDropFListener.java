//*******************************************************************************************************
//  * Object Name: PickDropFListener
//  * Object Type: Java class
//  * Description: 
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    27-JAN-2015          Modified the java class for 100% Parcel Drop
//  *                                         trigger requirement.
//  *                    15-APR-2015          Modified the java class for submitting XXHA Drop Report 
//	*					                      only for Non-Parcel deliveries. 
//*******************************************************************************************************/ 

package oracle.apps.wms.td.server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Vector;
import oracle.apps.fnd.common.AppsContext;
import oracle.apps.fnd.common.ProfileStore;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.inv.lov.server.LPNLOV;
import oracle.apps.inv.lov.server.LocatorKFF;
import oracle.apps.inv.lov.server.SubinventoryLOV;
import oracle.apps.inv.lov.server.UomLOV;
import oracle.apps.inv.utilities.server.NumberFieldBean;
import oracle.apps.inv.utilities.server.UtilFns;
import oracle.apps.mwa.beans.ButtonFieldBean;
import oracle.apps.mwa.beans.FieldBean;
import oracle.apps.mwa.beans.InputableFieldBean;
import oracle.apps.mwa.beans.LOVFieldBean;
import oracle.apps.mwa.beans.TextFieldBean;
import oracle.apps.mwa.container.MWALib;
import oracle.apps.mwa.container.Session;
import oracle.apps.mwa.eventmodel.AbortHandlerException;
import oracle.apps.mwa.eventmodel.DefaultOnlyHandlerException;
import oracle.apps.mwa.eventmodel.InterruptedHandlerException;
import oracle.apps.mwa.eventmodel.MWAEvent;
import oracle.apps.mwa.presentation.telnet.TelnetSession;
import oracle.apps.wms.td.server.CurrentTasksPage;
import oracle.apps.wms.td.server.MainPickPage;
import oracle.apps.wms.td.server.PickDropDetail;
import oracle.apps.wms.td.server.PickDropPage;
import oracle.apps.wms.td.server.StagingMovePage;
import oracle.apps.wms.td.server.TdButton;
import oracle.apps.wms.td.server.TdFListener;
import oracle.apps.wms.td.server.TdPage;
import oracle.apps.wms.td.server.TransactionDetails;
import oracle.jdbc.OracleCallableStatement;
//import oracle.jdbc.OraclePreparedStatement;
import java.sql.ResultSet;



public class PickDropFListener extends TdFListener {

   public static final String RCS_ID = "$Header: PickDropFListener.java 120.19.12010000.7 2011/09/22 11:35:18 abasheer ship $";
   public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: PickDropFListener.java 120.19.12010000.7 2011/09/22 11:35:18 abasheer ship $", "oracle.apps.wms.td.server");
   private Session ses = null;
   private PickDropPage pdPage = null;
   private PickDropDetail currDropDetail = null;
   private static String lotPrompt = "";
   private static String quantityPrompt = "";
   private static String snPrompt = "";
   private static String itemRevDelim = "";
   private static boolean delimChecked = false;
   private static String serialDelSQL = " DELETE FROM MTL_ALLOCATIONS_GTMP   WHERE INVENTORY_ITEM_ID = :1        AND SERIAL_NUMBER     = :2    ";
   private static boolean locWarningDisplayed = true;
   PreparedStatement preparedStatement = null;
   //Start of code added by Preethi as part of Parcel Drop Trigger requirement
   ResultSet rs;
   ResultSet rs1;
   ResultSet rs2;
   ResultSet rs3;
   ResultSet rs4;
   ResultSet rs5;
   ResultSet rs6;
   String flag="Y";
   String printername ="";
   String DocPrinterName ="";
   String ModeOfTransport ="";
   long TotalCount = 0L;
   long TotalPickCount = 0L;
   //End of code added by Preethi as part of Parcel Drop Trigger requirement


   public void fieldEntered(MWAEvent var1) throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException {
      super.fieldEntered(var1);
      this.ses = var1.getSession();
      this.pdPage = (PickDropPage)this.ses.getCurrentPage();
      if(this.pdPage.deconsolidate() && !this.pdPage.getDropType().equals("SUB_XFER") || this.pdPage.getDropType().equals("SUB_XFER") && !this.pdPage.getMultipleSubinvs().equals("N") && this.pdPage.deconsolidate() && !this.pdPage.getDropMode().equals("NONE")) {
         Vector var2 = this.pdPage.getDropList();
         if(var2.size() > 0) {
            this.currDropDetail = (PickDropDetail)var2.elementAt(this.pdPage.getCurrDropIndex());
         }
      }

      this.ses = var1.getSession();
      String var3 = UtilFns.fieldEnterSource(this.ses);
      if(!(this.pdPage.getCurrentFieldBean() instanceof InputableFieldBean)) {
         UtilFns.populateLaborParameters(this.ses);
      }

      if(UtilFns.isTraceOn) {
         UtilFns.log("Field name: " + var3);
      }

      PickDropPage var10001;
      if(var3.equals("PKD.CONFIRM_LPN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(1);
      } else if(var3.equals("PKD.LPN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(2);
      } else if(var3.equals("PKD.CONFIRM_ITEM")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(3);
         this.itemEntered(var1);
      } else if(var3.equals("PKD.CONFIRM_REV")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(4);
      } else if(var3.equals("PKD.CONFIRM_UOM")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(5);
         this.uomEntered(var1);
      } else if(var3.equals("PKD.CONFIRM_QTY")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(6);
      } else if(var3.equals("PKD.CONFIRM_LOT")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(7);
         this.lotEntered(var1);
      } else if(var3.equals("PKD.CONF_LOT_QTY")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(8);
      } else if(var3.equals("PKD.CONFIRM_SN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(9);
      } else if(var3.equals("PKD.CONFIRM_SERIAL")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(10);
         this.serialEntered(var1);
      } else if(var3.equals("PKD.XFER_LPN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(11);
      } else if(var3.equals("PKD.DROP_LPN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(12);
         this.dropLPNEntered(var1);
      } else if(var3.equals("PKD.CONFIRM_ZONE")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(13);
         this.zoneEntered(var1);
      } else if(var3.equals("PKD.CONFIRM_LOC")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(14);
         this.locEntered(var1);
      } else if(var3.equals("PKD.LOT_INFO_BTN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(15);
      } else if(var3.equals("PKD.SERIAL_INFO_BTN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(16);
      } else if(var3.equals("PKD.DROP_DTL_BTN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(17);
      } else if(var3.equals("PKD.DEL_INFO_BTN")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(18);
      } else if(var3.equals("PKD.PICK_DROP_SUBMIT")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(19);
      } else if(var3.equals("TD.CANCEL")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(20);
      } else if(var3.equals("PKD.DROP_LPN_SUBXFR")) {
         var10001 = this.pdPage;
         this.pdPage.setCurrFldIndex(21);
         this.toLPNEntered(var1);
      }

   }

   public void dropLPNEntered(MWAEvent var1) throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException {
      UtilFns.log("PKDF: Drop LPN Entered");
      String var2 = this.pdPage.getZone().getSubinventoryCode();
      this.ses.putObject("oracle.apps.wms.td.server.PickDropPage.drop_sub", var2);
      long var3 = Long.parseLong(this.pdPage.getLoc().getLocatorID());
      this.ses.putObject("oracle.apps.wms.td.server.PickDropPage.drop_loc", "" + var3);
      UtilFns.log("PKDF: zoneConfirmed Method1" + var2 + var3);
      String var5 = (String)this.ses.getValue("oracle.apps.wms.td.server.PickDropPage.PKD.XFER_LPN");
      if(var5 != null && !var5.equals("")) {
         this.pdPage.getDropLPN().setInputParameters(new String[]{"", "oracle.apps.wms.td.server.PickDropPage.PKL.DROP_LPN", "oracle.apps.wms.td.server.PickDropPage.PKD.XFER_LPN", "ORGID", "oracle.apps.wms.td.server.PickDropPage.drop_sub", "oracle.apps.wms.td.server.PickDropPage.drop_loc"});
      } else {
         this.pdPage.getDropLPN().setInputParameters(new String[]{"", "oracle.apps.wms.td.server.PickDropPage.PKL.DROP_LPN", "PICKING_LPN", "ORGID", "oracle.apps.wms.td.server.PickDropPage.drop_sub", "oracle.apps.wms.td.server.PickDropPage.drop_loc"});
      }

   }

   private void toLPNEntered(MWAEvent var1) throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException {
      UtilFns.log("PKDF: To LPN Entered");
      String var2 = this.pdPage.getZone().getSubinventoryCode();
      this.ses.putObject("oracle.apps.wms.td.server.PickDropPage.drop_sub", var2);
      long var3 = Long.parseLong(this.pdPage.getLoc().getLocatorID());
      this.ses.putObject("oracle.apps.wms.td.server.PickDropPage.drop_loc", "" + var3);
      UtilFns.log("PKDF: zoneConfirmed toLPNEntered : " + var2 + var3);
      this.pdPage.getToLPN().setInputParameters(new String[]{"", "oracle.apps.wms.td.server.PickDropPage.PKD.DROP_LPN_SUBXFR", "PICKING_LPN", "ORGID", "oracle.apps.wms.td.server.PickDropPage.drop_sub", "oracle.apps.wms.td.server.PickDropPage.drop_loc"});
   }

   public void fieldExited(MWAEvent var1) throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException {
      if(var1.getAction().equals("MWA_SUBMIT") || var1.getAction().equals("MWA_NEXTFIELD")) {
         super.fieldExited(var1);
         this.ses = var1.getSession();
         this.pdPage = (PickDropPage)this.ses.getCurrentPage();
         String var2 = ((FieldBean)var1.getSource()).getName();
         if(UtilFns.isTraceOn) {
            UtilFns.log("MainPickPage.fieldExited - Current Action is " + var1.getAction());
         }

         if(this.pdPage.getCurrentFieldBean() instanceof InputableFieldBean) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: TdFHandler - current field is not instance of TdButton or action is not nextfield ");
            }

            UtilFns.populateLaborParameters(this.ses);
         }

         UtilFns.log("PKDF: TdFHandler - fieldExited for " + var2);
         if(var2.equals("PKD.CONTINUE")) {
            String var4 = this.ses.getPreviousPage().getName();
            if(var4.equalsIgnoreCase("oracle.apps.wms.td.server.MainPickPage")) {
               TdPage.fetchNextTask(var1);
            } else {
               ((ButtonFieldBean)var1.getSource()).setNextPageName(var4);
            }
         } else if(var2.equals("PKD.PICK_DROP_SUBMIT")) {
            if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
               this.pickDrop(var1);
            }
         } else if(var2.equals("PKD.CONFIRM_ZONE")) {
            this.zoneConfirmed(var1);
         } else if(var2.equals("PKD.CONFIRM_LOC")) {
            this.locConfirmed(var1);
         } else if(var2.equals("PKD.DROP_LPN")) {
            if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
               this.validateDropLPN(var1);
            } else {
               this.dropLPNConfirmed(var1);
            }
         } else if(var2.equals("TD.CANCEL")) {
            this.cancel(var1);
         } else if(var2.equals("PKD.CONFIRM_UOM")) {
            this.uomConfirmed(var1);
         } else if(var2.equals("PKD.CONFIRM_LOT")) {
            this.lotConfirmed(var1);
         } else if(var2.equals("PKD.CONFIRM_SERIAL")) {
            this.serialConfirmed(var1);
         } else if(var2.equals("PKD.DROP_DTL_BTN")) {
            this.dropDtlConfirmed(var1, "FLD_EXIT");
         } else if(var2.equals("PKD.CONFIRM_LPN")) {
            this.confirmLPNExited(var1);
         } else if(var2.equals("PKD.CONFIRM_ITEM")) {
            this.itemConfirmed(var1);
         } else if(var2.equals("PKD.CONFIRM_REV")) {
            this.revConfirmed(var1);
         } else if(var2.equals("PKD.LPN")) {
            this.LPNConfirmed(var1);
         } else if(!var2.equals("PKD.CONFIRM_QTY") && !var2.equals("PKD.CONF_LOT_QTY")) {
            if(var2.equals("PKD.XFER_LPN")) {
               this.xferLPNConfirmed(var1);
            } else if(var2.equals("PKD.CONFIRM_SN")) {
               this.snConfirmed(var1);
            } else if(!var2.equals("PKD.DEL_INFO_BTN") && !var2.equals("PKD.LOT_INFO_BTN") && !var2.equals("PKD.SERIAL_INFO_BTN")) {
               if(var2.equals("")) {
                  ;
               }
            } else {
               this.infoBtnClicked(var1);
            }
         } else {
            this.qtyConfirmed(var1);
         }
      }

   }

   private void zoneEntered(MWAEvent var1) throws AbortHandlerException {
      UtilFns.log("PKDF:zoneEntered");
      if(this.pdPage.getDropType().equals("SUB_XFER") && this.pdPage.getRestSubCode() == 1) {
         String var2 = this.pdPage.getRestItemID() + "";
         UtilFns.log("PKDF:Item : " + var2 + " is restricted at subinventory");
         SubinventoryLOV var3 = this.pdPage.getZone();
         var3.setlovStatement("INV_UI_ITEM_SUB_LOC_LOVS.GET_RESTRICTED_SUBS");
         var3.setInputParameterTypes(new String[]{"C", "N", "S", "AN"});
         String[] var4 = new String[]{" ", "ORGID", "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_ZONE", var2};
         var3.setInputParameters(var4);
      }

   }

   private void locEntered(MWAEvent var1) throws AbortHandlerException {
      UtilFns.log("PKDF: locEntered Method");
      LocatorKFF var2 = this.pdPage.getLoc();
      int var3 = Integer.parseInt(this.pdPage.getZone().getLocatorType());
      this.ses = var1.getSession();
      UtilFns.log("PKDF: finalLocatorControl = " + var3);
      if(var3 == 3) {
         var2.setValidateFromLOV(false);
      } else {
         var2.setValidateFromLOV(true);
      }

      String var4 = "";
      String var5 = "";
      if(this.pdPage.getDropType().equals("SUB_XFER") && this.pdPage.getRestLocCode() == 1L) {
         var4 = this.pdPage.getRestItemID() + "";
         var5 = "1";
         UtilFns.log("PKDF:Item : " + var4 + " is restricted at locator");
         var2.setInputParameterTypes(new String[]{"C", "N", "S", "AN", "AN", "S", "S", "S"});
      }

      String[] var6;
      if(this.pdPage.getDropType().equals("CONS_STG_MV") && this.pdPage.getConsolDeliveryID() != 0L) {
         if(!var2.getLOVType().equals("LOCTYPELOCS")) {
            var2.setLocatorKFF("LOCTYPELOCS");
            var6 = new String[]{" ", "ORGID", "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_ZONE", "2", "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_LOC"};
            var2.setInputParameters(var6);
         }
      } else {
         UtilFns.log("setting input params ");
         var6 = new String[]{" ", "ORGID", "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_ZONE", var5, var4, "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_LOC", "PROJECT", "TASK"};
         UtilFns.log("input params  are set ");
         var2.setInputParameters(var6);
      }

      if(UtilFns.isPJMOrg(this.ses)) {
         if(this.ses.getObject("PROJECT") != null && !this.ses.getObject("PROJECT").equals("")) {
            String var8 = (String)this.ses.getObject("PROJECT");
            String var7 = (String)this.ses.getObject("TASK");
            var2.setProjectTask(var8, var7);
         } else {
            var2.setProjectTask("", "");
         }
      }

   }

   private void zoneConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(var1.getAction().equals("MWA_SUBMIT") || var1.getAction().equals("MWA_NEXTFIELD")) {
         UtilFns.log("PKDF: zoneConfirmed Method");
         String var2;
         if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
            var2 = this.pdPage.getDropType();
            if(var2.equals("OVERPICK") || var2.equals("CANCELLED")) {
               return;
            }
         }

         if(var1.getAction().equals("MWA_SUBMIT") && !this.pdPage.getSugZone().getValue().equals(this.pdPage.getZone().getValue())) {
            this.pdPage.getDropLPN().setValue("");
            if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
               this.pdPage.getToLPN().setValue("");
            }

            UtilFns.log("PKDF: Drop LPN field cleared from zoneConfirmed Method");
         }

         var2 = this.pdPage.getZone().getSubinventoryCode();
         String var3 = "";
         if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
            var3 = "" + this.pdPage.getTempID();
         } else {
            var3 = (String)this.ses.getObject("TEMP_ID");
         }

         TextFieldBean var4 = this.pdPage.getSugZone();
         String var5 = var4.getValue();
         this.ses.putObject("TDSUBINVENTORY", var2);
         if(!var5.equals(var2)) {
            UtilFns.log("PKDF: Confirmed sub is different from suggested transfer sub");
            String[] var6 = new String[]{"p_temp_id", "p_confirmed_drop_sub", "x_return_status", "x_msg_count", "x_msg_data", "x_lpn_controlled_flag"};
            String[] var7 = new String[]{"I", "I", "O", "O", "O", "O"};
            String[] var8 = new String[]{"N", "V", "V", "N", "V", "V"};
            String[] var9 = new String[]{var3, var2};

            try {
               Hashtable var10 = UtilFns.ProcessAPI(this.ses.getConnection(), "WMS_Task_Dispatch_Gen.validate_pick_drop_sub", var6, var7, var8, var9);
               String var11 = (String)var10.get("x_return_status");
               String var12;
               if(var11 == null || !var11.equalsIgnoreCase("S")) {
                  var12 = UtilFns.getStackedMessages(this.ses);
                  if(UtilFns.isTraceOn) {
                     UtilFns.trace("PKDF:validate_pick_drop_sub returned error : " + var12);
                  }

                  this.ses.setStatusMessage(var12);
                  throw new AbortHandlerException("Error in validate_pick_drop_sub");
               }

               if(this.pdPage.getDropType().equals("SUB_XFER")) {
                  var12 = (String)var10.get("x_lpn_controlled_flag");
                  if(var12.equals("1")) {
                     this.pdPage.getToLPN().setHidden(false);
                     this.pdPage.setSubLpnControlled(true);
                     this.ses.setRefreshScreen(true);
                  } else {
                     this.pdPage.getToLPN().setHidden(true);
                     this.pdPage.setSubLpnControlled(false);
                     this.ses.setRefreshScreen(true);
                  }
               }
            } catch (SQLException var13) {
               if(UtilFns.isTraceOn) {
                  UtilFns.trace("Error in validate_pick_drop_sub API...:" + var13);
               }

               this.ses.setStatusMessage(UtilFns.getMessage(this.ses, "INV", "INV_MWA_DB_ERROR"));
               throw new AbortHandlerException("Error in validate_pick_drop_sub");
            }
         } else if(this.pdPage.getDropType().equals("SUB_XFER")) {
            if(this.pdPage.chkSubinvLpnControlled(this.ses, var2)) {
               this.pdPage.getToLPN().setHidden(false);
               this.pdPage.setSubLpnControlled(true);
               this.ses.setRefreshScreen(true);
            } else {
               this.pdPage.getToLPN().setHidden(true);
               this.pdPage.setSubLpnControlled(false);
               this.ses.setRefreshScreen(true);
            }
         }

         this.ses.setNextFieldName("PKD.CONFIRM_LOC");
      }

   }

   private void locConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.log("PKDF: locConfirmed Method");
      }

      String var2;
      if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
         var2 = this.pdPage.getDropType();
         if(var2.equals("OVERPICK") || var2.equals("CANCELLED")) {
            return;
         }
      }

      if(var1.getAction().equals("MWA_SUBMIT") && !this.pdPage.getSugLoc().getValue().equals(this.pdPage.getLoc().getValue())) {
         this.pdPage.getDropLPN().setValue("");
         if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
            this.pdPage.getToLPN().setValue("");
         }

         UtilFns.log("PKDF: Drop LPN field cleared from locConfirmed Method");
      }

      var2 = this.pdPage.getLoc().getLocator();
      String var3 = this.pdPage.getLoc().getLocatorID();
      String var4 = "";
      if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
         var4 = "" + this.pdPage.getTaskType();
      } else {
         var4 = (String)this.ses.getObject("n");
      }

      boolean var5 = false;
      int var22;
      if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
         var22 = this.pdPage.getTxnType();
      } else {
         var22 = Integer.parseInt((String)this.ses.getObject("PKD.TRAN_TYPE"));
      }

      TextFieldBean var6 = this.pdPage.getSugLoc();
      String var7 = var6.getValue();
      if(UtilFns.isTraceOn) {
         UtilFns.log("s_sugval : " + var7 + "   ConfValue : " + var2);
      }

      if(this.ses.getObject("TD_FROM_PAGE") != null && UtilFns.isTraceOn) {
         UtilFns.log("  TD_FROM_PAGE : " + this.ses.getObject("TD_FROM_PAGE").toString());
      }

      String var8 = "";
      String var9 = "";
      if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
         var9 = "" + this.pdPage.getTempID();
      } else {
         var9 = (String)this.ses.getObject("TEMP_ID");
      }

      if(!var2.equalsIgnoreCase(var7)) {
         if(var22 != 51 && (this.ses.getObject("TD_FROM_PAGE") == null || this.ses.getObject("TD_FROM_PAGE").toString().equals("PICKDROP"))) {
            UtilFns.log("PKDF: Call API to validate drop to locator");
            String[] var10 = new String[]{"x_return_status", "x_message", "p_task_type", "p_task_id", "p_locator_id"};
            String[] var11 = new String[]{"O", "O", "I", "I", "I"};
            String[] var12 = new String[]{"V", "V", "N", "N", "N"};
            String[] var13 = new String[]{var4, var9, var3};

            try {
               Hashtable var14 = UtilFns.ProcessAPI(this.ses.getConnection(), "WMS_OP_RUNTIME_PUB_APIS.validate_pick_drop_Locator", var10, var11, var12, var13);
               String var15 = (String)var14.get("x_return_status");
               String var16 = (String)var14.get("x_message");
               if(var15 == null || !var15.equalsIgnoreCase("S")) {
                  if(UtilFns.isTraceOn) {
                     UtilFns.trace("PKDF: validate_pick_drop_Locator returned with status: " + var15 + " and error message : " + var16);
                  }

                  if(var15 == null || !var15.equalsIgnoreCase("W")) {
                     this.ses.setStatusMessage(var16);
                     throw new AbortHandlerException("Error in validate_pick_drop_Locator");
                  }

                  String var17 = (String)this.ses.getObject("CONFIRM_LOC_VALUE");
                  if(var17 == null) {
                     this.ses.putObject("CONFIRM_LOC_VALUE", this.pdPage.getLoc().getValue());
                  } else if(var17.equalsIgnoreCase(this.pdPage.getLoc().getValue())) {
                     locWarningDisplayed = false;
                  } else {
                     locWarningDisplayed = true;
                     this.ses.putObject("CONFIRM_LOC_VALUE", this.pdPage.getLoc().getValue());
                  }

                  UtilFns.trace("PKDF: Value of locWarningDisplayed=" + locWarningDisplayed);
                  if(locWarningDisplayed) {
                     UtilFns.trace("PKDF: Locator API Warning message will be displayed");
                  } else {
                     UtilFns.trace("PKDF: Locator API Warning message already displayed.  Will not be displayed again");
                  }

                  if(locWarningDisplayed) {
                     String[] var18 = new String[]{MWALib.getAKPrompt(this.ses, "oracle.apps.inv.utilities.InvResourceTable", "INV_NO_PROMPT"), MWALib.getAKPrompt(this.ses, "oracle.apps.inv.utilities.InvResourceTable", "INV_YES_PROMPT")};
                     TelnetSession var19 = (TelnetSession)this.ses;
                     int var20 = var19.showPromptPage(MWALib.getAKPrompt(this.ses, "oracle.apps.inv.utilities.InvResourceTable", "INV_WARNING_PROMPT"), var16, var18);
                     if(var20 == 0) {
                        throw new AbortHandlerException("User abort the warning page in validate_pick_drop_Locator");
                     }
                  }
               }
            } catch (SQLException var21) {
               if(UtilFns.isTraceOn) {
                  UtilFns.trace("Exception in validate_pick_drop_Locator API...:" + var21);
               }

               this.ses.setStatusMessage(UtilFns.getMessage(this.ses, "INV", "INV_MWA_DB_ERROR"));
               throw new AbortHandlerException("Exception in validate_pick_drop_Locator");
            }
         }

         UtilFns.log("PKDF: different loc entered by user");
         if(this.ses.getObject("TD_DIS_CONF") == null) {
            var8 = "N";
         } else {
            var8 = this.ses.getObject("TD_DIS_CONF").toString();
         }

         if(var8.equalsIgnoreCase("N")) {
            UtilFns.log("PKDF: Loc Discrepancy");
            String var23 = "";
            if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
               var23 = "" + this.pdPage.getTaskType();
            } else {
               var23 = (String)this.ses.getObject("PKD.TASK_TYPE");
            }

            if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
               this.ses.putObject("REASON_TYPE", "2");
            } else {
               this.ses.putObject("REASON_TYPE", var23.equals("4")?"4":"1");
            }

            this.ses.putObject("TD_FROM_PAGE", "PICKDROP");
            this.ses.putObject("LOC_DESCRIPENCY", "Y");
            this.pdPage.getLoc().setNextPageName("oracle.apps.wms.td.server.AuditPage");
            this.ses.putObject("pd_curr_field", "INV.LOC");
            if(UtilFns.wmsReleaseJOrHigher(this.ses)) {
               this.pdPage.setReenterPage();
            }
         } else {
            UtilFns.log("PKDF: Loc Discrepancy Taken Care of Already");
            this.pdPage.getLoc().setNextPageName((String)null);
         }

         this.pdPage.getDropLPN().setValue("");
      } else {
         UtilFns.log("PKDF: Suggested loc equals confirmed loc");
         this.pdPage.getLoc().setNextPageName((String)null);
         this.ses.putObject("LOC_DESCRIPENCY", "N");
         this.ses.putObject("PKD_LOC_RSN", "0");
      }

   }

   private void dropLPNConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.log("PKDF: dropLPNConfirmed Method");
      }

      String var2 = (String)((String)this.ses.getObject("TD_GEN_DROP_LPN"));
      UtilFns.log("PKDF: Generated drop lpn: " + var2);
      String var3 = ((LPNLOV)var1.getSource()).getValue().trim();
      UtilFns.log("PKDF:LPN value after trim:" + var3);
      this.ses.putObject("oracle.apps.wms.td.server.PickDropPage.s_drop_lpn", var3);
      String var4 = this.pdPage.getZone().getSubinventoryCode();
      long var5 = Long.parseLong(this.pdPage.getLoc().getLocatorID());
      int var7 = Integer.parseInt((String)this.ses.getObject("PKD.TRAN_TYPE"));
      long var8 = Long.parseLong(this.ses.getObject("ORGID").toString());
      long var10 = Long.parseLong(this.ses.getObject("PICKING_LPN").toString());
      if(var3 != null && !var3.equalsIgnoreCase("")) {
         if(var2 != null && var2.equals(var3)) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: Drop LPN is newly generated, no validations required.");
            }

         } else if(var7 == 51) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: Transaction type is sub transfer for WIP backflush or replenishment.");
            }

         } else {
            Connection var12 = this.ses.getConnection();
            OracleCallableStatement var13 = null;
            long var14 = 0L;

            try {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Picked LPN: " + var10);
                  UtilFns.log("PKDF: Org ID: " + var8);
                  UtilFns.log("PKDF: Drop LPN: " + var3);
                  UtilFns.log("PKDF: Staging Sub: " + var4);
                  UtilFns.log("PKDF: Staging Loc: " + var5);
               }

               var13 = (OracleCallableStatement)var12.prepareCall("BEGIN :1 := wms_task_dispatch_gen.validate_pick_drop_lpn(:2,:3,:4,:5,:6,:7,:8); END;");
               var13.registerOutParameter(1, 2);
               var13.setDouble(2, 1.0D);
               var13.setString(3, "T");
               var13.setLong(4, var10);
               var13.setLong(5, var8);
               var13.setString(6, var3);
               var13.setString(7, var4);
               var13.setLong(8, var5);
               var13.executeQuery();
               var14 = var13.getLong(1);
            } catch (Exception var24) {
               UtilFns.log("PKDF: dropLPNConfirmed Exception: " + var24);
               this.ses.setRefreshScreen(true);
               throw new AbortHandlerException("Error when validating drop LPN.");
            } finally {
               try {
                  if(var13 != null) {
                     var13.close();
                  }
               } catch (SQLException var23) {
                  UtilFns.log("PKDF: SQL Exception closing cstmt in dropLPNConfirmed().");
                  throw new AbortHandlerException("SQL error in dropLPNConfirmed().");
               }

            }

            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: After calling validate_pick_drop_lpn");
               UtilFns.log("PKDF: Return value: " + var14);
            }

            if(var14 == 1L) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Drop LPN validated successfully.");
               }

            } else if(var14 == 2L) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Drop LPN failed validations. Different Sub/loc");
               }

               this.ses.setStatusMessage(UtilFns.getMessage(this.ses, "WMS", "WMS_DROP_LPN_SUBLOC_MISMATCH"));
               throw new AbortHandlerException("Drop LPN validation failed.");
            } else if(var14 == 3L) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Drop LPN failed validations. Pick and Drop LPN Same");
               }

               this.ses.setStatusMessage(UtilFns.getMessage(this.ses, "WMS", "WMS_DROP_PICK_LPN_SAME"));
               throw new AbortHandlerException("Drop LPN validation failed.");
            } else if(var14 == 4L) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Drop LPN failed validations. Drop LPN is loaded to dock door already");
               }

               this.ses.setStatusMessage(UtilFns.getMessage(this.ses, "WMS", "WMS_DROP_LPN_LOADED"));
               throw new AbortHandlerException("Drop LPN validation failed.");
            } else {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Drop LPN failed validations.");
               }

               this.ses.setStatusMessage(UtilFns.getMessage(this.ses, "WMS", "WMS_DROP_LPN_DIFF_DELIV"));
               throw new AbortHandlerException("Drop LPN validation failed.");
            }
         }
      } else {
         if(UtilFns.isTraceOn) {
            UtilFns.log("PKDF: No drop LPN specified, so nothing to validate. Return.");
         }

      }
   }

   private void cancel(MWAEvent var1) throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException {
      if(var1.getAction().equals("MWA_SUBMIT")) {
         if(UtilFns.isTraceOn) {
            UtilFns.log("PKDF: Cancel Method");
         }

         Session var2 = var1.getSession();
         Connection var3 = var2.getConnection();
         UtilFns.executeDFFUpdate(var1.getSession(), false);
         long var4 = Long.parseLong(var2.getObject("EMPID").toString());
         String var6 = "";
         long var7 = 0L;
         if(!UtilFns.wmsReleaseJOrHigher(var2)) {
            var6 = (String)var2.getObject("TEMP_ID");
            var7 = Long.parseLong(var6);
         }

         try {
            if(UtilFns.wmsReleaseJOrHigher(var2)) {
               this.pdPage.cancelTask(var2);
            }

            UtilFns.initializeLaborParameters(var2);
            this.pdPage.callDevRequestCancelComplete(var1.getSession(), 53, "U");
         } catch (Exception var10) {
            var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_TASK_ERROR"));
            var2.setRefreshScreen(true);
         }

      }
   }

   private boolean proceedDropTask(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: in  proceedDropTask ");
      }

      Session var2 = var1.getSession();
      String var3 = var2.getObject("PICKING_LPN").toString();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: lpn_id  " + var3);
      }

      Connection var4 = var2.getConnection();
      long var5 = Long.parseLong(var3);
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: lpn Id  after long conv " + var5);
      }

      OracleCallableStatement var7 = null;
      String var8 = "X";

      label163: {
         boolean var9;
         try {
            var7 = (OracleCallableStatement)var4.prepareCall("BEGIN :1 := WMS_TASK_UTILS_pvt.can_drop(:2); END;");
            var7.registerOutParameter(1, 12, 0, 5);
            var7.setLong(2, var5);
            var7.execute();
            var8 = var7.getString(1);
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PKDF:  result is " + var8);
            }

            if(!var8.equalsIgnoreCase("Y")) {
               break label163;
            }

            var9 = true;
         } catch (Exception var20) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PKDF:  unload failed with mesg " + var20);
            }
            break label163;
         } finally {
            try {
               if(var7 != null) {
                  var7.close();
               }
            } catch (SQLException var19) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: SQL exception when closing cstmt in proceedDropTask().");
               }
            }

         }

         return var9;
      }

      if(var8.equalsIgnoreCase("W")) {
         var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_LPN_CANCEL_TASKS2"));
         throw new AbortHandlerException("PKDF: Task Drop Error");
      } else if(var8.equalsIgnoreCase("N")) {
         var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_LPN_WIP_CANCEL_JOB"));
         throw new AbortHandlerException("PKDF: Wip Task Drop Error");
      } else {
         return true;
      }
   }

   private void revertSuggestedCapacity(Hashtable var1, Connection var2) throws AbortHandlerException {
      String[] var3 = new String[]{"x_return_status", "x_msg_count", "x_msg_data", "p_organization_id", "p_inventory_location_id", "p_inventory_item_id", "p_primary_uom_flag", "p_transaction_uom_code", "p_quantity"};
      String[] var4 = new String[]{"O", "O", "O", "I", "I", "I", "I", "I", "I"};
      String[] var5 = new String[]{"V", "N", "V", "N", "N", "N", "V", "V", "N"};
      String var6 = (String)var1.get("Item");
      String var7 = (String)var1.get("Qty");
      String var8 = (String)var1.get("Uom");
      String var9 = (String)var1.get("LocID");
      String[] var10 = new String[]{this.ses.getObject("ORGID").toString(), var9, var6, "N", var8, var7};
      if(UtilFns.isTraceOn) {
         UtilFns.log("PKDF: item ID is " + var6);
         UtilFns.log("PKDF: txn Qty is " + var7);
         UtilFns.log("PKDF: txn Uom is " + var8);
         UtilFns.log("PKDF: Sug Loc is " + var9);
         UtilFns.log("PKDF: Before Calling revert_loc_suggested_capacity");
      }

      try {
         Hashtable var11 = UtilFns.ProcessAPI(var2, "INV_LOC_WMS_UTILS.revert_loc_suggested_capacity", var3, var4, var5, var10);
         if(UtilFns.isTraceOn) {
            UtilFns.log("PKDF: After calling revert, l_status is " + var11.get("x_return_status").toString());
            UtilFns.log("PKDF: l_msg_count is " + var11.get("x_msg_count").toString());
            UtilFns.log("PKDF: L_msg_data is " + var11.get("x_msg_data").toString());
         }
      } catch (Exception var12) {
         ;
      }

   }

   private void uomEntered(MWAEvent var1) {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: fieldEntered of UOM");
      }

      UomLOV var2 = this.pdPage.getConfUOMLOV();
      if(UtilFns.isTraceOn) {
         UtilFns.log("Item ID: " + this.currDropDetail.mItemID);
         UtilFns.log("UOM code: " + this.currDropDetail.mUOMLookupCode);
      }

      String[] var3 = new String[]{" ", "ORGID", "" + this.currDropDetail.mItemID, "" + this.currDropDetail.mUOMLookupCode, "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_UOM"};
      var2.setInputParameters(var3);
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKLF: After setting UOM params");
      }

   }

   private void uomConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside uomConfirmed()");
      }

      String var2 = ((UomLOV)var1.getSource()).getUomCode();
      Session var3 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: UOM Entered: " + var2);
      }

      if(!var2.equals(this.currDropDetail.mUOMCode)) {
         String var4 = var3.getObject("ORGID").toString();

         try {
            Connection var5 = var3.getConnection();
            double var6 = UtilFns.convert_uom(var5, var4, "" + this.currDropDetail.mItemID, "" + this.currDropDetail.mPrimaryQty, "", this.currDropDetail.mUOMCode, "", var2, "");
            this.currDropDetail.mConvQty = var6;
            this.currDropDetail.mConfUOMCode = var2;
            double var8 = UtilFns.convert_uom(var5, var4, "" + this.currDropDetail.mItemID, "" + this.currDropDetail.mRemPrimaryQty, "", this.currDropDetail.mUOMCode, "", var2, "");
            this.currDropDetail.mRemConvQty = var8;
         } catch (SQLException var10) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PKDF: Error - Unable to convert UOM:" + var10.toString());
            }

            var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_UOM_CONV_ERROR"));
            var3.setRefreshScreen(true);
            throw new AbortHandlerException("Error in UOM Conversion");
         }
      } else {
         this.currDropDetail.mConvQty = 0.0D;
         this.currDropDetail.mConfUOMCode = "";
         this.currDropDetail.mRemConvQty = 0.0D;
      }

      this.pdPage.setQty(var3);
   }

   private void lotEntered(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: fieldEntered of Lot Confirm");
      }

      LOVFieldBean var2 = this.pdPage.getConfLotLOV();
      var2.setlovStatement("wms_pick_drop_pvt.get_lot_lov");
      Session var3 = var1.getSession();
      if(lotPrompt.equalsIgnoreCase("")) {
         try {
            lotPrompt = MWALib.getAKPrompt(var3, "oracle.apps.inv.utilities.InvResourceTable", "INV_LOT_PROMPT");
         } catch (SQLException var9) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PKDF: SQL Exception getting AK prompt: " + var9);
            }

            throw new AbortHandlerException("SQL error getting AK prompt");
         }
      }

      if(quantityPrompt.equalsIgnoreCase("")) {
         try {
            quantityPrompt = MWALib.getAKPrompt(var3, "oracle.apps.inv.utilities.InvResourceTable", "INV_QUANTITY_PROMPT");
         } catch (SQLException var8) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PKDF: SQL Exception getting AK prompt: " + var8);
            }

            throw new AbortHandlerException("SQL error getting AK prompt");
         }
      }

      String[] var4 = new String[]{lotPrompt, quantityPrompt};
      var2.setSubfieldPrompts(var4);
      boolean[] var5 = new boolean[]{true, true};
      var2.setSubfieldDisplays(var5);
      String[] var6 = new String[]{"C", "AN", "AS", "AS", "AS", "S"};
      var2.setInputParameterTypes(var6);
      String[] var7 = new String[]{" ", "" + this.currDropDetail.mItemID, this.currDropDetail.mRevision, this.currDropDetail.mInnerLPN, this.currDropDetail.mConfUOMCode, "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_LOT"};
      var2.setInputParameters(var7);
   }

   private void lotConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside lotConfirmed()");
      }

      String var2 = ((LOVFieldBean)var1.getSource()).getValue();
      Session var3 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Lot Suggested: " + this.currDropDetail.mLotNumber);
         UtilFns.trace("PKDF: Lot Entered: " + var2);
      }

      if(!var2.equals(this.currDropDetail.mLotNumber)) {
         Vector var4 = this.pdPage.getDropList();
         int var5 = 0;
         int var6 = var4.size();

         boolean var7;
         for(var7 = false; var5 < var6 && !var7; ++var5) {
            PickDropDetail var8 = (PickDropDetail)var4.elementAt(var5);
            if(var8.mItemID == this.currDropDetail.mItemID && var8.mRevision.equals(this.currDropDetail.mRevision) && var8.mInnerLPN.equals(this.currDropDetail.mInnerLPN) && var8.mLotNumber.equals(var2)) {
               var7 = true;
            }
         }

         --var5;
         if(!var7) {
            var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_CONT_INVALID_LOT"));
            throw new AbortHandlerException("Cannot find scanned lot in drop details vector");
         }

         this.pdPage.setCurrDropIndex(var5);
         this.pdPage.setupPage(var3);
      }

   }

   private void serialEntered(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: fieldEntered of Serial Confirm");
      }

      LOVFieldBean var2 = this.pdPage.getConfSerialLOV();
      var2.setlovStatement("wms_pick_drop_pvt.get_serial_lov");
      Session var3 = var1.getSession();
      if(snPrompt.equalsIgnoreCase("")) {
         try {
            snPrompt = MWALib.getAKPrompt(var3, "oracle.apps.inv.utilities.InvResourceTable", "INV_SERIAL_PROMPT");
         } catch (SQLException var8) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PKDF: SQL Exception getting AK prompt: " + var8);
            }

            throw new AbortHandlerException("SQL error getting AK prompt");
         }
      }

      String[] var4 = new String[]{snPrompt};
      var2.setSubfieldPrompts(var4);
      boolean[] var5 = new boolean[]{true};
      var2.setSubfieldDisplays(var5);
      String[] var6 = new String[]{"C", "AN", "AS", "AS", "AS", "S"};
      var2.setInputParameterTypes(var6);
      String[] var7 = new String[]{" ", "" + this.currDropDetail.mItemID, this.currDropDetail.mRevision, this.currDropDetail.mInnerLPN, this.currDropDetail.mLotNumber, "oracle.apps.wms.td.server.PickDropPage.PKD.CONFIRM_SERIAL"};
      var2.setInputParameters(var7);
   }

   private void itemEntered(MWAEvent var1) {
      TextFieldBean var2 = this.pdPage.getConfItemFld();
      if(!delimChecked) {
         if(UtilFns.isTraceOn) {
            UtilFns.trace("PKDF: fieldEntered of Item Confirm");
         }

         delimChecked = true;
         Session var4 = var1.getSession();
         Connection var5 = var4.getConnection();

         try {
            AppsContext var6 = (AppsContext)((AppsContext)var4.getObject("CTX"));
            if(var6 != null) {
               ProfileStore var7 = var6.getProfileStore();
               itemRevDelim = var7.getProfile("WMS_ITEM_REVISION_DELIMITER");
               if(UtilFns.isTraceOn) {
                  UtilFns.trace("Profile value for delimiter is: " + itemRevDelim);
               }
            } else if(UtilFns.isTraceOn) {
               UtilFns.trace("Could not retrieve the CTX object from session!");
            }
         } catch (Exception var8) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("Exception while retrieving profile value: " + var8);
            }

            itemRevDelim = "";
         }
      }

      if(itemRevDelim != null && !itemRevDelim.equalsIgnoreCase("") && !itemRevDelim.equalsIgnoreCase("null")) {
         if(UtilFns.isTraceOn) {
            UtilFns.log("Delimiter is: " + itemRevDelim);
         }

         char var3 = itemRevDelim.charAt(0);
         var2.setBarcodeDelimiter(var3);
      }

   }

   private void serialConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside serialConfirmed()");
      }

      LOVFieldBean var2 = (LOVFieldBean)var1.getSource();
      String var3 = var2.getValue();
      String var4 = (String)this.currDropDetail.mSerialList.firstElement();
      Session var5 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PickDropFListener.serialConfirmed: Serial Suggested: " + var4);
         UtilFns.trace("PickDropFListener.serialConfirmed: Serial Entered: " + var3);
         UtilFns.trace("PickDropFListener.serialConfirmed: Serial List: " + this.currDropDetail.mSerialList);
         UtilFns.trace("PickDropFListener.serialConfirmed: Current Field Index: " + this.pdPage.getCurrFldIndex());
         UtilFns.trace("PickDropFListener.serialConfirmed: Remaining Primary Quantity: " + this.currDropDetail.mRemPrimaryQty);
      }

      int var6 = 0;
      int var7 = this.currDropDetail.mSerialList.size();

      boolean var8;
      for(var8 = false; var6 < var7 && !var8; ++var6) {
         String var9 = (String)this.currDropDetail.mSerialList.elementAt(var6);
         if(var9.equals(var3)) {
            var8 = true;
         }
      }

      --var6;
      if(var8) {
         this.currDropDetail.mSerialList.removeElementAt(var6);
         Connection var10 = var5.getConnection();
         PreparedStatement var11 = null;

         try {
            var11 = var10.prepareStatement(serialDelSQL);
            var11.setLong(1, this.currDropDetail.mItemID);
            var11.setString(2, var3);
            int var12 = var11.executeUpdate();
            if(var12 != 1) {
               throw new AbortHandlerException("Invalid row count from serial delete: " + var12);
            }
         } catch (SQLException var20) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PKDF: SQL Exception deleting serial number: " + var20);
            }

            throw new AbortHandlerException("SQL error deleting serials");
         } finally {
            try {
               if(var11 != null) {
                  var11.close();
               }
            } catch (Exception var19) {
               throw new AbortHandlerException("Exception closing prepared statement for serial delete: " + var19);
            }

         }

         --this.currDropDetail.mRemPrimaryQty;
         if(this.currDropDetail.mSerialList.size() > 0) {
            this.pdPage.setReenterPage();
            this.pdPage.setupPage(var5);
            var2.setValue("");
         } else {
            this.pdPage.unsetReenterPage();
         }

      } else {
         var5.setStatusMessage(UtilFns.getMessage(var5, "WMS", "WMS_CONT_INVALID_SER"));
         throw new AbortHandlerException("Cannot find scanned serial in drop detail serial vector: " + this.currDropDetail.mSerialList.toString());
      }
   }

   private void dropDtlConfirmed(MWAEvent var1, String var2) throws AbortHandlerException {
      Session var3 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PickDropFListener.dropDtlConfirmed: Called From: " + var2);
      }

      if(var2.equals("FLD_EXIT")) {
         if(!var1.getAction().equals("MWA_SUBMIT")) {
            return;
         }

         if(var1.getAction().equals("MWA_SUBMIT")) {
            if(UtilFns.isTraceOn) {
               UtilFns.trace("PickDropFListener.dropDtlConfirmed: Remaining Primary Quantity: " + this.currDropDetail.mRemPrimaryQty);
            }

            if(this.currDropDetail.mRemPrimaryQty > 0.0D) {
               if(this.currDropDetail.mSerialControl && !this.currDropDetail.mSerialAlloc && this.pdPage.isBulkPick()) {
                  var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_ENTER_SERIAL"));
                  throw new AbortHandlerException("Serial not confirmed.");
               }

               if(this.pdPage.isBulkPick() && this.currDropDetail.mLotAlloc || !this.pdPage.isBulkPick()) {
                  if(this.currDropDetail.mSerialControl) {
                     var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_ENTER_SERIAL"));
                     throw new AbortHandlerException("Serial not confirmed.");
                  }

                  var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_ENTER_QUANTITY"));
                  throw new AbortHandlerException("Quantity not confirmed.");
               }
            }
         }
      }

      int var4 = this.pdPage.getDropList().size();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("Remaining drops: " + var4);
      }

      if(var4 == 1) {
         this.pdPage.getDropList().removeElementAt(0);
         this.pdPage.setCurrDropIndex(0);
         this.pdPage.setupPage(var3);
      } else {
         if(var4 <= 1) {
            var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_UNEXPECTED_ERROR"));
            throw new AbortHandlerException("No drop details found!");
         }

         this.pdPage.deleteCurrentDrop();
         this.pdPage.setupPage(var3);
      }

   }

   private void confirmLPNExited(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside confirmLPNExited()");
      }

      String var2 = ((TextFieldBean)var1.getSource()).getValue();
      String var3 = "";
      Session var4 = var1.getSession();
      if(this.currDropDetail != null) {
         if(UtilFns.isTraceOn) {
            UtilFns.trace("PKDF: confirmLPNExited().  Bulk picking is TRUE");
         }

         if(!this.currDropDetail.mContentLPN.equalsIgnoreCase("")) {
            var3 = this.currDropDetail.mContentLPN;
         } else {
            var3 = this.currDropDetail.mInnerLPN;
         }
      }

      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Suggested LPN: " + var3);
         UtilFns.trace("PKDF: Confirmed LPN: " + var2);
      }

      if(!var3.equals("") && !var2.equals(var3)) {
         var4.setStatusMessage(UtilFns.getMessage(var4, "WMS", "WMS_CONF_LPN_MATCH_SUGG"));
         throw new AbortHandlerException("Confirmed LPN does not match suggested LPN");
      } else {
         if(var2 != null && !var2.equals("")) {
            this.pdPage.getDropLPN().setValue(var2);
         }

      }
   }

   private void itemConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside itemConfirmed()");
      }

      String var2 = ((TextFieldBean)var1.getSource()).getValue();
      String var3 = this.currDropDetail.mItemNumber;
      Session var4 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Suggested Item: " + var3);
         UtilFns.trace("PKDF: Confirmed Item: " + var2);
      }

      if(UtilFns.wmsReleaseJOrHigher(var4)) {
         Connection var5 = var4.getConnection();
         OracleCallableStatement var6 = null;
         String var7 = "";
         String var8 = "";
         String var9 = "";
         String var10 = "";

         try {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDP: Before calling wms_pick_drop_pvt.process_conf_item");
            }

            long var11 = this.pdPage.getOrgID();
            long var13 = this.pdPage.getDropLPNID();
            var6 = (OracleCallableStatement)var5.prepareCall("{call wms_pick_drop_pvt.process_conf_item(:1,:2,:3,:4,:5,:6,:7,:8)}");
            String var15 = null;
            var6.registerOutParameter(1, 12, 0, 10);
            var6.registerOutParameter(2, 12, 0, 1600);
            var6.registerOutParameter(3, 12, 0, 6);
            var6.registerOutParameter(4, 12, 0, 6);
            var6.registerOutParameter(5, 12, 0, 5);
            var6.setLong(6, var11);
            var6.setLong(7, var13);
            var6.setString(8, var2);
            var6.executeQuery();
            var15 = "" + var6.getString(5);
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: Status: " + var15);
            }

            if(!var15.equals("S")) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Error from wms_pick_drop_pvt.process_conf_item");
               }

               if(var15.equals("E")) {
                  var4.setStatusMessage(UtilFns.getStackedMessages(var4));
               } else {
                  var4.setStatusMessage(UtilFns.getMessage(var4, "WMS", "WMS_UNEXPECTED_ERROR"));
               }

               var4.setRefreshScreen(true);
               throw new AbortHandlerException("API to process item scan failed");
            }

            var7 = var6.getString(1);
            if(var7.equals("TRUE")) {
               var8 = var6.getString(2);
               var9 = var6.getString(3);
               if(var9 == null) {
                  var9 = "";
               }

               var10 = var6.getString(4);
            }
         } catch (Exception var23) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: PickDropFListener Exception: " + var23);
            }

            var4.setRefreshScreen(true);
            throw new AbortHandlerException("Error when processing item scan");
         } finally {
            try {
               if(var6 != null) {
                  var6.close();
               }
            } catch (SQLException var22) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDP: SQL Exception closing cstmt in PickDropFListener().");
               }

               throw new AbortHandlerException("SQL error in PickDropFListener().");
            }

         }

         if(UtilFns.isTraceOn) {
            UtilFns.log("PKDF: isXRef:       " + var7);
            UtilFns.log("PKDF: itemSegments: " + var8);
            UtilFns.log("PKDF: itemRev:      " + var9);
            UtilFns.log("PKDF: uomCode:      " + var10);
         }

         if(var7.equals("TRUE") && !var8.equals(var3) || !var7.equals("TRUE") && !var2.equals(var3)) {
            var4.setStatusMessage(UtilFns.getMessage(var4, "WMS", "WMS_CONF_ITEM_MATCH_SUGG"));
            throw new AbortHandlerException("Confirmed item does not match suggested item");
         }

         if(var7.equals("TRUE")) {
            this.pdPage.getConfItemFld().setValue(var8);
            if(!var9.equalsIgnoreCase("")) {
               this.pdPage.getConfRevFld().setValue(var9);
            }

            this.pdPage.getConfUOMLOV().setValue(var10);
         }
      } else if(!var2.equals(var3)) {
         var4.setStatusMessage(UtilFns.getMessage(var4, "WMS", "WMS_CONF_ITEM_MATCH_SUGG"));
         throw new AbortHandlerException("Confirmed item does not match suggested item");
      }

   }

   private void revConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside revConfirmed()");
      }

      String var2 = ((TextFieldBean)var1.getSource()).getValue();
      String var3 = this.currDropDetail.mRevision;
      Session var4 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Suggested Rev: " + var3);
         UtilFns.trace("PKDF: Confirmed Rev: " + var2);
      }

      if(!var2.equals(var3)) {
         var4.setStatusMessage(UtilFns.getMessage(var4, "WMS", "WMS_CONF_REV_MATCH_SUGG"));
         throw new AbortHandlerException("Confirmed revision does not match suggested revision");
      }
   }

   private void LPNConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside LPNConfirmed()");
      }

      String var2 = ((TextFieldBean)var1.getSource()).getValue();
      if(var2 == null) {
         var2 = "";
      }

      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Entered LPN: " + var2);
         UtilFns.trace("PKDF: Group #: " + this.currDropDetail.mGroupNum);
         UtilFns.trace("PKDF: Item: " + this.currDropDetail.mItemNumber);
         UtilFns.trace("PKDF: Revision: " + this.currDropDetail.mRevision);
         UtilFns.trace("PKDF: Primary qty: " + this.currDropDetail.mPrimaryQty);
         UtilFns.trace("PKDF: Primary UOM: " + this.currDropDetail.mUOMCode);
         UtilFns.trace("PKDF: Remaining qty: " + this.currDropDetail.mRemPrimaryQty);
         UtilFns.trace("PKDF: Serial control? " + (this.currDropDetail.mSerialControl?"TRUE":"FALSE"));
      }

      if(!var2.equalsIgnoreCase("")) {
         Session var3 = var1.getSession();
         Connection var4 = var3.getConnection();
         OracleCallableStatement var5 = null;
         double var7 = 0.0D;
         String var9 = "";

         int var6;
         try {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDP: Before calling wms_pick_drop_pvt.process_inner_lpn");
            }

            var5 = (OracleCallableStatement)var4.prepareCall("{call wms_pick_drop_pvt.process_inner_lpn(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11)}");
            String var10 = null;
            var5.registerOutParameter(1, 2);
            var5.registerOutParameter(2, 2);
            var5.registerOutParameter(3, 12, 0, 5);
            var5.registerOutParameter(4, 12, 0, 5);
            var5.setString(5, var2);
            var5.setInt(6, this.currDropDetail.mGroupNum);
            var5.setLong(7, this.currDropDetail.mItemID);
            var5.setString(8, this.currDropDetail.mRevision);
            var5.setDouble(9, this.currDropDetail.mRemPrimaryQty);
            var5.setString(10, this.currDropDetail.mUOMCode);
            var5.setString(11, this.currDropDetail.mSerialControl?"TRUE":"FALSE");
            var5.executeQuery();
            var10 = "" + var5.getString(4);
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: Status: " + var10);
            }

            if(!var10.equals("S")) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Error from wms_pick_drop_pvt.process_inner_lpn");
               }

               if(var10.equals("E")) {
                  var3.setStatusMessage(UtilFns.getStackedMessages(var3));
               } else {
                  var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_UNEXPECTED_ERROR"));
               }

               var3.setRefreshScreen(true);
               throw new AbortHandlerException("API to process scanned LPN failed");
            }

            var6 = var5.getInt(1);
            if(var6 == 3) {
               var7 = var5.getDouble(2);
               var9 = "" + var5.getString(3);
            }
         } catch (Exception var20) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: PickDropFListener Exception: " + var20);
            }

            var3.setRefreshScreen(true);
            throw new AbortHandlerException("Error when processing scanned LPN");
         } finally {
            try {
               if(var5 != null) {
                  var5.close();
               }
            } catch (SQLException var18) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDP: SQL Exception closing cstmt in PickDropFListener().");
               }

               throw new AbortHandlerException("SQL error in PickDropFListener().");
            }

         }

         if(UtilFns.isTraceOn) {
            UtilFns.log("PKDF: returnCode: " + var6);
            UtilFns.log("PKDF: remainingQty: " + var7);
            UtilFns.log("PKDF: innerLPNExists: " + var9);
         }

         switch(var6) {
         case 1:
            this.currDropDetail.mInnerLPN = var2;
            if(!this.currDropDetail.mLooseConfirmed) {
               this.currDropDetail.mLooseConfirmed = true;
            }

            this.pdPage.setupPage(var3);
            if(this.currDropDetail.mSerialControl) {
               var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_ENTER_SERIAL"));
            } else {
               var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_ENTER_QUANTITY"));
            }
            break;
         case 2:
            this.dropDtlConfirmed(var1, "OTHER");
            break;
         case 3:
            this.currDropDetail.mRemPrimaryQty = var7;
            if(!this.currDropDetail.mConfUOMCode.equalsIgnoreCase("")) {
               try {
                  double var22 = UtilFns.convert_uom(var4, "" + this.pdPage.getOrgID(), "" + this.currDropDetail.mItemID, "" + this.currDropDetail.mRemPrimaryQty, "", this.currDropDetail.mUOMCode, "", this.currDropDetail.mConfUOMCode, "");
                  this.currDropDetail.mRemConvQty = var22;
               } catch (SQLException var19) {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDP: SQL Exception calling UtilFns.convert_uom: " + var19);
                  }

                  throw new AbortHandlerException("SQL error in PickDropFListener().");
               }
            }

            this.currDropDetail.mInnerLPNexists = var9.equals("Y");
            this.pdPage.setupPage(var3);
         }

      }
   }

   private void qtyConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside qtyConfirmed()");
      }

      Session var2 = var1.getSession();
      String var3 = ((NumberFieldBean)var1.getSource()).getNumberValue();
      if(var3 == null) {
         var3 = "";
      }

      if(UtilFns.isTraceOn) {
         UtilFns.log("Confirmed qty: " + var3);
      }

      double var4 = 0.0D;
      double var6 = 0.0D;
      double var8 = 0.0D;
      String var10 = "";
      Connection var11 = var2.getConnection();
      if(!this.currDropDetail.mConfUOMCode.equalsIgnoreCase("")) {
         var4 = this.currDropDetail.mRemConvQty;
      } else {
         var4 = this.currDropDetail.mRemPrimaryQty;
      }

      if(!var3.equals("")) {
         try {
            var6 = Double.valueOf(var3).doubleValue();
         } catch (Exception var22) {
            var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_NUMBER_EXPECTED"));
            throw new AbortHandlerException("Number Expected." + var22);
         }

         if(var6 <= 0.0D) {
            var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_QTY_GREATER_ZERO"));
            throw new AbortHandlerException("Number must be > 0");
         } else {
            if(!this.currDropDetail.mConfUOMCode.equalsIgnoreCase("")) {
               try {
                  var8 = UtilFns.convert_uom(var11, "" + this.pdPage.getOrgID(), "" + this.currDropDetail.mItemID, "" + var6, "", this.currDropDetail.mConfUOMCode, "", this.currDropDetail.mUOMCode, "");
               } catch (SQLException var24) {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDF: PickDropFListener Exception: " + var24);
                  }

                  var2.setRefreshScreen(true);
                  throw new AbortHandlerException("Error when calling UtilFns.convert_uom");
               }
            } else {
               var8 = var6;
            }

            if(!this.currDropDetail.mLotControl && this.currDropDetail.mInnerLPN.equalsIgnoreCase("") && var6 <= var4 && this.pdPage.isBulkPick()) {
               OracleCallableStatement var12 = null;

               try {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDP: Before calling wms_pick_drop_pvt.process_loose_qty");
                  }

                  var12 = (OracleCallableStatement)var11.prepareCall("{call wms_pick_drop_pvt.process_loose_qty(:1,:2,:3,:4,:5,:6,:7)}");
                  String var13 = null;
                  var12.registerOutParameter(1, 12, 0, 5);
                  var12.registerOutParameter(2, 12, 0, 5);
                  var12.setInt(3, this.currDropDetail.mGroupNum);
                  var12.setLong(4, this.currDropDetail.mItemID);
                  var12.setString(5, this.currDropDetail.mRevision);
                  var12.setDouble(6, var8);
                  var12.setString(7, this.currDropDetail.mUOMCode);
                  var12.executeQuery();
                  var13 = "" + var12.getString(2);
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDF: Status: " + var13);
                  }

                  if(!var13.equals("S")) {
                     if(UtilFns.isTraceOn) {
                        UtilFns.log("PKDF: Error from wms_pick_drop_pvt.process_loose_qty");
                     }

                     if(var13.equals("E")) {
                        var2.setStatusMessage(UtilFns.getStackedMessages(var2));
                     } else {
                        var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_UNEXPECTED_ERROR"));
                     }

                     var2.setRefreshScreen(true);
                     throw new AbortHandlerException("API to process loose qty failed");
                  }

                  var10 = var12.getString(1);
                  if(var10 == null) {
                     var10 = "";
                  }
               } catch (Exception var25) {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDF: PickDropFListener Exception: " + var25);
                  }

                  var2.setRefreshScreen(true);
                  throw new AbortHandlerException("Error when processing loose qty");
               } finally {
                  try {
                     if(var12 != null) {
                        var12.close();
                     }
                  } catch (SQLException var23) {
                     if(UtilFns.isTraceOn) {
                        UtilFns.log("PKDP: SQL Exception closing cstmt in PickDropFListener().");
                     }

                     throw new AbortHandlerException("SQL error in PickDropFListener().");
                  }

               }

               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: looseQtyExists: " + var10);
               }
            } else if(var6 != var4) {
               var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_CONF_QTY_MATCH_SUGG"));
               throw new AbortHandlerException("Confirmed qty must match suggested qty");
            }

            this.currDropDetail.mRemPrimaryQty -= var8;
            if(!this.currDropDetail.mConfUOMCode.equalsIgnoreCase("")) {
               this.currDropDetail.mRemConvQty -= var6;
            }

            if(this.currDropDetail.mRemPrimaryQty > 0.0D && this.pdPage.isBulkPick() && !this.currDropDetail.mLotControl) {
               this.currDropDetail.mLooseQtyexists = var10.equals("Y");
            }

            if(!this.currDropDetail.mLooseConfirmed) {
               this.currDropDetail.mLooseConfirmed = true;
            }

            if(this.pdPage.isBulkPick()) {
               this.pdPage.setupPage(var2);
            }

         }
      } else {
         var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_CONF_QTY_MATCH_SUGG"));
         throw new AbortHandlerException("Number Expected.");
      }
   }

   private void pickDrop(MWAEvent var1) throws AbortHandlerException {
   Session var2 = var1.getSession();
	  
      if(var1.getAction().equals("MWA_SUBMIT")) {
         if(this.pdPage.isBulkPick() || !this.pdPage.isBulkPick() && this.proceedDropTask(var1)) {
            this.pdPage.callDevRequestCancelComplete(var1.getSession(), 51, "U");
            Connection var3 = var2.getConnection();
            OracleCallableStatement var4 = null;
            long var5 = this.pdPage.getOrgID();
            long var7 = this.pdPage.getDropLPNID();
            long var9 = Long.parseLong((String)var2.getObject("EMPID"));
            String var11 = null;
            if(this.pdPage.getDropType().equals("SUB_XFER")) {
               var11 = this.pdPage.getToLPN().getValue();
            } else {
               var11 = this.pdPage.getDropLPN().getValue();
            }

            String var12 = this.pdPage.getSugZone().getValue();
            String var13 = this.pdPage.getZone().getSubinventoryCode();
            String var14 = "" + this.pdPage.getDropLocID();
            String var15 = this.pdPage.isBulkPick()?"TRUE":"FALSE";
            long var16 = 0L;
            if(!this.pdPage.getDropType().equals("WIP_ISSUE")) {
               var16 = Long.parseLong(this.pdPage.getLoc().getLocatorID());
            }

            int var18 = this.pdPage.getTaskType();
            String var19 = this.pdPage.isLPNDone()?"TRUE":"FALSE";
            long var20 = 0L;
            if(var2.getObject("PKD_LOC_RSN") == null) {
               var20 = 0L;
            } else {
               var20 = Long.parseLong((String)var2.getObject("PKD_LOC_RSN"));
            }

            UtilFns.trace(" -- LPN Status Project -- ");
            UtilFns.trace("Org Id:" + var5);
            UtilFns.trace("Dropping LPN Id" + var7);
            UtilFns.trace("To sub: " + var13);
            UtilFns.trace("To locatorId :" + var16);
            if(this.currDropDetail != null) {
               UtilFns.trace("Got item " + this.currDropDetail.mItemID);
            } else {
               UtilFns.trace("There is no item in the page");
            }

            long var22 = 2L;

            try {
               var22 = UtilFns.isTrxAllowLPNs(var3, (String)null, -99L, -99L, (String)null, (String)null, var5, -99L, var13, var16, (String)null, (String)null, (String)null, var7, -99L, (String)null, -99L, -99L, var2);
               UtilFns.trace("Returned Value of istrxallowed in itemConfirmed method: " + var22);
            } catch (Exception var32) {
               UtilFns.trace("Exception occured while calling isTrxAllowLPNs method");
               UtilFns.trace("Error: " + var32);
            }

            if(var22 == 0L || var22 == 1L) {
               UtilFns.trace("Source check is failed");
               UtilFns.trace(UtilFns.getMessage(var1.getSession(), "WMS", "WMS_DISALLOW_TRANSACTION"));
               var2.setStatusMessage(UtilFns.getMessage(var1.getSession(), "WMS", "WMS_DISALLOW_TRANSACTION"));
               var2.setRefreshScreen(true);
               throw new AbortHandlerException(UtilFns.getMessage(var1.getSession(), "WMS", "WMS_DISALLOW_TRANSACTION"));
            }

            try {
               UtilFns.log("PKDP: Before calling wms_pick_drop_pvt.pick_drop");
               var4 = (OracleCallableStatement)var3.prepareCall("{call wms_pick_drop_pvt.pick_drop(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13)}");
               String var24 = null;
               var4.registerOutParameter(1, 12, 0, 5);
               var4.setLong(2, var5);
               var4.setLong(3, var7);
               var4.setLong(4, var9);
               var4.setString(5, var11);
               var4.setString(6, var12);
               var4.setString(7, var13);
               var4.setString(8, var14);
               var4.setLong(9, var16);
               var4.setLong(10, var20);
               var4.setInt(11, var18);
               var4.setString(12, var19);
               var4.setString(13, var15);
               var4.executeQuery();
               var24 = "" + var4.getString(1);
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Status: " + var24);
               }

               if(!var24.equals("S")) {
                  UtilFns.executeDFFUpdate(var2, false);
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDF: Error from wms_pick_drop_pvt.pick_drop");
                  }

                  if(var24.equals("E")) {
                     var2.setStatusMessage(UtilFns.getStackedMessages(var2));
                  } else {
                     var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_UNEXPECTED_ERROR"));
                  }

                  var2.setRefreshScreen(true);
                  throw new AbortHandlerException("wms_pick_drop_pvt.pick_drop failed");
               }

               UtilFns.executeDFFUpdate(var2, true);
               var2.setStatusMessage(UtilFns.getMessage(var2, "WMS", "WMS_TASK_DONE"));
	//Start of code added by Preethi as part of Parcel Drop Trigger Requirement
			   UtilFns.trace("Preethi...Return Status of Task::::: "+var24);
			   if (var24.equals("S"))
			   {
//Start of code by Preethi on 09Jun15 for getting total Sales order lines
try
{ 
Connection connection;
String str17 = "";
long l17 = pdPage.getDeliveryID();
Session ses = var1.getSession();
str17 = " SELECT COUNT(*) FROM wsh_new_deliveries wnd,wsh_delivery_assignments wda,wsh_delivery_details wdd WHERE wda.delivery_Detail_id = wdd.delivery_Detail_id AND wda.delivery_id = wnd.delivery_id AND wdd.source_code = 'OE' AND wda.delivery_id = :1 ";
connection=ses.getConnection();
        preparedStatement = connection.prepareStatement(str17);
      
		preparedStatement.setLong(1,l17);
		rs4 = preparedStatement.executeQuery();
		 while(rs4.next()){
		   TotalCount =rs4.getLong(1);
 if (UtilFns.isTraceOn)
          UtilFns.trace("Getting count of total no of lines for the Delivery::::: "+TotalCount);
		   }
}
catch (Exception var34)
    {
      UtilFns.log("Getting count of total no of lines for the Delivery:" + var34);
    }
    finally
    {
      try
      {
	    if(rs4!=null) rs4.close();
        if (preparedStatement != null) preparedStatement.close();
		
      }
      catch (Exception var34)
      {
	     UtilFns.log("Ex.. in getting count of total no of lines for the Delivery:::::  :" + var34);
      }
    }	
//End of code by Preethi on 09Jun15 for getting total sales order lines
//Start of code by Preethi on 09Jun15 for getting total sales order lines picked
try
{ 
Connection connection;
String str18 = "";
long l18 = pdPage.getDeliveryID();
Session ses = var1.getSession();
str18 = " SELECT COUNT(*) FROM wsh_new_deliveries wnd,wsh_delivery_assignments wda,wsh_delivery_details wdd WHERE wda.delivery_Detail_id = wdd.delivery_Detail_id AND wda.delivery_id = wnd.delivery_id AND wdd.source_code = 'OE' AND wdd.released_status  = 'Y' AND wda.delivery_id = :1 AND status_code NOT IN ('CO', 'CL', 'IT') ";
connection=ses.getConnection();
        preparedStatement = connection.prepareStatement(str18);
        preparedStatement.setLong(1,l18);
		rs5 = preparedStatement.executeQuery();
		 while(rs5.next()){
		   TotalPickCount =rs5.getLong(1);
 if (UtilFns.isTraceOn)
          UtilFns.trace("Getting total count of sales order lines picked for the Delivery::::: "+TotalPickCount);
		   }
}
catch (Exception var34)
    {
      UtilFns.log("Getting total count of sales order lines picked for the Delivery:" + var34);
    }
    finally
    {
      try
      {
	    if(rs5!=null) rs5.close();
        if (preparedStatement != null) preparedStatement.close();
		
      }
      catch (Exception var34)
      {
	     UtilFns.log("Ex.. in getting total count of sales order lines picked for the Delivery  :" + var34);
      }
    }	
//End of code by Preethi on 09Jun15 for getting total sales order lines picked 

// Start of code added by Preethi on 19 Jun 2015
try
{ 
Connection connection;
String sql = "";
long l22 = pdPage.getDeliveryID();
Session ses = var1.getSession();
sql = "select XXHA_WMS_PARCEL_VALIDATION_PKG.XXHA_WMS_PARCEL_VALIDATION(?) from dual";

connection=ses.getConnection();
preparedStatement = connection.prepareStatement(sql);
preparedStatement.setLong(1, l22);
rs6 = preparedStatement.executeQuery();
while(rs6.next()){
		   flag=rs6.getString(1);
		   UtilFns.trace("flag: "+flag); 
		 }
        if (UtilFns.isTraceOn)
          UtilFns.trace("WMS Parcel Function returns: "+flag+".");
    } catch (Exception localException3)
    {
      UtilFns.log("WMS Parcel Function returns:" + localException3);
    }
    finally
    {
      try
      {
	    if(rs6!=null) rs6.close();
        if (preparedStatement != null) preparedStatement.close();
		
      }
      catch (Exception localException4)
      {
	     UtilFns.log("Ex.. in PickDropFListener.while retrieving  :" + localException4);
      }
    }
// End of code added by Preethi on 19 Jun 2015

//Start of code by Preethi on 01Apr15 for getting delivery mode of transport
try
{ 
Connection connection;
String str12 = "";
long l12 = pdPage.getDeliveryID();
Session ses = var1.getSession();
str12 = " select decode(upper(wdd.mode_of_transport),'PARCEL',wdd.mode_of_transport,'Non-Parcel') MODE_OF_TRANSPORT FROM wsh_carrier_services_v wcs, wsh_delivery_details wdd , wsh_delivery_assignments wda, wsh_new_deliveries wnd where wcs.carrier_id = wdd.carrier_id and wdd.delivery_detail_id = wda.delivery_detail_id and wda.delivery_id = wnd.delivery_id and wda.delivery_id = :1 and rownum=1 ";
connection=ses.getConnection();
        preparedStatement = connection.prepareStatement(str12);
      
		preparedStatement.setLong(1,l12);
		rs1 = preparedStatement.executeQuery();
		 while(rs1.next()){
		   ModeOfTransport =rs1.getString(1);
 if (UtilFns.isTraceOn)
          UtilFns.trace("Getting Mode Of Transport of the Delivery::::: "+ModeOfTransport);
		   }
}
catch (Exception var34)
    {
      UtilFns.log("Getting Mode Of Transport of the Delivery:" + var34);
    }
    finally
    {
      try
      {
	    if(rs1!=null) rs1.close();
        if (preparedStatement != null) preparedStatement.close();
		
      }
      catch (Exception var34)
      {
	     UtilFns.log("Ex.. in getting Mode Of Transport of the Delivery  :" + var34);
      }
    }	
//End of code by Preethi on 01Apr15 for getting delivery mode of transport

//Start of code added by Preethi for getting the printer signed on by user for printing XXHA Drop Report	
try
{ 
Connection connection;
String m_userid;
m_userid = "";
String str10 = "";
Session ses = var1.getSession();
m_userid = (String)ses.getObject("USERID");
if (UtilFns.isTraceOn)
          UtilFns.trace("Getting UserId::::: "+(String)ses.getObject("USERID"));
str10 = " SELECT printer_name from wsh_report_printers where level_value_id = :1 and enabled_flag = 'Y' and default_printer_flag = 'Y' and rownum = 1 ";
connection=ses.getConnection();
        preparedStatement = connection.prepareStatement(str10);
      
		preparedStatement.setString(1,m_userid);
		rs = preparedStatement.executeQuery();
		 while(rs.next()){
		   printername =rs.getString(1);
 if (UtilFns.isTraceOn)
          UtilFns.trace("Getting Printer name assigned to the user::::: "+printername);
		   
		 }
}
catch (Exception var34)
    {
      UtilFns.log("Getting Printer Name assigned to the User:" + var34);
    }
    finally
    {
      try
      {
	    if(rs!=null) rs.close();
        if (preparedStatement != null) preparedStatement.close();
		
      }
      catch (Exception var34)
      {
	     UtilFns.log("Ex.. in getting Printer name assigned to the user  :" + var34);
      }
    }
//End of code added by Preethi for getting the printer signed on by user for printing XXHA Drop Report	
	
//Start of code added by Preethi on 21May15 for getting Parcel Drop Document printer
try
{ 
Connection connection;
String m_userid;
String m_respid;
m_userid = "";
m_respid = "";
String str20 = "";
Session ses = var1.getSession();
m_userid = (String)ses.getObject("USERID");
m_respid = (String)ses.getObject("RESPID");
if (UtilFns.isTraceOn)
          UtilFns.trace("Getting UserId::::: "+(String)ses.getObject("USERID"));
if (UtilFns.isTraceOn)
          UtilFns.trace("Getting RespId::::: "+(String)ses.getObject("RESPID"));
str20 = " SELECT fpov.profile_option_value FROM fnd_profile_options fpo,fnd_profile_option_values fpov,fnd_profile_options_tl fpot,fnd_user fu,fnd_application fap,fnd_responsibility frsp,fnd_nodes fnod,hr_operating_units hou WHERE fpo.profile_option_id = fpov.profile_option_id(+) AND fpo.profile_option_name = fpot.profile_option_name AND fu.user_id(+) = fpov.level_value and fpot.language = 'US'AND frsp.application_id(+) = fpov.level_value_application_id AND frsp.responsibility_id(+) = fpov.level_value AND fap.application_id(+) = fpov.level_value AND fnod.node_id(+) = fpov.level_value AND hou.organization_id(+) = fpov.level_value AND fpot.user_profile_option_name IN ('XXHA: WMS Parcel Mode Ship Documents Printer') AND (fu.user_id = :1 OR frsp.responsibility_id = :2) and rownum = 1 ";
connection=ses.getConnection();
        preparedStatement = connection.prepareStatement(str20);
      
		preparedStatement.setString(1,m_userid);
		preparedStatement.setString(2,m_respid);
		rs2 = preparedStatement.executeQuery();
		 while(rs2.next()){
		   DocPrinterName =rs2.getString(1);
 if (UtilFns.isTraceOn)
          UtilFns.trace("Getting Doc Printer name assigned to the user/responsibility::::: "+DocPrinterName);
		   
		 }
}

catch (Exception var34)
    {
      UtilFns.log("Getting Doc Printer Name assigned to the User/Resp:" + var34);
    }
    finally
    {
      try
      {
	    if(rs2!=null) rs2.close();
        if (preparedStatement != null) preparedStatement.close();
		
      }
      catch (Exception var34)
      {
	     UtilFns.log("Ex.. in getting Doc Printer name assigned to the user/resp  :" + var34);
      }
    }
	
//End of code added by Preethi on 21May15 for getting Parcel Drop Document Printer

//Start of code added by Preethi on 21May15 for getting Parcel Drop Label printer
//try
//{ 
//Connection connection;
//String m_userid;
//m_userid = "";
//String str22 = "";
//Session ses = var1.getSession();
//m_userid = (String)ses.getObject("USERID");
//m_respid = (String)ses.getObject("RESPONSIBILITYID");
//if (UtilFns.isTraceOn)
  //        UtilFns.trace("Getting UserId::::: "+(String)ses.getObject("USERID"));
//if (UtilFns.isTraceOn)
//          UtilFns.trace("Getting RespId::::: "+(String)ses.getObject("RESPONSIBILITYID"));
//str22 = " SELECT fpov.profile_option_value FROM fnd_profile_options fpo,fnd_profile_option_values fpov,fnd_profile_options_tl fpot,fnd_user fu,fnd_application fap,fnd_responsibility frsp,fnd_nodes fnod,hr_operating_units hou WHERE fpo.profile_option_id = fpov.profile_option_id(+) AND fpo.profile_option_name = fpot.profile_option_name AND fu.user_id(+) = fpov.level_value and fpot.language = 'US'AND frsp.application_id(+) = fpov.level_value_application_id AND frsp.responsibility_id(+) = fpov.level_value AND fap.application_id(+) = fpov.level_value AND fnod.node_id(+) = fpov.level_value AND hou.organization_id(+) = fpov.level_value AND fpot.user_profile_option_name IN ('XXHA: WMS Parcel Mode Label Printer') AND (fu.user_id = :1 OR frsp.responsibility_id = 22479) AND rownum = 1 ";
//connection=ses.getConnection();
  //      preparedStatement = connection.prepareStatement(str22);
      
	//	preparedStatement.setString(1,m_userid);
		//preparedStatement.setString(2,m_respid);
	//	rs3 = preparedStatement.executeQuery();
		// while(rs3.next()){
		  // LabelPrinterName =rs3.getString(1);
 //if (UtilFns.isTraceOn)
   //       UtilFns.trace("Getting Label Printer name assigned to the user/responsibility::::: "+LabelPrinterName);
		   
	//	 }
//}

//catch (Exception var34)
  //  {
    //  UtilFns.log("Getting Label Printer Name assigned to the User/Resp:" + var34);
    //}
    //finally
    //{
      //try
      //{
	    //if(rs3!=null) rs3.close();
        //if (preparedStatement != null) preparedStatement.close();
		
      //}
      //catch (Exception var34)
     // {
	   //  UtilFns.log("Ex.. in getting Label Printer name assigned to the user/resp  :" + var34);
      //}
    //}
	
//End of code added by Preethi on 21May15 for getting Parcel Drop Label Printer
	
//Start of code added by preethi on 30Mar2015 for updating Label Printer name for Shipshipment
try
{ 
Connection connection;
String str11 = "";
long l = 0L;
long l11 = pdPage.getDeliveryID();
Session ses = var1.getSession();
if (UtilFns.isTraceOn)
          UtilFns.trace("Getting Label Printer name for updating it in attribute5 of wsh_delivery_details table::::: "+printername);
str11 = " UPDATE wsh_delivery_details wdd SET attribute5 = :1 where wdd.delivery_detail_id IN (SELECT wda.delivery_detail_id from wsh_delivery_assignments wda, wsh_new_deliveries wnd where wdd.delivery_detail_id = wda.delivery_detail_id and wda.delivery_id = wnd.delivery_id and wdd.released_status = 'Y' and status_code NOT IN ('CO', 'CL', 'IT') and wda.delivery_id = :2) and wdd.attribute5 is null ";
connection=ses.getConnection();
        preparedStatement = connection.prepareStatement(str11);
preparedStatement.setString(1, printername);
preparedStatement.setLong(2, l11);
l = preparedStatement.executeUpdate();
if (UtilFns.isTraceOn)
UtilFns.trace("Updated printername for no of records count: " + l);
preparedStatement.close();
 if (l == 0L)
      {
        UtilFns.log(" Did not Update wsh_delivery_details table ");
      }
      else
      {
        UtilFns.log(" No. of records updated in wsh_delivery_details table = " + l);
      }
    }
catch (Exception var34)
    {
      UtilFns.log("Ex.. in PickDropFListener.while updating wsh_delivery_details :" + var34);
    }
    finally
    {
      try
      {
        if (preparedStatement!= null) preparedStatement.close();
      }
      catch (Exception var34)
      {
      }
	}
//End of code added by Preethi on 30Mar2015 for updating Label Printer name for Shipshipment

//Start of code added by Preethi on 21May15 for updating DocPrinterName for Shipping docs

try
{ 
Connection connection;
String str21 = "";
long l20 = 0L;
long l21 = pdPage.getDeliveryID();
Session ses = var1.getSession();
if (UtilFns.isTraceOn)
          UtilFns.trace("Getting Doc Printer name for updating it in attribute4 of wsh_delivery_details table::::: "+DocPrinterName);
str21 = " UPDATE wsh_delivery_details wdd SET attribute4 = :1 where wdd.delivery_detail_id IN (SELECT wda.delivery_detail_id from wsh_delivery_assignments wda, wsh_new_deliveries wnd where wdd.delivery_detail_id = wda.delivery_detail_id and wda.delivery_id = wnd.delivery_id and wdd.released_status = 'Y' and status_code NOT IN ('CO', 'CL', 'IT') and wda.delivery_id = :2) and wdd.attribute4 is null ";
connection=ses.getConnection();
        preparedStatement = connection.prepareStatement(str21);
preparedStatement.setString(1, DocPrinterName);
preparedStatement.setLong(2, l21);
l20 = preparedStatement.executeUpdate();
if (UtilFns.isTraceOn)
UtilFns.trace("Updated DocPrinterName for no of records count: " + l20);
preparedStatement.close();
 if (l20 == 0L)
      {
        UtilFns.log(" Did not Update wsh_delivery_details table ");
      }
      else
      {
        UtilFns.log(" No. of records updated in wsh_delivery_details table = " + l20);
      }
    }
catch (Exception var34)
    {
      UtilFns.log("Ex.. in PickDropFListener.while updating wsh_delivery_details :" + var34);
    }
    finally
    {
      try
      {
        if (preparedStatement!= null) preparedStatement.close();
      }
      catch (Exception var34)
      {
      }
	}

//End of code added by Preethi on 21May15 for updating DocPrinterName for Shipping docs

//Start of code added by Preethi on 15Apr15 for submitting XXHA Drop Report only for Non-Parcel deliveries.
 if (UtilFns.isTraceOn)
    UtilFns.trace("Total Pick Count:::: "+TotalPickCount);
	if (UtilFns.isTraceOn)
    UtilFns.trace("Total count of eligible Pick lines::::: "+TotalCount);

    if ((ModeOfTransport.equals("Non-Parcel")) && TotalCount == TotalPickCount)
	{
	if(UtilFns.isTraceOn)
   UtilFns.trace("Call to Submit XXHA Drop Report");
   Session session;
   Connection connection;
   session = var1.getSession();
   connection = session.getConnection();
   long l5 = pdPage.getDeliveryID();
   String str1;
   
 OracleCallableStatement oraclecallablestatement = null;
 str1 = "{ call     XXHA_ORACLE_SHIP_DOCS_PKG.XXHA_DROP_REPORT_PRC(:1,:2) } ";
   try {
        
	    oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(str1);
	    oraclecallablestatement.setLong(1, l5);
		oraclecallablestatement.setString(2, printername);
		oraclecallablestatement.execute();
		oraclecallablestatement.close();
        }
        catch(Exception exception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace((new StringBuilder()).append("Exception in Submitting XXHA Drop Report:").append(exception).toString());
        }
	}
//End of code added by Preethi on 15Apr15 for submitting XXHA Drop Report for only Non-Parcel deliveries.
}	 	

if (UtilFns.isTraceOn)
    UtilFns.trace("Total Pick Count1:::: "+TotalPickCount);
	if (UtilFns.isTraceOn)
    UtilFns.trace("Total count of eligible Pick lines1::::: "+TotalCount);
		 if(var24.equals("S") && TotalCount == TotalPickCount && (ModeOfTransport.equals("PARCEL")))
		 {	 
	     if("N".equals(flag))
		 {
  try
	{
	Session session;
	session = var1.getSession();
	  long l6 = pdPage.getDeliveryID();
	  if (UtilFns.isTraceOn)
    UtilFns.trace("Delivery Id from Pick Drop Page ::::: "+pdPage.getDeliveryID());
	if (UtilFns.isTraceOn)
    UtilFns.trace("Call Submit Shipshipment XML in Precision");
	SubmitShipshipmentXML(l6, var1);
	}
	  catch(Exception var34)
       {
            UtilFns.error("Ex in pickLoadDrop while submitting Shipshipment XML in Precision ", var34);
        }	
		 }		
		 
//try
  // {
  
 //long l7 = pdPage.getDeliveryID();
  
	//   if (UtilFns.isTraceOn)
//UtilFns.trace("Delivery ID from PickDropPage::::: "+l7);

//UtilFns.trace("Document printer from PickDropPage::::: "+printername);
//UtilFns.trace("Call Submit Oracle Shipping Documents");
   
	//  SubmitOracleShipDocs(l7, printername, var1);
	//}  
	  // catch (Exception var34)
    //{
      //UtilFns.error("Ex in PickLoadDrop while submitting Oracle Shipping documents", var34);
    //} 
			  } 
//End of code added by Preethi as part of Parcel Drop Trigger Requirement
               if(var2.getObject("TD_GEN_DROP_LPN") != null) {
                  var2.removeObject("TD_GEN_DROP_LPN");
               }

               this.sendLaborDetails(var1);
            } catch (Exception var34) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: PickDropFListener Exception: " + var34);
               }

               var2.setRefreshScreen(true);
               throw new AbortHandlerException("Error when processing pick drop");
            } finally {
               try {
                  if(var4 != null) {
                     var4.close();
                  }
               } catch (SQLException var33) {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDP: SQL Exception closing cstmt in PickDropFListener().");
                  }

                  throw new AbortHandlerException("SQL error in PickDropFListener().");
               }

            }
         }

         if((!this.pdPage.deconsolidate() || !this.pdPage.isLPNDone()) && this.pdPage.deconsolidate() && !(var2.getPreviousPage() instanceof StagingMovePage)) {
            this.pdPage.setCurrDropIndex(0);
            this.pdPage.getNextGroup(var2);
            this.pdPage.setupPage(var2);
         } else {
            var2.removeObject("PICKING_LPN");
            var2.removeObject("PICKING_LPN_NAME");
            var2.removeObject("TD_DIS_CONF");
            TdButton var36 = this.pdPage.getSubmitBtn();
            if(var2.getObject("TD.MULT_LPN_VECTOR") != null) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Multiple LPNs to drop");
               }

               Vector var37 = (Vector)((Vector)var2.getObject("TD.MULT_LPN_VECTOR"));
               if(var37.size() > 0) {
                  Hashtable var6 = (Hashtable)var37.elementAt(0);
                  String var38 = (String)var6.get("LPN_ID");
                  String var8 = (String)var6.get("LPN_NAME");
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDF: lpnID:   " + var38);
                     UtilFns.log("PKDF: lpnName: " + var8);
                  }

                  var2.putObject("PICKING_LPN", var38);
                  var2.putObject("PICKING_LPN_NAME", var8);
                  var2.putObject("TD_DIS_CONF", "N");
                  var37.removeElementAt(0);
                  var2.putObject("TD.MULT_LPN_VECTOR", var37);
                  var36.setNextPageName("oracle.apps.wms.td.server.PickDropPage");
               } else {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDF: TD.MULT_LPN_VECTOR has no LPNs: " + var37.size());
                  }

                  var2.removeObject("TD.MULT_LPN_VECTOR");
                  TdPage.fetchNextTask(var1);
               }
            } else if(!var2.getPreviousPage().getName().equalsIgnoreCase("oracle.apps.wms.td.server.MainPickPage") && (var2.getObject("CC_LOAD_DROP") == null || !"TRUE".equals((String)var2.getObject("CC_LOAD_DROP")))) {
               if(var2.getPreviousPage() instanceof CurrentTasksPage) {
                  var36.setNextPageName("oracle.apps.wms.td.server.CurrentTasksPage");
               } else {
                  var36.setNextPageName("|END_OF_TRANSACTION|");
               }
            } else {
               TdPage.fetchNextTask(var1);
               var2.putObject("CC_LOAD_DROP", "FALSE");
            }
         }

      }
   }
   
   
   public void SubmitOracleShipDocs(long l1,String s4,MWAEvent var1)
    {
   if(UtilFns.isTraceOn)
   UtilFns.trace("Inside call to SubmitOracleShippingDocs");
   Session session;
   Connection connection;
   session = var1.getSession();
   connection = session.getConnection();
   String s;
   
 OracleCallableStatement oraclecallablestatement = null;
 s = "{ call     XXHA_ORACLE_SHIP_DOCS_PKG.XXHA_ORACLE_SHIP_DOCS(:1,:2) } ";
   try {
        
	    oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(s);
	    oraclecallablestatement.setLong(1, l1);
		oraclecallablestatement.setString(2, s4);
		oraclecallablestatement.execute();
		oraclecallablestatement.close();
        }
        catch(Exception exception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace((new StringBuilder()).append("Exception in Submitting Oracle Shipping documents:").append(exception).toString());
        }
		
    }
   
   
 public void SubmitShipshipmentXML(long l, MWAEvent var1)
    {
	if(UtilFns.isTraceOn)
   UtilFns.trace("Inside call to SubmitShipshipmentXML");
        Connection connection;
        String s;
        OracleCallableStatement oraclecallablestatement;
        Session session = var1.getSession();
        connection = session.getConnection();
        s = "{ call     XXHA_WM_SHIPMENT_XML_PKG.XXHA_WM_SHIPMENT_XML(:1) } ";
		oraclecallablestatement = null;
       try
	   {
        oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(s);
        oraclecallablestatement.setLong(1, l);
        oraclecallablestatement.execute();
        oraclecallablestatement.close();
		}
		  catch(SQLException sqlexception1)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace("SQL exception when submitting the Shipshipment XML");
        }

		}
		

   private void xferLPNConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside xferLPNConfirmed()");
      }

      String var2 = ((TextFieldBean)var1.getSource()).getValue();
      Session var3 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Entered xfer LPN: " + var2);
      }

      Connection var4 = var3.getConnection();
      OracleCallableStatement var5 = null;

      try {
         UtilFns.log("PKDP: Before calling wms_pick_drop_pvt.validate_xfer_to_lpn");
         var5 = (OracleCallableStatement)var4.prepareCall("{call wms_pick_drop_pvt.validate_xfer_to_lpn(:1,:2,:3,:4,:5,:6,:7,:8,:9)}");
         String var6 = null;
         long var7 = this.pdPage.getOrgID();
         long var9 = this.pdPage.getDropLPNID();
         int var11 = this.currDropDetail.mGroupNum;
         String var12 = this.pdPage.isLPNDone()?"TRUE":"FALSE";
         String var13 = this.pdPage.getSubinventory();
         long var14 = this.pdPage.getDropLocID();
         long var16 = this.pdPage.getDeliveryID();
         var5.registerOutParameter(1, 12, 0, 5);
         var5.setLong(2, var7);
         var5.setLong(3, var9);
         var5.setInt(4, var11);
         var5.setString(5, var12);
         var5.setString(6, var2);
         var5.setString(7, var13);
         var5.setLong(8, var14);
         var5.setLong(9, var16);
         var5.executeQuery();
         var6 = "" + var5.getString(1);
         if(UtilFns.isTraceOn) {
            UtilFns.log("PKDF: Status: " + var6);
         }

         if(!var6.equals("S")) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: Error from wms_pick_drop_pvt.validate_xfer_to_lpn");
            }

            if(var6.equals("E")) {
               var3.setStatusMessage(UtilFns.getStackedMessages(var3));
            } else {
               var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_UNEXPECTED_ERROR"));
            }

            var3.setRefreshScreen(true);
            throw new AbortHandlerException("API to process scanned LPN failed");
         }
      } catch (Exception var25) {
         if(UtilFns.isTraceOn) {
            UtilFns.log("PKDF: PickDropFListener Exception: " + var25);
         }

         var3.setRefreshScreen(true);
         throw new AbortHandlerException("Error when processing xfer LPN");
      } finally {
         try {
            if(var5 != null) {
               var5.close();
            }
         } catch (SQLException var24) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDP: SQL Exception closing cstmt in PickDropFListener().");
            }

            throw new AbortHandlerException("SQL error in PickDropFListener().");
         }

      }

   }

   private void snConfirmed(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside snConfirmed()");
      }

      String var2 = ((TextFieldBean)var1.getSource()).getValue();
      if(var2 == null) {
         var2 = "";
      }

      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Entered SN: " + var2);
      }

      if(!var2.equalsIgnoreCase("")) {
         Session var3 = var1.getSession();
         Connection var4 = var3.getConnection();
         OracleCallableStatement var5 = null;
         String var6 = "";

         try {
            UtilFns.log("PKDP: Before calling wms_pick_drop_pvt.process_serial");
            var5 = (OracleCallableStatement)var4.prepareCall("{call wms_pick_drop_pvt.process_serial(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10)}");
            String var7 = null;
            long var8 = this.pdPage.getOrgID();
            long var10 = this.pdPage.getDropLPNID();
            String var12 = this.currDropDetail.mInnerLPN;
            long var13 = this.currDropDetail.mItemID;
            String var15 = this.currDropDetail.mRevision;
            String var16 = this.currDropDetail.mLotNumber;
            int var17 = this.currDropDetail.mGroupNum;
            var5.registerOutParameter(1, 12, 0, 5);
            var5.registerOutParameter(2, 12, 0, 5);
            var5.setLong(3, var8);
            var5.setLong(4, var10);
            var5.setString(5, var12);
            var5.setLong(6, var13);
            var5.setString(7, var15);
            var5.setString(8, var16);
            var5.setString(9, var2);
            var5.setInt(10, var17);
            var5.executeQuery();
            var7 = "" + var5.getString(2);
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: Status: " + var7);
            }

            if(!var7.equals("S")) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Error from wms_pick_drop_pvt.process_serial");
               }

               if(var7.equals("E")) {
                  var3.setStatusMessage(UtilFns.getStackedMessages(var3));
               } else {
                  var3.setStatusMessage(UtilFns.getMessage(var3, "WMS", "WMS_UNEXPECTED_ERROR"));
               }

               var3.setRefreshScreen(true);
               throw new AbortHandlerException("API to process scanned serial failed");
            }

            if(var12.equalsIgnoreCase("") && var16.equalsIgnoreCase("")) {
               var6 = var5.getString(1);
               if(var6 == null) {
                  var6 = "";
               }

               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: looseQtyExists: " + var6);
               }
            }

            if(!this.currDropDetail.mLooseConfirmed) {
               this.currDropDetail.mLooseConfirmed = true;
            }
         } catch (Exception var25) {
            if(UtilFns.isTraceOn) {
               UtilFns.log("PKDF: PickDropFListener Exception: " + var25);
            }

            var3.setRefreshScreen(true);
            throw new AbortHandlerException("Error when processing xfer LPN");
         } finally {
            try {
               if(var5 != null) {
                  var5.close();
               }
            } catch (SQLException var24) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDP: SQL Exception closing cstmt in PickDropFListener().");
               }

               throw new AbortHandlerException("SQL error in PickDropFListener().");
            }

         }

         --this.currDropDetail.mRemPrimaryQty;
         if(this.currDropDetail.mRemPrimaryQty > 0.0D) {
            this.currDropDetail.mLooseQtyexists = var6.equals("Y");
         }

         this.pdPage.setupPage(var3);
      }
   }

   private void infoBtnClicked(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside infoBtnClicked()");
      }

      Session var2 = var1.getSession();
      if(UtilFns.wmsReleaseJOrHigher(var2) && var1.getAction().equals("MWA_SUBMIT")) {
         this.pdPage.setReenterPage();
      }

   }

   private void validateDropLPN(MWAEvent var1) throws AbortHandlerException {
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Inside validateDropLPN()");
      }

      String var2 = ((LOVFieldBean)var1.getSource()).getValue();
      String var3 = (String)((String)this.ses.getObject("TD_GEN_DROP_LPN"));
      if(var2 == null) {
         var2 = "";
      }

      if(var3 == null) {
         var3 = "";
      }

      Session var4 = var1.getSession();
      if(UtilFns.isTraceOn) {
         UtilFns.trace("PKDF: Drop LPN entered is: " + var2);
         UtilFns.trace("PKDF: Generated LPN id: " + var3);
      }

      if(!var2.equalsIgnoreCase("")) {
         if(!var3.equals(var2)) {
            Connection var5 = var4.getConnection();
            OracleCallableStatement var6 = null;

            try {
               UtilFns.log("PKDP: Before calling wms_pick_drop_pvt.validate_pick_drop_lpn");
               var6 = (OracleCallableStatement)var5.prepareCall("{call wms_pick_drop_pvt.validate_pick_drop_lpn(:1,:2,:3,:4,:5,:6,:7,:8)}");
               String var7 = null;
               long var8 = this.pdPage.getOrgID();
               long var10 = this.pdPage.getDropLPNID();
               String var12 = this.pdPage.isLPNDone()?"TRUE":"FALSE";
               String var13 = this.pdPage.getZone().getSubinventoryCode();
               long var14 = Long.parseLong(this.pdPage.getLoc().getLocatorID());
               long var16 = this.pdPage.getDeliveryID();
               var6.registerOutParameter(1, 12, 0, 5);
               var6.setLong(2, var8);
               var6.setLong(3, var10);
               var6.setString(4, var12);
               var6.setString(5, var2);
               var6.setString(6, var13);
               var6.setLong(7, var14);
               var6.setLong(8, var16);
               var6.executeQuery();
               var7 = "" + var6.getString(1);
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: Status: " + var7);
               }

               if(!var7.equals("S")) {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDF: Error from wms_pick_drop_pvt.validate_pick_drop_lpn");
                  }

                  if(var7.equals("E")) {
                     var4.setStatusMessage(UtilFns.getStackedMessages(var4));
                  } else {
                     var4.setStatusMessage(UtilFns.getMessage(var4, "WMS", "WMS_UNEXPECTED_ERROR"));
                  }

                  var4.setRefreshScreen(true);
                  throw new AbortHandlerException("API to process drop LPN failed");
               }
            } catch (Exception var25) {
               if(UtilFns.isTraceOn) {
                  UtilFns.log("PKDF: PickDropFListener Exception: " + var25);
               }

               var4.setRefreshScreen(true);
               throw new AbortHandlerException("Error when processing drop LPN");
            } finally {
               try {
                  if(var6 != null) {
                     var6.close();
                  }
               } catch (SQLException var24) {
                  if(UtilFns.isTraceOn) {
                     UtilFns.log("PKDP: SQL Exception closing cstmt in PickDropFListener().");
                  }

                  throw new AbortHandlerException("SQL error in PickDropFListener().");
               }

            }

         }
      }
   }

   private void sendLaborDetails(MWAEvent var1) {
      boolean var2 = false;
      boolean var3 = false;
      boolean var4 = false;
      long var5 = 0L;
      Object var7 = null;
      String var8 = null;
      long var9 = 0L;
      long var11 = 0L;
      byte var13 = 0;
      String var14 = null;
      double var15 = 0.0D;
      long var17 = 0L;
      boolean var19 = false;
      byte var20 = 0;
      byte var21 = 0;
      Object var22 = null;
      byte var23 = 0;
      int var24 = 0;

      try {
         UtilFns.trace("Entred PickDropFListener.sendLaborDetails");
         Session var25 = var1.getSession();
         String var26 = (String)var25.getValue("ORGID");
         if(var26 != null && var26.trim().length() != 0 && !UtilFns.isWMSEnabled(var25.getConnection(), var26)) {
            UtilFns.trace("Organization is not WMS Enabled, hence txn details for lms not inserted: OrgId: " + var26);
            UtilFns.initializeLaborParameters(var25);
            return;
         }

         var8 = this.pdPage.getZone().getSubinventoryCode();
         UtilFns.trace("To Sub:" + var8);
         String var27 = this.pdPage.getLoc().getLocatorID();
         if(var27 != null && var27.trim().length() != 0) {
            var11 = Long.parseLong(var27);
         }

         UtilFns.trace("To LocId:" + var11);
         String var28 = "" + this.pdPage.getTaskType();
         int var29 = this.pdPage.getTxnType();
         String var30 = String.valueOf(var29);
         UtilFns.trace("WMSTaskTypeId:" + var28);
         UtilFns.trace("TrxTypeId:" + var30);
         byte var34;
         byte var35;
         if(("52".equals(var30) || "53".equals(var30)) && "1".equals(var28)) {
            var34 = 3;
            var35 = 3;
            UtilFns.trace("ActivityId: " + var34 + ",Outbound");
            UtilFns.trace("ActivityDetailId:" + var35 + ",Picking");
         } else if(("35".equals(var30) || "51".equals(var30)) && "1".equals(var28)) {
            var34 = 2;
            var35 = 3;
            UtilFns.trace("ActivityId: " + var34 + ",Manufacturing");
            UtilFns.trace("ActivityDetailId:" + var35 + ",Picking");
         } else if("64".equals(var30) && "4".equals(var28)) {
            var34 = 4;
            var35 = 8;
            UtilFns.trace("ActivityId: " + var34 + ",Warehousing");
            UtilFns.trace("ActivityDetailId:" + var35 + ",Replenishemnt");
         } else if("64".equals(var30) && "5".equals(var28)) {
            var34 = 4;
            var35 = 7;
            UtilFns.trace("ActivityId: " + var34 + ",Warehousing");
            UtilFns.trace("ActivityDetailId:" + var35 + ",MO Transfer");
         } else {
            if(!"2".equals(var30) || !"7".equals(var28)) {
               UtilFns.trace("TransactionType :" + var30 + ",is not valid for LMS, hence txn details for lms not inserted");
               UtilFns.initializeLaborParameters(var25);
               return;
            }

            var34 = 3;
            var35 = 4;
            UtilFns.trace("ActivityId: " + var34 + ",Outbound");
            UtilFns.trace("ActivityDetailId:" + var35 + ",Staging Move");
         }

         if(var25.getPreviousPage() instanceof MainPickPage) {
            String var31 = (String)var25.getObject("USER_EQP_ID");
            if(var31 != null && var31.trim().length() != 0) {
               var5 = Long.parseLong(var31);
            }

            UtilFns.trace("EquipmentId: " + var5);
            var13 = 10;
            UtilFns.trace("LaborTxnSourceId:" + var13 + ", Load and Drop");
            if(var34 == 3 && var35 == 3) {
               String var32 = (String)var25.getObject("LMS_OPERATION_PLAN_ID");
               if(var32 != null || var32.trim().length() != 0) {
                  var24 = Integer.parseInt(var32);
               }

               var25.putSessionObject("LMS_OPERATION_PLAN_ID", "");
            }

            UtilFns.trace("OperationPlanId:" + var24);
         } else if(var25.getPreviousPage() instanceof CurrentTasksPage || var25.getPreviousPage() instanceof StagingMovePage) {
            if(this.currDropDetail != null) {
               var14 = this.currDropDetail.mConfUOMCode;
               if(!"".equals(var14) && var14 != null) {
                  var15 = this.currDropDetail.mConvQty;
               } else {
                  var14 = this.currDropDetail.mUOMCode;
                  var15 = this.currDropDetail.mRemPrimaryQty;
               }

               var17 = this.currDropDetail.mItemID;
            }

            var13 = 9;
            UtilFns.trace("LaborTxnSourceId:" + var13 + ", Drop Loaded LPNs");
         }

         UtilFns.trace("TxnUOM: " + var14);
         UtilFns.trace("Qty: " + var15);
         UtilFns.trace("ItemId: " + var17);
         byte var37 = 2;
         UtilFns.trace("Group ID: 2");
         byte var36 = 3;
         UtilFns.trace("OperationId:" + var36);
         UtilFns.trace(" User_ID: " + (String)var25.getObject("USERID"));
         UtilFns.insertLaborDetails(var25, var34, var35, var36, var5, (String)var7, var8, var9, var11, var13, var14, var15, var17, var37, var20, var21, 0L, var23, var24);
         UtilFns.trace("Ended PickDropFListener.sendLaborDetails");
      } catch (Exception var33) {
         UtilFns.trace("Exception occured in PickDropFListener.sendLaborDetails." + var33.getMessage());
         var33.printStackTrace();
         UtilFns.initializeLaborParameters(this.ses);
      }

   }

}
