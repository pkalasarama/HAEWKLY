//*******************************************************************************************************
//  * Object Name: XXHAVerificationVoidPage
//  * Object Type: Java class
//  * Description: Created Java class for Verification Requirement
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    20-FEB-2015          Initial Object Creation
//*******************************************************************************************************/

package oracle.apps.inv.wshtxn.server;

import java.sql.*;
import java.util.Vector;
import oracle.apps.fnd.common.VersionInfo;
//import oracle.apps.inv.lov.server.XXHA_DeliveryLOV;
import oracle.apps.inv.lov.server.*;
import oracle.apps.inv.utilities.server.UtilFns;
import oracle.apps.mwa.beans.*;
import oracle.apps.mwa.container.MWALib;
import oracle.apps.mwa.container.Session;
import oracle.apps.mwa.eventmodel.*;
import oracle.jdbc.OracleCallableStatement;

public class XXHAVerificationVoidPage extends PageBean
    implements MWAPageListener, MWAFieldListener
{

    public XXHAVerificationVoidPage(Session session)
    {
	    
        addListener(this);
        ses = null;
        ses = session;
        Connection connection = ses.getConnection();
     
        mDeliveryFld = new XXHA_VoidDeliveryLOV("WMS");
        mDeliveryFld.setName("XXHAVerifyVoid.Delivery");
		 String as[] = {
            " ", "oracle.apps.inv.wshtxn.server.XXHAVerificationVoidPage.XXHAVerifyVoid.Delivery", "ORGID"
        };
        mDeliveryFld.setInputParameters(as);
		mDeliveryFld.setRequired(false);
        mDeliveryFld.setValidateFromLOV(true);
        mDeliveryFld.setHidden(false);
        mDeliveryFld.addListener(this);
		
		mMoreBtn = new ButtonFieldBean();
        mMoreBtn.setName("XXHAVerifyVoid.MORE");
        mMoreBtn.setNextPageName("oracle.apps.inv.wshtxn.server.XXHAVerificationVoidPage");
        mMoreBtn.addListener(this);
		
        mDoneBtn = new ButtonFieldBean();
        mDoneBtn.setName("XXHAVerifyVoid.DONE");
        mDoneBtn.setNextPageName("|END_OF_TRANSACTION|");
        mDoneBtn.addListener(this);
		
        mCancelBtn = new ButtonFieldBean();
        mCancelBtn.setName("XXHAVerifyVoid.CANCEL");
        mCancelBtn.setNextPageName("|END_OF_TRANSACTION|");
        mCancelBtn.setEnableAcceleratorKey(true);
		
        addFieldBean(mDeliveryFld);
        addFieldBean(mMoreBtn);
        addFieldBean(mDoneBtn);
        addFieldBean(mCancelBtn);
        initPrompts(ses);
        addListener(this);
		}
    

	 protected void initPrompts(Session session)
    {
        try
        {   setPrompt((new StringBuilder()).append(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_VOID_PROMPT")).append(" (").append((String)session.getValue("ORGCODE")).append(")").toString());
            mDeliveryFld.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_DLVR_NUMBER_PROMPT"));
			mMoreBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_MORE_PROMPT"));
            mDoneBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_DONE_PROMPT"));
            mCancelBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_CANCEL_PROMPT"));
            mDeliveryFld.retrieveAttributes("XXHA_INV_DLVR_NUMBER_PROMPT");
			mMoreBtn.retrieveAttributes("INV_MORE_PROMPT");
            mDoneBtn.retrieveAttributes("INV_DONE_PROMPT");
            mCancelBtn.retrieveAttributes("INV_CANCEL_PROMPT");
	    }
        catch(SQLException sqlexception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace("error in setting prompts");
        }
    }
	
	public XXHA_VoidDeliveryLOV getDeliveryFld()
    {
        return mDeliveryFld;
		
    }

    public ButtonFieldBean getMoreBtn()
    {
        return mMoreBtn;
    }

    public ButtonFieldBean getDoneBtn()
    {
        return mDoneBtn;
    }
	
	public void clear()
    {
       mDeliveryFld.clear();
    }
	
	 public void print(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	
	}
	
    public void pageExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
    }

    public void pageEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        Session session = mwaevent.getSession();
        try
        {
            mWMSInstalled = UtilFns.isWMSInstalled(session.getConnection(), "");
        }
        catch(Exception exception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace((new StringBuilder()).append("Exception when checking WMS installed:").append(exception).toString());
        }
      
    }

    public void specialKeyPressed(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
    }

    public void fieldEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        Session session = mwaevent.getSession();
    }

    public void fieldExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	UtilFns.trace("Inside Field Exited");
	 this.ses = mwaevent.getSession();
     this.mCon = this.ses.getConnection();
	 
	String s = ((FieldBean)mwaevent.getSource()).getName();
    boolean bool = mwaevent.getAction().equals("MWA_PREVIOUSFIELD");

    UtilFns.log("XXHAVerificationVoidPage: FieldExited = " + s);
    try {
      if (!bool)
      {
        if (s.equals(getDeliveryFld().getName())) 
		{
          DeliveryExited(mwaevent);
        } 
		 else if (s.equals(getMoreBtn().getName()))
		  {
                MoreExited(mwaevent);
				}
          else if (s.equals(getDoneBtn().getName()))
		     {
                DoneExited(mwaevent);
			}
            
        }
		}
      catch (Exception localException)
    {
      UtilFns.log("SQLException :  : In Field Exit = " + s);
    }
		ses.setRefreshScreen(true);
	}

	
	void DeliveryExited(MWAEvent mwaevent)
    throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
   {
  try
	{
	Session session;
	session = mwaevent.getSession();
	long l1;
    l1 = Long.parseLong(mDeliveryFld.getValue());
	if (UtilFns.isTraceOn)
    UtilFns.trace("Call for Submit VOID XML");
	SubmitVoidXML(l1, mwaevent);
	}
	  catch(Exception localException)
       {
            UtilFns.error("Ex in DeliveryExitedfield while submitting Void XML ", localException);
        }
	}
    
	void MoreExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        if(mwaevent.getAction().equals("MWA_SUBMIT"))
        {
            XXHA_VoidDeliveryLOV xxhadeliverylov = getDeliveryFld();
            clear();
            
        }
    }

    void DoneExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        if(mwaevent.getAction().equals("MWA_SUBMIT"))
            print(mwaevent);
    }
	
	public void SubmitVoidXML(long l, MWAEvent mwaevent)
    {
	if(UtilFns.isTraceOn)
   UtilFns.trace("Inside call to SubmitVoidXML");
        Connection connection;
        String s;
        OracleCallableStatement oraclecallablestatement;
        Session session = mwaevent.getSession();
        connection = session.getConnection();
        s = "{ call     XXHA_WM_VOID_XML_PKG.XXHA_WM_VOID_XML(:1) } ";
		oraclecallablestatement = null;
       try
	   {
        oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(s);
        oraclecallablestatement.setLong(1, l);
        oraclecallablestatement.execute();
        oraclecallablestatement.close();
		}
		  catch(SQLException sqlexception1)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace("SQL exception when submitting the VOID XML");
        }

		}
	
    public static final String RCS_ID = "$Header: XXHAVerificationVoidPage.java 120.1 2015/02/03 15:44:31 pranavat noship $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: XXHAVerificationVoidPage.java 120.1 2015/02/03 15:44:31 pranavat noship $", "oracle.apps.inv.wshtxn.server");
    XXHA_VoidDeliveryLOV mDeliveryFld;
	ButtonFieldBean mMoreBtn;
    ButtonFieldBean mDoneBtn;
    ButtonFieldBean mCancelBtn;
    Session ses;
	//Session mSes;
  Connection mCon;
    boolean mWMSInstalled;

}
