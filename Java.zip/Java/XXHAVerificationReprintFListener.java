//*******************************************************************************************************
//  * Object Name: XXHAVerificationReprintFListener
//  * Object Type: Java class
//  * Description: Created Java class for Verification Requirement
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    02-FEB-2015          Initial Object Creation
//*******************************************************************************************************/

package oracle.apps.inv.wshtxn.server;

import java.sql.*;
import java.util.Vector;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.inv.lov.server.*;
import oracle.apps.mwa.beans.*;
import oracle.apps.mwa.container.MWALib;
import oracle.apps.inv.utilities.server.NumberFieldBean;
import oracle.apps.inv.utilities.server.UtilFns;
import oracle.apps.mwa.container.Session;
import oracle.apps.mwa.eventmodel.*;
import oracle.jdbc.OracleCallableStatement;

// Referenced classes of package oracle.apps.inv.wshtxn.server:
//            XXHAVerificationPage

public class XXHAVerificationReprintFListener
    implements MWAFieldListener
{

    public XXHAVerificationReprintFListener()
    {
        pg = null;
        mSes = null;
		mMessageData = "";
       
    }

    public void fieldEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	if(UtilFns.isTraceOn)
            UtilFns.trace("XXHAVerificationReprintFListener : Entered field handler");
    
      
    }

   
public void fieldExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	UtilFns.trace("Inside Field Exited");
	 this.mSes = mwaevent.getSession();
     this.mCon = this.mSes.getConnection();
	 this.pg = ((XXHAVerificationReprintPage)this.mSes.getCurrentPage());
	 
	String s = ((FieldBean)mwaevent.getSource()).getName();
    boolean bool = mwaevent.getAction().equals("MWA_PREVIOUSFIELD");

    UtilFns.log("XXHAVerificationReprintPage: FieldExited = " + s);
    try {
      if (!bool)
      {
        if (s.equals(pg.getDeliveryFld().getName())) 
		{
          DeliveryExited(mwaevent);
        } 
		 else if (s.equals(pg.getMoreBtn().getName()))
		  {
                MoreExited(mwaevent);
				}   
        }
		}
      catch (Exception localException)
    {
      UtilFns.log("SQLException :  : In Field Exit = " + s);
    }
		mSes.setRefreshScreen(true);
    
	}

   void DeliveryExited(MWAEvent mwaevent)
    throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
   {
   try
   {
   String str1 = this.pg.mDeliveryFld.getValue();
   String str2 = this.pg.mDocPrtFld.getValue();
	   if (UtilFns.isTraceOn)
UtilFns.trace("Delivery number entered by the Shipper::::: "+str1);
UtilFns.trace("Document printer entered by the Shipper::::: "+str2);
UtilFns.trace("Call Submit Oracle Shipping Documents");
      SubmitOracleShipDocs(str1, str2, mwaevent);
	}  
	   catch (Exception localException)
    {
      UtilFns.error("Ex in DeliveryExitedfield while submitting Oracle Shipping documents", localException);
    }
	}
   
 void MoreExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        if(mwaevent.getAction().equals("MWA_SUBMIT"))
        {
            XXHA_ReprintDeliveryLOV xxhadeliverylov = pg.getDeliveryFld();
            pg.clear();
            
        }
    }

	
 public void SubmitOracleShipDocs(String s3,String s4,MWAEvent mwaevent)
    {
   if(UtilFns.isTraceOn)
   UtilFns.trace("Inside call to SubmitOracleShippingDocs");
   Session session;
   Connection connection;
   session = mwaevent.getSession();
   connection = session.getConnection();
   String s;
 
 OracleCallableStatement oraclecallablestatement = null;
 s = "{ call     XXHA_ORACLE_SHIP_DOCS_PKG.XXHA_ORACLE_SHIP_DOCS(:1, :2 ) } ";
   try {
        
	    oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(s);
	    oraclecallablestatement.setString(1, s3);
		oraclecallablestatement.setString(2, s4);
		oraclecallablestatement.execute();
		oraclecallablestatement.close();
        }
        catch(Exception exception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace((new StringBuilder()).append("Exception in Submitting Oracle Shipping documents:").append(exception).toString());
        }
		
    }
		
 
		Session session;   

    public static final String RCS_ID = "$Header: XXHAVerificationReprintFListener.java 120.4 2015/02/27 04:30:22 initial version by Apps Associates  $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: XXHAVerificationReprintFListener.java 120.4 2015/02/27 04:30:22 initial version by Apps Associates $", "oracle.apps.inv.wshtxn.server");
    XXHAVerificationReprintPage pg;
 
  Session mSes;
  Connection mCon;
  String mMessageData;
  XXHA_ReprintDeliveryLOV mDeliveryLOV;
  public static final int SUCCESS = 0;
  public static final int ERROR = 1;
  public static final int WARNING = 2;
  }
