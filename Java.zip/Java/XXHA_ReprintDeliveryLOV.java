//*******************************************************************************************************
//  * Object Name: XXHA_ReprintDeliveryLOV
//  * Object Type: Java class
//  * Description: Created Java class for Verification Requirement
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    04-JAN-2015          Initial Object Creation
//*******************************************************************************************************/ 

package oracle.apps.inv.lov.server;

import java.sql.*;
import java.util.Vector;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.inv.utilities.server.UtilFns;
import oracle.apps.mwa.container.*;
import oracle.apps.mwa.eventmodel.*;
import oracle.jdbc.OracleCallableStatement;
import oracle.apps.mwa.beans.*;

// Referenced classes of package oracle.apps.inv.lov.server:
//            InvLOVFieldBean

public class XXHA_ReprintDeliveryLOV extends InvLOVFieldBean
    implements MWAFieldListener
{

    public XXHA_ReprintDeliveryLOV(String s)
    {
        mLOVType = s;
        setName("DelivNumber");
        setValidateFromLOV(true);
        setDelivType(s);
        addListener(this);
    }

    public void setDelivType(String s)
    {
        mLOVType = s;
        if(s.equals("MO"))
        {
            setlovStatement("INV_MO_LOVS.GET_DELIVERY_NUM");
            String as[] = {
                "C", "N", "S", "S", "S", "S"
            };
            setInputParameterTypes(as);
            boolean aflag[] = {
                true, false
            };
            String as5[] = {
                "a", "a"
            };
            setSubfieldPrompts(as5);
            setSubfieldDisplays(aflag);
        } else
        if(s.equals("WMS"))
        {
            setlovStatement("XXHA_INV_SHIPPING_TRANS_PUB.XXHA_GET_VALID_DELIV_REPRINT");
            String as1[] = {
                "C", "S", "N"
            };
            setInputParameterTypes(as1);
            boolean aflag1[] = {
                true, false, false, false, false, false
            };
            setSubfieldDisplays(aflag1);
            setRequired(true);
            setHidden(false);
            setValidateFromLOV(true);
            String as6[] = {
                "a", "a", "a", "a", "a", "a"
            };
            setSubfieldPrompts(as6);
        } else
        if(s.equals("LABEL"))
        {
            setlovStatement("INV_SHIPPING_TRANSACTION_PUB.GET_VALID_DELIVERY_VIA_LPN");
            String as2[] = {
                "C", "S", "N", "AN"
            };
            setInputParameterTypes(as2);
            boolean aflag2[] = {
                true, false, false, false, false, false
            };
            setSubfieldDisplays(aflag2);
            setRequired(true);
            setHidden(false);
            setValidateFromLOV(true);
            String as7[] = {
                "a", "a", "a", "a", "a", "a"
            };
            setSubfieldPrompts(as7);
        } else
        if(s.equals("SHIPLPN"))
        {
            setlovStatement("WMS_SHIPPING_TRANSACTION_PUB.GET_LPN_DELIVERY");
            String as3[] = {
                "C", "N", "N", "N", "S"
            };
            setInputParameterTypes(as3);
            boolean aflag3[] = {
                true, false, false, false, false, false
            };
            setSubfieldDisplays(aflag3);
            setRequired(true);
            setValidateFromLOV(true);
            String as8[] = {
                "a", "a", "a", "a", "a", "a"
            };
            setSubfieldPrompts(as8);
        } else
        if(s.equals("CONSOLIDATION_INQ_DELS"))
        {
            setlovStatement("wms_consolidation_pub.GET_CONSOLIDATION_INQ_DEL_LOV");
            String as4[] = {
                "C", "N", "S", "AN"
            };
            setInputParameterTypes(as4);
            boolean aflag4[] = {
                true, false, true
            };
            setSubfieldDisplays(aflag4);
            setRequired(true);
            setHidden(false);
            setValidateFromLOV(true);
            String as9[] = {
                "a", "a", "a"
            };
            setSubfieldPrompts(as9);
        }
    }

    public void fieldEntered(MWAEvent mwaevent)
    {
        setSubPrompts(mwaevent.getSession());
    }

    public void fieldExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
       Session session = mwaevent.getSession();
	   session.getLogger().println((new StringBuilder()).append("DelivLOV: fieldExited:").append(getValue()).append(".").toString());
	 try
    {
if((mwaevent.getAction().equals("MWA_NEXTFIELD") || mwaevent.getAction().equals("MWA_SUBMIT")) && isPopulated())
	          setReturnValues();
              
        }
        catch(Exception exception)
       {
            session.getLogger().println((new StringBuilder()).append("Ex..DelivLOV: fieldExited").append(exception).toString());
           throw new AbortHandlerException((new StringBuilder()).append("Exception in DelivLOV - fldExited").append(exception).toString());
        }
        if(getValue().equals(""))
            clear();
    }

    private void setReturnValues()
    {
        Vector vector = getSelectedValues();
       
            mDeliveryName = (String)vector.elementAt(0);
            mDeliveryId = (String)vector.elementAt(1);
           // String s = (String)vector.elementAt(2);
   }

    public void clear()
    {
        setValue("");
        mDeliveryName = "";
        mDeliveryId = "";
        mGrossWeight = 0.0D;
        mGrossWeightUOM = "";
        mWaybill = "";
    }

    public String getDeliveryName()
    {
        return mDeliveryName;
    }

    public String getDeliveryId()
    {
        return mDeliveryId;
    }

    public double getGrossWeight()
    {
        return mGrossWeight;
    }

    public String getGrossWeightUOM()
    {
        return mGrossWeightUOM;
    }

    public String getWaybill()
    {
        return mWaybill;
    }

    public String getShipMethod()
    {
        return mShipMethod;
    }

    public void setSubPrompts(Session session)
    {
        if(numberPrompt.equals(""))
            try
            {
                numberPrompt = MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_NUMBER_PROMPT");
                namePrompt = MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_NAME_PROMPT");
                shipMethodPrompt = MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_SHIP_METHOD_PROMPT");
            }
            catch(SQLException sqlexception)
            {
                UtilFns.error("Error initialising the lov prompts for Delivery LOV", sqlexception);
            }
        if(mLOVType.equals("MO"))
        {
            String as[] = {
                numberPrompt, "a"
            };
            setSubfieldPrompts(as);
        } else
        if(mLOVType.equals("WMS") || mLOVType.equals("SHIPLPN") || mLOVType.equals("LABEL"))
        {
            String as1[] = {
                namePrompt, "a", "a", "a", "a", "a"
            };
            setSubfieldPrompts(as1);
        } else
        if(mLOVType.equals("CONSOLIDATION_INQ_DELS"))
        {
            String as2[] = {
                namePrompt, "a", shipMethodPrompt
            };
            setSubfieldPrompts(as2);
        }
    }

    public static final String RCS_ID = "$Header: XXHA_ReprintDeliveryLOV.java 120.4 2015/05/05 10:10:55 Initial version by Apps Associates $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: XXHA_ReprintDeliveryLOV.java 120.4 2015/05/05 10:10:55 Initial Version by Apps Associates $", "oracle.apps.inv.lov.server");
    private String mDeliveryName;
    private String mDeliveryId;
    private double mGrossWeight;
    private String mGrossWeightUOM;
    private String mWaybill;
    private String mShipMethod;
    private String mLOVType;
    private static String numberPrompt = "";
    private static String namePrompt = "";
    private static String shipMethodPrompt = "";
	//XXHAVerificationPage mVerifPage;
	
}
