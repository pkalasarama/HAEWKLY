//*******************************************************************************************************
//  * Object Name: XXHAVerificationPage
//  * Object Type: Java class
//  * Description: Created Java class for Verification Requirement
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    10-JAN-2015          Initial Object Creation
//*******************************************************************************************************/

package oracle.apps.inv.wshtxn.server;

import java.sql.*;
import java.util.Vector;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.inv.lov.server.*;
import oracle.apps.inv.utilities.server.UtilFns;
import oracle.apps.mwa.beans.*;
import oracle.apps.mwa.container.MWALib;
import oracle.apps.mwa.container.Session;
import oracle.apps.mwa.eventmodel.*;
import oracle.jdbc.OracleCallableStatement;

public class XXHAVerificationPage extends PageBean
    implements MWAPageListener, MWAFieldListener
{

    public XXHAVerificationPage(Session session)
    {
	 ses = null;
     VerificationFieldHandler = new XXHAVerificationFListener();
        ses = session;
        Connection connection = ses.getConnection();
      
	    mLabelPrtFld = new PrinterLOV();
        mLabelPrtFld.setName("XXHAVerify.LabelPrinter");
		String as1[] = {
            " ", "oracle.apps.inv.wshtxn.server.XXHAVerificationPage.XXHAVerify.LabelPrinter"
        };
        mLabelPrtFld.setInputParameters(as1);
        mLabelPrtFld.setRequired(false);
        mLabelPrtFld.setValidateFromLOV(true);
        mLabelPrtFld.setHidden(false);
        mLabelPrtFld.addListener(VerificationFieldHandler);
		
		mDocPrtFld = new PrinterLOV();
        mDocPrtFld.setName("XXHAVerify.DocPrinter");
		String as2[] = {
            " ", "oracle.apps.inv.wshtxn.server.XXHAVerificationPage.XXHAVerify.DocPrinter"
        };
        mDocPrtFld.setInputParameters(as2);
        mDocPrtFld.setRequired(false);
        mDocPrtFld.setValidateFromLOV(true);
        mDocPrtFld.setHidden(false);
        mDocPrtFld.addListener(VerificationFieldHandler);
		
        mDeliveryFld = new XXHA_DeliveryLOV("WMS");
        mDeliveryFld.setName("XXHAVerify.Delivery");
		 String as[] = {
            " ", "oracle.apps.inv.wshtxn.server.XXHAVerificationPage.XXHAVerify.Delivery", "ORGID"
        };
        mDeliveryFld.setInputParameters(as);
		mDeliveryFld.setRequired(false);
        mDeliveryFld.setValidateFromLOV(true);
        mDeliveryFld.setHidden(false);
        mDeliveryFld.addListener(VerificationFieldHandler);
		
		mDoneBtn = new ButtonFieldBean();
        mDoneBtn.setName("XXHAVerify.DONE");
        mDoneBtn.setNextPageName("|END_OF_TRANSACTION|");
       // mDoneBtn.addListener(VerificationFieldHandler);
		
        mMoreBtn = new ButtonFieldBean();
        mMoreBtn.setName("XXHAVerify.MORE");
        mMoreBtn.setNextPageName("oracle.apps.inv.wshtxn.server.XXHAVerificationPage");
        mMoreBtn.addListener(VerificationFieldHandler);
        
        mCancelBtn = new ButtonFieldBean();
        mCancelBtn.setName("XXHAVerify.CANCEL");
        mCancelBtn.setNextPageName("|END_OF_TRANSACTION|");
        mCancelBtn.setEnableAcceleratorKey(true);
        addFieldBean(mLabelPrtFld);
		addFieldBean(mDocPrtFld);
		addFieldBean(mDeliveryFld);
		addFieldBean(mDoneBtn);
		addFieldBean(mMoreBtn);
        addFieldBean(mCancelBtn);
        initPrompts(ses);
        addListener(this);
		}

    protected void initPrompts(Session session)
    {
        try
        {   setPrompt((new StringBuilder()).append(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_VERIFICATION_PROMPT")).append(" (").append((String)session.getValue("ORGCODE")).append(")").toString());
            mDeliveryFld.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_DLVR_NUMBER_PROMPT"));
			mLabelPrtFld.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_LABEL_PRINTER_PROMPT"));
			mDocPrtFld.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_DOC_PRINTER_PROMPT"));
			mMoreBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_MORE_PROMPT"));
            mDoneBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_DONE_PROMPT"));
            mCancelBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_CANCEL_PROMPT"));
            mDeliveryFld.retrieveAttributes("XXHA_INV_DLVR_NUMBER_PROMPT");
			mMoreBtn.retrieveAttributes("INV_MORE_PROMPT");
            mDoneBtn.retrieveAttributes("INV_DONE_PROMPT");
            mCancelBtn.retrieveAttributes("INV_CANCEL_PROMPT");
			mLabelPrtFld.retrieveAttributes("XXHA_INV_LABEL_PRINTER_PROMPT");
			mDocPrtFld.retrieveAttributes("XXHA_INV_DOC_PRINTER_PROMPT");
        }
        catch(SQLException sqlexception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace("error in setting prompts");
        }
    }
	
	public XXHA_DeliveryLOV getDeliveryFld()
    {
        return mDeliveryFld;
		
    }
	
	public PrinterLOV getLabelPrtFld()
    {
        return mLabelPrtFld;
    }
	
	public PrinterLOV getDocPrtFld()
    {
        return mDocPrtFld;
    }

	
	public ButtonFieldBean getMoreBtn()
    {
        return mMoreBtn;
    }

    public ButtonFieldBean getDoneBtn()
    {
        return mDoneBtn;
    }
	
	public void clear()
    {
	   mLabelPrtFld.clear();
	   mDocPrtFld.clear();
       mDeliveryFld.clear();
	  
    }
	
	 public void print(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	
	}


    public void pageExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
    }

    public void pageEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        Session session = mwaevent.getSession();
        try
        {
            mWMSInstalled = UtilFns.isWMSInstalled(session.getConnection(), "");
        }
        catch(Exception exception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace((new StringBuilder()).append("Exception when checking WMS installed:").append(exception).toString());
        }
      
    }

    public void specialKeyPressed(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
    }

    public void fieldEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        Session session = mwaevent.getSession();
    }

    public void fieldExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	}
        
    
	public static final String RCS_ID = "$Header: XXHAVerificationPage.java 120.4 2014/12/30 12:00:47 sdpaul ship $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: XXHAVerificationPage.java 120.4 2014/12/30 12:00:47 sdpaul ship $", "oracle.apps.inv.wshtxn.server");
    XXHA_DeliveryLOV mDeliveryFld;
	PrinterLOV mLabelPrtFld;
	PrinterLOV mDocPrtFld;
	ButtonFieldBean mMoreBtn;
    ButtonFieldBean mDoneBtn;
    ButtonFieldBean mCancelBtn;
    Session ses;
    XXHAVerificationFListener VerificationFieldHandler;
    boolean mWMSInstalled;

}
