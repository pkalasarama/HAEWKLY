//*******************************************************************************************************
//  * Object Name: XXHAVerificationVoidFunction
//  * Object Type: Java class
//  * Description: Created Java class for Verification Requirement
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    20-FEB-2015          Initial Object Creation
//*******************************************************************************************************/

package oracle.apps.inv.wshtxn.server;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.inv.utilities.server.OrgFunction;
import oracle.apps.mwa.eventmodel.*;

public class XXHAVerificationVoidFunction extends OrgFunction
    implements MWAAppListener
{

    public XXHAVerificationVoidFunction()
    {
        setFirstPageName("oracle.apps.inv.wshtxn.server.XXHAVerificationVoidPage");
        addListener(this);
    }

    public void appExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
    }

    public void appEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        super.appEntered(mwaevent);
        oracle.apps.mwa.container.Session session = mwaevent.getSession();
    }

    public static final String RCS_ID = "$Header: XXHAVerificationVoidFunction.java 120.0 2015/02/03 06:19:16 appldev noship $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: XXHAVerificationVoidFunction.java 120.0 2015/02/03 06:19:16 appldev noship $", "oracle.apps.inv.wshtxn.server");

}
