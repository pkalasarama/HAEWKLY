//*******************************************************************************************************
//  * Object Name: XXHAVerificationReprintPage
//  * Object Type: Java class
//  * Description: Created Java class for Verification Requirement
//  * Modification Log:
//  * Developer          Date                 Description
//  *-----------------   ------------------   ----------------------------------------------------------
//  * Apps Associates    02-FEB-2015          Initial Object Creation
//*******************************************************************************************************/

package oracle.apps.inv.wshtxn.server;

import java.sql.*;
import java.util.Vector;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.inv.lov.server.*;
import oracle.apps.inv.utilities.server.UtilFns;
import oracle.apps.mwa.beans.*;
import oracle.apps.mwa.container.MWALib;
import oracle.apps.mwa.container.Session;
import oracle.apps.mwa.eventmodel.*;
import oracle.jdbc.OracleCallableStatement;

public class XXHAVerificationReprintPage extends PageBean
    implements MWAPageListener, MWAFieldListener
{

    public XXHAVerificationReprintPage(Session session)
    {
	 ses = null;
     
        VerificationFieldHandler = new XXHAVerificationReprintFListener();
        ses = session;
        Connection connection = ses.getConnection(); 
		
		mDocPrtFld = new PrinterLOV();
        mDocPrtFld.setName("XXHAVerifyReprint.DocPrinter");
		String as2[] = {
            " ", "oracle.apps.inv.wshtxn.server.XXHAVerificationReprintPage.XXHAVerifyReprint.DocPrinter"
        };
        mDocPrtFld.setInputParameters(as2);
        mDocPrtFld.setRequired(true);
        mDocPrtFld.setValidateFromLOV(true);
        mDocPrtFld.setHidden(false);
        mDocPrtFld.addListener(VerificationFieldHandler);
		
        mDeliveryFld = new XXHA_ReprintDeliveryLOV("WMS");
        mDeliveryFld.setName("XXHAVerifyReprint.Delivery");
		 String as[] = {
            " ", "oracle.apps.inv.wshtxn.server.XXHAVerificationReprintPage.XXHAVerifyReprint.Delivery", "ORGID"
        };
        mDeliveryFld.setInputParameters(as);
		mDeliveryFld.setRequired(true);
        mDeliveryFld.setValidateFromLOV(true);
        mDeliveryFld.setHidden(false);
        mDeliveryFld.addListener(VerificationFieldHandler);
		
		mDoneBtn = new ButtonFieldBean();
        mDoneBtn.setName("XXHAVerifyReprint.DONE");
        mDoneBtn.setNextPageName("|END_OF_TRANSACTION|");
		
        mMoreBtn = new ButtonFieldBean();
        mMoreBtn.setName("XXHAVerifyReprint.MORE");
        mMoreBtn.setNextPageName("oracle.apps.inv.wshtxn.server.XXHAVerificationReprintPage");
        mMoreBtn.addListener(VerificationFieldHandler);
        
        mCancelBtn = new ButtonFieldBean();
        mCancelBtn.setName("XXHAVerifyReprint.CANCEL");
        mCancelBtn.setNextPageName("|END_OF_TRANSACTION|");
        mCancelBtn.setEnableAcceleratorKey(true);
        addFieldBean(mDocPrtFld);
		addFieldBean(mDeliveryFld);
		addFieldBean(mDoneBtn);
		addFieldBean(mMoreBtn);
        addFieldBean(mCancelBtn);
        initPrompts(ses);
        addListener(this);
		}

    protected void initPrompts(Session session)
    {
        try
        {   setPrompt((new StringBuilder()).append(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_VERIFY_REPRINT_PROMPT")).append(" (").append((String)session.getValue("ORGCODE")).append(")").toString());
            mDeliveryFld.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_DLVR_NUMBER_PROMPT"));
			mDocPrtFld.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "XXHA_INV_DOC_PRINTER_PROMPT"));
			mMoreBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_MORE_PROMPT"));
            mDoneBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_DONE_PROMPT"));
            mCancelBtn.setPrompt(MWALib.getAKPrompt(session, "oracle.apps.inv.utilities.InvResourceTable", "INV_CANCEL_PROMPT"));
            mDeliveryFld.retrieveAttributes("XXHA_INV_DLVR_NUMBER_PROMPT");
			mMoreBtn.retrieveAttributes("INV_MORE_PROMPT");
            mDoneBtn.retrieveAttributes("INV_DONE_PROMPT");
            mCancelBtn.retrieveAttributes("INV_CANCEL_PROMPT");
			mDocPrtFld.retrieveAttributes("XXHA_INV_DOC_PRINTER_PROMPT");
        }
        catch(SQLException sqlexception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace("error in setting prompts");
        }
    }
	
	public XXHA_ReprintDeliveryLOV getDeliveryFld()
    {
        return mDeliveryFld;
		
    }
	
	
	public PrinterLOV getDocPrtFld()
    {
        return mDocPrtFld;
    }

	
	public ButtonFieldBean getMoreBtn()
    {
        return mMoreBtn;
    }

    public ButtonFieldBean getDoneBtn()
    {
        return mDoneBtn;
    }
	
	public void clear()
    {
	   
	   mDocPrtFld.clear();
       mDeliveryFld.clear();
	  
    }
	
	 public void print(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	
	}


    public void pageExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
    }

    public void pageEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        Session session = mwaevent.getSession();
        try
        {
            mWMSInstalled = UtilFns.isWMSInstalled(session.getConnection(), "");
        }
        catch(Exception exception)
        {
            if(UtilFns.isTraceOn)
                UtilFns.trace((new StringBuilder()).append("Exception when checking WMS installed:").append(exception).toString());
        }
      
    }

    public void specialKeyPressed(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
    }

    public void fieldEntered(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
        Session session = mwaevent.getSession();
    }

    public void fieldExited(MWAEvent mwaevent)
        throws AbortHandlerException, InterruptedHandlerException, DefaultOnlyHandlerException
    {
	}
        
    
	public static final String RCS_ID = "$Header: XXHAVerificationReprintPage.java 120.4 2015/02/27 12:00:47 sdpaul ship $";
    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: XXHAVerificationReprintPage.java 120.4 2015/02/27 12:00:47 sdpaul ship $", "oracle.apps.inv.wshtxn.server");
    XXHA_ReprintDeliveryLOV mDeliveryFld;
	PrinterLOV mDocPrtFld;
	ButtonFieldBean mMoreBtn;
    ButtonFieldBean mDoneBtn;
    ButtonFieldBean mCancelBtn;
    Session ses;
    XXHAVerificationReprintFListener VerificationFieldHandler;
    boolean mWMSInstalled;

}
