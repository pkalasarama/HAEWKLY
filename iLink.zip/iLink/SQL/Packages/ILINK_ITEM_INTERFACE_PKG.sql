create or replace package      ILINK_ITEM_INTERFACE_PKG as

/*
REM +============================================================================================+
REM |Filename         :  BLD_ITEM_INTERFACE_PKG.pkh                   			 	 | 
REM |                                                                                            | 
REM |Copyright        : 2001-2013 CPG Solutions LLC - All Rights Reserved			 | 
REM |                   All rights reserved:  This software/documentation contains proprietary   | 
REM | 					information of CPG Solutions; it is provided under a license agreement 	 | 
REM |					containing restrictions on use and disclosure and is also protected 	 | 
REM | 					by copyright law.  Reverse engineering of the software is prohibited.    | 
REM |                   					   	   	   	  	 | 
REM |Description      : Package Header for Items Interface       				 |
REM |                        									 |
REM |                   	 	 		  	  		  	   	 | 
REM |                   					   	   	   	  	 | 
REM |                                                                                            | 
REM |Calling Program  : 			 	 					 | 
REM |                                                                                            | 
REM |Pre-requisites   : None									 | 
REM |                   		 	  	 		  	 	   	 | 
REM |                                                                                            | 
REM |Post Processing  : 								 	 | 
REM |                   	   			   			 		 | 
REM |                                                                                            | 
REM |                     									 | 
REM |Code Based On iLink Release: 7.6.1								 | 
REM |                                             						 | 
REM |                                                                                            | 
REM |Customer: Haemonetics 14-OCT-13		                                                 | 
REM |                                                                                            | 
REM |Customer Change History:                                                                    |
REM |------------------------                                                                    |
REM |Version  Date       Author         Remarks                                                  |
REM |-------  --------- --------------  ---------------------------------------------------------|
REM |1.0      14-OCT-13 CPG Solutions      First draft Version for Customer branched from iLink,     |
REM |                                   code base 7.6.0                           |
REM |1.1      05-MAR-14 CPG Solutions   Modified code to fix the doubling of cost issue         |
REM |         06-MAR-14 CPG Solutions   Modified code for price list attributes             |
REM |1.2      03-APR-14 CPG Solutions   Modified code related to price lists             |
REM |                                                                |
REM |1.3      22-MAY-14 CPG Solutions   Modified code to prevent description updates         |
REM |                                                                                            |
REM |1.4      29-MAY-14 CPG Solutions   Modified code to process - revs at child org when the -  |
REM |                      rev doesn't exist at master org             |
REM |1.5      02-JUN-14 CPG Solutions   Modified code to stop updates inv, po categories and     |
REM |                      related attributes. Also modified code to populate these|
REM |                                    values from Master org when assigning item to a new org |
REM |1.6      25-SEP-14 K Gangisetty    Made changes to the price list code                      |
REM |                                                                |
REM |1.7      30-JAN-15 K Gangisetty    Added Code to Create GL Accounts Dynamically             |
REM |                                                                |
REM |1.8      02-MAR-15 K Gangisetty    Modified Code to Invoke Item Import in Validate Mode     |
REM |                                    first and then in process mode                 |
REM |         08-JUN-15 K Gangisetty    Added code to perform revision validations         |
REM |         06-OCT-15 K Gangisetty    Added Code to populate "Lot Status Enabled" and          |
REM |                                    "Default Lot Status" fields for Lot controlled items	 | 
REM |1.9      19-FEB-16 K Gangisetty    Modified "update" records to populate master-controlled  |
REM |                                    attributes only for master org record                   |
REM |         29-FEB-16 K Gangisetty    Modified Code to stop updates to service attributes      |
REM |	 04-MAR-16 K Gangisetty    Modified Code to stop populating service attributes in   |
REM |				    the process while applying second template		    |	
REM | Be sure to update the version number below with the latest version number reference above. |
REM |                                                                                            |
REM +============================================================================================+
*/



                PROCEDURE  ILINK_ITEM_INT_MAIN(x_retcode Out Varchar2,x_errbuff Out Varchar2);
                PROCEDURE  ILINK_ITEM_COPY_ALL_ORG(p_master_org_id In Number,p_master_org_code In varchar2);
                PROCEDURE  ILINK_ITEM_PRE_VALIDATE(p_master_org_id In Number,p_master_org_code In varchar2);
                PROCEDURE  ILINK_ITEM_INSERT_INT(p_master_org_id In Number,p_master_org_code In varchar2);
                PROCEDURE  ILINK_INV_PRE_OPEN_INTERFACE(p_master_org_id In Number,p_req_id1 Out Number,p_req_id2 Out Number);
                PROCEDURE  ILINK_POST_ITEM_VAL_INTERFACE(p_req_id1 In Number,p_req_id2 In Number);
                PROCEDURE  ILINK_INV_OPEN_INTERFACE(p_master_org_id In Number,p_req_id1 Out Number,p_req_id2 Out Number);
                PROCEDURE  ILINK_POST_ITEM_INTERFACE(p_req_id1 In Number,p_req_id2 In Number);
                PROCEDURE  ILINK_UPDATE_ITEM_TEMPLATES;
		PROCEDURE  ILINK_INV_OPEN_INTERFACE1(p_master_org_id In Number,p_req_id Out Number);
                PROCEDURE  ILINK_POST_ITEM_INTERFACE1(p_req_id In Number);                
                PROCEDURE  ILINK_POST_ITEM_LOAD(p_master_org_id In Number,p_master_org_code In varchar2);

END ILINK_ITEM_INTERFACE_PKG;