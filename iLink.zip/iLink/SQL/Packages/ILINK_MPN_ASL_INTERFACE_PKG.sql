CREATE OR REPLACE package ILINK_MPN_ASL_INTERFACE_PKG as

/*
REM +============================================================================================+
REM |Filename         :  BLD_MPN_ASL_INTERFACE_PKG.pkh                   		 	 |
REM |                                                                                            |
REM |Copyright        : 2001-2013 CPG Solutions LLC - All Rights Reserved			 |
REM |                   All rights reserved:  This software/documentation contains proprietary   |
REM | 					information of CPG Solutions; it is provided under a license agreement 	 |
REM |					containing restrictions on use and disclosure and is also protected 	 |
REM | 					by copyright law.  Reverse engineering of the software is prohibited.    |
REM |                   					   	   	   	  	 |
REM |Description      : Package Header for MPN/ASLs Interface       				 |
REM |                        									 |
REM |                   	 	 		  	  		  	   	 |
REM |                   					   	   	   	  	 |
REM |                                                                                            |
REM |Calling Program  : 			 	 					 |
REM |                                                                                            |
REM |Pre-requisites   : None									 |
REM |                   		 	  	 		  	 	   	 |
REM |                                                                                            |
REM |Post Processing  : 								 	 |
REM |                   	   			   			 		 |
REM |                                                                                            |
REM |                     									 |
REM |Code Based On iLink Release: 7.6.0								 |
REM |                                             						 |
REM |                                                                                            |
REM |Customer:  Haemonetics 14-OCT-13	                                                         |
REM |                                                                                            |
REM |Customer Change History:                                                                    |
REM |------------------------                                                                    |
REM |Version  Date       Author         Remarks                                                  |
REM |-------  --------- --------------  ---------------------------------------------------------|
REM |1.0      14-OCT-13 CPG Solutions  	First draft Version for Customer branched from iLink,	 |
REM |                                   code base 7.6.0     			 		 |
REM |1.1      								 	  		 |
REM |                            								 |
REM |1.2      											 |
REM |                                   							 |
REM |1.3      											 |
REM |                                 								 |
REM |1.4      											 |
REM |                                                                                            |
REM | Be sure to update the version number below with the latest version number reference above. |
REM |                                                                                            |
REM +============================================================================================+
*/

                procedure  ILINK_MPN_ASL_INT_MAIN(x_retcode Out Varchar2,x_errbuff Out Varchar2);
                procedure  ILINK_VALIDATE_ASLS(p_master_org_id In Number,p_master_org_code In Varchar2);
                procedure  ILINK_PROCESS_ASLS(p_master_org_id In Number,p_master_org_code In Varchar2);

End ILINK_MPN_ASL_INTERFACE_PKG;