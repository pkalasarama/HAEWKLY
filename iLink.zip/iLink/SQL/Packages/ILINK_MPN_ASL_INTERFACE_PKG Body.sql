CREATE OR REPLACE package body ILINK_MPN_ASL_INTERFACE_PKG as

/*
REM +============================================================================================+
REM |Filename         :  BLD_MPN_ASL_INTERFACE_PKG.pkb                   			 |
REM |                                                                                            |
REM |Copyright        : 2001-2013 CPG Solutions LLC - All Rights Reserved			 |
REM |                   All rights reserved:  This software/documentation contains proprietary   |
REM | 					information of CPG Solutions; it is provided under a license agreement 	 |
REM |					containing restrictions on use and disclosure and is also protected 	 |
REM | 					by copyright law.  Reverse engineering of the software is prohibited.    |
REM |                   					   	   	   	  	 |
REM |Description      : Package Body for processing MPN/ASLs contains the following program Units|
REM |                    ILINK_MPN_ASL_INT_MAIN  (Main process)    				 |
REM |			 ILINK_VALIDATE_ASLS  (Validate ASL data)				 |
REM |			 ILINK_PROCESS_ASLS  (Process ASL data)					 |
REM |                   					   	   	   	  	 |
REM |                                                                                            |
REM |Calling Program  : Concurrent Executable name is ILINKMFGINT			 	 |
REM |                                                                                            |
REM |Pre-requisites   : None									 |
REM |                   		 	  	 		  	 	   	 |
REM |                                                                                            |
REM |Post Processing  : 								 	 |
REM |                   	   			   			 		 |
REM |                                                                                            |
REM |                     									 |
REM |Code Based On iLink Release: 7.6.0								 |
REM |                                             						 |
REM |                                                                                            |
REM |Customer:  Haemonetics 14-OCT-13                                                       	 |
REM |                                                                                            |
REM |Customer Change History:                                                                    |
REM |------------------------                                                                    |
REM |Version  Date       Author         Remarks                                                  |
REM |-------  --------- --------------  ---------------------------------------------------------|
REM |1.0      14-OCT-13 CPG Solutions  	First draft Version for Customer branched from iLink,	 |
REM |                                   code base 7.6.0     			 		 |
REM |1.1      											 |
REM |                            	 							 |
REM |1.2      											 |
REM |                                   							 |
REM |1.3      											 |
REM |                                 								 |
REM |1.4      											 |
REM |                                                                                            |
REM | Be sure to update the version number below with the latest version number reference above. |
REM |                                                                                            |
REM +============================================================================================+
*/

/* Declare Global Variables to hold values used across multiple procedures */

v_user_id 		Number := FND_GLOBAL.USER_ID();

Procedure ILINK_MPN_ASL_INT_MAIN(x_retcode OUT VARCHAR2,
                               x_errbuff OUT VARCHAR2) is

/* Define a Cursor to fetch the value for Master Organization */

Cursor get_master_org is
Select mpp.organization_id,
       mpp.organization_code
From MTL_PARAMETERS mpp,
     ILINK_DATA_XREF ref
Where ref.data_input1 = 'Default ASL Org Code' and
      mpp.organization_code = ref.data_output1;

/* Define a Cursor to verify if validated records exist in temp table */

Cursor get_validated_records is
Select count (*)
From ILINK_MFG_PART_NUMBERS
Where record_status = 'Validated';

v_master_org_id        	Number;
v_master_org_code	Varchar2(3);

v_count			Number := 0;


Begin

	/* Fetch the value for Master Organization id

    	 open get_master_org;
     	 fetch get_master_org into v_master_org_id,v_master_org_code;
     	 close get_master_org;    	*/


	/* Update Records from Agile with WHO information */

    	    Update ILINK_MFG_PART_NUMBERS imp
    	    Set imp.manufacturer_type = ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF('Default ASL Business Type',NULL,NULL,NULL,NULL),
    	    	imp.organization_code = attribute1,
    	        imp.organization_id = (Select distinct organization_id
				   From MTL_PARAMETERS mpp
				   Where mpp.organization_code = imp.attribute1),
    	        imp.created_by = v_user_id,
    	        imp.creation_date = SYSDATE
            Where imp.organization_code = 'ZZZ';


	/* Delete "Unchanged" records that already exist in Oracle to avoid validation on these records */

	   Delete From ILINK_MFG_PART_NUMBERS IMP
	   Where agile_sys_acd = 'U' and
	         exists (Select 'x'
		         From PO_APPROVED_SUPPLIER_LIST pasl,
			      PO_VENDORS pov,
			      PO_VENDOR_SITES_ALL pvs,
			      MTL_SYSTEM_ITEMS_B msi,
			      PO_ASL_STATUSES pos
		         Where imp.manufacturer_name = pov.vendor_name and
			       pasl.vendor_id = pov.vendor_id and
			       pvs.vendor_id = pov.vendor_id and
			       imp.attribute1 = pvs.vendor_site_code and
			       pvs.vendor_site_id = pasl.vendor_site_id and
			       msi.segment1 = imp.item_number and
			       pasl.item_id = msi.inventory_item_id and
			       msi.organization_id = imp.organization_id and
			       pasl.primary_vendor_item = imp.mfg_part_num and
			       pasl.owning_organization_id = imp.organization_id and
			       nvl(disable_flag,'N') = 'N' and
			       imp.preferred_status = pos.status and
			       pos.status_id = pasl.asl_status_id);


	 /* Delete "U" records when a corresponding "A" record exists	*/

	    Delete From ILINK_MFG_PART_NUMBERS temp1
            Where agile_sys_acd = 'U' and
		  exists (select 'x' from ILINK_MFG_PART_NUMBERS temp2
			  where temp1.eco_number = temp2.eco_number and
				temp1.item_number = temp2.item_number and
				temp1.manufacturer_name = temp2.manufacturer_name and
				temp1.attribute1 = temp2.attribute1 and
				temp1.mfg_part_num = temp2.mfg_part_num and
				temp2.agile_sys_acd = 'A');


	 /* Update the ACD flag from A(Addition) to C(Change) when there exists a corresponding D(Delete) record ,
	       since Agile sends MPN/ASL redline changes as a combination of Delete and then an Add. Also delete the D(delete) record            */

	    Update ILINK_MFG_PART_NUMBERS temp1
	    Set agile_sys_acd = 'C'
	    Where agile_sys_acd = 'A' and
		  exists (select 'x' from ILINK_MFG_PART_NUMBERS temp2
			  where temp1.eco_number = temp2.eco_number and
				temp1.item_number = temp2.item_number and
				temp1.manufacturer_name = temp2.manufacturer_name and
				temp1.attribute1 = temp2.attribute1 and
			        temp1.mfg_part_num = temp2.mfg_part_num and
				temp2.agile_sys_acd = 'D');

	    Delete From ILINK_MFG_PART_NUMBERS temp1
	    Where agile_sys_acd = 'D' and
		  exists (select 'x' from ILINK_MFG_PART_NUMBERS temp2
			  where temp1.eco_number = temp2.eco_number and
				temp1.item_number = temp2.item_number and
				temp1.manufacturer_name = temp2.manufacturer_name and
				temp1.attribute1 = temp2.attribute1 and
				temp1.mfg_part_num = temp2.mfg_part_num and
				temp2.agile_sys_acd = 'C');


       /* Call the procedure to validate ASL records */

        ILINK_VALIDATE_ASLS(v_master_org_id,v_master_org_code);
        commit;

	/* Call the procedure to insert records into Interface tables if "Validated" records exist in temp table */

	open get_validated_records;
        fetch get_validated_records into v_count;
	close get_validated_records;

        If v_count != 0  then

        /* Call the procedure to process ASL records */

        ILINK_PROCESS_ASLS(v_master_org_id,v_master_org_code);
        commit;

       End If;

 Exception
  When Others then
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_MPN_ASL_INT_MAIN is '||SQLERRM);

End ILINK_MPN_ASL_INT_MAIN;


Procedure  ILINK_VALIDATE_ASLS(p_master_org_id In Number,p_master_org_code In Varchar2) is


/* Define a Cursor to fetch unprocessed records from the temp table */

Cursor get_unprc_asl_items is
Select manufacturer_name,
       attribute1 vendor_site_code,
       manufacturer_type,
       mfg_part_num,
       item_number,
       Decode(agile_sys_acd,'A','A','U','A','C','C','D','D') transaction_type,
       agile_sys_acd,
       preferred_status asl_status,
       eco_number,
       record_id,
       organization_id
From ILINK_MFG_PART_NUMBERS
Where nvl(process_flag,'N') = 'N'
Order By eco_rel_date,eco_number,manufacturer_name,item_number,record_id;

/* Define a Cursor to Validate Supplier in Oracle */

Cursor get_vendor_id(p_vendor_name In Varchar2) is
Select vendor_id
From PO_VENDORS
Where upper(vendor_name) = upper(p_vendor_name) and
      (end_date_active is NULL or end_date_active > SYSDATE);

/* Define a Cursor to Validate Supplier Site in Oracle */

Cursor get_vendor_site_id(p_vendor_id In Number,p_vendor_site In Varchar2) is
Select vendor_site_id
From PO_VENDOR_SITES_ALL
Where vendor_id = p_vendor_id and
      upper(vendor_site_code) = upper(p_vendor_site) and
      (inactive_date is NULL or inactive_date > SYSDATE) and
      nvl(purchasing_site_flag,'N') = 'Y';


/* Define a Cursor to Validate Item Number in Oracle  */

Cursor get_item_id(p_org_id in number,p_item_num in varchar2) is
Select inventory_item_id,purchasing_enabled_flag
From ILINK_MTL_SYSTEM_ITEMS_VIEW
Where organization_id = p_org_id and
      item_number = p_item_num;

/* Define a Cursor to Validate ASL Status */

Cursor get_asl_status_id (p_status In Varchar2) is
Select status_id
From PO_ASL_STATUSES PAS
Where pas.status = p_status;

/* Define a Cursor to Validate ASL Business Type */

Cursor get_business_code(p_value In Varchar2) is
Select lookup_code
From fnd_lookup_values
Where lookup_type = 'ASL_VENDOR_BUSINESS_TYPE' and
      lookup_code = p_value and
      language = 'US';

/* Define a cursor to see if a ASL record exists for an item/supplier/site combination */

Cursor get_asl_item(p_vendor_id In Number,p_org_id In Number,p_item_id In Number,p_mfg_name In Varchar2,
			p_item_num In Varchar2,p_site_id In Number,p_site_code In Varchar2) is
Select primary_vendor_item
From PO_APPROVED_SUPPLIER_LIST pasl
Where vendor_id = p_vendor_id and
      vendor_site_id = p_site_id and
      item_id = p_item_id and
      owning_organization_id = p_org_id and
      nvl(disable_flag,'N') = 'N' and
      not exists (Select 'x' from ILINK_MFG_PART_NUMBERS imp
      		  Where imp.manufacturer_name = p_mfg_name and
      		        imp.attribute1 = p_site_code and
      		        imp.item_number = p_item_num and
      		        imp.mfg_part_num = pasl.primary_vendor_item and
      		        imp.agile_sys_acd = 'D');

Cursor check_dup_asl(p_vendor In Varchar2,p_item_num In varchar2,v_mfg_item In Varchar2,p_site_code In Varchar2) is
Select mfg_part_num
From ILINK_MFG_PART_NUMBERS
Where manufacturer_name = p_vendor and
      attribute1 = p_site_code and
      item_number = p_item_num and
      mfg_part_num != v_mfg_item and
      agile_sys_acd in ('A','U');


v_item_id               Number;
v_pur_flag		Varchar2(1);
v_master_org_id         Number;
v_vendor_id	        Number;
v_error_message         Varchar2(2000);
v_warning_message 	Varchar2(2000);
v_mfg_part_num          Varchar2(150);
v_agile_sys_acd		Varchar2(3);
v_asl_status		Varchar2(150);
v_txn_type		Varchar2(30);
v_record_status		Varchar2(50);
v_status_id     	Number;
v_bus_code		Varchar2(30);
v_item_number		Varchar2(40);
v_asl_item		Varchar2(30);
v_vendor_site_id	Number;

BEGIN



 /* Begin Processing records from Temp Table */

  For v_cur_part In get_unprc_asl_items Loop

     v_error_message 	:= NULL;
     v_warning_message 	:= NULL;
     v_record_status	:= 'S';
     v_vendor_id     	:= NULL;
     v_item_id       	:= NULL;
     v_pur_flag		:= NULL;
     v_status_id     	:= NULL;
     v_bus_code	     	:= NULL;
     v_asl_item		:= NULL;
     v_mfg_part_num	:= NULL;
     v_vendor_site_id	:= NULL;


    /* Validate Business Type */

     open get_business_code(v_cur_part.manufacturer_type);
     fetch get_business_code into v_bus_code;
     If get_business_code%NOTFOUND Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Business Code(Manufacturer/Supplier Sunclass) is Invalid' into v_error_message From DUAL;
     End If;
     close get_business_code;


    /* Validate Manufacturer/Supplier Name */

     If v_cur_part.manufacturer_name is NULL Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Manufacturer/Supplier Name cannot be Blank'
      into v_error_message From DUAL;
     End If;


    /* Validate Manufacturer Part Number */

     If v_cur_part.mfg_part_num is NULL Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Manufacturer/Supplier Part Number cannot be Blank'
      into v_error_message From DUAL;
     End If;


    /* Validate Supplier */

     open get_vendor_id(v_cur_part.manufacturer_name);
     fetch get_vendor_id into v_vendor_id;
     If get_vendor_id%NOTFOUND Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Supplier does not exist or is not Active in Oracle'
      into v_error_message From DUAL;
     End If;
     close get_vendor_id;


     /* Validate Supplier Site */

     open get_vendor_site_id(v_vendor_id,v_cur_part.vendor_site_code);
     fetch get_vendor_site_id into v_vendor_site_id;
     If get_vendor_site_id%NOTFOUND Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Supplier Site does not exist or is not a Purchasing Site in Oracle'
      into v_error_message From DUAL;
     End If;
     close get_vendor_site_id;


    /* Validate Item */

     open get_item_id(v_cur_part.organization_id,v_cur_part.item_number);
     fetch get_item_id into v_item_id,v_pur_flag;
     If get_item_id%NOTFOUND Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Item does not exist in Oracle' into v_error_message From DUAL;
     Elsif get_item_id%FOUND and v_pur_flag = 'N' Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Item Purchasable Flag is Set to No in Oracle'
      into v_error_message From DUAL;
     End If;
     close get_item_id;


    /* Validate ASL Status */

     open get_asl_status_id(v_cur_part.asl_status);
     fetch get_asl_status_id into v_status_id;
     If get_asl_status_id%NOTFOUND Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'ASL Status is Invalid' into v_error_message From DUAL;
     End If;
     close get_asl_status_id;


    /* Validate if ASL exists for Item/Vendor/Site combination */

    If  v_cur_part.transaction_type = 'A' Then

     open get_asl_item(v_vendor_id,v_cur_part.organization_id,v_item_id,v_cur_part.manufacturer_name,
     			 v_cur_part.item_number,v_vendor_site_id,v_cur_part.vendor_site_code);
     fetch get_asl_item into v_asl_item;
     If get_asl_item%FOUND and nvl(v_asl_item,'NA') != v_cur_part.mfg_part_num Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'Another ASL record exists for this Item/Supplier/Site combination' into v_error_message From DUAL;
     End If;
     close get_asl_item;

     open check_dup_asl(v_cur_part.manufacturer_name,v_cur_part.item_number,v_cur_part.mfg_part_num,v_cur_part.vendor_site_code);
     fetch check_dup_asl into v_asl_item;
     If check_dup_asl%Found Then
      v_record_status := 'E';
      Select decode(v_error_message,NULL,'Error: ',v_error_message||' , ')||'You are trying to add multiple ASL records for this Item/Supplier/Site combination' into v_error_message From DUAL;
     End If;
     close check_dup_asl;

    End If;


     /* If all the validations succeeded then mark the record as "Validated" */

        If v_record_status = 'S' Then

	 /* Mark record as validated and processed   */

	 Update ilink_mfg_part_numbers
	 Set process_flag = 'Y',
	     processed_date = SYSDATE,
	     record_status = 'Validated',
	     inventory_item_id = v_item_id,
	     manufacturer_id = v_vendor_id,
	     attribute2 = v_vendor_site_id
	 Where record_id = v_cur_part.record_id and
	      eco_number = v_cur_part.eco_number and
	      item_number = v_cur_part.item_number and
	      manufacturer_name = v_cur_part.manufacturer_name and
	      attribute1 = v_cur_part.vendor_site_code and
              mfg_part_num = v_cur_part.mfg_part_num and
              agile_sys_acd = v_cur_part.agile_sys_acd;

	/* The record failed with validation Errors */

	Elsif v_record_status = 'E' Then

	 Update ilink_mfg_part_numbers
	 Set process_flag = 'Y',
	     processed_date = SYSDATE,
	     record_status = 'Error',
	     inventory_item_id = v_item_id,
	     manufacturer_id = v_vendor_id,
	     error_message = v_error_message
	 Where record_id = v_cur_part.record_id and
	       eco_number = v_cur_part.eco_number and
	       item_number = v_cur_part.item_number and
	       manufacturer_name = v_cur_part.manufacturer_name and
	       attribute1 = v_cur_part.vendor_site_code and
               mfg_part_num = v_cur_part.mfg_part_num and
               agile_sys_acd = v_cur_part.agile_sys_acd;

        End If;		-- Process Succeded and Error Records

  End Loop;

Exception
  When Others then
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_VALIDATE_ASLS is '||SQLERRM);

End ILINK_VALIDATE_ASLS;


Procedure  ILINK_PROCESS_ASLS(p_master_org_id In Number,p_master_org_code In Varchar2) is

/* Define a cursor to fetch valid ASL Records */

Cursor get_valid_asl_items is
Select manufacturer_name,
       mfg_part_num,
       imp.item_number,
       Decode(agile_sys_acd,'A','A','U','A','C','C','D','D') transaction_type,
       agile_sys_acd,
       preferred_status asl_status,
       eco_number,
       record_id,
       imp.organization_id,
       imp.manufacturer_id vendor_id,
       imp.attribute1 vendor_site_code,
       imp.attribute2 vendor_site_id,
       inventory_item_id,
       pas.status_id,
       manufacturer_type business_code
From ILINK_MFG_PART_NUMBERS imp,
     PO_ASL_STATUSES pas
Where record_status = 'Validated' and
      imp.preferred_status = pas.status
Order By eco_rel_date,eco_number,manufacturer_name,item_number,record_id;


/* Define a Cursor to Verify if ASL Item exists in Oracle */

Cursor get_asl_item(p_vendor_id In Number,p_asl_part_num In Varchar2,p_vendor_site_id In Number,p_org_id In Number,p_item_id In Number) is
Select rowid,asl_id,asl_status_id
From PO_APPROVED_SUPPLIER_LIST pasl
Where vendor_id = p_vendor_id and
      vendor_site_id = p_vendor_site_id and
      item_id = p_item_id and
      primary_vendor_item = p_asl_part_num and
      owning_organization_id = p_org_id
      and nvl(disable_flag,'N') = 'N';

v_warning_message 	Varchar2(2000);
v_ora_asl_status_id	Number;
v_ora_asl_id		Number;
v_transfer_flag		Varchar2(30);

v_row_id1 		varchar2(50);
v_row_id2 		varchar2(50);
v_api_asl_id		Number;
v_ora_asl_row_id 	varchar2(50);
v_disable_flag		varchar2(1);

BEGIN


 /* Begin Processing records from Temp Table */

  For v_cur_part In get_valid_asl_items Loop

   v_transfer_flag := 'Yes';
   v_warning_message := NULL;

         /* Process ASL Additions */

     	 If v_cur_part.transaction_type = 'A' Then

     	  /* Verify if ASL Already exists in Oracle */

     	   v_ora_asl_id := NULL;
     	   v_ora_asl_status_id := NULL;
     	   v_ora_asl_row_id := NULL;

     	   open get_asl_item(v_cur_part.vendor_id,v_cur_part.mfg_part_num,v_cur_part.vendor_site_id,
     	   			v_cur_part.organization_id,v_cur_part.inventory_item_id);
     	   fetch get_asl_item into v_ora_asl_row_id,v_ora_asl_id,v_ora_asl_status_id;
     	   If get_asl_item%FOUND Then
     	    If nvl(v_cur_part.status_id,-9999) != v_ora_asl_status_id Then	-- Update ASL Record

     	     v_disable_flag := NULL;
	     If nvl(upper(v_cur_part.asl_status),'NA') = 'INACTIVE' Then
	      v_disable_flag := 'Y';
	     Else
	      v_disable_flag := NULL;
	     End If;

     	    Begin

		PO_ASL_THS1.update_row(
			x_row_id => v_ora_asl_row_id,
			x_asl_id => v_ora_asl_id,
			x_using_organization_id => v_cur_part.organization_id,
			x_owning_organization_id => v_cur_part.organization_id,
			x_vendor_business_type => v_cur_part.business_code,
			x_asl_status_id	=> v_cur_part.status_id,
			x_last_update_date => SYSDATE,
			x_last_updated_by => v_user_id,
			x_creation_date	=> SYSDATE,
			x_created_by => v_user_id,
			x_manufacturer_id => NULL,
			x_vendor_id => v_cur_part.vendor_id,
			x_item_id => v_cur_part.inventory_item_id,
			x_category_id => NULL,
			x_vendor_site_id => v_cur_part.vendor_site_id,
			x_primary_vendor_item => v_cur_part.mfg_part_num,
			x_manufacturer_asl_id => NULL,
			x_comments => NULL,
			x_review_by_date => NULL,
			x_attribute_category => NULL,
			x_attribute1 => NULL,
			x_attribute2 => NULL,
			x_attribute3 => NULL,
			x_attribute4 => NULL,
			x_attribute5 => NULL,
			x_attribute6 => NULL,
			x_attribute7 => NULL,
			x_attribute8 => NULL,
			x_attribute9 => NULL,
			x_attribute10 => NULL,
			x_attribute11 => NULL,
			x_attribute12 => NULL,
			x_attribute13 => NULL,
			x_attribute14 => NULL,
			x_attribute15 => NULL,
			x_last_update_login => NULL,
			x_disable_flag => v_disable_flag);

		   Commit;

		Exception

		 When Others Then

		 Update ilink_mfg_part_numbers
		 Set warning_message = warning_message||' '||'UPDATE of ASL Failed'
		 Where record_id = v_cur_part.record_id and
		      eco_number = v_cur_part.eco_number and
		      item_number = v_cur_part.item_number and
		      manufacturer_name = v_cur_part.manufacturer_name and
		      attribute1 = v_cur_part.vendor_site_code and
		      mfg_part_num = v_cur_part.mfg_part_num and
		      agile_sys_acd = v_cur_part.agile_sys_acd;

		End;

  	    Else
     	     v_warning_message := 'Warning: This ASL already exists for this supplier';
     	     v_transfer_flag := 'No';
     	    End If;
     	   Elsif get_asl_item%NOTFOUND Then	-- Add ASL Record

     	   	v_api_asl_id := NULL;

		PO_ASL_THS.insert_row(
			x_row_id => v_row_id1,
			x_asl_id => v_api_asl_id,
			x_using_organization_id => v_cur_part.organization_id,
			x_owning_organization_id => v_cur_part.organization_id,
			x_vendor_business_type => v_cur_part.business_code,
			x_asl_status_id	=> v_cur_part.status_id,
			x_last_update_date => SYSDATE,
			x_last_updated_by => v_user_id,
			x_creation_date	=> SYSDATE,
			x_created_by => v_user_id,
			x_manufacturer_id => NULL,
			x_vendor_id => v_cur_part.vendor_id,
			x_item_id => v_cur_part.inventory_item_id,
			x_category_id => NULL,
			x_vendor_site_id => v_cur_part.vendor_site_id,
			x_primary_vendor_item => v_cur_part.mfg_part_num,
			x_manufacturer_asl_id => NULL,
			x_comments => NULL,
			x_review_by_date => NULL,
			x_attribute_category => NULL,
			x_attribute1 => NULL,
			x_attribute2 => NULL,
			x_attribute3 => NULL,
			x_attribute4 => NULL,
			x_attribute5 => NULL,
			x_attribute6 => NULL,
			x_attribute7 => NULL,
			x_attribute8 => NULL,
			x_attribute9 => NULL,
			x_attribute10 => NULL,
			x_attribute11 => NULL,
			x_attribute12 => NULL,
			x_attribute13 => NULL,
			x_attribute14 => NULL,
			x_attribute15 => NULL,
			x_last_update_login => NULL,
			x_disable_flag => NULL);

		 Commit;

	        If v_api_asl_id is NULL Then			-- Record not inserted by API

		 Update ilink_mfg_part_numbers
		 Set warning_message = warning_message||' '||'INSERT of ASL Failed'
		 Where record_id = v_cur_part.record_id and
		      eco_number = v_cur_part.eco_number and
		      item_number = v_cur_part.item_number and
		      manufacturer_name = v_cur_part.manufacturer_name and
		      attribute1 = v_cur_part.vendor_site_code and
		      mfg_part_num = v_cur_part.mfg_part_num and
		      agile_sys_acd = v_cur_part.agile_sys_acd;

		Elsif v_api_asl_id is NOT NULL Then     		-- ASL Record is inserted by API, so insert ASL attributes record

		po_asl_attributes_ths.insert_row(
			x_row_id => v_row_id2,
			x_asl_id => v_api_asl_id,
			x_using_organization_id => v_cur_part.organization_id,
			x_last_update_date => SYSDATE,
			x_last_updated_by => v_user_id,
			x_creation_date	=> SYSDATE,
			x_created_by => v_user_id,
			x_document_sourcing_method => 'ASL',
			x_release_generation_method => NULL,
			x_purchasing_unit_of_measure => NULL,
			x_enable_plan_schedule_flag => 'N',
			x_enable_ship_schedule_flag => 'N',
			x_plan_schedule_type => NULL,
			x_ship_schedule_type => NULL,
			x_plan_bucket_pattern_id => NULL,
			x_ship_bucket_pattern_id => NULL,
			x_enable_autoschedule_flag => 'N',
			x_scheduler_id => NULL,
			x_enable_authorizations_flag => 'N',
			x_vendor_id => v_cur_part.vendor_id,
			x_vendor_site_id => v_cur_part.vendor_site_id,
			x_item_id => v_cur_part.inventory_item_id,
			x_category_id => NULL,
			x_attribute_category => NULL,
			x_attribute1 => NULL,
			x_attribute2 => NULL,
			x_attribute3 => NULL,
			x_attribute4 => NULL,
			x_attribute5 => NULL,
			x_attribute6 => NULL,
			x_attribute7 => NULL,
			x_attribute8 => NULL,
			x_attribute9 => NULL,
			x_attribute10 => NULL,
			x_attribute11 => NULL,
			x_attribute12 => NULL,
			x_attribute13 => NULL,
			x_attribute14 => NULL,
			x_attribute15=> NULL,
			x_last_update_login => NULL,
			x_price_update_tolerance => NULL,
			x_processing_lead_time => NULL,
			x_delivery_calendar => NULL,
			x_min_order_qty => NULL,
			x_fixed_lot_multiple => NULL,
			x_country_of_origin_code => NULL,
			x_enable_vmi_flag => 'N',
			x_vmi_min_qty => NULL,
			x_vmi_max_qty => NULL,
			x_enable_vmi_auto_repl_flag => NULL,
			x_vmi_replenishment_approval => NULL,
			x_consigned_from_supplier_flag => NULL,
			x_consigned_billing_cycle => NULL,
			x_last_billing_date => NULL,
			x_replenishment_method => NULL,
			x_vmi_min_days => NULL,
			x_vmi_max_days => NULL,
			x_fixed_order_quantity => NULL,
			x_forecast_horizon => NULL,
			x_consume_on_aging_flag => NULL,
			x_aging_period => NULL);

	 	Commit;

	    End If;

  	   End If;
  	   close get_asl_item;


  	/* Process ASL Changes */

  	Elsif v_cur_part.transaction_type = 'C' Then

	  /* Fetch Current ASL Status from Oracle */

 	   v_ora_asl_id := NULL;
	   v_ora_asl_status_id := NULL;
	   v_ora_asl_row_id := NULL;

	   open get_asl_item(v_cur_part.vendor_id,v_cur_part.mfg_part_num,v_cur_part.vendor_site_id,
	        	   			v_cur_part.organization_id,v_cur_part.inventory_item_id);
     	   fetch get_asl_item into v_ora_asl_row_id,v_ora_asl_id,v_ora_asl_status_id;
	   If get_asl_item%NOTFOUND Then
	    v_warning_message := 'Warning: The ASL you are trying to update does not exist in Oracle';
	    v_transfer_flag := 'No';
     	   Elsif get_asl_item%FOUND and v_cur_part.status_id = v_ora_asl_status_id Then
     	    v_warning_message := 'Warning: The ASL does not need an update in Oracle';
     	    v_transfer_flag := 'No';
	   Elsif get_asl_item%FOUND and v_cur_part.status_id != v_ora_asl_status_id Then

	    v_disable_flag := NULL;
	    If nvl(upper(v_cur_part.asl_status),'NA') = 'INACTIVE' Then
	     v_disable_flag := 'Y';
	    Else
	     v_disable_flag := NULL;
	    End If;

	    /* Update ASL with the new status */

	       Begin

		PO_ASL_THS1.update_row(
			x_row_id => v_ora_asl_row_id,
			x_asl_id => v_ora_asl_id,
			x_using_organization_id => v_cur_part.organization_id,
			x_owning_organization_id => v_cur_part.organization_id,
			x_vendor_business_type => v_cur_part.business_code,
			x_asl_status_id	=> v_cur_part.status_id,
			x_last_update_date => SYSDATE,
			x_last_updated_by => v_user_id,
			x_creation_date	=> SYSDATE,
			x_created_by => v_user_id,
			x_manufacturer_id => NULL,
			x_vendor_id => v_cur_part.vendor_id,
			x_item_id => v_cur_part.inventory_item_id,
			x_category_id => NULL,
			x_vendor_site_id => v_cur_part.vendor_site_id,
			x_primary_vendor_item => v_cur_part.mfg_part_num,
			x_manufacturer_asl_id => NULL,
			x_comments => NULL,
			x_review_by_date => NULL,
			x_attribute_category => NULL,
			x_attribute1 => NULL,
			x_attribute2 => NULL,
			x_attribute3 => NULL,
			x_attribute4 => NULL,
			x_attribute5 => NULL,
			x_attribute6 => NULL,
			x_attribute7 => NULL,
			x_attribute8 => NULL,
			x_attribute9 => NULL,
			x_attribute10 => NULL,
			x_attribute11 => NULL,
			x_attribute12 => NULL,
			x_attribute13 => NULL,
			x_attribute14 => NULL,
			x_attribute15 => NULL,
			x_last_update_login => NULL,
			x_disable_flag => v_disable_flag);

		   Commit;

		Exception

		 When Others Then

		 Update ilink_mfg_part_numbers
		 Set warning_message = warning_message||' '||'UPDATE of ASL Failed'
		 Where record_id = v_cur_part.record_id and
		      eco_number = v_cur_part.eco_number and
		      item_number = v_cur_part.item_number and
		      manufacturer_name = v_cur_part.manufacturer_name and
		      attribute1 = v_cur_part.vendor_site_code and
		      mfg_part_num = v_cur_part.mfg_part_num and
		      agile_sys_acd = v_cur_part.agile_sys_acd;

		End;

  	   End If;
  	   close get_asl_item;

  	/* Process ASL Deletes */

	Elsif v_cur_part.transaction_type = 'D' Then

	  /* Fetch Current ASL Status from Oracle */

	   v_ora_asl_id := NULL;
	   v_ora_asl_status_id := NULL;
	   v_ora_asl_row_id := NULL;

	   open get_asl_item(v_cur_part.vendor_id,v_cur_part.mfg_part_num,v_cur_part.vendor_site_id,
	   	        	   			v_cur_part.organization_id,v_cur_part.inventory_item_id);
     	   fetch get_asl_item into v_ora_asl_row_id,v_ora_asl_id,v_ora_asl_status_id;
	   If get_asl_item%NOTFOUND Then
	    v_warning_message := 'Warning: The ASL you are trying to delete does not exist in Oracle';
	    v_transfer_flag := 'No';
	   Elsif get_asl_item%FOUND Then

	   /* Disable ASL */

	      Begin

		PO_ASL_THS1.update_row(
			x_row_id => v_ora_asl_row_id,
			x_asl_id => v_ora_asl_id,
			x_using_organization_id => v_cur_part.organization_id,
			x_owning_organization_id => v_cur_part.organization_id,
			x_vendor_business_type => v_cur_part.business_code,
			x_asl_status_id	=> v_ora_asl_status_id,
			x_last_update_date => SYSDATE,
			x_last_updated_by => v_user_id,
			x_creation_date	=> SYSDATE,
			x_created_by => v_user_id,
			x_manufacturer_id => NULL,
			x_vendor_id => v_cur_part.vendor_id,
			x_item_id => v_cur_part.inventory_item_id,
			x_category_id => NULL,
			x_vendor_site_id => v_cur_part.vendor_site_id,
			x_primary_vendor_item => v_cur_part.mfg_part_num,
			x_manufacturer_asl_id => NULL,
			x_comments => NULL,
			x_review_by_date => NULL,
			x_attribute_category => NULL,
			x_attribute1 => NULL,
			x_attribute2 => NULL,
			x_attribute3 => NULL,
			x_attribute4 => NULL,
			x_attribute5 => NULL,
			x_attribute6 => NULL,
			x_attribute7 => NULL,
			x_attribute8 => NULL,
			x_attribute9 => NULL,
			x_attribute10 => NULL,
			x_attribute11 => NULL,
			x_attribute12 => NULL,
			x_attribute13 => NULL,
			x_attribute14 => NULL,
			x_attribute15 => NULL,
			x_last_update_login => NULL,
			x_disable_flag => 'Y');

		   Commit;

		Exception

		 When Others Then

		 Update ilink_mfg_part_numbers
		 Set warning_message = warning_message
		 Where record_id = v_cur_part.record_id and
		      eco_number = v_cur_part.eco_number and
		      item_number = v_cur_part.item_number and
		      manufacturer_name = v_cur_part.manufacturer_name and
		      attribute1 = v_cur_part.vendor_site_code and
		      mfg_part_num = v_cur_part.mfg_part_num and
		      agile_sys_acd = v_cur_part.agile_sys_acd;

		End;

  	   End If;
  	   close get_asl_item;

	 End If;	-- Processed Add/Change/Delete

	/* Mark record as processed   */

	 Update ilink_mfg_part_numbers
	 Set process_flag = 'Y',
	     processed_date = SYSDATE,
	     record_status = 'Succeeded',
	     warning_message = warning_message||' '||v_warning_message,
	     transfer_to_oracle = v_transfer_flag
	 Where record_id = v_cur_part.record_id and
	      eco_number = v_cur_part.eco_number and
	      item_number = v_cur_part.item_number and
	      manufacturer_name = v_cur_part.manufacturer_name and
              mfg_part_num = v_cur_part.mfg_part_num and
              agile_sys_acd = v_cur_part.agile_sys_acd;

  End Loop;

Exception
  When Others then
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_PROCESS_ASLS is '||SQLERRM);

End ILINK_PROCESS_ASLS;


End ILINK_MPN_ASL_INTERFACE_PKG;