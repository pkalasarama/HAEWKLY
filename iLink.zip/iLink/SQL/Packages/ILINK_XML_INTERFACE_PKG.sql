create or replace package ILINK_XML_INTERFACE_PKG as

/*
REM +============================================================================================+
REM |Filename         :  BLD_XML_INTERFACE_PKG.pkh                   			 	 |
REM |                                                                                            |
REM |Copyright        : 2001-2013 CPG Solutions LLC - All Rights Reserved			 |
REM |                   All rights reserved:  This software/documentation contains proprietary   |
REM | 					information of CPG Solutions; it is provided under a license agreement 	 |
REM |					containing restrictions on use and disclosure and is also protected 	 |
REM | 					by copyright law.  Reverse engineering of the software is prohibited.    |
REM |                   					   	   	   	  	 |
REM |Description      : Package Header for parsing XML Files       				 |
REM |                        									 |
REM |                   	 	 		  	  		  	   	 |
REM |                   					   	   	   	  	 |
REM |                                                                                            |
REM |Calling Program  : 			 	 					 |
REM |                                                                                            |
REM |Pre-requisites   : None									 |
REM |                   		 	  	 		  	 	   	 |
REM |                                                                                            |
REM |Post Processing  : 								 	 |
REM |                   	   			   			 		 |
REM |                                                                                            |
REM |                     									 |
REM |Code Based On iLink Release: 7.6.2								                             |
REM |                                             						                         |
REM |                                                                                            |
REM |Customer:  Haemonetics 14-OCT-13                                                       	 |
REM |                                                                                            |
REM |Customer Change History:                                                                    |
REM |------------------------                                                                    |
REM |Version  Date       Author         Remarks                                                  |
REM |-------  --------- --------------  ---------------------------------------------------------|
REM |1.0      14-OCT-13 CPG Solutions  	First draft Version for Customer branched from iLink,	 |
REM |                                   code base 7.6.0     			 		                 |
REM |1.1      05-SEP-14 K Gangisetty    Modified Code to filter BOMs for purchased parts	     |
REM |                            								                                 |
REM |1.2      15-DEC-15 K Gangisetty    Modified code to delete data from staging tables when a	 |
REM |                                   failed change order comes back from Agile		         |
REM |1.3      											                                         |
REM |                                 								                             |
REM |1.4      											                                         |
REM |                                                                                            |
REM |1.5      										 	                                         |
REM |                                    			                                             |
REM |1.6     											                                         |
REM |                                                                                            |
REM | Be sure to update the version number below with the latest version number reference above. |
REM |                                                                                            |
REM +============================================================================================+
*/

                procedure  ILINK_XML_INT_MAIN(x_retcode OUT VARCHAR2,x_errbuff OUT VARCHAR2);
                procedure  ILINK_XML_PARSE_FILES(p_file_name In varchar2);
                procedure  ILINK_XML_LOAD_DATA;
		procedure  ILINK_XML_POST_LOAD;
		Function   ILINK_DATA_XREF(p_input1 In varchar2,p_input2 In varchar2,p_input3 In varchar2,
			 			p_input4 In varchar2,p_input5 In varchar2) Return Varchar2;
END ILINK_XML_INTERFACE_PKG;