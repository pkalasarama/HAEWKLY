CREATE OR REPLACE package ILINK_ECO_INTERFACE_PKG as

/*
REM +============================================================================================+
REM |Filename         :  BLD_ECO_INTERFACE_PKG.pkh                   			 	 |
REM |                                                                                            |
REM |Copyright        : 2001-2012 CPG Solutions LLC - All Rights Reserved			 |
REM |                   All rights reserved:  This software/documentation contains proprietary   |
REM | 					information of CPG Solutions; it is provided under a license agreement 	 |
REM |					containing restrictions on use and disclosure and is also protected 	 |
REM | 					by copyright law.  Reverse engineering of the software is prohibited.    |
REM |                   					   	   	   	  	 |
REM |Description      : Package Header for ECO Interface      				 	 |
REM |                        									 |
REM |                   	 	 		  	  		  	   	 |
REM |                   					   	   	   	  	 |
REM |                                                                                            |
REM |Calling Program  : 			 	 					 |
REM |                                                                                            |
REM |Pre-requisites   : None									 |
REM |                   		 	  	 		  	 	   	 |
REM |                                                                                            |
REM |Post Processing  : 								 	 |
REM |                   	   			   			 		 |
REM |                                                                                            |
REM |                     									 |
REM |Code Based On iLink Release: 7.6.0								 |
REM |                                             						 |
REM |                                                                                            |
REM |Customer: Angio Dynamics 06-SEP-2012   	                                                 |
REM |                                                                                            |
REM |Customer Change History:                                                                    |
REM |------------------------                                                                    |
REM |Version  Date       Author         Remarks                                                  |
REM |-------  --------- --------------  ---------------------------------------------------------|
REM |1.0      06-SEP-12 CPG Solutions  	First draft Version for Customer branched from iLink,	 |
REM |                                   code base 7.6.0     			 		 |
REM |1.1      								 	  		 |
REM |                            								 |
REM |1.2      											 |
REM |                                   							 |
REM |1.3      											 |
REM |                                 								 |
REM |1.4      											 |
REM |                                                                                            |
REM | Be sure to update the version number below with the latest version number reference above. |
REM |                                                                                            |
REM +============================================================================================+
*/

                PROCEDURE  ILINK_ECO_INT_MAIN(X_RETCODE OUT VARCHAR2,X_ERRBUFF OUT VARCHAR2);
		PROCEDURE  ILINK_ECO_COPY_ALL_ORGS(P_MASTER_ORG_ID IN NUMBER,P_MASTER_ORG_CODE IN VARCHAR2);
		PROCEDURE  ILINK_ECO_PRE_VALIDATE(P_MASTER_ORG_ID IN NUMBER);
		PROCEDURE  ILINK_ECO_INSERT_INT;
	        PROCEDURE  ILINK_CALL_ECO_APIS_INTERFACE(P_INTF_TAG IN VARCHAR2,P_STATUS_FLAG OUT VARCHAR2);
		PROCEDURE  ILINK_POST_ECO_API_PROCESS;

END ILINK_ECO_INTERFACE_PKG;