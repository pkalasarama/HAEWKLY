CREATE OR REPLACE package body ILINK_ECO_INTERFACE_PKG as                                                                                        

/*
REM +============================================================================================+
REM |Filename         :  BLD_ECO_INTERFACE_PKG.pkb                   			 	 | 
REM |                                                                                            | 
REM |Copyright        : 2001-2013 CPG Solutions LLC - All Rights Reserved			 | 
REM |                   All rights reserved:  This software/documentation contains proprietary   | 
REM | 					information of CPG Solutions; it is provided under a license agreement 	 | 
REM |					containing restrictions on use and disclosure and is also protected 	 | 
REM | 					by copyright law.  Reverse engineering of the software is prohibited.    | 
REM |                   					   	   	   	  	 | 
REM |Description      : Package Body for parsing XML Files contains the following program Units	 |
REM |                    ILINK_ECO_INT_MAIN      (Main process)    				 |
REM |			 ILINK_ECO_COPY_ALL_ORGS (Copy ECOs to Child Orgs)			 |
REM |   		 ILINK_ECO_PRE_VALIDATE (Validate data on Temporary tables)		 |
REM |    		 ILINK_ECO_INSERT_INT  (Insert validated records into Interface Tables)  |
REM |    		 ILINK_CALL_ECO_APIS_INTERFACE (Call ECO APIs)	                         |
REM |			 ILINK_POST_ECO_API_PROCESS (Determine the ECO Sucess/Error Status)      |
REM |                   					   	   	   	  	 | 
REM |                                                                                            | 
REM |Calling Program  : Concurrent Executable name is ILINKECOINT			 	 | 
REM |                                                                                            | 
REM |Pre-requisites   : None									 | 
REM |                   		 	  	 		  	 	   	 | 
REM |                                                                                            | 
REM |Post Processing  : 								 	 | 
REM |                   	   			   			 		 | 
REM |                                                                                            | 
REM |                     									 | 
REM |Code Based On iLink Release: 7.6.4								 | 
REM |                                             						 | 
REM |                                                                                            | 
REM |                                                                                            | 
REM |Customer: Haemonetics 14-OCT-13	   	                                                 | 
REM |                                                                                            | 
REM |Customer Change History:                                                                    | 
REM |------------------------                                                                    | 
REM |Version  Date       Author         Remarks                                                  | 
REM |-------  --------- --------------  ---------------------------------------------------------| 
REM |1.0      14-OCT-13 CPG Solutions  	First draft Version for Customer branched from iLink,	 | 
REM |                                   code base 7.6.0     			 		 | 
REM |1.1      08-MAY-14 CPG Solutions   Modified the parameter "operation_sequence_number" to	 | 
REM |                            	 "new_operation_sequence_number" in the ECO API		 | 
REM |1.2      14-MAY-14 CPG Solutions   Modified MCO logic to process revs for new items 	 | 
REM |                                   							 | 
REM |1.3      27-JUN-14 CPG Solutions   Modified code for old Agile rev check			 | 
REM |                                 								 | 
REM |1.4      29-OCT-14 K Gangisetty    Modified code to fix the BOM redlines for WB Whole Blood | 
REM |                                    Items                                                   | 
REM | Be sure to update the version number below with the latest version number reference above. | 
REM |                                                                                            | 
REM +============================================================================================+
*/

/* Declare Global Variables to be used across procedures */

  TYPE v_error_type IS TABLE OF VARCHAR2(30000) INDEX BY VARCHAR2(200);

  v_eco_header 	v_error_type;
  v_aff_item 	v_error_type;
  v_bom_comp 	v_error_type;
  v_sub_comp	v_error_type;
  v_bom_rdes	v_error_type;                           

  v_user_id 		Number := FND_GLOBAL.USER_ID();                


Procedure  ILINK_ECO_INT_MAIN(x_retcode OUT VARCHAR2,                                                                               
			      x_errbuff OUT VARCHAR2) is                                                                            


/* Define a Cursor to fetch the value for Master Organization */

Cursor get_master_org is
Select mpp.organization_id,
       mpp.organization_code
From MTL_PARAMETERS mpp,
     ILINK_DATA_XREF ref
Where mpp.organization_id = mpp.master_organization_id and
      ref.data_input1 = 'Master Org Code' and
      mpp.organization_code = ref.data_output1;


/* Define a cursor to fetch distinct ECO Number from the interface table */

Cursor get_unprc_eco is
Select distinct eec.change_notice,
       iet.released_date
From ENG_ENG_CHANGES_INTERFACE eec,
     ILINK_ECOS_TRANSFERED iet                                                                                                
Where eec.transaction_type = 'CREATE' and
      eec.change_notice = iet.eco_number
Order by iet.released_date; 

/* Define a Cursor to fetch ECO records in the interface tables ready to be processed */

Cursor get_eco(p_eco_no In varchar2) is                                                                                                                   
Select eng_changes_ifce_key                                                                                                         
From ENG_ENG_CHANGES_INTERFACE                                                                                                      
Where change_notice = p_eco_no
Order by eng_changes_ifce_key; 

/* Define a cursor to verify if validated records exist in temp table */

Cursor get_validated_records is
Select count (*)                                                                                                            
From ILINK_ECOS_TRANSFERED                                                                                                 
Where record_status = 'Validated'; 

v_count_records  	Number := 0;
v_master_org_id         Number;
v_master_org_code	Varchar2(3);
v_commit_flag		Varchar2(1);
v_status_flag		Varchar2(1);                                                                                                

begin           


	/* Fetch the value for Master Organization id  */
	
	 Open get_master_org;
	 Fetch get_master_org into v_master_org_id,v_master_org_code;
	 Close get_master_org;

	
	/* Call the Procedure to Populate the ECO records in temp tables for all organizations */

	ILINK_ECO_COPY_ALL_ORGS(v_master_org_id,v_master_org_code);
	commit; 

	/* Call the procedure to validate all the records before inserting into Interface tables */                                 

	ILINK_ECO_PRE_VALIDATE(v_master_org_id);                                                                                                    
	commit;                                                                                                                     

	/* Call the procedure to insert records into Interface tables if "Validated" records exist in temp table */                                                                                                                                    

	Open get_validated_records;
	Fetch get_validated_records into v_count_records;
	Close get_validated_records;                                                                                      

	If v_count_records != 0  then                                                                                               

		ILINK_ECO_INSERT_INT;                                                                                               
		commit;                                                                                                             

		/* Call the procedure to run the ECO Import API if records exist in the Interface tables */  

		For c_unprc_eco in get_unprc_eco Loop

		 v_commit_flag := 'Y';                      
		 FOR c_eco in get_eco(c_unprc_eco.change_notice) LOOP                                                                                           
		  ILINK_CALL_ECO_APIS_INTERFACE(c_eco.eng_changes_ifce_key,v_status_flag);
		  If nvl(v_status_flag,'E') != 'S' Then
		   v_commit_flag := 'N';
		  End If;
		 END LOOP;

		/* Commit only if all the ecos for all the orgs have succeded */
		 If nvl(v_commit_flag,'Y') = 'N' Then
		  Rollback;
		 Else
		  Commit;
		 End If;

		End Loop;      

		ILINK_POST_ECO_API_PROCESS;
		commit;                                                                                                   

	End If;    

  Exception
   When Others then
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_ECO_INT_MAIN is '||SQLERRM);


End ILINK_ECO_INT_MAIN;              


Procedure  ILINK_ECO_COPY_ALL_ORGS(p_master_org_id In Number,p_master_org_code In varchar2) is


/* Define a cursor to fetch ECOs that need to be inserted in child organizations */

Cursor get_unprc_eco is
Select distinct eco_number
From ILINK_ECOS_TRANSFERED 
Where organization_code = 'ZZZ'; 

/* Define a cursor to fetch child organizations from Items Tables for an ECO  */

Cursor get_item_eco_orgs(p_eco_no In Varchar2) is
Select distinct organization_id,
       organization_code
From ILINK_MTL_ITEMS_INT_TEMP 
Where eco_number = p_eco_no;
      
/* Define a cursor to fetch ECOs that need to be inserted in child organizations */

Cursor get_unprc_aff_eco is
Select distinct eco_number,
       item_number,
       new_revision
From ILINK_ECO_ITEM_REVISIONS_TEMP
Where organization_code = 'ZZZ'; 

/* Define a cursor to fetch child organizations from Items Tables for an ECO  */

Cursor get_item_aff_orgs(p_eco_no In Varchar2,p_item_no In Varchar2) is
Select distinct organization_id,
       organization_code
From ILINK_MTL_ITEMS_INT_TEMP 
Where eco_number = p_eco_no and
      item_number = p_item_no;            

/* Define a cursor to fetch MCO types to add BOM records for items in missing orgs */

Cursor get_mco_type is
Select data_output1 change_type
From ILINK_DATA_XREF
Where data_input1 = 'MCO Type';

-- Added the below cursor on 05/14/2014

/* Define a cursor new items created on MCO types to process revs */

Cursor get_rev_mco is
Select a.eco_number,
       a.item_number,
       a.revision
From  ILINK_MTL_ITEMS_INT_TEMP a,
      ILINK_DATA_XREF b
Where b.data_input1 = 'MCO Type For Item Revisions' and 
      b.data_output1 = a.attribute4 and
      nvl(disabled_flag,'N') = 'N' and
      a.organization_code = p_master_org_code and
      nvl(a.transaction_type,'NA') = 'CREATE' and
      a.revision is NOT NULL;


/* Define a cursor to organizations of a BOM from EBS  */

Cursor get_item_ebs_orgs(p_item_no In Varchar2) is
Select bbm.organization_id,
       mpp.organization_code                                                                                                   
From BOM_BILL_OF_MATERIALS bbm,                                                                                                     
     ILINK_MTL_SYSTEM_ITEMS_VIEW msi,
     MTL_PARAMETERS mpp
Where bbm.organization_id = msi.organization_id and                                   
      bbm.assembly_item_id = msi.inventory_item_id and
      msi.item_number = p_item_no and  
      bbm.alternate_bom_designator is NULL and
      bbm.organization_id = mpp.organization_id;

v_eco_status 	Varchar2(30);
v_pos		Number;
v_num		Number;
v_var		Number;
v_open_orgs	Varchar2(150) := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF('ECO Open Status Orgs',NULL,NULL,NULL,NULL);
v_eco_org	Varchar2(150);

Begin


   /* Populate ECO Header for all the child organizations */
   
        For c_ecoh in get_unprc_eco Loop
   
         For c_eco_orgs in get_item_eco_orgs(c_ecoh.eco_number) Loop
         
         
              v_eco_org	:= NULL;
	      v_eco_status := NULL;
	      v_pos := 0; 
	      v_var := 0;
	      Loop

	       v_pos := v_pos + 1;  

	       Select instr(NVL(v_open_orgs,'!'),',',1,v_pos) into v_num from dual;

	       If v_num != 0 then
		select substr(v_open_orgs,v_var+1,v_num-(v_var+1)) into v_eco_org from dual;
	       ElsIf v_num = 0 Then
		select substr(v_open_orgs,v_var+1,length(v_open_orgs)) into v_eco_org from dual;
	       End If;       

	       If v_eco_org = c_eco_orgs.organization_code Then
		v_eco_status := 'Open';
	       End If;

	       v_var := v_num;

	       Exit when v_num = 0;

	      End Loop;                   
   
   		Insert into ILINK_ECOS_TRANSFERED 
   			(eco_number,
   			eco_type,
   			description,
   			originator,
   			reason_code,
   			attribute1,
   			eco_status,
   			approval_status,
   			originated_date,
   			released_date,
   			organization_id,
   			organization_code,
   			record_status,
   			process_flag,
   			creation_date,
   			created_by,
   			last_update_date,
   			last_updated_by)   
   		Select 	eco1.eco_number,
   			eco1.eco_type,
   			eco1.description,
   			eco1.originator,
   			eco1.reason_code,
   			eco1.attribute1,
   			nvl(v_eco_status,'Scheduled'),
   			eco1.approval_status,
   			eco1.originated_date,
   			eco1.released_date,
   			c_eco_orgs.organization_id,
   			c_eco_orgs.organization_code,
   			eco1.record_status,
   			eco1.process_flag,
   			SYSDATE,
   			v_user_id,
   			SYSDATE,
   			v_user_id
   		From ILINK_ECOS_TRANSFERED eco1
   		Where eco1.eco_number = c_ecoh.eco_number and
   		      eco1.organization_code = 'ZZZ' and
   		      not exists (Select 'x' From ILINK_ECOS_TRANSFERED eco2
   				  Where eco2.organization_id = c_eco_orgs.organization_id and 
   					eco1.eco_number = eco2.eco_number);
   
   		
        End Loop;
   
    End Loop;
    

     /* Populate Affected Item and BOM records for all the organizations */

     For c_ecoa in get_unprc_aff_eco Loop

      For c_aff_orgs in get_item_aff_orgs(c_ecoa.eco_number,c_ecoa.item_number) Loop
		
		Insert into ILINK_ECO_ITEM_REVISIONS_TEMP
			(eco_number,
			item_number,
			new_revision,
			old_revision,
			lifecycle_status,
			attribute1,
			attribute2,
			attribute3,
			attribute4,
			effective_date_from,
			disposition_code,
			record_status,
			process_flag,
			organization_id,
			organization_code)
		Select 	itm1.eco_number,
			itm1.item_number,
			itm1.new_revision,
			itm1.old_revision,
			itm1.lifecycle_status,
			itm1.attribute1,
			itm1.attribute2,
			itm1.attribute3,
			itm1.attribute4,
			itm1.effective_date_from,
			itm1.disposition_code,
			itm1.record_status,
			itm1.process_flag,
			c_aff_orgs.organization_id,
			c_aff_orgs.organization_code
		From ILINK_ECO_ITEM_REVISIONS_TEMP itm1
		Where itm1.eco_number = c_ecoa.eco_number and
		      itm1.item_number = c_ecoa.item_number and
		      itm1.organization_code = 'ZZZ' and
		      not exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP itm2
				  Where itm2.organization_id = c_aff_orgs.organization_id and 
					itm2.eco_number = itm1.eco_number and
					itm2.item_number = itm1.item_number);
					
					
		Insert into ILINK_ECO_ITEM_BOMS_TEMP
			(eco_number,
			assembly_item_number,
			assembly_item_revision,
			component_item_number,
			component_remarks,
			quantity,
			agile_sys_acd,
			find_number,
			attribute1,
			attribute2,
			attribute3,
			attribute4,
			attribute5,
			record_status,
			process_flag,
			organization_id,
			organization_code)
		Select 	bom1.eco_number,
			bom1.assembly_item_number,
			c_ecoa.new_revision,
			bom1.component_item_number,
			bom1.component_remarks,
			bom1.quantity,
			bom1.agile_sys_acd,
			bom1.find_number,
			bom1.attribute1,
			bom1.attribute2,
			bom1.attribute3,
			bom1.attribute4,
			bom1.attribute5,
			bom1.record_status,
			bom1.process_flag,
			c_aff_orgs.organization_id,
			c_aff_orgs.organization_code
		From ILINK_ECO_ITEM_BOMS_TEMP bom1
		Where bom1.eco_number = c_ecoa.eco_number and
		      bom1.assembly_item_number = c_ecoa.item_number and
		      bom1.organization_code = 'ZZZ' and
		      not exists (Select 'x' From ILINK_ECO_ITEM_BOMS_TEMP bom2
				  Where bom2.organization_id = c_aff_orgs.organization_id and
					bom2.eco_number = bom1.eco_number and
					bom2.assembly_item_number = bom1.assembly_item_number and
					bom2.component_item_number = bom1.component_item_number) and
		      exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP imt
		      	      Where imt.eco_number = bom1.eco_number and
		      	            imt.item_number = bom1.assembly_item_number and
      				    imt.mfg_orgs like '%'||c_aff_orgs.organization_code||'%');		
      				    
		Insert into ILINK_ECO_BOM_REFDES_TEMP
     			(eco_number,
     			assembly_item_number,
     			assembly_item_revision,
     			component_item_number,
     			quantity,
     			agile_sys_acd,
     			find_number,
     			reference_designator,
     			record_status,
     			process_flag,
     			organization_id,
     			organization_code)
     		Select 	bom1.eco_number,
     			bom1.assembly_item_number,
     			c_ecoa.new_revision,
     			bom1.component_item_number,
     			bom1.quantity,
     			bom1.agile_sys_acd,
     			bom1.find_number,
     			bom1.reference_designator,
     			bom1.record_status,
     			bom1.process_flag,
     			c_aff_orgs.organization_id,
     			c_aff_orgs.organization_code
     		From ILINK_ECO_BOM_REFDES_TEMP bom1
     		Where bom1.eco_number = c_ecoa.eco_number and
     		      bom1.assembly_item_number = c_ecoa.item_number and
     		      bom1.organization_code = 'ZZZ' and
     		      not exists (Select 'x' From ILINK_ECO_BOM_REFDES_TEMP bom2
     				  Where bom2.organization_id = c_aff_orgs.organization_id and
     					bom2.eco_number = bom1.eco_number and
     					bom2.assembly_item_number = bom1.assembly_item_number and
     					bom2.component_item_number = bom1.component_item_number and
     					bom2.reference_designator = bom1.reference_designator) and
			  exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP imt
		      	      	  Where imt.eco_number = bom1.eco_number and
		      	            	imt.item_number = bom1.assembly_item_number and
      				    	imt.mfg_orgs like '%'||c_aff_orgs.organization_code||'%');      				    
      				    
		Insert into ILINK_ECO_ITEM_BOMS_TEMP
			(eco_number,
			assembly_item_number,
			assembly_item_revision,
			component_item_number,
			component_remarks,
			quantity,
			agile_sys_acd,
			find_number,
			attribute1,
			attribute2,
			attribute3,
			attribute4,
			attribute5,
			record_status,
			process_flag,
			organization_id,
			organization_code)
		Select 	bom1.eco_number,
			bom1.assembly_item_number,
			c_ecoa.new_revision,
			bom1.component_item_number,
			bom1.component_remarks,
			bom1.quantity,
			bom1.agile_sys_acd,
			bom1.find_number,
			bom1.attribute1,
			bom1.attribute2,
			bom1.attribute3,
			bom1.attribute4,
			bom1.attribute5,
			bom1.record_status,
			bom1.process_flag,
			c_aff_orgs.organization_id,
			c_aff_orgs.organization_code
		From ILINK_ECO_ITEM_BOMS_TEMP bom1
		Where bom1.eco_number = c_ecoa.eco_number and
		      bom1.assembly_item_number = c_ecoa.item_number and
		      bom1.organization_code = 'ZZZ' and
		      not exists (Select 'x' From ILINK_ECO_ITEM_BOMS_TEMP bom2
				  Where bom2.organization_id = c_aff_orgs.organization_id and
					bom2.eco_number = bom1.eco_number and
					bom2.assembly_item_number = bom1.assembly_item_number and
					bom2.component_item_number = bom1.component_item_number) and
		      exists (Select 'x' from ILINK_DATA_XREF imt
		      	      Where imt.data_input1 = 'Other BOM Orgs' and
      				    imt.data_output1 like '%'||c_aff_orgs.organization_code||'%');      				    
					
					     	
			Insert into ILINK_ECO_BOM_REFDES_TEMP
				(eco_number,
				assembly_item_number,
				assembly_item_revision,
				component_item_number,
				quantity,
				agile_sys_acd,
				find_number,
				reference_designator,
				record_status,
				process_flag,
				organization_id,
				organization_code)
			Select 	bom1.eco_number,
				bom1.assembly_item_number,
				c_ecoa.new_revision,
				bom1.component_item_number,
				bom1.quantity,
				bom1.agile_sys_acd,
				bom1.find_number,
				bom1.reference_designator,
				bom1.record_status,
				bom1.process_flag,
				c_aff_orgs.organization_id,
				c_aff_orgs.organization_code
			From ILINK_ECO_BOM_REFDES_TEMP bom1
			Where bom1.eco_number = c_ecoa.eco_number and
			      bom1.assembly_item_number = c_ecoa.item_number and
			      bom1.organization_code = 'ZZZ' and
			      not exists (Select 'x' From ILINK_ECO_BOM_REFDES_TEMP bom2
					  Where bom2.organization_id = c_aff_orgs.organization_id and
						bom2.eco_number = bom1.eco_number and
						bom2.assembly_item_number = bom1.assembly_item_number and
						bom2.component_item_number = bom1.component_item_number and
						bom2.reference_designator = bom1.reference_designator) and
				  exists (Select 'x' from ILINK_DATA_XREF imt
		      	      		  Where imt.data_input1 = 'Other BOM Orgs' and
      				    		imt.data_output1 like '%'||c_aff_orgs.organization_code||'%');   			      				    		     				    	
      				    					     	
     End Loop;

    End Loop;
    
    
    /* Populate ECO Header, Affected Item and BOM records for all the organizations where the item has a BOM in EBS */

     For c_ecoa in get_unprc_aff_eco Loop

      For c_aff_orgs in get_item_ebs_orgs(c_ecoa.item_number) Loop
      
      	      v_eco_org	:= NULL;
      	      v_eco_status := NULL;
      	      v_pos := 0; 
      	      v_var := 0;
      	      Loop
      
      	       v_pos := v_pos + 1;  
      
      	       Select instr(NVL(v_open_orgs,'!'),',',1,v_pos) into v_num from dual;
      
      	       If v_num != 0 then
      		select substr(v_open_orgs,v_var+1,v_num-(v_var+1)) into v_eco_org from dual;
      	       ElsIf v_num = 0 Then
      		select substr(v_open_orgs,v_var+1,length(v_open_orgs)) into v_eco_org from dual;
      	       End If;       
      
      	       If v_eco_org = c_aff_orgs.organization_code Then
      		v_eco_status := 'Open';
      	       End If;
      
      	       v_var := v_num;
      
      	       Exit when v_num = 0;
      
	      End Loop;                   
      
                Insert into ILINK_ECOS_TRANSFERED 
   			(eco_number,
   			eco_type,
   			description,
   			originator,
   			reason_code,
   			attribute1,
   			eco_status,
   			approval_status,
   			originated_date,
   			released_date,
   			organization_id,
   			organization_code,
   			record_status,
   			process_flag,
   			creation_date,
   			created_by,
   			last_update_date,
   			last_updated_by)   
   		Select 	eco1.eco_number,
   			eco1.eco_type,
   			eco1.description,
   			eco1.originator,
   			eco1.reason_code,
   			eco1.attribute1,
   			nvl(v_eco_status,'Scheduled'),
   			eco1.approval_status,
   			eco1.originated_date,
   			eco1.released_date,
   			c_aff_orgs.organization_id,
			c_aff_orgs.organization_code,
   			eco1.record_status,
   			eco1.process_flag,
   			SYSDATE,
   			v_user_id,
   			SYSDATE,
   			v_user_id
   		From ILINK_ECOS_TRANSFERED eco1
   		Where eco1.eco_number = c_ecoa.eco_number and
   		      eco1.organization_code = 'ZZZ' and
   		      not exists (Select 'x' From ILINK_ECOS_TRANSFERED eco2
   				  Where eco2.organization_id = c_aff_orgs.organization_id and 
   					eco1.eco_number = eco2.eco_number);      
		
		Insert into ILINK_ECO_ITEM_REVISIONS_TEMP
			(eco_number,
			item_number,
			new_revision,
			old_revision,
			lifecycle_status,
			attribute1,
			attribute2,
			attribute3,
			attribute4,
			effective_date_from,
			disposition_code,
			record_status,
			process_flag,
			organization_id,
			organization_code)
		Select 	itm1.eco_number,
			itm1.item_number,
			itm1.new_revision,
			itm1.old_revision,
			itm1.lifecycle_status,
			itm1.attribute1,
			itm1.attribute2,
			itm1.attribute3,
			itm1.attribute4,
			itm1.effective_date_from,
			itm1.disposition_code,
			itm1.record_status,
			itm1.process_flag,
			c_aff_orgs.organization_id,
			c_aff_orgs.organization_code
		From ILINK_ECO_ITEM_REVISIONS_TEMP itm1
		Where itm1.eco_number = c_ecoa.eco_number and
		      itm1.item_number = c_ecoa.item_number and
		      itm1.organization_code = 'ZZZ' and
		      not exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP itm2
				  Where itm2.organization_id = c_aff_orgs.organization_id and 
					itm2.eco_number = itm1.eco_number and
					itm2.item_number = itm1.item_number);
					
					
		Insert into ILINK_ECO_ITEM_BOMS_TEMP
			(eco_number,
			assembly_item_number,
			assembly_item_revision,
			component_item_number,
			component_remarks,
			quantity,
			agile_sys_acd,
			find_number,
			attribute1,
			attribute2,
			attribute3,
			attribute4,
			attribute5,
			record_status,
			process_flag,
			organization_id,
			organization_code)
		Select 	bom1.eco_number,
			bom1.assembly_item_number,
			c_ecoa.new_revision,
			bom1.component_item_number,
			bom1.component_remarks,
			bom1.quantity,
			bom1.agile_sys_acd,
			bom1.find_number,
			bom1.attribute1,
			bom1.attribute2,
			bom1.attribute3,
			bom1.attribute4,
			bom1.attribute5,
			bom1.record_status,
			bom1.process_flag,
			c_aff_orgs.organization_id,
			c_aff_orgs.organization_code
		From ILINK_ECO_ITEM_BOMS_TEMP bom1
		Where bom1.eco_number = c_ecoa.eco_number and
		      bom1.assembly_item_number = c_ecoa.item_number and
		      bom1.organization_code = 'ZZZ' and
		      not exists (Select 'x' From ILINK_ECO_ITEM_BOMS_TEMP bom2
				  Where bom2.organization_id = c_aff_orgs.organization_id and
					bom2.eco_number = bom1.eco_number and
					bom2.assembly_item_number = bom1.assembly_item_number and
					bom2.component_item_number = bom1.component_item_number);		
      				    
		Insert into ILINK_ECO_BOM_REFDES_TEMP
     			(eco_number,
     			assembly_item_number,
     			assembly_item_revision,
     			component_item_number,
     			quantity,
     			agile_sys_acd,
     			find_number,
     			reference_designator,
     			record_status,
     			process_flag,
     			organization_id,
     			organization_code)
     		Select 	bom1.eco_number,
     			bom1.assembly_item_number,
     			c_ecoa.new_revision,
     			bom1.component_item_number,
     			bom1.quantity,
     			bom1.agile_sys_acd,
     			bom1.find_number,
     			bom1.reference_designator,
     			bom1.record_status,
     			bom1.process_flag,
     			c_aff_orgs.organization_id,
     			c_aff_orgs.organization_code
     		From ILINK_ECO_BOM_REFDES_TEMP bom1
     		Where bom1.eco_number = c_ecoa.eco_number and
     		      bom1.assembly_item_number = c_ecoa.item_number and
     		      bom1.organization_code = 'ZZZ' and
     		      not exists (Select 'x' From ILINK_ECO_BOM_REFDES_TEMP bom2
     				  Where bom2.organization_id = c_aff_orgs.organization_id and
     					bom2.eco_number = bom1.eco_number and
     					bom2.assembly_item_number = bom1.assembly_item_number and
     					bom2.component_item_number = bom1.component_item_number and
     					bom2.reference_designator = bom1.reference_designator);      				          				    		      				    		     				    
      				    					     	
     End Loop;

    End Loop;    
    
    
    
	/* Delete Original ECO records in temp tables */                                                                                                         
     
       	  Delete From ILINK_ECOS_TRANSFERED                                                                                                     
    	  Where organization_code = 'ZZZ';    
    
    	  Delete From ILINK_ECO_ITEM_REVISIONS_TEMP
    	  Where organization_code = 'ZZZ';                                                                                           
    
    	  Delete From ILINK_ECO_ITEM_BOMS_TEMP
    	  Where organization_code = 'ZZZ';            
    	  
    	  Delete From ILINK_ECO_BOM_REFDES_TEMP
	  Where organization_code = 'ZZZ'; 
	  

    /* Delete affected items and BOM Component records from MCOs 

    For c_mco_type1 in get_mco_type Loop
		         
     Delete From ILINK_ECO_ITEM_BOMS_TEMP ibm
     Where exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP iei,
                                   ILINK_MTL_ITEMS_INT_TEMP itm
		   Where ibm.eco_number = iei.eco_number and
			 ibm.organization_code = iei.organization_code and
			 ibm.assembly_item_number = iei.item_number and
			 iei.eco_number = itm.eco_number and
			 iei.item_number = itm.item_number and		
			 iei.organization_code = itm.organization_code and
			 itm.transaction_type = 'UPDATE' and
			 exists (Select 'x' From ILINK_ECOS_TRANSFERED iet
				 Where iet.eco_number = iei.eco_number and
				       iet.eco_type = c_mco_type1.change_type)); 

     Delete From ILINK_ECO_ITEM_REVISIONS_TEMP iei
     Where exists (Select 'x' From ILINK_ECOS_TRANSFERED iet
	           Where iet.eco_number = iei.eco_number and
		         iet.organization_code = iei.organization_code and
		         iet.eco_type = c_mco_type1.change_type) and
	   exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP itm
	   	   Where iei.eco_number = itm.eco_number and
			 iei.organization_code = itm.organization_code and
			 iei.item_number = itm.item_number and
			 itm.transaction_type = 'UPDATE');			        

    End Loop;	*/ 
    
   -- Added the below on 05/14/2014 to process revisions only for new items 
   
    For c1 in get_rev_mco Loop
		         
     Update ILINK_ECO_ITEM_BOMS_TEMP
     Set assembly_item_revision = c1.revision
     Where eco_number = c1.eco_number and    			 
     	   assembly_item_number = c1.item_number;

     Update ILINK_ECO_ITEM_REVISIONS_TEMP iei
     Set new_revision = c1.revision
     Where eco_number = c1.eco_number and    			 
     	   item_number = c1.item_number;

    End Loop;	-- End 05/14/2014    
        
    
  Exception
   When Others then
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_ECO_COPY_ALL_ORGS is '||SQLERRM);

End ILINK_ECO_COPY_ALL_ORGS;


Procedure ILINK_ECO_PRE_VALIDATE(p_master_org_id In Number) is                                                                                               


/* Define cursors to determine if BOM exists for an assembly */         

Cursor get_assy_number is                                                                                                           
Select eco_number,
       item_number,
       organization_id                                                                                       
From ILINK_ECO_ITEM_REVISIONS_TEMP aei                                                                                              
Where aei.record_status = 'Unprocessed' and                                                                                         
      exists (Select 'x' From ILINK_ECO_ITEM_BOMS_TEMP aeb                                                                          
		Where aeb.eco_number = aei.eco_number and
		      aeb.organization_id = aei.organization_id)                                                                                            
Order by eco_number;                                                                                                                

Cursor get_bom_exists(p_assy_number In varchar2,p_org_id In number) is                                                              
Select 'Y'                                                                                                                          
From BOM_BILL_OF_MATERIALS bbm,                                                                                                     
    ILINK_MTL_SYSTEM_ITEMS_VIEW msi                                                                                                 
Where msi.organization_id = p_org_id and                                                                                            
      msi.item_number = p_assy_number and                                                                                           
      bbm.organization_id = msi.organization_id and                                                                                 
      bbm.assembly_item_id = msi.inventory_item_id and
      bbm.alternate_bom_designator is NULL;                                                                                 

/*  Define Cursor to validate ECO Headers  */                                                                                       

Cursor get_eco_header is                                                                                                            
Select eco_number,                                                                                        
       description,
       attribute1 change_type,       
       originator,
       reason_code reason_code,                                                                               
       organization_code,                                                                                                          
       organization_id,                                                                                                            
       record_status                                                                                                            
From ILINK_ECOS_TRANSFERED                                                                                                          
Where nvl(process_flag,'N') = 'N'                                                                                                   
Order by released_date,eco_number;                                                                                                                

/*  Define Cursor to validate ECO Assembly Items  */                                                                                

Cursor get_eco_item(p_eco_no In Varchar2,p_org_id In Number) is                                                                                                              
Select irev.eco_number,
       irev.record_id,                                                                                                             
       irev.item_number,
       irev.new_revision,
       irev.lifecycle_status,    
       decode(to_char(irev.effective_date_from,'HH24:MI:SS'),'00:00:00',
	      to_date(to_char(irev.effective_date_from,'DD-MON-YYYY')||to_char(SYSDATE,'HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS'),                                                                              
			      irev.effective_date_from) effective_date_from,                                                                      
       irev.effective_date_to,                                                                                                     
       irev.old_revision,                                                                               
       irev.organization_code,                                                                                                     
       irev.organization_id,                                                                                                       
       irev.record_status,
       irev.attribute2,
       irev.attribute3,
       irev.attribute4,
       irev.disposition_type
From ILINK_ECO_ITEM_REVISIONS_TEMP IREV                                                                                  
Where irev.eco_number = p_eco_no and
      irev.organization_id = p_org_id and                                                                                               
      nvl(irev.process_flag,'N') = 'N' and
      exists (Select 'x' From ILINK_ECOS_TRANSFERED AET                                                                               
	    Where aet.eco_number = irev.eco_number and                                                                              
		  aet.organization_id = irev.organization_id and
		  aet.record_status = 'Validated')                                                                                        
Order by irev.item_number,irev.new_revision;                                                                                       

/*  Define Cursor to validate ECO BOM components  */                                                                                

Cursor get_bom_component(p_eco_no In Varchar2,p_org_id In Number,p_assy_item In Varchar2) is                                                                                                         
Select ibom.eco_number,  
       ibom.record_id,                                                                                                             
       ibom.assembly_item_number,
       ibom.assembly_item_revision,
       ibom.component_item_number,
       ibom.find_number,
       ibom.organization_code,
       ibom.parent_comp_number,	                                                                                
       ibom.quantity,                                                                                                              
       ibom.effective_date_from,                                                                                                   
       ibom.effective_date_to,                                                                                                     
       ibom.agile_sys_acd,
       ibom.organization_id,                                                                                                       
       ibom.record_status,
       ibom.component_yield,
       ibom.attribute5 sub_flag
From ILINK_ECO_ITEM_BOMS_TEMP IBOM                                                                                                  
Where ibom.eco_number = p_eco_no and
      ibom.organization_id = p_org_id and 
      ibom.assembly_item_number = p_assy_item and
      nvl(ibom.process_flag,'N') = 'N' and                                                                                             
      exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP AEI                                                                       
	      Where aei.eco_number = ibom.eco_number and                                                                              
		    aei.organization_id = ibom.organization_id and
		    aei.item_number = ibom.assembly_item_number and                                                                   
		    aei.record_status = 'Validated')                                                                                  
Order by assembly_item_number asc,component_item_number,find_number asc,attribute5 desc;             -- Added component_item_number for Haemonetics                                         

/* Define Cursor to Verify if the ECO exists in Oracle */                                                                           

Cursor get_eco_oracle(p_eco_number IN varchar2,p_organization_id IN number) is                                                      
Select change_notice                                                                                                                
From ENG_ENGINEERING_CHANGES                                                                                                        
Where organization_id = p_organization_id and                                                                                       
      change_notice = p_eco_number;                                                                                                 

/* Define Cursor to Verify if the Reason code exists in Oracle */                                                                   

Cursor get_reason_code(p_reason_code_description IN varchar2) is                                                                    
Select eng_change_reason_code                                                                                                       
From ENG_CHANGE_REASONS                                                                                                             
Where upper(description) = upper(p_reason_code_description) or                                                                                    
      upper(eng_change_reason_code) = upper(p_reason_code_description) and                                                                        
      (disable_date is NULL or disable_date > SYSDATE);                                                                             

/* Define Cursor to Verify if the ECO Type exists in Oracle */                                                                   

Cursor get_eco_type(p_eco_type IN varchar2) is                                                                    
Select b.type_name
From ENG_CHANGE_ORDER_TYPES a,
     ENG_CHANGE_ORDER_TYPES_TL b
Where a.change_order_type_id = b.change_order_type_id and
      a.change_mgmt_type_code = 'CHANGE_ORDER' and
      a.type_classification = 'HEADER' and
      b.language = 'US' and
      b.type_name = p_eco_type; 
      
/* Define a cursor to verify if Originator exists in Oracle */

Cursor get_originator(p_name In Varchar2) is
Select fnu.user_name
From FND_USER fnu,
     HR_EMPLOYEES hre
Where upper(hre.FIRST_NAME)||' '||upper(hre.last_name) = upper(p_name) and
      hre.employee_id = fnu.employee_id;
      
/* Define Cursor to Verify if component data exists in temp table for a given Assembly item */                                      

Cursor get_bom_data(p_eco_number IN varchar2,p_item_number IN varchar2,p_org_id IN Number) is                                                          
Select count(*)                                                                                                                     
From ILINK_ECO_ITEM_BOMS_TEMP                                                                                                       
Where eco_number = p_eco_number and                                                                                                 
      assembly_item_number = p_item_number and
      organization_id = p_org_id;                                                                                         


/* Define Cursor to Verify if an item exists in Oracle */                                                                           

Cursor get_oracle_item(p_item_number IN varchar2,p_organization_id IN number) is                                                    
Select inventory_item_id                                                                                                            
From ILINK_MTL_SYSTEM_ITEMS_VIEW                                                                                                               
Where organization_id = p_organization_id and                                                                                       
     item_number = p_item_number;                                                                                                      


/* Define Cursor to fetch the latest revision for an item in Oracle */                                                              

Cursor get_latest_rev_oracle(p_item_id IN number,p_organization_id IN number) is                                                    
Select revision,effectivity_date,revision agile_rev                                                                                          
From MTL_ITEM_REVISIONS                                                                                                             
Where inventory_item_id = p_item_id and                                                                                             
      organization_id = p_organization_id
Order by revision desc;                                                                                          


/* Define Cursor to Verify if a component exists for a given BOM (Assembly) in Oracle */                                            

Cursor get_comp_exists_bom(p_assembly_item_id IN number,p_organization_id IN number,                                                
			   p_component_item_id IN number) is                                                                      
Select bic.operation_seq_num,                                                                                                       
       to_date(to_char(BIC.effectivity_date,'DD-MON-YYYY HH24:MI:SS'),'DD-MON-YYYY HH24:MI:SS') effectivity_date,
       bic.item_num,
       bic.component_quantity                    
From BOM_BILL_OF_MATERIALS BBM,                                                                                                     
     BOM_INVENTORY_COMPONENTS BIC                                                                                                   
Where bbm.assembly_item_id =  p_assembly_item_id and                                                                                
      bbm.organization_id = p_organization_id and   
      bbm.alternate_bom_designator is NULL and	                                                                                
      bic.component_item_id = p_component_item_id and                                                                               
      bic.bill_sequence_id = bbm.bill_sequence_id and                                                        
     (bic.disable_date is null or bic.disable_date > SYSDATE) and
      bic.effectivity_date <= SYSDATE and				-- Added for Haemonetics
      bic.implementation_date is NOT NULL and 				-- Added for Haemonetics
      bic.implementation_date <= SYSDATE;     				-- Added for Haemonetics                                                                 


/* Define Cursor to fetch the component details (to be used for processing ACD types "C" and "D") from Oracle */                    

Cursor get_assembly_details(p_eco_number IN varchar2,p_item_number IN varchar2,p_org_id IN Number) is                                                  
Select new_revision,
       effective_date_from                                                                                             
From ILINK_ECO_ITEM_REVISIONS_TEMP                                                                                                  
Where eco_number = p_eco_number and                                                                                                 
      item_number = p_item_number and
      organization_id = p_org_id;  

/* Define a cursor to fetch the parent component details for substitutes */

Cursor get_par_comp_details(p_eco_num In varchar2,p_assy_num In varchar2,
			    p_assy_rev In varchar2,p_comp_num In varchar2,p_org_id IN Number) is
Select operation_seq_num,
       agile_sys_acd
From ILINK_ECO_ITEM_BOMS_TEMP
Where eco_number= p_eco_num and
      assembly_item_number = p_assy_num and
      assembly_item_revision = p_assy_rev and                                              
      component_item_number = p_comp_num and
      nvl(attribute5,'P') = 'P' and
      organization_id = p_org_id;             

/* Define a cursor to check if substitute exists for a component */

Cursor check_sub_exists(p_assembly_item_id IN number,p_organization_id IN number,                                                
			p_SUB_component_item_id IN number,p_component_num In varchar2) is                                                                                             
Select 'Y'                
From BOM_BILL_OF_MATERIALS BBM,                                                                                                     
     BOM_INVENTORY_COMPONENTS BIC,
     BOM_SUBSTITUTE_COMPONENTS BSC,
     ILINK_MTL_SYSTEM_ITEMS_VIEW MSI                                                                                                   
Where bbm.assembly_item_id =  p_assembly_item_id and                                                                                
      bbm.organization_id = p_organization_id and 
      bbm.alternate_bom_designator is NULL and	                                                                                  
      bic.component_item_id = msi.inventory_item_id and 
      msi.organization_id = bbm.organization_id and
      msi.item_number = P_component_num and                                                                              
      bic.bill_sequence_id = bbm.bill_sequence_id and                                                                               
      (bic.disable_date is null or bic.disable_date > SYSDATE) and
      bsc.substitute_component_id = p_sub_component_item_id and        
      bic.component_sequence_id = bsc.component_sequence_id;   

/* Define a cursor to fetch substitutes to disable for find number changes */

Cursor get_existing_subs(p_assembly_item_id IN number,p_organization_id IN number,p_component_num In varchar2,p_eco_num IN varchar2) is
Select msi2.item_number sub_number,
       bsc.substitute_item_quantity sub_qty,
       bic.operation_seq_num       
From BOM_BILL_OF_MATERIALS BBM,                                                                                                     
     BOM_INVENTORY_COMPONENTS BIC,
     BOM_SUBSTITUTE_COMPONENTS BSC,
     ILINK_MTL_SYSTEM_ITEMS_VIEW MSI1,
     ILINK_MTL_SYSTEM_ITEMS_VIEW MSI2                                                                                                   
Where bbm.assembly_item_id =  p_assembly_item_id and                                                                                
      bbm.organization_id = p_organization_id and 
      bbm.alternate_bom_designator is NULL and	                                                                                  
      bic.component_item_id = msi1.inventory_item_id and 
      msi1.organization_id = bbm.organization_id and                                                                
      bsc.substitute_component_id = msi2.inventory_item_id and 
      msi2.organization_id = bbm.organization_id and
      msi1.item_number = p_component_num and                                                                              
      bic.bill_sequence_id = bbm.bill_sequence_id and                                                                               
      (bic.disable_date is null or bic.disable_date > SYSDATE) and  
      bic.component_sequence_id = bsc.component_sequence_id and
      nvl(bsc.acd_type,1) = 1 and	
      not exists (Select 'x' From ILINK_ECO_ITEM_BOMS_TEMP temp,
				  ILINK_MTL_SYSTEM_ITEMS_VIEW MSI3
		  Where temp.eco_number = p_eco_num and
			temp.assembly_item_number = msi3.item_number and
			msi3.inventory_item_id = bbm.assembly_item_id and
			temp.parent_comp_number = p_component_num and
			temp.component_item_number = msi2.item_number and
			temp.agile_sys_acd in ('A','D'));

/* Define a cursor to see if Assembly Item exists on ane Errored ECOs */

Cursor get_error_eco(p_assy_item In varchar2,p_eco_number in varchar2) is
Select itm.eco_number 
From ILINK_ECO_ITEM_REVISIONS_TEMP itm
Where itm.item_number = p_assy_item and
      exists (Select 'X' From ILINK_ECOS_TRANSFERED ecoh
			 Where  itm.eco_number = ecoh.eco_number and
				upper(ecoh.record_status) ='ERROR' and
				eco_number != p_eco_number); 

/* Define a cursor to check if duplicate primaries exists on a find number */

Cursor check_dup_primary(p_eco_number IN Varchar2,p_org_id IN Number,p_find_num IN Number,
			p_assy_num IN Varchar2,p_comp_num IN Varchar2) is
Select component_item_number
From ILINK_ECO_ITEM_BOMS_TEMP
Where eco_number= p_eco_number and
      organization_id = p_org_id and
      assembly_item_number = p_assy_num and                                             
      nvl(attribute5,'P') = 'P' and
      find_number = p_find_num and
      component_item_number != p_comp_num and
      agile_sys_acd in ('A','C');
      
/* Define a cursor to check if the item seq # already exists in EBS */

Cursor check_ebs_item_seq (p_assembly_item_id IN number,p_organization_id IN number,                                                
			   p_item_seq_num IN number) is
Select bic.item_num,
       bic.component_item_id		-- Added on 11/11/2014
From BOM_BILL_OF_MATERIALS BBM,                                                                                                     
     BOM_INVENTORY_COMPONENTS BIC                                                                                                   
Where bbm.assembly_item_id =  p_assembly_item_id and                                                                                
      bbm.organization_id = p_organization_id and   
      bbm.alternate_bom_designator is NULL and	     
      bic.bill_sequence_id = bbm.bill_sequence_id and  
      bic.item_num = p_item_seq_num and                                                                    
     (bic.disable_date is null or bic.disable_date > SYSDATE) and
      bic.implementation_date is NOT NULL;
      
-- Added the below cursor on 10/29/2014      
/* Define a cursor to check if the item seq # already exists in EBS For C type Redlines */

Cursor check_ebs_item_seq1 (p_assembly_item_id IN number,p_organization_id IN number,                                                
			   p_item_seq_num IN number,p_comp_id In Number) is
Select bic.item_num,
       bic.component_item_id		-- Added on 11/11/2014
From BOM_BILL_OF_MATERIALS BBM,                                                                                                     
     BOM_INVENTORY_COMPONENTS BIC                                                                                                   
Where bbm.assembly_item_id =  p_assembly_item_id and                                                                                
      bbm.organization_id = p_organization_id and   
      bbm.alternate_bom_designator is NULL and	     
      bic.bill_sequence_id = bbm.bill_sequence_id and
      bic.component_item_id != p_comp_id and
      bic.item_num = p_item_seq_num and                                                                    
     (bic.disable_date is null or bic.disable_date > SYSDATE) and
      bic.implementation_date is NOT NULL;      			-- End 10/29/2014
      
/* Define a cursor to check if a component is being disabled on a find number */

Cursor check_disable_comp(p_eco_number IN Varchar2,p_org_id IN Number,p_find_num IN Number,
			p_assy_num IN Varchar2) is
Select component_item_number
From ILINK_ECO_ITEM_BOMS_TEMP
Where eco_number= p_eco_number and
      organization_id = p_org_id and
      assembly_item_number = p_assy_num and                                             
      nvl(attribute5,'P') = 'P' and
      find_number = p_find_num and
      agile_sys_acd = 'D';      

-- Added the cursor on 11/11/2014      
/* Define a cursor to check if a component is being changed on a find number */

Cursor check_comp_change(p_eco_number IN Varchar2,p_org_id IN Number,p_find_num IN Number,
			p_assy_num IN Varchar2,p_comp_id In Number) is
Select 'y'
From ILINK_ECO_ITEM_BOMS_TEMP a,
     MTL_SYSTEM_ITEMS_B b
Where a.eco_number= p_eco_number and
      a.organization_id = p_org_id and
      a.assembly_item_number = p_assy_num and 
      b.inventory_item_id = p_comp_id and
      b.organization_id = a.organization_id and
      b.segment1 = a.component_item_number and
      nvl(a.attribute5,'P') = 'P' and
      a.find_number != p_find_num and
      a.agile_sys_acd = 'C';      
      
/* Define a cursor to fetch the max item seq # for a bom/org in EBS */

Cursor get_ebs_org_seq (p_assembly_item_id IN number,p_organization_id IN number) is
Select max(bic.item_num)
From BOM_BILL_OF_MATERIALS BBM,                                                                                                     
     BOM_INVENTORY_COMPONENTS BIC                                                                                                   
Where bbm.assembly_item_id =  p_assembly_item_id and                                                                                
      bbm.organization_id = p_organization_id and   
      bbm.alternate_bom_designator is NULL and	     
      bic.bill_sequence_id = bbm.bill_sequence_id and                                                    
     (bic.disable_date is null or bic.disable_date > SYSDATE);      
     
/* Define a cursor to fetch the max item seq # for a bom in EBS */

Cursor get_ebs_bom_seq (p_assembly_item_id IN number,p_organization_id IN number) is
Select max(bic.item_num)
From BOM_BILL_OF_MATERIALS BBM,                                                                                                     
     BOM_INVENTORY_COMPONENTS BIC                                                                                                   
Where bbm.assembly_item_id =  p_assembly_item_id and                                                                                
      bbm.organization_id != p_organization_id and   
      bbm.alternate_bom_designator is NULL and	     
      bic.bill_sequence_id = bbm.bill_sequence_id and                                                     
     (bic.disable_date is null or bic.disable_date > SYSDATE);           

/* Define a cursor to fetch starting revision */

Cursor get_starting_rev (p_org_id in Number) is
Select starting_revision
From mtl_parameters
Where organization_id = p_org_id;                   

/* Define a Cursor to validate Organization Hierarchy Values */

Cursor valid_org_hier_value(p_value In Varchar2) is
Select a.name
From PER_ORGANIZATION_STRUCTURES a,
     PER_ORG_STRUCTURE_VERSIONS b
Where a.ORGANIZATION_STRUCTURE_ID = b.organization_structure_id and
     (b.date_to is NULL or b.date_to > SYSDATE)  and
     a.name = p_value;                           

/* Define a cursor to verify if error records exist for an ECO at Item-Master Level */

Cursor get_item_errors(p_eco_no In Varchar2,p_org_code In Varchar2) is
Select count(*) 
From ILINK_MTL_ITEMS_INT_TEMP
Where eco_number = p_eco_no and
      -- organization_code = p_org_code and
      record_status = 'Error';                                                                                

/* Define a cursor to verify if error records exist for an ECO at MPN Level */

Cursor get_mpn_errors(p_eco_no In Varchar2) is
Select count(*) 
From ILINK_MFG_PART_NUMBERS
Where eco_number = p_eco_no and
      record_status = 'Error';   
      
/* Define a cursor to fetch the ACD flags of reference designators */

Cursor get_refdes_status(p_eco_number In Varchar2,p_organization_id In Number,p_assembly_item_number In Varchar2,
		       	 p_assembly_item_revision In Varchar2,p_component_item_number In Varchar2) is
Select distinct nvl(agile_sys_acd,'U')
From ILINK_ECO_BOM_REFDES_TEMP
Where eco_number = p_eco_number and
      organization_id = p_organization_id and
      assembly_item_number = p_assembly_item_number and
      assembly_item_revision = p_assembly_item_revision and
      component_item_number = p_component_item_number
Order by nvl(agile_sys_acd,'U');


/* Define a cursor to retrive BOMs to be created in Parent Orgs by ECOs transferred from Agile */                                                       
                                                                                                                                    
Cursor get_master_bills is                                                                                                          
Select distinct msi.inventory_item_id,
       aei.organization_id,
       aet.eco_number
From ILINK_ECO_ITEM_REVISIONS_TEMP aei,
     MTL_PARAMETERS mpp,                                                                                                                                                                                                   
     ILINK_ECOS_TRANSFERED aet,                                                                                                     
     ILINK_MTL_SYSTEM_ITEMS_VIEW msi,
     ILINK_DATA_XREF idx                                                                                                           
Where idx.data_input1 = 'BOM Propagation Org' and
      mpp.organization_code = idx.data_output1 and 
      aet.organization_id = mpp.organization_id and
      aet.record_status = 'Validated' and                                                                                         
      aei.eco_number = aet.eco_number and         
      aei.organization_id = aet.organization_id and                                                                               
      msi.organization_id = aei.organization_id and                                                                                      
      msi.item_number = aei.item_number;          

/* Define a cursor to fetch all the child organizations where common BOMs will be created or exist*/                                     
                                                                                                                                    
Cursor get_child_orgs_for_bills (p_item_id IN Number,p_master_org_id In Number) is                                                                             
Select mpp.organization_id,
       msi.item_number,
       msi.inventory_item_id,
       mpp.organization_code
From MTL_PARAMETERS mpp,                                                                                                            
     ILINK_MTL_SYSTEM_ITEMS_VIEW msi,
     ILINK_DATA_XREF idx,
     ILINK_MTL_ITEMS_INT_TEMP itm                                                                                                         
Where idx.data_input1 = 'BOM Propagation Org' and
      idx.data_input2 = mpp.organization_code and
      msi.inventory_item_id = p_item_id and                                                                                       
      msi.organization_id = mpp.organization_id and   
      itm.organization_id = p_master_org_id and
      itm.item_number = msi.item_number and 
      itm.organization_code like '%'||mpp.organization_code||'%'
Union
Select mpp.organization_id,
       msi.item_number,
       bom.assembly_item_id,
       mpp.organization_code
From MTL_PARAMETERS mpp,                                                                                                            
     ILINK_MTL_SYSTEM_ITEMS_VIEW msi,
     ILINK_DATA_XREF idx,
     BOM_BILL_OF_MATERIALS bom                                                                                                         
Where idx.data_input1 = 'BOM Propagation Org' and
      idx.data_input2 = mpp.organization_code and
      msi.inventory_item_id = p_item_id and                                                                                       
      msi.organization_id = mpp.organization_id and   
      bom.assembly_item_id = msi.inventory_item_id and                                                                                       
      bom.organization_id = msi.organization_id;              

/* Define a cursor to create missing component items in child organizations prior to creating common BOMs */

Cursor get_missing_comp_items (p_assy_item In Varchar2, p_eco_number In Varchar2, p_child_org_id In Number, p_master_org_id In Number) is
Select distinct a.item_number,
	a.inventory_item_id,
	a.description
 From ILINK_MTL_SYSTEM_ITEMS_VIEW a,
      ILINK_ECO_ITEM_BOMS_TEMP e,
      ILINK_ECOS_TRANSFERED f
 Where a.organization_id = p_master_org_id and
       e.assembly_item_number = p_assy_item and
       e.eco_number = p_eco_number and
       a.item_number = e.component_item_number and
       a.organization_id = e.organization_id and
       e.eco_number = f.eco_number and
       e.organization_id = f.organization_id and
       not exists (Select 'x' From ILINK_MTL_SYSTEM_ITEMS_VIEW g
   		   Where a.item_number = g.item_number and
		         g.organization_id = p_child_org_id);
		         
/* Define a cursor to Validate Disposition Code */

Cursor get_disp_code(p_disp_type In Varchar2) is
Select lookup_code
From MFG_LOOKUPS
Where lookup_type = 'ECG_MATERIAL_DISPOSITION' and
      upper(meaning) = upper(p_disp_type);
      
      
/* Define a cursor to verify if operation sequence exists in Oracle */

Cursor get_op_seq (p_assy_item In Varchar2,p_org_id In Number,p_op_seq In Number) is
Select 'Y'
From BOM_OPERATIONAL_ROUTINGS a,
     BOM_OPERATION_SEQUENCES b,
     ILINK_MTL_SYSTEM_ITEMS_VIEW C
Where c.organization_id = p_org_id and
      a.assembly_item_id = c.inventory_item_id and
      c.item_number = p_assy_item and
      a.organization_id = c.organization_id and
      a.routing_sequence_id = b.routing_sequence_id and
      a.alternate_routing_designator is NULL and
      b.operation_seq_num = p_op_seq and
      (b.disable_date is NULL or b.disable_date > SYSDATE) and
      b.effectivity_date <= SYSDATE and				
      b.implementation_date is NOT NULL and 	
      b.implementation_date <= SYSDATE;
      
      
/* Define a cursor to verify fetch lowest operation sequence in Oracle */

Cursor get_low_op_seq (p_assy_item In Varchar2,p_org_id In Number) is
Select min(b.operation_seq_num)
From BOM_OPERATIONAL_ROUTINGS a,
     BOM_OPERATION_SEQUENCES b,
     ILINK_MTL_SYSTEM_ITEMS_VIEW C
Where c.organization_id = p_org_id and
      a.assembly_item_id = c.inventory_item_id and
      c.item_number = p_assy_item and
      a.organization_id = c.organization_id and
      a.routing_sequence_id = b.routing_sequence_id and
      a.alternate_routing_designator is NULL and
      (b.disable_date is NULL or b.disable_date > SYSDATE) and
      b.effectivity_date <= SYSDATE and				
      b.implementation_date is NOT NULL and 	
      b.implementation_date <= SYSDATE;      
      
      
/* Define a cursor to fetch flag to determine item seq num logic */

Cursor get_item_seq_flag(p_seg1 In Varchar2, p_seg4 In Varchar2) is
Select 'Y'
From ILINK_DATA_XREF
Where data_input1 = 'BOM Item Seq Inventory Category' and
      data_output1 = p_seg1 and
      data_output2 = p_seg4;
      


v_item_id               Number;                                                                                                     
v_user_id               Number;                                                                                                     
v_reason_code           Varchar2(15);                                                                                               
v_record_status         Varchar2(1);                                                                                                
v_eco_number            Varchar2(10);                                                                                               
v_item_bom_count        Number;                                                                                                     
v_component_id          Number;                                                                                                     
v_error_text_item       Varchar2(4000);            
v_warning_text_item     Varchar2(4000);            
v_error_text_comp       Varchar2(4000);            
v_error_text_eco        Varchar2(4000);      
v_error_str		Varchar2(100);		   
v_warning_text          Varchar2(2000);   
v_latest_rev_oracle     Varchar2(30);                                                                                               
v_latest_effdate        Date;                                                                                                       
v_effectivity_date      Date;                                                                                                       
v_revision              Varchar2(30);                                                                                               
v_comp_eff_date         Date;                                                                                                       
v_oper_seq_num          Number;                                                                                                     
v_sys_acd               Varchar2(1);                                                                                                
v_parent_rev            Varchar2(3);                                                                                                
v_parent_sch_date       Date;                                                                                                       
v_text_log              Varchar2(30);                                                                                               
v_bom_exists		Varchar2(1);    
v_ou_value		Varchar2(100);

v_par_sys_acd		Varchar2(1);
v_sub_exists		Varchar2(1);        

v_error_eco		Varchar2(20);    
v_start_rev		Varchar2(3);   
v_agile_rev		Varchar2(30);     
v_attribute1		Varchar2(100);  

v_comp_find_num		Number;     
v_comp_qty		Number;   
v_dup_comp_number       Varchar2(50);                   
v_ebs_item_seq		Number;
v_disable_comp		Varchar2(50);
v_item_seq_num		Number;


V_item_err_count	Number;
v_mpn_err_count		Number;
v_eco_type		Varchar2(80);
v_originator		Varchar2(240);
v_refdes_status		Varchar2(10);

call_status_itm     	Boolean;
rphase_itm          	Varchar2(30);
rstatus_itm         	Varchar2(30);
message_itm         	Varchar2(240);
dphase_itm          	Varchar2(30);
dstatus_itm         	Varchar2(30);
v_ret_itm           	Number;
v_item_count		Number;
v_disp_code		Number;
v_op_exists		Varchar2(1);
v_op_seq		Number;
v_item_seq_flag		Varchar2(1);
v_ora_comp_id		Number;		-- Added on 11/11/2014
v_comp_exists		Varchar2(1);	-- Added on 11/11/2014

begin                                                                                                                               


	/* Determine if BOM exists for an assembly */                                                                                      

	   For c_bom_exists in get_assy_number Loop                                                                                        
	    v_bom_exists := NULL;                                                                                                       
	    open get_bom_exists(c_bom_exists.item_number,c_bom_exists.organization_id);                                                    
	    fetch get_bom_exists into v_bom_exists;                                                                                        
	    close get_bom_exists;                                                                                                          
	    If nvl(v_bom_exists,'N') = 'Y' then -- BOM exists so delete U(nchanged)s from component table                                  
	     Delete From ILINK_ECO_ITEM_BOMS_TEMP                                                                                          
	     Where assembly_item_number = c_bom_exists.item_number and                                                                     
		   organization_id = c_bom_exists.organization_id and                                                                             
		   eco_number = c_bom_exists.eco_number and                                                                                       
		   agile_sys_acd = 'U';                                                                                                  
	    Else 		-- BOM does not exists so delete C(hange)s, A(ddition)s and D(isable)s                             
	     Delete From ILINK_ECO_ITEM_BOMS_TEMP                                                                                          
	     Where assembly_item_number = c_bom_exists.item_number and                                                                     
		   organization_id = c_bom_exists.organization_id and                                                                             
		   eco_number = c_bom_exists.eco_number and                                                                                       
		   agile_sys_acd != 'U';
	     Update ILINK_ECO_ITEM_BOMS_TEMP
	     Set agile_sys_acd = 'A' 
	     Where assembly_item_number = c_bom_exists.item_number and
		   organization_id = c_bom_exists.organization_id and
		   eco_number = c_bom_exists.eco_number and
		   agile_sys_acd = 'U';                                                                                                        
	    End If;                                                                                                                             
	   End Loop;                                                                                                                       

	Commit;           


	/* Begin Processing ECO Headers */                                                                                          

	 For c_eco_header in get_eco_header Loop                                                                                    

		v_record_status := NULL;                                                                                            
		v_error_text_eco:= NULL;                                                                                            
		v_eco_number    := NULL;  
		v_warning_text	:= NULL;
		
		/* Validate ECO Type Value */                                                                        
				
		 Open get_eco_type(c_eco_header.change_type);                                                     
		 Fetch get_eco_type into v_eco_type;                                                                             
		  If get_eco_type%NOTFOUND Then                                                                                        
		   v_record_status := 'E';                                                                                     
		   Select decode(v_error_text_eco,NULL,'Error: ',v_error_text_eco||' , ')||'ECO Type Does not exists in ORACLE'
		   into v_error_text_eco From DUAL;                  
		  End If;                                                                                                             
		 Close get_eco_type;  

		/* Validate Reason Code */                                                                                          

		If c_eco_header.reason_code is NOT NULL Then                                                            
		 Open get_reason_code(c_eco_header.reason_code);                                                         
		 Fetch get_reason_code into v_reason_code;                                                                           
		 If get_reason_code%NOTFOUND Then                                                                                    
		  v_reason_code := NULL;                                                                                      
		  v_record_status := 'W';                                                                                     
		  Select decode(v_warning_text,NULL,'WARNING: ',v_warning_text||' , ')||' Reason Code '||c_eco_header.reason_code||' does not exist in Oracle '
		  into v_warning_text from dual;
		 End If;                                                                                                             
		 close get_reason_code;                                                                                              
		End If;     
		
		/* Validate Originator 
		
		If c_eco_header.originator is NOT NULL Then
		 open get_originator(c_eco_header.originator);
		 fetch get_originator into v_originator;
		 If get_originator%NOTFOUND Then                                                                                    
		  v_originator := NULL;                                                                                      
		  v_record_status := 'W';                                                                                     
		  Select decode(v_warning_text,NULL,'WARNING: ',v_warning_text||' , ')||' Originator '||c_eco_header.originator||' does not exist in Oracle '
		  into v_warning_text from dual;
		 End If;                                                                                                             
		 close get_originator;                                                                                              
		End If;     */

		/* Verify If any Item-Master or MPN Errors exist for this ECo */ 

		v_item_err_count := 0;
		Open get_item_errors(c_eco_header.eco_number,c_eco_header.organization_code);
		Fetch get_item_errors into v_item_err_count;
		Close get_item_errors;
		If nvl(v_item_err_count,0) != 0 Then
		 v_record_status := 'E';                                                                                     
		 Select decode(v_error_text_eco,NULL,'Error: ',v_error_text_eco||' , ')||' Item-Master Level errors exist for this ECO'
		 into v_error_text_eco From DUAL;  
		End if;	


		If c_eco_header.organization_id = p_master_org_id Then                                                                       
		v_mpn_err_count := 0;
		Open get_mpn_errors(c_eco_header.eco_number);
		Fetch get_mpn_errors into v_mpn_err_count;
		Close get_mpn_errors;
		If nvl(v_mpn_err_count,0) != 0 Then
		 v_record_status := 'E';                                                                                     
		 Select decode(v_error_text_eco,NULL,'Error: ',v_error_text_eco||' , ')||' ASL Level errors exist for this ECO'
		 into v_error_text_eco From DUAL;  
		End If;	             
		End If;                                                          

		/* Verify If ECO Already Exists in ORACLE */                                                                        

		Open get_eco_oracle(c_eco_header.eco_number,c_eco_header.organization_id);                                                     
		Fetch get_eco_oracle into v_eco_number;                                                                             
		If get_eco_oracle%FOUND Then                                                                                        
			v_record_status := 'E';                                                                                     
			Select decode(v_error_text_eco,NULL,'Error: ',v_error_text_eco||' , ')||'ECO number already exists in ORACLE'
			into v_error_text_eco From DUAL;                  
		End If;                                                                                                             
		Close get_eco_oracle;                                                       

		/* If all the validations succeeded then mark the Header record as "Validated" */                                   

		If nvl(v_record_status,'S') in ('S','W') Then                                                                       
			update ILINK_ECOS_TRANSFERED                                                                                
			set record_status = 'Validated',                                                                            
			    reason_code = v_reason_code,                                                                            
			    error_message = v_error_text_eco,                                                                       
			    -- originator = v_originator,
			    warning_message = v_warning_text
			Where eco_number = c_eco_header.eco_number and
			      organization_id = c_eco_header.organization_id;                                                   

		/* If any of the validations failed then mark the record as "Error" */                                              

		Elsif nvl(v_record_status,'S') = 'E' Then                                                                           
			update ILINK_ECOS_TRANSFERED                                                                                
			set record_status = 'Error',                                                                                
			    process_flag = 'Y',  
			    processed_date = SYSDATE,                                                                                   
			    error_message = v_error_text_eco,
			    warning_message = v_warning_text                                                                      
			Where eco_number = c_eco_header.eco_number and
			      organization_id = c_eco_header.organization_id;                                                    
		End If;                                                                                                             



	 /*  Begin Processing Assembly (Revised) Items  */                                                                          


		FOR c_new_item in get_eco_item(c_eco_header.eco_number,c_eco_header.organization_id) Loop                                                                                

		v_record_status := NULL;                                                                                            
		v_error_text_item := NULL;                                                                                          
		v_warning_text_item := NULL;                                                                                        
		v_item_id := NULL;                                                                                                  
		v_revision := NULL;                                                                                                 
		v_effectivity_date := NULL;      
		v_ebs_item_seq := NULL;
		v_item_seq_num := NULL;


		      /*  Verify if Item exists in Oracle  */                                                                        

			Open get_oracle_item(c_new_item.item_number,c_new_item.organization_id);                                    
			Fetch get_oracle_item into v_item_id;                                                                       
			IF get_oracle_item%NOTFOUND Then                                                                            
			  v_record_status := 'E';                                                                                     
			  v_error_text_item := 'Item Does not exist in Oracle';                                                       
			Elsif get_oracle_item%FOUND Then                                                               

			   /* Validate New Revision */        

				/* Determine starting revision for org */

				v_start_rev := NULL;
				Open get_starting_rev(c_new_item.organization_id);
				Fetch get_starting_rev into v_start_rev;
				Close get_starting_rev;                                                                                                                 


			     Open get_latest_rev_oracle(v_item_id,c_new_item.organization_id);                                      
			     Fetch get_latest_rev_oracle into v_latest_rev_oracle,v_latest_effdate,v_agile_rev;                                 
			     If get_latest_rev_oracle%FOUND Then                                                                    


				/* Check to see if Assembly Item exists on ane Errored ECOs */

				Open get_error_eco(c_new_item.item_number,c_new_item.eco_number);
				Fetch get_error_eco into v_error_eco;
				If get_error_eco%FOUND and (v_latest_rev_oracle = v_start_rev) Then  -- This assembly exists on ECOs that have been errored
				  v_record_status := 'E';
				  v_error_text_item := ' This Assembly item exists on previously errored ECO(s)';
				Elsif get_error_eco%NOTFOUND OR (get_error_eco%FOUND and (v_latest_rev_oracle != v_start_rev)) Then   


				/* Verify if Old revision in Agile matches the current revision in Oracle */                        
				/* Added an additional clause to ignore the initial old revision */                                               

				If (v_latest_rev_oracle != v_start_rev) and                                                                 
					(v_agile_rev != nvl(c_new_item.old_revision,v_agile_rev)) and                                            
					(c_new_item.new_revision != v_latest_rev_oracle)  -- Then                                                 
					and nvl(ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF('Agile Old Rev Check',NULL,NULL,NULL,NULL),'No') = 'Yes' Then -- Added on 06/27/2014
				   v_record_status := 'E';                                                                          
				   v_error_text_item := ' The old Revision from AGILE '||c_new_item.old_revision||
				   				' does not match the current Oracle revision '||v_latest_rev_oracle; 

				/* Error out if New revision in Agile is older (lesser) than the current revision in Oracle */      

				Elsif v_latest_rev_oracle > c_new_item.new_revision  Then                                           
				 v_record_status := 'E';                                                                            
				 v_error_text_item :=' Current Revision in Oracle '||v_latest_rev_oracle||
				 				' is newer than AGILE revision '||c_new_item.new_revision;                  

				/* If New revision in Agile matches the current revision in Oracle then verify that there is BOM data*/                                                                                                                                 


				Elsif v_latest_rev_oracle = c_new_item.new_revision then                                            
				 -- Find If this item is being sent as part of BOMs (PS Data)                                       
				 v_item_bom_count := 0;                                                                             
				 Open get_bom_data(c_new_item.eco_number,c_new_item.item_number,c_new_item.organization_id);                                   
				 Fetch get_bom_data into v_item_bom_count;                                                          
				 Close get_bom_data;                                                                                
				 If v_item_bom_count = 0 Then                                                                       
				  v_record_status := 'W';                                                                           
				  -- v_warning_text_item := ' The AGILE Revision matches the Latest Oracle revision and the item has no BOM data so an irrelevant ECO is created in Oracle ';                                                                              

				 End If; 	-- (v_latest_rev_oracle != v_start_rev)

				 v_revision := c_new_item.new_revision;                                                             

				/* Continue processing if New revision in Agile is newer (greater) than the current revision in Oracle */                                                                                                                               


				Elsif v_latest_rev_oracle < c_new_item.new_revision Then                                            
				 v_record_status := 'S';                                                                            
				 v_revision := c_new_item.new_revision;                                                             
				End If;  	-- get_error_eco%FOUND                                                                                            

				/* Validate New Effectivity Date */                                                                 

				If nvl(v_record_status,'S') != 'E' Then                                                             

				 /* Mark Effective date as current day (sysdate) if Effective data in Agile is older(less) than current day */                                                                                                                                                                                                                                                             

				If c_new_item.effective_date_from <= SYSDATE Then                                                    
				 v_record_status := 'S';                                                                            
				 --v_effectivity_date := SYSDATE;                                                                     
				 -- Select SYSDATE+0.00138 into v_effectivity_date from Dual;
				 Select SYSDATE+ nvl(to_number(ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF('ECO Effectivity Add Days',NULL,NULL,NULL,NULL)),0.00138)
				 into v_effectivity_date from Dual;

				 /* Continue processing if Effective date in Agile is newer (greater) than that of current revision in Oracle */                                                                                                                        

				Elsif c_new_item.effective_date_from > SYSDATE Then                                                
				 v_record_status := 'S';                                                                            
				 v_effectivity_date := c_new_item.effective_date_from;                                              
				End if;                                                                                             

				/* Error out if Effective date in Agile is older (lesser) than that of current revision in Oracle */

				if v_latest_effdate > v_effectivity_date then                                                       
				 v_record_status := 'E';                                                                            
				 v_error_text_item := v_error_text_item||' Current Revision in Oracle has a higher Effectvity date than AGILE new revision ';                                                                                                            

				End If;         

				End If;                

				End IF;
				Close get_error_eco;                                                                                          

			     End If;                                                                                                
			     Close get_latest_rev_oracle;                                                            

			End If;                                                                                                     
			Close get_oracle_item;                     
			
			/* Determine the item seq num logic flag */
			
			v_item_seq_flag	:= NULL;						
			open get_item_seq_flag(nvl(c_new_item.attribute3,'NA'),nvl(c_new_item.attribute4,'NA'));
			fetch get_item_seq_flag into v_item_seq_flag;
			close get_item_seq_flag;
			
			If nvl(v_item_seq_flag,'N') = 'N' Then	-- Derive Item Seq Number
			  
			   -- Fetch max item seq for this item/org in EBS
			   
			   open get_ebs_org_seq (v_item_id,c_new_item.organization_id);
			   fetch get_ebs_org_seq into v_ebs_item_seq;
			   If get_ebs_org_seq%NOTFOUND Then
			    open get_ebs_bom_seq (v_item_id,c_new_item.organization_id);
			    fetch get_ebs_bom_seq into v_ebs_item_seq;
			    close get_ebs_bom_seq;
			   End If;
			   close get_ebs_org_seq;			
			   
			End If;

			If v_error_text_item is NOT NULL Then                                                                       
			 v_error_text_item := 'Error : '||v_error_text_item;                                                        
			End If;                                                                                                                                                                                                          

			/* Attach any warning messages at the end of error message */                                               

			If v_warning_text_item is NOT NULL Then                                                                     
			 v_error_text_item := v_error_text_item||' WARNING :'||v_warning_text_item;                                 
			 v_warning_text_item := 'WARNING :'||v_warning_text_item;                                                   
			End If;                                                                                                 

			 /* If all the validations succeeded then mark the record as "Validated" */                                 

			If nvl(v_record_status,'S') in ('S','W') Then                                                               

			update ILINK_ECO_ITEM_REVISIONS_TEMP                                                                        
			set record_status = 'Validated',                                                                            
			    inventory_item_id = v_item_id,                                                                          
			    new_revision = v_revision,                                                                              
			    eco_number = c_new_item.eco_number,                                                                     
			    item_number = c_new_item.item_number,                                                                   
			    effective_date_from = nvl(v_effectivity_date,SYSDATE),                                                               
			    error_message = v_warning_text_item,
			    disposition_code = v_disp_code
			Where eco_number = c_new_item.eco_number and                                                  
			      organization_id = c_new_item.organization_id and
			      item_number = c_new_item.item_number and                                                
			      nvl(new_revision,'!') = nvl(c_new_item.new_revision,'!');                                               

			/* If any of the validations failed then mark the Assembly item record and ECO header records as "Error" */ 

			Elsif nvl(v_record_status,'S') = 'E' Then      
			
			 v_error_str := NULL;	
			 Select Decode(instr(nvl(v_error_text_eco,'ERROR'),'Check Assembly Item(s):'),0,'Check Assembly Item(s): ')
			 Into v_error_str From Dual;
			 
			v_error_text_eco := substr(v_error_text_eco||' '||v_error_str||c_new_item.item_number,1,4000);	-- Modified on 02/18/09

			Update ILINK_ECO_ITEM_REVISIONS_TEMP                                                                        
			Set record_status = 'Error',                                                                                
			    error_message =  v_error_text_item                                                                      
			Where eco_number = c_new_item.eco_number and                                                  
			      organization_id = c_new_item.organization_id and
			      item_number = c_new_item.item_number and                                                
			      nvl(new_revision,'!') = nvl(c_new_item.new_revision,'!');                                                 

			Update ILINK_ECOS_TRANSFERED                                                                                
			Set record_status = 'Error',                                                                                
			    process_flag = 'Y',       
			    processed_date = SYSDATE,                                                                                
			    error_message = v_error_text_eco
			Where eco_number = c_new_item.eco_number and
			      organization_id = c_new_item.organization_id;                                                     

			End If;
			
			

		/*  Begin Processing BOM Components and Substitutes */                                                                             

		FOR c_new_component in get_bom_component(c_eco_header.eco_number,c_eco_header.organization_id,c_new_item.item_number) Loop                                                                       

			v_error_text_comp := NULL;                                                                                  
			v_record_status := NULL;                                                                                    
			v_component_id := NULL;                                                                                     
			v_item_id := NULL;                                                                                          
			v_oper_seq_num := NULL;                                                                                     
			v_sys_acd := NULL;                                                                                          
			v_comp_eff_date := NULL;
			v_comp_find_num := NULL;
			v_comp_qty	:= NULL;  

			/* Fetch the value for Assembly Item ID */                                                                  

			 Open get_oracle_item(c_new_component.assembly_item_number,c_new_component.organization_id);                
			 Fetch get_oracle_item into v_item_id;                                                                      
			 Close get_oracle_item;                      

			  /* Get Assembly Item Revision to update component temp table (and further to be loaded into components interface table) */                                                                                                                      

			 Open get_assembly_details (c_new_component.eco_number,c_new_component.assembly_item_number,c_new_component.organization_id);               
			 Fetch get_assembly_details into v_parent_rev,v_parent_sch_date;                                            
			 Close get_assembly_details;                      
			 
			 /* Validate Quantity */
			 			 
			/* If nvl(c_new_component.quantity,0) < 0 Then
			   v_record_status := 'E';                                                                                 
			   Select decode(v_error_text_comp,NULL,'',v_error_text_comp||' , ')||'The Quantity Should be Equal to Or Greater than Zero' 
			   Into v_error_text_comp From DUAL;
			 End If;	*/
			 			 

			 /* Validate Component Yield 

			 If nvl(c_new_component.component_yield,1) = 0 or nvl(c_new_component.component_yield,0) > 1 Then
			  v_record_status := 'E';                                                                                 
			  Select decode(v_error_text_comp,NULL,'',v_error_text_comp||' , ')||'The Component Yield Value should be between 0 and 1' 
			  Into v_error_text_comp From DUAL;
			 End If;		 	*/

			/* Verify if component Item exists in Oracle */                                                             

			Open get_oracle_item(c_new_component.component_item_number,c_new_component.organization_id);  
			Fetch get_oracle_item into v_component_id;                                                                  
			If get_oracle_item%NOTFOUND Then                                                                            
			 v_record_status :='E';                                                                                     
			 Select decode(v_error_text_comp,NULL,'',v_error_text_comp||' , ')||' Component '||c_new_component.component_item_number||' does not exists in Oracle'
			 Into v_error_text_comp From DUAL;
			Elsif get_oracle_item%FOUND Then

			
			If nvl(c_new_component.sub_flag,'P') = 'P' Then 						                                                                               		

			 /* validate Transaction Types (Add,Delete,Change) for Components */                                                        

			 Open get_comp_exists_bom(v_item_id,c_new_component.organization_id,v_component_id);                  
			 Fetch get_comp_exists_bom into v_oper_seq_num,v_comp_eff_date,v_comp_find_num,v_comp_qty;                                             
			 Close get_comp_exists_bom;                                                                                 

			/* Begin validation For ACD Type "A" (additions) for Components */                                                         

			 If c_new_component.agile_sys_acd = 'A' Then               
			 
			  If nvl(v_item_seq_flag,'N') = 'Y' Then		-- Special Item Seq Logic
			 
			   /* Check for duplicate item seq num in iLink tables */			
			
			   Open check_dup_primary(c_new_component.eco_number,c_new_component.organization_id,c_new_component.find_number,
						 c_new_component.assembly_item_number,c_new_component.component_item_number);
			   Fetch check_dup_primary into v_dup_comp_number;
			   If check_dup_primary%FOUND Then 
			    v_record_status := 'E';                                                                                 
			    v_error_text_comp := ' This item seq number '||c_new_component.find_number||' has multiple components';
			   Else
			   
			   /* Check for duplicate item seq num in Oracle */	-- Modified the logic on 11/11/2014
			   
			   v_ora_comp_id := NULL;		-- Added on 11/11/2014
			   open check_ebs_item_seq (v_item_id,c_new_component.organization_id,c_new_component.find_number);
			   fetch check_ebs_item_seq into v_ebs_item_seq,v_ora_comp_id;	-- Added v_ora_comp_id on 11/11/2014
			   If check_ebs_item_seq%FOUND Then	-- Check if that item seq is being disabled
			    
			    v_disable_comp := NULL;	-- Added on 11/11/2014
			    open check_disable_comp(c_new_component.eco_number,c_new_component.organization_id,c_new_component.find_number,
						     c_new_component.assembly_item_number);
			    fetch check_disable_comp into v_disable_comp;
			    close check_disable_comp;
			    
			     -- Added the below on 11/11/2014
			     v_comp_exists := NULL;
			     open check_comp_change(c_new_component.eco_number,c_new_component.organization_id,c_new_component.find_number,
						     c_new_component.assembly_item_number,v_ora_comp_id);
			     fetch check_comp_change into v_comp_exists;
			     close check_comp_change;	-- End 11/11/2014
			     
			     If v_disable_comp is NULL and nvl(v_comp_exists,'N') = 'N' Then			     
			      v_record_status := 'E';                                                                                 
			      v_error_text_comp := ' This item seq number '||c_new_component.find_number||' already exists in the BOM in Oracle';			     
			     End If;			-- End 11/11/2014	
			     
			   End If; 
			   close check_ebs_item_seq;
			   
			   End If;
			   close check_dup_primary;			  
			  
			  Elsif nvl(v_item_seq_flag,'N') = 'N' Then	-- Derive Item Seq Number
			  
			   If nvl(v_item_seq_num,0) = 0 Then
			    v_item_seq_num := nvl(v_ebs_item_seq,0) + 10;
			   Else 
			    v_item_seq_num := nvl(v_item_seq_num,0) + 10;
			   End If;
			   
			  End If;
			   

			   /* Error out if the component already exists in the BOM of Assembly Item */                              

			   If v_oper_seq_num is NOT NULL Then                                                                       
			    v_sys_acd := 'A';                                                                                                            
			    v_record_status := 'E';                                                                                 
			    Select decode(v_error_text_comp,NULL,'',v_error_text_comp||' , ')||' This component already exists in the BOM of Assembly item'
			    Into v_error_text_comp From DUAL;

			  /* continue if the component does not exist in the BOM of Assembly Item */                                

			   Elsif v_oper_seq_num is NULL and nvl(v_record_status,'NA') != 'E' Then                                                                        
			    v_sys_acd := 'A';                                                                                       
			    --v_oper_seq_num := 1;                                                                                    
			    -- v_record_status := 'S';                                                                                 
			    
				/* Fetch Lowest Operation Sequence */ -- Added for Haemonetics 

				 v_op_seq := NULL;						 
				 open get_low_op_seq(c_new_component.assembly_item_number,c_new_component.organization_id);
				 fetch get_low_op_seq into v_op_seq;
				 If get_low_op_seq%NOTFOUND Then
				  v_oper_seq_num := 1;
				 Else
				  v_oper_seq_num := nvl(v_op_seq,1);
				 End If;
				 close get_low_op_seq;		-- Haemonetics 	
			
			   End If; -- v_oper_seq_num is NOT NULL                                                                                                 

			/* Begin validation For ACD Type "C" (Changes) for Components */                                                           

			 Elsif c_new_component.agile_sys_acd = 'C' Then      
			 
			  If nvl(v_item_seq_flag,'N') = 'Y' Then	-- Modified the logic on 11/11/2014
			 
			   /* Check for duplicate item seq num in iLink tables */			
			
			   Open check_dup_primary(c_new_component.eco_number,c_new_component.organization_id,c_new_component.find_number,
						 c_new_component.assembly_item_number,c_new_component.component_item_number);
			   Fetch check_dup_primary into v_dup_comp_number;
			   If check_dup_primary%FOUND Then 
			    v_record_status := 'E';                                                                                 
			    v_error_text_comp := ' This item seq number '||c_new_component.find_number||' has multiple components';
			   Else
			   
			   /* Check for duplicate item seq num in Oracle */
			   
			   -- open check_ebs_item_seq (v_item_id,c_new_component.organization_id,c_new_component.find_number);	-- Commented out on 10/29/2014
			   v_ora_comp_id := NULL;		-- Added on 11/11/2014
			   open check_ebs_item_seq1 (v_item_id,c_new_component.organization_id,c_new_component.find_number,v_component_id);	-- Replaced check_ebs_item_seq with check_ebs_item_seq1 and added the v_component_id parameter on 10/29/2014
			   fetch check_ebs_item_seq1 into v_ebs_item_seq,v_ora_comp_id;		-- Added v_ora_comp_id on 11/11/2014 		-- Replaced check_ebs_item_seq with check_ebs_item_seq1 on 10/29/2014
			   If check_ebs_item_seq1%FOUND Then	-- Check if that item seq is being disabled	-- Replaced check_ebs_item_seq with check_ebs_item_seq1 on 10/29/2014
			    
			    v_disable_comp := NULL;	-- Added on 11/11/2014
			    open check_disable_comp(c_new_component.eco_number,c_new_component.organization_id,c_new_component.find_number,
						     c_new_component.assembly_item_number);
			    fetch check_disable_comp into v_disable_comp;
			    close check_disable_comp;
			    
			    -- Added the below on 11/11/2014
			    open check_comp_change(c_new_component.eco_number,c_new_component.organization_id,c_new_component.find_number,
			     						     c_new_component.assembly_item_number,v_ora_comp_id);
			    fetch check_comp_change into v_comp_exists;
			    close check_comp_change;	-- End 11/11/2014
			     
			    If v_disable_comp is NULL and nvl(v_comp_exists,'N') = 'N' Then
			     v_record_status := 'E';                                                                                 
			     v_error_text_comp := ' This item seq number '||c_new_component.find_number||' already exists in the BOM in Oracle';
			    End If;			-- Added on 11/11/2014
			    
			   End If;
			    
			   close check_ebs_item_seq1;								-- Replaced check_ebs_item_seq with check_ebs_item_seq1 on 10/29/2014
			   
			   End If;
			   close check_dup_primary;
			   
			  End If;			 

			  /* Error out if the component does not exist in the BOM of Assembly Item */                               

			  If v_oper_seq_num is NULL Then                                                                            
			   v_sys_acd := 'C';                                                                                                             
			   v_record_status := 'E';                                                                                  
			   Select decode(v_error_text_comp,NULL,'',v_error_text_comp||' , ')||' This component does not exist in the BOM of Assembly item'                       
			   Into v_error_text_comp From DUAL;
			   
			  /* Continue if the component exists in the BOM of Assembly Item */                                        

			  Elsif v_oper_seq_num is NOT NULL Then                                                                     
			   v_sys_acd := 'C';                                                                                        
			   -- v_record_status := 'S';         

			  End If; -- v_oper_seq_num is NULL          
			  			  
			/* Validate Operation Sequence */ -- Added for Haemonetics 
			
			v_op_exists := NULL;
			If nvl(v_oper_seq_num,1) = 1 Then
			 v_op_exists := 'Y';
			Elsif nvl(v_oper_seq_num,1) != 1 Then			 
			 open get_op_seq(c_new_component.assembly_item_number,c_new_component.organization_id,v_oper_seq_num);
			 fetch get_op_seq into v_op_exists;
			 close get_op_seq;
			End If;
			If nvl(v_op_exists,'N') = 'N' Then
			 v_record_status :='E';
			 v_error_text_comp := ' Component '||c_new_component.component_item_number||' has an invalid Operation Seq Number'; 
			End If;		-- Haemonetics 			  

			/* Begin validation For ACD Type "D" (Disables) for Components */                                                          

			 Elsif c_new_component.agile_sys_acd = 'D' Then   

			  v_sys_acd := 'D';                                                            

			  /* Error out if the component does not exist in the BOM of Assembly Item */                               

			  If v_oper_seq_num is NULL Then                                                              

			   v_record_status := 'E';                                                                                  
			   Select decode(v_error_text_comp,NULL,'',v_error_text_comp||' , ')||' This component does not exist in the BOM of Assembly item'                       
			   Into v_error_text_comp From DUAL;
			   
			  /* Continue if the component exists in the BOM of Assembly Item */                                        

			  Elsif v_oper_seq_num is NOT NULL Then                                                                     
			   v_sys_acd := 'D';                                                                                        
			   -- v_record_status := 'S';                               
			  End If;  -- v_oper_seq_num is NULL
			  
			  
			/* Validate Operation Sequence */ -- Added for Haemonetics 
			
			v_op_exists := NULL;
			If nvl(v_oper_seq_num,1) = 1 Then
			 v_op_exists := 'Y';
			Elsif nvl(v_oper_seq_num,1) != 1 Then			 
			 open get_op_seq(c_new_component.assembly_item_number,c_new_component.organization_id,v_oper_seq_num);
			 fetch get_op_seq into v_op_exists;
			 close get_op_seq;
			End If;
			If nvl(v_op_exists,'N') = 'N' Then
			 v_record_status :='E';
			 v_error_text_comp := ' Component '||c_new_component.component_item_number||' has an invalid Operation Seq Number'; 
			End If;		-- Haemonetics 					  

			 End If;  -- c_new_component.agile_sys_acd = 'A'

			
			/* validate Transaction Types (Add and Delete) for Substitutes */  

			Elsif nvl(c_new_component.sub_flag,'P') = 'A' Then 

			 If c_new_component.parent_comp_number is NULL Then
			  v_record_status := 'E';                                                                                  
			  v_error_text_comp := ' This Substitute does not have a parent component assocaited with it'; 
			 Else                        

			 v_par_sys_acd := NULL;                                                                                                           
			 Open get_par_comp_details(c_new_component.eco_number,c_new_component.assembly_item_number,
						   c_new_component.assembly_item_revision,c_new_component.parent_comp_number,
						   c_new_component.organization_id);
			 Fetch get_par_comp_details into v_oper_seq_num,v_par_sys_acd;
			 Close get_par_comp_details;  

			 v_sub_exists := NULL;
			 Open check_sub_exists(v_item_id,c_new_component.organization_id,v_component_id,c_new_component.parent_comp_number);
			 Fetch check_sub_exists into v_sub_exists;
			 Close check_sub_exists;                                                                                    

			/* Begin validation For ACD Type "A" (additions) for Substitutes */                                                         

			 If c_new_component.agile_sys_acd = 'A' and v_par_sys_acd = 'A' Then  

			    v_oper_seq_num := 1; 
			    v_sys_acd := 'A';                                                                                    
			    v_record_status := 'S'; 

			 Elsif c_new_component.agile_sys_acd = 'A' and v_par_sys_acd = 'C' Then                                                                      

			   /* Delete if the Substitute already exists for the component in the BOM */                          

			   If nvl(v_sub_exists,'N') = 'Y' then                                                                       
			    v_sys_acd := 'X';                                                                                                            
			    v_record_status := 'S'; 

			  /* continue if the Substitute does not exists for the component in the BOM */                                

			   Elsif nvl(v_sub_exists,'N') = 'N' Then    

			    v_sys_acd := 'A';                                                                                      
			    v_record_status := 'S';                                                                                 
			   End If;                                                                                                  

			/* Begin validation For ACD Type "D" (Disables) for Substitutes */                                                          

			 Elsif c_new_component.agile_sys_acd = 'D' and v_par_sys_acd = 'A' Then     

			  /* Delete if trying to disable a Substitute for a NEW component in the BOM */

			  v_sys_acd := 'X';
			  v_record_status := 'S'; 

			 Elsif c_new_component.agile_sys_acd = 'D' and v_par_sys_acd = 'C' Then                                                                 

			  /* Error out if the Substitute does not exist for the component in the BOM */                               

			  If nvl(v_sub_exists,'N') = 'N' then  

			   v_sys_acd := 'D';                                                                                                        
			   v_record_status := 'E';                                                                                  
			   v_error_text_comp := ' This Substitute does not exist for the component '||c_new_component.parent_comp_number||' in the BOM';                       

			  /* Continue if the component exists in the BOM of Assembly Item */                                        

			  Elsif nvl(v_sub_exists,'N') = 'Y' Then 

			   v_sys_acd := 'D';                                                                                        
			   v_record_status := 'S';                                                                                  
			  End If;  

			 End If;  -- c_new_component.agile_sys_acd = 'A' and v_par_sys_acd = 'A' Then  
			End If;   -- If c_new_component.parent_comp_number is NULL 
			End If;   -- nvl(c_new_component.sub_flag,'P') = 'P'


			End If;                                                                                                     
			close get_oracle_item;                                                                                      		


			/* If all the validations succeeded then mark the record as "Validated" */                                  

			If nvl(v_record_status,'S') in ('S','W') Then                                                     

			Update ILINK_ECO_ITEM_BOMS_TEMP                                                                             
			Set record_status = 'Validated',                                                                            
			    eco_number = c_new_component.eco_number,                                                                
			    assembly_item_number = c_new_component.assembly_item_number,                                            
			    component_item_number = c_new_component.component_item_number,                                          
			    effective_date_from = v_comp_eff_date,                                                                  
			    effective_date_to = v_parent_sch_date,                                                                  
			    operation_seq_num = v_oper_seq_num,                                                                     
			    assembly_item_revision = v_parent_rev,                                                                  
			    agile_sys_acd = v_sys_acd,
			    find_number = nvl(v_item_seq_num,find_number)
			Where eco_number = c_new_component.eco_number and                                             
			      organization_id = c_new_component.organization_id and
			      assembly_item_number = c_new_component.assembly_item_number and                         
			      component_item_number = c_new_component.component_item_number and                       
			      nvl(parent_comp_number,'NA') = nvl(c_new_component.parent_comp_number,'NA') and 
			      agile_sys_acd = c_new_component.agile_sys_acd and
			      nvl(attribute5,'P') = nvl(c_new_component.sub_flag,'P');  
			      
			/* Update dates for BOM reference Designators 	-- Commented out on 02/21/2014
			
			 Update ILINK_ECO_BOM_REFDES_TEMP
			 Set effective_date_from = v_parent_sch_date,
			     operation_seq_num = v_oper_seq_num
			 Where eco_number = c_new_component.eco_number and  
			       organization_id = c_new_component.organization_id and                                                                     
			       assembly_item_number = c_new_component.assembly_item_number and 
			       assembly_item_revision = c_new_component.assembly_item_revision and                                                     
			       component_item_number = c_new_component.component_item_number; 		*/

			/* Process Reference Designators for the component -- Commented out on 02/21/2014	
		
		       v_refdes_status := NULL;
		       open get_refdes_status(c_new_component.eco_number,c_new_component.organization_id,c_new_component.assembly_item_number,
		       				c_new_component.assembly_item_revision,c_new_component.component_item_number);
		       fetch get_refdes_status into v_refdes_status;
		       close get_refdes_status;
		       
		       If Nvl(v_refdes_status,'U') = 'U' Then
			
			If v_sys_acd = 'A' Then 

			 -- Mark the Ref Des for addition 

			 Update ILINK_ECO_BOM_REFDES_TEMP
			 Set record_status = 'Validated',
			     effective_date_from = v_parent_sch_date,
			     operation_seq_num = v_oper_seq_num,
			     agile_sys_acd = 'A'
			 Where eco_number = c_new_component.eco_number and  
			       organization_id = c_new_component.organization_id and                                                                     
			       assembly_item_number = c_new_component.assembly_item_number and 
			       assembly_item_revision = c_new_component.assembly_item_revision and                                                     
			       component_item_number = c_new_component.component_item_number; 

			Elsif v_sys_acd = 'C' Then	

			 -- Add Extra Ref Des in Oracle as deletes to the temp table 

			  Insert into ILINK_ECO_BOM_REFDES_TEMP
				(eco_number,
				 assembly_item_number,
				 assembly_item_revision,
				 component_item_number,
				 effective_date_from,
				 agile_sys_acd,
				 organization_code,
				 operation_seq_num,
				 reference_designator,
				 record_status,
				 process_flag)
			  Select c_new_component.eco_number,
				 c_new_component.assembly_item_number,
				 c_new_component.assembly_item_revision,
				 c_new_component.component_item_number,
				 v_parent_sch_date,
				 'D',
				 c_new_component.organization_code,
				 v_oper_seq_num,
				 brd.component_reference_designator,
				 'Validated',
				 'N'
			  From BOM_REFERENCE_DESIGNATORS brd,
			       BOM_BILL_OF_MATERIALS BBM,                                                                                                     
			       BOM_INVENTORY_COMPONENTS BIC,
			       ILINK_MTL_SYSTEM_ITEMS_VIEW msia,
			       ILINK_MTL_SYSTEM_ITEMS_VIEW msic 
			  Where bbm.assembly_item_id = v_item_id and                                                                                
				bbm.organization_id = c_new_component.organization_id and   
				bbm.alternate_bom_designator is NULL and	                                                                                
				bic.component_item_id = v_component_id and                                                                          
				bic.bill_sequence_id = bbm.bill_sequence_id and
				(bic.disable_date is null or bic.disable_date > SYSDATE) and
				brd.component_sequence_id = bic.component_sequence_id and
				nvl(brd.acd_type,1) = 1 and
				msia.inventory_item_id = bbm.assembly_item_id and
				msia.organization_id = bbm.organization_id and
				msic.inventory_item_id = bic.component_item_id and
				msic.organization_id = bbm.organization_id and
				not exists (Select 'x' From ILINK_ECO_BOM_REFDES_TEMP irt
					    Where irt.assembly_item_number = msia.item_number and
						  irt.component_item_number = msic.item_number and
						  irt.reference_designator = brd.component_reference_designator and
						  irt.organization_id = bbm.organization_id and 
						  irt.process_flag = 'N');	

			 -- Delete Existing Ref Des in Oracle from the temp table 

			  Delete From ILINK_ECO_BOM_REFDES_TEMP irt
			  Where eco_number = c_new_component.eco_number and                                                                       
			       assembly_item_number = c_new_component.assembly_item_number and 
			       assembly_item_revision = c_new_component.assembly_item_revision and                                                     
			       component_item_number = c_new_component.component_item_number and
			       organization_id = c_new_component.organization_id and 
			       agile_sys_acd = 'U' and
			       exists (Select 'x' 
				       From BOM_REFERENCE_DESIGNATORS brd,
					    BOM_BILL_OF_MATERIALS BBM,                                                                                                     
					    BOM_INVENTORY_COMPONENTS BIC                                                                                                   
				       Where bbm.assembly_item_id = v_item_id and                                                                                
					     bbm.organization_id = c_new_component.organization_id and   
					     bbm.alternate_bom_designator is NULL and	                                                                                
					     bic.component_item_id = v_component_id and                                                                               
					     bic.bill_sequence_id = bbm.bill_sequence_id and
					     (bic.disable_date is null or bic.disable_date > SYSDATE) and
					     brd.component_sequence_id = bic.component_sequence_id and
					     nvl(brd.acd_type,1) = 1 and
					     brd.component_reference_designator = irt.reference_designator);

			 -- Mark New ref Des for Addition in the temp table

			 Update ILINK_ECO_BOM_REFDES_TEMP
			 Set record_status = 'Validated',
			     effective_date_from = v_parent_sch_date,
			     operation_seq_num = v_oper_seq_num,
			     agile_sys_acd = 'A'
			 Where eco_number = c_new_component.eco_number and  
			       organization_id = c_new_component.organization_id and                                                                     
			       assembly_item_number = c_new_component.assembly_item_number and 
			       assembly_item_revision = c_new_component.assembly_item_revision and                                                     
			       component_item_number = c_new_component.component_item_number and
			       agile_sys_acd = 'U'; 

			Elsif v_sys_acd = 'D' Then	  

			 -- Delete Ref Des for Disabling Components in the temp table 

			 Delete From ILINK_ECO_BOM_REFDES_TEMP 
			 Where eco_number = c_new_component.eco_number and  
			       organization_id = c_new_component.organization_id and                                                                     
			       assembly_item_number = c_new_component.assembly_item_number and 
			       assembly_item_revision = c_new_component.assembly_item_revision and                                                     
			       component_item_number = c_new_component.component_item_number;  
			       
			Elsif Nvl(v_refdes_status,'U') != 'U' Then
			
			  Update ILINK_ECO_BOM_REFDES_TEMP
			  Set record_status = 'Validated'
			  Where eco_number = c_new_component.eco_number and  
			       organization_id = c_new_component.organization_id and                                                                     
			       assembly_item_number = c_new_component.assembly_item_number and 
			       assembly_item_revision = c_new_component.assembly_item_revision and                                                     
			       component_item_number = c_new_component.component_item_number; 
			 
			End If; -- Unprocessed (U) reference designators exist 
			
		       End If; -- End Processing of Reference Designators */                                                	


		/* If any of the validations failed then mark the component item record, it's Assembly item record and ECO header records as "Error" */                                                                                                         


			Elsif nvl(v_record_status,'S') = 'E' Then   
			
			v_error_str := NULL;	
			Select Decode(instr(nvl(v_error_text_item,'ERROR'),'Check Component(s) : '),0,'Check Component(s) : ')
			Into v_error_str From Dual;
			
			v_error_text_item := substr(v_error_text_item||' '||v_error_str||c_new_component.component_item_number||' ',1,4000);

			v_error_str := NULL;	 
			Select Decode(instr(nvl(v_error_text_eco,'ERROR'),'Check Component(s) : '),0,'Check Component(s) : ')
			Into v_error_str From Dual;	
	
			v_error_text_eco := substr(v_error_text_eco||' '||v_error_str||c_new_component.assembly_item_number||'('||c_new_component.component_item_number||') ',1,4000);			

			Update ILINK_ECO_ITEM_BOMS_TEMP                                                                             
			Set record_status = 'Error',                                                                                
			    error_message = 'Error: '||v_error_text_comp                                                            
			Where eco_number = c_new_component.eco_number and                                             
			      organization_id = c_new_component.organization_id and
			      assembly_item_number = c_new_component.assembly_item_number and                         
			      component_item_number = c_new_component.component_item_number;                     

			Update ILINK_ECO_ITEM_REVISIONS_TEMP                                                                        
			Set record_status = 'Error',                                                                                
			    error_message = v_error_text_item
			Where eco_number = c_new_component.eco_number and     
			      organization_id = c_new_component.organization_id and                                        
			      item_number = c_new_component.assembly_item_number;                                     

			Update ILINK_ECOS_TRANSFERED                                                                                
			Set record_status = 'Error',                                                                                
			    process_flag = 'Y',    
			    processed_date = SYSDATE,                                                                                   
			    error_message = v_error_text_eco
			Where eco_number = c_new_component.eco_number and
			      organization_id = c_new_component.organization_id;                                                
			      
		 End If;
			
		End Loop;  -- BOM Components

	     End Loop;	-- Affected Items

	   End Loop;  -- ECO Header

		
		/* Delete Reference Designators Not Marked for Processing -- Commented out on 02/21/2014

		   Delete From ILINK_ECO_BOM_REFDES_TEMP a
		   Where a.agile_sys_acd = 'U' and
			 not exists (Select 'x' From ILINK_ECOS_TRANSFERED b
				     Where a.eco_number = b.eco_number and
					   b.record_status = 'Error');  	*/	                                                                                               

  Exception
    When Others then
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_ECO_PRE_VALIDATE is '||SQLERRM);

End ILINK_ECO_PRE_VALIDATE;                                                                                                    



/*   Process all Pre-Validated REcords and move them to OPen Interface Table */                                                     

Procedure  ILINK_ECO_INSERT_INT is                                                                                                  

/* Define Cursor to fetch "Validated" Header records from temp table */                                                             

Cursor get_eco_headers is                                                                                                           
Select eco_number,                                                                                                                 
       description,                                                                                                                
       attribute1 change_type,    
       eco_status,
       approval_status,
       originated_date,                                                                                                            
       released_date,                                                                                                              
       originator,                                                                                                                 
       reason_code,                                                                                                                                                                                                                           
       organization_code,                                                                                                          
       organization_id,                                                                                                            
       record_status                                                                                                               
From ILINK_ECOS_TRANSFERED aet                                                                                                      
Where record_status = 'Validated' and                                                                                               
      not exists (Select 'x'  From ILINK_ECO_ITEM_REVISIONS_TEMP aei                                                                
		  Where aei.eco_number = aet.eco_number and 
			aei.organization_id = aet.organization_id and                                                                        
			aei.record_status = 'Error') and                                                                            
      not exists (Select 'x'  From ILINK_ECO_ITEM_BOMS_TEMP aeb                                                                     
		  Where aeb.eco_number = aet.eco_number and                                                                         
			aeb.organization_id = aet.organization_id and
			aeb.record_status = 'Error') and
      not exists (Select 'x' From ILINK_ECOS_TRANSFERED aet1
		  Where aet1.eco_number = aet.eco_number and                                                                                
			aet1.organization_id != aet.organization_id and
			aet1.record_status = 'Error')
Order by released_date,eco_number,organization_code;                                                                                              

/* Define Cursor to fetch "Validated" Assembly item records from temp table */                                           

Cursor get_rev_items is                                                                                                             
Select eco_number,                                                                                                                 
       record_id,                                                                                                                  
       item_number,                                                                                                                
       SUBSTR(new_revision,1,3) new_revision,                                                                                                               
       lifecycle_status,                                                                                                           
       effective_date_from,                                                                                                        
       effective_date_to,                                                                                                          
       old_revision,                                                                                                 
       organization_code,                                                                                                          
       organization_id,                                                                                                            
       record_status,
       disposition_code
From ILINK_ECO_ITEM_REVISIONS_TEMP aei                                                                                              
Where record_status = 'Validated' and                                                                                               
      not exists (Select 'x'  From ILINK_ECOS_TRANSFERED aet                                                                        
		  Where aei.eco_number = aet.eco_number and  
			aei.organization_id = aet.organization_id and                                                                       
			aet.record_status = 'Error') and                                                                            
      not exists (Select 'x'  From ILINK_ECO_ITEM_BOMS_TEMP aeb                                                                     
		  Where aeb.eco_number = aei.eco_number and 
			aeb.organization_id = aei.organization_id and                                                                        
			aeb.record_status = 'Error') and
      not exists (Select 'x' From ILINK_ECOS_TRANSFERED aet1
		  Where aet1.eco_number = aei.eco_number and                                                                                
			aet1.organization_id != aei.organization_id and
			aet1.record_status = 'Error')                                                                               
Order by eco_number,organization_code,item_number,new_revision;                                                                     

/* Define Cursor to fetch "Validated" Component Item records from temp table */                                                     

Cursor get_bom_comp is                                                                                                              
Select eco_number,                                                                                                                 
       assembly_item_number,                                                                                                       
       component_item_number,                                                                                                      
       quantity,                                                                                                                   
       operation_seq_num,                                                                                                          
       find_number,    
       attribute2,
       agile_sys_acd,                                                                                                              
       organization_code, 
       organization_id,                                                                                                         
       effective_date_from,                                                                                                        
       effective_date_to,                                                                                                          
       SUBSTR(assembly_item_revision,1,3) assembly_item_revision,                                                                                                     
       component_remarks
From ILINK_ECO_ITEM_BOMS_TEMP aeb                                                                                                   
Where record_status = 'Validated' and  
      nvl(attribute5,'P') = 'P' and                                                                                             
      not exists (Select 'x'  From ILINK_ECOS_TRANSFERED aet                                                                        
		  Where aeb.eco_number = aet.eco_number and  
			aeb.organization_id = aet.organization_id and                                                                                                                                              
			aet.record_status = 'Error') and                                                                            
      not exists (Select 'x'  From ILINK_ECO_ITEM_REVISIONS_TEMP aei                                                                
		  Where aeb.eco_number = aei.eco_number and 
			aeb.organization_id = aei.organization_id and                                                                                                                                               
			aei.record_status = 'Error') and
      not exists (Select 'x' From ILINK_ECOS_TRANSFERED aet1
		  Where aet1.eco_number = aeb.eco_number and                                                                                
			aet1.organization_id != aeb.organization_id and
			aet1.record_status = 'Error')                                                                                  
Order by eco_number,organization_code,assembly_item_number,component_item_number,agile_sys_acd; 

/*  Define Cursor to fetch "Validated" SUBSTITUTE Component Item records from temp table */                                                     

Cursor get_bom_sub_comp is                                                                                                              
Select eco_number,                                                                                                                 
       assembly_item_number,                                                                                                       
       component_item_number,
       parent_comp_number,                                                                                                      
       quantity,                                                                                                                   
       operation_seq_num,                                                                                                          
       find_number,                                                                                                                       
       agile_sys_acd,                                                                                                              
       organization_code,    
       organization_id,                                                                                                      
       effective_date_from,                                                                                                        
       effective_date_to,                                                                                                          
       SUBSTR(assembly_item_revision,1,3) assembly_item_revision,                                                                                                     
       component_remarks                                                                                                                  
From ILINK_ECO_ITEM_BOMS_TEMP aeb                                                                                                   
Where record_status = 'Validated' and  
      attribute5 = 'A' and                                                                                             
      not exists (Select 'x'  From ILINK_ECOS_TRANSFERED aet                                                                        
		  Where aeb.eco_number = aet.eco_number and   
			aeb.organization_id = aet.organization_id and                                                                                                                                             
			aet.record_status = 'Error') and                                                                            
      not exists (Select 'x'  From ILINK_ECO_ITEM_REVISIONS_TEMP aei                                                                
		  Where aeb.eco_number = aei.eco_number and    
			aeb.organization_id = aei.organization_id and                                                                                                                                            
			aei.record_status = 'Error') and
      not exists (Select 'x' From ILINK_ECOS_TRANSFERED aet1
		  Where aet1.eco_number = aeb.eco_number and                                                                                
			aet1.organization_id != aeb.organization_id and
			aet1.record_status = 'Error')                                                                                  
Order by eco_number,organization_code,assembly_item_number,component_item_number,agile_sys_acd;  

/*  Define Cursor to fetch Reference Designators for "Validated" Component Item records from temp table -- Commented out on 02/21/2014                                                   

Cursor get_bom_ref_des is                                                                                                              
Select ird.eco_number,                                                                                                                 
       ird.assembly_item_number,                                                                                                       
       ird.component_item_number,   
       ird.agile_sys_acd,                                                                                               
       ird.operation_seq_num,                                                                                                          
       ird.organization_code,     
       ird.organization_id,                                                                                                     
       ird.effective_date_from,                                                                                                        
       SUBSTR(ird.assembly_item_revision,1,3) assembly_item_revision,                                                                                                     
       ird.reference_designator
From ILINK_ECO_BOM_REFDES_TEMP ird                                                                                                 
Where ird.record_status = 'Validated' and                                                                                         
      not exists (Select 'x'  From ILINK_ECOS_TRANSFERED aet                                                                        
		  Where ird.eco_number = aet.eco_number and    
			ird.organization_id = aet.organization_id and                                                                                                                                            
			aet.record_status = 'Error') and                                                                            
      not exists (Select 'x'  From ILINK_ECO_ITEM_REVISIONS_TEMP aei                                                                
		  Where ird.eco_number = aei.eco_number and
			ird.organization_id = aei.organization_id and                                                                                                                                                
			aei.record_status = 'Error') and
      not exists (Select 'x' From ILINK_ECOS_TRANSFERED aet1
		  Where aet1.eco_number = ird.eco_number and                                                                                
			aet1.organization_id != ird.organization_id and
			aet1.record_status = 'Error')                                                                                 
Order by ird.eco_number,ird.organization_code,ird.assembly_item_number,ird.component_item_number,ird.agile_sys_acd;       */                                 

/*  Define Cursor to fetch Reference Designators based on "Validated" Component Item records from temp table */                                                   

Cursor get_bom_ref_des is                                                                                                              
Select aeb.eco_number,                                                                                                                 
       aeb.assembly_item_number,                                                                                                       
       aeb.component_item_number,   
       aeb.agile_sys_acd,                                                                                               
       aeb.operation_seq_num,                                                                                                          
       aeb.organization_code,     
       aeb.organization_id,                                                                                                     
       aeb.effective_date_to,                                                                                                        
       SUBSTR(aeb.assembly_item_revision,1,3) assembly_item_revision,                                                                                                     
       aeb.find_number reference_designator
From ILINK_ECO_ITEM_BOMS_TEMP aeb                                                                                                   
Where aeb.record_status = 'Validated' and  
      nvl(aeb.attribute5,'P') = 'P' and         
      aeb.agile_sys_acd = 'A' and
      nvl(aeb.find_number,'0') != '0' and
      not exists (Select 'x'  From ILINK_ECOS_TRANSFERED aet                                                                        
		  Where aeb.eco_number = aet.eco_number and  
			aeb.organization_id = aet.organization_id and                                                                                                                                              
			aet.record_status = 'Error') and                                                                            
      not exists (Select 'x'  From ILINK_ECO_ITEM_REVISIONS_TEMP aei                                                                
		  Where aeb.eco_number = aei.eco_number and 
			aeb.organization_id = aei.organization_id and                                                                                                                                               
			aei.record_status = 'Error') and
      not exists (Select 'x' From ILINK_ECOS_TRANSFERED aet1
		  Where aet1.eco_number = aeb.eco_number and                                                                                
			aet1.organization_id != aeb.organization_id and
			aet1.record_status = 'Error')                                                                                  
Order by eco_number,organization_code,assembly_item_number,component_item_number,agile_sys_acd; 

v_eco_number  	Varchar2(10);                                                                                                         
v_eco_type	Varchar2(80);                                                                                                          
v_org_hierarchy Varchar2(50);                                                                                                       


begin                                                                                                                                                                                                                          


      /* Insert ECO Header records into interface table*/                                                                           

      For c_eco_header in get_eco_headers Loop                                                                                     


	Insert into ENG_ENG_CHANGES_INTERFACE                                                                                       
		(change_notice,     
		organization_id,                                                                                                 
		organization_code,                                                                                                  
		change_order_type,                                                                                                  
		description,                                                                                                        
		eng_changes_ifce_key,                                                                                               
		transaction_type,                                                                                                   
		approval_status_name,                                                                                               
		status_name,                                                                                                      
		reason_code,    
		requestor_user_name,
		plm_or_erp_change)                                                                                                           
	Values                                                                                                                      
		(c_eco_header.eco_number, 
		c_eco_header.organization_id,                                                                                           
		c_eco_header.organization_code,                                                                                     
		c_eco_header.change_type,                                                                                                         
		c_eco_header.description,                                                                                           
		'AGILE'||c_eco_header.eco_number||c_eco_header.organization_code,                                                                                   
		'CREATE',                                                                                                           
		nvl(c_eco_header.approval_status,'Approved'),                                                                                                         
		c_eco_header.eco_status,                                                                                                        
		c_eco_header.reason_code,  
		NULL,
		'ERP');                                                                                                                              

	/* Mark the record as Processed indicating the record is inserted into the Interface table */                               

	Update ILINK_ECOS_TRANSFERED                                                                                                
	Set process_flag = 'Y',
	    processed_date = SYSDATE                                                                                                        
	Where eco_number = c_eco_header.eco_number and                                                                              
	      organization_id = c_eco_header.organization_id;                                                                   

	End Loop;                                                                                                                   


     /* Insert  Revised Items(Assembly) records into interface table*/                                                              

      For c_rev_item in get_rev_items Loop                                                                                         

	Insert into ENG_REVISED_ITEMS_INTERFACE                                                                                     
		(change_notice,    
		organization_id,                                                                                                  
		organization_code,                                                                                                  
		revised_item_number,                                                                                                
		new_item_revision,                                                                                                  
		scheduled_date,                                                                                                     
		transaction_type,                                                                                                   
		descriptive_text,                                                                                                   
		comments,     
		disposition_type,
		eng_revised_items_ifce_key,                                                                                         
		eng_changes_ifce_key)    
	Values                                                                                                                      
		(c_rev_item.eco_number,   
		c_rev_item.organization_id,                                                                                           
		c_rev_item.organization_code,                                                                                       
		c_rev_item.item_number,                                                                                             
		c_rev_item.new_revision,                                                                                            
		c_rev_item.effective_date_from,                                                                                     
		'CREATE',                                                                                                           
		c_rev_item.new_revision,                                                                                                                
		NULL,                                                                                                               
		NULL,
		'AGILE'||c_rev_item.eco_number||c_rev_item.organization_code,                                                                                     
		'AGILE'||c_rev_item.eco_number||c_rev_item.organization_code);                                                                                                              

	/* Mark the record as Processed indicating the record is inserted into the Interface table */                               

	Update ILINK_ECO_ITEM_REVISIONS_TEMP                                                                                        
	Set process_flag = 'Y',
	    processed_date = SYSDATE                                                                                                        
	Where eco_number = c_rev_item.eco_number and  
	      organization_id = c_rev_item.organization_id and                                                                              
	      item_number = c_rev_item.item_number and                                                                              
	      new_revision = c_rev_item.new_revision;                                                                               


	End Loop;                                                                                                                   


       /* Insert BOM components records into interface table */                                                                     

       FOR c_bom_comp in get_bom_comp LOOP                                                                                          

	insert into BOM_INVENTORY_COMPS_INTERFACE                                                                                   
		(change_notice,                                                                                                      
		assembly_item_number,                                                                                               
		component_item_number,                                                                                              
		component_quantity,                                                                                                 
		operation_seq_num,                                                                                                  
		item_num,            
		attribute2,
		old_operation_seq_num,                                                                                              
		transaction_type,                                                                                                   
		acd_type,    
		organization_id,                                                                                                       
		organization_code,                                                                                                  
		old_effectivity_date,                                                                                               
		effectivity_date,                                                                                                   
		new_revised_item_revision,                                                                                          
		bom_inventory_comps_ifce_key,                                                                                       
		eng_revised_items_ifce_key,                                                                                         
		eng_changes_ifce_key,                                                                                               
		revised_item_number,                                                                                                
		component_remarks,
		component_yield_factor, 
		interface_entity_type)                                                                                                                                                                                                                         
	values                                                                                                                      
		(c_bom_comp.eco_number,                                                                                              
		c_bom_comp.assembly_item_number,                                                                                    
		c_bom_comp.component_item_number,                                                                                   
		c_bom_comp.quantity,                                                                                                
		c_bom_comp.operation_seq_num,                                                                                       
		c_bom_comp.find_number,      
		NULL,
		decode(c_bom_comp.agile_sys_acd,'A',NULL,c_bom_comp.operation_seq_num),                                             
		'CREATE',                                                                                                           
		decode(c_bom_comp.agile_sys_acd,'A',1,'C',2,'D',3),     
		c_bom_comp.organization_id,                                                            
		c_bom_comp.organization_code,                                                                                       
		c_bom_comp.effective_date_from,                                                                                     
		c_bom_comp.effective_date_to,                                                                                       
		c_bom_comp.assembly_item_revision,                                                                                  
		'AGILE'||c_bom_comp.eco_number||c_bom_comp.organization_code,                                                                                     
		'AGILE'||c_bom_comp.eco_number||c_bom_comp.organization_code,                                                                                     
		'AGILE'||c_bom_comp.eco_number||c_bom_comp.organization_code,                                                                                     
		c_bom_comp.assembly_item_number,                                                                                    
		c_bom_comp.component_remarks, 
		NULL, 
		'ECO');                                                                                                             


	/* Mark the record as Processed indicating the record is inserted into the Interface table */                               

	Update ILINK_ECO_ITEM_BOMS_TEMP                                                                                             
	Set process_flag = 'Y',
	    processed_date = SYSDATE                                                                                                        
	Where eco_number = c_bom_comp.eco_number and   
	      organization_id = c_bom_comp.organization_id and                                                                             
	      assembly_item_number = c_bom_comp.assembly_item_number and                                                            
	      assembly_item_revision = c_bom_comp.assembly_item_revision and                                                        
	      component_item_number = c_bom_comp.component_item_number and                                                          
	      agile_sys_acd = c_bom_comp.agile_sys_acd;                                                                             


       End Loop;    

     /* Insert BOM component Reference Designator records into interface table */                                                                     

       For c_bom_rdes in get_bom_ref_des Loop                                                                                          

	Insert into BOM_REF_DESGS_INTERFACE                                                                                   
		(change_notice,                                                                                                      
		assembly_item_number,                                                                                               
		component_item_number,                                                                                             
		operation_seq_num,                                                                                                  
		component_reference_designator, 
		ref_designator_comment,                                                                                                                        
		transaction_type,                                                                                                   
		acd_type,  
		organization_id,                                                                                                         
		organization_code,                                                                                               
		effectivity_date,                                                                                                   
		new_revised_item_revision, 
		bom_ref_desgs_ifce_key,                                                                                         
		bom_inventory_comps_ifce_key,                                                                                       
		eng_revised_items_ifce_key,                                                                                         
		eng_changes_ifce_key,                                                                                               
		interface_entity_type,
		process_flag)                                                                                                                                                                                                      
	Values                                                                                                                      
		(c_bom_rdes.eco_number,                                                                                              
		c_bom_rdes.assembly_item_number,                                                                                    
		c_bom_rdes.component_item_number,                                                                                   
		c_bom_rdes.operation_seq_num,
		c_bom_rdes.reference_designator,                                             
		c_bom_rdes.reference_designator,
		'CREATE',                                                                                                           
		decode(c_bom_rdes.agile_sys_acd,'A',1,'D',3),
		c_bom_rdes.organization_id,                                                                 
		c_bom_rdes.organization_code,
		c_bom_rdes.effective_date_to,	-- from,                                                                                       
		c_bom_rdes.assembly_item_revision,                                                                                  
		'AGILE'||c_bom_rdes.eco_number||c_bom_rdes.organization_code, 
		'AGILE'||c_bom_rdes.eco_number||c_bom_rdes.organization_code,                                                                                     
		'AGILE'||c_bom_rdes.eco_number||c_bom_rdes.organization_code,                                                                                     
		'AGILE'||c_bom_rdes.eco_number||c_bom_rdes.organization_code,                                                                                     
		'ECO',
		1);                                                                                                             


	/* Mark the record as Processed indicating the record is inserted into the Interface table */                               

	Update ILINK_ECO_BOM_REFDES_TEMP                                                                                             
	Set process_flag = 'Y',
	    processed_date = SYSDATE                                                                                                        
	Where eco_number = c_bom_rdes.eco_number and    
	      organization_id = c_bom_rdes.organization_id and                                                                            
	      assembly_item_number = c_bom_rdes.assembly_item_number and                                                            
	      assembly_item_revision = c_bom_rdes.assembly_item_revision and                                                        
	      component_item_number = c_bom_rdes.component_item_number and                                                           
	      reference_designator = c_bom_rdes.reference_designator;                                                                             


       End Loop;    

     /* Insert BOM SUBSTITUTE components records into interface table */                                                                     

       For c_bom_sub_comp in get_bom_sub_comp Loop                                                                                          

	Insert into BOM_SUB_COMPS_INTERFACE                                                                                  
		(change_notice,                                                                                                      
		assembly_item_number,                                                                                               
		component_item_number,                                                                                              
		substitute_comp_number,                                                                                              
		substitute_item_quantity,                                                                                                   
		operation_seq_num,                                                                                             
		transaction_type,                                                                                                   
		acd_type,               
		organization_id,                                                                                            
		organization_code,                                                                                              
		effectivity_date,                                                                                                   
		new_revised_item_revision,  
		bom_sub_comps_ifce_key,                                                                                         
		bom_inventory_comps_ifce_key,                                                                                       
		eng_revised_items_ifce_key,                                                                                         
		eng_changes_ifce_key,                                                                                                            
		interface_entity_type)                                                                                                                           
	Values                                                                                                                      
		(c_bom_sub_comp.eco_number,                                                                                              
		c_bom_sub_comp.assembly_item_number, 
		c_bom_sub_comp.parent_comp_number,                                                                                   
		c_bom_sub_comp.component_item_number,                                                                                   
		c_bom_sub_comp.quantity,                                                                                                
		c_bom_sub_comp.operation_seq_num,                                           
		'CREATE',                                                                                                           
		decode(c_bom_sub_comp.agile_sys_acd,'A',1,'D',3), 
		c_bom_sub_comp.organization_id,                                                                
		c_bom_sub_comp.organization_code,                                                                                       
		c_bom_sub_comp.effective_date_to,                                                                                     
		c_bom_sub_comp.assembly_item_revision, 
		'AGILE'||c_bom_sub_comp.eco_number||c_bom_sub_comp.organization_code,                                                                                    
		'AGILE'||c_bom_sub_comp.eco_number||c_bom_sub_comp.organization_code,                                                                                     
		'AGILE'||c_bom_sub_comp.eco_number||c_bom_sub_comp.organization_code,                                                                                     
		'AGILE'||c_bom_sub_comp.eco_number||c_bom_sub_comp.organization_code,                                                                                                 
		'ECO');                                                                                                             


	/* Mark the record as Processed indicating the record is inserted into the Interface table */                               

	Update ILINK_ECO_ITEM_BOMS_TEMP                                                                                             
	Set process_flag = 'Y',
	    processed_date = SYSDATE                                                                                                    
	Where eco_number = c_bom_sub_comp.eco_number and            
	      organization_id = c_bom_sub_comp.organization_id and                                                                    
	      assembly_item_number = c_bom_sub_comp.assembly_item_number and                                                            
	      assembly_item_revision = c_bom_sub_comp.assembly_item_revision and                                                        
	      component_item_number = c_bom_sub_comp.component_item_number and                                                          
	      agile_sys_acd = c_bom_sub_comp.agile_sys_acd;                                                                             


       End Loop;                                                                                                                                                        

       Commit;          

   Exception
    When Others then
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_ECO_INSERT_INT is '||SQLERRM);

End ILINK_ECO_INSERT_INT;                                                                                                     


/*   Call  Oracle Engineering ECO Interface APIs passing one ECO at a time  */                                                      

Procedure ILINK_CALL_ECO_APIS_INTERFACE (p_intf_tag IN VARCHAR2,p_status_flag OUT Varchar2)  is                                                              

  l_eco_rec             Eng_Eco_Pub.Eco_Rec_Type;                                                                                   
  l_eco_revision_tbl    Eng_Eco_Pub.Eco_Revision_Tbl_Type;                                                                          
  l_revised_item_tbl    Eng_Eco_Pub.Revised_Item_Tbl_Type;                                                                          
  l_rev_component_tbl   Bom_Bo_Pub.Rev_Component_Tbl_Type;                                                                          
  l_sub_component_tbl   Bom_Bo_Pub.Sub_Component_Tbl_Type;                                                                          
  l_ref_designator_tbl  Bom_Bo_Pub.Ref_Designator_Tbl_Type;                                                                         
  l_rev_operation_tbl   Bom_Rtg_Pub.Rev_Operation_Tbl_Type;                                                                         
  l_rev_op_resource_tbl Bom_Rtg_Pub.Rev_Op_Resource_Tbl_Type;                                                                       
  l_rev_sub_resource_tbl Bom_Rtg_Pub.Rev_Sub_Resource_Tbl_Type;                                                                     
  l_return_status       VARCHAR2(1);                                                                                                
  l_msg_count           NUMBER;                                                                                                     
  l_msg_data            VARCHAR2(4000);                                                                                             
  l_Error_Table         Error_Handler.Error_Tbl_Type;                                                                               
  l_Message_text        Varchar2(4000);                                                                                             
  l_output_dir          Varchar2(20);                                                                                               
  l_output_file         Varchar2(20);                                                                                               
  v_error_message       Varchar2(30000);                                                                                            

/* Define a cursor to process ECO header records from the interface table */                                                        

  Cursor c_eco_rec IS                                                                                                               
   Select *                                                                                                                          
   From ENG_ENG_CHANGES_INTERFACE                                                                                                   
   Where eng_changes_ifce_key like p_intf_tag
   Order by eng_changes_ifce_key;                                                                                      

/* Define a cursor to process Assembly item records from the interface table */                                          

  Cursor c_rev_items IS                                                                                                             
   Select *                                                                                                                         
   From ENG_REVISED_ITEMS_INTERFACE                                                                                                 
   Where eng_revised_items_ifce_key like p_intf_tag
   Order by eng_revised_items_ifce_key;                                                                                

/* Define a cursor to process Component item records from the interface table */                                                    

  Cursor c_rev_comps IS                                                                                                             
   Select *                                                                                                                         
   From BOM_INVENTORY_COMPS_INTERFACE                                                                                               
   Where bom_inventory_comps_ifce_key like p_intf_tag 
   Order by bom_inventory_comps_ifce_key;

/* Define a cursor to process SUBSTUTUTE Component item records from the interface table */                                                    

  Cursor c_sub_comps IS                                                                                                             
   Select *                                                                                                                         
   From BOM_SUB_COMPS_INTERFACE                                                                                               
   Where bom_sub_comps_ifce_key like p_intf_tag 
   Order by bom_sub_comps_ifce_key;

/* Define a cursor to process Component item reference designator records from the interface table */                                                    

  Cursor c_ref_desgs IS                                                                                                             
   Select *                                                                                                                         
   From BOM_REF_DESGS_INTERFACE                                                                                               
   Where bom_ref_desgs_ifce_key like p_intf_tag 
   Order by bom_ref_desgs_ifce_key;                                                                        

  v_comp_count  	Number;                                                                                                             
  v_item_count  	Number;                                                                                                             
  v_desg_count  	Number; 
  v_sub_comp_count 	Number;                                                                                                        

  BEGIN                                                                                                                             

   /* Fetch ECO Headers */                                                                                                          

   For eco_rec IN c_eco_rec Loop                                                                                                    
    l_eco_rec.eco_name := eco_rec.change_notice;                                                                                 
    l_eco_rec.organization_code := eco_rec.organization_code;                                                                       
    l_eco_rec.change_type_code := eco_rec.change_order_type;                                                                        
    l_eco_rec.status_name := eco_rec.status_name;                                                                                   
    l_eco_rec.eco_department_name := eco_rec.responsible_org_code;                                                                  
    l_eco_rec.approval_status_name := eco_rec.approval_status_name;                                                                 
    l_eco_rec.reason_code := eco_rec.reason_code;                                                                                   
    l_eco_rec.description := eco_rec.description;                                                                                   
    l_eco_rec.transaction_type := eco_rec.transaction_type;                                                                         
    -- l_eco_rec.requestor := eco_rec.requestor_user_name;                                                                             
    l_eco_rec.need_by_date := eco_rec.need_by_date;                                                                                 
    l_eco_rec.plm_or_erp_change := eco_rec.plm_or_erp_change;                                                                       
    -- l_eco_rec.attribute1 := eco_rec.attribute1;                                                                                   
    -- l_eco_rec.attribute2 := eco_rec.attribute2;                                                                                   
    -- l_eco_rec.attribute3 := eco_rec.attribute3;                                                                                   
    --l_eco_rec.organization_hierarchy := eco_rec.organization_hierarchy;                                                             
    --l_eco_rec.hierarchy_flag := 1;                                                                                                
   End Loop;                                                                                                                        

 /* Fetch Assembly items */                                                                                            

  v_item_count := 1;                                                                                                                
  For ri IN c_rev_items Loop                                                                                                        
   l_revised_item_tbl(v_item_count).eco_name := ri.change_notice;  
   l_revised_item_tbl(v_item_count).organization_code := ri.organization_code;                                                      
   l_revised_item_tbl(v_item_count).revised_item_name := ri.revised_item_number;                                                    
   If ri.new_item_revision = FND_API.G_MISS_CHAR THEN                                                                               
    l_revised_item_tbl(v_item_count).new_revised_item_revision := NULL;                                                             
   Else                                                                                                                            
    l_revised_item_tbl(v_item_count).new_revised_item_revision := ri.new_item_revision;                                             
   End If;                                                                                                                          
   l_revised_item_tbl(v_item_count).start_effective_date := ri.scheduled_date;                                                      
   l_revised_item_tbl(v_item_count).status_type := ri.status_type;                                                                  
   l_revised_item_tbl(v_item_count).mrp_active := ri.mrp_active;                                                                    
   l_revised_item_tbl(v_item_count).earliest_effective_date := ri.early_schedule_date;                                              
   l_revised_item_tbl(v_item_count).change_description := ri.descriptive_text;  
   l_revised_item_tbl(v_item_count).New_Revised_Item_Rev_Desc := ri.descriptive_text; 
   l_revised_item_tbl(v_item_count).disposition_type := ri.disposition_type;
   l_revised_item_tbl(v_item_count).transaction_type := ri.transaction_type;   
   l_revised_item_tbl(v_item_count).attribute1 := NULL;  
   -- l_revised_item_tbl(v_item_count).update_wip := 2;                                                       
   v_item_count := v_item_count + 1;                                                                                                
  End Loop;                                                                                                                         

 /* Fetch BOM components */                                                                                                         

  v_comp_count := 1;                                                                                                                
  For rc IN c_rev_comps Loop                                                                                                        
   l_rev_component_tbl(v_comp_count).eco_name := rc.change_notice;                                                          
   l_rev_component_tbl(v_comp_count).revised_item_name := rc.assembly_item_number;                                                  
   l_rev_component_tbl(v_comp_count).component_item_name := rc.component_item_number;                                               
   l_rev_component_tbl(v_comp_count).organization_code := rc.organization_code;                                                     
   l_rev_component_tbl(v_comp_count).new_revised_item_revision := rc.new_revised_item_revision;                                     
   l_rev_component_tbl(v_comp_count).start_effective_date := rc.effectivity_date;                                                   
   l_rev_component_tbl(v_comp_count).disable_date := rc.disable_date;                                                               
   -- l_rev_component_tbl(v_comp_count).operation_sequence_number := rc.operation_seq_num;             -- Commented out on 05/08/2014
   l_rev_component_tbl(v_comp_count).new_operation_sequence_number := rc.operation_seq_num;            -- Added on 05/08/2014
   l_rev_component_tbl(v_comp_count).acd_type := rc.acd_type;                                                                       
   l_rev_component_tbl(v_comp_count).old_effectivity_date := rc.old_effectivity_date;                                               
   l_rev_component_tbl(v_comp_count).old_operation_sequence_number :=rc.old_operation_seq_num;                                      
   l_rev_component_tbl(v_comp_count).item_sequence_number := rc.item_num;                                                           
   l_rev_component_tbl(v_comp_count).quantity_per_assembly := rc.component_quantity;                                                
   l_rev_component_tbl(v_comp_count).transaction_type := rc.transaction_type;                                                       
   l_rev_component_tbl(v_comp_count).comments := rc.component_remarks;  
   -- l_rev_component_tbl(v_comp_count).projected_yield := rc.component_yield_factor;  
   -- l_rev_component_tbl(v_comp_count).attribute1 := 'FN '||rc.attribute2;                                                              
   l_rev_component_tbl(v_comp_count).quantity_related := NULL; -- 1;                                                              
   v_comp_count :=  v_comp_count + 1;                                                                                               
  End Loop;                  

  v_sub_comp_count := 1;
  For rs in c_sub_comps Loop 
   l_sub_component_tbl(v_sub_comp_count).eco_name := rs.change_notice;                                                   
   l_sub_component_tbl(v_sub_comp_count).revised_item_name := rs.assembly_item_number; 
   l_sub_component_tbl(v_sub_comp_count).organization_code := rs.organization_code; 
   l_sub_component_tbl(v_sub_comp_count).start_effective_date := rs.effectivity_date;  
   l_sub_component_tbl(v_sub_comp_count).new_revised_item_revision := rs.new_revised_item_revision; 
   l_sub_component_tbl(v_sub_comp_count).alternate_bom_code := NULL; 
   l_sub_component_tbl(v_sub_comp_count).Component_Item_Name := rs.component_item_number; 
   l_sub_component_tbl(v_sub_comp_count).substitute_component_name := rs.substitute_comp_number;
   l_sub_component_tbl(v_sub_comp_count).acd_type := rs.acd_type; 
   l_sub_component_tbl(v_sub_comp_count).operation_sequence_number := rs.operation_seq_num; 
   l_sub_component_tbl(v_sub_comp_count).substitute_item_quantity := rs.substitute_item_quantity; 
   l_sub_component_tbl(v_sub_comp_count).transaction_type := rs.transaction_type;
   v_sub_comp_count :=  v_sub_comp_count + 1; 
  End Loop;                      

  /* Fetch reference designators */ 

  v_desg_count := 1;
  For rd IN c_ref_desgs Loop 
   l_ref_designator_tbl(v_desg_count).eco_name := rd.change_notice;  
   l_ref_designator_tbl(v_desg_count).organization_code := rd.organization_code; 
   l_ref_designator_tbl(v_desg_count).revised_item_name := rd.assembly_item_number; 
   l_ref_designator_tbl(v_desg_count).component_item_name := rd.component_item_number;
   l_ref_designator_tbl(v_desg_count).start_effective_date := rd.effectivity_date; 
   l_ref_designator_tbl(v_desg_count).new_revised_item_revision := rd.new_revised_item_revision; 
   l_ref_designator_tbl(v_desg_count).operation_sequence_number := rd.operation_seq_num; 
   l_ref_designator_tbl(v_desg_count).reference_designator_name := rd.component_reference_designator; 
   l_ref_designator_tbl(v_desg_count).acd_type := rd.acd_type; 
   l_ref_designator_tbl(v_desg_count).ref_designator_comment := rd.component_reference_designator;
   l_ref_designator_tbl(v_desg_count).new_reference_designator := rd.new_designator; 
   l_ref_designator_tbl(v_desg_count).transaction_type := rd.transaction_type; 
   v_desg_count := v_desg_count + 1;
  End Loop;                                                                                   

  /* Initialize the Error Handler Array to hold error messages */                                                                   

  Error_Handler.Initialize;                                                                                                         

   /* Call the ECO API */                                                                                                           

   Eng_Eco_PUB.Process_Eco                                                                                                          
   ( p_api_version_number => 1.0,                                                                                                   
     p_init_msg_list => FALSE,                                                                                                      
     x_return_status => l_return_status,                                                                                            
     x_msg_count => l_msg_count,                                                                                                    
     p_bo_identifier => 'ECO',                                                                                                      
     p_eco_rec => l_eco_rec,                                                                                                        
     p_eco_revision_tbl => l_eco_revision_tbl,                                                                                      
     p_revised_item_tbl => l_revised_item_tbl,                                                                                      
     p_rev_component_tbl => l_rev_component_tbl,                                                                                    
     p_ref_designator_tbl => l_ref_designator_tbl,                                                                                  
     p_sub_component_tbl => l_sub_component_tbl,                                                                                    
     p_rev_operation_tbl => l_rev_operation_tbl,                                                                                    
     p_rev_op_resource_tbl => l_rev_op_resource_tbl,                                                                                
     p_rev_sub_resource_tbl => l_rev_sub_resource_tbl,                                                                              
     x_eco_rec => l_eco_rec,                                                                                                        
     x_eco_revision_tbl => l_eco_revision_tbl,                                                                                      
     x_revised_item_tbl => l_revised_item_tbl,                                                                                      
     x_rev_component_tbl => l_rev_component_tbl,                                                                                    
     x_ref_designator_tbl => l_ref_designator_tbl,                                                                                  
     x_sub_component_tbl => l_sub_component_tbl,                                                                                    
     x_rev_operation_tbl => l_rev_operation_tbl,                                                                                    
     x_rev_op_resource_tbl => l_rev_op_resource_tbl,                                                                                
     x_rev_sub_resource_tbl => l_rev_sub_resource_tbl,                                                                              
     p_debug => 'N',                                                                                                                
     p_output_dir => l_output_dir,                                                                                                  
     p_debug_filename => l_output_file);                                                                                            


  /* ECO is successfully processed */                                                                              

  If l_return_status = 'S' Then           

	p_status_flag := 'S';          
	v_eco_header('ECO Status For '||p_intf_tag) := 'S'; 

	v_eco_header('Error Message For ECO Header '||p_intf_tag) := ' ';       
	v_eco_header('Concatenated Message For '||p_intf_tag) := ' ';                                                                        

  /* ECO is NOT successfully processed */                                                                          

  Else       

	p_status_flag := 'E';                                                                                                    
	v_eco_header('ECO Status For '||p_intf_tag) := 'E';    

   /* Write Status and Error Messages to Concurrent Log File */

	FND_FILE.PUT_LINE(FND_FILE.Log,'Error Messages for ECO Number '||replace(p_intf_tag,'AGILE'));
	FND_FILE.PUT_LINE(FND_FILE.LOG,'-----------------------------------------------------------');                                                                                                                        

  /* Perform all the error handler operations */                                                                                    

   /* Retreive the error message at ECO header level and update the corresponding records in temp table */                          

	Error_Handler.Get_Entity_Message                                                                                                 
	( p_entity_id => 'ECO' ,                                                                                                         
	x_message_list => l_error_table );                                                                                             

	v_error_message := NULL;                                                                                                         
	For i IN 1..l_error_table.COUNT Loop                                                                                             
	 v_error_message := v_error_message||l_error_table(i).message_text;                                                              
	End Loop;                                                                                                                        

	v_eco_header('Error Message For ECO Header '||p_intf_tag) := nvl(v_error_message,'Error Occured for this at the API');                                           

	FND_FILE.PUT_LINE(FND_FILE.LOG,'ECO Header level message is '||v_error_message);

  /* Retreive the record status at Assembly item level and update the corresponding records in temp table */              

	For i IN 1..(v_item_count-1) Loop 
	 v_aff_item('Assembly Status For '||p_intf_tag||' '||l_revised_item_tbl(i).revised_item_name) := l_revised_item_tbl(i).return_status;                                                                                               
	End Loop;                                                                                                                        


   /* Retreive the error message at Assembly item level and update the corresponding records in temp table */             

	Error_Handler.Get_Entity_Message                                                                                                 
	( p_entity_id => 'RI' ,                                                                                                          
	x_message_list => l_error_table );      


	v_error_message := NULL;

	For i IN 1..l_error_table.COUNT Loop                                                                                             
	 If l_error_table(i).message_type NOT IN ('S','W') Then                                                                          
	  v_aff_item('Assembly Error Message For '||p_intf_tag||'('||i||')') := l_error_table(i).message_text; 
	  v_error_message := substr(v_error_message||' '||l_error_table(i).message_text,1,4000); 
	  FND_FILE.PUT_LINE(FND_FILE.LOG,'Assembly Level Message'||'('||i||') is '||l_error_table(i).message_text);
	 End If;                                                                                                                         
	End Loop;                                                                                                                        

  /* Retreive the record status at BOM Component item level and update the corresponding records in temp table */                   

	If v_comp_count > 1 Then                                                                                                         

	 For i IN 1..(v_comp_count-1) Loop                                                                                                
	  v_bom_comp('Component Status For '||p_intf_tag||' '||l_rev_component_tbl(i).revised_item_name||' '||l_rev_component_tbl(i).component_item_name) 
		:= l_rev_component_tbl(i).return_status;                                         
	 End Loop;                                                                                                                        

    /* Retreive the error message at BOM Component item level and update the corresponding records in temp table */                 

	 Error_Handler.Get_Entity_Message                                                                                                 
	 ( p_entity_id => 'RC' ,                                                                                                          
	 x_message_list => l_error_table );                                                                                             

	 For i IN 1..l_error_table.COUNT Loop                                                                                             
	  If l_error_table(i).message_type NOT IN ('S','W') then                                                                          
	   v_bom_comp('Component Error Message '||p_intf_tag||'('||i||')') := l_error_table(i).message_text; 
	   v_error_message := substr(v_error_message||' '||l_error_table(i).message_text,1,4000);
	   FND_FILE.PUT_LINE(FND_FILE.LOG,'BOM Component Level Message'||'('||i||') is '||l_error_table(i).message_text);                                                                                                              
	  End If;                                                                                                                         
	 End Loop;

	End If;

   /* Retreive the record status at BOM Component Ref Des level and update the corresponding records in temp table */                  

	If v_desg_count > 1 Then                                                                                                         

	-- Commented out on 09/20/2008 as the API does not recognize the reference designator value correctly in the status
	 /* For i IN 1..(v_desg_count-1) Loop                                                                                                
	  v_bom_rdes('Ref Des Status For '||p_intf_tag||' '||l_rev_component_tbl(i).revised_item_name
				     ||' '||l_rev_component_tbl(i).component_item_name
				     ||' '||l_ref_designator_tbl(i).reference_designator_name)
			:= l_ref_designator_tbl(i).return_status;                                         
	 End Loop;    */                                                                                                                    

    /* Retreive the error message at BOM Component item level and update the corresponding records in temp table */                 

	 Error_Handler.Get_Entity_Message                                                                                                 
	 ( p_entity_id => 'RD' ,                                                                                                          
	 x_message_list => l_error_table );                                                                                             

	 For i IN 1..l_error_table.COUNT Loop                                                                                             
	  If l_error_table(i).message_type NOT IN ('S','W') then                                                                          
	   v_bom_rdes('Ref Des Error Message '||p_intf_tag||'('||i||')') := l_error_table(i).message_text;
	   v_error_message := substr(v_error_message||' '||l_error_table(i).message_text,1,4000);
	   FND_FILE.PUT_LINE(FND_FILE.LOG,'Reference Desginator Level Message'||'('||i||') is '||l_error_table(i).message_text); 
	  End If;                                                                                                                         
	 End Loop;                                                                                                                                                                                                                                                          

	End If;        


   /* Retreive the record status at BOM SUBSTITUTE Component item level and update the corresponding records in temp table */                   

	If v_sub_comp_count > 1 Then                                                                                                         
	 For i IN 1..(v_sub_comp_count-1) Loop 
	  v_sub_comp('Substitute Component Status For '||p_intf_tag||' '||l_sub_component_tbl(i).revised_item_name
						  ||' '||l_sub_component_tbl(i).component_item_name
						  ||' '||l_sub_component_tbl(i).substitute_component_name)
			:= l_sub_component_tbl(i).return_status;                                                              
	 End Loop;                                                                                                                        

    /* Retreive the error message at BOM Component item level and update the corresponding records in temp table */                 

	 Error_Handler.Get_Entity_Message                                                                                                 
	 (p_entity_id => 'SC' ,                                                                                                          
	 x_message_list => l_error_table );                                                                                             

	 For i IN 1..l_error_table.COUNT Loop                                                                                             
	  If l_error_table(i).message_type NOT IN ('S','W') then   
	   v_sub_comp('Substitute Component Error Message '||p_intf_tag||'('||i||')') := l_error_table(i).message_text;   
	   v_error_message := substr(v_error_message||' '||l_error_table(i).message_text,1,4000);
	   FND_FILE.PUT_LINE(FND_FILE.LOG,'BOM Substitute Level Message'||'('||i||') is '||l_error_table(i).message_text);                                                                 
	  End If;                                                                                                                         
	End Loop;  

   End If; 

   FND_FILE.CLOSE;

   v_eco_header('Concatenated Message For '||p_intf_tag) := v_error_message;                                                                                                                                      

  End If;           

  Exception
    When Others then
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_ECO_APIS_INTERFACE is '||SQLERRM);

 End ILINK_CALL_ECO_APIS_INTERFACE;    


 Procedure ILINK_POST_ECO_API_PROCESS is

 /* Declare a cursor to fetch Header Records */

 Cursor get_header_rec is
 Select eco_number,
	organization_code
 From ILINK_ECOS_TRANSFERED
 Where record_status = 'Validated';

 /* Declare a cursor to fetch Assembly Item records */

 Cursor get_assy_rec is
 Select eco_number,
	organization_code,
	item_number
 From ILINK_ECO_ITEM_REVISIONS_TEMP
 Where record_status = 'Validated';

 /* Declare a cursor to fetch Primary and Substitute BOM Component records */

 Cursor get_comp_rec(p_alt_flag IN Varchar2) is
 Select eco_number,
	organization_code,
	assembly_item_number,
	component_item_number,
	parent_comp_number
 From ILINK_ECO_ITEM_BOMS_TEMP
 Where record_status = 'Validated' and
       nvl(attribute5,'P') = p_alt_flag;

 /* Declare a cursor to fetch reference designator records */

 Cursor get_rdes_rec is
 Select eco_number,
	organization_code,
	assembly_item_number,
	component_item_number,
	reference_designator
 From ILINK_ECO_BOM_REFDES_TEMP
 Where record_status = 'Validated';


 Begin

   /* Delete from the interface tables  */

    Delete From ENG_ENG_CHANGES_INTERFACE Where eng_changes_ifce_key like 'AGILE%';

    Delete From ENG_REVISED_ITEMS_INTERFACE Where eng_changes_ifce_key like 'AGILE%';     
    
    Delete From BOM_BILL_OF_MTLS_INTERFACE a
    Where a.transaction_type = 'NO_OP' and
          exists (Select 'x' from ILINK_ECO_ITEM_BOMS_TEMP b
                  where a.item_number = b.assembly_item_number);

    Delete From BOM_INVENTORY_COMPS_INTERFACE Where eng_changes_ifce_key like 'AGILE%';  

    Delete From BOM_SUB_COMPS_INTERFACE Where eng_changes_ifce_key like 'AGILE%';

    Delete From BOM_REF_DESGS_INTERFACE Where eng_changes_ifce_key like 'AGILE%'; 

   /* Update Statuses for records in the temp tables */

   For c_header in get_header_rec Loop

    Begin

    Update ILINK_ECOS_TRANSFERED
    Set process_flag = 'Y',
	processed_date = SYSDATE,  
	record_status = Decode(v_eco_header('ECO Status For '||'AGILE'||c_header.eco_number||c_header.organization_code),'S','Succeeded','E','Error'),
	error_message = trim(substr(error_message||v_eco_header('Error Message For ECO Header '||'AGILE'||c_header.eco_number||c_header.organization_code)||
						v_eco_header('Concatenated Message For '||'AGILE'||c_header.eco_number||c_header.organization_code),1,4000)),
	transfer_to_oracle = Decode(v_eco_header('ECO Status For '||'AGILE'||c_header.eco_number||c_header.organization_code),'S','YES',NULL)
    Where eco_number = c_header.eco_number and
	  organization_code = c_header.organization_code;

    Exception
     When OTHERS Then
     Update ILINK_ECOS_TRANSFERED
     Set process_flag = 'Y',
	 processed_date = SYSDATE,
	 record_status = 'Error'
     Where eco_number = c_header.eco_number and
	   organization_code = c_header.organization_code;
    End;

   End Loop;

   For c_assy in get_assy_rec Loop

    Begin

    Update ILINK_ECO_ITEM_REVISIONS_TEMP
    Set process_flag = 'Y',
	processed_date = SYSDATE,  
	record_status = Decode(v_aff_item('Assembly Status For '||'AGILE'||c_assy.eco_number||c_assy.organization_code||' '||c_assy.item_number),
			'S','Succeeded','W','Warning','Error')
    Where eco_number = c_assy.eco_number and
	  organization_code = c_assy.organization_code and
	  item_number = c_assy.item_number;

    Exception
     When OTHERS Then
	Update ILINK_ECO_ITEM_REVISIONS_TEMP
	Set process_flag = 'Y',
	    processed_date = SYSDATE
	Where eco_number = c_assy.eco_number and
	  organization_code = c_assy.organization_code and
	  item_number = c_assy.item_number;       
    End;

   End Loop;

   For c_prim_comp in get_comp_rec('P') Loop

    Begin

    Update ILINK_ECO_ITEM_BOMS_TEMP
    Set process_flag = 'Y',
	processed_date = SYSDATE,  
	record_status = Decode(v_bom_comp('Component Status For '||'AGILE'||c_prim_comp.eco_number||c_prim_comp.organization_code||' '||
				c_prim_comp.assembly_item_number||' '||c_prim_comp.component_item_number),'S','Succeeded','W','Warning','Error')
    Where eco_number = c_prim_comp.eco_number and
	  organization_code = c_prim_comp.organization_code and
	  assembly_item_number = c_prim_comp.assembly_item_number and
	  component_item_number = c_prim_comp.component_item_number and
	  nvl(attribute5,'P') = 'P';

   Exception
     When OTHERS Then
	Update ILINK_ECO_ITEM_BOMS_TEMP
	Set process_flag = 'Y',
	    processed_date = SYSDATE
	Where eco_number = c_prim_comp.eco_number and
	      organization_code = c_prim_comp.organization_code and
	      assembly_item_number = c_prim_comp.assembly_item_number and
	      component_item_number = c_prim_comp.component_item_number and
	      nvl(attribute5,'P') = 'P';	
    End;

   End Loop;

   For c_sub_comp in get_comp_rec('A') Loop

    Begin

    Update ILINK_ECO_ITEM_BOMS_TEMP
    Set process_flag = 'Y',
	processed_date = SYSDATE,  
	record_status = Decode(v_sub_comp('Substitute Component Status For '||'AGILE'||c_sub_comp.eco_number||c_sub_comp.organization_code||' '||
					c_sub_comp.assembly_item_number||' '||c_sub_comp.parent_comp_number||' '||
					c_sub_comp.component_item_number),'S','Succeeded','W','Warning','Error')
    Where eco_number = c_sub_comp.eco_number and
	  organization_code = c_sub_comp.organization_code and
	  assembly_item_number = c_sub_comp.assembly_item_number and
	  parent_comp_number = c_sub_comp.parent_comp_number and
	  component_item_number = c_sub_comp.component_item_number and
	  nvl(attribute5,'P') = 'A';

   Exception
    When OTHERS Then
	Update ILINK_ECO_ITEM_BOMS_TEMP
	Set process_flag = 'Y',
	    processed_date = SYSDATE  
	Where eco_number = c_sub_comp.eco_number and
	      organization_code = c_sub_comp.organization_code and
	      assembly_item_number = c_sub_comp.assembly_item_number and
	      parent_comp_number = c_sub_comp.parent_comp_number and
	      component_item_number = c_sub_comp.component_item_number and
	      nvl(attribute5,'P') = 'A';
    End;

   End Loop;

   For c_bom_rdes in get_rdes_rec Loop

    Begin

    Update ILINK_ECO_BOM_REFDES_TEMP
    Set process_flag = 'Y',
	processed_date = SYSDATE,  
	record_status = Decode(v_bom_rdes('Ref Des Status For '||'AGILE'||c_bom_rdes.eco_number||c_bom_rdes.organization_code||' '||
					c_bom_rdes.assembly_item_number||' '||
					c_bom_rdes.component_item_number||' '||
					c_bom_rdes.reference_designator),'S','Succeeded','W','Warning','Error')
    Where eco_number = c_bom_rdes.eco_number and
	  organization_code = c_bom_rdes.organization_code and
	  assembly_item_number = c_bom_rdes.assembly_item_number and
	  component_item_number = c_bom_rdes.component_item_number and
	  reference_designator = c_bom_rdes.reference_designator;

   Exception
    When OTHERS Then
	Update ILINK_ECO_BOM_REFDES_TEMP
	Set process_flag = 'Y',
	    processed_date = SYSDATE
	Where eco_number = c_bom_rdes.eco_number and
	      organization_code = c_bom_rdes.organization_code and
	      assembly_item_number = c_bom_rdes.assembly_item_number and
	      component_item_number = c_bom_rdes.component_item_number and
	      reference_designator = c_bom_rdes.reference_designator;	

    End;

   End Loop;


  Exception
   When Others then
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_POST_ECO_API_PROCESS is '||SQLERRM);


 End ILINK_POST_ECO_API_PROCESS;


End ILINK_ECO_INTERFACE_PKG;