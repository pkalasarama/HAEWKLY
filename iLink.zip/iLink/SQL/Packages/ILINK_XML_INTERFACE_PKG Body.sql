create or replace package body ILINK_XML_INTERFACE_PKG as

/*
REM +============================================================================================+
REM |Filename         :  BLD_XML_INTERFACE_PKG.pkb                   			 	             |
REM |                                                                                            |
REM |Copyright        : 2001-2013 CPG Solutions LLC - All Rights Reserved			             |
REM |                   All rights reserved:  This software/documentation contains proprietary   |
REM | 					information of CPG Solutions; it is provided under a license agreement 	 |
REM |					containing restrictions on use and disclosure and is also protected 	 |
REM | 					by copyright law.  Reverse engineering of the software is prohibited.    |
REM |                   					   	   	   	  	                                     |
REM |Description      : Package Body for parsing XML Files contains the following program Units	 |
REM |                   ILINK_XML_INT_MAIN      (Main process)    				                 |
REM |                   ILINK_XML_PARSE_FILES (Parse XML files into a Temporary table)		     |
REM |                   ILINK_XML_LOAD_DATA  (Load the parsed XML data into Ilink temp Tables)   |
REM |                   ILINK_XML_POST_LOAD (Perform Post Load activities)	 		             |
REM |                   ILINK_DATA_XREF  (Determine Translated Oracle Values for Agile Data)     |
REM |                   	 	 		  	  		  	   	                                     |
REM |                   					   	   	   	  	                                     |
REM |                                                                                            |
REM |Calling Program  : Concurrent Executable name is ILINKXMLINT                                |
REM |                                                                                            |
REM |Pre-requisites   : None									                                 |
REM |                   		 	  	 		  	 	   	                                     |
REM |                                                                                            |
REM |Post Processing  : 								 	                                     |
REM |                   	   			   			 		                                     |
REM |                                                                                            |
REM |                     									                                     |
REM |Code Based On iLink Release: 7.6.3								                             |
REM |                                             						                         |
REM |                                                                                            |
REM |Customer:  Haemonetics 14-OCT-13                                                       	 |
REM |                                                                                            |
REM |Customer Change History:                                                                    |
REM |------------------------                                                                    |
REM |Version  Date       Author         Remarks                                                  |
REM |-------  --------- --------------  ---------------------------------------------------------|
REM |1.0      14-OCT-13 CPG Solutions  	First draft Version for Customer branched from iLink,	 |
REM |                                   code base 7.6.0     			 		                 |
REM |1.1      05-SEP-14 K Gangisetty    Modified Code to filter BOMs for purchased parts	     |
REM |                            								                                 |
REM |1.2      15-DEC-15 K Gangisetty    Modified code to delete data from staging tables when a	 |
REM |                                   failed change order comes back from Agile		         |
REM |1.3      15-NOV-16	K Gangisetty    Modified substr with substrb for ECO Description         |
REM |                                  								                             |
REM |1.4      											                                         |
REM |                                                                                            |
REM |1.5      										 	                                         |
REM |                                    			                                             |
REM |1.6     											                                         |
REM |                                                                                            |
REM | Be sure to update the version number below with the latest version number reference above. |
REM |                                                                                            |
REM +============================================================================================+
*/

/* Declare Global Variables to hold values used across multiple procedures */

v_user_id 		Number := FND_GLOBAL.USER_ID();

procedure  ILINK_XML_INT_MAIN(x_retcode OUT VARCHAR2,
                              x_errbuff OUT VARCHAR2) is

/* Fetch Unprocessed files from the server */

Cursor get_xml_files is
select trim(file_name) file_name
from ILINK_XML_files
where parsed_date is NULL
order by file_name;

V_file_name   Varchar2(100);

 Begin


        /* Call the procedure to Parse XML files into a Temporary table */

	For c_xml_file in get_xml_files Loop

         v_file_name := c_xml_file.file_name;

         ILINK_XML_PARSE_FILES (v_file_name);

        /* Call the procedure to load the parsed XML data into Ilink temp Tables */

	 ILINK_XML_LOAD_DATA;

	End Loop;

	/* Call the procedure to Perform some post data load steps */

	 ILINK_XML_POST_LOAD;

	 Commit;

  Exception
   When others then
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_XML_INT_MAIN is '||SQLERRM);

 End ILINK_XML_INT_MAIN;



procedure ILINK_XML_PARSE_FILES ( p_file_name In varchar2 ) is


    v_clob  		clob;
    v_parser    	dbms_xmlparser.Parser;
    v_doc       	dbms_xmldom.domdocument;
    v_length		Number;
    v_attr_length	Number;
    v_nodelist		dbms_xmldom.DOMNodeList;
    v_tag_node 		dbms_xmldom.DOMNode;
    v_parent_node	dbms_xmldom.DOMNode;
    v_Value_node	dbms_xmldom.DOMNode;
    v_tag		Varchar2(500);
    v_parent_tag	Varchar2(5000);
    v_parent_tag1	Varchar2(500);
    v_value 		Varchar2(4000);
    v_element		dbms_xmldom.DOMElement;
    v_node_map		dbms_xmldom.DOMNamedNodeMap;
    v_attr_node		dbms_xmldom.DOMNode;
    v_attr_name 	Varchar2(500);
    v_attr_val 		Varchar2(4000);
    v_count		number := 0;
    v_ptag		Varchar2(5000);

 Begin

        v_parser := dbms_xmlparser.newParser;	-- Initialize the parser

	dbms_xmlparser.setBaseDir(v_parser,'ILINK_UTL_DIR');

        -- dbms_xmlparser.parse(v_parser,p_file_name);  -- Begin parsing the file

        dbms_xmlparser.parse(v_parser,substr(p_file_name,instr(p_file_name,'/',-1,1)+1));  -- Begin parsing the file

        v_doc   := dbms_xmlparser.getDocument(v_parser);

        v_nodelist := dbms_xmldom.getElementsByTagName(v_doc,'*');

        v_length :=dbms_xmldom.getLength(v_nodelist);


        /* loop through all the Elements in the file */

	For i in 0..v_length-1 loop

	 v_tag_node := dbms_xmldom.item(v_nodelist, i);
	 v_element := dbms_xmldom.makeElement(v_tag_node);

	 v_tag := dbms_xmldom.getNodeName(v_tag_node);		-- The child tag name
 	 v_parent_node := dbms_xmldom.getParentNode(v_tag_node);
 	 v_ptag := v_parent_tag;
	 v_parent_tag := dbms_xmldom.getNodeName(v_parent_node);	-- The Parent tag name

	 /* If v_parent_tag = 'ProductLines' Then
	  v_parent_tag := v_ptag||v_parent_tag;
	 End If; */

	 /* If v_parent_tag = 'Multilist01' Then
	  v_parent_tag := v_ptag||v_parent_tag;
	 End If; */

	 If v_parent_tag = 'Multilist02' Then
	  v_parent_tag := v_ptag||v_parent_tag;
	 End If;

	 If v_parent_tag = 'Multilist03' Then
	  v_parent_tag := v_ptag||v_parent_tag;
	 End If;

         v_Value_node := dbms_xmldom.getFirstChild(v_tag_node);

         v_value := NULL;

	  If not dbms_xmldom.IsNull(v_value_node) then

	   v_value := dbms_xmldom.getNodeValue(v_value_node);	-- The child tag value

    	  End If;

	v_count := v_count + 1;

	Insert into ILINK_XML_STAGE (id,file_name,tag_name,parent_tag_name,TAG_VALUE,full_tag_name)
	     Values (v_count,p_file_name,v_tag,substr(v_parent_tag,1,500),v_value,substr(v_parent_tag||v_tag,1,1000));

	v_parent_tag1 := dbms_xmldom.getTagName(v_element);

        /* get all attributes of element */

	v_node_map := dbms_xmldom.getAttributes(v_tag_node);

        If (dbms_xmldom.isNull(v_node_map) = FALSE) then

         v_attr_length := dbms_xmldom.getLength(v_node_map);

         /* loop through attributes */

          For j in 0..v_attr_length-1 loop

	   v_count := v_count + 1;
           v_attr_node := dbms_xmldom.item(v_node_map, j);
           v_attr_name := dbms_xmldom.getNodeName(v_attr_node);	-- Attribute Name
           v_attr_val := dbms_xmldom.getNodeValue(v_attr_node);	-- Attribute Value

           Insert into ILINK_XML_STAGE (id,file_name,tag_name,parent_tag_name,TAG_VALUE,full_tag_name)
              Values (v_count,p_file_name,v_attr_name,v_parent_tag1,v_attr_val,v_parent_tag1||v_attr_name);

         End loop;

        End If;

       End loop ;

	/* Update the file to indicate it has been parsed */

	Update ILINK_XML_FILES
	set parsed_date = SYSDATE
	Where file_name = p_file_name and parsed_date is NULL;

	dbms_xmlparser.freeParser(v_parser);		-- Release the parser
     	dbms_xmldom.freeDocument(v_doc);

	commit;

 Exception

  When Others Then

   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_XML_PARSE_FILES is '||SQLERRM);

   Update ILINK_XML_FILES
   set processed_flag = 'E',
       error_message = 'Parsing Error',
       parsed_date = SYSDATE,
       processed_date = SYSDATE
   Where file_name = p_file_name and parsed_date is NULL;

End ILINK_XML_PARSE_FILES;



procedure ILINK_XML_LOAD_DATA is

 /* Fetch All Unprocessed Flies */

 Cursor get_unprocessed_files is
 Select file_name
 from ILINK_XML_FILES
 Where nvl(processed_flag,'N') = 'N' and
       parsed_date is NOT NULL and processed_date is NULL
 order by parsed_Date;

 /* Determine total records for the file */

 Cursor get_total_count(p_file_name In varchar2) is
 select count(*) v_count from ILINK_XML_STAGE
 where  file_name = p_file_name;

 /* Starting Data Position Cursor for ECO Header */

 Cursor get_eco_sid (p_file_name In varchar2,p_eco_string1 In Varchar2,p_eco_string2 In Varchar2) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
 	(full_tag_name = p_eco_string1 or full_tag_name = p_eco_string2);

 /* Ending Data Position Cursor for ECO Header */

 Cursor get_eco_eid (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
 	(full_tag_name = p_string1 or full_tag_name = p_string2);

 /* Extract Data between pointers For ECO Header, Affected Item, BOM Redlines, Part, BOM and MPN */

 Cursor get_data (p_file_name In varchar2,p_sid number,p_eid number) is
 select id,full_tag_name whole_tag,tag_value from ILINK_XML_STAGE
 where file_name = p_file_name  and
       (id between p_sid and p_eid)
 Order by id;

 /* Determine number of Affected Items, Parts */

 Cursor get_item_count(p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2) is
 select count(*) v_count from ILINK_XML_STAGE
 where 	file_name = p_file_name and
 	(full_tag_name = p_string1 or full_tag_name = p_string2);

 /* Staring Data Position Cursor for Affected Items, Parts  */

 Cursor get_start_id (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2,p_num In number) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	id > p_num and
	(full_tag_name = p_string1 or full_tag_name = p_string2)
 order by id;

 /* Ending Data Position Cursor for Affected Items */

  Cursor get_aff_end_id (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2,p_string3 In Varchar2,p_num In number) is
  select id from ILINK_XML_STAGE
  where file_name = p_file_name and
 	id > p_num and
 	(full_tag_name = p_string1 or full_tag_name = p_string2 or full_tag_name = p_string3)
 order by id;

 /* Ending Data Position Cursor for Manufacturers */

 Cursor get_end_id (p_file_name In varchar2,p_string In varchar2,p_num In number) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	id > p_num and
	full_tag_name = p_string
 order by id;

/* Ending Data Position Cursor for Parts and Documents */

 Cursor get_parts_end_id (p_file_name In varchar2,p_string1 In varchar2,p_string2 In Varchar2,p_string3 In Varchar2,p_num In number) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	id > p_num and
	(full_tag_name = p_string1 or full_tag_name = p_string2 or full_tag_name = p_string3)
 order by id;

 /* Determine number of Redlines for an Affected Item and BOMs for a part */

 Cursor get_bom_count(p_file_name In varchar2,p_sid number,p_eid number,p_string In Varchar2) is
 select count(*) v_count from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	(id between p_sid and p_eid) and
	full_tag_name =  p_string;

 /* Staring Data Position Cursor for Redlined Items and BOMs */

 Cursor get_bom_start_id (p_file_name In varchar2,p_string In Varchar2,p_aff_num In number,p_num In number) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	id > p_aff_num and
	id > p_num and
	full_tag_name = p_string
 order by id;

 /* Ending Data Position Cursor for redlined BOMs */

  Cursor get_bomred_end_id (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2,p_string3 In Varchar2,p_num In number) is
  select id from ILINK_XML_STAGE
  where file_name = p_file_name and
 	id > p_num and
 	(full_tag_name = p_string1 or full_tag_name = p_string2 or full_tag_name = p_string3)
 order by id;

 /* Ending Data Position Cursor for redlined BOMs */

 Cursor get_bom_end_id (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2,p_num In number) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	id > p_num and
	(full_tag_name = p_string1 or full_tag_name = p_string2)
 order by id;

/* Determine number of BOMs for a part and document*/

 Cursor get_bom_count1(p_file_name In varchar2,p_sid number,p_eid number,p_string1 In Varchar2,p_string2 In Varchar2) is
 select count(*) v_count from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	(id between p_sid and p_eid) and
	(full_tag_name =  p_string1 or full_tag_name =  p_string2);

/* Staring Data Position Cursor for BOMs */

  Cursor get_bom_start_id1 (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2,p_aff_num In number,p_num In number) is
  select id from ILINK_XML_STAGE
  where file_name = p_file_name and
 	id > p_aff_num and
 	id > p_num and
 	(full_tag_name = p_string1 or full_tag_name = p_string2)
  order by id;

/* Ending Data Position Cursor for BOMs of parts and documents */

  Cursor get_bom_end_id1 (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2,p_string3 In Varchar2,p_string4 In Varchar2,p_num In number) is
  select id from ILINK_XML_STAGE
  where file_name = p_file_name and
 	id > p_num and
 	(full_tag_name = p_string1 or full_tag_name = p_string2 or full_tag_name = p_string3 or full_tag_name = p_string4)
  order by id;


 /* Ending Data Position Cursor for redlined MPNs */

   Cursor get_mpn_end_id (p_file_name In varchar2,p_string1 In Varchar2,p_string2 In Varchar2,p_string3 In Varchar2,
   				p_string4 In Varchar2,p_num In number) is
   select id from ILINK_XML_STAGE
   where file_name = p_file_name and
  	id > p_num and
  	(full_tag_name = p_string1 or full_tag_name = p_string2 or full_tag_name = p_string3 or full_tag_name = p_string4)
  order by id;


  /* Staring Data Position Cursor for Old snapshot of Redlined Items and BOMs */

 Cursor get_bom_new_start_id (p_file_name In varchar2,p_aff_num In number,p_num In number,p_string IN Varchar2) is
 select id from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	id > p_aff_num and
	id > p_num and
	full_tag_name = p_string
 order by id;


 /* Fetch the value of an ID */

 Cursor get_id_value (p_file_name In varchar2,p_id In number) is
 select tag_value from ILINK_XML_STAGE
 where 	file_name = p_file_name and
	id = p_id;

/* Determine if the ECO exists in I-link's temp tables */

 Cursor get_eco_no_intf (p_eco_no In Varchar2) is
 Select 'Y'
 From ILINK_ECOS_TRANSFERED
 Where eco_number = p_eco_no;


/* Determine if the ECO exists in Oracle */

 Cursor get_eco_no_orcl (p_eco_no In Varchar2) is
 Select 'Y'
 From ENG_ENGINEERING_CHANGES
 Where change_notice = p_eco_no;

 /* Determine Item Status from Affected Item */

 Cursor get_item_status(p_eco_no In Varchar2,p_item_no In Varchar2) is
 Select lifecycle_status
 From ILINK_ECO_ITEM_REVISIONS_TEMP
 Where eco_number = p_eco_no and
       item_number = p_item_no;



 v_total_count		Number;
 v_tag_value 		varchar(2000);

 v_eco_header_sid	Number;
 v_eco_header_eid	Number;
 v_eco_number		Varchar2(10);
 v_eco_description	Varchar2(2000);
 v_eco_type		Varchar2(80);
 v_eco_originator	Varchar2(150);
 v_eco_reasoncode	Varchar2(2000);
 v_eco_dateoriginated	Date;
 v_eco_datereleased	Date;
 v_eco_exists_intf	Varchar2(1) := 'N';
 v_eco_exists_orcl	Varchar2(1) := 'N';


 v_aff_item_count	Number;
 v_aff_item_sid		Number;
 v_aff_item_eid		Number;
 v_aff_item_num		Number;
 v_aff_end_string1	Varchar2(100);
 v_aff_end_string2	Varchar2(100);
 v_aff_end_string3	Varchar2(100);
 v_assembly_item 	Varchar2(40);
 v_old_rev		Varchar2(30);
 v_new_rev		Varchar2(30);
 v_effectivity_date	Date;
 v_old_status		Varchar2(150);
 v_new_status		Varchar2(150);
 v_agile_rev		Varchar2(150);

 v_redline_count	Number;
 v_red_item_sid		Number;
 v_red_item_eid		Number;
 v_new_red_item_sid	Number;
 v_red_num		Number;
 v_red_end_string1	Varchar2(100);
 v_red_end_string2	Varchar2(100);
 v_red_end_string3	Varchar2(100);
 v_component_item	Varchar2(40);
 v_comp_qty		Number;
 v_sys_acd		Varchar2(1);
 v_change_flag		Varchar2(10);
 v_comp_find_num	Number;
 v_comp_item_type	Varchar2(150);
 v_old_component_item	Varchar2(40);
 v_old_comp_qty		Number;
 v_old_comp_find_num	Number;
 v_old_comp_item_type	Varchar2(150);
 v_old_comp_lifecycle	Varchar2(150);
 v_comp_lifecycle	Varchar2(150);
 v_old_comp_oraitem	Varchar2(150);
 v_comp_oraitem		Varchar2(150);

 v_mpn_redline_count	Number;
 v_mpn_item_sid		Number;
 v_mpn_item_eid		Number;
 v_mpn_red_num		Number;
 v_mpn_end_string1	Varchar2(100);
 v_mpn_end_string2	Varchar2(100);
 v_mpn_end_string3	Varchar2(100);
 v_mpn_end_string4	Varchar2(100);
 v_new_mpn_item_sid	Number;
 v_mpn_sys_acd		Varchar2(1);
 v_old_mpn_item		Varchar2(150);
 v_old_mfg_name		Varchar2(240);
 v_old_mpn_status	Varchar2(150);
 v_old_mpn_asl_flag	Varchar2(30);
 v_mpn_count		Number;
 v_mpn_item		Varchar2(150);
 v_mfg_name		Varchar2(240);
 v_mpn_sid		Number;
 v_mpn_eid		Number;
 v_mpn_num		Number;
 v_mpn_num1		Number;
 v_mpn_status		Varchar2(150);
 v_mfg_num		Varchar2(30);

 v_parts_count		Number;
 v_parts_sid		Number;
 v_parts_eid		Number;
 v_parts_num		Number;
 v_parts_end_string1	Varchar2(100);
 v_parts_end_string2	Varchar2(100);
 v_parts_end_string3	Varchar2(100);
 v_parts_end_string	Varchar2(100);
 v_item_number 		Varchar2(40);
 v_item_description	Varchar2(240);
 v_item_status		Varchar2(30);
 v_item_status1		Varchar2(30);
 v_uom			Varchar2(30);
 v_lot_serial_ctrl	Varchar2(100);
 v_shelf_life_days	Number;
 v_oracle_item		Varchar2(10);
 v_erp_product_line	Varchar2(100);
 v_erp_product_type	Varchar2(100);
 v_erp_product_sub	Varchar2(100);
 v_erp_platform		Varchar2(100);
 v_tax_code_dff		Varchar2(240);
 v_inv_cat_code		Varchar2(100);
 v_template		Varchar2(30);
 v_makebuy_template	Varchar2(30);
 v_obsolete_template	Varchar2(30);
 v_mfg_orgs		Varchar2(1000);
 v_non_mfg_orgs		Varchar2(1000);
 v_fast_pack		Varchar2(240);
 v_commodity_code	Varchar2(100);
 v_service_repair	Varchar2(10);
 v_service_install	Varchar2(10);
 v_service_return	Varchar2(10);
 v_service_category	Varchar2(100);
 v_service_request	Varchar2(100);
 v_user_item_type	Varchar2(100);
 v_ship_qty		Number;
 v_revision		Varchar2(3);
 v_part_type		Varchar2(100);
 v_item_type		Varchar2(15);
 v_item_cost		Number;
 v_item_type_cat	Varchar2(100);

 v_bom_count		Number;
 v_bom_item_sid		Number;
 v_bom_item_eid		Number;
 v_bom_num		Number;
 v_bom_end_string1	Varchar2(100);
 v_bom_end_string2	Varchar2(100);
 v_bom_end_string3	Varchar2(100);
 v_bom_end_string4	Varchar2(100);
 v_bom_component_item	Varchar2(40);
 v_bom_comp_qty		Number;
 v_bom_find_num		Number;
 v_bom_item_type	Varchar2(150);
 v_bom_lifecycle	Varchar2(150);
 v_bom_oraitem		Varchar2(150);

 v_timezone		Varchar2(30) := ILINK_DATA_XREF('Default Time Zone',NULL,NULL,NULL,NULL);
 v_timezone_name	Varchar2(30);

 v_file_name		Varchar2(100);


Begin


 /* Deterine the current time zone */

 Select TO_CHAR(FROM_TZ(sys_extract_utc(systimestamp),'GMT') AT TIME ZONE to_char(v_timezone),'TZD')
 into v_timezone_name From Dual;

 For c_file in get_unprocessed_files loop	-- File Processing

  v_file_name := c_file.file_name;

 /* Determine total records for the file */

 v_total_count := 0;
 open get_total_count(c_file.file_name);
 fetch get_total_count into v_total_count;
 close get_total_count;

 /* Process ECO Header */

  v_eco_header_sid	:= NULL;
  v_eco_header_eid	:= NULL;
  v_eco_number		:= NULL;
  v_eco_description	:= NULL;
  v_eco_type		:= NULL;
  v_eco_originator	:= NULL;
  v_eco_reasoncode	:= NULL;
  v_eco_dateoriginated	:= NULL;
  v_eco_datereleased	:= NULL;

  /* Determine ECO Header starting position */

  open get_eco_sid (c_file.file_name,'ChangeOrdersCoverPage','ManufacturerOrdersCoverPage');
  fetch get_eco_sid into v_eco_header_sid;
  close get_eco_sid;

  /* Determine ECO Header ending position */

  open get_eco_eid (c_file.file_name,'ChangeOrdersAffectedItems','ManufacturerOrdersAffectedItems');
  fetch get_eco_eid into v_eco_header_eid;
  close get_eco_eid;
  If v_eco_header_eid is NULL Then
   v_eco_header_eid := v_total_count;
  End If;

 /* Extract ECO header Data */

  For c_ecoh_data in get_data (c_file.file_name,v_eco_header_sid+1,v_eco_header_eid-1) Loop

   If c_ecoh_data.whole_tag = 'CoverPageNumber' Then
    v_eco_number := c_ecoh_data.tag_value;
   ElsIf c_ecoh_data.whole_tag in ('CoverPageDescription','CoverPageDescriptionOfChange') Then
    v_eco_description := substrb(c_ecoh_data.tag_Value,1,1950);					-- Modified substr with substrb on 11/15/2016
   ElsIf c_ecoh_data.whole_tag = 'CoverPageChangeType' Then
    v_eco_type := nvl(ILINK_DATA_XREF('ECO Type',c_ecoh_data.tag_Value,NULL,NULL,NULL),c_ecoh_data.tag_Value);
   ElsIf c_ecoh_data.whole_tag = 'CoverPageOriginator' Then
    v_eco_originator := c_ecoh_data.tag_value;
   /* ElsIf c_ecoh_data.whole_tag = 'CoverPageReasonCode' Then
    v_eco_reasoncode := nvl(ILINK_DATA_XREF('ECO Reason Code',c_ecoh_data.tag_Value,NULL,NULL,NULL),c_ecoh_data.tag_Value);*/
   ElsIf c_ecoh_data.whole_tag = 'CoverPageDateOriginated' Then
    v_eco_dateoriginated := new_time(to_date(REPLACE(REPLACE(c_ecoh_data.tag_value,'Z',NULL),'T',NULL),'YYYY-MM-DDHH24:MI:SS'),'GMT',v_timezone_name);
   Elsif c_ecoh_data.whole_tag = 'CoverPageDateReleased' Then
    v_eco_datereleased := new_time(to_date(REPLACE(REPLACE(c_ecoh_data.tag_value,'Z',NULL),'T',NULL),'YYYY-MM-DDHH24:MI:SS'),'GMT',v_timezone_name);
   End If;

  End Loop;	-- End ECO Header Data extract

 /* Determine if the ECO exists in the temp tables */

 open get_eco_no_intf(v_eco_number);
 fetch get_eco_no_intf into v_eco_exists_intf;
 close get_eco_no_intf;

 /* Determine if the ECO exists in the temp tables */

  open get_eco_no_orcl(v_eco_number);
  fetch get_eco_no_orcl into v_eco_exists_orcl;
  close get_eco_no_orcl;
  
  -- Added the below on 12/15/2015
  
  If nvl(v_eco_exists_intf,'N') = 'Y' Then		-- Change Order exists in iLink staging tables, so delete them first				
  
   Delete From ILINK_ECOS_TRANSFERED
   Where eco_number = v_eco_number;
   
   Delete From ILINK_ECO_ITEM_REVISIONS_TEMP
   Where eco_number = v_eco_number;
   
   Delete From ILINK_ECO_ITEM_BOMS_TEMP
   Where eco_number = v_eco_number;
   
   Delete From ILINK_MTL_ITEMS_INT_TEMP
   Where eco_number = v_eco_number;
   
  End If;						-- End 12/15/2015

 -- If nvl(v_eco_exists_intf,'N') = 'N' and nvl(v_eco_exists_orcl,'N') = 'N' Then -- ECO Does not exists in I-link tables Or Oracle so proceed with inserting the ECO	-- Commented out on 12/15/2015
 
 If nvl(v_eco_exists_orcl,'N') = 'N' Then		-- Added on 12/15/2015

  Insert into ILINK_ECOS_TRANSFERED
	(eco_number,
	description,
	originator,
	originated_date,
	eco_type,
	released_date,
	attribute1,
	approval_status,
	record_status,
	process_flag,
	organization_code,
	creation_date,
	created_by,
	last_update_date,
	last_updated_by)
  Values
	(v_eco_number,
	v_eco_description,
	v_eco_originator,
	v_eco_dateoriginated,
	v_eco_type,
	nvl(v_eco_datereleased,v_eco_dateoriginated),				-- 02/10/2014
	ILINK_DATA_XREF('Default ECO Type',NULL,NULL,NULL,NULL),
	ILINK_DATA_XREF('Default ECO Approval Status',NULL,NULL,NULL,NULL),
	'Unprocessed',
	'N',
	'ZZZ',
	SYSDATE,
	v_user_id,
	SYSDATE,
	v_user_id);

 /* Process Affected Items */

  /* Determine number of Affected Items */

  v_aff_item_count := 0;
  open get_item_count(c_file.file_name,'ChangeOrdersAffectedItems','ManufacturerOrdersAffectedItems');
  fetch get_item_count into v_aff_item_count;
  close get_item_count;

  If v_aff_item_count > 0 Then
   For i in 1 .. v_aff_item_count loop	-- Affected Items Section Begins

    v_assembly_item 	:= NULL;
    v_old_rev		:= NULL;
    v_new_rev		:= NULL;
    v_effectivity_date	:= NULL;
    v_old_status	:= NULL;
    v_new_status	:= NULL;
    v_agile_rev		:= NULL;

 /* Determine Affected Items starting position */

  v_aff_item_sid := NULL;
  open get_start_id (c_file.file_name,'ChangeOrdersAffectedItems','ManufacturerOrdersAffectedItems',nvl(v_aff_item_num,0));
  fetch get_start_id into v_aff_item_sid;
  close get_start_id;

  v_aff_item_num := v_aff_item_sid;

  /* Determine Affected Items Ending position */

  v_aff_end_string1 := NULL;
  v_aff_end_string2 := NULL;
  v_aff_end_string3 := NULL;
  If i = v_aff_item_count Then
   v_aff_end_string1 := 'AgileDataManufacturerParts';
   v_aff_end_string2 := 'AgileDataParts';
   v_aff_end_string3 := 'AgileDataDocuments';
  ElsIf i != v_aff_item_count Then
   v_aff_end_string1 := 'ChangeOrdersAffectedItems';
   v_aff_end_string2 := 'ManufacturerOrdersAffectedItems';
   v_aff_end_string3 := NULL;
  End If;

  v_aff_item_eid := NULL;
  open get_aff_end_id (c_file.file_name,v_aff_end_string1,v_aff_end_string2,v_aff_end_string3,v_aff_item_sid);
  fetch get_aff_end_id into v_aff_item_eid;
  close get_aff_end_id;

  /* Extract Affected Item data */

   For c_eco_data in get_data (c_file.file_name,v_aff_item_sid+1,nvl(v_aff_item_eid,v_total_count)) Loop

    If c_eco_data.whole_tag = 'AffectedItemsItemNumber' Then
     v_assembly_item := c_eco_data.tag_value;
    ElsIf c_eco_data.whole_tag = 'AffectedItemsOldRev' Then
     v_old_rev := trim(substr(c_eco_data.tag_value,1,3));
    ElsIf c_eco_data.whole_tag = 'AffectedItemsNewRev' Then
     v_new_rev := trim(substr(c_eco_data.tag_value,1,3));
     v_agile_rev := trim(c_eco_data.tag_value);
    ElsIf c_eco_data.whole_tag = 'AffectedItemsEffectiveDate' Then
     v_effectivity_date := new_time(to_date(REPLACE(REPLACE(c_eco_data.tag_value,'Z',NULL),'T',NULL),'YYYY-MM-DDHH24:MI:SS'),'GMT',v_timezone_name);
    ElsIf c_eco_data.whole_tag = 'AffectedItemsOldLifecyclePhase' Then
     v_old_status := nvl(ILINK_DATA_XREF('Item Status',c_eco_data.tag_value,NULL,NULL,NULL),c_eco_data.tag_value);	-- 02/10/2014
    ElsIf c_eco_data.whole_tag = 'AffectedItemsLifecyclePhase' Then
     v_new_status := nvl(ILINK_DATA_XREF('Item Status',c_eco_data.tag_value,NULL,NULL,NULL),c_eco_data.tag_value);	-- 02/10/2014
    End If;

   End Loop;	-- End Affected Items Data extract

   Insert into ILINK_ECO_ITEM_REVISIONS_TEMP
	(eco_number,
	item_number,
	new_revision,
	old_revision,
	lifecycle_status,
	attribute1,
	effective_date_from,
	attribute2,
	record_status,
	process_flag,
	organization_code)
   Values
	(v_eco_number,
	v_assembly_item,
	v_new_rev,
	v_old_rev,
	v_new_status,
	v_old_status,
	nvl(v_effectivity_date,to_date(to_char(SYSDATE,'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS')),
	v_agile_rev,
	'Unprocessed',
	'N',
	'ZZZ');


  /* Process BOM Redlines */

  /* Determine number of BOM Redlines for an Affected Item */

  v_redline_count := 0;
  open get_bom_count(c_file.file_name,v_aff_item_sid,v_aff_item_eid,'RedlinesRedlinedBOMRow');
  fetch get_bom_count into v_redline_count;
  close get_bom_count;

  If v_redline_count > 0 Then	-- BOM Redlines exist

   for j in 1..v_redline_count Loop	-- BOM Redline Section Begins

     v_component_item	:= NULL;
     v_comp_qty		:= NULL;
     v_sys_acd		:= NULL;
     v_change_flag	:= NULL;
     v_comp_find_num	:= NULL;
     v_comp_item_type	:= NULL;
     v_comp_lifecycle	:= NULL;
     v_comp_oraitem	:= NULL;


     v_old_component_item	:= NULL;
     v_old_comp_qty		:= NULL;
     v_old_comp_find_num	:= NULL;
     v_old_comp_item_type	:= NULL;
     v_old_comp_lifecycle	:= NULL;
     v_old_comp_oraitem		:= NULL;


     /* Determine BOM Redline starting position */

     v_red_item_sid := NULL;
     open get_bom_start_id (c_file.file_name,'RedlinesRedlinedBOMRow',v_aff_item_sid,nvl(v_red_num,v_aff_item_sid));
     fetch get_bom_start_id into v_red_item_sid;
     close get_bom_start_id;

     v_red_num := v_red_item_sid;

     /* Determine BOM Redline Ending position */

     v_red_end_string1 := NULL;
     v_red_end_string2 := NULL;
     If j = v_redline_count Then
      v_red_end_string1 := 'AgileDataParts';
      v_red_end_string2 := 'AgileDataManufacturerParts';
      v_red_end_string3 := 'ChangeOrdersAffectedItems';
     ElsIf j != v_redline_count Then
      v_red_end_string1 := 'RedlinesRedlinedBOMRow';
      v_red_end_string2 := NULL;
      v_red_end_string3 := NULL;
     End If;

     v_red_item_eid := NULL;
     open get_bomred_end_id (c_file.file_name,v_red_end_string1,v_red_end_string2,v_red_end_string3,v_red_item_sid);
     fetch get_bomred_end_id into v_red_item_eid;
     close get_bomred_end_id;

     /* Extract Redline Data */
     For c_ps_data in get_data (c_file.file_name,v_red_item_sid,v_red_item_eid) Loop

       If c_ps_data.whole_tag = 'RedlinedBOMRowRedlineAction' Then
        Select decode(c_ps_data.tag_value,'Added','A','Changed','C','Deleted','D','X') into v_sys_acd from dual;
       End If;

      If v_sys_acd = 'C' Then

	v_new_red_item_sid := NULL;

	 /* Determine Staring Data Position Cursor for OLD snapshot of BOM Redline */

        open get_bom_new_start_id (c_file.file_name,v_aff_item_sid,v_red_item_sid,'RedlinedBOMRowRedlinedBOMRowPrevious');
	fetch get_bom_new_start_id into v_new_red_item_sid;
	close get_bom_new_start_id;

	/* Extract BOM Redlines OLD Data */

	If c_ps_data.id >= v_new_red_item_sid Then

      		If c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemNumber' Then
		 v_old_component_item := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousQty' Then
       		 v_old_comp_qty := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousFindNum' Then
       		 v_old_comp_find_num := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemType' Then
       		 v_old_comp_item_type := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemLifecyclePhase' Then
       		 v_old_comp_lifecycle := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemList19' Then
       		 v_old_comp_oraitem := c_ps_data.tag_Value;
		End If;		-- End Redlines OLD Data extract


	/* Extract BOM redline NEW Data */

	ElsIf c_ps_data.id < v_new_red_item_sid Then

      		If c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemNumber' Then
		 v_component_item := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentQty' Then
       		 v_comp_qty := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentFindNum' Then
       		 v_comp_find_num := c_ps_data.tag_Value;
       		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemType' Then
       		 v_comp_item_type := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemLifecyclePhase' Then
       		 v_comp_lifecycle := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemList19' Then
       		 v_comp_oraitem := c_ps_data.tag_Value;
       		End If;			-- End Redlines New Data extract

        End If;

     ElsIf v_sys_acd = 'A' Then

	/* Extract BOM redline NEW Data */

      		If c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemNumber' Then
		 v_component_item := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentQty' Then
       		 v_comp_qty := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentFindNum' Then
       		 v_comp_find_num := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemType' Then
       		 v_comp_item_type := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemLifecyclePhase' Then
       		 v_comp_lifecycle := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowCurrentItemList19' Then
       		 v_comp_oraitem := c_ps_data.tag_Value;
       		End If;	 	-- End BOM Redlines New Data extract

     ElsIf v_sys_acd = 'D' Then

	/* Extract BOM redline OLD Data */

      		If c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemNumber' Then
		 v_old_component_item := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousQty' Then
       		 v_old_comp_qty := c_ps_data.tag_Value;
      		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousFindNum' Then
       		 v_old_comp_find_num := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemType' Then
       		 v_old_comp_item_type := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemLifecyclePhase' Then
       		 v_old_comp_lifecycle := c_ps_data.tag_Value;
		ElsIf c_ps_data.whole_tag = 'RedlinedBOMRowPreviousItemList19' Then
       		 v_old_comp_oraitem := c_ps_data.tag_Value;
       		End If;			-- End BOM Redlines OLD Data extract

     End If;

     End Loop;  -- End BOM redlines data extract

      If v_sys_acd = 'C' Then

        Insert into ILINK_ECO_ITEM_BOMS_TEMP
	 	(eco_number,
		assembly_item_number,
		assembly_item_revision,
		component_item_number,
		quantity,
		agile_sys_acd,
		find_number,
		attribute1,
		attribute2,
		attribute3,
		attribute4,
		attribute5,
		record_status,
		process_flag,
		organization_code)
       Values
       		(v_eco_number,
		v_assembly_item,
		v_new_rev,
		v_old_component_item,
	 	v_old_comp_qty,
		'D',
		v_old_comp_find_num,
		v_old_comp_item_type,
		v_old_comp_find_num,
		v_old_comp_oraitem,
		v_old_comp_lifecycle,
		'P',
		'Unprocessed',
		'N',
		'ZZZ');


	Insert into ILINK_ECO_ITEM_BOMS_TEMP
	 	(eco_number,
		assembly_item_number,
		assembly_item_revision,
		component_item_number,
		quantity,
		agile_sys_acd,
		find_number,
		attribute1,
		attribute2,
		attribute3,
		attribute4,
		attribute5,
		record_status,
		process_flag,
		organization_code)
        Values
        	(v_eco_number,
		v_assembly_item,
		v_new_rev,
		nvl(v_component_item,v_old_component_item),
	 	nvl(v_comp_qty,v_old_comp_qty),
		'A',
		nvl(v_comp_find_num,v_old_comp_find_num),
		nvl(v_comp_item_type,v_old_comp_item_type),
		v_old_comp_find_num,
		nvl(v_comp_oraitem,v_old_comp_oraitem),
		nvl(v_comp_lifecycle,v_old_comp_lifecycle),
		'P',
		'Unprocessed',
		'N',
		'ZZZ');

       ElsIf v_sys_acd = 'A' Then

	Insert into ILINK_ECO_ITEM_BOMS_TEMP
	 	(eco_number,
		assembly_item_number,
		assembly_item_revision,
		component_item_number,
		quantity,
		agile_sys_acd,
		find_number,
		attribute1,
		attribute2,
		attribute3,
		attribute4,
		attribute5,
		record_status,
		process_flag,
		organization_code)
	Values
		(v_eco_number,
		v_assembly_item,
		v_new_rev,
		v_component_item,
		v_comp_qty,
		'A',
		v_comp_find_num,
		v_comp_item_type,
		v_old_comp_find_num,
		v_comp_oraitem,
		v_comp_lifecycle,
		'P',
		'Unprocessed',
		'N',
		'ZZZ');

      ElsIf v_sys_acd = 'D' Then

	Insert into ILINK_ECO_ITEM_BOMS_TEMP
	 	(eco_number,
		assembly_item_number,
		assembly_item_revision,
		component_item_number,
		quantity,
		agile_sys_acd,
		find_number,
		attribute1,
		attribute2,
		attribute3,
		attribute4,
		attribute5,
		record_status,
		process_flag,
		organization_code)
	Values
		(v_eco_number,
		v_assembly_item,
		v_new_rev,
		v_old_component_item,
		v_old_comp_qty,
		'D',
		v_old_comp_find_num,
		v_old_comp_item_type,
		v_old_comp_find_num,
		v_old_comp_oraitem,
		v_old_comp_lifecycle,
		'P',
		'Unprocessed',
		'N',
		'ZZZ');

      End If;

    End Loop;  -- BOM Redlines Section Ends

   End If;


   /* Process MPN/ASL Redlines

  -- Determine number of MPN/ASL Redlines for an Affected Item

  v_mpn_redline_count := 0;
  open get_bom_count(c_file.file_name,v_aff_item_sid,v_aff_item_eid,'RedlinesRedlinedAMLRow');
  fetch get_bom_count into v_mpn_redline_count;
  close get_bom_count;

  If v_mpn_redline_count > 0 Then	-- MPN Redlines exist

   for j in 1..v_mpn_redline_count Loop	-- MPN Redline Section Begins

     v_mpn_item			:= NULL;
     v_mfg_name			:= NULL;
     v_mpn_status		:= NULL;

     v_old_mpn_item		:= NULL;
     v_old_mfg_name		:= NULL;
     v_old_mpn_status		:= NULL;


     -- Determine MPN Redline's starting position

     v_mpn_item_sid := NULL;
     open get_bom_start_id (c_file.file_name,'RedlinesRedlinedAMLRow',v_aff_item_sid,nvl(v_mpn_red_num,v_aff_item_sid));
     fetch get_bom_start_id into v_mpn_item_sid;
     close get_bom_start_id;

     v_mpn_red_num := v_mpn_item_sid;

     -- Determine MPN Redline's Ending position

     v_mpn_end_string1 := NULL;
     v_mpn_end_string2 := NULL;
     If j = v_mpn_redline_count Then
      v_mpn_end_string1 := 'AgileDataManufacturerParts';
      v_mpn_end_string2 := 'AgileDataParts';
      v_mpn_end_string3 := 'ManufacturerOrdersAffectedItems';
      v_mpn_end_string4 := 'ChangeOrdersAffectedItems';
     ElsIf j != v_mpn_redline_count Then
      v_mpn_end_string1 := 'RedlinesRedlinedAMLRow';
      v_mpn_end_string2 := NULL;
      v_mpn_end_string3 := NULL;
      v_mpn_end_string4 := NULL;
     End If;

     v_mpn_item_eid := NULL;

     open get_mpn_end_id (c_file.file_name,v_mpn_end_string1,v_mpn_end_string2,v_mpn_end_string3,v_mpn_end_string4,v_mpn_item_sid);
     fetch get_mpn_end_id into v_mpn_item_eid;
     close get_mpn_end_id;


     -- Extract MPN Redline Data

     For c_mpn_data in get_data (c_file.file_name,v_mpn_item_sid,v_mpn_item_eid) loop
       If c_mpn_data.whole_tag = 'RedlinedAMLRowRedlineAction' Then
        Select decode(c_mpn_data.tag_value,'Added','A','Changed','C','Deleted','D','X') into v_mpn_sys_acd from dual;
       End If;

      If v_mpn_sys_acd = 'C' Then

	v_new_mpn_item_sid := NULL;
	 -- Determine Staring Data Position Cursor for New snapshot of MPN Redline
        open get_bom_new_start_id (c_file.file_name,v_aff_item_sid,v_mpn_item_sid,'RedlinedAMLRowRedlinedAMLRowPrevious');
	fetch get_bom_new_start_id into v_new_mpn_item_sid;
	close get_bom_new_start_id;

	-- Extract MPN Redlines OLD Data

	If c_mpn_data.id >= v_new_mpn_item_sid Then

      		If c_mpn_data.whole_tag = 'RedlinedAMLRowPreviousMfr.PartNumber' Then
       		 v_old_mpn_item := c_mpn_data.tag_value;
      		ElsIf c_mpn_data.whole_tag = 'RedlinedAMLRowPreviousMfr.Name' Then
       		 v_old_mfg_name := nvl(c_mpn_data.tag_Value,0);
      		ElsIf c_mpn_data.whole_tag like 'RedlinedAMLRowPreviousPreferredStatus' Then
       		 v_old_mpn_status := c_mpn_data.tag_value;
      		End If;		-- End MPN Redlines OLD Data extract


	-- Extract MPN redline NEW Data

	ElsIf c_mpn_data.id < v_new_mpn_item_sid Then

		If c_mpn_data.whole_tag = 'RedlinedAMLRowCurrentMfr.PartNumber' Then
		 v_mpn_item := c_mpn_data.tag_value;
		ElsIf c_mpn_data.whole_tag = 'RedlinedAMLRowCurrentMfr.Name' Then
		 v_mfg_name := nvl(c_mpn_data.tag_Value,0);
		ElsIf c_mpn_data.whole_tag like 'RedlinedAMLRowCurrentPreferredStatus' Then
		 v_mpn_status := c_mpn_data.tag_value;
      		End If;	-- End MPN Redlines NEW Data extract

        End If;

     ElsIf v_mpn_sys_acd = 'A' Then

	-- Extract MPN redline NEW Data

      		If c_mpn_data.whole_tag = 'RedlinedAMLRowCurrentMfr.PartNumber' Then
		 v_mpn_item := c_mpn_data.tag_value;
		ElsIf c_mpn_data.whole_tag = 'RedlinedAMLRowCurrentMfr.Name' Then
		 v_mfg_name := nvl(c_mpn_data.tag_Value,0);
		ElsIf c_mpn_data.whole_tag like 'RedlinedAMLRowCurrentPreferredStatus' Then
		 v_mpn_status := c_mpn_data.tag_value;
      		End If;	-- End MPN Redlines NEW Data extract

     ElsIf v_mpn_sys_acd = 'D' Then

	-- Extract MPN redline OLD Data

      		If c_mpn_data.whole_tag = 'RedlinedAMLRowPreviousMfr.PartNumber' Then
		 v_old_mpn_item := c_mpn_data.tag_value;
		ElsIf c_mpn_data.whole_tag = 'RedlinedAMLRowPreviousMfr.Name' Then
		 v_old_mfg_name := nvl(c_mpn_data.tag_Value,0);
		ElsIf c_mpn_data.whole_tag like 'RedlinedAMLRowPreviousPreferredStatus' Then
		 v_old_mpn_status := c_mpn_data.tag_value;
		End If;		-- End MPN Redlines OLD Data extract

     End If;

     End Loop;  -- End MPN redlines data extract

      If v_mpn_sys_acd = 'C' Then

        Insert into ILINK_MFG_PART_NUMBERS
		(manufacturer_name,
		mfg_part_num,
		item_number,
		agile_sys_acd,
		preferred_status,
		eco_number,
		eco_orig_date,
		eco_rel_date,
		organization_code,
		record_status,
		process_flag,
		record_id,
		creation_date,
		created_by,
		last_update_date,
		last_updated_by)
        Values
        	(nvl(v_old_mfg_name,v_mfg_name),
		v_old_mpn_item,
		v_assembly_item,
		'D',
	 	v_old_mpn_status,
	 	v_eco_number,
		v_eco_dateoriginated,
		v_eco_datereleased,
		'ZZZ',
		'Unprocessed',
		'N',
		ILINK_ORACLE_S.nextval,
		SYSDATE,
		v_user_id,
		SYSDATE,
		v_user_id);

	Insert into ILINK_MFG_PART_NUMBERS
	 	(manufacturer_name,
		mfg_part_num,
		item_number,
		agile_sys_acd,
		preferred_status,
		eco_number,
		eco_orig_date,
		eco_rel_date,
		organization_code,
		record_status,
		process_flag,
		record_id,
		creation_date,
		created_by,
		last_update_date,
		last_updated_by)
        Values
        	(nvl(v_mfg_name,v_old_mfg_name),
		nvl(v_mpn_item,v_old_mpn_item),
		v_assembly_item,
		'A',
	 	nvl(v_mpn_status,v_old_mpn_status),
	 	v_eco_number,
		v_eco_dateoriginated,
		v_eco_datereleased,
		'ZZZ',
		'Unprocessed',
		'N',
		ILINK_ORACLE_S.nextval,
		SYSDATE,
		v_user_id,
		SYSDATE,
		v_user_id);

       ElsIf v_mpn_sys_acd = 'A' Then

	Insert into ILINK_MFG_PART_NUMBERS
		(manufacturer_name,
		mfg_part_num,
		item_number,
		agile_sys_acd,
		preferred_status,
		eco_number,
		eco_orig_date,
		eco_rel_date,
		organization_code,
		record_status,
		process_flag,
		record_id,
		creation_date,
		created_by,
		last_update_date,
		last_updated_by)
	Values
		(v_mfg_name,
		v_mpn_item,
		v_assembly_item,
		'A',
		v_mpn_status,
		v_eco_number,
		v_eco_dateoriginated,
		v_eco_datereleased,
		'ZZZ',
		'Unprocessed',
		'N',
		ILINK_ORACLE_S.nextval,
		SYSDATE,
		v_user_id,
		SYSDATE,
		v_user_id);

      ElsIf v_mpn_sys_acd = 'D' Then

	Insert into ILINK_MFG_PART_NUMBERS
		(manufacturer_name,
		mfg_part_num,
		item_number,
		agile_sys_acd,
		preferred_status,
		eco_number,
		eco_orig_date,
		eco_rel_date,
		organization_code,
		record_status,
		process_flag,
		record_id,
		creation_date,
		created_by,
		last_update_date,
		last_updated_by)
	Values
		(v_old_mfg_name,
		v_old_mpn_item,
		v_assembly_item,
		'D',
		v_old_mpn_status,
		v_eco_number,
		v_eco_dateoriginated,
		v_eco_datereleased,
		'ZZZ',
		'Unprocessed',
		'N',
		ILINK_ORACLE_S.nextval,
		SYSDATE,
		v_user_id,
		SYSDATE,
		v_user_id);

      End If;


    End Loop;  -- MPN Redlines Section Ends
   End If;  */

   End Loop;  -- Affected Items Section Ends
  End If;


  /* Process Items */

  /* Determine number of Items */

  v_parts_count := 0;
  open get_item_count(c_file.file_name,'AgileDataParts','AgileDataDocuments');
  fetch get_item_count into v_parts_count;
  close get_item_count;

  If v_parts_count > 0 Then
   For k in 1 .. v_parts_count loop	-- Parts Section Begins

    v_item_number 	:= NULL;
    v_item_description	:= NULL;
    v_item_status	:= NULL;
    v_uom		:= NULL;
    v_lot_serial_ctrl 	:= NULL;
    v_shelf_life_days	:= NULL;
    v_oracle_item	:= NULL;
    v_erp_product_line	:= NULL;
    v_erp_product_type	:= NULL;
    v_erp_product_sub	:= NULL;
    v_erp_platform	:= NULL;
    v_template		:= NULL;
    v_makebuy_template	:= NULL;
    v_obsolete_template	:= NULL;
    v_mfg_orgs		:= NULL;
    v_non_mfg_orgs	:= NULL;
    v_fast_pack		:= NULL;
    v_commodity_code	:= NULL;
    v_service_repair	:= NULL;
    v_service_install	:= NULL;
    v_service_return	:= NULL;
    v_service_request	:= NULL;
    v_service_category	:= NULL;
    v_user_item_type	:= NULL;
    v_ship_qty		:= NULL;
    v_revision		:= NULL;
    v_part_type		:= NULL;
    v_item_type		:= NULL;
    v_item_cost		:= NULL;
    v_item_type_cat	:= NULL;


  /* Determine Part's starting position */

  v_parts_sid := NULL;
  open get_start_id (c_file.file_name,'AgileDataParts','AgileDataDocuments',nvl(v_parts_num,0));
  fetch get_start_id into v_parts_sid;
  close get_start_id;

  v_parts_num := v_parts_sid;

  /* Determine Part's Ending position */

  v_parts_eid := NULL;
  v_parts_end_string1 := NULL;
  v_parts_end_string2 := NULL;
  v_parts_end_string3 := NULL;
  If k != v_parts_count Then
   v_parts_end_string1 := 'AgileDataParts';
   v_parts_end_string2 := 'AgileDataDocuments';
   v_parts_end_string3 := 'ManufacturerOrdersCoverPage';
   open get_parts_end_id (c_file.file_name,v_parts_end_string1,v_parts_end_string2,v_parts_end_string3,v_parts_sid);
   fetch get_parts_end_id into v_parts_eid;
   close get_parts_end_id;
  ElsIf k = v_parts_count Then
   v_parts_eid := v_total_count;
  End If;



  /* Extract Part Data */

   For c_parts_data in get_data (c_file.file_name,v_parts_sid+1,v_parts_eid) loop
    If c_parts_data.whole_tag = 'TitleBlockNumber' Then
     v_item_number := c_parts_data.tag_Value;
    ElsIf c_parts_data.whole_tag = 'TitleBlockDescription' Then
     v_item_description := c_parts_data.tag_Value;
    ElsIf c_parts_data.whole_tag = 'TitleBlockLifecyclePhase' Then
     v_item_status := nvl(ILINK_DATA_XREF('Item Status',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
    ElsIf c_parts_data.whole_tag = 'TitleBlockRev' Then
     -- v_revision := trim(substr(c_parts_data.tag_value,1,3));
     Select replace(replace(trim(substr(c_parts_data.tag_value,1,3)),'('),')') into v_revision from dual;	-- 02/10/2014
    Elsif c_parts_data.whole_tag = 'TitleBlockPartType' Then
     v_part_type := c_parts_data.tag_Value;
     v_item_type := 'Part';
    Elsif c_parts_data.whole_tag = 'TitleBlockDocumentType' Then
     v_item_type := 'Document';
    Elsif c_parts_data.whole_tag = 'TitleBlockCommodity' Then
     Select substr(c_parts_data.tag_value,instr(c_parts_data.tag_value,'(',1)+1,(instr(c_parts_data.tag_value,')',1)-(instr(c_parts_data.tag_value,'(',1)+1)))
     Into v_commodity_code From Dual;
    Elsif c_parts_data.whole_tag = 'PageTwoList01' Then
     Select Decode(v_uom,NULL,nvl(ILINK_DATA_XREF('UOM Code',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value),v_uom) into v_uom from Dual;
    Elsif c_parts_data.whole_tag = 'PageTwoList02' Then
     v_lot_serial_ctrl := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoNumeric01' Then
     v_shelf_life_days := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoList19' Then
     v_oracle_item := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoList04' Then
     v_erp_product_line := nvl(ILINK_DATA_XREF('ERP Product Line',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
    Elsif c_parts_data.whole_tag = 'PageTwoList05' Then
     v_erp_product_type := nvl(ILINK_DATA_XREF('ERP Product Type',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
    Elsif c_parts_data.whole_tag = 'PageTwoList06' Then
     v_erp_product_sub := nvl(ILINK_DATA_XREF('ERP Product Sub Type',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
    Elsif c_parts_data.whole_tag = 'PageTwoList03' Then
     v_erp_platform := nvl(ILINK_DATA_XREF('ERP Platform',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
    Elsif c_parts_data.whole_tag = 'PageTwoList21' Then
     v_makebuy_template := nvl(ILINK_DATA_XREF('Item Template',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
    Elsif c_parts_data.whole_tag like 'PageTwoMultilist02%' Then
     Select v_mfg_orgs||Decode(v_mfg_orgs,NULL,NULL,' ')||c_parts_data.tag_value
     into v_mfg_orgs From Dual;
    Elsif c_parts_data.whole_tag like 'PageTwoMultilist03%' Then
     Select v_non_mfg_orgs||Decode(v_non_mfg_orgs,NULL,NULL,' ')||c_parts_data.tag_value
     into v_non_mfg_orgs From Dual;
    Elsif nvl(v_part_type,'NA') = 'Disposables Finished Goods' and c_parts_data.whole_tag = 'PageThreeList21' Then
     v_fast_pack := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoList18' Then
     v_service_repair := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoList20' Then
     v_service_install := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoList22' Then
     v_service_return := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoListt' Then
     v_service_category := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoList17' Then
     v_user_item_type := nvl(ILINK_DATA_XREF('Item Type',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
     v_item_type_cat := nvl(ILINK_DATA_XREF('Item Type Category',c_parts_data.tag_value,NULL,NULL,NULL),c_parts_data.tag_value);
    Elsif c_parts_data.whole_tag = 'PageTwoNumeric02' Then
     v_ship_qty := c_parts_data.tag_Value;
    Elsif c_parts_data.whole_tag = 'PageTwoMoney02' Then
     v_item_cost := c_parts_data.tag_Value;
    End If;
   End Loop;	-- End Items Data extract

   v_item_status1 := NULL;
   open get_item_status(v_eco_number,v_item_number);
   fetch get_item_status into v_item_status1;
   close get_item_status;


   -- If nvl(upper(v_item_status),'NA') != 'PRODUCTION' Then
   If nvl(upper(v_item_status1),'NA') != 'PRODUCTION' Then
    v_service_repair	:= NULL;
    v_service_install	:= NULL;
    v_service_return	:= NULL;
    v_service_category	:= NULL;
   End If;

   -- v_service_request :=  Nvl(v_service_repair,v_service_install);

   If nvl(v_service_repair,'NA') = 'Yes' Then
    v_service_request := 'Yes';
   Elsif nvl(v_service_repair,'NA') = 'No' Then
    v_service_request := 'No';
   Elsif v_service_repair is NULL and nvl(v_service_install,'NA') = 'Yes' Then
    v_service_request := 'Yes';
   End If;


   /* Insert Item Record */

  If nvl(v_oracle_item,'N') = 'Yes' Then

   Insert into ILINK_MTL_ITEMS_INT_TEMP
	(eco_number,
	record_id,
	item_number,
	description,
	item_status_code_agile,
	revision,
	part_type,
	attribute1,
	primary_uom_code,
	lot_serial_control,
	lot_control_code,
	serial_control_code,
	shelf_life_control,
	shelf_life_days,
	erp_product_line,
	erp_product_type,
	erp_product_sub_type,
	erp_platform,
	template_name,
	make_buy_template,
	obsolete_template,
	mfg_orgs,
	non_mfg_orgs,
	attribute2,
	po_category_code,
	service_used_for_repair,
	enable_service_billing,
	billing_type,
	service_request,
	serv_track_install_base,
	track_install_base,
	enable_contract_cover,
	service_returnable,
	service_category_code,
	item_type,
	shipping_qty_box,
	attribute4,
	agile_item_cost,
	product_family_code,
	eco_orig_date,
	eco_rel_date,
	organization_code,
	record_status,
	process_flag,
	creation_date,
	created_by,
	last_update_date,
	last_updated_by
	)
   Values
	(v_eco_number,
	ILINK_ORACLE_S.nextval,
	v_item_number,
	v_item_description,
	v_item_status,
	v_revision,
	v_part_type,
	v_item_type,
	v_uom,
	v_lot_serial_ctrl,
	Decode(v_lot_serial_ctrl,NULL,NULL,ILINK_DATA_XREF('Lot and Serial Number control',v_lot_serial_ctrl,'Lot Control',NULL,NULL)),
	Decode(v_lot_serial_ctrl,NULL,NULL,ILINK_DATA_XREF('Lot and Serial Number control',v_lot_serial_ctrl,'Serial Number Control',NULL,NULL)),
    	Decode(v_lot_serial_ctrl,NULL,NULL,ILINK_DATA_XREF('Lot and Serial Number control',v_lot_serial_ctrl,'Shelf Life Control',NULL,NULL)),
    	v_shelf_life_days,
    	v_erp_product_line,
    	v_erp_product_type,
    	v_erp_product_sub,
    	v_erp_platform,
    	ILINK_DATA_XREF('Default Item Master Template',NULL,NULL,NULL,NULL),
    	v_makebuy_template,
    	-- ILINK_DATA_XREF('Default Item Obsolete Template',v_item_status,NULL,NULL,NULL),
    	ILINK_DATA_XREF('Default Item Obsolete Template',v_item_status1,NULL,NULL,NULL),
    	v_mfg_orgs,
    	v_non_mfg_orgs,
    	v_fast_pack,
    	v_commodity_code,
    	v_service_repair,
    	-- Decode(v_service_repair,NULL,NULL,ILINK_DATA_XREF('Service: Used for Repair',v_service_repair,'Enable Service Billing',NULL,NULL)),
    	Decode(v_service_request,NULL,NULL,ILINK_DATA_XREF('Service: Used for Repair',v_service_request,'Enable Service Billing',NULL,NULL)),
    	-- Decode(v_service_repair,NULL,NULL,ILINK_DATA_XREF('Service: Used for Repair',v_service_repair,'Billing Type',NULL,NULL)),
    	Decode(v_service_request,NULL,NULL,ILINK_DATA_XREF('Service: Used for Repair',v_service_request,'Billing Type',NULL,NULL)),
    	Decode(v_service_request,NULL,NULL,ILINK_DATA_XREF('Service: Used for Repair',v_service_request,'Service Request',NULL,NULL)),
    	v_service_install,
    	Decode(v_service_install,NULL,NULL,ILINK_DATA_XREF('Service: Track in Install Base',v_service_install,'Track in Installed Base',NULL,NULL)),
    	Decode(v_service_install,NULL,NULL,ILINK_DATA_XREF('Service: Track in Install Base',v_service_install,'Enable Contract Coverage',NULL,NULL)),
    	Decode(v_service_return,NULL,NULL,ILINK_DATA_XREF('Service: Returnable',v_service_return,NULL,NULL,NULL)),
    	v_service_category,
    	v_user_item_type,
    	v_ship_qty,
    	v_eco_type,
    	v_item_cost,
    	v_item_type_cat,
	v_eco_dateoriginated,
	v_eco_datereleased,
	'ZZZ',
	'Unprocessed',
	'N',
	SYSDATE,
	v_user_id,
	SYSDATE,
	v_user_id
	);


  /* Process BOMs */

  /* Determine number of BOM Components for a PART */

  v_bom_count := 0;
  open get_bom_count1(c_file.file_name,v_parts_sid,v_parts_eid,'PartsBOM','DocumentsBOM');
  fetch get_bom_count1 into v_bom_count;
  close get_bom_count1;

  If v_bom_count > 0 Then	-- BOMs exist

   for l in 1..v_bom_count Loop	-- BOM Section Begins

     v_bom_component_item	:= NULL;
     v_bom_comp_qty		:= 0;
     v_bom_find_num		:= NULL;
     v_bom_item_type		:= NULL;
     v_bom_lifecycle		:= NULL;
     v_bom_oraitem		:= NULL;

     /* Determine BOM's starting position */
     v_bom_item_sid := NULL;
     open get_bom_start_id1 (c_file.file_name,'PartsBOM','DocumentsBOM',v_parts_sid,nvl(v_bom_num,v_parts_sid));
     fetch get_bom_start_id1 into v_bom_item_sid;
     close get_bom_start_id1;

     v_bom_num := v_bom_item_sid;

     /* Determine BOM's Ending position */

     v_bom_end_string1 := NULL;
     v_bom_end_string2 := NULL;
     v_bom_end_string3 := NULL;
     v_bom_end_string4 := NULL;
     If l = v_bom_count Then
      v_bom_end_string1 := 'PartsPageTwo';
      v_bom_end_string2 := 'AgileDataParts';
      v_bom_end_string3 := 'DocumentsPageTwo';
      v_bom_end_string4 := 'AgileDataDocuments';
     ElsIf l != v_bom_count Then
      v_bom_end_string1 := 'PartsBOM';
      V_bom_end_string2 := NULL;
      v_bom_end_string3 := 'DocumentsBOM';
      v_bom_end_string4 := NULL;
     End If;

     v_bom_item_eid := NULL;
     open get_bom_end_id1 (c_file.file_name,v_bom_end_string1,v_bom_end_string2,v_bom_end_string3,v_bom_end_string4,v_bom_item_sid);
     fetch get_bom_end_id1 into v_bom_item_eid;
     close get_bom_end_id1;

     /* Extract BOM data */

     For c_ps_data in get_data (c_file.file_name,v_bom_item_sid+1,v_bom_item_eid) loop

      If c_ps_data.whole_tag = 'BOMItemNumber' Then
       v_bom_component_item := c_ps_data.tag_value;
      ElsIf c_ps_data.whole_tag = 'BOMQty' Then
       v_bom_comp_qty := c_ps_data.tag_Value;
      ElsIf c_ps_data.whole_tag = 'BOMFindNum' Then
       v_bom_find_num := c_ps_data.tag_Value;
      ElsIf c_ps_data.whole_tag = 'BOMItemType' Then
       v_bom_item_type := c_ps_data.tag_Value;
      ElsIf c_ps_data.whole_tag = 'BOMItemList19' Then
       v_bom_oraitem := c_ps_data.tag_Value;
      ElsIf c_ps_data.whole_tag = 'BOMItemLifecyclePhase' Then
       v_bom_lifecycle := c_ps_data.tag_Value;
      End If;

     End Loop;	-- End BOMs Data extract

     Insert into ILINK_ECO_ITEM_BOMS_TEMP
        (eco_number,
        assembly_item_number,
        assembly_item_revision,
        component_item_number,
        quantity,
        agile_sys_acd,
	find_number,
	attribute1,
	attribute2,
	attribute3,
	attribute4,
	attribute5,
	record_status,
	process_flag,
	organization_code)
     Values
	(v_eco_number,
	v_item_number,
	v_revision,
	v_bom_component_item,
	v_bom_comp_qty,
	'U',
	v_bom_find_num,
	v_bom_item_type,
	v_bom_find_num,
	v_bom_oraitem,
	v_bom_lifecycle,
	'P',
	'Unprocessed',
	'N',
	'ZZZ');


    /* Extract Reference Designator data 	-- Commented out on 02/21/2014

     For c_rd_data in get_data (c_file.file_name,v_bom_item_sid+1,v_bom_item_eid) Loop

      If c_rd_data.whole_tag = 'ReferenceDesignatorsReferenceDesignator' Then

	Insert into ILINK_ECO_BOM_REFDES_TEMP
		(eco_number,
		assembly_item_number,
		assembly_item_revision,
		component_item_number,
		quantity,
		agile_sys_acd,
		find_number,
		reference_designator,
		record_status,
		process_flag,
		organization_code)
     	Values
		(v_eco_number,
		v_item_number,
		v_revision,
		v_bom_component_item,
		v_bom_comp_qty,
		'U',
		v_bom_find_num,
		substr(c_rd_data.tag_value,1,15),
		'Unprocessed',
		'N',
		'ZZZ');

      End If;

     End Loop;	-- End Ref Des Data extract	*/


    End Loop;  -- BOMs Section Ends

   End If;


  /* Process Manufacturer/ASL Part Data (MPN/ASL)

  -- Determine number of MPN/ASLs for an Item

  v_mpn_count := 0;
  open get_bom_count(c_file.file_name,v_parts_sid,v_parts_eid,'PartsManufacturers');
  fetch get_bom_count into v_mpn_count;
  close get_bom_count;

  If v_mpn_count > 0 Then	-- MPN/ASLs exist

   for l in 1..v_mpn_count Loop	-- MPN/ASL Section Begins

     v_mpn_item		:= NULL;
     v_mfg_name		:= NULL;
     v_mpn_status	:= NULL;

     -- Determine MPN's starting position
     v_mpn_sid := NULL;
     open get_bom_start_id (c_file.file_name,'PartsManufacturers',v_parts_sid,nvl(v_mpn_num,v_parts_sid));
     fetch get_bom_start_id into v_mpn_sid;
     close get_bom_start_id;

     v_mpn_num := v_mpn_sid;

     -- Determine MPN's Ending position

     v_mpn_end_string1 := NULL;
     v_mpn_end_string2 := NULL;
     If l = v_mpn_count Then
      v_mpn_end_string1 := 'PartsPageTwo';
      v_mpn_end_string2 := 'AgileDataParts';
     ElsIf l != v_mpn_count Then
      v_mpn_end_string1 := 'PartsManufacturers';
      V_mpn_end_string2 := NULL;
     End If;

     v_mpn_eid := NULL;
     open get_bom_end_id (c_file.file_name,v_mpn_end_string1,v_mpn_end_string2,v_mpn_sid);
     fetch get_bom_end_id into v_mpn_eid;
     close get_bom_end_id;

     -- Extract MPN data

     For c_mpn_data in get_data (c_file.file_name,v_mpn_sid+1,v_mpn_eid) loop
      If c_mpn_data.whole_tag = 'ManufacturersMfr.PartNumber' Then
       v_mpn_item := c_mpn_data.tag_value;
      ElsIf c_mpn_data.whole_tag = 'ManufacturersMfr.Name' Then
       v_mfg_name := c_mpn_data.tag_Value;
      ElsIf c_mpn_data.whole_tag = 'ManufacturersPreferredStatus' Then
       v_mpn_status := c_mpn_data.tag_Value;
      End If;
     End Loop;	-- End MPNs Data extract

    Insert into ILINK_MFG_PART_NUMBERS
	(manufacturer_name,
	mfg_part_num,
	item_number,
	agile_sys_acd,
	preferred_status,
	eco_number,
	eco_orig_date,
	eco_rel_date,
	organization_code,
	record_status,
	process_flag,
	record_id,
	creation_date,
	created_by,
	last_update_date,
	last_updated_by)
     Values
	(v_mfg_name,
	v_mpn_item,
	v_item_number,
	'U',
	v_mpn_status,
	v_eco_number,
	v_eco_dateoriginated,
	v_eco_datereleased,
	'ZZZ',
	'Unprocessed',
	'N',
	ILINK_ORACLE_S.nextval,
	SYSDATE,
	v_user_id,
	SYSDATE,
	v_user_id);

    End Loop;  -- MPNs Section Ends
   End If;  */

  End If;   -- v_oracle_item != 'N'

   End Loop;  -- Parts Section Ends
  End If;


 /* Updated the file name indicating it's been processed */

  Update ILINK_XML_FILES
  Set processed_flag = 'Y',
      processed_Date = SYSDATE,
      eco_number = v_eco_number
  Where file_name = c_file.file_name and
        processed_date is NULL;

 Else -- ECO exists in I-link tables or Oracle so Error out the file

  /* If nvl(v_eco_exists_intf,'N') = 'Y' Then							-- Commented out on 09/09/2014

   Update ILINK_XML_FILES
   Set processed_flag = 'E',
      error_message = 'Duplicate ECO Error: '||v_eco_number||' exists in I-link tables',
      processed_Date = SYSDATE,
      eco_number = v_eco_number
   Where file_name = c_file.file_name and processed_date is NULL;

  Elsif nvl(v_eco_exists_orcl,'N') = 'Y' Then	*/						-- End 12/15/2015
  
  If nvl(v_eco_exists_orcl,'N') = 'Y' Then							-- Added on 12/15/2015

   Update ILINK_XML_FILES
   Set processed_flag = 'E',
       error_message = 'Duplicate ECO Error: '||v_eco_number||' exists in Oracle',
       processed_Date = SYSDATE,
       eco_number = v_eco_number
   Where file_name = c_file.file_name and processed_date is NULL;

  End If;

 End If; --  Checking if ECO exists

 /* Delete from the parsing stage table */

   Delete from ILINK_XML_STAGE
   Where file_name = c_file.file_name;


 End Loop;	-- File Processing Ends


  Commit;


 Exception
  When others then
  FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_XML_LOAD_DATA is '||SQLERRM);

    Rollback;

   Update ILINK_XML_FILES
   Set processed_flag = 'E',
       error_message = 'Date Type and/or Data Length Error',
       processed_Date = SYSDATE,
       parsed_date = SYSDATE,
       eco_number = v_eco_number
   Where file_name = v_file_name and
         processed_date is NULL;

   Insert into ILINK_XML_STAGE_ERROR
    (id,file_name,tag_name,tag_value,parent_tag_name)
   Select id,file_name,tag_name,tag_value,parent_tag_name
   From ILINK_XML_STAGE
   Where file_name = v_file_name;

   Delete from ILINK_XML_STAGE
   Where file_name = v_file_name;

   commit;


End ILINK_XML_LOAD_DATA;


Procedure ILINK_XML_POST_LOAD  is


Begin

/* Update Item Status from affected item section */		-- 02/10/2014

    Update ILINK_MTL_ITEMS_INT_TEMP rev
    Set item_status_code_agile = (Select distinct lifecycle_status
      		      		  From ILINK_ECO_ITEM_REVISIONS_TEMP itm
      		      		  Where rev.eco_number = itm.eco_number and
      		    	    		rev.item_number = itm.item_number and
      		    	    		rev.organization_code = itm.organization_code)
    Where organization_code = 'ZZZ';

    Update ILINK_ECO_ITEM_BOMS_TEMP rev
    Set attribute4 = (Select distinct lifecycle_status
      		      		  From ILINK_ECO_ITEM_REVISIONS_TEMP itm
      		      		  Where rev.eco_number = itm.eco_number and
      		    	    		rev.component_item_number = itm.item_number and
      		    	    		rev.organization_code = itm.organization_code)
    Where organization_code = 'ZZZ';


/* Update inventory category segment2 and segment4 from item section */

    Update ILINK_ECO_ITEM_REVISIONS_TEMP rev
    Set attribute3 = (Select distinct erp_product_line
      		      From ILINK_MTL_ITEMS_INT_TEMP itm
      		      Where rev.eco_number = itm.eco_number and
      		    	    rev.item_number = itm.item_number and
      		    	    rev.organization_code = itm.organization_code)
    Where organization_code = 'ZZZ';

    Update ILINK_ECO_ITEM_REVISIONS_TEMP rev
    Set attribute4 = (Select distinct erp_platform
      		      From ILINK_MTL_ITEMS_INT_TEMP itm
      		      Where rev.eco_number = itm.eco_number and
      		    	    rev.item_number = itm.item_number and
      		    	    rev.organization_code = itm.organization_code)
    Where organization_code = 'ZZZ';

    Commit;


/* Delete Documents


Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP itm
   	      Where itm.eco_number = bom.eco_number and
   	            itm.item_number = bom.component_item_number and
   	            nvl(itm.attribute1,'NA') = 'Document');

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP itm
   	      Where itm.eco_number = bom.eco_number and
   	            itm.item_number = bom.assembly_item_number and
   	            nvl(itm.attribute1,'NA') = 'Document');

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP itm
   	      Where itm.eco_number = bom.eco_number and
   	            itm.item_number = bom.component_item_number and
   	            nvl(itm.attribute1,'NA') = 'Document');

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP itm
   	      Where itm.eco_number = bom.eco_number and
   	            itm.item_number = bom.assembly_item_number and
   	            nvl(itm.attribute1,'NA') = 'Document');

Delete From ILINK_ECO_ITEM_REVISIONS_TEMP bom
Where exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP itm
   	      Where itm.eco_number = bom.eco_number and
   	            itm.item_number = bom.item_number and
   	            nvl(itm.attribute1,'NA') = 'Document');

Delete From ILINK_MFG_PART_NUMBERS bom
Where exists (Select 'x' from ILINK_MTL_ITEMS_INT_TEMP itm
   	      Where itm.eco_number = bom.eco_number and
   	            itm.item_number = bom.item_number and
   	            nvl(itm.attribute1,'NA') = 'Document');

Delete From ILINK_MTL_ITEMS_INT_TEMP itm
Where nvl(itm.attribute1,'NA') = 'Document';		*/


/* Filter Items with document filters */

Delete From ILINK_MFG_PART_NUMBERS mfg
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = mfg.eco_number and
		    itm.item_number = mfg.item_number and
		    idx.data_input1 = 'Document Filter Type' and
		    itm.part_type = idx.data_output1);

Delete From ILINK_ECO_ITEM_REVISIONS_TEMP rev
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = rev.eco_number and
		    itm.item_number = rev.item_number and
		    idx.data_input1 = 'Document Filter Type' and
		    itm.part_type = idx.data_output1);

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'Document Filter Type' and
		    itm.part_type = idx.data_output1);

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.component_item_number and
		    idx.data_input1 = 'Document Filter Type' and
		    itm.part_type = idx.data_output1);

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'Document Filter Type' and
		    itm.part_type = idx.data_output1);

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.component_item_number and
		    idx.data_input1 = 'Document Filter Type' and
		    itm.part_type = idx.data_output1);

Delete From ILINK_MTL_ITEMS_INT_TEMP itm
Where organization_code = 'ZZZ' and
      exists (select 'x' from ILINK_DATA_XREF idx
	      where idx.data_input1 = 'Document Filter Type' and
		    itm.part_type = idx.data_output1);

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (select 'x' From ILINK_ECO_ITEM_BOMS_TEMP itm,
	      		      ILINK_DATA_XREF idx
	      where itm.eco_number = bom.eco_number and
	            itm.assembly_item_number = bom.assembly_item_number and
		    itm.component_item_number = bom.component_item_number and
	      	    idx.data_input1 = 'Document Filter Type' and
		    itm.attribute1 = idx.data_output1);

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (select 'x' from ILINK_DATA_XREF idx
	      where idx.data_input1 = 'Document Filter Type' and
		    bom.attribute1 = idx.data_output1);



/* Filter Items with Filter lifecycles */

Delete From ILINK_MFG_PART_NUMBERS mfg
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = mfg.eco_number and
		    itm.item_number = mfg.item_number and
		    idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.item_status_code_agile = idx.data_output1);

Delete From ILINK_ECO_ITEM_REVISIONS_TEMP rev
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = rev.eco_number and
		    itm.item_number = rev.item_number and
		    idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.item_status_code_agile = idx.data_output1);

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.item_status_code_agile = idx.data_output1);

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.component_item_number and
		    idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.item_status_code_agile = idx.data_output1);

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.item_status_code_agile = idx.data_output1);

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.component_item_number and
		    idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.item_status_code_agile = idx.data_output1);

Delete From ILINK_MTL_ITEMS_INT_TEMP itm
Where organization_code = 'ZZZ' and
      exists (select 'x' from ILINK_DATA_XREF idx
	      where idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.item_status_code_agile = idx.data_output1);


Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (select 'x' From ILINK_ECO_ITEM_BOMS_TEMP itm,
	      		      ILINK_DATA_XREF idx
	      where itm.eco_number = bom.eco_number and
	            itm.assembly_item_number = bom.assembly_item_number and
		    itm.component_item_number = bom.component_item_number and
	      	    idx.data_input1 = 'Item Filter Lifecycle' and
		    itm.attribute4 = idx.data_output1);

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (select 'x' from ILINK_DATA_XREF idx
	      where idx.data_input1 = 'Item Filter Lifecycle' and
		    bom.attribute4 = idx.data_output1);



/* Filter Items with Filter From and To lifecycles */

Delete From ILINK_MFG_PART_NUMBERS mfg
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = mfg.eco_number and
		    itm.item_number = mfg.item_number and
		    idx.data_input1 = 'Item Filter Lifecycle From and To' and
		    itm.lifecycle_status = idx.data_output2 and
		    nvl(itm.attribute1,'N/A') = idx.data_output1);

Delete From ILINK_MTL_ITEMS_INT_TEMP mfg
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = mfg.eco_number and
		    itm.item_number = mfg.item_number and
		    idx.data_input1 = 'Item Filter Lifecycle From and To' and
		    itm.lifecycle_status = idx.data_output2 and
		    nvl(itm.attribute1,'N/A') = idx.data_output1);

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'Item Filter Lifecycle From and To' and
		    itm.lifecycle_status = idx.data_output2 and
		    nvl(itm.attribute1,'N/A') = idx.data_output1);

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_ECO_ITEM_REVISIONS_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'Item Filter Lifecycle From and To' and
		    itm.lifecycle_status = idx.data_output2 and
		    nvl(itm.attribute1,'N/A') = idx.data_output1);

Delete From ILINK_ECO_ITEM_REVISIONS_TEMP itm
Where organization_code = 'ZZZ' and
      exists (select 'x' from ILINK_DATA_XREF idx
	      where idx.data_input1 = 'Item Filter Lifecycle From and To' and
		    itm.lifecycle_status = idx.data_output2 and
		    nvl(itm.attribute1,'N/A') = idx.data_output1);


/* Filter BOM Components that are marked as non-oracle items in Agile */

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (select 'x' From ILINK_ECO_ITEM_BOMS_TEMP itm
	      where itm.eco_number = bom.eco_number and
	            itm.assembly_item_number = bom.assembly_item_number and
		    itm.component_item_number = bom.component_item_number and
	      	    nvl(itm.attribute3,'No') = 'No');

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      nvl(attribute3,'No') = 'No';


-- Added the below on 09/05/2014 to filter BOMs for purchased parts

Delete From ILINK_ECO_ITEM_BOMS_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'BOM Filter Template' and
		    itm.make_buy_template = idx.data_output1);

Delete From ILINK_ECO_BOM_REFDES_TEMP bom
Where organization_code = 'ZZZ' and
      exists (Select 'x' From ILINK_MTL_ITEMS_INT_TEMP itm,
			      ILINK_DATA_XREF idx
	      Where itm.eco_number = bom.eco_number and
		    itm.item_number = bom.assembly_item_number and
		    idx.data_input1 = 'BOM Filter Template' and
		    itm.make_buy_template = idx.data_output1);      	-- End 09/05/2014


  /* Update Revisions for Assembly Items that do not have revisions

    Update ILINK_ECO_ITEM_REVISIONS_TEMP rev
    Set new_revision = (Select distinct revision
  		      From ILINK_MTL_ITEMS_INT_TEMP itm
  		      Where rev.eco_number = itm.eco_number and
  		    	    rev.item_number = itm.item_number and
  		    	    rev.organization_code = itm.organization_code)
    Where new_revision is NULL;


    Update ILINK_ECO_ITEM_BOMS_TEMP rev
    Set assembly_item_revision = (Select distinct revision
  		    	        From ILINK_MTL_ITEMS_INT_TEMP itm
  		    	        Where rev.eco_number = itm.eco_number and
  		    	  	      rev.assembly_item_number = itm.item_number and
  		    	  	      rev.organization_code = itm.organization_code)
    Where assembly_item_revision is NULL;


    Update ILINK_ECO_BOM_REFDES_TEMP rev
    Set assembly_item_revision = (Select distinct revision
  		    	        From ILINK_MTL_ITEMS_INT_TEMP itm
  		    	        Where rev.eco_number = itm.eco_number and
  		    	  	      rev.assembly_item_number = itm.item_number and
  		    	  	      rev.organization_code = itm.organization_code)
    Where assembly_item_revision is NULL;


    Commit;   */


    /* Update Agile Revisions for Items */

    Update ILINK_MTL_ITEMS_INT_TEMP rev
    Set attribute5 = (Select distinct attribute2
  		      From ILINK_ECO_ITEM_REVISIONS_TEMP itm
  		      Where rev.eco_number = itm.eco_number and
  		    	    rev.item_number = itm.item_number and
  		    	    rev.organization_code = 'ZZZ' and
  		    	    rev.organization_code = itm.organization_code)
    Where attribute5 is NULL;





 /* Update the ACD flag from A(Addition) to C(Change) when there exists a corresponding D(Delete) record ,
     since Agile sends BOM redline changes as a combination of Delete and then an Add. Also delete the D(delete) record  */

  Update ILINK_ECO_ITEM_BOMS_TEMP temp1
  Set agile_sys_acd = 'C'
  Where agile_sys_acd = 'A' and
        temp1.organization_code = 'ZZZ' and
        temp1.attribute5 = 'P' and
        exists (select 'x' from  ILINK_ECO_ITEM_BOMS_TEMP temp2
                where temp1.eco_number = temp2.eco_number and
                      temp1.organization_code = temp2.organization_code and
                      temp2.organization_code = 'ZZZ' and
                      temp1.assembly_item_number = temp2.assembly_item_number and
  	              temp1.assembly_item_revision = temp2.assembly_item_revision and
                      temp1.component_item_number = temp2.component_item_number and
                      -- nvl(temp1.attribute2,temp1.find_number) = temp2.find_number and
                      -- nvl(temp1.attribute9,nvl(temp1.operation_seq_num,1)) = nvl(temp2.operation_seq_num,1) and
		      temp2.attribute5 = 'P' and
                      temp2.agile_sys_acd = 'D');

  Delete From ILINK_ECO_ITEM_BOMS_TEMP temp1
  Where agile_sys_acd = 'D' and
  	temp1.organization_code = 'ZZZ' and
        temp1.attribute5 = 'P' and
        exists (select 'x' from  ILINK_ECO_ITEM_BOMS_TEMP temp2
                where temp1.eco_number = temp2.eco_number and
                      temp1.organization_code = temp2.organization_code and
                      temp2.organization_code = 'ZZZ' and
                      temp1.assembly_item_number = temp2.assembly_item_number and
		      temp1.assembly_item_revision = temp2.assembly_item_revision and
                      temp1.component_item_number = temp2.component_item_number and
                      -- nvl(temp2.attribute2,temp2.find_number) = temp1.find_number and
                      -- nvl(temp2.attribute9,nvl(temp2.operation_seq_num,1)) = nvl(temp1.operation_seq_num,1) and
		      temp2.attribute5 = 'P' and
                      temp2.agile_sys_acd = 'C');


  /* Update the ACD flag from A(Addition) to C(Change) when there exists a corresponding D(Delete) record ,
       since Agile sends MPN/ASL redline changes as a combination of Delete and then an Add. Also delete the D(delete) record */

    Update ILINK_MFG_PART_NUMBERS temp1
    Set agile_sys_acd = 'C'
    Where temp1.agile_sys_acd = 'A' and
          temp1.organization_code = 'ZZZ' and
          exists (select 'x' from ILINK_MFG_PART_NUMBERS temp2
                  where temp1.eco_number = temp2.eco_number and
                        temp1.organization_code = temp2.organization_code and
                        temp2.organization_code = 'ZZZ' and
                        temp1.item_number = temp2.item_number and
                        temp1.manufacturer_name = temp2.manufacturer_name and
    	                temp1.mfg_part_num = temp2.mfg_part_num and
                        temp2.agile_sys_acd = 'D');

    Delete From ILINK_MFG_PART_NUMBERS temp1
    Where temp1.agile_sys_acd = 'D' and
          temp1.organization_code = 'ZZZ' and
          exists (select 'x' from ILINK_MFG_PART_NUMBERS temp2
                  where temp1.eco_number = temp2.eco_number and
                        temp1.organization_code = temp2.organization_code and
                        temp2.organization_code = 'ZZZ' and
                        temp1.item_number = temp2.item_number and
                        temp1.manufacturer_name = temp2.manufacturer_name and
    	                temp1.mfg_part_num = temp2.mfg_part_num and
                        temp2.agile_sys_acd = 'C');

   commit;

 Exception
  When others then
  FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Procedure ILINK_XML_POST_LOAD is '||SQLERRM);

End ILINK_XML_POST_LOAD;



Function ILINK_XML_VALUE(p_input1 In varchar2,p_input2 In Number)
 Return Varchar2 is

Cursor get_xml_value is
 Select tag_value from ILINK_XML_STAGE
 Where file_name = p_input1 and
       id = p_input2;

v_value 	Varchar2(1000);

Begin

 /* Return Oracle cross-reference values for all data elements */

  open get_xml_value;
  fetch get_xml_value into v_value;
  close get_xml_value;


 Return (v_value);

End ILINK_XML_VALUE;



Function ILINK_DATA_XREF(p_input1 In varchar2,p_input2 In varchar2,p_input3 In varchar2,
			 p_input4 In varchar2,p_input5 In varchar2)
 Return Varchar2 is

Cursor get_xref_value is
 Select data_output1
 From ILINK_DATA_XREF
 Where data_input1 = p_input1 and
       (data_input2 = p_input2 or p_input2 is NULL) and
       (data_input3 = p_input3 or p_input3 is NULL) and
       (data_input4 = p_input4 or p_input4 is NULL) and
       (data_input5 = p_input5 or p_input5 is NULL) and
       nvl(disabled_flag,'N') = 'N'
 Order by creation_date desc;

v_value 	Varchar2(1000);

Begin

 /* Return Oracle cross-reference values for all data elements */

  open get_xref_value;
  fetch get_xref_value into v_value;
  close get_xref_value;

 Return (v_value);

End ILINK_DATA_XREF;


end ILINK_XML_INTERFACE_PKG;
