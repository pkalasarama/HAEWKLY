create or replace PACKAGE BODY      ILINK_ITEM_INTERFACE_PKG
AS
   /*
   REM +============================================================================================+
   REM |Filename         :  BLD_ITEM_INTERFACE_PKG.pkb                                     |
   REM |                                                                                            |
   REM |Copyright        : 2001-2013 CPG Solutions LLC - All Rights Reserved             |
   REM |                   All rights reserved:  This software/documentation contains proprietary   |
   REM |                     information of CPG Solutions; it is provided under a license agreement      |
   REM |                    containing restrictions on use and disclosure and is also protected      |
   REM |                     by copyright law.  Reverse engineering of the software is prohibited.    |
   REM |                                                                   |
   REM |Description      : Package Body for processing Items contains the following program Units     |
   REM |                    ILINK_ITEM_INT_MAIN  (Main process)                     |
   REM |             ILINK_ITEM_COPY_ALL_ORG (Populate Records for all Organizations)     |
   REM |            ILINK_ITEM_PRE_VALIDATE  (Validate data on Temporary tables)         |
   REM |             ILINK_ITEM_INSERT_INT  (Insert validated records into Interface Tables) |
   REM |             ILINK_INV_OPEN_INTERFACE (Call Item Import Open Interface)          |
   REM |                    ILINK_POST_ITEM_INTERFACE  (Review and update status after item import) |                                                |
   REM |                                                                   |
   REM |                                                                                            |
   REM |Calling Program  : Concurrent Executable name is ILINKINVINT                  |
   REM |                                                                                            |
   REM |Pre-requisites   : None                                     |
   REM |                                                                  |
   REM |                                                                                            |
   REM |Post Processing  :                                       |
   REM |                                                               |
   REM |                                                                                            |
   REM |                                                          |
   REM |Code Based On iLink Release: 7.6.9                              |
   REM |                                                                      |
   REM |                                                                                            |
   REM |Customer:  Haemonetics 14-OCT-13                                                             |
   REM |                                                                                            |
   REM |Customer Change History:                                                                    |
   REM |------------------------                                                                    |
   REM |Version  Date       Author         Remarks                                                  |
   REM |-------  --------- --------------  ---------------------------------------------------------|
   REM |1.0      14-OCT-13 CPG Solutions      First draft Version for Customer branched from iLink,     |
   REM |                                   code base 7.6.0                           |
   REM |1.1      05-MAR-14 CPG Solutions   Modified code to fix the doubling of cost issue         |
   REM |         06-MAR-14 CPG Solutions   Modified code for price list attributes             |
   REM |1.2      03-APR-14 CPG Solutions   Modified code related to price lists             |
   REM |                                                                |
   REM |1.3      22-MAY-14 CPG Solutions   Modified code to prevent description updates         |
   REM |                                                                                            |
   REM |1.4      29-MAY-14 CPG Solutions   Modified code to process - revs at child org when the -  |
   REM |                      rev doesn't exist at master org             |
   REM |1.5      02-JUN-14 CPG Solutions   Modified code to stop updates inv, po categories and     |
   REM |                      related attributes. Also modified code to populate these|
   REM |                                    values from Master org when assigning item to a new org |
   REM |1.6      25-SEP-14 K Gangisetty    Made changes to the price list code                      |
   REM |                                                                |
   REM |1.7      30-JAN-15 K Gangisetty    Added Code to Create GL Accounts Dynamically             |
   REM |                                                                |
   REM |1.8      02-MAR-15 K Gangisetty    Modified Code to Invoke Item Import in Validate Mode     |
   REM |                                    first and then in process mode                 |
   REM |         08-JUN-15 K Gangisetty    Added code to perform revision validations         |
   REM |         06-OCT-15 K Gangisetty    Added Code to populate "Lot Status Enabled" and          |
   REM |                                    "Default Lot Status" fields for Lot controlled items	 | 
   REM |1.9      19-FEB-16 K Gangisetty    Modified "update" records to populate master-controlled  |
   REM |                                    attributes only for master org record                   |
   REM |         29-FEB-16 K Gangisetty    Modified Code to stop updates to service attributes      |
   REM |	 04-MAR-16 K Gangisetty    Modified Code to stop populating service attributes in   |
   REM |				    the process while applying second template		    |	
   REM | Be sure to update the version number below with the latest version number reference above. |
   REM |                                                                                            |
   REM +============================================================================================+
   */

   /* Declare Global Variables to hold values used across multiple procedures */

   v_inv_cat_set_name   VARCHAR2 (30)
                           := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Category Set Name',
                                                                       'Inventory',
                                                                       NULL,
                                                                       NULL,
                                                                       NULL);
   v_po_cat_set_name    VARCHAR2 (30)
                           := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Category Set Name',
                                                                       'Purchasing',
                                                                       NULL,
                                                                       NULL,
                                                                       NULL);
   v_ser_cat_set_name   VARCHAR2 (30)
                           := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Category Set Name',
                                                                       'Service',
                                                                       NULL,
                                                                       NULL,
                                                                       NULL);
   v_itp_cat_set_name   VARCHAR2 (30)
                           := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Category Set Name',
                                                                       'Item Type',
                                                                       NULL,
                                                                       NULL,
                                                                       NULL);

   v_user_id            NUMBER := FND_GLOBAL.USER_ID ();


   PROCEDURE ILINK_ITEM_INT_MAIN (x_retcode OUT VARCHAR2, x_errbuff OUT VARCHAR2)
   IS
      /* Define a Cursor to fetch the value for Master Organization */

      CURSOR get_master_org
      IS
         SELECT mpp.organization_id, mpp.organization_code
           FROM MTL_PARAMETERS mpp, ILINK_DATA_XREF REF
          WHERE     mpp.organization_id = mpp.master_organization_id
                AND REF.data_input1 = 'Master Org Code'
                AND mpp.organization_code = REF.data_output1;

      /* Define a Cursor to verify if validated records exist in temp table */

      CURSOR get_validated_records
      IS
         SELECT COUNT (*)
           FROM ILINK_MTL_ITEMS_INT_TEMP
          WHERE record_status = 'Validated';

      /* Define a Cursor to verify if unprocessed records exist in item interface table */

      CURSOR get_item_intf_count
      IS
         SELECT COUNT (*)
           FROM mtl_system_items_interface
          WHERE     transaction_type IN ('CREATE', 'UPDATE')
                AND process_flag = 1
                AND set_process_id = 0;

      /* Define a Cursor to verify if unprocessed records exist in item interface table */

      CURSOR get_item_intf_count1
      IS
         SELECT COUNT (*)
           FROM mtl_system_items_interface
          WHERE transaction_type = 'UPDATE' AND process_flag = 1 AND set_process_id = 1;

      /* Define a Cursor to verify if unprocessed records exist in category interface table */

      CURSOR get_cat_intf_count
      IS
         SELECT COUNT (*)
           FROM mtl_item_categories_interface
          WHERE     transaction_type IN ('CREATE', 'UPDATE', 'DELETE')
                AND process_flag = 1
                AND set_process_id = 0;


      v_count_temp_records   NUMBER := 0;
      v_count_item_intf      NUMBER := 0;
      v_count_cat_intf       NUMBER := 0;

      v_master_org_id        NUMBER;
      v_master_org_code      VARCHAR2 (3);

      v_req_id1              NUMBER;
      v_req_id2              NUMBER;
   BEGIN
      /* Fetch the value for Master Organization id  */

      OPEN get_master_org;

      FETCH get_master_org
      INTO v_master_org_id, v_master_org_code;

      CLOSE get_master_org;


      /* Call the Procedure to Populate the Item records in temp table for all organizations */

      ILINK_item_copy_all_org (v_master_org_id, v_master_org_code);
      COMMIT;

      /* Call the procedure to validate all the records before inserting into Interface tables */

      ILINK_item_pre_validate (v_master_org_id, v_master_org_code);
      COMMIT;


      -- Added the below to invoke item import in validate mode and return the status on 03/02/2015
      -- This is to validate CREATE records at Master Org and UPDATE records at all orgs

      /* Call the procedure to insert records into Interface tables if "Validated" records exist in temp table */

      OPEN get_validated_records;

      FETCH get_validated_records INTO v_count_temp_records;

      CLOSE get_validated_records;

      IF v_count_temp_records != 0
      THEN
         ILINK_item_insert_int (v_master_org_id, v_master_org_code);
         COMMIT;

         /* Added on 05/12/2015 to delete child org records when the item does not exist in EBS */

         DELETE FROM MTL_SYSTEM_ITEMS_INTERFACE msii
               WHERE     msii.set_process_id = 0
                     AND msii.organization_id != v_master_org_id
                     AND msii.transaction_type = 'CREATE'
                     AND NOT EXISTS
                                (SELECT 'x'
                                   FROM MTL_SYSTEM_ITEMS_B msi
                                  WHERE msi.organization_id = v_master_org_id
                                        AND msii.item_number = msi.segment1);

         DELETE FROM MTL_ITEM_REVISIONS_INTERFACE msii
               WHERE     msii.set_process_id = 0
                     AND msii.organization_id != v_master_org_id
                     AND msii.transaction_type = 'CREATE'
                     AND NOT EXISTS
                                (SELECT 'x'
                                   FROM MTL_SYSTEM_ITEMS_B msi
                                  WHERE msi.organization_id = v_master_org_id
                                        AND msii.item_number = msi.segment1);

         DELETE FROM MTL_ITEM_CATEGORIES_INTERFACE msii
               WHERE     msii.set_process_id = 0
                     AND msii.organization_id != v_master_org_id
                     AND msii.transaction_type = 'CREATE'
                     AND NOT EXISTS
                                (SELECT 'x'
                                   FROM MTL_SYSTEM_ITEMS_B msi
                                  WHERE msi.organization_id = v_master_org_id
                                        AND msii.item_number = msi.segment1);

         COMMIT;

         /* Call the procedure to run the Item Import if records exist in the Interface tables */

         OPEN get_item_intf_count;

         FETCH get_item_intf_count INTO v_count_item_intf;

         CLOSE get_item_intf_count;

         OPEN get_cat_intf_count;

         FETCH get_cat_intf_count INTO v_count_cat_intf;

         CLOSE get_cat_intf_count;

         IF (v_count_item_intf != 0) OR (v_count_cat_intf != 0)
         THEN
            v_req_id1 := NULL;
            v_req_id2 := NULL;

            ILINK_inv_pre_open_interface (v_master_org_id, v_req_id1, v_req_id2);
            COMMIT;

            /* call the procedure to review and report the errors from Item Import Interface */

            ILINK_post_item_val_interface (v_req_id1, v_req_id2);
            COMMIT;
         END IF;
      END IF;

      -- Error out all items on a change order even when one item at one org on that change order has failed

      UPDATE ILINK_MTL_ITEMS_INT_TEMP a
         SET record_status = 'Error',
             process_flag = 'Y',
             processed_date = SYSDATE,
             error_message = SUBSTR (error_message || ' REJECTED AS PART OF BATCH', 1, 3900)
       WHERE NVL (record_status, 'NA') != 'Error'
             AND EXISTS
                    (SELECT 'x'
                       FROM ILINK_MTL_ITEMS_INT_TEMP b
                      WHERE a.eco_number = b.eco_number AND b.record_status = 'Error'); -- End 03/02/2015

      COMMIT;


      -- Added the below to create the items at just master org

      /* Call the procedure to insert records into Interface tables if "Validated" records exist in temp table */

      OPEN get_validated_records;

      FETCH get_validated_records INTO v_count_temp_records;

      CLOSE get_validated_records;

      IF v_count_temp_records != 0
      THEN
         ILINK_item_insert_int (v_master_org_id, v_master_org_code);
         COMMIT;

         /* Delete child org records when the item does not exist in EBS */

         DELETE FROM MTL_SYSTEM_ITEMS_INTERFACE msii
               WHERE     msii.set_process_id = 0
                     AND msii.organization_id != v_master_org_id
                     AND msii.transaction_type = 'CREATE'
                     AND NOT EXISTS
                                (SELECT 'x'
                                   FROM MTL_SYSTEM_ITEMS_B msi
                                  WHERE msi.organization_id = v_master_org_id
                                        AND msii.item_number = msi.segment1);

         DELETE FROM MTL_ITEM_REVISIONS_INTERFACE msii
               WHERE     msii.set_process_id = 0
                     AND msii.organization_id != v_master_org_id
                     AND msii.transaction_type = 'CREATE'
                     AND NOT EXISTS
                                (SELECT 'x'
                                   FROM MTL_SYSTEM_ITEMS_B msi
                                  WHERE msi.organization_id = v_master_org_id
                                        AND msii.item_number = msi.segment1);

         DELETE FROM MTL_ITEM_CATEGORIES_INTERFACE msii
               WHERE     msii.set_process_id = 0
                     AND msii.organization_id != v_master_org_id
                     AND msii.transaction_type = 'CREATE'
                     AND NOT EXISTS
                                (SELECT 'x'
                                   FROM MTL_SYSTEM_ITEMS_B msi
                                  WHERE msi.organization_id = v_master_org_id
                                        AND msii.item_number = msi.segment1);

         /* Delete UPDATE Records From interface tables */

         DELETE FROM MTL_ITEM_CATEGORIES_INTERFACE msii
               WHERE msii.set_process_id = 0
                     AND EXISTS
                            (SELECT 'x'
                               FROM MTL_SYSTEM_ITEMS_INTERFACE msi
                              WHERE     msi.organization_id = msii.organization_id
                                    AND msi.item_number = msii.item_number
                                    AND msi.transaction_type = 'UPDATE');

         DELETE FROM MTL_SYSTEM_ITEMS_INTERFACE
               WHERE transaction_type = 'UPDATE';

         COMMIT;


         /* Call the procedure to run the Item Import if records exist in the Interface tables */

         OPEN get_item_intf_count;

         FETCH get_item_intf_count INTO v_count_item_intf;

         CLOSE get_item_intf_count;

         OPEN get_cat_intf_count;

         FETCH get_cat_intf_count INTO v_count_cat_intf;

         CLOSE get_cat_intf_count;

         IF (v_count_item_intf != 0) OR (v_count_cat_intf != 0)
         THEN
            v_req_id1 := NULL;
            v_req_id2 := NULL;

            ILINK_inv_open_interface (v_master_org_id, v_req_id1, v_req_id2);
            COMMIT;

            /* call the procedure to review and report the errors from Item Import Interface */

            ILINK_post_item_interface (v_req_id1, v_req_id2);
            COMMIT;
         END IF;
      END IF;


      -- Added the below to invoke item import in validate mode for child orgs

      /* Call the procedure to insert records into Interface tables if "Validated" records exist in temp table */

      OPEN get_validated_records;

      FETCH get_validated_records INTO v_count_temp_records;

      CLOSE get_validated_records;

      IF v_count_temp_records != 0
      THEN
         ILINK_item_insert_int (v_master_org_id, v_master_org_code);
         COMMIT;

         /* Call the procedure to run the Item Import if records exist in the Interface tables */

         OPEN get_item_intf_count;

         FETCH get_item_intf_count INTO v_count_item_intf;

         CLOSE get_item_intf_count;

         OPEN get_cat_intf_count;

         FETCH get_cat_intf_count INTO v_count_cat_intf;

         CLOSE get_cat_intf_count;

         IF (v_count_item_intf != 0) OR (v_count_cat_intf != 0)
         THEN
            v_req_id1 := NULL;
            v_req_id2 := NULL;

            ILINK_inv_pre_open_interface (v_master_org_id, v_req_id1, v_req_id2);
            COMMIT;

            /* call the procedure to review and report the errors from Item Import Interface */

            ILINK_post_item_val_interface (v_req_id1, v_req_id2);
            COMMIT;
         END IF;
      END IF;

      -- Error out all items on a change order even when one item at one org on that change order has failed

      UPDATE ILINK_MTL_ITEMS_INT_TEMP a
         SET record_status = 'Error',
             process_flag = 'Y',
             processed_date = SYSDATE,
             error_message = SUBSTR (error_message || ' REJECTED AS PART OF BATCH', 1, 3900)
       WHERE NVL (record_status, 'NA') != 'Error'
             AND EXISTS
                    (SELECT 'x'
                       FROM ILINK_MTL_ITEMS_INT_TEMP b
                      WHERE a.eco_number = b.eco_number AND b.record_status = 'Error'); -- End 03/02/2015

      -- Update Master Org Record item by suffixing Obsolete

      UPDATE MTL_SYSTEM_ITEMS_B msi
         SET segment1 = segment1 || '-IObsolete'
       WHERE msi.organization_id = v_master_org_id
             AND EXISTS
                    (SELECT 'x'
                       FROM ILINK_MTL_ITEMS_INT_TEMP imi
                      WHERE     msi.organization_id = imi.organization_id
                            AND msi.segment1 = imi.item_number
                            AND imi.transaction_type = 'CREATE')
             AND EXISTS
                    (SELECT 'x'
                       FROM ILINK_MTL_ITEMS_INT_TEMP imi
                      WHERE     imi.organization_id != v_master_org_id
                            AND msi.segment1 = imi.item_number
                            AND imi.record_status = 'Error');


      COMMIT;

      /* Call the procedure to insert records into Interface tables if "Validated" records exist in temp table */

      OPEN get_validated_records;

      FETCH get_validated_records INTO v_count_temp_records;

      CLOSE get_validated_records;

      IF v_count_temp_records != 0
      THEN
         ILINK_item_insert_int (v_master_org_id, v_master_org_code);
         COMMIT;

         /* Call the procedure to run the Item Import if records exist in the Interface tables */

         OPEN get_item_intf_count;

         FETCH get_item_intf_count INTO v_count_item_intf;

         CLOSE get_item_intf_count;

         OPEN get_cat_intf_count;

         FETCH get_cat_intf_count INTO v_count_cat_intf;

         CLOSE get_cat_intf_count;

         IF (v_count_item_intf != 0) OR (v_count_cat_intf != 0)
         THEN
            v_req_id1 := NULL;
            v_req_id2 := NULL;

            ILINK_inv_open_interface (v_master_org_id, v_req_id1, v_req_id2);
            COMMIT;

            /* call the procedure to review and report the errors from Item Import Interface */

            ILINK_post_item_interface (v_req_id1, v_req_id2);
            COMMIT;
         END IF;
      END IF;

      /* Call the procedure to update make/buy template for new items */

      ILINK_UPDATE_ITEM_TEMPLATES;
      COMMIT;

      OPEN get_item_intf_count1;

      FETCH get_item_intf_count1 INTO v_count_item_intf;

      CLOSE get_item_intf_count1;

      IF (v_count_item_intf != 0)
      THEN
         v_req_id1 := NULL;

         ILINK_INV_OPEN_INTERFACE1 (v_master_org_id, v_req_id1);
         COMMIT;

         ILINK_POST_ITEM_INTERFACE1 (v_req_id1);
         COMMIT;
      END IF;


      /* Call the procedure to perform post-item load activities */

      ILINK_POST_ITEM_LOAD (v_master_org_id, v_master_org_code);
      COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG, 'Error in Procedure ILINK_ITEM_INT_MAIN is ' || SQLERRM);
   END ILINK_ITEM_INT_MAIN;


   PROCEDURE ILINK_ITEM_COPY_ALL_ORG (p_master_org_id IN NUMBER, p_master_org_code IN VARCHAR2)
   IS
      /* Define a Cursor to fetch all items that need to be Inserted in Child Organizations */

      CURSOR get_items
      IS
         SELECT eco_number,
                record_id,
                item_number,
                description,
                item_status_code_agile,
                revision,
                part_type,
                attribute1,
                primary_uom_code,
                lot_serial_control,
                lot_control_code,
                serial_control_code,
                shelf_life_control,
                shelf_life_days,
                erp_product_line,
                erp_product_type,
                erp_product_sub_type,
                erp_platform,
                template_name,
                make_buy_template,
                obsolete_template,
                mfg_orgs,
                non_mfg_orgs,
                attribute2,
                po_category_code,
                service_used_for_repair,
                enable_service_billing,
                billing_type,
                service_request,
                serv_track_install_base,
                track_install_base,
                enable_contract_cover,
                service_returnable,
                service_category_code,
                item_type,
                shipping_qty_box,
                attribute4,
                attribute5,
                agile_item_cost,
                product_family_code,
                eco_orig_date,
                eco_rel_date,
                organization_code,
                record_status,
                process_flag,
                creation_date,
                created_by,
                last_update_date,
                last_updated_by
           FROM ILINK_MTL_ITEMS_INT_TEMP
          WHERE organization_code = 'ZZZ';

      /* Define a cursor to fecth Org ID */

      CURSOR get_org_id (
         p_org_code IN VARCHAR2)
      IS
         SELECT a.organization_id,
                a.auto_lot_alpha_prefix,
                a.auto_serial_alpha_prefix,
                a.sales_account,
                a.cost_of_sales_account,
                a.expense_account,
                b.disable_date
           FROM MTL_PARAMETERS a, ORG_ORGANIZATION_DEFINITIONS b
          WHERE     a.organization_code = p_org_code
                AND a.organization_id = b.organization_id(+)
                AND (b.disable_date(+) IS NULL OR b.disable_date(+) > SYSDATE);


      /* Define a cursor to fetch Item Creation Org(s) */

      CURSOR get_item_orgs
      IS
         SELECT data_output1
           FROM ILINK_DATA_XREF
          WHERE data_input1 = 'Item Creation Orgs';

      -- Added the below cursors on 06/02/2014

      /* Define a cusor to fetch items which exists at master org and not at child orgs */

      CURSOR get_new_org_items
      IS
         SELECT a.eco_number,
                a.item_number,
                a.organization_code,
                b.inventory_item_id
           FROM ILINK_MTL_ITEMS_INT_TEMP a, ILINK_MTL_SYSTEM_ITEMS_VIEW b
          WHERE     NVL (a.process_flag, 'N') = 'N'
                AND NVL (a.attribute15, 'N') = 'N'
                AND a.item_number = b.item_number
                AND b.organization_id = p_master_org_id
                AND NOT EXISTS
                           (SELECT 'X'
                              FROM ILINK_MTL_SYSTEM_ITEMS_VIEW c
                             WHERE b.inventory_item_id = c.inventory_item_id
                                   AND a.organization_id = c.organization_id);

      /* Define a cursor to fetch Inventory And PO Category of an item */

      CURSOR get_category_code (
         p_category_set_name   IN VARCHAR2,
         p_inventory_item_id   IN NUMBER)
      IS
         SELECT mc.category_concat_segs category_value
           FROM MTL_CATEGORY_SETS MCS, MTL_CATEGORIES_V MC, MTL_ITEM_CATEGORIES MIC
          WHERE     mcs.category_set_name = p_category_set_name
                AND mic.organization_id = p_master_org_id
                AND mic.inventory_item_id = p_inventory_item_id
                AND mcs.category_set_id = mic.category_set_id
                AND mic.category_id = mc.category_id;                              -- End 06/02/2014


      v_rec_date        DATE := SYSDATE;
      v_org_code        VARCHAR2 (1000);
      v_pos             NUMBER;
      v_num             NUMBER;
      v_var             NUMBER;
      v_pos1            NUMBER;
      v_num1            NUMBER;
      v_var1            NUMBER;
      v_org_id          NUMBER;
      v_lot_prefix      VARCHAR2 (100);
      v_serial_prefix   VARCHAR2 (100);
      v_sales_acct      NUMBER;
      v_cogs_acct       NUMBER;
      v_exp_acct        NUMBER;
      v_item_orgs       VARCHAR2 (150);
      v_po_tax_orgs     VARCHAR2 (150)
                           := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('PO Taxable Orgs',
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL);
      v_po_tax_flag     VARCHAR2 (150)
                           := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Default Taxable Flag',
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL);
      v_po_tax_code     VARCHAR2 (150)
                           := ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                                 'Default Purchasing Tax Code',
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL);
      v_po_org_code     VARCHAR2 (150);
      v_po_org_flag     VARCHAR2 (1);
      v_disable_date    DATE;
      v_po_cat_code     VARCHAR2 (100);                                       -- Added on 06/02/2014
      v_inv_cat_code    VARCHAR2 (100);                                       -- Added on 06/02/2014
      v_tax_code_dff    VARCHAR2 (100);                                       -- Added on 06/02/2014
   BEGIN
      /* Fetch Item Creation Orgs String */

      OPEN get_item_orgs;

      FETCH get_item_orgs INTO v_item_orgs;

      CLOSE get_item_orgs;

      /* populate Item records for mfg organizations */

      FOR c_valid_items IN get_items
      LOOP
         -- Fetch Mfg Orgs

         v_org_code := NULL;
         v_pos := 0;
         v_var := 0;

         LOOP
            v_pos := v_pos + 1;

            SELECT INSTR (NVL (c_valid_items.mfg_orgs, '!'),
                          ' ',
                          1,
                          v_pos)
              INTO v_num
              FROM DUAL;

            IF v_num != 0
            THEN
               SELECT SUBSTR (c_valid_items.mfg_orgs, v_var + 1, v_num - (v_var + 1))
                 INTO v_org_code
                 FROM DUAL;
            ELSIF v_num = 0
            THEN
               SELECT SUBSTR (c_valid_items.mfg_orgs, v_var + 1, LENGTH (c_valid_items.mfg_orgs))
                 INTO v_org_code
                 FROM DUAL;
            END IF;

            v_org_id := NULL;
            v_lot_prefix := NULL;
            v_serial_prefix := NULL;
            v_sales_acct := NULL;
            v_cogs_acct := NULL;
            v_exp_acct := NULL;
            v_disable_date := NULL;

            OPEN get_org_id (v_org_code);

            FETCH get_org_id
            INTO v_org_id,
                 v_lot_prefix,
                 v_serial_prefix,
                 v_sales_acct,
                 v_cogs_acct,
                 v_exp_acct,
                 v_disable_date;

            CLOSE get_org_id;

            -- Check if this org is part of the PO Taxbale Orgs

            v_po_org_code := NULL;
            v_po_org_flag := NULL;
            v_pos1 := 0;
            v_var1 := 0;

            LOOP
               v_pos1 := v_pos1 + 1;

               SELECT INSTR (NVL (v_po_tax_orgs, '!'),
                             ',',
                             1,
                             v_pos1)
                 INTO v_num1
                 FROM DUAL;

               IF v_num1 != 0
               THEN
                  SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, v_num1 - (v_var1 + 1))
                    INTO v_po_org_code
                    FROM DUAL;
               ELSIF v_num1 = 0
               THEN
                  SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, LENGTH (v_po_tax_orgs))
                    INTO v_po_org_code
                    FROM DUAL;
               END IF;

               IF v_po_org_code = v_org_code
               THEN
                  v_po_org_flag := 'Y';
               END IF;

               v_var1 := v_num1;

               EXIT WHEN v_num1 = 0;
            END LOOP;

            IF v_org_id IS NOT NULL AND v_disable_date IS NULL
            THEN
               INSERT INTO ILINK_MTL_ITEMS_INT_TEMP (eco_number,
                                                     record_id,
                                                     item_number,
                                                     description,
                                                     item_status_code_agile,
                                                     revision,
                                                     part_type,
                                                     attribute1,
                                                     primary_uom_code,
                                                     lot_serial_control,
                                                     lot_control_code,
                                                     serial_control_code,
                                                     shelf_life_control,
                                                     shelf_life_days,
                                                     erp_product_line,
                                                     erp_product_type,
                                                     erp_product_sub_type,
                                                     erp_platform,
                                                     inv_category_code,
                                                     attribute3,
                                                     sales_account_id,
                                                     cost_of_sales_acct_id,
                                                     expense_account_id,
                                                     template_name,
                                                     make_buy_template,
                                                     obsolete_template,
                                                     mfg_orgs,
                                                     non_mfg_orgs,
                                                     attribute2,
                                                     po_category_code,
                                                     service_used_for_repair,
                                                     enable_service_billing,
                                                     billing_type,
                                                     service_request,
                                                     serv_track_install_base,
                                                     track_install_base,
                                                     enable_contract_cover,
                                                     service_returnable,
                                                     service_category_code,
                                                     item_type,
                                                     shipping_qty_box,
                                                     taxable_flag,
                                                     po_tax_code,
                                                     auto_lot_alpha_prefix,
                                                     start_auto_lot_number,
                                                     auto_serial_prefix,
                                                     start_serial_number,
                                                     attribute4,
                                                     attribute5,
                                                     agile_item_cost,
                                                     product_family_code,
                                                     eco_orig_date,
                                                     eco_rel_date,
                                                     organization_code,
                                                     organization_id,
                                                     record_status,
                                                     process_flag,
                                                     creation_date,
                                                     created_by,
                                                     last_update_date,
                                                     last_updated_by)
                    VALUES (
                              c_valid_items.eco_number,
                              c_valid_items.record_id,
                              c_valid_items.item_number,
                              c_valid_items.description,
                              c_valid_items.item_status_code_agile,
                              c_valid_items.revision,
                              c_valid_items.part_type,
                              c_valid_items.attribute1,
                              c_valid_items.primary_uom_code,
                              c_valid_items.lot_serial_control,
                              c_valid_items.lot_control_code,
                              c_valid_items.serial_control_code,
                              c_valid_items.shelf_life_control,
                              c_valid_items.shelf_life_days,
                              c_valid_items.erp_product_line,
                              c_valid_items.erp_product_type,
                              c_valid_items.erp_product_sub_type,
                              c_valid_items.erp_platform,
                                 c_valid_items.erp_product_line
                              || '.'
                              || c_valid_items.erp_product_type
                              || '.'
                              || c_valid_items.erp_product_sub_type
                              || '.'
                              || c_valid_items.erp_platform,
                                 c_valid_items.erp_product_line
                              || '.'
                              || c_valid_items.erp_product_type
                              || '.'
                              || c_valid_items.erp_product_sub_type,
                              v_sales_acct,
                              v_cogs_acct,
                              v_exp_acct,
                              c_valid_items.template_name,
                              c_valid_items.make_buy_template,
                              c_valid_items.obsolete_template,
                              c_valid_items.mfg_orgs,
                              c_valid_items.non_mfg_orgs,
                              c_valid_items.attribute2,
                              c_valid_items.po_category_code,
                              c_valid_items.service_used_for_repair,
                              c_valid_items.enable_service_billing,
                              c_valid_items.billing_type,
                              c_valid_items.service_request,
                              c_valid_items.serv_track_install_base,
                              c_valid_items.track_install_base,
                              c_valid_items.enable_contract_cover,
                              c_valid_items.service_returnable,
                              c_valid_items.service_category_code,
                              c_valid_items.item_type,
                              c_valid_items.shipping_qty_box,
                              DECODE (v_po_org_flag,  'Y', v_po_tax_flag,  NULL, NULL,  NULL),
                              DECODE (v_po_org_flag,  'Y', v_po_tax_code,  NULL, NULL,  NULL),
                              DECODE (v_lot_prefix, NULL, v_org_code, v_lot_prefix),
                              ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                                 'Default Start Auto Lot Number',
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL),
                              DECODE (v_serial_prefix, NULL, v_org_code, v_serial_prefix),
                              ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                                 'Default Start Auto Serial Number',
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL),
                              c_valid_items.attribute4,
                              c_valid_items.attribute5,
                              c_valid_items.agile_item_cost,
                              c_valid_items.product_family_code,
                              c_valid_items.eco_orig_date,
                              c_valid_items.eco_rel_date,
                              v_org_code,
                              v_org_id,
                              c_valid_items.record_status,
                              c_valid_items.process_flag,
                              v_rec_date,
                              v_user_id,
                              v_rec_date,
                              v_user_id);
            END IF;

            v_var := v_num;

            EXIT WHEN v_num = 0;
         END LOOP;


         -- Fetch Non-Mfg Orgs

         v_org_code := NULL;
         v_pos := 0;
         v_var := 0;

         LOOP
            v_pos := v_pos + 1;

            SELECT INSTR (NVL (c_valid_items.non_mfg_orgs, '!'),
                          ' ',
                          1,
                          v_pos)
              INTO v_num
              FROM DUAL;

            IF v_num != 0
            THEN
               SELECT SUBSTR (c_valid_items.non_mfg_orgs, v_var + 1, v_num - (v_var + 1))
                 INTO v_org_code
                 FROM DUAL;
            ELSIF v_num = 0
            THEN
               SELECT SUBSTR (c_valid_items.non_mfg_orgs,
                              v_var + 1,
                              LENGTH (c_valid_items.non_mfg_orgs))
                 INTO v_org_code
                 FROM DUAL;
            END IF;

            v_org_id := NULL;
            v_lot_prefix := NULL;
            v_serial_prefix := NULL;
            v_sales_acct := NULL;
            v_cogs_acct := NULL;
            v_exp_acct := NULL;
            v_disable_date := NULL;

            OPEN get_org_id (v_org_code);

            FETCH get_org_id
            INTO v_org_id,
                 v_lot_prefix,
                 v_serial_prefix,
                 v_sales_acct,
                 v_cogs_acct,
                 v_exp_acct,
                 v_disable_date;

            CLOSE get_org_id;

            -- Check if this org is part of the PO Taxbale Orgs

            v_po_org_code := NULL;
            v_po_org_flag := NULL;
            v_pos1 := 0;
            v_var1 := 0;

            LOOP
               v_pos1 := v_pos1 + 1;

               SELECT INSTR (NVL (v_po_tax_orgs, '!'),
                             ',',
                             1,
                             v_pos1)
                 INTO v_num1
                 FROM DUAL;

               IF v_num1 != 0
               THEN
                  SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, v_num1 - (v_var1 + 1))
                    INTO v_po_org_code
                    FROM DUAL;
               ELSIF v_num1 = 0
               THEN
                  SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, LENGTH (v_po_tax_orgs))
                    INTO v_po_org_code
                    FROM DUAL;
               END IF;

               IF v_po_org_code = v_org_code
               THEN
                  v_po_org_flag := 'Y';
               END IF;

               v_var1 := v_num1;

               EXIT WHEN v_num1 = 0;
            END LOOP;

            IF v_org_id IS NOT NULL AND v_disable_date IS NULL
            THEN
               INSERT INTO ILINK_MTL_ITEMS_INT_TEMP (eco_number,
                                                     record_id,
                                                     item_number,
                                                     description,
                                                     item_status_code_agile,
                                                     revision,
                                                     part_type,
                                                     attribute1,
                                                     primary_uom_code,
                                                     lot_serial_control,
                                                     lot_control_code,
                                                     serial_control_code,
                                                     shelf_life_control,
                                                     shelf_life_days,
                                                     erp_product_line,
                                                     erp_product_type,
                                                     erp_product_sub_type,
                                                     erp_platform,
                                                     inv_category_code,
                                                     attribute3,
                                                     sales_account_id,
                                                     cost_of_sales_acct_id,
                                                     expense_account_id,
                                                     template_name,
                                                     make_buy_template,
                                                     obsolete_template,
                                                     mfg_orgs,
                                                     non_mfg_orgs,
                                                     attribute2,
                                                     po_category_code,
                                                     service_used_for_repair,
                                                     enable_service_billing,
                                                     billing_type,
                                                     service_request,
                                                     serv_track_install_base,
                                                     track_install_base,
                                                     enable_contract_cover,
                                                     service_returnable,
                                                     service_category_code,
                                                     item_type,
                                                     shipping_qty_box,
                                                     taxable_flag,
                                                     po_tax_code,
                                                     auto_lot_alpha_prefix,
                                                     start_auto_lot_number,
                                                     auto_serial_prefix,
                                                     start_serial_number,
                                                     attribute4,
                                                     attribute5,
                                                     agile_item_cost,
                                                     product_family_code,
                                                     eco_orig_date,
                                                     eco_rel_date,
                                                     organization_code,
                                                     organization_id,
                                                     record_status,
                                                     process_flag,
                                                     creation_date,
                                                     created_by,
                                                     last_update_date,
                                                     last_updated_by)
                  SELECT itm1.eco_number,
                         itm1.record_id,
                         itm1.item_number,
                         itm1.description,
                         itm1.item_status_code_agile,
                         itm1.revision,
                         itm1.part_type,
                         itm1.attribute1,
                         itm1.primary_uom_code,
                         itm1.lot_serial_control,
                         itm1.lot_control_code,
                         itm1.serial_control_code,
                         itm1.shelf_life_control,
                         itm1.shelf_life_days,
                         itm1.erp_product_line,
                         itm1.erp_product_type,
                         itm1.erp_product_sub_type,
                         itm1.erp_platform,
                            itm1.erp_product_line
                         || '.'
                         || itm1.erp_product_type
                         || '.'
                         || itm1.erp_product_sub_type
                         || '.'
                         || itm1.erp_platform,
                            itm1.erp_product_line
                         || '.'
                         || itm1.erp_product_type
                         || '.'
                         || itm1.erp_product_sub_type,
                         v_sales_acct,
                         v_cogs_acct,
                         v_exp_acct,
                         itm1.template_name,
                         itm1.make_buy_template,
                         itm1.obsolete_template,
                         itm1.mfg_orgs,
                         itm1.non_mfg_orgs,
                         itm1.attribute2,
                         itm1.po_category_code,
                         itm1.service_used_for_repair,
                         itm1.enable_service_billing,
                         itm1.billing_type,
                         itm1.service_request,
                         itm1.serv_track_install_base,
                         itm1.track_install_base,
                         itm1.enable_contract_cover,
                         itm1.service_returnable,
                         itm1.service_category_code,
                         itm1.item_type,
                         itm1.shipping_qty_box,
                         DECODE (v_po_org_flag,  'Y', v_po_tax_flag,  NULL, NULL,  NULL),
                         DECODE (v_po_org_flag,  'Y', v_po_tax_code,  NULL, NULL,  NULL),
                         DECODE (v_lot_prefix, NULL, v_org_code, v_lot_prefix),
                         ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Default Start Auto Lot Number',
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL),
                         DECODE (v_serial_prefix, NULL, v_org_code, v_serial_prefix),
                         ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                            'Default Start Auto Serial Number',
                            NULL,
                            NULL,
                            NULL,
                            NULL),
                         itm1.attribute4,
                         itm1.attribute5,
                         itm1.agile_item_cost,
                         itm1.product_family_code,
                         itm1.eco_orig_date,
                         itm1.eco_rel_date,
                         v_org_code,
                         v_org_id,
                         itm1.record_status,
                         itm1.process_flag,
                         v_rec_date,
                         v_user_id,
                         v_rec_date,
                         v_user_id
                    FROM ILINK_MTL_ITEMS_INT_TEMP itm1
                   WHERE     itm1.eco_number = c_valid_items.eco_number
                         AND itm1.item_number = c_valid_items.item_number
                         AND itm1.organization_code = 'ZZZ'
                         AND NOT EXISTS
                                    (SELECT 'x'
                                       FROM ILINK_MTL_ITEMS_INT_TEMP itm2
                                      WHERE     itm2.organization_id = v_org_id
                                            AND itm2.eco_number = itm1.eco_number
                                            AND itm2.item_number = itm1.item_number);
            END IF;

            v_var := v_num;

            EXIT WHEN v_num = 0;
         END LOOP;


         -- Fetch Item Creation Orgs

         v_org_code := NULL;
         v_pos := 0;
         v_var := 0;

         LOOP
            v_pos := v_pos + 1;

            SELECT INSTR (NVL (v_item_orgs, '!'),
                          ',',
                          1,
                          v_pos)
              INTO v_num
              FROM DUAL;

            IF v_num != 0
            THEN
               SELECT SUBSTR (v_item_orgs, v_var + 1, v_num - (v_var + 1))
                 INTO v_org_code
                 FROM DUAL;
            ELSIF v_num = 0
            THEN
               SELECT SUBSTR (v_item_orgs, v_var + 1, LENGTH (v_item_orgs))
                 INTO v_org_code
                 FROM DUAL;
            END IF;

            v_org_id := NULL;
            v_lot_prefix := NULL;
            v_serial_prefix := NULL;
            v_sales_acct := NULL;
            v_cogs_acct := NULL;
            v_exp_acct := NULL;
            v_disable_date := NULL;

            OPEN get_org_id (v_org_code);

            FETCH get_org_id
            INTO v_org_id,
                 v_lot_prefix,
                 v_serial_prefix,
                 v_sales_acct,
                 v_cogs_acct,
                 v_exp_acct,
                 v_disable_date;

            CLOSE get_org_id;

            -- Check if this org is part of the PO Taxbale Orgs

            v_po_org_code := NULL;
            v_po_org_flag := NULL;
            v_pos1 := 0;
            v_var1 := 0;

            LOOP
               v_pos1 := v_pos1 + 1;

               SELECT INSTR (NVL (v_po_tax_orgs, '!'),
                             ',',
                             1,
                             v_pos1)
                 INTO v_num1
                 FROM DUAL;

               IF v_num1 != 0
               THEN
                  SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, v_num1 - (v_var1 + 1))
                    INTO v_po_org_code
                    FROM DUAL;
               ELSIF v_num1 = 0
               THEN
                  SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, LENGTH (v_po_tax_orgs))
                    INTO v_po_org_code
                    FROM DUAL;
               END IF;

               IF v_po_org_code = v_org_code
               THEN
                  v_po_org_flag := 'Y';
               END IF;

               v_var1 := v_num1;

               EXIT WHEN v_num1 = 0;
            END LOOP;

            IF v_org_id IS NOT NULL AND v_disable_date IS NULL
            THEN
               INSERT INTO ILINK_MTL_ITEMS_INT_TEMP (eco_number,
                                                     record_id,
                                                     item_number,
                                                     description,
                                                     item_status_code_agile,
                                                     revision,
                                                     part_type,
                                                     attribute1,
                                                     primary_uom_code,
                                                     lot_serial_control,
                                                     lot_control_code,
                                                     serial_control_code,
                                                     shelf_life_control,
                                                     shelf_life_days,
                                                     erp_product_line,
                                                     erp_product_type,
                                                     erp_product_sub_type,
                                                     erp_platform,
                                                     inv_category_code,
                                                     attribute3,
                                                     sales_account_id,
                                                     cost_of_sales_acct_id,
                                                     expense_account_id,
                                                     template_name,
                                                     make_buy_template,
                                                     obsolete_template,
                                                     mfg_orgs,
                                                     non_mfg_orgs,
                                                     attribute2,
                                                     po_category_code,
                                                     service_used_for_repair,
                                                     enable_service_billing,
                                                     billing_type,
                                                     service_request,
                                                     serv_track_install_base,
                                                     track_install_base,
                                                     enable_contract_cover,
                                                     service_returnable,
                                                     service_category_code,
                                                     item_type,
                                                     shipping_qty_box,
                                                     taxable_flag,
                                                     po_tax_code,
                                                     auto_lot_alpha_prefix,
                                                     start_auto_lot_number,
                                                     auto_serial_prefix,
                                                     start_serial_number,
                                                     attribute4,
                                                     attribute5,
                                                     agile_item_cost,
                                                     product_family_code,
                                                     eco_orig_date,
                                                     eco_rel_date,
                                                     organization_code,
                                                     organization_id,
                                                     record_status,
                                                     process_flag,
                                                     creation_date,
                                                     created_by,
                                                     last_update_date,
                                                     last_updated_by)
                  SELECT itm1.eco_number,
                         itm1.record_id,
                         itm1.item_number,
                         itm1.description,
                         itm1.item_status_code_agile,
                         itm1.revision,
                         itm1.part_type,
                         itm1.attribute1,
                         itm1.primary_uom_code,
                         itm1.lot_serial_control,
                         itm1.lot_control_code,
                         itm1.serial_control_code,
                         itm1.shelf_life_control,
                         itm1.shelf_life_days,
                         itm1.erp_product_line,
                         itm1.erp_product_type,
                         itm1.erp_product_sub_type,
                         itm1.erp_platform,
                            itm1.erp_product_line
                         || '.'
                         || itm1.erp_product_type
                         || '.'
                         || itm1.erp_product_sub_type
                         || '.'
                         || itm1.erp_platform,
                            itm1.erp_product_line
                         || '.'
                         || itm1.erp_product_type
                         || '.'
                         || itm1.erp_product_sub_type,
                         v_sales_acct,
                         v_cogs_acct,
                         v_exp_acct,
                         itm1.template_name,
                         itm1.make_buy_template,
                         itm1.obsolete_template,
                         itm1.mfg_orgs,
                         itm1.non_mfg_orgs,
                         itm1.attribute2,
                         itm1.po_category_code,
                         itm1.service_used_for_repair,
                         itm1.enable_service_billing,
                         itm1.billing_type,
                         itm1.service_request,
                         itm1.serv_track_install_base,
                         itm1.track_install_base,
                         itm1.enable_contract_cover,
                         itm1.service_returnable,
                         itm1.service_category_code,
                         itm1.item_type,
                         itm1.shipping_qty_box,
                         DECODE (v_po_org_flag,  'Y', v_po_tax_flag,  NULL, NULL,  NULL),
                         DECODE (v_po_org_flag,  'Y', v_po_tax_code,  NULL, NULL,  NULL),
                         DECODE (v_lot_prefix, NULL, v_org_code, v_lot_prefix),
                         ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Default Start Auto Lot Number',
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL),
                         DECODE (v_serial_prefix, NULL, v_org_code, v_serial_prefix),
                         ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                            'Default Start Auto Serial Number',
                            NULL,
                            NULL,
                            NULL,
                            NULL),
                         itm1.attribute4,
                         itm1.attribute5,
                         itm1.agile_item_cost,
                         itm1.product_family_code,
                         itm1.eco_orig_date,
                         itm1.eco_rel_date,
                         v_org_code,
                         v_org_id,
                         itm1.record_status,
                         itm1.process_flag,
                         v_rec_date,
                         v_user_id,
                         v_rec_date,
                         v_user_id
                    FROM ILINK_MTL_ITEMS_INT_TEMP itm1
                   WHERE     itm1.eco_number = c_valid_items.eco_number
                         AND itm1.item_number = c_valid_items.item_number
                         AND itm1.organization_code = 'ZZZ'
                         AND NOT EXISTS
                                    (SELECT 'x'
                                       FROM ILINK_MTL_ITEMS_INT_TEMP itm2
                                      WHERE     itm2.organization_id = v_org_id
                                            AND itm2.eco_number = itm1.eco_number
                                            AND itm2.item_number = itm1.item_number);
            END IF;

            v_var := v_num;

            EXIT WHEN v_num = 0;
         END LOOP;


         -- Master Org Record

         v_org_id := NULL;
         v_lot_prefix := NULL;
         v_serial_prefix := NULL;
         v_sales_acct := NULL;
         v_cogs_acct := NULL;
         v_exp_acct := NULL;
         v_disable_date := NULL;

         OPEN get_org_id (p_master_org_code);

         FETCH get_org_id
         INTO v_org_id,
              v_lot_prefix,
              v_serial_prefix,
              v_sales_acct,
              v_cogs_acct,
              v_exp_acct,
              v_disable_date;

         CLOSE get_org_id;

         -- Check if this org is part of the PO Taxbale Orgs

         v_po_org_code := NULL;
         v_po_org_flag := NULL;
         v_pos1 := 0;
         v_var1 := 0;

         LOOP
            v_pos1 := v_pos1 + 1;

            SELECT INSTR (NVL (v_po_tax_orgs, '!'),
                          ',',
                          1,
                          v_pos1)
              INTO v_num1
              FROM DUAL;

            IF v_num1 != 0
            THEN
               SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, v_num1 - (v_var1 + 1))
                 INTO v_po_org_code
                 FROM DUAL;
            ELSIF v_num1 = 0
            THEN
               SELECT SUBSTR (v_po_tax_orgs, v_var1 + 1, LENGTH (v_po_tax_orgs))
                 INTO v_po_org_code
                 FROM DUAL;
            END IF;

            IF v_po_org_code = p_master_org_code
            THEN
               v_po_org_flag := 'Y';
            END IF;

            v_var1 := v_num1;

            EXIT WHEN v_num1 = 0;
         END LOOP;

         IF v_org_id IS NOT NULL
         THEN
            INSERT INTO ILINK_MTL_ITEMS_INT_TEMP (eco_number,
                                                  record_id,
                                                  item_number,
                                                  description,
                                                  item_status_code_agile,
                                                  revision,
                                                  part_type,
                                                  attribute1,
                                                  primary_uom_code,
                                                  lot_serial_control,
                                                  lot_control_code,
                                                  serial_control_code,
                                                  shelf_life_control,
                                                  shelf_life_days,
                                                  erp_product_line,
                                                  erp_product_type,
                                                  erp_product_sub_type,
                                                  erp_platform,
                                                  inv_category_code,
                                                  attribute3,
                                                  sales_account_id,
                                                  cost_of_sales_acct_id,
                                                  expense_account_id,
                                                  template_name,
                                                  make_buy_template,
                                                  obsolete_template,
                                                  mfg_orgs,
                                                  non_mfg_orgs,
                                                  attribute2,
                                                  po_category_code,
                                                  service_used_for_repair,
                                                  enable_service_billing,
                                                  billing_type,
                                                  service_request,
                                                  serv_track_install_base,
                                                  track_install_base,
                                                  enable_contract_cover,
                                                  service_returnable,
                                                  service_category_code,
                                                  item_type,
                                                  shipping_qty_box,
                                                  taxable_flag,
                                                  po_tax_code,
                                                  auto_lot_alpha_prefix,
                                                  start_auto_lot_number,
                                                  auto_serial_prefix,
                                                  start_serial_number,
                                                  attribute4,
                                                  attribute5,
                                                  agile_item_cost,
                                                  product_family_code,
                                                  eco_orig_date,
                                                  eco_rel_date,
                                                  organization_code,
                                                  organization_id,
                                                  record_status,
                                                  process_flag,
                                                  creation_date,
                                                  created_by,
                                                  last_update_date,
                                                  last_updated_by)
                 VALUES (
                           c_valid_items.eco_number,
                           c_valid_items.record_id,
                           c_valid_items.item_number,
                           c_valid_items.description,
                           c_valid_items.item_status_code_agile,
                           c_valid_items.revision,
                           c_valid_items.part_type,
                           c_valid_items.attribute1,
                           c_valid_items.primary_uom_code,
                           c_valid_items.lot_serial_control,
                           c_valid_items.lot_control_code,
                           c_valid_items.serial_control_code,
                           c_valid_items.shelf_life_control,
                           c_valid_items.shelf_life_days,
                           c_valid_items.erp_product_line,
                           c_valid_items.erp_product_type,
                           c_valid_items.erp_product_sub_type,
                           c_valid_items.erp_platform,
                              c_valid_items.erp_product_line
                           || '.'
                           || c_valid_items.erp_product_type
                           || '.'
                           || c_valid_items.erp_product_sub_type
                           || '.'
                           || c_valid_items.erp_platform,
                              c_valid_items.erp_product_line
                           || '.'
                           || c_valid_items.erp_product_type
                           || '.'
                           || c_valid_items.erp_product_sub_type,
                           v_sales_acct,
                           v_cogs_acct,
                           v_exp_acct,
                           c_valid_items.template_name,
                           c_valid_items.make_buy_template,
                           c_valid_items.obsolete_template,
                           c_valid_items.mfg_orgs,
                           c_valid_items.non_mfg_orgs,
                           c_valid_items.attribute2,
                           c_valid_items.po_category_code,
                           c_valid_items.service_used_for_repair,
                           c_valid_items.enable_service_billing,
                           c_valid_items.billing_type,
                           c_valid_items.service_request,
                           c_valid_items.serv_track_install_base,
                           c_valid_items.track_install_base,
                           c_valid_items.enable_contract_cover,
                           c_valid_items.service_returnable,
                           c_valid_items.service_category_code,
                           c_valid_items.item_type,
                           c_valid_items.shipping_qty_box,
                           DECODE (v_po_org_flag,  'Y', v_po_tax_flag,  NULL, NULL,  NULL),
                           DECODE (v_po_org_flag,  'Y', v_po_tax_code,  NULL, NULL,  NULL),
                           DECODE (v_lot_prefix, NULL, p_master_org_code, v_lot_prefix),
                           ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                              'Default Start Auto Lot Number',
                              NULL,
                              NULL,
                              NULL,
                              NULL),
                           DECODE (v_serial_prefix, NULL, p_master_org_code, v_serial_prefix),
                           ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                              'Default Start Auto Serial Number',
                              NULL,
                              NULL,
                              NULL,
                              NULL),
                           c_valid_items.attribute4,
                           c_valid_items.attribute5,
                           c_valid_items.agile_item_cost,
                           c_valid_items.product_family_code,
                           c_valid_items.eco_orig_date,
                           c_valid_items.eco_rel_date,
                           p_master_org_code,
                           v_org_id,
                           c_valid_items.record_status,
                           c_valid_items.process_flag,
                           v_rec_date,
                           v_user_id,
                           v_rec_date,
                           v_user_id);
         END IF;
      END LOOP;                                                                     -- c_valid_items



      /* Update the organization value as master organization for each Item record in temp table along with WHO information

        Update ILINK_MTL_ITEMS_INT_TEMP
        Set organization_code = p_master_org_code,
        organization_id = p_master_org_id,
        created_by = v_user_id,
        creation_date = v_rec_date,
        last_updated_by = v_user_id,
        last_update_date = v_rec_date
        Where organization_code = 'ZZZ';      */


      /* Delete the master org records */

      DELETE FROM ILINK_MTL_ITEMS_INT_TEMP
            WHERE organization_code = 'ZZZ';


      -- Added the below on 06/02/2014 to populate inv, po categories and related attributes from master org

      FOR c1 IN get_new_org_items
      LOOP
         v_po_cat_code := NULL;
         v_inv_cat_code := NULL;
         v_tax_code_dff := NULL;

         OPEN get_category_code (v_inv_cat_set_name, c1.inventory_item_id);

         FETCH get_category_code INTO v_inv_cat_code;

         CLOSE get_category_code;

         OPEN get_category_code (v_po_cat_set_name, c1.inventory_item_id);

         FETCH get_category_code INTO v_po_cat_code;

         CLOSE get_category_code;

         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET inv_category_code = v_inv_cat_code,
                po_category_code = v_po_cat_code,
                attribute3 =
                   SUBSTR (v_inv_cat_code,
                           1,
                           INSTR (v_inv_cat_code,
                                  '.',
                                  1,
                                  3)
                           - 1),
                attribute15 = 'Y'
          WHERE     eco_number = c1.eco_number
                AND item_number = c1.item_number
                AND organization_code = c1.organization_code;
      END LOOP;                                                                    -- End 06/02/2014
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_ITEM_COPY_ALL_ORG is ' || SQLERRM);
   END ILINK_ITEM_COPY_ALL_ORG;


   -- Added this procedure on 01/30/2015

   PROCEDURE CREATE_GL_ACCOUNT (p_org_id      IN     NUMBER,
                                p_acct_id     IN     NUMBER,
                                p_prd_line    IN     VARCHAR2,
                                p_acct_str       OUT VARCHAR2,
                                p_acct_id1       OUT NUMBER,
                                p_error_msg      OUT VARCHAR2)
   IS
      CURSOR get_account_str (
         p_account_id     IN NUMBER,
         p_product_line   IN VARCHAR2)
      IS
         SELECT    segment1
                || '.'
                || p_product_line
                || '.'
                || segment3
                || '.'
                || segment4
                || '.'
                || segment5
                || '.'
                || segment6
                || '.'
                || segment7
                || '.'
                || segment8
                || '.'
                || segment9
           FROM GL_CODE_COMBINATIONS
          WHERE code_combination_id = p_account_id;

      CURSOR get_coa_id (p_organization_id IN NUMBER)
      IS
         SELECT chart_of_accounts_id
           FROM ORG_ORGANIZATION_DEFINITIONS
          WHERE organization_id = p_organization_id;

      CURSOR get_acct_id (p_account_str IN VARCHAR2)
      IS
         SELECT code_combination_id
           FROM GL_CODE_COMBINATIONS
          WHERE    segment1
                || '.'
                || segment2
                || '.'
                || segment3
                || '.'
                || segment4
                || '.'
                || segment5
                || '.'
                || segment6
                || '.'
                || segment7
                || '.'
                || segment8
                || '.'
                || segment9 = p_account_str;

      v_keyval_status   BOOLEAN;
      v_coa_id          NUMBER;
      v_acct_str        VARCHAR2 (500);
      v_acct_id         NUMBER;
      v_error_msg       VARCHAR2 (500);
   BEGIN
      OPEN get_coa_id (p_org_id);

      FETCH get_coa_id INTO v_coa_id;

      CLOSE get_coa_id;

      OPEN get_account_str (p_acct_id, p_prd_line);

      FETCH get_account_str INTO v_acct_str;

      CLOSE get_account_str;

      -- keyval_mode can be one of CREATE_COMBINATION CHECK_COMBINATION FIND_COMBINATION
      -- create will only work if dynamic inserts on and cross validation rules not broken

      v_keyval_status :=
         fnd_flex_keyval.validate_segs ('CREATE_COMBINATION',
                                        'SQLGL',
                                        'GL#',
                                        v_coa_id,
                                        v_acct_str,
                                        'V',
                                        SYSDATE,
                                        'ALL',
                                        NULL,
                                        NULL,
                                        NULL,
                                        NULL,
                                        FALSE,
                                        FALSE,
                                        NULL,
                                        NULL,
                                        NULL);

      SELECT SUBSTR (fnd_flex_keyval.error_message, 1, 450) INTO v_error_msg FROM DUAL;

      COMMIT;

      OPEN get_acct_id (v_acct_str);

      FETCH get_acct_id INTO v_acct_id;

      CLOSE get_acct_id;

      IF v_acct_id IS NOT NULL
      THEN
         p_acct_id1 := v_acct_id;
         p_error_msg := NULL;
      ELSE
         p_acct_id1 := NULL;
         p_error_msg := v_error_msg;
      END IF;

      p_acct_str := v_acct_str;
   END CREATE_GL_ACCOUNT;


   PROCEDURE ILINK_ITEM_PRE_VALIDATE (p_master_org_id IN NUMBER, p_master_org_code IN VARCHAR2)
   IS
      /* Define a Cursor to validate Item records from temp table */

      CURSOR get_items
      IS
           SELECT record_id,
                  item_number,
                  description,
                  item_status_code_agile item_status_code,
                  primary_uom_code,
                  inv_category_code,
                  attribute3 tax_code_dff,
                  sales_account_id,
                  cost_of_sales_acct_id,
                  expense_account_id,
                  template_name,
                  make_buy_template,
                  obsolete_template,
                  po_category_code,
                  service_category_code,
                  item_type,
                  attribute4 eco_type,
                  agile_item_cost,
                  erp_product_type,
                  erp_product_sub_type,
                  product_family_code item_type_category,
                  organization_code,
                  organization_id,
                  eco_number,
                  eco_rel_date,
                  revision,
                  attribute5 agile_revision
             FROM ILINK_MTL_ITEMS_INT_TEMP
            WHERE NVL (process_flag, 'N') = 'N'
         ORDER BY eco_rel_date,
                  eco_number,
                  record_id,
                  item_number,
                  organization_id;

      /* Define a Cursor to Verify if the item exists in Oracle */

      CURSOR item_exists_oracle (p_item_number IN VARCHAR2, p_organization_id IN NUMBER)
      IS
         SELECT inventory_item_id, primary_uom_code, planner_code
           FROM ILINK_MTL_SYSTEM_ITEMS_VIEW
          WHERE item_number = p_item_number AND organization_id = p_organization_id;

      /* Define a Cursor to Verify if a record for the item exists in interface table */

      CURSOR item_exists_intf_table (
         p_item_number         IN VARCHAR2,
         p_organization_code   IN VARCHAR2)
      IS
         SELECT item_number
           FROM MTL_SYSTEM_ITEMS_INTERFACE
          WHERE     item_number = p_item_number
                AND organization_code = p_organization_code
                AND transaction_type = 'CREATE'
                AND set_process_id = 0;

      /* Define a Cursor to Verify if category values exist in Oracle */

      CURSOR valid_category_value (
         p_category_Set_name   IN VARCHAR2,
         p_category_value      IN VARCHAR2)
      IS
         SELECT mic.category_concat_segs category_value, attribute1
           FROM MTL_CATEGORY_SETS MCS, MTL_CATEGORIES_V MIC
          WHERE     mcs.category_set_name = p_category_Set_name
                AND mcs.structure_id = mic.structure_id
                AND category_concat_segs = p_category_value
                AND mic.enabled_flag = 'Y'
                AND (mic.disable_date > SYSDATE OR mic.disable_date IS NULL)
                AND ( (mcs.validate_flag = 'Y'
                       AND EXISTS
                              (SELECT 'x'
                                 FROM MTL_CATEGORY_SET_VALID_CATS_V mcv
                                WHERE mcs.category_set_id = mcv.category_set_id
                                      AND mic.category_concat_segs = mcv.category_concat_segments))
                     OR mcs.validate_flag = 'N');


      /* Define a Cursor to Verify if Template exists in Oracle */

      CURSOR valid_template (p_template_name IN VARCHAR2)
      IS
         SELECT template_name
           FROM MTL_ITEM_TEMPLATES
          WHERE template_name = p_template_name;

      /* Define a Cursor to Verify if UOM code exists in Oracle */

      CURSOR valid_uom_code (
         p_uom_code IN VARCHAR2)
      IS
         SELECT uom_code
           FROM MTL_UNITS_OF_MEASURE
          WHERE (uom_code = p_uom_code OR unit_of_measure = p_uom_code)
                AND (disable_date IS NULL OR disable_date > SYSDATE);

      /* Define a Cursor to Verify if Item Status exists in Oracle */

      CURSOR valid_item_status (
         p_item_status IN VARCHAR2)
      IS
         SELECT inventory_item_status_code
           FROM MTL_ITEM_STATUS
          WHERE inventory_item_status_code = p_item_status
                AND (disable_date IS NULL OR disable_date > SYSDATE);


      /* Define a cursor to verify if an item exists on earlier released ECOs */

      CURSOR item_prior_eco (
         p_item_no        IN VARCHAR2,
         p_eco_no         IN VARCHAR2,
         p_eco_rel_date   IN DATE)
      IS
         SELECT eco_number
           FROM ILINK_MTL_ITEMS_INT_TEMP
          WHERE     item_number = p_item_no
                AND eco_number != p_eco_no
                AND eco_rel_date < p_eco_rel_date;

      /* Define a Cursor to fetch the vlaue set for descriptive flexfield segment */

      CURSOR get_dff_value_set (
         p_col_name IN VARCHAR2)
      IS
         SELECT fdc.flex_value_set_id
           FROM FND_DESCR_FLEX_COL_USAGE_VL fdc
          WHERE fdc.descriptive_flexfield_name = 'MTL_SYSTEM_ITEMS'
                AND fdc.application_column_name = p_col_name;

      /* Define a Cursor to fetch the descriptive flexfield segment LOV values */

      CURSOR get_dff_value (p_flex_set_id IN NUMBER, p_value IN VARCHAR2)
      IS
         SELECT DISTINCT ffl.flex_value
           FROM FND_FLEX_VALUES ffl
          WHERE ffl.flex_value_set_id = p_flex_set_id AND UPPER (ffl.flex_value) = UPPER (p_value);

      /* Define a Cursor to Verify if Item Type exists in Oracle */

      CURSOR valid_item_type (p_item_type IN VARCHAR2)
      IS
         SELECT lookup_code
           FROM FND_LOOKUP_VALUES
          WHERE lookup_Type = 'ITEM_TYPE' AND language = 'US' AND lookup_code = p_item_type;

      /* Define a cursor to fetch Account ID */

      CURSOR get_account_id (
         p_acct_id   IN NUMBER,
         p_acct      IN VARCHAR2)
      IS
         SELECT b.code_combination_id
           FROM GL_CODE_COMBINATIONS a, GL_CODE_COMBINATIONS b
          WHERE     a.code_combination_id = p_acct_id
                AND a.segment1 = b.segment1
                AND b.segment2 = p_acct
                AND a.segment3 = b.segment3
                AND a.segment4 = b.segment4
                AND a.segment5 = b.segment5
                AND a.segment6 = b.segment6
                AND a.segment7 = b.segment7
                AND a.segment8 = b.segment8
                AND a.segment9 = b.segment9;

      /* Define a cursor to check if ECO Type is restricted for item creation */

      CURSOR check_eco_type (p_eco_type IN VARCHAR2)
      IS
         SELECT 'Y'
           FROM ILINK_DATA_XREF
          WHERE data_input1 = 'Item Creation Restrict Change Type' AND data_output1 = p_eco_type;

      /* Define a cursor to check if ECO Type is restricted for item creation */

      CURSOR check_eco_cost_type (p_eco_type IN VARCHAR2)
      IS
         SELECT 'Y'
           FROM ILINK_DATA_XREF
          WHERE data_input1 = 'Change Type For Item Cost/Price' AND data_output1 = p_eco_type;

      /* Define a cursor to validate planner code */

      CURSOR valid_planner_code (
         p_org_id    IN NUMBER,
         p_planner   IN VARCHAR2)
      IS
         SELECT 'Y'
           FROM MTL_PLANNERS
          WHERE     planner_code = p_planner
                AND organization_id = p_org_id
                AND NVL (disable_date, SYSDATE) < SYSDATE;


      -- Added the below cursors on 06/08/2015

      /* Define a cursor to fetch starting revision */

      CURSOR get_starting_rev (p_org_id IN NUMBER)
      IS
         SELECT starting_revision
           FROM mtl_parameters
          WHERE organization_id = p_org_id;

      /* Define a cursor to fetch new and old revisions from Agile */

      CURSOR get_agile_revisions (p_eco_no IN VARCHAR2, p_item_no IN VARCHAR2)
      IS
         SELECT old_revision, new_revision
           FROM ILINK_ECO_ITEM_REVISIONS_TEMP
          WHERE eco_number = p_eco_no AND item_number = p_item_no;

      /* Define Cursor to fetch the latest revision for an item in Oracle */

      CURSOR get_latest_rev_oracle (p_item_id IN NUMBER, p_organization_id IN NUMBER)
      IS
           SELECT revision
             FROM MTL_ITEM_REVISIONS
            WHERE inventory_item_id = p_item_id AND organization_id = p_organization_id
         ORDER BY revision DESC;                                                   -- End 06/08/2015


      v_item_id             NUMBER;
      v_item_number         VARCHAR2 (40);
      v_item_status         VARCHAR2 (10);
      v_uom_code            VARCHAR2 (10);
      v_inv_cat_code        VARCHAR2 (100);
      v_tax_code_dff        VARCHAR2 (240);
      v_template_name       VARCHAR2 (150);
      v_make_buy_template   VARCHAR2 (150);
      v_obsolete_template   VARCHAR2 (150);
      v_po_cat_code         VARCHAR2 (100);
      v_ser_cat_code        VARCHAR2 (100);
      v_item_type           VARCHAR2 (100);
      v_status_flag         VARCHAR2 (1);
      v_error_text          VARCHAR2 (4000);
      v_warning_text        VARCHAR2 (4000);
      v_transaction_type    VARCHAR2 (10);
      v_old_uom             VARCHAR2 (10);
      v_prior_eco           VARCHAR2 (10);
      v_flex_set_id         NUMBER;
      v_cat_tax_code        VARCHAR2 (150);
      v_cat_attribute1      VARCHAR2 (150);
      v_sales_account_id    NUMBER;
      v_cogs_account_id     NUMBER;
      v_exp_account_id      NUMBER;
      v_restrict_ecotype    VARCHAR2 (1);
      v_cost_ecotype        VARCHAR2 (1);
      l_cost_rec            xxha_ilink_ext.t_item_cost;
      l_price_rec           xxha_ilink_ext.t_item_price;
      v_item_cost           NUMBER;
      v_item_type_cat       VARCHAR2 (100);
      v_planner_code        VARCHAR2 (30);
      v_invalid_planner     VARCHAR2 (1);

      v_acct_str            VARCHAR2 (500);                                   -- Added on 01/30/2015
      v_error_msg           VARCHAR2 (500);                                   -- Added on 01/30/2015

      v_start_rev           VARCHAR2 (3);                                     -- Added on 06/08/2015
      v_old_rev_agile       VARCHAR2 (30);                                    -- Added on 06/08/2015
      v_new_rev_agile       VARCHAR2 (30);                                    -- Added on 06/08/2015
      v_latest_rev_oracle   VARCHAR2 (30);                                    -- Added on 06/08/2015
   BEGIN
      /* Begin Processing all the records from the temp table */

      FOR c_valid_items IN get_items
      LOOP
         v_error_text := NULL;
         v_warning_text := NULL;
         v_status_flag := 'S';
         v_transaction_type := NULL;

         v_item_status := NULL;
         v_uom_code := NULL;
         v_inv_cat_code := NULL;
         v_tax_code_dff := NULL;
         v_template_name := NULL;
         v_make_buy_template := NULL;
         v_obsolete_template := NULL;
         v_po_cat_code := NULL;
         v_ser_cat_code := NULL;
         v_item_type := NULL;
         v_item_id := NULL;
         v_old_uom := NULL;
         v_cat_tax_code := NULL;
         v_cat_attribute1 := NULL;
         v_sales_account_id := NULL;
         v_cogs_account_id := NULL;
         v_exp_account_id := NULL;
         v_restrict_ecotype := NULL;
         v_item_cost := NULL;
         v_item_type_cat := NULL;
         v_cost_ecotype := NULL;
         v_planner_code := NULL;
         v_invalid_planner := NULL;


         /*  Verify if Item exists in Oracle or if Item Exists in Interface table */

         OPEN item_exists_oracle (c_valid_items.item_number, c_valid_items.organization_id);

         FETCH item_exists_oracle
         INTO v_item_id, v_old_uom, v_planner_code;

         IF item_exists_oracle%NOTFOUND
         THEN
            OPEN item_exists_intf_table (c_valid_items.item_number, c_valid_items.organization_code);

            FETCH item_exists_intf_table INTO v_item_number;

            /* Item not found in Oracle or Interface table so transaction type is "CREATE" (create a new item in Oracle) */

            IF item_exists_intf_table%NOTFOUND
            THEN
               v_transaction_type := 'CREATE';
            ELSE /* A record exists in Interface table with transaction Type "CREATE" so transaction type is "UPDATE" */
               v_transaction_type := 'UPDATE';
            END IF;

            CLOSE item_exists_intf_table;
         ELSE                            /* Item exists in Oracle so transaction type is "UPDATE" */
            v_transaction_type := 'UPDATE';
         END IF;

         CLOSE item_exists_oracle;


         /*  Validate UOM code */

         -- If c_valid_items.primary_uom_code is NOT NULL then
         OPEN valid_uom_code (c_valid_items.primary_uom_code);

         FETCH valid_uom_code INTO v_uom_code;

         IF valid_uom_code%NOTFOUND
         THEN
            IF v_transaction_type = 'UPDATE'
            THEN
               v_status_flag := 'W';

               SELECT DECODE (v_error_text, NULL, '', v_warning_text || ' , ')
                      || 'UOM:Cannot Update Unit Of Measure'
                 INTO v_error_text
                 FROM DUAL;
            ELSE
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Unit Of Measure'
                 INTO v_error_text
                 FROM DUAL;
            END IF;
         ELSIF     (valid_uom_code%FOUND)
               AND (v_transaction_type = 'UPDATE')
               AND (v_uom_code != v_old_uom)
         THEN
            v_status_flag := 'W';

            SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                   || 'UOM:Cannot Update Unit Of Measure'
              INTO v_error_text
              FROM DUAL;
         END IF;

         CLOSE valid_uom_code;

         -- End If;


         /* Validate Item Status */

         OPEN valid_item_status (c_valid_items.item_status_code);

         FETCH valid_item_status INTO v_item_status;

         IF valid_item_status%NOTFOUND
         THEN
            v_status_flag := 'E';

            SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Item Status Code'
              INTO v_error_text
              FROM DUAL;
         END IF;

         CLOSE valid_item_status;


         /* Validate Inventory Category Code  */

         IF c_valid_items.inv_category_code IS NOT NULL AND v_transaction_type = 'CREATE'
         THEN                                   -- Added v_transaction_type = 'CREATE' on 06/02/2014
            OPEN valid_category_value (v_inv_cat_set_name, c_valid_items.inv_category_code);

            FETCH valid_category_value
            INTO v_inv_cat_code, v_cat_tax_code;

            IF valid_category_value%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Inventory Category Code'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_category_value;
         END IF;


         /* Validate Tax Code DFF Value */

         IF c_valid_items.tax_code_dff IS NOT NULL AND v_transaction_type = 'CREATE'
         THEN                                   -- Added v_transaction_type = 'CREATE' on 06/02/2014
            v_flex_set_id := NULL;

            OPEN get_dff_value_set ('ATTRIBUTE14');

            FETCH get_dff_value_set INTO v_flex_set_id;

            CLOSE get_dff_value_set;

            IF v_flex_set_id IS NOT NULL
            THEN
               OPEN get_dff_value (v_flex_set_id, c_valid_items.tax_code_dff);

               FETCH get_dff_value INTO v_tax_code_dff;

               IF get_dff_value%NOTFOUND
               THEN
                  v_status_flag := 'E';

                  SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Tax Code DFF'
                    INTO v_error_text
                    FROM DUAL;
               END IF;

               CLOSE get_dff_value;
            ELSE
               v_tax_code_dff := c_valid_items.tax_code_dff;
            END IF;
         END IF;


         IF v_cat_tax_code IS NOT NULL
         THEN
            /* Derive Sales Account */

            v_acct_str := NULL;                                               -- Added on 01/30/2015
            v_error_msg := NULL;                                              -- Added on 01/30/2015

            OPEN get_account_id (c_valid_items.sales_account_id, v_cat_tax_code);

            FETCH get_account_id INTO v_sales_account_id;

            -- Added the below on 01/30/2015
            IF get_account_id%NOTFOUND
            THEN
               CREATE_GL_ACCOUNT (c_valid_items.organization_id,
                                  c_valid_items.sales_account_id,
                                  v_cat_tax_code,
                                  v_acct_str,
                                  v_sales_account_id,
                                  v_error_msg);
            END IF;                                                                -- End 01/30/2015

            CLOSE get_account_id;
            -- Added on 01/30/2015
            IF v_sales_account_id IS NULL
            THEN
               v_status_flag := 'E';

               SELECT    DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Sales Account combination '
                      || v_acct_str
                      || ' was not created by API and error message is '
                      || v_error_msg
                 INTO v_error_text
                 FROM DUAL;
            END IF;                                                                -- End 01/30/2015

            /* Derive COGS Account */

            v_acct_str := NULL;                                               -- Added on 01/30/2015
            v_error_msg := NULL;                                              -- Added on 01/30/2015

            OPEN get_account_id (c_valid_items.cost_of_sales_acct_id, v_cat_tax_code);

            FETCH get_account_id INTO v_cogs_account_id;

            -- Added the below on 01/30/2015
            IF get_account_id%NOTFOUND
            THEN
               CREATE_GL_ACCOUNT (c_valid_items.organization_id,
                                  c_valid_items.cost_of_sales_acct_id,
                                  v_cat_tax_code,
                                  v_acct_str,
                                  v_cogs_account_id,
                                  v_error_msg);
            END IF;                                                                -- End 01/30/2015

            CLOSE get_account_id;

            -- Added on 01/30/2015
            IF v_cogs_account_id IS NULL
            THEN
               v_status_flag := 'E';

               SELECT    DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Cost Of Sales Account combination '
                      || v_acct_str
                      || ' was not created by API and error message is '
                      || v_error_msg
                 INTO v_error_text
                 FROM DUAL;
            END IF;                                                                -- End 01/30/2015

            /* Derive Expense Account */

            v_acct_str := NULL;                                               -- Added on 01/30/2015
            v_error_msg := NULL;                                              -- Added on 01/30/2015

            OPEN get_account_id (c_valid_items.expense_account_id, v_cat_tax_code);

            FETCH get_account_id INTO v_exp_account_id;

            -- Added the below on 01/30/2015
            IF get_account_id%NOTFOUND
            THEN
               CREATE_GL_ACCOUNT (c_valid_items.organization_id,
                                  c_valid_items.expense_account_id,
                                  v_cat_tax_code,
                                  v_acct_str,
                                  v_exp_account_id,
                                  v_error_msg);
            END IF;                                                                -- End 01/30/2015

            CLOSE get_account_id;

            -- Added on 01/30/2015
            IF v_exp_account_id IS NULL
            THEN
               v_status_flag := 'E';

               SELECT    DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Expense Account combination '
                      || v_acct_str
                      || ' was not created by API and error message is '
                      || v_error_msg
                 INTO v_error_text
                 FROM DUAL;
            END IF;                                                                -- End 01/30/2015
         END IF;


         /* Validate Template */

         IF v_transaction_type = 'CREATE'
         THEN
            OPEN valid_template (c_valid_items.template_name);

            FETCH valid_template INTO v_template_name;

            IF valid_template%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Template'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_template;
         END IF;


         /* Validate Make/Buy Template */

         IF v_transaction_type = 'CREATE'
         THEN
            OPEN valid_template (c_valid_items.make_buy_template);

            FETCH valid_template INTO v_make_buy_template;

            IF valid_template%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Make/Buy Template'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_template;
         END IF;


         /* Validate Obsolete Template */

         IF c_valid_items.obsolete_template IS NOT NULL
         THEN
            OPEN valid_template (c_valid_items.obsolete_template);

            FETCH valid_template INTO v_obsolete_template;

            IF valid_template%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Obsolete Template'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_template;
         END IF;


         /* Validate Purchasing Category Code  */

         IF c_valid_items.po_category_code IS NOT NULL AND v_transaction_type = 'CREATE'
         THEN                                   -- Added v_transaction_type = 'CREATE' on 06/02/2014
            OPEN valid_category_value (v_po_cat_set_name, c_valid_items.po_category_code);

            FETCH valid_category_value
            INTO v_po_cat_code, v_cat_attribute1;

            IF valid_category_value%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Purchasing Category Code'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_category_value;
         END IF;


         /* Validate Service Category Code  */

         IF c_valid_items.service_category_code IS NOT NULL
         THEN
            OPEN valid_category_value (v_ser_cat_set_name, c_valid_items.service_category_code);

            FETCH valid_category_value
            INTO v_ser_cat_code, v_cat_attribute1;

            IF valid_category_value%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Service Category Code'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_category_value;
         END IF;


         /* Validate Item Type  */

         IF v_transaction_type = 'CREATE' AND c_valid_items.item_type IS NOT NULL
         THEN
            OPEN valid_item_type (c_valid_items.item_type);

            FETCH valid_item_type INTO v_item_type;

            IF valid_item_type%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Item Type'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_item_type;
         END IF;


         /* Validate Item Type Category Code  */

         IF c_valid_items.item_type_category IS NOT NULL
         THEN
            OPEN valid_category_value (v_itp_cat_set_name, c_valid_items.item_type_category);

            FETCH valid_category_value
            INTO v_item_type_cat, v_cat_tax_code;

            IF valid_category_value%NOTFOUND
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Item Type Category Code'
                 INTO v_error_text
                 FROM DUAL;
            END IF;

            CLOSE valid_category_value;
         END IF;


         /* Verify if an item exists on earlier released ECOs */

         v_prior_eco := NULL;

         OPEN item_prior_eco (c_valid_items.item_number,
                              c_valid_items.eco_number,
                              c_valid_items.eco_rel_date);

         FETCH item_prior_eco INTO v_prior_eco;

         IF item_prior_eco%FOUND
         THEN
            v_status_flag := 'E';

            SELECT    DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                   || 'Item Exists on an Earlier Released ECO '
                   || v_prior_eco
              INTO v_error_text
              FROM DUAL;
         END IF;

         CLOSE item_prior_eco;


         /* Verify If the ECO Type is restricted for item Creation at master org */

         IF c_valid_items.organization_code = p_master_org_code AND v_transaction_type = 'CREATE'
         THEN
            OPEN check_eco_type (c_valid_items.eco_type);

            FETCH check_eco_type INTO v_restrict_ecotype;

            CLOSE check_eco_type;

            IF NVL (v_restrict_ecotype, 'N') = 'Y'
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Item can not be created on this type of change order'
                 INTO v_error_text
                 FROM DUAL;
            END IF;
         END IF;


         /* Validate Revisions */

         IF    c_valid_items.agile_revision IN ('#', ' ')
            OR LENGTH (c_valid_items.agile_revision) > 3
            OR c_valid_items.agile_revision < '#'
         THEN
            v_status_flag := 'E';

            SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ') || 'Invalid Revision'
              INTO v_error_text
              FROM DUAL;
         END IF;


         /* Validate Invalid Planner for existing items */

         IF NVL (v_transaction_type, 'NA') = 'UPDATE' AND v_planner_code IS NOT NULL
         THEN
            OPEN valid_planner_code (c_valid_items.organization_id, v_planner_code);

            FETCH valid_planner_code INTO v_invalid_planner;

            CLOSE valid_planner_code;

            IF NVL (v_invalid_planner, 'N') = 'Y'
            THEN
               v_status_flag := 'E';

               SELECT DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                      || 'Planner Code for this item in EBS is Invalid'
                 INTO v_error_text
                 FROM DUAL;
            END IF;
         END IF;


         /* Validate Item Costs and Price */

         OPEN check_eco_cost_type (c_valid_items.eco_type);

         FETCH check_eco_cost_type INTO v_cost_ecotype;

         CLOSE check_eco_cost_type;

         IF NVL (v_cost_ecotype, 'N') = 'Y'
         THEN
            XXHA_ILINK_EXT.GET_INFO (
               P_ORGANIZATION_CODE        => c_valid_items.organization_code,
               P_ITEM_NUMBER              => c_valid_items.item_number,
               P_AGILE_COST               => c_valid_items.agile_item_cost,
               P_ITEM_TYPE                => ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                                               'Make/Buy Item Type',
                                               c_valid_items.item_type,
                                               NULL,
                                               NULL,
                                               NULL),
               P_ITEM_CATEGORY_SEGMENT2   => c_valid_items.erp_product_type,
               P_ITEM_CATEGORY_SEGMENT3   => c_valid_items.erp_product_sub_type,
               P_ITEM_COST_TAB            => l_cost_rec,
               p_item_price_tab           => l_price_rec);

            FOR i IN 1 .. l_cost_rec.COUNT
            LOOP
               IF NVL (l_cost_rec (i).return_status, 2) NOT IN (0)
                  AND TRIM (l_cost_rec (i).error_message) IS NOT NULL
               THEN
                  v_status_flag := 'E';

                  SELECT SUBSTR (
                            DECODE (v_error_text,
                                    NULL, '',
                                    v_error_text || ' Item Cost Error Message is ')
                            || l_cost_rec (i).error_message,
                            1,
                            3900)
                    INTO v_error_text
                    FROM DUAL;
               END IF;

               IF     NVL (l_cost_rec (i).return_status, 3) IN (0, 2)
                  AND l_cost_rec (i).Update_Frozen_Flag = 'Y'
                  AND l_cost_rec (i).cost IS NOT NULL
               THEN
                  v_item_cost := l_cost_rec (i).cost;
               END IF;
            END LOOP;

            FOR i IN 1 .. l_price_rec.COUNT
            LOOP
               IF NVL (l_price_rec (i).return_status, 2) NOT IN (0)
                  AND TRIM (l_price_rec (i).error_message) IS NOT NULL
               THEN
                  v_status_flag := 'E';

                  SELECT SUBSTR (
                            DECODE (v_error_text,
                                    NULL, '',
                                    v_error_text || ' Item Price List Error Message is ')
                            || l_price_rec (i).error_message,
                            1,
                            3900)
                    INTO v_error_text
                    FROM DUAL;
               END IF;
            END LOOP;
         END IF;


         -- Added the below on 06/08/2015 for revision validations

         v_latest_rev_oracle := NULL;
         v_old_rev_agile := NULL;
         v_new_rev_agile := NULL;

         IF v_item_id IS NOT NULL
         THEN                                       -- Validate Revisions Only If Item Exists in EBS
            /* Determine starting revision for org */

            v_start_rev := NULL;

            OPEN get_starting_rev (c_valid_items.organization_id);

            FETCH get_starting_rev INTO v_start_rev;

            CLOSE get_starting_rev;

            OPEN get_latest_rev_oracle (v_item_id, c_valid_items.organization_id);

            FETCH get_latest_rev_oracle INTO v_latest_rev_oracle;

            IF get_latest_rev_oracle%FOUND
            THEN
               OPEN get_agile_revisions (c_valid_items.eco_number, c_valid_items.item_number);

               FETCH get_agile_revisions
               INTO v_old_rev_agile, v_new_rev_agile;

               CLOSE get_agile_revisions;

               IF v_latest_rev_oracle != v_start_rev
               THEN
                  /* Verify if Old revision in Agile matches the current revision in Oracle */
                  /* Added an additional clause to ignore the initial old revision */

                  IF     (v_latest_rev_oracle != v_start_rev)
                     AND (v_latest_rev_oracle != NVL (v_old_rev_agile, v_latest_rev_oracle))
                     AND (v_new_rev_agile != v_latest_rev_oracle)                            -- Then
                     AND NVL (ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Agile Old Rev Check',
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL),
                              'No') = 'Yes'
                  THEN
                     v_status_flag := 'E';

                     SELECT    DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                            || 'The old Revision from AGILE '
                            || v_old_rev_agile
                            || ' does not match the current Oracle revision '
                            || v_latest_rev_oracle
                       INTO v_error_text
                       FROM DUAL;
                  /* Error out if New revision in Agile is older (lesser) than the current revision in Oracle */

                  ELSIF v_latest_rev_oracle > v_new_rev_agile
                  THEN
                     v_status_flag := 'E';

                     SELECT    DECODE (v_error_text, NULL, '', v_error_text || ' , ')
                            || ' Current Revision in Oracle '
                            || v_latest_rev_oracle
                            || ' is newer than AGILE revision '
                            || v_new_rev_agile
                       INTO v_error_text
                       FROM DUAL;
                  END IF;
               END IF;
            END IF;

            CLOSE get_latest_rev_oracle;
         END IF;                                                                   -- End 06/08/2015


         /* If all the validations succeeded then mark the record as "Validated" */

         IF v_status_flag IN ('S', 'W')
         THEN
            UPDATE ILINK_MTL_ITEMS_INT_TEMP
               SET sales_account_id = v_sales_account_id, -- nvl(v_sales_account_id,sales_account_id),        -- Modified on 01/30/2015
                   cost_of_sales_acct_id = v_cogs_account_id, -- nvl(v_cogs_account_id,cost_of_sales_acct_id),    -- Modified on 01/30/2015
                   expense_account_id = v_exp_account_id, -- nvl(v_exp_account_id,expense_account_id),        -- Modified on 01/30/2015
                   item_cost = v_item_cost,
                   record_status = 'Validated',
                   process_flag = 'Y',
                   processed_date = SYSDATE,
                   inventory_item_id = v_item_id,
                   validation_date = SYSDATE,
                   warning_message =
                      DECODE (v_warning_text,
                              NULL, NULL,
                              'WARNING: Check Field(s) :' || v_warning_text)
             WHERE     eco_number = c_valid_items.eco_number
                   AND item_number = c_valid_items.item_number
                   AND organization_id = c_valid_items.organization_id;
         ELSE
            UPDATE ILINK_MTL_ITEMS_INT_TEMP
               SET record_status = 'Error',
                   process_flag = 'Y',
                   processed_date = SYSDATE,
                   error_message =
                      error_message || 'Error: Invalid value in field(s):' || v_error_text,
                   warning_message =
                      DECODE (v_warning_text,
                              NULL, NULL,
                              'Warning: Check Field(s) :' || v_warning_text)
             WHERE     eco_number = c_valid_items.eco_number
                   AND item_number = c_valid_items.item_number
                   AND organization_code = c_valid_items.organization_code;
         END IF;                                                              -- v_status_flag = 'E'
      END LOOP;

      -- Error out the item at all orgs even if it has failed at one Org

      UPDATE ILINK_MTL_ITEMS_INT_TEMP a
         SET record_status = 'Error', process_flag = 'Y', processed_date = SYSDATE
       WHERE EXISTS
                (SELECT 'x'
                   FROM ILINK_MTL_ITEMS_INT_TEMP b
                  WHERE     a.eco_number = b.eco_number
                        AND a.item_number = b.item_number
                        AND b.record_status = 'Error');
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_ITEM_PRE_VALIDATE is ' || SQLERRM);
   END ILINK_ITEM_PRE_VALIDATE;


   PROCEDURE ILINK_ITEM_INSERT_INT (p_master_org_id IN NUMBER, p_master_org_code IN VARCHAR2)
   IS
      /* Define a Cursor to fetch "Validated" records From temp table */

      CURSOR get_valid_items
      IS
           SELECT eco_number,
                  record_id,
                  item_number,
                  description,
                  item_status_code_agile,
                  primary_uom_code,
                  lot_control_code,
                  serial_control_code,
                  shelf_life_control,
                  shelf_life_days,
                  inv_category_code,
                  attribute3 tax_code_dff,
                  sales_account_id,
                  cost_of_sales_acct_id,
                  expense_account_id,
                  template_name,
                  make_buy_template,
                  obsolete_template,
                  attribute2 fast_pack,
                  po_category_code,
                  DECODE (UPPER (enable_service_billing),
                          'YES', 'Y',
                          'Y', 'Y',
                          'NO', 'N',
                          'N', 'N',
                          NULL)
                     enable_serv_bill_flag,
                  DECODE (UPPER (billing_type),
                          'MATERIAL', 'M',
                          'LABOR', 'L',
                          'EXPENSE', 'E',
                          'NULL', 'NULL',
                          NULL)
                     billing_type_flag,
                  DECODE (UPPER (service_request),
                          'ENABLED', 'E',
                          'INACTIVE', 'I',
                          'DISABLED', 'D',
                          'NULL', 'NULL',
                          NULL)
                     service_request_flag,
                  serv_track_install_base,
                  DECODE (UPPER (track_install_base),
                          'YES', 'Y',
                          'Y', 'Y',
                          'NO', 'N',
                          'N', 'N',
                          NULL)
                     track_install_base_flag,
                  DECODE (UPPER (enable_contract_cover),
                          'YES', 'Y',
                          'Y', 'Y',
                          'NO', 'N',
                          'N', 'N',
                          NULL)
                     enable_contract_cover_flag,
                  DECODE (UPPER (service_returnable),
                          'FAST RETURN', 'M',
                          'NO RETURN', 'N',
                          'SLOW RETURN', 'S',
                          'NULL', 'NULL',
                          NULL)
                     service_returnable_flag,
                  service_category_code,
                  item_type,
                  shipping_qty_box,
                  taxable_flag,
                  po_tax_code,
                  auto_lot_alpha_prefix,
                  start_auto_lot_number,
                  auto_serial_prefix,
                  start_serial_number,
                  item_cost,
                  product_family_code item_type_category,
                  eco_orig_date,
                  eco_rel_date,
                  organization_code,
                  organization_id,
                  creation_date,
                  validation_date,
                  inventory_item_id
             FROM ILINK_MTL_ITEMS_INT_TEMP
            WHERE record_status = 'Validated'
         ORDER BY eco_rel_date,
                  eco_number,
                  record_id,
                  item_number,
                  organization_id;

      /* Define a Cursor to determine if any unprocessed records exist in Interface table From previous RUN */

      CURSOR get_record_count (
         p_item_number         IN VARCHAR2,
         p_organization_code   IN VARCHAR2,
         p_transaction_type    IN VARCHAR2)
      IS
         SELECT COUNT (*)
           FROM MTL_SYSTEM_ITEMS_INTERFACE
          WHERE     item_number = p_item_number
                AND organization_code = p_organization_code
                AND transaction_type = p_transaction_type
                AND set_process_id = 0;


      /* Define a Cursor to retreive current item attributes to determine if an UPDATE is necessary */

      CURSOR get_item_attributes (p_item_number IN VARCHAR2, p_organization_id IN NUMBER)
      IS
         SELECT description,
                inventory_item_status_code,
                tax_code,
                sales_account,
                cost_of_sales_account,
                expense_account,
                serv_billing_enabled_flag,
                billing_type,
                service_request,
                track_in_install_base,
                enable_contract_coverage,
                recovered_part_disp_code
           FROM ILINK_MTL_SYSTEM_ITEMS_VIEW
          WHERE organization_id = p_organization_id AND item_number = p_item_number;

      /* Define a Cursor to fetch item status level attributes */

      CURSOR get_item_status_attr (p_item_status IN VARCHAR2)
      IS
         SELECT attribute_name, attribute_value, control_level_disp
           FROM MTL_STAT_ATTRIB_VALUES_ALL_V
          WHERE INVENTORY_ITEM_STATUS_CODE = p_item_status;

      /* Define a Cursor to Verify if the item exists in Oracle */

      CURSOR item_exists_oracle (p_item_number IN VARCHAR2, p_organization_id IN NUMBER)
      IS
         SELECT inventory_item_id
           FROM ILINK_MTL_SYSTEM_ITEMS_VIEW
          WHERE item_number = p_item_number AND organization_id = p_organization_id;

      /* Define a Cursor to Verify if a record for the item exists in interface table */

      CURSOR item_exists_intf_table (
         p_item_number         IN VARCHAR2,
         p_organization_code   IN VARCHAR2)
      IS
         SELECT item_number
           FROM MTL_SYSTEM_ITEMS_INTERFACE
          WHERE     item_number = p_item_number
                AND organization_code = p_organization_code
                AND transaction_type = 'CREATE'
                AND set_process_id = 0;

      /* Define a Cursor to fetch and verify category value "SPL Flag" */

      CURSOR get_category_code (
         p_category_set_name   IN VARCHAR2,
         p_organization_id     IN NUMBER,
         p_inventory_item_id   IN NUMBER,
         p_cat_value           IN VARCHAR2)
      IS
         SELECT mc.category_concat_segs category_value
           FROM MTL_CATEGORY_SETS MCS, MTL_CATEGORIES_V MC, MTL_ITEM_CATEGORIES MIC
          WHERE     mcs.category_set_name = p_category_set_name
                AND mic.organization_id = p_organization_id
                AND mic.inventory_item_id = p_inventory_item_id
                AND mcs.category_set_id = mic.category_set_id
                AND mic.category_id = mc.category_id
                AND (mc.category_concat_segs = p_cat_value OR p_cat_value IS NULL);

      /* Define a Cursor to detemine if a category value is controlled at master org or indvidual org level */

      CURSOR get_category_control_level (p_category_set_name IN VARCHAR2)
      IS
         SELECT control_level
           FROM MTL_CATEGORY_SETS
          WHERE category_set_name = p_category_set_name;

      /* Check if an item exists at MST org to copy the revisions */

      CURSOR check_item_exists (p_item_num IN VARCHAR2)
      IS
         -- Select 'Y'                             -- Commented out on 05/29/2014
         SELECT inventory_item_id                                             -- Added on 05/29/2014
           FROM ILINK_MTL_SYSTEM_ITEMS_VIEW
          WHERE item_number = p_item_num AND organization_id = p_master_org_id;

      /* Fetch Item revisions from MST org to copy into child orgs     -- Commented out on 05/29/2014

      Cursor get_item_revs(p_item_num In Varchar2) is
      Select a.revision,a.revision_label,a.description,a.effectivity_date
      From MTL_ITEM_REVISIONS_B a,
           ILINK_MTL_SYSTEM_ITEMS_VIEW b
      Where b.item_number = p_item_num and
            a.organization_id = p_master_org_id and
            a.organization_id = b.organization_id and
            a.inventory_item_id = b.inventory_item_id
      Order by a.revision;                    */
      -- End 05/29/2014

      -- Added the below cursors on 05/29/2014

      /* Fetch Item revisions from MST org to copy into child orgs */

      CURSOR get_item_revs (p_item_id IN NUMBER)
      IS
         SELECT revision,
                revision_label,
                description,
                effectivity_date
           FROM MTL_ITEM_REVISIONS_B
          WHERE inventory_item_id = p_item_id AND organization_id = p_master_org_id;

      /* Fetch starting rev at an org */

      CURSOR get_start_rev (p_org_id IN NUMBER)
      IS
         SELECT starting_revision
           FROM MTL_PARAMETERS
          WHERE organization_id = p_org_id;

      /* Check if an item has the starting rev (-) at master org */

      CURSOR check_start_rev (
         p_item_id     IN NUMBER,
         p_org_id      IN NUMBER,
         p_start_rev   IN VARCHAR2)
      IS
         SELECT 'Y'
           FROM MTL_ITEM_REVISIONS_B
          WHERE     inventory_item_id = p_item_id
                AND organization_id = p_master_org_id
                AND revision = p_start_rev;

      /* Fetch the minimum effectivity date minus one second */

      CURSOR get_min_eff_date (p_item_id IN NUMBER)
      IS
         SELECT MIN (effectivity_date) - 0.0000125
           FROM MTL_ITEM_REVISIONS_B
          WHERE inventory_item_id = p_item_id AND organization_id = p_master_org_id; -- End 05/29/2014


      v_error_message        VARCHAR2 (4000);
      v_warning_message      VARCHAR2 (4000);
      v_count_records        NUMBER;
      v_description          VARCHAR2 (240);
      v_item_status          VARCHAR2 (30);
      v_update_flag          VARCHAR2 (1);
      v_cat_update_flag      VARCHAR2 (1);
      v_bom_allowed          VARCHAR2 (1);
      v_build_in_wip         VARCHAR2 (1);
      v_cust_ord_enabled     VARCHAR2 (1);
      v_int_ord_enabled      VARCHAR2 (1);
      v_invoice_enabled      VARCHAR2 (1);
      v_purchaseable         VARCHAR2 (1);
      v_stockable            VARCHAR2 (1);
      v_transactable         VARCHAR2 (1);
      v_item_number          VARCHAR2 (40);
      v_transaction_type     VARCHAR2 (20);
      v_item_id              NUMBER;
      v_txn_type             VARCHAR2 (10);
      v_po_cat_code          VARCHAR2 (100);
      v_poctl_level          NUMBER;
      v_inv_cat_code         VARCHAR2 (100);
      v_invctl_level         NUMBER;
      v_ser_cat_code         VARCHAR2 (100);
      v_serctl_level         NUMBER;
      v_tax_code_dff         VARCHAR2 (240);
      v_sales_account        NUMBER;
      v_cogs_account         NUMBER;
      v_expense_account      NUMBER;
      v_serv_billing_flag    VARCHAR2 (30);
      v_billing_type         VARCHAR2 (30);
      v_service_request      VARCHAR2 (30);
      v_track_install_base   VARCHAR2 (30);
      v_contract_coverage    VARCHAR2 (30);
      v_recovered_code       VARCHAR2 (30);
      v_item_exists          VARCHAR2 (1);
      v_obs_template         VARCHAR2 (30);
      v_item_type_cat        VARCHAR2 (100);
      v_itpctl_level         NUMBER;
      v_item_id1             NUMBER;                                          -- Added on 05/29/2014
      v_start_rev_exists     VARCHAR2 (1);                                    -- Added on 05/29/2014
      v_start_rev            VARCHAR2 (10);                                   -- Added on 05/29/2014
      v_min_eff_date         DATE;                                            -- Added on 05/29/2014
   BEGIN
      /* Check if Inventory Category code is controlled at Master org or at Indvidual Org level */

      OPEN get_category_control_level (v_inv_cat_set_name);

      FETCH get_category_control_level INTO v_invctl_level;

      CLOSE get_category_control_level;

      /* Check if PO Category code is controlled at Master org or at Indvidual Org level */

      OPEN get_category_control_level (v_po_cat_set_name);

      FETCH get_category_control_level INTO v_poctl_level;

      CLOSE get_category_control_level;

      /* Check if Service Category code is controlled at Master org or at Indvidual Org level */

      OPEN get_category_control_level (v_ser_cat_set_name);

      FETCH get_category_control_level INTO v_serctl_level;

      CLOSE get_category_control_level;

      /* Check if Item Type Category code is controlled at Master org or at Indvidual Org level */

      OPEN get_category_control_level (v_itp_cat_set_name);

      FETCH get_category_control_level INTO v_itpctl_level;

      CLOSE get_category_control_level;


      /* Begin processing of "Validated" records from temp table */

      FOR c_valid_items IN get_valid_items
      LOOP
         /*  Verify if Item exists in Oracle or if Item Exists in Interface table */

         v_item_id := NULL;

         OPEN item_exists_oracle (c_valid_items.item_number, C_valid_items.organization_id);

         FETCH item_exists_oracle INTO v_item_id;

         IF item_exists_oracle%NOTFOUND
         THEN
            OPEN item_exists_intf_table (c_valid_items.item_number, C_valid_items.organization_code);

            FETCH item_exists_intf_table INTO v_item_number;

            /* Item not found in Oracle or Interface table so set transaction type as "CREATE" (create a new item in Oracle) */

            IF item_exists_intf_table%NOTFOUND
            THEN
               v_transaction_type := 'CREATE';
            ELSE /* A record exists in Interface table with transaction Type "CREATE" so set transaction type as "UPDATE" */
               v_transaction_type := 'UPDATE';
            END IF;

            CLOSE item_exists_intf_table;
         ELSE                        /* Item exists in Oracle so set transaction type as "UPDATE" */
            v_transaction_type := 'UPDATE';
         END IF;

         CLOSE item_exists_oracle;


         /* Perform checks for transaction type as CREATE (new item) */

         IF v_transaction_type = 'CREATE'
         THEN
            v_count_records := 0;

            OPEN get_record_count (c_valid_items.item_number,
                                   c_valid_items.organization_code,
                                   'CREATE');

            FETCH get_record_count INTO v_count_records;

            CLOSE get_record_count;

            IF v_count_records = 0
            THEN                           /* No CREATE record exists for item in Interface table */
               /* Fetch Item Status attributes */

               v_bom_allowed := NULL;
               v_build_in_wip := NULL;
               v_cust_ord_enabled := NULL;
               v_int_ord_enabled := NULL;
               v_invoice_enabled := NULL;
               v_purchaseable := NULL;
               v_stockable := NULL;
               v_transactable := NULL;

               FOR c1 IN get_item_status_attr (c_valid_items.item_status_code_agile)
               LOOP
                  IF c1.attribute_name = 'MTL_SYSTEM_ITEMS.BOM_ENABLED_FLAG'
                     AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_bom_allowed := c1.attribute_value;
                  ELSIF c1.attribute_name = 'MTL_SYSTEM_ITEMS.BUILD_IN_WIP_FLAG'
                        AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_build_in_wip := c1.attribute_value;
                  ELSIF c1.attribute_name = 'MTL_SYSTEM_ITEMS.CUSTOMER_ORDER_ENABLED_FLAG'
                        AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_cust_ord_enabled := c1.attribute_value;
                  ELSIF c1.attribute_name = 'MTL_SYSTEM_ITEMS.INTERNAL_ORDER_ENABLED_FLAG'
                        AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_int_ord_enabled := c1.attribute_value;
                  ELSIF c1.attribute_name = 'MTL_SYSTEM_ITEMS.INVOICE_ENABLED_FLAG'
                        AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_invoice_enabled := c1.attribute_value;
                  ELSIF c1.attribute_name = 'MTL_SYSTEM_ITEMS.MTL_TRANSACTIONS_ENABLED_FLAG'
                        AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_transactable := c1.attribute_value;
                  ELSIF c1.attribute_name = 'MTL_SYSTEM_ITEMS.PURCHASING_ENABLED_FLAG'
                        AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_purchaseable := c1.attribute_value;
                  ELSIF c1.attribute_name = 'MTL_SYSTEM_ITEMS.STOCK_ENABLED_FLAG'
                        AND c1.control_level_disp IN ('Under status control', 'Default control')
                  THEN
                     v_stockable := c1.attribute_value;
                  END IF;
               END LOOP;


               /* Insert item Record into Item Interface table as CREATE (New Item) */

               INSERT INTO MTL_SYSTEM_ITEMS_INTERFACE (transaction_type,
                                                       item_number,
                                                       description,
                                                       inventory_item_status_code,
                                                       primary_uom_code,
                                                       lot_control_code,
                                                       shelf_life_code,
                                                       serial_number_control_code,
                                                       shelf_life_days,
                                                       attribute_category,
                                                       attribute14,
                                                       sales_account,
                                                       cost_of_sales_account,
                                                       expense_account,
                                                       template_name,
                                                       attribute5,
                                                       serv_billing_enabled_flag,
                                                       material_billable_flag,
                                                       serv_req_enabled_code,
                                                       comms_nl_trackable_flag,
                                                       serviceable_product_flag,
                                                       recovered_part_disp_code,
                                                       item_type,
                                                       taxable_flag,
                                                       purchasing_tax_code,
                                                       auto_lot_alpha_prefix,
                                                       start_auto_lot_number,
                                                       auto_serial_alpha_prefix,
                                                       start_auto_serial_number,
                                                       organization_code,
                                                       organization_id,
                                                       bom_enabled_flag,
                                                       build_in_wip_flag,
                                                       customer_order_enabled_flag,
                                                       internal_order_enabled_flag,
                                                       invoice_enabled_flag,
                                                       purchasing_enabled_flag,
                                                       mtl_transactions_enabled_flag,
                                                       stock_enabled_flag,
                                                       material_cost,
                                                       material_sub_elem,
	       					       lot_status_enabled,			-- Added on 10/06/2015
						       default_lot_status_id,			-- Added on 10/06/2015
						       lot_divisible_flag,			-- Added on 10/06/2015                                                       
                                                       set_process_id,
                                                       created_by,
                                                       creation_date,
                                                       process_flag)
                    VALUES (
                              'CREATE',
                              c_valid_items.item_number,
                              DECODE (c_valid_items.organization_id,
                                      p_master_org_id, c_valid_items.description,
                                      NULL),
                              c_valid_items.item_status_code_agile,
                              DECODE (c_valid_items.organization_id,
                                      p_master_org_id, c_valid_items.primary_uom_code,
                                      NULL),
                              DECODE (UPPER (c_valid_items.lot_control_code),
                                      'NO CONTROL', 1,
                                      'FULL CONTROL', 2,
                                      NULL),
                              DECODE (UPPER (c_valid_items.shelf_life_control),
                                      'NO CONTROL', 1,
                                      'SHELF LIFE DAYS', 2,
                                      'USER-DEFINED', 4,
                                      NULL),
                              DECODE (UPPER (c_valid_items.serial_control_code),
                                      'NO CONTROL', 1,
                                      'AT RECEIPT', 5,
                                      'AT SALES ORDER ISSUE', 6,
                                      'PREDEFINED', 2,
                                      NULL),
                              DECODE (UPPER (c_valid_items.shelf_life_control),
                                      'SHELF LIFE DAYS', c_valid_items.shelf_life_days,
                                      NULL),
                              c_valid_items.organization_id,
                              c_valid_items.tax_code_dff,
                              c_valid_items.sales_account_id,
                              c_valid_items.cost_of_sales_acct_id,
                              c_valid_items.expense_account_id,
                              DECODE (c_valid_items.organization_id,
                                      p_master_org_id, c_valid_items.template_name,
                                      NULL),
                              c_valid_items.fast_pack,
                              DECODE (c_valid_items.organization_id,
                                      p_master_org_id, c_valid_items.enable_serv_bill_flag,
                                      NULL),
                              DECODE (
                                 c_valid_items.organization_id,
                                 p_master_org_id, DECODE (c_valid_items.billing_type_flag,
                                                          'NULL', NULL,
                                                          c_valid_items.billing_type_flag),
                                 NULL),
                              DECODE (
                                 c_valid_items.organization_id,
                                 p_master_org_id, DECODE (c_valid_items.service_request_flag,
                                                          'NULL', NULL,
                                                          c_valid_items.service_request_flag),
                                 NULL),
                              DECODE (c_valid_items.organization_id,
                                      p_master_org_id, c_valid_items.track_install_base_flag,
                                      NULL),
                              DECODE (c_valid_items.organization_id,
                                      p_master_org_id, c_valid_items.enable_contract_cover_flag,
                                      NULL),
                              DECODE (c_valid_items.service_returnable_flag,
                                      'NULL', NULL,
                                      c_valid_items.service_returnable_flag),
                              c_valid_items.item_type,
                              c_valid_items.taxable_flag,
                              c_valid_items.po_tax_code,
                              c_valid_items.auto_lot_alpha_prefix,
                              c_valid_items.start_auto_lot_number,
                              c_valid_items.auto_serial_prefix,
                              c_valid_items.start_serial_number,
                              c_valid_items.organization_code,
                              c_valid_items.organization_id,
                              v_bom_allowed,
                              v_build_in_wip,
                              v_cust_ord_enabled,
                              v_int_ord_enabled,
                              v_invoice_enabled,
                              v_purchaseable,
                              v_transactable,
                              v_stockable,
                              c_valid_items.item_cost,
                              DECODE (c_valid_items.item_cost, NULL, NULL, 'Material'),
			      Decode(upper(c_valid_items.lot_control_code),'FULL CONTROL','Y',NULL),		-- Added on 10/06/2015
			      Decode(upper(c_valid_items.lot_control_code),'FULL CONTROL',1,NULL),		-- Added on 10/06/2015
			      Decode(upper(c_valid_items.lot_control_code),'FULL CONTROL','Y',NULL),		-- Added on 10/06/2015                              
                              0,
                              v_user_id,
                              NVL (c_valid_items.validation_date, c_valid_items.creation_date),
                              1);


               /* Added the below to copy revisions for Items in child org from MST */

               IF c_valid_items.organization_id != p_master_org_id
               THEN
                  -- v_item_exists := NULL;        -- Commented out on 05/29/2014
                  v_item_id1 := NULL;                                         -- Added on 05/29/2014

                  OPEN check_item_exists (c_valid_items.item_number);

                  -- fetch check_item_exists into v_item_exists;    -- Commented out on 05/29/2014
                  FETCH check_item_exists INTO v_item_id1;                    -- Added on 05/29/2014

                  CLOSE check_item_exists;

                  -- If nvl(v_item_exists,'N') = 'Y' Then    -- Commented out on 05/29/2014
                  IF v_item_id1 IS NOT NULL
                  THEN                                                        -- Added on 05/29/2014
                     -- For c_revs in get_item_revs (c_valid_items.item_number) Loop    -- Commented out on 05/29/2014
                     FOR c_revs IN get_item_revs (v_item_id1)
                     LOOP                                                     -- Added on 05/29/2014
                        INSERT INTO MTL_ITEM_REVISIONS_INTERFACE (transaction_type,
                                                                  item_number,
                                                                  organization_code,
                                                                  organization_id,
                                                                  revision,
                                                                  revision_label,
                                                                  description,
                                                                  effectivity_date,
                                                                  set_process_id,
                                                                  created_by,
                                                                  creation_date,
                                                                  process_flag)
                             VALUES (
                                       'CREATE',
                                       c_valid_items.item_number,
                                       c_valid_items.organization_code,
                                       c_valid_items.organization_id,
                                       c_revs.revision,
                                       c_revs.revision_label,
                                       c_revs.description,
                                       c_revs.effectivity_date,
                                       0,
                                       v_user_id,
                                       NVL (c_valid_items.validation_date,
                                            c_valid_items.creation_date),
                                       1);
                     END LOOP;

                     -- Added the below on 05/29/2014 to insert starting rev (-) if it is missing at master org

                     v_start_rev := NULL;

                     OPEN get_start_rev (c_valid_items.organization_id);

                     FETCH get_start_rev INTO v_start_rev;

                     CLOSE get_start_rev;

                     v_start_rev_exists := NULL;

                     OPEN check_start_rev (v_item_id1, c_valid_items.organization_id, v_start_rev);

                     FETCH check_start_rev INTO v_start_rev_exists;

                     CLOSE check_start_rev;

                     IF NVL (v_start_rev_exists, 'N') = 'N'
                     THEN                               -- Starting rev does not exist at master org
                        v_min_eff_date := NULL;

                        OPEN get_min_eff_date (v_item_id1);

                        FETCH get_min_eff_date INTO v_min_eff_date;

                        CLOSE get_min_eff_date;

                        INSERT INTO MTL_ITEM_REVISIONS_INTERFACE (transaction_type,
                                                                  item_number,
                                                                  organization_code,
                                                                  organization_id,
                                                                  revision,
                                                                  revision_label,
                                                                  effectivity_date,
                                                                  set_process_id,
                                                                  created_by,
                                                                  creation_date,
                                                                  process_flag)
                             VALUES (
                                       'CREATE',
                                       c_valid_items.item_number,
                                       c_valid_items.organization_code,
                                       c_valid_items.organization_id,
                                       v_start_rev,
                                       v_start_rev,
                                       v_min_eff_date,
                                       0,
                                       v_user_id,
                                       NVL (c_valid_items.validation_date,
                                            c_valid_items.creation_date),
                                       1);
                     END IF;               -- nvl(v_start_rev_exists,'N') = 'N'    -- End 05/29/2014
                  END IF;                                                 -- v_item_exists,'N') = 'Y
               END IF;                           -- c_valid_items.organization_id != p_master_org_id

               IF c_valid_items.inv_category_code IS NOT NULL
               THEN
                  IF v_invctl_level = 2
                     OR (v_invctl_level = 1 AND c_valid_items.organization_id = p_master_org_id)
                  THEN
                     INSERT INTO MTL_ITEM_CATEGORIES_INTERFACE (item_number,
                                                                organization_code,
                                                                organization_id,
                                                                category_set_name,
                                                                category_name,
                                                                created_by,
                                                                creation_date,
                                                                set_process_id,
                                                                transaction_type,
                                                                process_flag)
                          VALUES (c_valid_items.item_number,
                                  c_valid_items.organization_code,
                                  c_valid_items.organization_id,
                                  v_inv_cat_set_name,
                                  c_valid_items.inv_category_code,
                                  v_user_id,
                                  NVL (c_valid_items.validation_date, c_valid_items.creation_date),
                                  0,
                                  'CREATE',
                                  1);
                  END IF;
               END IF;


               IF c_valid_items.po_category_code IS NOT NULL
               THEN
                  IF v_poctl_level = 2
                     OR (v_poctl_level = 1 AND c_valid_items.organization_id = p_master_org_id)
                  THEN
                     INSERT INTO MTL_ITEM_CATEGORIES_INTERFACE (item_number,
                                                                organization_code,
                                                                organization_id,
                                                                category_set_name,
                                                                category_name,
                                                                created_by,
                                                                creation_date,
                                                                set_process_id,
                                                                transaction_type,
                                                                process_flag)
                          VALUES (c_valid_items.item_number,
                                  c_valid_items.organization_code,
                                  c_valid_items.organization_id,
                                  v_po_cat_set_name,
                                  c_valid_items.po_category_code,
                                  v_user_id,
                                  NVL (c_valid_items.validation_date, c_valid_items.creation_date),
                                  0,
                                  'CREATE',
                                  1);
                  END IF;
               END IF;


               IF c_valid_items.item_type_category IS NOT NULL
               THEN
                  IF v_itpctl_level = 2
                     OR (v_itpctl_level = 1 AND c_valid_items.organization_id = p_master_org_id)
                  THEN
                     INSERT INTO MTL_ITEM_CATEGORIES_INTERFACE (item_number,
                                                                organization_code,
                                                                organization_id,
                                                                category_set_name,
                                                                category_name,
                                                                created_by,
                                                                creation_date,
                                                                set_process_id,
                                                                transaction_type,
                                                                process_flag)
                          VALUES (c_valid_items.item_number,
                                  c_valid_items.organization_code,
                                  c_valid_items.organization_id,
                                  v_itp_cat_set_name,
                                  c_valid_items.item_type_category,
                                  v_user_id,
                                  NVL (c_valid_items.validation_date, c_valid_items.creation_date),
                                  0,
                                  'CREATE',
                                  1);
                  END IF;
               END IF;
            /* If c_valid_items.service_category_code is NOT NULL then

                If v_serctl_level = 2 or (v_serctl_level = 1 and c_valid_items.organization_id = p_master_org_id) Then
                   Insert into MTL_ITEM_CATEGORIES_INTERFACE
                    (item_number,
                    organization_code,
                    organization_id,
                    category_set_name,
                    category_name,
                    created_by,
                    creation_date,
                    set_process_id,
                    transaction_type,
                    process_flag)
                   Values
                    (c_valid_items.item_number,
                    c_valid_items.organization_code,
                    c_valid_items.organization_id,
                    v_ser_cat_set_name,
                    c_valid_items.service_category_code,
                    v_user_id,
                    nvl(c_valid_items.validation_date,c_valid_items.creation_date),
                    0,
                    'CREATE',
                    1);
                End If;

            End If;    */


            END IF;
         /* Perform checks for transaction type as UPDATE  */

         ELSIF v_count_records != 0 OR v_transaction_type = 'UPDATE'
         THEN
            /* Determine if an UPDATE is necessary by comparing Item attributes in Oracle to attributes in Agile */

            v_description := NULL;
            v_item_status := NULL;
            v_tax_code_dff := NULL;
            v_sales_account := NULL;
            v_cogs_account := NULL;
            v_expense_account := NULL;
            v_serv_billing_flag := NULL;
            v_billing_type := NULL;
            v_service_request := NULL;
            v_track_install_base := NULL;
            v_contract_coverage := NULL;
            v_recovered_code := NULL;
            v_obs_template := NULL;


            OPEN get_item_attributes (c_valid_items.item_number, c_valid_items.organization_id);

            FETCH get_item_attributes
            INTO v_description,
                 v_item_status,
                 v_tax_code_dff,
                 v_sales_account,
                 v_cogs_account,
                 v_expense_account,
                 v_serv_billing_flag,
                 v_billing_type,
                 v_service_request,
                 v_track_install_base,
                 v_contract_coverage,
                 v_recovered_code;

            CLOSE get_item_attributes;

            v_update_flag := 'N';

            -- If c_valid_items.organization_id = p_master_org_id Then        -- Master Level Attributes

            /* If c_valid_items.description = v_description Then            -- Commented out on 05/22/2014
         v_description := NULL;
        Else
         v_update_flag := 'Y';
         v_description := c_valid_items.description;
        End If;                        */
            -- End 05/22/2014
            
           -- Commented out on 02/29/2016 the below to stop updates to service attributes
	
          /*  IF c_valid_items.enable_serv_bill_flag IS NOT NULL
            THEN
               IF c_valid_items.enable_serv_bill_flag = NVL (v_serv_billing_flag, 'NA')
               THEN
                  v_serv_billing_flag := NULL;
               ELSIF c_valid_items.enable_serv_bill_flag != NVL (v_serv_billing_flag, 'NA')
               THEN
                  v_update_flag := 'Y';
                  v_serv_billing_flag := c_valid_items.enable_serv_bill_flag;
               END IF;
            END IF;

            IF c_valid_items.billing_type_flag IS NOT NULL
            THEN
               IF c_valid_items.billing_type_flag = NVL (v_billing_type, 'NA')
               THEN
                  v_billing_type := NULL;
               ELSIF c_valid_items.billing_type_flag != NVL (v_billing_type, 'NA')
               THEN
                  v_update_flag := 'Y';

                  -- v_billing_type := c_valid_items.billing_type_flag;
                  SELECT DECODE (c_valid_items.billing_type_flag,
                                 'NULL', '!',
                                 c_valid_items.billing_type_flag)
                    INTO v_billing_type
                    FROM DUAL;
               END IF;
            END IF;

            IF c_valid_items.service_request_flag IS NOT NULL
            THEN
               IF c_valid_items.service_request_flag = NVL (v_service_request, 'NA')
               THEN
                  v_service_request := NULL;
               ELSIF c_valid_items.service_request_flag != NVL (v_service_request, 'NA')
               THEN
                  v_update_flag := 'Y';

                  -- v_service_request := c_valid_items.service_request_flag;
                  SELECT DECODE (c_valid_items.service_request_flag,
                                 'NULL', '!',
                                 c_valid_items.service_request_flag)
                    INTO v_service_request
                    FROM DUAL;
               END IF;
            END IF;

            IF c_valid_items.track_install_base_flag IS NOT NULL
            THEN
               IF c_valid_items.track_install_base_flag = NVL (v_track_install_base, 'NA')
               THEN
                  v_track_install_base := NULL;
               ELSIF c_valid_items.track_install_base_flag != NVL (v_track_install_base, 'NA')
               THEN
                  v_update_flag := 'Y';
                  v_track_install_base := c_valid_items.track_install_base_flag;
               END IF;
            END IF;

            IF c_valid_items.enable_contract_cover_flag IS NOT NULL
            THEN
               IF c_valid_items.enable_contract_cover_flag = NVL (v_contract_coverage, 'NA')
               THEN
                  v_contract_coverage := NULL;
               ELSIF c_valid_items.enable_contract_cover_flag != NVL (v_contract_coverage, 'NA')
               THEN
                  v_update_flag := 'Y';
                  v_contract_coverage := c_valid_items.enable_contract_cover_flag;
               END IF;
            END IF;	*/	-- End 02/29/2016

            -- End If;        -- Master Level Attributes

            IF c_valid_items.item_status_code_agile = v_item_status
            THEN
               v_item_status := NULL;
            ELSE
               v_update_flag := 'Y';
               v_item_status := c_valid_items.item_status_code_agile;
               v_obs_template :=
                  ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Default Item Obsolete Template',
                                                           c_valid_items.item_status_code_agile,
                                                           NULL,
                                                           NULL,
                                                           NULL);
            END IF;

            /* If c_valid_items.tax_code_dff is NOT NULL Then                -- Commented out on 06/02/2014
             If c_valid_items.tax_code_dff = nvl(v_tax_code_dff,'NA') Then
              v_tax_code_dff := NULL;
             Elsif c_valid_items.tax_code_dff != nvl(v_tax_code_dff,'NA') Then
              v_update_flag := 'Y';
              v_tax_code_dff := c_valid_items.tax_code_dff;
             End If;
            End If;

            If c_valid_items.sales_account_id is NOT NULL Then
             If c_valid_items.sales_account_id = v_sales_account Then
              v_sales_account := NULL;
             Elsif c_valid_items.sales_account_id != v_sales_account Then
              v_update_flag := 'Y';
              v_sales_account := c_valid_items.sales_account_id;
             End If;
            End If;

            If c_valid_items.cost_of_sales_acct_id is NOT NULL Then
             If c_valid_items.cost_of_sales_acct_id = v_cogs_account Then
              v_cogs_account := NULL;
             Elsif c_valid_items.cost_of_sales_acct_id != v_cogs_account Then
              v_update_flag := 'Y';
              v_cogs_account := c_valid_items.cost_of_sales_acct_id;
             End If;
            End If;

            If c_valid_items.expense_account_id is NOT NULL Then
             If c_valid_items.expense_account_id = v_expense_account Then
              v_expense_account := NULL;
             Elsif c_valid_items.expense_account_id != v_expense_account Then
              v_update_flag := 'Y';
              v_expense_account := c_valid_items.expense_account_id;
             End If;
            End If;                                        */
            -- End 06/02/2014
            
	   -- Commented out on 02/29/2016 the below to stop updates to service attributes            

            /* IF c_valid_items.service_returnable_flag IS NOT NULL
            THEN
               IF c_valid_items.service_returnable_flag = NVL (v_recovered_code, 'NA')
               THEN
                  v_recovered_code := NULL;
               ELSIF c_valid_items.service_returnable_flag != NVL (v_recovered_code, 'NA')
               THEN
                  v_update_flag := 'Y';

                  -- v_recovered_code := c_valid_items.service_returnable_flag;
                  SELECT DECODE (c_valid_items.service_returnable_flag,
                                 'NULL', '!',
                                 c_valid_items.service_returnable_flag)
                    INTO v_recovered_code
                    FROM DUAL;
               END IF;
            END IF;	*/

            v_cat_update_flag := 'N';
            v_po_cat_code := NULL;
            v_inv_cat_code := NULL;
            v_ser_cat_code := NULL;
            v_item_type_cat := NULL;

            /* Determine If Inventory Category Codes are different       -- Commented out on 06/02/2014

            If v_invctl_level = 2 or (v_invctl_level = 1 and c_valid_items.organization_id = p_master_org_id) then
             open get_category_code(v_inv_cat_set_name,c_valid_items.organization_id,c_valid_items.inventory_item_id,NULL);
             fetch get_category_code into v_inv_cat_code;
             close get_category_code;

             If nvl(c_valid_items.inv_category_code,'NA') != nvl(v_inv_cat_code,'NA') and c_valid_items.inv_category_code is NOT NULL Then
              v_cat_update_flag := 'Y';
             End If;
                End If;                            */
            -- End 06/02/2014


            /* Determine If Purchasing Category Codes are different       -- Commented out on 06/02/2014

            If v_poctl_level = 2 or (v_poctl_level = 1 and c_valid_items.organization_id = p_master_org_id) then
             open get_category_code(v_po_cat_set_name,c_valid_items.organization_id,c_valid_items.inventory_item_id,NULL);
             fetch get_category_code into v_po_cat_code;
             close get_category_code;

             If nvl(c_valid_items.po_category_code,'NA') != nvl(v_po_cat_code,'NA') and c_valid_items.po_category_code is NOT NULL Then
              v_cat_update_flag := 'Y';
             End If;
                End If;                                    */
            -- End on 06/02/2014


            /* Determine If Item Type Category Codes are different   */

            IF v_itpctl_level = 2
               OR (v_itpctl_level = 1 AND c_valid_items.organization_id = p_master_org_id)
            THEN
               OPEN get_category_code (v_itp_cat_set_name,
                                       c_valid_items.organization_id,
                                       c_valid_items.inventory_item_id,
                                       NULL);

               FETCH get_category_code INTO v_item_type_cat;

               CLOSE get_category_code;

               IF NVL (c_valid_items.item_type_category, 'NA') != NVL (v_item_type_cat, 'NA')
                  AND c_valid_items.item_type_category IS NOT NULL
               THEN
                  v_cat_update_flag := 'Y';
               END IF;
            END IF;


            /* Determine If Service Category Codes are different

        If v_serctl_level = 2 or (v_serctl_level = 1 and c_valid_items.organization_id = p_master_org_id) then
         open get_category_code(v_ser_cat_set_name,c_valid_items.organization_id,c_valid_items.inventory_item_id,NULL);
         fetch get_category_code into v_ser_cat_code;
         close get_category_code;

         If nvl(c_valid_items.service_category_code,'NA') != nvl(v_ser_cat_code,'NA') Then
          v_cat_update_flag := 'Y';
         End If;
            End If;                 */

            IF v_update_flag = 'N' AND (v_cat_update_flag = 'N')
            THEN                                           -- Item record does not require an UPDATE
               /* Mark the record as Processed and issue a warning that the record does not require an UPDATE
                      since all the attributes in Oracle match with the attributes in Agile */

               UPDATE ILINK_MTL_ITEMS_INT_TEMP
                  SET process_flag = 'Y',
                      processed_date = SYSDATE,
                      transfer_to_oracle = 'No',
                      -- warning_message = warning_message||' WARNING : Item does not need an UPDATE since all the attributes in Oracle match those in Agile',
                      record_status = 'Succeeded'
                WHERE     record_id = c_valid_items.record_id
                      AND item_number = c_valid_items.item_number
                      AND organization_id = c_valid_items.organization_id;
            ELSIF v_update_flag = 'Y' OR (v_cat_update_flag = 'Y')
            THEN                                                /* Item record requires an UPDATE */
               v_count_records := 0;

               OPEN get_record_count (c_valid_items.item_number,
                                      c_valid_items.organization_code,
                                      'UPDATE');

               FETCH get_record_count INTO v_count_records;

               CLOSE get_record_count;

               IF v_count_records = 0 AND v_update_flag = 'Y'
               THEN                        /* No UPDATE records exist for item in Interface table */
                  /* Insert Record into Item Interface as UPDATE */

                  INSERT INTO MTL_SYSTEM_ITEMS_INTERFACE (transaction_type,
                                                          item_number,
                                                          -- description,                    -- Commented out on 05/22/2014
                                                          inventory_item_status_code,
                                                          -- attribute14,                    -- Commented out on 06/02/2014
                                                          -- sales_account,                -- Commented out on 06/02/2014
                                                          -- cost_of_sales_account,            -- Commented out on 06/02/2014
                                                          -- expense_account,                -- Commented out on 06/02/2014
                                                          template_name,
                                                          -- serv_billing_enabled_flag,		-- Commented out on 02/29/2016
                                                          -- material_billable_flag,		-- Commented out on 02/29/2016
                                                          -- serv_req_enabled_code,		-- Commented out on 02/29/2016
                                                          -- comms_nl_trackable_flag,		-- Commented out on 02/29/2016
                                                          -- serviceable_product_flag,		-- Commented out on 02/29/2016
                                                          -- recovered_part_disp_code,		-- Commented out on 02/29/2016
                                                          inventory_item_id,
                                                          organization_code,
                                                          organization_id,
                                                          set_process_id,
                                                          created_by,
                                                          creation_date,
                                                          last_updated_by,
                                                          last_update_date,
                                                          process_flag)
                       VALUES ('UPDATE',
                               c_valid_items.item_number,
                               -- v_description,                 -- Commented out on 05/22/2014
                               v_item_status,
                               -- v_tax_code_dff,                -- Commented out on 06/02/2014
                               -- v_sales_account,                -- Commented out on 06/02/2014
                               -- v_cogs_account,                -- Commented out on 06/02/2014
                               -- v_expense_account,                -- Commented out on 06/02/2014
                               v_obs_template,						
                               -- DECODE (c_valid_items.organization_id,		-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               --       p_master_org_id,v_serv_billing_flag,NULL),	-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               -- DECODE (c_valid_items.organization_id,		-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               --       p_master_org_id,v_billing_type,NULL),		-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               -- DECODE (c_valid_items.organization_id,		-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               --       p_master_org_id,v_service_request,NULL),	-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               -- DECODE (c_valid_items.organization_id,		-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               --       p_master_org_id,v_track_install_base,NULL),	-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               -- DECODE (c_valid_items.organization_id,		-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               --       p_master_org_id,v_contract_coverage,NULL),	-- Modified on 02/19/2016	-- Commented out on 02/29/2016
                               -- v_recovered_code,									-- Commented out on 02/29/2016
                               c_valid_items.inventory_item_id,
                               c_valid_items.organization_code,
                               c_valid_items.organization_id,
                               0,
                               v_user_id,
                               NVL (c_valid_items.validation_date, c_valid_items.creation_date),
                               v_user_id,
                               NVL (c_valid_items.validation_date, c_valid_items.creation_date),
                               1);
               END IF;                                      -- UPDATE record in item interface table

               IF v_cat_update_flag = 'Y'
               THEN
                  /* Update Inventory Category code             -- Commented out on 06/02/2014

                      If (nvl(v_inv_cat_code,'NA') != nvl(c_valid_items.inv_category_code,'NA')) and
                            (v_invctl_level = 2 or (v_invctl_level = 1 and c_valid_items.organization_id = p_master_org_id)) then

                          v_txn_type := NULL;
                          If nvl(c_valid_items.inv_category_code,'NA') = 'NA' Then
                           v_txn_type := 'DELETE';
                          Elsif nvl(v_inv_cat_code,'NA') = 'NA' Then
                           v_txn_type := 'CREATE';
                          Else
                           v_txn_type := 'UPDATE';
                          End If;
                          If  v_txn_type in ('CREATE','UPDATE') Then
                             Insert into MTL_ITEM_CATEGORIES_INTERFACE
                              (item_number,
                              organization_code,
                              organization_id,
                              inventory_item_id,
                              category_set_name,
                              category_name,
                              old_category_name,
                              transaction_type,
                              created_by,
                              creation_date,
                              set_process_id,
                              process_flag)
                             Values
                              (c_valid_items.item_number,
                              c_valid_items.organization_code,
                              c_valid_items.organization_id,
                              c_valid_items.inventory_item_id,
                              v_inv_cat_set_name,
                              nvl(c_valid_items.inv_category_code,v_inv_cat_code),
                              v_inv_cat_code,
                              v_txn_type,
                              v_user_id,
                              nvl(c_valid_items.validation_date,c_valid_items.creation_date),
                              0,
                              1);
                          End If;
                      End If; -- Inventory Category Code        */
                  -- End 06/02/2014


                  /* Update Purchasing Category code             -- Commented out on 06/02/2014

                  If (nvl(v_po_cat_code,'NA') != nvl(c_valid_items.po_category_code,'NA')) and
                        (v_poctl_level = 2 or (v_poctl_level = 1 and c_valid_items.organization_id = p_master_org_id)) then

                      v_txn_type := NULL;
                      If nvl(c_valid_items.po_category_code,'NA') = 'NA' Then
                       v_txn_type := 'DELETE';
                      Elsif nvl(v_po_cat_code,'NA') = 'NA' Then
                       v_txn_type := 'CREATE';
                      Else
                       v_txn_type := 'UPDATE';
                      End If;
                      If  v_txn_type in ('CREATE','UPDATE') Then
                         Insert into MTL_ITEM_CATEGORIES_INTERFACE
                          (item_number,
                          organization_code,
                          organization_id,
                          inventory_item_id,
                          category_set_name,
                          category_name,
                          old_category_name,
                          transaction_type,
                          created_by,
                          creation_date,
                          set_process_id,
                          process_flag)
                         Values
                          (c_valid_items.item_number,
                          c_valid_items.organization_code,
                          c_valid_items.organization_id,
                          c_valid_items.inventory_item_id,
                          v_po_cat_set_name,
                          nvl(c_valid_items.po_category_code,v_po_cat_code),
                          v_po_cat_code,
                          v_txn_type,
                          v_user_id,
                          nvl(c_valid_items.validation_date,c_valid_items.creation_date),
                          0,
                          1);
                      End If;
                  End If; -- Product Family Category Code        */
                  -- End 06/02/2014


                  /* Update Item Type Category code */

                  IF (NVL (v_item_type_cat, 'NA') != NVL (c_valid_items.item_type_category, 'NA'))
                     AND (v_itpctl_level = 2
                          OR (v_itpctl_level = 1
                              AND c_valid_items.organization_id = p_master_org_id))
                  THEN
                     v_txn_type := NULL;

                     IF NVL (c_valid_items.item_type_category, 'NA') = 'NA'
                     THEN
                        v_txn_type := 'DELETE';
                     ELSIF NVL (v_item_type_cat, 'NA') = 'NA'
                     THEN
                        v_txn_type := 'CREATE';
                     ELSE
                        v_txn_type := 'UPDATE';
                     END IF;

                     IF v_txn_type IN ('CREATE', 'UPDATE')
                     THEN
                        INSERT INTO MTL_ITEM_CATEGORIES_INTERFACE (item_number,
                                                                   organization_code,
                                                                   organization_id,
                                                                   inventory_item_id,
                                                                   category_set_name,
                                                                   category_name,
                                                                   old_category_name,
                                                                   transaction_type,
                                                                   created_by,
                                                                   creation_date,
                                                                   set_process_id,
                                                                   process_flag)
                             VALUES (
                                       c_valid_items.item_number,
                                       c_valid_items.organization_code,
                                       c_valid_items.organization_id,
                                       c_valid_items.inventory_item_id,
                                       v_itp_cat_set_name,
                                       NVL (c_valid_items.item_type_category, v_item_type_cat),
                                       v_item_type_cat,
                                       v_txn_type,
                                       v_user_id,
                                       NVL (c_valid_items.validation_date,
                                            c_valid_items.creation_date),
                                       0,
                                       1);
                     END IF;
                  END IF;                                                 -- Item Type Category Code
               /* Update Service Category code

                If (nvl(v_ser_cat_code,'NA') != nvl(c_valid_items.service_category_code,'NA')) and
                     (v_serctl_level = 2 or (v_serctl_level = 1 and c_valid_items.organization_id = p_master_org_id)) then

                   v_txn_type := NULL;
                   If nvl(c_valid_items.service_category_code,'NA') = 'NA' Then
                    v_txn_type := 'DELETE';
                   Elsif nvl(v_ser_cat_code,'NA') = 'NA' Then
                    v_txn_type := 'CREATE';
                   Else
                    v_txn_type := 'UPDATE';
                   End If;
                   If  v_txn_type in ('CREATE','UPDATE') Then
                      Insert into MTL_ITEM_CATEGORIES_INTERFACE
                       (item_number,
                       organization_code,
                       organization_id,
                       inventory_item_id,
                       category_set_name,
                       category_name,
                       old_category_name,
                       transaction_type,
                       created_by,
                       creation_date,
                       set_process_id,
                       process_flag)
                      Values
                       (c_valid_items.item_number,
                       c_valid_items.organization_code,
                       c_valid_items.organization_id,
                       c_valid_items.inventory_item_id,
                       v_ser_cat_set_name,
                       nvl(c_valid_items.service_category_code,v_ser_cat_code),
                       v_ser_cat_code,
                       v_txn_type,
                       v_user_id,
                       nvl(c_valid_items.validation_date,c_valid_items.creation_date),
                       0,
                       1);
                   End If;
               End If; -- Service Category Code    */

               END IF;                                  -- UPDATE Record in category interface table
            END IF;                                                   -- Item record requires UPDATE
         END IF;                                                                 -- Transaction Type

         /* Mark the record as Processed indicating the record is inserted into the Interface table */

         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET process_flag = 'Y', processed_date = SYSDATE, transaction_type = v_transaction_type
          WHERE     record_id = c_valid_items.record_id
                AND item_number = c_valid_items.item_number
                AND organization_id = c_valid_items.organization_id;
      -- FND_FILE.PUT_LINE(FND_FILE.LOG,'Item/org/update/cat_update/ is '||c_valid_items.item_number||' '||c_valid_items.organization_code||' '||v_update_flag||' '||v_cat_update_flag);


      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_ITEM_INSERT_INT is ' || SQLERRM);
   END ILINK_ITEM_INSERT_INT;


   -- Added the below procedure on 03/02/2015 to Invoke Item Import in Validate Mode

   PROCEDURE ILINK_INV_PRE_OPEN_INTERFACE (p_master_org_id   IN     NUMBER,
                                           p_req_id1            OUT NUMBER,
                                           p_req_id2            OUT NUMBER)
   IS
      /* Define a Cursor to verify if records exist in the Interface table */

      CURSOR get_intf_table_count (p_transaction_type IN VARCHAR2)
      IS
         SELECT COUNT (*)
           FROM MTL_SYSTEM_ITEMS_INTERFACE
          WHERE transaction_type = p_transaction_type AND process_flag = 1 AND set_process_id = 0;

      CURSOR get_cat_table_count
      IS
         SELECT COUNT (*)
           FROM MTL_ITEM_CATEGORIES_INTERFACE
          WHERE process_flag = 1 AND set_process_id = 0;


      v_ret              NUMBER;
      call_status        BOOLEAN;
      rphase             VARCHAR2 (30);
      rstatus            VARCHAR2 (30);
      dphase             VARCHAR2 (30);
      dstatus            VARCHAR2 (30);
      MESSAGE            VARCHAR2 (240);
      v_count_records    NUMBER;
      v_count_records1   NUMBER;
      v_org_id           NUMBER;
   BEGIN
      v_count_records := 0;

      /* Determine if records with transaction type "CREATE" exist in the Item Interface table */

      OPEN get_intf_table_count ('CREATE');

      FETCH get_intf_table_count INTO v_count_records;

      CLOSE get_intf_table_count;


      IF V_count_Records > 0
      THEN
         /* Records with transaction type "CREATE" exist in the Interface table so call Item Import in CREATE mode */

         v_ret :=
            fnd_request.submit_request ('INV',
                                        'INCOIN',
                                        'Import Items',
                                        TO_CHAR (SYSDATE, 'DD-MON-RR HH24:MI:SS'),
                                        FALSE,
                                        p_master_org_id,                                   -- org id
                                        1,                                 -- 'Yes', -- all org flag
                                        1,                           -- 'Yes', -- Validate Item Flag
                                        2,                             -- 'No', -- Process Item Flag
                                        2,                 -- 'No'   -- Delete Imported Records Flag
                                        0,                                         -- set Process ID
                                        1                            -- 'CREATE' -- Transaction Type
                                         );

         p_req_id1 := v_ret;

         IF v_ret = 0
         THEN                                                               /* Item Import failed */
            raise_application_error (-20020, 'Error in Item Import Interface');
         ELSE
            COMMIT;                                                      /* Item Import succeeded */

            /* Exit out when the concurrent request for Item Import completes */
            LOOP
               call_status :=
                  fnd_concurrent.get_request_status (v_ret,
                                                     '',
                                                     '',
                                                     rphase,
                                                     rstatus,
                                                     dphase,
                                                     dstatus,
                                                     MESSAGE);

               IF    (dphase = 'COMPLETE' AND dstatus = 'NORMAL')
                  OR (dphase = 'COMPLETE' AND dstatus = 'ERROR')
                  OR (dphase = 'COMPLETE' AND dstatus = 'TERMINATED')
                  OR (dphase = 'COMPLETE' AND dstatus = 'WARNING')
               THEN
                  EXIT;
               END IF;
            END LOOP;
         END IF;
      END IF;


      v_count_records := 0;
      v_count_records1 := 0;

      /* Determine if records with transaction type "UPDATE" exist in the Item Interface table */

      OPEN get_intf_table_count ('UPDATE');

      FETCH get_intf_table_count INTO v_count_records;

      CLOSE get_intf_table_count;

      /* Determine if records with exist in the Categories Interface table */

      OPEN get_cat_table_count;

      FETCH get_cat_table_count INTO v_count_records1;

      CLOSE get_cat_table_count;

      IF v_count_Records > 0 OR v_count_records1 > 0
      THEN
         /* Records with transaction type "UPDATE" exist in the Interface table so call Item Import in UPDATE mode */

         v_ret :=
            fnd_request.submit_request ('INV',
                                        'INCOIN',
                                        'Import Items',
                                        TO_CHAR (SYSDATE, 'DD-MON-RR HH24:MI:SS'),
                                        FALSE,
                                        p_master_org_id,                                   -- org id
                                        1,                                 --'Yes',  -- all org flag
                                        1,                           -- 'Yes', -- Validate Item Flag
                                        2,                             -- 'No', -- Process Item Flag
                                        2,                 -- 'No'   -- Delete Imported Records Flag
                                        0,                                         -- set Process ID
                                        2                            -- 'UPDATE' -- Transaction Type
                                         );

         p_req_id2 := v_ret;

         IF v_ret = 0
         THEN                                                               /* Item Import failed */
            raise_application_error (-20020, 'Error in Item Import Interface');
         ELSE
            COMMIT;                                                      /* Item Import succeeded */

            /* Exit out when the concurrent request for Item Import completes */
            LOOP
               call_status :=
                  fnd_concurrent.get_request_status (v_ret,
                                                     '',
                                                     '',
                                                     rphase,
                                                     rstatus,
                                                     dphase,
                                                     dstatus,
                                                     MESSAGE);

               IF    (dphase = 'COMPLETE' AND dstatus = 'NORMAL')
                  OR (dphase = 'COMPLETE' AND dstatus = 'ERROR')
                  OR (dphase = 'COMPLETE' AND dstatus = 'TERMINATED')
                  OR (dphase = 'COMPLETE' AND dstatus = 'WARNING')
               THEN
                  EXIT;
               END IF;
            END LOOP;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_INV_PRE_OPEN_INTERFACE is ' || SQLERRM);
   END ILINK_INV_PRE_OPEN_INTERFACE;                                               -- End 03/02/2015


   -- Added the below procedure on 03/02/2015 to Report Status after Item Import is inovked in Validate Mode

   PROCEDURE ILINK_POST_ITEM_VAL_INTERFACE (p_req_id1 IN NUMBER, p_req_id2 IN NUMBER)
   IS
      /* Define a Cursor to retreive errors from Item Interface table */

      CURSOR item_errors
      IS
           SELECT msie.error_message,
                  msii.process_flag,
                  msii.creation_date,
                  msii.item_number,
                  msii.organization_id,
                  msii.transaction_type
             FROM MTL_SYSTEM_ITEMS_INTERFACE msii, MTL_INTERFACE_ERRORS msie
            WHERE msii.set_process_id = 0 AND msii.transaction_id = msie.transaction_id(+)
         ORDER BY item_number;


      /* Define a Cursor to retreive errors from Item Categories Interface table */

      CURSOR category_errors
      IS
           SELECT msie.error_message,
                  mici.process_flag,
                  mici.item_number,
                  mici.creation_date,
                  mici.organization_id
             FROM MTL_ITEM_CATEGORIES_INTERFACE mici, MTL_INTERFACE_ERRORS msie
            WHERE mici.set_process_id = 0 AND mici.transaction_id = msie.transaction_id(+)
         ORDER BY item_number;
   BEGIN
      /* Fetch record status from Item interface and update corresponding records in temp table */

      FOR c_item_errors IN item_errors
      LOOP
         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET error_message = error_message || ' ' || c_item_errors.error_message,
                record_status =
                   DECODE (c_item_errors.process_flag,
                           4, 'Validated',
                           NULL, 'Validated',
                           'Error'),
                processed_date = SYSDATE,
                attribute10 = 'Item Import Validated'
          WHERE     organization_id = c_item_errors.organization_id
                AND item_number = c_item_errors.item_number
                AND -- transaction_type = c_item_errors.transaction_type and
                    record_status = 'Validated'; --and nvl(validation_date,creation_date) = c_item_errors.creation_date;
      END LOOP;

      /* Fetch record status from Item Categories interface and update corresponding records in temp table */

      FOR c_cat_errors IN category_errors
      LOOP
         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET error_message = error_message || ' ' || c_cat_errors.error_message,
                record_status =
                   DECODE (c_cat_errors.process_flag,
                           4, 'Validated',
                           NULL, 'Validated',
                           'Error'),
                processed_date = SYSDATE,
                attribute10 = 'Item Import Validated'
          WHERE     organization_id = c_cat_errors.organization_id
                AND item_number = c_cat_errors.item_number
                AND record_status = 'Validated'; -- and nvl(validation_date,creation_date) = c_cat_errors.creation_date;
      END LOOP;

      /* Delete records from Interface tables */

      DELETE FROM MTL_INTERFACE_ERRORS mie
            WHERE EXISTS
                     (SELECT 'x'
                        FROM MTL_SYSTEM_ITEMS_INTERFACE msi
                       WHERE msi.transaction_id = mie.transaction_id AND msi.set_process_id = 0)
                  OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_INTERFACE_ERRORS mie
            WHERE EXISTS
                     (SELECT 'x'
                        FROM MTL_ITEM_CATEGORIES_INTERFACE mic
                       WHERE mic.transaction_id = mie.transaction_id AND mic.set_process_id = 0)
                  OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_SYSTEM_ITEMS_INTERFACE
            WHERE set_process_id = 0 OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_ITEM_REVISIONS_INTERFACE
            WHERE set_process_id = 0 OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_ITEM_CATEGORIES_INTERFACE
            WHERE set_process_id = 0 OR request_id IN (p_req_id1, p_req_id2);
   /* Update Successfully processed records in temp table

   Update ILINK_MTL_ITEMS_INT_TEMP
   Set transfer_to_oracle = Decode(transfer_to_oracle,NULL,'YES',transfer_to_oracle)
   Where process_flag = 'Y' and
         record_status = 'Succeeded';    */

   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_POST_ITEM_VAL_INTERFACE is ' || SQLERRM);
   END ILINK_POST_ITEM_VAL_INTERFACE;                                              -- End 03/02/2015


   PROCEDURE ILINK_INV_OPEN_INTERFACE (p_master_org_id   IN     NUMBER,
                                       p_req_id1            OUT NUMBER,
                                       p_req_id2            OUT NUMBER)
   IS
      /* Define a Cursor to verify if records exist in the Interface table */

      CURSOR get_intf_table_count (p_transaction_type IN VARCHAR2)
      IS
         SELECT COUNT (*)
           FROM MTL_SYSTEM_ITEMS_INTERFACE
          WHERE transaction_type = p_transaction_type AND process_flag = 1 AND set_process_id = 0;

      CURSOR get_cat_table_count
      IS
         SELECT COUNT (*)
           FROM MTL_ITEM_CATEGORIES_INTERFACE
          WHERE process_flag = 1 AND set_process_id = 0;


      v_ret              NUMBER;
      call_status        BOOLEAN;
      rphase             VARCHAR2 (30);
      rstatus            VARCHAR2 (30);
      dphase             VARCHAR2 (30);
      dstatus            VARCHAR2 (30);
      MESSAGE            VARCHAR2 (240);
      v_count_records    NUMBER;
      v_count_records1   NUMBER;
      v_org_id           NUMBER;
   BEGIN
      v_count_records := 0;

      /* Determine if records with transaction type "CREATE" exist in the Item Interface table */

      OPEN get_intf_table_count ('CREATE');

      FETCH get_intf_table_count INTO v_count_records;

      CLOSE get_intf_table_count;


      IF V_count_Records > 0
      THEN
         /* Records with transaction type "CREATE" exist in the Interface table so call Item Import in CREATE mode */

         v_ret :=
            fnd_request.submit_request ('INV',
                                        'INCOIN',
                                        'Import Items',
                                        TO_CHAR (SYSDATE, 'DD-MON-RR HH24:MI:SS'),
                                        FALSE,
                                        p_master_org_id,                                   -- org id
                                        1,                                 -- 'Yes', -- all org flag
                                        1,                           -- 'Yes', -- Validate Item Flag
                                        1,                            -- 'Yes', -- Process Item Flag
                                        2,                 -- 'No'   -- Delete Imported Records Flag
                                        0,                                         -- set Process ID
                                        1                            -- 'CREATE' -- Transaction Type
                                         );

         p_req_id1 := v_ret;

         IF v_ret = 0
         THEN                                                               /* Item Import failed */
            raise_application_error (-20020, 'Error in Item Import Interface');
         ELSE
            COMMIT;                                                      /* Item Import succeeded */

            /* Exit out when the concurrent request for Item Import completes */
            LOOP
               call_status :=
                  fnd_concurrent.get_request_status (v_ret,
                                                     '',
                                                     '',
                                                     rphase,
                                                     rstatus,
                                                     dphase,
                                                     dstatus,
                                                     MESSAGE);

               IF    (dphase = 'COMPLETE' AND dstatus = 'NORMAL')
                  OR (dphase = 'COMPLETE' AND dstatus = 'ERROR')
                  OR (dphase = 'COMPLETE' AND dstatus = 'TERMINATED')
                  OR (dphase = 'COMPLETE' AND dstatus = 'WARNING')
               THEN
                  EXIT;
               END IF;
            END LOOP;
         END IF;
      END IF;


      v_count_records := 0;
      v_count_records1 := 0;

      /* Determine if records with transaction type "UPDATE" exist in the Item Interface table */

      OPEN get_intf_table_count ('UPDATE');

      FETCH get_intf_table_count INTO v_count_records;

      CLOSE get_intf_table_count;

      /* Determine if records with exist in the Categories Interface table */

      OPEN get_cat_table_count;

      FETCH get_cat_table_count INTO v_count_records1;

      CLOSE get_cat_table_count;

      IF v_count_Records > 0 OR v_count_records1 > 0
      THEN
         /* Records with transaction type "UPDATE" exist in the Interface table so call Item Import in UPDATE mode */

         v_ret :=
            fnd_request.submit_request ('INV',
                                        'INCOIN',
                                        'Import Items',
                                        TO_CHAR (SYSDATE, 'DD-MON-RR HH24:MI:SS'),
                                        FALSE,
                                        p_master_org_id,                                   -- org id
                                        1,                                 --'Yes',  -- all org flag
                                        1,                           -- 'Yes', -- Validate Item Flag
                                        1,                            -- 'Yes', -- Process Item Flag
                                        2,                 -- 'No'   -- Delete Imported Records Flag
                                        0,                                         -- set Process ID
                                        2                            -- 'UPDATE' -- Transaction Type
                                         );

         p_req_id2 := v_ret;

         IF v_ret = 0
         THEN                                                               /* Item Import failed */
            raise_application_error (-20020, 'Error in Item Import Interface');
         ELSE
            COMMIT;                                                      /* Item Import succeeded */

            /* Exit out when the concurrent request for Item Import completes */
            LOOP
               call_status :=
                  fnd_concurrent.get_request_status (v_ret,
                                                     '',
                                                     '',
                                                     rphase,
                                                     rstatus,
                                                     dphase,
                                                     dstatus,
                                                     MESSAGE);

               IF    (dphase = 'COMPLETE' AND dstatus = 'NORMAL')
                  OR (dphase = 'COMPLETE' AND dstatus = 'ERROR')
                  OR (dphase = 'COMPLETE' AND dstatus = 'TERMINATED')
                  OR (dphase = 'COMPLETE' AND dstatus = 'WARNING')
               THEN
                  EXIT;
               END IF;
            END LOOP;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_INV_OPEN_INTERFACE is ' || SQLERRM);
   END ILINK_INV_OPEN_INTERFACE;


   PROCEDURE ILINK_POST_ITEM_INTERFACE (p_req_id1 IN NUMBER, p_req_id2 IN NUMBER)
   IS
      /* Define a Cursor to retreive errors from Item Interface table */

      CURSOR item_errors
      IS
           SELECT msie.error_message,
                  msii.process_flag,
                  msii.creation_date,
                  msii.item_number,
                  msii.organization_id,
                  msii.transaction_type
             FROM MTL_SYSTEM_ITEMS_INTERFACE msii, MTL_INTERFACE_ERRORS msie
            WHERE msii.set_process_id = 0 AND msii.transaction_id = msie.transaction_id(+)
         ORDER BY item_number;


      /* Define a Cursor to retreive errors from Item Categories Interface table */

      CURSOR category_errors
      IS
           SELECT msie.error_message,
                  mici.process_flag,
                  mici.item_number,
                  mici.creation_date,
                  mici.organization_id
             FROM MTL_ITEM_CATEGORIES_INTERFACE mici, MTL_INTERFACE_ERRORS msie
            WHERE mici.set_process_id = 0 AND mici.transaction_id = msie.transaction_id(+)
         ORDER BY item_number;
   BEGIN
      /* Fetch record status from Item interface and update corresponding records in temp table */

      FOR c_item_errors IN item_errors
      LOOP
         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET error_message = error_message || ' ' || c_item_errors.error_message,
                record_status =
                   DECODE (c_item_errors.process_flag,
                           7, 'Succeeded',
                           NULL, 'Succeeded',
                           'Error'),
                processed_date = SYSDATE
          WHERE     organization_id = c_item_errors.organization_id
                AND item_number = c_item_errors.item_number
                AND -- transaction_type = c_item_errors.transaction_type and
                    record_status = 'Validated'; --and nvl(validation_date,creation_date) = c_item_errors.creation_date;
      END LOOP;

      /* Fetch record status from Item Categories interface and update corresponding records in temp table */

      FOR c_cat_errors IN category_errors
      LOOP
         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET error_message = error_message || ' ' || c_cat_errors.error_message,
                record_status =
                   DECODE (c_cat_errors.process_flag,
                           7, 'Succeeded',
                           NULL, 'Succeeded',
                           'Error'),
                processed_date = SYSDATE
          WHERE     organization_id = c_cat_errors.organization_id
                AND item_number = c_cat_errors.item_number
                AND record_status = 'Validated'; -- and nvl(validation_date,creation_date) = c_cat_errors.creation_date;
      END LOOP;

      /* Delete records from Interface tables */

      DELETE FROM MTL_INTERFACE_ERRORS mie
            WHERE EXISTS
                     (SELECT 'x'
                        FROM MTL_SYSTEM_ITEMS_INTERFACE msi
                       WHERE msi.transaction_id = mie.transaction_id AND msi.set_process_id = 0)
                  OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_INTERFACE_ERRORS mie
            WHERE EXISTS
                     (SELECT 'x'
                        FROM MTL_ITEM_CATEGORIES_INTERFACE mic
                       WHERE mic.transaction_id = mie.transaction_id AND mic.set_process_id = 0)
                  OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_SYSTEM_ITEMS_INTERFACE
            WHERE set_process_id = 0 OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_ITEM_REVISIONS_INTERFACE
            WHERE set_process_id = 0 OR request_id IN (p_req_id1, p_req_id2);

      DELETE FROM MTL_ITEM_CATEGORIES_INTERFACE
            WHERE set_process_id = 0 OR request_id IN (p_req_id1, p_req_id2);

      /* Update Successfully processed records in temp table */

      UPDATE ILINK_MTL_ITEMS_INT_TEMP
         SET transfer_to_oracle = DECODE (transfer_to_oracle, NULL, 'YES', transfer_to_oracle)
       WHERE process_flag = 'Y' AND record_status = 'Succeeded';
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_POST_ITEM_INTERFACE is ' || SQLERRM);
   END ILINK_POST_ITEM_INTERFACE;


   PROCEDURE ILINK_UPDATE_ITEM_TEMPLATES
   IS
      CURSOR get_templ_items
      IS
           SELECT eco_number,
                  record_id,
                  item_number,
                  description,
                  item_status_code_agile,
                  primary_uom_code,
                  lot_control_code,
                  serial_control_code,
                  shelf_life_control,
                  shelf_life_days,
                  inv_category_code,
                  attribute3 tax_code_dff,
                  sales_account_id,
                  cost_of_sales_acct_id,
                  expense_account_id,
                  template_name,
                  make_buy_template,
                  obsolete_template,
                  attribute2 fast_pack,
                  po_category_code,
                  enable_service_billing,
                  billing_type,
                  service_request,
                  serv_track_install_base,
                  track_install_base,
                  enable_contract_cover,
                  service_returnable,
                  service_category_code,
                  item_type,
                  shipping_qty_box,
                  taxable_flag,
                  po_tax_code,
                  auto_lot_alpha_prefix,
                  start_auto_lot_number,
                  auto_serial_prefix,
                  start_serial_number,
                  eco_orig_date,
                  eco_rel_date,
                  organization_code,
                  organization_id,
                  creation_date,
                  validation_date,
                  inventory_item_id
             FROM ILINK_MTL_ITEMS_INT_TEMP
            WHERE record_status = 'Succeeded' AND transaction_type = 'CREATE'
         ORDER BY eco_rel_date, eco_number, item_number;
   BEGIN
      /* Insert records into interface table to update source type and source org for an item */

      FOR c_valid_items IN get_templ_items
      LOOP
         /* Insert item Record into Item Interface table as CREATE (New Item) */

         INSERT INTO MTL_SYSTEM_ITEMS_INTERFACE (transaction_type,
                                                 item_number,
                                                 inventory_item_status_code,
                                                 lot_control_code,
                                                 shelf_life_code,
                                                 serial_number_control_code,
                                                 shelf_life_days,
                                                 attribute_category,
                                                 attribute14,
                                                 sales_account,
                                                 cost_of_sales_account,
                                                 expense_account,
                                                 template_name,
                                                 attribute5,
                                                 -- serv_billing_enabled_flag,	-- Commented out on 03/04/2016
                                                 -- material_billable_flag,	-- Commented out on 03/04/2016
                                                 -- serv_req_enabled_code,	-- Commented out on 03/04/2016
                                                 -- comms_nl_trackable_flag,	-- Commented out on 03/04/2016
                                                 -- serviceable_product_flag,	-- Commented out on 03/04/2016
                                                 -- recovered_part_disp_code,	-- Commented out on 03/04/2016
                                                 item_type,
                                                 taxable_flag,
                                                 purchasing_tax_code,
                                                 auto_lot_alpha_prefix,
                                                 start_auto_lot_number,
                                                 auto_serial_alpha_prefix,
                                                 start_auto_serial_number,
                                                 organization_code,
                                                 organization_id,
                                                 set_process_id,
                                                 created_by,
                                                 creation_date,
                                                 process_flag)
              VALUES (
                        'UPDATE',
                        c_valid_items.item_number,
                        c_valid_items.item_status_code_agile,
                        DECODE (UPPER (c_valid_items.lot_control_code),
                                'NO CONTROL', 1,
                                'FULL CONTROL', 2,
                                NULL),
                        DECODE (UPPER (c_valid_items.shelf_life_control),
                                'NO CONTROL', 1,
                                'SHELF LIFE DAYS', 2,
                                'USER-DEFINED', 4,
                                NULL),
                        DECODE (UPPER (c_valid_items.serial_control_code),
                                'NO CONTROL', 1,
                                'AT RECEIPT', 5,
                                'AT SALES ORDER ISSUE', 6,
                                'PREDEFINED', 2,
                                NULL),
                        DECODE (UPPER (c_valid_items.shelf_life_control),
                                'SHELF LIFE DAYS', c_valid_items.shelf_life_days,
                                NULL),
                        c_valid_items.organization_id,
                        c_valid_items.tax_code_dff,
                        c_valid_items.sales_account_id,
                        c_valid_items.cost_of_sales_acct_id,
                        c_valid_items.expense_account_id,
                        c_valid_items.make_buy_template,
                        c_valid_items.fast_pack,
                       /*  DECODE (UPPER (c_valid_items.enable_service_billing),	-- Commented out on 03/04/2016
                                'YES', 'Y',
                                'Y', 'Y',
                                'NO', 'N',
                                'N', 'N',
                                NULL),
                        DECODE (UPPER (c_valid_items.billing_type),
                                'MATERIAL', 'M',
                                'LABOR', 'L',
                                'EXPENSE', 'E',
                                NULL),
                        DECODE (UPPER (c_valid_items.service_request),
                                'ENABLED', 'E',
                                'INACTIVE', 'I',
                                'DISABLED', 'D',
                                NULL),
                        DECODE (UPPER (c_valid_items.track_install_base),
                                'YES', 'Y',
                                'Y', 'Y',
                                'NO', 'N',
                                'N', 'N',
                                NULL),
                        DECODE (UPPER (c_valid_items.enable_contract_cover),
                                'YES', 'Y',
                                'Y', 'Y',
                                'NO', 'N',
                                'N', 'N',
                                NULL),
                        DECODE (UPPER (c_valid_items.service_returnable),
                                'FAST RETURN', 'M',
                                'NO RETURN', 'N',
                                'SLOW RETURN', 'S',
                                NULL),			*/			-- End 03/04/2016
                        c_valid_items.item_type,
                        c_valid_items.taxable_flag,
                        c_valid_items.po_tax_code,
                        c_valid_items.auto_lot_alpha_prefix,
                        c_valid_items.start_auto_lot_number,
                        c_valid_items.auto_serial_prefix,
                        c_valid_items.start_serial_number,
                        c_valid_items.organization_code,
                        c_valid_items.organization_id,
                        1,
                        v_user_id,
                        SYSDATE,
                        1);

         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET record_status = 'Validated', -- transaction_type = 'UPDATE',
                                             attribute7 = 'CREATE'
          WHERE     record_id = c_valid_items.record_id
                AND eco_number = c_valid_items.eco_number
                AND item_number = c_valid_items.item_number
                AND organization_code = c_valid_items.organization_code;
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_ITEM_SOURCE_VALUES is ' || SQLERRM);
   END ILINK_UPDATE_ITEM_TEMPLATES;


   PROCEDURE ILINK_INV_OPEN_INTERFACE1 (p_master_org_id IN NUMBER, p_req_id OUT NUMBER)
   IS
      /* Define a Cursor to verify if records exist in the Interface table */

      CURSOR get_intf_table_count (p_transaction_type IN VARCHAR2)
      IS
         SELECT COUNT (*)
           FROM MTL_SYSTEM_ITEMS_INTERFACE
          WHERE transaction_type = p_transaction_type AND process_flag = 1 AND set_process_id = 1;


      v_ret             NUMBER;
      call_status       BOOLEAN;
      rphase            VARCHAR2 (30);
      rstatus           VARCHAR2 (30);
      dphase            VARCHAR2 (30);
      dstatus           VARCHAR2 (30);
      MESSAGE           VARCHAR2 (240);
      v_count_records   NUMBER;
      v_org_id          NUMBER;
   BEGIN
      v_count_records := 0;


      /* Determine if records with transaction type "UPDATE" exist in the Item Interface table */

      OPEN get_intf_table_count ('UPDATE');

      FETCH get_intf_table_count INTO v_count_records;

      CLOSE get_intf_table_count;

      IF v_count_Records > 0
      THEN
         /* Records with transaction type "UPDATE" exist in the Interface table so call Item Import in UPDATE mode */

         v_ret :=
            fnd_request.submit_request ('INV',
                                        'INCOIN',
                                        'Import Items',
                                        TO_CHAR (SYSDATE, 'DD-MON-RR HH24:MI:SS'),
                                        FALSE,
                                        p_master_org_id,                                   -- org id
                                        1,                                 --'Yes',  -- all org flag
                                        1,                           -- 'Yes', -- Validate Item Flag
                                        1,                            -- 'Yes', -- Process Item Flag
                                        2,                 -- 'No'   -- Delete Imported Records Flag
                                        1,                                         -- set Process ID
                                        2                            -- 'UPDATE' -- Transaction Type
                                         );

         p_req_id := v_ret;

         IF v_ret = 0
         THEN                                                               /* Item Import failed */
            raise_application_error (-20020, 'Error in Item Import Interface');
         ELSE
            COMMIT;                                                      /* Item Import succeeded */

            /* Exit out when the concurrent request for Item Import completes */
            LOOP
               call_status :=
                  fnd_concurrent.get_request_status (v_ret,
                                                     '',
                                                     '',
                                                     rphase,
                                                     rstatus,
                                                     dphase,
                                                     dstatus,
                                                     MESSAGE);

               IF    (dphase = 'COMPLETE' AND dstatus = 'NORMAL')
                  OR (dphase = 'COMPLETE' AND dstatus = 'ERROR')
                  OR (dphase = 'COMPLETE' AND dstatus = 'TERMINATED')
                  OR (dphase = 'COMPLETE' AND dstatus = 'WARNING')
               THEN
                  EXIT;
               END IF;
            END LOOP;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_INV_OPEN_INTERFACE is ' || SQLERRM);
   END ILINK_INV_OPEN_INTERFACE1;


   PROCEDURE ILINK_POST_ITEM_INTERFACE1 (p_req_id IN NUMBER)
   IS
      /* Define a Cursor to retreive errors from Item Interface table */

      CURSOR item_errors
      IS
           SELECT msie.error_message,
                  msii.process_flag,
                  msii.creation_date,
                  msii.item_number,
                  msii.organization_id,
                  msii.transaction_type
             FROM MTL_SYSTEM_ITEMS_INTERFACE msii, MTL_INTERFACE_ERRORS msie
            WHERE msii.set_process_id = 1 AND msii.transaction_id = msie.transaction_id(+)
         ORDER BY item_number;
   BEGIN
      /* Fetch record status from Item interface and update corresponding records in temp table */

      FOR c_item_errors IN item_errors
      LOOP
         UPDATE ILINK_MTL_ITEMS_INT_TEMP
            SET error_message = error_message || ' ' || c_item_errors.error_message,
                record_status =
                   DECODE (c_item_errors.process_flag,
                           7, 'Succeeded',
                           NULL, 'Succeeded',
                           'Error'),
                processed_date = SYSDATE
          WHERE     organization_id = c_item_errors.organization_id
                AND item_number = c_item_errors.item_number
                AND -- transaction_type = c_item_errors.transaction_type and
                    record_status = 'Validated'; --and nvl(validation_date,creation_date) = c_item_errors.creation_date;
      END LOOP;


      /* Delete records from Interface tables */

      DELETE FROM MTL_INTERFACE_ERRORS mie
            WHERE EXISTS
                     (SELECT 'x'
                        FROM MTL_SYSTEM_ITEMS_INTERFACE msi
                       WHERE msi.transaction_id = mie.transaction_id AND msi.set_process_id = 1)
                  OR request_id IN (p_req_id);

      DELETE FROM MTL_SYSTEM_ITEMS_INTERFACE
            WHERE set_process_id = 1 OR request_id IN (p_req_id);

      /* Update Successfully processed records in temp table */

      UPDATE ILINK_MTL_ITEMS_INT_TEMP
         SET transfer_to_oracle = DECODE (transfer_to_oracle, NULL, 'YES', transfer_to_oracle)
       WHERE process_flag = 'Y' AND record_status = 'Succeeded';
   EXCEPTION
      WHEN OTHERS
      THEN
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Error in Procedure ILINK_POST_ITEM_INTERFACE is ' || SQLERRM);
   END ILINK_POST_ITEM_INTERFACE1;


   PROCEDURE ILINK_POST_ITEM_LOAD (p_master_org_id IN NUMBER, p_master_org_code IN VARCHAR2)
   IS
      /* Define a cursor to fetch items with ship qty to process uom intra class conversion */

      CURSOR get_ship_qty_items
      IS
           SELECT a.eco_number,
                  a.item_number,
                  a.eco_rel_date,
                  a.shipping_qty_box,
                  b.inventory_item_id
             FROM ILINK_MTL_ITEMS_INT_TEMP a, ILINK_MTL_SYSTEM_ITEMS_VIEW b
            WHERE     a.record_status = 'Succeeded'
                  AND NVL (a.shipping_qty_box, 0) != 0
                  AND b.organization_id = p_master_org_id
                  AND b.item_number = a.item_number
         ORDER BY eco_rel_date, eco_number, item_number;


      /* Define a cursor to fetch the current intra-class UOM for an item */

      CURSOR get_uom_conv (p_item_id IN NUMBER)
      IS
         SELECT conversion_rate
           FROM MTL_UOM_CONVERSIONS
          WHERE inventory_item_id = p_item_id AND UNIT_OF_MEASURE = 'Case';

      /* Define a cursor to fetch items to process item costs and price lists */

      CURSOR get_item_costs
      IS
           SELECT a.eco_number,
                  a.item_number,
                  a.eco_rel_date,
                  a.agile_item_cost,
                  a.item_type,
                  a.erp_product_type,
                  a.erp_product_sub_type,
                  a.organization_code,
                  a.organization_id,
                  b.inventory_item_id
             FROM ILINK_MTL_ITEMS_INT_TEMP a, ILINK_MTL_SYSTEM_ITEMS_VIEW b, ILINK_DATA_XREF c
            WHERE     a.record_status = 'Succeeded'
                  AND -- nvl(a.item_cost,0) != 0 and
                      b.organization_id = a.organization_id
                  AND b.item_number = a.item_number
                  AND c.data_input1 = 'Change Type For Item Cost/Price'
                  AND c.data_output1 = a.attribute4
         ORDER BY a.eco_rel_date, a.eco_number, a.item_number;

      /* Define a Cursor to verify if records exist in the Interface table */

      CURSOR get_intf_count
      IS
           SELECT COUNT (*), cost_type, GROUP_ID                     -- Added group_id on 03/05/2014
             FROM CST_ITEM_CST_DTLS_INTERFACE
            WHERE process_flag = 1 AND created_by = v_user_id AND GROUP_ID IS NOT NULL -- Modified from 0 to NOT NULL on 03/05/2014
         GROUP BY cost_type, GROUP_ID;                               -- Added group_id on 03/05/2014


      /* Declare a cursor to fetch any errors from the costing interface tables */

      CURSOR cost_errors
      IS
           SELECT DISTINCT cic.ERROR_CODE,
                           cic.error_explanation,
                           cic.cost_element,
                           cic.resource_code,
                           cic.inventory_item_id,
                           cic.organization_id,
                           msi.item_number
             FROM CST_ITEM_CST_DTLS_INTERFACE cic, ILINK_MTL_SYSTEM_ITEMS_VIEW msi
            WHERE     cic.GROUP_ID = 0
                  AND cic.inventory_item_id = msi.inventory_item_id
                  AND cic.organization_id = msi.organization_id
                  AND cic.process_flag != 1
                  AND cic.ERROR_CODE IS NOT NULL
         ORDER BY inventory_item_id;


      v_ora_uom_rate                NUMBER;
      v_cost_type_id                NUMBER;
      v_ora_item_cost               NUMBER;
      l_cost_rec                    xxha_ilink_ext.t_item_cost;
      l_price_rec                   xxha_ilink_ext.t_item_price;
      v_intf_count                  NUMBER;
      v_ret                         NUMBER;
      call_status                   BOOLEAN;
      rphase                        VARCHAR2 (30);
      rstatus                       VARCHAR2 (30);
      dphase                        VARCHAR2 (30);
      dstatus                       VARCHAR2 (30);
      MESSAGE                       VARCHAR2 (240);


      gpr_return_status             VARCHAR2 (1) := NULL;
      gpr_msg_count                 NUMBER := 0;
      gpr_msg_data                  VARCHAR2 (2000) := NULL;

      -- START OF MODIFIED CODE - 04/03/2014
      /*
      gpr_price_list_rec         QP_PRICE_LIST_PUB.Price_List_Rec_Type;
      gpr_price_list_val_rec     QP_PRICE_LIST_PUB.Price_List_Val_Rec_Type;
      gpr_price_list_line_tbl     QP_PRICE_LIST_PUB.Price_List_Line_Tbl_Type;
      gpr_price_list_line_val_tbl     QP_PRICE_LIST_PUB.Price_List_Line_Val_Tbl_Type;
      gpr_qualifiers_tbl        QP_Qualifier_Rules_Pub.Qualifiers_Tbl_Type;
      gpr_qualifiers_val_tbl     QP_Qualifier_Rules_Pub.Qualifiers_Val_Tbl_Type;
      gpr_pricing_attr_tbl         QP_PRICE_LIST_PUB.Pricing_Attr_Tbl_Type;
      gpr_pricing_attr_val_tbl     QP_PRICE_LIST_PUB.Pricing_Attr_Val_Tbl_Type;
      ppr_price_list_rec         QP_PRICE_LIST_PUB.Price_List_Rec_Type;
      ppr_price_list_val_rec     QP_PRICE_LIST_PUB.Price_List_Val_Rec_Type;
      ppr_price_list_line_tbl     QP_PRICE_LIST_PUB.Price_List_Line_Tbl_Type;
      ppr_price_list_line_val_tbl     QP_PRICE_LIST_PUB.Price_List_Line_Val_Tbl_Type;
      ppr_qualifiers_tbl         QP_Qualifier_Rules_Pub.Qualifiers_Tbl_Type;
      ppr_qualifiers_val_tbl     QP_Qualifier_Rules_Pub.Qualifiers_Val_Tbl_Type;
      ppr_pricing_attr_tbl         QP_PRICE_LIST_PUB.Pricing_Attr_Tbl_Type;
      ppr_pricing_attr_val_tbl     QP_PRICE_LIST_PUB.Pricing_Attr_Val_Tbl_Type;
      */

      GPR_PRICE_LIST_REC            QP_PRICE_LIST_PUB.PRICE_LIST_REC_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_REC;
      GPR_PRICE_LIST_VAL_REC        QP_PRICE_LIST_PUB.PRICE_LIST_VAL_REC_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_VAL_REC;
      GPR_PRICE_LIST_LINE_TBL       QP_PRICE_LIST_PUB.PRICE_LIST_LINE_TBL_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_TBL;
      GPR_PRICE_LIST_LINE_VAL_TBL   QP_PRICE_LIST_PUB.PRICE_LIST_LINE_VAL_TBL_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
      gpr_qualifiers_tbl            QP_Qualifier_Rules_Pub.Qualifiers_Tbl_Type
                                       := Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_TBL;
      GPR_QUALIFIERS_VAL_TBL        QP_QUALIFIER_RULES_PUB.QUALIFIERS_VAL_TBL_TYPE
                                       := QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_VAL_TBL;
      GPR_PRICING_ATTR_TBL          QP_PRICE_LIST_PUB.PRICING_ATTR_TBL_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_TBL;
      gpr_pricing_attr_val_tbl      QP_PRICE_LIST_PUB.Pricing_Attr_Val_Tbl_Type
                                       := QP_Price_List_PUB.G_MISS_PRICING_ATTR_VAL_TBL;

      PPR_PRICE_LIST_REC            QP_PRICE_LIST_PUB.PRICE_LIST_REC_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_REC;
      ppr_price_list_val_rec        QP_PRICE_LIST_PUB.Price_List_Val_Rec_Type
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_VAL_REC;
      PPR_PRICE_LIST_LINE_TBL       QP_PRICE_LIST_PUB.PRICE_LIST_LINE_TBL_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_TBL;
      ppr_price_list_line_val_tbl   QP_PRICE_LIST_PUB.Price_List_Line_Val_Tbl_Type
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
      PPR_QUALIFIERS_TBL            QP_QUALIFIER_RULES_PUB.QUALIFIERS_TBL_TYPE
                                       := QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_TBL;
      PPR_QUALIFIERS_VAL_TBL        QP_QUALIFIER_RULES_PUB.QUALIFIERS_VAL_TBL_TYPE
                                       := QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_VAL_TBL;
      PPR_PRICING_ATTR_TBL          QP_PRICE_LIST_PUB.PRICING_ATTR_TBL_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_TBL;
      PPR_PRICING_ATTR_VAL_TBL      QP_PRICE_LIST_PUB.PRICING_ATTR_VAL_TBL_TYPE
                                       := QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_VAL_TBL;
      -- END OF MODIFIED CODE - 04/03/2014

      K                             NUMBER := 0;
      j                             NUMBER := 0;

      v_line_id                     NUMBER;
      v_attr_id                     NUMBER;

      v_precedence                  NUMBER;
      v_start_date                  DATE;
   BEGIN
      /* Process Intra Class UOM Conversions */

      FOR c1 IN get_ship_qty_items
      LOOP
         OPEN get_uom_conv (c1.inventory_item_id);

         FETCH get_uom_conv INTO v_ora_uom_rate;

         IF get_uom_conv%NOTFOUND
         THEN
            INSERT INTO MTL_UOM_CONVERSIONS (inventory_item_id,
                                             unit_of_measure,
                                             uom_code,
                                             uom_class,
                                             last_update_date,
                                             last_updated_by,
                                             creation_date,
                                             created_by,
                                             last_update_login,
                                             conversion_rate,
                                             default_conversion_flag)
                 VALUES (c1.inventory_item_id,
                         'Case',
                         'Ca',
                         'Quantities',
                         SYSDATE,
                         v_user_id,
                         SYSDATE,
                         v_user_id,
                         -1,
                         c1.shipping_qty_box,
                         'N');
         END IF;

         CLOSE get_uom_conv;
      END LOOP;


      /* Process Item Costs */

      FOR c1 IN get_item_costs
      LOOP
         XXHA_ILINK_EXT.GET_INFO (P_ORGANIZATION_CODE        => c1.organization_code,
                                  P_ITEM_NUMBER              => c1.item_number,
                                  P_AGILE_COST               => c1.agile_item_cost,
                                  P_ITEM_TYPE                => ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                                                                  'Make/Buy Item Type',
                                                                  c1.item_type,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL),
                                  P_ITEM_CATEGORY_SEGMENT2   => c1.erp_product_type,
                                  P_ITEM_CATEGORY_SEGMENT3   => c1.erp_product_sub_type,
                                  P_ITEM_COST_TAB            => l_cost_rec,
                                  p_item_price_tab           => l_price_rec);

         FOR i IN 1 .. l_cost_rec.COUNT
         LOOP
            IF     NVL (l_cost_rec (i).return_status, 2) IN (0)
               AND l_cost_rec (i).cost_type IS NOT NULL
               AND l_cost_rec (i).cost IS NOT NULL
            THEN
               /* Insert records into cost interface table */

               INSERT INTO CST_ITEM_CST_DTLS_INTERFACE (cost_type,
                                                        cost_type_id,
                                                        inventory_item_id,
                                                        organization_id,
                                                        process_flag,
                                                        cost_element,
                                                        cost_element_id,
                                                        resource_code,
                                                        usage_rate_or_amount,
                                                        basis_type,
                                                        inventory_asset_flag,
                                                        shrinkage_rate,
                                                        lot_size,
                                                        based_on_rollup_flag,
                                                        created_by,
                                                        creation_date,
                                                        GROUP_ID)
                    VALUES (l_cost_rec (i).cost_type,
                            l_cost_rec (i).cost_type_id,
                            c1.inventory_item_id,
                            c1.organization_id,
                            1,
                            'Material',
                            NULL,                                              -- v_cost_element_id,
                            'Material',
                            l_cost_rec (i).cost,
                            DECODE (l_cost_rec (i).basis_type,  'Y', 1,  'N', 4,  NULL),
                            DECODE (l_cost_rec (i).Inventory_Asset,  'Y', 1,  'N', 2,  NULL),
                            l_cost_rec (i).Shrinkage_Rate,
                            l_cost_rec (i).Lot_Size,
                            DECODE (l_cost_rec (i).Based_on_Rollup,  'Y', 1,  'N', 2,  NULL),
                            v_user_id,
                            SYSDATE,
                            l_cost_rec (i).cost_type_id);    -- 0);        -- Modified on 03/05/2014
            END IF;
         END LOOP;                                                       -- i in 1..l_cost_rec.count
      END LOOP;                                                              -- c1 in get_item_costs

      /* Invoke Import Costs Concurrent Program */

      FOR c_cost_rec IN get_intf_count
      LOOP
         /* Records in the Interface table so call Item cost Import */

         v_ret :=
            fnd_request.submit_request ('BOM',
                                        'CSTPCIMP',
                                        'Cost Import Process',
                                        TO_CHAR (SYSDATE, 'DD-MON-RR HH24:MI:SS'),
                                        FALSE,
                                        4, -- Import Cost Option: Import item costs,resource rates, and overhead rates
                                        2,                    -- Remove and replace cost information
                                        1,                                     -- Group Id: Specific
                                        1,                                               -- Group ID
                                        c_cost_rec.GROUP_ID, --0,    -- Group ID: From cursor    -- Modified from 0 on 03/05/2014
                                        c_cost_rec.cost_type,              -- Cost Type to Import to
                                        1                             -- Delete Successful rows: Yes
                                         );

         IF v_ret = 0
         THEN                                                          /* Item Cost Import failed */
            raise_application_error (-20020, 'Error in Item Cost Import Interface');
         ELSE
            COMMIT;                                                      /* Item Import succeeded */

            /* Exit out when the concurrent request for Item Cost Import completes */
            LOOP
               call_status :=
                  fnd_concurrent.get_request_status (v_ret,
                                                     '',
                                                     '',
                                                     rphase,
                                                     rstatus,
                                                     dphase,
                                                     dstatus,
                                                     MESSAGE);

               IF    (dphase = 'COMPLETE' AND dstatus = 'NORMAL')
                  OR (dphase = 'COMPLETE' AND dstatus = 'ERROR')
                  OR (dphase = 'COMPLETE' AND dstatus = 'TERMINATED')
                  OR (dphase = 'COMPLETE' AND dstatus = 'WARNING')
               THEN
                  EXIT;
               END IF;
            END LOOP;
         END IF;

         /* Extract errors from the costing interface tables and update iLink temp tables */

         FOR c_cost_errors IN cost_errors
         LOOP
            UPDATE ILINK_MTL_ITEMS_INT_TEMP
               SET warning_message =
                      SUBSTR (
                            warning_message
                         || ' Warning:Cost Import Failed with error '
                         || c_cost_errors.ERROR_CODE,
                         1,
                         3900)
             WHERE item_number = c_cost_errors.item_number
                   AND organization_id = c_cost_errors.organization_id;
         END LOOP;

         /* Delete records from the costing interface tables */

         DELETE FROM CST_ITEM_CST_DTLS_INTERFACE
               WHERE request_id = v_ret;
      END LOOP;                                                                        -- c_cost_rec


      /* Process Item Price Lists */

      SELECT TRUNC (SYSDATE) INTO v_start_date FROM DUAL;                     -- Added on 03/06/2014

      FOR c1 IN get_item_costs
      LOOP
         -- START OF MODIFIED CODE - 04/03/2014
         IF L_PRICE_REC.COUNT > 0
         THEN
            L_PRICE_REC.DELETE;
         END IF;

         -- END OF MODIFIED CODE - 04/03/2014

         XXHA_ILINK_EXT.GET_INFO (P_ORGANIZATION_CODE        => c1.organization_code,
                                  P_ITEM_NUMBER              => c1.item_number,
                                  P_AGILE_COST               => c1.agile_item_cost,
                                  P_ITEM_TYPE                => ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF (
                                                                  'Make/Buy Item Type',
                                                                  c1.item_type,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL),
                                  P_ITEM_CATEGORY_SEGMENT2   => c1.erp_product_type,
                                  P_ITEM_CATEGORY_SEGMENT3   => c1.erp_product_sub_type,
                                  P_ITEM_COST_TAB            => l_cost_rec,
                                  p_item_price_tab           => l_price_rec);

         -- START OF MODIFIED CODE - 04/03/2014
         --  FND_FILE.PUT_LINE(FND_FILE.LOG,'-- ITEM ---'||C1.ITEM_NUMBER||'--- ORG ---'||C1.ORGANIZATION_CODE||'--- COUNT ---'||TO_CHAR(L_PRICE_REC.COUNT));
         --  FOR jjj IN 1..L_PRICE_REC.COUNT LOOP
         --      FND_FILE.PUT_LINE(FND_FILE.LOG,'-- List_header_id ---'||to_char(l_price_rec(jjj).Price_List_id)||'--- item ---'||to_char(c1.inventory_item_id));
         --  end loop;

         GPR_PRICE_LIST_REC := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_REC;
         GPR_PRICE_LIST_VAL_REC := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_VAL_REC;
         GPR_PRICE_LIST_LINE_TBL := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_TBL;
         GPR_PRICE_LIST_LINE_VAL_TBL := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
         gpr_qualifiers_tbl := Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_TBL;
         GPR_QUALIFIERS_VAL_TBL := QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_VAL_TBL;
         GPR_PRICING_ATTR_TBL := QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_TBL;
         gpr_pricing_attr_val_tbl := QP_Price_List_PUB.G_MISS_PRICING_ATTR_VAL_TBL;

         PPR_PRICE_LIST_REC := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_REC;
         ppr_price_list_val_rec := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_VAL_REC;
         PPR_PRICE_LIST_LINE_TBL := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_TBL;
         ppr_price_list_line_val_tbl := QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
         PPR_QUALIFIERS_TBL := QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_TBL;
         PPR_QUALIFIERS_VAL_TBL := QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_VAL_TBL;
         PPR_PRICING_ATTR_TBL := QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_TBL;
         PPR_PRICING_ATTR_VAL_TBL := QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_VAL_TBL;
         j := 0;

         -- END OF MODIFIED CODE - 04/03/2014

         FOR i IN 1 .. l_price_rec.COUNT
         LOOP
            IF     NVL (l_price_rec (i).return_status, 0) IN (0)
               AND l_price_rec (i).Price_List_Name IS NOT NULL
               AND l_price_rec (i).Price IS NOT NULL
            THEN                    -- Modified nvl value in return status from 2 to 0 on 03/06/2014
               -- START OF MODIFIED CODE - 04/03/2014
               --   Begin
               -- END OF MODIFIED CODE - 04/03/2014

               gpr_return_status := NULL;

               gpr_msg_count := 0;

               SELECT QP_LIST_LINES_S.NEXTVAL INTO v_line_id FROM DUAL;

               SELECT QP_LINE_ATTR_S.NEXTVAL INTO v_attr_id FROM DUAL;

               -- START OF MODIFIED CODE - 04/03/2014
               J := j + 1; -- Commented out and replaced j with i in below variable assignments on 03/06/2014
               -- END OF MODIFIED CODE - 04/03/2014

               GPR_PRICE_LIST_LINE_TBL (I).LIST_HEADER_ID := L_PRICE_REC (I).PRICE_LIST_ID;
               GPR_PRICE_LIST_LINE_TBL (I).LIST_LINE_ID := FND_API.G_MISS_NUM;
               GPR_PRICE_LIST_LINE_TBL (I).LIST_LINE_TYPE_CODE := 'PLL';
               GPR_PRICE_LIST_LINE_TBL (I).OPERATION := QP_GLOBALS.G_OPR_CREATE;
               GPR_PRICE_LIST_LINE_TBL (I).OPERAND := L_PRICE_REC (I).PRICE;
               gpr_price_list_line_tbl (I).arithmetic_operator := 'UNIT_PRICE';
               GPR_PRICE_LIST_LINE_TBL (I).START_DATE_ACTIVE := V_START_DATE; -- Modified from NULL to v_start_date on 03/06/2014
               gpr_price_list_line_tbl (I).PRODUCT_PRECEDENCE :=
                  TO_NUMBER (ILINK_XML_INTERFACE_PKG.ILINK_DATA_XREF ('Default PLL Precedence',
                                                                      NULL,
                                                                      NULL,
                                                                      NULL,
                                                                      NULL)); -- v_precedence;    -- Modified from NULL to mapping record value on 03/06/2014

               -- START OF MODIFIED CODE - 04/03/2014
               gpr_pricing_attr_tbl (I).list_header_id := L_PRICE_REC (I).PRICE_LIST_ID; -- Bruce M.
               -- END OF MODIFIED CODE - 04/03/2014

               GPR_PRICING_ATTR_TBL (I).PRICING_ATTRIBUTE_ID := FND_API.G_MISS_NUM;
               GPR_PRICING_ATTR_TBL (I).LIST_LINE_ID := FND_API.G_MISS_NUM;
               GPR_PRICING_ATTR_TBL (I).PRODUCT_ATTRIBUTE_CONTEXT := 'ITEM';
               gpr_pricing_attr_tbl (I).PRODUCT_ATTRIBUTE := 'PRICING_ATTRIBUTE1';
               GPR_PRICING_ATTR_TBL (I).PRODUCT_ATTR_VALUE := TO_CHAR (C1.INVENTORY_ITEM_ID);
               GPR_PRICING_ATTR_TBL (I).PRODUCT_UOM_CODE := L_PRICE_REC (I).UOM;
               GPR_PRICING_ATTR_TBL (I).EXCLUDER_FLAG := 'N';
               GPR_PRICING_ATTR_TBL (I).ATTRIBUTE_GROUPING_NO := 1;
               gpr_pricing_attr_tbl (I).PRICE_LIST_LINE_INDEX := I;
               GPR_PRICING_ATTR_TBL (I).OPERATION := QP_GLOBALS.G_OPR_CREATE;
            -- START OF MODIFIED CODE - 04/03/2014
            END IF;
         END LOOP;                                                           -- 1..l_price_rec.count

         IF J > 0
         THEN
            BEGIN
               FND_MSG_PUB.INITIALIZE;
               Oe_Msg_Pub.initialize;
               -- END OF MODIFIED CODE - 04/03/2014

               QP_PRICE_LIST_PUB.Process_Price_List (
                  p_api_version_number        => 1.0,
                  p_init_msg_list             => FND_API.G_FALSE,
                  p_return_values             => FND_API.G_FALSE,
                  p_commit                    => FND_API.G_FALSE,
                  x_return_status             => gpr_return_status,
                  x_msg_count                 => gpr_msg_count,
                  x_msg_data                  => gpr_msg_data,
                  p_PRICE_LIST_rec            => gpr_price_list_rec,
                  p_PRICE_LIST_LINE_tbl       => gpr_price_list_line_tbl,
                  p_PRICING_ATTR_tbl          => gpr_pricing_attr_tbl-- START OF MODIFIED CODE - 04/03/2014
                                                                     -- Removed the below on 9/25/2014
                                                                     /* , X_PRICE_LIST_REC=> GPR_PRICE_LIST_REC
                                                                     , x_PRICE_LIST_val_rec=> gpr_price_list_val_rec
                                                                     , x_PRICE_LIST_LINE_tbl=> gpr_price_list_line_tbl
                                                                     , x_PRICE_LIST_LINE_val_tbl=> gpr_price_list_line_val_tbl
                                                                     , X_QUALIFIERS_TBL=> GPR_QUALIFIERS_TBL
                                                                     , x_QUALIFIERS_val_tbl=> gpr_qualifiers_val_tbl
                                                                     , x_PRICING_ATTR_tbl=> gpr_pricing_attr_tbl
                                                                     , x_PRICING_ATTR_val_tbl=> gpr_pricing_attr_val_tbl */
                                                                     -- End 9/25/2014
                                                                     -- Added the below on 9/25/2014
                  ,
                  x_PRICE_LIST_rec            => ppr_price_list_rec,
                  x_PRICE_LIST_val_rec        => ppr_price_list_val_rec,
                  x_PRICE_LIST_LINE_tbl       => ppr_price_list_line_tbl,
                  x_PRICE_LIST_LINE_val_tbl   => ppr_price_list_line_val_tbl,
                  x_QUALIFIERS_tbl            => ppr_qualifiers_tbl,
                  x_QUALIFIERS_val_tbl        => ppr_qualifiers_val_tbl,
                  x_PRICING_ATTR_tbl          => ppr_pricing_attr_tbl,
                  x_PRICING_ATTR_val_tbl      => ppr_pricing_attr_val_tbl           -- End 9/25/2014
                                                                         -- END OF MODIFIED CODE - 04/03/2014
                  );

               IF gpr_return_status <> FND_API.G_RET_STS_SUCCESS
               THEN
                  -- Return (0);    --    Failure
                  RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
               ELSE
                  -- Return (1);    --    Success
                  COMMIT;
               END IF;
            EXCEPTION
               WHEN FND_API.G_EXC_ERROR
               THEN
                  gpr_return_status := FND_API.G_RET_STS_ERROR;
                  -- START OF MODIFIED CODE - 04/03/2014
                  FND_FILE.PUT_LINE (
                     FND_FILE.LOG,
                        'Error in Procedure ILINK_PRICE_LIST_LINES for Item ID '
                     || TO_CHAR (c1.inventory_item_id)
                     || ' is ');
                  -- END OF MODIFIED CODE - 04/03/2014
                  FND_FILE.PUT_LINE (FND_FILE.LOG, '--------------------------------------------');
                  FND_FILE.PUT_LINE (FND_FILE.LOG, gpr_msg_data);

                  ROLLBACK;
               WHEN FND_API.G_EXC_UNEXPECTED_ERROR
               THEN
                  gpr_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
                  FND_FILE.PUT_LINE (FND_FILE.LOG,
                                     'Error in Procedure ILINK_PRICE_LIST_LINES is as follows');
                  FND_FILE.PUT_LINE (FND_FILE.LOG, '--------------------------------------------');
                  FND_FILE.PUT_LINE (FND_FILE.LOG, ' message count is : ' || gpr_msg_count);

                  FOR k IN 1 .. gpr_msg_count
                  LOOP
                     gpr_msg_data := oe_msg_pub.get (p_msg_index => k, p_encoded => 'F');
                     FND_FILE.PUT_LINE (FND_FILE.LOG,
                                        'error message ' || k || 'is: ' || gpr_msg_data);
                  END LOOP;

                  ROLLBACK;
               WHEN OTHERS
               THEN
                  gpr_return_status := FND_API.G_RET_STS_UNEXP_ERROR;
                  FND_FILE.PUT_LINE (FND_FILE.LOG,
                                     'Error in Procedure ILINK_PRICE_LIST_LINES is as follows');
                  FND_FILE.PUT_LINE (FND_FILE.LOG, '--------------------------------------------');
                  FND_FILE.PUT_LINE (FND_FILE.LOG, gpr_msg_data);

                  -- START OF MODIFIED CODE - 04/03/2014
                  --          DECLARE
                  --            V_SQLERRM VARCHAR2(1000);
                  --          BEGIN
                  --            V_SQLERRM := SQLERRM;
                  --                FND_FILE.PUT_LINE(FND_FILE.LOG,V_SQLERRM);
                  --          end;
                  -- END OF MODIFIED CODE - 04/03/2014

                  ROLLBACK;
            END;
         END IF;
      -- START OF MODIFIED CODE - 04/03/2014
      --End Loop;    -- 1..l_price_rec.count
      -- END OF MODIFIED CODE - 04/03/2014

      END LOOP;                                                                    -- get_item_costs
   END ILINK_POST_ITEM_LOAD;
END ILINK_ITEM_INTERFACE_PKG;