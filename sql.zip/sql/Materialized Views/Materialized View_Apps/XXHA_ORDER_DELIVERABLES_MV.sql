--------------------------------------------------------
--  File created - Thursday-December-04-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Materialized View XXHA_ORDER_DELIVERABLES_MV
--------------------------------------------------------

  CREATE MATERIALIZED VIEW "APPS"."XXHA_ORDER_DELIVERABLES_MV" ("ORG_ID", "SOURCE_HEADER_ID", "SOURCE_LINE_ID", "SOURCE_HEADER_NUMBER", "SOURCE_HEADER_TYPE_NAME", "SOURCE_LINE_NUMBER", "SOURCE_LINE_TYPE_CODE", "RELEASED_STATUS_NAME", "NEXT_LINE_STATUS", "LOT_NUMBER", "DELIVERY_ROW_COUNT")
  ORGANIZATION HEAP PCTFREE 10 PCTUSED 0 INITRANS 2 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 131072 NEXT 131072 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "APPS_TS_TX_DATA" 
  PARALLEL 4 
  BUILD IMMEDIATE
  USING INDEX 
  REFRESH COMPLETE ON DEMAND START WITH sysdate+0 NEXT SYSDATE + 1/24
  USING DEFAULT LOCAL ROLLBACK SEGMENT
  USING ENFORCED CONSTRAINTS DISABLE QUERY REWRITE
  AS (
  SELECT org_id                                                                                                                                                                                                                                                                                                                                                                                       ,
    source_header_id                                                                                                                                                                                                                                                                                                                                                                                  ,
    source_line_id                                                                                                                                                                                                                                                                                                                                                                                    ,
    wdv.source_header_number                                                                                                                                                                                                                                                                                                                                                                          ,
    wdv.source_header_type_name                                                                                                                                                                                                                                                                                                                                                                       ,
    wdv.source_line_number                                                                                                                                                                                                                                                                                                                                                                            ,
    wdv.source_line_type_code                                                                                                                                                                                                                                                                                                                                                                         ,
    released_status_name                                                                                                                                                                                                                                                                                                                                                                              ,
    DECODE (wdv.released_status_name, 'Backordered', 'Pick Release', 'Cancelled', 'Not Applicable', 'Released to Warehouse', 'Transact Move Order', 'Ready to Release', 'Pick Release', 'Staged/Pick Confirmed', 'Ship Confirm/Close Trip Stop', 'Shipped', DECODE (wdv.inv_interfaced_flag, 'Y', 'Interfaced/Not Applicable', 'X', 'Interfaced/Not Applicable', 'Run Interfaces' ) ) next_line_status,
    wdv.lot_number                                                                                                                                                                                                                                                                                                                                                                                    ,
    COUNT (1) delivery_row_count
     FROM wsh_deliverables_v wdv
    WHERE source_code   = 'OE'
  AND source_name       = 'Order Management'
  AND wdv.creation_date > SYSDATE - 720
 GROUP BY org_id                                                                                                                                                                                                                                                                                                                                                                     ,
    source_header_id                                                                                                                                                                                                                                                                                                                                                                 ,
    source_line_id                                                                                                                                                                                                                                                                                                                                                                   ,
    wdv.source_header_number                                                                                                                                                                                                                                                                                                                                                         ,
    wdv.source_header_type_name                                                                                                                                                                                                                                                                                                                                                      ,
    wdv.source_line_number                                                                                                                                                                                                                                                                                                                                                           ,
    wdv.source_line_type_code                                                                                                                                                                                                                                                                                                                                                        ,
    released_status_name                                                                                                                                                                                                                                                                                                                                                             ,
    DECODE (wdv.released_status_name, 'Backordered', 'Pick Release', 'Cancelled', 'Not Applicable', 'Released to Warehouse', 'Transact Move Order', 'Ready to Release', 'Pick Release', 'Staged/Pick Confirmed', 'Ship Confirm/Close Trip Stop', 'Shipped', DECODE (wdv.inv_interfaced_flag, 'Y', 'Interfaced/Not Applicable', 'X', 'Interfaced/Not Applicable', 'Run Interfaces' ) ),
    wdv.lot_number
  );

  CREATE INDEX "APPS"."XXHA_ORDER_DELIVERABLES_PK" ON "APPS"."XXHA_ORDER_DELIVERABLES_MV" ("ORG_ID", "SOURCE_HEADER_ID", "SOURCE_LINE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 131072 NEXT 131072 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "APPS_TS_TX_DATA" ;

   COMMENT ON MATERIALIZED VIEW "APPS"."XXHA_ORDER_DELIVERABLES_MV"  IS 'snapshot table for snapshot APPS.XXHA_ORDER_DELIVERABLES_MV';
