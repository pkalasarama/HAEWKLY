--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_ITEMINST_CUSTNBR
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_ITEMINST_CUSTNBR" (p_party_id in number) return varchar2
as p_output varchar2 (200);
begin
/* R12 Upgrade Modified on 10/04/2012 by Venkatesh Sarangam, Rolta */
  /*select customer_number
  into p_output
  from ra_customers
  where party_id = p_party_id;*/

  select hca.account_number
  into p_output
  from hz_parties hp,
       hz_cust_accounts hca
  where hp.party_id = hca.party_id
    and hp.party_id = p_party_id;
  return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_ItemInst_CustNbr;

/
