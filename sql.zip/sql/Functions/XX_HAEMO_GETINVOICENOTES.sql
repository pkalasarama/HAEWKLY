--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GETINVOICENOTES
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GETINVOICENOTES" (p_trxid  number)
  RETURN VARCHAR2
IS
  l_text  VARCHAR2(4000) := NULL;
BEGIN
  FOR cur_rec IN (SELECT  st.short_text
                  FROM fnd_documents_vl fnddoc
                  inner join fnd_attached_documents fndattdoc
                  on fnddoc.document_id = fndattdoc.document_id
                  and fndattdoc.entity_name = 'RA_CUSTOMER_TRX'
                  inner join fnd_documents_short_text st
                  on fnddoc.media_id=st.media_id
                  WHERE fndattdoc.pk1_value = to_char(p_trxid)) 
  LOOP
    l_text := l_text || ' ' || cur_rec.short_text;
  END LOOP;
  RETURN LTRIM(l_text, ' ');
END;

/
