 -- ======================================================================================
 --      Copyright(c) 2015 Haemonetics Corporation
 --                    All rights reserved.
 -- ======================================================================================
 -- NAME : XXHA_SUPERVISORS_V.sql
 -- PROGRAM TYPE
 -- SQL Program/Script
 -- 
 -- DESCRIPTION
 -- This function returns the Supervisor for the employee.
 -- 
 -- HISTORY
 -- 
 -- ======================================================================================
 -- Modification Date   Modified By      Activity
 -- ======================================================================================
 -- 27-Feb-2015         B. Marcoux       Initial function creation.
 -- 
 -- ======================================================================================

CREATE OR REPLACE
FUNCTION XXHA_DETERMINE_SUPERVISOR_FNC(p_person_id IN NUMBER, p_supervisor_id IN NUMBER)
RETURN NUMBER AS

l_EMPLOYEE             per_assignments_x.person_id%TYPE := NULL;

--------------------------------------------------------------------------------
-- Retrieve Supervisor for Employees
CURSOR cur_1(c_person_id NUMBER) IS
SELECT pax.SUPERVISOR_ID
  FROM per_assignments_x pax
 WHERE pax.supervisor_id IN (p_supervisor_id)
       START WITH pax.person_id = c_person_id
       CONNECT BY PRIOR pax.SUPERVISOR_ID = pax.PERSON_ID;

BEGIN

   BEGIN
      OPEN cur_1(p_person_id);
      LOOP
         FETCH cur_1 INTO l_EMPLOYEE;
         EXIT WHEN cur_1%NOTFOUND;
      END LOOP;
      CLOSE cur_1;
   END;

   RETURN l_EMPLOYEE;

EXCEPTION
     WHEN OTHERS THEN
          RETURN NULL;

END XXHA_DETERMINE_SUPERVISOR_FNC;