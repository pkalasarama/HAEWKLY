--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_TERM_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_TERM_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select NAME
		into   lp_attr_val
		from   RA_TERMS
		where  TO_CHAR(TERM_ID) = p_attr_val
			   and TRUNC(SYSDATE) BETWEEN NVL(START_DATE_ACTIVE,TRUNC(SYSDATE)) AND NVL(END_DATE_ACTIVE,TRUNC(SYSDATE));
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE10' then
	 	select FREIGHT_TERMS
		into   lp_attr_val
		from   OE_FRGHT_TERMS_ACTIVE_V
		where  FREIGHT_TERMS_CODE = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE11' then
	 	select LOOKUP_CODE
		into   lp_attr_val
		from   OE_SHIP_METHODS_V
		where  LOOKUP_CODE = p_attr_val;
	 end if;
	 return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_TERM_QUAL_VAL;

/
