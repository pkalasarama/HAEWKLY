--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INV_ORG_DESC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INV_ORG_DESC" (p_org_id in number) return varchar2
as p_output varchar2 (300);

begin
  select organization_name
  into p_output
  FROM org_organization_definitions
  where organization_id = p_org_id;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Inv_Org_Desc;

/
