/*******************************************************************************************************
    * Object Name: XXHA_WMS_PARCEL_VALIDATION
    * Object Type: Function
    * Description: This Function checks for if the item is overpack, if the carrier is FEDEX
	*              and if the ship to country is not US or Canada and returns the status. This is 
	*			   created for 100% Parcel drop trigger requirement. 
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    10-May-2015          Initial object creation.
*******************************************************************************************************/ 

create or replace 
FUNCTION "XXHA_WMS_PARCEL_VALIDATION"(
    p_delivery_id NUMBER)
  RETURN VARCHAR2
AS
  l_status VARCHAR2(100);
  l_count  NUMBER;
  l_count1 NUMBER;
  l_count2 NUMBER;
BEGIN
  BEGIN
    SELECT COUNT(wnd.delivery_id)
    INTO l_count
    FROM wsh_new_deliveries wnd,
      wsh_delivery_assignments wda,
      wsh_delivery_details wdd
    WHERE wda.delivery_Detail_id = wdd.delivery_Detail_id
    AND wda.delivery_id          = wnd.delivery_id
    AND wnd.delivery_id          =p_delivery_id
    AND EXISTS
      (SELECT 1
      FROM wsh_container_items wci
      WHERE wci.master_organization_id = wdd.organization_id
      AND wci.load_item_id             = wdd.inventory_item_id
      );
      DBMS_OUTPUT.PUT_LINE ('The count is: '||l_count2);
  EXCEPTION
  WHEN no_data_found THEN
    l_status:='N';
  END;
IF l_count =1 THEN
  l_status:='Y';
  RETURN l_status;
ELSE
  l_status:='N';
END IF;
BEGIN
  SELECT COUNT(DISTINCT wnd.delivery_id)
  INTO l_count1
  FROM wsh_new_deliveries wnd,
    wsh_delivery_assignments wda,
    wsh_delivery_details wdd
  WHERE wda.delivery_Detail_id = wdd.delivery_Detail_id
  AND wda.delivery_id          = wnd.delivery_id
  AND wnd.delivery_id          =p_delivery_id
  AND EXISTS
    (SELECT 1
    FROM WSH_CARRIERS_V
    WHERE upper(CARRIER_NAME) LIKE '%FEDEX%'
    AND carrier_id=wnd.carrier_id
    )
  AND EXISTS
    (SELECT 1
    FROM hz_locations hl
    WHERE hl.location_id=wdd.ship_to_location_id
    AND hl.country NOT IN ('US','CA')
    );
EXCEPTION
WHEN no_data_found THEN
  l_status:='N';
END;
IF l_count1 =1 THEN
  l_status :='Y';
  RETURN l_status;
ELSE
  l_status:='N';
END IF;
  BEGIN
    SELECT COUNT(wnd.delivery_id)
    INTO l_count2
    FROM wsh_new_deliveries wnd,
      wsh_delivery_assignments wda,
      wsh_delivery_details wdd,
      fnd_lookup_values flv,
      mtl_parameters mp
    WHERE wda.delivery_Detail_id = wdd.delivery_Detail_id
    AND wda.delivery_id          = wnd.delivery_id
    AND wnd.delivery_id       =p_delivery_id
    and wdd.organization_id = mp.organization_id
    AND wdd.ship_method_code  =   flv.description
   and flv.lookup_type        = 'XXHA_WMS_SUPPRESS_PRECISION'
   AND flv.enabled_flag = 'Y'
   AND flv.language = USERENV('LANG')
   and lookup_code like mp.organization_code||':'||wdd.SHIP_METHOD_code
   AND NOT EXISTS
      (SELECT 1
      FROM wsh_container_items wci
      WHERE wci.master_organization_id = wdd.organization_id
      AND wci.load_item_id             = wdd.inventory_item_id
      );
   EXCEPTION
  WHEN no_data_found THEN
    l_status:='N';
  END;
IF l_count2 =1 THEN
  l_status:='Y';
  RETURN l_status;
ELSE
  l_status:='N';
END IF;
RETURN l_status;
END;