--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_PIR_FF_VALIDATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_PIR_FF_VALIDATE" (
/*****************************************************************************************
* Name/Purpose : xxha_pir_ff_validate
* Description  : creates                                                                 *
*                function xxha_pir_ff_validate                                           *
*                Field Service Problem/Resolution Code Extension for CAPA                *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 19-JUN-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
incident_id number,
incident_number number,
inventory_item_id number,
incident_type_id number,
problem_code varchar2,
resolution_code varchar2,
--problemCodes
incident_attribute_1 varchar2,
incident_attribute_7 varchar2,
incident_attribute_8 varchar2,
incident_attribute_9 varchar2,
incident_attribute_10 varchar2,
--resolution_codes
incident_attribute_11 varchar2,
incident_attribute_12 varchar2,
incident_attribute_13 varchar2,
incident_attribute_14 varchar2,
incident_attribute_15 varchar2
) return varchar2
as
TYPE type_problem_codes IS TABLE OF cs_incidents_all_b.incident_attribute_15%TYPE INDEX BY BINARY_INTEGER;
TYPE type_resolution_codes IS TABLE OF cs_incidents_all_b.incident_attribute_15%TYPE INDEX BY BINARY_INTEGER;
va_problem_code type_problem_codes;
va_resolution_code type_resolution_codes;
va_err_problem_code type_problem_codes;
va_err_resolution_code type_resolution_codes;
--select * from cs_incidents_all_b
--cursor c_problem_code 
v_message varchar2(1000);
v_pc_message varchar2(1000);
v_rc_message varchar2(1000);
--problem_code cursor
cursor cp(x_problem_code varchar2, x_inventory_item_id number, x_incident_type_id number) is
select meaning Problem, lookup_code problem_code, description
from cs_lookups cslu
where lookup_type = 'REQUEST_PROBLEM_CODE'
and enabled_flag = 'Y'
and trunc(sysdate) between trunc(nvl(start_date_active,sysdate))
and trunc(nvl(end_date_active,sysdate))
and cslu.lookup_code = x_problem_code
and exists (
  select 1 from cs_sr_prob_code_mapping_detail cstl
  where cstl.problem_code = cslu.lookup_code
    and trunc(sysdate) between trunc(nvl(cstl.start_date_active,sysdate))
    and trunc(nvl(cstl.end_date_active,sysdate))
    and trunc(sysdate) between trunc(nvl(cstl.map_start_date_active,sysdate))
    and trunc(nvl(cstl.map_end_date_active,sysdate))
    and cstl.inventory_item_id = x_inventory_item_id
    and (cstl.incident_type_id is null or cstl.incident_type_id = x_incident_type_id)
    )
union
select meaning Problem, lookup_code problem_code, description
from cs_lookups cslu
where lookup_type = 'REQUEST_PROBLEM_CODE'
and enabled_flag = 'Y'
and trunc(sysdate) between trunc(nvl(start_date_active,sysdate))
and trunc(nvl(end_date_active,sysdate))
and cslu.lookup_code = x_problem_code
and exists (
  select 1 from cs_sr_prob_code_mapping_detail cstl, mtl_item_categories mic
  where cstl.problem_code = cslu.lookup_code
    and trunc(sysdate) between trunc(nvl(cstl.start_date_active,sysdate))
    and trunc(nvl(cstl.end_date_active,sysdate))
    and trunc(sysdate) between trunc(nvl(cstl.map_start_date_active,sysdate))
    and trunc(nvl(cstl.map_end_date_active,sysdate))
    and cstl.category_id = mic.category_id
    and mic.inventory_item_id = x_inventory_item_id
    and (cstl.incident_type_id is null or cstl.incident_type_id = fnd_profile.value('XXHA_CS_CP_ORDERS_SR_TYPE'))
    )
union
select meaning Problem, lookup_code problem_code, description
from cs_lookups cslu
where lookup_type = 'REQUEST_PROBLEM_CODE'
and enabled_flag = 'Y'
and trunc(sysdate) between trunc(nvl(start_date_active,sysdate))
and trunc(nvl(end_date_active,sysdate))
and cslu.lookup_code = x_problem_code
and exists (
  select 1 from cs_sr_prob_code_mapping_detail cstl
  where cstl.problem_code = cslu.lookup_code
    and trunc(sysdate) between trunc(nvl(cstl.start_date_active,sysdate))
    and trunc(nvl(cstl.end_date_active,sysdate))
    and trunc(sysdate) between trunc(nvl(cstl.map_start_date_active,sysdate))
    and trunc(nvl(cstl.map_end_date_active,sysdate))
    and cstl.incident_type_id = fnd_profile.value('XXHA_CS_CP_ORDERS_SR_TYPE')
    and cstl.inventory_item_id is null and cstl.category_id is null 
    )
union
select meaning Problem, lookup_code problem_code, description
from cs_lookups cslu
where lookup_type = 'REQUEST_PROBLEM_CODE'
and enabled_flag = 'Y'
and trunc(sysdate) between trunc(nvl(start_date_active,sysdate))
and trunc(nvl(end_date_active,sysdate))
and cslu.lookup_code = x_problem_code
and not exists (
  select 1 from cs_sr_prob_code_mapping_detail cstl
  where cstl.problem_code = cslu.lookup_code
    and trunc(sysdate) between trunc(nvl(cstl.start_date_active,sysdate))
    and trunc(nvl(cstl.end_date_active,sysdate))
    and trunc(sysdate) between trunc(nvl(cstl.map_start_date_active,sysdate))
    and trunc(nvl(cstl.map_end_date_active,sysdate))
);
--resolution_code cursor
cursor cr(x_resolution_code varchar2, x_problem_code varchar2, x_inventory_item_id number, x_incident_type_id number) is
select meaning Resolution, lookup_code resolution_code, description
from cs_lookups cslu
where lookup_type = 'REQUEST_RESOLUTION_CODE'
and   enabled_flag = 'Y'
and trunc(sysdate) between trunc(nvl(start_date_active,sysdate))
and trunc(nvl(end_date_active,sysdate))
and cslu.lookup_code = x_resolution_code
and exists (
  select 1 from cs_sr_res_code_mapping_detail cstl
  where cstl.resolution_code = cslu.lookup_code
    and trunc(sysdate) between trunc(nvl(cstl.start_date_active,sysdate))
    and trunc(nvl(cstl.end_date_active,sysdate))
    and trunc(sysdate) between trunc(nvl(cstl.map_start_date_active,sysdate))
    and trunc(nvl(cstl.map_end_date_active,sysdate))
    and (cstl.incident_type_id is null or cstl.incident_type_id = fnd_profile.value('XXHA_CS_CP_ORDERS_SR_TYPE'))
    and (cstl.problem_code is null or cstl.problem_code = x_problem_code)
    and (cstl.inventory_item_id is null or cstl.inventory_item_id =x_inventory_item_id)
    and cstl.category_id is null
    )
union
select meaning Resolution, lookup_code resolution_code, description
from cs_lookups cslu
where lookup_type = 'REQUEST_RESOLUTION_CODE'
and   enabled_flag = 'Y'
and trunc(sysdate) between trunc(nvl(start_date_active,sysdate))
and trunc(nvl(end_date_active,sysdate))
and cslu.lookup_code = x_resolution_code
and exists (
  select 1 from cs_sr_res_code_mapping_detail cstl, mtl_item_categories mic
  where cstl.resolution_code = cslu.lookup_code
    and trunc(sysdate) between trunc(nvl(cstl.start_date_active,sysdate))
    and trunc(nvl(cstl.end_date_active,sysdate))
    and trunc(sysdate) between trunc(nvl(cstl.map_start_date_active,sysdate))
    and trunc(nvl(cstl.map_end_date_active,sysdate))
    and cstl.category_id = mic.category_id
    and (cstl.incident_type_id is null or cstl.incident_type_id = x_incident_type_id)
    and (cstl.problem_code is null or cstl.problem_code = x_problem_code)
    and mic.inventory_item_id = x_inventory_item_id
    )
union
select meaning Resolution, lookup_code resolution_code, description
from cs_lookups cslu
where lookup_type = 'REQUEST_RESOLUTION_CODE'
and   enabled_flag = 'Y'
and trunc(sysdate) between trunc(nvl(start_date_active,sysdate))
and trunc(nvl(end_date_active,sysdate))
and cslu.lookup_code = x_resolution_code
and not exists (
  select 1 from cs_sr_res_code_mapping_detail cstl
  where cstl.resolution_code = cslu.lookup_code
    and trunc(sysdate) between trunc(nvl(cstl.start_date_active,sysdate))
    and trunc(nvl(cstl.end_date_active,sysdate))
    and trunc(sysdate) between trunc(nvl(cstl.map_start_date_active,sysdate))
    and trunc(nvl(cstl.map_end_date_active,sysdate))
    )
;
v_valid_info boolean;
begin
  va_problem_code.delete;
  va_resolution_code.delete;
  if incident_attribute_1 is not null then
    va_problem_code(va_problem_code.count +1) := incident_attribute_1;
  end if;
  if incident_attribute_7 is not null then
    va_problem_code(va_problem_code.count +1) := incident_attribute_7;
  end if;
  if incident_attribute_8 is not null then
    va_problem_code(va_problem_code.count +1) := incident_attribute_8;
  end if;
  if incident_attribute_9 is not null then
    va_problem_code(va_problem_code.count +1) := incident_attribute_9;
  end if;
  if incident_attribute_10 is not null then
    va_problem_code(va_problem_code.count +1) := incident_attribute_10;
  end if;
  for p in 1..va_problem_code.count loop
    v_valid_info := false;
    for i in cp(va_problem_code(p), inventory_item_id, incident_type_id) loop
      v_valid_info := true;
    end loop;
    if not v_valid_info then
      v_message := substr(v_message || va_problem_code(p) ||',',1,1000);
    end if;
  end loop;
  if length(v_message) > 1 and substr(v_message,length(v_message),1) = ',' then
    v_message := substr(v_message,1,length(v_message)-1);
  end if;
  if length(v_message) > 0 then
    v_pc_message := 'Problem codes ' || v_message ||' are not applicable to this Service Request.';
  end if;
  -- validating resolution_codes
  -- need problem_code column to validate for dependent resolution_codes
  if problem_code is not null then
    va_problem_code(va_problem_code.count +1) := problem_code;
  end if;
  -- no need for resolution_code column just flex fields are enough
  if incident_attribute_11 is not null then
    va_resolution_code(va_resolution_code.count +1) := incident_attribute_11;
  end if;
  if incident_attribute_12 is not null then
    va_resolution_code(va_resolution_code.count +1) := incident_attribute_12;
  end if;
  if incident_attribute_13 is not null then
    va_resolution_code(va_resolution_code.count +1) := incident_attribute_13;
  end if;
  if incident_attribute_14 is not null then
    va_resolution_code(va_resolution_code.count +1) := incident_attribute_14;
  end if;
  if incident_attribute_15 is not null then
    va_resolution_code(va_resolution_code.count +1) := incident_attribute_15;
  end if;
  v_message := '';
  for r in 1..va_resolution_code.count loop
    v_valid_info := false;
    for p in 1..va_problem_code.count loop
      for i in cr(va_resolution_code(r), va_problem_code(p), inventory_item_id, incident_type_id) loop
        v_valid_info := true;
      end loop;
    end loop;
    if not v_valid_info then
      v_message := substr(v_message || va_resolution_code(r) ||',',1,1000);
    end if;
  end loop;
  if length(v_message) > 1 and substr(v_message,length(v_message),1) = ',' then
    v_message := substr(v_message,1,length(v_message)-1);
  end if;
  if length(v_message) > 0 then
    v_rc_message := 'Resolution codes ' || v_message ||' are not applicable to this Service Request.';
  end if;
  if v_pc_message is not null or v_rc_message is not null then
    return v_pc_message || chr(10) || v_rc_message || chr(10) || 'Please correct these before closing the Service Request.';
  end if;
  return 'NOERROR';
  --return 'Problem Code ... not available for this incident';
end;

/
