--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_MEDICAL_DEVICE_TAX
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_MEDICAL_DEVICE_TAX" (
/*****************************************************************************************
* Name/Purpose : XXHA_MEDICAL_DEVICE_TAX_DDL_2.sql                                       *
* Description  : creates                                                                 *
*                function xxha_medical_device_tax                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 09-JAN-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
p_transaction_amount number,
p_disc1_percentage number,
p_disc2_percentage number,
p_markdown_factor number,
p_excise_percentage number
) return number is
v_amount number;
v_excise_amount number;
begin
  if nvl(p_transaction_amount,0) = 0 or nvl(p_excise_percentage,0) = 0 then
     return 0;
  end if;
  v_amount := p_transaction_amount;
  if nvl(p_disc1_percentage,0) != 0 then
    v_amount := v_amount * p_disc1_percentage;
  end if;
  if nvl(p_disc2_percentage,0) != 0 then
    v_amount := v_amount * p_disc2_percentage;
  end if;
  if nvl(p_markdown_factor,0) != 0 then
    v_amount := v_amount / p_markdown_factor;
  end if;
  return v_amount * p_excise_percentage /100;
end ;

/
