--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_MATERIAL_CERT_PROC_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_MATERIAL_CERT_PROC_FNC" (p_COLLECTION_ID IN NUMBER, p_OCCURRENCE IN NUMBER, p_ITEM_ID IN NUMBER)
RETURN VARCHAR AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_MATERIAL_CERT_PROC_FNC
 * Description:  This function will determine if an Item exists in the Cert Mapping Table  
 *               It is used by the Trigger 'XXHA_MATERIAL_CERT_TRG'.
 * Notes:
 *
 * Modified:     Ver    Date         Modification
 *-------------  -----  -----------  ----------------------------------------------------------------------------------------------
 * BMarcoux      1.0    21-FEB-2014  Initial Function Creation
 *
 **********************************************************************************************************************************/

l_flag           VARCHAR(01) := NULL;

-- Return Flag
CURSOR cur_1
    IS
SELECT 'Y'
  FROM
       Xxha_MATERIAL_Cert_V			      cert
 WHERE
       cert.RESULTS_ID	= p_COLLECTION_ID
   AND cert.OCCURRENCE	= p_OCCURRENCE
   AND cert.Item_ID     = p_ITEM_ID
 ;

BEGIN

    BEGIN
        OPEN cur_1;
       FETCH cur_1 INTO l_flag;
       CLOSE cur_1;
    END;

    RETURN NVL(l_flag,'N');

END XXHA_MATERIAL_CERT_PROC_FNC;

/
