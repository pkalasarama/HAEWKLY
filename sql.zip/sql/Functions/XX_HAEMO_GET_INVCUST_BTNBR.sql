--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INVCUST_BTNBR
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INVCUST_BTNBR" (p_cust_id in number) return varchar2
as p_output varchar2 (100);
BEGIN
/* R12 Upgrade Modified on 10/08/2012 by Venkatesh Sarangam, Rolta */
  /*select customer_number
  into p_output
  from ra_customers
  where customer_id = p_cust_id;*/
  SELECT hca.account_number
  INTO p_output
  FROM hz_parties hp,
       hz_cust_accounts hca
  where hca.cust_account_id = p_cust_id;
  return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_InvCust_BTNBR;

/
