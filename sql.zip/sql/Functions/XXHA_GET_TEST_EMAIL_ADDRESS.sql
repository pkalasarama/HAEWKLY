CREATE OR REPLACE FUNCTION "APPS"."XXHA_GET_TEST_EMAIL_ADDRESS" 
  /* ******************************************************************************************************
  * Object Name: XXHA_GET_TEST_EMAIL_ADDRESS
  * Object Type: FUNCTION
  *
  * Description: This function will return test email address to be used in ship notification
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    16-JAN-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
      RETURN VARCHAR2
   AS
      --
      l_test_mail_address   VARCHAR2 (400);
   --
   BEGIN
      BEGIN
         SELECT fscpv.parameter_value
           INTO l_test_mail_address
           FROM fnd_svc_comp_params_tl fscpt, fnd_svc_comp_param_vals fscpv
          WHERE fscpt.display_name = 'Test Address'
            AND fscpt.parameter_id = fscpv.parameter_id
and customization_level='U';
      EXCEPTION
         WHEN OTHERS
         THEN
                              l_test_mail_address:='vijay.medikonda@haemonetics.com';
                             -- l_test_mail_address:='ohmesh.suraj@haemonetics.com';
            END;   
 
      RETURN l_test_mail_address;
   END;
   /
   