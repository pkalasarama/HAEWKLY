--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_RTV_GL_SEGMENTS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_RTV_GL_SEGMENTS" (p_person_id IN NUMBER)
RETURN VARCHAR2 AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_RTV_GL_SEGMENTS
 * Description:  This function will retrieve the GL Segments for an employee until a value is found
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      18-SEP-2013     Initial Function Creation
 * BMarcoux        2.0      11-NOV-2013     Correction for Cursor Issue
 *
 **********************************************************************************************************************************/

l_Str_Segment             VARCHAR2(250) := NULL;
l_CODE_COMB_ID            PER_ASSIGNMENTS_X.DEFAULT_CODE_COMB_ID%TYPE := NULL;

--------------------------------------------------------------------------------
-- Retrieve Employee and GL Segment data
CURSOR cur_1(c_person_id NUMBER) IS
SELECT GLCC.SEGMENT1||'.'||GLCC.SEGMENT2||'.'||GLCC.SEGMENT3||'.'||GLCC.SEGMENT4||'.'||GLCC.SEGMENT5||'.'||'602150'||'.'||GLCC.SEGMENT7
     , PAX.DEFAULT_CODE_COMB_ID
  FROM PER_PEOPLE_X         PEP
     , PER_ASSIGNMENTS_X    PAX
     , GL_CODE_COMBINATIONS GLCC
 WHERE PEP.PERSON_ID            = PAX.PERSON_ID
   AND PAX.DEFAULT_CODE_COMB_ID = GLCC.CODE_COMBINATION_ID(+)
       START WITH PAX.PERSON_ID = c_person_id
       CONNECT BY PRIOR PAX.SUPERVISOR_ID = PAX.PERSON_ID;

BEGIN

    BEGIN
       OPEN cur_1(p_person_id);
       LOOP
           FETCH cur_1 INTO l_Str_Segment
                          , l_CODE_COMB_ID;
           EXIT WHEN cur_1%NOTFOUND OR l_CODE_COMB_ID IS NOT NULL;
       END LOOP;
    END;

    IF l_CODE_COMB_ID IS NOT NULL AND cur_1%FOUND THEN
       RETURN l_Str_Segment;
    ELSE
       RETURN NULL;
    END IF;

    CLOSE cur_1;

END XXHA_RTV_GL_SEGMENTS;

/
