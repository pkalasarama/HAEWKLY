
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_GET_CONCAT_QTY_F" ( p_qty number, p_load_item_id number ) 
  return varchar2
    /*******************************************************************************************************
    * Object Name: XXHA_GET_CONCAT_QTY_F
    * Object Type: FUNCTION
    *
    * Description: This function will return concatenated quantities
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/

  is 
l_max_qty number;
l_min_qty number;
lp_qty number;
l_output varchar2(1000);
begin
-- Get the max load quantity for item 
select max(max_load_quantity) into l_max_qty from wsh_container_items where load_item_id = p_load_item_id;
lp_qty := p_qty;
dbms_output.put_line('lp_qty, l_max_qty '||lp_qty||','||l_max_qty);

--if input qty is less than max load quantity get the immediate greater or equal value and return.
if lp_qty < l_max_qty then 
--l_output := l_output ||',';
l_min_qty := 0;
dbms_output.put_line('lp_qty, l_max_qty less if'||lp_qty||','||l_max_qty);
select min(max_load_quantity) into l_min_qty from wsh_container_items where load_item_id = p_load_item_id and max_load_quantity >= lp_qty;
l_output := l_output || l_min_qty;
dbms_output.put_line('l_output less if'||l_output);
end if;

--if input qty is greater than max load quantity concatenated quantities will be calculated and returned.
while (lp_qty >= l_max_qty) loop
l_output := l_output || l_max_qty;
lp_qty := lp_qty - l_max_qty; 
dbms_output.put_line('lp_qty '||lp_qty);
if lp_qty < l_max_qty then 
l_output := l_output ||',';
l_min_qty := 0;
select min(max_load_quantity) into l_min_qty from wsh_container_items where load_item_id = p_load_item_id and max_load_quantity >= lp_qty;
l_output := l_output || l_min_qty;
dbms_output.put_line('l_output if'||l_output);
elsif lp_qty >= l_max_qty then
l_output := l_output ||',';
dbms_output.put_line('l_output elsif'||l_output);
end if;
dbms_output.put_line('lp_qty '||lp_qty);
dbms_output.put_line('l_output loop'||l_output);
end loop;

dbms_output.put_line('l_output '||l_output);
return l_output;
exception when others then 
null;
return null;
end;
/