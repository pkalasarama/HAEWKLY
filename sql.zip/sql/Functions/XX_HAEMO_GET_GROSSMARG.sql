--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_GROSSMARG
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_GROSSMARG" (p_sales_rev IN NUMBER, p_cost IN NUMBER) return number as 
p_output NUMBER;

begin 
      select 100*(p_sales_rev-p_cost)/p_sales_rev
      into p_output
      from dual;
      return nvl((p_output),0);

exception 
      when others then
      p_output := 0;
      return nvl((p_output),0);
end XX_HAEMO_Get_GrossMarg;

/
