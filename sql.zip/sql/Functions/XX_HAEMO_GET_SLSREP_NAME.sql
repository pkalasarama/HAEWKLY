--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_SLSREP_NAME
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_SLSREP_NAME" (p_salesrep_id IN NUMBER, p_org_id IN NUMBER) return VARCHAR2
as p_output varchar2 (200);

BEGIN
  Select name
  INTO p_output
  FROM jtf_rs_salesreps
  WHERE salesrep_id = p_salesrep_id
  and org_id = p_org_id;
  RETURN NVL((p_output),'N/A');

EXCEPTION
  WHEN OTHERS THEN
  p_output := 'N/A';
  RETURN NVL((p_output),'N/A');
END XX_HAEMO_Get_SlsRep_Name;

/
