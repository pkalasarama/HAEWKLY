--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_MOD_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_MOD_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select NAME
		into   lp_attr_val
		from   QP_SECU_LIST_HEADERS_VL
		where  TO_CHAR(LIST_HEADER_ID) = p_attr_val
			   and LIST_TYPE_CODE IN ('DEL','PRO')
			   and view_flag = 'Y';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE2' then
	 	select LIST_LINE_NO
		into   lp_attr_val
		from   QP_LIST_LINES
		where  TO_CHAR(LIST_LINE_ID) = p_attr_val
			   and list_line_no is not null;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE3' then
	 	select Coupon_Number
		into   lp_attr_val
		from   QP_COUPONS
		where  TO_CHAR(Coupon_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE4' then
	 	select NAME
		into   lp_attr_val
		from   QP_SECU_LIST_HEADERS_VL
		where  TO_CHAR(LIST_HEADER_ID) = p_attr_val
			   and LIST_TYPE_CODE IN ('PRL' , 'AGR')
			   and view_flag = 'Y';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE10' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 end if;
	 return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_MOD_QUAL_VAL;

/
