--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_IS_NUMBER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_IS_NUMBER" (in_var IN VARCHAR2)
   RETURN VARCHAR2
IS
   v_number   NUMBER;
BEGIN
   IF in_var IS NOT NULL
   THEN
      v_number := TO_NUMBER (in_var);
      RETURN 'TRUE'; -- No exception, so is a number
   ELSE
      RETURN 'FALSE';
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN 'FALSE';
END;

/
