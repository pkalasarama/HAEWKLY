--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_GL_BOOK_CURR
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_GL_BOOK_CURR" (p_org_id in number) return varchar2
as p_output varchar2 (50);
begin
/* R12 Upgrade Modified on 10/09/2012 by Venkatesh Sarangam, Rolta */
  /*select gsb.currency_code
  into p_output
  from org_organization_definitions ood, gl_sets_of_books gsb
  where ood.organization_id = p_org_id
  and ood.set_of_books_id = gsb.set_of_books_id;*/
  select gsb.currency_code
  into p_output
  from org_organization_definitions ood,
       gl_ledgers gsb
  where ood.organization_id = p_org_id
  and ood.set_of_books_id = gsb.ledger_id;
  return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Gl_Book_Curr;

/
