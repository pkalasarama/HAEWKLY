--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_CURR_DLY_RATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_CURR_DLY_RATE" (p_from_curr in varchar, p_to_curr in varchar, p_conv_date in date) return number as 
p_output NUMBER;

begin 
      select conversion_rate
      into p_output
      from gl_daily_rates
      where conversion_type = '1000' -- Constant Currency
      and from_currency = p_from_curr
      and to_currency = p_to_curr
      and conversion_date = p_conv_date;
      return nvl((p_output),0);

exception 
      when others then
      p_output := 0;
      return nvl((p_output),0);
end XX_HAEMO_Get_Curr_Dly_Rate;

/
