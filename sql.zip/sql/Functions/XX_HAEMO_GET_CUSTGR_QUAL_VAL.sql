--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_CUSTGR_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_CUSTGR_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select tl.list_name
		into   lp_attr_val
		from   AMS_LIST_HEADERS_ALL list
			   , AMS_LIST_HEADERS_ALL_TL tl
		where  TO_CHAR(list.list_header_id) = p_attr_val
			   and list.list_header_id = tl.list_header_id
			   AND userenv('LANG') = language
			   AND status_code in ( 'AVAILABLE','LOCKED','EXECUTED','EXECUTING','VALIDATED','VALIDATING');
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE2' then
	 	select tl.cell_name
		into   lp_attr_val
		from   AMS_CELLS_ALL_B cell
			   , AMS_CELLS_ALL_TL tl
		where  TO_CHAR(cell.cell_id) = p_attr_val
			   and cell.cell_id = tl.cell_id
			   AND userenv('LANG') = language
			   AND cell.status_code = 'AVAILABLE';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE3' then
	 	select hz.PARTY_NAME
		into   lp_attr_val
		from   ams_party_market_segments ams
			   , hz_parties hz
		where  TO_CHAR(hz.PARTY_ID) = p_attr_val
			   and ams.market_qualifier_type = 'BG'
			   AND ams.market_qualifier_reference = hz.party_id
			   AND ams.market_qualifier_reference = ams.party_id
			   AND EXISTS ( SELECT 1
			   	   		    FROM   ams_party_market_segments
							WHERE  market_qualifier_type = 'BG'
		       					   AND market_qualifier_reference =  ams.market_qualifier_reference
		       					   AND market_qualifier_reference <> party_id);
	 end if;
	 return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_CUSTGR_QUAL_VAL;

/
