CREATE OR REPLACE
FUNCTION XXHA_RTV_PICK_RELEASE_DATE(
         p_delivery_id          wsh_delivery_assignments.delivery_id%TYPE
       , p_delivery_detail_id   wsh_delivery_assignments.delivery_detail_id%TYPE) RETURN VARCHAR2 AS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_RTV_PICK_RELEASE_DATE
 * Description:  This Script will retrieve the Pick Release Date
 * Notes:        Used by the following rdf's:
 *               - XXHA_WSHRDINVD.rdf (Commercial Invoices for Distributors)
 *
 * Modified:      Ver     Date              Modification
 *-------------   -----   ----------        ----------------------------------------------------------------------------------------
 * BMarcoux       1.0     18-SEP-2014       Initial Function Creation
 *
 **********************************************************************************************************************************/

    l_pick_release_date VARCHAR2 (15) := NULL;

BEGIN

  SELECT
         (TO_CHAR(mtrl.status_date, 'DD-MON-YYYY'))
    INTO 
         l_pick_release_date
    FROM
         wsh_delivery_assignments  wda
       , wsh_new_deliveries        wnd
       , wsh_delivery_details      wdd
       , mtl_txn_request_lines     mtrl
       , mtl_txn_request_headers   mtrh
       , wsh_pick_slip_v           wpsv
   WHERE
         wda.delivery_id         = p_delivery_id
     AND wda.delivery_detail_id  = p_delivery_detail_id
     AND wnd.delivery_id         = wda.delivery_id
     AND wdd.delivery_detail_id  = wda.delivery_detail_id
     AND wdd.MOVE_ORDER_LINE_ID  = mtrl.line_id
     AND mtrl.header_id          = mtrh.header_id 
     AND mtrl.line_id            = wpsv.move_order_line_id
     AND ROWNUM                  = 1
     ;

    RETURN l_pick_release_date;

EXCEPTION
    WHEN OTHERS THEN
         l_pick_release_date := NULL;
         RETURN l_pick_release_date;

END XXHA_RTV_PICK_RELEASE_DATE;