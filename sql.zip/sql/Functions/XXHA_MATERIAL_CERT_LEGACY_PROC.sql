CREATE OR REPLACE
FUNCTION XXHA_MATERIAL_CERT_LEGACY_PROC(p_COLLECTION_ID IN NUMBER, p_OCCURRENCE IN NUMBER, p_ITEM_ID IN NUMBER)
RETURN VARCHAR AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_MATERIAL_CERT_LEGACY_PROC
 * Description:  This function will determine if an Item exists in the Cert Mapping Table  
 *               It is used by the Trigger 'XXHA_MATERIAL_CERT_TRG'.
 * Notes:
 *
 * Modified:     Ver    Date         Modification
 *-------------  -----  -----------  ----------------------------------------------------------------------------------------------
 * BMarcoux      1.0    16-FEB-2017  Initial Function Creation
 *
 **********************************************************************************************************************************/

l_flag           VARCHAR(01) := NULL;

-- Return Flag
CURSOR cur_1
    IS
SELECT 'Y'
  FROM
       XXHA_MATERIAL_CERT_V   cert
 WHERE
       cert.RESULTS_ID      = p_COLLECTION_ID
   AND cert.OCCURRENCE      = p_OCCURRENCE
   AND cert.Item_ID         = p_ITEM_ID
 ;

BEGIN

    BEGIN
        OPEN cur_1;
       FETCH cur_1 INTO l_flag;
       CLOSE cur_1;
    END;

    RETURN NVL(l_flag,'N');

END XXHA_MATERIAL_CERT_LEGACY_PROC;