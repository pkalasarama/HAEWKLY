CREATE OR REPLACE
FUNCTION XXHA_MATERIAL_CERT_FASTPCK_FNC(p_Status1 IN VARCHAR, p_Status2 IN VARCHAR, p_WEB_TRANSACTION_ID IN NUMBER)
RETURN NUMBER AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_MATERIAL_CERT_FASTPCK_FNC
 * Description:  This function will return the count and update 'PROCESSED_FLAG' and 'DATE_PROCESSED' in the table 'WM_TRACKCHANGES'.  
 *               It is used by 'XXHA: Material Certificates Generation FastPack'.
 * Notes:
 *
 * Modified:     Ver    Date         Modification
 *-------------  -----  -----------  ----------------------------------------------------------------------------------------------
 * BMarcoux      1.0    26-APR-2017  Initial Function Creation
 *
 **********************************************************************************************************************************/

l_count           NUMBER := NULL;

-- Count the number of records
CURSOR cur_1
    IS
SELECT NVL(COUNT(*),0)
  FROM WM_TRACKCHANGES
 WHERE 
       WEB_TRANSACTION_ID <= p_WEB_TRANSACTION_ID
   AND TRANSACTION_TYPE    = 'HAEMO_FASTPACK_CERT'
   AND PROCESSED_FLAG      = p_Status2
   AND DATE_PROCESSED      IS NULL;

BEGIN

   -- Update the records
   BEGIN
      UPDATE WM_TRACKCHANGES 
      SET PROCESSED_FLAG      = p_Status2
        , DATE_PROCESSED      = SYSDATE 
      WHERE 
          WEB_TRANSACTION_ID <= p_WEB_TRANSACTION_ID
      AND TRANSACTION_TYPE    = 'HAEMO_FASTPACK_CERT'
      AND PROCESSED_FLAG      = p_Status1
      AND DATE_PROCESSED      IS NULL;
      COMMIT;
   END;

    -- Count the number of records (WHERE STATUS = p_Status2)
    BEGIN
        OPEN cur_1;
       FETCH cur_1 INTO l_count;
       CLOSE cur_1;
    END;

    RETURN l_count;

END XXHA_MATERIAL_CERT_FASTPCK_FNC;