--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_AP_INVDIST_TOTAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_AP_INVDIST_TOTAL" (p_org_id in number, p_invoice_id in number)return number 
as p_output Number;

Begin
  Select sum(amount)
  into p_output
  from ap_invoice_distributions_all
  where org_id = p_org_id
  and invoice_id = p_invoice_id;
  return nvl ((p_output),0);

exception
  when others then
  p_output := 0;
  return nvl ((p_output),0);
end XX_HAEMO_Get_AP_InvDIst_Total;

/
