--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_CHECK_RESPONSIBILITIES
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_CHECK_RESPONSIBILITIES" (p_user_id IN NUMBER)
RETURN VARCHAR2 AS
/***********************************************************************************************************************************
 *
 * Function:     XXHA_CHECK_RESPONSIBILITIES
 * Description:  This function will determine if a user has responsibilities other than 'Contingent Worker Maintenance',
 *                    'Contingent Worker Self-Service', 'Employee Self-Service', 'Haemonetics Employee Self Service' or
 *                    'Manager Self Service'.
 *
 * Notes:        This function is used by the Alert, 'HAE Employee EBS Responsibility Supervisor Review'
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      24-SEP-2013     Initial Function Creation
 *
 **********************************************************************************************************************************/

l_Process             VARCHAR2(02) := NULL;

--------------------------------------------------------------------------------
-- Retrieve Responsibilities associated to the User ID
CURSOR cur_1(c_user_id NUMBER) 
    IS
SELECT 'Y'
  FROM 
       FND_USER_RESP_GROUPS_DIRECT          RESP
     , FND_RESPONSIBILITY_VL                RESV
     , FND_SECURITY_GROUPS_VL               SEC
 WHERE 
       RESP.User_ID                       = p_user_id
   AND RESV.responsibility_ID             = RESP.Responsibility_ID
   AND RESP.Responsibility_Application_ID = RESV.Application_ID
   AND RESP.Security_Group_ID             = SEC.Security_Group_ID
   AND TRUNC(SYSDATE)	                  BETWEEN NVL(TRUNC(RESP.Start_Date), SYSDATE) AND NVL(TRUNC(RESP.End_Date), SYSDATE)
   AND TRUNC(SYSDATE)	                  BETWEEN NVL(TRUNC(RESV.Start_Date), SYSDATE) AND NVL(TRUNC(RESV.End_Date), SYSDATE)
   AND RESV.Responsibility_Name NOT IN
    ( 'Contingent Worker Maintenance'
     ,'Contingent Worker Self-Service'
     ,'Employee Self-Service'
     ,'Haemonetics Employee Self Service'
     ,'Manager Self Service');

BEGIN

    BEGIN
       OPEN cur_1(p_user_id);
       FETCH cur_1 INTO l_Process;
       CLOSE cur_1;
    END;

    IF l_Process IS NOT NULL THEN
       RETURN l_Process;
    ELSE
       RETURN 'N';
    END IF;

END XXHA_CHECK_RESPONSIBILITIES;

/
