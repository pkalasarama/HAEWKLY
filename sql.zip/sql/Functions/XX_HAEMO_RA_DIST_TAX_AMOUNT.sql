--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_RA_DIST_TAX_AMOUNT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_RA_DIST_TAX_AMOUNT" (p_cust_trx_line_id number)
return number
as
lp_line_amount number;
begin
	 select rctlg.amount
	 into   lp_line_amount
	 from   RA_CUST_TRX_LINE_GL_DIST_ALL rctlg
	 		, ra_customer_trx_lines_all rctla
	 where  rctla.customer_trx_line_id = rctlg.customer_trx_line_id 
	 		and rctla.link_to_cust_trx_line_id = p_cust_trx_line_id;
	 return lp_line_amount;
exception
		 when others then
		 	  lp_line_amount := 0;
			  return lp_line_amount;
end XX_HAEMO_RA_DIST_TAX_AMOUNT;

/
