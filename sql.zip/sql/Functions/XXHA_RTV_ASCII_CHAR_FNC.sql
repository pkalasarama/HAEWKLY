CREATE OR REPLACE 
FUNCTION XXHA_RTV_ASCII_CHAR_FNC(P_TEXT VARCHAR2) 
RETURN VARCHAR2 IS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_RTV_ASCII_CHAR_FNC
 * Description:  Function to retrieve translated character for special character from table XXHA_ASCII_TRANSLATION_TBL.  Called
 *                 by the function XXHA_REMOVE_SPECIAL_CHAR_FNC.
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      12-SEP-2014     Initial Function Creation
 *
 **********************************************************************************************************************************/
 
    l_char                        VARCHAR2 (3 byte)  := NULL;

BEGIN

    SELECT
         ASCII_TRANSLATION
    INTO 
         l_char
    FROM
         HAEMO.XXHA_ASCII_TRANSLATION_TBL hae
    WHERE
         hae.ASCII_CHARACTER   = P_TEXT;

    RETURN l_char;

EXCEPTION
    WHEN OTHERS THEN
         l_char := NULL;
         RETURN l_char;

END XXHA_RTV_ASCII_CHAR_FNC;