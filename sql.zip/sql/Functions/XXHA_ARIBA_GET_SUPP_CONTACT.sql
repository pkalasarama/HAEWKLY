CREATE OR REPLACE FUNCTION XXHA_ARIBA_GET_SUPP_CONTACT (p_party_site_id IN NUMBER)
   RETURN VARCHAR2
IS

/*****************************************************************************************
* Name/Purpose : XXHA_ARIBA_GET_SUPP_CONTACT / Ariba Spend Analysys extract              *
* Description  : Funtion to retreive supplier contact information                        *
*                                                                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 12-Jan-2015     Harish Kollipara     Initial Creation                                  *
*                                                                                        *
/****************************************************************************************/

   v_contact   VARCHAR2 (4000);

BEGIN

   SELECT    PERSON_FIRST_NAME
          || ','
          || PERSON_lasT_NAME
          || ','
          || primary_phone_area_code
          || ' '
          || pty_rel.primary_phone_number
          || ','
          || pty_rel.email_address
     INTO v_contact
     FROM ap_supplier_contacts apsc, hz_parties pty_rel
    WHERE     1 = 1
          AND apsc.rel_party_id = pty_rel.party_id(+)
          AND p_party_site_id = apsc.org_party_site_id
          AND ROWNUM < 2;

   RETURN v_contact;
   EXCEPTION
   WHEN OTHERS
        THEN
           RETURN ',,,';

END XXHA_ARIBA_GET_SUPP_CONTACT;