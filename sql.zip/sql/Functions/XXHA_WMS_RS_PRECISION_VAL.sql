create or replace FUNCTION        "XXHA_WMS_RS_PRECISION_VAL" (
    p_header_id NUMBER)
    /* ******************************************************************************************************
    * Object Name: XXHA_WMS_RS_PRECISION_VAL
    * Object Type: PROCEDURE
    *
    * Description: This procedure will be used in rateshop process
    *
    * Modification Log:
    * Developer         Version       Date                 Description
    *-----------------  ------------  ------------------   ------------------------------------------------
    * Apps Associates    	1.0		  27-JAN-2015          Initial object creation.
    * Apps Associates    	1.1		  07-OCT-2015		   Added FOB in grouping for RATESHOP as per change request. Change attribute12 value to PENDING
    *
    *******************************************************************************************************/

	RETURN VARCHAR2
AS
  l_status VARCHAR2(100);
  l_count  NUMBER;
  l_count1 NUMBER;
BEGIN
  BEGIN
    SELECT COUNT(1)
    INTO l_count
    FROM wm_trackchanges
    WHERE SUBSTR(comments,25)=p_header_id
    AND transaction_type     in ('RATESHOP','RERATESHOP');
    --AND processed_flag       ='Y';
    IF l_count !=0 THEN
      BEGIN
        SELECT COUNT(1)
        INTO l_count1
        FROM oe_order_lines_all
        WHERE header_id=p_header_id
        AND attribute12='Pending' -- 'SENT TO PRECISION' --v1.1 Change attribute12 value to PENDING
		;
      EXCEPTION
      WHEN OTHERS THEN
        NULL;
      END;
      IF l_count1 !=0 THEN
        l_status  :='N';
      ELSE
        l_status:='Y';
      END IF;
    ELSE
      l_status:='Y';
    END IF;
  EXCEPTION
  WHEN no_data_found THEN
    l_status:='Y';
  END;
RETURN l_status;
END;
/