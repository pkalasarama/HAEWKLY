CREATE OR REPLACE
FUNCTION XXHA_DETERMINE_OC_MEMBER(p_person_id IN NUMBER)
RETURN NUMBER AS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_DETERMINE_OC_MEMBER
 * Description:  This function will determine the OC Member an employee is associated with.
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      05-FEB-2015     Initial Function Creation
 *
 **********************************************************************************************************************************/

l_OC_MEMBER             per_assignments_x.person_id%TYPE := NULL;
c_BOD                   per_assignments_x.person_id%TYPE := 18668;              -- Board of Directors

--------------------------------------------------------------------------------
-- Determine OC Member
CURSOR cur_1(c_person_id NUMBER) IS
SELECT 
       paxa.SUPERVISOR_ID
  FROM 
       per_assignments_x       paxa
     , per_people_x            ppxa
 WHERE
     ppxa.person_id           = paxa.person_id
  -- DETERMINE OC MEMBER
 AND paxa.supervisor_id IN
    (SELECT
            ppx.person_id
       FROM
            per_people_x              ppx
          , per_assignments_x         pax
          , apps.per_grades           pg
      WHERE
            ppx.person_id           = pax.person_id
        AND current_employee_flag   = 'Y'
        AND NVL(pax.GRADE_ID,-999)  = pg.GRADE_ID(+)
        AND pg.name                 like 'OC%'
        AND pax.supervisor_id       <> c_BOD
        AND NOT EXISTS
           (SELECT 
                   p.person_id
              FROM
                   apps.per_all_people_f      p
                 , apps.per_all_assignments_f a
                 , apps.per_grades            pg
             WHERE
                   p.person_id              = ppx.person_id
               AND p.person_id              = a.person_id
               AND NVL(a.GRADE_ID,-999)     = pg.GRADE_ID(+)
               AND NVL(pg.name,'XXX')       LIKE 'OC.%'
               AND current_employee_flag    = 'Y'
               AND SYSDATE                  BETWEEN a.effective_start_date AND a.effective_end_date
               AND SYSDATE                  BETWEEN p.effective_start_date AND p.effective_end_date
               AND a.supervisor_id = (SELECT
                                             p2.person_id 
                                        FROM
                                             apps.per_all_people_f      p2
                                           , APPS.per_all_assignments_f a2 
                                       WHERE 
                                             p2.person_id             = a2.person_id
                                         AND a2.supervisor_id         = c_BOD
                                         AND SYSDATE                  BETWEEN P2.effective_start_date AND P2.effective_end_date
                                         AND SYSDATE                  BETWEEN a2.effective_start_date AND a2.effective_end_date)))
START WITH paxa.person_id = c_person_id
CONNECT BY PRIOR paxa.SUPERVISOR_ID = paxa.PERSON_ID;

BEGIN

    -- Determeine OC Member
    OPEN  cur_1(p_person_id);
    FETCH cur_1 INTO l_OC_MEMBER;
    CLOSE cur_1;

    RETURN l_OC_MEMBER;

EXCEPTION
     WHEN OTHERS THEN
          RETURN NULL;

END XXHA_DETERMINE_OC_MEMBER;