--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_VOL_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_VOL_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE10' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE11' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE12' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE13' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE14' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE15' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE16' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE17' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 end if;
	 return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_VOL_QUAL_VAL;

/
