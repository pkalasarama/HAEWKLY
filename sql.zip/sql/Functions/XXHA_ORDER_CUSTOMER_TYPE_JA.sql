--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_ORDER_CUSTOMER_TYPE_JA
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_ORDER_CUSTOMER_TYPE_JA" (p_header_id NUMBER, p_line_id NUMBER)
RETURN VARCHAR2
IS
lp_text VARCHAR2(240);
lp_agreement NUMBER;
lp_sold_to NUMBER;
BEGIN
  	  SELECT agreement_id
  	  INTO   lp_agreement
  	  FROM   oe_order_lines_all
  	  WHERE  header_id = p_header_id
  			 AND line_id = p_line_id;
      IF lp_agreement IS NOT NULL THEN
    	 lp_text := 'Hospital';
      ELSIF lp_agreement IS NULL THEN
	  	  BEGIN
		  	   SELECT sold_to_org_id
			   INTO   lp_sold_to
			   FROM   oe_order_headers_all
			   WHERE  header_id = p_header_id;
/* R12 Upgrade Modified on 10/03/2012 by Venkatesh Sarangam, Rolta */
			   /*SELECT customer_class_code
			   INTO   lp_text
			   FROM   ra_customers
			   WHERE  customer_id = lp_sold_to;*/
         SELECT hca.customer_class_code
         INTO lp_text
         FROM hz_parties hp,
              hz_cust_accounts hca
         WHERE hp.party_id = hca.party_id
         and   hca.cust_account_id = lp_sold_to;
			   IF lp_text = 'BB' THEN
			   	  lp_text := 'Blood Center';
			   ELSE
			   	   lp_text := NULL;
			   END IF;
			   RETURN lp_text;
		  END;
      END IF;
	  RETURN lp_text;
EXCEPTION
WHEN OTHERS THEN
lp_text := NULL;
RETURN lp_text;
END XXHA_ORDER_CUSTOMER_TYPE_JA;

/
