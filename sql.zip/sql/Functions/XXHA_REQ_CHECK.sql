--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_REQ_CHECK
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_REQ_CHECK" (p_req_line number)
return varchar2
is
lp_check varchar2(240);
lp_trans number;
begin
	 select transaction_id
	 into   lp_trans
	 from   rcv_transactions
	 where  requisition_line_id = p_req_line
	 		and transaction_type = 'RECEIVE';
	 if lp_trans is null then
	 	lp_check := 'NOT RECEIVED';
     else
	 	lp_check := 'RECEIVED';
     end if;
	 return lp_check;
exception
	 when others then
	 	  lp_check := 'NOT RECEIVED';
		  return lp_check;
end XXHA_REQ_CHECK;

/
