CREATE OR REPLACE 
FUNCTION XXHA_WD_EMPLOYEE_SPEC_CHAR_FN(P_TEXT VARCHAR2) 
RETURN VARCHAR2 IS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_WD_EMPLOYEE_SPEC_CHAR_FN
 * Description:  Function to remove special characters.  This function is used by the view, 'XXHA_WD_EMPLOYEE_COSTING_V'
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      09-APR-2018     Initial Function Creation
 *
 **********************************************************************************************************************************/

    l_text                        VARCHAR2 (250)     := NULL;
    l_char                        VARCHAR2 (3 byte)  := NULL;
    i                             INTEGER            := 0;

BEGIN

    -- Set variable to input text
    l_text := p_text;

    -- Replace special characters with a space (allowable characters are ASCII BETWEEN 39 AND 126)
    IF LENGTH(l_text) > 0 THEN
       FOR i IN 1..LENGTH(l_text) 
       LOOP
           l_char := SUBSTR((l_text),i,1);
           IF (ASCII (l_char) NOT BETWEEN 39 AND 126) THEN
              l_text := REPLACE(l_text, l_char, ' ');
           END IF;
       END LOOP;
    END IF;

    RETURN l_text;

END XXHA_WD_EMPLOYEE_SPEC_CHAR_FN;