--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_PRODUCT_TYPE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_PRODUCT_TYPE" (p_item_id in number) return varchar2
as 
p_output varchar2 (240);
begin
  select substr(ca.description,instr(ca.description,'.',1,1) + 1,instr(ca.description,'.',1,2) - (instr(ca.description,'.',1,1) + 1))
  into   p_output
  from mtl_system_items_b i inner join mtl_item_categories ic
  on i.inventory_item_id = ic.inventory_item_id
  and i.organization_id = ic.organization_id 
  inner join mtl_categories ca
  on ic.category_id = ca.category_id
  and category_set_id = 1
  where i.organization_id = 103
  --and i.enabled_flag = 'Y'
  --and i.start_date_active is not null
  and ca.disable_date is null
  and i.inventory_item_id = p_item_id;
  return nvl(p_output, 'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_GET_PRODUCT_TYPE;

/
