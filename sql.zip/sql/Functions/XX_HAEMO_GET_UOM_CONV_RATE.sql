--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_UOM_CONV_RATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_UOM_CONV_RATE" (p_item_id in number, p_uom in varchar) return number as 
p_output NUMBER;

begin 
      select conversion_rate
      into p_output
      from mtl_uom_conversions
      where inventory_item_id = p_item_id
      and uom_code = p_uom
      and disable_date is null or trunc(disable_date) > = trunc(sysdate);
      return nvl((p_output),0);

exception 
      when others then
      p_output := 0;
      return nvl((p_output),0);
end XX_HAEMO_Get_UOM_Conv_Rate;

/
