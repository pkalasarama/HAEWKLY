CREATE OR REPLACE 
FUNCTION XXHA_REMOVE_SPECIAL_CHAR_FNC(P_TEXT VARCHAR2, P_NAME VARCHAR2) 
RETURN VARCHAR2 IS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_REMOVE_SPECIAL_CHAR_FNC
 * Description:  This function will
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      12-SEP-2014     Initial Function Creation
 * BMarcoux        2.0      15-JAN-2015     Remove processing specific to Preferred Name.  Preferred Name will be processed the same
 *                                            was a First and Last Names.
 *
 **********************************************************************************************************************************/

    l_text                        VARCHAR2 (250)     := NULL;
    l_char                        VARCHAR2 (3 byte)  := NULL;
    i                             INTEGER            := 0;

BEGIN

    -- Set variable to input text
    l_text := p_text;

    -- If input text is 'Preferred Name' and contains more than one name, take up to the last character before the occurence of the space
    --IF P_NAME = 'P' THEN
    --   IF  l_text LIKE '% %' THEN
    --       l_text := SUBSTR(l_text, 1, INSTR(l_text,' ',1,1)-1);
    --   END IF;
    --END IF;

    -- If input text contains a parenthesis or space with parenthesis, take up to the special characters.
    IF  l_text LIKE '% (%' THEN
        l_text := SUBSTR(l_text, 1, INSTR(l_text,' (',1,1)-1);
    ELSIF  p_text LIKE '%(%' THEN
        l_text := SUBSTR(l_text, 1, INSTR(l_text,'(',1,1)-1);
    ELSE
        l_text := l_text;
    END IF;

    -- If input text has more than one name in it and it contains a space, hyphen, comma, apostrophe or period the character will be removed
    l_text := REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(l_text,' ',''),'-',''),',',''),'''',''),'.','');

    -- Replace special characters (regular characters are ASCII BETWEEN 48 AND 122 and space is ASCII 32)
    IF LENGTH(l_text) > 0 THEN
       FOR i IN 1..LENGTH(l_text) 
       LOOP
           l_char := SUBSTR((l_text),i,1);
           IF (ASCII (l_char) NOT BETWEEN 48 AND 122) AND (ASCII (l_char) != 32) THEN
              l_text := REPLACE(l_text, l_char, XXHA_RTV_ASCII_CHAR_FNC(l_char));
           END IF;
       END LOOP;
    END IF;

    RETURN l_text;

END XXHA_REMOVE_SPECIAL_CHAR_FNC;