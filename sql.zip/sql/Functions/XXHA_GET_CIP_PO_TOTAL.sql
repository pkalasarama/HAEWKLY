--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_GET_CIP_PO_TOTAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_GET_CIP_PO_TOTAL" (p_cer_number varchar2) return number is
/*****************************************************************************************
* Name/Purpose : XXHA_CIP_ANALYSIS_FUNC.sql                                              *
* Description  : creates                                                                 *
*                procedure xxha_get_cip_po_total                                         *
*                Return PO Amount for Open POs for a CER_NUMBER or                       *
*                Invoice Amounts for Closed                                              *
* Date           Author                      Description                                 *
* -----------    -----------------           ---------------                             *
* 04-DEC-2013    Manuel Fernandes            Initial Creation                            *
******************************************************************************************/
v_amount number := 0;
begin
  SELECT sum(
     DECODE ( PHA11.CLOSED_CODE, 'CLOSED',(SELECT NVL(SUM(I.AMOUNT),0)
                                          FROM AP_INVOICE_DISTRIBUTIONS_ALL I 
                                                   ,PO_DISTRIBUTIONS_ALL D
                                          WHERE I.PO_DISTRIBUTION_ID = D.PO_DISTRIBUTION_ID
                                              AND I.LINE_TYPE_LOOKUP_CODE = 'ITEM'
                                              AND D.PO_HEADER_ID = PHA11.PO_HEADER_ID ), 
              'FINALLY CLOSED', (SELECT NVL(SUM(I.AMOUNT),0)
                                            FROM AP_INVOICE_DISTRIBUTIONS_ALL I 
                                                     ,PO_DISTRIBUTIONS_ALL D
                                            WHERE I.PO_DISTRIBUTION_ID = D.PO_DISTRIBUTION_ID
                                                AND I.LINE_TYPE_LOOKUP_CODE = 'ITEM'
                                                AND D.PO_HEADER_ID = PHA11.PO_HEADER_ID ),
          'CANCELLED', (SELECT NVL(SUM(I.AMOUNT),0)
          FROM AP_INVOICE_DISTRIBUTIONS_ALL I 
                   ,PO_DISTRIBUTIONS_ALL D
          WHERE I.PO_DISTRIBUTION_ID = D.PO_DISTRIBUTION_ID
              AND I.LINE_TYPE_LOOKUP_CODE = 'ITEM'
              AND D.PO_HEADER_ID = PHA11.PO_HEADER_ID ),  (select (sum(PLA1.QUANTITY*PLA1.UNIT_PRICE)) from po_lines_all pla1 where pla1.po_header_id = pha11.po_header_id))) AMOUNT
 INTO v_amount
 FROM 
    PO.PO_HEADERS_ALL PHA11
WHERE 1=1
  AND PHA11.PO_header_id in
    (
    select PLA.PO_HEADER_ID from PO.PO_REQUISITION_LINES_ALL PRLA, PO.PO_LINE_LOCATIONS_ALL PLLA, PO.PO_LINES_ALL PLA, HAEMO.XXHA_CIP_DATA cip11
     where prla.LINE_LOCATION_ID = plla. line_location_id
     and   plla.po_line_id = pla.po_line_id
     and   pla.po_header_id = pha11.po_header_id
     AND PRLA.CLOSED_CODE IS NULL
     AND (PRLA.CANCEL_FLAG = 'N' OR PRLA.CANCEL_FLAG IS NULL)
     AND PRLA.REQUISITION_HEADER_ID =cip11.REQUISITION_HEADER_ID
     AND CER_NUMBER = p_cer_number);
     return v_amount;
exception when no_data_found then
    return null;
end;

/
