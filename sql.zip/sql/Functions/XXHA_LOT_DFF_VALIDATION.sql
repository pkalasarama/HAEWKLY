
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_LOT_DFF_VALIDATION" (
    p_lot_number VARCHAR2,
    p_organization_id   NUMBER,
    p_inventory_item_id NUMBER)
  RETURN NUMBER
 /*****************************************************************************************
    * Name/Purpose : XXHA_LOT_DFF_VALIDATION                                                  *
    *                Lot DFF Validation          *
    * Date         Author             Description                                            *
    * -----------  -----------------  ---------------                                        *
    * 25-MAR-2015  Vijay Medikonda    Lot DFF Validation            *
    *                                                                                        *
    *****************************************************************************************/
  
AS
  l_count  NUMBER;
  l_number NUMBER:=0;
  l_exp_count number;
BEGIN
  SELECT COUNT(1)
  INTO l_count
  FROM XXHA_COM_PICK_EXCEP
  WHERE item_id=p_inventory_item_id
  --AND TRUNC(SYSDATE) BETWEEN TRUNC(DATE_FROM) AND NVL(TRUNC(DATE_TO),TRUNC(SYSDATE+1))
  AND SYSDATE BETWEEN DATE_FROM AND NVL(DATE_TO,SYSDATE+1);
  IF l_count!=0 THEN
    SELECT COUNT(1)
    INTO l_exp_count
    FROM --MTL_RSV_QUANTITIES_TEMP T,
      MTL_LOT_NUMBERS V,
      XXHA_COM_PICK_EXCEP A
    WHERE 1                   =1
    AND A.ITEM_ID             = V.INVENTORY_ITEM_ID
    AND UPPER(V.C_ATTRIBUTE4) = UPPER(A.COUNTRY_OF_ORIGIN)
    AND v.LOT_NUMBER          = p_lot_number
	--AND TRUNC(SYSDATE) BETWEEN TRUNC(A.DATE_FROM) AND NVL(TRUNC(A.DATE_TO),TRUNC(SYSDATE+1))
    AND SYSDATE BETWEEN A.DATE_FROM AND NVL(A.DATE_TO,SYSDATE+1)
    AND v.organization_id   = p_organization_id
    AND v.inventory_item_id = p_inventory_item_id;
    IF l_exp_count          =0 THEN
      l_number             :=1;
    ELSE
      l_number:=0;
    END IF;
  ELSE
    l_number:=0;
  END IF;
RETURN l_number;
END;
/