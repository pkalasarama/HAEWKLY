--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_MAX_EXTNDATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_MAX_EXTNDATE" (    P_PERSON_ID      NUMBER)
/* ###########################################################################*/
/*     HAEMONETICS                                                                                                                                                */
/*     File Name :       XX_HAEMO_GET_MAX_EXTNDATE.sql                                                                                       */
/*     Description  : This function takes in the Person_Id and return  back the max number of days his contract                */
/*                         can be extended                                                                                                                         */                                                                                                                                                               
/*     Date                 Created By Notes                                                                                                                     */
/*   -----------------------------------------                                                                                                                    */
/*    09/23/2013       Vijay Samba        Inital Creation                                                                                                 */
/*    02/21/2014       David Lund         Changed the number of days from 90 to 120                                                                                                */
/*                                                                                                                                                                          */
/* ###########################################################################*/    
    
    RETURN NUMBER
    IS
    v_maxnum_of_extn_days     NUMBER;
    BEGIN
    
     select ADD_MONTHS(MIN(EFFECTIVE_START_DATE ),9) - TRUNC(SYSDATE)
      INTO v_maxnum_of_extn_days
     from per_people_f 
     where PERSON_ID =P_PERSON_ID;
     
     If v_maxnum_of_extn_days <= 0
     THEN V_MAXNUM_OF_EXTN_DAYS := 0;
     ELSIF (v_maxnum_of_extn_days > 0 AND v_maxnum_of_extn_days <= 120)
         THEN 
          DBMS_OUTPUT.PUT_LINE('Retune back the original value ' ||v_maxnum_of_extn_days );
          
     ELSIF      V_MAXNUM_OF_EXTN_DAYS > 120
       THEN v_maxnum_of_extn_days := 120;
       
     END IF;
     
        -- Keeping the above logic as is but returning 90 always so that we can easily enable the logic of not being able to extend a contingent worker for more than 9 months from his start date.--Vijay Samba 11/15/2013
      v_maxnum_of_extn_days := 120;
     RETURN v_maxnum_of_extn_days;
     
     EXCEPTION
     WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE('ERROR IS '||SQLERRM);
     v_maxnum_of_extn_days :=0;
     RETURN v_maxnum_of_extn_days;
    END;

/
