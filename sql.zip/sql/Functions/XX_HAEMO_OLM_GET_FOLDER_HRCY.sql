--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_OLM_GET_FOLDER_HRCY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_OLM_GET_FOLDER_HRCY" (pvFolderId IN NUMBER) return varchar2 is
  lvFolder VARCHAR2(100):= NULL;
  lnParentId NUMBER := NULL;
  lvFolderList VARCHAR2(500) := NULL;
  lnTmpFolderId NUMBER := pvFolderId;
begin
  WHILE TRUE LOOP
    BEGIN
      select name, nvl( parent_folder_id,-1) 
        into lvFolder, lnParentId
        from ota_lo_folders 
       where folder_id = lnTmpFolderId;
--         and parent_folder_id IS NOT NULL;
       
       lnTmpFolderId := lnParentId;

      IF nvl(lnParentId,-1) = -1 THEN
         lvFolderList := lvFolderList || lvFolder ;
         RETURN lvFolderList; 
      ELSE
         lvFolderList := lvFolderList || lvFolder || '>' ;
         lvFolder := NULL;
         lnParentId := NULL;
      END IF;
               
    EXCEPTION
      WHEN OTHERS THEN
        IF lvFolderList IS NULL THEN
         lvFolderList := 'Error finding folderlist';
        END IF; 
         RETURN lvFolderList;
    END;
  END LOOP;  
  return lvFolderList;
end XX_HAEMO_OLM_GET_FOLDER_HRCY;

/
