CREATE OR REPLACE FUNCTION "APPS"."XXHA_PROD_DB" 
  /* ******************************************************************************************************
  * Object Name: XXHA_PROD_DB
  * Object Type: FUNCTION
  *
  * Description: This function will return if instance is Prod or non prod
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    16-JAN-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
   RETURN VARCHAR2
AS
   --
   l_prof_inst_name   VARCHAR2 (400);
   l_database         VARCHAR2 (400);
--
BEGIN
   SELECT NAME INTO l_database FROM v$database;
   
   IF l_database = 'HAEPRD'
   THEN
      RETURN 'Y';
   ELSE
      RETURN 'N';
   end if;
end;
/