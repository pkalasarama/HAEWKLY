
CREATE OR REPLACE FUNCTION "APPS"."XXHA_CUST_NAME" (P_CUSTOMER_ID number, p_consignee_flag VARCHAR2)
    /* ******************************************************************************************************
    * Object Name: XXHA_CUST_NAME
    * Object Type: FUNCTION
    *
    * Description: This function is used in Custom BOL report to get Customer Name
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JUN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/

return varchar2
is
L_CUST_NAME varchar2(50);
l_consignee_flag VARCHAR2(1);
lp_consignee_flag VARCHAR2(1);
begin
  IF p_consignee_flag IS NULL THEN 
   lp_consignee_flag := 'C';
   ELSE
   lp_consignee_flag := p_consignee_flag;
  END IF; 
  
  select PARTY_NAME, consignee_flag 
  INTO L_CUST_NAME , l_consignee_flag
  from 
   (SELECT party.party_name,
      cust_acct.cust_account_id,
      'C' consignee_flag
    FROM hz_parties party,
      hz_cust_accounts cust_acct
    where CUST_ACCT.PARTY_ID = PARTY.PARTY_ID
    and CUST_ACCT.CUST_ACCOUNT_ID = P_CUSTOMER_ID
    UNION
    SELECT party.party_name,
      PV.VENDOR_ID CUST_ACCOUNT_ID,
      'V' consignee_flag
    FROM hz_parties party,
      po_vendors pv
    where PV.PARTY_ID = PARTY.PARTY_ID
    and PV.VENDOR_ID = P_CUSTOMER_ID
    ) where CONSIGNEE_FLAG = lp_consignee_flag;

dbms_output.put_line('L_CUST_NAME: '||L_CUST_NAME);		
return L_CUST_NAME;
exception when others then
return null;
end;
/