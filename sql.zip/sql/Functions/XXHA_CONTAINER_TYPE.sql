
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_CONTAINER_TYPE" (p_inventory_item_id number, p_organization_id number, p_container_item_flag varchar2, p_REQUESTED_QUANTITY number)
    /* ******************************************************************************************************
    * Object Name: XXHA_CONTAINER_TYPE
    * Object Type: FUNCTION
    *
    * Description: This function is used in Custom BOL report to get container type
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JUN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/

  return varchar2
is
L_CONTAINER_TYPE_CODE varchar2(50);
begin
select msib_nc.CONTAINER_TYPE_CODE into L_CONTAINER_TYPE_CODE
from mtl_system_items_b msib_nc, wsh_container_items wci
where 	1=1
	  AND wci.load_item_id           = p_inventory_item_id
	  AND wci.master_organization_id = p_organization_id 
	  and WCI.CONTAINER_ITEM_ID      = MSIB_NC.INVENTORY_ITEM_ID(+)
	  AND wci.master_organization_id = msib_nc.organization_id(+)
	  AND DECODE(p_container_item_flag,'N',wci.max_load_quantity,0) = DECODE(p_container_item_flag,'N',
		(SELECT MIN(inn.max_load_quantity)
		FROM wsh_container_items inn
		WHERE  inn.load_item_id = Wci.Load_Item_Id
		and inn.max_load_quantity >= NVL(p_requested_quantity,0)
		),0);
dbms_output.put_line('L_CONTAINER_TYPE_CODE: '||L_CONTAINER_TYPE_CODE);		
return L_CONTAINER_TYPE_CODE;
exception when others then
return null;
end;
/