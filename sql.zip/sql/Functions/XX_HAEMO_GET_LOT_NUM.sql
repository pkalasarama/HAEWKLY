--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_LOT_NUM
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_LOT_NUM" (p_org_id IN NUMBER, p_trans_id IN NUMBER) return VARCHAR2 as 
p_output VARCHAR2(200);

begin 
      select lot_number
      into p_output
      from mtl_transaction_lot_val_v
      where organization_id = p_org_id
      and transaction_id = p_trans_id;
      return nvl((p_output),'N/A');

exception 
      when others then
      p_output := 'N/A';
      return nvl((p_output),'N/A');
end XX_HAEMO_Get_Lot_Num;

/
