create or replace FUNCTION XXHA_DETERMINE_EC_MEMBER (p_person_id IN NUMBER)
RETURN NUMBER
AS

/**********************************************************************************************************************************
*
* Function:     XXHA_DETERMINE_EC_MEMBER
* Description:  This function will determine the EC Member an employee is associated with
* Notes:
*
* Modified:       Ver      Date            Modification
*-------------    -----    -----------     ----------------------------------------------------------------------------------------
* BMarcoux        1.0      17-SEP-2013     Initial Function Creation
*                                          Person_id: 18668 = BOD (Board of Directors)
*                                          Person_id: 536   = CEO (Brian Concannon)
*                                          Person_id: 6865  = CEO Executive Assistant (Bryanne Salmon)
* BMarcoux        2.0      05-FEB-2014     Update function for new EC Members
* BMarcoux        3.0      15-MAY-2014     Update function to determine EC Members dynamically
* DKantem         4.0      18-MAY-2015     Update the function to determine the EC members based on HAE_LEADERSHIP_ROLE (Incident #INC0051381)
* BMarcoux        5.0      03-NOV-2015     Change CEO from Brian Concannon (536) to Ron Gelbman (51122)
* BMarcoux        6.0      25-OCT-2016     Modification for EC Member calculation
**********************************************************************************************************************************/

l_EC_MEMBER     per_assignments_x.person_id%TYPE     := NULL;
l_person_id     per_assignments_x.person_id%TYPE     := NULL;
l_person_id_x   per_assignments_x.person_id%TYPE     := NULL;

BEGIN

   l_person_id := p_person_id;

   -- Call Function to determine EC Member
   l_EC_MEMBER := APPS.XXHA_DETERMINE_EC_MBR(p_person_id);

   -- IF EC_MEMBER is the same as p_person_id then we have an EC Member so roll up one
   IF l_EC_MEMBER = l_person_id THEN
      SELECT supervisor_id
        INTO l_person_id_x
        FROM apps.per_all_assignments_f papf
       WHERE papf.person_id = l_EC_MEMBER
         AND to_date(sysdate) BETWEEN papf.effective_start_date AND NVL(papf.effective_end_date,sysdate);
      RETURN l_person_id_x;
   ELSE
      RETURN l_EC_MEMBER;
   END IF;

END XXHA_DETERMINE_EC_MEMBER;