--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_ASP
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_ASP" (p_sales_rev IN NUMBER, p_sales_qty IN NUMBER) return number as 
p_output number;

begin 
      select (p_sales_rev/p_sales_qty)
      into p_output
      from dual;
      return nvl((p_output),0);

exception
  when others then
  p_output := 0;
  return nvl((p_output),0);
end XX_HAEMO_Get_ASP;

/
