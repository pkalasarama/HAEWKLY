--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_PAST_WORKING_DATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_PAST_WORKING_DATE" (p_date date, p_num_of_days number)
return date
is
lp_date date;
begin
	 select calendar_date
	 into   lp_date
	 from   (select *
	  	     from   (select *
	  	             from   bom_calendar_dates
				     where  calendar_date <= trunc(p_date)
				   	 	    and seq_num is not null
				   		    and rownum <= 60
				     order by calendar_date desc)
	  	     order by calendar_date asc)
	 where   rownum = 1;
	 return lp_date;
exception
		 when others then
		 	  lp_date := null;
			  return lp_date;
end XX_HAEMO_GET_PAST_WORKING_DATE;

/
