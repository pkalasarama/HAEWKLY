--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_CUST_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_CUST_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select lookup_code
		into   lp_attr_val
		from   ar_lookups
		where  lookup_code = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE2' then
	 	select customer_name
		into   lp_attr_val
		from   qp_customers_v
		where  TO_CHAR(customer_id) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE5' then
	 	select party.party_name
		into   lp_attr_val
		from   hz_cust_acct_sites_all acct
			   , hz_cust_site_uses_all site
			   , hz_locations loc
			   , hz_parties party
			   , hz_party_sites party_site
			   , ar_lookups al
		where  party.party_id = party_site.party_id
			   and party_site.location_id = loc.location_id
			   and acct.party_site_id = party_site.party_site_id
			   and site.cust_acct_site_id = acct.cust_acct_site_id
			   and site.site_use_code = al.lookup_code
			   and al.lookup_type = 'SITE_USE_CODE'
			   and site.status  = 'A'
			   and TO_CHAR(site.site_use_id) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE7' then
	 	select name
		into   lp_attr_val
		from   OE_AGREEMENTS
		where  TO_CHAR(AGREEMENT_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE8' then
	 	select lookup_code
		into   lp_attr_val
		from   qp_lookups
		where  lookup_code = p_attr_val
			   and lookup_type = 'QP_AGREEMENT_TYPE';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE11' then
	 	select CUSTOMER_NAME
		into   lp_attr_val
		from   QP_SHIP_TO_ORGS_V
		where  TO_CHAR(ORGANIZATION_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE12' then
	 	select NAME
		into   lp_attr_val
		from   HZ_CUST_PROFILE_CLASSES
		where  TO_CHAR(PROFILE_CLASS_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE13' then
	 	select LOOKUP_CODE
		into   lp_attr_val
		from   OE_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'SALES_CHANNEL';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE14' then
	 	select substrb(party.PARTY_NAME,1,50)||' '||oito.name
		into   lp_attr_val
		from   oe_invoice_to_orgs_v oito
			   , hz_cust_accounts cust_acct
			   , hz_parties party
		where  TO_CHAR(oito.organization_id) = p_attr_val
			   and cust_acct.PARTY_ID = party.PARTY_ID
			   AND oito.CUSTOMER_ID = cust_acct.CUST_ACCOUNT_ID;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE15' then
	 	select MEANING
		into   lp_attr_val
		from   FND_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'YES_NO';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE16' then
	 	select PARTY_NUMBER
		into   lp_attr_val
		from   HZ_PARTIES
		where  TO_CHAR(PARTY_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE17' then
	 	select b.party_site_number
		into   lp_attr_val
		from   HZ_PARTIES a
			   , HZ_PARTY_SITES b
			   , HZ_PARTY_SITE_USES c
			   , HZ_LOCATIONS d
		where  c.site_use_type = 'SHIP_TO'
			   AND c.party_site_id = b.party_site_id
			   AND b.party_id = a.party_id
			   AND d.location_id = b.location_id
			   AND TO_CHAR(b.party_site_id) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE18' then
	 	select b.party_site_number
		into   lp_attr_val
		from   HZ_PARTIES a
			   , HZ_PARTY_SITES b
			   , HZ_PARTY_SITE_USES c
			   , HZ_LOCATIONS d
		where  c.site_use_type = 'BILL_TO'
			   AND c.party_site_id = b.party_site_id
			   AND b.party_id = a.party_id
			   AND d.location_id = b.location_id
			   AND TO_CHAR(b.party_site_id) = p_attr_val;
	  end if;
	  return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_CUST_QUAL_VAL;

/
