
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_LPN" (p_parent_delivery_detail_id number)
    /* ******************************************************************************************************
    * Object Name: XXHA_LPN
    * Object Type: FUNCTION
    *
    * Description: This function is used in Custom BOL report to get LPN
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JUN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/

  return varchar2
is
L_lpn varchar2(50);
begin
select NVL(lpn.license_plate_number,lpn_parent.license_plate_number) license_plate_number into L_lpn
from 		apps.wsh_delivery_details wda_parent ,
		wms_license_plate_numbers lpn_parent,
		(SELECT wda1.delivery_detail_id,
		  wlp.license_plate_number
		FROM wsh_delivery_assignments wda1,
		  wsh_delivery_details wdd1,
		  wms_license_plate_numbers wlp
		WHERE 1                           =1
		AND wda1.parent_delivery_detail_id=wdd1.delivery_detail_id
		AND wdd1.lpn_id                   =wlp.lpn_id
		) lpn
where 	1=1
 AND wda_parent.delivery_detail_id(+) = p_parent_delivery_detail_id
 AND wda_parent.lpn_id                = lpn_parent.lpn_id(+)
 AND wda_parent.delivery_detail_id    = lpn.delivery_detail_id(+);
dbms_output.put_line('L_lpn: '||L_lpn);		
return L_lpn;
exception when others then
return null;
end;
/