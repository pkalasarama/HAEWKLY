--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_MATERIAL_CERT_ISDATE_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_MATERIAL_CERT_ISDATE_FNC" 
(
    p_date              IN VARCHAR2
)
RETURN VARCHAR2 IS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_MATERIAL_CERT_ISDATE
 * Description:  This function will return the value in date form if it's a date field
 * Notes:
 *
 * Modified:     Ver    Date         Modification
 *-------------  -----  -----------  ----------------------------------------------------------------------------------------------
 * BMarcoux      1.0    18-MAR-2014  Initial Function Creation
 *
 **********************************************************************************************************************************/

BEGIN

    RETURN to_char(to_date(p_date,'YYYY/MM/DD'), 'DD-MON-YY');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
             RETURN p_date;
        WHEN OTHERS THEN
             RETURN p_date;

END XXHA_MATERIAL_CERT_ISDATE_FNC;

/
