--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_INV_ADJ_ACCT_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_INV_ADJ_ACCT_FNC" (p_org number)
return number
is
    l_acct_id   number := 0;
    l_acct_seg  varchar2(250);
begin
    begin
        select a.segment1||'.'||
               a.segment2||'.'||
               a.segment3||'.'||
               a.segment4||'.'||
               a.segment5||'.'||
               '133330'  ||'.'||
               a.segment7||'.'||
               a.segment8||'.'||
               a.segment9
         into  l_acct_seg
         from gl_code_combinations_kfv a,
              mtl_parameters b
        where b.organization_id = p_org
          and a.code_combination_id = b.material_account;
    exception
    when others
    then
        l_acct_seg := 'XYZ';
    end;

    if nvl(l_acct_seg,'XYZ') <> 'XYZ' then
        begin
            select code_combination_id
             into  l_acct_id
             from gl_code_combinations_kfv
            where concatenated_segments = l_acct_seg;
        exception
        when others
        then
            l_acct_id  := -1;
        end;
    else
        l_acct_id  := -1;
    end if;

   return l_acct_id;

exception
when others
then
    return -1;
end;

/
