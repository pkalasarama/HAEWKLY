--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_GL_PERIOD
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_GL_PERIOD" (p_date in DATE) return VARCHAR2 as 
p_output VARCHAR2 (100);

begin 
      select period_name
      into p_output
      from gl_periods
      where trunc(p_date) between trunc(start_date) and trunc(end_date)
      and period_set_name = 'HAE_GLOBAL_CAL'
      and period_type = '21';
      return nvl((p_output),'N/A');

exception 
      when others then
      p_output := 'N/A';
      return nvl((p_output),'N/A');
end XX_HAEMO_Get_Gl_Period;

/
