--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_BSA_XML
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_BSA_XML" (p_id IN NUMBER, p_rec_type IN  VARCHAR2) RETURN VARCHAR2 IS

/*Created BY Centium ON 26th April 2010 FOR Blanket SALES Agreement XML publisher Report customization
  This function is called from Java Extension Class HaeBSAPrintXML.class*/

/*********************************************************************************************************************************************************
 *
 * $Header: XXHA_BSA_XML.sql 05-11-2010.11:00:00 Nandu Vellal Exp $
 *
 * HAEMONETICS
 *
 * File Name:    XXHA_BSA_XML.sql
 * Author:       Nandu Vellal
 * Original:     05-11-2010
 * Function:     XXHA_BSA_XML
 * Description:  This Script will compile the function which builds XML Elements for BSA Reports
 *
 * Notes:
 *
 * Modified:      Ver     Date              Modification
 *-------------   -----   ----------        ---------------------------------------------------------------------------------------------------------------
 * Nandu Vellal           05-11-2010        Initial Function Creation
 * Nandu Vellal           05-21-2010        Modified - Changes related to NA Consumable Grouping Logic
 * Nandu Vellal           05-26-2010        Modified - Changes to pricing start date and end date logic
 * Nandu Vellal           06-10-2010        Modified - Changes to Equipment Type and Quantity Cursor
 *                                                   - Initcap on city of ship to cust and legal cust
 *                                                   - Secondary Pricelist changed query for performance issue
 * Nandu Vellal           06-18-2010        Modified - Changes to show Commitment Short Text
 * Nandu Vellal           06-29-2010        Modified - Introduced New element called <BlanketType>
 * Nandu Vellal           07-09-2010        Modified - Removed rounding of annual commitment (for 'Duration of Agreement')
 * BMarcoux       V1.00   01-07-2011        Modified - Added processing to determine Item Description based upon Customer Language ('Legal' Address)
 *                                                     Incident# 69342
 * BMarcoux       V2.00   11-01-2011        Modified - Removed views RA_Customers, RA_Addresses_All and RA_Site_Uses_All
 * BMarcoux       V3.00   11-02-2011        Modified - Processing to NA Blanket Sales Agreements
 * BMarcoux       V4.00   02-10-2012        Modified - Correction to processing for EU data.  Removed code that checked 'prod_subtype_desc' for BOWL and NONBOWL.
 *                V4.01                                Added rounding when calculating 'ln_total_commit'.
 *
 ********************************************************************************************************************************************************/

--------------------------------------------------------------------------------
-- cur_cat
CURSOR cur_cat(c_line_id NUMBER) IS
SELECT
       obl.line_id line_id,
       obl.header_id header_id,
       obh.price_list_id,
       obl.activation_date,
       e.inventory_item_id,
       e.segment1 mtl_item_number,
       obl.ordered_item item_number,
       TO_CHAR(0, 'L') curr,
       replace(msit.description,'&',' and ') item_description,
/*     msit.description item_description,  */
/*     substr(msit.description, 1, instr(msit.description, '&')) || substr(msit.description, instr(msit.description,'&') + 1, (LENGTH(msit.description))) item_description, */
/*     substr(msit.description, 1, instr(msit.description, '&')) item_description, */
       g.segment1||' '||g.segment2||' '||g.segment3 category_segments,
       g.segment1 prod_line,
       ffvt1.description prod_line_desc,
       g.segment2 prod_type,
       ffvt2.description prod_type_desc,
--     DECODE(ffvt2.description , 'Equipment', DECODE(ffvt3.description, 'Accessory', ffvt2.description||' ', ffvt2.description), ffvt2.description)  prod_type_desc,
       g.segment3 prod_subtype,
       ffvt3.description prod_subtype_desc,
       DECODE(UPPER(g.segment3), 'BOWL', 'BOWL', 'NONBOWL') Bowl_Nonbowl,
       g.segment4 platform,
       ffvt4.description platform_desc,
       g.structure_id,
       f.category_set_id,
       e.item_type,
       e.organization_id,
       NVL(obl.blanket_min_quantity, obl.blanket_max_quantity) blanket_min_quantity,
       obl.blanket_max_quantity,
       obll.attribute1 Recovery_fee,
       obll.attribute2 Interest,
       obll.attribute3 Maintenance_fee
/* New Code to retrieve DFF's                                                 */
/* V3.00                                                                      */
     , obll.Attribute4             owned_systems          -- Number of Owned Systems DFF
     , obll.Attribute5             nonowned_systems       -- Number of Non-Owned Systems DFF
     , obll.Attribute6             util_rate              -- Target Annual Utilization Rate DFF
     , obh.Attribute6              agreement_duration     -- Agreement Duration (#months) DFF

  FROM
       oe_blktprt_lines_v          obl,
       oe_blanket_lines_all        obll,
       mtl_system_items_b          e,
       mtl_system_items_tl         msit,
       mtl_item_categories         f,
       mtl_categories_b            g,
       fnd_flex_value_sets         ffvs1,
       fnd_flex_values             ffv1,
       fnd_flex_values_tl          ffvt1,
       fnd_flex_value_sets         ffvs2,
       fnd_flex_values             ffv2,
       fnd_flex_values_tl          ffvt2,
       fnd_flex_value_sets         ffvs3,
       fnd_flex_values             ffv3,
       fnd_flex_values_tl          ffvt3,
       fnd_flex_value_sets         ffvs4,
       fnd_flex_values             ffv4,
       fnd_flex_values_tl          ffvt4,
       xdo_templates_b             xt,
       oe_blanket_headers_all      obh,
       oe_transaction_types_all    ott
 WHERE
       obl.inventory_item_id     = e.inventory_item_id
   AND e.inventory_item_id       = f.inventory_item_id
   AND e.organization_id         = f.organization_id
   AND msit.inventory_item_id    = e.inventory_item_id
   AND msit.organization_id      = e.organization_id
   AND obl.header_id             = obh.header_id
   AND obh.order_type_id         = ott.transaction_type_id
   AND ott.layout_template_id    = xt.template_id
-- AND DECODE(xt.default_territory, '00', 'US') = msit.language
-- AND msit.LANGUAGE = USERENV('LANG')
   AND msit.LANGUAGE             = DECODE(xt.default_language,
                                        'fr', 'F',
                                        'de', 'D',
                                        'ja', 'JA',
                                        'it', 'I',
                                        'en', 'US',
                                        'US')
   AND f.category_id             = g.category_id
   AND f.category_set_id         = 1
   AND g.segment1                = ffv1.flex_value
   AND ffv1.flex_value_id        = ffvt1.flex_value_id
   AND ffvs1.flex_value_set_id   = ffv1.flex_value_set_id
   AND ffvs1.flex_value_set_name = 'HAE_PRODUCT_LINE_ITEM_CATEGORY'
   AND ffvt1.LANGUAGE            = 'US'--userenv('LANG')
   AND g.segment2                = ffv2.flex_value
   AND ffv2.flex_value_id        = ffvt2.flex_value_id
   AND ffvs2.flex_value_set_id   = ffv2.flex_value_set_id
   AND ffvs2.flex_value_set_name = 'HAE_PRODUCT_TYPE_ITEM_CATEGORY'
   AND ffvt2.LANGUAGE            = 'US'--userenv('LANG')
   AND g.segment3                = ffv3.flex_value
   AND ffv3.flex_value_id        = ffvt3.flex_value_id
   AND ffvs3.flex_value_set_id   = ffv3.flex_value_set_id
   AND ffvs3.flex_value_set_name = 'HAE_PRODUCT_SUBTYPE_ITEM_CATEGORY'
   AND ffvt3.LANGUAGE            = 'US'--userenv('LANG')
   AND g.segment4                = ffv4.flex_value
   AND ffv4.flex_value_id        = ffvt4.flex_value_id
   AND ffvs4.flex_value_set_id   = ffv4.flex_value_set_id
   AND ffvs4.flex_value_set_name = 'HAE_PLATFORM_ITEM_CATEGORY'
   AND ffvt4.LANGUAGE            = 'US'--userenv('LANG')
   AND g.structure_id            = 101
   AND e.organization_id         = 103
-- AND UPPER(e.segment1)         <> 'FREIGHT'
   AND obl.line_id               = c_line_id
   AND obl.line_id               = obll.line_id;

/* New Code to retrieve Item Description in the Customer's Language           */
/* V1.00                                                                      */
--------------------------------------------------------------------------------
-- cur_cust_item
CURSOR cur_cust_item(c_line_id NUMBER) IS
SELECT
       msit.description           cust_item_description,
-- V2.00 Obsolete Code - START
--     aav.language               cust_language,
--     DECODE(aav.language, 'F', 'F', 'D', 'D', 'JA', 'JA', 'I', 'I', 'US', 'US', 'US') cust_language_decode
-- V2.00 Obsolete Code - END
-- V2.00 New Code - START
       Loc.language               cust_language,
       DECODE(Loc.language, 'F', 'F', 'D', 'D', 'JA', 'JA', 'I', 'I', 'US', 'US', 'US') cust_language_decode
-- V2.00 New Code - END
  FROM
       oe_blktprt_lines_v         obl,
       oe_blanket_headers_all     obh,
       mtl_system_items_b         e,
       mtl_system_items_tl        msit,
       mtl_item_categories        f,
       mtl_categories_b           g,
       fnd_flex_value_sets        ffvs1,
       fnd_flex_values            ffv1,
       fnd_flex_values_tl         ffvt1,
       fnd_flex_value_sets        ffvs2,
       fnd_flex_values            ffv2,
       fnd_flex_values_tl         ffvt2,
       fnd_flex_value_sets        ffvs3,
       fnd_flex_values            ffv3,
       fnd_flex_values_tl         ffvt3,
       fnd_flex_value_sets        ffvs4,
       fnd_flex_values            ffv4,
       fnd_flex_values_tl         ffvt4,
       fnd_territories_tl         ftl,
-- V2.00 Obsolete Code - START
--     ra_customers               rc,
--     ra_addresses_all           aav,
--     ra_site_uses_all           rsu,
-- V2.00 Obsolete Code - END
-- V2.00 New Code - START
       hz_cust_accounts           cust,
       hz_cust_acct_sites_all     cas,      --acct_site
       hz_cust_site_uses_all      su,       --site_uses
       hz_party_sites             ps,       --party_site
       hz_locations               loc
-- V2.00 New Code - END
 WHERE
       obl.inventory_item_id      = e.inventory_item_id
   AND e.inventory_item_id        = f.inventory_item_id
   AND e.organization_id          = f.organization_id
   AND msit.inventory_item_id     = e.inventory_item_id
   AND msit.organization_id       = e.organization_id
   AND obh.header_id              = obl.header_id
   AND f.category_id              = g.category_id
   AND f.category_set_id          = 1
   AND g.segment1                 = ffv1.flex_value
   AND ffv1.flex_value_id         = ffvt1.flex_value_id
   AND ffvs1.flex_value_set_id    = ffv1.flex_value_set_id
   AND ffvs1.flex_value_set_name  = 'HAE_PRODUCT_LINE_ITEM_CATEGORY'
   AND ffvt1.LANGUAGE             = 'US'--userenv('LANG')
   AND g.segment2                 = ffv2.flex_value
   AND ffv2.flex_value_id         = ffvt2.flex_value_id
   AND ffvs2.flex_value_set_id    = ffv2.flex_value_set_id
   AND ffvs2.flex_value_set_name  = 'HAE_PRODUCT_TYPE_ITEM_CATEGORY'
   AND ffvt2.LANGUAGE             = 'US'--userenv('LANG')
   AND g.segment3                 = ffv3.flex_value
   AND ffv3.flex_value_id         = ffvt3.flex_value_id
   AND ffvs3.flex_value_set_id    = ffv3.flex_value_set_id
   AND ffvs3.flex_value_set_name  = 'HAE_PRODUCT_SUBTYPE_ITEM_CATEGORY'
   AND ffvt3.LANGUAGE             = 'US'--userenv('LANG')
   AND g.segment4                 = ffv4.flex_value
   AND ffv4.flex_value_id         = ffvt4.flex_value_id
   AND ffvs4.flex_value_set_id    = ffv4.flex_value_set_id
   AND ffvs4.flex_value_set_name  = 'HAE_PLATFORM_ITEM_CATEGORY'
   AND ffvt4.LANGUAGE             = 'US'--userenv('LANG')
   AND g.structure_id             = 101
   AND e.organization_id          = 103
-- V2.00 Obsolete Code - START
-- AND obh.sold_to_org_id         = rc.customer_id
-- AND rc.customer_id             = aav.customer_id
-- AND aav.address_id             = rsu.address_id
-- AND UPPER(rsu.site_use_code)   = 'LEGAL'
-- AND aav.country                = ftl.territory_code
-- AND NVL(rsu.status, 'A')       = 'A'
-- AND ftl.LANGUAGE               = 'US'
-- AND msit.LANGUAGE              = DECODE(aav.language, 'F', 'F', 'D', 'D', 'JA', 'JA', 'I', 'I', 'US', 'US', 'US')
-- V2.00 Obsolete Code - END
-- V2.00 New Code - START
   AND obh.sold_to_org_id         = cust.CUST_ACCOUNT_ID
   AND cust.Cust_Account_ID       = cas.cust_account_ID
   AND cas.Cust_acct_site_ID      = su.cust_acct_site_ID
   AND UPPER(su.site_use_code)    = 'LEGAL'
   AND cas.Party_site_ID          = ps.party_site_ID
   AND ps.Location_ID             = loc.location_ID--(+)
   AND loc.country                = ftl.territory_code
   AND NVL(su.status, 'A')        = 'A'
   AND ftl.LANGUAGE               = 'US'
   AND msit.LANGUAGE              = DECODE(Loc.language, 'F', 'F', 'D', 'D', 'JA', 'JA', 'I', 'I', 'US', 'US', 'US')
-- V2.00 New Code - END
   AND obl.line_id                = c_line_id
   ;

/* New Code to retrieve Item Description in the Customer's Language           */
/* V1.00                                                                      */
/* Declare 'lv_cust_item_description'                                         */
 lv_cust_item_description    VARCHAR2(240);

--------------------------------------------------------------------------------
-- cur_catsegments
CURSOR cur_catsegments(c_header_id NUMBER, c_segments VARCHAR2) IS
SELECT
       mc.segment1||' '||mc.segment2||' '||mc.segment3 Category_Segments,
       COUNT(obl.inventory_item_id) cnt,
       SUM(NVL(oblv.Blanket_Min_Quantity, oblv.Blanket_Max_Quantity)) Total_Cons_Commit,
       SUM(TO_NUMBER(obl.attribute1) + TO_NUMBER(obl.attribute2) + TO_NUMBER(obl.attribute3)) Equipment_Fees
  FROM
       oe_blanket_lines_all      obl,
       oe_blktprt_lines_v        oblv,
       mtl_system_items_b        msi,
       mtl_system_items_tl       msit,
       mtl_item_categories       mic,
       mtl_categories_b          mc
 WHERE
       obl.inventory_item_id   = msi.inventory_item_id
   AND obl.line_id             = oblv.line_id
   AND msi.inventory_item_id   = mic.inventory_item_id
   AND msi.organization_id     = mic.organization_id
   AND msit.inventory_item_id  = msi.inventory_item_id
   AND msit.organization_id    = msi.organization_id
   AND mic.category_id         = mc.category_id
   AND mic.category_set_id     = 1
   AND mc.structure_id         = 101
   AND msi.organization_id     = 103
   AND obl.header_id           = c_header_id
   AND mc.segment1||' '||mc.segment2||' '||mc.segment3 = c_segments
   AND msit.LANGUAGE           = 'US'
 GROUP BY
       mc.segment1||' '||mc.segment2||' '||mc.segment3;

 lv_Category_Segments   VARCHAR2(100);
 ln_cat_cnt             NUMBER;
 ln_total_cons_commit   NUMBER;
 ln_equipment_fees      NUMBER;

 lv_catsegments         cur_catsegments%ROWTYPE;

--------------------------------------------------------------------------------
-- cur_head
CURSOR cur_head(c_head_id NUMBER) IS
SELECT
       otl.variable_name,
       otl.variable_value
FROM
       okc_terms_local_var_v OTL
WHERE
       otl.document_id    = c_head_id
AND    otl.variable_value IS NOT NULL;

--------------------------------------------------------------------------------
-- cur_head_text
CURSOR cur_head_text(c_head_id_text NUMBER) IS
SELECT
       fdst.SHORT_TEXT            shorttext_value
FROM
       FND_DOCUMENTS_SHORT_TEXT   FDST,
       fnd_documents_VL           fdv,
       fnd_attached_documents     fad,
       fnd_document_categories_tl fdct,
       oe_blanket_headers_ALL     obh,
       oe_blanket_headers_ext     obhe
WHERE
       fdst.MEDIA_ID            = fdv.MEDIA_ID
AND    fad.DOCUMENT_ID          = fdv.DOCUMENT_ID
AND    fad.category_id          = fdct.category_id
AND    fdct.LANGUAGE            = 'US'
AND    TO_CHAR(obh.HEADER_ID)   = fad.PK1_VALUE
AND    obhe.order_number        = obh.order_number
AND    FDCT.user_name           = 'Printed Documents'
AND    fad.PK1_VALUE            = TO_CHAR(c_head_id_text);

--------------------------------------------------------------------------------
-- cur_cons_shorttext
CURSOR cur_cons_shorttext(c_head_id_text NUMBER) IS
SELECT
       fdst.SHORT_TEXT  Consumables_ST_value,
       fad.seq_num seq_num,
       fdv.datatype_name datatype,
       fdct.user_name category
FROM
       FND_DOCUMENTS_SHORT_TEXT   FDST,
       fnd_documents_VL           fdv,
       fnd_attached_documents     fad,
       fnd_document_categories_tl fdct,
       oe_blanket_headers_ALL     obh,
       oe_blanket_headers_ext     obhe
WHERE
       fdst.MEDIA_ID            = fdv.MEDIA_ID
AND    fad.DOCUMENT_ID          = fdv.DOCUMENT_ID
AND    fad.category_id          = fdct.category_id
AND    fdct.LANGUAGE            = 'US'
AND    TO_CHAR(obh.HEADER_ID)   = fad.PK1_VALUE
AND    obhe.order_number        = obh.order_number
AND    FDCT.user_name           = 'Consumable Text'
AND    fad.PK1_VALUE            = TO_CHAR(c_head_id_text);

 lv_cons_shorttext cur_cons_shorttext%ROWTYPE;

--------------------------------------------------------------------------------
-- cur_equip_shorttext
CURSOR cur_equip_shorttext(c_head_id_text NUMBER) IS
SELECT
       fdst.SHORT_TEXT  equipment_ST_value,
       fad.seq_num seq_num,
       fdv.datatype_name datatype,
       fdct.user_name category
FROM
       FND_DOCUMENTS_SHORT_TEXT   FDST,
       fnd_documents_VL           fdv,
       fnd_attached_documents     fad,
       fnd_document_categories_tl fdct,
       oe_blanket_headers_ALL     obh,
       oe_blanket_headers_ext     obhe
WHERE
       fdst.MEDIA_ID            = fdv.MEDIA_ID
AND    fad.DOCUMENT_ID          = fdv.DOCUMENT_ID
AND    fad.category_id          = fdct.category_id
AND    fdct.LANGUAGE            = 'US'
AND    TO_CHAR(obh.HEADER_ID)   = fad.PK1_VALUE
AND    obhe.order_number        = obh.order_number
AND    FDCT.user_name           = 'Equipment Text'
AND    fad.PK1_VALUE            = TO_CHAR(c_head_id_text);

 lv_equip_shorttext cur_equip_shorttext%ROWTYPE;

--------------------------------------------------------------------------------
-- cur_commit_shorttext
CURSOR cur_commit_shorttext(c_head_id_text NUMBER) IS
SELECT
       fdst.SHORT_TEXT  commit_ST_value,
       fad.seq_num seq_num,
       fdv.datatype_name datatype,
       fdct.user_name category
FROM
       FND_DOCUMENTS_SHORT_TEXT    FDST,
       fnd_documents_VL            fdv,
       fnd_attached_documents      fad,
       fnd_document_categories_tl  fdct,
       oe_blanket_headers_ALL      obh,
       oe_blanket_headers_ext      obhe
WHERE
       fdst.MEDIA_ID             = fdv.MEDIA_ID
AND    fad.DOCUMENT_ID           = fdv.DOCUMENT_ID
AND    fad.category_id           = fdct.category_id
AND    fdct.LANGUAGE             = 'US'
AND    TO_CHAR(obh.HEADER_ID)    = fad.PK1_VALUE
AND    obhe.order_number         = obh.order_number
AND    FDCT.user_name            = 'Commitment Text'
AND    fad.PK1_VALUE             = TO_CHAR(c_head_id_text);

 lv_commit_shorttext cur_commit_shorttext%ROWTYPE;

/* New Code to retrieve accessories shorttext                                 */
/* V3.00                                                                      */
--------------------------------------------------------------------------------
-- cur_access_shorttext
CURSOR cur_access_shorttext(c_head_id_text NUMBER) IS
SELECT
       fdst.SHORT_TEXT  access_ST_value,
       fad.seq_num seq_num,
       fdv.datatype_name datatype,
       fdct.user_name category
FROM
       FND_DOCUMENTS_SHORT_TEXT    FDST,
       fnd_documents_VL            fdv,
       fnd_attached_documents      fad,
       fnd_document_categories_tl  fdct,
       oe_blanket_headers_ALL      obh,
       oe_blanket_headers_ext      obhe
WHERE
       fdst.MEDIA_ID             = fdv.MEDIA_ID
AND    fad.DOCUMENT_ID           = fdv.DOCUMENT_ID
AND    fad.category_id           = fdct.category_id
AND    fdct.LANGUAGE             = 'US'
AND    TO_CHAR(obh.HEADER_ID)    = fad.PK1_VALUE
AND    obhe.order_number         = obh.order_number
AND    FDCT.user_name            = 'Accessories Text'
AND    fad.PK1_VALUE             = TO_CHAR(c_head_id_text);

 lv_access_shorttext cur_access_shorttext%ROWTYPE;

--------------------------------------------------------------------------------
-- cur_price_line
CURSOR cur_price_line(c_price_list_id     NUMBER,
                      c_inventory_item_id NUMBER,
                      c_activation_date   DATE) IS
SELECT /*+ index(d qp_list_headers_b_pk)
           index(b qp_list_lines_pk)
       index(c qp_pricing_attributes_pk) */
       LTRIM (RTRIM (b.operand)) price,
       a.list_header_id,
       c.pricing_attribute_id,
       NVL(b.start_date_active, d.start_date_active) Price_Start_Date,
       NVL(b.end_date_active, NVL(d.end_date_active, SYSDATE+1)) Price_End_Date
FROM
       qp_list_headers_b         d,
       qp_list_headers_tl        a,
       qp_list_lines             b,
       qp_pricing_attributes     c,
       mtl_system_items_b        e
WHERE
       a.list_header_id        = b.list_header_id
AND    d.list_header_id        = a.list_header_id
AND    b.list_line_id          = c.list_line_id
AND    b.list_header_id        = c.list_header_id
AND    e.inventory_item_id     = TO_NUMBER(c.product_attr_value)
AND    c_activation_date BETWEEN NVL(b.START_DATE_ACTIVE, d.START_DATE_ACTIVE)
                             AND NVL (b.end_date_active, SYSDATE + 1)
AND    e.organization_id       = 103
AND    a.LANGUAGE(+)           = USERENV ('LANG')
AND    d.list_header_id        = c_price_list_id
AND    e.inventory_item_id     = c_inventory_item_id
ORDER BY
       b.start_date_active DESC,
       d.start_date_active DESC;

--------------------------------------------------------------------------------
-- cur_price_line1  /*999G999D99*/
CURSOR cur_price_line1(c_price_list_id     NUMBER,
                       c_inventory_item_id NUMBER,
                       c_activation_date   DATE) IS
SELECT
       LTRIM (RTRIM (b.operand)) price,
       NVL(b.start_date_active, d.start_date_active) Price_Start_Date,
       NVL(b.end_date_active, d.end_date_active) Price_End_Date
FROM
       qp_list_headers_b          f,
       qp_secondary_price_lists_v d,
       qp_list_headers_tl         a,
       qp_list_lines_v            b,
       qp_pricing_attributes      c,
       mtl_system_items_b         e
WHERE
       a.list_header_id         = b.list_header_id
AND    d.list_header_id         = a.list_header_id
AND    b.list_line_id           = c.list_line_id
AND    b.list_header_id         = c.list_header_id
AND    e.inventory_item_id      = TO_NUMBER (c.product_attr_value)
AND    c_activation_date  BETWEEN NVL(b.START_DATE_ACTIVE, NVL(d.START_DATE_ACTIVE, SYSDATE))
                              AND NVL(b.end_date_active, NVL(d.end_date_active, SYSDATE + 1))
AND    e.organization_id        = 103
AND    a.LANGUAGE(+)            = USERENV ('LANG')
AND    d.parent_price_list_id   = c_price_list_id
AND    f.list_header_id         = d.list_header_id
AND    e.inventory_item_id      = c_inventory_item_id
AND    precedence IN(
       SELECT MIN(precedence)
         FROM  qp_secondary_price_lists_v         qps,
               qp_list_lines_v                    b1
        WHERE  qps.list_header_id               = b1.list_header_id
          AND  c_activation_date          BETWEEN NVL(b1.start_date_active, NVL(qps.start_date_active, SYSDATE))
          AND NVL(b1.end_date_active, NVL(qps.end_date_active, SYSDATE + 1))
          AND  TO_NUMBER(b1.product_attr_value) = c_inventory_item_id
          AND  qps.parent_price_list_id         = c_price_list_id)
ORDER BY
       b.start_date_active DESC,
       f.start_date_active DESC;

--------------------------------------------------------------------------------
-- cur_duration
CURSOR cur_duration(c_head_id_dur NUMBER) IS
SELECT variable_value
FROM   OKC_TERMS_LOCAL_VAR_V otl
WHERE  otl.variable_name   = 'Duration of Agreement'
AND    otl.document_id     = c_head_id_dur;

/* New Code to retrieve cur_agreement_duration                                */
/* V3.00                                                                      */
--------------------------------------------------------------------------------
-- cur_agreement_duration
CURSOR cur_agreement_duration(c_head_id NUMBER) IS
SELECT Attribute6
FROM   oe_blanket_headers_all    obh
WHERE  obh.header_id           = c_head_id;

lv_agreement_duration cur_agreement_duration%ROWTYPE;

--------------------------------------------------------------------------------
-- cur_utilization
CURSOR cur_utilization(c_head_id NUMBER) IS
SELECT variable_value
FROM   OKC_TERMS_LOCAL_VAR_V otl
WHERE  otl.variable_name   = 'Utilization Rate'
AND    otl.document_id     = c_head_id;

lv_utilization cur_utilization%ROWTYPE;

--------------------------------------------------------------------------------
-- cur_unsted_lines
CURSOR cur_unsted_lines(c_head_id NUMBER, c_item_id NUMBER) IS
SELECT line_id,
       inventory_item_id
FROM   OE_BLKTPRT_LINES_V      OBL
WHERE  OBL.header_id         = c_head_id
AND    OBL.inventory_item_id = c_item_id
ORDER BY OBL.activation_date;

--------------------------------------------------------------------------------
-- cur_org_addr
CURSOR cur_org_addr(c_head_id NUMBER) IS
SELECT
       hl.address_line_1           Address1,
       hl.address_line_2           Address2,
       hl.address_line_3           Address3,
       hl.town_or_city             City,
       hl.region_2                 state,
       ftl.territory_short_name    Country,
       hl.postal_code              PostalCode,
       hl.telephone_number_1       Phone1,
       hl.telephone_number_2       Phone2,
       hl.address_line_2||' '||hl.address_line_3||' '||hl.town_or_city||' '||ftl.territory_short_name||' '||hl.postal_code FormattedAddress,
       obh.transactional_curr_code Currency,
       obh.flow_status_code        Status,
       ottl.name                   Blanket_Type,
       b.name                      Instance_Name
FROM
       oe_blanket_headers_all  obh,
       oe_transaction_types_tl ottl,
       hr_organization_units   hou,
       hr_locations            hl,
       fnd_territories_tl      ftl,
       v$database              b                                                -- V3.00
WHERE
       obh.org_id            = hou.organization_id
AND    hou.location_id       = hl.location_id
AND    hl.country            = ftl.territory_code
AND    obh.order_type_id     = ottl.transaction_type_id
AND    ottl.LANGUAGE         = 'US'
AND    ftl.LANGUAGE          = 'US'
AND    obh.header_id         = c_head_id;

lv_org_addr cur_org_addr%ROWTYPE;

-- V2.00 Obsolete Code - START
--CURSOR cur_cust_addr (c_head_id NUMBER) IS
--SELECT  aav.address1,
--        aav.address2,
--		aav.address3,
--		aav.address4,
--		INITCAP(aav.city) city,
--		aav.state,
--		aav.postal_code,
--		ftl.territory_short_name country
--FROM    oe_blanket_headers_all obh,
--        ra_customers rc,
--		ra_addresses_all aav,
--		ra_site_uses_all rsu,
--	    fnd_territories_tl ftl
--WHERE   obh.sold_to_org_id = rc.customer_id
--AND     rc.customer_id = aav.customer_id
--AND     aav.address_id = rsu.address_id
--AND     UPPER(rsu.site_use_code) = 'LEGAL'
--AND     aav.country = ftl.territory_code
--AND     NVL(rsu.status, 'A') = 'A'
--AND     ftl.LANGUAGE = 'US'
--AND     obh.header_id = c_head_id;
-- V2.00 Obsolete Code - END

-- V2.00 New Code - START
--------------------------------------------------------------------------------
-- cur_cust_addr
CURSOR cur_cust_addr (c_head_id NUMBER) IS
SELECT
       Loc.address1,
       Loc.address2,
       Loc.address3,
       Loc.address4,
       INITCAP(Loc.city) city,
       Loc.state,
       Loc.postal_code,
       ftl.territory_short_name country
FROM
       oe_blanket_headers_all       obh,
       hz_cust_accounts             cust,
       hz_cust_acct_sites_all       cas,
       hz_cust_site_uses_all        su,
       hz_party_sites               ps,
       hz_locations                 loc,
       fnd_territories_tl           ftl
WHERE
       obh.sold_to_org_id         = cust.CUST_ACCOUNT_ID
AND    cust.Cust_Account_ID       = cas.cust_account_ID
AND    cas.Cust_acct_site_ID      = su.cust_acct_site_ID
AND    UPPER(su.site_use_code)    = 'LEGAL'
AND    cas.Party_site_ID          = ps.party_site_ID
AND    ps.Location_ID             = loc.location_ID
AND    loc.country                = ftl.territory_code
AND    NVL(su.status, 'A')        = 'A'
AND    ftl.LANGUAGE               = 'US'
AND    obh.header_id              = c_head_id;
-- V2.00 New Code - END

lv_cust_addr cur_cust_addr%ROWTYPE;

-- V2.00 Obsolete Code - START
--CURSOR cur_ship_addr (c_head_id NUMBER) IS
--SELECT  aav.address1,
--        aav.address2,
--		aav.address3,
--		aav.address4,
--		INITCAP(aav.city) city,
--		aav.state,
--		aav.postal_code,
--		ftl.territory_short_name country
--FROM    oe_blanket_headers_all obh,
--        ra_customers rc,
--		ra_addresses_all aav,
--		ra_site_uses_all rsu,
--	    fnd_territories_tl ftl
--WHERE   obh.ship_to_org_id = rsu.site_use_id
--AND     rc.customer_id = aav.customer_id
--AND     aav.address_id = rsu.address_id
--AND     aav.country = ftl.territory_code
--AND     ftl.LANGUAGE = 'US'
--AND     obh.header_id = c_head_id;
-- V2.00 Obsolete Code - END

-- V2.00 New Code - START
--------------------------------------------------------------------------------
-- cur_ship_addr
CURSOR cur_ship_addr(c_head_id NUMBER) IS
SELECT
       Loc.address1,
       Loc.address2,
       Loc.address3,
       Loc.address4,
       INITCAP(Loc.city) city,
       Loc.state,
       Loc.postal_code,
       obh.ship_to_org_id,
       ftl.territory_short_name country
FROM
       oe_blanket_headers_all       obh,
       hz_cust_site_uses_all        su,
       hz_cust_acct_sites_all       cas,
       hz_party_sites               ps,
       hz_locations                 loc,
       fnd_territories_tl           ftl
WHERE
       obh.ship_to_org_id         = su.site_use_id
AND    su.cust_acct_site_ID       = cas.Cust_acct_site_ID
AND    cas.Party_site_ID          = ps.party_site_ID
AND    ps.Location_ID             = loc.location_ID
AND    loc.country                = ftl.territory_code
AND    ftl.LANGUAGE               = 'US'
AND    obh.header_id              = c_head_id;
-- V2.00 New Code - END

--------------------------------------------------------------------------------
-- cur_equip
CURSOR cur_equip(c_head_id NUMBER) IS
SELECT cat_id,
       otl.variable_name equip_name,
       otl.variable_value equip_val,
   (SELECT otl1.variable_value
      FROM okc_terms_local_var_v    otl1
     WHERE otl1.document_id       = c_head_id
       AND otl1.cat_id            = otl.cat_id
       AND otl1.variable_name     = 'Quantity'||DECODE(SUBSTR(otl.variable_name, LENGTH(otl.variable_name)),
                                        '1', '1',
                                        '2', '2',
                                        '3', '3',
                                        '4', '4',
                                        '5', '5')) qty
FROM   okc_terms_local_var_v    OTL
WHERE  otl.document_id        = c_head_id
AND    otl.variable_name   LIKE 'Equipment Type%';

/*SELECT cat_id,
       otl.variable_name equip_name,
       otl.variable_value equip_val,
	   (SELECT otl1.variable_value
	    FROM   okc_terms_local_var_v otl1
		WHERE  otl1.cat_id = otl.cat_id
		AND    variable_name LIKE 'Quantity%') qty
  FROM okc_terms_local_var_v OTL
 WHERE otl.document_id = c_head_id
 AND   otl.variable_name LIKE 'Equipment Type%';*/ --Commented on June09 as it is erroring out

lv_equip           cur_equip%ROWTYPE;
lv_ship_addr       cur_ship_addr%ROWTYPE;
lv_unstead_lines   cur_unsted_lines%ROWTYPE;
ln_unstead_cnt     NUMBER := 1;
ln_unstead_cnt_1   NUMBER := 1;                                                   -- V4.00

/*CURSOR cur_att(c_line_id NUMBER) IS
SELECT attribute1 Recovery_fee, attribute2 Interest ,attribute3 Maintenance_fee
FROM OE_BLANKET_lines_ALL
WHERE line_id = c_line_id;*/


/* New Code to retrieve Item Description in the Customer's Language           */
/* V1.00                                                                      */
/* added 'lv_cur_cust_item cur_cust_item%ROWTYPE'                             */
   lv_cur_cust_item        cur_cust_item%ROWTYPE;
/* V3.00                                                                      */
/* added 'lv_utilrate', 'ln_total_commit', 'lv_total_commit' and              */
/* 'ln_agreement_duration'                                                    */
   lv_utilrate             VARCHAR2(5);
   ln_total_commit         NUMBER;
   lv_total_commit         VARCHAR2(10);
   ln_agreement_duration   NUMBER;
   lv_cat                  cur_cat%ROWTYPE;
   lv_head                 cur_head%ROWTYPE;
   lv_head_price           cur_price_line%ROWTYPE;
   lv_head_price1          cur_price_line1%ROWTYPE;
   ld_prev_startdate       DATE := NULL;
   lv_active_pline         VARCHAR2(1);
   lv_xml_out              VARCHAR2(4000);
   lv_head_text            cur_head_text%ROWTYPE;
   lv_durmonths            VARCHAR2(15);
   lv_duryears             VARCHAR2(15);
   ln_lineinv_count        NUMBER;
   lv_commitment_type      VARCHAR2(20);
   ln_annual_minval        NUMBER;
   lv_annual_minval        VARCHAR2(10);
   ln_quantity             NUMBER;
   lv_period               VARCHAR2(10);
   lv_price                VARCHAR2(20);
   ld_price_start_date     DATE;
   ld_price_end_date       DATE;
   lv_cur_price            VARCHAR2(20);
   lv_lst_hdr_id           NUMBER;
   lv_qty_per_case         NUMBER;
   lv_price_per_case       NUMBER;
   lv_qty_case             NUMBER;
   lv_price_case           NUMBER;

BEGIN

IF p_rec_type = 'Header' THEN

  lv_xml_out := lv_xml_out||'   <Header>'||CHR(10);
  lv_xml_out := lv_xml_out||'      <RepRunDate>'||TO_CHAR(SYSDATE, 'YYYY-MM-DD')||'</RepRunDate>'||CHR(10);

--------------------------------------------------------------------------------
-- cur_org_addr
  OPEN cur_org_addr(p_id);
  FETCH cur_org_addr INTO lv_org_addr;

  lv_xml_out := lv_xml_out||'      <Currency>'||lv_org_addr.Currency||'</Currency>'||CHR(10);
  lv_xml_out := lv_xml_out||'      <Status>'||lv_org_addr.Status||'</Status>'||CHR(10);
  lv_xml_out := lv_xml_out||'      <BlanketType>'||lv_org_addr.Blanket_Type||'</BlanketType>'||CHR(10);
  lv_xml_out := lv_xml_out||'      <InstanceName>'||lv_org_addr.Instance_Name||'</InstanceName>'||CHR(10);            -- V3.00
  lv_xml_out := lv_xml_out||'      <OUAddress>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address1>'||lv_org_addr.Address1||'</Address1>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address2>'||lv_org_addr.Address2||'</Address2>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address3>'||lv_org_addr.Address3||'</Address3>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <City>'||lv_org_addr.City||'</City>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <State>'||lv_org_addr.State||'</State>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Country>'||lv_org_addr.Country||'</Country>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <PostalCode>'||lv_org_addr.PostalCode||'</PostalCode>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Phone1>'||lv_org_addr.Phone1||'</Phone1>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Phone2>'||lv_org_addr.Phone2||'</Phone2>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <FormattedAddress>'||lv_org_addr.FormattedAddress||'</FormattedAddress>'||CHR(10);
  lv_xml_out := lv_xml_out||'      </OUAddress>'||CHR(10);

  CLOSE cur_org_addr;

--------------------------------------------------------------------------------
-- cur_cust_addr
  OPEN cur_cust_addr(p_id);
  FETCH cur_cust_addr INTO lv_cust_addr;

  lv_xml_out := lv_xml_out||'      <CustLegalAddress>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address1>'||lv_cust_addr.Address1||'</Address1>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address2>'||lv_cust_addr.Address2||'</Address2>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address3>'||lv_cust_addr.Address3||'</Address3>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address4>'||lv_cust_addr.Address4||'</Address4>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <City>'||lv_cust_addr.City||'</City>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <State>'||lv_cust_addr.State||'</State>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <PostalCode>'||lv_cust_addr.postal_code||'</PostalCode>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Country>'||lv_cust_addr.Country||'</Country>'||CHR(10);
  lv_xml_out := lv_xml_out||'      </CustLegalAddress>'||CHR(10);

  CLOSE cur_cust_addr;

--------------------------------------------------------------------------------
-- cur_ship_addr
  OPEN cur_ship_addr(p_id);
  FETCH cur_ship_addr INTO lv_ship_addr;

  lv_xml_out := lv_xml_out||'      <CustShipAddress>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address1>'||lv_ship_addr.Address1||'</Address1>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address2>'||lv_ship_addr.Address2||'</Address2>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address3>'||lv_ship_addr.Address3||'</Address3>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Address4>'||lv_ship_addr.Address4||'</Address4>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <City>'||lv_ship_addr.City||'</City>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <State>'||lv_ship_addr.State||'</State>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <PostalCode>'||lv_ship_addr.postal_code||'</PostalCode>'||CHR(10);
  lv_xml_out := lv_xml_out||'         <Country>'||lv_ship_addr.Country||'</Country>'||CHR(10);
  lv_xml_out := lv_xml_out||'      </CustShipAddress>'||CHR(10);

  CLOSE cur_ship_addr;

--------------------------------------------------------------------------------
-- cur_equip
  OPEN cur_equip(p_id);
  LOOP

     FETCH cur_equip INTO lv_equip;
     EXIT WHEN cur_equip%NOTFOUND;

     lv_xml_out := lv_xml_out||'      <EquipType>'||CHR(10);
     lv_xml_out := lv_xml_out||'         <Equip>'||lv_equip.equip_val||'</Equip>'||CHR(10);
     lv_xml_out := lv_xml_out||'         <Qty>'||lv_equip.qty||'</Qty>'||CHR(10);
     lv_xml_out := lv_xml_out||'      </EquipType>'||CHR(10);

  END LOOP;
  CLOSE cur_equip;


/*  OPEN cur_head(p_id);
  LOOP

     FETCH cur_head INTO lv_head;
	 EXIT WHEN cur_head%NOTFOUND;
     lv_xml_out := lv_xml_out||'      <ContractClause>'||CHR(10);
	 lv_xml_out := lv_xml_out||'         <Name>'||lv_head.variable_name||'</Name>'||CHR(10);
	 lv_xml_out := lv_xml_out||'         <Value>'||lv_head.variable_value||'</Value>'||CHR(10);
     lv_xml_out := lv_xml_out||'      </ContractClause>'||CHR(10);

  END LOOP;
  CLOSE cur_head;*/

--------------------------------------------------------------------------------
-- cur_head_text
  OPEN cur_head_text(p_id);
  LOOP

     FETCH cur_head_text INTO lv_head_text;
	   EXIT WHEN cur_head_text%NOTFOUND;
	   lv_xml_out := lv_xml_out||'      <ShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <ShorTxtVal>'||lv_head_text.shorttext_value||'</ShorTxtVal>'||CHR(10);
	   lv_xml_out := lv_xml_out||'      </ShortText>'||CHR(10);

  END LOOP;
  CLOSE cur_head_text;

--------------------------------------------------------------------------------
-- cur_cons_shorttext
  OPEN cur_cons_shorttext(p_id);
  LOOP

     FETCH cur_cons_shorttext INTO lv_cons_shorttext;
	   EXIT WHEN cur_cons_shorttext%NOTFOUND;
	   lv_xml_out := lv_xml_out||'      <ConsShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <ShortText>'||lv_cons_shorttext.Consumables_ST_value||'</ShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <SeqNum>'||lv_cons_shorttext.seq_num||'</SeqNum>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <DataType>'||lv_cons_shorttext.datatype||'</DataType>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <Category>'||lv_cons_shorttext.category||'</Category>'||CHR(10);
	   lv_xml_out := lv_xml_out||'      </ConsShortText>'||CHR(10);

  END LOOP;
  CLOSE cur_cons_shorttext;

--------------------------------------------------------------------------------
-- cur_equip_shorttext
  OPEN cur_equip_shorttext(p_id);
  LOOP

     FETCH cur_equip_shorttext INTO lv_equip_shorttext;
	   EXIT WHEN cur_equip_shorttext%NOTFOUND;
	   lv_xml_out := lv_xml_out||'      <EquipShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <ShortText>'||lv_equip_shorttext.Equipment_ST_value||'</ShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <SeqNum>'||lv_equip_shorttext.seq_num||'</SeqNum>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <DataType>'||lv_equip_shorttext.datatype||'</DataType>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <Category>'||lv_equip_shorttext.category||'</Category>'||CHR(10);
	   lv_xml_out := lv_xml_out||'      </EquipShortText>'||CHR(10);

  END LOOP;
  CLOSE cur_equip_shorttext;

--------------------------------------------------------------------------------
-- cur_commit_shorttext
  OPEN cur_commit_shorttext(p_id);
  LOOP

     FETCH cur_commit_shorttext INTO lv_commit_shorttext;
	   EXIT WHEN cur_commit_shorttext%NOTFOUND;
	   lv_xml_out := lv_xml_out||'      <CommitShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <ShortText>'||lv_commit_shorttext.commit_ST_value||'</ShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <SeqNum>'||lv_equip_shorttext.seq_num||'</SeqNum>'||CHR(10);
	   lv_xml_out := lv_xml_out||'      </CommitShortText>'||CHR(10);

  END LOOP;
  CLOSE cur_commit_shorttext;

/* New Code to retrieve accessories shorttext                                 */
/* V3.00                                                                      */
--------------------------------------------------------------------------------
-- cur_access_shorttext
  OPEN cur_access_shorttext(p_id);
  LOOP

     FETCH cur_access_shorttext INTO lv_access_shorttext;
	   EXIT WHEN cur_access_shorttext%NOTFOUND;
	   lv_xml_out := lv_xml_out||'      <AccessShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <AccShortText>'||lv_access_shorttext.access_ST_value||'</AccShortText>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <AccSeqNum>'||lv_access_shorttext.seq_num||'</AccSeqNum>'||CHR(10);
	   lv_xml_out := lv_xml_out||'      </AccessShortText>'||CHR(10);

  END LOOP;
  CLOSE cur_access_shorttext;

--------------------------------------------------------------------------------
-- cur_utilization
  OPEN cur_utilization(p_id);

     FETCH cur_utilization INTO lv_utilization;
     lv_xml_out := lv_xml_out||'      <ArticleUtilization>'||lv_utilization.variable_value||'</ArticleUtilization>'||CHR(10);

  CLOSE cur_utilization;

/* New Code to create new XML Tag 'AgreementDuration'                         */
/* V3.00                                                                      */
--------------------------------------------------------------------------------
-- cur_agreement_duration
  OPEN cur_agreement_duration(p_id);

     FETCH cur_agreement_duration INTO lv_agreement_duration;
	   lv_xml_out := lv_xml_out||'      <AgreementDuration>'||CHR(10);
--	   lv_xml_out := lv_xml_out||'         <AgreeDuration>'||NVL(lv_agreement_duration.Attribute6,0) ||'</AgreeDuration>'||CHR(10);    -- NEW 2012/01/11
	   lv_xml_out := lv_xml_out||'         <AgreeDuration>'||NVL(lv_agreement_duration.Attribute6,'N/A') ||'</AgreeDuration>'||CHR(10);  -- NEW 2012/01/11
	   lv_xml_out := lv_xml_out||'      </AgreementDuration>'||CHR(10);

  CLOSE cur_agreement_duration;

--------------------------------------------------------------------------------
-- cur_duration
  OPEN cur_duration(p_id);

     FETCH cur_duration INTO lv_durmonths;

/* IF lv_durmonths IS NULL THEN
      lv_durmonths := '12';
      lv_duryears  := 1;
	 END IF;*/
	   lv_duryears := lv_durmonths / 12;
	   lv_xml_out := lv_xml_out||'      <Duration>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <YrDuration>'||lv_duryears ||'</YrDuration>'||CHR(10);
	   lv_xml_out := lv_xml_out||'         <Mths>'||lv_durmonths ||'</Mths>'||CHR(10);
	   lv_xml_out := lv_xml_out||'      </Duration>'||CHR(10);

  CLOSE cur_duration;

  lv_xml_out := lv_xml_out||'   </Header>';


ELSIF p_rec_type = 'Line' THEN

--------------------------------------------------------------------------------
-- cur_cat
  OPEN cur_cat(p_id);

  LOOP
     FETCH cur_cat INTO lv_cat;
     EXIT WHEN cur_cat%NOTFOUND;

     BEGIN
        SELECT otl.variable_value
          INTO lv_durmonths
          FROM okc_terms_local_var_v  OTL
         WHERE OTL.variable_name    = 'Duration of Agreement'
           AND OTL.document_id      = lv_cat.header_id;

		 DBMS_OUTPUT.PUT_LINE(lv_durmonths);

	   EXCEPTION WHEN NO_DATA_FOUND THEN
	       lv_durmonths := NULL;
	   END;

	   BEGIN
	      SELECT COUNT(*)
		      INTO ln_lineinv_count
		      FROM oe_blanket_lines_all    OBL
		     WHERE OBL.inventory_item_id = lv_cat.inventory_item_id
		       AND OBL.header_id         = lv_cat.header_id;

	      IF ln_lineinv_count > 1 THEN
		       lv_commitment_type := 'Unsteady';
        ELSIF ln_lineinv_count = 1 THEN
		       lv_commitment_type := 'Steady';
		    END IF;

     END;

/* Correction to original code to only determine Annual and Total Commitment  */
/* if Product SubType Desc = 'BOWL' or 'NONBOWL'                              */
/* V3.00                                                                      */
	   BEGIN

/* Initialize values 'lv_annual_minval' and 'lv_total_commit'                 */
/* V3.00                                                                      */
     lv_annual_minval := NULL;
     lv_total_commit  := NULL;

--	    IF UPPER(lv_cat.prod_subtype_desc) IN ('BOWL','NONBOWL') THEN            -- V4.00
--	    IF UPPER(lv_cat.prod_subtype_desc) IN ('BOWL','NONBOWL','NON BOWL') THEN -- V4.00
	         BEGIN --1
		          IF lv_commitment_type = 'Steady' THEN
		             IF lv_cat.blanket_min_quantity IS NULL THEN
		                lv_annual_minval := NULL;
		             ELSIF lv_durmonths IS NULL THEN
                        lv_annual_minval := NULL;
		          ELSE
                 SELECT (lv_cat.blanket_min_quantity * 12) / TO_NUMBER(lv_durmonths)
                   INTO  ln_annual_minval
                   FROM  okc_terms_local_var_v OTL
                  WHERE  OTL.variable_name   = 'Duration of Agreement'
                    AND  OTL.document_id     = lv_cat.header_id;
--		    		     lv_annual_minval := ln_annual_minval;                        -- V4.00
		    		     lv_annual_minval := round(ln_annual_minval,3);                 -- V4.00
		          END IF;

--      lv_period := 'Year 1';

		          ELSIF lv_commitment_type = 'Unsteady' THEN
		                OPEN cur_unsted_lines(lv_cat.header_id, lv_cat.inventory_item_id);
		                LOOP
                             FETCH cur_unsted_lines INTO lv_unstead_lines;
                             EXIT WHEN cur_unsted_lines%NOTFOUND;
                                  IF lv_unstead_lines.line_id = lv_cat.line_id THEN
                                     lv_period := 'Year '||TO_CHAR(ln_unstead_cnt);
                                     EXIT;
                                     END IF;

				                 ln_unstead_cnt := ln_unstead_cnt + 1;

		                END LOOP;
		                CLOSE cur_unsted_lines;

		                IF lv_cat.blanket_min_quantity IS NULL THEN
		                   lv_annual_minval := NULL;
		                ELSE
		                   lv_annual_minval := lv_cat.blanket_min_quantity;
		                END IF;

		          -- END IF for lv_commitment_type = 'Steady'
		          END IF;

	         EXCEPTION WHEN NO_DATA_FOUND THEN
	            lv_annual_minval := NULL;
	         END; --1

/* New Code to create new XML Tag 'TotalCommit'                               */
/* V3.00                                                                      */
	         BEGIN --2

              SELECT obh.Attribute6
                INTO ln_agreement_duration                                      -- value is in months
                FROM oe_blanket_headers_all    obh
               WHERE obh.header_id           = lv_cat.header_id;

		          IF lv_commitment_type = 'Steady' THEN
		             IF lv_cat.blanket_min_quantity IS NULL THEN
		                lv_total_commit := NULL;
		          ELSIF ln_agreement_duration IS NULL THEN
                        lv_total_commit := NULL;
		          ELSE
                        ln_total_commit := ROUND((lv_cat.blanket_min_quantity * (TO_NUMBER(ln_agreement_duration / 12))));     -- V4.01
--                      ln_total_commit := (lv_cat.blanket_min_quantity * (TO_NUMBER(ln_agreement_duration / 12)));            -- V4.01
                        lv_total_commit := ln_total_commit;
		          END IF;

		          ELSIF lv_commitment_type = 'Unsteady' THEN
		                OPEN cur_unsted_lines(lv_cat.header_id, lv_cat.inventory_item_id);
		                LOOP
                             FETCH cur_unsted_lines INTO lv_unstead_lines;
					         EXIT WHEN cur_unsted_lines%NOTFOUND;
					              IF lv_unstead_lines.line_id = lv_cat.line_id THEN
					                 lv_period := 'Year '||TO_CHAR(ln_unstead_cnt_1);  -- V4.00
--					                 lv_period := 'Year '||TO_CHAR(ln_unstead_cnt);    -- V4.00
				                  EXIT;
                                  END IF;

	                    ln_unstead_cnt_1 := ln_unstead_cnt_1 + 1;                 -- V4.00
--	                  ln_unstead_cnt   := ln_unstead_cnt   + 1;                 -- V4.00

		                END LOOP;
		                CLOSE cur_unsted_lines;

		                IF lv_cat.blanket_min_quantity IS NULL THEN
		                   lv_total_commit := NULL;
		                ELSE
		                   lv_total_commit := lv_cat.blanket_min_quantity;
		                END IF;

		          -- END IF for lv_commitment_type = 'Steady'
		          END IF;

	         EXCEPTION WHEN NO_DATA_FOUND THEN
	            lv_total_commit := NULL;
	         END; --2

--------------------------------------------------------------------------------
/* END IF - Product SubType Desc = 'BOWL' or 'NONBOWL'                        */
--	      END IF;                                                               -- V4.00
	   END;

     OPEN cur_price_line(lv_cat.price_list_id,
                         lv_cat.inventory_item_id,
                         lv_cat.activation_date);
     LOOP
	      FETCH cur_price_line INTO lv_head_price ;
	      EXIT WHEN cur_price_line%NOTFOUND ;

	      IF TRUNC(SYSDATE) BETWEEN lv_head_price.Price_Start_Date AND NVL(ld_prev_startdate, NVL(lv_head_price.Price_end_Date, SYSDATE)) THEN
	         lv_active_pline := 'Y';
	      ELSE
	         lv_active_pline := 'N';
	      END IF;

          ld_prev_startdate    := lv_head_price.Price_Start_Date;
--        lv_cur_price         := lv_head_price.price; 17 MAY
          lv_cur_price         := TO_NUMBER(lv_head_price.price);
          ld_price_start_date  := lv_head_price.Price_Start_Date;
          ld_price_end_date    := lv_head_price.Price_End_Date;

     END LOOP;
     CLOSE cur_price_line;

     IF lv_cur_price IS NULL THEN
        OPEN cur_price_line1(lv_cat.price_list_id,
                             lv_cat.inventory_item_id,
                             lv_cat.activation_date);

        LOOP
	         FETCH cur_price_line1 INTO lv_head_price1;
	         EXIT WHEN cur_price_line1%NOTFOUND;

	         IF TRUNC(SYSDATE) BETWEEN lv_head_price1.Price_Start_Date AND NVL(ld_prev_startdate, NVL(lv_head_price1.Price_end_Date, SYSDATE)) THEN
	            lv_active_pline := 'Y';
	         ELSE
	            lv_active_pline := 'N';
	         END IF;

	         ld_prev_startdate    := lv_head_price1.Price_Start_Date;
	         lv_cur_price         := TO_NUMBER(lv_head_price1.price);
	         ld_price_start_date  := lv_head_price1.Price_Start_Date;
	         ld_price_end_date	  := lv_head_price1.Price_End_Date;

        END LOOP;
        CLOSE cur_price_line1;

     END IF;

     IF lv_cur_price IS NULL THEN
        lv_cur_price:=0;
     END IF;

  BEGIN
     SELECT MUC.conversion_rate
       INTO lv_qty_case
       FROM oe_blktprt_lines_v           obl,
            mtl_system_items_b           msi,
            mtl_uom_conversions          MUC
      WHERE obl.inventory_item_id      = MSI.inventory_item_id
        AND msi.inventory_item_id      = MUC.inventory_item_id
        AND msi.organization_id        = 103
        AND obl.line_id                = p_id
        AND UPPER(muc.unit_of_measure) = 'CASE';

     lv_qty_per_case   := ROUND(lv_qty_case,3);
     lv_price_per_case := ROUND(lv_price_case,3);

     EXCEPTION WHEN NO_DATA_FOUND THEN
         lv_qty_per_case   := 0;
         lv_price_per_case := 0;
         WHEN OTHERS THEN
              lv_qty_per_case   := 0;
              lv_price_per_case := 0;
  END;

  BEGIN
     OPEN cur_catsegments(lv_cat.header_id, lv_cat.category_segments);
     LOOP
          FETCH cur_catsegments INTO lv_catsegments;
          EXIT WHEN cur_catsegments%NOTFOUND;

   	      lv_Category_Segments := lv_catsegments.Category_Segments;
   	      ln_cat_cnt           := lv_catsegments.cnt;
   	      ln_total_cons_commit := lv_catsegments.Total_Cons_Commit;
   	      ln_equipment_fees    := lv_catsegments.Equipment_Fees;

     END LOOP;
     CLOSE cur_catsegments;
  END;

/* New Code to retrieve Item Description in the Customer's Language           */
/* V1.00                                                                      */
/* Added '<CustItemDescription>'                                              */
  BEGIN
     OPEN cur_cust_item(p_id);
     LOOP
          FETCH cur_cust_item INTO lv_cur_cust_item;
          EXIT WHEN cur_cust_item%NOTFOUND;
   	      lv_cust_item_description := lv_cur_cust_item.cust_item_description;
     END LOOP;
     CLOSE cur_cust_item;
  END;

/* New Code to create new XML Tag 'EquipMatrix'                               */
/* V3.00                                                                      */
  lv_utilrate := NVL(lv_cat.blanket_min_quantity,0) + NVL(lv_cat.owned_systems,0) + NVL(lv_cat.nonowned_systems,0);

  IF lv_cat.prod_subtype_desc = 'Machine' THEN
        lv_xml_out := lv_xml_out||'   <EquipMatrix>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemNumberEquip>'||lv_cat.item_number||'</ItemNumberEquip>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemDescriptionEquip>'||lv_cat.item_description||'</ItemDescriptionEquip>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CustItemDescriptionEquip>'||lv_cur_cust_item.cust_item_description||'</CustItemDescriptionEquip>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdLineEquip>'||lv_cat.prod_line_desc||'</ProdLineEquip>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdTypeEquip>'||lv_cat.prod_type_desc||'</ProdTypeEquip>'||CHR(10);           -- this contains 'Equipment'
        lv_xml_out := lv_xml_out||'      <ProdSubTypeEquip>'||lv_cat.prod_subtype_desc||'</ProdSubTypeEquip>'||CHR(10);  -- this contains 'Machine'
        lv_xml_out := lv_xml_out||'      <PlatformEquip>'||lv_cat.platform_desc||'</PlatformEquip>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BlanketMinQtyEquip>'||NVL(lv_cat.blanket_min_quantity,0)||'</BlanketMinQtyEquip>'||CHR(10);
-- START NEW
        lv_xml_out := lv_xml_out||'      <EquipQty>'||lv_utilrate||'</EquipQty>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <EquipUtilRate>'||NVL(lv_cat.util_rate,0)||'</EquipUtilRate>'||CHR(10);
-- END NEW
        lv_xml_out := lv_xml_out||'   </EquipMatrix>';
  END IF;

/* New Code to create new XML Tag 'AccMatrix'                                 */
/* V3.00                                                                      */
--  IF lv_cat.prod_subtype_desc IN ('Accessory','Parts') THEN                   -- NEW 2012/01/12
  IF lv_cat.prod_subtype_desc IN ('Accessory','Parts','Software') THEN          -- NEW 2012/01/12
        lv_xml_out := lv_xml_out||'   <AccMatrix>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemNumberAcc>'||lv_cat.item_number||'</ItemNumberAcc>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemDescriptionAcc>'||lv_cat.item_description||'</ItemDescriptionAcc>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CustItemDescriptionAcc>'||lv_cur_cust_item.cust_item_description||'</CustItemDescriptionAcc>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdLineAcc>'||lv_cat.prod_line_desc||'</ProdLineAcc>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdTypeAcc>'||lv_cat.prod_type_desc||'</ProdTypeAcc>'||CHR(10);           -- this contains 'Equipment'
        lv_xml_out := lv_xml_out||'      <ProdSubTypeAcc>'||lv_cat.prod_subtype_desc||'</ProdSubTypeAcc>'||CHR(10);  -- this contains 'Machine'
        lv_xml_out := lv_xml_out||'      <PlatformAcc>'||lv_cat.platform_desc||'</PlatformAcc>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BlanketMinQtyAcc>'||NVL(lv_cat.blanket_min_quantity,0)||'</BlanketMinQtyAcc>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <PriceAcc>'||lv_cur_price||'</PriceAcc>'||CHR(10);
        lv_xml_out := lv_xml_out||'   </AccMatrix>';
  END IF;

/* New Code to retrieve Item Description in the Customer's Language           */
/* V1.00                                                                      */
/* Added tag for '<CustItemDescription>'                                      */
/* V3.00                                                                      */
/* Added tag for '<AnnualCommit>', '<TotalCommit>' and '<ExtPrice>'           */
        lv_xml_out := lv_xml_out||'   <ItemCategory>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <HeaderID>'||lv_cat.header_id||'</HeaderID>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <LineID>'||lv_cat.line_id||'</LineID>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemNumber>'||lv_cat.item_number||'</ItemNumber>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemDescription>'||lv_cat.item_description||'</ItemDescription>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CustItemDescription>'||lv_cur_cust_item.cust_item_description||'</CustItemDescription>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CategorySegments>'||lv_cat.category_segments||'</CategorySegments>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CategoryCount>'||ln_cat_cnt||'</CategoryCount>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <TotalConsCommitment>'||ln_total_cons_commit||'</TotalConsCommitment>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <EquipFees>'||ln_equipment_fees||'</EquipFees>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdLine>'||lv_cat.prod_line_desc||'</ProdLine>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdType>'||lv_cat.prod_type_desc||'</ProdType>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdSubType>'||lv_cat.prod_subtype_desc||'</ProdSubType>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Platform>'||lv_cat.platform_desc||'</Platform>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BowlNonbowl>'||lv_cat.Bowl_Nonbowl||'</BowlNonbowl>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <StrucId>'||lv_cat.structure_id||'</StrucId>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CatSetId>'||lv_cat.category_set_id||'</CatSetId>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemType>'||lv_cat.item_type||'</ItemType>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BlanketMinQty>'||NVL(lv_cat.blanket_min_quantity,0)||'</BlanketMinQty>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BlanketMaxQty>'||NVL(lv_cat.blanket_max_quantity,0)||'</BlanketMaxQty>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <RecovFee>'||lv_cat.Recovery_fee||'</RecovFee>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Interest>'||lv_cat.Interest||'</Interest>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Mfee>'||lv_cat.Maintenance_fee ||'</Mfee>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CommitmentType>'||lv_commitment_type ||'</CommitmentType>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Period>'||lv_period||'</Period>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <AnnualMinValue>'||NVL(lv_annual_minval,0)||'</AnnualMinValue>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <AnnualCommit>'||NVL(lv_cat.blanket_min_quantity,lv_cat.blanket_max_quantity)||'</AnnualCommit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <TotalCommit>'||NVL(lv_total_commit,0)||'</TotalCommit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Price>'||lv_cur_price||'</Price>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ExtPrice>'||lv_cur_price * NVL(lv_cat.blanket_min_quantity,0)||'</ExtPrice>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <PriceStartDate>'||TO_CHAR(ld_price_start_date, 'RRRR-MM-DD')||'</PriceStartDate>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <PriceEndDate>'||TO_CHAR(ld_price_end_date, 'RRRR-MM-DD')||'</PriceEndDate>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <QtyPerCase>'||lv_qty_per_case||'</QtyPerCase>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <PricePerCase>'||lv_price_per_case||'</PricePerCase>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ActivePriceLine>'||lv_active_pline||'</ActivePriceLine>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Currency>'||lv_cat.curr||'</Currency>'||CHR(10);
        lv_xml_out := lv_xml_out||'   </ItemCategory>';

/* New Code to create new XML Tag 'ItemCategory_Commit'                       */
/* V3.00                                                                      */
  IF  NVL(lv_cat.blanket_min_quantity,0) != 0
  AND lv_cat.prod_type_desc              != 'Equipment'
--  AND lv_cat.prod_type_desc              != 'Software'                        -- NEW 2012/01/12
  AND lv_cat.prod_subtype_desc           != 'Software'                          -- NEW 2012/01/12
  AND UPPER(lv_cat.item_number)          != 'FREIGHT' THEN
        lv_xml_out := lv_xml_out||'   <ItemCategory_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <HeaderID_Commit>'||lv_cat.header_id||'</HeaderID_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <LineID_Commit>'||lv_cat.line_id||'</LineID_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ItemNumber_Commit>'||lv_cat.item_number||'</ItemNumber_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdLine_Commit>'||lv_cat.prod_line_desc||'</ProdLine_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdType_Commit>'||lv_cat.prod_type_desc||'</ProdType_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <ProdSubType_Commit>'||lv_cat.prod_subtype_desc||'</ProdSubType_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Platform_Commit>'||lv_cat.platform_desc||'</Platform_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BowlNonbowl_Commit>'||lv_cat.Bowl_Nonbowl||'</BowlNonbowl_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BlanketMinQty_Commit>'||NVL(lv_cat.blanket_min_quantity,0)||'</BlanketMinQty_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <BlanketMaxQty_Commit>'||NVL(lv_cat.blanket_max_quantity,0)||'</BlanketMaxQty_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <Period_Commit>'||lv_period||'</Period_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <TotalCommit_Commit>'||NVL(lv_total_commit,0)||'</TotalCommit_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <AnnualCommit_Commit>'||NVL(lv_cat.blanket_min_quantity,lv_cat.blanket_max_quantity)||'</AnnualCommit_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'      <CommitmentType_Commit>'||lv_commitment_type ||'</CommitmentType_Commit>'||CHR(10);
        lv_xml_out := lv_xml_out||'   </ItemCategory_Commit>';
  END IF;

  END LOOP;
  CLOSE cur_cat;

END IF;

lv_xml_out := REPLACE(lv_xml_out, '&', 'null;');

RETURN lv_xml_out;

EXCEPTION WHEN OTHERS THEN
  IF p_rec_type = 'Header' THEN
     lv_xml_out := '   <Header>'||CHR(10)||SQLERRM||CHR(10)||'   </Header>';
  ELSIF p_rec_type = 'Line' THEN
     lv_xml_out := '   <ItemCategory>'||CHR(10)||SQLERRM||CHR(10)||'   </ItemCategory>';
  END IF;

  RETURN REPLACE(lv_xml_out, '&', 'null;');

END;

/
