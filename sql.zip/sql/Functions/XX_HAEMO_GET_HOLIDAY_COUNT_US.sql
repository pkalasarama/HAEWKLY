--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_HOLIDAY_COUNT_US
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_HOLIDAY_COUNT_US" (p_from_date in date, p_to_date in date) return number as p_output NUMBER;

begin 
      select count(jca.exception_id)
      into p_output
      from jtf_calendars_vl jtc, jtf_cal_excp_assign_v jca, jtf_cal_exceptions_vl jce
      where jtc.calendar_id = 1
      and jtc.calendar_id = jca.calendar_id
      and jca.exception_id = jce.exception_id
      and jce.start_date_time between p_from_date and p_to_date;
      return nvl((p_output),0);

exception 
      when others then
      p_output := 0;
      return nvl((p_output),0);
end XX_HAEMO_Get_Holiday_Count_US;

/
