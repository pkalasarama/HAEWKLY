--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_LATESTEXPDATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_LATESTEXPDATE" (INIEXPDT date)
RETURN date
IS
  iniExpdate date := INIEXPDT;
BEGIN
  if (iniExpdate < sysdate) then
    WHILE iniExpdate < sysdate LOOP -- loop until iniExpdate >= sysdate
        iniExpdate := add_months(iniExpdate,12);
     END LOOP;
    RETURN iniExpdate;
  else
    return iniExpdate;
  end if;
END;

/
