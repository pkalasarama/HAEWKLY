--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_SO_LINE_CAT_CODE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_SO_LINE_CAT_CODE" (p_trx_type_id in number) return varchar2
as p_output varchar2 (50);

begin
  select order_category_code
  into p_output
  from OE_TRANSACTION_TYPES_ALL
  where transaction_type_id = p_trx_type_id;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_SO_Line_Cat_Code;

/
