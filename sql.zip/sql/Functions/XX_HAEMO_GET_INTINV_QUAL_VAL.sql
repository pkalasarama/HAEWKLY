--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INTINV_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INTINV_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select NAME
		into   lp_attr_val
		from   HR_OPERATING_UNITS
		where  TO_CHAR(ORGANIZATION_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE2' then
	 	select NAME
		into   lp_attr_val
		from   HR_OPERATING_UNITS
		where  TO_CHAR(ORGANIZATION_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE3' then
	 	select substr(party.PARTY_NAME,1,50)
		into   lp_attr_val
		from   HZ_CUST_ACCOUNTS cust
			   , Hz_parties party
		where  TO_CHAR(cust.cust_account_id) = p_attr_val
			   and cust.party_id = party.party_id;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE4' THEN
/* R12 Upgrade Modified on 10/04/2012 by Venkatesh Sarangam, Rolta */
	 	/*select rsu.location
		into   lp_attr_val
		from   ra_addresses_all ra
			   , ra_site_uses_all rsu
			   , fnd_territories_vl ft
		where  TO_CHAR(rsu.site_use_id) = p_attr_val
			   and nvl(rsu.status,'A') = 'A'
			   and rsu.site_use_code = 'BILL_TO'
			   and ra.address_id = rsu.address_id
			   and nvl(ra.status,'A') = 'A'
			   and ft.territory_code(+) = ra.country ;*/
     select hcsu.location
    into lp_attr_val
    from hz_party_sites hps,
         hz_locations hl,
         hz_cust_acct_sites_all hcas,
         hz_cust_site_uses_all hcsu,
         fnd_territories_vl ft
    where TO_CHAR(hcsu.site_use_id) = p_attr_val
      and nvl(hcsu.status,'A') = 'A'
      and hcsu.site_use_code = 'BILL_TO'
      and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
      and nvl(hcas.status,'A') = 'A'
      and ft.territory_code(+) = hl.country ;
	 end if;
	 return lp_attr_val;
exception
when others then
RETURN NULL;
end XX_HAEMO_GET_INTINV_QUAL_VAL;

/
