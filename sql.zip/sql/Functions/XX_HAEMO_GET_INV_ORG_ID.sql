--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INV_ORG_ID
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INV_ORG_ID" (p_org_code in varchar) return number
as p_output NUMBER (15);

begin
  select organization_id
  into p_output
  FROM org_organization_definitions
  where organization_code = p_org_code;
  return nvl((p_output),0);

exception
  when others then
  p_output := 0;
  return nvl((p_output),0);
end XX_HAEMO_Get_Inv_Org_ID;

/
