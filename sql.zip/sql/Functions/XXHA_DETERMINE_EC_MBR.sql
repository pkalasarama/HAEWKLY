create or replace FUNCTION XXHA_DETERMINE_EC_MBR(p_person_id IN NUMBER)
RETURN NUMBER
AS

/**********************************************************************************************************************************
*
* Function:     XXHA_DETERMINE_EC_MBR
* Description:  This function will determine the EC Member an employee is associated with
* Notes:
*
* Modified:       Ver      Date            Modification
*-------------    -----    -----------     ----------------------------------------------------------------------------------------
* BMarcoux        1.0      17-SEP-2013     Initial Function Creation
*                                          Person_id: 18668 = BOD (Board of Directors)
*                                          Person_id: 536   = CEO (Brian Concannon)
*                                          Person_id: 6865  = CEO Executive Assistant (Bryanne Salmon)
* BMarcoux        2.0      05-FEB-2014     Update function for new EC Members
* BMarcoux        3.0      15-MAY-2014     Update function to determine EC Members dynamically
* DKantem         4.0      18-MAY-2015     Update the function to determine the EC members based on HAE_LEADERSHIP_ROLE (Incident #INC0051381)
* BMarcoux        5.0      03-NOV-2015     Change CEO from Brian Concannon (536) to Ron Gelbman (51122)
* BMarcoux        6.0      25-OCT-2016     Modification for EC Member calculation
**********************************************************************************************************************************/

l_EC_MEMBER     per_assignments_x.person_id%TYPE     := NULL;
x_person_id     per_assignments_x.person_id%TYPE     := NULL;
l_person_id     per_assignments_x.person_id%TYPE     := NULL;
l_person_id_x   per_assignments_x.person_id%TYPE     := NULL;

-- Cursor to retrieve EC Members
CURSOR cur_ec(c_person_id NUMBER)
IS
SELECT COUNT(1) COUNT
FROM PER_PEOPLE_EXTRA_INFO ppei
WHERE 1=1
AND ppei.information_type                      LIKE 'HAE_LEADERSHIP_ROLE'
AND ppei.person_id                             = c_person_id
AND pei_information3                           = 'EC'
AND to_date(sysdate,'dd-mon-rrrr hh24:mi:ss')  >= to_date(pei_information1,'rrrr/mm/dd hh24:mi:ss')
AND (pei_information2                          IS NULL
OR to_date(sysdate,'dd-mon-rrrr hh24:mi:ss')   < to_date(pei_information2,'rrrr/mm/dd hh24:mi:ss'));

BEGIN

   l_person_id := p_person_id;

   WHILE 1 = 1
   LOOP
      FOR rec_ec IN cur_ec(l_person_id)
      LOOP
         x_person_id := l_person_id;
         IF rec_ec.count > 0 THEN
            SELECT papf.person_id
            INTO l_EC_MEMBER
            FROM apps.PER_PEOPLE_EXTRA_INFO ppei
              ,  apps.per_all_people_f      papf
            WHERE 1=1
            AND ppei.information_type                      LIKE 'HAE_LEADERSHIP_ROLE'
            AND ppei.person_id                             = l_person_id
            AND pei_information3                           = 'EC'
            AND to_date(sysdate,'dd-mon-rrrr hh24:mi:ss')  >= to_date(pei_information1,'rrrr/mm/dd hh24:mi:ss')
            AND (pei_information2                          IS NULL
            OR to_date(sysdate,'dd-mon-rrrr hh24:mi:ss')   < to_date(pei_information2,'rrrr/mm/dd hh24:mi:ss'))
            AND papf.person_id                             = ppei.person_id
            AND to_date(sysdate) BETWEEN papf.effective_start_date AND NVL(papf.effective_end_date,sysdate);
            RETURN l_EC_MEMBER;
         ELSE
            SELECT supervisor_id
            INTO l_person_id
            FROM apps.per_all_assignments_f papf
            WHERE person_id = x_person_id
            AND to_date(sysdate) BETWEEN papf.effective_start_date AND NVL(papf.effective_end_date,sysdate);
         END IF;
      END LOOP;
   END LOOP;

RETURN NULL;

EXCEPTION
   WHEN OTHERS THEN
        RETURN NULL;

END XXHA_DETERMINE_EC_MBR;