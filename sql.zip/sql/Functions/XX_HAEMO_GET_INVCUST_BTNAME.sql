--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INVCUST_BTNAME
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INVCUST_BTNAME" (p_cust_id in number) return varchar2
as p_output varchar2 (200);
BEGIN
/* R12 Upgrade Modified on 10/03/2012 by Venkatesh Sarangam, Rolta */
  /*select customer_name
  into p_output
  from ra_customers
  where customer_id = p_cust_id;*/
  SELECT hp.party_name customer_name
  INTO p_output
  from hz_parties hp,
       hz_cust_accounts hca
  WHERE hca.cust_account_id = p_cust_id
    AND hp.party_id = hca.party_id;
  return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_InvCust_BTNAME;

/
