--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_CURR_CONV_RATE_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_CURR_CONV_RATE_FNC" (p_current_code VARCHAR2
                                              , p_target_code  VARCHAR2)
 RETURN NUMBER
 IS
   l_rate number;
                     
 BEGIN
                          
     select conversion_rate
     into   l_rate
     from   apps.gl_daily_rates 
     where  conversion_type = 'Corporate'               
     and    conversion_date = Last_Day(ADD_MONTHS(trunc(sysdate),-2))+1
     and    from_currency = p_current_code
     and    to_currency = p_target_code;
                          
     if l_rate is not null
        then return l_rate;
     else return 1;
     end if;                 
                     
 EXCEPTION
 WHEN OTHERS THEN
       RETURN 1;
 END XXHA_CURR_CONV_RATE_FNC;
 

/
