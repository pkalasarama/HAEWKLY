--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_RTV_LOT_EXP_DATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_RTV_LOT_EXP_DATE" (
         p_organization_id           mtl_lot_numbers.organization_id%TYPE
      ,  p_inventory_item_id         mtl_lot_numbers.inventory_item_id%TYPE
      ,  p_lot_number                mtl_lot_numbers.lot_number%TYPE) RETURN VARCHAR2 AS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_RTV_LOT_EXP_DATE
 * Description:  This Script will retrieve the Lot Expiration Date for a selected Organization, Inventory Item ID and Lot Number
 * Notes:        Used by the following rdf's:
 *               - XXHA_WSHRDINV.rdf (Commercial Invoices)
 *               - XXHA_WSHRDPIK.rdf (Pick Slips)
 *
 * Modified:      Ver     Date              Modification
 *-------------   -----   ----------        ----------------------------------------------------------------------------------------
 * BMarcoux       1.0     06-SEP-2013       Initial Function Creation
 *
 **********************************************************************************************************************************/

    l_exp_date VARCHAR2 (10) := NULL;

BEGIN

    SELECT
         (TO_CHAR(lot.expiration_date, 'YYYY-MM'))
    INTO 
         l_exp_date
    FROM
         mtl_lot_numbers         lot
    WHERE
         lot.organization_id   = p_organization_id
    AND  lot.inventory_item_id = p_inventory_item_id
    AND  lot.lot_number        = p_lot_number;

    RETURN l_exp_date;

EXCEPTION
    WHEN OTHERS THEN
         l_exp_date := NULL;
         RETURN l_exp_date;

END XXHA_RTV_LOT_EXP_DATE;

/
