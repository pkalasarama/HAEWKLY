--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_ITEM_FROZ_COST
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_ITEM_FROZ_COST" (p_org_id in number, p_item_id in number)return number 
as p_output Number;

Begin
  Select item_cost
  into p_output
  from apps.cst_item_costs
  where organization_id = p_org_id
  and inventory_item_id = p_item_id
  and cost_type_id = 1;
  return nvl ((p_output),0);

exception
  when others then
  p_output := 0;
  return nvl ((p_output),0);
end XX_HAEMO_Get_Item_Froz_Cost;

/
