--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_DEL_SERIAL_NUMBER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_DEL_SERIAL_NUMBER" (p_header_id NUMBER, p_line_id NUMBER)
RETURN VARCHAR2
IS
v_serial_number VARCHAR2(10000);
CURSOR cur_serial (l_header_id NUMBER, l_line_id NUMBER)
IS
    SELECT DISTINCT wdd.serial_number
		   , wdd.source_line_number
	FROM   wsh_delivery_details wdd
	   	   , wsh_new_deliveries wnd
	   	   , wsh_delivery_assignments wda
	   	   , mtl_unit_transactions mut
	WHERE  wdd.delivery_detail_id = wda.delivery_detail_id
	   	   AND wda.delivery_id = wnd.delivery_id(+)
	   	   AND wdd.transaction_id = mut.transaction_id(+)
	   	   AND wdd.source_header_id = l_header_id
		   AND wdd.source_line_id = l_line_id
-- 		   AND wdd.source_line_id IN (SELECT source_line_id
-- 	   	   					  	  	  FROM   wsh_delivery_details
-- 								  	  WHERE  source_header_id = l_header_id)
	ORDER BY wdd.source_line_number;
	v_length NUMBER;
BEGIN
	FOR rec_serial IN cur_serial(p_header_id, p_line_id) LOOP
	  	v_serial_number := v_serial_number||''||rec_serial.serial_number||'; ';
	END LOOP;
	v_length := LENGTH(v_serial_number);
	v_serial_number := SUBSTR(v_serial_number, 1, (v_length-2));
	RETURN v_serial_number;
END xx_haemo_get_del_serial_number;

/
