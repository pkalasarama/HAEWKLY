--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_ORD_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_ORD_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE2' then
	 	select name
		into   lp_attr_val
		from   OE_LINE_TYPES_V
		where  TO_CHAR(line_type_id) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE8' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE9' then
	 	select T.NAME
		into   lp_attr_val
		from   OE_TRANSACTION_TYPES_ALL A,OE_TRANSACTION_TYPES_TL T
		where  TO_CHAR(A.TRANSACTION_TYPE_ID) = p_attr_val
			   and A.transaction_type_id = T.transaction_type_id
			   and T.language = userenv('LANG')
			   and A.transaction_type_code='ORDER';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE8' then
	 	select lookup_code
		into   lp_attr_val
		from   qp_lookups
		where  lookup_code = p_attr_val
			   and lookup_type = 'QP_AGREEMENT_TYPE';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE10' then
	 	select MEANING
		into   lp_attr_val
		from   FND_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'YES_NO';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE11' then
	 	select MEANING
		into   lp_attr_val
		from   FND_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'YES_NO';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE12' then
	 	select oola.CUST_PO_NUMBER
		into   lp_attr_val
		from   OE_ORDER_LINES_ALL oola
			   , OE_ORDER_HEADERS_ALL ooha
		where  TO_CHAR(oola.CUST_PO_NUMBER) = p_attr_val
			   and oola.CUST_PO_NUMBER IS NOT NULL
			   AND oola.HEADER_ID = ooha.HEADER_ID;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE13' then
	 	select LOOKUP_CODE
		into   lp_attr_val
		from   OE_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'ORDER_CATEGORY';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE14' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE15' then
	 	select LOOKUP_CODE
		into   lp_attr_val
		from   OE_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'SOURCE_TYPE';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE16' then
	 	select LOOKUP_CODE
		into   lp_attr_val
		from   OE_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'SHIPMENT_PRIORITY';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE17' then
	 	select p_attr_val
		into   lp_attr_val
		from   dual;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE18' then
	 	select NAME||' '||LOCATION_CODE
		into   lp_attr_val
		from   OE_SHIP_FROM_ORGS_V
		where  TO_CHAR(organization_id) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE19' then
	 	select LOOKUP_CODE
		into   lp_attr_val
		from   OE_LOOKUPS
		where  LOOKUP_CODE = p_attr_val
			   and LOOKUP_TYPE = 'LINE_CATEGORY';
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE20' then
	 	select LOOKUP_CODE
		into   lp_attr_val
		from   WSH_LOOKUPS
		where  ENABLED_FLAG = 'Y'
			   AND LOOKUP_TYPE = 'FREIGHT_COST_TYPE'
			   AND LOOKUP_CODE = p_attr_val;
	  end if;
	  return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_ORD_QUAL_VAL;

/
