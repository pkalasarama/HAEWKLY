CREATE OR REPLACE
FUNCTION XXHA_MATERIAL_CERT_FNC(p_Status1 IN VARCHAR, p_Status2 in VARCHAR, p_WB_LEGACY VARCHAR)
RETURN NUMBER AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_MATERIAL_CERT_FNC
 * Description:  This function will update the columns 'Status' and 'Process Date' in the Table 'XXHA_HAEMODOCS_CERT_TBL'.  
 *               It is used by 'XXHA: Material Certificates Generation' and by 'XXHA: Material Certificates Generation Legacy'.
 * Notes:
 *
 * Modified:     Ver    Date         Modification
 *-------------  -----  -----------  ----------------------------------------------------------------------------------------------
 * BMarcoux      1.0    30-JAN-2014  Initial Function Creation
 *                                   - The first time this is called, it will set the Status to 'P' for the concurrent program to select records that need to be processed
 *                                   - The second time this is called, it will set the Status to 'C' to show records have completed processing
 *
 * BMarcoux      2.0    16-FEB-2017  Added processing for Legacy Certs (p_WB_LEGACY)
 *
 **********************************************************************************************************************************/

l_count           NUMBER := NULL;

-- Count the number of records
CURSOR cur_1
    IS
SELECT NVL(COUNT(*),0)
  FROM XXHA_MATERIAL_CERT_TBL
 WHERE STATUS    = p_Status2
   AND WB_LEGACY = p_WB_LEGACY;

BEGIN

    -- Update the records
    BEGIN
        UPDATE XXHA_MATERIAL_CERT_TBL hae
        SET hae.STATUS          = p_Status2
          , hae.DATE_PROCESSED  = SYSDATE
        WHERE hae.STATUS        = p_Status1
          AND hae.WB_LEGACY     = p_WB_LEGACY;
        COMMIT;
    END;

    -- Count the number of records (WHERE STATUS = p_Status2)
    BEGIN
        OPEN cur_1;
       FETCH cur_1 INTO l_count;
       CLOSE cur_1;
    END;

    RETURN l_count;

END XXHA_MATERIAL_CERT_FNC;