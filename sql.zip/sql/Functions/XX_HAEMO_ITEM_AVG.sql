--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_ITEM_AVG
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_ITEM_AVG" (p_item_id number, p_organization_id number, p_months number)
return number
is
lp_line_id number;
begin
--   if p_months = 3 then
  	 select round((count(oola.shipped_quantity)/p_months), 2)
  	 into   lp_line_id
  	 from   oe_order_lines_all oola
  	 where  oola.inventory_item_id = p_item_id
	 	 	and oola.ship_from_org_id = p_organization_id
		 	and nvl(to_char(sysdate, 'MM') - to_char(oola.actual_shipment_date, 'MM'), 0) = p_months;
	 return lp_line_id;
--   elsif p_months = 6 then
--   	 select round((count(oola.shipped_quantity)/6), 2)
--   	 into   lp_line_id
--   	 from   oe_order_lines_all oola
--   	 where  oola.inventory_item_id = p_item_id
-- 	 	 	and oola.ship_from_org_id = p_organization_id
-- 		 	and nvl(to_char(sysdate, 'MM') - to_char(oola.actual_shipment_date, 'MM'), 0) = 6;
-- 	 return lp_line_id;
-- end if;
end XX_HAEMO_ITEM_AVG;

/
