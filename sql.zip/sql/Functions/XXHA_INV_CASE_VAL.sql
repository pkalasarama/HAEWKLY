/* Formatted on 2015/10/14 16:48 (Formatter Plus v4.8.8) */
CREATE OR REPLACE FUNCTION xxha_inv_case_val (
   p_inventory_item_id   IN   NUMBER,
   p_uom                 IN   VARCHAR2
)
   RETURN VARCHAR2
AS
/**********************************************************************************************************************************
*
* Package:       xxha_inv_case_val
* Description:   validate flexfield entry ( mtl_system_items, attribute20, ensure UOM entered is setup for this part
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    4-OCT-2015  Initial Creation
**********************************************************************************************************************************/
   v_test   NUMBER;
BEGIN
   IF p_uom IS NULL
   THEN
      RETURN 'true';
   END IF;

   SELECT COUNT (*)
     INTO v_test
     FROM mtl_uom_conversions
    WHERE inventory_item_id = p_inventory_item_id AND uom_code = p_uom;

   IF v_test > 0
   THEN
      RETURN 'true';
   ELSE
      RETURN 'false';
   END IF;
END;