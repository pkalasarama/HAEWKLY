--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_TER_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_TER_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select jt.name
		into   lp_attr_val
		from   JTF_TERR_QTYPE_USGS jtqu
			   , JTF_TERR jt
			   , JTF_QUAL_TYPE_USGS jqtu
		where  TO_CHAR(jt.terr_id) = p_attr_val
			   and (TRUNC(jt.start_date_active) <= TRUNC(SYSDATE)
			   	    AND (TRUNC(jt.end_date_active) >= TRUNC(SYSDATE)
						 OR jt.end_date_active IS NULL ))
			   AND jt.terr_id = jtqu.terr_id
			   AND jtqu.qual_type_usg_id = jqtu.qual_type_usg_id
			   AND jqtu.source_id = -1003
			   AND jqtu.qual_type_id = -1007;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE2' then
	 	select jt.name
		into   lp_attr_val
		from   JTF_TERR_QTYPE_USGS jtqu, JTF_TERR jt, JTF_QUAL_TYPE_USGS jqtu
		where  TO_CHAR(jt.terr_id) = p_attr_val
			   and (TRUNC(jt.start_date_active) <= TRUNC(SYSDATE)
			   	    AND (TRUNC(jt.end_date_active) >= TRUNC(SYSDATE)
						 OR jt.end_date_active IS NULL ))
  			   AND jt.terr_id = jtqu.terr_id
			   AND jtqu.qual_type_usg_id = jqtu.qual_type_usg_id
			   AND jqtu.source_id = -1001
			   AND jqtu.qual_type_id = -1002;
	 end if;
	 return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_TER_QUAL_VAL;

/
