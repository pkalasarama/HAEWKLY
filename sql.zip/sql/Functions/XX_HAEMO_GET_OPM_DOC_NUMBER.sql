--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_OPM_DOC_NUMBER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_OPM_DOC_NUMBER" (
      p_doc_type VARCHAR2,
      p_doc_id  IN NUMBER,
      p_line_id IN NUMBER,
      p_item_id IN NUMBER)
    RETURN VARCHAR2
  AS
    p_output VARCHAR2 (10);
  BEGIN
    IF p_doc_type = 'PROD' THEN
      SELECT h.batch_no
      INTO p_output
      FROM pm_matl_dtl d,
        pm_btch_hdr h,
        fm_form_mst f
      WHERE d.batch_id  = p_doc_id
      AND d.line_id     = p_line_id
      AND d.item_id     = p_item_id
      AND d.batch_id    = h.batch_id
      AND h.formula_id  = f.formula_id
      AND h.delete_mark = 0
      AND f.delete_mark = 0;
    elsif p_doc_type    = 'PORD' THEN
      SELECT h.po_no
      INTO p_output
      FROM po_ordr_hdr h,
        po_ordr_dtl d,
        po_vend_mst v,
        op_ship_mst s
      WHERE d.po_id      = p_doc_id
      AND d.line_id      = p_line_id
      AND d.item_id      = p_item_id
      AND d.po_id        = h.po_id
      AND v.vendor_id    = d.shipvend_id
      AND s.shipper_code = d.shipper_code
      AND h.delete_mark  = 0
      AND s.delete_mark  = 0;
    elsif p_doc_type     = 'OPSO' THEN
      SELECT h.order_no
      INTO p_output
      FROM op_ordr_hdr h,
        op_ordr_dtl d,
        op_cust_mst v,
        op_ship_mst s
      WHERE d.order_id   = p_doc_id
      AND d.line_id      = p_line_id
      AND d.item_id      = p_item_id
      AND d.order_id     = h.order_id
      AND v.cust_id      = d.shipcust_id
      AND s.shipper_code = d.shipper_code
      AND h.delete_mark  = 0
      AND s.delete_mark  = 0
      AND v.delete_mark  = 0;
    elsif p_doc_type     = 'RECV' THEN
      SELECT h.recv_no
      INTO p_output
      FROM po_recv_hdr h,
        po_recv_dtl d,
        po_vend_mst v,
        op_ship_mst s
      WHERE d.recv_id    = p_doc_id
      AND d.line_id      = p_line_id
      AND d.item_id      = p_item_id
      AND d.recv_id      = h.recv_id
      AND v.vendor_id    = d.shipvend_id
      AND s.shipper_code = d.shipper_code
      AND h.delete_mark  = 0
      AND s.delete_mark  = 0
      AND v.delete_mark  = 0;
    elsif p_doc_type     = 'OPSP' THEN
      SELECT b1.bol_no
      INTO p_output
      FROM op_bill_lad b1,
        op_bill_lad b2,
        op_ordr_dtl d,
        op_cust_mst v,
        op_ship_mst s
      WHERE b1.bol_id    = p_doc_id
      AND d.line_id      = p_line_id
      AND d.item_id      = p_item_id
      AND d.bol_id       = b2.bol_id
      AND v.cust_id      = d.shipcust_id
      AND s.shipper_code = d.shipper_code
      AND b1.delete_mark = 0
      AND b2.delete_mark = 0
      AND s.delete_mark  = 0
      AND v.delete_mark  = 0;
    elsif p_doc_type     = 'OPCR' THEN
      SELECT b1.bol_no
      INTO p_output
      FROM op_bill_lad b1,
        op_ordr_dtl d,
        op_cust_mst v,
        op_ship_mst s
      WHERE d.invoice_id = p_doc_id
      AND d.line_id      = p_line_id
      AND d.item_id      = p_item_id
      AND d.invoice_id   = b1.bol_id
      AND v.cust_id      = d.shipcust_id
      AND s.shipper_code = b1.shipper_code
      AND b1.delete_mark = 0
      AND s.delete_mark  = 0
      AND v.delete_mark  = 0;
    elsif p_doc_type    IN ('CREI','ADJI','STSI','TRNI','GRDI', 'CRER','ADJR','STSR','TRNR','GRDR') THEN
      SELECT m.journal_no
      INTO p_output
      FROM ic_jrnl_mst m,
        ic_adjs_jnl d
      WHERE d.doc_id   = p_doc_id
      AND d.item_id    = p_item_id
      AND d.line_id    = p_line_id
      AND d.journal_id = m.journal_id;
    elsif p_doc_type   = 'XFER' THEN
      SELECT transfer_no
      INTO p_output
      FROM ic_xfer_mst
      WHERE Transfer_id = p_doc_id
      AND item_id       = p_item_id;
    elsif p_doc_type    = 'PORC' THEN
      SELECT DISTINCT rsh.receipt_num
      INTO p_output
      FROM rcv_shipment_lines rsl,
        rcv_shipment_headers rsh,
        rcv_transactions rt
      WHERE rt.transaction_id   = p_line_id
      AND rt.shipment_header_id = rsh.shipment_header_id
      AND rt.shipment_line_id   = rsl.shipment_line_id;
    elsif p_doc_type            = 'OMSO' THEN
      SELECT DISTINCT ooh.order_number
      INTO p_output
      FROM oe_order_headers_all ooh,
        oe_order_lines_all ool
      WHERE ool.line_id = p_line_id
      AND ooh.header_id = ool.header_id;
    END IF;
    RETURN p_output;
  EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
  END XX_HAEMO_Get_OPM_Doc_Number;

/
