--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_SHIPFRM_CNTY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_SHIPFRM_CNTY" (p_org_id in number) return varchar2
as p_output varchar2 (25);

begin
  select country
  into p_output
  from apps.hr_locations
  where inventory_organization_id = p_org_id;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_ShipFrm_Cnty;

/
