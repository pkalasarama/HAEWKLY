--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_CHECK_PO_BLNKT_QTY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_CHECK_PO_BLNKT_QTY" (p_itemid  number, p_invorg_id number)
-- +===========================================================================+
-- | Name        : XXHA_CHECK_PO_BLNKT_QTY                                     |
-- | Purpose     : Check if PO blanket qty committed is null for an item       |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 06/04/13  1.0  IPadela       Initial version                              |
-- +===========================================================================+
  RETURN VARCHAR2
IS
  l_text  VARCHAR2(1 char) := 'N';
BEGIN
  FOR cur_rec IN (select pol.quantity_committed
                  from po_lines_all pol, po_headers_all poh
                  where pol.po_header_id = poh.po_header_id
                  and pol.item_id = p_itemid
                  and pol.org_id = (select operating_unit 
                                    from org_organization_definitions
                                    where organization_id = p_invorg_id)
                  and poh.type_lookup_code = 'BLANKET'
                  and Nvl(poh.cancel_flag,'N') = 'N'
                  and Nvl(pol.cancel_flag,'N') = 'N'
                  and Nvl(poh.closed_code,'OPEN') not in ('FINALLY CLOSED', 'CLOSED')
                  and Nvl(pol.closed_code, 'OPEN') not in ('FINALLY CLOSED', 'CLOSED', 'CLOSED FOR INVOICE', 'CLOSED FOR RECEIVING')
                  )                             
  LOOP
    IF cur_rec.quantity_committed IS NULL
    THEN
      l_text := 'Y';
      RETURN l_text; 
    END IF;
  END LOOP;
  RETURN l_text;
END;

/
