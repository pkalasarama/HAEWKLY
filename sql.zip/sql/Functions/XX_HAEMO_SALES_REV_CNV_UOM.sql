--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_SALES_REV_CNV_UOM
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_SALES_REV_CNV_UOM" (P_ITEM_ID NUMBER, P_QTY NUMBER, P_TO_UOM VARCHAR2)
/*****************************************************************************************
* Function Name : XX_HAEMO_SALES_REV_CNV_UOM                                             *
* Purpose       : Calculate quantity conversion from Transaction UOM to Each             *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
* MTL_UOM_CONVERSIONS            S                                                       *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* Draft 1A   11-Dec-2007     Rakesh Sawarkar      Initial Creation                       *
******************************************************************************************/
RETURN NUMBER
IS
LP_QTY NUMBER := 0;
LP_RATE NUMBER := 0;
BEGIN
	 SELECT CONVERSION_RATE
	 INTO   LP_RATE
	 FROM   MTL_UOM_CONVERSIONS
	 WHERE  INVENTORY_ITEM_ID = P_ITEM_ID
	 		AND UPPER(UOM_CODE) = UPPER(P_TO_UOM);
	 LP_QTY := NVL(P_QTY * LP_RATE,0);
	 RETURN LP_QTY;
EXCEPTION
		 WHEN OTHERS THEN
		 RETURN P_QTY;
END XX_HAEMO_SALES_REV_CNV_UOM;


/
