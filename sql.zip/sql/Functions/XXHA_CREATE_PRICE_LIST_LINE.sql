--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_CREATE_PRICE_LIST_LINE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_CREATE_PRICE_LIST_LINE" (p_price_list_header_id number, p_inventory_item_id number, p_unit_price number, p_product_uom_code varchar2)
/*****************************************************************************************
* Name/Purpose : CREATE Price list line for an item used primarily with ASCP RXC Orders  *
*                                                                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 17-DEC-2012     Manuel Fernandes     Initial Creation                                  *
*****************************************************************************************/
return boolean
as
gpr_return_status VARCHAR2 (1) := NULL;
gpr_msg_count NUMBER := 0;
gpr_msg_data VARCHAR2 (2000);
gpr_price_list_rec qp_price_list_pub.price_list_rec_type;
gpr_price_list_val_rec qp_price_list_pub.price_list_val_rec_type;
gpr_price_list_line_tbl qp_price_list_pub.price_list_line_tbl_type;
gpr_price_list_line_val_tbl qp_price_list_pub.price_list_line_val_tbl_type;
gpr_qualifiers_tbl qp_qualifier_rules_pub.qualifiers_tbl_type;
gpr_qualifiers_val_tbl qp_qualifier_rules_pub.qualifiers_val_tbl_type;
gpr_pricing_attr_tbl qp_price_list_pub.pricing_attr_tbl_type;
gpr_pricing_attr_val_tbl qp_price_list_pub.pricing_attr_val_tbl_type;
ppr_price_list_rec qp_price_list_pub.price_list_rec_type;
ppr_price_list_val_rec qp_price_list_pub.price_list_val_rec_type;
ppr_price_list_line_tbl qp_price_list_pub.price_list_line_tbl_type;
ppr_price_list_line_val_tbl qp_price_list_pub.price_list_line_val_tbl_type;
ppr_qualifiers_tbl qp_qualifier_rules_pub.qualifiers_tbl_type;
ppr_qualifiers_val_tbl qp_qualifier_rules_pub.qualifiers_val_tbl_type;
ppr_pricing_attr_tbl qp_price_list_pub.pricing_attr_tbl_type;
ppr_pricing_attr_val_tbl qp_price_list_pub.pricing_attr_val_tbl_type;
k NUMBER := 1;
j NUMBER := 1;
BEGIN
--DBMS_OUTPUT.put_line ('Start 1');
-- INITIALIZATION REQUIRED FOR R12
--mo_global.set_policy_context ('S', 308);
--mo_global.init('ONT');
--fnd_global.apps_initialize (user_id => 22661, resp_id => 50237, resp_appl_id => 660);
--select * from oe_price_lists where price_list_id = 5568537
gpr_price_list_rec.list_header_id := p_price_list_header_id; --5568537; -- Enter the list_header_id from qp_list_headers
--gpr_price_list_rec.NAME := 'US RX Crossroads Dummy Price List'; -- Enter the price list name
gpr_price_list_rec.list_type_code := 'PRL';
--gpr_price_list_rec.description := 'US RX Crossroads Dummy Price List'; --Enter the price list Description
gpr_price_list_rec.operation := qp_globals.g_opr_update;
k := 1; -- create the price list line rec

gpr_price_list_line_tbl (k).list_header_id := p_price_list_header_id; --5568537; -- Enter the list_header_id from qp_list_headers
gpr_price_list_line_tbl (k).list_line_id := fnd_api.g_miss_num;
gpr_price_list_line_tbl (k).list_line_type_code := 'PLL';
gpr_price_list_line_tbl (k).operation := qp_globals.g_opr_create;
gpr_price_list_line_tbl (k).operand := p_unit_price; --0; --Enter the Unit Price
gpr_price_list_line_tbl (k).arithmetic_operator := 'UNIT_PRICE';
j := 1;
gpr_pricing_attr_tbl (j).pricing_attribute_id := fnd_api.g_miss_num;
gpr_pricing_attr_tbl (j).list_line_id := fnd_api.g_miss_num;
gpr_pricing_attr_tbl (j).product_attribute_context := 'ITEM';
gpr_pricing_attr_tbl (j).product_attribute := 'PRICING_ATTRIBUTE1';
--select * from haemo.xxha_rxc_sales_issues where error_message like '*check price list%'
--select distinct inventory_item_id from mtl_system_items_b msi where segment1 = '798-60'
--select * from mtl_system_items_b msi where segment1 = '798-60'
gpr_pricing_attr_tbl (j).product_attr_value := to_char(p_inventory_item_id); --'540688'; -- Enter the inventory_item_id
gpr_pricing_attr_tbl (j).product_uom_code := p_product_uom_code; --'Ea'; -- Enter the UOM
gpr_pricing_attr_tbl (j).excluder_flag := 'N';
gpr_pricing_attr_tbl (j).attribute_grouping_no := 1;
gpr_pricing_attr_tbl (j).price_list_line_index := 1;
gpr_pricing_attr_tbl (j).operation := qp_globals.g_opr_create;
--dbms_output.put_line('Calling qp_price_list_pub.process_price_list API to Enter Item Into Price List');
--dbms_output.put_line('=============================================');
qp_price_list_pub.process_price_list
(p_api_version_number => 1,
p_init_msg_list => fnd_api.g_false,
p_return_values => fnd_api.g_false,
p_commit => fnd_api.g_false,
x_return_status => gpr_return_status,
x_msg_count => gpr_msg_count,
x_msg_data => gpr_msg_data,
p_price_list_rec => gpr_price_list_rec,
p_price_list_line_tbl => gpr_price_list_line_tbl,
p_pricing_attr_tbl => gpr_pricing_attr_tbl,
x_price_list_rec => ppr_price_list_rec,
x_price_list_val_rec => ppr_price_list_val_rec,
x_price_list_line_tbl => ppr_price_list_line_tbl,
x_price_list_line_val_tbl => ppr_price_list_line_val_tbl,
x_qualifiers_tbl => ppr_qualifiers_tbl,
x_qualifiers_val_tbl => ppr_qualifiers_val_tbl,
x_pricing_attr_tbl => ppr_pricing_attr_tbl,
x_pricing_attr_val_tbl => ppr_pricing_attr_val_tbl);
IF ppr_price_list_line_tbl.count > 0 THEN
/*
FOR k in 1 .. ppr_price_list_line_tbl.count
LOOP
dbms_output.put_line('No Of Record Got Insterted=> ' || to_char(k));
dbms_output.put_line('Return Status = ' || ppr_price_list_line_tbl(k).return_status);
END LOOP;
*/
  null;
END IF;
IF ppr_price_list_line_tbl(k).return_status = fnd_api.g_ret_sts_success THEN
  return true;
--Commit;
--rollback;
--DBMS_OUTPUT.put_line ('The Item has been successfully loaded into the price list');
Else
  return false;
--Rollback;
  DBMS_OUTPUT.put_line ('The Item has not been loaded into the price list');
end if;
/*
FOR k in 1 .. gpr_msg_count
LOOP
gpr_msg_data := oe_msg_pub.get(
p_msg_index => k,
p_encoded => 'F');
dbms_output.put_line('The Error Message Due to which The Item has not been loaded to Price List ' || to_char( k) || ' is: ' || gpr_msg_data);
END LOOP;
*/
--DBMS_OUTPUT.put_line ('Done');
END;

/*
declare
  x boolean;
begin
x := xxha_create_price_list_line(5568537, 540688, 0, 'Ea');
if x then
  dbms_output.put_line('success');
else
  dbms_output.put_line('failed');
end if;
end;
*/

/
