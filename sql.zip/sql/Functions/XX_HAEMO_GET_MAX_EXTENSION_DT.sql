--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_MAX_EXTENSION_DT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_MAX_EXTENSION_DT" (    P_PERSON_ID      NUMBER)
/* ###########################################################################*/
/*     HAEMONETICS                                                                                                                                                */
/*     File Name :       XX_HAEMO_GET_MAX_EXTENSION_DT.sql                                                                                */
/*     Description  : This function takes in the Person_Id and return  back the max date untill which his contract               */
/*                         can be extended                                                                                                                         */                                                                                                                                                               
/*     Date                 Created By Notes                                                                                                                     */
/*   -----------------------------------------                                                                                                                    */
/*    09/23/2013       Vijay Samba        Inital Creation                                                                                                 */
/*    02/21/2014       David Lund         Changed the number of days from 90 to 120                                                                                                */
/*                                                                                                                                                                          */
/* ###########################################################################*/

    RETURN DATE
    IS
    v_maxnum_of_extn_days     NUMBER;
    BEGIN
    
     select ADD_MONTHS(MIN(EFFECTIVE_START_DATE ),9) - TRUNC(SYSDATE)
      INTO v_maxnum_of_extn_days
     from per_people_f 
     where PERSON_ID =P_PERSON_ID;
     
        IF V_MAXNUM_OF_EXTN_DAYS <= 0
           THEN 
            RETURN SYSDATE;
          ELSIF (v_maxnum_of_extn_days >0 AND v_maxnum_of_extn_days<=120 )THEN
            RETURN TRUNC(SYSDATE+v_maxnum_of_extn_days);
          ELSIF V_MAXNUM_OF_EXTN_DAYS >120  THEN
            RETURN TRUNC(SYSDATE+120);
          END IF;
     
--     RETURN v_maxnum_of_extn_days;
     
     EXCEPTION
     WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE('ERROR IS '||SQLERRM);
     v_maxnum_of_extn_days :=0;
     RETURN TRUNC(SYSDATE);
     
    END;

/
