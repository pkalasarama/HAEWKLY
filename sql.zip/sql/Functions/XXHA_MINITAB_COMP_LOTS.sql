--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_MINITAB_COMP_LOTS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_MINITAB_COMP_LOTS" (P_LOT_NUMBER VARCHAR2) RETURN VARCHAR2 IS
--$Header$
/*******************************************************************************************
*Function Name: XXHA_MINITAB_COMP_LOTS
*
*Description: This functions returns the 37075-00 component lots that make up the 0625B-00 
*				   part. The 0625B-00 finished good lot is the parameter
*
*Created By: David Lund
*Date:   JAN-24-2011
*
*Modification Log:
*Developer             Date                     Description
*-----------------   ------------------   ------------------------------------------------
* David Lund		     Sep-21-2011           Created this function
* David Lund		     Jan-16-2012           Removed the level for 37075-00 part
*******************************************************************************************/
-- 

    v_counter NUMBER := 0;
    v_data_string varchar2(2000) := null;

CURSOR c_lots IS
SELECT DISTINCT geneo.comp_lot||',' comp_lot
FROM (SELECT 'Lot Source' direction
,  LEVEL AS comp_levels
, ci.segment1 component_item
, ci.inventory_item_id comp_item_id
, gen.comp_lot
, gen.assm_expiration_date
, gen.assm_rev assembly_revision
, gen.assm_lot assembly_lot
, gen.quantity_completed assm_quantity_completed
from 
(  select dj.wip_entity_id assm_job_id
  , lots.LOT_NUMBER comp_lot, lots.INVENTORY_ITEM_ID comp_item_id, lots.organization_id comp_org_id
  , ln.expiration_date assm_expiration_date
  , lots.quantity quantity
  , dj.LOT_NUMBER assm_lot, dj.primaRY_ITEM_ID assm_item_id, dj.organization_id assm_org_id
  , lots.LOT_NUMBER||'/'||lots.INVENTORY_ITEM_ID comp_key
  , dj.LOT_NUMBER||'/'||dj.primaRY_ITEM_ID assm_key
  , dj.bom_revision assm_rev
  , dj.quantity_completed
from  wip_discrete_jobs dj, mtl_lot_numbers ln
, (select transaction_source_id , AL5.INVENTORY_ITEM_ID, al5.organization_id, AL5.LOT_NUMBER, sum(al5.transaction_quantity) quantity
        , al5.expiration_date
        from APPS.MTL_TRANSACTION_LOT_VAL_V AL5
        where al5.transaction_source_type_id = 5
        group by transaction_source_id , AL5.INVENTORY_ITEM_ID, al5.organization_id
        , AL5.LOT_NUMBER, al5.expiration_date) lots
where lots.transaction_source_id = dj.wip_entity_id(+)
and dj.primary_item_id = ln.inventory_item_id
and dj.organization_id = ln.organization_id
and dj.lot_number = ln.lot_number
) gen
, mtl_system_items_b ci
WHERE gen.comp_item_id = ci.inventory_item_id
and gen.assm_org_id = ci.organization_id
 CONNECT BY NOCYCLE PRIOR gen.comp_key = gen.assm_key
  START WITH gen.comp_key = (select distinct l.lot_number||'/'||l.inventory_item_id
                                 FROM MTL_LOT_NUMBERS_ALL_v l
                                 WHERE l.inventory_item_id = 2296
                                 and l.lot_number = P_LOT_NUMBER)) geneo
, (	 SELECT A.NAME plan_name
   ,i.segment1 part_number
   ,b.item_id
   ,b.lot_number
   ,b.character4 cavity_core_rod
   ,b.character18 cavity_wall_thickness
   ,b.character20 core_rod_thickness
	from qa_plans a,
	     qa_results b,
       mtl_system_items_b i
	where a.plan_id = b.plan_id
	  AND A.organization_id = b.organization_id
    AND b.organization_id = i.organization_id
    AND b.item_id = i.inventory_item_id
AND A.NAME = '37075_00 SETUP_INSPECTION_PTO'
and i.segment1 = '37075-00') cp
WHERE geneo.component_item = '37075-00'
--DL removed 1/16/2012
--and geneo.comp_levels = 3
AND geneo.comp_item_id = cp.item_id(+)
AND geneo.comp_lot = cp.lot_number(+)
order by 1;


  BEGIN
    FOR lots IN C_LOTS loop

      IF v_data_string IS NULL THEN
        v_data_string := lots.comp_lot;
      else
        v_data_string := v_data_string||' '||lots.comp_lot;
      end if;

        v_counter := v_counter + 1;
    
      IF v_counter = 4 THEN
        v_counter := 0;
        v_data_string := v_data_string||chr(10);
      end if;

    END loop;
    
    v_data_string := ltrim(rtrim(rtrim(v_data_string,' '),','),',');
    v_data_string := rtrim(v_data_string,','||chr(10));
    RETURN v_data_string;

  END;

/
