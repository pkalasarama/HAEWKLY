create or replace FUNCTION xxha_wms_ship_method(
    p_ship_method VARCHAR2)
  RETURN VARCHAR2
/*******************************************************************************************************
  * Object Name: XXHA_WMS_RS_PRECISION_VAL
  * Object Type: FUNCTION
  *
  * Description: This Procedure will process rerateshop/ ondemand scenario	
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    27-JUN-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
AS
  l_ship_method VARCHAR2(100);
BEGIN
  BEGIN
    SELECT upper(meaning)
    INTO l_ship_method
    FROM FND_LOOKUP_VALUES ship_method
    WHERE ship_method.lookup_code=p_ship_method
    AND SHIP_METHOD.LOOKUP_TYPE  = 'SHIP_METHOD'
    AND SHIP_METHOD.LANGUAGE     = USERENV('LANG');
  EXCEPTION
  WHEN OTHERS THEN
    NULL;
  END;
RETURN l_ship_method;
END;
/