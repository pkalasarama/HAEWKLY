--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_RESCODE_DESC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_RESCODE_DESC" (p_res_code in VARCHAR2) return varchar2
as p_output varchar2 (400);

begin
  select description
  into p_output
  from csd_service_codes_vl
  where service_code = p_res_code;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_ResCode_Desc;

/
