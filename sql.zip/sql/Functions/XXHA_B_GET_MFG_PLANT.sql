--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_B_GET_MFG_PLANT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_B_GET_MFG_PLANT" (
   p_inventory_item_id    NUMBER,
   p_organization_id      NUMBER,
   p_rawwip               VARCHAR2 := 'N')
   -- +===========================================================================+
   -- | Name        : XXHA_B_GET_MFG_PLANT                                     |
   -- | Purpose     : Get current Primary Mfg. Plant assignment for an item       |
   -- | History                                                                   |
   -- | =======                                                                   |
   -- | When      Rev  Who       What                                             |
   -- | --------  ---  --------  ------------------------------------------------ |
   -- | 01/15/14  1.0  IMenzies      Initial version                              |
   -- +===========================================================================+
   RETURN VARCHAR2
IS
   l_plant   VARCHAR2 (4000 BYTE);
BEGIN
   BEGIN
      SELECT 'Service' plant
        INTO l_plant
        FROM DUAL
       WHERE EXISTS
                (SELECT 0
                   FROM apps.mtl_parameters mp
                  WHERE     mp.organization_id = p_organization_id
                        AND mp.attribute7 = 'Y');
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         BEGIN
            SELECT LISTAGG (
                         CASE
                            WHEN summary_group = 'Contract Manufacturing'
                            THEN
                               'Contract Mfg '
                            WHEN summary_group IS NOT NULL
                            THEN
                               summary_group || ' '
                         END
                      || plant_name
                      || ' - '
                      || allocation_percent
                      || '%',
                      ', ')
                   WITHIN GROUP (ORDER BY
                                    mp.allocation_percent DESC,
                                    mp.RANK,
                                    mp.sr_source_id)
                      plant
              INTO l_plant
              FROM apps.xxha_b_mfg_plant_asgn_c_v mp
             WHERE     rule_rnk = 1
                   AND mp.organization_id = p_organization_id
                   AND mp.inventory_item_id = decode(p_rawwip,'Y',-1,p_inventory_item_id)
                   AND mp.raw_wip_flag = p_rawwip;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               l_plant := 'Unspecified';
         END;
   END;

   RETURN l_plant;
END;

/
