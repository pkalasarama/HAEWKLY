--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_RA_TAX_AMOUNT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_RA_TAX_AMOUNT" (p_cust_trx_line_id number)
return number
as
lp_line_amount number;
begin
	 select extended_amount
	 into   lp_line_amount
	 from   ra_customer_trx_lines_all
	 where  link_to_cust_trx_line_id = p_cust_trx_line_id
			and line_type = 'TAX';
	 return lp_line_amount;
exception
		 when others then
		 	  lp_line_amount := 0;
			  return lp_line_amount;
end XX_HAEMO_RA_TAX_AMOUNT;

/
