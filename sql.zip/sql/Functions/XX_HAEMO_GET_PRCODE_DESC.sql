--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_PRCODE_DESC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_PRCODE_DESC" (p_prob_code in VARCHAR2) return varchar2
as p_output varchar2 (400);

begin
  select description
  into p_output
  from csd_diagnostic_codes_vl
  where diagnostic_code = p_prob_code;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_PrCode_Desc;

/
