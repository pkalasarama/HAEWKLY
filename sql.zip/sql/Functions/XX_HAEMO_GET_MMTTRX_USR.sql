--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_MMTTRX_USR
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_MMTTRX_USR" (p_mmttrx_id number)
return varchar2
is
lp_user_name varchar2(240);
begin
	 select fu.description
	 into   lp_user_name
	 from   mtl_material_transactions mmt
	   		, fnd_user fu
	 where  mmt.created_by = fu.user_id
	   		and mmt.transaction_id = p_mmttrx_id;
	 return lp_user_name;
exception
		 when others then
		 return null;
end xx_haemo_get_mmttrx_usr;

/
