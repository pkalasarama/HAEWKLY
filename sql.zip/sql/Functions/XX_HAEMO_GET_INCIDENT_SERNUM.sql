--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INCIDENT_SERNUM
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INCIDENT_SERNUM" (p_org_id IN NUMBER, p_incident_id IN NUMBER) RETURN VARCHAR2
as p_output VARCHAR2 (50);

Begin
  Select distinct serial_number
  into p_output
  from cs_charge_details_v
  where inc_org_id = p_org_id
  and incident_id = p_incident_id
  and serial_number is not null;
  Return NVL((p_output), 'N/A');
   
Exception
  WHEN OTHERS THEN
  p_output := 'N/A';
  RETURN NVL ((p_output),'N/A');

END XX_HAEMO_GET_Incident_SerNum;

/
