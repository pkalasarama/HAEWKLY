--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_LOT_STATUS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_LOT_STATUS" (p_org_id in number, p_item_id in number, p_lot_number in varchar) return varchar2
as p_output varchar2 (15);

begin
  select mstl.status_code
  into p_output
  from mtl_loT_numbers lot, mtl_material_statuses_b mstb, mtl_material_statuses_tl mstl
  where lot.status_id = mstb.status_id (+)
  AND mstb.status_id = mstl.status_id (+)
  AND mstl.language (+) =userenv('LANG') 
  and lot.organization_id = p_org_id
  and lot.inventory_item_id = p_item_id
  and lot.lot_number = p_lot_number;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Lot_Status;

/
