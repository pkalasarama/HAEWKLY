
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_FIND_LOCKED_ROWS" (
   v_rowid      ROWID,
   table_name   VARCHAR2
)
    /*******************************************************************************************************
    * Object Name: XXHA_FIND_LOCKED_ROWS
    * Object Type: FUNCTION
    *
    * Description: This function is used to find locked rows.
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/
  
   RETURN ROWID
  
IS
   x   NUMBER;
   PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   EXECUTE IMMEDIATE    'Begin
     Select 1 into :x from '
                     || table_name
                     || ' where rowid =:v_rowid for update nowait;
    Exception
     When Others Then
       :x:=null;
    End;'
               USING OUT x, v_rowid;

   ROLLBACK;

   IF x = 1
   THEN
      RETURN v_rowid;
   ELSIF x IS NULL
   THEN
      RETURN NULL;
   END IF;
END;
/