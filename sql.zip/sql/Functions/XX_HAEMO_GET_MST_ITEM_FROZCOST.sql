--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_MST_ITEM_FROZCOST
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_MST_ITEM_FROZCOST" (p_item_id in number)return number 
as p_output Number;

Begin
  Select item_cost
  into p_output
  from apps.cst_item_costs
  where organization_id = 103
  and inventory_item_id = p_item_id
  and cost_type_id = 1;
  return nvl ((p_output),0);

exception
  when others then
  p_output := 0;
  return nvl ((p_output),0);
end XX_HAEMO_Get_MST_Item_FrozCost;

/
