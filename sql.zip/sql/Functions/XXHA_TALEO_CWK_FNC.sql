--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_TALEO_CWK_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_TALEO_CWK_FNC" (p_person_id IN NUMBER)
RETURN VARCHAR AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_TALEO_CWK_FNC
 * Description:  This function will determine if a CWK Employee has 'Taleo User Type' populated.
 *               It is used by the view 'XXHA_TALEO_EMP_V'.
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      31-JUL-2014     Initial Function Creation
 *
 **********************************************************************************************************************************/

l_flag           VARCHAR(01) := NULL;

--------------------------------------------------------------------------------
-- Retrieve CWK Employees who have 'Taleo User Type' populated 
CURSOR cur_1 IS
SELECT 'Y'
  FROM  
     PER_ALL_PEOPLE_F             PEP
   , PER_ALL_ASSIGNMENTS_F        ASG
   , hr_all_organization_units    org
   , per_periods_of_service       ppos
   , (SELECT 
           PE.PERSON_ID
         , PE.PEI_INFORMATION3
       FROM  
           PER_PEOPLE_EXTRA_INFO  PE
       WHERE 
           PE.INFORMATION_TYPE    = 'HAE_TALEO_USER_TYPES'
       AND TRUNC(SYSDATE)         BETWEEN TRUNC(TO_DATE(PE.PEI_INFORMATION1,'YYYY/MM/DD HH24:MI:SS')) AND TRUNC(NVL(TO_DATE(PE.PEI_INFORMATION2,'YYYY/MM/DD HH24:MI:SS'), TRUNC(SYSDATE)))
       AND PE.PEI_INFORMATION3    IS NOT NULL) TUT
 WHERE
     PEP.PERSON_ID                = p_person_id
 AND PEP.PERSON_ID                = ASG.PERSON_ID
 AND TRUNC(SYSDATE)               BETWEEN PEP.EFFECTIVE_START_DATE AND PEP.EFFECTIVE_END_DATE
 AND TRUNC(SYSDATE)               BETWEEN ASG.EFFECTIVE_START_DATE AND ASG.EFFECTIVE_END_DATE
 AND asg.organization_id          = org.organization_id(+)
 AND asg.period_of_service_id     = ppos.period_of_service_id
 AND asg.primary_flag             = 'Y'
 AND HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE (TRUNC(sysdate),PEP.PERSON_ID) like 'HAE Contingent%'
 AND pep.person_id                = tut.person_id;

BEGIN

    BEGIN
        OPEN cur_1;
       FETCH cur_1 INTO l_flag;
       CLOSE cur_1;
    END;

    RETURN NVL(l_flag,'N');

END XXHA_TALEO_CWK_FNC;

/
