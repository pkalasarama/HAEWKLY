--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_IDM_END_DATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_IDM_END_DATE" (
  p_in_date IN DATE
, p_in_Str  IN VARCHAR2 DEFAULT NULL) RETURN DATE AS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_IDM_END_DATE
 * Description:  This Script will check a date against another date in a character field and return the appropriate value
 * Notes:
 *
 * Modified:      Ver     Date              Modification
 *-------------   -----   ----------        ----------------------------------------------------------------------------------------
 * BMarcoux               06-SEP-2013       Initial Function Creation
 * BMarcoux               12-DEC-2013       Since PPOS.ATTRIBUTE1 (Last Day Worked) is no longer a required field, return Actual Termination Date
 *                                            if Last Day Worked has no value.
 *
 **********************************************************************************************************************************/

    l_Date   DATE;
    l_Str    DATE;

BEGIN

    -- Add a day to input date if there's a value
    IF  p_in_date IS NOT NULL THEN
        l_Date := p_in_date + 1;
    END IF;

    -- Add a day to input string (Date DFF) if there's a value
    IF  p_in_Str IS NOT NULL THEN
        l_Str := TO_DATE((SUBSTR(p_in_Str,1,10) || ' 00:00:00'),'YYYY/MM/DD HH24:MI:SS') + 1;
    END IF;

    -- Take the least value of Actual Termination Date and Last Day Worked
    IF l_date IS NOT NULL AND l_Str IS NOT NULL THEN
       RETURN LEAST(l_Date, l_Str);
    -- If Last Day Worked is NULL then return Actual Termination Date
    ELSIF l_Date IS NOT NULL AND l_Str IS NULL THEN
       RETURN l_Date;
    ELSE
       RETURN NULL;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
         RETURN NULL;

END XXHA_IDM_END_DATE;

/
