--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_INV_TURNS_CLASSIF_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_INV_TURNS_CLASSIF_FNC" (
   p_inventory_item_id   IN   NUMBER,
   p_organization_id     IN   NUMBER
)
   RETURN VARCHAR2
IS
   lP_classification          VARCHAR2 (200) DEFAULT NULL;
   lp_sourcing_rule_id        NUMBER         := 0;
   lp_purchasing_count        NUMBER         := 0;
   lp_mfg_count               NUMBER         := 0;
   lp_transfer_count          NUMBER         := 0;
   lp_total_count             NUMBER         := 0;
   lp_source_org_null_count   NUMBER         := 0;

   CURSOR cur_org
   IS
      SELECT source_type.meaning source_type, ood.organization_code,
             msr.sourcing_rule_id
        FROM mrp_assignment_sets mas,
             mrp_sr_assignments msa,
             mrp_sourcing_rules msr,
             mrp_sr_receipt_org msro,
             mrp_sr_source_org msso,
             fnd_lookup_values source_type,
             org_organization_definitions ood
       WHERE mas.assignment_set_id = msa.assignment_set_id
         AND msa.sourcing_rule_id = msr.sourcing_rule_id
         AND msr.sourcing_rule_id = msro.sourcing_rule_id
         AND msro.sr_receipt_id = msso.sr_receipt_id
         AND msso.source_type = source_type.lookup_code
         AND source_type.lookup_type = 'MRP_SOURCE_TYPE'
         AND source_type.LANGUAGE = 'US'
         AND msso.source_organization_id = ood.organization_id
         AND msr.sourcing_rule_type = 1
         AND source_type.meaning <> 'Transfer From'
         AND msa.inventory_item_id = p_inventory_item_id
         AND msa.organization_id = p_organization_id;
BEGIN
   BEGIN
      SELECT msa.sourcing_rule_id
        INTO lp_sourcing_rule_id
        FROM mrp_assignment_sets mas, mrp_sr_assignments msa
       WHERE mas.assignment_set_id = msa.assignment_set_id
         AND msa.inventory_item_id = p_inventory_item_id
         AND msa.organization_id = p_organization_id;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         lP_classification := 'No Sourcing Rule FG';
      WHEN OTHERS
      THEN
         NULL;
   END;

   IF (lP_classification IS NULL)                 --First IF for classification
   THEN
      BEGIN
         SELECT   SUM (DECODE (source_type.meaning, 'Buy From', 1, 0))
                                                             purchasing_count,
                  SUM (DECODE (source_type.meaning, 'Make At', 1, 0))
                                                                    mfg_count,
                  SUM (DECODE (source_type.meaning, 'Transfer From', 1, 0))
                                                               transfer_count,
                  COUNT (*) total_count,
                  SUM (CASE
                          WHEN msso.source_organization_id IS NULL
                             THEN 1
                          ELSE 0
                       END) source_org_null_count
             INTO lp_purchasing_count,
                  lp_mfg_count,
                  lp_transfer_count,
                  lp_total_count,
                  lp_source_org_null_count
             FROM mrp_sourcing_rules msr,
                  mrp_sr_receipt_org msro,
                  mrp_sr_source_org msso,
                  fnd_lookup_values source_type
            WHERE msr.sourcing_rule_id = msro.sourcing_rule_id
              AND msro.sr_receipt_id = msso.sr_receipt_id
              AND msso.source_type = source_type.lookup_code
              AND source_type.lookup_type = 'MRP_SOURCE_TYPE'
              AND source_type.LANGUAGE = 'US'
              AND msr.sourcing_rule_type = 1
              AND msr.sourcing_rule_id = lp_sourcing_rule_id
         GROUP BY source_type.meaning;

         IF lp_source_org_null_count > 0
         THEN
            lP_classification := 'No Sourcing Rule FG';
         ELSIF lp_purchasing_count = lp_total_count
         THEN
            lP_classification := 'Purchase FG For all Org';
         ELSIF (lp_purchasing_count > 0 AND lp_mfg_count > 0)
         THEN
            lP_classification := 'FG with Make ''&'' Purchase Sourcing Rules';
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;

      IF (lP_classification IS NULL)             --Second IF for classification
      THEN
         FOR org_rec IN cur_org
         LOOP
            IF (   org_rec.organization_code = 'BDO'
                OR org_rec.organization_code = 'AVO'
               )
            THEN
               lP_classification := 'BDO + AVO';
            ELSIF (   org_rec.organization_code = 'UNO'
                   OR org_rec.organization_code = 'UPO'
                  )
            THEN
               lP_classification := 'UNO + UPO';
            ELSIF lp_total_count = 1
            THEN
               IF org_rec.organization_code = 'BTO'
               THEN
                  lP_classification := 'BTO';
               ELSIF org_rec.organization_code = 'GBX'
               THEN
                  lP_classification := 'GBX';
               ELSIF org_rec.organization_code = 'JPO'
               THEN
                  lP_classification := 'JPO';
               END IF;
            ELSIF lp_total_count > 1
            THEN
               lP_classification := 'Multi-Mfg-Org FG';
            END IF;
         END LOOP;
      END IF;                            --End of Second IF for classification
   END IF;                                --End of First IF for classification

   RETURN (lP_classification);
END XXHA_INV_TURNS_CLASSIF_FNC;

/
