CREATE OR REPLACE FUNCTION xxha_soa_date_test (p_date IN VARCHAR2)
/**********************************************************************************************************************************
*
* Package:     xxha_soa_date_test
* Description:   Used by OM forms personalization for date validation
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    13-OCT-2015  Initial Creation
**********************************************************************************************************************************/
   RETURN VARCHAR2
AS
   v_test   DATE;
BEGIN
   IF p_date IS NULL
   THEN
      RETURN 'Y';
   END IF;

   IF LENGTH (p_date) > 9
   THEN
      v_test := TO_DATE (p_date, 'dd-mon-yyyy hh:mi:ss am');
   ELSE
      v_test := TO_DATE (p_date, 'dd-mon-yy');
   END IF;

   RETURN 'Y';
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN 'N';
END;