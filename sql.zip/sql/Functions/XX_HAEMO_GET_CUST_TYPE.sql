--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_CUST_TYPE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_CUST_TYPE" (p_cust_id in number) return varchar2
as p_output varchar2 (200);
BEGIN
/* R12 Upgrade Modified on 09/28/2012 by Venkatesh Sarangam, Rolta */
  select arl.meaning
  INTO p_output
  FROM --apps.ra_customers rac,
       hz_parties hp, --
       hz_cust_accounts hca, --
       apps.ar_lookups arl
  WHERE --rac.customer_type = arl.lookup_code
       hp.party_id=hca.party_id --
  and  hca.customer_type = arl.lookup_code
  AND arl.lookup_type = 'CUSTOMER_TYPE'
 -- AND rac.customer_id = p_cust_id
  and hca.cust_account_id = p_cust_id;  --
  return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Cust_Type;

/
