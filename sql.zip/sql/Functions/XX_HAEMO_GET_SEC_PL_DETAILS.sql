--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_SEC_PL_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_SEC_PL_DETAILS" (PriceListId IN number,ItemId in number)
   RETURN VARCHAR2
IS
   v_PListId   NUMBER;
   v_SecPLDet varchar(500 char);
BEGIN
  select list_header_id into v_PListId from qp_secondary_price_lists_v
  where parent_price_list_id = to_char(PriceListId)
  and precedence = (select min(precedence) from qp_secondary_price_lists_v
                    where parent_price_list_id = to_char(PriceListId)
                    and start_date_active <= sysdate and (end_date_active >= sysdate or end_date_active is null));
  if v_PListId is null then
    return null;
  else
    select ht.name || ',' || hb.currency_code || ',' || to_char(lv.start_date_Active,'mm/dd/yyyy') || ',' || to_char(lv.end_date_active, 'mm/dd/yyyy') || ',' || lv.operand || ',' || to_char(hb.start_date_active, 'mm/dd/yyyy') || ',' || to_char(hb.end_date_active,'mm/dd/yyyy') 
    into v_SecPLDet
    from qp_list_headers_b hb inner join qp_list_headers_tl ht
    on hb.list_header_id = ht.list_header_id
    and ht.language = 'US'
    inner join qp_list_lines_v lv
    on hb.list_header_id = lv.list_header_id
    where lv.start_date_active <= sysdate and (lv.end_date_active >= sysdate or lv.end_date_active is null)
    and hb.list_header_id = v_PListId
    and lv.product_id = to_char(ItemId);
    
    if v_SecPLDet is null then
      return null;
    else
       return v_SecPLDet;
    end if;
  end if;
EXCEPTION
  WHEN OTHERS THEN
  return null;
END;

/
