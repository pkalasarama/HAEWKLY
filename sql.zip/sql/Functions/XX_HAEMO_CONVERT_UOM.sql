--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_CONVERT_UOM
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_CONVERT_UOM" (p_item_id number, p_qty number, p_to_uom varchar2)
return number
is
lp_qty number;
lp_rate number;
begin
	 select conversion_rate
	 into   lp_rate
	 from   mtl_uom_conversions
	 where  inventory_item_id = p_item_id
	 		and UPPER(uom_code) = UPPER(p_to_uom);
	 lp_qty := p_qty / lp_rate;
	 return lp_qty;
exception
		 when others then
		 return p_qty;
end XX_HAEMO_CONVERT_UOM;

/
