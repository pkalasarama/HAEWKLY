create or replace FUNCTION        "XXHA_WMS_RATESHOP_VALIDATION" (
    p_header_id NUMBER)
    /*******************************************************************************************************
    * Object Name: XXHA_WMS_RATESHOP_VALIDATION
    * Object Type: FUNCTION
    *
    * Description: This function will return rateshop validation
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    * Apps Associates    04-DEC-2015          included RERATESHOP
    *
    *******************************************************************************************************/

	RETURN VARCHAR2
AS
  l_status VARCHAR2(100);
  l_count  NUMBER;
BEGIN
  BEGIN
    SELECT COUNT(1)
    INTO l_count
    FROM wm_trackchanges
    WHERE SUBSTR(comments,25)=p_header_id
    AND transaction_type     in ('RATESHOP','RERATESHOP')
    AND processed_flag       ='Y';
    IF l_count               !=0 THEN
      l_status              :='Y';
    ELSE
      l_status:='N';
    END IF;
  EXCEPTION
  WHEN no_data_found THEN
    l_status:='N';
  END;
RETURN l_status;
END;
/