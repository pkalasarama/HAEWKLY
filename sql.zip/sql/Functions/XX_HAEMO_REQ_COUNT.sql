--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_REQ_COUNT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_REQ_COUNT" (p_op_unit varchar2, p_preparer varchar2, p_auth_status varchar2, p_type varchar2)
return number
is
lp_org_id number(15);
lp_person number(10);
lp_req_count number(10);
begin
	 select count(distinct prh.segment1)
	 into   lp_req_count
	 from   po_requisition_headers_all prh
	 	   , hr_operating_units hr
		   , per_people_f ppf
	 where  prh.org_id = hr.organization_id
	   		and prh.preparer_id = ppf.person_id
	   		and hr.name = p_op_unit
	   		and ppf.full_name = p_preparer
	   		and prh.authorization_status = UPPER(p_auth_status)
	   		and prh.type_lookup_code = UPPER(p_type);
	 return lp_req_count;
end XX_HAEMO_REQ_COUNT;

/
