CREATE OR REPLACE
FUNCTION XXHA_LAST_USAGE_DATE_FNC(p_user_id IN NUMBER, p_responsibility_id IN NUMBER)
RETURN VARCHAR AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_LAST_USAGE_DATE_FNC
 * Description:  This function will determine when the last date a responsibility was used.
 *               This function is used by the Procedure HAEMO_Resp_last_u_date_n.
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      28-JUL-2015     Initial Function Creation
 *
 **********************************************************************************************************************************/

l_start_time         VARCHAR(100) := NULL;

BEGIN

   -- Retrieve the most recent use of the responsibility
   SELECT
       to_char(flr.start_time,'DD-MON-YYYY HH24:MI:SS') last_usage
   INTO 
       l_start_time
   FROM
       fnd_logins                 fl
     , fnd_login_Responsibilities flr
   WHERE
       fl.user_id(+)            = p_user_id
   AND fl.login_id              = flr.login_id
   AND flr.responsibility_id(+) = p_responsibility_id
   AND ROWNUM                   = 1
   ORDER BY 
       flr.start_time DESC;

   RETURN l_start_time;

EXCEPTION
   WHEN OTHERS THEN
        l_start_time := NULL;
        RETURN l_start_time;

END XXHA_LAST_USAGE_DATE_FNC;