CREATE OR REPLACE FUNCTION "APPS"."XXHA_WMS_SUPP_PREC_FUNC" ( P_ORG_CODE varchar2, P_SHIP_METHOD varchar2)
  /*******************************************************************************************************
  * Object Name: XXHA_WMS_SUPP_PREC_FUNC
  * Object Type: FUNCTION
  *
  * Description: This function will be used to get list of ship methods
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    16-JAN-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
return varchar2
is
L_COUNT varchar2(1) ;
begin
select COUNT(1) into L_COUNT from FND_LOOKUP_VALUES where LOOKUP_TYPE = 'XXHA_WMS_SUPPRESS_PRECISION' 
and LOOKUP_CODE like P_ORG_CODE||':'||P_SHIP_METHOD;

if L_COUNT <> 0 then 
return 'Y';
else 
return 'N';
end if;
EXCEPTION when OTHERS then 
return 'N';
end;
/