--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_OP_UNIT_DESC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_OP_UNIT_DESC" (p_org_id in number) return Varchar2
as p_output Varchar2 (200);
begin
/* R12 Upgrade Modified on 10/04/2012 by Venkatesh Sarangam, Rolta */
  /*select operating_unit
  into p_output
  FROM aso_i_operating_units_v
  where org_id = p_org_id;*/
  select name
  into p_output
  from hr_operating_units
  where organization_id = p_org_id;
  return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Op_Unit_Desc;

/
