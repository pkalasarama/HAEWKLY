
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_HOLD_ATTR" ( p_header_id NUMBER)
    RETURN NUMBER
    /*******************************************************************************************************
    * Object Name: XXHA_HOLD_ATTR
    * Object Type: FUNCTION
    *
    * Description: This function will return hold details
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/

	AS
    l_hold_rateshop NUMBER;
  BEGIN
    SELECT COUNT(1)
    INTO l_hold_rateshop
    FROM oe_order_holds_all ooha,
      oe_hold_sources_all ohsa,
      OE_HOLD_DEFINITIONS ohd
    WHERE ooha.header_id   = p_header_id
    AND ooha.released_flag = 'N'
    AND ooha.hold_source_id= ohsa.hold_source_id
    AND ohsa.hold_id       = ohd.hold_id
    AND ohd.attribute1     = 'N';
    fnd_file.put_line(fnd_file.log, 'l_hold_rateshop:'||l_hold_rateshop);
    RETURN l_hold_rateshop;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log, 'l_hold_rateshop EXCEPTION'||SQLERRM);
    RETURN 0;
  END;
  /