
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_GET_QTY_CNT_F" ( p_qty number, p_qty_sub number, p_load_item_id number ) 
  return varchar2
    /*******************************************************************************************************
    * Object Name: XXHA_GET_QTY_CNT_F
    * Object Type: FUNCTION
    *
    * Description: This function will return quantities
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/

  is 
l_max_qty number;
l_min_qty number;
lp_qty number;
l_output varchar2(1000);
l_qty_cnt number := 0;
begin
-- Get the max load quantity for item 
select max(max_load_quantity) into l_max_qty from wsh_container_items where load_item_id = p_load_item_id;
lp_qty := p_qty;
dbms_output.put_line('lp_qty initial value '||lp_qty);

--if input qty is less than max load quantity get the immediate greater or equal value and return.
if lp_qty < l_max_qty then 
	l_min_qty := 0;
  select min(max_load_quantity) into l_min_qty from wsh_container_items where load_item_id = p_load_item_id and max_load_quantity >= lp_qty;
  l_output := l_output || l_min_qty;
  dbms_output.put_line('l_output less if '||l_output);
  
  	if p_qty_sub = l_min_qty then -- to capture count
	  l_qty_cnt := l_qty_cnt +1;
	  dbms_output.put_line('l_qty_cnt if '||l_qty_cnt);
	end if;

end if;

--if input qty is greater than max load quantity concatenated quantities will be calculated and returned.
while (lp_qty >= l_max_qty) loop

dbms_output.put_line('p_qty_sub:'||p_qty_sub||', l_max_qty:'||l_max_qty);
 if p_qty_sub = l_max_qty then -- to capture count
  l_qty_cnt := l_qty_cnt +1;
  dbms_output.put_line('l_qty_cnt loop '||l_qty_cnt);
 end if;

 l_output := l_output || l_max_qty;
 lp_qty := lp_qty - l_max_qty; 
 dbms_output.put_line('lp_qty deducted value '||lp_qty);
 
 if (lp_qty < l_max_qty AND lp_qty > 0 ) --lp_qty < l_max_qty 
 then 
	l_output := l_output ||',';
	l_min_qty := 0;
	select min(max_load_quantity) into l_min_qty from wsh_container_items where load_item_id = p_load_item_id and max_load_quantity >= lp_qty;
	l_output := l_output || l_min_qty;
	dbms_output.put_line('l_output if'||l_output);
		if p_qty_sub = l_min_qty then -- to capture count
		l_qty_cnt := l_qty_cnt +1;
		dbms_output.put_line('l_qty_cnt loop if '||l_qty_cnt);
		end if;
		
   elsif lp_qty >= l_max_qty then
	l_output := l_output ||',';
	dbms_output.put_line('l_output elsif '||l_output);
 end if;
 
 dbms_output.put_line('lp_qty '||lp_qty);
 dbms_output.put_line('l_output loop '||l_output);
end loop;

dbms_output.put_line('l_output, l_qty_cnt '||l_output||','||l_qty_cnt);
return l_qty_cnt;
exception when others then 
null;
return null;
end;
/