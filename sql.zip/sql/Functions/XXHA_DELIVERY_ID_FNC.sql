CREATE OR REPLACE
FUNCTION XXHA_DELIVERY_ID_FNC(p_delivery_id IN NUMBER)
RETURN VARCHAR AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_DELIVERY_ID_FNC
 * Description:  This function will be used by WebMethods to determine if a Delivery ID is valid
 * Notes:
 *
 * Modified:      CR#         Ver     Date          Modification
 *-------------   ---------   -----   -----------   ----------------------------------------------------------------------------------------
 * BMarcoux       ESC113784   1.0     11-NOV-2014   Initial Function Creation
 *
 **********************************************************************************************************************************/

l_Process             VARCHAR2(02) := NULL;

--------------------------------------------------------------------------------
-- Retrieve Delivery Record
CURSOR cur_1(c_delivery_id NUMBER)
IS
SELECT 'Y'
FROM 
    wsh_new_deliveries        wnd
  , wsh_delivery_assignments  wda
  , wsh_delivery_details      wdd
  , oe_order_headers_all      oh
  , oe_order_lines_all        ol
    
WHERE
    wnd.delivery_id         = p_delivery_id
AND wnd.delivery_id         = wda.delivery_id
AND wda.delivery_detail_id  = wdd.delivery_detail_id
AND wdd.source_header_id    = oh.header_id
AND wdd.source_line_id      = ol.line_id
;

BEGIN

    -- See if Delivery ID Exists
    OPEN  cur_1(p_delivery_id);
    FETCH cur_1 INTO l_Process;
    CLOSE cur_1;

    IF l_Process IS NOT NULL THEN
       RETURN l_Process;
    ELSE
       RETURN 'N';
    END IF;

END;