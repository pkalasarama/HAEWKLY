--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_SALES_6MON
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_SALES_6MON" (p_org_id in number, p_item_id in number) return number as 
p_output NUMBER;

begin 
      select sum(primary_quantity)
      into p_output
      from invfg_material_transactions
      where organization_id = p_org_id
      and inventory_item_id = p_item_id
      and trunc(transaction_date) between add_months(trunc(sysdate,'mm'),-6) and add_months(last_day(trunc(sysdate)),-1)
      and transaction_source_type_id in (2,8)
      and transaction_type_id in (33,50);
      return nvl((p_output),0);

exception 
      when others then
      p_output := 0;
      return nvl((p_output),0);
end XX_HAEMO_Get_Sales_6Mon;

/
