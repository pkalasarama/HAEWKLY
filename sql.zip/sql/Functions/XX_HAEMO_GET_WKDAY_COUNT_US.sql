--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_WKDAY_COUNT_US
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_WKDAY_COUNT_US" (p_from_date in date, p_to_date in date) return number as p_output NUMBER;

begin 
      select sum(case when (to_char(calendar_date,'DY') in ('MON','TUE','WED','THU','FRI')) then count(calendar_date) ELSE 0 END)
      into p_output
      from bom_calendar_dates
      where calendar_code = 'HAE_4-4-5'
      and calendar_date between p_from_date and p_to_date
      group by calendar_date;
      return nvl((p_output),0);

exception 
      when others then
      p_output := 0;
      return nvl((p_output),0);
end XX_HAEMO_Get_Wkday_Count_US;

/
