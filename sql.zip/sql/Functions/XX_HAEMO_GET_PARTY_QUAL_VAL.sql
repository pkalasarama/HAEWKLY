--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_PARTY_QUAL_VAL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_PARTY_QUAL_VAL" (p_attr_col varchar2, p_attr_val varchar2)
return varchar2
is
lp_attr_val varchar2(4000);
begin
	 if p_attr_col = 'QUALIFIER_ATTRIBUTE1' then
	 	select PARTY_NUMBER
		into   lp_attr_val
		from   HZ_PARTIES
		where  TO_CHAR(PARTY_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE2' then
	 	select PARTY_NUMBER
		into   lp_attr_val
		from   HZ_PARTIES
		where  TO_CHAR(PARTY_ID) = p_attr_val;
	 elsif p_attr_col = 'QUALIFIER_ATTRIBUTE3' then
	 	select NAME
		into   lp_attr_val
		from   HR_OPERATING_UNITS
		where  TO_CHAR(ORGANIZATION_ID) = p_attr_val;
	 end if;
	 return lp_attr_val;
exception
		 when others then
		 	  return null;
end XX_HAEMO_GET_PARTY_QUAL_VAL;

/
