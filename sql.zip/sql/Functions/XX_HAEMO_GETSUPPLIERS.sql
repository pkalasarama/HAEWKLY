--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GETSUPPLIERS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GETSUPPLIERS" (itemid  number, orgid number)
  RETURN VARCHAR2
IS
  l_text  VARCHAR2(4000) := NULL;
BEGIN
  FOR cur_rec IN
  (
  select pov.vendor_name
  from MRP_SR_ASSIGNMENTS MSA inner join MRP_SR_RECEIPT_ORG MRO
  on MSA.sourcing_rule_id = MRO.sourcing_rule_id
  and (trunc(sysdate) between trunc(mro.effective_date) and trunc(mro.disable_date) or trunc(mro.disable_date) is null)
  inner join MRP_SR_SOURCE_ORG MSO
  on mro.sr_receipt_id = mso.sr_receipt_id
  --inner join MSC_TRADING_PARTNERS MTP
  --on MSO.source_partner_id = MTP.partner_id
  inner join
/* R12 Upgrade Modified on 10/08/2012 by Venkatesh Sarangam, Rolta */
--PO_VENDORS POV
  ap_suppliers pov
  --on MTP.sr_tp_id = POV.vendor_id
  on MSO.vendor_id = POV.vendor_id
  where MSA.inventory_item_id = itemid
  and MSA.organization_id = orgid
  )
  LOOP
    l_text := l_text || ', ' || cur_rec.vendor_name;
  END LOOP;
  RETURN LTRIM(l_text, ', ');
end;

/
