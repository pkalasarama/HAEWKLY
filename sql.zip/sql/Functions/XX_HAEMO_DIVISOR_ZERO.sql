--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_DIVISOR_ZERO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_DIVISOR_ZERO" (p_numerator number, p_denominator number)
return number
is
lp_result number;
begin
	 if p_denominator <> 0 then
	 	lp_result := p_numerator/p_denominator;
	 else
	 	 lp_result := 0;
	 end if;	 
	 return lp_result;
end;

/
