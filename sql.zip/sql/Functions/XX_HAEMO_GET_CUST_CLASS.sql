--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_CUST_CLASS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_CUST_CLASS" (p_cust_id in number) return varchar2
as p_output varchar2 (200);
BEGIN
/* R12 Upgrade Modified on 10/08/2012 by Venkatesh Sarangam, Rolta */
  /*select arl.meaning
  into p_output
  from apps.ra_customers rac, apps.ar_lookups arl
  where rac.customer_id = p_cust_id
  and rac.customer_class_code = arl.lookup_code
  and arl.lookup_type = 'CUSTOMER CLASS';*/
  select arl.meaning
  into p_output
  from apps.hz_parties hp,
       apps.hz_cust_accounts hca,
       apps.ar_lookups arl
  where hca.cust_account_id = p_cust_id
  AND hca.customer_class_code = arl.lookup_code
  and arl.lookup_type = 'CUSTOMER CLASS';
   return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Cust_Class;

/
