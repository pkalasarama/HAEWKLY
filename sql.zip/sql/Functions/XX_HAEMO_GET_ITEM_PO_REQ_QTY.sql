--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_ITEM_PO_REQ_QTY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_ITEM_PO_REQ_QTY" (p_org_id in number, p_item_id in number, p_subinv in varchar2)return number 
as p_output Number;

Begin
  Select sum(quantity)
  into p_output
  from invfg_inventory_supplies
  where to_organization_id = p_org_id
  and inventory_item_id = p_item_id
  and to_subinventory_name = p_subinv
  and supply_type_code IN ('REQ','PO');
  return nvl ((p_output),0);

exception
  when others then
  p_output := 0;
  return nvl ((p_output),0);
end XX_HAEMO_Get_Item_PO_Req_Qty;

/
