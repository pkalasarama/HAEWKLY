--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_ITEM_SERIAL_NUMB
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_ITEM_SERIAL_NUMB" (p_org_id IN NUMBER, p_trans_id IN NUMBER) RETURN VARCHAR2
as p_output VARCHAR2 (500);

CURSOR c1 IS
  Select serial_number 
  from apps.mtl_unit_transactions_all_v
  where organization_id = p_org_id
  and transaction_id = p_trans_id;
  
BEGIN
   For C1rec IN c1 loop
   select p_output || DECODE(p_output, NULL, c1rec.serial_number,'/'||c1rec.serial_number)
   into p_output
   from dual;
   
   end loop;
   
   Return NVL((p_output), 'N/A');
   
Exception
  WHEN OTHERS THEN
  p_output := 'N/A';
  RETURN NVL ((p_output),'N/A');
END XX_HAEMO_GET_Item_Serial_Numb;

/
