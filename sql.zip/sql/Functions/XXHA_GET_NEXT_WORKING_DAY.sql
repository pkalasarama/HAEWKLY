--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_GET_NEXT_WORKING_DAY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_GET_NEXT_WORKING_DAY" (p_organization_id number, p_todays_date date default sysdate, p_forward_days number default 0, p_default_forward boolean default true, p_call_sequence number default 1, p_recursive_limit number default 20)
return date is
/*****************************************************************************************
* Name/Purpose : xxha_get_next_working_day (get Next Working Day from Calandar)          *
*                p_Organization_id for calendar                                          *
*                p_todays_date Date from where to find next working day                  *
*                p_forward_days number of days to move forward                           *
*                           (-) negative value would mean move backward (prior date)     *
*                p_call_sequence for internal use call values as 1                       *
*                p_recursive_limit to fail on recursion logic fail                       *
*                                  protect from infinite loop                            *
*                                                                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 10-OCT-2012     Manuel Fernandes     Initial Creation                                  *
*****************************************************************************************/
  cursor c_working_day(x_organization_id number, x_todays_date date) is
      SELECT nvl(BCD.SEQ_NUM,-1)
      FROM   BOM_CALENDAR_DATES BCD,
             MTL_PARAMETERS MP
      WHERE  MP.ORGANIZATION_ID   = x_organization_id
        AND  BCD.CALENDAR_CODE    = MP.CALENDAR_CODE
        AND  BCD.EXCEPTION_SET_ID = MP.CALENDAR_EXCEPTION_SET_ID
        AND  BCD.CALENDAR_DATE    = TRUNC(x_todays_date);
  cursor c_forward(x_organization_id number, x_todays_date date, x_forward_days number) is
    SELECT BCD1.CALENDAR_DATE
    FROM   BOM_CALENDAR_DATES BCD1,
           BOM_CALENDAR_DATES BCD2,
           MTL_PARAMETERS MP
    WHERE  MP.ORGANIZATION_ID    = x_organization_id
      AND  BCD1.CALENDAR_CODE    = MP.CALENDAR_CODE
      AND  BCD2.CALENDAR_CODE    = MP.CALENDAR_CODE
      AND  BCD1.EXCEPTION_SET_ID = MP.CALENDAR_EXCEPTION_SET_ID
      AND  BCD2.EXCEPTION_SET_ID = MP.CALENDAR_EXCEPTION_SET_ID
      AND  BCD2.CALENDAR_DATE    = TRUNC(x_todays_date)
     AND  BCD1.SEQ_NUM = NVL(BCD2.SEQ_NUM, BCD2.NEXT_SEQ_NUM) + CEIL(abs(x_forward_days));
  cursor c_backward(x_organization_id number, x_todays_date date, x_forward_days number) is
    SELECT BCD1.CALENDAR_DATE
    FROM   BOM_CALENDAR_DATES BCD1,
           BOM_CALENDAR_DATES BCD2,
           MTL_PARAMETERS MP
    WHERE  MP.ORGANIZATION_ID    = x_organization_id
      AND  BCD1.CALENDAR_CODE    = MP.CALENDAR_CODE
      AND  BCD2.CALENDAR_CODE    = MP.CALENDAR_CODE
      AND  BCD1.EXCEPTION_SET_ID = MP.CALENDAR_EXCEPTION_SET_ID
      AND  BCD2.EXCEPTION_SET_ID = MP.CALENDAR_EXCEPTION_SET_ID
      AND  BCD2.CALENDAR_DATE    = TRUNC(x_todays_date)
      AND  BCD1.SEQ_NUM = NVL(BCD2.SEQ_NUM, BCD2.PRIOR_SEQ_NUM)
                             --(new_proc_days) + 1 - CEIL(lt); --Bug2331915
                             - FLOOR(abs(x_forward_days));
l_return_date date := null;
v_dummy number := null;
v_todays_date date := null;
v_date date := null;
v_partial_day number;
begin
  if p_call_sequence > p_recursive_limit then
    --dbms_output.put_line('recursion limit reached');
    return null; -- set this to null later
  end if;
  v_partial_day := p_todays_date - trunc(p_todays_date);
  v_todays_date := p_todays_date;
  open c_working_day(p_organization_id, v_todays_date);
  fetch c_working_day into v_dummy;
  if c_working_day%notfound then
    close c_working_day;
    return null;
  end if;
  if v_dummy = -1 then
    v_todays_date := null;
  end if;
  close c_working_day;
  while v_todays_date is null -- date is not defined as p_todays_date is not a working day
  loop
    v_todays_date := xxha_get_next_working_day(p_organization_id, p_todays_date +1, 0, p_default_forward, p_call_sequence +1, p_recursive_limit);
    if v_todays_date is null then
      return null;
    end if;
  end loop;
  if v_todays_date is null then
    return trunc(v_todays_date)+ v_partial_day;
  end if;
  if p_forward_days = 0 then
    return trunc(v_todays_date) +v_partial_day;
  end if;
  --dbms_output.put_line('Todays Date :'||to_char(v_todays_date));
  if p_forward_days != 0 then
    if p_forward_days > 0 then
      --dbms_output.put_line('Moving forward:'||to_char(p_forward_days));
      open c_forward(p_organization_id, v_todays_date, p_forward_days);
      fetch c_forward into v_date;
      if c_forward%notfound then
        close c_forward;
        return null;
      end if;
      close c_forward;
      return trunc(v_date) +v_partial_day;
    end if;
    if p_forward_days < 0 then
      --dbms_output.put_line('Moving backward :'||to_char(p_forward_days));
      open c_backward(p_organization_id, v_todays_date, abs(p_forward_days));
      fetch c_backward into v_date;
      if c_backward%notfound then
        close c_backward;
        return null;
      end if;
      close c_backward;
      return trunc(v_date) +v_partial_day;
    end if;
  end if;
  return null;
end;

/
