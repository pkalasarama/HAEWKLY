create or replace FUNCTION XXHA_MATERIAL_CERT_LOTNUMBER
(
    p_view              IN VARCHAR2
  , p_collection_id     IN NUMBER
  , p_occurrence        IN NUMBER
)
RETURN VARCHAR2 IS

/**********************************************************************************************************************************
 *
 * Function:     XXHA_MATERIAL_CERT_LOTNUMBER
 * Description:  This function will return the Lot_Expiration_Date if it exists in a Quality Plan View
 *               If a Quality Plan View does not have the column Lot_Expiration_Date, it will return a NULL Value
 *               It is used by the view 'XXHA_MATERIAL_CERT_V'.
 * Notes:
 *
 * Modified:     Ver    Date         Modification
 *-------------  -----  -----------  ----------------------------------------------------------------------------------------------
 * BMarcoux      1.0    16-FEB-2017  Initial Function Creation for Legacy Certs
 *
 **********************************************************************************************************************************/

   query_str           VARCHAR2(1000);
   Lot_number          VARCHAR2(100);

BEGIN

   query_str := 'SELECT LOT_NUMBER FROM ' || p_view || ' WHERE collection_id = :collection_id and occurrence = :occurrence';

   EXECUTE IMMEDIATE query_str
           INTO lot_number
           USING p_collection_id, p_occurrence;

   RETURN lot_number;

   EXCEPTION
        WHEN NO_DATA_FOUND THEN
             RETURN NULL;
        WHEN OTHERS THEN
             RETURN NULL;

END;