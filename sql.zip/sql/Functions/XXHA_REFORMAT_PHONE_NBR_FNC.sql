--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_REFORMAT_PHONE_NBR_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_REFORMAT_PHONE_NBR_FNC" (p_phone_nbr IN VARCHAR2)
RETURN VARCHAR2 AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_REFORMAT_PHONE_NBR_FNC
 * Description:  This function will reformat the phone number
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      11-DEC-2013     Initial Function Creation
 *
 **********************************************************************************************************************************/

    l_phone_number                VARCHAR2(100) := NULL;
    l_phone_number_in             VARCHAR2(100) := NULL;
    v_ch                          VARCHAR2(100) := NULL;
    v_temp                        VARCHAR2(100) := NULL;
    i                             INTEGER       := 0;

BEGIN

    l_phone_number_in := p_phone_nbr;
    l_phone_number    := p_phone_nbr;

    BEGIN

        -- Remove any non-numeric values from input phone number
        IF LENGTH(l_phone_number) > 0 THEN
           FOR i IN 1..LENGTH(l_phone_number) LOOP
               v_ch := SUBSTR(l_phone_number,i,1);
               IF v_ch BETWEEN '0' AND '9' THEN
                  v_temp := v_temp || v_ch;
               END IF;
           END LOOP;
        END IF;

    END;

    -- If first character of phone number is '1', remove it
    IF SUBSTR(v_temp,1,1) = '1'
       THEN v_temp := SUBSTR(v_temp,2,LENGTH(v_temp));
    END IF;

    -- Reformat phone number 
    IF LENGTH(v_temp) = 10 THEN
       RETURN (SUBSTR(v_temp,1,3) || '-' || SUBSTR(v_temp,4,3) ||  '-' || SUBSTR(v_temp,7,4));
    ELSE
       RETURN l_phone_number_in;
    END IF;

END XXHA_REFORMAT_PHONE_NBR_FNC;

/
