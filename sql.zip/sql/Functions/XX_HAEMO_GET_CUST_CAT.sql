--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_CUST_CAT
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_CUST_CAT" (p_cust_id in number) return varchar2
as p_output varchar2 (200);
BEGIN
/* R12 Upgrade Modified on 10/03/2012 by Venkatesh Sarangam, Rolta */
 /* select arl.meaning
  into p_output
  from apps.ra_customers rac, apps.ar_lookups arl
  where rac.customer_id = p_cust_id
  and rac.customer_category_code = arl.lookup_code
  AND arl.lookup_type = 'CUSTOMER_CATEGORY';*/
  SELECT ar1.meaning
  INTO p_output
  FROM hz_parties hp,
       hz_cust_accounts hca,
  apps.ar_lookups ar1
  WHERE hca.cust_account_id = p_cust_id
    AND hp.category_code = ar1.lookup_code
    AND hp.party_id = hca.party_id
    and ar1.lookup_type = 'CUSTOMER_CATEGORY';

  return nvl((p_output),'N/A');
exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Cust_Cat;

/
