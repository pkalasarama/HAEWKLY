
  CREATE OR REPLACE FUNCTION "APPS"."XXHA_WMS_ORG_VALIDATION" (
    p_organization_CODE VARCHAR2)
    /*******************************************************************************************************
    * Object Name: XXHA_WMS_ORG_VALIDATION
    * Object Type: FUNCTION
    *
    * Description: This function will return org validation details
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/
	
  RETURN VARCHAR2
AS
  l_status VARCHAR2(100);
BEGIN
  BEGIN
    SELECT 'Y'
    INTO l_status
    FROM fnd_lookup_values
    WHERE lookup_type='XXHA_WMS_ORGS'
    AND language     ='US'
    and enabled_flag='Y'
    and trunc(sysdate) between trunc(start_date_active) and trunc(nvl(end_date_active,sysdate))
    AND lookup_code  =p_organization_code;
  EXCEPTION
  WHEN no_data_found THEN
    l_status:='N';
  END;
RETURN l_status;
END;
/