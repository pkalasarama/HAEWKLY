--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INVLINE_SLSREP
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INVLINE_SLSREP" (p_org_id IN NUMBER, p_cust_trx_id IN NUMBER, p_cust_trx_line_id IN NUMBER) return VARCHAR2
as p_output varchar2 (200);

BEGIN
  Select jrs.name
  INTO p_output
  FROM RA_CUST_TRX_LINE_SALESREPS_ALL ras, jtf_rs_salesreps jrs
  where ras.org_id = jrs.org_id 
  and ras.salesrep_id = jrs.salesrep_id
  and ras.org_id = p_org_id
  and ras.customer_trx_id = p_cust_trx_id
  and ras.customer_trx_line_id  = p_cust_trx_line_id;
  RETURN NVL((p_output),'N/A');

EXCEPTION
  WHEN OTHERS THEN
  p_output := 'N/A';
  RETURN NVL((p_output),'N/A');
END XX_HAEMO_Get_InvLine_Slsrep;

/
