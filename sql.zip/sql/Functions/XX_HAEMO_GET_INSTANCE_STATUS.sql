--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_INSTANCE_STATUS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_INSTANCE_STATUS" (p_status_id in number) return varchar2
as p_output varchar2 (240);

begin

  select description
  into p_output
  from csi_instance_statuses
  where instance_status_id = p_status_id;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_Instance_Status;

/
