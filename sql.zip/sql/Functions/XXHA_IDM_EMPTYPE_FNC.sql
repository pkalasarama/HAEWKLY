CREATE OR REPLACE
FUNCTION XXHA_IDM_EMPTYPE_FNC(p_date in DATE, p_person_id IN NUMBER, p_ATTRIBUTE13 IN VARCHAR)
RETURN VARCHAR AS
/**********************************************************************************************************************************
 *
 * Function:     XXHA_IDM_EMPTYPE_FNC
 * Description:  This function will determine the Employee Type based upon Person ID, Person Type and PER.ATTRIBUTE13.
 *               This function is used by the view XXHA_IDM_RECON_V.
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 *-------------    -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      08-AUG-2014     Initial Function Creation
 *
 **********************************************************************************************************************************/

l_PERSON_TYPE           per_person_types_tl.user_person_type%TYPE := NULL;
l_EMPLOYEE_TYPE         VARCHAR(100) := NULL;

BEGIN

    IF HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE (TRUNC(p_date), P_PERSON_ID) LIKE '%.%' THEN
       l_PERSON_TYPE := SUBSTR(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(p_date), P_PERSON_ID), 1, INSTR(hr_person_type_usage_info.get_user_person_type(TRUNC(p_date),P_PERSON_ID),'.',1,1)-1);
    ELSE
       l_PERSON_TYPE := HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(p_date), P_PERSON_ID);
    END IF;

    IF l_PERSON_TYPE = 'Employee' or l_PERSON_TYPE = 'Ex-employee' THEN
       l_EMPLOYEE_TYPE := 'Full-Time';
    ELSIF l_PERSON_TYPE = 'HAE Contingent Worker' OR l_PERSON_TYPE = 'HAE Ex-contingent Worker' THEN
          IF NVL(UPPER(p_ATTRIBUTE13),'YES') = 'YES' THEN
             l_EMPLOYEE_TYPE := 'CWK';
          ELSE
             l_EMPLOYEE_TYPE := 'CWK No email account';
          END IF;
    END IF;

    RETURN l_EMPLOYEE_TYPE;

END XXHA_IDM_EMPTYPE_FNC;