--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XX_HAEMO_GET_USER_NAME
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XX_HAEMO_GET_USER_NAME" (p_user_id in number) return varchar2
as p_output varchar2 (50);

begin
  select user_name
  into p_output
  from fnd_user
  where user_id = p_user_id;
  return nvl((p_output),'N/A');

exception
  when others then
  p_output := 'N/A';
  return nvl((p_output),'N/A');
end XX_HAEMO_Get_User_name;

/
