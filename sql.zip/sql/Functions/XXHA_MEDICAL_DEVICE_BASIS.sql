--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_MEDICAL_DEVICE_BASIS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_MEDICAL_DEVICE_BASIS" (
/*****************************************************************************************
* Name/Purpose : XXHA_MEDICAL_DEVICE_BASIS_DDL_3.sql                                     *
* Description  : creates                                                                 *
*                function xxha_medical_device_basis                                      *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 09-JAN-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
p_transaction_amount number,
p_disc1_percentage number,
p_disc2_percentage number,
p_markdown_factor number
) return number is
v_amount number;
v_excise_amount number;
begin
  if nvl(p_transaction_amount,0) = 0 then
     return 0;
  end if;
  v_amount := p_transaction_amount;
  if nvl(p_disc1_percentage,0) != 0 then
    v_amount := v_amount * p_disc1_percentage;
  end if;
  if nvl(p_disc2_percentage,0) != 0 then
    v_amount := v_amount * p_disc2_percentage;
  end if;
  if nvl(p_markdown_factor,0) != 0 then
    v_amount := v_amount / p_markdown_factor;
  end if;
  return v_amount;
end ;

/
