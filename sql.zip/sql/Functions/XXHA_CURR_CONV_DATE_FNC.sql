--------------------------------------------------------
--  File created - Saturday-November-22-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function XXHA_CURR_CONV_DATE_FNC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "APPS"."XXHA_CURR_CONV_DATE_FNC" (p_current_code VARCHAR2
                                                        , p_target_code VARCHAR2)
 RETURN DATE
 IS
   l_date date;  
                     
 BEGIN                          
     select conversion_date
     into   l_date
     from   apps.gl_daily_rates 
     where  conversion_type = 'Corporate'               
     and    conversion_date = Last_Day(ADD_MONTHS(trunc(sysdate),-2))+1
     and    from_currency = p_current_code
     and    to_currency = p_target_code;
                          
     if l_date is not null
        then return l_date;
     else return sysdate;
     end if;                  
                     
 EXCEPTION
 WHEN OTHERS THEN
       RETURN sysdate;
 END XXHA_CURR_CONV_DATE_FNC;
 

/
