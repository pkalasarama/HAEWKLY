CREATE OR REPLACE package      xxha_contract_approval_wf as



                   procedure XXHA_Admin_Approver(    itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2    ) ;


procedure XXHA_Contract_Chg_Date(    itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2    );

end  xxha_contract_approval_wf;

/


CREATE OR REPLACE PACKAGE BODY      xxha_contract_approval_wf
AS
   PROCEDURE xxha_admin_approver (
      itemtype    IN              VARCHAR2,
      itemkey     IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      resultout   OUT NOCOPY      VARCHAR2
   )
   IS
      l_initiator_display_name        VARCHAR2 (240);
      l_next_performer_username       VARCHAR2 (240);
      l_next_performer_username_out   VARCHAR2 (240);
      l_n_performer_display_name      VARCHAR2 (240);
      lv_contract_id                  NUMBER;
      lv_performer                    VARCHAR2 (240);
   BEGIN
      --
      -- RUN mode - normal process execution
      --
      IF (funcmode = 'RUN')
      THEN
         lv_contract_id :=
            wf_engine.getitemattrtext (itemtype      => itemtype,
                                       itemkey       => itemkey,
                                       aname         => 'CONTRACT_ID'
                                      );

         SELECT fsr.user_name
           INTO lv_performer
           FROM jtf_rs_all_resources_vl jtf,
                okc_contacts_v ocv,
                per_all_people_f per,
                fnd_user fsr
          WHERE jtf.resource_id = ocv.object1_id1
            AND ocv.cro_code = 'ADMIN'
            AND fsr.employee_id = per.person_id
            AND per.party_id = jtf.person_party_id
            AND ocv.dnz_chr_id = lv_contract_id
            AND TRUNC (SYSDATE) BETWEEN per.effective_start_date
                                    AND per.effective_end_date;

         wf_engine.setitemattrtext (itemtype      => itemtype,
                                    itemkey       => itemkey,
                                    aname         => 'XXHAE_PERFORMER',
                                    avalue        => lv_performer
                                   );
         resultout := 'COMPLETE:';
      END IF;

      RETURN;

        -- CANCEL mode
      --
      IF (funcmode = 'CANCEL')
      THEN
         --
         resultout := 'COMPLETE:';
         RETURN;
      --
      END IF;

      --
      -- TIMEOUT mode
      --
      IF (funcmode = 'TIMEOUT')
      THEN
         --
         resultout := 'COMPLETE:';
         RETURN;
      --
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         wf_core.CONTEXT ('OKC_WF_K_APPROVE',
                          'SELECT_APPROVER',
                          itemtype,
                          itemkey,
                          TO_CHAR (actid),
                          funcmode
                         );
         RAISE;
   END xxha_admin_approver;

   PROCEDURE xxha_contract_chg_date (
      itemtype    IN              VARCHAR2,
      itemkey     IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      resultout   OUT NOCOPY      VARCHAR2
   )
   IS
      l_initiator_display_name        VARCHAR2 (240);
      l_next_performer_username       VARCHAR2 (240);
      l_next_performer_username_out   VARCHAR2 (240);
      l_n_performer_display_name      VARCHAR2 (240);
      lv_start_date                   DATE;
      lv_end_date                     DATE;
      lv_contract_id                  NUMBER;
      l_duration                      NUMBER;
      l_timeunits                     VARCHAR2 (1000);
      x_return_status                 VARCHAR2 (1000);
   BEGIN
      --
      -- RUN mode - normal process execution
      --
      IF (funcmode = 'RUN')
      THEN
         lv_contract_id :=
            wf_engine.getitemattrtext (itemtype      => itemtype,
                                       itemkey       => itemkey,
                                       aname         => 'CONTRACT_ID'
                                      );
         lv_start_date :=
            wf_engine.getitemattrtext (itemtype      => itemtype,
                                       itemkey       => itemkey,
                                       aname         => 'XXHSS_CONTRACT_START_DATE'
                                      );
         lv_end_date :=
            wf_engine.getitemattrtext (itemtype      => itemtype,
                                       itemkey       => itemkey,
                                       aname         => 'XXHSS_CONTRACT_END_DATE'
                                      );

         IF lv_start_date IS NOT NULL AND lv_end_date IS NOT NULL
         THEN
            UPDATE okc_k_headers_b
               SET start_date = lv_start_date,
                   end_date = lv_end_date
             WHERE ID = lv_contract_id;

            UPDATE okc_k_lines_b
               SET start_date = lv_start_date,
                   end_date = lv_end_date
             WHERE chr_id = lv_contract_id;

            UPDATE okc_k_lines_b
               SET start_date = lv_start_date,
                   end_date = lv_end_date
             WHERE dnz_chr_id = lv_contract_id;
                                           ---AND CHR_ID IS NULL AND LSE_ID=9;

            okc_time_util_pub.get_duration (p_start_date         => lv_start_date,
                                            p_end_date           => lv_end_date,
                                            x_duration           => l_duration,
                                            x_timeunit           => l_timeunits,
                                            x_return_status      => x_return_status
                                           );

            UPDATE oks_stream_levels_b
               SET start_date = lv_start_date,
                   end_date = lv_end_date
             WHERE dnz_chr_id = lv_contract_id;

            UPDATE oks_level_elements
               SET date_start = lv_start_date,
                   date_end = lv_end_date,
                   date_to_interface = lv_start_date,
                   date_transaction = lv_start_date
             WHERE dnz_chr_id = lv_contract_id;

            resultout := wf_engine.eng_completed || ':' || 'T';

         ELSIF lv_start_date IS NULL AND lv_end_date IS NOT NULL
         THEN
            resultout := wf_engine.eng_completed || ':' || 'F';
         ELSIF lv_end_date IS NULL AND lv_start_date IS NOT NULL
         THEN
            resultout := wf_engine.eng_completed || ':' || 'F';
            ELSE  resultout := wf_engine.eng_completed || ':' || 'T';
         END IF;
      ---   resultout := 'COMPLETE:';
      END IF;

      RETURN;

      IF (funcmode = 'CANCEL')
      THEN
         --
         resultout := wf_engine.eng_completed || ':' || 'F';
         RETURN;
      --
      END IF;

      --
      -- TIMEOUT mode
      --
      IF (funcmode = 'TIMEOUT')
      THEN
         --
         resultout := wf_engine.eng_completed || ':' || 'F';
         RETURN;
      --
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         wf_core.CONTEXT ('OKC_WF_K_APPROVE',
                          'Change_Contract_Date',
                          itemtype,
                          itemkey,
                          TO_CHAR (actid),
                          funcmode
                         );
         RAISE;
   END xxha_contract_chg_date;
END xxha_contract_approval_wf;

/
