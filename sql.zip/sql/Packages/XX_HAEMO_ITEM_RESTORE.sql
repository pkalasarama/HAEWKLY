CREATE OR REPLACE package xx_haemo_item_restore
is
procedure xx_haemo_item_main (p_language varchar2);
end xx_haemo_item_restore;
/


CREATE OR REPLACE package body xx_haemo_item_restore
is
procedure xx_haemo_item_main (p_language varchar2)
is
v_desc varchar2(240);
cursor c_items_old
is
  select distinct inventory_item_id
  from   mtl_system_items_tl
  where  language = p_language
  		 and description is null;
begin
	for r_items_old in c_items_old loop
		select distinct description
		into   v_desc
		from   mtl_system_items_tl
		where  inventory_item_id = r_items_old.inventory_item_id
			   and language = 'US';
		update mtl_system_items_tl
		set    description = v_desc
		where  language = p_language
			   and inventory_item_id = r_items_old.inventory_item_id;
	end loop;
	commit;
end xx_haemo_item_main;
end xx_haemo_item_restore;
/
