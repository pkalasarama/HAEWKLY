CREATE OR REPLACE package xxha_medet_tax
/*****************************************************************************************
* Name/Purpose : XXHA_MEDET_TAX_PKG_DDL_5.sql                                           *
* Description  : creates                                                                 *
*                package xxha_medet_tax                                                  *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 09-JAN-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
as
  disc1_percentage number := null;
  disc2_percentage number := null;
  markdown_factor number := null;
  excise_percentage number := null;
  org_id number := null;
  tax_date date := null;
  function get_disc1_percentage(p_org_id number, p_date date) return number;
  function get_disc2_percentage(p_org_id number, p_date date) return number;
  function get_markdown_factor(p_org_id number, p_date date) return number;
  function get_excise_percentage(p_org_id number, p_date date) return number;
  procedure upload(err_buf out varchar2, ret_code out number, pv_log_messages varchar2, pv_from_date varchar2, pv_to_date varchar2, pv_category_set_name varchar2);
end;
/


CREATE OR REPLACE package body xxha_medet_tax
/*****************************************************************************************
* Name/Purpose : XXHA_MEDET_TAX_PKG_DDL_5.sql                                           *
* Description  : creates                                                                 *
*                package body xxha_medet_tax                                             *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 09-JAN-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
is
  function dummy return number is
  begin
    return 0;
  end;
  procedure init_rates(p_org_id number, p_date date) is
    cursor c1(x_org_id number, x_tax_code varchar2, x_date date) is
    select org_id, start_date, end_date, b.tax_rate, tax_code from AR_VAT_TAX_ALL_B b
    where org_id = x_org_id
    and   tax_code = x_tax_code
    and   x_date >= start_date
    and   x_date <= nvl(end_date,x_date); 
  begin
    if not (xxha_medet_tax.org_id is not null and xxha_medet_tax.tax_date is not null and p_org_id = xxha_medet_tax.org_id and xxha_medet_tax.tax_date = p_date) then
      xxha_medet_tax.org_id := p_org_id;
      xxha_medet_tax.tax_date := p_date;
      for i in c1(p_org_id, 'MDETRI', p_date)
      loop
        xxha_medet_tax.disc1_percentage := i.tax_rate;
      end loop;
      for i in c1(p_org_id, 'MDETRC', p_date)
      loop
        xxha_medet_tax.disc2_percentage := i.tax_rate;
      end loop;
      for i in c1(p_org_id, 'MDET', p_date)
      loop
        xxha_medet_tax.excise_percentage := i.tax_rate;
      end loop;
      xxha_medet_tax.markdown_factor := 1;
      for i in c1(p_org_id, 'MDETMD', p_date)
      loop
        xxha_medet_tax.markdown_factor := i.tax_rate;
      end loop;
    end if;
  end;  
  function get_disc1_percentage(p_org_id number, p_date date) return number is
  begin
    xxha_medet_tax.init_rates(p_org_id, p_date);
    return xxha_medet_tax.disc1_percentage;
  end;
  function get_disc2_percentage(p_org_id number, p_date date) return number is
  begin
    xxha_medet_tax.init_rates(p_org_id, p_date);
    return xxha_medet_tax.disc2_percentage;
  end;
  function get_markdown_factor(p_org_id number, p_date date) return number is
  begin
    xxha_medet_tax.init_rates(p_org_id, p_date);
    return xxha_medet_tax.markdown_factor;
  end;
  function get_excise_percentage(p_org_id number, p_date date) return number is
  begin
    xxha_medet_tax.init_rates(p_org_id, p_date);
    return xxha_medet_tax.excise_percentage;
  end;
    procedure upload(err_buf out varchar2, ret_code out number, pv_log_messages varchar2, pv_from_date varchar2, pv_to_date varchar2, pv_category_set_name varchar2) is
    begin
      xxha_medex_upload(err_buf,              ret_code,            pv_log_messages,          pv_from_date,          pv_to_date,          pv_category_set_name);
    end;
end;
/
