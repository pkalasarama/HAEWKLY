CREATE OR REPLACE package XXHA_PO_TEXT_ATTACH_PKG as

GC_SYSDATE date := TRUNC(sysdate);
GN_USER_ID FND_USER.USER_ID%type := FND_GLOBAL.USER_ID;
GN_LOGIN_ID FND_USER.USER_ID%type := FND_PROFILE.value('LOGIN_ID');
G_LANG VARCHAR2(20);
GC_RECORD_ERROR          VARCHAR2(5)              :='E';
GC_RECORD_SUCCESS        VARCHAR2(5)              :='S';
gc_error_msg varchar2(2000);


--PROCEDURE INSERT_LONG_TEXT;

PROCEDURE MAIN_PROC(ERRBUF    OUT VARCHAR2 ,
      RETCODE                 OUT VARCHAR2);

PROCEDURE INSERT_FND_DOC_TAB(
p_media_id IN NUMBER,
P_DESCRIPTION in varchar2,
po_number1 in varchar2
);

procedure attach_doc_fnd(p_media_id IN NUMBER,
P_DOCUMENT_ID IN NUMBER,
p_entity IN VARCHAR2,
p_id IN VARCHAR2,
p_category_id IN NUMBER,
P_DATATYPE_ID IN NUMBER,
P_DESCRIPTION in varchar2,
po_number2 in varchar2);

end xxha_po_text_attach_pkg;

/


CREATE OR REPLACE package body XXHA_PO_TEXT_ATTACH_PKG as

--procedure INSERT_LONG_TEXT is
PROCEDURE MAIN_PROC(ERRBUF    OUT VARCHAR2 ,
      RETCODE                 OUT VARCHAR2) is
cursor L_GET_TXT_CUR  is
select * from XXHA_PO_HEADER_TEXT_STG
where
PO_DESCRIPTION IS NOT NULL
and flag is null;
P_MEDIA_ID NUMBER;
PONUM VARCHAR2(20);
PONUM1 VARCHAR2(20);
counter_no number;
BEGIN
COUNTER_NO := 0; --To concatenate unique number along with text_tepe(po_description)
PONUM1 := null;
-- Get next media id seq for long text
FOR L_GET_TXT_REC IN L_GET_TXT_CUR
LOOP
ponum:=L_GET_TXT_REC.po_number;
SELECT fnd_documents_long_text_s.nextval
INTO p_media_id
FROM DUAL;

/* commented by sreeram
IF PONUM=PONUM1 THEN
COUNTER_NO:=COUNTER_NO+1;
ELSE
COUNTER_NO:=NULL;
COUNTER_NO:=1;
end if;
*/
COUNTER_NO:=COUNTER_NO+1;

-- load into long text table
INSERT INTO fnd_documents_long_text(
MEDIA_ID, LONG_TEXT )
VALUES (P_MEDIA_ID,L_GET_TXT_REC.PO_DESCRIPTION);
FND_FILE.PUT_LINE(FND_FILE.LOG,'media_id='||P_MEDIA_ID);
--DBMS_OUTPUT.PUT_LINE('media_id='||P_MEDIA_ID);
--DBMS_OUTPUT.PUT_LINE('po_number'||L_GET_TXT_REC.PO_NUMBER);
update XXHA_PO_HEADER_TEXT_STG set FLAG='S' where PO_NUMBER=PONUM;
--XXHA_PO_TEXT_ATTACH.INSERT_FND_DOC_TAB(P_MEDIA_ID,L_GET_TXT_REC.po_description,L_GET_TXT_REC.po_number);
XXHA_PO_TEXT_ATTACH_PKG.INSERT_FND_DOC_TAB(P_MEDIA_ID,L_GET_TXT_REC.TEXT_TYPE||COUNTER_NO,L_GET_TXT_REC.PO_NUMBER);
ponum1:=L_GET_TXT_REC.po_number;
end loop;
EXCEPTION
WHEN OTHERS THEN
--DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM,1,80 ));
--DBMS_OUTPUT.PUT_LINE('po_number2: '||PONUM);
GC_ERROR_MSG:='Insert Long Text' ||' '||SQLERRM;
UPDATE XXHA_PO_HEADER_TEXT_STG SET FLAG='E',ERROR_MSG=GC_ERROR_MSG WHERE PO_NUMBER=PONUM;
/*RETCODE:=-1;
errbuf := SQLCODE||':'||SQLERRM;*/
fnd_file.put_line(fnd_file.log,SUBSTR(sqlerrm,1,80 ));
--RAISE;
end main_proc;

PROCEDURE INSERT_FND_DOC_TAB(
p_media_id IN NUMBER,
P_DESCRIPTION in varchar2,
PO_NUMBER1 in varchar2) is

E_INSERT_ERROR EXCEPTION;
E_INSERT_ERROR1 EXCEPTION;
l_category_id number;
l_datatype_id number;
L_ROWID rowid;
L_MEDIA_ID number;
G_LANG VARCHAR2(20);
HEADER_ID varchar2(20);
P_DOCUMENT_ID NUMBER;
CNT NUMBER; --category count
cnt1 number; --header count
BEGIN
-- get next sequence val for fnd_documents
select FND_DOCUMENTS_S.NEXTVAL
INTO p_document_id
from DUAL;


select COUNT(PO_HEADER_ID) into CNT1
from PO_HEADERS_ALL where SEGMENT1=PO_NUMBER1 group by PO_HEADER_ID;


IF CNT1 = 1 THEN
select PO_HEADER_ID into HEADER_ID
from PO_HEADERS_ALL where SEGMENT1=PO_NUMBER1;
else
RAISE E_INSERT_ERROR1;
end if;

select USERENV ('LANG') into G_LANG from DUAL;

SELECT COUNT(DCT. CATEGORY_ID)
INTO cnt
from FND_DOCUMENT_CATEGORIES_TL DCT,
    FND_DOC_CATEGORY_USAGES DCU,
    FND_ATTACHMENT_FUNCTIONS AF
    WHERE DCT.CATEGORY_ID=DCU.CATEGORY_ID
    AND DCU.ATTACHMENT_FUNCTION_ID=AF.ATTACHMENT_FUNCTION_ID
    AND AF.FUNCTION_NAME = 'PO_POXPOEPO'
    and DCT.LANGUAGE = USERENV('LANG')
    AND DCT.USER_NAME = 'To Supplier'--'Documents'
    group by DCT. CATEGORY_ID;

    if CNT = 1 then
    SELECT DCT. CATEGORY_ID
INTO l_category_id
from FND_DOCUMENT_CATEGORIES_TL DCT,
    FND_DOC_CATEGORY_USAGES DCU,
    FND_ATTACHMENT_FUNCTIONS AF
    WHERE DCT.CATEGORY_ID=DCU.CATEGORY_ID
    AND DCU.ATTACHMENT_FUNCTION_ID=AF.ATTACHMENT_FUNCTION_ID
    AND AF.FUNCTION_NAME = 'PO_POXPOEPO'
    and DCT.LANGUAGE = USERENV('LANG')
    and DCT.USER_NAME = 'To Supplier';--'Documents';
    else
    RAISE E_INSERT_ERROR;
    end if;
SELECT datatype_id
INTO l_datatype_id
from FND_DOCUMENT_DATATYPES
WHERE name = 'LONG_TEXT'--'SHORT_TEXT' -- again, pick whatever kind of attachment you loaded
and LANGUAGE = G_LANG;
l_media_id:=p_media_id;
--fnd_global.APPS_INITIALIZE('1318','50578','201');
fnd_documents_pkg.insert_row
( X_ROWID                        => l_rowid
, X_DOCUMENT_ID                  => p_document_id
, X_CREATION_DATE                => GC_SYSDATE
, X_CREATED_BY                   => GN_USER_ID
, X_LAST_UPDATE_DATE             => GC_SYSDATE
, X_LAST_UPDATED_BY              => GN_USER_ID
, X_LAST_UPDATE_LOGIN            => GN_LOGIN_ID
, X_DATATYPE_ID                  => l_datatype_id
, X_CATEGORY_ID                  => l_category_id
, X_SECURITY_TYPE                => 2
, X_PUBLISH_FLAG                 => 'Y'
, X_USAGE_TYPE                   => 'O'
, X_LANGUAGE                     => 'US'
, X_DESCRIPTION                  => P_DESCRIPTION
, X_FILE_NAME                    => NULL--L_FILENAME
, X_MEDIA_ID                     => L_MEDIA_ID
,X_CREATE_DOC                    => 'Y'
);
update XXHA_PO_HEADER_TEXT_STG set FLAG='S' where PO_NUMBER=PO_NUMBER1;
COMMIT;
/*DBMS_OUTPUT.PUT_LINE ('document id is '||P_DOCUMENT_ID);
DBMS_OUTPUT.PUT_LINE ('media_id is '||L_MEDIA_ID);
DBMS_OUTPUT.PUT_LINE ('category_id is '||L_CATEGORY_ID);
DBMS_OUTPUT.PUT_LINE ('datatype_id is '||L_DATATYPE_ID);
DBMS_OUTPUT.PUT_LINE ('DESCRIPTION is '||P_DESCRIPTION);*/
FND_FILE.PUT_LINE(FND_FILE.log,'document id is '||P_DOCUMENT_ID);
fnd_file.put_line(fnd_file.log,'media_id is '||L_MEDIA_ID);
FND_FILE.PUT_LINE(FND_FILE.log,'category_id is '||L_CATEGORY_ID);
fnd_file.put_line(fnd_file.log,'datatype_id is '||L_DATATYPE_ID);
FND_FILE.PUT_LINE(FND_FILE.log,'DESCRIPTION is '||P_DESCRIPTION);
XXHA_PO_TEXT_ATTACH_PKG.ATTACH_DOC_FND(L_MEDIA_ID,P_DOCUMENT_ID,'PO_HEADERS',header_id,l_category_id,L_DATATYPE_ID,P_DESCRIPTION,po_number1);
EXCEPTION
WHEN E_INSERT_ERROR THEN
--dbms_output.put_line(SUBSTR(sqlerrm,1,80 ));
--dbms_output.put_line('po_number3: '||po_number1);
GC_ERROR_MSG:=GC_ERROR_MSG ||' '||'Documents category is not attached';
UPDATE XXHA_PO_HEADER_TEXT_STG SET FLAG='E',ERROR_MSG=GC_ERROR_MSG WHERE PO_NUMBER=PO_NUMBER1;
FND_FILE.PUT_LINE(FND_FILE.LOG,'Error:'||SQLERRM);
WHEN E_INSERT_ERROR1 THEN
--dbms_output.put_line(SUBSTR(sqlerrm,1,80 ));
--dbms_output.put_line('po_number4: '||po_number1);
GC_ERROR_MSG:=GC_ERROR_MSG ||' '||'Getting multiple header ids';
UPDATE XXHA_PO_HEADER_TEXT_STG SET FLAG='E',ERROR_MSG=GC_ERROR_MSG WHERE PO_NUMBER=PO_NUMBER1;
FND_FILE.PUT_LINE(FND_FILE.LOG,'Error:'||SQLERRM);
when OTHERS then
FND_FILE.PUT_LINE(FND_FILE.LOG,SUBSTR(SQLERRM,1,80 ));
--DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM,1,80 ));
--DBMS_OUTPUT.PUT_LINE('po_number5: '||PO_NUMBER1);
GC_ERROR_MSG:='Insert Documents:' ||' '||SQLERRM;
rollback;
update XXHA_PO_HEADER_TEXT_STG set FLAG='E',ERROR_MSG=GC_ERROR_MSG where PO_NUMBER=PO_NUMBER1;
COMMIT;
--RAISE;
end INSERT_FND_DOC_TAB;

procedure attach_doc_fnd(p_media_id IN NUMBER,
P_DOCUMENT_ID IN NUMBER,
p_entity IN VARCHAR2,
p_id IN VARCHAR2,
p_category_id IN NUMBER,
P_DATATYPE_ID IN NUMBER,
P_DESCRIPTION in varchar2,
po_number2 in varchar2)
IS
v_rowid VARCHAR2(50);
v_attached_document_id NUMBER;
V_FUNC VARCHAR2(20):='attach_doc_fnd';
L_SEQ_NUM number;
E_INSERT_ERROR EXCEPTION;
L_MEDIA_ID NUMBER;
l_document_id number;
BEGIN
SELECT fnd_attached_documents_s.nextval
INTO v_attached_document_id
from SYS.DUAL;

SELECT NVL(MAX(seq_num),0) + 10
INTO l_seq_num
from FND_ATTACHED_DOCUMENTS
where ENTITY_NAME = 'PO_HEADERS'--P_ENTITY_NAME
and PK1_VALUE = P_ID;

SELECT userenv ('LANG') INTO g_lang FROM dual;
L_MEDIA_ID:=P_MEDIA_ID;
L_DOCUMENT_ID:=P_DOCUMENT_ID;
--call oracle api
fnd_attached_documents_pkg.insert_row (
x_rowid => v_rowid,
x_attached_document_id => v_attached_document_id,
x_document_id => l_document_id,
x_creation_date => GC_SYSDATE,
x_created_by => GN_USER_ID,
x_last_update_date => GC_SYSDATE,
x_last_updated_by => GN_USER_ID,
X_LAST_UPDATE_LOGIN => GN_LOGIN_ID,
x_seq_num => l_seq_num,
x_entity_name => p_entity,
x_column1 => NULL,
x_pk1_value => p_id,
x_pk2_value => NULL,
x_pk3_value => NULL,
x_pk4_value => NULL,
x_pk5_value => NULL,
x_automatically_added_flag => 'N',
x_datatype_id => p_datatype_id,
x_category_id => p_category_id,
x_security_type => 1,
x_security_id => NULL,
x_publish_flag => 'Y',
x_image_type => NULL,
x_storage_type => NULL,
X_USAGE_TYPE => 'O',
X_LANGUAGE => G_LANG,
x_description => p_description,
x_file_name => NULL,
X_MEDIA_ID => L_MEDIA_ID);
IF (v_rowid IS NULL) THEN
RAISE e_insert_error;
end if;
update XXHA_PO_HEADER_TEXT_STG set FLAG='S' where PO_NUMBER=PO_NUMBER2;
COMMIT;
--dbms_output.put_line(' Attached Doc id:'||V_ATTACHED_DOCUMENT_ID);
fnd_file.put_line(fnd_file.log,' Attached Doc id:'||V_ATTACHED_DOCUMENT_ID);
EXCEPTION
WHEN E_INSERT_ERROR THEN
--DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM,1,80 ));
FND_FILE.PUT_LINE(FND_FILE.LOG,SUBSTR(SQLERRM,1,80 ));
GC_ERROR_MSG:=GC_ERROR_MSG ||' '||SQLERRM;
update XXHA_PO_HEADER_TEXT_STG set FLAG='E',ERROR_MSG=GC_ERROR_MSG where PO_NUMBER=PO_NUMBER2;
when OTHERS then
FND_FILE.PUT_LINE(FND_FILE.LOG,SUBSTR(SQLERRM,1,80 ));
--DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM,1,80 ));
GC_ERROR_MSG:='Attach Doc' ||' '||SQLERRM;
UPDATE XXHA_PO_HEADER_TEXT_STG SET FLAG='E',ERROR_MSG=GC_ERROR_MSG WHERE PO_NUMBER=PO_NUMBER2;
--RAISE;
END ATTACH_DOC_FND;
end XXHA_PO_TEXT_ATTACH_PKG;

/
