CREATE OR REPLACE package      XXHA_ECO_PROCESS_ECO
-- +=====================================================================================+
-- | Name        : XXHA_ECO_PROCESS_ECO                                                  |
-- | Purpose     : Support the Interface of ECO into EBS.                                |
-- |                                                                                     |
-- | Description : For this interface, ECO nd Items are received                         |
-- |               at organizations (including master [MST]),                            |
-- |               ECO and Items                                                         |
-- |               Data is provided in 4 staging tables:                                 |
-- |                  XXHA_ECO_REVISIONS_STG                                             |
-- |                  XXHA_ECO_ITEMS_STG                                                 |
-- |                  XXHA_ITEM_CST_DTLS_STG                                             |
-- |                  XXHA_ITEM_PRICE_LIST_STG                                           |
-- |                                                                                     |
-- |               Staged data is propcessed.  If all data is succcessfully              |
-- |               processed objects are then moved to the appropiate                    |
-- |               interface tables.  This includes the ECO and                          |
-- |               item objects are processed and an error are inserted in               |
-- |               common error table..                                                  |
-- |                                                                                     |
-- |                                                                                     |
-- |                                                                                     |
-- | Comment       : This package interfaces eco, it does  launch                        |
-- |                 standard Import Items program.                                      |
-- |                                                                                     |
-- | History                                                                             |
-- | =======                                                                             |
-- | When      Rev  Who       What                                                       |
-- | --------  ---  --------  ------------------------------------------------           |
-- | 20090315  1.0  Palash Kundu      Initial version                                    |
-- | 20090501  1.1  Palash Kundu      Changed code to accomodate Fastpack DFF            |
-- | 20090615  1.2  Palash Kundu      Changed code to accomodate Non Rev Org Assignment  |
-- | 20091021  1.3  Vasil S. Valkov   Changed package to process one ECO at a time,      |
-- |                                  Mark every staging tables record as PS even if     |
-- |				                  ECO is rejected.                                   |
-- |                                  Ensure that item revision is moved every time.     |
-- | 20100301  1.4  Raj Reddy         Item cost load and Std cost update changes.        |
-- | 20100521  1.5  Dave Lund         Added logic to insert records into cost import     |
-- |                                  table if item exists in the org                    |
-- | 20100708  1.6  Vasil S. Valkov   Removed commented out SQL to support ERP104321     |
-- | 20120112  1.7  Vasil S. Valkov   Added code to round cost to a given precision.     |
-- |                                  Added code for adding item and its price to all    |
-- |                                  price lists is supposed to go to.                  |
-- |                                  The price is calculated based on the cost, uplift  |
-- |                                  factor and currency factor.                        |
-- |                                  Added a new method for manually adding an item to  |
-- |                                  the price lists - ADD_EXIST_ITEM_PRICE_LIST.       |
-- | 20121221  3.0  Bruce Marcoux     Corrected issue with details being written to      |
-- |                                  output.  Stringing of data to 'l_return_msg'       |
-- |                                  caused the field length to be exceeded.  As a      |
-- |                                  result, the updates failed.                        |
-- +=====================================================================================+
AS
       --GlobalVariables
      gn_record_number         xxha_common_errors.record_number%TYPE;                                          --Record_number of staging table
      gc_record_identifier     xxha_common_errors.record_identifier%TYPE;                                      --Record identifier of staging table
      gc_error_code            xxha_common_errors.error_code%TYPE;                                             --Error_code insert in common error table
      gc_error_msg             xxha_common_errors.error_msg%TYPE;                                              --Error_msg  insert in common error table
      gc_comments              xxha_common_errors.comments%TYPE;                                               --Comments   insert in common error table
      gc_attribute1            xxha_common_errors.attribute1%TYPE;                                             --Attribute1 insert in common error table
      gc_attribute2            xxha_common_errors.attribute2%TYPE;                                             --Attribute2 insert in common error table
      gc_attribute3            xxha_common_errors.attribute3%TYPE;                                             --Attribute3 insert in common error table
      gc_attribute4            xxha_common_errors.attribute4%TYPE := 'N';                                             --Attribute4 insert in common error table
      gc_attribute5            xxha_common_errors.attribute5%TYPE;                                             --Attribute5 insert in common error table
      gc_table_name            xxha_common_errors.table_name%TYPE;                                             --Variable to get Staging Table Name
      gc_status                VARCHAR2(2);                                                                    --Variable to get status flag of data insertion in common error table
      gc_conc_name             fnd_concurrent_programs.concurrent_program_name%TYPE;-- :='XXHA_ITEM_CONV_P2';        --Concurrent program name to delete the records from common error table
      gn_request_id            xxha_common_errors.request_id%TYPE                   := fnd_global.conc_request_id;--Request Id of running concurrent Program
      gc_error_logged  varchar2(1);
	  
	  -- VV: added for ver2.1 2012-01-12 (price list)
	  gc_line_type_code        fnd_lookup_values.lookup_code%TYPE:='PLL';
	  gc_prc_attribute         qp_segments_b.segment_mapping_column%TYPE:='PRICING_ATTRIBUTE1';
	  gc_prc_context_code      qp_prc_contexts_b.prc_context_code%TYPE:='ITEM';
	  
PROCEDURE processing_eco
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
  --      ,p_commit_flag  in  varchar2
--		,p_force_commit in varchar2
        );


--PROCEDURE UPDATE_COST_TYPE;

--PROCEDURE LOAD_CST_ITEM_CST_DTLS_INT;

--PROCEDURE VALIDATE_ITEM_CST_DTLS_STG;

PROCEDURE populate_fnd_log
	 (  p_flag  in varchar2,
	    p_msg   in varchar2
	 );

PROCEDURE process_eco_item_cost
        (  p_debug_flag  in varchar2,
           p_return_msg out varchar2
        );

PROCEDURE POPULATE_ITEM_COST;

PROCEDURE INS_ROLLED_ITEM_COST
		( x_errbuf out  varchar2,
          x_retcode out  varchar2,
		  p_item in  varchar2,
		  p_item_cost in  number,
		  p_flag in  varchar2
		);

procedure process_eco_item_price_list
        (  p_debug_flag  in varchar2,
           p_return_msg out varchar2
        );
		
procedure populate_price_lists;

procedure add_exist_item_price_list
		( x_errbuf out varchar2
		, x_retcode out varchar2
		, p_item in varchar2
		, p_flag in  varchar2
		);

end XXHA_ECO_PROCESS_ECO;
/


CREATE OR REPLACE package body      XXHA_ECO_PROCESS_ECO
as
-- +=====================================================================================+
-- | Name        : XXHA_ECO_PROCESS_ECO                                                  |
-- | Purpose     : Support the Interface of ECO into EBS.                                |
-- |                                                                                     |
-- | Description : For this interface, ECO nd Items are received                         |
-- |                at organizations (including master [MST]),                           |
-- |               ECO and Items                                                         |
-- |               Data is provided in 4 staging tables:                                 |
-- |                  XXHA_ECO_REVISIONS_STG                                             |
-- |                  XXHA_ECO_ITEMS_STG                                                 |
-- |                  XXHA_ITEM_CST_DTLS_STG                                             |
-- |                  XXHA_ITEM_PRICE_LIST_STG                                           |
-- |                                                                                     |
-- |               Staged data is processed.  If all data is succcessfully               |
-- |               processed objects are then moved to the appropiate                    |
-- |               interface tables.  This includes the ECO and                          |
-- |               item objects are processed and an error are inserted in               |
-- |               common error table.                                                   |
-- |                                                                                     |
-- |                                                                                     |
-- |                                                                                     |
-- | Comment     : This package interfaces eco, it does  launch                          |
-- |               standard Import Items program.                                        |
-- |                                                                                     |
-- | History                                                                             |
-- | =======                                                                             |
-- | When        Rev  Who              What                                              |
-- | --------  ---  --------  -----------------------------------------------------------|
-- | 20090315  1.0  Palash Kundu      Initial version                                    |
-- | 20090501  1.1  Palash Kundu      Changed code to accomodate Fastpack DFF            |
-- | 20090615  1.2  Palash Kundu      Changed code to accomodate Non Rev Org Assign      |
-- | 20091021  1.3  Vasil S. Valkov   Changed package to process one ECO at a time,      |
-- |                                  Mark every staging tables record as PS even if     |
-- |                                  ECO is rejected.                                   |
-- |                                  Ensure that item revision is moved every time.     |
-- | 20100301  1.4  Raj Reddy         Item cost load and Std cost update changes.        |
-- | 20100521  1.5  Dave Lund         Added logic to insert records into cost import     |
-- |                                  table if item exists in the org.                   |
-- | 20100708  1.6  Vasil S. Valkov   Removed commented out SQL to support ERP104321.    |
-- | 20100721  1.7  Dave Lund         Added logic to capture error messages that were    |
-- |                                  previously being skipped.                          |
-- | 20100722  1.8  Dave Lund         Moved ECO END to be after cost update.             |
-- | 20110721  1.9  Eric Rossing      Added logic to include revision status type field  |
-- |                                  so non-mfg org revisions can be set to             |
-- |                                  "Scheduled".                                       |
-- | 20111103  2.0  Vasil S. Valkov   Added period_type limit in the first query of      |
-- |                                  POPULATE_ITEM_COST method.                         |
-- | 20120112  2.1  Vasil S. Valkov   Added code to round cost to a given precision.     |
-- |                                  Added code for adding item and its price to all    |
-- |                                  price lists is supposed to go to.                  |
-- |                                  The price is calculated based on the cost, uplift  |
-- |                                  factor and currency factor.                        |
-- |                                  Added a new method for manually adding an item to  |
-- |                                  the price lists - ADD_EXIST_ITEM_PRICE_LIST.       |
-- | 20121221  3.0  Bruce Marcoux     Corrected issue with details being written to      |
-- |                                  output.  Stringing of data to 'l_return_msg'       |
-- |                                  caused the field length to be exceeded.  As a      |
-- |                                  result, the updates failed.                        |
-- |                                                                                     |
-- | 20130325  4.0  Diane Houston     Change to use the Agile Find Sequence for the      |
-- |                                  EBS Component Item Num when the parent item has    |
-- |                                  an inventory category that matches the map table   |
-- |                                  Also change to fix a bug in the select from        |
-- |                                  gl_periods in the cost proc to trunc the creation  |
-- |                                  date used to get the period so it returns values   |
-- |                                  when the crt date is the last day of the month.    |
-- |                                  See the document 'Using Agile Find Sequence in EBS'|
-- |                                                                                     |
-- |           5.0  Diane Houston     Change to allow a WB Find Number logic to disable  |
-- |                                  a currently used component and add a replacement   |
-- |                                  component in the same ECO the uses the same find   |
-- |                                  number as the component being disabled.            |
-- |                                  Also changed the logic to find the actual operation|
-- |                                  of the component that is being updated or disabled |
-- |                                  since the operation sequence and component item    |
-- |                                  are the key of the bom components.                 |
-- | 12-Mar-2014      Manuel Fernandes Changed call to CMCICU                            |
-- |                                  Seeded Update Standard Cost call to reflect R12    |
-- |                                  parameters                                         |
-- |                                  Changed Cost to reflect uplift(ed) Cost for USD    |
-- |                                  Operating/Org                                      |
-- |                                                                                     |
-- +=====================================================================================+
--
----err and sucess table type--------
 TYPE XX_COMMON_ERROR_Tbl_Type IS TABLE OF XXHA_COMMON_ERRORS%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_COMMON_ERROR_TBL		XX_COMMON_ERROR_Tbl_Type;

	TYPE XX_ECO_SUCCESS_Tbl_Type IS TABLE OF XXHA_ECO_REVISIONS_STG%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_ECO_SUCCESS_TBL		XX_ECO_SUCCESS_Tbl_Type;
    TYPE XX_ECO_ERROR_Tbl_Type IS TABLE OF XXHA_ECO_REVISIONS_STG%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_ECO_ERROR_TBL		XX_ECO_SUCCESS_Tbl_Type;
   g_eco_name varchar2 (2000);
   g_request_id number;

-- This procedure logs errors to common error table.
procedure log_error
          is
begin
   gc_error_logged := 'Y';
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,gc_comments
                            ,nvl(gc_table_name,'XXHA_ECO_REVISIONS_STG')
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
	dbms_output.put_line('error '||gc_error_code||gc_error_msg||gc_comments);
exception
   when others then
      dbms_output.put_line(sqlerrm);
      fnd_file.put_line(fnd_file.log,'Error in XXHA_INV_CONV_ITM_P2_PK.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
end log_error;


--This procedure populates the sucessful ECO's
procedure populate_eco_success_stg_tbl(eco_name varchar2,organization_code varchar2) is
  l_eco_succ_counter number;
begin
   l_eco_succ_counter :=XX_ECO_SUCCESS_TBL.count;
			 XX_ECO_SUCCESS_TBL(l_eco_succ_counter+1).eco_name := eco_name;
			 XX_ECO_SUCCESS_TBL(l_eco_succ_counter+1).organization_code := organization_code;
			--XX_ECO_SUCCESS_TBL(l_eco_succ_counter+1).api_status := api_status;
			XX_ECO_SUCCESS_TBL(l_eco_succ_counter+1).record_id := gn_record_number;

end populate_eco_success_stg_tbl;

--This procedure populates error eco's
procedure populate_eco_error_stg_tbl(eco_name varchar2,organization_code varchar2) is
  l_eco_succ_counter number;
begin
   l_eco_succ_counter :=XX_ECO_ERROR_TBL.count;
			 XX_ECO_ERROR_TBL(l_eco_succ_counter+1).eco_name := eco_name;
			 XX_ECO_ERROR_TBL(l_eco_succ_counter+1).organization_code := organization_code;
			--XX_ECO_SUCCESS_TBL(l_eco_succ_counter+1).api_status := api_status;
			XX_ECO_ERROR_TBL(l_eco_succ_counter+1).record_id := gn_record_number;

end populate_eco_error_stg_tbl;

--This procedure populate common error type
procedure populate_common_error(error_msg varchar2) is
  l_error_counter number;
begin
dbms_output.put_line(' popu err '||substr(error_msg,1,2000));
gc_error_logged := 'Y';
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := gn_record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := gc_error_code;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := gc_record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute3 := g_eco_name;

end populate_common_error;
--this is a overloaded common error type population
procedure populate_common_error(error_msg varchar2,error_code varchar2,error_comments varchar2,record_number number,record_identifier varchar2) is
  l_error_counter number;
begin
gc_error_logged := 'Y';
--dbms_output.put_line(' popu err large '||substr(error_msg,1,2000));
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := substr(error_code,1,20);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_comments,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute3 := g_eco_name;

end populate_common_error;

---this procedure logs all errors.
procedure log_all_errors IS
l_error_occured boolean := FALSE;
BEGIN
  dbms_output.put_line('All Error '||xx_common_error_tbl.count);
  FOR i IN 1..XX_COMMON_ERROR_TBL.COUNT LOOP
     l_error_occured := true;
	 gc_error_logged := 'N';
	 gn_request_id :=  XX_COMMON_ERROR_TBL(i).request_id;
     gn_record_number := XX_COMMON_ERROR_TBL(i).record_number;
     gc_record_identifier := XX_COMMON_ERROR_TBL(i).record_identifier ;
     gc_error_code := XX_COMMON_ERROR_TBL(i).error_code;
     gc_error_msg := XX_COMMON_ERROR_TBL(i).error_msg;
     gc_comments  :=  XX_COMMON_ERROR_TBL(i).comments;
     gc_table_name :=  XX_COMMON_ERROR_TBL(i).table_name;
     gc_attribute1 :=  XX_COMMON_ERROR_TBL(i).attribute1;
     gc_attribute2 :=  XX_COMMON_ERROR_TBL(i).attribute2;
     gc_attribute3:=  XX_COMMON_ERROR_TBL(i).attribute3;
     gc_attribute4 :=  XX_COMMON_ERROR_TBL(i).attribute4;
     gc_attribute5 :=  XX_COMMON_ERROR_TBL(i).attribute5;

	 log_error;

	 update xxha_eco_revisions_stg
--	 set status = 'VE'
         set status = 'PS'
	 where record_id = gn_record_number
	 ;


  ENd LOOP;
  IF NOT l_error_occured THEN
   /* xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,'No Error Occured'
                            ,'XXHA_ECO_REVISIONS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );*/
    gc_error_logged := 'N';

  END IF;

END;



-----errr end-----

--This procedure calls ECO API
PROCEDURE Call_Eco_API
(
p_ECO_rec               IN    eng_eco_pub.Eco_Rec_Type,
p_eco_revision_tbl      IN    eng_eco_pub.Eco_Revision_Tbl_Type,
p_change_line_tbl       IN    eng_eco_pub.Change_Line_Tbl_Type,
p_revised_item_tbl      IN    eng_eco_pub.Revised_Item_Tbl_Type,
p_rev_component_tbl     IN    Bom_Bo_Pub.Rev_Component_Tbl_Type,
p_ref_designator_tbl    IN    Bom_Bo_Pub.Ref_Designator_Tbl_Type,
p_sub_component_tbl     IN    Bom_Bo_Pub.Sub_Component_Tbl_Type,
p_rev_operation_tbl     IN    Bom_Rtg_Pub.Rev_Operation_Tbl_Type,
p_rev_op_resource_tbl   IN    Bom_Rtg_Pub.Rev_Op_Resource_Tbl_Type,  --L1
p_rev_sub_resource_tbl  IN    Bom_Rtg_Pub.Rev_Sub_Resource_Tbl_Type,
x_return_status         IN	OUT  VARCHAR2
)

is
x_message_list        Error_Handler.Error_Tbl_Type;
--x_return_status             VARCHAR2(2000);
x_msg_count                 NUMBER;
/*p_ECO_rec                   eng_eco_pub.Eco_Rec_Type;
p_eco_revision_tbl          eng_eco_pub.Eco_Revision_Tbl_Type;
--p_eco_revision_tbl          eng_eco_pub.Eco_Revision_Tbl_Type;
p_change_line_tbl           eng_eco_pub.Change_Line_Tbl_Type;
p_revised_item_tbl          eng_eco_pub.Revised_Item_Tbl_Type;
p_rev_component_tbl         Bom_Bo_Pub.Rev_Component_Tbl_Type;
p_ref_designator_tbl        Bom_Bo_Pub.Ref_Designator_Tbl_Type;
p_sub_component_tbl         Bom_Bo_Pub.Sub_Component_Tbl_Type;
p_rev_operation_tbl         Bom_Rtg_Pub.Rev_Operation_Tbl_Type;
p_rev_op_resource_tbl       Bom_Rtg_Pub.Rev_Op_Resource_Tbl_Type;  --L1
p_rev_sub_resource_tbl      Bom_Rtg_Pub.Rev_Sub_Resource_Tbl_Type;
*/
x_ECO_rec                   eng_eco_pub.Eco_Rec_Type;
x_eco_revision_tbl          eng_eco_pub.Eco_Revision_Tbl_Type;
--x_eco_revision_tbl          eng_eco_pub.Eco_Revision_Tbl_Type;
x_change_line_tbl           eng_eco_pub.Change_Line_Tbl_Type;
x_revised_item_tbl          eng_eco_pub.Revised_Item_Tbl_Type;
x_rev_component_tbl         Bom_Bo_Pub.Rev_Component_Tbl_Type;
x_ref_designator_tbl        Bom_Bo_Pub.Ref_Designator_Tbl_Type;
x_sub_component_tbl         Bom_Bo_Pub.Sub_Component_Tbl_Type;
x_rev_operation_tbl         Bom_Rtg_Pub.Rev_Operation_Tbl_Type;
x_rev_op_resource_tbl       Bom_Rtg_Pub.Rev_Op_Resource_Tbl_Type;  --L1
x_rev_sub_resource_tbl      Bom_Rtg_Pub.Rev_Sub_Resource_Tbl_Type;


begin
  error_handler.initialize;
x_message_list.delete;
dbms_output.put_line('API Start ----------------'||'a0'||p_revised_item_tbl.count||p_eco_revision_Tbl.count||'a'||p_Rev_Component_Tbl.count||'b'||p_Rev_Operation_Tbl.count);
eng_eco_pub.Process_Eco
(   p_api_version_number        => 1.0
,   p_init_msg_list             => FALSE
,   x_return_status             =>x_return_status
,   x_msg_count                 =>x_msg_count
,   p_bo_identifier             => 'ECO'
,   p_ECO_rec                   =>p_ECO_Rec
,   p_eco_revision_tbl          =>p_eco_revision_tbl
,   p_change_line_tbl           =>p_Change_Line_Tbl
,   p_revised_item_tbl          =>p_Revised_Item_Tbl
,   p_rev_component_tbl         =>p_Rev_Component_Tbl
,   p_ref_designator_tbl        =>p_Ref_Designator_Tbl
,   p_sub_component_tbl         =>p_Sub_Component_Tbl
,   p_rev_operation_tbl         =>p_Rev_Operation_Tbl
,   p_rev_op_resource_tbl       =>p_Rev_Op_Resource_Tbl
,   p_rev_sub_resource_tbl      =>p_Rev_Sub_Resource_Tbl
,   x_ECO_rec                   =>x_Eco_Rec
,   x_eco_revision_tbl          =>x_Eco_Revision_Tbl
,   x_change_line_tbl           =>x_Change_Line_Tbl           -- Eng Change
,   x_revised_item_tbl          =>x_Revised_Item_Tbl
,   x_rev_component_tbl         =>x_Rev_Component_Tbl
,   x_ref_designator_tbl        =>x_Ref_Designator_Tbl
,   x_sub_component_tbl         =>x_Sub_Component_Tbl
,   x_rev_operation_tbl         =>x_Rev_Operation_Tbl    --L1--
,   x_rev_op_resource_tbl       =>x_Rev_Op_Resource_Tbl  --L1--
,   x_rev_sub_resource_tbl      =>x_Rev_Sub_Resource_Tbl --L1--
,   p_debug                     =>'N'
,   p_output_dir                =>''
,   p_debug_filename            =>'ECO_BO_Debug.log'
);
dbms_output.put_line('API end---');
dbms_output.put_line(x_return_status||p_eco_revision_tbl.count);
IF x_return_status <> 'S' THEN
--rollback;

populate_eco_error_stg_tbl(p_ECO_rec.eco_name,p_ECO_rec.organization_code);
else
null;
populate_eco_success_stg_tbl(p_ECO_rec.eco_name,p_ECO_rec.organization_code);

IF p_eco_rec.transaction_type = 'CREATE' THEN
/* update eng_engineering_changes
set status_type = 4
where change_notice = p_eco_rec.eco_name
;*/
update eng_revised_items
set --status_type = 4
--,
status_code = 2
where change_notice = p_eco_rec.eco_name
;
END IF;

--commit;
END IF;
IF x_return_status <> 'S' THEN
 Error_Handler.GET_MESSAGE_LIST(x_message_list=>x_message_list);
	      FOR i IN 1..x_message_list.COUNT LOOP
	         --insert into xxha_tst_test (msg) values (x_message_list(i).message_text);
			 g_eco_name := p_eco_rec.eco_name;
			populate_common_error(x_message_list(i).message_text,x_return_status,'ECO_API_ERROR',gn_record_number,gc_record_identifier);
			dbms_output.put_line('Err'||x_message_list(i).message_text);
			--populate_common_error(x_message_list(i).message_text);
			 --populate_common_error(x_message_list(i).message_text,x_return_status,l_item_table(l_item_table.count).segment1||l_item_table(l_item_table.count).organization_code||l_item_table(l_item_table.count).primary_uom_code||x_return_status||l_item_table(l_item_table.count).unit_of_issue||'2'||'ITEM_API_ERROR',gn_record_number,gc_record_identifier);
			 --gc_error_msg := x_message_list(i).message_text;
			 --log_error;
	      END LOOP;
END IF;
EXCEPTION
when others then
populate_common_error(substr(sqlerrm,1,1000));
--dbms_output.put_line(sqlerrm);
end;

PROCEDURE chk_acd_type
(p_acd_type IN varchar2
 , p_action_type IN OUT VARCHAR2)
is

begin
  	 	IF upper(p_acd_type) = 'ADD' THEN
		  p_action_type := '1';
		ELSIF upper(p_acd_type) = 'CHANGE' THEN
		  p_action_type := '2';
		ELSIF upper(p_acd_type) = 'DISABLE' THEN
		  p_action_type := '3';
		ELSE
		  p_action_type :=   p_acd_type;
		END IF;

end;


--this procedure populates ECO data
--needed for Std Oracle ECO API
PROCEDURE populate_eco_data
(
p_eco_name IN xxha_eco_revisions_stg.eco_name%type
,p_organization_code IN VARCHAR2
,x_ECO_rec            IN OUT       eng_eco_pub.Eco_Rec_Type
,x_revised_item_tbl  IN OUT        eng_eco_pub.Revised_Item_Tbl_Type
,x_rev_component_tbl IN OUT        Bom_Bo_Pub.Rev_Component_Tbl_Type
,x_rev_operation_tbl IN OUT        Bom_Rtg_Pub.Rev_Operation_Tbl_Type
,x_rev_op_resource_tbl IN OUT      Bom_Rtg_Pub.Rev_Op_Resource_Tbl_Type
,x_ref_designator_tbl  IN OUT      Bom_Bo_Pub.Ref_Designator_Tbl_Type
)
is
cursor c_get_eco_anr is
select *
from xxha_eco_revisions_stg
where nvl(status,'NEW') <> 'PS'
and nvl(agile_eco_status,'ANR') <> 'RELEASED'
and eco_name = p_eco_name
and organization_code = p_organization_code
order by revised_item_name
;

l_loop_counter number;
l_comp_action VARCHAR2 (2000);
l_ops_action VARCHAR2 (2000);
l_resource_action VARCHAR2 (2000);
l_comp_loop_counter number;
l_ref_loop_counter number;
l_pre_revised_item varchar2 (2000);
begin
  l_loop_counter := 1;
  l_comp_loop_counter := 0;
  l_ref_loop_counter := 0;
  --dbms_output.put_line ('populate_eco_data');
  l_pre_revised_item := 'AA';
  for v_get_eco_anr in c_get_eco_anr loop
    gn_record_number := v_get_eco_anr.record_id;
	--l_loop_counter := l_loop_counter + 1;


    IF l_loop_counter  = 1 THEN
	  x_eco_rec.eco_name := v_get_eco_anr.eco_name;
	  x_eco_rec.organization_code := v_get_eco_anr.organization_code;
	  x_eco_rec.description := v_get_eco_anr.description;
	  x_eco_rec.status_name := v_get_eco_anr.status_name;
	  x_eco_rec.reason_code := v_get_eco_anr.reason_code;
	  x_eco_rec.requestor := v_get_eco_anr.requestor;
	  x_eco_rec.change_type_code := v_get_eco_anr.change_type_code;
	  x_eco_rec.approval_status_name := 'Approved';
	  x_ECO_rec.plm_or_erp_change := 'ERP';
	  x_eco_rec.transaction_type := 'CREATE';
	END IF;
----addd
   --chg
   IF l_loop_counter  >= 1 AND  v_get_eco_anr.revised_item_name <> l_pre_revised_item THEN
      x_revised_item_tbl(l_loop_counter).organization_code := v_get_eco_anr.organization_code;
	  x_revised_item_tbl(l_loop_counter).eco_name := v_get_eco_anr.eco_name;
	  x_revised_item_tbl(l_loop_counter).revised_item_name := v_get_eco_anr.revised_item_name;
	  x_revised_item_tbl(l_loop_counter).new_revised_item_revision := v_get_eco_anr.new_revised_item_revision;
	  x_revised_item_tbl(l_loop_counter).start_effective_date := to_date(to_char(v_get_eco_anr.start_effective_date_rev,'MM/DD/YYYY HH:MI:SS AM'),'MM/DD/YYYY HH:MI:SS AM');--nvl(v_get_eco_anr.start_effective_date_rev,sysdate);--to_date('21-JAN-2009 14:58:22','DD-MON-YYYY HH24:MI:SS');
	  x_revised_item_tbl(l_loop_counter).transaction_type := 'CREATE';
	  x_revised_item_tbl(l_loop_counter).enable_item_in_local_org           := 'Y';
-- Added by Eric Rossing 7/21/11 v1.9 - set status type if it's not null
    if v_get_eco_anr.revision_status is not null then
        select lookup_code
        into x_revised_item_tbl(l_loop_counter).status_type
        from mfg_lookups
        where lookup_type='ECG_ECN_STATUS'
        and meaning=v_get_eco_anr.revision_status;
    end if;
-- End of v1.8 addition
      l_loop_counter := l_loop_counter + 1;
	  dbms_output.put_line ('populate_eco_data'||v_get_eco_anr.organization_code|| x_revised_item_tbl.count);
-----addd end
	END IF;
	l_pre_revised_item := v_get_eco_anr.revised_item_name;
	--chg END IF;

	IF l_loop_counter  >= 1 THEN
	/*  x_revised_item_tbl(l_loop_counter).organization_code := v_get_eco_anr.organization_code;
	  x_revised_item_tbl(l_loop_counter).eco_name := v_get_eco_anr.eco_name;
	  x_revised_item_tbl(l_loop_counter).revised_item_name := v_get_eco_anr.revised_item_name;
	  x_revised_item_tbl(l_loop_counter).new_revised_item_revision := v_get_eco_anr.new_revised_item_revision;
	  x_revised_item_tbl(l_loop_counter).start_effective_date := nvl(v_get_eco_anr.start_effective_date_rev,sysdate);--to_date('21-JAN-2009 14:58:22','DD-MON-YYYY HH24:MI:SS');
	  x_revised_item_tbl(l_loop_counter).transaction_type := 'CREATE';
	  x_revised_item_tbl(l_loop_counter).enable_item_in_local_org           := 'Y';
	  */IF v_get_eco_anr.component_item_name IS NOT NULL THEN
	  	--dbms_output.put_line ('populate_eco_data comp');
		l_comp_loop_counter := l_comp_loop_counter + 1;
		x_rev_component_tbl(l_comp_loop_counter).revised_item_name := v_get_eco_anr.revised_item_name;
		x_rev_component_tbl(l_comp_loop_counter).start_effective_date :=  to_date(to_char(v_get_eco_anr.start_effective_date_rev,'MM/DD/YYYY HH:MI:SS AM'),'MM/DD/YYYY HH:MI:SS AM');--x_revised_item_tbl(1).start_effective_date ;--v_get_eco_anr.start_effective_date_comp  ;
		x_rev_component_tbl(l_comp_loop_counter).organization_code := v_get_eco_anr.organization_code;
		x_rev_component_tbl(l_comp_loop_counter).eco_name := v_get_eco_anr.eco_name;
		x_rev_component_tbl(l_comp_loop_counter).operation_sequence_number := v_get_eco_anr.new_operation_sequence_number;
		x_rev_component_tbl(l_comp_loop_counter).New_revised_Item_Revision := v_get_eco_anr.new_revised_item_revision;
		--x_rev_component_tbl(l_loop_counter).operation_sequence_number := v_get_eco_anr.new_operation_sequence_number;

		chk_acd_type(v_get_eco_anr.rev_component_acd_type,l_comp_action);
		x_rev_component_tbl(l_comp_loop_counter).acd_type := l_comp_action;
		x_rev_component_tbl(l_comp_loop_counter).Component_Item_Name       := v_get_eco_anr.component_item_name;
		x_rev_component_tbl(l_comp_loop_counter).item_sequence_number       := v_get_eco_anr.item_sequence_number;
		x_rev_component_tbl(l_comp_loop_counter).quantity_per_assembly       := v_get_eco_anr.quantity_per_assembly;
		x_rev_component_tbl(l_comp_loop_counter).wip_supply_type       := v_get_eco_anr.wip_supply_type;
		x_rev_component_tbl(l_comp_loop_counter).supply_subinventory       := v_get_eco_anr.supply_subinventory;
		x_rev_component_tbl(l_comp_loop_counter).location_name       := v_get_eco_anr.location_name;
		x_rev_component_tbl(l_comp_loop_counter).old_effectivity_date := to_date( v_get_eco_anr.old_comp_effective_date,'MM-DD-YYYY HH:MI:SS AM');
		x_rev_component_tbl(l_comp_loop_counter).old_operation_sequence_number := v_get_eco_anr.old_operation_sequence_number;
		x_rev_component_tbl(l_comp_loop_counter).transaction_type       := 'CREATE';
	  ---add ref des-----------------
	  IF v_get_eco_anr.Reference_Designator is not null AND l_comp_action  = 1 then
	    l_ref_loop_counter := l_ref_loop_counter + 1;
		x_ref_designator_tbl(l_ref_loop_counter).eco_name := v_get_eco_anr.eco_name;
		x_ref_designator_tbl(l_ref_loop_counter).organization_code := v_get_eco_anr.organization_code;
	    x_ref_designator_tbl(l_ref_loop_counter).revised_item_name := v_get_eco_anr.revised_item_name;
		x_ref_designator_tbl(l_ref_loop_counter).start_effective_date :=  to_date(to_char(v_get_eco_anr.start_effective_date_rev,'MM/DD/YYYY HH:MI:SS AM'),'MM/DD/YYYY HH:MI:SS AM');--x_revised_item_tbl(1).start_effective_date ;--v_get_eco_anr.start_effective_date_comp  ;
	    x_ref_designator_tbl(l_ref_loop_counter).operation_sequence_number := v_get_eco_anr.new_operation_sequence_number;
		x_ref_designator_tbl(l_ref_loop_counter).New_revised_Item_Revision := v_get_eco_anr.new_revised_item_revision;
		x_ref_designator_tbl(l_ref_loop_counter).Component_Item_Name       := v_get_eco_anr.component_item_name;
		x_ref_designator_tbl(l_ref_loop_counter).Reference_Designator_Name            := v_get_eco_anr.Reference_Designator;
		x_ref_designator_tbl(l_ref_loop_counter).acd_type := l_comp_action;
		x_ref_designator_tbl(l_ref_loop_counter).transaction_type       := 'CREATE';
	  ENd IF;
	  -----add ref des end--------------

	  END IF;
	   IF v_get_eco_anr.component_item_name IS NOT NULL AND  v_get_eco_anr.use_up_row = 'Y' THEN
	  	l_comp_loop_counter := l_comp_loop_counter + 1;
		x_rev_component_tbl(l_comp_loop_counter).revised_item_name := v_get_eco_anr.revised_item_name;
		x_rev_component_tbl(l_comp_loop_counter).start_effective_date := v_get_eco_anr.start_effective_date_comp  ;
		x_rev_component_tbl(l_comp_loop_counter).organization_code := v_get_eco_anr.organization_code;
		x_rev_component_tbl(l_comp_loop_counter).eco_name := v_get_eco_anr.eco_name;
		x_rev_component_tbl(l_comp_loop_counter).new_operation_sequence_number := '99999';--v_get_eco_anr.new_operation_sequence_number;
		--x_rev_component_tbl(l_loop_counter).operation_sequence_number := v_get_eco_anr.new_operation_sequence_number;

		--chk_acd_type(v_get_eco_anr.rev_component_acd_type,l_comp_action);
		x_rev_component_tbl(l_comp_loop_counter).acd_type :=1;
		x_rev_component_tbl(l_comp_loop_counter).Component_Item_Name       := v_get_eco_anr.component_item_name;
		x_rev_component_tbl(l_comp_loop_counter).item_sequence_number       := v_get_eco_anr.item_sequence_number;
		x_rev_component_tbl(l_comp_loop_counter).quantity_per_assembly       := v_get_eco_anr.quantity_per_assembly;
		x_rev_component_tbl(l_comp_loop_counter).wip_supply_type       := v_get_eco_anr.wip_supply_type;
		x_rev_component_tbl(l_comp_loop_counter).supply_subinventory       := v_get_eco_anr.supply_subinventory;
		x_rev_component_tbl(l_comp_loop_counter).location_name       := v_get_eco_anr.location_name;
		x_rev_component_tbl(l_comp_loop_counter).old_effectivity_date := to_date( v_get_eco_anr.old_comp_effective_date,'MM-DD-YYYY HH:MI:SS AM');
		x_rev_component_tbl(l_comp_loop_counter).old_operation_sequence_number := v_get_eco_anr.old_operation_sequence_number;
		x_rev_component_tbl(l_comp_loop_counter).transaction_type       := 'CREATE';
	  END IF;
		IF v_get_eco_anr.department_code is not null then
			chk_acd_type(v_get_eco_anr.rev_operation_acd_type,l_ops_action);
			x_rev_operation_tbl(l_loop_counter).revised_item_name := v_get_eco_anr.revised_item_name;
			x_rev_operation_tbl(l_loop_counter).start_effective_date := v_get_eco_anr.start_effective_date_ops  ;
			x_rev_operation_tbl(l_loop_counter).disable_date := v_get_eco_anr.disable_date_ops ;
			x_rev_operation_tbl(l_loop_counter).acd_type := l_ops_action;
			x_rev_operation_tbl(l_loop_counter).organization_code := v_get_eco_anr.organization_code;
			x_rev_operation_tbl(l_loop_counter).eco_name := v_get_eco_anr.eco_name;
			x_rev_operation_tbl(l_loop_counter).operation_sequence_number := v_get_eco_anr.operation_sequence_number;
			x_rev_operation_tbl(l_loop_counter).old_operation_sequence_number := v_get_eco_anr.old_operation_sequence_number;
			x_rev_operation_tbl(l_loop_counter).department_code       := v_get_eco_anr.department_code;
			x_rev_operation_tbl(l_loop_counter).Old_Start_Effective_Date := to_Date( v_get_eco_anr.old_ops_effective_date,'MM-DD-YYYY HH:MI:SS AM');
			x_rev_operation_tbl(l_loop_counter).transaction_type       := 'CREATE';

		END IF;
		IF v_get_eco_anr.resource_code IS NOT NULL THEN
			chk_acd_type(v_get_eco_anr.rev_resource_acd_type,l_resource_action);
			x_rev_op_resource_tbl(l_loop_counter).revised_item_name := v_get_eco_anr.revised_item_name ;
			--p_rev_op_resource_tbl(l_loop_counter).New_revised_Item_Revision := 'A';
			x_rev_op_resource_tbl(l_loop_counter).acd_type := l_resource_action;
			x_rev_op_resource_tbl(l_loop_counter).op_start_effective_date := v_get_eco_anr.start_effective_date_ops  ;
			x_rev_op_resource_tbl(l_loop_counter).organization_code := v_get_eco_anr.organization_code;
			x_rev_op_resource_tbl(l_loop_counter).eco_name := v_get_eco_anr.eco_name;
			x_rev_op_resource_tbl(l_loop_counter).operation_sequence_number := v_get_eco_anr.operation_sequence_number;
			x_rev_op_resource_tbl(l_loop_counter).resource_sequence_number       := v_get_eco_anr.resource_sequence_number;
			x_rev_op_resource_tbl(l_loop_counter).usage_rate_or_amount       := v_get_eco_anr.usage_rate_or_amount;
			x_rev_op_resource_tbl(l_loop_counter).resource_code       := v_get_eco_anr.resource_code;
			x_rev_op_resource_tbl(l_loop_counter).transaction_type       := 'CREATE';
		END IF;

	END IF;
  end loop;
end;

--this procedure is for creation of ECO

PROCEDURE Create_ECO_ANR
(p_eco_name in xxha_eco_revisions_stg.eco_name%type
)
is

cursor c_get_eco_anr is
select distinct eco_name,organization_code--,record_id
from xxha_eco_revisions_stg
where nvl(status,'NEW') <> 'PS'
and eco_name = p_eco_name
;
l_ECO_rec                   eng_eco_pub.Eco_Rec_Type;
l_eco_revision_tbl          eng_eco_pub.Eco_Revision_Tbl_Type;
l_change_line_tbl           eng_eco_pub.Change_Line_Tbl_Type;
l_revised_item_tbl          eng_eco_pub.Revised_Item_Tbl_Type;
l_rev_component_tbl         Bom_Bo_Pub.Rev_Component_Tbl_Type;
l_rev_operation_tbl         Bom_Rtg_Pub.Rev_Operation_Tbl_Type;
l_ref_designator_tbl        Bom_Bo_Pub.Ref_Designator_Tbl_Type;
l_rev_op_resource_tbl       Bom_Rtg_Pub.Rev_Op_Resource_Tbl_Type;  --L1
l_sub_component_tbl         Bom_Bo_Pub.Sub_Component_Tbl_Type;
l_rev_sub_resource_tbl      Bom_Rtg_Pub.Rev_Sub_Resource_Tbl_Type;
l_return_status VARCHAR2 (2000);
begin
  for v_get_eco_anr in c_get_eco_anr loop

     gc_record_identifier := v_get_eco_anr.eco_name||' '||v_get_eco_anr.organization_code;
	 l_revised_item_tbl.delete;
	 l_rev_component_tbl.delete;
	 l_rev_operation_tbl.delete;
	 l_rev_op_resource_tbl.delete;
	 l_ref_designator_tbl.delete;
	 populate_eco_data
	 (
	  v_get_eco_anr.eco_name
	  ,v_get_eco_anr.organization_code
	  ,l_ECO_rec
	  ,l_revised_item_tbl
	  ,l_rev_component_tbl
	  ,l_rev_operation_tbl
	  ,l_rev_op_resource_tbl
	  ,l_ref_designator_tbl
	 );
	 dbms_output.put_line('Call API----------------');
	 Call_Eco_API
	 (
	  l_ECO_rec,
	  l_eco_revision_tbl,
	  l_change_line_tbl,
	  l_revised_item_tbl,
	  l_rev_component_tbl,
	  l_ref_designator_tbl,
	  l_sub_component_tbl,
	  l_rev_operation_tbl,
	  l_rev_op_resource_tbl,
	  l_rev_sub_resource_tbl,
	  l_return_status
	 )
	 ;

  end loop;

end;

--this procedure is for creation of ECO Record ID
--which is a unique sequence number
Procedure create_eco_record_id (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
is

cursor c_get_null_record_id is
select * from xxha_eco_revisions_stg
where record_id is null
and eco_name = p_eco_name
;

begin
for v_get_null_record_id in c_get_null_record_id loop
  update xxha_eco_revisions_stg
  set record_id = haemo.xxha_eco_revision_s.nextval
  where eco_name = v_get_null_record_id.eco_name
  and organization_code = v_get_null_record_id.organization_code
  and record_id is null
  and eco_name = p_eco_name
  ;

end loop;
commit;
end;


--this procedure is for updating of Item Seq Num
PROCEDURE update_item_seq_num (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
is
cursor c_eco_rev is
select distinct revised_item_name
 from xxha_eco_revisions_stg
where status <> 'PS'
and component_item_name is not null
and item_sequence_number is null
and eco_name = p_eco_name
;

cursor c_bom_exists (q_assly_item_number varchar2) is
select bill_sequence_id
from bom_bill_of_materials bom,mtl_system_items items
where items.inventory_item_id = bom.assembly_item_id
and items.organization_id = bom.organization_id
and segment1 = q_assly_item_number
;

cursor c_eco_rev_no_bom (q_revised_item_name varchar2) is
select distinct revised_item_name,component_item_name
from xxha_eco_revisions_stg
where status <> 'PS'
and component_item_name is not null
and item_sequence_number is null
and revised_item_name = q_revised_item_name
and eco_name = p_eco_name
;

cursor c_eco_rev_bom_org (q_revised_item_name varchar2,q_org_code varchar2) is
select distinct revised_item_name,component_item_name
from xxha_eco_revisions_stg
where status <> 'PS'
and component_item_name is not null
and item_sequence_number is null
and revised_item_name = q_revised_item_name
and organization_code = q_org_code
and eco_name = p_eco_name
;

cursor c_eco_rev_org (q_revised_item_name varchar2) is
select distinct organization_code,revised_item_name
from xxha_eco_revisions_stg
where status <> 'PS'
and component_item_name is not null
and item_sequence_number is null
and revised_item_name = q_revised_item_name
and eco_name = p_eco_name
;

cursor c_eco_rev_bom_exists (q_revised_item_name varchar2,q_org_code varchar2) is
select items.segment1,bill_sequence_id
from bom_bill_of_materials bom,mtl_system_items items,mtl_parameters param
where items.inventory_item_id = bom.assembly_item_id
and items.organization_id = bom.organization_id
and param.organization_id = bom.organization_id
and items.segment1 = q_revised_item_name
and organization_code = q_org_code
;

cursor c_get_comp_item_num (q_revised_item_name varchar2,q_comp_item_name varchar2) is
select  distinct item_num
from bom_bill_of_materials bom,mtl_system_items items,bom_components_b comp,mtl_system_items items_comp
where items.inventory_item_id = bom.assembly_item_id
and items.organization_id = bom.organization_id
and comp.bill_sequence_id = bom.bill_sequence_id
and items.segment1 = q_revised_item_name
and items_comp.inventory_item_id = comp.component_item_id
and items_comp.organization_id = bom.organization_id
and items_comp.segment1 = q_comp_item_name
;

l_bom_exists boolean;
l_bom_exists_in_org boolean;
l_item_seq_num number;
l_comp_item_seq_num number;

begin

-- START of FIX ITEM SEQUENCE NUMBER 2
-- Added by Diane Houston March 22, 2013

-- Setting the Item Seq to null if should get default assignment, not set
-- from Agile.  Only do this on New Components because prior logic
-- sets the item sequence number for updates

update xxha_eco_revisions_stg xers
set    item_sequence_number = null
where  xers.status != 'PS'
       and xers.eco_name = p_eco_name
       and xers.component_item_name is not null
       and xers.item_sequence_number is not null
       and xers.rev_component_acd_type = 1
       and not exists
       (select 'x'
        from   mtl_item_categories mic,
               mtl_categories mc,
               haemo.xxha_agile_item_num_cat_map hain
        where  xers.rev_item_id = mic.inventory_item_id
               and mic.organization_id = 103 -- MST
               and mic.category_set_id = 1 -- Inventory
               and mic.category_id =  mc.category_id
               and mc.segment1 = hain.product_line
               and mc.segment4 = nvl(hain.product_platform, mc.segment4));

commit;

-- Setting the Item Seq to -999 if should get Agile No and it is null
-- It does not matter if it is an Add, Change or Disable

update xxha_eco_revisions_stg xers
set    item_sequence_number = -999
where  xers.status != 'PS'
       and xers.eco_name = p_eco_name
       and xers.component_item_name is not null
       and xers.item_sequence_number is null
--       and xers.rev_component_acd_type = 1
       and exists
       (select 'x'
        from   mtl_item_categories mic,
               mtl_categories mc,
               haemo.xxha_agile_item_num_cat_map hain
        where  mic.organization_id = 103 -- MST
               and xers.rev_item_id = mic.inventory_item_id
               and mic.category_set_id = 1 -- Inventory
               and mic.category_id =  mc.category_id
               and mc.segment1 = hain.product_line
               and mc.segment4 = nvl(hain.product_platform, mc.segment4));

commit;

-- Setting the Item Seq to -888 if this component_item num is shared by a different
-- component_item_num within the same parent in the staging table and it is being
-- set from Agile.  Only care for adds and updates

update xxha_eco_revisions_stg xers
set    item_sequence_number = -888
where  nvl(xers.status,'x') != 'PS'
       and xers.eco_name = p_eco_name
       and xers.component_item_name is not null
       and xers.item_sequence_number is not null
       and xers.item_sequence_number > 0
       and xers.rev_component_acd_type in ( 1,2)
       and exists
       (select 'x'
        from   mtl_item_categories mic,
               mtl_categories mc,
               haemo.xxha_agile_item_num_cat_map hain
        where  mic.organization_id = 103 -- MST
               and xers.rev_item_id = mic.inventory_item_id
               and mic.category_set_id = 1 -- Inventory
               and mic.category_id =  mc.category_id
               and mc.segment1 = hain.product_line
               and mc.segment4 = nvl(hain.product_platform, mc.segment4))
       and exists
       (select 'x'
        from   xxha_eco_revisions_stg xers_x
        where  xers.eco_name = xers_x.eco_name
               and xers.organization_code = xers_x.organization_code
               and nvl(xers_x.status,'x') != 'PS'
               and xers.revised_item_name = xers_x.revised_item_name
               and xers.component_item_name != nvl(xers_x.component_item_name,'x')
               and xers.item_sequence_number = xers_x.item_sequence_number
               and xers_x.rev_component_acd_type in ( 1,2)
               and xers_x.item_sequence_number > 0);

commit;

-- Setting the Item Seq to -777 if this component_item num is shared by a different
-- component_item_num within the same parent in the EBS tables for the parent item
-- and the value is being set from Agile.  It passes the test if the ECO
-- disables the find sequence that is being added/updated but already exists on the BOM.

update xxha_eco_revisions_stg xers
set    item_sequence_number = -777
where  nvl(xers.status,'x') != 'PS'
       and xers.eco_name = p_eco_name
       and xers.component_item_name is not null
       and xers.item_sequence_number is not null
       and xers.item_sequence_number > 0
       and xers.rev_component_acd_type in (1,2)
       and exists
       (select 'x'
        from   mtl_item_categories mic,
               mtl_categories mc,
               haemo.xxha_agile_item_num_cat_map hain
        where  mic.organization_id = 103 -- MST
               and xers.rev_item_id = mic.inventory_item_id
               and mic.category_set_id = 1 -- Inventory
               and mic.category_id =  mc.category_id
               and mc.segment1 = hain.product_line
               and mc.segment4 = nvl(hain.product_platform, mc.segment4))
       and exists
       (select 'x'
        from   bom_bill_of_materials bbom,
               bom_inventory_components bic
        where  xers.org_id = bbom.organization_id
               and xers.rev_item_id = bbom.assembly_item_id
               and bbom.bill_sequence_id = bic.bill_sequence_id
               and bic.component_item_id != xers.comp_item_id
               and bic.item_num = xers.item_sequence_number
               and bic.effectivity_date <= sysdate
               and nvl(bic.disable_date,sysdate) >= sysdate
               and nvl(bic.implementation_date, sysdate + 1) <= sysdate )
      and not exists
       (select 'x'
        from   xxha_eco_revisions_stg xers_x
        where  xers.eco_name = xers_x.eco_name
               and xers.organization_code = xers_x.organization_code
               and nvl(xers_x.status,'x') != 'PS'
               and xers.revised_item_name = xers_x.revised_item_name
               and xers.item_sequence_number = xers_x.item_sequence_number
               and xers_x.rev_component_acd_type = 3
               and xers_x.item_sequence_number > 0);

commit;

-- END of FIX ITEM SEQUENCE NUMBER 2
-- Diane Houston March 22, 2013

for v_eco_rev in c_eco_rev loop
  l_bom_exists := false;
  for v_bom_exists in c_bom_exists(v_eco_rev.revised_item_name) loop
    l_bom_exists := true;
  end loop;
  IF l_bom_exists THEN
    null;
	for v_Eco_rev_org in c_eco_rev_org (v_eco_rev.revised_item_name) loop
	  l_bom_exists_in_org := false;
	    for v_eco_rev_bom_exists in c_eco_rev_bom_exists (v_eco_rev.revised_item_name,v_Eco_rev_org.organization_code) loop
	      select  max(item_num)
		  into l_item_seq_num
		  from bom_components_b
		  where bill_sequence_id = v_eco_rev_bom_exists.bill_sequence_id;
		  l_bom_exists_in_org := true;

		IF l_bom_exists_in_org then

		  for v_eco_rev_bom_org in c_eco_rev_bom_org(v_eco_rev.revised_item_name,v_Eco_rev_org.organization_code) loop
		    l_item_seq_num := l_item_seq_num + 10;
			update xxha_eco_revisions_stg
	          set item_sequence_number = l_item_seq_num
	          where revised_item_name = v_eco_rev.revised_item_name
	          and component_item_name = v_eco_rev_bom_org.component_item_name
			  and organization_code = v_Eco_rev_org.organization_code
	          and item_sequence_number is null
	          and eco_name = p_eco_name
	          ;
		  end loop;

		ELSE
		for v_eco_rev_bom_org in c_eco_rev_bom_org(v_eco_rev.revised_item_name,v_Eco_rev_org.organization_code) loop
		 for v_get_comp_item_num in c_get_comp_item_num (v_eco_rev.revised_item_name,v_eco_rev_bom_org.component_item_name) loop
		   l_item_seq_num := v_get_comp_item_num.item_num;
		 end loop;
		   l_item_seq_num := l_item_seq_num+10;
		   update xxha_eco_revisions_stg
	          set item_sequence_number = l_item_seq_num
	          where revised_item_name = v_eco_rev.revised_item_name
	          and component_item_name = v_eco_rev_bom_org.component_item_name
			  and item_sequence_number is null
			  and eco_name = p_eco_name
	          ;
		end loop;
		END IF;
	  end loop;
	   IF NOT l_bom_exists_in_org THEN
	    dbms_output.put_line('Bom Exists233');
		for v_eco_rev_bom_org in c_eco_rev_bom_org(v_eco_rev.revised_item_name,v_Eco_rev_org.organization_code) loop
		 for v_get_comp_item_num in c_get_comp_item_num (v_eco_rev.revised_item_name,v_eco_rev_bom_org.component_item_name) loop
		   l_item_seq_num := v_get_comp_item_num.item_num;
		 end loop;
		   --l_item_seq_num := l_item_seq_num+10;
		   update xxha_eco_revisions_stg
	          set item_sequence_number = l_item_seq_num
	          where revised_item_name = v_eco_rev.revised_item_name
	          and component_item_name = v_eco_rev_bom_org.component_item_name
			  and item_sequence_number is null
			  and eco_name = p_eco_name
	          ;
		end loop;
	  END IF;
	end loop;
  ELSE
    l_item_seq_num := 10;
    for v_eco_rev_no_bom in c_eco_rev_no_bom (v_eco_rev.revised_item_name) loop

	  update xxha_eco_revisions_stg
	  set item_sequence_number = l_item_seq_num
	  where revised_item_name = v_eco_rev.revised_item_name
	  and component_item_name = v_eco_rev_no_bom.component_item_name
	  and item_sequence_number is null
	  and eco_name = p_eco_name
	  ;
	  l_item_seq_num := l_item_seq_num + 10;
	end loop;
  END IF;
end loop;
commit;
end;

--This procedure is for cration od Eco Item record id
Procedure create_eco_items_record_id (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
is
cursor c_get_null_record_id is
select * from xxha_eco_items_stg
where record_id is null
and agile_eco_no = p_eco_name
;

begin
for v_get_null_record_id in c_get_null_record_id loop
  update xxha_eco_items_stg
  set record_id = haemo.xxha_eco_revision_s.nextval
  where item_number = v_get_null_record_id.item_number
  and inventory_org_code = v_get_null_record_id.inventory_org_code
  and record_id is null
  and agile_eco_no = p_eco_name
  ;

end loop;
commit;
end;

--this procedure is for Post processing Items steps.
PROCEDURE Post_Process_Items (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
is
cursor c_eco_items is
select *
from xxha_eco_items_stg
where status <> 'PS'
and record_id is not null
and agile_eco_no = p_eco_name
;
cursor c_item_invorgs_status (q_record_id number,q_item_number varchar2,q_org_code varchar2) is
select status
from xxha_item_invorgs_stg
where item_number = q_item_number
and inventory_org_code = q_org_code
and record_id = q_record_id
and status <> 'PS'
;
cursor c_item_rev_status (q_record_id number,q_item_number varchar2) is
select status
from xxha_item_revisions_stg
where item_number = q_item_number
and item_record_id = q_record_id
and status <> 'PS'
;
l_all_ps boolean;
begin

  for v_eco_items in c_eco_items loop
     update xxha_common_errors
	 set attribute3 = v_eco_items.agile_eco_no
	 ,attribute4 = 'N'
	 where attribute4 <> 'Y'
	 and (record_identifier = p_eco_name||' '||v_eco_items.item_number||' '||v_eco_items.inventory_org_code
     OR record_identifier = v_eco_items.item_number || '/' || v_eco_items.inventory_org_code
     --- DL 7/21/10 This line will include errors caught by the API that were not previously captured
     OR record_identifier = v_eco_items.item_number || ' ' || v_eco_items.inventory_org_code)
	 ;
	 commit;
     l_all_ps := true;
     -- commented out on 2009-10-16, VV
/*      for v_item_invorgs_status in c_item_invorgs_status (v_eco_items.record_id,v_eco_items.item_number,v_eco_items.inventory_org_code) loop
	    l_all_ps := false;
	  end loop;
	  for v_item_rev_status in c_item_rev_status (v_eco_items.record_id,v_eco_items.item_number) loop
	    l_all_ps := false;
	  end loop;
*/
	  IF l_all_ps THEN
	    update xxha_eco_items_stg
		set status = 'PS'
		where item_number = v_eco_items.item_number
		and inventory_org_code = v_eco_items.inventory_org_code
		and record_id = v_eco_items.record_id
		and agile_eco_no = p_eco_name
		;
		/* xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,v_eco_items.record_id
                            ,v_eco_items.item_number||'/'||v_eco_items.inventory_org_code
                            ,gc_error_code
                            ,gc_error_msg
                            ,'ITEM SUCCESS'
                            ,'XXHA_ECO_ITEMS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,v_eco_items.agile_eco_no
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );	*/
	  END IF;
  end loop;
  commit;
end;

--This procedure is for pre processing of items
--It takes data from one table eco items table and
--splits the data into 3 Item conversion tables
PROCEDURE Pre_Process_Items (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
is
cursor c_items_templ is
select * from xxha_eco_items_stg
where status <> 'PS'
and inventory_org_code = 'MST'
and agile_eco_no = p_eco_name
;
cursor c_items_cle is
select * from xxha_eco_items_stg
where status <> 'PS'
and inventory_org_code = 'MST'
and agile_eco_no = p_eco_name
and item_number not in
(select item_number from xxha_items_cleaned_stg
where status <> 'PS'
)
;

cursor c_items_inv is
select * from xxha_eco_items_stg stg
where status <> 'PS'
and agile_eco_no = p_eco_name
and item_number not in
(select item_number from xxha_item_invorgs_stg where inventory_org_code = stg.inventory_org_code
and status <> 'PS'
)
;
cursor c_items_rev is
select * from xxha_eco_items_stg
where status <> 'PS'
and inventory_org_code = 'MST'
and agile_eco_no = p_eco_name
and item_number not in
(select item_number from xxha_item_revisions_stg
where status <> 'PS'
)
;
cursor c_item_rec_id (q_item_number varchar2)is
select * from xxha_eco_items_stg
where status <> 'PS'
and agile_eco_no = p_eco_name
and item_number = q_item_number
and inventory_org_code = 'MST'
;
l_item_rec_id number;
l_item_rev_num number;
cursor c_items_rev_dash is
select distinct item_number,description,staged_effective_date from xxha_item_revisions_stg
where status <> 'PS'
and item_number not in
(select distinct item_number from xxha_eco_items_stg where status <> 'PS' and trunc(effective_date) <= trunc(sysdate))
and item_number  not in
(select item_number from xxha_item_revisions_stg
where revision_no = '-'
and status <> 'PS'
)
and item_number not in
(select segment1 from mtl_system_items_b where organization_id = 103)
;
cursor c_chk_mst_rec is
select * from xxha_eco_items_stg
where status <> 'PS'
and agile_eco_no = p_eco_name
;
cursor c_chk_rev_exists is
select *
from xxha_item_revisions_stg
where status <> 'PS';

cursor c_get_mst_rev (q_item_number varchar2,q_revision varchar2)is
  select items.segment1,revision,rev.description,effectivity_date,implementation_date
from mtl_item_revisions_b rev,mtl_system_items items
where items.inventory_item_id = rev.inventory_item_id
and items.organization_id = rev.organization_id
and items.segment1 = q_item_number
and rev.revision <> q_revision
and rev.organization_id = 103
;

cursor c_chk_current_rev_exists (q_item_number varchar2) is
select distinct items.segment1
from mtl_system_items items,mtl_item_revisions_b rev
where items.organization_id = rev.organization_id
and items.inventory_item_id = rev.inventory_item_id
and rev.organization_id = 103
and items.segment1 =  q_item_number
and trunc(rev.effectivity_date) >= trunc(sysdate)
;
l_current_rev_exists boolean;
l_rev_rec_id number;
l_item_number varchar2 (2000);
l_starting_revision varchar2 (2000);
begin
delete from xxha_items_cleaned_stg;
delete from xxha_item_invorgs_stg;
delete from xxha_item_revisions_stg;
delete from xxha_item_revisions_int_stg;
delete from mtl_item_revisions_interface;
commit;
/*update xxha_items_cleaned_stg
set status = 'PS'
where status <> 'PS';
update xxha_item_invorgs_stg
set status = 'PS'
where status <> 'PS';
update xxha_item_revisions_stg
set status = 'PS'
where status <> 'PS';*/
create_eco_items_record_id (p_eco_name);

for v_chk_mst_rec in c_chk_mst_rec loop
  begin
    select distinct item_number
	into l_item_number
	from xxha_eco_items_stg
	where item_number = v_chk_mst_rec.item_number
	and inventory_org_code = 'MST'
	and status <> 'PS'
	;
  exception
  when no_data_found	then
    insert into XXHA_ECO_ITEMS_STG
	(RECORD_ID
	,INVENTORY_ORG_CODE
	,ITEM_NUMBER
	,description
	,TEMPLATE_CODE
	,agile_eco_no
	,revision_no
	,effective_date
	,item_product_line
	,item_product_type
	,item_product_subtype
	,item_platform
	,item_status
	,primary_uom
	,status
	)
	VALUES
	(haemo.xxha_eco_revision_s.nextval
	,'MST'
	,v_chk_mst_rec.item_number
	,v_chk_mst_rec.description
	,'HAE_ECO_TEMPLATE'
	,v_chk_mst_rec.agile_eco_no
	,v_chk_mst_rec.revision_no
	,v_chk_mst_rec.effective_date
	,v_chk_mst_rec.item_product_line
	,v_chk_mst_rec.item_product_type
	,v_chk_mst_rec.item_product_subtype
	,v_chk_mst_rec.item_platform
	,v_chk_mst_rec.item_status
	,v_chk_mst_rec.primary_uom
	,'NEW'
	)
	;

  end;
end loop;
commit;
---Assign Master Templates
for v_item_templ in c_items_templ loop
 IF v_item_templ.lot_control = '2' then
   update xxha_eco_items_stg
   set template_code = 'LCI-Lot Controlled Item'
   where item_number = v_item_templ.item_number
   and inventory_org_code = 'MST'
   and agile_eco_no = p_eco_name
   ;
 END IF;
  IF v_item_templ.serial_number_generation <> '1' then
   update xxha_eco_items_stg
   set template_code = 'SCI-Serial Control Item'
   where item_number = v_item_templ.item_number
   and inventory_org_code = 'MST'
   and agile_eco_no = p_eco_name
   ;
 END IF;
  IF v_item_templ.serial_number_generation = '1' AND v_item_templ.lot_control = '1' then
   update xxha_eco_items_stg
   set template_code = 'NCI-Non Controlled Item'
   where item_number = v_item_templ.item_number
   and inventory_org_code = 'MST'
   and agile_eco_no = p_eco_name
   ;
 END IF;

end loop;

for v_items_cle in c_items_cle loop
--Populate Items with Master Control Attributes
INSERT INTO XXHA_ITEMS_CLEANED_STG (
   RECORD_ID,
    CI_FLAG,
   STATUS,
   ITEM_NUMBER,
   DESCRIPTION,
    ITEM_STATUS,
	 PRIMARY_UOM,
   SECONDARY_UOM,
    START_DATE_ACTIVE,
	 TEMPLATE_CODE,
   ITEM_PRODUCT_LINE,
    ITEM_PRODUCT_TYPE,
	 ITEM_PRODUCT_SUBTYPE,
   ITEM_PLATFORM,
    STERILIZATION_CODE,
	 INVOICE_UOM,
   JAN_CODE,
    TEMPRHREQ,
	 JAPAN_CATEGORIES,
   REVISION_CONTROL,
    LOT_EXPIRATION,
	 LOT_CONTROL,
   SERIAL_NUMBER_GENERATION,
    COST_OF_GOODS_SOLD_ACCOUNT,
	 OUTSIDE_PROCESSING_ITEM,
   OUTSIDE_PROCESSING_UNIT_TYPE,
   UNIT_OF_ISSUE,
    EXPENSE_ACCOUNT,
   WEIGHT_UOM,
    UNIT_WEIGHT,
	 VOLUME_UOM,
   UNIT_VOLUME,
    VEHICLE,
	 CONTAINER,
   CONTAINER_TYPE,
    INTERNAL_VOLUME,
	 MAXIMUM_LOAD_WEIGHT,
   MINIMUM_FILL_PERCENTAGE,
    DIMENSION_UOM,
	 LENGTH,
   WIDTH,
    HEIGHT,
	 MINMAX_MINIMUM_QTY,
   MINMAX_MAXIMUM_QTY,
    SOURCE_TYPE,
	 SAFETY_STOCK,
   SAFETY_STOCK_BUCKET_DAYS,
    SAFETY_STOCK_PERCENT,
	 FORECAST_TYPE,
   WINDOW_DAYS,
   TARGET_INVENTORY_DAYS_SUPPLY,
    TARGET_INVENTORY_WINDOW,
   POSTPROCESSING_LEAD_TIME,
    FIXED_LEAD_TIME,
	 PICK_COMPONENTS,
   SALES_ACCOUNT,
    SERVICE_REQUEST_CODE,
	 ENABLE_CONTRACT_COVERAGE,
   ENABLE_DEFECT_TRACKING,
    ENABLE_SERVICE_BILLING,
	 BILLING_TYPE,
   RECOVERED_PART_DISPOSITION,
   HAE_PURCHASING_CATEGORY,
   charuserfield1
   ,fastpack
   )
VALUES ( v_items_cle.RECORD_ID,
     'C',
    v_items_cle.STATUS,
    v_items_cle.ITEM_NUMBER,
    v_items_cle.DESCRIPTION,
     v_items_cle.ITEM_STATUS,
	  v_items_cle.PRIMARY_UOM,
    v_items_cle.SECONDARY_UOM,
     v_items_cle.START_DATE_ACTIVE,
	  v_items_cle.TEMPLATE_CODE,
    v_items_cle.ITEM_PRODUCT_LINE,
     v_items_cle.ITEM_PRODUCT_TYPE,
	  v_items_cle.ITEM_PRODUCT_SUBTYPE,
    v_items_cle.ITEM_PLATFORM,
     v_items_cle.STERILIZATION_CODE,
	  v_items_cle.INVOICE_UOM,
    v_items_cle.JAN_CODE,
     v_items_cle.TEMPRHREQ,
	  v_items_cle.JAPAN_CATEGORIES,
    v_items_cle.REVISION_CONTROL,
     v_items_cle.LOT_EXPIRATION,
	  v_items_cle.LOT_CONTROL,
    v_items_cle.SERIAL_NUMBER_GENERATION,
     v_items_cle.COST_OF_GOODS_SOLD_ACCOUNT,
	  v_items_cle.OUTSIDE_PROCESSING_ITEM,
    v_items_cle.OUTSIDE_PROCESSING_UNIT_TYPE,
    v_items_cle.UNIT_OF_ISSUE,
     v_items_cle.EXPENSE_ACCOUNT,
    v_items_cle.WEIGHT_UOM,
     v_items_cle.UNIT_WEIGHT,
	  v_items_cle.VOLUME_UOM,
    v_items_cle.UNIT_VOLUME,
     v_items_cle.VEHICLE,
	  v_items_cle.CONTAINER,
    v_items_cle.CONTAINER_TYPE,
     v_items_cle.INTERNAL_VOLUME,
	  v_items_cle.MAXIMUM_LOAD_WEIGHT,
    v_items_cle.MINIMUM_FILL_PERCENTAGE,
     v_items_cle.DIMENSION_UOM,
	  v_items_cle.LENGTH,
    v_items_cle.WIDTH,
     v_items_cle.HEIGHT,
	  v_items_cle.MINMAX_MINIMUM_QTY,
    v_items_cle.MINMAX_MAXIMUM_QTY,
     v_items_cle.SOURCE_TYPE,
	  v_items_cle.SAFETY_STOCK,
    v_items_cle.SAFETY_STOCK_BUCKET_DAYS,
     v_items_cle.SAFETY_STOCK_PERCENT,
	  v_items_cle.FORECAST_TYPE,
    v_items_cle.WINDOW_DAYS,
    v_items_cle.TARGET_INVENTORY_DAYS_SUPPLY,
     v_items_cle.TARGET_INVENTORY_WINDOW,
    v_items_cle.POSTPROCESSING_LEAD_TIME,
     v_items_cle.FIXED_LEAD_TIME,
	  v_items_cle.PICK_COMPONENTS,
    v_items_cle.SALES_ACCOUNT,
     v_items_cle.SERVICE_REQUEST_CODE,
	  v_items_cle.ENABLE_CONTRACT_COVERAGE,
    v_items_cle.ENABLE_DEFECT_TRACKING,
     v_items_cle.ENABLE_SERVICE_BILLING,
	  v_items_cle.BILLING_TYPE,
    v_items_cle.RECOVERED_PART_DISPOSITION,
     v_items_cle.HAE_PURCHASING_CATEGORY
	,v_items_cle.agile_eco_no
	,v_items_cle.fastpack
	 )
	 ;
end loop;
commit;
for v_items_inv in c_items_inv loop
	for v_item_rec_id in c_item_rec_id (v_items_inv.item_number) loop
	 l_item_rec_id := v_item_rec_id.record_id;
	end loop;
--populate Item by Inv Org table
	INSERT INTO XXHA_ITEM_INVORGS_STG (
   RECORD_ID,
    ITEM_RECORD_ID,
	 CI_FLAG,
   STATUS,
   ITEM_NUMBER,
    INVENTORY_ORG_CODE,
     USER_ITEM_TYPE,
	CONVERSIONS,
   SUPPLIER_NO_AGILE,
    SUPPLIER_NO_BPCS,
	 STARTING_LOT_PREFIX,
   STARTING_LOT_NUMBER,
    PURCHASED,
	 TAXABLE,
   PURCHASING_TAX_CODE,
    DEFAULT_BUYER_NAME,
	 PLANNER,
   MAKE_OR_BUY,
    SOURCE_ORG_CODE,
	 PREPROCESSING_LEAD_TIME,
   PROCESSING_LEAD_TIME,
    DEFAULT_SHIPPING_ORG_CODE,
	TAX_CODE,
    PAYMENT_TERMS_NAME,
	STERILIZATION_CODE,
    INVOICE_UOM,
	 JAN_CODE,
   TEMPRHREQ,
   JAPAN_CATEGORIES,
    OUTSIDE_PROCESSING_ITEM,
   OUTSIDE_PROCESSING_UNIT_TYPE,
    UNIT_OF_ISSUE,
	MINMAX_MINIMUM_QTY,
    MINMAX_MAXIMUM_QTY,
	 SOURCE_TYPE,
   SAFETY_STOCK,
    SAFETY_STOCK_BUCKET_DAYS,
	 SAFETY_STOCK_PERCENT,
   FORECAST_TYPE,
    WINDOW_DAYS,
	 TARGET_INVENTORY_DAYS_SUPPLY,
   TARGET_INVENTORY_WINDOW,
    POSTPROCESSING_LEAD_TIME,
	 FIXED_LEAD_TIME,
   PICK_COMPONENTS,
   ENABLE_DEFECT_TRACKING,
    RECOVERED_PART_DISPOSITION,
   TEMPLATE_CODE,
    SERIAL_NUMBER_GENERATION,
   STARTING_SERIAL_NUMBER,
    STARTING_SERIAL_PREFIX
	,item_cost
   )
  VALUES
  ( v_items_inv.RECORD_ID,
    nvl(l_item_rec_id,v_items_inv.RECORD_ID),--v_items_inv.RECORD_ID,
	 'C',
   v_items_inv.STATUS,
   v_items_inv.ITEM_NUMBER,
    v_items_inv.INVENTORY_ORG_CODE,
     v_items_inv.USER_ITEM_TYPE,
	v_items_inv.CONVERSIONS,
   v_items_inv.SUPPLIER_NO_AGILE,
    v_items_inv.SUPPLIER_NO_BPCS,
	 v_items_inv.STARTING_LOT_PREFIX,
   v_items_inv.STARTING_LOT_NUMBER,
    v_items_inv.PURCHASED,
	 v_items_inv.TAXABLE,
   v_items_inv.PURCHASING_TAX_CODE,
    v_items_inv.DEFAULT_BUYER_NAME,
	 v_items_inv.PLANNER,
   v_items_inv.MAKE_OR_BUY,
    v_items_inv.SOURCE_ORG_CODE,
	 v_items_inv.PREPROCESSING_LEAD_TIME,
   v_items_inv.PROCESSING_LEAD_TIME,
    v_items_inv.DEFAULT_SHIPPING_ORG_CODE,
	v_items_inv.TAX_CODE,
    v_items_inv.PAYMENT_TERMS_NAME,
	v_items_inv.STERILIZATION_CODE,
    v_items_inv.INVOICE_UOM,
	 v_items_inv.JAN_CODE,
   v_items_inv.TEMPRHREQ,
   v_items_inv.JAPAN_CATEGORIES,
    v_items_inv.OUTSIDE_PROCESSING_ITEM,
   v_items_inv.OUTSIDE_PROCESSING_UNIT_TYPE,
    v_items_inv.UNIT_OF_ISSUE,
	v_items_inv.MINMAX_MINIMUM_QTY,
    v_items_inv.MINMAX_MAXIMUM_QTY,
	 v_items_inv.SOURCE_TYPE,
   v_items_inv.SAFETY_STOCK,
    v_items_inv.SAFETY_STOCK_BUCKET_DAYS,
	 v_items_inv.SAFETY_STOCK_PERCENT,
   v_items_inv.FORECAST_TYPE,
    v_items_inv.WINDOW_DAYS,
	 v_items_inv.TARGET_INVENTORY_DAYS_SUPPLY,
   v_items_inv.TARGET_INVENTORY_WINDOW,
    v_items_inv.POSTPROCESSING_LEAD_TIME,
	 v_items_inv.FIXED_LEAD_TIME,
   v_items_inv.PICK_COMPONENTS,
   v_items_inv.ENABLE_DEFECT_TRACKING,
    v_items_inv.RECOVERED_PART_DISPOSITION,
   v_items_inv.TEMPLATE_CODE,
    v_items_inv.SERIAL_NUMBER_GENERATION,
   v_items_inv.STARTING_SERIAL_NUMBER,
    v_items_inv.STARTING_SERIAL_PREFIX
	,  v_items_inv.shelf_life_days
	 )
	 ;
end loop;
--populate Item Revision table
for v_items_rev in c_items_rev loop

	for v_item_rec_id in c_item_rec_id (v_items_rev.item_number) loop
	 l_item_rec_id := v_item_rec_id.record_id;
	end loop;
	 INSERT INTO XXHA_ITEM_REVISIONS_STG (
   RECORD_ID,
    ITEM_RECORD_ID,
	 CI_FLAG,
   STATUS,
   ITEM_NUMBER,
   REVISION_NO,
   CHANGE_NOTICE,
    EFFECTIVE_DATE,
	 DESCRIPTION,
     STAGED_EFFECTIVE_DATE
	 )
VALUES (haemo.xxha_eco_revision_s.nextval,--v_items_rev.RECORD_ID,
    l_item_rec_id,--v_items_rev.RECORD_ID,
	 'C',
  v_items_rev.STATUS,
   v_items_rev.ITEM_NUMBER,
   v_items_rev.REVISION_NO,
   v_items_rev.agile_eco_no,--v_items_rev.CHANGE_NOTICE,
    v_items_rev.EFFECTIVE_DATE,
	 v_items_rev.DESCRIPTION,
     to_char(v_items_rev.EFFECTIVE_DATE, 'MM/DD/YYYY HH:MI:SS AM')--v_items_rev.STAGED_EFFECTIVE_DATE
	  )
	  ;
end loop;
commit;

for v_items_rev_dash in c_items_rev_dash loop
--select haemo.xxha_eco_revision_s.nextval ;
 l_current_rev_exists := false;
 for v_chk_current_rev_exists in c_chk_current_rev_exists (v_items_rev_dash.item_number) loop
   l_current_rev_exists := true;
 end loop;
 IF NOT l_current_rev_exists THEN
 select starting_revision
 into l_starting_revision
 from mtl_parameters
 where organization_id = 103;
	for v_item_rec_id in c_item_rec_id (v_items_rev_dash.item_number) loop
	 l_item_rec_id := v_item_rec_id.record_id;
	end loop;
	 INSERT INTO XXHA_ITEM_REVISIONS_STG (
   RECORD_ID,
    ITEM_RECORD_ID,
	 CI_FLAG,
   STATUS,
   ITEM_NUMBER,
   REVISION_NO,
   CHANGE_NOTICE,
    EFFECTIVE_DATE,
	 DESCRIPTION
     ,STAGED_EFFECTIVE_DATE
	 )
VALUES (haemo.xxha_eco_revision_s.nextval,--xxha_eco_revision_s.next_val,--v_items_rev_dash.RECORD_ID,
    l_item_rec_id,--haemo.xxha_eco_revision_s.nextval,--xxha_eco_revision_s.next_val,--v_items_rev_dash.RECORD_ID,
	 'C',
  'NEW',--v_items_rev_dash.STATUS,
   v_items_rev_dash.ITEM_NUMBER,
   l_starting_revision,--'-',--v_items_rev.REVISION_NO,
   '',--v_items_rev_dash.CHANGE_NOTICE,
    sysdate,--v_items_rev_das.EFFECTIVE_DATE,
	 v_items_rev_dash.DESCRIPTION
     ,v_items_rev_dash.STAGED_EFFECTIVE_DATE
	  )
	  ;
  END IF;
end loop;
--for v_get_mst_rev in c_get_mst_rev(l_item_id,v_item_post_revision.inventory_org_code) loop
--	  insert into xxha_item_revisions_int_stg
--	  (inventory_item_id,organization_id,revision,last_updated_by,created_by,implementation_date,effectivity_date,description,item_number,organization_code,process_flag,transaction_type,set_process_id)
--	  values
--	   (v_get_mst_rev.inventory_item_id,v_item_post_revision.inv_org_id,v_get_mst_rev.revision,fnd_global.user_id,fnd_global.user_id,v_get_mst_rev.implementation_date,v_get_mst_rev.effectivity_date,v_get_mst_rev.description,v_item_post_revision.item_number,v_item_post_revision.inventory_org_code,'1','CREATE','100000')
--	   ;
--	end loop;
commit;
for v_chk_rev_exists in c_chk_rev_exists loop
  for v_get_mst_rev in c_get_mst_rev (v_chk_rev_exists.item_number,v_chk_rev_exists.revision_no) loop
    INSERT INTO XXHA_ITEM_REVISIONS_STG (
   RECORD_ID,
    item_record_id,
	 CI_FLAG,
   STATUS,
   ITEM_NUMBER,
   REVISION_NO,
   CHANGE_NOTICE,
    EFFECTIVE_DATE,
	 DESCRIPTION
     ,STAGED_EFFECTIVE_DATE
	 )
VALUES (haemo.xxha_eco_revision_s.nextval,
    v_chk_rev_exists.item_RECORD_ID,
	 'C',
  v_chk_rev_exists.STATUS,
   v_chk_rev_exists.ITEM_NUMBER,
   v_get_mst_rev.REVISION,
   v_chk_rev_exists.CHANGE_NOTICE,
    v_get_mst_rev.EFFECTIVITY_DATE,
	 v_get_mst_rev.DESCRIPTION
     ,to_char(v_get_mst_rev.EFFECTIVITY_DATE, 'MM/DD/YYYY HH:MI:SS AM')
	  )
	  ;
  end loop;
end loop;
commit;
end ;

--this procedure is fr submitting item load

PROCEDURE submit_item_load (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
IS
ln_request_id number;
l_phase varchar2 (2000);
l_status varchar2 (2000);
l_dev_phase varchar2 (2000);
l_dev_status varchar2 (2000);
l_msg varchar2 (2000);
l_req_status boolean;
BEGIN
Pre_Process_Items (p_eco_name);
---add---
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_request_id--xx_eco_success_tbl(i).record_id
                            ,''--xx_eco_success_tbl(i).eco_name||'/'||xx_eco_success_tbl(i).organization_code
                            ,'S'--gc_error_code
                            ,''--gc_error_msg
                            ,'ITEM START'
                            ,'XXHA_ECO_ITEMS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,''--xx_eco_success_tbl(i).eco_name
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
  ---add---
ln_request_id := FND_REQUEST.SUBMIT_REQUEST('HAEMO'
                                              ,'XXHA_P2_PROCESS_ITEM'
                                              ,'XXHA_P2_PROCESS_ITEM'
                                              , SYSDATE
                                              , FALSE
                                              , 'Y'--Commit
                                              , 'Y'--Validate
                                              , 'Y'--Convert_Item
					      , 'Y'--Inv Cat
					      , 'Y'--PO Cat
					      , 'N'--Rev
					      , 'Y'--Force Commit
                                              );
commit;
l_req_status := fnd_concurrent.wait_for_request (ln_request_id
,60
,2400
,l_phase
,l_status
,l_dev_phase
,l_dev_status
,l_msg);
if l_req_status then
ln_request_id := FND_REQUEST.SUBMIT_REQUEST('HAEMO'
                                              ,'XXHA_P2_PROCESS_ITEM'
                                              ,'XXHA_P2_PROCESS_ITEM'
                                              , SYSDATE
                                              , FALSE
                                              , 'Y'--Commit
                                              , 'Y'--Validate
                                              , 'N'--Convert_Item
					      , 'N'--Inv Cat
					      , 'N'--PO Cat
					      , 'Y'--Rev
					      , 'Y'--Force Commit
                                              );

end if;
commit;
l_req_status := fnd_concurrent.wait_for_request (ln_request_id
,60
,2400
,l_phase
,l_status
,l_dev_phase
,l_dev_status
,l_msg);
if l_req_status then

ln_request_id := FND_REQUEST.SUBMIT_REQUEST('INV'
                                              ,'INCOIN'
                                              ,'Import Items'
                                              , SYSDATE
                                              , FALSE
                                              , '189'--All Org
                                              , '1'--Validate
                                              , '1'--Process
					      , '1'--Delete Processed
					      , '1'--Process Set
					      ,''
					      , '1' -- Create or Update
					      );
commit;
end if;
g_request_id := ln_request_id;
/*l_req_status := fnd_concurrent.wait_for_request (ln_request_id
,60
,240
,l_phase
,l_status
,l_dev_phase
,l_dev_status
,l_msg);*/
	Post_Process_Items (p_eco_name);
---add---
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_request_id--xx_eco_success_tbl(i).record_id
                            ,''
                            ,'S'--gc_error_code
                            ,''--gc_error_msg
                            ,'ITEM END'
                            ,'XXHA_ECO_ITEMS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,''--xx_eco_success_tbl(i).eco_name
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
  ---add---
END;
--chk If rev already exist in PRD
PROCEDURE Chk_Rev_Exists (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
is
cursor c_chk_item_rev is
select * from xxha_eco_revisions_stg
where status <> 'PS'
and eco_name = p_eco_name
;
cursor c_chk_current_rev_exists (q_item_number varchar2,q_org_code varchar2,q_rev varchar2) is
select distinct items.segment1
from mtl_system_items items,mtl_item_revisions_b rev,mtl_parameters param
where items.organization_id = rev.organization_id
and items.inventory_item_id = rev.inventory_item_id
and items.organization_id = param.organization_id
--and rev.organization_id = 103
and items.segment1 =  q_item_number
and param.organization_code = q_org_code
and revision = q_rev
;
begin
  for v_chk_item_rev in c_chk_item_rev loop
    for v_chk_current_rev_exists in c_chk_current_rev_exists (v_chk_item_rev.revised_item_name,v_chk_item_rev.organization_code,v_chk_item_rev.new_revised_item_revision) loop
	  update xxha_eco_revisions_stg
	  set new_revised_item_revision = null
	  where status <> 'PS'
	  and record_id is not null
	  and revised_item_name = v_chk_item_rev.revised_item_name
	  and organization_code = v_chk_item_rev.organization_code
	  and new_revised_item_revision = v_chk_item_rev.new_revised_item_revision
	  and eco_name = p_eco_name
	  ;

	end loop;
  end loop;
end ;

--this procedure is for pre processing ECO.

PROCEDURE Pre_Process_ECO (p_eco_name in xxha_eco_revisions_stg.eco_name%type)
is
cursor c_pre_process_eco is
select *
from xxha_eco_revisions_stg
where nvl(status,'NEW') <> 'PS'
and eco_name = p_eco_name
;

cursor c_chk_eco_created (q_eco_name varchar2,q_org_code varchar2) is
select change_notice
from eng_engineering_changes eng,mtl_parameters param
where eng.organization_id = param.organization_id
and change_notice = q_eco_name
and organization_code = q_org_code
;

--cursor c_pre_process_eco is
--select *
--from xxha_eco_revisions_stg
--where nvl(status,'NEW') <> 'PS'
--;

l_rev_item_id number;
l_org_id number;
l_comp_item_id number;
l_rev_item_exists varchar2 (2000);
l_comp_item_exists varchar2 (2000);
l_rev_effective_date date;
l_rev_exists varchar2 (2000);
l_item_seq_number VARCHAR2 (2000);
l_op_seq_number   VARCHAR2 (2000);
l_comp_effective_date  VARCHAR2 (2000);
l_comp_exists     varchar2 (2000);
l_op_sequence_id NUMBER;
l_ops_effective_date  varchar2 (2000);
l_ops_exists varchar2 (2000);
l_resource_seq_num VARCHAR2 (2000);
l_res_exists varchar2 (2000);
l_comp_acd_type number;
l_ops_acd_type number;
l_res_acd_type number;
l_assly_item_number varchar2 (2000);
l_item_org_id number;
l_revised_item_cat_map varchar2 (2000);
-- Added old op_seq_number for new logic on update/disable of existing comp
l_old_op_seq_number   VARCHAR2 (2000);

begin
create_eco_record_id (p_eco_name);
create_eco_items_record_id (p_eco_name);

update xxha_eco_revisions_stg
set change_type_code = 'Prod Chg'
where status <> 'PS'
and eco_name = p_eco_name
;
/*
for v_pre_process_eco in c_pre_process_eco loop
  for v_chk_eco_created in c_chk_eco_created (v_pre_process_eco.eco_name,v_pre_process_eco.organization_code) loop
    update xxha_Eco_revisions_stg
	set status = 'PS'
	where eco_name = v_pre_process_eco.eco_name
	and organization_code = v_pre_process_eco.organization_code
	;
	xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,v_pre_process_eco.record_id
                            ,v_pre_process_eco.eco_name||'/'||v_pre_process_eco.organization_code
                            ,'S'--gc_error_code
                            ,''--gc_error_msg
                            ,'ECO SUCCESS'
                            ,'XXHA_ECO_REVISIONS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,v_pre_process_eco.eco_name
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
  end loop;
end loop;
commit;
*/
  for v_pre_process_eco in c_pre_process_eco loop

  l_old_op_seq_number := null;

    XXHA_ECO_UTIL_PKG.CHK_ITEM_AT_ORG
	(       v_pre_process_eco.revised_item_name
		   ,v_pre_process_eco.organization_code
		   ,l_rev_item_id
		   ,l_org_id
		   ,l_rev_item_exists
        );
	l_item_org_id := l_org_id;
   dbms_output.put_line(l_org_id);
      XXHA_ECO_UTIL_PKG.CHK_ITEM_AT_ORG
	(       v_pre_process_eco.component_item_name
		   ,v_pre_process_eco.organization_code
		   ,l_comp_item_id
		   ,l_org_id
		   ,l_comp_item_exists
        );

	XXHA_ECO_UTIL_PKG.chk_rev_at_org
          (
           l_rev_item_id
		   ,l_org_id
		   ,v_pre_process_eco.new_revised_item_revision
		   ,l_rev_effective_date
		   ,l_rev_exists
        );

	XXHA_ECO_UTIL_PKG.chk_comp_at_org
          (
           l_rev_item_id
		   ,l_comp_item_id
		   ,l_org_id
		   ,l_item_seq_number
		   ,l_op_seq_number
		   ,l_comp_effective_date
		   ,l_comp_exists
        );

     IF l_comp_exists = 'Y' THEN

        l_old_op_seq_number := l_op_seq_number;

     END IF;

-- START of FIX ITEM SEQUENCE NUMBER 1
-- Added by Diane Houston March 22, 2013

  IF l_comp_exists = 'Y' THEN

     l_revised_item_cat_map := 'N';

     BEGIN
     select 'Y'
     into   l_revised_item_cat_map
     from   dual
     where  exists
            (select 'x'
             from   mtl_item_categories mic,
                    mtl_categories mc,
                    haemo.xxha_agile_item_num_cat_map hain
              where  mic.inventory_item_id = l_rev_item_id
               and mic.organization_id = 103 -- MST
               and mic.category_set_id = 1 -- Inventory
               and mic.category_id =  mc.category_id
               and mc.segment1 = hain.product_line
               and mc.segment4 = nvl(hain.product_platform, mc.segment4));
     EXCEPTION WHEN NO_DATA_FOUND THEN
         l_revised_item_cat_map := 'N';
     END;

     IF l_revised_item_cat_map = 'Y' THEN

        l_item_seq_number := null;

     END IF;

  END IF;

-- END of FIX ITEM SEQUENCE NUMBER 1

	dbms_output.put_line(l_op_seq_number||' '||l_item_seq_number||' '||l_comp_effective_date||length(to_char(l_comp_effective_date)));
	XXHA_ECO_UTIL_PKG.chk_ops_at_org
          (
           l_rev_item_id
		   ,l_org_id
		   ,v_pre_process_eco.department_code
		   ,l_op_seq_number
		   ,l_op_sequence_id
		   ,l_ops_effective_date
		   ,l_ops_exists
        );

	dbms_output.put_line(l_op_seq_number||' '||l_ops_effective_date);
	IF l_ops_exists = 'Y'  THEN
		XXHA_ECO_UTIL_PKG.chk_ops_resource
          (
           l_op_sequence_id
		   ,v_pre_process_eco.resource_code
		   ,l_resource_seq_num
		   ,l_res_exists
        );
	ELSE
	 l_res_exists := 'N';
	END IF;

-- If stmt added by Diane Houston to not override the actual ops seq
-- on the component if it actually has one.  Also does not get a new
-- operation if the component has the default 1 (no op seq)

  IF l_ops_exists = 'N' and nvl(l_old_op_seq_number,0) != 1 THEN

    XXHA_ECO_UTIL_PKG.get_ops_at_org
          (
           l_rev_item_id
		   ,l_org_id
		   ,l_op_seq_number
		   ,l_op_sequence_id
		  ,l_ops_effective_date
		  ,l_ops_exists
        );

 END IF;

	update xxha_eco_revisions_stg
	set revised_item_exists = l_rev_item_exists
	,component_item_exists = l_comp_item_exists
	,component_exists = l_comp_exists
	,operation_exists =  l_ops_exists
	,resource_exists = l_res_exists
	,rev_item_id = l_rev_item_id
	,comp_item_id = l_comp_item_id
	,org_id = l_item_org_id
	,operation_seq_id = l_op_sequence_id
	,old_comp_effective_date = l_comp_effective_date--,1,9),'DD-MON-YYYY HH24:MI:SS')
	,old_ops_effective_date = l_ops_effective_date
	,old_operation_sequence_number = l_op_seq_number
--addd
	,new_operation_sequence_number = nvl(l_op_seq_number,1)
	,item_sequence_number = nvl(l_item_seq_number, item_sequence_number)
---addd
	where record_id = v_pre_process_eco.record_id
	and eco_name = v_pre_process_eco.eco_name
	and organization_code = v_pre_process_eco.organization_code
	;

  end loop;
  commit;

  for v_pre_process_eco in c_pre_process_eco loop
    --dbms_output.put_line('AA');
	if v_pre_process_eco.component_item_name is not null then
		if nvl(v_pre_process_eco.component_exists,'N') = 'N'   then
		  l_comp_acd_type := 1;
		  --dbms_output.put_line('AA1');
		else
		  --dbms_output.put_line('AA2');
		  if nvl(v_pre_process_eco.component_exists,'N') = 'Y' then
		    if v_pre_process_eco.disable_date_comp is null then
			  l_comp_acd_type := 2;
			else
			  l_comp_acd_type := 3;
			end if;
		  end if;
		end if;
    else
	  l_comp_acd_type := null;

	end if;
   if v_pre_process_eco.department_code is not null then
	     if nvl(v_pre_process_eco.operation_exists,'N') = 'N' then
		  l_ops_acd_type := 1;
		else
		  if nvl(v_pre_process_eco.operation_exists,'N') = 'Y' then
		    if v_pre_process_eco.disable_date_ops is null then
			  l_ops_acd_type := 2;
			else
			  l_ops_acd_type := 3;
			end if;
		  end if;
		end if;
   else
     l_ops_acd_type := null;
   end if;
   if l_ops_acd_type is not null then
	     if nvl(v_pre_process_eco.resource_exists,'N') = 'N' then
		  l_res_acd_type := 1;
		else
		  /*if nvl(v_pre_process_eco.resource_exists,'N') = 'Y' then
		    if v_pre_process_eco.disable_date_ops is null then
			  l_ops_acd_type := 3;
			else
			  l_ops_acd_type := 2;
			end if;
		  end if; */
		   l_res_acd_type := 2;
		end if;
	else
	  l_res_acd_type := null;
	end if;
    update xxha_eco_revisions_stg
	set rev_component_acd_type = l_comp_acd_type
	, rev_operation_acd_type = l_ops_acd_type
	,rev_resource_acd_type = l_res_acd_type
	where record_id = v_pre_process_eco.record_id
	and eco_name = v_pre_process_eco.eco_name
	;
  end loop;
  commit;
  for v_pre_process_eco in c_pre_process_eco loop
    IF v_pre_process_eco.change_type_code = 'Use Up' THEN
      NULL;
	  l_rev_item_exists := 'N';
	  dbms_output.put_line(v_pre_process_eco.org_id);
	  XXHA_ECO_UTIL_PKG.get_assly_chk_comp
          (
            l_rev_item_id
		   ,v_pre_process_eco.org_id
		   ,l_item_seq_number
		   ,l_op_seq_number
		   ,l_comp_effective_date
		   ,l_assly_item_number
		   ,l_rev_item_exists
        );
delete from xxha_eco_revisions_stg where eco_name = v_pre_process_eco.eco_name
and organization_code = v_pre_process_eco.organization_code and use_up_row = 'Y';
		INSERT INTO XXHA_ECO_REVISIONS_STG ( RECORD_ID, ECO_NAME, ORGANIZATION_CODE, CHANGE_TYPE_CODE,
ORGANIZATION_HIERARCHY, AGILE_ECO_STATUS, STATUS_NAME, REQUESTOR, ECO_DEPARTMENT_NAME, REASON_CODE,
PRIORITY_CODE, DESCRIPTION, REVISED_ITEM_NAME, NEW_REVISED_ITEM_REVISION, NEW_EFFECTIVE_DATE,
REV_COMPONENT_ACD_TYPE, COMPONENT_ITEM_NAME, OLD_OPERATION_SEQUENCE_NUMBER,
NEW_OPERATION_SEQUENCE_NUMBER, ITEM_SEQUENCE_NUMBER, QUANTITY_PER_ASSEMBLY, DISABLE_DATE_OPS,
WIP_SUPPLY_TYPE, SUPPLY_SUBINVENTORY, LOCATION_NAME, PLANNING_PERCENT, PROJECTED_YIELD,
INCLUDE_IN_COST_ROLLUP, COMMENTS, REV_OPERATION_ACD_TYPE, OPERATION_SEQUENCE_NUMBER,
DEPARTMENT_CODE, START_EFFECTIVE_DATE, DISABLE_DATE_COMP, REV_RESOURCE_ACD_TYPE,
RESOURCE_SEQUENCE_NUMBER, RESOURCE_CODE, USAGE_RATE_OR_AMOUNT, DATE_STAGED, STATUS,
START_EFFECTIVE_DATE_REV, START_EFFECTIVE_DATE_COMP, START_EFFECTIVE_DATE_OPS,
START_EFFECTIVE_DATE_RESOURCE, REVISED_ITEM_EXISTS, COMPONENT_ITEM_EXISTS, OPERATION_EXISTS,
RESOURCE_EXISTS, REV_ITEM_ID, COMP_ITEM_ID, ORG_ID, OPERATION_SEQ_ID, OLD_COMP_EFFECTIVE_DATE,
OLD_OPS_EFFECTIVE_DATE, COMPONENT_EXISTS,use_up_row ) VALUES (
v_pre_process_eco.record_id, v_pre_process_eco.eco_name, v_pre_process_eco.organization_code, v_pre_process_eco.CHANGE_TYPE_CODE, NULL,  v_pre_process_eco.agile_Eco_status,  v_pre_process_eco.status_name,  v_pre_process_eco.requestor
, v_pre_process_eco.ECO_DEPARTMENT_NAME, v_pre_process_eco.REASON_CODE,
v_pre_process_eco.PRIORITY_CODE, v_pre_process_eco.DESCRIPTION,l_assly_item_number, null, v_pre_process_eco.NEW_EFFECTIVE_DATE,
2, v_pre_process_eco.REVISED_ITEM_NAME, l_op_seq_number,
null,null, null, null,
null, null, null, null, null,
null, Null, null, l_op_seq_number,
null, v_pre_process_eco.START_EFFECTIVE_DATE, null, null,
null, null, null, null, 'NEW',
v_pre_process_eco.START_EFFECTIVE_DATE_REV, v_pre_process_eco.START_EFFECTIVE_DATE_COMP, null,
null, l_rev_item_exists, 'Y', 'N',
'N', null, l_rev_item_id, l_ORG_ID, null, l_comp_effective_date,
null, 'Y','Y'
);

    ENd IF;
  end loop;
  commit;
  update_item_seq_num (p_eco_name);
  Chk_Rev_Exists (p_eco_name);
  commit;
end;

--this procedure is for updating ECO

PROCEDURE Update_ECO_Released
(p_eco_name in xxha_eco_revisions_stg.eco_name%type
)
is

cursor c_get_eco_released is
select *
from xxha_eco_revisions_stg
where nvl(status,'NEW') <> 'PS'
and nvl(agile_eco_status,'ANR') = 'RELEASED'
and eco_name = p_eco_name
;
l_ECO_rec                   eng_eco_pub.Eco_Rec_Type;

l_eco_revision_tbl          eng_eco_pub.Eco_Revision_Tbl_Type;
--p_eco_revision_tbl          eng_eco_pub.Eco_Revision_Tbl_Type;
l_change_line_tbl           eng_eco_pub.Change_Line_Tbl_Type;
l_revised_item_tbl          eng_eco_pub.Revised_Item_Tbl_Type;
l_rev_component_tbl         Bom_Bo_Pub.Rev_Component_Tbl_Type;
l_ref_designator_tbl        Bom_Bo_Pub.Ref_Designator_Tbl_Type;
l_sub_component_tbl         Bom_Bo_Pub.Sub_Component_Tbl_Type;
l_rev_operation_tbl         Bom_Rtg_Pub.Rev_Operation_Tbl_Type;
l_rev_op_resource_tbl       Bom_Rtg_Pub.Rev_Op_Resource_Tbl_Type;  --L1
l_rev_sub_resource_tbl      Bom_Rtg_Pub.Rev_Sub_Resource_Tbl_Type;
l_return_status VARCHAR2 (2000);
begin

  for v_get_eco_released in c_get_eco_released loop
     gn_record_number := v_get_eco_released.record_id;
     gc_record_identifier := v_get_eco_released.eco_name||' '||v_get_eco_released.organization_code;
	 l_eco_rec.eco_name :=  v_get_eco_released.eco_name;
	 l_eco_rec.organization_code :=  v_get_eco_released.organization_code;
	 l_eco_rec.transaction_type := 'UPDATE';
	 l_eco_rec.status_Name := 'Open';

	 Call_Eco_API
	 (
	  l_ECO_rec,
	  l_eco_revision_tbl,
	  l_change_line_tbl,
	  l_revised_item_tbl,
	  l_rev_component_tbl,
	  l_ref_designator_tbl,
	  l_sub_component_tbl,
	  l_rev_operation_tbl,
	  l_rev_op_resource_tbl,
	  l_rev_sub_resource_tbl,
	  l_return_status
	 )
	 ;
  end loop;
end;

--This procedure is for processing ECO.

PROCEDURE processing_eco
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
       -- ,p_commit_flag  in  varchar2
	--	,p_force_commit in varchar2
        )
		IS
cursor c_get_eco is
select distinct eco_name
from xxha_eco_revisions_stg
where nvl(status,'NEW') <> 'PS'
and upper(status) <> 'RELEASED'
and rownum < 2
;

cursor c_get_item_eco is
select distinct agile_eco_no
from xxha_eco_items_stg
where status <> 'PS'
-- and inventory_org_code = 'MST'
and rownum < 2
;

cursor c_get_eco_released is
select distinct eco_name
from xxha_eco_revisions_stg
where nvl(status,'NEW') <> 'PS'
and upper(status) = 'RELEASED'
;

cursor c_get_cost_errors( p_eco_num xxha_eco_revisions_stg.eco_name%type ) is
select item_number, organization_code, item_cost, status
from xxha_item_cst_dtls_stg
where nvl(error_flag,'PS') = 'PS'
and status like 'Err:%'
and attribute3 = p_eco_num
;

l_commit_eco boolean;
l_wait_for_item boolean;
l_phase varchar2 (2000);
l_status varchar2 (2000);
l_dev_phase varchar2 (2000);
l_dev_status varchar2 (2000);
l_msg varchar2 (2000);
l_eco_name xxha_eco_revisions_stg.eco_name%type;

l_count_seq_errors number;

---- For Item cost load and Std cost update changes
l_ret_msg varchar2 (2000);
l_debug_flag varchar2(1):= 'N';
l_req_status boolean;
begin
  gn_request_id := fnd_global.conc_request_id;
  FND_GLOBAL.APPS_INITIALIZE(USER_ID=>fnd_global.USER_ID,RESP_ID=>fnd_global.RESP_ID,RESP_APPL_ID=>fnd_global.RESP_APPL_ID);

  ---add---
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_request_id--xx_eco_success_tbl(i).record_id
                            ,''--xx_eco_success_tbl(i).eco_name||'/'||xx_eco_success_tbl(i).organization_code
                            ,'S'--gc_error_code
                            ,''--gc_error_msg
                            ,'ECO START'
                            ,'XXHA_ECO_REVISIONS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,''--xx_eco_success_tbl(i).eco_name
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
  for v_get_eco in c_get_eco loop
        l_eco_name := v_get_eco.eco_name;
  end loop;

  if l_eco_name is null then
  	for v_get_item_eco in c_get_item_eco loop
		l_eco_name := v_get_item_eco.agile_eco_no;
	end loop;

  end if;

  FND_FILE.PUT_LINE(FND_FILE.LOG,'Processing ECO :'||l_eco_name);

	submit_item_load(l_eco_name);

  	l_wait_for_item := fnd_concurrent.wait_for_request (g_request_id
								,30
								,2400
								,l_phase
								,l_status
								,l_dev_phase
								,l_dev_status
								,l_msg);
	IF l_wait_for_item THEN
		Pre_Process_ECO( l_eco_name );

-- START of FIX ITEM SEQUENCE NUMBER 3
-- Added by Diane Houston Apr 23, 2013
-- To avoid abend when processing revisions related to find sequence errors
-- The abend is an existing problem that occurs on some error conditions

   BEGIN
   select count(*)
   into   l_count_seq_errors
   from   xxha_eco_revisions_stg
   where  nvl(status,'NEW') != 'PS'
          and eco_name = l_eco_name
          and nvl(item_sequence_number,0) < 0;
   EXCEPTION WHEN OTHERS THEN
        l_count_seq_errors := 0;
   END;

   IF l_count_seq_errors > 0 THEN

      BEGIN
      update xxha_eco_revisions_stg
      set    status = 'PS'
      where eco_name = l_eco_name
            and component_item_name is null
            and nvl(status,'NEW') != 'PS';
      EXCEPTION WHEN OTHERS THEN
        null;
      END;

      commit;

   END IF;

-- END of FIX ITEM SEQUENCE NUMBER 3

		FOR v_get_eco in c_get_eco LOOP
			l_commit_eco := true;
			Create_ECO_ANR	(v_get_eco.eco_name);
			FOR i IN 1..XX_ECO_ERROR_TBL.COUNT LOOP
				IF xx_eco_error_tbl(i).eco_name = v_get_eco.eco_name THEN
					l_commit_eco := false;
				END IF;
			END LOOP;
			IF l_commit_eco THEN
				commit;
			ELSE
				rollback;
			 END IF;
		END LOOP;

  		log_all_errors;
  		commit;

  		FOR i IN 1..XX_ECO_SUCCESS_TBL.COUNT LOOP
    			l_commit_eco := true;
			FOR i IN 1..XX_ECO_ERROR_TBL.COUNT LOOP
	   			IF xx_eco_error_tbl(i).eco_name = xx_eco_success_tbl(i).eco_name THEN
	     				l_commit_eco := false;
	   			END IF;

	 		END LOOP;
	 		IF l_commit_eco THEN
		  		update xxha_eco_revisions_stg
		  		set status = 'PS'
		  		where eco_name = xx_eco_success_tbl(i).eco_name
		  		and organization_code = xx_eco_success_tbl(i).organization_code
		  		and record_id is not null-- = xx_eco_success_tbl(i).record_id
		  		;
          			xxha_common_utilities_pkg.insert_error_prc(
                             		gn_request_id
                            		,xx_eco_success_tbl(i).record_id
                            		,xx_eco_success_tbl(i).eco_name||'/'||xx_eco_success_tbl(i).organization_code
                            		,'S'--gc_error_code
                            		,''--gc_error_msg
                            		,'ECO SUCCESS'
                            		,'XXHA_ECO_REVISIONS_STG'
                            		,gc_attribute1
                            		,gc_attribute2
                            		,xx_eco_success_tbl(i).eco_name
                            		,'N'--gc_attribute4
                            		,gc_attribute5
                            		,gc_status
                            		);
			END IF;
		END LOOP;
   		-- VV added code, 2009-10-22
   		begin
			update xxha_eco_revisions_stg
			set status = 'PS'
			where eco_name = l_eco_name
			and status <> 'PS'
			and record_id is not null
			;
			commit;
			FND_FILE.PUT_LINE(FND_FILE.LOG,'Updated records in XXHA_ECO_REVISIONS_STG for ' || l_eco_name);

		exception
			when others
			then
          			FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in updating XXHA_ECO_REVISIONS_STG table records for ' || l_eco_name);
		end;
  		-- VV end added code, 2009-10-22
  		---add---
  		commit;
	END IF;
	null;

	-- Item cost load and Std cost update changes
	begin
		-- flag to enable messages in concurrent log. Possible values Y or N
		l_debug_flag := 'Y';  -- comment this if debug statements are not required in prog log

		populate_fnd_log (l_debug_flag,'Start of item cost changes.');

		loop
			l_req_status := fnd_concurrent.get_request_status (g_request_id
									,null   -- application
									,null   -- program
									,l_phase
									,l_status
									,l_dev_phase
									,l_dev_status
									,l_msg);
			exit when l_dev_phase =  'COMPLETE';
		end loop;

		if l_dev_phase = 'COMPLETE'
	                and l_dev_status in ('NORMAL','WARNING') then

			populate_fnd_log (l_debug_flag,'process_eco_item_cost submitted');

			process_eco_item_cost
				(p_debug_flag => l_debug_flag,
				 p_return_msg => l_ret_msg);

			populate_fnd_log (l_debug_flag,'Message from process_eco_item_cost: '||l_ret_msg);

		end if;

		populate_fnd_log (l_debug_flag,'End of item cost changes.');

	exception
	when others then
	  	fnd_file.put_line(fnd_file.log, 'Error in cost loading block'||substr(sqlerrm,1,100));
	end;


	-- Adding price to price list from cost
	-- VV: added for ver2.1 2012-01-12 (price list)
	begin
		-- flag to enable messages in concurrent log. Possible values Y or N
		l_debug_flag := 'Y';  -- comment this if debug statements are not required in prog log
		l_ret_msg := null;

		populate_fnd_log (l_debug_flag,'Start of item price list changes.');

		if l_dev_phase = 'COMPLETE' and l_dev_status in ('NORMAL','WARNING') then

			populate_fnd_log (l_debug_flag,'process_eco_item_price_list submitted');

			process_eco_item_price_list( p_debug_flag => l_debug_flag, p_return_msg => l_ret_msg );

			populate_fnd_log (l_debug_flag,'Message from process_eco_item_price_list: '||l_ret_msg);

		end if;

		populate_fnd_log (l_debug_flag,'End of item price list changes.');

	exception
	when others then
		fnd_file.put_line(fnd_file.log, 'Error in item price list loading block'||substr(sqlerrm,1,100));
	end;

  	---DL 7/21/10 Moved from before cost load to after cost load
	xxha_common_utilities_pkg.insert_error_prc(
		gn_request_id
		,gn_request_id--xx_eco_success_tbl(i).record_id
		,''--xx_eco_success_tbl(i).eco_name||'/'||xx_eco_success_tbl(i).organization_code
		,'S'--gc_error_code
		,''--gc_error_msg
		,'ECO END'
		,'XXHA_ECO_REVISIONS_STG'
		,gc_attribute1
		,gc_attribute2
		,''--xx_eco_success_tbl(i).eco_name
		,'N'--gc_attribute4
		,gc_attribute5
		,gc_status
	);

end;

-- procedure to record messages in concurrent log
PROCEDURE populate_fnd_log
	 (  p_flag  in varchar2,
	    p_msg   in varchar2
	 )
IS
	--p_flag := 'N';
	--p_msg  := NULL;
BEGIN
	IF p_flag = 'Y' THEN
		fnd_file.put_line(fnd_file.output, p_msg);
	END IF;

EXCEPTION
WHEN OTHERS THEN
	fnd_file.put_line(fnd_file.log, 'Error from exception in populate_fnd_log'||substr(sqlerrm,1,100));
END populate_fnd_log;

-- Call this once the items and revisions are loaded by ECO Interface
PROCEDURE process_eco_item_cost
        (  p_debug_flag  in varchar2,
           p_return_msg out varchar2
        )
IS
	cursor c_item_costs1
	is
	select distinct group_id, group_description, cost_type
	from xxha_item_cst_dtls_stg
	where error_flag = 'PS'
	  and status = 'NEW'
	  and nvl(group_description,'ABC') like 'COSTUPDATE%'
	order by group_id;

	cursor c_item_costs
        is
	select *
	from xxha_item_cst_dtls_stg
	where error_flag = 'PS'
	  and status = 'NEW'
	  and nvl(group_description,'ABC') like 'COSTUPDATE%'
	order by group_id, record_id;

	cursor c_groups
	is
	select distinct cost_type
	from xxha_item_cst_dtls_stg
	where nvl(error_flag,'XY') <> 'PS'
	and status = 'NEW'
	and group_id is null;

	cursor c_reqs
	is
	select *
	from xxha_item_cst_dtls_stg
	where attribute14 is not null
	and error_flag = 'PS'
	order by group_id, record_id;

	l_debug_flag varchar2(1):= 'N';
	v_msg        varchar2(1000);
	l_errbuf     varchar2(100);
	l_retcode    number;
	l_req_status boolean;
	ln_request_id number;
	l_std_cost_type_id number;
	l_user_cost_type_id number;
	l_item_cost number;
	l_cost_type varchar2(100);
	l_phase varchar2 (2000);
	l_status varchar2 (2000);
	l_dev_phase varchar2 (2000);
	l_dev_status varchar2 (2000);
	l_msg varchar2 (2000);
	l_cogs_account	number;
	l_upd_msg varchar2 (2000);
	l_seq	number:=0;

BEGIN
	populate_fnd_log (l_debug_flag,'Start process_eco_item_cost');

	IF p_debug_flag = 'Y' THEN
		l_debug_flag := 'Y';
	END IF;

	populate_item_cost;

	for l_rec in c_groups loop

		select HAEMO.XXHA_ITEM_CST_DTLS_S1.nextval
		into l_seq from dual;

		update xxha_item_cst_dtls_stg
		   set group_id = l_seq,
		       group_description = 'COSTUPDATE-GROUPID:'||l_seq
		 where nvl(error_flag,'XY') <> 'PS'
		and group_id is null
		and status = 'NEW'
		and cost_type = l_rec.cost_type;

		commit;
	end loop;

	populate_fnd_log (l_debug_flag,'XXHA_ITEM_COSTS_CONV_P2 process submitted.');

	XXHA_ITEM_COSTS_CONV_P2.pre_processing_item_cost
		(x_errbuf       =>   l_errbuf
		,x_retcode      =>   l_retcode
		,p_debug        => 'Y'
		,p_purge_data   => 'N'
		,p_commit_flag  => 'Y'
		,p_force_commit => 'Y'
		);

	update xxha_item_cst_dtls_stg
	   set status = 'Err: Item Cost Import Interface Error.'
	 where inventory_item_id is null;

	commit;

	populate_fnd_log (l_debug_flag,'l_errbuf -'||l_errbuf);
	populate_fnd_log (l_debug_flag,'l_retcode -'||l_retcode);

	begin
		select cost_type_id
		into l_std_cost_type_id
		from cst_cost_types
		where cost_type = 'Frozen';
	exception
	when others
	then
		null;
	end;

	for r_rec in c_item_costs1 loop

		ln_request_id   := null;
		l_cost_type	:= null;
		l_phase		:= null;
		l_status	:= null;
		l_dev_phase	:= null;
		l_dev_status	:= null;
		l_msg		:= null;
		l_upd_msg       := null;

		begin
			select cost_type_id, cost_type
			into l_user_cost_type_id, l_cost_type
			from cst_cost_types
			where cost_type = r_rec.cost_type;
		exception
		when no_data_found then
			l_user_cost_type_id := -1;
			l_upd_msg           := l_upd_msg||'Err: User Cost Type Setup Not Found.';
		end;

		if nvl(l_user_cost_type_id,-1) > 1 then

			ln_request_id := FND_REQUEST.SUBMIT_REQUEST('BOM'
								,'CSTPCIMP'
								,'Cost Import Process'
								, SYSDATE
								, FALSE
								, '1'                   -- Import cost option
								, '2'		        -- Mode to run this request
								, '1'		        -- Group ID option
								, 'Y'		        -- Group ID Dummy
								, r_rec.group_id 	-- Group ID
								, l_cost_type 		-- Cost type to import to
								, '1' 			-- Delete successful rows
								);
			commit;

			populate_fnd_log (l_debug_flag,'Cost Import Process is Submitted for group : '||r_rec.group_description);

			loop
				l_req_status := fnd_concurrent.get_request_status (ln_request_id
										,'BOM'        -- application
										,'CSTPCIMP'   -- program
										,l_phase
										,l_status
										,l_dev_phase
										,l_dev_status
										,l_msg);

				exit when l_dev_phase = 'COMPLETE';
			end loop;

			populate_fnd_log (l_debug_flag,'Cost Import Process Completed for group : '||r_rec.group_description);

		end if;
	end loop;

	populate_fnd_log (l_debug_flag,'Before Update Standard Cost Process.');

	for l_item_costs in c_item_costs loop

		l_item_cost     := null;
		l_cogs_account	:= null;
		l_upd_msg	:= null;
		ln_request_id   := null;
		l_upd_msg	:= null;

		populate_fnd_log (l_debug_flag,'Item - '|| l_item_costs.item_number);
		populate_fnd_log (l_debug_flag,'Organization - '|| l_item_costs.organization_code);

		if  nvl(l_item_costs.attribute15,'N') <> 'Y' then

			begin
				select material_cost
				into l_item_cost
				from cst_item_costs
				where cost_type_id = l_std_cost_type_id
				and inventory_item_id = l_item_costs.inventory_item_id
				and organization_id = l_item_costs.organization_id;
        --l_item_cost := null;
				if l_item_cost is not null
				then
					l_upd_msg := l_upd_msg||'Msg: Frozen cost for item exists and is '||l_item_cost;
				end if;
			exception
			when no_data_found then
				l_item_cost := null;

			end;

			populate_fnd_log (l_debug_flag,'Std Cost of Item before update: '||l_item_cost);

		/*	-- inventory adjustment account logic change
			begin
				select cost_of_sales_account
				into   l_cogs_account
				from   mtl_system_items_b_kfv
				where  organization_id = l_item_costs.organization_id
				  and  inventory_item_id = l_item_costs.inventory_item_id;
			exception
			when no_data_found then
				l_cogs_account := null;
				l_upd_msg := l_upd_msg||'Err: Inv adj account not found for item';
			end;
		*/
			begin
				select apps.xxha_inv_adj_acct_fnc(l_item_costs.organization_id)
				into   l_cogs_account
				from   dual;

				if nvl(l_cogs_account,-1) = -1 then
					l_upd_msg := l_upd_msg||'Err: Inv adj account not found for item';
				end if;
			exception
			when no_data_found then
			--	l_cogs_account := null;
				l_cogs_account := -1;
				l_upd_msg := l_upd_msg||'Err: Inv adj account not found for item';
			end;


			populate_fnd_log (l_debug_flag,'Inv adj account: '||l_cogs_account);

		--	if l_item_cost is null and l_cogs_account is not null
			if l_item_cost is null and l_cogs_account <> -1
			then
				ln_request_id := FND_REQUEST.SUBMIT_REQUEST('BOM'
									,'CMCICU'
									,'Update Standard Cost from SRS'
									, SYSDATE
									, FALSE
									, l_item_costs.organization_id   -- Organization Id
									, '1'			 	 -- BOM Install flag
									, l_user_cost_type_id 	         -- Cost Type
                  , '1'
									, l_cogs_account 		 -- Adjustment Account
									, l_item_costs.group_description -- Description
									, '2'				-- Item Range
									, '1' 				-- Sort Option
									, '0'				-- Update Option
									, NULL				-- Item dummy
									, NULL				-- Category dummy
									, l_item_costs.inventory_item_id -- Specific Item
									, NULL				-- Category set
									, NULL				-- Category validate flag
									, NULL				-- Category structure
									, NULL				-- Specific Category
									, NULL				-- Item From
									, NULL				-- Item To
									, NULL				-- Resource From
									, NULL				-- Resource To
									, NULL				-- Overhead From
									, NULL				-- Overhead To
									, NULL				-- Run Adjustment Reports
									, NULL				-- Save Details
									);

				populate_fnd_log (l_debug_flag,'Update Standard Cost Process is Submitted.');

				commit;
			end if;

		elsif nvl(l_item_costs.attribute15,'N') = 'Y' then
			l_upd_msg := l_upd_msg||'Msg: Cost update for this cost type is not needed. ';
		end if;

		update xxha_item_cst_dtls_stg
		set status = nvl(l_upd_msg,status),
		    attribute14 = ln_request_id
		where record_id = l_item_costs.record_id;

		commit;
	end loop;

	populate_fnd_log (l_debug_flag,'Updating each cost update program status.');

	for l_rec in c_reqs loop

		l_phase		:= null;
		l_status	:= null;
		l_dev_phase	:= null;
		l_dev_status	:= null;
		l_msg		:= null;
		l_upd_msg	:= null;

		populate_fnd_log (l_debug_flag,'Conc Req id: '||l_rec.attribute14);

		loop
			l_req_status := fnd_concurrent.get_request_status (l_rec.attribute14
								,'BOM'      -- application
								,'CMCICU'   -- program
								,l_phase
								,l_status
								,l_dev_phase
								,l_dev_status
								,l_msg);
			exit when l_dev_phase =  'COMPLETE';
		end loop;

/*		if l_dev_phase <> 'COMPLETE' then

			l_req_status := fnd_concurrent.wait_for_request (l_rec.attribute14
									,60
									,2400
									,l_phase
									,l_status
									,l_dev_phase
									,l_dev_status
									,l_msg);
		end if;

*/		if l_dev_phase = 'COMPLETE'
			and l_dev_status in ('NORMAL','WARNING') then

			populate_fnd_log (l_debug_flag,'Update Standard Cost Process Completed.');

			l_upd_msg := l_upd_msg||'Msg: Item cost updated successfully.';
		else
			populate_fnd_log (l_debug_flag,'Update Standard Cost Process did not complete.'||l_msg);

			l_upd_msg := l_upd_msg||'Err: Item cost did not update successfully.'||l_msg;
		end if;

		update xxha_item_cst_dtls_stg
		   set status = nvl(l_upd_msg,status),
		       attribute14 = null
		where record_id = l_rec.record_id;

		 commit;
	end loop;

	populate_fnd_log (l_debug_flag,'End of Update Standard Cost Process.');

EXCEPTION
WHEN OTHERS THEN
	p_return_msg:= 'Error from exception in process_eco_item_cost'||substr(sqlerrm,1,100);
END process_eco_item_cost;

PROCEDURE INS_ROLLED_ITEM_COST
	( x_errbuf          out  varchar2
        , x_retcode         out  varchar2
    --   , p_inv_org          in  varchar2
	  , p_item             in  varchar2
	  , p_item_cost        in  number
	  , p_flag	     in  varchar2
	)
IS
	l_ret_msg varchar2(2000);
	l_rolling_org number;

	cursor c_inv_orgs
	is
	select organization_code
	 from  org_organization_definitions od
   where exists (select null
                from mtl_system_items_b i
                where i.segment1 = p_item
                and i.organization_id = od.organization_id)
   ;
BEGIN

	fnd_file.put_line(fnd_file.output,'=================================START====================================');
	fnd_file.put_line(fnd_file.output,'==========================================================================');
--	fnd_file.put_line(fnd_file.output,'Program was submitted from Inv Org: '||p_inv_org);
	fnd_file.put_line(fnd_file.output,'Selected Item Number : '||p_item);
	fnd_file.put_line(fnd_file.output,'Entered Item Cost : '||p_item_cost);
	fnd_file.put_line(fnd_file.output,'Inserting rolledup cost for all orgs.');

	for l_rec in c_inv_orgs loop

		INSERT INTO haemo.xxha_item_cst_dtls_stg
		 (  record_id,
		    item_number,
		    organization_code,
		    item_cost,
		    creation_date
		 )
		VALUES
		 (
		   haemo.XXHA_ITEM_CST_DTLS_S.nextval,
		   p_item,
		   l_rec.organization_code,
		   p_item_cost,
		   sysdate
		);

	end loop;

	commit;

	fnd_file.put_line(fnd_file.output,'Inserting rolledup cost for all orgs completed.');
	fnd_file.put_line(fnd_file.output,'process_eco_item_cost submitted from Item rollup conc program.');

	process_eco_item_cost
		(p_debug_flag => p_flag,
		 p_return_msg => l_ret_msg);

	fnd_file.put_line(fnd_file.output, 'Message from Item rollup conc program - process_eco_item_cost: '||l_ret_msg);

	l_ret_msg := null;

	process_eco_item_price_list( p_debug_flag => p_flag, p_return_msg => l_ret_msg );

	fnd_file.put_line(fnd_file.output, 'Message from Item rollup conc program - process_eco_item_price_list: '||l_ret_msg);

	fnd_file.put_line(fnd_file.output,'==================================END=====================================');
	fnd_file.put_line(fnd_file.output,'==========================================================================');

EXCEPTION
WHEN OTHERS THEN
	fnd_file.put_line(fnd_file.output, 'Error while processing rolled up cost for items :'|| substr(sqlerrm,1,100));
END INS_ROLLED_ITEM_COST;

PROCEDURE POPULATE_ITEM_COST
IS

	cursor c_org_item_cost
	is
	select *
	from xxha_item_cst_dtls_stg
	where error_flag <> 'PS'
	and status = 'NEW'
	order by record_id;

	-- VV: added for ver2.1 2012-01-12 (price list)
	cursor c_item
	is
	select distinct item_number, attribute3
	from xxha_item_cst_dtls_stg
	where error_flag <> 'PS'
	and status = 'NEW';

	cursor c_price_list
	is
	select qlhb.list_header_id,
		   qlhb.attribute1,		-- org that the price is based on
		   qlhb.attribute2,		-- an uplift factor for the price
		   qlht.name,
           qlhb.currency_code
	from qp_list_headers_b qlhb,
		 qp_list_headers_tl qlht
	where qlhb.list_header_id = qlht.list_header_id
	and qlht.language = userenv('LANG')
	and qlhb.attribute1 is not null
	and qlhb.attribute2 is not null;
	-- VV: end for ver2.1 2012-01-12 (price list)

	l_res_code	varchar2(10):= 'Material';
	l_cost_element	varchar2(10):= 'Material';
	l_curr_cost_type     varchar2(10);
	l_next_cost_type    varchar2(10);
	l_prev_cost_type    varchar2(10);
	l_other_cost_type    varchar2(10);
	l_usage_rate	number;
	l_fisc_month	number;
	l_fiscal_year   varchar2(10);
	l_service_flag  varchar2(10);
	l_item_sub_type varchar2(10);
	l_prod_type	varchar2(10);
	l_rate		number:=1;
	l_target_code   varchar2(10):='USD';
	l_disp 		varchar2(40):=1;
	l_eqip 		varchar2(40):=1;
	l_serv 		varchar2(40):=1;
	l_sftw 		varchar2(40):=1;
	l_misc 		varchar2(40):=1;
	l_uplift	varchar2(10):=1;
	l_make_code	number:=2;
	l_op_unit 	number := fnd_global.org_id;
	l_count		number;
	l_bom_exists	varchar2(1);
	l_op_exists	varchar2(1);
	l_inv_org_id	number;
	l_item_id	number;

	-- VV: added for ver2.1 2012-01-12 (rounding)
	l_rounding varchar2(40):=5;

	-- VV: added for ver2.1 2012-01-12 (price list)
	l_org_curr varchar2(10);
--	l_org_cost varchar2(2000);
--	l_pl_rec_status varchar2(2000) := 'NEW';
	l_uom varchar2(3);

BEGIN
	for c_rec in c_org_item_cost loop

		l_curr_cost_type    := NULL;
		l_next_cost_type    := NULL;
		l_prev_cost_type    := NULL;
		l_other_cost_type   := NULL;
		l_usage_rate	    := NULL;
		l_fisc_month	    := NULL;
		l_fiscal_year	    := NULL;
		l_service_flag      := 'N';
		l_item_sub_type     := NULL;
		l_prod_type         := NULL;
		l_count		    := '0';
		l_bom_exists        := 'N';
		l_op_exists         := 'N';
		l_inv_org_id        := '0';
		l_item_id	    := '0';

		select period_num,
			to_char(to_date(period_year, 'YYYY'),'YY'),
			to_char(to_date(period_year, 'YYYY'),'YY')-1,
			to_char(to_date(period_year, 'YYYY'),'YY')+1
		 into l_fisc_month, l_fiscal_year, l_prev_cost_type,l_next_cost_type
		 from gl_periods
		where period_set_name = 'HAE_GLOBAL_CAL'
		  and period_type = '21'     -- ver 2.0 added by Vasil 11/3/2011
		  and trunc(c_rec.creation_date) between start_date and nvl(end_date,sysdate);

		l_curr_cost_type  := 'FY'||l_fiscal_year||'PEND';

		if l_fisc_month = '12' then
			l_other_cost_type := 'FY'||l_next_cost_type||'PEND';
		elsif l_fisc_month = '1' then
			l_other_cost_type := 'FY'||l_prev_cost_type||'PEND';
		end if;

		begin
			select attribute7
			into   l_service_flag
			from   mtl_parameters
			where  organization_code = c_rec.organization_code;

			if l_service_flag is null
		        	then l_service_flag := 'N';
		        end if;
     		exception
     		when others then
     			l_service_flag := 'N';
     		end;

     		begin
     			select msb.organization_id, msb.inventory_item_id
     		          into l_inv_org_id, l_item_id
     			  from mtl_system_items_b msb,
     			       mtl_parameters mp
     			 where mp.organization_code = c_rec.organization_code
     			   and msb.organization_id  = mp.organization_id
     			   and msb.segment1 = c_rec.item_number;
     		exception
     		when others
     		  then
     		  	null;
     		end;

		begin
			 select segment3,
			 	segment2
			 into   l_item_sub_type,
			 	l_prod_type
			 from  mtl_item_categories_v a
			 where a.inventory_item_id = l_item_id
			   and a.organization_id = l_inv_org_id
			   and a.category_set_name = 'Inventory';

			   if (l_item_sub_type is null or
			      l_prod_type is null)
			   then
			 	l_prod_type := 'XYZ';
			 	l_item_sub_type := 'XYZ';
			   end if;

		exception
		when others then
			l_prod_type := 'XYZ';
			l_item_sub_type := 'XYZ';
     		end;

		begin
			select sob.currency_code,
			       ood.operating_unit
			  into l_target_code,
			       l_op_unit
			  from org_organization_definitions ood,
			       gl_sets_of_books sob
			 where ood.organization_code = c_rec.organization_code
			   and ood.set_of_books_id = sob.set_of_books_id;

			select conversion_rate
			into   l_rate
			from   apps.gl_daily_rates
			where  conversion_type = 'Corporate'
			and    conversion_date = trunc(c_rec.creation_date)
			and    from_currency = 'USD'
			and    to_currency = l_target_code;

			if l_rate is null
			then
				l_rate := '1';
			end if;
		exception
		when others then
			l_rate := '1';
     		end;

     		begin
			select attribute8,
				 attribute9,
				 attribute10,
				 attribute11,
				 attribute12
			  into   l_disp,
				 l_eqip,
				 l_serv,
				 l_sftw,
				 l_misc
			  from mtl_parameters
			  where organization_code = c_rec.organization_code;

		  	if l_disp is null then
		  	   l_disp := 1;
		  	elsif l_eqip is null then
		  	   l_eqip := 1;
		  	elsif l_serv is null then
		  	   l_serv := 1;
		  	elsif l_sftw is null then
		  	   l_sftw := 1;
		  	elsif l_misc is null then
		  	   l_misc := 1;
     			end if;
     		exception
     		when others
     		then
			l_disp := '1';
			l_eqip := '1';
			l_serv := '1';
			l_sftw := '1';
			l_misc := '1';
     		end;

		begin
			if l_prod_type = 'Disp' then
				l_uplift := l_disp;
			elsif l_prod_type = 'Equi' then
				l_uplift := l_eqip;
			elsif l_prod_type = 'Misc' then
				l_uplift := l_misc;
			elsif l_prod_type = 'Serv' then
				l_uplift := l_serv;
			elsif l_prod_type = 'Sftw' then
				l_uplift := l_sftw;
			else
				l_uplift := 1;
			end if;

		exception
		when others
		then
			l_uplift := 1;
		end;

		/*
		-- not used
		begin
			select 'Y'
			into   l_bom_exists
			from bom_bill_of_materials bom
			where bom.assembly_item_id = l_inv_org_id
			and bom.organization_id = l_inv_org_id;
		exception
		when others then
			l_bom_exists := 'N';
		end;

		-- not used
		begin
			select count(*)
			  into l_count
			  from org_organization_definitions ood ,
			       mtl_system_items_b msb
			 where exists
			 	(select 1
				   from org_organization_definitions ood1
				  where ood1.organization_id = l_inv_org_id
			     	    and ood.operating_unit = ood1.operating_unit)
			   and ood.organization_id = msb.organization_id
			   and msb.inventory_item_id = l_item_id
			   and msb.planning_make_buy_code = 1 ;

			   if l_count > 0 then
			   	l_make_code := '1';
			   end if;
		exception
		when others then
     			l_make_code := '0';
		end;
		*/

		begin
			select 'Y'
			  into l_op_exists
			  from  org_organization_definitions ood,
				hr_operating_units hou
			 where ood.organization_id = l_inv_org_id
			   and ood.operating_unit = hou.organization_id
			   and hou.name = 'Haemonetics Corp US OU';

			   if l_op_exists is null
			   then
			   	l_op_exists := 'N';
			   end if;
		exception
		when others then
			l_op_exists := 'N';
		end;

		if l_service_flag = 'Y' and l_item_sub_type = 'Mach' then
			l_usage_rate := 0;
		else
			-- if l_op_exists = 'Y' then
			if l_target_code = 'USD' then
        -- changed as per request to use uplift for USD also
        -- introduced using of uplift even for USD driven operating unit/org
				--l_usage_rate := c_rec.item_cost * l_rate;
				l_usage_rate := c_rec.item_cost * l_rate * nvl(to_number(l_uplift),1);
			else
				l_usage_rate := c_rec.item_cost * l_rate * l_uplift;
			end if;
		end if;

		-- VV: added for ver2.1 2012-01-12 (rounding)
		begin
			select   attribute14
			  into   l_rounding
			  from mtl_parameters
			  where organization_code = c_rec.organization_code;

			if l_rounding is null
			  then
			    l_rounding := 5;
			end if;
		exception
		when others then
			l_rounding := 5;
		end;

		update xxha_item_cst_dtls_stg
		   set 	cost_type = l_curr_cost_type,
			cost_element = l_cost_element,
			resource_code = l_res_code,
			usage_rate_or_amount = round(l_usage_rate, l_rounding) -- VV: added for ver2.1 2012-01-12 (round)
		--	group_id = record_id,
		--	group_description = 'COSTUPDATE-GROUPID:'||record_id
		 where record_id = c_rec.record_id;

		 if l_other_cost_type is not null then
			INSERT INTO haemo.xxha_item_cst_dtls_stg
			 (  record_id,
			    item_number,
			    organization_code,
			    item_cost,
			    creation_date,
			    cost_type,
			    cost_element,
			    resource_code,
			    usage_rate_or_amount,
			    attribute3,
			    attribute15
			 )
			VALUES
			 (
			   haemo.XXHA_ITEM_CST_DTLS_S.nextval,
			   c_rec.item_number,
			   c_rec.organization_code,
			   c_rec.item_cost,
			   sysdate,
			   l_other_cost_type,
			   l_cost_element,
			   l_res_code,
			   round(l_usage_rate, l_rounding), -- VV: added for ver2.1 2012-01-12 (round)
			   c_rec.attribute3,
			   'Y'
			);
		 end if;

		commit;
	end loop;	-- end c_org_item_cost loop

	-- VV: added for ver2.1 2012-01-12 (price list)
	for c_rec_item in c_item loop

		l_item_id := null;
		l_uom := null;

		begin
     		select inventory_item_id, primary_uom_code
     		    into l_item_id, l_uom
     		from mtl_system_items_b
     		where organization_id = 103
			and segment1 = c_rec_item.item_number;
     	exception
     	when others
     	  then
     	  	null;
     	end;

		for c_rec_pl in c_price_list loop

			l_inv_org_id := null;
			l_org_curr := null;

			begin

				select sob.currency_code, ood.organization_id
					into l_org_curr, l_inv_org_id
				from org_organization_definitions ood,
			         gl_sets_of_books sob
				where ood.organization_code = c_rec_pl.attribute1
				and ood.set_of_books_id = sob.set_of_books_id;

			exception
			when others
			then
				null;
			end;

			insert into haemo.xxha_item_price_list_stg
			(  	inventory_item_id,
				item_number,
				unit_of_measure,
				org_id,
				assoc_org,
				org_curr,
				pl_curr,
				uplift,
				list_header_id,
				price_list,
				eco_number,
				error_flag,
				status
			)
			values
			(  	l_item_id,
				c_rec_item.item_number,
				l_uom,
				l_inv_org_id,
				c_rec_pl.attribute1,
				l_org_curr,
				c_rec_pl.currency_code,
				c_rec_pl.attribute2,
				c_rec_pl.list_header_id,
				c_rec_pl.name,
				c_rec_item.attribute3,
				'NEW',
				'NEW'
			);

			insert into haemo.xxha_item_price_list_stg_log
			(  	inventory_item_id,
				item_number,
				unit_of_measure,
				org_id,
				assoc_org,
				org_curr,
				pl_curr,
				uplift,
				list_header_id,
				price_list,
				eco_number,
				error_flag,
				status
			)
			values
			(  	l_item_id,
				c_rec_item.item_number,
				l_uom,
				l_inv_org_id,
				c_rec_pl.attribute1,
				l_org_curr,
				c_rec_pl.currency_code,
				c_rec_pl.attribute2,
				c_rec_pl.list_header_id,
				c_rec_pl.name,
				c_rec_item.attribute3,
				'NEW',
				'NEW'
			);
			commit;
		end loop; -- end c_price_list loop
	end loop; -- end c_item loop
	-- VV: end for ver2.1 2012-01-12 (price list)

EXCEPTION
WHEN OTHERS THEN
	fnd_file.put_line(fnd_file.output, 'Error while processing POPULATE_ITEM_COST :' ||substr(sqlerrm,1,100));
END POPULATE_ITEM_COST;

-- VV: added for ver2.1 2012-01-12 (price list)
PROCEDURE process_eco_item_price_list(  p_debug_flag  in varchar2, p_return_msg out varchar2 )
IS

cursor c_item_price_list
	is
	select *
	from xxha_item_price_list_stg
	where error_flag <> 'PS'
	and status = 'NEW'
	order by record_id;

	l_return_msg varchar2(2000);
	l_price varchar2(2000);
	l_rate number := 1;
	l_org_cost varchar2(2000);
	l_pl_rec_status varchar2(2000);
	l_error_flag varchar2(2000);


BEGIN

	for c_rec_item_pl in c_item_price_list loop

		l_price := null;
		l_rate := 1;
		l_org_cost := null;

		begin
			select item_cost
					into l_org_cost
				from cst_item_cost_type_v
				where cost_type = 'Frozen'
				and inventory_item_id = c_rec_item_pl.inventory_item_id
				and organization_id = c_rec_item_pl.org_id;


		exception
		when others then
			null;
		end;

		if l_org_cost is null then
			l_pl_rec_status := 'No cost for item ' || c_rec_item_pl.item_number || ' in ' || c_rec_item_pl.assoc_org;
			l_error_flag := 'PS';
/*
			update haemo.xxha_item_price_list_stg
			set status = l_pl_rec_status, error_flag = 'PS'
			where record_id = c_rec_item_pl.record_id;
			commit;
*/
		else
			l_price := (l_org_cost * c_rec_item_pl.uplift);

			if c_rec_item_pl.org_curr != c_rec_item_pl.pl_curr then

				begin
					select conversion_rate
						into l_rate
					from apps.gl_daily_rates
					where conversion_type = 'Corporate'
					and conversion_date = trunc(c_rec_item_pl.creation_date)
					and from_currency = c_rec_item_pl.org_curr
					and to_currency = c_rec_item_pl.pl_curr;
				exception
				when others	then
					null;
				end;

				l_price := (l_price * l_rate);
			end if;

			l_error_flag := c_rec_item_pl.error_flag;
			l_pl_rec_status := c_rec_item_pl.status;

		end if;

		update haemo.xxha_item_price_list_stg
		   set 	price = l_price, org_cost = l_org_cost, status = l_pl_rec_status, error_flag = l_error_flag
		 where record_id = c_rec_item_pl.record_id;

		commit;

-- BMarcoux - 2012/12/21 - Replaced stringing of the data into one message with a single message being written out for each update/commit
		-- l_return_msg := l_return_msg || chr(10) || chr(9) || l_pl_rec_status;	-- chr(10)=new line; chr(9)=tab
    fnd_file.put_line(fnd_file.output, chr(9) || l_pl_rec_status);

	end loop; -- end c_item_price_list loop

	populate_price_lists;

-- BMarcoux - 2012/12/21 - No longer a need to update 'p_return_msg' with 'l_return_msg'
	--p_return_msg := l_return_msg;
  EXCEPTION
  WHEN OTHERS THEN
	  p_return_msg:= 'Error from exception in process_eco_item_price_list'||substr(sqlerrm,1,100);

END process_eco_item_price_list;

procedure populate_price_lists
is
	lc_price_list_rec            QP_Price_List_PUB.Price_List_Rec_Type           :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_REC;
	lc_price_list_val_rec        QP_Price_List_PUB.Price_List_Val_Rec_Type       :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_VAL_REC;
	lc_price_list_line_tbl       QP_Price_List_PUB.Price_List_Line_Tbl_Type      :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_TBL;
	lc_price_list_line_val_tbl   QP_Price_List_PUB.Price_List_Line_Val_Tbl_Type  :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
	lc_qualifiers_tbl            Qp_Qualifier_Rules_Pub.Qualifiers_Tbl_Type      :=  Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_TBL;
	lc_qualifiers_val_tbl        Qp_Qualifier_Rules_Pub.Qualifiers_Val_Tbl_Type  :=  Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_VAL_TBL;
	lc_pricing_attr_tbl          QP_Price_List_PUB.Pricing_Attr_Tbl_Type         :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_TBL;
	lc_pricing_attr_val_tbl      QP_Price_List_PUB.Pricing_Attr_Val_Tbl_Type     :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_VAL_TBL;

	lc_data                      VARCHAR2(2000);
	ln_count                     NUMBER;
	lc_status                    VARCHAR2(1000);
	ln_line_index                NUMBER := 0;
	lc_api_mst_err_flag          VARCHAR2(1) := 'N';
	lc_debug_file                VARCHAR2(200);
	lc_item_process_mode         VARCHAR2(20);
	ln_list_line_id              NUMBER;
	ln_pricing_attribute_id      NUMBER;
	ln_Start_Date_Active         DATE;

	l_sts_notes varchar2(1000);

	-- Cursor to get all the price list data from the staging table
	CURSOR l_price_list
	IS
	select *
	from xxha_item_price_list_stg
	where error_flag <> 'PS'
	and status = 'NEW'
	order by record_id;

	-- Cursor to check if item exists and it's active in price list
	CURSOR l_chk_price_list_lines( p_header_id NUMBER, p_item_id NUMBER, p_Start_Date_Active DATE )
	IS
	SELECT
		  A.list_line_id
		, b.pricing_attribute_id
		, a.Start_Date_Active
	FROM
		  qp_list_lines          A
		, qp_pricing_attributes  B
	WHERE
		 A.list_line_id       = B.list_line_id
	AND  A.list_header_id     = p_header_id
	AND  product_attr_value   = p_item_id
	and trunc(sysdate) between trunc(p_Start_Date_Active) and trunc(nvl(a.end_date_active, trunc(sysdate)));

BEGIN

	-- Process the records
	FOR l_price_list_rec IN l_price_list LOOP

		lc_status := null;
		lc_item_process_mode := null;
		l_sts_notes := null;

		lc_price_list_line_tbl :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_TBL;
      	lc_pricing_attr_tbl :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_TBL;

		-- Check if Price Line with the item exists in Oracle Tables
		OPEN l_chk_price_list_lines( l_price_list_rec.list_header_id, l_price_list_rec.inventory_item_id, TO_DATE(l_price_list_rec.creation_date,'YYYY-MM-DD' ) );
			FETCH l_chk_price_list_lines
				INTO ln_list_line_id, ln_pricing_attribute_id, ln_Start_Date_Active;
					IF l_chk_price_list_lines%NOTFOUND THEN
						lc_item_process_mode := 'C'; --Create Lines
					ELSE
						l_sts_notes := 'Item Exists in price list->' || l_price_list_rec.price_list;
					END IF;
		CLOSE l_chk_price_list_lines;

		-- Set Line Index to 1
		ln_line_index := 1;

		-- CREATE PRICE LIST LINES
		IF lc_item_process_mode = 'C' THEN

			------------------------------------
			--Assign price list Line information
			------------------------------------
			lc_price_list_line_tbl(ln_line_index).list_header_id          := l_price_list_rec.list_header_id;
			lc_price_list_line_tbl(ln_line_index).Arithmetic_operator     := 'UNIT_PRICE';
			lc_price_list_line_tbl(ln_line_index).created_by              := fnd_global.user_id;
			lc_price_list_line_tbl(ln_line_index).creation_date           := SYSDATE;
			lc_price_list_line_tbl(ln_line_index).last_updated_by         := fnd_global.user_id;
			lc_price_list_line_tbl(ln_line_index).last_update_date        := SYSDATE;
			lc_price_list_line_tbl(ln_line_index).last_update_login       := fnd_global.user_id;
			lc_price_list_line_tbl(ln_line_index).list_line_id            := FND_API.G_MISS_NUM;
			lc_price_list_line_tbl(ln_line_index).list_line_type_code     := gc_line_type_code;
			lc_price_list_line_tbl(ln_line_index).operation               := QP_GLOBALS.G_OPR_CREATE;
			lc_price_list_line_tbl(ln_line_index).product_precedence      := 220;
			lc_price_list_line_tbl(ln_line_index).Operand                 := l_price_list_rec.price;

			lc_price_list_line_tbl(ln_line_index).start_date_active       := l_price_list_rec.creation_date;
			lc_price_list_line_tbl(ln_line_index).end_date_active         := null;

			------------------------------------
			--Assign price attribute information
			------------------------------------
			lc_pricing_attr_tbl(ln_line_index).list_header_id             := l_price_list_rec.list_header_id;
			lc_pricing_attr_tbl(ln_line_index).attribute_grouping_no      := 1;
			lc_pricing_attr_tbl(ln_line_index).created_by                 := fnd_global.user_id;
			lc_pricing_attr_tbl(ln_line_index).creation_date              := SYSDATE;
			lc_pricing_attr_tbl(ln_line_index).excluder_flag              := 'N';
			lc_pricing_attr_tbl(ln_line_index).last_updated_by            := fnd_global.user_id;
			lc_pricing_attr_tbl(ln_line_index).last_update_date           := SYSDATE;
			lc_pricing_attr_tbl(ln_line_index).last_update_login          := fnd_global.user_id;
			lc_pricing_attr_tbl(ln_line_index).List_line_id               := FND_API.G_MISS_NUM;
			lc_pricing_attr_tbl(ln_line_index).pricing_attribute_id       := FND_API.G_MISS_NUM;
			lc_pricing_attr_tbl(ln_line_index).product_attribute          := gc_prc_attribute;
			lc_pricing_attr_tbl(ln_line_index).product_attribute_context  := gc_prc_context_code;
			lc_pricing_attr_tbl(ln_line_index).product_attr_value         := l_price_list_rec.inventory_item_id;
			lc_pricing_attr_tbl(ln_line_index).product_uom_code           := l_price_list_rec.unit_of_measure;
			lc_pricing_attr_tbl(ln_line_index).price_list_line_index      := ln_line_index;
			lc_pricing_attr_tbl(ln_line_index).operation                  := Qp_Globals.G_OPR_CREATE;

			BEGIN
				-- Call the standard API
				fnd_msg_pub.initialize;
				lc_debug_file := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
				oe_debug_pub.initialize;
				oe_debug_pub.setdebuglevel(5);
				Oe_Msg_Pub.initialize;

				QP_Price_List_PUB.Process_Price_List(
					  p_api_version_number            => 1.0
					, p_init_msg_list                 => FND_API.G_FALSE
					, p_return_values                 => FND_API.G_FALSE
					, p_commit                        => FND_API.G_FALSE
					, x_return_status                 => lc_status
					, x_msg_count                     => ln_count
					, x_msg_data                      => lc_data
					, p_price_list_rec                => lc_price_list_rec
					, p_price_list_val_rec            => lc_price_list_val_rec
					, p_price_list_line_tbl           => lc_price_list_line_tbl
					, p_price_list_line_val_tbl       => lc_price_list_line_val_tbl
					, p_qualifiers_tbl                => lc_qualifiers_tbl
					, p_qualifiers_val_tbl            => lc_qualifiers_val_tbl
					, p_pricing_attr_tbl              => lc_pricing_attr_tbl
					, p_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
					, x_price_list_rec                => lc_price_list_rec
					, x_price_list_val_rec            => lc_price_list_val_rec
					, x_price_list_line_tbl           => lc_price_list_line_tbl
					, x_price_list_line_val_tbl       => lc_price_list_line_val_tbl
					, x_qualifiers_tbl                => lc_qualifiers_tbl
					, x_qualifiers_val_tbl            => lc_qualifiers_val_tbl
					, x_pricing_attr_tbl              => lc_pricing_attr_tbl
					, x_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
				);

				dbms_output.put_line( 'Item: ' || l_price_list_rec.item_number );
				dbms_output.put_line( 'Price List: ' || l_price_list_rec.price_list );
				dbms_output.put_line( 'Line Index: ' || ln_line_index );
				dbms_output.put_line( 'Error message: ' || lc_data );

				IF lc_price_list_line_tbl.count > 0 THEN
					FOR k in 1 .. lc_price_list_line_tbl.count LOOP
						dbms_output.put_line('Record = '|| k ||'Return Status = '|| lc_price_list_line_tbl(k).return_status);
					END LOOP;
				END IF;

				IF (lc_status <> FND_API.G_RET_STS_SUCCESS) THEN
					lc_api_mst_err_flag := 'Y';
					RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
				END IF;
				EXCEPTION WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
					FOR I IN 1 .. ln_count LOOP
						lc_data := oe_msg_pub.get(
							  p_msg_index => 1
							, p_encoded   => 'F'
						);
						FND_FILE.PUT_LINE( FND_FILE.LOG, 'Error when adding item# ' || l_price_list_rec.item_number || ' to price list ' || l_price_list_rec.price_list || chr(10) || chr(9) );
						FND_FILE.PUT_LINE( FND_FILE.LOG, lc_data );
					END LOOP;
				WHEN OTHERS THEN
					-- Log error
					FND_FILE.PUT_LINE(FND_FILE.LOG,'Unexpected error encountered when calling the API '||SQLERRM);
					dbms_output.put_line( 'Unexpected error encountered when calling the API '||SQLERRM );
					RAISE;
				end;

        if( lc_status not in ( 'E', 'U' ) ) THEN
					l_sts_notes := 'Item added to price list.' || l_price_list_rec.price_list;
				else
					l_sts_notes := lc_data;
        end if;

    end if; -- end lc_item_process_mode='C'

		IF( lc_api_mst_err_flag <>'N' ) THEN
			ROLLBACK;	-- if one price list failed, rollback everything
		ELSE
			COMMIT;	-- commit item to all price lists
		END IF;

		update haemo.xxha_item_price_list_stg
		set error_flag = 'PS', status = l_sts_notes
		where record_id = l_price_list_rec.record_id;
		commit;

	END LOOP; -- End of main loop

END populate_price_lists;

PROCEDURE add_exist_item_price_list
			(
			  x_errbuf out varchar2
			, x_retcode out varchar2
			, p_item in varchar2
			, p_flag in  varchar2
			)
IS
	l_ret_msg varchar2(2000);
	l_rolling_org number;
	l_item_id number;
	l_uom varchar2(3);
	l_inv_org_id number;
	l_org_curr varchar2(10);


	CURSOR l_chk_price_list_lines
	is
	select qlhb.list_header_id,
		   qlhb.attribute1,
		   qlhb.attribute2,
		   qlht.name,
		   qlhb.currency_code
	from qp_list_headers_b qlhb,
		 qp_list_headers_tl qlht
	where qlhb.list_header_id = qlht.list_header_id
	and qlht.language = userenv('LANG')
	and qlhb.attribute1 is not null
	and qlhb.attribute2 is not null
	and not exists (select null from qp_list_lines qll, qp_pricing_attributes qpa where qll.list_line_id = qpa.list_line_id
    and qlhb.list_header_id = qll.list_header_id and trunc(sysdate) between trunc(qll.start_date_active) and trunc(nvl(qll.end_date_active, trunc(sysdate)))
    and qpa.product_attr_value = l_item_id);

BEGIN

	begin
		select inventory_item_id, primary_uom_code
			into l_item_id, l_uom
		from mtl_system_items_b
		where organization_id = 103
		and segment1 = p_item;
    exception
    when others then
      	null;
    end;

	fnd_file.put_line(fnd_file.output,'=================================START====================================');
	fnd_file.put_line(fnd_file.output,'==========================================================================');
	fnd_file.put_line(fnd_file.output,'Selected Item Number : ' || p_item);
	fnd_file.put_line(fnd_file.output,'Inserting price into price lists.');

	for l_pl_rec in l_chk_price_list_lines loop

		l_inv_org_id := null;
		l_org_curr := null;

		begin
			select sob.currency_code, ood.organization_id
			  into l_org_curr, l_inv_org_id
			from org_organization_definitions ood,
		         gl_sets_of_books sob
			where ood.organization_code = l_pl_rec.attribute1
			and ood.set_of_books_id = sob.set_of_books_id;

			exception
			when others
			then
				null;
			end;

		insert into haemo.xxha_item_price_list_stg
		(  	inventory_item_id,
			item_number,
			unit_of_measure,
			org_id,
			assoc_org,
			org_curr,
			pl_curr,
			uplift,
			list_header_id,
			price_list,
			eco_number,
			error_flag,
			status
		)
		values
		(  	l_item_id,
			p_item,
			l_uom,
			l_inv_org_id,
			l_pl_rec.attribute1,
			l_org_curr,
			l_pl_rec.currency_code,
			l_pl_rec.attribute2,
			l_pl_rec.list_header_id,
			l_pl_rec.name,
			null,
			'NEW',
			'NEW'
		);

		insert into haemo.xxha_item_price_list_stg_log
		(  	inventory_item_id,
			item_number,
			unit_of_measure,
			org_id,
			assoc_org,
			org_curr,
			pl_curr,
			uplift,
			list_header_id,
			price_list,
			eco_number,
			error_flag,
			status
		)
		values
		(  	l_item_id,
			p_item,
			l_uom,
			l_inv_org_id,
			l_pl_rec.attribute1,
			l_org_curr,
			l_pl_rec.currency_code,
			l_pl_rec.attribute2,
			l_pl_rec.list_header_id,
			l_pl_rec.name,
			null,
			'NEW',
			'NEW'
		);
	end loop;

	commit;

-- BMarcoux - 2012/12/21 - Moved output line to here
	fnd_file.put_line(fnd_file.output, 'Messages from concurrent program: ');
	process_eco_item_price_list( p_debug_flag => p_flag, p_return_msg => l_ret_msg );

-- BMarcoux - 2012/12/21 - Check 'l_ret_msg' for a value, if one exists then report it
	IF l_ret_msg <> NULL THEN
       fnd_file.put_line(fnd_file.output, 'Error Message from concurrent program: ' || l_ret_msg);
	END IF;

	fnd_file.put_line(fnd_file.output,'==================================END=====================================');
	fnd_file.put_line(fnd_file.output,'==========================================================================');

EXCEPTION
WHEN OTHERS THEN
	fnd_file.put_line(fnd_file.output, 'Error while adding item to price list:'|| substr(sqlerrm,1,100));
END add_exist_item_price_list;


END XXHA_ECO_PROCESS_ECO;
/
