CREATE OR REPLACE
PACKAGE XXHA_EFFECTIVE_END_DATE_PKG AUTHID CURRENT_USER AS

/************************************************************************************************************************
* Package Name : XXHA_EFFECTIVE_END_DATE_PKG                                                                            *
* Purpose      : This package provides a function to retrieve the latest Effective End Date from PER_ALL_ASSIGNMENTS_F  *
*                  and PER_ALL_PEOPLE_F.                                                                                *
*                This package will be used by the View 'XXHA_IDM_RECON_V'.                                              *
*                                                                                                                       *
* Functions    : ASSIGNMENT                                                                                             *
* Functions    : PEOPLE                                                                                                 *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
* - PER_ALL_ASSIGNMENTS_F     S                                                                                         *
* - PER_ALL_PEOPLE_F          S                                                                                         *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        11-JAN-2016     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

--------------------------------------------------------------------------------
-- FUNCTION ASSIGNMENT

FUNCTION ASSIGNMENT(
         p_PERSON_ID     IN PER_ALL_ASSIGNMENTS_F.PERSON_ID%TYPE)
         RETURN DATE;

--------------------------------------------------------------------------------
-- FUNCTION PEOPLE

FUNCTION PEOPLE(
         p_PERSON_ID     IN PER_ALL_PEOPLE_F.PERSON_ID%TYPE)
         RETURN DATE;

END XXHA_EFFECTIVE_END_DATE_PKG;