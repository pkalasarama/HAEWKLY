CREATE OR REPLACE package XXHA_ST_CONTACT AS
/*********************************************************************************************
* Package Name : XXHA_ST_CONTACT                                                             *
* Purpose      : This package provides functions to retrieve ShipTo Contact Information.     *
*                                                                                            *
* Used By      : XXHA: Sales Order Acknowledgment Report XX                                  *
*              : XXHA: Pick Slip Report XX                                                   *
*                                                                                            *
* PROCEDURES   : XXHA_GET_CONTACT_NAME                                                       *
*              : XXHA_GET_PHONE_NUMBER                                                       *
*              : XXHA_GET_FAX_NUMBER                                                         *
*              : XXHA_GET_ORDLNE_CONTACT_ID                                                  *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*   AR_CONTACTS_V            S                                                               *
*   HZ_ORG_CONTACTS          S                                                               *
*   HZ_RELATIONSHIPS         S                                                               *
*   HZ_CONTACT_POINTS        S                                                               *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        09-MAR-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
* 2.0        04-MAY-2012     B. Marcoux           Added processing for retrieving FAX#.      *
*                                                 Added Procedure XXHA_GET_ORDLNE_CONTACT_ID *
*                                                                                            *
*********************************************************************************************/

PROCEDURE XXHA_GET_CONTACT_NAME(
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Data               OUT VARCHAR2
                          );

PROCEDURE XXHA_GET_PHONE_NUMBER(
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                          );

PROCEDURE XXHA_GET_FAX_NUMBER(
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                          );

PROCEDURE XXHA_GET_ORDLNE_CONTACT_ID(
                           p_Pick_Slip_Number  IN  NUMBER
                        ,  p_Organization_ID   IN  NUMBER
                        ,  p_Ship_To_Org_ID    IN  NUMBER
                        ,  p_Count             IN  NUMBER
                        ,  p_Data              OUT NUMBER
                        );

END XXHA_ST_CONTACT;
/


CREATE OR REPLACE package BODY XXHA_ST_CONTACT IS
/*********************************************************************************************
* Package Name : XXHA_ST_CONTACT                                                             *
* Purpose      : This package provides functions to retrieve ShipTo Contact Information.     *
*                                                                                            *
* Used By      : XXHA: Sales Order Acknowledgment Report XX                                  *
*                                                                                            *
* PROCEDURES   : XXHA_GET_CONTACT_NAME                                                       *
*              : XXHA_GET_PHONE_NUMBER                                                       *
*              : XXHA_GET_FAX_NUMBER                                                         *
*              : XXHA_GET_ORDLNE_CONTACT_ID                                                  *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*   AR_CONTACTS_V            S                                                               *
*   HZ_ORG_CONTACTS          S                                                               *
*   HZ_RELATIONSHIPS         S                                                               *
*   HZ_CONTACT_POINTS        S                                                               *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        09-MAR-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
* 2.0        04-MAY-2012     B. Marcoux           Added processing for retrieving FAX#.      *
*                                                 Added Procedure XXHA_GET_ORDLNE_CONTACT_ID *
*                                                                                            *
*********************************************************************************************/

--------------------------------------------------------------------------------
-- Retrieve Customer Contact Name
PROCEDURE XXHA_GET_CONTACT_NAME
                        (
                           p_Contact_Id        IN  NUMBER
                        ,  p_Count             IN  NUMBER
                        ,  p_Data              OUT VARCHAR2
                        )  IS

l_loop_count   NUMBER        := 0;
l_data         VARCHAR2(240) := NULL;

   CURSOR contact_cursor IS
   SELECT
        DECODE(cn.First_Name, NULL, cn.Last_Name, cn.First_Name || ' ' || cn.Last_Name)
   FROM
        AR_CONTACTS_V                 cn
   WHERE
        cn.Contact_Id                 = p_Contact_Id;

BEGIN

  OPEN  contact_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contact_cursor INTO l_data;
              IF contact_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contact_cursor%NOTFOUND THEN
                 l_data := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;           
        END LOOP;

  CLOSE contact_cursor;

  p_Data := l_data;

END;

--------------------------------------------------------------------------------
-- Retrieve Customer Contact Phone Numbers
PROCEDURE XXHA_GET_PHONE_NUMBER
                        (
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                        )  IS

l_loop_count            NUMBER                                      := 0;
l_Phone_Country_Code    HZ_CONTACT_POINTS.PHONE_COUNTRY_CODE%TYPE   := NULL;
l_Phone_Area_Code       HZ_CONTACT_POINTS.PHONE_AREA_CODE%TYPE      := NULL;
l_Phone_Number          HZ_CONTACT_POINTS.PHONE_NUMBER%TYPE         := NULL;
l_Phone_Extension       HZ_CONTACT_POINTS.PHONE_EXTENSION%TYPE      := NULL;

   CURSOR contact_cursor IS
   SELECT
        hzp.Phone_Country_Code
   ,    hzp.Phone_Area_Code
   ,    hzp.Phone_Number
   ,    hzp.Phone_Extension
   FROM
        AR_CONTACTS_V                 cn
   ,    HZ_ORG_CONTACTS               hzc
   ,    HZ_RELATIONSHIPS              hzr
   ,    HZ_CONTACT_POINTS             hzp
   WHERE
        cn.Contact_ID               = p_Contact_Id
   AND  cn.Contact_Number           = hzc.Contact_Number
   AND  hzc.Party_Relationship_Id   = hzr.Relationship_Id
   AND  hzr.Directional_Flag        = 'F'
   AND  hzr.Object_Table_Name (+)   = 'HZ_PARTIES' 
   AND  hzr.Subject_Table_Name (+)	= 'HZ_PARTIES' 
   AND  hzr.Party_Id                =  hzp.Owner_Table_Id
   AND  hzp.Owner_Table_Name (+)    = 'HZ_PARTIES'
   AND  hzp.Contact_Point_Type	    = 'PHONE'
   AND  hzp.Phone_Line_Type	        <> 'FAX'
   AND  hzp.Status	              	= 'A'
   ORDER BY
      hzp.primary_flag desc
   ,  hzp.contact_point_id;

BEGIN

  OPEN  contact_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contact_cursor 
            INTO l_Phone_Country_Code
               , l_Phone_Area_Code
               , l_Phone_Number
               , l_Phone_Extension;
              IF contact_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contact_cursor%NOTFOUND THEN
                 l_Phone_Country_Code := NULL;
                 l_Phone_Area_Code    := NULL;
                 l_Phone_Number       := NULL;
                 l_Phone_Extension    := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;
        END LOOP;

  CLOSE contact_cursor;

  p_Phone_Country_Code := l_Phone_Country_Code;
  p_Phone_Area_Code    := l_Phone_Area_Code;
  p_Phone_Number       := l_Phone_Number;
  p_Phone_Extension    := l_Phone_Extension;

END;

--------------------------------------------------------------------------------
-- Retrieve Customer Contact Fax Number
PROCEDURE XXHA_GET_FAX_NUMBER
                        (
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                        )  IS

l_loop_count            NUMBER                                      := 0;
l_Phone_Country_Code    HZ_CONTACT_POINTS.PHONE_COUNTRY_CODE%TYPE   := NULL;
l_Phone_Area_Code       HZ_CONTACT_POINTS.PHONE_AREA_CODE%TYPE      := NULL;
l_Phone_Number          HZ_CONTACT_POINTS.PHONE_NUMBER%TYPE         := NULL;
l_Phone_Extension       HZ_CONTACT_POINTS.PHONE_EXTENSION%TYPE      := NULL;

   CURSOR contact_cursor IS
   SELECT
        hzp.Phone_Country_Code
   ,    hzp.Phone_Area_Code
   ,    hzp.Phone_Number
   ,    hzp.Phone_Extension
   FROM
        AR_CONTACTS_V                 cn
   ,    HZ_ORG_CONTACTS               hzc
   ,    HZ_RELATIONSHIPS              hzr
   ,    HZ_CONTACT_POINTS             hzp
   WHERE
        cn.Contact_ID               = p_Contact_Id
   AND  cn.Contact_Number           = hzc.Contact_Number
   AND  hzc.Party_Relationship_Id   = hzr.Relationship_Id
   AND  hzr.Directional_Flag        = 'F'
   AND  hzr.Object_Table_Name (+)   = 'HZ_PARTIES' 
   AND  hzr.Subject_Table_Name (+)	= 'HZ_PARTIES' 
   AND  hzr.Party_Id                =  hzp.Owner_Table_Id
   AND  hzp.Owner_Table_Name (+)    = 'HZ_PARTIES'
   AND  hzp.Contact_Point_Type	    = 'PHONE'
   AND  hzp.Phone_Line_Type	        = 'FAX'
   AND  hzp.Status	              	= 'A'
   ORDER BY
      hzp.primary_flag desc
   ,  hzp.contact_point_id;

BEGIN

  OPEN  contact_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contact_cursor 
            INTO l_Phone_Country_Code
               , l_Phone_Area_Code
               , l_Phone_Number
               , l_Phone_Extension;
              IF contact_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contact_cursor%NOTFOUND THEN
                 l_Phone_Country_Code := NULL;
                 l_Phone_Area_Code    := NULL;
                 l_Phone_Number       := NULL;
                 l_Phone_Extension    := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;
        END LOOP;

  CLOSE contact_cursor;

  p_Phone_Country_Code := l_Phone_Country_Code;
  p_Phone_Area_Code    := l_Phone_Area_Code;
  p_Phone_Number       := l_Phone_Number;
  p_Phone_Extension    := l_Phone_Extension;

END;

--------------------------------------------------------------------------------
-- Retrieve Order Line Customer Contact ID
PROCEDURE XXHA_GET_ORDLNE_CONTACT_ID
                        (
                           p_Pick_Slip_Number  IN  NUMBER
                        ,  p_Organization_ID   IN  NUMBER
                        ,  p_Ship_To_Org_ID    IN  NUMBER
                        ,  p_Count             IN  NUMBER
                        ,  p_Data              OUT NUMBER
                        )  IS

l_loop_count   NUMBER        := 0;
l_data         NUMBER        := NULL;
l_lnnbr        NUMBER        := NULL;

   CURSOR contactid_cursor IS

   SELECT DISTINCT
         oola.SHIP_TO_CONTACT_ID
   	   , oola.line_number
   FROM
         wsh_pick_slip_v                    wpsv,
         mtl_system_items_vl                msi,
         wsh_delivery_details               wdd,
         mtl_txn_request_lines              mtrl,
         mtl_txn_request_headers            mtrh,
         wsh_delivery_assignments           wda,
         wsh_new_deliveries                 wnd,
         oe_order_lines_all                 oola
   WHERE 
         wpsv.pick_slip_number            = p_Pick_Slip_Number
     AND mtrl.organization_id             = p_Organization_ID 
     AND wpsv.line_status                 = 'PICKED'
     AND wpsv.move_order_line_id          = mtrl.line_id
     AND mtrl.header_id                   = mtrh.header_id
     AND mtrl.line_id                     = wdd.move_order_line_id  
     AND nvl(wpsv.transaction_id,-99)     = decode(nvl(wdd.transaction_id ,-99),-99,nvl(wpsv.transaction_id,-99),wdd.transaction_id)
     AND wdd.inventory_item_id            = msi.inventory_item_id(+)
     AND wdd.organization_id              = msi.organization_id(+)
     AND wdd.delivery_detail_id           = wda.delivery_detail_id
     AND wda.delivery_id                  = wnd.delivery_id(+)
     AND wdd.source_header_id             = oola.header_id
     AND oola.SHIP_TO_CONTACT_ID          IS NOT NULL
     AND oola.ship_to_org_id              = p_Ship_To_Org_ID
     AND wdd.source_code                  = 'OE'
     AND wdd.released_status              != 'S'

   UNION ALL

   SELECT DISTINCT
         oola.SHIP_TO_CONTACT_ID
   	   , oola.line_number
   FROM
         wsh_pick_slip_v                    wpsv,
         mtl_system_items_vl                msi,
         wsh_delivery_details               wdd,
         mtl_txn_request_lines              mtrl,
         mtl_txn_request_headers            mtrh,
         wsh_delivery_assignments           wda,
         wsh_new_deliveries                 wnd,
         oe_order_lines_all                 oola
   WHERE 
         wpsv.pick_slip_number            = p_Pick_Slip_Number
     AND mtrl.organization_id             = p_Organization_ID 
     AND wpsv.line_status                 = 'UNPICKED'
     AND wpsv.move_order_line_id          = mtrl.line_id
     AND mtrl.header_id                   = mtrh.header_id
     AND mtrl.line_id                     = wdd.move_order_line_id
     AND wdd.inventory_item_id            = msi.inventory_item_id(+)
     AND wdd.organization_id              = msi.organization_id(+)
     AND wdd.delivery_detail_id           = wda.delivery_detail_id
     AND wda.delivery_id                  = wnd.delivery_id(+)
     AND wdd.source_header_id             = oola.header_id
     AND oola.SHIP_TO_CONTACT_ID          IS NOT NULL
     AND oola.ship_to_org_id              = p_Ship_To_Org_ID  --14512
     AND wdd.released_status              = 'S'
     AND wdd.source_code                  = 'OE'
   ORDER BY
      2;

BEGIN

  OPEN  contactid_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contactid_cursor INTO l_data, l_lnnbr;
              IF contactid_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contactid_cursor%NOTFOUND THEN
                 l_data := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;           
        END LOOP;

  CLOSE contactid_cursor;

  p_Data := l_data;

END;

END XXHA_ST_CONTACT;
/
