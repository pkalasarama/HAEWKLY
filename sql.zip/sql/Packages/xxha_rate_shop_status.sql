create or replace PACKAGE      xxha_rate_shop_status
AS
/**********************************************************************************************************************************
*
* Package:      xxha_rate_shop_status
* Description:   Assigned to Validation Templates in Oracle.  The validation templates will be built into
*                Processing Constraint Rules to provide case validation at the time of order entry and during order updates.
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    4-Aug-2014  Initial Creation
*
/**********************************************************************************************************************************/

   PROCEDURE attribute12_val (
      p_application_id                 IN       NUMBER,
      p_entity_short_name              IN       VARCHAR2,
      p_validation_entity_short_name   IN       VARCHAR2,
      p_validation_tmplt_short_name    IN       VARCHAR2,
      p_record_set_short_name          IN       VARCHAR2,
      p_scope                          IN       VARCHAR2,
      x_result                         OUT      NUMBER
   );

  
END; 
/

create or replace PACKAGE BODY xxha_rate_shop_status
  /**********************************************************************************************************************************
  *
  * Package:      xxha_rate_shop_status
  * Description:   Assigned to Validation Templates in Oracle.  The validation templates will be built into
  *                Processing Constraint Rules to provide case validation at the time of order entry and during order updates.
  * Notes:
  *
  * Modified:     Ver    Date         Modification
  *-------------  -----  -----------  ----------------------------------------------------------------------------------------------
  * Dbrowne       1.0    4-Aug-2014  Initial Creation
  **********************************************************************************************************************************/
AS
  PROCEDURE attribute12_val(
      p_application_id               IN NUMBER,
      p_entity_short_name            IN VARCHAR2,
      p_validation_entity_short_name IN VARCHAR2,
      p_validation_tmplt_short_name  IN VARCHAR2,
      p_record_set_short_name        IN VARCHAR2,
      p_scope                        IN VARCHAR2,
      x_result OUT NUMBER )
  IS
    l_count NUMBER;
  BEGIN
    x_result := 0;
    oe_debug_pub.ADD ('xxha_oe_case_val_pkg.attribute12_val');
    IF NVL(oe_line_security.g_record.attribute12,'None')='Pending' THEN
      SELECT COUNT(1)
      INTO l_count
      FROM wm_trackchanges
      WHERE SUBSTR(comments,25)=oe_line_security.g_record.header_id
      AND transaction_type    IN ('RATESHOP','RERATESHOP')
      and TRANSACTION_ID=oe_line_security.g_record.attribute10;
      IF l_count              !=0 THEN
        x_result              := 1;
      END IF;
    END IF;
  END;
END;
/