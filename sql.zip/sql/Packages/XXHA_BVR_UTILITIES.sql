CREATE OR REPLACE PACKAGE "XXHA_BVR_UTILITIES" AS

/*********************************************************************************************
* Package Name : XXHA_BVR_UTILITIES                                                          *
* Purpose      : This package provides functions to create the BVR Report.                   *
*                This package will be used by the XML Report 'XXHA: AR Invoice Report CH'.   *
*                It is called from within FUNCTION 'CF_1Formula'                             *
*                                                                                            *
* Procedures   : RECURSIVE_MODULO_10                                                         *
*              : POPULATE_BVR_TABLE                                                          *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
* - XXHA_BVR_INVOICES        U                                                               *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        15-MAR-2007     MDI                  Swiss BVR solution                         *
* 2.0        23-NOV-2009     B. Marcoux           ERP103913                                  *
*                                                 Incident# 49319 (See Incident# 46300 -     *
*                                                 Changes to EU Banking Information)         *
* 3.0        17-FEB-2010     B. Marcoux           ERP104166                                  *
*                                                 Incident# 55595                            *
*                                                 Correct Bank Account Number for string     *
*                                                 at bottom of BVR.                          *
* 4.0        23-SEP-2010     E. Rossing           Incident# 69787                            *
*                                                 Use Invoice ID instead of Invoice Number   *
*                                                 to avoid problems with duplicate invoice   *
*                                                 numbers.                                   *
*********************************************************************************************/

  FUNCTION POPULATE_BVR_TABLE ( P_CONC_REQ_ID       NUMBER
  
-- 4.0 - ERossing
--                             , P_AR_INVOICE_NUMBER VARCHAR2
                             , P_AR_INVOICE_ID     NUMBER
                             
                              , P_ORG_ID            NUMBER
                              , P_TOTAL_AMOUNT      NUMBER) RETURN VARCHAR2;
END;
/


CREATE OR REPLACE PACKAGE BODY "XXHA_BVR_UTILITIES" AS
/*********************************************************************************************
* Package Name : XXHA_BVR_UTILITIES                                                          *
* Purpose      : This package provides functions to create the BVR Report.                   *
*                This package will be used by the XML Report 'XXHA: AR Invoice Report CH'.   *
*                It is called from within FUNCTION 'CF_1Formula'                             *
*                                                                                            *
* Procedures   : RECURSIVE_MODULO_10                                                         *
*              : POPULATE_BVR_TABLE                                                          *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
* - XXHA_BVR_INVOICES        U                                                               *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        15-MAR-2007     MDI                  Swiss BVR solution                         *
* 2.0        23-NOV-2009     B. Marcoux           ERP103913                                  *
*                                                 Incident# 49319 (See Incident# 46300 -     *
*                                                 Changes to EU Banking Information)         *
* 3.0        17-FEB-2010     B. Marcoux           ERP104166                                  *
*                                                 Incident# 55595                            *
*                                                 Correct Bank Account Number for string     *
*                                                 at bottom of BVR.                          *
* 4.0        23-SEP-2010     E. Rossing           Incident# 69787                            *
*                                                 Use Invoice ID instead of Invoice Number   *
*                                                 to avoid problems with duplicate invoice   *
*                                                 numbers.                                   *
*********************************************************************************************/
FUNCTION RECURSIVE_MODULO_10(P_STRING VARCHAR2) RETURN NUMBER IS
    TYPE CHECKTABLE_TYPE IS TABLE OF NUMBER INDEX BY VARCHAR2(1);
    v_checktable CHECKTABLE_TYPE;
    v_counter INTEGER := 0;
    v_report  INTEGER := 0;
    v_index   INTEGER := 0;
    v_number  INTEGER := 0;
  BEGIN
    /*
    checktable[0-9] = {0,9,4,6,8,2,7,1,3,5}
    U = 0
    P = 0
    FOR all digits in checknumber from left
    LOOP
      num = selected digit
      idx = (num + u) mod 10
      u = checktable[idx]
    END LOOP
    checkdigit = (10 -u) mod 10
    */
    v_checktable(0) := 0; v_checktable(1) := 9; v_checktable(2) := 4; v_checktable(3) := 6; v_checktable(4) := 8;
    v_checktable(5) := 2; v_checktable(6) := 7; v_checktable(7) := 1; v_checktable(8) := 3; v_checktable(9) := 5;
--    FOR v_counter IN 1..(LENGTH(P_STRING-1)) LOOP
    FOR v_counter IN 1..LENGTH(P_STRING) LOOP
      v_number := SUBSTR(P_STRING,v_counter,1);
      v_index  := (v_number + v_report) MOD 10;
      v_report := v_checktable(v_index);
    END LOOP;
    RETURN (10 - v_report) MOD 10;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN -1;
  END;
FUNCTION POPULATE_BVR_TABLE( P_CONC_REQ_ID       NUMBER
  -- 4.0 - ERossing
--                             , P_AR_INVOICE_NUMBER VARCHAR2
                             , P_AR_INVOICE_ID     NUMBER

                             , P_ORG_ID            NUMBER
                             , P_TOTAL_AMOUNT      NUMBER) RETURN VARCHAR2 IS
-- 4.0 - ERossing
--    CURSOR invoice_cur( P_AR_INVOICE_NUMBER VARCHAR2
    CURSOR invoice_cur( P_AR_INVOICE_ID NUMBER
                      , P_ORG_ID NUMBER) IS
      /*SELECT rc.customer_number                cust_number    ------11i code Modified
           , rc.customer_name                  cust_name
           , raa.address1                      cust_adr1
           , raa.address2                      cust_adr2
           , raa.city                          cust_city
           , raa.state                         cust_state
           , raa.postal_code                   cust_postal_code
           , ft.territory_short_name           cust_country
           , hl.description                    company_name
           , hl.ADDRESS_LINE_1                 company_address1
           , hl.ADDRESS_LINE_2                 company_address2
           , hl.ADDRESS_LINE_3                 company_address3
           , hl.TOWN_OR_CITY                   company_city
           , hl.COUNTRY                        company_country
           , substr(hl.postal_code,0,5)        company_postal_code
-- 4.0 - ERossing - add invoice number to query, since it's no longer a parameter
           , rcta.trx_number                   invoice_number
           FROM ra_customer_trx_all       rcta
           , ra_addresses_all          raa
           , ra_site_uses_all          rsua
           , ra_customers              rc
           , fnd_territories_tl        ft
           , hr_all_organization_units hou
           , hr_locations              hl
-- 4.0 - ERossing
--       WHERE rcta.trx_number          = P_AR_INVOICE_NUMBER
       WHERE rcta.customer_trx_id         = P_AR_INVOICE_ID
AND rcta.org_id              = P_ORG_ID
         AND rcta.bill_to_site_use_id = rsua.site_use_id
         AND rsua.address_id          = raa.address_id
         AND raa.customer_id          = rc.customer_id
         AND ft.territory_code        = raa.country
         AND decode(ft.territory_code, NULL, userenv('LANG'), ft.LANGUAGE) = userenv('LANG')
         AND rcta.ORG_ID              = hou.ORGANIZATION_ID
         AND hl.LOCATION_ID           = hou.LOCATION_ID;*/
    -------R12 Remediated
SELECT   HCA.ACCOUNT_NUMBER               cust_number
           , HP.PARTY_NAME                  cust_name
           , HL.ADDRESS1                      cust_adr1
           , HL.ADDRESS2                      cust_adr2
           , HL.CITY                          cust_city
           , HL.STATE                         cust_state
           , HL.POSTAL_CODE                   cust_postal_code
           , ft.territory_short_name           cust_country
           , hrl.description                    company_name
           , hrl.ADDRESS_LINE_1                 company_address1
           , hrl.ADDRESS_LINE_2                 company_address2
           , hrl.ADDRESS_LINE_3                 company_address3
           , hrl.TOWN_OR_CITY                   company_city
           , hrl.COUNTRY                        company_country
           , substr(hrl.postal_code,0,5)        company_postal_code
-- 4.0 - ERossing - add invoice number to query, since it's no longer a parameter
           , rcta.trx_number                   invoice_number
 FROM          ra_customer_trx_all       rcta
           ---, ra_addresses_all          raa
            , HZ_LOCATIONS  HL
            , HZ_PARTY_SITES HPS
            , HZ_CUST_ACCT_SITES_ALL HCASA
           ---, ra_site_uses_all          rsua
           , HZ_CUST_SITE_USES_ALL HCSUA
           ---, ra_customers              rc
           , HZ_PARTIES   hp
           , HZ_CUST_ACCOUNTS HCA
           , fnd_territories_tl        ft
           , hr_all_organization_units hou
           , hr_locations              hrl
WHERE         rcta.customer_trx_id    = P_AR_INVOICE_ID
         AND           rcta.org_id            = P_ORG_ID
          AND           rcta.BILL_TO_SITE_USE_ID = HCSUA.SITE_USE_ID
         AND  HP.PARTY_ID = HCA.PARTY_ID
        and HP.PARTY_ID = HPS.PARTY_ID
        AND HPS.LOCATION_ID= HL.LOCATION_ID
        AND HCASA.CUST_ACCT_SITE_ID=HCSUA.CUST_ACCT_SITE_ID
        AND HCASA.CUST_ACCOUNT_ID= HCA.CUST_ACCOUNT_ID
        AND HPS.PARTY_SITE_ID = HCASA.PARTY_SITE_ID
        AND ft.territory_code        = HL.COUNTRY ------
         AND decode(ft.territory_code, NULL, userenv('LANG'), ft.LANGUAGE) = userenv('LANG')
         AND rcta.ORG_ID              = hou.ORGANIZATION_ID
         AND hrl.LOCATION_ID           = hou.LOCATION_ID;
 CURSOR bank_cur IS
-- 2.0 - BMarcoux - ERP103913
--      SELECT ALA.LOCKBOX_NUMBER  COMPANY_NUMBER
      SELECT '01647846'          COMPANY_NUMBER
           , ABB.BANK_NAME       COMPANY_BANK_NAME
           , ABB.ADDRESS_LINE1   COMPANY_BANK_ADDRESS1
           , ABB.ADDRESS_LINE2   COMPANY_BANK_ADDRESS2
           , ABB.CITY            COMPANY_BANK_CITY
           , ABB.ZIP             COMPANY_BANK_ZIP
        FROM ----AP_BANK_ACCOUNTS_ALL ABA--11i code modified
           ---, AP_BANK_BRANCHES     ABB--11i code modified
            ce_bank_accounts     ABA,--R12 Remediated
            ce_bank_branches_v  ABB  --R12 Remediated
-- 2.0 - BMarcoux - ERP103913
--           , AR_LOCKBOXES_ALL     ALA
       WHERE ---ABA.BANK_BRANCH_ID = ABB.BANK_BRANCH_ID--11i code modified
             ABA.BANK_BRANCH_ID = ABB.BRANCH_PARTY_ID--R12 Remediated
         ----AND ABA.ACCOUNT_TYPE   = 'INTERNAL'--11i code modified
         AND ABA.ACCOUNT_CLASSIFICATION   = 'INTERNAL'--R12 Remediated
         AND ABA.CURRENCY_CODE  = 'CHF'--R12 Remediated
         AND ABA.Bank_Account_Num = '01000714000'--R12 Remediated
-- 2.0 - BMarcoux - ERP103913
--         AND ABA.IBAN_NUMBER    = ALA.BANK_ORIGINATION_NUMBER
;
CURSOR bvr_cur(P_CONC_REQ_ID NUMBER) IS
      SELECT XBI.BVR_ID
        FROM HAEMO.XXHA_BVR_INVOICES XBI
       WHERE XBI.CONC_REQ_ID = P_CONC_REQ_ID
         FOR UPDATE;
 v_invoice_rec    invoice_cur%ROWTYPE;
    v_bank_rec       bank_cur%ROWTYPE;
    v_next_val       NUMBER := 0;
    v_esr_line       VARCHAR2(255);
    v_esr_reference  VARCHAR2(255);
    v_esr_checksum   NUMBER;
    err_msg          VARCHAR2(100);
BEGIN
    OPEN bank_cur;
    FETCH bank_cur INTO v_bank_rec;
    CLOSE bank_cur;
-- 4.0 - ERossing
    --OPEN invoice_cur( P_AR_INVOICE_NUMBER
    OPEN invoice_cur( P_AR_INVOICE_ID
     , P_ORG_ID);
    FETCH invoice_cur INTO v_invoice_rec;
    CLOSE invoice_cur;
OPEN bvr_cur(P_CONC_REQ_ID);
    FETCH bvr_cur INTO v_next_val;
    IF bvr_cur%NOTFOUND THEN
       v_next_val := 0;
    END IF;
    CLOSE bvr_cur;
-- 2.0 - BMarcoux - ERP103913 - Change first eleven (11) digits to the account number at DB Zurich (01000714000) - used to be only six (6) digits.
-- This will cut down the Customer Number from eleven (11) digits to six (6) digits.
-- set ESR REFERENCE NUMBER
--  v_esr_reference :=    331782
--                     || LPAD(v_invoice_rec.cust_number,11,'0')
    v_esr_reference :=    '01000714000'
                       || LPAD(v_invoice_rec.cust_number,6,'0')
-- 4.0 - ERossing
--                       || LPAD(P_AR_INVOICE_NUMBER,9,'0');
                       || LPAD(v_invoice_rec.invoice_number,9,'0');

--                     || RECURSIVE_MODULO_10(P_AR_INVOICE_NUMBER);
    v_esr_reference := v_esr_reference||RECURSIVE_MODULO_10(v_esr_reference);

    -- set ESR LINE
/*
    v_esr_line :=    '01'
                  || LTRIM(RTRIM(REPLACE(TO_CHAR(P_TOTAL_AMOUNT,'00000000.00'),'.','')))
                  || RECURSIVE_MODULO_10(LTRIM(RTRIM(REPLACE(TO_CHAR(P_TOTAL_AMOUNT,'00000000.00'),'.',''))))
                  || '>'
                  || v_esr_reference
                  || '+ '
                  || v_bank_rec.COMPANY_NUMBER
                  || '>';
*/
    v_esr_line := '01' || LTRIM(RTRIM(REPLACE(TO_CHAR(P_TOTAL_AMOUNT,'00000000.00'),'.','')));
    v_esr_line := v_esr_line||RECURSIVE_MODULO_10(v_esr_line);
-- 3.0 - BMarcoux - ERPxxxxxx
    v_esr_line := v_esr_line||'>' || v_esr_reference || '+ ' || '010647846' || '>';
--    v_esr_line := v_esr_line||'>' || v_esr_reference || '+ ' || v_bank_rec.COMPANY_NUMBER || '>';

    -- DBMS_OUTPUT.PUT_LINE('              Primary Key '||P_CONC_REQ_ID||' '||v_next_val + 1);
INSERT INTO HAEMO.XXHA_BVR_INVOICES ( CONC_REQ_ID
                                        , BVR_ID
                                        , COMPANY_NUMBER
                                        , COMPANY_NAME
                                        , COMPANY_ADDRESS_1
                                        , COMPANY_ADDRESS_2
                                        , COMPANY_CITY
                                        , COMPANY_BANK_NAME
                                        , COMPANY_BANK_ADDRESS
                                        , AR_CUSTOMER_NUMBER
                                        , AR_INVOICE_NUMBER
                                        , CUSTOMER_NAME
                                        , CUSTOMER_ADDRESS_1
                                        , CUSTOMER_ADDRESS_2
                                        , CUSTOMER_CITY
                                        , CUSTOMER_POSTAL_CODE -- MDI 12/04/07
                                        , CUSTOMER_COUNTRY
                                        , INVOICE_AMOUNT
                                        , ESR_LINE
                                        , ESR_REFERENCE_NUMBER)
    VALUES ( P_CONC_REQ_ID
           , HAEMO.XXHA_BVR_INVOICES_S.NEXTVAL
           , v_bank_rec.COMPANY_NUMBER
           , v_invoice_rec.company_name
           , v_invoice_rec.company_address1
           , v_invoice_rec.company_address2
           , v_invoice_rec.company_city
           , v_bank_rec.COMPANY_BANK_NAME
           , v_bank_rec.COMPANY_BANK_ADDRESS1
           , v_invoice_rec.cust_number
-- 4.0 - ERossing
--         , P_AR_INVOICE_NUMBER
           , v_invoice_rec.invoice_number

           , v_invoice_rec.cust_name
           , v_invoice_rec.cust_adr1
           , v_invoice_rec.cust_adr2
           , v_invoice_rec.cust_city
           , v_invoice_rec.cust_postal_code -- MDI 12/04/07
           , v_invoice_rec.cust_country
           , P_TOTAL_AMOUNT
           , v_esr_line
           , v_esr_reference);
    RETURN NULL;
  EXCEPTION
    WHEN OTHERS THEN
      err_msg := SUBSTR(SQLERRM, 1, 100);
      RETURN 'Error '||err_msg;
  END;
END;
/
