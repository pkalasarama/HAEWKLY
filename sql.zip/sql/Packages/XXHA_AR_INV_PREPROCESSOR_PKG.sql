CREATE OR REPLACE PACKAGE XXHA_AR_INV_PREPROCESSOR_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_AR_PREPROCESSOR_PKG                                                *
* Purpose      : This package updates table column RA_INTERFACE_LINES_ALL.BATCH_SOURCE_NAME    *
*                It is called as a pre-processing step before AR AutoInvoice Runs        *
*                                                                                        *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        09-Feb-2009     Amit Patl OCS      Initial Creation                         *
*                                                                                        *
*****************************************************************************************/

PROCEDURE main(err_buf      out  VARCHAR2
              ,ret_code     OUT  VARCHAR2
              ,p_inquiry_flag  IN   VARCHAR2 DEFAULT 'Y' );


END XXHA_AR_INV_PREPROCESSOR_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_AR_INV_PREPROCESSOR_PKG  AS
--Version 1.0.1
/********************************************************************************************************************************************
* Package Name : XXHA_AR_PREPROCESSOR_PKG                                                                                  
* Purpose      : This package updates table column RA_INTERFACE_LINES_ALL.BATCH_SOURCE_NAME                                
*                It is called as a pre-processing step before AR AutoInvoice Runs                                          
*                                                                                                                          
*                                                                                        				   
* Procedures   :    Main                                                                                                   
* --------------                                                                         				   
*                                                                                        				   
* Tables Accessed :             Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)              
* ra_interface_lines_all        S,U
* oe_order_headers_all          S
* oe_order_lines_all            S
* po_requisition_lines_all      S
* rcv_shipment_lines            S
* hr_all_organization_units     S
* cst_item_costs                S
*
*
*                                                                                       				   
*                                                                                        				   
* Change History                                                                         				   
*                                                                                        				   
* Ver        Date            Author               Description                            				   
* ------     -----------     -----------------    ---------------                        				   
* 1.0        09-Feb-2009     Amit Patl OCS       Initial Creation                        				   
* 1.1        10-Mar-2009     Suresh Ramamoorthy  Replaced sales line price with Item's cost				   
* 1.2        26-Mar-2009     Suresh Ramamoorthy  Expanded comments and removed previously commented code for aesthetics purpose
* 1.3	     12-Aug-2010     IPadela		 modified to make the batch source to be determined at sales order line level
						 so if a line has been recieved it is interfaced irrespective if the whole
						 order is received or not. Also set the conversion date to the date of the invoice run
                                                 for the IRQ only
* 1.4        11-Jan-2013     DI Lyubov Morozova  Removed undocumented enhancement for ESC111681
* 1.5  jan-2013  Changes made related to OPM tickets  i188021, i167578. Fix bug with  duplicated print  for Split lines.
* 1.6  May 15 2014 changed the org_id assignment from profile to MO_GLOBAL.get_current_org_id
***************************************************************************************************************************************************/

PROCEDURE main (
                err_buf         out  VARCHAR2
               ,ret_code        OUT  VARCHAR2
               ,p_inquiry_flag   IN   VARCHAR2 DEFAULT 'Y'
               )  is
           



CURSOR cur_interface_SO (p_org_id       NUMBER) IS
    select   DISTINCT 
             rila.interface_line_attribute1     SO_NUMBER
            ,rila.interface_line_attribute6     SO_LN_ID --1.3 - IPadela - added the line id and number in the distinct clause
            ,rila.org_id
           ,rila.sales_order_line              SO_LN_NUMBER --1.3 - IPadela - added the line id and number in the distinct clause
           ,(select 
                  max(rila1.interface_line_attribute6)
           from ra_interface_lines_all rila1
           where rila.interface_line_attribute1 = rila1.interface_line_attribute1
             and rila.sales_order_line = rila1.sales_order_line
             and rila.org_id = rila1.org_id
             and rila1.interface_status  is null
             and rila1.batch_source_name = 'Intercompany Invoice Hold'
            group by rila.sales_order_line, rila1.interface_line_attribute1) max_so_ln_id  -- Added  to fix bug, when status  for  internal order is  listed twice  for split lines ( i167578, i188021)
    from    ra_interface_lines_all rila
    where   rila.interface_status  is null
    and     rila.batch_source_name = 'Intercompany Invoice Hold'
    AND     rila.org_id  = p_org_id
    ORDER BY  rila.interface_line_attribute1
            ,rila.interface_line_attribute6;
    
    
--1.3 IPadela - added the SO line id as a parameter to this cursor since we now want to look up by each line separately    
CURSOR cur_rcv_shipment  (p_so_number      VARCHAR2,
			  p_so_line_id     VARCHAR2,
                            p_org_id       NUMBER
                            )    IS
    select   DISTINCT ooha.order_number                
            ,ooha.orig_sys_document_ref           req_number
            ,ooha.source_document_id
            ,ooha.org_id                          so_org_id
            ,haou1.name                           shipping_ou
            ,prl.org_id                           pr_org_id
            ,haou2.name                           receiving_ou       
            ,oola.line_id     
            ,oola.line_number
            ,shl.shipment_line_id                  shp_ln_id
            ,shl.shipment_header_id                shp_hd_id    
            ,shl.shipment_line_status_code         shp_line_status     
            ,shl.quantity_received                 rcv_q
            ,shl.quantity_shipped                  shp_q  
            ,shl.destination_type_code             dest_type     
            ,shl.oe_order_header_id                oe_hd_id     
            ,shl.oe_order_line_id                  oe_ln_id
            ,prl.requisition_header_id             po_req_hdr_id
            ,prl.requisition_line_id               po_req_ln_id   
            ,shl.from_organization_id              from_inv_org
            ,shl.to_organization_id                to_inv_org             
            ,shl.ship_to_location_id               to_org
            ,shl.source_document_code              src_doc
            ,shl.item_id                           item_id
            ,oola.ordered_item                     item                    
            ,shl.unit_of_measure                   uom
            ,oola.unit_selling_price        
		,oola.inventory_item_id    
            ,oola.ship_from_org_id
            ,oola.ship_to_org_id
from       oe_order_headers_all     ooha
          ,oe_order_lines_all       oola
          ,po_requisition_lines_all prl
          ,rcv_shipment_lines       shl
          ,hr_all_organization_units haou1
          ,hr_all_organization_units haou2  
where       ooha.order_number = p_so_number
AND         ooha.org_id  = p_org_id
AND         oola.line_id = to_number(p_so_line_id) --ver 1.3 also added this line to get only the shipment info for this line
AND         ooha.header_id = oola.header_id
and         oola.source_document_id = prl.requisition_header_id
AND         oola.source_document_line_id = prl.requisition_line_id
and         prl.requisition_line_id = shl.requisition_line_id
and         ooha.org_id      = haou1.organization_id
and         prl.org_id       = haou2.organization_id
order by    ooha.order_number, oola.line_number;           

  
 
ln_hold_cnt                   NUMBER;
ln_total_cnt                  NUMBER;
ln_release_cnt                NUMBER;
lc_fully_received_flag        VARCHAR2(1) ;
lc_expected_flag              VARCHAR2(1) ;

ln_record_cnt                 NUMBER := 0;

ln_org_id                     NUMBER;

l_unit_item_cost              NUMBER;

    
----------------   Main Block -----------------------------------------------
   

BEGIN


   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Begin Main Block');
   FND_FILE.PUT_LINE(FND_FILE.LOG, '****************');
   
    
            -- ln_org_id := FND_PROFILE.VALUE('ORG_ID');  commented by sreeram on 5/15
           ln_org_id :=  MO_GLOBAL.get_current_org_id; -- added by sreeram on 5/15 to fix MOAC issue raised by Paul/Roberto
            
            
         select    count(distinct  rila.INTERFACE_LINE_ATTRIBUTE6)
           INTO    ln_hold_cnt
           from    ra_interface_lines_all rila
          WHERE    interface_status IS NULL   
            AND    batch_source_name = 'Intercompany'
            AND    interface_line_context = 'INTERCOMPANY'
            and    org_id = ln_org_id;
            
            
      FND_FILE.PUT_LINE(FND_FILE.LOG, 'No. of New Sales Orders lines ready to put on Hold for AR Intercompany Invoice :'||ln_hold_cnt);      
            
     -- If p_inquiry_flag is 'N' then apply Invoicing Hold on all the intercompany invoices first; then in the cursor below we quarantine the lines that have 
     -- no receipts and release the Invoicing hold on those that have been fully received
     
     If p_inquiry_flag = 'N' THEN   

          UPDATE ra_interface_lines_all
          SET    batch_source_name = 'Intercompany Invoice Hold'
          WHERE  1 = 1
          AND    interface_status IS NULL   
          AND    batch_source_name = 'Intercompany'
          AND    interface_line_context = 'INTERCOMPANY'
          and    org_id = ln_org_id;
          
     END IF;
  
 
    select       count(distinct  rila.INTERFACE_LINE_ATTRIBUTE6) --1.3 IPadela - changed this to attribute 6 to get the no of lines instead of orders
      INTO       ln_total_cnt
      from       ra_interface_lines_all rila
     where       rila.interface_status  is null
       and       rila.batch_source_name = 'Intercompany Invoice Hold'
       and       org_id = ln_org_id;
    
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Total No. Sales Orders lines on Hold for AR Intercompany Invoice :'||ln_total_cnt);
        
  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, LPAD('Intercompany Invoice Hold Report', 100, ' '));
  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, LPAD('--------------------------------', 100, ' '));                
  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, '    ');
  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, '   ');
  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD('Shipping OU', 50,' ')||RPAD('Receiving OU', 50, ' ')||RPAD('REQ Number', 15,' ')||RPAD('SO Number', 15, ' ')||RPAD('SO LN Number', 15, ' ')||RPAD('Item', 25, ' ')||RPAD('UOM', 10, ' ')||LPAD('Item Unit Cost', 20, ' ')||LPAD('Shipped Qty', 15,' ')||LPAD('Received Qty', 15, ' ')||'     '||RPAD('Shipping Status', 20, ' '));
  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD('*', 50,'*')||RPAD('*', 50, '*')||RPAD('*', 15,'*')||RPAD('*', 15, '*')||LPAD('*', 15, '*')||RPAD('*', 25, '*')||RPAD('*', 10, '*')||RPAD('*', 15, '*')||LPAD('*', 20,'*')||LPAD('*', 15, '*')||LPAD('*', 5, '*')||RPAD('*', 20, '*'));
  FND_FILE.PUT_LINE(FND_FILE.OUTPUT, '     ');
  
  
  FOR  l_interface_so IN cur_interface_SO (ln_org_id) LOOP
           
         lc_fully_received_flag        := 'N';
         lc_expected_flag              := 'N';
  
        
          --1.3 IPadela - added SO line id to this call as we now want to look up by each line separately 
          FOR  l_rcv_shipment IN cur_rcv_shipment(l_interface_so.so_number,
  						l_interface_so.SO_LN_ID,
                                                    l_interface_so.org_id)
                                                    
          LOOP
          
                  -- If the entire shipped quantity is received for the line then the flag lc_expected_flag will be set to N as it will no longer be EXPECTED RECEIPT; this will
                  -- trigger the release of Invoicing hold in the UPDATE statement below
             
                  IF l_rcv_shipment.rcv_q = l_rcv_shipment.shp_q THEN
  
                          lc_fully_received_flag := 'Y';              
                  ELSE
                          lc_expected_flag := 'Y'; 
  
                  END IF;
  
  /* --1.4.moved to outter "IF" clause"
  	            BEGIN
                    select item_cost
                    into   l_unit_item_cost
                    from   cst_item_costs cic
                    where  cic.inventory_item_id = l_rcv_shipment.inventory_item_id
                    and    cic.organization_id = l_rcv_shipment.ship_from_org_id
                    and    cic.cost_type_id = 1 ; -- Frozen cost; 
   
                  EXCEPTION 
  	            when OTHERS then 
                     l_unit_item_cost := NULL;
  
                  END; 
          */
         		     -- FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD(l_rcv_shipment.Shipping_OU, 50,' ')||RPAD(l_rcv_shipment.Receiving_OU, 50, ' ')||RPAD(l_rcv_shipment.req_number, 15,' ')||RPAD(l_rcv_shipment.order_number, 15, ' ')||RPAD(l_rcv_shipment.line_number, 15, ' ')||RPAD(l_rcv_shipment.Item, 25, ' ')||RPAD(l_rcv_shipment.UOM, 10, ' ')||LPAD(TO_CHAR(l_rcv_shipment.unit_selling_price * l_rcv_shipment.shp_q,99999999.99), 20, '  ' )||LPAD(l_rcv_shipment.shp_q, 15,' ')||LPAD(l_rcv_shipment.rcv_q, 15, ' ')||'     '||RPAD(l_rcv_shipment.shp_line_status, 20, ' '));    
                 
          END LOOP;
          
     --1.4 Added  "IF" clause to fix bug, when status  for  internal order is  listed twice  for split lines ( i167578, i188021)
          if (l_interface_so.so_ln_id = l_interface_so.max_so_ln_id) then 
             FOR  l_rcv_shipment IN cur_rcv_shipment(l_interface_so.so_number,
  						l_interface_so.SO_LN_ID,
                                                    l_interface_so.org_id)
                                                    
          LOOP
             
  	            BEGIN
                    select item_cost
                    into   l_unit_item_cost
                    from   cst_item_costs cic
                    where  cic.inventory_item_id = l_rcv_shipment.inventory_item_id
                    and    cic.organization_id = l_rcv_shipment.ship_from_org_id
                    and    cic.cost_type_id = 1 ; -- Frozen cost; 
   
                  EXCEPTION 
  	            when OTHERS then 
                     l_unit_item_cost := NULL;
  
                  END; 
             
             FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD(l_rcv_shipment.Shipping_OU, 50,' ')||RPAD(l_rcv_shipment.Receiving_OU, 50, ' ')||RPAD(l_rcv_shipment.req_number, 15,' ')||RPAD(l_rcv_shipment.order_number, 15, ' ')||RPAD(l_rcv_shipment.line_number, 15, ' ')||RPAD(l_rcv_shipment.Item, 25, ' ')||RPAD(l_rcv_shipment.UOM, 10, ' ')||LPAD(TO_CHAR(l_unit_item_cost,99999999.99), 20, '  ' )||LPAD(l_rcv_shipment.shp_q, 15,' ')||LPAD(l_rcv_shipment.rcv_q, 15, ' ')||'     '||RPAD(l_rcv_shipment.shp_line_status, 20, ' '));
         END LOOP;      
          
        END IF;
       
        
             IF   lc_expected_flag = 'N' and p_inquiry_flag = 'N' THEN
                 -- After scanning through a sales order line if we find that the received quantity matches the shipped quantity 
                 -- we set the lc_expected_flag to 'N' as there are no more EXPECTED RECEIPTS; hence we release the Invoicing Hold in the UPDATE statement below
                 -- provided the pre-processor concurrent program is NOT run in Inquiry mode                        
                 UPDATE     ra_interface_lines_all
                    SET     batch_source_name = 'Intercompany'
                  WHERE     interface_line_attribute1 = l_interface_so.so_number
                  and       org_id = ln_org_id
                  AND     interface_line_attribute6 = l_interface_so.SO_LN_ID; --1.3 IPadela - added this line to update the line if it has been received irrespective of the whole order
                  
                  --1.3 IPadela - this is to update the conversion date only for the IRQ lines and leave the drop ships alone
                  UPDATE     ra_interface_lines_all ra
                    SET     conversion_date = sysdate
                  WHERE     interface_line_attribute1 = l_interface_so.so_number
                  and       org_id = ln_org_id
                  AND     interface_line_attribute6 = l_interface_so.SO_LN_ID --1.3 IPadela -added this line to update the line if it has been received irrespective of the whole order 
                  and exists (select 1                                        --1.3 IPadela -added this clause to limit to only IRQs
                              from oe_order_lines_all ol,
                                   oe_order_headers_all oh
                              where ra.interface_line_attribute6 = ol.line_id
                              and ol.header_id = oh.header_id
                              and ra.batch_source_name in ('Intercompany')
                              and oh.order_source_id = 10);
                                     
                   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Sales Order line '||l_interface_so.SO_LN_NUMBER||' released for AR Invoice Import.')  ;
                   FND_FILE.PUT_LINE(FND_FILE.OUTPUT, 'Sales Order line '||l_interface_so.SO_LN_NUMBER||' released for AR Invoice Import.')  ;
                    
                    ln_record_cnt := ln_record_cnt + 1;
            END iF;  
            
             FND_FILE.PUT_LINE(FND_FILE.OUTPUT, RPAD('*', 50,'*')||RPAD('*', 50, '*')||RPAD('*', 15,'*')||RPAD('*', 15, '*')||RPAD('*', 25, '*')||RPAD('*', 10, '*')||LPAD('*', 20, '*')||LPAD('*', 15,'*')||LPAD('*', 15, '*')||LPAD('*', 5, '*')||RPAD('*', 20, '*')); 
  
  
        COMMIT;
        
      
  
  END LOOP;


END MAIN;

END XXHA_AR_INV_PREPROCESSOR_PKG;
/
