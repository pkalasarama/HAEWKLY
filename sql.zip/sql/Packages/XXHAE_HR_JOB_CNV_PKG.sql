CREATE OR REPLACE package xxhae_hr_job_cnv_pkg AS
--
--
procedure main(retcode             out number
              ,errbuf              out varchar2
              ,p_business_group_id in number
              ,p_effective_date    in varchar2
              ,p_validate 		   varchar2 default 'Y'
              ,p_jobs_only         varchar2 default 'N'
              ,p_debug               varchar2 default 'N'
              ,p_employee_number   varchar2 default null
              );
--
procedure convert_old_jobs
              (retcode             out number
              ,errbuf              out varchar2
              ,p_effective_date    in varchar2
              ,p_validate          in varchar2
              ,p_debug		   varchar2 default 'N'
              );
--
procedure end_positions(retcode             out number
              ,errbuf              out varchar2
              ,p_effective_date    in varchar2
              ,p_validate          in varchar2
              ,p_debug	           varchar2 default 'N'
              );
--
end xxhae_hr_job_cnv_pkg;

/


CREATE OR REPLACE package body xxhae_hr_job_cnv_pkg as
--
g_package 	varchar2(100) := 'xxhae_hr_job_cnv_pkg.';
g_api		varchar2(1000);
g_debug		varchar2(1);
g_message   varchar2(240);
--
procedure write_trace(p_line_1        varchar2
                     ,p_line_2        varchar2) is
begin
   --
   if g_debug = 'Y' then
      fnd_file.put_line(fnd_file.log, rpad(p_line_1, 100) ||  p_line_2);
      dbms_output.put_line(rpad(p_line_1, 100) ||  p_line_2);
   end if;
   --
end write_trace;
--
procedure update_job_string(p_employee_number varchar2, p_effective_date date)
is
--
cursor csr_employees(cp_effective_Date date) is
select paf.position_id, ppf.employee_number, paf.assignment_id,
       paf.job_id, xxhae.job_level, xxhae.job_family,
       ppf.business_group_id, xxhae.business_group
from per_all_people_f ppf,
     per_all_Assignments_f paf,
     xxhae_hr_job_cnv_tbl xxhae,
     per_business_groups pbg
where xxhae.employee_number = ppf.employee_number
  and  xxhae.employee_number = p_employee_number
  --and ppf.business_group_id = 0
  and paf.position_id is not null
  and pbg.name = xxhae.business_group
  and ppf.business_group_id = pbg.business_group_id
  and paf.business_group_id = ppf.business_group_id
  and nvl(xxhae.cnv_validate_status, 'X') <> 'C'
  and paf.person_id = ppf.person_id
  and paf.business_group_id = ppf.business_group_id
  and paf.assignment_type = 'E'
  and cp_effective_date between ppf.effective_start_date and ppf.effective_end_Date
  and cp_effective_date between paf.effective_start_date and paf.effective_end_Date;
--
 l_job_name        varchar2(150);
 l_job_code        varchar2(150);
 l_job_title       varchar2(150);
 l_labor_type      varchar2(150);
 l_adp_job_code    varchar2(150);
 l_message         varchar2(4000);
 l_procedure	   varchar2(100);
 --
 --Function to retrive job title.
 --
 function get_job_title (p_job_id number)
 return varchar2 is
 --
 l_return varchar2(150);
 --
 begin
--
    select segment2
    into l_return
    from per_jobs pj
         ,per_job_definitions pjd
    where pj.job_id = p_job_id
     and pjd.job_definition_id = pj.job_definition_id;
  --
  return l_return;
  --
  exception
  when others then
    g_message := 'Job title not found for job id' || p_job_id;
    raise;
 end;
 --
 --Function to retrive position segment.
 --
 function get_position_segment (p_position_id number, p_segment varchar2)
 return varchar2 is
 --
 l_return varchar2(150);
 l_dyn_sql varchar2(1000);
 type dynamic_val is ref cursor;
 csr_position_seg dynamic_val;
 invalid_value exception;
 --
 begin
 --
  l_dyn_sql := 'select ' || p_segment
              || ' from per_all_positions pap, '
              || ' per_position_definitions ppd '
              || ' where pap.position_id = ' || p_position_id
              || ' and pap.position_definition_id = ppd.position_definition_id ';
  --
  open csr_position_seg for l_dyn_sql;
  fetch csr_position_seg into l_return;
  --
  if csr_position_seg%notfound then
    raise invalid_value;
  end if;
  --
  close csr_position_seg;
  --
  return l_return;
  --
  exception
  when invalid_value then
  g_message := p_segment || ' Value not found for position id' || p_position_id;
  raise;
  when others then
  g_message := p_segment || ' Value not found for position id' || p_position_id;
    raise;
 end;
 --
 function validate_flex_value (p_val_set_name varchar2, p_value varchar2)
 return varchar2 is
 --
 l_return varchar2(150);
 --
 begin
 --
  select ffv.flex_value
  into l_return
  from fnd_flex_values ffv,
       fnd_flex_value_sets ffvs
  where ffvs.flex_value_set_name = p_val_set_name
       and ffvs.flex_value_Set_id = ffv.flex_value_Set_id
       and upper(ffv.flex_value) = upper(rtrim(p_value))
       and ffv.enabled_flag = 'Y';
  --
  return l_return;
  --
  exception
  when others then
   g_message := 'Invalid value ' || p_value || ' for value set ' || p_val_set_name;
    raise;
 end;
--
function get_adp_job_code (p_position_id number, p_effective_Date date)
 return varchar2 is
 --
 l_return varchar2(150);
 --
 begin
 --
  select attribute11
  into l_return
  from hr_all_positions_f
  where position_id = p_position_id
    and p_effective_date between effective_start_Date and effective_end_Date;
  --
  return l_return;
  --
  exception
  when others then
  g_message := 'ADP code not found for position id ' || p_position_id;
   -- return null;
  raise;
 end;
--
begin
    --
    l_procedure := g_package || 'update_job_string';
    --
    write_trace('Entering: ' || l_procedure, 10);
    --
    for csr_emp in csr_employees(p_effective_date)
      --
      loop
       --
       begin
         --
         l_job_code := get_position_segment(csr_emp.position_id, 'segment4');
         --
         write_trace('Job_code', l_job_code);
         --
         l_job_title := get_job_title(csr_emp.job_id);
         --
         write_trace('Job_title', l_job_title);
         --
         csr_emp.job_level := validate_flex_value ('HAE_GLOBAL_HR_JOB_LEVEL', csr_emp.job_level);
         --
         write_trace('Job_level', csr_emp.job_level);
         --
         csr_emp.job_family := validate_flex_value ('HAE_GLOBAL_HR_JOB_FAMILY', csr_emp.job_family);
         --
         write_trace('Job_family', csr_emp.job_family);
         --
         l_labor_type := get_position_segment(csr_emp.position_id, 'segment6');
         --
         write_trace('Labor Type', l_labor_type);
         --
         l_job_name := l_job_code           || '.' ||
                       l_job_title          || '.' ||
                       csr_emp.job_level    || '.' ||
                       csr_emp.job_family   || '.' ||
                       l_labor_type;
         --
         write_trace('New Job String', l_job_name);
         --
         l_adp_job_code := get_adp_job_code(csr_emp.position_id,p_effective_Date);
         --
         write_trace('ADP Job Code', l_adp_job_code);
         --
         update xxhae_hr_job_cnv_tbl
         set job_name = l_job_name,
             job_code = l_job_code,
             job_title = l_job_title,
             job_level = csr_emp.job_level,
             job_family = csr_emp.job_family,
             job_labor_type = l_labor_type,
             adp_job_code = l_adp_job_code,
             position_id = csr_emp.position_id,
             assignment_id = csr_emp.assignment_id,
             business_group_id = csr_emp.business_group_id,
             cnv_validate_status = 'C'
         where employee_number = csr_emp.employee_number
           and business_group = csr_emp.business_group;
         --
         write_trace(l_procedure, 20);
         --
       exception
       --
       when others then
         --
         l_message := g_message;
         --
         rollback;
         --
         update xxhae_hr_job_cnv_tbl
         set cnv_validate_status = 'E',
             cnv_message = l_message
         where employee_number = csr_emp.employee_number
           and business_group = csr_emp.business_group;
         --
         commit;
         --
         raise;
         --
       end;
    end loop;
   --
   write_trace('Leaving: ' || l_procedure, 999);
end update_job_string;
--
procedure create_jobs(p_employee_number varchar2, p_effective_date date) is
--
cursor csr_jobs is
select *
from xxhae_hr_job_cnv_tbl
where employee_number = p_employee_number
  and nvl(cnv_job_status,'X') <> 'C'
  and cnv_validate_status = 'C';
--
l_business_group_id number(10);
l_job_group_id      number(10);
l_job_id            number(10);
l_def_id            number;
l_ovn               number(10);
l_job_def_id        number(10) := null;
l_job_name          varchar2(150);
l_adp_job_code      varchar2(150);
l_date_from         date := to_date('01-jan-1951','dd-mon-yyyy'); --p_effective_date;
l_name              varchar2(150);
l_message           varchar2(4000);
l_procedure			varchar2(100);
moreThanOneADPCode  exception;
--
begin
    --
    l_procedure := g_package || 'create_jobs';
    --
    write_trace('Entering: '|| l_procedure, 10);
    --
    for csr_job in csr_jobs
    loop
       --
       begin
          --
          g_api := 'hr_job_api.create_job - ';
         write_trace(l_procedure, 20);
          --
          --check if the job already exists. If yes, then skip job creation.
          --
          begin
            select job_id, job_definition_id, attribute1
            into l_job_id, l_def_id, l_adp_job_code
            from per_jobs
            where name = csr_job.job_name
              and business_group_id = csr_job.business_group_id;
          exception when others then
            l_job_id := null;
          end;
          --
         write_trace('Job ID', l_job_id);
          --
          if l_job_id is null then
               --
               l_ovn := null;
               --
               begin
                select job_group_id
                into l_job_group_id
                from per_job_groups
                where business_group_id = csr_job.business_group_id;
               --
               exception
               when others then
               l_message := 'Job Group not found for business group id ' || csr_job.business_group_id;
               raise;
               end;
               --
               write_trace('Job Group ID', l_job_group_id);
               --
               begin
                   hr_job_api.create_job
                    (p_validate                      => false
                    ,p_business_group_id             => csr_job.business_group_id
                    ,p_date_from                     => l_date_from
                    ,p_job_group_id                  => l_job_group_id
                  --  ,p_attribute_category            in     varchar2 default null
                    ,p_attribute1                    => csr_job.adp_job_code
                  /*  ,p_attribute2                    in     varchar2 default null
                    ,p_attribute3                    in     varchar2 default null
                    ,p_attribute4                    in     varchar2 default null
                    ,p_attribute5                    in     varchar2 default null
                    ,p_attribute6                    in     varchar2 default null
                    ,p_attribute7                    in     varchar2 default null
                    ,p_attribute8                    in     varchar2 default null
                    ,p_attribute9                    in     varchar2 default null
                    ,p_attribute10                   in     varchar2 default null
                    ,p_attribute11                   in     varchar2 default null
                    ,p_attribute12                   in     varchar2 default null
                    ,p_attribute13                   in     varchar2 default null
                    ,p_attribute14                   in     varchar2 default null
                    ,p_attribute15                   in     varchar2 default null
                    ,p_attribute16                   in     varchar2 default null
                    ,p_attribute17                   in     varchar2 default null
                    ,p_attribute18                   in     varchar2 default null
                    ,p_attribute19                   in     varchar2 default null
                    ,p_attribute20                   in     varchar2 default null
                    ,p_job_information_category      in     varchar2 default null
                    ,p_job_information1              in     varchar2 default null
                    ,p_job_information2              in     varchar2 default null
                    ,p_job_information3              in     varchar2 default null
                    ,p_job_information4              in     varchar2 default null
                    ,p_job_information5              in     varchar2 default null
                    ,p_job_information6              in     varchar2 default null
                    ,p_job_information7              in     varchar2 default null
                    ,p_job_information8              in     varchar2 default null
                    ,p_job_information9              in     varchar2 default null
                    ,p_job_information10             in     varchar2 default null
                    ,p_job_information11             in     varchar2 default null
                    ,p_job_information12             in     varchar2 default null
                    ,p_job_information13             in     varchar2 default null
                    ,p_job_information14             in     varchar2 default null
                    ,p_job_information15             in     varchar2 default null
                    ,p_job_information16             in     varchar2 default null
                    ,p_job_information17             in     varchar2 default null
                    ,p_job_information18             in     varchar2 default null
                    ,p_job_information19             in     varchar2 default null
                    ,p_job_information20             in     varchar2 default null */
                    ,p_segment1                      => csr_job.job_code
                    ,p_segment2                      => csr_job.job_title
                    ,p_segment3                      => csr_job.job_level
                    ,p_segment4                      => csr_job.job_family
                    ,p_segment5                      => csr_job.job_labor_type
                 /*   ,p_segment6                      in     varchar2 default null
                    ,p_segment7                      in     varchar2 default null
                    ,p_segment8                      in     varchar2 default null
                    ,p_segment9                      in     varchar2 default null
                    ,p_segment10                     in     varchar2 default null
                    ,p_segment11                     in     varchar2 default null
                    ,p_segment12                     in     varchar2 default null
                    ,p_segment13                     in     varchar2 default null
                    ,p_segment14                     in     varchar2 default null
                    ,p_segment15                     in     varchar2 default null
                    ,p_segment16                     in     varchar2 default null
                    ,p_segment17                     in     varchar2 default null
                    ,p_segment18                     in     varchar2 default null
                    ,p_segment19                     in     varchar2 default null
                    ,p_segment20                     in     varchar2 default null
                    ,p_segment21                     in     varchar2 default null
                    ,p_segment22                     in     varchar2 default null
                    ,p_segment23                     in     varchar2 default null
                    ,p_segment24                     in     varchar2 default null
                    ,p_segment25                     in     varchar2 default null
                    ,p_segment26                     in     varchar2 default null
                    ,p_segment27                     in     varchar2 default null
                    ,p_segment28                     in     varchar2 default null
                    ,p_segment29                     in     varchar2 default null
                    ,p_segment30                     in     varchar2 default null
                    ,p_concat_segments               in     varchar2 default null
                    ,p_language_code                 in     varchar2 default hr_api.userenv_lang */
                    ,p_job_id                           => l_job_id
                    ,p_object_version_number            => l_ovn
                    ,p_job_definition_id             => l_job_def_id
                    ,p_name                          => l_name
                    );
               --
               write_trace(l_procedure, 30);
               --
               update xxhae_hr_job_cnv_tbl
               set job_id = l_job_id,
                   job_definition_id = l_job_def_id,
                   cnv_job_status = 'C'
               where job_name = csr_job.job_name
                 and employee_number = csr_job.employee_number
                 and business_group_id = csr_job.business_group_id;
               --
               exception
               --
               when others then
               --
               l_message := g_api || substr(sqlerrm, 1, 2000);
               write_trace('l_message', l_message);
               --
               rollback;
               --
               update xxhae_hr_job_cnv_tbl
               set cnv_job_status = 'E',
                   cnv_message = l_message
               where employee_number = csr_job.employee_number
                 and business_group = csr_job.business_group;
               --
               commit;
               --
               raise;
               --
               end;
          else
            --
            -- check if adp job code is same as that for position for existing job.
            --if not, error out the record.
            if nvl(l_adp_job_code,'xxx') <> nvl(csr_job.adp_job_code,'xxx') then
                   l_message := 'More than one ADP job code for the job string ' || csr_job.job_name;
                   fnd_file.put_line(fnd_file.log, 'More than one ADP job code for the job string ' || csr_job.job_name);
                   raise moreThanOneADPCode;
            end if;
            --
            update xxhae_hr_job_cnv_tbl
               set job_id = l_job_id,
                   job_definition_id = l_def_id,
                   cnv_job_status = 'C'
               where employee_number = csr_job.employee_number
                 and business_group = csr_job.business_group;
           --
          end if;
       --
       exception
       --
       when moreThanOneADPCode then
       --
       rollback;
       --
       update xxhae_hr_job_cnv_tbl
       set cnv_job_status = 'E',
           cnv_message = l_message
       where employee_number = csr_job.employee_number
         and business_group = csr_job.business_group;
        -- and business_group_id = csr_job.business_group_id;
       --
       commit;
       raise;
       --
       when others then
       --
       rollback;
       --
       update xxhae_hr_job_cnv_tbl
       set cnv_job_status = 'E',
           cnv_message = l_message
       where --job_name = csr_job.job_name
             employee_number = csr_job.employee_number
         and business_group = csr_job.business_group;
         --and business_group_id = csr_job.business_group_id;
       --
       commit;
       --
       raise;
       --
       end;
       --
    end loop;
   --
   write_trace('Leaving: ' || l_procedure, 999);
end create_jobs;
--
procedure update_valid_grades(p_employee_number varchar2, p_effective_Date date)
is
--
cursor csr_grades is
select pvg.*, pvg.rowid, xxhae.employee_number,xxhae.job_id new_job_id, xxhae.job_name,--, xxhae.business_group_id
       pos.effective_start_date, pos.effective_end_Date,xxhae.business_group
from xxhae_hr_job_cnv_tbl xxhae,
     per_valid_grades pvg,
     hr_all_positions_f pos
where employee_number = p_employee_number
  and pvg.business_group_id = xxhae.business_group_id
  and pvg.position_id = xxhae.position_id
  and pos.position_id = pvg.position_id
  and nvl(cnv_grade_status,'X') <> 'C'
  and cnv_job_status = 'C';
--
--
l_ovn               number;
l_message           varchar2(4000);
moreThanOneValidGrade exception;
l_procedure			varchar2(100);
--
 begin
    --
    l_procedure := g_package || 'update_valid_grades';
    --
    g_api := 'per_valid_grades_pkg2.update_row - ';
    --
    write_trace('Entering: '|| l_procedure, 10);
    --
    --
    for csr_rec in csr_grades
    loop
        begin
             --
            write_trace('new Job_id' , csr_rec.new_job_id);
            write_trace('valid_grade_id', csr_rec.valid_grade_id);
            write_trace('Grade_id',csr_rec.grade_id);
            write_trace('start_date', csr_rec.date_from);
            write_trace('Valid Grade Job ID', csr_rec.job_id);
            --
            if csr_rec.job_id is  null then
              per_valid_grades_pkg2.update_row
                    (X_Rowid                     => csr_rec.rowid,
                     X_Valid_Grade_Id            => csr_rec.valid_grade_id,
                     X_Business_Group_Id         => csr_rec.business_group_id,
                     X_Grade_Id                  => csr_rec.grade_id,
                     X_Date_From                 => csr_rec.date_from,
                     X_Comments                  => csr_rec.comments,
                     X_Date_To                   => csr_rec.date_to,
                     X_Job_Id                    => csr_rec.new_job_id,
                     X_Position_Id               => null,
                     X_Attribute_Category        => csr_rec.attribute_category,
                     X_Attribute1                => csr_rec.attribute1,
                     X_Attribute2                => csr_rec.attribute2,
                     X_Attribute3                => csr_rec.attribute3,
                     X_Attribute4                => csr_rec.attribute4,
                     X_Attribute5                => csr_rec.attribute5,
                     X_Attribute6                => csr_rec.attribute6,
                     X_Attribute7                => csr_rec.attribute7,
                     X_Attribute8                => csr_rec.attribute8,
                     X_Attribute9                => csr_rec.attribute9,
                     X_Attribute10               => csr_rec.attribute10,
                     X_Attribute11               => csr_rec.attribute11,
                     X_Attribute12               => csr_rec.attribute12,
                     X_Attribute13               => csr_rec.attribute13,
                     X_Attribute14               => csr_rec.attribute14,
                     X_Attribute15               => csr_rec.attribute15,
                     X_Attribute16               => csr_rec.attribute16,
                     X_Attribute17               => csr_rec.attribute17,
                     X_Attribute18               => csr_rec.attribute18,
                     X_Attribute19               => csr_rec.attribute19,
                     X_Attribute20               => csr_rec.attribute20,
                     x_end_of_time               => apps.hr_general.end_of_time,
                     x_pst1_date_end             => csr_rec.effective_end_Date,
                     x_pst1_date_effective       => csr_rec.effective_start_Date
                    );
             --
             update xxhae_hr_job_cnv_tbl
             set valid_grade_id = csr_rec.valid_grade_id,
                 grade_id = csr_rec.grade_id,      --11/30/2009 added
                 cnv_grade_status = 'C'
             where employee_number = csr_rec.employee_number
              and business_group = csr_rec.business_group;
             --
          else
            if nvl(csr_rec.job_id,'xxx') <> nvl(csr_rec.new_job_id,'xxx') then
                   l_message := 'More than one valid grade the job string ' || csr_rec.job_name;
                   fnd_file.put_line(fnd_file.log, l_message);
                   raise moreThanOneValidGrade;
            end if;
            --
            update xxhae_hr_job_cnv_tbl
               set valid_grade_id = csr_rec.valid_grade_id,
                   cnv_grade_status = 'C'
               where employee_number = csr_rec.employee_number
                 and business_group = csr_rec.business_group;
           --
          end if;
        exception
        --
        when moreThanOneValidGrade then
        --
        rollback;
        --
        update xxhae_hr_job_cnv_tbl
        set cnv_grade_status = 'E',
            cnv_message = l_message
        where employee_number = csr_rec.employee_number
          and business_group = csr_rec.business_group;
        --
        commit;
        --
        raise;
        --
        when others then
        --
        l_message := g_api || substr(sqlerrm, 1, 2000);
        --
        rollback;
        --
        update xxhae_hr_job_cnv_tbl
        set cnv_grade_status = 'E',
            cnv_message = l_message
        where employee_number = csr_rec.employee_number
          and business_group = csr_rec.business_group;
        --
        commit;
        --
        raise;
        --
        end;
        --
    end loop;
   --
   write_trace('Leaving: ' || l_procedure, 999);
 end update_valid_grades;
--
procedure convert_assignments(p_employee_number varchar2, p_effective_date date)
is
--
cursor csr_assignment
is
select paf.assignment_id, xxhae.job_id, paf.object_version_number, xxhae.employee_number,
       paf.effective_start_date, paf.effective_end_date, xxhae.business_group_id, xxhae.business_group,
       xxhae.grade_id
from per_all_assignments_f paf,
     xxhae_hr_job_cnv_tbl xxhae
where employee_number = p_employee_number
  and paf.assignment_id = xxhae.assignment_id
  and paf.business_group_id = xxhae.business_group_id
  and paf.assignment_type = 'E'
  and paf.primary_flag ='Y'
  and nvl(cnv_asg_status,'X') <> 'C'
  and nvl(cnv_grade_status,'X') <> 'E'
  and paf.effective_End_Date >= p_effective_Date --p_effective_date between paf.effective_start_Date and paf.effective_end_Date
;
l_message           varchar2(4000);
l_procedure			varchar2(100);
l_datetrack_mode    varchar2(30);
rec_effective_date  date;
--
l_soft_coding_keyflex_id      		number;
l_effective_start_date        		date;
l_effective_end_date          		date;
l_special_ceiling_step_id           number;
l_business_group_id                 number;
l_ovn                               number;
l_people_group_id                   number;
l_group_name                  		varchar2(100);
l_concatenated_segments       		varchar2(200);
l_no_managers_warning         		boolean;
l_other_manager_warning       		boolean;
l_hourly_salaried_warning     		boolean;
l_org_now_no_manager_warning 		boolean;
l_spp_delete_warning         		boolean;
l_gsp_post_process_warning    		varchar2(200);
l_entries_changed_warning    		varchar2(200);
l_tax_district_changed_warning  	boolean;
--
begin
    --
    l_procedure := g_package || 'convert_assignments';
    --
    g_api := 'hr_assignment_api.update_emp_asg_criteria - ';
    --
    write_trace('Entering: '|| l_procedure, 10);
    --
    for csr_asg in csr_assignment
    loop
        begin
            --
            l_datetrack_mode := null;
            rec_effective_date:= null;
            l_ovn := csr_asg.object_version_number;
            l_business_group_id := csr_asg.business_group_id;
            --
            if (csr_asg.effective_start_date < p_effective_date and csr_asg.effective_end_date = '31-dec-4712') then
            l_datetrack_mode := 'UPDATE';            rec_effective_date := p_effective_date;
            elsif (csr_asg.effective_start_date < p_effective_date and csr_asg.effective_end_date < '31-dec-4712') then
            l_datetrack_mode := 'UPDATE_CHANGE_INSERT';
            rec_effective_date := p_effective_date;
            else
            l_datetrack_mode := 'CORRECTION';
            rec_effective_date := csr_asg.effective_start_date;
            end if;
            --
            write_trace('l_datetrack_mode' , l_datetrack_mode);
            --
            write_trace('l_ovn', l_ovn);
            --
            hr_assignment_api.update_emp_asg_criteria
        	        (p_effective_date               => rec_effective_date
        	        ,p_datetrack_update_mode        => l_datetrack_mode
        	        ,p_assignment_id                => csr_asg.assignment_id
        	        ,p_validate                     => FALSE
        	      --  ,p_called_from_mass_update      => l_called_from_mass_update
        	        ,p_grade_id                     => csr_asg.grade_id
        	        ,p_position_id                  => null
        	        ,p_job_id                       => csr_asg.job_id
        	       /* ,p_payroll_id                   => csr_asg.payroll_id
        	        ,p_location_id                  => csr_asg.location_id
        	        ,p_organization_id              => csr_asg.organization_id
        	        ,p_pay_basis_id                 => csr_asg.pay_basis_id
        	        ,p_segment1                     => csr_asg.ppg_segment1
        	        ,p_segment2                     => csr_asg.ppg_segment2
        	        ,p_segment3                     => csr_asg.ppg_segment3
        	        ,p_segment4                     => csr_asg.ppg_segment4
        	        ,p_segment5                     => csr_asg.ppg_segment5
        	        ,p_segment6                     => csr_asg.ppg_segment6
        	        ,p_segment7                     => csr_asg.ppg_segment7
        	        ,p_segment8                     => csr_asg.ppg_segment8
        	        ,p_segment9                     => csr_asg.ppg_segment9
        	        ,p_segment10                    => csr_asg.ppg_segment10
        	        ,p_segment11                    => csr_asg.ppg_segment11
        	        ,p_segment12                    => csr_asg.ppg_segment12
        	        ,p_segment13                    => csr_asg.ppg_segment13
        	        ,p_segment14                    => csr_asg.ppg_segment14
        	        ,p_segment15                    => csr_asg.ppg_segment15
        	        ,p_segment16                    => csr_asg.ppg_segment16
        	        ,p_segment17                    => csr_asg.ppg_segment17
        	        ,p_segment18                    => csr_asg.ppg_segment18
        	        ,p_segment19                    => csr_asg.ppg_segment19
        	        ,p_segment20                    => csr_asg.ppg_segment20
        	        ,p_segment21                    => csr_asg.ppg_segment21
        	        ,p_segment22                    => csr_asg.ppg_segment22
        	        ,p_segment23                    => csr_asg.ppg_segment23
        	        ,p_segment24                    => csr_asg.ppg_segment24
        	        ,p_segment25                    => csr_asg.ppg_segment25
        	        ,p_segment26                    => csr_asg.ppg_segment26
        	        ,p_segment27                    => csr_asg.ppg_segment27
        	        ,p_segment28                    => csr_asg.ppg_segment28
        	        ,p_segment29                    => csr_asg.ppg_segment29
        	        ,p_segment30                    => csr_asg.ppg_segment30
        	        ,p_employment_category          => csr_asg.employment_category
        	        ,p_concat_segments              => csr_asg.concat_segments
        	        ,p_contract_id                  => csr_asg.contract_id
        	        ,p_establishment_id             => csr_asg.establishment_id
        	        ,p_scl_segment1                 => csr_asg.scl_segment1
        	        ,p_grade_ladder_pgm_id          => csr_asg.grade_ladder_pgm_id
        	        ,p_supervisor_assignment_id     => csr_asg.supervisor_assignment_id  */
                    --
                    -- in out
                    --
        	        ,p_object_version_number        => l_ovn
        	        ,p_special_ceiling_step_id      => l_special_ceiling_step_id
        	        ,p_people_group_id              => l_people_group_id
        	        ,p_soft_coding_keyflex_id       => l_soft_coding_keyflex_id
                    --
                    -- out
                    --
        	        ,p_group_name                   => l_group_name
        	        ,p_effective_start_date         => l_effective_start_date
        	        ,p_effective_end_date           => l_effective_end_date
        	        ,p_org_now_no_manager_warning   => l_org_now_no_manager_warning
        	        ,p_other_manager_warning        => l_other_manager_warning
        	        ,p_spp_delete_warning           => l_spp_delete_warning
        	        ,p_entries_changed_warning      => l_entries_changed_warning
        	        ,p_tax_district_changed_warning => l_tax_district_changed_warning
        	        ,p_concatenated_segments        => l_concatenated_segments
          		    ,p_gsp_post_process_warning     => l_gsp_post_process_warning
                    );
              --
              update xxhae_hr_job_cnv_tbl
              set cnv_asg_status = 'C'
              where employee_number = csr_asg.employee_number
                and business_group = csr_asg.business_group;
              --
       exception
       --
       when others then
       --
       rollback;
       --
       l_message := g_api || substr(sqlerrm, 1, 2000);
       --
       update xxhae_hr_job_cnv_tbl
       set cnv_asg_status = 'E',
           cnv_message = l_message
       where employee_number = csr_asg.employee_number
          and business_group = csr_asg.business_group;
       --
       commit;
       --
       raise;
       --
       end;
    end loop;
   --
   write_trace('Leaving: ' || l_procedure, 999);
   --
end convert_assignments;
--
procedure end_positions(retcode             out number
              ,errbuf              out varchar2
              ,p_effective_date    in varchar2
              ,p_validate          in varchar2
              ,p_debug	           varchar2 default 'N'
              ) is
              /*(p_employee_number varchar2,
                        p_effective_date  date)*/
--
  cursor csr_positions (cp_effective_date date)
  is
  select pos.position_id, pos.object_version_number, xxhae.employee_number, xxhae.business_group,
         position_definition_id, name
  from hr_all_positions_f pos,
       xxhae_hr_job_cnv_tbl xxhae
  where /*employee_number = nvl(p_employee_number, employee_number)
  and */pos.availability_status_id = 1
  and cp_effective_date between pos.effective_start_date and pos.effective_end_Date
  and pos.business_group_id = xxhae.business_group_id
  and  nvl(xxhae.cnv_position_status, 'X') <> 'C'
  and  nvl(xxhae.cnv_status, 'X') = 'C'
  and pos.position_id = xxhae.position_id;
--
l_ovn                       number;
l_exists                    number;
l_effective_start_date      date;
l_effective_end_date        date;
l_pos_def_id                number;
l_warning1                  boolean;
l_effective_Date            date := to_date(p_effective_date, 'YYYY/MM/DD HH24:MI:SS');
l_name                      varchar2(150);
l_message                   varchar2(4000);
l_procedure	            varchar2(100);
next_rec                    exception;
--
begin
    --
    g_debug := p_debug;
    --
    fnd_file.put_line(fnd_file.log, '=====================Parameters=====================');
    fnd_file.put_line(fnd_file.log, 'Effective Date			: ' || p_effective_date);
    fnd_file.put_line(fnd_file.log, 'Validate Mode(Y/N)?		: ' || p_validate);
    fnd_file.put_line(fnd_file.log, 'Debug (Y/N)?			: ' || p_debug);
    fnd_file.put_line(fnd_file.log, '====================================================');
    --
    l_procedure := g_package || 'end_positions';
    --
    g_api := 'hr_position_api.update_position - ';
    --
    write_trace('Entering: '|| l_procedure, 10);
    --
    for csr_rec in csr_positions (l_effective_date)
    loop
        begin
            write_trace('==========================================================', null);
            write_trace('         Processing Employee Number  ' || csr_rec.employee_number, null);
            write_trace('==========================================================', null);
            --
            l_ovn := csr_rec.object_version_number;
            l_pos_def_id := csr_Rec.position_definition_id;
            l_name       := csr_rec.name;
            --
            write_trace('Position_id', csr_Rec.position_id);
            write_trace('ovn', l_ovn);
            --
            --check if position has alreaday been eliminated.
            --
            begin
              select 1
              into l_exists
              from hr_All_positions_f
              where position_id = csr_Rec.position_id
               and availability_status_id = 1
               and l_effective_date between effective_start_Date and effective_end_date;
           exception when others then
            raise next_rec; --position has already been eliminated.
           end;
    /*        hr_position_api.delete_position
                  (p_validate                    => false
                  ,p_position_id                 => csr_rec.position_id
                  ,p_effective_start_date        => l_effective_start_date
                  ,p_effective_end_date          => l_effective_end_Date
                  ,p_object_version_number       => l_ovn
                  ,p_effective_date              => p_effective_date
                  ,p_datetrack_mode              => 'DELETE'
                  --,p_security_profile_id
                  );*/
            --
            hr_position_api.update_position
                  (p_validate                     => false
                  ,p_position_id                 => csr_rec.position_id
                  ,p_effective_start_date        => l_effective_start_date
                  ,p_effective_end_date          => l_effective_end_Date
                  ,p_position_definition_id      => l_pos_def_id
                  ,p_valid_grades_changed_warning => l_warning1
                  ,p_name                         => l_name
                  ,p_availability_status_id      => 5
                  ,p_object_version_number       => l_ovn
                  ,p_effective_date              => l_effective_Date
                  ,p_datetrack_mode              => 'UPDATE'
                  );
            write_trace(l_procedure, 30);
            --
            update xxhae_hr_job_cnv_tbl
            set cnv_position_status = 'C'
            where employee_number = csr_rec.employee_number
              and business_group = csr_rec.business_group;
           --
           if upper(nvl(p_validate, 'Y')) = 'N' then
              commit;
           else
              rollback;
           end if;
           --
       exception
       --
       when next_rec then
        write_trace(l_procedure, 40);
        --
        update xxhae_hr_job_cnv_tbl
        set cnv_position_status = 'C'
        where employee_number = csr_rec.employee_number
        and business_group = csr_rec.business_group;
       --
       when others then
       --
       l_message := g_api || substr(sqlerrm, 1, 2000);
       --
       rollback;
       --
       update xxhae_hr_job_cnv_tbl
       set cnv_position_status = 'E',
           cnv_message = l_message
       where employee_number = csr_rec.employee_number
          and business_group = csr_rec.business_group;
       --
       commit;
       --
       end;
    end loop;
   --
   write_trace('Leaving: ' || l_procedure, 999);
   --
end;
--
procedure convert_data(p_effective_date     date
                      ,p_validate			varchar2
                      ,p_employee_number	varchar2
                      ,p_jobs_only          varchar2
                      )
is
--
cursor csr_unique_employee is
select employee_number
from  xxhae_hr_job_cnv_tbl xxhae
where employee_number = nvl(p_employee_number, employee_number)
  and  nvl(xxhae.cnv_status, 'X') <> 'C';
--
l_message           varchar2(4000);
--
begin
   --
   write_trace('Entering: convert_data', 10);
   --
    for csr_rec in csr_unique_employee
    loop
        --
        begin
            --
            write_trace('==========================================================', null);
            write_trace('         Processing Employee Number  ' || csr_rec.employee_number, null);
            write_trace('==========================================================', null);
            --
            if upper(nvl(p_validate,'Y')) = 'Y' then
                --
                update xxhae_hr_job_cnv_tbl
                set cnv_status = 'U'
                   ,cnv_message = null
                where employee_number = csr_rec.employee_number
                 and cnv_status = 'E';
                 --
                 commit;
                --
             end if;
            --
            update_job_string(csr_rec.employee_number, p_effective_date);
            --
            create_jobs(csr_rec.employee_number, p_effective_date);
            --
            update_valid_grades(csr_rec.employee_number, p_effective_date);
            --
            if p_jobs_only = 'N' then
            --
            convert_assignments(csr_rec.employee_number, p_effective_date);
            --
          --  end_positions(csr_rec.employee_number, p_effective_date);
            --
            update xxhae_hr_job_cnv_tbl
            set cnv_status = 'C'
            where employee_number = csr_rec.employee_number
             and cnv_asg_status = 'C';
            --
            end if;
            --
        exception when others then
               --
               rollback;
               --
               update xxhae_hr_job_cnv_tbl
               set    cnv_status = 'E'
               where  employee_number = csr_rec.employee_number;
               --
               commit;
               --
        end;
     --
     if upper(nvl(p_validate, 'Y')) = 'N' then
       commit;
     else
       rollback;
     end if;
     --
    end loop;
   --
   write_trace('Leaving: convert_data', 999);
exception
when others then
dbms_output.put_line('error in convert data' || sqlerrm);
end convert_data;
--
procedure run_error_report(p_employee_number  varchar2) is
--
cursor csr_errors is
select *
from   xxhae_hr_job_cnv_tbl xxhae
where  employee_number = nvl(p_employee_number, employee_number)
and    cnv_status = 'E';
--
begin
   --
   fnd_file.put_line(fnd_file.output, '=====================================================================================================================================================');
   fnd_file.put_line(fnd_file.output, '========================================================<< Conversion Summary Error Report >>========================================================');
   fnd_file.put_line(fnd_file.output, '=====================================================================================================================================================');
   fnd_file.put_line(fnd_file.output, 'Employee Number          Job Name          Business Group ID          Error Message');
   fnd_file.put_line(fnd_file.output, '=====================================================================================================================================================');
   --
   for csr_err in csr_errors
   loop
      begin
         --
         fnd_file.put_line(fnd_file.output, rpad(csr_err.employee_number, 20, ' ')	 ||
						                    rpad(csr_err.job_name, 34, ' ')	         ||
						                    rpad(csr_err.business_group_id, 27, ' ') ||
                                            csr_err.cnv_message
                          );
         --
      end;
   end loop;
--
end run_error_report;
--
procedure insert_po_approval_groups
              (retcode             out number
              ,errbuf              out varchar2
              ,p_validate          varchar2
              ) is
--
begin
  --
     insert into xxha_po_approval_assign_tbl poa
          (operating_unit, job_code, document_type, approval_group, start_date, end_date, process_date, status, error_msg)
          (select distinct org.name operating_unit
          , j2.name job
          , f.CONTROL_FUNCTION_NAME document_type
          , g.CONTROL_GROUP_NAME approval_group
          , to_date(null) start_date
          , to_date(null) end_date
          , to_date(null) process_date
          , null status
          , null err_msg
          from PO_POSITION_CONTROLS_all p
          , per_jobs j
          , PO_CONTROL_GROUPS_all g
          , PO_CONTROL_functions f
          , hr_all_organization_units org
          , per_job_definitions jd
          , per_job_definitions jd2
          , per_jobs j2
          where p.job_id = j.job_id
          and sysdate between p.START_DATE and nvl(p.end_date,sysdate)
          and p.CONTROL_GROUP_ID = g.CONTROL_GROUP_ID
          and p.CONTROL_FUNCTION_ID = f.CONTROL_FUNCTION_ID
          and f.ENABLED_FLAG = 'Y'
          and g.ENABLED_FLAG = 'Y'
          and p.org_id = org.organization_id
          and g.org_id = org.organization_id
          and jd.job_definition_id = j.job_definition_id
          and jd.segment2 = jd2.segment2
          and j.job_id <> j2.job_id
          and j.business_group_id = j2.business_group_id
          and jd2.job_definition_id = j2.job_definition_id
          and not exists (select null
                          from PO_POSITION_CONTROLS_all p2
                          where p2.job_id = j2.job_id));
     --
     if upper(nvl(p_validate, 'Y')) = 'N' then
       commit;
     else
       rollback;
     end if;
--
exception
  when others then
  errbuf := 'Error in insert_po_approval_groups: ' || sqlerrm;
  retcode := 2;
end insert_po_approval_groups;
--
procedure convert_old_jobs
              (retcode             out number
              ,errbuf              out varchar2
              ,p_effective_date    in varchar2
              ,p_validate          in varchar2
              ,p_debug	           varchar2 default 'N'
              ) is
 --
 cursor csr_old_jobs
 is
 select pj.job_id, pj.name, pj.job_definition_id, pj.object_version_number, pjd.segment1,
        pjd.segment2, pjd.segment3, pjd.segment4, pjd.segment5, pj.date_from
 from per_jobs pj,
      per_job_definitions pjd
 where pjd.job_definition_id = pj.job_definition_id
   --and job_id in (20062,38067)-- 38067--38063
   and (pjd.segment1 is null
     or pjd.segment3 is null
     or pjd.segment4 is null
     or pjd.segment5 is null
     );
 --
 l_effective_date  date := to_date(p_effective_date, 'YYYY/MM/DD HH24:MI:SS');
 l_ovn             number;
 l_job_def_id      number;
 l_name            varchar2(150);
 l_warning         boolean;
 l_job_code        varchar2(150);
 l_job_level       varchar2(150);
 l_job_family      varchar2(150);
 l_job_labor       varchar2(150);
 --
 begin
    --
    g_debug := p_debug;
    --
    fnd_file.put_line(fnd_file.log, '=====================Parameters=====================');
    fnd_file.put_line(fnd_file.log, 'Effective Date			: ' || p_effective_date);
    fnd_file.put_line(fnd_file.log, 'Validate Mode(Y/N)?		: ' || p_validate);
    fnd_file.put_line(fnd_file.log, 'Debug (Y/N)?			: ' || p_debug);
    fnd_file.put_line(fnd_file.log, '====================================================');
    --
    for csr_job in csr_old_jobs
    loop
        begin
            --
            write_trace('==========================================================', null);
            write_trace('         Processing Job  ' || csr_job.name, null);
            write_trace('==========================================================', null);
            --
            l_ovn := csr_job.object_version_number;
            l_job_def_id := null;--csr_job.job_definition_id;
            --
            if csr_job.segment1 is null then
                csr_job.segment1 := 'NA';
            end if;
            --
            if csr_job.segment3 is null then
                csr_job.segment3 := 'NA';
            end if;
            --
            if csr_job.segment4 is null then
                csr_job.segment4 := 'NA';
            end if;
            --
            if csr_job.segment5 is null then
                csr_job.segment5 := 'NA';--'NA';
            end if;
            --
            write_trace('Job ID', csr_job.job_id);
            write_trace('Job def ID', l_job_def_id);
            write_trace('segment1', csr_job.segment1);
            write_trace('segment2', csr_job.segment2);
            write_trace('segment3', csr_job.segment3);
            write_trace('segment4', csr_job.segment4);
            write_trace('segment5', csr_job.segment5);
            --
            hr_job_api.UPDATE_JOB(
               p_validate                      => false
              ,p_job_id                        => csr_job.job_id
              ,p_object_version_number         => l_ovn
              ,p_segment1                      => csr_job.segment1
              ,p_segment2                      => csr_job.segment2
              ,p_segment3                      => csr_job.segment3
              ,p_segment4                      => csr_job.segment4
              ,p_segment5                      => csr_job.segment5
              ,p_job_definition_id             => l_job_def_id
              ,p_name                          => l_name
              ,p_valid_grades_changed_warning  => l_warning
            --  ,p_effective_date                =>l_effective_Date-- csr_job.date_from
              );
            --
        exception when others then
           fnd_file.put_line(fnd_file.log, csr_job.name || ' Error: ' || sqlerrm);
        end;
        --
        if upper(nvl(p_validate, 'Y')) = 'N' then
         commit;
        else
         rollback;
        end if;
        --
    end loop;
    --
 end convert_old_jobs;
--
procedure main(retcode             out number
              ,errbuf              out varchar2
              ,p_business_group_id in number
              ,p_effective_date    in varchar2
              ,p_validate 		   varchar2 default 'Y'
              ,p_jobs_only         varchar2 default 'N'
              ,p_debug			   varchar2 default 'N'
              ,p_employee_number   varchar2 default null
              ) is
 --
 l_effective_date  date := to_date(p_effective_date, 'YYYY/MM/DD HH24:MI:SS');
 --
 begin
    --
    g_debug := p_debug;
    --
    write_trace('Entering: Main', 10);
    --
    fnd_file.put_line(fnd_file.log, '=====================Parameters=====================');
    fnd_file.put_line(fnd_file.log, 'Business Group id 		: ' || p_business_group_id);
    fnd_file.put_line(fnd_file.log, 'Effective Date			: ' || p_effective_date);
    fnd_file.put_line(fnd_file.log, 'Validate Mode(Y/N)?		: ' || p_validate);
    fnd_file.put_line(fnd_file.log, 'Debug (Y/N)?			: ' || p_debug);
    fnd_file.put_line(fnd_file.log, 'Employee Number		: ' || p_employee_number);
    fnd_file.put_line(fnd_file.log, '====================================================');
    --
   -- convert_old_jobs(l_effective_Date, p_validate);
    --
    convert_data(l_effective_date, p_validate, p_employee_number,p_jobs_only);
    --
    if p_jobs_only = 'Y' then
      insert_po_approval_groups(retcode, errbuf, p_validate);
    end if;
    --
    --end_positions(null, p_effective_date);
    --
    run_error_report(p_employee_number);
    --
    write_trace('Leaving: Main End of Conversion !!!', 999);
    --
 end main;
--
end xxhae_hr_job_cnv_pkg;

/
