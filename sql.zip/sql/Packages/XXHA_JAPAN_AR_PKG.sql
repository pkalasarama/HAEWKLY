create or replace PACKAGE XXHA_JAPAN_AR_PKG AS 

/*****************************************************************************************
* Package Name : XXHA_JAPAN_AR_PKG                                                       *
* Purpose      : This package will process the data in the table                         *
*               'HAEMO.XXHA_JAPAN_AR_ZENGIN_TBL'.                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        17-DEC-2014     Bruce Marcoux        Initial Creation                       *
*                                                                                        *
*****************************************************************************************/

-- Global Variable Declaration
g_remit_bank_account_id                                          AR_CASH_RECEIPTS_ALL.remit_bank_acct_use_id%TYPE;
g_rcpt_method_id                                                 AR_CASH_RECEIPTS_ALL.receipt_method_id%TYPE;

PROCEDURE XXHA_MAIN_FUNC(
                      x_errbuf                              OUT  VARCHAR2
                    , x_retcode                             OUT  VARCHAR2
                    , p_remit_bank_account_id               IN   NUMBER
                    , p_rcpt_method_id                      IN   NUMBER
                        );

PROCEDURE XXHA_DETERMINE_CBI_PROCESS(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    , p_CBIA_CUSTOMER_PRIORITY                   NUMBER
                      );

PROCEDURE XXHA_CBI_P1(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P2(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P3(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P4(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P5(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P6(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P7(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P8(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P9(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P10(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P11(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    );

PROCEDURE XXHA_CBI_P12(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CBI_ACCOUNT_NUMBER                       NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID                 NUMBER
                    , p_CUSTOMER_NAME_BANKING                    VARCHAR2
                    , p_MULTCUST_COUNT                           NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT                     NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING                 NUMBER
                    , p_CUSTOMER_JRC                             VARCHAR2
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    , p_CBIA_CUSTOMER_PRIORITY                   NUMBER
                    );

PROCEDURE XXHA_WRITE_OUTPUT(
                      p_CBI_CONS_INV_ID                          NUMBER
                    , p_CUSTOMER_NUMBER                          NUMBER
                    , p_RECEIPT_AMOUNT                           NUMBER
                    , p_BANK_CHARGE                              NUMBER
                    , p_DATE_YYYYMMDD                            NUMBER
                    , p_DATE_DDMONYY                             DATE
                    , p_NUMBER                                   NUMBER
                    , p_CASH_RECEIPT_ID                          NUMBER
                    , p_ALERT                                    VARCHAR2
                    , p_ERROR                                    VARCHAR2
                    );

PROCEDURE XXHA_FIND_MATCH_CBI_AMT_JRC(
                      p_CUSTOMER_NAME_BANKING                IN  VARCHAR2
                    , p_TOTAL_RECEIPT_AMOUNT                 IN  NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING            OUT  NUMBER
                    , p_CUSTOMER_NUMBER                     OUT  NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID            OUT  NUMBER
                    , p_CBI_CONS_INV_ID                     OUT  NUMBER
                    , p_multi_matching_CBI_found            OUT  VARCHAR2
                    );

PROCEDURE XXHA_FIND_MATCH_CBI_AMT_NONJRC(
                      p_CUSTOMER_NAME_BANKING                IN  VARCHAR2
                    , p_TOTAL_RECEIPT_AMOUNT                 IN  NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING            OUT  NUMBER
                    , p_CUSTOMER_NUMBER                     OUT  NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID            OUT  NUMBER
                    , p_CBI_CONS_INV_ID                     OUT  NUMBER
                    , p_multi_matching_CBI_found            OUT  VARCHAR2
                    );
END XXHA_JAPAN_AR_PKG;