create or replace PACKAGE XXHA_SERVICEREP_IS_EMPLOYEE AS
/**********************************************************************************************************************************
 *
 * Package Name : XXHA_SERVICEREP_IS_EMPLOYEE
 * Description:  This function will determine if a SalesRep is still an employee.  
 *               It is used by the Concurrent Program, 'XXHA: SubInventory Assignments Report US'. (XXHA_SubInventoryAssignments.rdf)
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 * -------------   -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      05-MAY-2015     Initial Function Creation
 *
 **********************************************************************************************************************************/

FUNCTION SERVICEREP_IS_EMP(p_Resource_ID IN NUMBER, p_Subinventory_Code IN VARCHAR2) RETURN VARCHAR2;

END XXHA_SERVICEREP_IS_EMPLOYEE;