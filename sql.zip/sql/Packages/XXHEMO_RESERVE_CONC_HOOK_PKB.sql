
CREATE OR REPLACE PACKAGE BODY "APPS"."XXHEMO_RESERVE_CONC_HOOK" 
    /* ******************************************************************************************************
    * Object Name: XXHEMO_RESERVE_CONC_HOOK
    * Object Type: PACKAGE
    *
    * Description: This Package is for reserve order based on outbound exception items
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/
AS
  /* $Header: OEXRSHOB.pls 120.0 2005/06/01 00:11:34 appldev noship $ */
  --  Global constant holding the package name
  G_PKG_NAME CONSTANT VARCHAR2(30) := 'XXHEMO_RESERVE_CONC_HOOK';
PROCEDURE Qty_Per_Business_Rule(
    p_x_rsv_tbl IN OUT NOCOPY
    /* file.sql.39 change */
    xxhemo_RESERVE_CONC.rsv_tbl_type)
IS
BEGIN
  -- Write your code here
  NULL;
END Qty_Per_Business_Rule;
PROCEDURE Simulated_Results(
    p_x_rsv_tbl IN OUT NOCOPY
    /* file.sql.39 change */
    xxhemo_RESERVE_CONC.rsv_tbl_type)
IS
BEGIN
  -- Write your code here
  NULL;
END Simulated_Results;
END XXHEMO_RESERVE_CONC_HOOK;
/