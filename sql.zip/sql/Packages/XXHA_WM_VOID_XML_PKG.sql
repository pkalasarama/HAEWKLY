/*******************************************************************************************************
    * Object Name: XXHA_WM_VOID_XML_PKG
    * Object Type: Package
    * Description: This package is created for parcel overpack void requirement
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    05-FEB-2015          Initial object creation.
*******************************************************************************************************/ 

create or replace 
PACKAGE        "XXHA_WM_VOID_XML_PKG" 
AS
PROCEDURE  XXHA_WM_VOID_XML(
    p_delivery_id NUMBER);
END;
/
create or replace 
PACKAGE BODY        "XXHA_WM_VOID_XML_PKG" 
AS
PROCEDURE XXHA_WM_VOID_XML(
    p_delivery_id NUMBER)
AS
  p_rec_wm_trackChange wm_trackchanges%ROWTYPE;
  c_transaction_type VARCHAR2(100) :='VOIDXML';
  l_err              VARCHAR2(100);
BEGIN
  p_rec_wm_trackChange.transaction_type   := c_transaction_type;
  p_rec_wm_trackChange.date_created       := SYSDATE;
  p_rec_wm_trackChange.processed_flag     := 'N';
  p_rec_wm_trackChange.transaction_id     :=p_delivery_id;
  p_rec_wm_trackChange.comments           :='DELIVERY DETAILS INSERT FOR '|| p_delivery_id;
  p_rec_wm_trackChange.transaction_status := 1;
  -- Call Procedure to Insert into wm_track_changes
  wm_track_changes_pkg.web_transaction(p_rec_wm_trackChange);
  COMMIT;
EXCEPTION
WHEN OTHERS THEN
  NULL;
END;
END XXHA_WM_VOID_XML_PKG;
/