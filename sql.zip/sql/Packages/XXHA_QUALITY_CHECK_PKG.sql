CREATE OR REPLACE PACKAGE XXHA_QUALITY_CHECK_PKG AS

  PROCEDURE CHECK_BSA_NUMBER(x_return_status            OUT NOCOPY VARCHAR2,
                             p_chr_id                   IN  NUMBER);

  PROCEDURE CHECK_CONTADMIN(x_return_status            OUT NOCOPY VARCHAR2,
                             p_chr_id                      IN  NUMBER);


END XXHA_QUALITY_CHECK_PKG;

/


CREATE OR REPLACE PACKAGE BODY XXHA_QUALITY_CHECK_PKG AS
PROCEDURE CHECK_BSA_NUMBER(x_return_status            OUT NOCOPY VARCHAR2,
                             p_chr_id                   IN  NUMBER) IS
l_return_status	VARCHAR2(20) := OKC_API.G_RET_STS_SUCCESS;
    l_bsa_number        VARCHAR2(10) :=0;
BEGIN
BEGIN
SELECT NVL(OkH.ATTRIBUTE2, 0)
         INTO l_bsa_number
/* R12 Upgrade Modified on 09/28/2012 by Venkatesh Sarangam, Rolta */
--       FROM okc_k_headers_b OKH
         FROM okc_k_headers_all_b OKH
        WHERE OKH.id = p_chr_id
          AND NVL(OKH.template_yn, 'N') = 'N';
EXCEPTION WHEN OTHERS THEN
x_return_status := OKC_API.G_RET_STS_ERROR;
OKC_API.set_message(p_app_name     => 'OKC',
                            p_msg_name     => 'XXHA_OKC_QA_BSA_REQUIRED');
END;
IF l_bsa_number = 0 or l_bsa_number is NULL THEN
x_return_status := OKC_API.G_RET_STS_ERROR;
      OKC_API.set_message(
        p_app_name     => 'OKC',
        p_msg_name     => 'XXHA_OKC_QA_BSA_REQUIRED');

    ELSE
x_return_status := l_return_status;
 END IF;
 EXCEPTION WHEN OTHERS  THEN
 x_return_status := OKC_API.G_RET_STS_ERROR;
OKC_API.set_message(
        p_app_name     => 'OKC',
        p_msg_name     => 'XXHA_OKC_QA_BSA_REQUIRED');
END CHECK_BSA_NUMBER;
PROCEDURE CHECK_CONTADMIN(x_return_status            OUT NOCOPY VARCHAR2,
                            p_chr_id                      IN  NUMBER) AS
l_return_status	VARCHAR2(20) := OKC_API.G_RET_STS_SUCCESS;
    ln_cont_admin        NUMBER;
BEGIN
BEGIN
SELECT 1
     INTO   ln_cont_admin
     FROM   okc_k_party_roles_b okp
           ,okc_contacts oc
     WHERE  okp.id = oc.cpl_id
     AND    okp.rle_code = 'VENDOR'
     AND    oc.CRO_CODE = 'ADMIN'
     AND    okp.chr_id = p_chr_id;
EXCEPTION WHEN NO_DATA_FOUND THEN
x_return_status := OKC_API.G_RET_STS_ERROR;
OKC_API.set_message(
        p_app_name     => 'OKC',
        p_msg_name     => 'XXHA_OKC_QA_CONTADMIN_REQUIRED');
END;
IF ln_cont_admin = 1 THEN
x_return_status := l_return_status;
END IF;
END CHECK_CONTADMIN;
END XXHA_QUALITY_CHECK_PKG;
/
