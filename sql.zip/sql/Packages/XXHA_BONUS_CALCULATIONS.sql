CREATE OR REPLACE PACKAGE XXHA_BONUS_CALCULATIONS
AS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_BONUS_CALCULATIONS
*  Description:
*      This package is written to calculat bonus and move to EIT
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*
******************************************************************************/


PROCEDURE CALCULATE_AND_MOVE(errbuf OUT VARCHAR2, retcode OUT NUMBER, P_YEAR VARCHAR2, P_CURRENCY VARCHAR2);
PROCEDURE INITIALIZE_EIT(errbuf OUT VARCHAR2, retcode OUT NUMBER, P_YEAR VARCHAR2, P_CURRENCY VARCHAR2);
END;

/


CREATE OR REPLACE PACKAGE BODY XXHA_BONUS_CALCULATIONS
AS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_BONUS_CALCULATIONS
*  Procedure:  CALCULATE_AND_MOVE
*  Description:
*      This package is written to calculat bonus and move to EIT
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*  07-May-2008       Milan Parihar       Corrected code for VARCHAR to NUMBER  
*                                        conversion error.
*
******************************************************************************/


PROCEDURE CALCULATE_AND_MOVE( errbuf OUT VARCHAR2, retcode OUT NUMBER,P_YEAR VARCHAR2, P_CURRENCY VARCHAR2)
AS
/* Current Year In Grade attribute5  moved to EIT PEI_INFORMATION1 read only */
 l_year   VARCHAR2(150)  := P_YEAR;
/* Global Value moved to EIT read only to PEI_INFORMATION2 */
 l_currency VARCHAR2(150) DEFAULT NULL;
/*In Grade WW Target Bonus Potential Percentage ATTRIBUTE3 */
 l_ww_tgt_bonus_potn_perc    VARCHAR2(150) DEFAULT NULL;
/* Amount calculated stored in EIT PEI_INFORMATION4, calculation l_ww_tgt_bonus_potn_perc
 * ANnual Salary */
 l_target_bonus NUMBER DEFAULT NULL;
 /*Manually entered by Administrator in PUI EIT FORM PEI_INFORMATION4 */
 l_prorated_bonus NUMBER DEFAULT NULL;
 /*Manually entered in Grade ATTRIBUTE1 Corporate%  */
 l_corporate_percent   VARCHAR2(150) DEFAULT NULL;
 /*Manually entered in Grade ATTRIBUTE2 REgional%  */
 l_regional_percent   VARCHAR2(150) DEFAULT NULL;
 /*Manually entered in Grade ATTRIBUTE3  Region Name  */
 l_region_name   VARCHAR2(150) DEFAULT NULL;
 /*Manually entered in Grade ATTRIBUTE4  Individual%  */
 l_individual_percent   VARCHAR2(150) DEFAULT NULL;
 l_individual_achievement   VARCHAR2(150) DEFAULT NULL;
 l_person_id NUMBER;
 l_information_type         VARCHAR2(30) DEFAULT 'HAE_BONUS_GLB'  ;
 l_pei_information_category VARCHAR2(30) DEFAULT 'HAE_BONUS_GLB'  ;
 l_corp_target_amt number DEFAULT NULL;
 l_corp_bonus_payout VARCHAR2(150) DEFAULT NULL;
 l_tot_bonus_payout NUMBER;
 l_corp_oper_income NUMBER;
 l_corp_revenue NUMBER;
 l_ind_target_amt VARCHAR2(150) DEFAULT NULL;
 l_ind_bonus_payout VARCHAR2(150) DEFAULT NULL;
 l_reg_target_amt VARCHAR2(150) DEFAULT NULL;
 l_reg_revenue NUMBER  DEFAULT NULL;
 l_reg_operating_income  NUMBER  DEFAULT NULL;
 l_reg_bonus_payout VARCHAR2(150) DEFAULT NULL;
 l_salary NUMBER DEFAULT NULL;
 l_person_extra_info_id      NUMBER;
 l_object_version_number    NUMBER;
 l_grade_name VARCHAR2(150) DEFAULT NULL;
 L_REGION_VALUE VARCHAR2(150);
 L_REGION_VALUE_OI VARCHAR2(150);
 L_REGION_VALUE_REV VARCHAR2(150);




CURSOR csr_get_grade_info
IS
   SELECT ppf.PERSON_ID,
          PPF.BUSINESS_GROUP_ID ,
          ppf.employee_number,
          NVL (ppb.pay_annualization_factor,0),
          NVL (ppei.pei_information3, '0') WW_BONUS_TGT_TOT_POTN,
          NVL (ppei.pei_information6, '0') WW_BONUS_TGT_CORP,
          NVL (ppei.pei_information7, '0') WW_BONUS_TGT_REG ,
          NVL (ppei.pei_information8, '0') WW_BONUS_TGT_IND ,
          NVL( ppei.PEI_INFORMATION9, '0') Individual_Achievment,
          to_number(nvl(ppei.PEI_INFORMATION5, '0')) Prorated_Bonus,
          ppei.object_version_number,
          ppei.PERSON_EXTRA_INFO_ID,
          NVL (GRD.NAME, '0')    GRADE_NAME ,
          NVL (  ppp.proposed_salary_n ,0),
          (trunc(ppb.pay_annualization_factor) *    trunc(ppp.proposed_salary_n) )  annual_salary ,
          ppg.segment1      region
     FROM PER_GRADES GRD,
          PER_ALL_ASSIGNMENTS_F ASSIGN,
          per_all_people_f ppf ,
          per_pay_proposals ppp,
          per_pay_bases ppb ,
          per_people_extra_info ppei,
          pay_people_groups ppg
    WHERE GRD.GRADE_ID = ASSIGN.GRADE_ID
      and ppf.person_id = ASSIGN.person_id
      and ASSIGN.People_Group_Id = ppg.people_group_id
      AND TRUNC(SYSDATE) BETWEEN ppf.effective_start_date AND ppf.effective_end_date
      AND TRUNC(SYSDATE) BETWEEN ASSIGN.effective_start_date AND ASSIGN.effective_end_date
      AND ppei.person_id = ppf.person_id
      AND ppei.information_type = l_information_type
      AND ppei.pei_information1 = p_year
      AND ppp.assignment_id = ASSIGN.assignment_id
      AND ppp.change_date = ( select max(pp1.change_date )
                                from per_pay_proposals pp1
                               where pp1.assignment_id = ppp.assignment_id )
      and ppb.pay_basis_id = ASSIGN.pay_basis_id;

-- CURSOR  for globals
CURSOR c_global( p_date DATE, P_NAME VARCHAR2)
IS
   SELECT TO_NUMBER(GLOBAL_VALUE) global_value
     FROM FF_GLOBALS_F
    WHERE GLOBAL_NAME = P_NAME
      AND p_date BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE;
--

CURSOR c_table_values( P_ROW VARCHAR2 , P_COLUMN VARCHAR2 , P_BUSINESS_GROUP_ID NUMBER)
IS
   SELECT C.VALUE
     FROM  pay_user_tables a,
           pay_user_columns b,
           pay_user_column_instances_v2 c
    WHERE  A.USER_TABLE_NAME = 'HAE WW Bonus Table'
      and a.user_table_id = b.user_table_id
      and b.user_column_id = c.user_column_id
      and trunc(sysdate ) between c.effective_start_date and c.effective_end_date
      AND c.ROW_LOW_RANGE_OR_NAME = P_ROW
      AND b.user_column_name = P_COLUMN
      AND A.BUSINESS_GROUP_ID = B.BUSINESS_GROUP_ID
      AND B.BUSINESS_GROUP_ID = C.BUSINESS_GROUP_ID
      -- hard coded to zero as we don't have to define table "HAE WW Bonus Table" for all Business Groups
      AND C.BUSINESS_GROUP_ID = 0
 ;

 ---
FUNCTION GET_GLOBAL_VALUE( P_DATE DATE, P_NAME VARCHAR2)
 RETURN NUMBER
 IS

L_RETURN_VAL NUMBER;

BEGIN

FOR C_GLOB_REC IN c_global(p_date, p_name)
loop
   l_return_val := C_GLOB_REC.global_value;
end loop;

RETURN l_return_val;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 0;
END;



 ---
FUNCTION GET_TABLE_VALUE( P_REGION VARCHAR2, P_COLUMN VARCHAR2 , P_BUSINESS_GROUP_ID NUMBER)
 RETURN NUMBER
 IS

L_RETURN_VAL NUMBER;
L_VALUE varchar2(200);

BEGIN

OPEN c_table_values(P_REGION , P_COLUMN, P_BUSINESS_GROUP_ID);
FETCH c_table_values INTO  L_VALUE;
IF c_table_values%NOTFOUND
THEN
   L_VALUE := NULL;
END IF;
CLOSE c_table_values;

RETURN  L_VALUE;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 0;
END;


BEGIN   ----- MAIN

FOR GRD_REC IN csr_get_grade_info
LOOP
  BEGIN
--
  l_individual_achievement := grd_rec.individual_achievment;
  l_prorated_bonus := grd_rec.prorated_bonus;
  l_object_version_number := grd_rec.object_version_number;
  l_person_extra_info_id := grd_rec.person_extra_info_id;

  OPEN c_table_values(GRD_REC.region , 'OI Payout PCT', GRD_REC.BUSINESS_GROUP_ID);
  FETCH c_table_values INTO  L_REGION_VALUE_OI;
  IF c_table_values%NOTFOUND
  THEN
     L_REGION_VALUE_OI := NULL;
  END IF;
  CLOSE c_table_values;

  OPEN c_table_values(GRD_REC.region , 'Rev Payout PCT', GRD_REC.BUSINESS_GROUP_ID);
  FETCH c_table_values INTO  L_REGION_VALUE_REV;
  IF c_table_values%NOTFOUND
  THEN
     L_REGION_VALUE_REV := NULL;
  END IF;
  CLOSE c_table_values;

  L_REGION_VALUE_REV :=  GET_TABLE_VALUE( GRD_REC.region , 'Rev Payout PCT' , GRD_REC.BUSINESS_GROUP_ID);

  L_REGION_VALUE_OI :=  GET_TABLE_VALUE( GRD_REC.region , 'OI Payout PCT', GRD_REC.BUSINESS_GROUP_ID);

  l_person_id := GRD_REC.person_id;
  l_salary := GRD_REC.annual_salary;
  l_year :=  P_YEAR;
  l_ww_tgt_bonus_potn_perc := GRD_REC.WW_BONUS_TGT_TOT_POTN;
  IF l_prorated_bonus <> 0 THEN
     l_target_bonus := l_prorated_bonus;
  ELSE
     l_target_bonus :=  GRD_REC.WW_BONUS_TGT_TOT_POTN * GRD_REC.annual_salary  / 100 ;
  END IF;

  l_corporate_percent := GRD_REC.WW_BONUS_TGT_CORP;
  l_regional_percent := GRD_REC.WW_BONUS_TGT_REG;
  l_individual_percent := GRD_REC.WW_BONUS_TGT_IND ;
  l_grade_name := GRD_REC.GRADE_NAME;
  l_corp_target_amt :=  trunc(l_corporate_percent)  *  trunc(l_target_bonus)  / 100 ;

--CORPORATE INCOME
  l_corp_oper_income := l_corp_target_amt *
                        GET_TABLE_VALUE( 'CORP_OI_FI_PCT' , 'Others', GRD_REC.BUSINESS_GROUP_ID) *
                        GET_TABLE_VALUE( 'CORP_OI_HR_PCT' , 'Others', GRD_REC.BUSINESS_GROUP_ID);

-- CORP REVENUE
  l_corp_revenue := l_corp_target_amt *
                    GET_TABLE_VALUE ('CORP_REV_HR_PCT','Others', GRD_REC.BUSINESS_GROUP_ID) *
                    GET_TABLE_VALUE ('CORP_REV_FI_PCT','Others' , GRD_REC.BUSINESS_GROUP_ID);

  l_corp_bonus_payout := l_corp_revenue + l_corp_oper_income;

  l_reg_target_amt := l_regional_percent * l_target_bonus  / 100 ;

 -- REGIONAL
  l_reg_revenue := l_reg_target_amt *
                   GET_TABLE_VALUE( GRD_REC.region , 'Rev Payout PCT', GRD_REC.BUSINESS_GROUP_ID) *
                   GET_TABLE_VALUE ('BU_REV_HR_PCT','Others', GRD_REC.BUSINESS_GROUP_ID);

  l_reg_operating_income := l_reg_target_amt *
                            GET_TABLE_VALUE( GRD_REC.region , 'OI Payout PCT', GRD_REC.BUSINESS_GROUP_ID)  *
                            GET_TABLE_VALUE ('BU_OI_HR_PCT','Others', GRD_REC.BUSINESS_GROUP_ID);

  l_reg_bonus_payout := l_reg_revenue  +  l_reg_operating_income;
 -- individual
  l_ind_target_amt :=  l_individual_percent * l_target_bonus / 100;
  
  -- (07-May-2008) Added exception to override VARCHAR to NUMBER conversion error.
  BEGIN

     IF TO_NUMBER ( SUBSTR(GRD_REC.GRADE_NAME ,1,2)) < 28 THEN
	     l_ind_bonus_payout :=  l_ind_target_amt  *
				    GET_TABLE_VALUE ('HAE_IND_FUND_PCT','Others', GRD_REC.BUSINESS_GROUP_ID) *
				    to_Number (l_individual_achievement) / 100  * GET_TABLE_VALUE ('CORP_OI_FI_PCT_EE','Others', GRD_REC.BUSINESS_GROUP_ID);
	  ELSE
	     l_ind_bonus_payout :=  l_ind_target_amt  *
				    GET_TABLE_VALUE ('HAE_IND_FUND_PCT','Others', GRD_REC.BUSINESS_GROUP_ID) *
				    to_Number (l_individual_achievement) / 100;
	  END IF;
  EXCEPTION WHEN OTHERS THEN 
    NULL;  
  END;
  l_tot_bonus_payout := nvl( l_corp_bonus_payout,0) +
                        nvl( l_reg_bonus_payout,0) +
                        nvl(l_ind_bonus_payout,0) ;


    BEGIN
    hr_person_extra_info_api.update_person_extra_info
      (p_validate                      => FALSE
--      ,p_person_id                     =>
--      ,P_PEI_ATTRIBUTE_CATEGORY        =>
      ,p_pei_information_category      => l_pei_information_category
--      ,p_pei_information1              =>    -- Year
--      ,p_pei_information2              =>    -- currency
--      ,p_pei_information3              =>    --Target Bonus Perc
      ,p_pei_information4              => l_target_bonus  --Target bonus Amount
--      ,p_pei_information5              =>    -- Base Salary %
--      ,p_pei_information6              =>    --corporate_percent
--      ,p_pei_information7              =>    --regional_percent
--      ,p_pei_information8              =>    --individual_percent
--      ,p_pei_information9              =>    --individual_achievement
--      ,p_pei_information10             =>    --
      ,p_pei_information11             => l_corp_bonus_payout -- calculated
      ,p_pei_information12             => l_ind_target_amt
      ,p_pei_information13             => l_ind_bonus_payout-- calculated
      ,p_pei_information14             => l_reg_target_amt
      ,p_pei_information15             => l_reg_bonus_payout-- calculated
      ,p_pei_information16             => l_corp_oper_income
      ,p_pei_information17             => l_corp_revenue
      ,p_pei_information18             => l_reg_revenue
      ,p_pei_information19             => l_reg_operating_income
      ,p_pei_information20             => l_corp_target_amt
      ,p_pei_information30             => l_tot_bonus_payout
      ,p_person_extra_info_id          => l_person_extra_info_id
      ,p_object_version_number         => l_object_version_number
   );
EXCEPTION
 WHEN OTHERS THEN
 NULL;

END;

 EXCEPTION
 WHEN OTHERS THEN
NULL;
 END;
   END LOOP;
 EXCEPTION
 WHEN OTHERS THEN
 NULL;


END CALCULATE_AND_MOVE;


PROCEDURE INITIALIZE_EIT(errbuf OUT VARCHAR2, retcode OUT NUMBER, P_YEAR VARCHAR2, P_CURRENCY VARCHAR2)
AS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_BONUS_CALCULATIONS
*  Procedure:  INITIALIZE_EIT
*  Description:
*      This package is written to initialize EIT
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*  10-MAR-2009       R. Sneep          Added pei_information3 to create API
*
******************************************************************************/

/* Current Year In Grade attribute5  moved to EIT PEI_INFORMATION1 read only */
 l_year   VARCHAR2(150)  := P_YEAR;
 l_information_type         VARCHAR2(30) DEFAULT 'HAE_BONUS_GLB'  ;
 l_pei_information_category VARCHAR2(30) DEFAULT 'HAE_BONUS_GLB'  ;
 l_person_extra_info_id     NUMBER;
 l_object_version_number    NUMBER;

 L_DO_CREATE_EIT            BOOLEAN DEFAULT TRUE;

CURSOR csr_get_grade_info
 IS
    SELECT ASSIGN.PERSON_ID,
           GRD.ATTRIBUTE6 WW_BONUS_TGT_TOT_POTN,
           GRD.ATTRIBUTE1 WW_BONUS_TGT_CORP,
           GRD.ATTRIBUTE2 WW_BONUS_TGT_REG,
           GRD.ATTRIBUTE4 WW_BONUS_TGT_IND,
           GRD.NAME        GRADE_NAME
     FROM PER_GRADES GRD,
          PER_ALL_ASSIGNMENTS_F ASSIGN
    WHERE GRD.GRADE_ID = ASSIGN.GRADE_ID
      and TRUNC(sysdate) between ASSIGN.effective_start_date and ASSIGN.effective_end_date;


CURSOR c_eit_data(p_person_id NUMBER , P_YEAR VARCHAR2)
IS
select pei.PEI_INFORMATION1 -- year
  from per_people_extra_info pei
 where pei.person_id = p_person_id
   AND pei.PEI_INFORMATION_CATEGORY = 'HAE_BONUS_GLB'
   AND pei.INFORMATION_TYPE = 'HAE_BONUS_GLB'
   AND pei.PEI_INFORMATION1 = P_YEAR ;             --- TEST YEAR


BEGIN

FOR GRD_REC IN csr_get_grade_info
LOOP

   BEGIN

    OPEN c_eit_data(GRD_REC.PERSON_ID , P_YEAR );
    FETCH c_eit_data INTO l_year;
    IF c_eit_data%NOTFOUND THEN
       L_DO_CREATE_EIT := TRUE;
    ELSE
       L_DO_CREATE_EIT := FALSE;
    END IF;

    CLOSE c_eit_data;

    IF (L_DO_CREATE_EIT ) THEN
       hr_person_extra_info_api.create_person_extra_info
         (p_validate                      => FALSE
         ,p_person_id                     => GRD_REC.PERSON_ID
         ,p_information_type              => l_information_type
         ,p_pei_information_category      => l_pei_information_category
         ,p_pei_information1              => l_year -- Year
--         ,p_pei_information2              => P_CURRENCY -- currency
         ,p_pei_information3              => GRD_REC.WW_BONUS_TGT_TOT_POTN  --Target Bonus Perc
         ,p_pei_information4              => NULL --Target bonus Amount
         ,p_pei_information5              => null  -- Base Salary %
         ,p_pei_information6              => GRD_REC.WW_BONUS_TGT_CORP -- CORP
         ,p_pei_information7              => GRD_REC.WW_BONUS_TGT_REG -- REG
         ,p_pei_information8              => GRD_REC.WW_BONUS_TGT_IND  -- IND
         ,p_pei_information9              => NULL -- individual achievement
--         ,p_pei_information10             =>
         ,p_pei_information11             => NULL -- calculated
         ,p_pei_information12             => NULL
         ,p_pei_information13             => NULL -- calculated
         ,p_pei_information14             => NULL
         ,p_pei_information15             => NULL -- calculated
         ,p_pei_information16             => NULL
         ,p_pei_information17             => NULL
         ,p_pei_information18             => NULL
         ,p_pei_information19             => NULL
         ,p_pei_information20             => NULL
         ,p_person_extra_info_id          => l_person_extra_info_id
         ,p_object_version_number         => l_object_version_number
         );
    END IF;

   EXCEPTION WHEN OTHERS THEN
      NULL;
   END;
END LOOP;

EXCEPTION WHEN OTHERS THEN
   NULL;
END INITIALIZE_EIT;

END XXHA_BONUS_CALCULATIONS;
/
