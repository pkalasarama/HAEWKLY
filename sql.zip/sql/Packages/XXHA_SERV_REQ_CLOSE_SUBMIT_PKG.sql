create or replace PACKAGE XXHA_SERV_REQ_CLOSE_SUBMIT_PKG AUTHID CURRENT_USER 
AS

/*****************************************************************************************************************************
* Package Name : XXHA_SERV_REQ_CLOSE_SUBMIT_PKG                                                                              *
*                                                                                                                            *
* Purpose      : Package to submit Concurrent Program 'XXHA: Service Request Closure Report'                                 *
*                                                                                                                            *
* Procedures   : Process_PGM                                                                                                 *
*                                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                            *
* - XDO_TEMPLATES_VL                  S                                                                                      *
* - XDO_LOBS                          S                                                                                      *
* - fnd_concurrent_programs_vl        S                                                                                      *
* - XXHA_SERV_REQ_CLOSE_V             S                                                                                      *
*                                                                                                                            *
* Change History                                                                                                             *
*                                                                                                                            *
* Ver        Date            Author               Description                                                                *
* ------     -----------     -----------------    ---------------                                                            *
* 1.0        24-AUG-2016     BMarcoux             Intial Program Creation.                                                   *
*                                                                                                                            *
* 5.0        06-JUN-2017     Bruce Marcoux        INC0107201 - Service Batch - Records processed with errors email not sent. *
*                                                  Modification to place spreadsheets on server and be picked up by          *
*                                                  WebMethods processing and placed on shared drive instead of being         *
*                                                  emailed as an attachment. Added PARM: P_REPORT_PROGRAM_ID.                *
******************************************************************************************************************************/

--GlobalVariables
gc_log_msg               VARCHAR2(3000);
gc_debug_flag            VARCHAR2(1);

--Procedure to Process Concurrent Program
PROCEDURE Process_PGM(
                      x_errbuf                       OUT VARCHAR2
                    , x_retcode                      OUT VARCHAR2
                    , P_SESSION_ID                   IN  NUMBER
                    , P_CONCURRENT_PGM               IN  VARCHAR2
                    , P_TEMPLATE_CODE                IN  VARCHAR2
                    , P_DEBUG                        IN  VARCHAR2
                    , P_EMAIL_SERVER                 IN  VARCHAR2
                    , P_EMAIL_PORT                   IN  VARCHAR2
                    , P_TEST_EMAIL_ACCOUNT           IN  VARCHAR2
                    , P_PRODUCTION_INSTANCE_DB_NAME  IN  VARCHAR2
                    , P_Value_Set_ID_EMail           IN  NUMBER
                    , P_REPORT_PROGRAM_ID            IN  NUMBER
                     );

END XXHA_SERV_REQ_CLOSE_SUBMIT_PKG;