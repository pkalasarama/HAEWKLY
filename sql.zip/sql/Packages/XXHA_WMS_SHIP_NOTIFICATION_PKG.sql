CREATE OR REPLACE PACKAGE "APPS"."XXHA_WMS_SHIP_NOTIFICATION_PKG" 
    /* ******************************************************************************************************
    * Object Name: XXHA_WMS_SHIP_NOTIFICATION_PKG
    * Object Type: PACKAGE
    *
    * Description: This package will be calling ship notif process
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/
AS
  PROCEDURE xxha_ship_notification_prc(
      ERRBUF     IN OUT VARCHAR2,
      RETCODE    IN OUT VARCHAR2,
      p_deliv_id IN NUMBER );
END XXHA_WMS_SHIP_NOTIFICATION_PKG;
/

CREATE OR REPLACE PACKAGE BODY "APPS"."XXHA_WMS_SHIP_NOTIFICATION_PKG" 
    /* ******************************************************************************************************
    * Object Name: XXHA_WMS_SHIP_NOTIFICATION_PKG
    * Object Type: PACKAGE
    *
    * Description: This package will be calling ship notif process
    *
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    27-JAN-2015          Initial object creation.
    *
    *
    *******************************************************************************************************/
AS
  PROCEDURE xxha_ship_notification_prc(
      ERRBUF     IN OUT VARCHAR2,
      RETCODE    IN OUT VARCHAR2,
      p_deliv_id IN NUMBER )
  AS
    l_number NUMBER;
  BEGIN
    XXHA_BE_SHIP_NOTIF_PKG.XXHA_GET_MAIL_BODY(p_deliv_id);
  END xxha_ship_notification_prc;
END XXHA_WMS_SHIP_NOTIFICATION_PKG;
/