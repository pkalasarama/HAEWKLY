create or replace 
PACKAGE XXHA_WB_SHIPPING_DOCS_PKG
AS
/*************************************************************************************************************
    * Object Name: XXHA_WB_SHIPPING_DOCS_PKG
    * Object Type: Package
    * Description: This package created for Shipping documents requirement and is called at webmethods side.
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    08-APR-2015          Initial object creation.
**************************************************************************************************************/ 
  PROCEDURE xxha_ship_docs_prc(
      p_deliv_id IN NUMBER );
END XXHA_WB_SHIPPING_DOCS_PKG;
/

create or replace 
PACKAGE body XXHA_WB_SHIPPING_DOCS_PKG
AS
/*************************************************************************************************************
    * Object Name: XXHA_WB_SHIPPING_DOCS_PKG
    * Object Type: Package
    * Description: This package created for Shipping documents requirement and is called at webmethods side.
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    08-APR-2015          Initial object creation.
**************************************************************************************************************/ 
PROCEDURE xxha_ship_docs_prc(
    p_deliv_id IN NUMBER )
AS
  l_user_id             NUMBER         := 1706;      ---30035;   --1706;
  l_resp_id             NUMBER         := NULL;
  l_resp_appl_id        NUMBER         := NULL;
  l_responsibility_name VARCHAR2 (255) := 'US Order Management Super User OC';
  --local variables for calling XXHA Shipping Documents Program
  l_doc_printer   VARCHAR2(50);
  l_lookup_code   VARCHAR2(250);
 -- l_mode_of_transport VARCHAR2(50);
 -- l_org_code VARCHAR2(10);
  l_option_return BOOLEAN;
  ln_request_id   NUMBER;
 BEGIN
  BEGIN
    SELECT frt.application_id,
      frt.responsibility_id
    INTO l_resp_appl_id,
      l_resp_id
    FROM fnd_responsibility_tl frt
    WHERE frt.LANGUAGE          = 'US'
    AND frt.responsibility_name = l_responsibility_name;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    l_resp_appl_id := '';
    l_resp_id      := '';
  END;
  fnd_global.apps_initialize (user_id => l_user_id, resp_id => l_resp_id, resp_appl_id => l_resp_appl_id );
  -- fnd_global.apps_initialize (29067,20420,1);
 /* SELECT attribute4
  INTO l_doc_printer
  FROM wsh_delivery_details wdd
  WHERE wdd.delivery_detail_id IN
    (SELECT wda.delivery_detail_id
    FROM wsh_delivery_assignments wda,
      wsh_new_deliveries wnd
    WHERE wdd.delivery_detail_id = wda.delivery_detail_id
    AND wda.delivery_id          = wnd.delivery_id
      -- AND wdd.released_status      = 'Y'
      -- AND status_code NOT         IN ('CO', 'CL', 'IT')
    AND wda.delivery_id = p_deliv_id
    )
  AND wdd.attribute4 IS NOT NULL
  AND rownum          = 1;*/
  SELECT wdd.attribute4, 
  --DECODE(upper(wdd.mode_of_transport),'PARCEL',wdd.mode_of_transport,'NP') MODE_OF_TRANSPORT,
   --    ood.organization_code
     flv.lookup_code 
      INTO l_doc_printer,
     -- l_mode_of_transport,
     -- l_org_code
           l_lookup_code
      FROM wsh_carrier_services_v wcs,
        wsh_delivery_details wdd ,
        wsh_delivery_assignments wda,
        wsh_new_deliveries wnd,
        wsh_lookups wl,
        org_organization_definitions ood,
        fnd_lookup_values_vl flv 
      WHERE wcs.carrier_id       = wdd.carrier_id
      AND wdd.delivery_detail_id = wda.delivery_detail_id
      AND wda.delivery_id        = wnd.delivery_id
      AND wdd.organization_id    = ood.organization_id
      AND wda.delivery_id        = p_deliv_id
      AND wdd.mode_of_transport  = wl.lookup_code
      AND wl.lookup_type(+)      = 'XXHA_WSH_BOL_MODE_OF_TRANSPORT'
      and flv.lookup_type        = 'XXHA_WMS_SHIPPING_DOCS'
      and flv.tag             =  DECODE(upper(wdd.mode_of_transport),'PARCEL',wdd.mode_of_transport,'NP')
      and flv.description        = ood.organization_code
      AND wl.enabled_flag        = 'Y'
      and flv.enabled_flag       = 'Y'
      AND wdd.attribute4 IS NOT NULL
      AND rownum          = 1
      GROUP BY wdd.attribute4,
     -- wdd.mode_of_transport, ood.organization_code
      flv.lookup_code ;
  --l_option_return := fnd_request.set_print_options (printer => p_doc_printer, style => NULL, copies => 1, save_output => TRUE, print_together => 'N' );
  -- DBMS_OUTPUT.put_line ('Printer:' || p_doc_printer);
  /*ln_request_id := fnd_request.submit_request ( 'HAEMO' -- Application
  , 'XXHA_SHIP_DOCS_PRG'                                -- Program
  , NULL                                                -- Description
  , NULL                                                -- Start Time
  , FALSE                                               -- Sub Request
  , p_deliv_id                                          -- Delivery ID
  , l_doc_printer                                       -- Shipping docs printer
  );
  COMMIT;*/
  ln_request_id := fnd_request.submit_request ( 'HAEMO' -- Application
  , l_lookup_code                                       -- Program
  , NULL                                                -- Description
  , NULL                                                -- Start Time
  , FALSE                                               -- Sub Request
  , p_deliv_id                                          -- Delivery ID
  , l_doc_printer                                       -- Shipping docs printer
  );
  COMMIT;
  IF ln_request_id = 0 THEN
    DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
  END IF;
END;
END XXHA_WB_SHIPPING_DOCS_PKG;
/