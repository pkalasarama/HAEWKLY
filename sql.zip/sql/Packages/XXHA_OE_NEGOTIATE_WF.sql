CREATE OR REPLACE PACKAGE      xxha_oe_negotiate_wf AUTHID CURRENT_USER
AS
/*
*************************************************************************
** Haemonetics
** Extension
** Implemented by KBACE
*************************************************************************
** Business Object: OM WORKFLOW INTEGRATION
** File Name:       XXHA_OE_NEGOTIATE_WF.PKS
** File Type:       PACKAGE SPECIFICATION
** Purpose:         OM Negotiation Header workflow Integration with AME for BSA Approval
*************************************************************************
*/
   PROCEDURE update_approver_list (
      itemtype    IN              VARCHAR2,
      itemkey     IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      resultout   IN OUT NOCOPY   VARCHAR2
   );

   PROCEDURE purge_approver_list (
      itemtype    IN              VARCHAR2,
      itemkey     IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      resultout   IN OUT NOCOPY   VARCHAR2
   );
END xxha_oe_negotiate_wf;

/


CREATE OR REPLACE PACKAGE BODY      XXHA_OE_NEGOTIATE_WF
AS
/*
*************************************************************************
** Haemonetics
** Extension
** Implemented by KBACE
*************************************************************************
** Business Object: OM WORKFLOW INTEGRATION
** File Name:       XXHA_OE_NEGOTIATE_WF.PKB
** File Type:       PACKAGE BODY
** Purpose:         OM Negotiation Header workflow Integration with AME for BSA Approval
*************************************************************************
*/
   PROCEDURE update_approver_list (
      itemtype    IN              VARCHAR2,
      itemkey     IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      resultout   IN OUT NOCOPY   VARCHAR2
   )
   IS
      l_approversout                   ame_util.approverstable2;
      l_itemindexesout                 ame_util.idlist;
      l_itemclassesout                 ame_util.stringlist;
      l_itemidsout                     ame_util.stringlist;
      l_itemsourcesout                 ame_util.longstringlist;
      l_approvalprocesscompleteynout   VARCHAR2 (10);
      l_flag                           VARCHAR2 (20);
      l_approverin                     ame_util.approverrecord2;
      l_tran_type                      oe_blanket_headers_all.order_type_id%TYPE;
      l_list_id                        oe_approver_lists.list_id%TYPE;
      l_email                          VARCHAR2 (100);
      l_sub_email                      VARCHAR2 (1000);
      l_user                           VARCHAR2 (100);
      l_role_name                      VARCHAR2 (100);
      l_role                           VARCHAR2 (100);
      l_diplay_name                    VARCHAR2 (100);
      l_count                          NUMBER;
      ln_count                         NUMBER;
      l_source_line_id                 oe_order_headers_all.source_document_id%TYPE;
      l_header_id                      oe_blanket_headers_all.header_id%TYPE;
      l_app_req                        VARCHAR2 (5);
      l_xxapprover                     VARCHAR2 (100);
      l_phase_code                     oe_transaction_types_all.def_transaction_phase_code%TYPE;
   BEGIN
      ame_api2.getallapprovers1
             (applicationidin                   => 660,
              transactiontypein                 => 'XXHA_BSA_APPRL',
              transactionidin                   => TO_CHAR (itemkey),
              approvalprocesscompleteynout      => l_approvalprocesscompleteynout,
              approversout                      => l_approversout,
              itemindexesout                    => l_itemindexesout,
              itemclassesout                    => l_itemclassesout,
              itemidsout                        => l_itemidsout,
              itemsourcesout                    => l_itemsourcesout
             );

      --insert into debug_table values('1',l_approversOut.count);

      -- Select the transaction Type  id
      SELECT order_type_id
        INTO l_tran_type
        FROM oe_blanket_headers_all
       WHERE header_id = TO_NUMBER (itemkey);

       SELECT def_transaction_phase_code
         INTO l_phase_code
         FROM oe_transaction_types_all
        WHERE transaction_type_id = l_tran_type;

      BEGIN
         SELECT list_id
           INTO l_list_id
           FROM oe_approver_lists
          WHERE transaction_type_id = l_tran_type
            AND NVL(transaction_phase_code,'X') = NVL(l_phase_code,'X');
      EXCEPTION
         WHEN OTHERS
         THEN
            BEGIN
               SELECT MAX (list_id)
                 INTO l_list_id
                 FROM oe_approver_lists;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_list_id := 1;
            END;

            l_list_id := l_list_id + 1;

            INSERT INTO oe_approver_lists
                        (list_id, NAME,
                         transaction_type_id, description,
                         creation_date, created_by, last_update_date,
                         last_updated_by, last_update_login
                         ,transaction_phase_code
                        )
                 VALUES (l_list_id, 'XXHA BSA Approval-' || l_list_id,
                         l_tran_type, 'XXHA BSA Approval-' || l_list_id,
                         SYSDATE, -1, SYSDATE,
                         -1, -1
                         ,l_phase_code
                        );
      END;

      FOR i IN 1 .. l_approversout.COUNT
      LOOP
         l_xxapprover := l_approversout (i).NAME;
/*
         INSERT INTO xx_temp
              VALUES ('l_xxapprover ' || l_xxapprover);*/

         INSERT INTO oe_approver_list_members
              VALUES (l_list_id, l_approversout (i).NAME,
                      l_approversout (i).approver_order_number, 'Y', SYSDATE,
                      -1, SYSDATE, -1, -1, NULL, itemkey, NULL, NULL, NULL,
                      NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                      NULL, NULL);
      END LOOP;

      resultout := 'SUCCESS';
   EXCEPTION
      WHEN OTHERS
      THEN
         resultout := 'FAIL';
   END update_approver_list;

   PROCEDURE purge_approver_list (
      itemtype    IN              VARCHAR2,
      itemkey     IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      resultout   IN OUT NOCOPY   VARCHAR2
   )
   IS
      l_tran_type   oe_blanket_headers_all.order_type_id%TYPE;
      l_list_id     oe_approver_lists.list_id%TYPE;
      l_role_name   wf_local_user_roles.role_name%TYPE;
      l_phase_code  oe_transaction_types_all.def_transaction_phase_code%TYPE;
   BEGIN
-- Select the transaction Type  id
      SELECT order_type_id
        INTO l_tran_type
        FROM oe_blanket_headers_all
       WHERE header_id = TO_NUMBER (itemkey);

       SELECT def_transaction_phase_code
         INTO l_phase_code
         FROM oe_transaction_types_all
        WHERE transaction_type_id = l_tran_type;

      SELECT list_id
        INTO l_list_id
        FROM oe_approver_lists
       WHERE transaction_type_id = l_tran_type
       AND NVL(transaction_phase_code,'X') = NVL(l_phase_code,'X');

      DELETE FROM oe_approver_list_members
            WHERE list_id = l_list_id
              AND attribute1= TO_CHAR (itemkey); --Vijay: Need to verify whether this condition needs to be included or not
      l_role_name := itemkey || '%';
/*
      DELETE FROM wf_local_user_roles
            WHERE role_name LIKE l_role_name;

      DELETE FROM wf_local_roles
            WHERE NAME LIKE l_role_name;*/

      resultout := 'SUCCESS';
   EXCEPTION
      WHEN OTHERS
      THEN
         resultout := 'FAIL';
   END purge_approver_list;
END XXHA_OE_NEGOTIATE_WF;

/
