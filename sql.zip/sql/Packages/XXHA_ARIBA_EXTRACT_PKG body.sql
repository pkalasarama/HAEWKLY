create or replace PACKAGE BODY XXHA_ARIBA_EXTRACT_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_ARIBA_EXTRACT_PKG                                                                                 *
* Purpose      : This package provides a function to process the Ariba data into the tables.                            *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        29-OCT-2015     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

PROCEDURE XXHA_PROCESS_DATA(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2
         ,p_Fiscal_Period_1  IN VARCHAR2
         ,p_Fiscal_Period_2  IN VARCHAR2
         ,p_Fiscal_Period_3  IN VARCHAR2) AS

BEGIN

DECLARE

   TRUNC_XXHA_ARIBA_INVOICES    VARCHAR2(500);
   TRUNC_XXHA_ARIBA_PO3_EXTRACT VARCHAR2(500);
   TRUNC_XXHA_ARIBA_ACCOUNT     VARCHAR2(500);

   l_fiscal_period_1            VARCHAR2(15) := p_Fiscal_Period_1;
   l_fiscal_period_2            VARCHAR2(15) := p_Fiscal_Period_2;
   l_fiscal_period_3            VARCHAR2(15) := p_Fiscal_Period_3;
   l_date_from                  DATE;
   l_date_to                    DATE;

   BEGIN

      -- TRUNCATE TABLE APPS.XXHA_ARIBA_INVOICES
      TRUNC_XXHA_ARIBA_INVOICES := 'TRUNCATE TABLE APPS.XXHA_ARIBA_INVOICES';
      EXECUTE IMMEDIATE TRUNC_XXHA_ARIBA_INVOICES;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'TRUNCATE TABLE APPS.XXHA_ARIBA_INVOICES: Completed');

      -- TRUNCATE TABLE APPS.XXHA_ARIBA_PO3_EXTRACT
      TRUNC_XXHA_ARIBA_PO3_EXTRACT := 'TRUNCATE TABLE APPS.XXHA_ARIBA_PO3_EXTRACT';
      EXECUTE IMMEDIATE TRUNC_XXHA_ARIBA_PO3_EXTRACT;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'TRUNCATE TABLE APPS.XXHA_ARIBA_PO3_EXTRACT: Completed');

      -- TRUNCATE TABLE APPS.XXHA_ARIBA_ACCOUNT
      TRUNC_XXHA_ARIBA_ACCOUNT := 'TRUNCATE TABLE APPS.XXHA_ARIBA_ACCOUNT';
      EXECUTE IMMEDIATE TRUNC_XXHA_ARIBA_ACCOUNT;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'TRUNCATE TABLE APPS.XXHA_ARIBA_ACCOUNT: Completed');

      -- Fiscal Periods
      FND_FILE.PUT_LINE(FND_FILE.LOG,'l_fiscal_period_1: ' || l_fiscal_period_1);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'l_fiscal_period_2: ' || l_fiscal_period_2);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'l_fiscal_period_3: ' || l_fiscal_period_3);

      -- Use Fiscal Periods to determine Start and End Dates for Creating View 'APPS.XXHA_ARIBA_CURR_RATES_MAP_V'
      SELECT MIN(glp.Start_Date)
           , MAX(glp.End_Date)
        INTO
             l_date_from
           , l_date_to
        FROM
             GL_PERIODS                        glp
       WHERE
             glp.Period_Set_Name  = 'HAE_GLOBAL_CAL'
         AND glp.period_type      = '21'
         AND glp.Period_Name      in (p_Fiscal_Period_1, p_Fiscal_Period_2, p_Fiscal_Period_3);

      -- Date From and Date To
      FND_FILE.PUT_LINE(FND_FILE.LOG,'l_date_from: ' || l_date_from);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'l_date_to:   ' || l_date_to);

      -- Process Invoices
      XXHA_LOAD_ARIBA_INVOICES(
          errbuf
         ,errcode
         ,l_fiscal_period_1
         ,l_fiscal_period_2
         ,l_fiscal_period_3);

      IF errcode = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG, errbuf);
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Load into APPS.XXHA_ARIBA_INVOICES: Completed');
      END IF;

      -- Process PO
      XXHA_LOAD_ARIBA_PO3_EXTRACT(
          errbuf
         ,errcode
         ,l_fiscal_period_1
         ,l_fiscal_period_2
         ,l_fiscal_period_3);

      IF errcode = 2 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG, errbuf);
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Load into APPS.XXHA_ARIBA_PO3_EXTRACT: Completed');
      END IF;

      -- Process Accounts
      XXHA_LOAD_ARIBA_ACCOUNT(
          errbuf
         ,errcode
         ,l_fiscal_period_1
         ,l_fiscal_period_2
         ,l_fiscal_period_3);

      IF errcode = 3 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG, errbuf);
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Load into APPS.XXHA_ARIBA_ACCOUNT: Completed');
      END IF;

      -- Create View 'APPS.XXHA_ARIBA_CURR_RATES_MAP_V'
      XXHA_CREATE_VIEW(
          errbuf
         ,errcode
         ,l_date_from
         ,l_date_to);

      IF errcode = 4 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG, errbuf);
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG,'CREATE OR REPLACE VIEW APPS.XXHA_ARIBA_CURR_RATES_MAP_V: Completed');
      END IF;

   END;

END XXHA_PROCESS_DATA;

PROCEDURE XXHA_LOAD_ARIBA_INVOICES(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2
         ,p_Fiscal_Period_1  IN VARCHAR2
         ,p_Fiscal_Period_2  IN VARCHAR2
         ,p_Fiscal_Period_3  IN VARCHAR2) AS

   BEGIN

      -- Load data into APPS.XXHA_ARIBA_INVOICES
      INSERT INTO APPS.XXHA_ARIBA_INVOICES
      (SELECT DISTINCT
         apia.invoice_id 
       , aila.line_number
       , apida.INVOICE_DISTRIBUTION_ID
       , apida.accounting_date
       , apida.quantity_invoiced
       , apida.amount
       , apia.invoice_currency_code
       , apida.description
       , pol.category_id
       , mb.segment1
       , mb.revision_qty_control_code
       , pol.unit_meas_lookup_code
       , apia.vendor_id
       , apia.vendor_site_id
       , poh.agent_id
       , glcc.segment6
       , glcc.segment1
       , pod.deliver_to_location_id
       , glcc.segment3
       , glcc.segment1
       , poha2.segment1
       , poh.po_header_id
       , pol.line_num
       , apia.invoice_date
       , apia.Gl_Date
       , apia.invoice_num 
       , APTT.DESCRIPTION
       , apida.line_type_lookup_code
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , NULL
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 1, glcc.segment1)
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 2, glcc.segment2)
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 3, glcc.segment3)
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 4, glcc.segment4)
       , NULL
       , NULL
       , NULL
       , NULL
       , apida.DIST_CODE_COMBINATION_ID
      FROM 
         ap.ap_invoices_all                apia
       , ap_invoice_lines_all              aila
       , ap_invoice_distributions_all      apida
       , po_distributions_all              pod
       , po_lines_all                      pol
       , po_headers_all                    poh
       , ap_terms_tl                       aptt
       , gl_code_combinations              glcc
       , ap_checks_all                     apca
       , mtl_system_items_b                mb
       , ap_invoice_payments_all           apipa
       , po_headers_all                    poha2
       , GL_PERIODS                        glp
      WHERE 
          apia.invoice_id                = apida.invoice_id
      AND aila.invoice_id                = apia.invoice_id
      AND apida.INVOICE_LINE_NUMBER      = aila.line_number
      AND apida.po_distribution_id       = pod.po_distribution_id(+)
      AND pod.po_line_id                 = pol.po_line_id(+)
      AND pol.po_header_id               = poh.po_header_id(+)
      AND NVL(pod.PO_HEADER_ID, 1)       = NVL(poh.po_header_id, 1)
      AND apida.DIST_CODE_COMBINATION_ID = glcc.code_combination_id
      AND apia.terms_id                  = aptt.term_id
      AND aptt.language                  ='US'
      AND apca.STATUS_LOOKUP_CODE       <> 'VOIDED'
      --AND NVL(aptt.term_id, 1)           = NVL(poh.terms_id, NVL(aptt.term_id, 1))
      AND apca.check_id(+)               = apipa.check_id
      AND pol.item_id                    = mb.inventory_item_id(+)
      AND mb.organization_id(+)          = 103
      AND apia.invoice_id                = apipa.invoice_id(+)
      AND POL.CONTRACT_ID                = POHA2.PO_HEADER_ID(+)
      AND apida.Period_Name              = glp.Period_Name
      AND glp.Period_Set_Name            = 'HAE_GLOBAL_CAL'
      AND glp.period_type                = '21'
      AND glp.Period_Name in (p_Fiscal_Period_1, p_Fiscal_Period_2, p_Fiscal_Period_3));

      COMMIT;

      EXCEPTION
           WHEN OTHERS THEN
                errbuf := 'Error in XXHA_ARIBA_EXTRACT_PKG.XXHA_PROCESS_DATA - Load into APPS.XXHA_ARIBA_INVOICES: ' || SQLERRM;
                errcode := 1;

END XXHA_LOAD_ARIBA_INVOICES;

PROCEDURE XXHA_LOAD_ARIBA_PO3_EXTRACT(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2
         ,p_Fiscal_Period_1  IN VARCHAR2
         ,p_Fiscal_Period_2  IN VARCHAR2
         ,p_Fiscal_Period_3  IN VARCHAR2) AS

   BEGIN

      -- Load data into APPS.XXHA_ARIBA_PO3_EXTRACT
      INSERT INTO APPS.XXHA_ARIBA_PO3_EXTRACT
      (SELECT DISTINCT
         poh.po_header_id 
       , pol.line_num
       , pod.po_distribution_id
       , TO_CHAR (poh.creation_date, 'YYYY-MM-DD')
       , pol.quantity
       , NVL (pol.quantity * pol.unit_price, 0)
       , poh.currency_code
       , pol.item_description
       , pol.category_id
       , mb.segment1
       , mb.revision_qty_control_code
       , pol.unit_meas_lookup_code
       , poh.vendor_id
       , poh.vendor_site_id
       , poh.agent_id
       , glcc.segment6
       , glcc.segment1
       , pod.deliver_to_location_id
       , poh2.segment1
       , glcc.segment5
       , glcc.segment1
       , pol.closed_flag
       , pol.line_type_id
       , glcc.code_combination_id
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 1, glcc.segment1)
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 2, glcc.segment2)
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 3, glcc.segment3)
       , gl_flexfields_pkg.get_description_sql (glcc.chart_of_accounts_id, 4, glcc.segment4)
      FROM 
         po_headers_all       poh
       , po_distributions_all pod
       , gl_code_combinations glcc
       , po_lines_all         pol
       , mtl_system_items_b   mb
       , po_headers_all       poh2
       , ap_suppliers         aps 
      WHERE     
          poh.po_header_id            = pod.po_header_id
      AND POH.PO_HEADER_ID            = POL.PO_HEADER_ID
      AND aps.vendor_id               = poh.vendor_id
      AND pol.item_id                 = mb.inventory_item_id(+)
      AND mb.ORGANIZATION_ID(+)       = 103
      AND aps.vendor_type_lookup_code <> 'EMPLOYEE'
      AND pod.po_line_id              = pol.po_line_id
      AND pod.code_combination_id     = glcc.code_combination_id
      AND pol.contract_id             = poh2.po_header_id(+)
      AND poh.org_id IN
         (SELECT DISTINCT operating_unit
                     FROM ORG_ORGANIZATION_DEFINITIONS
                    WHERE user_definition_enable_date <= SYSDATE
                      AND ((disable_date > SYSDATE) 
                       OR (disable_date IS NULL)))
      AND poh.po_header_id IN (SELECT DISTINCT "POID" FROM APPS.XXHA_ARIBA_INVOICES));
      
      COMMIT;

      EXCEPTION
           WHEN OTHERS THEN
                errbuf := 'Error in XXHA_ARIBA_EXTRACT_PKG.XXHA_PROCESS_DATA - Load into APPS.XXHA_ARIBA_PO3_EXTRACT: ' || SQLERRM;
                errcode := 2;

END XXHA_LOAD_ARIBA_PO3_EXTRACT;

PROCEDURE XXHA_LOAD_ARIBA_ACCOUNT(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2
         ,p_Fiscal_Period_1  IN VARCHAR2
         ,p_Fiscal_Period_2  IN VARCHAR2
         ,p_Fiscal_Period_3  IN VARCHAR2) AS

   BEGIN

      -- Load data into APPS.XXHA_ARIBA_ACCOUNT
      INSERT INTO APPS.XXHA_ARIBA_ACCOUNT
      (SELECT
          gcc.segment6
        , gcc.segment1
        , gl_flexfields_pkg.get_description_sql(gcc.chart_of_accounts_id, 6, gcc.segment6)
        , chart_of_accounts_id
      FROM 
          gl_code_combinations gcc
      WHERE 
          1 = 1
      AND gcc.code_combination_id IN 
         (SELECT DIST_CODE_COMBINATION_ID
            FROM APPS.XXHA_ARIBA_INVOICES));
      
      COMMIT;

      EXCEPTION
           WHEN OTHERS THEN
                errbuf := 'Error in XXHA_ARIBA_EXTRACT_PKG.XXHA_PROCESS_DATA - Load into APPS.XXHA_ARIBA_ACCOUNT: ' || SQLERRM;
                errcode := 3;

END XXHA_LOAD_ARIBA_ACCOUNT;

PROCEDURE XXHA_CREATE_VIEW(
          errbuf         OUT VARCHAR2
         ,errcode        OUT VARCHAR2
         ,p_date_from     IN VARCHAR2
         ,p_date_to       IN VARCHAR2) AS

   CrtView                   VARCHAR2(1500);

   BEGIN

   CrtView := 
  'CREATE OR REPLACE FORCE VIEW APPS.XXHA_ARIBA_CURR_RATES_MAP_V 
   (
     "FROMCURRENCY"
   , "TOCURRENCY"
   , "RATE"
   , "DATE"
   )  
   AS
   SELECT
       FROM_CURRENCY
   ,   TO_CURRENCY
   ,   CONVERSION_RATE
   ,   TO_CHAR(CONVERSION_DATE, ''' || 'YYYY-MM-DD' || ''')
   FROM
       gl_daily_rates
   WHERE
       CONVERSION_TYPE = ''Corporate''
   AND CONVERSION_DATE BETWEEN ''' || p_date_from || ''' AND ''' || p_date_to || ''''
   ;
   
   EXECUTE IMMEDIATE CrtView;

   EXCEPTION
        WHEN OTHERS THEN
             errbuf := 'Error in XXHA_ARIBA_EXTRACT_PKG.XXHA_CREATE_VIEW - XXHA_ARIBA_CURR_RATES_MAP_V: ' || SQLERRM;
             errcode := 4;

END XXHA_CREATE_VIEW;

END XXHA_ARIBA_EXTRACT_PKG;