CREATE OR REPLACE package xxha_bonus_viewer as

-- ======================================================================+
-- ======================================================================+
--
-- PROGRAM NAME  : xxha_bonus_viewer
--
-- Description   : This package is used by HAE Update Bonus Viewer concurrent program
-- Change History:
-- ---------------
-- Version Date        Author          Remarks
-- ------- ----------- --------------- ---------------
-- 1.0     12-Jan-2010  Kbace          Initial Version
-- ======================================================================+


    procedure main(
      p_errmsg            out nocopy varchar2
    , p_errnum            out nocopy number
    , p_effective_date    in         varchar2
     );

end xxha_bonus_viewer;
/


CREATE OR REPLACE package body xxha_bonus_viewer
as

-- ======================================================================+
-- ======================================================================+
--
-- PROGRAM NAME  : xxha_bonus_viewer
--
-- Description   : This package is used by HAE Update Bonus Viewer concurrent program
-- Change History:
-- ---------------
-- Version Date        Author          Remarks
-- ------- ----------- --------------- ---------------
-- 1.0     12-Jan-2010  Kbace          Initial Version
-- ======================================================================+

--
  --
  procedure main(
      p_errmsg            out nocopy varchar2
    , p_errnum            out nocopy number
    , p_effective_date    in         varchar2
     ) as
  
cursor get_all_active_employees (c_effective_date date)
is
select asg.person_id, bg.name bg_name,grd.attribute6 target,pap.last_name,pap.first_name,pap.employee_number
from   per_periods_of_service pps,per_business_groups bg,per_all_assignments_f asg,per_grades grd,per_all_people_f pap
where  c_effective_date between asg.effective_start_date and asg.effective_end_date
and    c_effective_date between pap.effective_start_date and pap.effective_end_date
and    pps.actual_termination_date is null
and    asg.person_id = pps.person_id
and    asg.person_id = pap.person_id
and    asg.grade_id  = grd.grade_id
and    asg.business_group_id = bg.business_group_id
order by 3,2;

cursor get_bonus_eit_info (c_person_id number,
                           c_effective_date date
                          )
is 
select pei.* 
from per_people_extra_info pei  
where information_type like 'HAE_EE_BONUS_VIEW'
and   pei_information3 in ('WW Non-Sales Bonus','ESD Bonus')
and   c_effective_date  between to_date(pei_information1,'YYYY/MM/DD HH24:MI:SS') and NVL(to_date(pei_information2,'YYYY/MM/DD HH24:MI:SS'),c_effective_date +1) 
and   pei.person_id = c_person_id;

l_effective_date date;
l_eit_record_found varchar2(1);

begin

-- set the effective date

l_effective_date := fnd_date.canonical_to_date( p_effective_date );

-- Output Messages

FND_FILE.put_line( FND_FILE.output, 'Parameters:');
FND_FILE.put_line( FND_FILE.output, '===========');
FND_FILE.put_line( FND_FILE.output, 'Effective Date:            ' ||l_effective_date );
FND_FILE.put_line( FND_FILE.output, '===========');
FND_FILE.put_line( FND_FILE.output, '  ');
FND_FILE.put_line( FND_FILE.output, '  ');

FND_FILE.put_line( FND_FILE.output, 'Start of Messages');
FND_FILE.put_line( FND_FILE.output, '===========');
FND_FILE.put_line( FND_FILE.output, 'Full Name'||'~'||'Emp Num'||'~'||'BG Name'||'~'||'Message');            

-- get all active employees

begin 
  for grd_rec in get_all_active_employees (l_effective_date )
  loop
      
  l_eit_record_found := 'N';
  
  -- check the eit record for each employee
  
      for eit_rec in get_bonus_eit_info (grd_rec.person_id,l_effective_date)
      loop
  
          l_eit_record_found := 'Y';
      
  -- if the target bonus stored for the grade does not match the EIT record then update the EIT
  
          if to_number(grd_rec.target) <> to_number(NVL(eit_rec.pei_information4,0)) then
  
              -- update the new target information
              -- write the details to the log file
  
              hr_person_extra_info_api.update_person_extra_info
                                      (  p_person_extra_info_id         => eit_rec.person_extra_info_id   --in     number
                                        ,p_object_version_number        => eit_rec.object_version_number--in out nocopy number
                                        ,p_pei_attribute_category       => eit_rec.pei_attribute_category--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute1               => eit_rec.pei_attribute1--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute2               => eit_rec.pei_attribute2--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute3               => eit_rec.pei_attribute3--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute4               => eit_rec.pei_attribute4--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute5               => eit_rec.pei_attribute5--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute6               => eit_rec.pei_attribute6--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute7               => eit_rec.pei_attribute7--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute8               => eit_rec.pei_attribute8--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute9               => eit_rec.pei_attribute9--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute10              => eit_rec.pei_attribute10--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute11              => eit_rec.pei_attribute11--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute12              => eit_rec.pei_attribute12--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute13              => eit_rec.pei_attribute13--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute14              => eit_rec.pei_attribute14--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute15              => eit_rec.pei_attribute15--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute16              => eit_rec.pei_attribute16--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute17              => eit_rec.pei_attribute17--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute18              => eit_rec.pei_attribute18--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute19              => eit_rec.pei_attribute19--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_attribute20              => eit_rec.pei_attribute20--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information_category     => eit_rec.pei_information_category--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information1             => eit_rec.pei_information1--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information2             => eit_rec.pei_information2--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information3             => eit_rec.pei_information3--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information4             => grd_rec.target--eit_rec.pei_information4--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information5             => eit_rec.pei_information5--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information6             => eit_rec.pei_information6--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information7             => eit_rec.pei_information7--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information8             => eit_rec.pei_information8--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information9             => eit_rec.pei_information9--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information10            => eit_rec.pei_information10--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information11            => eit_rec.pei_information11--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information12            => eit_rec.pei_information12--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information13            => eit_rec.pei_information13--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information14            => eit_rec.pei_information14--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information15            => eit_rec.pei_information15--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information16            => eit_rec.pei_information16--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information17            => eit_rec.pei_information17--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information18            => eit_rec.pei_information18--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information19            => eit_rec.pei_information19--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information20            => eit_rec.pei_information20--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information21            => eit_rec.pei_information21--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information22            => eit_rec.pei_information22--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information23            => eit_rec.pei_information23--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information24            => eit_rec.pei_information24--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information25            => eit_rec.pei_information25--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information26            => eit_rec.pei_information26--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information27            => eit_rec.pei_information27--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information28            => eit_rec.pei_information28--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information29            => eit_rec.pei_information29--in     varchar2 default hr_api.g_varchar2
                                        ,p_pei_information30            => eit_rec.pei_information30--in     varchar2 default hr_api.g_varchar2
                                        );
              FND_FILE.put_line( FND_FILE.output, grd_rec.last_name||', '||grd_rec.first_name||'~'||grd_rec.employee_number||'~'||grd_rec.bg_name||'~'||'Target bonus percentage in the Employee Bonus View EIT for '||eit_rec.pei_information3||' has been updated from '||NVL(eit_rec.pei_information4,'NULL')||'% to '||to_number(grd_rec.target)||'%');
              commit;               
         end if;
          
      end loop;
      
      -- IF eit record not found write to the output file
      
      if l_eit_record_found = 'N' then
    
        FND_FILE.put_line( FND_FILE.output, grd_rec.last_name||', '||grd_rec.first_name||'~'||grd_rec.employee_number||'~'||grd_rec.bg_name||'~'||'No active EIT record for this person');            
      
      end if;
    
  end loop;
exception
    when others then
    FND_FILE.put_line( FND_FILE.output, 'Program encountered an unexpected error, Plase restart the request');            
    rollback;
end;

end main;    
     
end xxha_bonus_viewer;
/
