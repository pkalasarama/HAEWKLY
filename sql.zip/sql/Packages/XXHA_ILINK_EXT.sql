CREATE OR REPLACE package xxha_ilink_ext AUTHID CURRENT_USER AS
/*****************************************************************************************
* Name/Purpose : xxha_ilink_ext package Spec                                             *
* Description  : EBS to Agile Cost and Pricing Retrieval                                 *
*                                                                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 16-Jan-2014     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
/****************************************************************************************/
TYPE rec_item_cost IS
		RECORD (
      Record_Type varchar2(10) default 'COST',
      Cost_Type varchar2(240), -- FYXXPEND
      Cost_Type_ID number,
      Cost number,
      Update_Frozen_Flag char(1), --Y/N
      Lot_Size number,
      Basis_Type varchar2(240),
      Based_on_Rollup char(1), --Y/N
      Shrinkage_Rate number,
      Inventory_Asset char(1), --Y/N
      Return_Status number, -- 0=Normal Completion, 2=Warning, 3 = Error
      Error_Message varchar2(2000)
      );
  TYPE t_item_cost IS
    TABLE of rec_item_cost index by binary_integer;
  TYPE rec_item_price IS
    RECORD (
      Record_Type varchar2(10) default 'PL',
      Price_List_Name	Varchar2(240),
      Price_List_ID	Number,
      Price	Number,
      UOM	Varchar2(3),
      Return_Status number, -- 0=Normal Completion, 2=Warning, 3 = Error
      Error_Message varchar2(2000)
      );
  TYPE t_item_price IS
    TABLE of rec_item_price index by binary_integer;
  procedure get_price_rec(
    p_Organization_code varchar2, --varchar2(3)
    p_Item_Number varchar2, --varchar2(40)
    p_Agile_Cost number,
    p_Item_Type varchar2, --varchar2(240)
    p_Item_Category_Segment2 varchar2, --varchar2(240)
    p_Item_Category_Segment3 varchar2, --varchar2(240)
    p_item_cost_tab in out t_item_cost,
    p_item_price_tab in out t_item_price
    );
  procedure get_cost_rec(
    p_Organization_code varchar2, --varchar2(3)
    p_Item_Number varchar2, --varchar2(40)
    p_Agile_Cost number,
    p_Item_Type varchar2, --varchar2(240)
    p_Item_Category_Segment2 varchar2, --varchar2(240)
    p_Item_Category_Segment3 varchar2, --varchar2(240)
    p_item_cost_tab in out t_item_cost,
    p_item_price_tab in out t_item_price
    );
    procedure get_info(
      p_Organization_code varchar2, --varchar2(3)
      p_Item_Number varchar2, --varchar2(40)
      p_Agile_Cost number,
      p_Item_Type varchar2, --varchar2(240)
      p_Item_Category_Segment2 varchar2, --varchar2(240)
      p_Item_Category_Segment3 varchar2, --varchar2(240)
      p_item_cost_tab out t_item_cost,
      p_item_price_tab out t_item_price
    );
    function get_v_sysdate return date;
    procedure print_recs(
      p_item_cost_tab t_item_cost,
      p_item_price_tab t_item_price);
end;
/


CREATE OR REPLACE PACKAGE BODY APPS.xxha_ilink_ext
AS
   /*****************************************************************************************
   * Name/Purpose : xxha_ilink_ext package Body                                             *
   * Description  : EBS to Agile Cost and Pricing Retrieval                                 *
   *                                                                                        *
   * Date            Author               Description                                       *
   * -----------     -----------------    ---------------                                   *
   * 16-Jan-2014     Manuel Fernandes     Initial Creation                                  *
   * 06-Mar-2014     Manuel Fernandes     Changed Error Messages to include Org Code        *
   *                                      Non-Case sensitive  Item_Category_Segment1 + 2    *
   *                                      Included Period_year + Period_num for debugging   *
   * 12-Mar-2014     Manuel Fernandes     Changed Cost to reflect uplift(ed) Cost for USD   *
   *                                      Operating/Org                                     *
   * 24-Mar-2014     Manuel Fernandes     For Service Org and MACH category Items           *
   *                                      Cost being zero (Zero rate) set                   *
   *                                      v_conversion_rate to 0 (Zero)                     *
   * 16-Apr-2014     Manuel Fernandes     Update Frozen Cost Flag = 'N' for zero cost Orgs  *
   *                                      Cost sent back is 0                               *
   * 24-Apr-2014     Manuel Fernandes     Changed Cost BACK NOT to reflect                  *
   *                                      uplift(ed) Cost for USD Operating/Org             *
   *17-July-2014      Harish Kollipara    Changed material_costs to Item_costs in           *
   *                                      get_cost proc andmodified currency conversion     *
   *                                      in  get_price_rec proc
   *                                                                                        *
   /****************************************************************************************/
   --*select * from cst_cost_elements
   PROCEDURE print_recs (p_item_cost_tab t_item_cost, p_item_price_tab t_item_price)
   IS
   BEGIN
      DBMS_OUTPUT.put_line ('p_item_cost_tab count ' || TO_CHAR (p_item_cost_tab.COUNT));

      FOR i IN 1 .. p_item_cost_tab.COUNT
      LOOP
         DBMS_OUTPUT.put_line ('p_item_cost_tab ' || TO_CHAR (i));
         DBMS_OUTPUT.put_line ('Record_Type ' || p_item_cost_tab (i).Record_Type);
         DBMS_OUTPUT.put_line ('Cost_Type ' || p_item_cost_tab (i).Cost_Type);
         DBMS_OUTPUT.put_line ('Cost_Type_ID ' || p_item_cost_tab (i).Cost_Type_ID);
         DBMS_OUTPUT.put_line ('Cost ' || p_item_cost_tab (i).Cost);
         DBMS_OUTPUT.put_line ('Update_Frozen_Flag ' || p_item_cost_tab (i).Update_Frozen_Flag);
         DBMS_OUTPUT.put_line ('Lot_Size ' || p_item_cost_tab (i).Lot_Size);
         DBMS_OUTPUT.put_line ('Basis_Type ' || p_item_cost_tab (i).Basis_Type);
         DBMS_OUTPUT.put_line ('Based_on_Rollup ' || p_item_cost_tab (i).Based_on_Rollup);
         DBMS_OUTPUT.put_line ('Shrinkage_Rate ' || p_item_cost_tab (i).Shrinkage_Rate);
         DBMS_OUTPUT.put_line ('Inventory_Asset ' || p_item_cost_tab (i).Inventory_Asset);
         DBMS_OUTPUT.put_line ('Return_Status ' || p_item_cost_tab (i).Return_Status);
         DBMS_OUTPUT.put_line ('Error_Message ' || p_item_cost_tab (i).Error_Message);
      END LOOP;

      DBMS_OUTPUT.put_line ('p_item_price_tab count ' || TO_CHAR (p_item_price_tab.COUNT));

      FOR i IN 1 .. p_item_price_tab.COUNT
      LOOP
         DBMS_OUTPUT.put_line ('Record_Type ' || p_item_price_tab (i).Record_Type);
         DBMS_OUTPUT.put_line ('Price_List_Name ' || p_item_price_tab (i).Price_List_Name);
         DBMS_OUTPUT.put_line ('Price_List_ID ' || p_item_price_tab (i).Price_List_ID);
         DBMS_OUTPUT.put_line ('Price ' || p_item_price_tab (i).Price);
         DBMS_OUTPUT.put_line ('UOM ' || p_item_price_tab (i).UOM);
      END LOOP;
   END;

   FUNCTION get_v_sysdate
      RETURN DATE
   IS
   BEGIN
      --return add_months(sysdate,-8-12+0);
      RETURN SYSDATE;
   --return sysdate;
   END;

   FUNCTION get_period_sysdate
      RETURN DATE
   IS
   BEGIN
      --return add_months(sysdate,-8-12+0);
      RETURN SYSDATE;
   --return sysdate;
   END;

   PROCEDURE get_price_rec (p_Organization_code               VARCHAR2,                --varchar2(3)
                            p_Item_Number                     VARCHAR2,               --varchar2(40)
                            p_Agile_Cost                      NUMBER,
                            p_Item_Type                       VARCHAR2,              --varchar2(240)
                            p_Item_Category_Segment2          VARCHAR2,              --varchar2(240)
                            p_Item_Category_Segment3          VARCHAR2,              --varchar2(240)
                            p_item_cost_tab            IN OUT t_item_cost,
                            p_item_price_tab           IN OUT t_item_price)
   IS
      CURSOR c_org_price_lists (
         x_organization_code VARCHAR2)
      IS
         SELECT price_list_id,
                name price_list_name,
                currency_code,
                attribute2 price_uplift
           FROM oe_price_lists
          WHERE attribute1 = x_organization_code                                            --'BTO1'
                AND TRUNC (SYSDATE) BETWEEN start_date_active
                                        AND NVL (end_date_active, TRUNC (SYSDATE));

      CURSOR c_operating_units (
         x_organization_code VARCHAR2)
      IS
         SELECT ood.operating_unit,
                hou.name,
                sob.set_of_books_id,
                sob.name sob,
                sob.short_name sob_short_name,
                sob.currency_code
           FROM org_organization_definitions ood, hr_operating_units hou, gl_sets_of_books sob
          WHERE     ood.operating_unit = hou.organization_id
                AND ood.organization_code = x_organization_code                              --'BTO'
                AND hou.set_of_books_id = sob.set_of_books_id;

      v_operating_unit_rec        c_operating_units%ROWTYPE;

      CURSOR c_conversion_rates (
         x_sysdate                 DATE,
         x_target_currency_code    VARCHAR2,
         x_from_currency_code      VARCHAR2)
      IS
         SELECT conversion_rate
           FROM apps.gl_daily_rates
          WHERE     conversion_type = 'Corporate'
                AND conversion_date = TRUNC (x_sysdate)
                AND from_currency = x_from_currency_code
                AND to_currency = x_target_currency_code;

      v_conversion_rate           NUMBER := NULL;
      v_inventory_item_id         NUMBER := NULL;
      v_organization_id           NUMBER := NULL;
      v_primary_uom_code          VARCHAR2 (100) := NULL;
      v_org_currency_code         VARCHAR2 (100);
      v_price_list_exists         BOOLEAN;
      v_price_line_exists         BOOLEAN;
      v_some_price_line_missing   BOOLEAN;
      v_frozen_cost_exists        BOOLEAN;
      v_frozen_cost               NUMBER;
      v_rounding                  NUMBER;
      v_dummy_number              NUMBER;
      v_price_list_counter        NUMBER := 0;
      v_sysdate                   DATE;
      v_period_sysdate            DATE;
   BEGIN
      v_sysdate := xxha_ilink_ext.get_v_sysdate;
      v_period_sysdate := xxha_ilink_ext.get_period_sysdate;
      v_frozen_cost_exists := FALSE;
      v_price_list_exists := FALSE;
      v_price_line_exists := FALSE;


      --frozen cost exists ?
      BEGIN
         SELECT cic.item_cost,
                msi.organization_id,
                msi.inventory_item_id,
                TO_NUMBER (NVL (mp.attribute14, '5'))
           INTO v_frozen_cost,
                v_organization_id,
                v_inventory_item_id,
                v_rounding
           FROM mtl_system_items msi,
                mtl_parameters mp,
                cst_item_costs cic,
                cst_cost_types cct
          WHERE     msi.organization_id = mp.organization_id
                AND mp.organization_code = mp.organization_code
                AND msi.segment1 = p_item_number
                AND mp.organization_code = p_organization_code
                AND msi.organization_id = cic.organization_id
                AND msi.inventory_item_id = cic.inventory_item_id
                AND cic.cost_type_id = cct.cost_type_id
                AND cct.cost_type = 'Frozen';

         v_frozen_cost_exists := TRUE;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            RETURN;                                                   -- frozen cost does not exists
      END;

      -- price list header exists?
      BEGIN
         SELECT 1
           INTO v_dummy_number
           FROM DUAL
          WHERE EXISTS
                   (SELECT 1
                      FROM oe_price_lists
                     WHERE attribute1 = p_organization_code                                 --'BTO1'
                           AND TRUNC (SYSDATE) BETWEEN start_date_active
                                                   AND NVL (end_date_active, TRUNC (SYSDATE)));

         v_price_list_exists := TRUE;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            RETURN;                                                    -- price list does not exists
      END;

      BEGIN
         --MST primary UOM
         SELECT msi.primary_uom_code
           INTO v_primary_uom_code
           FROM mtl_system_items msi, mtl_parameters mp
          WHERE     msi.organization_id = mp.organization_id
                AND mp.organization_code = mp.organization_code
                AND msi.segment1 = p_item_number
                AND mp.organization_code = 'MST';

         IF v_primary_uom_code IS NULL
         THEN
            p_item_price_tab (1).Error_Message :=
                  p_item_price_tab (1).Error_Message
               || '*MST_PRIMARY_UOM_IS_NULL:'
               || p_Organization_code;
            p_item_price_tab (1).Return_Status := 2;
            RETURN;
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            p_item_price_tab (1).Error_Message :=
                  p_item_price_tab (1).Error_Message
               || '*MST_PRIMARY_UOM_NOT_FOUND:'
               || p_Organization_code;
            p_item_price_tab (1).Return_Status := 2;
            RETURN;
      END;

      -- price line exists for transfer price list
      v_price_line_exists := FALSE;
      v_some_price_line_missing := FALSE;

      FOR i IN c_org_price_lists (p_organization_code)
      LOOP
         BEGIN
            SELECT 1
              INTO v_dummy_number
              FROM DUAL
             WHERE EXISTS
                      (SELECT *
                         FROM qp_list_lines_v pll, oe_price_lists pl       --operand = price of item
                        WHERE     pl.price_list_id = pll.list_header_id
                              AND pl.price_list_id = i.price_list_id                       --5532652
                              AND pll.PA_LIST_HEADER_ID = i.price_list_id                  --5532652
                              AND pll.PRODUCT_ATTRIBUTE_CONTEXT = 'ITEM'
                              AND DECODE (pll.product_attribute,
                                          'PRICING_ATTRIBUTE1', pll.PRODUCT_ATTR_VAL_DISP,
                                          'Y')
                                     IS NOT NULL
                              AND pll.product_precedence = 220
                              AND pll.arithmetic_operator = 'UNIT_PRICE'
                              AND pll.list_line_type_code = 'PLL'
                              AND pll.product_uom_code = v_primary_uom_code                   --'Ea'
                              --and PRODUCT_ATTR_VAL_DISP = '16375-00' --this not product_attribute_value which would be character inventory_item_id
                              AND pll.product_attr_value = TO_CHAR (v_inventory_item_id) -- '643365'
                              AND TRUNC (SYSDATE) BETWEEN pll.start_date_active
                                                      AND NVL (pll.end_date_active,
                                                               TRUNC (SYSDATE))
                              AND TRUNC (SYSDATE) BETWEEN pl.start_date_active
                                                      AND NVL (pl.end_date_active, TRUNC (SYSDATE)));

            v_price_line_exists := TRUE;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_some_price_line_missing := TRUE;
         END;
      END LOOP;

      --
      IF v_price_line_exists
      THEN
         IF NOT v_some_price_line_missing
         THEN
            RETURN;
         -- we have a price list line and there is no missing line in any other transfer price list
         END IF;
      END IF;

      -- all exists so we need prce data
      OPEN c_operating_units (p_organization_code);

      FETCH c_operating_units INTO v_operating_unit_rec;

      IF c_operating_units%NOTFOUND
      THEN
         CLOSE c_operating_units;

         --error no operating unit
         RETURN;
      END IF;

      CLOSE c_operating_units;

      v_price_list_counter := 0;

      v_org_currency_code := NULL;

      BEGIN
         SELECT gl.currency_code
           INTO v_org_currency_code
           FROM org_organization_definitions ood, gl_ledgers gl
          WHERE     1 = 1
                AND ood.organization_id = v_organization_id
                AND ood.set_of_books_id = gl.ledger_id;
      EXCEPTION
         WHEN OTHERS
         THEN
            FND_FILE.PUT_LINE (
               FND_FILE.LOG,
               ' cannot find org functional currency for v_organization_id: ' || v_organization_id);
      END;

      FOR i IN c_org_price_lists (p_organization_code)
      LOOP
         BEGIN
            SELECT 1
              INTO v_dummy_number
              FROM DUAL
             WHERE EXISTS
                      (SELECT *
                         FROM qp_list_lines_v pll, oe_price_lists pl       --operand = price of item
                        WHERE     pl.price_list_id = pll.list_header_id
                              AND pl.price_list_id = i.price_list_id                       --5532652
                              AND pll.PA_LIST_HEADER_ID = i.price_list_id                  --5532652
                              AND pll.PRODUCT_ATTRIBUTE_CONTEXT = 'ITEM'
                              AND DECODE (pll.product_attribute,
                                          'PRICING_ATTRIBUTE1', pll.PRODUCT_ATTR_VAL_DISP,
                                          'Y')
                                     IS NOT NULL
                              AND pll.product_precedence = 220
                              AND pll.arithmetic_operator = 'UNIT_PRICE'
                              AND pll.list_line_type_code = 'PLL'
                              AND pll.product_uom_code = v_primary_uom_code                   --'Ea'
                              --and PRODUCT_ATTR_VAL_DISP = '16375-00' --this not product_attribute_value which would be character inventory_item_id
                              AND pll.product_attr_value = TO_CHAR (v_inventory_item_id) -- '643365'
                              AND TRUNC (SYSDATE) BETWEEN pll.start_date_active
                                                      AND NVL (pll.end_date_active,
                                                               TRUNC (SYSDATE))
                              AND TRUNC (SYSDATE) BETWEEN pl.start_date_active
                                                      AND NVL (pl.end_date_active, TRUNC (SYSDATE)));

            --dbms_output.put_line('Reached Continue');
            CONTINUE;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               --dbms_output.put_line('price line is needed');
               NULL;
         END;

         --dbms_output.put_line('After Continue reached');
         v_conversion_rate := NULL;

         --10/21/2014 changed by hk. 
         --when currency on PL is same as ORG currency then no conversion is reqd.
         IF i.currency_code = v_org_currency_code
         THEN
            v_conversion_rate := 1;
         ELSE
            OPEN c_conversion_rates (v_sysdate, i.currency_code, v_org_currency_code);

            FETCH c_conversion_rates INTO v_conversion_rate;


            CLOSE c_conversion_rates;
         END IF;



         --dbms_output.put_line('Currency Code ' ||i.currency_code);
         --dbms_output.put_line('v_frozen_cost'||to_char(v_frozen_cost)||'*'||'price_uplift'|| i.price_uplift||'*'||'v_conversion_rate'||to_char(v_conversion_rate));
         v_price_list_counter := v_price_list_counter + 1;
         p_item_price_tab (v_price_list_counter).Record_Type := 'PL';
         p_item_price_tab (v_price_list_counter).Price_List_Name := i.price_list_name;
         p_item_price_tab (v_price_list_counter).Price_List_ID := i.price_list_id;
         p_item_price_tab (v_price_list_counter).UOM := v_primary_uom_code;

         IF v_conversion_rate IS NULL
         THEN
            p_item_price_tab (1).Error_Message :=
                  p_item_price_tab (1).Error_Message
               || '*CONVERSION_RATE_IS_NULL:'
               || p_Organization_code;
            p_item_price_tab (1).Return_Status := 2;
         ELSE
            p_item_price_tab (v_price_list_counter).Price :=
               v_frozen_cost * i.price_uplift * v_conversion_rate;
         END IF;
      --p_item_price_tab(1).currency_code := i.currency_code;
      END LOOP;
   END;

   PROCEDURE get_cost_rec (p_Organization_code               VARCHAR2,                 --varchar2(3)
                           p_Item_Number                     VARCHAR2,                --varchar2(40)
                           p_Agile_Cost                      NUMBER,
                           p_Item_Type                       VARCHAR2,               --varchar2(240)
                           p_Item_Category_Segment2          VARCHAR2,               --varchar2(240)
                           p_Item_Category_Segment3          VARCHAR2,               --varchar2(240)
                           p_item_cost_tab            IN OUT t_item_cost,
                           p_item_price_tab           IN OUT t_item_price)
   IS
      x                       VARCHAR2 (100);

      CURSOR c_organizations (x_organization_code VARCHAR2)
      IS
         SELECT mp.organization_id,
                mp.attribute6 zero_cost_flag,
                mp.attribute7 service_org_flag,
                mp.attribute13 manufacturing_org_flag,
                mp.attribute8 disp_uplift,
                mp.attribute9 eqip_uplift,
                mp.attribute10 serv_uplift,
                mp.attribute11 sftw_uplift,
                mp.attribute12 misc_uplift,
                TO_NUMBER (NVL (mp.attribute14, '5')) rounding
           FROM mtl_parameters mp
          WHERE mp.organization_code = x_organization_code;

      v_organization_rec      c_organizations%ROWTYPE;

      --
      CURSOR c1 (
         x_organization_code    VARCHAR2,
         x_item                 VARCHAR2)
      IS
         SELECT msi.inventory_item_id,
                msi.segment1,
                msi.organization_id,
                msi.FIXED_LOT_MULTIPLIER,
                msi.shrinkage_rate,
                msi.DEFAULT_INCLUDE_IN_ROLLUP_FLAG,
                msi.INVENTORY_ASSET_FLAG
           FROM mtl_system_items msi, mtl_parameters mp
          WHERE     msi.organization_id = mp.organization_id
                AND mp.organization_code = mp.organization_code
                AND msi.segment1 = x_item
                AND mp.organization_code = x_organization_code;

      v_master_item_rec       c1%ROWTYPE;
      v_org_item_rec          c1%ROWTYPE;

      CURSOR c_item_categories (
         x_organization_id     NUMBER,
         x_inventory_tem_id    NUMBER)
      IS
         SELECT segment2 Item_Category_Segment2, segment3 Item_Category_Segment3
           FROM mtl_item_categories_v a
          WHERE     a.inventory_item_id = x_inventory_tem_id
                AND a.organization_id = x_organization_id
                AND a.category_set_name = 'Inventory';

      v_item_category_rec     c_item_categories%ROWTYPE;

      --
      CURSOR c_cost_types (
         x_sysdate DATE)
      IS
         SELECT cct.cost_type current_cost_type,
                cct.cost_type_id current_cost_type_id,
                (SELECT cost_type
                   FROM gl_periods gp, cst_cost_types cct
                  WHERE gp.period_set_name = 'HAE_GLOBAL_CAL' AND gp.period_type = '21' -- ver 2.0 added by Vasil 11/3/2011
                        AND TRUNC (x_sysdate) BETWEEN gp.start_date
                                                  AND NVL (gp.end_date, x_sysdate)
                        AND cct.cost_type =
                               'FY'
                               || TO_CHAR (
                                     TO_DATE (
                                        period_year + DECODE (period_num,  1, -1,  12, 1,  NULL),
                                        'YYYY'),
                                     'YY')
                               || 'PEND'                                        -- current_cost_type
                                        )
                   other_cost_type,
                (SELECT cost_type_id
                   FROM gl_periods gp, cst_cost_types cct
                  WHERE gp.period_set_name = 'HAE_GLOBAL_CAL' AND gp.period_type = '21' -- ver 2.0 added by Vasil 11/3/2011
                        AND TRUNC (x_sysdate) BETWEEN gp.start_date
                                                  AND NVL (gp.end_date, x_sysdate)
                        AND cct.cost_type =
                               'FY'
                               || TO_CHAR (
                                     TO_DATE (
                                        period_year + DECODE (period_num,  1, -1,  12, 1,  NULL),
                                        'YYYY'),
                                     'YY')
                               || 'PEND'                                        -- current_cost_type
                                        )
                   other_cost_type_id,
                period_year,
                period_num
           FROM gl_periods gp, cst_cost_types cct
          WHERE     gp.period_set_name = 'HAE_GLOBAL_CAL'
                AND gp.period_type = '21'                        -- ver 2.0 added by Vasil 11/3/2011
                AND TRUNC (x_sysdate) BETWEEN gp.start_date AND NVL (gp.end_date, x_sysdate)
                AND cct.cost_type = 'FY' || TO_CHAR (TO_DATE (period_year, 'YYYY'), 'YY') || 'PEND' -- current_cost_type
                                                                                                   ;

      v_cost_type_rec         c_cost_types%ROWTYPE;

      --
      CURSOR c_item_costs (
         x_organization_code    VARCHAR2,
         x_item                 VARCHAR2,
         x_cost_type            VARCHAR2)
      IS
         SELECT msi.inventory_item_id,
                msi.segment1,
                msi.organization_id,
                cct.cost_type,
                cic.material_cost,
                cic.item_cost,
                'N' Update_Frozen_Flag,
                DECODE (cic.inventory_asset_flag, 1, 'Y', 'N') Inventory_Asset,
                cic.lot_size,
                DECODE (cic.based_on_rollup_flag, 1, 'Y', 'N') based_on_rollup,
                cic.shrinkage_rate,
                cic.defaulted_flag
           FROM mtl_system_items msi,
                mtl_parameters mp,
                cst_item_costs cic,
                cst_cost_types cct
          WHERE     msi.organization_id = mp.organization_id
                AND mp.organization_code = mp.organization_code
                AND msi.segment1 = x_item
                AND mp.organization_code = x_organization_code
                AND msi.organization_id = cic.organization_id
                AND msi.inventory_item_id = cic.inventory_item_id
                AND cic.cost_type_id = cct.cost_type_id
                AND cct.cost_type = x_cost_type;

      v_item_cost_rec         c_item_costs%ROWTYPE;
      v_org_item_cost_rec     c_item_costs%ROWTYPE;

      CURSOR c_operating_units (
         x_organization_code VARCHAR2)
      IS
         SELECT ood.operating_unit,
                hou.name,
                sob.set_of_books_id,
                sob.name sob,
                sob.short_name sob_short_name,
                sob.currency_code
           FROM org_organization_definitions ood, hr_operating_units hou, gl_sets_of_books sob
          WHERE     ood.operating_unit = hou.organization_id
                AND ood.organization_code = x_organization_code                              --'BTO'
                AND hou.set_of_books_id = sob.set_of_books_id;

      v_operating_unit_rec    c_operating_units%ROWTYPE;

      CURSOR c_conversion_rates (
         x_sysdate                 DATE,
         x_target_currency_code    VARCHAR2)
      IS
         SELECT conversion_rate
           FROM apps.gl_daily_rates
          WHERE     conversion_type = 'Corporate'
                AND conversion_date = TRUNC (x_sysdate)
                AND from_currency = 'USD'
                AND to_currency = x_target_currency_code;

      v_default_basis_type    VARCHAR2 (1) := NULL;
      v_conversion_rate       NUMBER := NULL;
      v_uplift                NUMBER := 1;
      v_new_cost              NUMBER;
      v_zero_rate             NUMBER := 1;
      v_error_message         VARCHAR2 (2000);
      v_return_status         NUMBER := 0;
      v_sysdate               DATE;
      v_period_sysdate        DATE;
      v_debug_step            NUMBER := 0;
      v_cost_tab_index        NUMBER;
      v_org_item_cost_found   BOOLEAN;
   BEGIN
      v_sysdate := xxha_ilink_ext.get_v_sysdate;
      v_period_sysdate := xxha_ilink_ext.get_period_sysdate;

      --ORG_CODE NOT FOUND
      OPEN c_organizations (p_organization_code);

      FETCH c_organizations INTO v_organization_rec;

      IF c_organizations%NOTFOUND
      THEN
         CLOSE c_organizations;

         -- This must be buy
         v_error_message := 'ORG_NOT_DEFINED';
         v_return_status := 2;
         p_item_cost_tab (1).Return_Status := 2;        -- 0=Normal Completion, 2=Warning, 3 = Error
         p_item_cost_tab (1).Error_Message := v_error_message;
         RETURN;
      END IF;

      CLOSE c_organizations;

      --
      --Item in MST Org
      OPEN c1 ('MST', p_Item_number);

      FETCH c1 INTO v_master_item_rec;

      IF c1%NOTFOUND
      THEN
         IF UPPER (p_item_type) = 'MAKE'
         THEN
            CLOSE c1;

            p_item_cost_tab.delete;
            p_item_price_tab.delete;
            p_item_cost_tab (1).Return_Status := 0;     -- 0=Normal Completion, 2=Warning, 3 = Error
            p_item_cost_tab (1).Error_Message := v_error_message;
            RETURN;
         END IF;

         v_master_item_rec.organization_id := 103;
      -- BUY Item not in MST need to calculate cost
      END IF;

      CLOSE c1;

      --
      OPEN c_item_categories (v_master_item_rec.organization_id,
                              v_master_item_rec.inventory_item_id);

      FETCH c_item_categories INTO v_item_category_rec;

      CLOSE c_item_categories;

      --
      OPEN c_cost_types (v_period_sysdate);

      FETCH c_cost_types INTO v_cost_type_rec;

      IF c_cost_types%NOTFOUND
      THEN
         CLOSE c_cost_types;

         p_item_cost_tab (1).Return_Status := 2;        -- 0=Normal Completion, 2=Warning, 3 = Error
         p_item_cost_tab (1).Error_Message := '*COST_TYPE_NOT_DEFINED:' || p_Organization_code;
         RETURN;
      END IF;

      --dbms_output.put_line(v_cost_type_rec.period_year);
      --dbms_output.put_line(v_cost_type_rec.period_num);
      --dbms_output.put_line(v_cost_type_rec.other_cost_type);
      --dbms_output.put_line(to_char(v_cost_type_rec.other_cost_type_id));
      -- found cost_type
      CLOSE c_cost_types;

      BEGIN
         SELECT DECODE (default_basis_type, 1, 'Y', 'N')
           INTO v_default_basis_type
           FROM BOM_RESOURCES_ALL_V
          WHERE resource_code = 'Material' AND organization_id = v_master_item_rec.organization_id;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            --error no current cost type defined
            v_error_message :=
                  v_error_message
               || '*RESOURCE_Material_NOTDEFINED_FOR_ORG:'
               || p_Organization_code
               || '*';
            v_default_basis_type := 'N';
      END;

      -- let us first do Item Cost for existing item
      -- Frozen cost exists and Master Item exists
      OPEN c_item_costs ('MST', p_Item_number, 'Frozen');

      FETCH c_item_costs INTO v_item_cost_rec;

      IF c_item_costs%NOTFOUND
      THEN
         v_item_cost_rec.cost_type := '*NOTFOUND*';

         IF SUBSTR (NVL (UPPER (v_organization_rec.zero_cost_flag), 'N'), 1, 1) = 'Y'
         THEN
            v_item_cost_rec.update_frozen_flag := 'N';
            v_item_cost_rec.item_cost := 0;                                                 ----????
            v_item_cost_rec.material_cost := 0;                                            -----????
         ELSE
            v_item_cost_rec.update_frozen_flag := 'Y';
            v_item_cost_rec.item_cost := p_agile_cost;                                      ----????
            v_item_cost_rec.material_cost := p_agile_cost;                                 -----????
         END IF;
      END IF;

      CLOSE c_item_costs;

      --org/item attributes
      OPEN c1 (p_organization_code, p_Item_number);

      FETCH c1 INTO v_org_item_rec;

      CLOSE c1;

      --ou info
      OPEN c_operating_units (p_organization_code);

      FETCH c_operating_units INTO v_operating_unit_rec;

      IF c_operating_units%NOTFOUND
      THEN
         CLOSE c_operating_units;

         --error no operating unit
         RETURN;
      END IF;

      CLOSE c_operating_units;

      --dbms_output.put_line(v_operating_unit_rec.currency_code);
      v_uplift := 1;
      v_zero_rate := 1;

      IF v_organization_rec.service_org_flag = 'Y'
         AND UPPER (NVL (v_item_category_rec.Item_Category_Segment3, p_Item_Category_Segment3)) =
                'MACH'
      THEN
         v_zero_rate := 0;
         v_conversion_rate := 0;
      ELSE
         /*
         Reverted back
         commented to alow for uplift in USD also
         */



         OPEN c_conversion_rates (v_sysdate, v_operating_unit_rec.currency_code);

         FETCH c_conversion_rates INTO v_conversion_rate;

         CLOSE c_conversion_rates;

         --modified by hkollipara on 7/30/2014 . Uplift should be applied regardless of USD org or not >>START
         IF v_operating_unit_rec.currency_code = 'USD'
         THEN
            --  v_uplift := 1; -- commented by hkollipara.
            v_conversion_rate := 1;
         END IF;

         --dbms_output.put_line('Currency Code ' ||v_operating_unit_rec.currency_code);
         IF UPPER (NVL (v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) =
               'DISP'
         THEN
            v_uplift := NVL (TO_NUMBER (v_organization_rec.disp_uplift), 1);
         ELSIF UPPER (NVL (v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) =
                  'EQUI'
         THEN                                                    --hkollipara.. changed EQIP to EQUI
            v_uplift := NVL (TO_NUMBER (v_organization_rec.eqip_uplift), 1);
         ELSIF UPPER (NVL (v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) =
                  'SERV'
         THEN
            v_uplift := NVL (TO_NUMBER (v_organization_rec.serv_uplift), 1);
         ELSIF UPPER (NVL (v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) =
                  'SFTW'
         THEN
            v_uplift := NVL (TO_NUMBER (v_organization_rec.sftw_uplift), 1);
         ELSIF UPPER (NVL (v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) =
                  'MISC'
         THEN
            v_uplift := NVL (TO_NUMBER (v_organization_rec.misc_uplift), 1);
         ELSE
            v_uplift := 1;
         END IF;
      -- <<END. code changes by hkollipara on 7/30/2014. Uplift should be applied regardless on USD org or not
      /* Commented uplift not needed for USD Org/operating
      -- Uplift changes as follows
      if v_operating_unit_rec.currency_code = 'USD' then
        --v_uplift := 1;
        v_conversion_rate := 1;
      else
        open c_conversion_rates(v_sysdate, v_operating_unit_rec.currency_code);
        fetch c_conversion_rates into v_conversion_rate;
        close c_conversion_rates;
        --dbms_output.put_line('Currency Code ' ||v_operating_unit_rec.currency_code);
      end if;
      if upper(nvl(v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) = 'DISP' then
        v_uplift := nvl(to_number(v_organization_rec.disp_uplift),1);
      elsif upper(nvl(v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) = 'EQIP' then
        v_uplift := nvl(to_number(v_organization_rec.eqip_uplift),1);
      elsif upper(nvl(v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) = 'SERV' then
        v_uplift := nvl(to_number(v_organization_rec.serv_uplift),1);
      elsif upper(nvl(v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) = 'SFTW' then
        v_uplift := nvl(to_number(v_organization_rec.sftw_uplift),1);
      elsif upper(nvl(v_item_category_rec.Item_Category_Segment2, p_Item_Category_Segment2)) = 'MISC' then
        v_uplift := nvl(to_number(v_organization_rec.misc_uplift),1);
      else
        v_uplift := 1;
      end if;
      */
      END IF;

      --dbms_output.put_line('Step 6');
      ----?????? is there a flag that says cost should be zero
      DBMS_OUTPUT.put_line (
            'v_zero_rate'
         || TO_CHAR (v_zero_rate)
         || '*v_conversion_rate'
         || TO_CHAR (v_conversion_rate)
         || '*v_uplift'
         || TO_CHAR (v_uplift)
         || '*v_item_cost_rec.material_cost'
         || v_item_cost_rec.material_cost
         || ',v_organization_rec.rounding'
         || TO_CHAR (v_organization_rec.rounding));
      v_new_cost :=
         ROUND (v_zero_rate * v_conversion_rate * v_uplift * v_item_cost_rec.item_cost,
                v_organization_rec.rounding); ----?????  // hkollipara changed material_cost to item_cost 7/17/2014
      v_cost_tab_index := 1;
      --check if New Cost is Same as Cost in EBS is same do not create a record
      --check for Cost types in the organization
      --If different sent it over else do not send record
      -- get item cost for organization/Current costtype
      v_org_item_cost_found := TRUE;

      OPEN c_item_costs (p_Organization_code, p_Item_number, v_cost_type_rec.current_cost_type);

      FETCH c_item_costs INTO v_org_item_cost_rec;

      IF c_item_costs%NOTFOUND
      THEN
         v_org_item_cost_found := FALSE;
      END IF;

      CLOSE c_item_costs;

      IF (NOT ( (NOT v_org_item_cost_found) OR v_item_cost_rec.material_cost != v_new_cost))
      THEN
         --dbms_output.put_line('Step 7*v_new_cost'||to_char(v_new_cost)||'*v_item_cost_rec.material_cost'||to_char(v_item_cost_rec.material_cost));
         NULL;
      END IF;

      IF ( (NOT v_org_item_cost_found) OR v_item_cost_rec.item_cost != v_new_cost)
      THEN                                -- hkollipara changed material_cost to item_cost 7/17/2014
         -- costtype/orgcost not found
         p_item_cost_tab (v_cost_tab_index).Record_Type := 'COST';
         p_item_cost_tab (v_cost_tab_index).Cost_Type := v_cost_type_rec.current_cost_type;
         p_item_cost_tab (v_cost_tab_index).Cost_Type_ID := v_cost_type_rec.current_cost_type_id;

         IF v_conversion_rate IS NULL
         THEN
            p_item_cost_tab (v_cost_tab_index).Return_Status := 2;
            p_item_cost_tab (v_cost_tab_index).Error_Message :=
               v_error_message || '*CONVERSION_RATE_IS_NULL:' || p_Organization_code;
         ELSE
            IF SUBSTR (NVL (UPPER (v_organization_rec.zero_cost_flag), 'N'), 1, 1) = 'Y'
            THEN
               p_item_cost_tab (v_cost_tab_index).Cost := 0;
            ELSE
               p_item_cost_tab (v_cost_tab_index).Cost := v_new_cost;
            END IF;

            p_item_cost_tab (v_cost_tab_index).Return_Status := 0; -- 0=Normal Completion, 2=Warning, 3 = Error
            p_item_cost_tab (v_cost_tab_index).Error_Message := v_error_message;
         END IF;

         IF SUBSTR (NVL (UPPER (v_organization_rec.zero_cost_flag), 'N'), 1, 1) = 'Y'
         THEN
            p_item_cost_tab (v_cost_tab_index).Update_Frozen_Flag := 'N'; --v_item_cost_rec.Update_Frozen_Flag;
         ELSE
            p_item_cost_tab (v_cost_tab_index).Update_Frozen_Flag := 'Y'; --v_item_cost_rec.Update_Frozen_Flag;\
         END IF;

         p_item_cost_tab (v_cost_tab_index).Lot_Size := v_item_cost_rec.lot_size;
         p_item_cost_tab (v_cost_tab_index).Basis_Type := v_default_basis_type;
         p_item_cost_tab (v_cost_tab_index).Based_on_Rollup := v_item_cost_rec.based_on_rollup;
         p_item_cost_tab (v_cost_tab_index).Shrinkage_Rate := v_item_cost_rec.Shrinkage_Rate;
         p_item_cost_tab (v_cost_tab_index).Inventory_Asset := v_item_cost_rec.Inventory_Asset;
         --
         v_cost_tab_index := v_cost_tab_index + 1;
      ELSE
         --dbms_output.put_line('current-cost-type cost is same in MST');
         NULL;
      END IF;

      --
      --
      IF v_cost_type_rec.other_cost_type IS NOT NULL
      THEN
         --check for Cost types in the organization
         --If different sent it over else do not send record
         -- get item cost for organization/Current costtype
         v_org_item_cost_found := TRUE;

         OPEN c_item_costs (p_Organization_code, p_Item_number, v_cost_type_rec.other_cost_type);

         FETCH c_item_costs INTO v_org_item_cost_rec;

         IF c_item_costs%NOTFOUND
         THEN
            v_org_item_cost_found := FALSE;
         END IF;

         CLOSE c_item_costs;

         IF ( (NOT v_org_item_cost_found) OR v_item_cost_rec.item_cost != v_new_cost)
         THEN                              -- hkolipara changed material_cost to item_cost 7/17/2014
            -- other costtype/orgcost not found
            p_item_cost_tab (v_cost_tab_index).Record_Type := 'COST';
            p_item_cost_tab (v_cost_tab_index).Cost_Type := v_cost_type_rec.other_cost_type;
            p_item_cost_tab (v_cost_tab_index).Cost_Type_ID := v_cost_type_rec.other_cost_type_id;

            IF v_conversion_rate IS NULL
            THEN
               p_item_cost_tab (v_cost_tab_index).Return_Status := 2;
               p_item_cost_tab (v_cost_tab_index).Error_Message :=
                  v_error_message || '*CONVERSION_RATE_IS_NULL:' || p_Organization_code;
            ELSE
               IF SUBSTR (NVL (UPPER (v_organization_rec.zero_cost_flag), 'N'), 1, 1) = 'Y'
               THEN
                  p_item_cost_tab (v_cost_tab_index).Cost := 0;
               ELSE
                  p_item_cost_tab (v_cost_tab_index).Cost := v_new_cost;
               END IF;

               p_item_cost_tab (v_cost_tab_index).Return_Status := 0; -- 0=Normal Completion, 2=Warning, 3 = Error
               p_item_cost_tab (2).Error_Message := v_error_message;
            END IF;

            p_item_cost_tab (v_cost_tab_index).Update_Frozen_Flag := 'N'; --v_item_cost_rec.Update_Frozen_Flag;
            p_item_cost_tab (v_cost_tab_index).Lot_Size := v_item_cost_rec.lot_size;
            p_item_cost_tab (v_cost_tab_index).Basis_Type := v_default_basis_type;
            p_item_cost_tab (v_cost_tab_index).Based_on_Rollup := v_item_cost_rec.based_on_rollup;
            p_item_cost_tab (v_cost_tab_index).Shrinkage_Rate := v_item_cost_rec.Shrinkage_Rate;
            p_item_cost_tab (v_cost_tab_index).Inventory_Asset := v_item_cost_rec.Inventory_Asset;
         ELSE
            --dbms_output.put_line('other-cost-type cost is same in MST');
            NULL;
         END IF;
      END IF;

      RETURN;
   END;

   PROCEDURE get_info (p_Organization_code            VARCHAR2,                        --varchar2(3)
                       p_Item_Number                  VARCHAR2,                       --varchar2(40)
                       p_Agile_Cost                   NUMBER,
                       p_Item_Type                    VARCHAR2,                      --varchar2(240)
                       p_Item_Category_Segment2       VARCHAR2,                      --varchar2(240)
                       p_Item_Category_Segment3       VARCHAR2,                      --varchar2(240)
                       p_item_cost_tab            OUT t_item_cost,
                       p_item_price_tab           OUT t_item_price)
   IS
   BEGIN
      get_cost_rec (p_Organization_code,
                    p_Item_Number,
                    p_Agile_Cost,
                    p_Item_Type,
                    p_Item_Category_Segment2,
                    p_Item_Category_Segment3,
                    p_item_cost_tab,
                    p_item_price_tab);
      --if p_item_cost_tab.count > 0 then
      --dbms_output.put_line('need to do price list');
      get_price_rec (p_Organization_code,
                     p_Item_Number,
                     p_Agile_Cost,
                     p_Item_Type,
                     p_Item_Category_Segment2,
                     p_Item_Category_Segment3,
                     p_item_cost_tab,
                     p_item_price_tab);
   --end if;
   END;
END;
/
