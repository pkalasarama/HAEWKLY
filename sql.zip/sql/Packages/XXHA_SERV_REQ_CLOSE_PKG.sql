create or replace PACKAGE XXHA_SERV_REQ_CLOSE_PKG AUTHID CURRENT_USER
AS

/***********************************************************************************************************************************
* Package Name : XXHA_SERV_REQ_CLOSE_PKG                                                                                           *
*                                                                                                                                  *
* Purpose      : This package will process all Service Requests (and Depot Repair Orders, if they exist) that are determined       *
*                 to be eligible for closure based upon selected criteria.                                                         *
*                                                                                                                                  *
* Procedures   : TRANSACTION_MAIN                                                                                                  *
*                CHECK_DR_SR_TASKS_DAYS                                                                                            *
*                CHECK_DR_SR_TASK_STATUS                                                                                           *
*                EDITS_PRE_PROCESS                                                                                                 *
*                EDITS_SR_WITH_DR                                                                                                  *
*                EDITS_SR_WITHOUT_DR                                                                                               *
*                DEBRIEF_PROCESS_WITH_DR                                                                                           *
*                DEBRIEF_PROCESS_WITHOUT_DR                                                                                        *
*                DEBRIEF_TASK_STATUS_UPDATE                                                                                        *
*                DEBRIEF_TASK_ASSIGN_UPDATE                                                                                        *
*                DEBRIEF_SUBMIT_CONCURRENT_PGM                                                                                     *
*                FIND_RECENT_SR                                                                                                    *
*                UPDATE_OM_INTERFACE                                                                                               *
*                ORDER_SUBMIT_DETERMINATION                                                                                        *
*                ORDER_SUBMIT_WITHOUT_CC                                                                                           *
*                ORDER_SUBMIT_WITH_CC                                                                                              *
*                ORDER_UPDATE_WITH_CC                                                                                              *
*                ORDER_UPDATE_SET_TO_BOOKED                                                                                        *
*                UPDATE_LOGISTIC_LINES_FOR_DR                                                                                      *
*                CLOSE_DEPOT_REPAIR_ORDERS                                                                                         *
*                EDITS_POST_PROCESS                                                                                                *
*                EDITS_POST_SR_WITH_DR                                                                                             *
*                EDITS_POST_SR_WITHOUT_DR                                                                                          *
*                CLOSE_SERVICE_REQUEST                                                                                             *
*                REPORT_SUBMISSION                                                                                                 *
*                WRITE_HEADER                                                                                                      *
*                WRITE_DETAIL                                                                                                      *
*                                                                                                                                  *
* Change History                                                                                                                   *
*                                                                                                                                  *
* Ver        Date            Author                    Description                                                                 *
* ------     -----------     ----------------------    -----------------------------------------------                             *
* 1.0        29-JUN-2016     Bruce Marcoux             Initial Package creation                                                    *
*                                                                                                                                  *
* 2.0        04-APR-2017     Bruce Marcoux             ESC115336/INC0104753 - Concurrent program does not end                      *
*                                                        Issue was with code in the procedure 'DEBRIEF_SUBMIT_CONCURRENT_PGM'      *
*                                                        as it was looping when checking the status of the submitted debrief.      *
*                                                        Modified code to check Status_Code for the submitted program.  If         *
*                                                        Status_Code has 'E' or 'D', code will drop out of loop that checks        *
*                                                        the job for completion and will return an error to the calling            *
*                                                        procedure.  The calling procedures were modified to check for an          *
*                                                        error and handle it accordingly.                                          *
*                                                                                                                                  *
* 3.0        04-MAY-2017     Bruce Marcoux             INC0106532 - Service Request Closure program taking longer than normal      *
*                                                        to process.                                                               *
*                                                        Modified code to not write out debug statements.  Processing will         *
*                                                        check P_Debug for value instead of always writing debugs to table.        *
*                                                        Commented out unncessary FND_FILE.PUT_LINE statements.                    *
*                                                                                                                                  *
* 4.0        17-MAY-2017     Bruce Marcoux              INC0107158 - Task Assignment Error Message unclear                         *
*                                                        Corrected code when checking DFF's Context Value for Task Assingments     *
*                                                        and Task Assignments Additional.                                          *
*                                                        Checking additional columns:                                              *
*                                                        AND fdfv1.context_required_flag           = 'Y'                           *
*                                                        AND fdfv1.context_user_override_flag      = 'Y'                           *
*                                                        AND fdfcv1.enabled_flag                   = 'Y'                           *
*                                                        AND fdfcuv1.display_flag                  = 'Y'                           * 
*                                                        AND fdfcuv1.enabled_flag                  = 'Y'                           *
*                                                                                                                                  *
* 5.0        06-JUN-2017     Bruce Marcoux              INC0107201 - Service Batch - Records processed with errors email not sent. *
*                                                        Modification to place spreadsheets on server and be picked up by          *
*                                                        WebMethods processing and placed on shared drive instead of being         *
*                                                        emailed as an attachment. Added PARM: P_REPORT_PROGRAM_ID.                *
************************************************************************************************************************************/

-- Global Variable Declaration
g_Value_Set_ID                    NUMBER;
g_Session_ID                      NUMBER;
g_SysDate                         DATE;
g_Debug                           VARCHAR(03);                                  -- g_Debug Values: 'YES', 'NO'
g_Operating_Unit_Group            HR_ORGANIZATION_INFORMATION_V.Attribute1%TYPE;
g_Process_Type                    XXHA_SERV_REQ_CLOSE_DTL.PROCESS_TYPE%TYPE;    -- g_Process_Type Values (R/U): R=Report Only, U=Update and Report
g_Concurrent_Program_Name         fnd_concurrent_programs.CONCURRENT_PROGRAM_NAME%TYPE;
g_SCT_Responsibility_Name         fnd_Responsibility_tl.Responsibility_name%TYPE;
g_FSE_Responsibility_Name         fnd_Responsibility_tl.Responsibility_name%TYPE;
g_Current_Responsibility_ID       fnd_Responsibility_tl.Responsibility_ID%TYPE;
g_Current_User_ID                 FND_USER.User_ID%TYPE;
g_Current_Resp_Appl_ID            fnd_Responsibility_tl.Application_ID%TYPE;
g_Application_Short_Name          fnd_application.APPLICATION_SHORT_NAME%TYPE;
g_Sequence_Nbr_HDR                XXHA_SERV_REQ_CLOSE_DTL.SEQUENCE_NBR%TYPE     := 0;
g_Error_Type_ERR                  XXHA_SERV_REQ_CLOSE_DTL.ERROR_TYPE%TYPE       := 'ERR';
g_Error_Type_INF                  XXHA_SERV_REQ_CLOSE_DTL.ERROR_TYPE%TYPE       := 'INF';
g_Error_Type_DBG                  XXHA_SERV_REQ_CLOSE_DTL.ERROR_TYPE%TYPE       := 'DBG';

PROCEDURE TRANSACTION_MAIN(
                      x_errbuf                             OUT VARCHAR2
                    , x_retcode                            OUT VARCHAR2
                    , P_Process_Type                       IN  VARCHAR2
                    , P_Operating_Unit_Group               IN  VARCHAR2
                    , P_Concurrent_Program_Name            IN  VARCHAR2
                    , P_Service_Request_Nbr                IN  VARCHAR2
                    , P_Org_ID                             IN  NUMBER
                    , P_Debug                              IN  VARCHAR2
                    , P_Concurrent_Pgm                     IN  VARCHAR2
                    , P_Template_Code                      IN  VARCHAR2
                    , P_Value_Set_ID                       IN  NUMBER
                    , P_Task_Number_Days                   IN  NUMBER
                    , P_SR_Creation_Date                   IN  VARCHAR2
                    , P_SR_Creation_Date_To                IN  VARCHAR2
                    , P_Purge_Number_Days                  IN  NUMBER
                    , P_EMAIL_SERVER                       IN  VARCHAR2
                    , P_EMAIL_PORT                         IN  VARCHAR2
                    , P_TEST_EMAIL_ACCOUNT                 IN  VARCHAR2
                    , P_PRODUCTION_INSTANCE_DB_NAME        IN  VARCHAR2
                    , P_Value_Set_ID_EMail                 IN  NUMBER
                    , P_REPORT_PROGRAM_ID                  IN  NUMBER
                    );

PROCEDURE CHECK_DR_SR_TASKS_DAYS(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_Task_Number_Days                   IN  NUMBER
                    , P_CHECK_DR_SR_TASKS_DAYS             OUT VARCHAR2
                    );

PROCEDURE CHECK_DR_SR_TASK_STATUS(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_CHECK_DR_SR_TASK_STATUS            OUT VARCHAR2
                    );

PROCEDURE EDITS_PRE_PROCESS(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_EDITS_PRE_PROCESS                  OUT VARCHAR2
                    );

PROCEDURE EDITS_SR_WITH_DR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_EDITS_SR_WITH_DR                   OUT VARCHAR2
                    );

PROCEDURE EDITS_SR_WITHOUT_DR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_EDITS_SR_WITHOUT_DR                OUT VARCHAR2
                    );

PROCEDURE DEBRIEF_PROCESS_WITH_DR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Task_ID                            IN  NUMBER
                    , P_DEBRIEF_PROCESS_WITH_DR            OUT VARCHAR2
                    );

PROCEDURE DEBRIEF_PROCESS_WITHOUT_DR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Task_ID                            IN  NUMBER
                    , P_DEBRIEF_PROCESS_WITHOUT_DR         OUT VARCHAR2
                    );

PROCEDURE DEBRIEF_TASK_STATUS_UPDATE(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Task_ID                            IN  NUMBER
                    , P_Source_Object_Type_Code            IN  VARCHAR2
                    , P_DEBRIEF_TASK_STATUS_UPDATE         OUT VARCHAR2
                    );

PROCEDURE DEBRIEF_TASK_ASSIGN_UPDATE(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Task_ID                            IN  NUMBER
                    , P_Source_Object_Type_Code            IN  VARCHAR2
                    , P_DEBRIEF_TASK_ASSIGN_UPDATE         OUT VARCHAR2
                    );

PROCEDURE DEBRIEF_SUBMIT_CONCURRENT_PGM(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_API_Version                        IN  NUMBER
                    , P_Debrief_Number                     IN  VARCHAR2
                    , P_Debrief_Header_ID                  IN  NUMBER
                    , P_User_ID                            IN  NUMBER
                    , P_Type                               IN  VARCHAR2
                    , P_DEBRIEF_SUBMIT_CONCURRENT          OUT VARCHAR2         -- 2017/04/04 - Added output parameter 'P_DEBRIEF_SUBMIT_CONCURRENT'
                    );

-- FIND_RECENT_SR (NOT CURRENTLY ACTIVE)
PROCEDURE FIND_RECENT_SR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Serial_Number                      IN  VARCHAR2
                    , P_Incident_Date                      IN  DATE
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_FIND_RECENT_SR                     OUT VARCHAR2
                    );

PROCEDURE UPDATE_OM_INTERFACE(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Serial_Number                      IN  VARCHAR2
                    , P_Incident_Date                      IN  DATE
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_UPDATE_OM_INTERFACE                OUT VARCHAR2
                    );

-- ORDER_SUBMIT_DETERMINATION (NOT CURRENTLY ACTIVE)
PROCEDURE ORDER_SUBMIT_DETERMINATION(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Serial_Number                      IN  VARCHAR2
                    , P_Incident_Date                      IN  DATE
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_ORDER_SUBMIT_DETERMINATION         OUT VARCHAR2
                    );

-- ORDER_SUBMIT_WITHOUT_CC (NOT CURRENTLY ACTIVE)
PROCEDURE ORDER_SUBMIT_WITHOUT_CC(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Serial_Number                      IN  VARCHAR2
                    , P_Incident_Date                      IN  DATE
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_ORDER_SUBMIT_WITHOUT_CC            OUT VARCHAR2
                    );

-- ORDER_SUBMIT_WITH_CC (NOT CURRENTLY ACTIVE)
PROCEDURE ORDER_SUBMIT_WITH_CC(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Serial_Number                      IN  VARCHAR2
                    , P_Incident_Date                      IN  DATE
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_ORDER_SUBMIT_WITH_CC               OUT VARCHAR2
                    );

-- ORDER_UPDATE_WITH_CC (NOT CURRENTLY ACTIVE)
PROCEDURE ORDER_UPDATE_WITH_CC(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Serial_Number                      IN  VARCHAR2
                    , P_Incident_Date                      IN  DATE
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_Order_Number                       IN  VARCHAR2
                    , P_Header_ID                          IN  NUMBER
                    , P_ORDER_UPDATE_WITH_CC               OUT VARCHAR2
                    );

-- ORDER_UPDATE_SET_TO_BOOKED (NOT CURRENTLY ACTIVE)
PROCEDURE ORDER_UPDATE_SET_TO_BOOKED(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Serial_Number                      IN  VARCHAR2
                    , P_Incident_Date                      IN  DATE
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_Order_Number                       IN  VARCHAR2
                    , P_Header_ID                          IN  NUMBER
                    , P_ORDER_UPDATE_SET_TO_BOOKED         OUT VARCHAR2
                    );

PROCEDURE UPDATE_LOGISTIC_LINES_FOR_DR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Close_Depot_Repair_Order           OUT VARCHAR2
                    , P_UPDATE_LOGISTIC_LINES_FOR_DR       OUT VARCHAR2
                    );

PROCEDURE CLOSE_DEPOT_REPAIR_ORDERS(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_CLOSE_DEPOT_REPAIR_ORDERS          OUT VARCHAR2
                    );

PROCEDURE EDITS_POST_PROCESS(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_EDITS_POST_PROCESS                 OUT VARCHAR2
                    );

PROCEDURE EDITS_POST_SR_WITH_DR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_EDITS_POST_SR_WITH_DR              OUT VARCHAR2
                    );

PROCEDURE EDITS_POST_SR_WITHOUT_DR(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_EDITS_POST_SR_WITHOUT_DR           OUT VARCHAR2
                    );

PROCEDURE CLOSE_SERVICE_REQUEST(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_CLOSE_SERVICE_REQUEST              OUT VARCHAR2
                    );

PROCEDURE REPORT_SUBMISSION(
                      P_Session_ID                         IN  NUMBER
                    , P_Current_User_ID                    IN  NUMBER
                    , P_CONCURRENT_PGM                     IN  VARCHAR2
                    , P_TEMPLATE_CODE                      IN  VARCHAR2
                    , P_Debug                              IN  VARCHAR2
                    , P_EMAIL_SERVER                       IN  VARCHAR2
                    , P_EMAIL_PORT                         IN  VARCHAR2
                    , P_TEST_EMAIL_ACCOUNT                 IN  VARCHAR2
                    , P_PRODUCTION_INSTANCE_DB_NAME        IN  VARCHAR2
                    , P_Value_Set_ID_EMail                 IN  NUMBER
                    , P_REPORT_PROGRAM_ID                  IN  NUMBER
                    );

PROCEDURE WRITE_HEADER(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Incident_Number                    IN  VARCHAR2
                    , P_Incident_Status_ID                 IN  NUMBER
                    , P_Status_Code                        IN  VARCHAR2
                    , P_Closed_Flag                        IN  VARCHAR2
                    , P_Incident_Type_ID                   IN  NUMBER
                    , P_Incident_Type                      IN  VARCHAR2
                    , P_Inventory_Item_ID                  IN  NUMBER
                    , P_Inventory_Item_Number              IN  VARCHAR2
                    , P_Inventory_Item_Serial_Number       IN  VARCHAR2
                    , P_Contract_ID                        IN  NUMBER
                    , P_Contract_Number                    IN  VARCHAR2
                    , P_Country                            IN  VARCHAR2
                    , P_Errors_Exist                       IN  VARCHAR2
                    );

PROCEDURE WRITE_DETAIL(
                      P_Org_ID                             IN  NUMBER
                    , P_Incident_ID                        IN  NUMBER
                    , P_Amount                             IN  NUMBER
                    , P_Error_Type                         IN  VARCHAR2
                    , P_Error_Message                      IN  VARCHAR2
                    );

END XXHA_SERV_REQ_CLOSE_PKG;