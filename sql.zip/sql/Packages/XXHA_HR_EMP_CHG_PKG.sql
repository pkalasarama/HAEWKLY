CREATE OR REPLACE PACKAGE      xxha_hr_emp_chg_pkg
IS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_HR_EMP_CHG_PKG
*  Description:
*      This package is written to create a report of employee changes (i.e.
*      table row inserts only).  The primary purpose is to keep 3rd party payroll
*      information in sync with HR.
*      This package is called from Oracle Reports.
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  01-Dec-2008       Ralph Sneep       Created New.
*
******************************************************************************/

PROCEDURE Main ( p_errbuf            OUT VARCHAR2
                ,p_retcode           OUT NUMBER
                ,p_date_from         IN  DATE
                ,p_date_to           IN  DATE
                ,p_business_group_id NUMBER);

END xxha_hr_emp_chg_pkg;

/


CREATE OR REPLACE PACKAGE BODY      xxha_hr_emp_chg_pkg
IS
/*****************************************************************************
*  ORACLE CONSULTING
*
*  Package:  XXHA_HR_EMP_CHG_PKG
*  Description:
*      This package is written to create a report of employee changes (i.e.
*      table row inserts only).  The primary purpose is to keep 3rd party payroll
*      information in sync with HR.
*      This package is called from Oracle Reports.
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  01-Dec-2008       Ralph Sneep       Created New.
*
******************************************************************************/

-- GLOBAL VARIABLES --

g_pgm_location           VARCHAR2(100) := NULL;

-- Constants --

-- Counts --



-----------------------------------------------------------------------------------
-- P R O C E D U R E
-- Name: Insert_Emp_Chgs_Table
-- Description: Insert a row into the Employee Changes temporary table
-----------------------------------------------------------------------------------
PROCEDURE Insert_Emp_Chgs_Table (p_emp_chgs_tbl_rec IN xxha_hr_emp_changes%ROWTYPE)
IS

BEGIN

g_pgm_location := 'Insert_Emp_Chgs_Table';

INSERT
  INTO xxha_hr_emp_changes
VALUES p_emp_chgs_tbl_rec;


EXCEPTION
   WHEN OTHERS THEN
      RAISE;

END Insert_Emp_Chgs_Table;



--------------------------------------------------------------------------------------
-- P R O C E D U R E
-- Name: Process_Employee_Changes
-- Description: This procedure processes employees that are new hires or have data
--              changes detected.  A change is defined as a difference in the before
--              and after values of a monitored field.  The before and after values are
--              based on points in time as defined by the Date From and Date To input
--              parameters.  Therefore, only changes due to row inserts (i.e. new
--              effective date) are detected.  Changes due to row updates are not
--              detected.
--------------------------------------------------------------------------------------
PROCEDURE Process_Employee_Changes (p_date_from         IN  DATE
                                   ,p_date_to           IN  DATE
                                   ,p_business_group_id IN NUMBER)
IS

l_emp_chgs_tbl_rec   xxha_hr_emp_changes%ROWTYPE;

ln_count_contacts    NUMBER(5);
ln_prev_person_id    NUMBER(15) := -1;

-- Obtain most recent employee data that are new or changed --
CURSOR c_emp_new( p_start_date DATE
                 ,p_end_date DATE
                 ,p_business_group_id NUMBER)
IS
SELECT pbg.name Business_Group
      ,pap.employee_number
      ,pap.national_identifier
      ,pap.full_name
      ,pap.last_name
      ,pap.first_name
      ,pap.middle_names
      ,hr_general.decode_lookup('SEX',pap.sex) Gender
      ,ppos.date_start Latest_Hire_Date
      ,pap.date_of_birth
      ,hr_general.decode_lookup('MAR_STATUS',pap.marital_status) Marital_Status
      ,pap.email_address
      ,pap.previous_last_name
      ,pap.original_date_of_hire
      ,ft.territory_short_name Country_of_Birth
      ,hr_general.decode_lookup('NATIONALITY',pap.nationality) Nationality
      ,pa.address_line1
      ,pa.address_line2
      ,pa.address_line3
      ,pa.town_or_city
      ,pa.region_1
      ,pa.region_2
      ,pa.region_3
      ,pa.postal_code
      ,pa.country
      ,pp1.phone_number Home_Phone
      ,pp2.phone_number Work_Phone
      ,pp3.phone_number Mobile_Phone_Home
      ,pp4.phone_number Mobile_Phone_Work
      ,haou.name Organization_Name
      ,hap.name Position_Name
      ,pg.name Grade_Name
      ,pay.payroll_name
      ,hl.location_code
      ,past.user_status Assignment_Status
      ,hr_general.decode_lookup('EMP_CAT',paa.employment_category) Assignment_Category
      ,pap2.full_name Supervisor
      ,ppp.proposed_salary_n
      ,ppp.attribute1 Hourly_Rate
      ,pet.output_currency_code
      ,hr_general.decode_lookup('PROPOSAL_REASON',ppp.proposal_reason) Proposal_Reason
      ,ppp.approved
      ,ppp.change_date Sal_Change_Date
      ,ppp.date_to Sal_Date_To
      ,pca.effective_start_date Cost_Eff_Dt
      ,pcak.segment1 Cost_Legal_Entity
      ,pcak.segment2 Cost_Product_Line
      ,pcak.segment3 Cost_Business_Unit
      ,pcak.segment4 Cost_Management_Unit
      ,pcak.segment5 Cost_Department
      ,pcak.segment6 Cost_Account
      ,pppm1.priority Priority1
      ,pppm1.amount Amount1
      ,pppm1.percentage Percentage1
      ,popm1.org_payment_method_name Pay_Meth_Name1
      ,ppt1.territory_code Territory_Code1
      ,pea1.segment1 Bank_Acct1_Seg1
      ,pea1.segment2 Bank_Acct1_Seg2
      ,pea1.segment3 Bank_Acct1_Seg3
      ,pea1.segment4 Bank_Acct1_Seg4
      ,pea1.segment5 Bank_Acct1_Seg5
      ,pea1.segment6 Bank_Acct1_Seg6
      ,pea1.segment7 Bank_Acct1_Seg7
      ,pea1.segment8 Bank_Acct1_Seg8
      ,pea1.segment9 Bank_Acct1_Seg9
      ,pea1.segment10 Bank_Acct1_Seg10
      ,pppm2.priority Priority2
      ,pppm2.amount Amount2
      ,pppm2.percentage Percentage2
      ,popm2.org_payment_method_name Pay_Meth_Name2
      ,ppt2.territory_code Territory_Code2
      ,pea2.segment1 Bank_Acct2_Seg1
      ,pea2.segment2 Bank_Acct2_Seg2
      ,pea2.segment3 Bank_Acct2_Seg3
      ,pea2.segment4 Bank_Acct2_Seg4
      ,pea2.segment5 Bank_Acct2_Seg5
      ,pea2.segment6 Bank_Acct2_Seg6
      ,pea2.segment7 Bank_Acct2_Seg7
      ,pea2.segment8 Bank_Acct2_Seg8
      ,pea2.segment9 Bank_Acct2_Seg9
      ,pea2.segment10 Bank_Acct2_Seg10
      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.actual_termination_date,NULL) Actual_Termination_Date
      ,DECODE(past.per_system_status,'TERM_ASSIGN',hr_general.decode_lookup('LEAV_REAS',ppos.leaving_reason),NULL) Term_Reason
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute2,NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',FND_DATE.CANONICAL_TO_DATE(ppos.attribute1),NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute3,NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute4,NULL)
      ,DECODE(pbg.legislation_code,'GB',pap.per_information5,NULL) GB_Work_Permit_Nbr
      ,pap.attribute2 CH_Second_Nationality
      ,pap.attribute9 SE_EMail
      ,DECODE(pbg.legislation_code,'NL',pa.add_information13,NULL) NL_House_Number
      ,DECODE(pbg.legislation_code,'NL',pa.add_information14,NULL) NL_House_Number_Addition
      ,DECODE(pbg.legislation_code,'NL',pa.add_information17,NULL) KR_Address_Line1
      ,pap.effective_start_date Person_Eff_Start_Date
      ,DECODE(pap.effective_end_date,hr_general.end_of_time,NULL,pap.effective_end_date)
      ,paa.effective_start_date Asg_Eff_Start_Date
      ,DECODE(paa.effective_end_date,hr_general.end_of_time,NULL,paa.effective_end_date)
      ,pa.date_from addr_date_from
      ,pp1.date_from phone_home_date_from
      ,pp2.date_from phone_work_date_from
      ,pp3.date_from phone_mobile_home_date_from
      ,pp4.date_from phone_mobile_work_date_from
      ,pppm1.effective_start_date pppm1_eff_dt
      ,pppm1.effective_start_date pppm2_eff_dt
      ,pap.business_group_id
      ,pap.person_id
      ,paa.assignment_id
      ,j.name job
  FROM per_all_people_f pap
      ,per_business_groups pbg
      ,per_periods_of_service ppos
      ,per_addresses pa
      ,per_phones pp1
      ,per_phones pp2
      ,per_phones pp3
      ,per_phones pp4
      ,per_all_assignments_f paa
      ,hr_all_organization_units haou
      ,per_grades pg
      ,hr_all_positions_f hap
      ,pay_all_payrolls_f pay
      ,hr_locations_all hl
      ,pay_input_values_f piv
      ,pay_element_types_f pet
      ,per_pay_bases ppb
      ,per_all_people_f pap2
      ,per_pay_proposals ppp
      ,pay_cost_allocation_keyflex pcak
      ,pay_cost_allocations_f pca
      ,pay_personal_payment_methods_f pppm1
      ,pay_personal_payment_methods_f pppm2
      ,pay_external_accounts pea1
      ,pay_external_accounts pea2
      ,pay_org_payment_methods_f popm1
      ,pay_org_payment_methods_f popm2
      ,pay_payment_types ppt1
      ,pay_payment_types ppt2
      ,per_assignment_status_types past
      ,fnd_territories_vl ft
      ,per_jobs j
 WHERE pbg.business_group_id = pap.business_group_id
   AND pa.person_id(+) = pap.person_id
   AND pp1.parent_id(+) = pap.person_id
   AND pp2.parent_id(+) = pap.person_id
   AND pp3.parent_id(+) = pap.person_id
   AND pp4.parent_id(+) = pap.person_id
   AND ppos.period_of_service_id = paa.period_of_service_id
   AND ppp.assignment_id(+) = paa.assignment_id
   AND past.assignment_status_type_id = paa.assignment_status_type_id
   AND paa.person_id = pap.person_id
   AND haou.organization_id = paa.organization_id
   AND ppp.assignment_id(+) = paa.assignment_id
   AND pg.grade_id(+) = paa.grade_id
   AND hap.position_id(+) = paa.position_id
   AND pay.payroll_id(+) = paa.payroll_id
   AND ppb.pay_basis_id(+) = paa.pay_basis_id
   AND piv.input_value_id(+) = ppb.input_value_id
   AND pet.element_type_id(+) = piv.element_type_id
   AND hl.location_id = paa.location_id
   and j.job_id(+) = paa.job_id
   and j.business_group_id(+) =  paa.business_group_id
   AND pap2.person_id(+) = paa.supervisor_id
   AND ft.territory_code(+) = pap.country_of_birth
   AND pcak.cost_allocation_keyflex_id(+) = pca.cost_allocation_keyflex_id
   AND pca.assignment_id(+) = paa.assignment_id
   AND pppm1.assignment_id(+) = paa.assignment_id
   AND pea1.external_account_id(+) = pppm1.external_account_id
   AND popm1.org_payment_method_id(+) = pppm1.org_payment_method_id
   AND ppt1.payment_type_id(+) = popm1.payment_type_id
   AND pppm2.assignment_id(+) = paa.assignment_id
   AND pea2.external_account_id(+) = pppm2.external_account_id
   AND popm2.org_payment_method_id(+) = pppm2.org_payment_method_id
   AND ppt2.payment_type_id(+) = popm2.payment_type_id
   AND pppm1.percentage(+) = 100
   AND pppm2.percentage(+) <> 100
   AND paa.assignment_type = 'E'
   AND paa.primary_flag = 'Y'
   AND pa.primary_flag(+) = 'Y'
   AND pp1.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp2.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp3.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp4.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp1.phone_type(+) = 'H1'
   AND pp2.phone_type(+) = 'W1'
   AND pp3.phone_type(+) = 'MH'
   AND pp4.phone_type(+) = 'MW'
   AND p_end_date BETWEEN pap.effective_start_date AND pap.effective_end_date
   AND p_end_date BETWEEN paa.effective_start_date AND paa.effective_end_date
   AND p_end_date BETWEEN pa.date_from(+) AND NVL(pa.date_to(+),p_end_date)
   AND p_end_date BETWEEN pp1.date_from(+) AND NVL(pp1.date_to(+),p_end_date)
   AND p_end_date BETWEEN pp2.date_from(+) AND NVL(pp2.date_to(+),p_end_date)
   AND p_end_date BETWEEN pp3.date_from(+) AND NVL(pp3.date_to(+),p_end_date)
   AND p_end_date BETWEEN pp4.date_from(+) AND NVL(pp4.date_to(+),p_end_date)
   AND p_end_date BETWEEN hap.effective_start_date(+) AND hap.effective_end_date(+)
   AND p_end_date BETWEEN piv.effective_start_date(+) AND piv.effective_end_date(+)
   AND p_end_date BETWEEN pet.effective_start_date(+) AND pet.effective_end_date(+)
   AND p_end_date BETWEEN pap2.effective_start_date(+) AND pap2.effective_end_date(+)
   AND p_end_date BETWEEN pay.effective_start_date(+) AND pay.effective_end_date(+)
   AND p_end_date BETWEEN ppp.change_date(+) AND NVL(ppp.date_to(+),p_end_date)
   AND p_end_date BETWEEN pca.effective_start_date(+) AND pca.effective_end_date(+)
   AND p_end_date BETWEEN pppm1.effective_start_date(+) AND pppm1.effective_end_date(+)
   AND p_end_date BETWEEN popm1.effective_start_date(+) AND popm1.effective_end_date(+)
   AND p_end_date BETWEEN pppm2.effective_start_date(+) AND pppm2.effective_end_date(+)
   AND p_end_date BETWEEN popm2.effective_start_date(+) AND popm2.effective_end_date(+)
   AND pap.business_group_id = p_business_group_id
   AND (xxha_hr_util.person_is_emp(pap.person_id,p_end_date) = 'Y' OR xxha_hr_util.person_is_ex_emp(pap.person_id,p_end_date) = 'Y')
MINUS
SELECT pbg.name Business_Group
      ,pap.employee_number
      ,pap.national_identifier
      ,pap.full_name
      ,pap.last_name
      ,pap.first_name
      ,pap.middle_names
      ,hr_general.decode_lookup('SEX',pap.sex) Gender
      ,ppos.date_start Latest_Hire_Date
      ,pap.date_of_birth
      ,hr_general.decode_lookup('MAR_STATUS',pap.marital_status) Marital_Status
      ,pap.email_address
      ,pap.previous_last_name
      ,pap.original_date_of_hire
      ,ft.territory_short_name Country_of_Birth
      ,hr_general.decode_lookup('NATIONALITY',pap.nationality) Nationality
      ,pa.address_line1
      ,pa.address_line2
      ,pa.address_line3
      ,pa.town_or_city
      ,pa.region_1
      ,pa.region_2
      ,pa.region_3
      ,pa.postal_code
      ,pa.country
      ,pp1.phone_number Home_Phone
      ,pp2.phone_number Work_Phone
      ,pp3.phone_number Mobile_Phone_Home
      ,pp4.phone_number Mobile_Phone_Work
      ,haou.name Organization_Name
      ,hap.name Position_Name
      ,pg.name Grade_Name
      ,pay.payroll_name
      ,hl.location_code
      ,past.user_status Assignment_Status
      ,hr_general.decode_lookup('EMP_CAT',paa.employment_category) Assignment_Category
      ,pap2.full_name Supervisor
      ,ppp.proposed_salary_n
      ,ppp.attribute1 Hourly_Rate
      ,pet.output_currency_code
      ,hr_general.decode_lookup('PROPOSAL_REASON',ppp.proposal_reason) Proposal_Reason
      ,ppp.approved
      ,ppp.change_date Sal_Change_Date
      ,ppp.date_to Sal_Date_To
      ,pca.effective_start_date Cost_Eff_Dt
      ,pcak.segment1 Cost_Legal_Entity
      ,pcak.segment2 Cost_Product_Line
      ,pcak.segment3 Cost_Business_Unit
      ,pcak.segment4 Cost_Management_Unit
      ,pcak.segment5 Cost_Department
      ,pcak.segment6 Cost_Account
      ,pppm1.priority Priority1
      ,pppm1.amount Amount1
      ,pppm1.percentage Percentage1
      ,popm1.org_payment_method_name Pay_Meth_Name1
      ,ppt1.territory_code Territory_Code1
      ,pea1.segment1 Bank_Acct1_Seg1
      ,pea1.segment2 Bank_Acct1_Seg2
      ,pea1.segment3 Bank_Acct1_Seg3
      ,pea1.segment4 Bank_Acct1_Seg4
      ,pea1.segment5 Bank_Acct1_Seg5
      ,pea1.segment6 Bank_Acct1_Seg6
      ,pea1.segment7 Bank_Acct1_Seg7
      ,pea1.segment8 Bank_Acct1_Seg8
      ,pea1.segment9 Bank_Acct1_Seg9
      ,pea1.segment10 Bank_Acct1_Seg10
      ,pppm2.priority Priority2
      ,pppm2.amount Amount2
      ,pppm2.percentage Percentage2
      ,popm2.org_payment_method_name Pay_Meth_Name2
      ,ppt2.territory_code Territory_Code2
      ,pea2.segment1 Bank_Acct2_Seg1
      ,pea2.segment2 Bank_Acct2_Seg2
      ,pea2.segment3 Bank_Acct2_Seg3
      ,pea2.segment4 Bank_Acct2_Seg4
      ,pea2.segment5 Bank_Acct2_Seg5
      ,pea2.segment6 Bank_Acct2_Seg6
      ,pea2.segment7 Bank_Acct2_Seg7
      ,pea2.segment8 Bank_Acct2_Seg8
      ,pea2.segment9 Bank_Acct2_Seg9
      ,pea2.segment10 Bank_Acct2_Seg10
      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.actual_termination_date,NULL) Actual_Termination_Date
      ,DECODE(past.per_system_status,'TERM_ASSIGN',hr_general.decode_lookup('LEAV_REAS',ppos.leaving_reason),NULL) Term_Reason
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute2,NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',FND_DATE.CANONICAL_TO_DATE(ppos.attribute1),NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute3,NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute4,NULL)
      ,DECODE(pbg.legislation_code,'GB',pap.per_information5,NULL) GB_Work_Permit_Nbr
      ,pap.attribute2 CH_Second_Nationality
      ,pap.attribute9 SE_EMail
      ,DECODE(pbg.legislation_code,'NL',pa.add_information13,NULL) NL_House_Number
      ,DECODE(pbg.legislation_code,'NL',pa.add_information14,NULL) NL_House_Number_Addition
      ,DECODE(pbg.legislation_code,'NL',pa.add_information17,NULL) KR_Address_Line1
      ,pap.effective_start_date Person_Eff_Start_Date
      ,DECODE(pap.effective_end_date,hr_general.end_of_time,NULL,pap.effective_end_date)
      ,paa.effective_start_date Asg_Eff_Start_Date
      ,DECODE(paa.effective_end_date,hr_general.end_of_time,NULL,paa.effective_end_date)
      ,pa.date_from addr_date_from
      ,pp1.date_from phone_home_date_from
      ,pp2.date_from phone_work_date_from
      ,pp3.date_from phone_mobile_home_date_from
      ,pp4.date_from phone_mobile_work_date_from
      ,pppm1.effective_start_date pppm1_eff_dt
      ,pppm1.effective_start_date pppm2_eff_dt
      ,pap.business_group_id
      ,pap.person_id
      ,paa.assignment_id
      ,j.name job
  FROM per_all_people_f pap
      ,per_business_groups pbg
      ,per_periods_of_service ppos
      ,per_addresses pa
      ,per_phones pp1
      ,per_phones pp2
      ,per_phones pp3
      ,per_phones pp4
      ,per_all_assignments_f paa
      ,hr_all_organization_units haou
      ,per_grades pg
      ,per_jobs j
      ,hr_all_positions_f hap
      ,pay_all_payrolls_f pay
      ,hr_locations_all hl
      ,pay_input_values_f piv
      ,pay_element_types_f pet
      ,per_pay_bases ppb
      ,per_all_people_f pap2
      ,per_pay_proposals ppp
      ,pay_cost_allocation_keyflex pcak
      ,pay_cost_allocations_f pca
      ,pay_personal_payment_methods_f pppm1
      ,pay_personal_payment_methods_f pppm2
      ,pay_external_accounts pea1
      ,pay_external_accounts pea2
      ,pay_org_payment_methods_f popm1
      ,pay_org_payment_methods_f popm2
      ,pay_payment_types ppt1
      ,pay_payment_types ppt2
      ,per_assignment_status_types past
      ,fnd_territories_vl ft
 WHERE pbg.business_group_id = pap.business_group_id
   AND pa.person_id(+) = pap.person_id
   AND pp1.parent_id(+) = pap.person_id
   AND pp2.parent_id(+) = pap.person_id
   AND pp3.parent_id(+) = pap.person_id
   AND pp4.parent_id(+) = pap.person_id
   AND ppos.period_of_service_id = paa.period_of_service_id
   AND ppp.assignment_id(+) = paa.assignment_id
   AND past.assignment_status_type_id = paa.assignment_status_type_id
   AND paa.person_id = pap.person_id
   AND haou.organization_id = paa.organization_id
   AND ppp.assignment_id(+) = paa.assignment_id
   AND pg.grade_id(+) = paa.grade_id
   and j.job_id(+) = paa.job_id
   and j.business_group_id(+) =  paa.business_group_id
   AND hap.position_id(+) = paa.position_id
   AND pay.payroll_id(+) = paa.payroll_id
   AND ppb.pay_basis_id(+) = paa.pay_basis_id
   AND piv.input_value_id(+) = ppb.input_value_id
   AND pet.element_type_id(+) = piv.element_type_id
   AND hl.location_id = paa.location_id
   AND pap2.person_id(+) = paa.supervisor_id
   AND ft.territory_code(+) = pap.country_of_birth
   AND pcak.cost_allocation_keyflex_id(+) = pca.cost_allocation_keyflex_id
   AND pca.assignment_id(+) = paa.assignment_id
   AND pppm1.assignment_id(+) = paa.assignment_id
   AND pea1.external_account_id(+) = pppm1.external_account_id
   AND popm1.org_payment_method_id(+) = pppm1.org_payment_method_id
   AND ppt1.payment_type_id(+) = popm1.payment_type_id
   AND pppm2.assignment_id(+) = paa.assignment_id
   AND pea2.external_account_id(+) = pppm2.external_account_id
   AND popm2.org_payment_method_id(+) = pppm2.org_payment_method_id
   AND ppt2.payment_type_id(+) = popm2.payment_type_id
   AND pppm1.percentage(+) = 100
   AND pppm2.percentage(+) <> 100
   AND paa.assignment_type = 'E'
   AND paa.primary_flag = 'Y'
   AND pa.primary_flag(+) = 'Y'
   AND pp1.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp2.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp3.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp4.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp1.phone_type(+) = 'H1'
   AND pp2.phone_type(+) = 'W1'
   AND pp3.phone_type(+) = 'MH'
   AND pp4.phone_type(+) = 'MW'
   AND p_start_date BETWEEN pap.effective_start_date AND pap.effective_end_date
   AND p_start_date BETWEEN paa.effective_start_date AND paa.effective_end_date
   AND p_start_date BETWEEN pa.date_from(+) AND NVL(pa.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp1.date_from(+) AND NVL(pp1.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp2.date_from(+) AND NVL(pp2.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp3.date_from(+) AND NVL(pp3.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp4.date_from(+) AND NVL(pp4.date_to(+),p_start_date)
   AND p_start_date BETWEEN hap.effective_start_date(+) AND hap.effective_end_date(+)
   AND p_start_date BETWEEN piv.effective_start_date(+) AND piv.effective_end_date(+)
   AND p_start_date BETWEEN pet.effective_start_date(+) AND pet.effective_end_date(+)
   AND p_start_date BETWEEN pap2.effective_start_date(+) AND pap2.effective_end_date(+)
   AND p_start_date BETWEEN pay.effective_start_date(+) AND pay.effective_end_date(+)
   AND p_start_date BETWEEN ppp.change_date(+) AND NVL(ppp.date_to(+),p_start_date)
   AND p_start_date BETWEEN pca.effective_start_date(+) AND pca.effective_end_date(+)
   AND p_start_date BETWEEN pppm1.effective_start_date(+) AND pppm1.effective_end_date(+)
   AND p_start_date BETWEEN popm1.effective_start_date(+) AND popm1.effective_end_date(+)
   AND p_start_date BETWEEN pppm2.effective_start_date(+) AND pppm2.effective_end_date(+)
   AND p_start_date BETWEEN popm2.effective_start_date(+) AND popm2.effective_end_date(+)
   AND pap.business_group_id = p_business_group_id
   AND (xxha_hr_util.person_is_emp(pap.person_id,p_start_date) = 'Y' OR xxha_hr_util.person_is_ex_emp(pap.person_id,p_start_date) = 'Y');



-- Obtain the before employee data --
CURSOR c_emp_old( p_start_date DATE
                 ,p_person_id NUMBER)
IS
SELECT pbg.name Business_Group
      ,pap.employee_number
      ,pap.national_identifier
      ,pap.full_name
      ,pap.last_name
      ,pap.first_name
      ,pap.middle_names
      ,hr_general.decode_lookup('SEX',pap.sex) Gender
      ,ppos.date_start Latest_Hire_Date
      ,pap.date_of_birth
      ,hr_general.decode_lookup('MAR_STATUS',pap.marital_status) Marital_Status
      ,pap.email_address
      ,pap.previous_last_name
      ,pap.original_date_of_hire
      ,ft.territory_short_name Country_of_Birth
      ,hr_general.decode_lookup('NATIONALITY',pap.nationality) Nationality
      ,pa.address_line1
      ,pa.address_line2
      ,pa.address_line3
      ,pa.town_or_city
      ,pa.region_1
      ,pa.region_2
      ,pa.region_3
      ,pa.postal_code
      ,pa.country
      ,pp1.phone_number Home_Phone
      ,pp2.phone_number Work_Phone
      ,pp3.phone_number Mobile_Phone_Home
      ,pp4.phone_number Mobile_Phone_Work
      ,haou.name Organization_Name
      ,hap.name Position_Name
      ,pg.name Grade_Name
      ,pay.payroll_name
      ,hl.location_code
      ,past.user_status Assignment_Status
      ,hr_general.decode_lookup('EMP_CAT',paa.employment_category) Assignment_Category
      ,pap2.full_name Supervisor
      ,ppp.proposed_salary_n
      ,ppp.attribute1 Hourly_Rate
      ,DECODE(ppp.change_date,NULL,NULL,pet.output_currency_code) Output_Currency_Code
      ,hr_general.decode_lookup('PROPOSAL_REASON',ppp.proposal_reason) Proposal_Reason
      ,ppp.approved
      ,ppp.change_date Sal_Change_Date
      ,ppp.date_to Sal_Date_To
      ,pca.effective_start_date Cost_Eff_Dt
      ,pcak.segment1 Cost_Legal_Entity
      ,pcak.segment2 Cost_Product_Line
      ,pcak.segment3 Cost_Business_Unit
      ,pcak.segment4 Cost_Management_Unit
      ,pcak.segment5 Cost_Department
      ,pcak.segment6 Cost_Account
      ,pppm1.priority Priority1
      ,pppm1.amount Amount1
      ,pppm1.percentage Percentage1
      ,popm1.org_payment_method_name Pay_Meth_Name1
      ,ppt1.territory_code Territory_Code1
      ,pea1.segment1 Bank_Acct1_Seg1
      ,pea1.segment2 Bank_Acct1_Seg2
      ,pea1.segment3 Bank_Acct1_Seg3
      ,pea1.segment4 Bank_Acct1_Seg4
      ,pea1.segment5 Bank_Acct1_Seg5
      ,pea1.segment6 Bank_Acct1_Seg6
      ,pea1.segment7 Bank_Acct1_Seg7
      ,pea1.segment8 Bank_Acct1_Seg8
      ,pea1.segment9 Bank_Acct1_Seg9
      ,pea1.segment10 Bank_Acct1_Seg10
      ,pppm2.priority Priority2
      ,pppm2.amount Amount2
      ,pppm2.percentage Percentage2
      ,popm2.org_payment_method_name Pay_Meth_Name2
      ,ppt2.territory_code Territory_Code2
      ,pea2.segment1 Bank_Acct2_Seg1
      ,pea2.segment2 Bank_Acct2_Seg2
      ,pea2.segment3 Bank_Acct2_Seg3
      ,pea2.segment4 Bank_Acct2_Seg4
      ,pea2.segment5 Bank_Acct2_Seg5
      ,pea2.segment6 Bank_Acct2_Seg6
      ,pea2.segment7 Bank_Acct2_Seg7
      ,pea2.segment8 Bank_Acct2_Seg8
      ,pea2.segment9 Bank_Acct2_Seg9
      ,pea2.segment10 Bank_Acct2_Seg10
      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.actual_termination_date,NULL) Actual_Termination_Date
      ,DECODE(past.per_system_status,'TERM_ASSIGN',hr_general.decode_lookup('LEAV_REAS',ppos.leaving_reason),NULL) Term_Reason
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute2,NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',FND_DATE.CANONICAL_TO_DATE(ppos.attribute1),NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute3,NULL)
--      ,DECODE(past.per_system_status,'TERM_ASSIGN',ppos.attribute4,NULL)
      ,DECODE(pbg.legislation_code,'GB',pap.per_information5,NULL) GB_Work_Permit_Nbr
      ,pap.attribute2 CH_Second_Nationality
      ,pap.attribute9 SE_EMail
      ,DECODE(pbg.legislation_code,'NL',pa.add_information13,NULL) NL_House_Number
      ,DECODE(pbg.legislation_code,'NL',pa.add_information14,NULL) NL_House_Number_Addition
      ,DECODE(pbg.legislation_code,'NL',pa.add_information17,NULL) KR_Address_Line1
      ,pap.effective_start_date Person_Eff_Start_Date
      ,DECODE(pap.effective_end_date,hr_general.end_of_time,NULL,pap.effective_end_date)
      ,paa.effective_start_date Asg_Eff_Start_Date
      ,DECODE(paa.effective_end_date,hr_general.end_of_time,NULL,paa.effective_end_date)
      ,pa.date_from addr_date_from
      ,pp1.date_from phone_home_date_from
      ,pp2.date_from phone_work_date_from
      ,pp3.date_from phone_mobile_home_date_from
      ,pp4.date_from phone_mobile_work_date_from
      ,pppm1.effective_start_date pppm1_eff_dt
      ,pppm1.effective_start_date pppm2_eff_dt
      ,pap.business_group_id
      ,pap.person_id
      ,paa.assignment_id
      ,j.name job
  FROM per_all_people_f pap
      ,per_business_groups pbg
      ,per_periods_of_service ppos
      ,per_addresses pa
      ,per_phones pp1
      ,per_phones pp2
      ,per_phones pp3
      ,per_phones pp4
      ,per_all_assignments_f paa
      ,hr_all_organization_units haou
      ,per_grades pg
      ,per_jobs j
      ,hr_all_positions_f hap
      ,pay_all_payrolls_f pay
      ,hr_locations_all hl
      ,pay_input_values_f piv
      ,pay_element_types_f pet
      ,per_pay_bases ppb
      ,per_all_people_f pap2
      ,per_pay_proposals ppp
      ,pay_cost_allocation_keyflex pcak
      ,pay_cost_allocations_f pca
      ,pay_personal_payment_methods_f pppm1
      ,pay_personal_payment_methods_f pppm2
      ,pay_external_accounts pea1
      ,pay_external_accounts pea2
      ,pay_org_payment_methods_f popm1
      ,pay_org_payment_methods_f popm2
      ,pay_payment_types ppt1
      ,pay_payment_types ppt2
      ,per_assignment_status_types past
      ,fnd_territories_vl ft
 WHERE pbg.business_group_id = pap.business_group_id
   AND pa.person_id(+) = pap.person_id
   AND pp1.parent_id(+) = pap.person_id
   AND pp2.parent_id(+) = pap.person_id
   AND pp3.parent_id(+) = pap.person_id
   AND pp4.parent_id(+) = pap.person_id
   AND ppos.period_of_service_id = paa.period_of_service_id
   AND ppp.assignment_id(+) = paa.assignment_id
   AND past.assignment_status_type_id = paa.assignment_status_type_id
   AND paa.person_id = pap.person_id
   AND haou.organization_id = paa.organization_id
   AND ppp.assignment_id(+) = paa.assignment_id
   AND pg.grade_id(+) = paa.grade_id
   and j.job_id(+) = paa.job_id
   and j.business_group_id(+) =  paa.business_group_id
   AND hap.position_id(+) = paa.position_id
   AND pay.payroll_id(+) = paa.payroll_id
   AND ppb.pay_basis_id(+) = paa.pay_basis_id
   AND piv.input_value_id(+) = ppb.input_value_id
   AND pet.element_type_id(+) = piv.element_type_id
   AND hl.location_id = paa.location_id
   AND pap2.person_id(+) = paa.supervisor_id
   AND ft.territory_code(+) = pap.country_of_birth
   AND pcak.cost_allocation_keyflex_id(+) = pca.cost_allocation_keyflex_id
   AND pca.assignment_id(+) = paa.assignment_id
   AND pppm1.assignment_id(+) = paa.assignment_id
   AND pea1.external_account_id(+) = pppm1.external_account_id
   AND popm1.org_payment_method_id(+) = pppm1.org_payment_method_id
   AND ppt1.payment_type_id(+) = popm1.payment_type_id
   AND pppm2.assignment_id(+) = paa.assignment_id
   AND pea2.external_account_id(+) = pppm2.external_account_id
   AND popm2.org_payment_method_id(+) = pppm2.org_payment_method_id
   AND ppt2.payment_type_id(+) = popm2.payment_type_id
   AND pppm1.percentage(+) = 100
   AND pppm2.percentage(+) <> 100
   AND paa.assignment_type = 'E'
   AND paa.primary_flag = 'Y'
   AND pa.primary_flag(+) = 'Y'
   AND pp1.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp2.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp3.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp4.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp1.phone_type(+) = 'H1'
   AND pp2.phone_type(+) = 'W1'
   AND pp3.phone_type(+) = 'MH'
   AND pp4.phone_type(+) = 'MW'
   AND p_start_date BETWEEN pap.effective_start_date AND pap.effective_end_date
   AND p_start_date BETWEEN paa.effective_start_date AND paa.effective_end_date
   AND p_start_date BETWEEN pa.date_from(+) AND NVL(pa.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp1.date_from(+) AND NVL(pp1.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp2.date_from(+) AND NVL(pp2.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp3.date_from(+) AND NVL(pp3.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp4.date_from(+) AND NVL(pp4.date_to(+),p_start_date)
   AND p_start_date BETWEEN hap.effective_start_date(+) AND hap.effective_end_date(+)
   AND p_start_date BETWEEN piv.effective_start_date(+) AND piv.effective_end_date(+)
   AND p_start_date BETWEEN pet.effective_start_date(+) AND pet.effective_end_date(+)
   AND p_start_date BETWEEN pap2.effective_start_date(+) AND pap2.effective_end_date(+)
   AND p_start_date BETWEEN pay.effective_start_date(+) AND pay.effective_end_date(+)
   AND p_start_date BETWEEN ppp.change_date(+) AND NVL(ppp.date_to(+),p_start_date)
   AND p_start_date BETWEEN pca.effective_start_date(+) AND pca.effective_end_date(+)
   AND p_start_date BETWEEN pppm1.effective_start_date(+) AND pppm1.effective_end_date(+)
   AND p_start_date BETWEEN popm1.effective_start_date(+) AND popm1.effective_end_date(+)
   AND p_start_date BETWEEN pppm2.effective_start_date(+) AND pppm2.effective_end_date(+)
   AND p_start_date BETWEEN popm2.effective_start_date(+) AND popm2.effective_end_date(+)
   AND pap.person_id = p_person_id;

c_emp_rec_old  c_emp_old%ROWTYPE;


-- Obtain most recent Contact data for the employee that are new or changed --
CURSOR c_con_new( p_start_date DATE
                 ,p_end_date DATE
                 ,p_business_group_id NUMBER)
IS
SELECT pbg.name Business_Group
      ,pap.employee_number
      ,pap.national_identifier
      ,pap.full_name
      ,con.last_name
      ,con.first_name
      ,con.middle_names
      ,hr_general.decode_lookup('SEX',con.sex) Gender
      ,hr_general.decode_lookup('CONTACT',pcr.contact_type) Relationship
      ,con.date_of_birth
      ,pcr.primary_contact_flag
      ,pcr.beneficiary_flag
      ,pcr.dependent_flag
      ,pp1.phone_number Home_Phone
      ,pp2.phone_number Work_Phone
      ,pp3.phone_number Mobile_Phone_Home
      ,pp4.phone_number Mobile_Phone_Work
      ,pap.per_information19 JP_Last_Name_Kanji
      ,pap.per_information18 JP_First_Name_Kanji
      ,con.attribute7 TW_Chinese_Name
      ,pcr.date_start
      ,pcr.date_end
      ,con.effective_start_date con_eff_start_dt
--      ,con.effective_end_date con_eff_end
      ,DECODE(con.effective_end_date,hr_general.end_of_time,NULL,con.effective_end_date) con_eff_end_dt
      ,pap.effective_start_date
--      ,pap.effective_end_date
      ,DECODE(pap.effective_end_date,hr_general.end_of_time,NULL,pap.effective_end_date) effective_end_date
      ,pp1.date_from phone_home_date_from
      ,pp2.date_from phone_work_date_from
      ,pp3.date_from phone_mobile_home_date_from
      ,pp4.date_from phone_mobile_work_date_from
      ,pap.business_group_id
      ,pap.person_id per_person_id
      ,con.person_id con_person_id
  FROM per_all_people_f pap
      ,per_all_people_f con
      ,per_contact_relationships pcr
      ,per_phones pp1
      ,per_phones pp2
      ,per_phones pp3
      ,per_phones pp4
      ,per_business_groups pbg
 WHERE pcr.person_id = pap.person_id
   AND pcr.contact_person_id = con.person_id
   AND pp1.parent_id(+) = con.person_id
   AND pp2.parent_id(+) = con.person_id
   AND pp3.parent_id(+) = con.person_id
   AND pp4.parent_id(+) = con.person_id
   AND pbg.business_group_id = pap.business_group_id
   AND pap.employee_number IS NOT NULL
   AND pp1.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp2.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp3.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp4.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp1.phone_type(+) = 'H1'
   AND pp2.phone_type(+) = 'W1'
   AND pp3.phone_type(+) = 'MH'
   AND pp4.phone_type(+) = 'MW'
   AND p_end_date BETWEEN pap.effective_start_date AND pap.effective_end_date
   AND p_end_date BETWEEN con.effective_start_date AND con.effective_end_date
   AND p_end_date BETWEEN pcr.date_start AND NVL(pcr.date_end,p_end_date)
   AND p_end_date BETWEEN pp1.date_from(+) AND NVL(pp1.date_to(+),p_end_date)
   AND p_end_date BETWEEN pp2.date_from(+) AND NVL(pp2.date_to(+),p_end_date)
   AND p_end_date BETWEEN pp3.date_from(+) AND NVL(pp3.date_to(+),p_end_date)
   AND p_end_date BETWEEN pp4.date_from(+) AND NVL(pp4.date_to(+),p_end_date)
   AND pap.business_group_id = p_business_group_id
   AND (xxha_hr_util.person_is_emp(pap.person_id,p_end_date) = 'Y' OR xxha_hr_util.person_is_ex_emp(pap.person_id,p_end_date) = 'Y')
MINUS
SELECT pbg.name Business_Group
      ,pap.employee_number
      ,pap.national_identifier
      ,pap.full_name
      ,con.last_name
      ,con.first_name
      ,con.middle_names
      ,hr_general.decode_lookup('SEX',con.sex) Gender
      ,hr_general.decode_lookup('CONTACT',pcr.contact_type) Relationship
      ,con.date_of_birth
      ,pcr.primary_contact_flag
      ,pcr.beneficiary_flag
      ,pcr.dependent_flag
      ,pp1.phone_number Home_Phone
      ,pp2.phone_number Work_Phone
      ,pp3.phone_number Mobile_Phone_Home
      ,pp4.phone_number Mobile_Phone_Work
      ,pap.per_information19 JP_Last_Name_Kanji
      ,pap.per_information18 JP_First_Name_Kanji
      ,con.attribute7 TW_Chinese_Name
      ,pcr.date_start
      ,pcr.date_end
      ,con.effective_start_date con_eff_start_dt
      ,DECODE(con.effective_end_date,hr_general.end_of_time,NULL,con.effective_end_date) con_eff_end_dt
      ,pap.effective_start_date
      ,DECODE(pap.effective_end_date,hr_general.end_of_time,NULL,pap.effective_end_date) effective_end_date
      ,pp1.date_from phone_home_date_from
      ,pp2.date_from phone_work_date_from
      ,pp3.date_from phone_mobile_home_date_from
      ,pp4.date_from phone_mobile_work_date_from
      ,pap.business_group_id
      ,pap.person_id per_person_id
      ,con.person_id con_person_id
  FROM per_all_people_f pap
      ,per_all_people_f con
      ,per_contact_relationships pcr
      ,per_phones pp1
      ,per_phones pp2
      ,per_phones pp3
      ,per_phones pp4
      ,per_business_groups pbg
 WHERE pcr.person_id = pap.person_id
   AND pcr.contact_person_id = con.person_id
   AND pp1.parent_id(+) = con.person_id
   AND pp2.parent_id(+) = con.person_id
   AND pp3.parent_id(+) = con.person_id
   AND pp4.parent_id(+) = con.person_id
   AND pbg.business_group_id = pap.business_group_id
   AND pap.employee_number IS NOT NULL
   AND pp1.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp2.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp3.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp4.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp1.phone_type(+) = 'H1'
   AND pp2.phone_type(+) = 'W1'
   AND pp3.phone_type(+) = 'MH'
   AND pp4.phone_type(+) = 'MW'
   AND p_start_date BETWEEN pap.effective_start_date AND pap.effective_end_date
   AND p_start_date BETWEEN con.effective_start_date AND con.effective_end_date
   AND p_start_date BETWEEN pcr.date_start AND NVL(pcr.date_end,p_start_date)
   AND p_start_date BETWEEN pp1.date_from(+) AND NVL(pp1.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp2.date_from(+) AND NVL(pp2.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp3.date_from(+) AND NVL(pp3.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp4.date_from(+) AND NVL(pp4.date_to(+),p_start_date)
   AND pap.business_group_id = p_business_group_id
   AND (xxha_hr_util.person_is_emp(pap.person_id,p_start_date) = 'Y' OR xxha_hr_util.person_is_ex_emp(pap.person_id,p_start_date) = 'Y')
ORDER BY 31,32;

-- Obtain before Contact data for the contact that are new or changed --
CURSOR c_con_old( p_start_date DATE
                 ,p_person_id NUMBER
                 ,p_con_person_id NUMBER)
IS
SELECT pbg.name Business_Group
      ,pap.employee_number
      ,pap.national_identifier
      ,pap.full_name
      ,con.last_name
      ,con.first_name
      ,con.middle_names
      ,hr_general.decode_lookup('SEX',con.sex) Gender
      ,hr_general.decode_lookup('CONTACT',pcr.contact_type) Relationship
      ,con.date_of_birth
      ,pcr.primary_contact_flag
      ,pcr.beneficiary_flag
      ,pcr.dependent_flag
      ,pp1.phone_number Home_Phone
      ,pp2.phone_number Work_Phone
      ,pp3.phone_number Mobile_Phone_Home
      ,pp4.phone_number Mobile_Phone_Work
      ,pap.per_information19 JP_Last_Name_Kanji
      ,pap.per_information18 JP_First_Name_Kanji
      ,con.attribute7 TW_Chinese_Name
      ,pcr.date_start
      ,pcr.date_end
      ,con.effective_start_date con_eff_start_dt
--      ,con.effective_end_date con_eff_end
      ,DECODE(con.effective_end_date,hr_general.end_of_time,NULL,con.effective_end_date) con_eff_end_dt
      ,pap.effective_start_date
--      ,pap.effective_end_date
      ,DECODE(pap.effective_end_date,hr_general.end_of_time,NULL,pap.effective_end_date) effective_end_date
      ,pp1.date_from phone_home_date_from
      ,pp2.date_from phone_work_date_from
      ,pp3.date_from phone_mobile_home_date_from
      ,pp4.date_from phone_mobile_work_date_from
      ,pap.business_group_id
      ,pap.person_id per_person_id
      ,con.person_id con_person_id
  FROM per_all_people_f pap
      ,per_all_people_f con
      ,per_contact_relationships pcr
      ,per_phones pp1
      ,per_phones pp2
      ,per_phones pp3
      ,per_phones pp4
      ,per_business_groups pbg
 WHERE pcr.person_id = pap.person_id
   AND pcr.contact_person_id = con.person_id
   AND pp1.parent_id(+) = con.person_id
   AND pp2.parent_id(+) = con.person_id
   AND pp3.parent_id(+) = con.person_id
   AND pp4.parent_id(+) = con.person_id
   AND pbg.business_group_id = pap.business_group_id
   AND pap.employee_number IS NOT NULL
   AND pp1.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp2.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp3.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp4.parent_table(+) = 'PER_ALL_PEOPLE_F'
   AND pp1.phone_type(+) = 'H1'
   AND pp2.phone_type(+) = 'W1'
   AND pp3.phone_type(+) = 'MH'
   AND pp4.phone_type(+) = 'MW'
   AND p_start_date BETWEEN pap.effective_start_date AND pap.effective_end_date
   AND p_start_date BETWEEN con.effective_start_date AND con.effective_end_date
   AND p_start_date BETWEEN pcr.date_start AND NVL(pcr.date_end,p_start_date)
   AND p_start_date BETWEEN pp1.date_from(+) AND NVL(pp1.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp2.date_from(+) AND NVL(pp2.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp3.date_from(+) AND NVL(pp3.date_to(+),p_start_date)
   AND p_start_date BETWEEN pp4.date_from(+) AND NVL(pp4.date_to(+),p_start_date)
   AND pap.person_id = p_person_id
   AND con.person_id = p_con_person_id;

c_con_rec_old  c_con_old%ROWTYPE;


-------------------------------------------------------
-- B E G I N
-------------------------------------------------------
BEGIN

g_pgm_location := 'Process_Employee_Changes';

-- Process Changes --
FOR c_emp_rec_new IN c_emp_new(p_date_from, p_date_to,p_business_group_id)
LOOP
   -- Get old data for the employee if exists --
   OPEN c_emp_old(p_date_from,c_emp_rec_new.person_id);
   FETCH c_emp_old INTO c_emp_rec_old;
   IF c_emp_old%NOTFOUND
   THEN  -- N e w   H i r e --
      l_emp_chgs_tbl_rec.business_group_id := c_emp_rec_new.business_group_id;
      l_emp_chgs_tbl_rec.person_id := c_emp_rec_new.person_id;
      l_emp_chgs_tbl_rec.employee_number := c_emp_rec_new.employee_number;
      l_emp_chgs_tbl_rec.full_name := c_emp_rec_new.full_name;
   --------------
   -- Employee --
   --------------
      l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.person_eff_start_date;
      l_emp_chgs_tbl_rec.old_value := NULL;
      l_emp_chgs_tbl_rec.sort_seq1 := '005';
      -- Lastest Start Date --
      l_emp_chgs_tbl_rec.field_name := 'Empl Latest Start Date';
      l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.latest_hire_date;
      l_emp_chgs_tbl_rec.sort_seq2 := '000';
      insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      -- Last Name --
      l_emp_chgs_tbl_rec.field_name := 'Empl Last Name';
      l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.last_name;
      l_emp_chgs_tbl_rec.sort_seq2 := '005';
      insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      -- First Name --
      IF c_emp_rec_new.first_name IS NOT NULL THEN
          l_emp_chgs_tbl_rec.field_name := 'Empl First Name';
          l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.first_name;
          l_emp_chgs_tbl_rec.sort_seq2 := '010';
          insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Middle Names --
      IF c_emp_rec_new.middle_names IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Middle Names';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.middle_names;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Gender --
      IF c_emp_rec_new.gender IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Gender';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.gender;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- National ID --
      IF c_emp_rec_new.national_identifier IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl National ID';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.national_identifier;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Birth Date --
      IF c_emp_rec_new.date_of_birth IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Birth Date';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.date_of_birth;
         l_emp_chgs_tbl_rec.sort_seq2 := '030';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Marital Status --
      IF c_emp_rec_new.marital_status IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Marital Status';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.marital_status;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Nationality --
      IF c_emp_rec_new.nationality IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Nationality';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.nationality;
         l_emp_chgs_tbl_rec.sort_seq2 := '040';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Work Permit Number --
      IF c_emp_rec_new.gb_work_permit_nbr IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Work Permit';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.gb_work_permit_nbr;
         l_emp_chgs_tbl_rec.sort_seq2 := '045';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Country of Birth --
      IF c_emp_rec_new.country_of_birth IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Country of Birth';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.country_of_birth;
         l_emp_chgs_tbl_rec.sort_seq2 := '050';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Email --
      IF c_emp_rec_new.email_address IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Email';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.email_address;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Sweden Email --
      IF c_emp_rec_new.se_email IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Email';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.se_email;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Previous Last Name --
      IF c_emp_rec_new.previous_last_name IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Prev Last Name';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.previous_last_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '060';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Date First Hired --
      IF c_emp_rec_new.original_date_of_hire IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Date First Hired';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.original_date_of_hire;
         l_emp_chgs_tbl_rec.sort_seq2 := '065';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Second Nationality --
      IF c_emp_rec_new.ch_second_nationality IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl 2nd Nationality';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.ch_second_nationality;
         l_emp_chgs_tbl_rec.sort_seq2 := '065';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   -------------
   -- Address --
   -------------
      l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.addr_date_from;
      l_emp_chgs_tbl_rec.sort_seq1 := '010';
      -- Line 1 --
      IF c_emp_rec_new.address_line1 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Line 1';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.address_line1;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Line 2 --
      IF c_emp_rec_new.address_line2 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Line 2';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.address_line2;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Line 3 --
      IF c_emp_rec_new.address_line3 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Line 3';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.address_line3;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Town or City --
      IF c_emp_rec_new.town_or_city IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Town or City';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.town_or_city;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Region 1 --
      IF c_emp_rec_new.region_1 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Region 1';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.region_1;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Region 2 --
      IF c_emp_rec_new.region_2 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Region 2';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.region_2;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Region 3 --
      IF c_emp_rec_new.region_3 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Region 3';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.region_3;
         l_emp_chgs_tbl_rec.sort_seq2 := '030';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Postal Code --
      IF c_emp_rec_new.postal_code IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Postal Code';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.postal_code;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Country --
      IF c_emp_rec_new.country IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Country';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.country;
         l_emp_chgs_tbl_rec.sort_seq2 := '040';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- NL House Number --
      IF c_emp_rec_new.nl_house_number IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr NL House Number';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.nl_house_number;
         l_emp_chgs_tbl_rec.sort_seq2 := '045';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- NL House Number Addition --
      IF c_emp_rec_new.nl_house_number_addition IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr NL House Number Add';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.nl_house_number_addition;
         l_emp_chgs_tbl_rec.sort_seq2 := '050';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- KR Address Line1 --
      IF c_emp_rec_new.kr_address_line1 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr KR Line1';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.kr_address_line1;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   ------------
   -- Phones --
   ------------
      l_emp_chgs_tbl_rec.sort_seq1 := '015';
      -- Phone - Home --
      IF c_emp_rec_new.home_phone IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Home';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.home_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Work --
      IF c_emp_rec_new.work_phone IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Work';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.work_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Home) --
      IF c_emp_rec_new.mobile_phone_home IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Mobile (Home)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_mobile_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.mobile_phone_home;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Work) --
      IF c_emp_rec_new.mobile_phone_work IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Mobile (Work)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_mobile_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.mobile_phone_work;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   ----------------
   -- Assignment --
   ----------------
      l_emp_chgs_tbl_rec.sort_seq1 := '020';
      -- Organization --
      IF c_emp_rec_new.organization_name IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Organization';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.organization_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Position --
      IF c_emp_rec_new.position_name IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Position';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.position_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Job --
      IF c_emp_rec_new.job IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Job';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.job;
         l_emp_chgs_tbl_rec.sort_seq2 := '006';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Grade --
      IF c_emp_rec_new.grade_name IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Grade';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.grade_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Payroll --
      IF c_emp_rec_new.payroll_name IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Payroll';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.payroll_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Location --
      IF c_emp_rec_new.location_code IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Location';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.location_code;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Status --
      IF c_emp_rec_new.assignment_status IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Assignment Status';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.assignment_status;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Category --
      IF c_emp_rec_new.assignment_category IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Assignment Category';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.assignment_category;
         l_emp_chgs_tbl_rec.sort_seq2 := '030';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Supervisor --
      IF c_emp_rec_new.supervisor IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Supervisor';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.supervisor;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   -------------
   -- Salary --
   -------------
      IF c_emp_rec_new.sal_change_date IS NOT NULL THEN
         l_emp_chgs_tbl_rec.sort_seq1 := '040';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.sal_change_date;
         -- Change Date --
         l_emp_chgs_tbl_rec.field_name := 'Salary Change Date';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.sal_change_date;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Salary --
         l_emp_chgs_tbl_rec.field_name := 'Salary Annual Salary';
         l_emp_chgs_tbl_rec.new_value := TRIM(TO_CHAR(c_emp_rec_new.proposed_salary_n,'999,999,999.00'));
         l_emp_chgs_tbl_rec.sort_seq2 := '002';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Hourly Rate --
         l_emp_chgs_tbl_rec.field_name := 'Salary Hourly Rate';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.hourly_rate;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Currency --
         l_emp_chgs_tbl_rec.field_name := 'Salary Currency';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.output_currency_code;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Change Reason --
         l_emp_chgs_tbl_rec.field_name := 'Salary Change Reason';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.proposal_reason;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Approved --
         l_emp_chgs_tbl_rec.field_name := 'Salary Approved';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.approved;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   -------------
   -- Costing --
   -------------
      l_emp_chgs_tbl_rec.sort_seq1 := '045';
      -- Legal Entity (Segment1) --
      IF c_emp_rec_new.cost_legal_entity IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Legal Entity';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_legal_entity;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Product Line (Segment2) --
      IF c_emp_rec_new.cost_product_line IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Product Line';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_product_line;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Business Unit (Segment3) --
      IF c_emp_rec_new.cost_business_unit IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Business Unit';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_business_unit;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Management Unit (Segment4) --
      IF c_emp_rec_new.cost_management_unit IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Management Unit';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_management_unit;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Department (Segment5) --
      IF c_emp_rec_new.cost_department IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Department';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_department;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Account (Segment6) --
      IF c_emp_rec_new.cost_account IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Account';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_account;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   ------------------
   -- Pay Method 1 --
   ------------------
      IF c_emp_rec_new.pay_meth_name1 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.sort_seq1 := '050';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.pppm1_eff_dt;
         -- Payment Method Name --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Name';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.pay_meth_name1;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Priority --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Priority';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.priority1;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Amount --
         IF c_emp_rec_new.amount1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Amount';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.amount1;
            l_emp_chgs_tbl_rec.sort_seq2 := '010';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Percentage --
         IF c_emp_rec_new.percentage1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Percentage';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.percentage1;
            l_emp_chgs_tbl_rec.sort_seq2 := '015';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 1 --
         IF c_emp_rec_new.bank_acct1_seg1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg1';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg1;
            l_emp_chgs_tbl_rec.sort_seq2 := '020';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 2 --
         IF c_emp_rec_new.bank_acct1_seg2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg2';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg2;
            l_emp_chgs_tbl_rec.sort_seq2 := '025';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 3 --
         IF c_emp_rec_new.bank_acct1_seg3 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg3';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg3;
            l_emp_chgs_tbl_rec.sort_seq2 := '030';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 4 --
         IF c_emp_rec_new.bank_acct1_seg4 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg4';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg4;
            l_emp_chgs_tbl_rec.sort_seq2 := '035';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 5 --
         IF c_emp_rec_new.bank_acct1_seg5 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg5';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg5;
            l_emp_chgs_tbl_rec.sort_seq2 := '040';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 6 --
         IF c_emp_rec_new.bank_acct1_seg6 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg6';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg6;
            l_emp_chgs_tbl_rec.sort_seq2 := '045';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 7 --
         IF c_emp_rec_new.bank_acct1_seg7 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg7';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg7;
            l_emp_chgs_tbl_rec.sort_seq2 := '050';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 8 --
         IF c_emp_rec_new.bank_acct1_seg8 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg8';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg8;
            l_emp_chgs_tbl_rec.sort_seq2 := '055';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 9 --
         IF c_emp_rec_new.bank_acct1_seg9 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg9';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg9;
            l_emp_chgs_tbl_rec.sort_seq2 := '060';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 10 --
         IF c_emp_rec_new.bank_acct1_seg10 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg10';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg10;
            l_emp_chgs_tbl_rec.sort_seq2 := '065';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
      END IF;
   ------------------
   -- Pay Method 2 --
   ------------------
      IF c_emp_rec_new.pay_meth_name2 IS NOT NULL THEN
         l_emp_chgs_tbl_rec.sort_seq1 := '055';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.pppm2_eff_dt;
         -- Payment Method Name --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Name';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.pay_meth_name2;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Priority --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Priority';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.priority2;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Amount --
         IF c_emp_rec_new.amount2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Amount';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.amount2;
            l_emp_chgs_tbl_rec.sort_seq2 := '010';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Percentage --
         IF c_emp_rec_new.percentage2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Percentage';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.percentage2;
            l_emp_chgs_tbl_rec.sort_seq2 := '015';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 1 --
         IF c_emp_rec_new.bank_acct2_seg1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg1';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg1;
            l_emp_chgs_tbl_rec.sort_seq2 := '020';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 2 --
         IF c_emp_rec_new.bank_acct2_seg2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg2';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg2;
            l_emp_chgs_tbl_rec.sort_seq2 := '025';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 3 --
         IF c_emp_rec_new.bank_acct2_seg3 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg3';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg3;
            l_emp_chgs_tbl_rec.sort_seq2 := '030';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 4 --
         IF c_emp_rec_new.bank_acct2_seg4 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg4';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg4;
            l_emp_chgs_tbl_rec.sort_seq2 := '035';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 5 --
         IF c_emp_rec_new.bank_acct2_seg5 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg5';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg5;
            l_emp_chgs_tbl_rec.sort_seq2 := '040';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 6 --
         IF c_emp_rec_new.bank_acct2_seg6 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg6';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg6;
            l_emp_chgs_tbl_rec.sort_seq2 := '045';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 7 --
         IF c_emp_rec_new.bank_acct2_seg7 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg7';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg7;
            l_emp_chgs_tbl_rec.sort_seq2 := '050';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 8 --
         IF c_emp_rec_new.bank_acct2_seg8 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg8';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg8;
            l_emp_chgs_tbl_rec.sort_seq2 := '055';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 9 --
         IF c_emp_rec_new.bank_acct2_seg9 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg9';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg9;
            l_emp_chgs_tbl_rec.sort_seq2 := '060';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 10 --
         IF c_emp_rec_new.bank_acct2_seg10 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg10';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg10;
            l_emp_chgs_tbl_rec.sort_seq2 := '065';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
      END IF;
-----------------------------------------
   ELSE -- Change to Existing Employee --
-----------------------------------------
      l_emp_chgs_tbl_rec.business_group_id := c_emp_rec_new.business_group_id;
      l_emp_chgs_tbl_rec.person_id := c_emp_rec_new.person_id;
      l_emp_chgs_tbl_rec.employee_number := c_emp_rec_new.employee_number;
      l_emp_chgs_tbl_rec.full_name := c_emp_rec_new.full_name;
   --------------
   -- Employee --
   --------------
      l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.person_eff_start_date;
      l_emp_chgs_tbl_rec.sort_seq1 := '005';
      -- Lastest Start Date --
      IF c_emp_rec_new.latest_hire_date <> c_emp_rec_old.latest_hire_date THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Latest Start Date';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.latest_hire_date;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.latest_hire_date;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Last Name --
      IF c_emp_rec_new.last_name <> c_emp_rec_old.last_name THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Last Name';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.last_name;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.last_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- First Name --
      IF NVL(c_emp_rec_new.first_name,'$$') <> NVL(c_emp_rec_old.first_name,'$$') THEN
          l_emp_chgs_tbl_rec.field_name := 'Empl First Name';
          l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.first_name;
          l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.first_name;
          l_emp_chgs_tbl_rec.sort_seq2 := '010';
          insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Middle Names --
      IF NVL(c_emp_rec_new.middle_names,'$$') <> NVL(c_emp_rec_old.middle_names,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Middle Names';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.middle_names;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.middle_names;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Gender --
      IF NVL(c_emp_rec_new.gender,'$$') <> NVL(c_emp_rec_old.gender,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Gender';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.gender;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.gender;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- National ID --
      IF NVL(c_emp_rec_new.national_identifier,'$$') <> NVL(c_emp_rec_old.national_identifier,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl National ID';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.national_identifier;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.national_identifier;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Birth Date --
      IF NVL(c_emp_rec_new.date_of_birth,hr_general.end_of_time) <> NVL(c_emp_rec_old.date_of_birth,hr_general.end_of_time) THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Birth Date';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.date_of_birth;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.date_of_birth;
         l_emp_chgs_tbl_rec.sort_seq2 := '030';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Marital Status --
      IF NVL(c_emp_rec_new.marital_status,'$$') <> NVL(c_emp_rec_old.marital_status,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Marital Status';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.marital_status;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.marital_status;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Nationality --
      IF NVL(c_emp_rec_new.nationality,'$$') <> NVL(c_emp_rec_old.nationality,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Nationality';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.nationality;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.nationality;
         l_emp_chgs_tbl_rec.sort_seq2 := '040';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Work Permit Number --
      IF NVL(c_emp_rec_new.gb_work_permit_nbr,'$$') <> NVL(c_emp_rec_old.gb_work_permit_nbr,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Work Permit';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.gb_work_permit_nbr;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.gb_work_permit_nbr;
         l_emp_chgs_tbl_rec.sort_seq2 := '045';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Country of Birth --
      IF NVL(c_emp_rec_new.country_of_birth,'$$') <> NVL(c_emp_rec_old.country_of_birth,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Country of Birth';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.country_of_birth;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.country_of_birth;
         l_emp_chgs_tbl_rec.sort_seq2 := '050';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Email --
      IF NVL(c_emp_rec_new.email_address,'$$') <> NVL(c_emp_rec_old.email_address,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Email';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.email_address;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.email_address;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Sweden Email --
      IF NVL(c_emp_rec_new.se_email,'$$') <> NVL(c_emp_rec_old.se_email,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Email';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.se_email;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.se_email;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Previous Last Name --
      IF NVL(c_emp_rec_new.previous_last_name,'$$') <> NVL(c_emp_rec_old.previous_last_name,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Prev Last Name';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.previous_last_name;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.previous_last_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '060';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Date First Hired --
      IF NVL(c_emp_rec_new.original_date_of_hire,hr_general.end_of_time) <> NVL(c_emp_rec_old.original_date_of_hire,hr_general.end_of_time) THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl Date First Hired';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.original_date_of_hire;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.original_date_of_hire;
         l_emp_chgs_tbl_rec.sort_seq2 := '065';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Second Nationality --
      IF NVL(c_emp_rec_new.ch_second_nationality,'$$') <> NVL(c_emp_rec_old.ch_second_nationality,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Empl 2nd Nationality';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.ch_second_nationality;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.ch_second_nationality;
         l_emp_chgs_tbl_rec.sort_seq2 := '065';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   -------------
   -- Address --
   -------------
      l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.addr_date_from;
      l_emp_chgs_tbl_rec.sort_seq1 := '010';
      -- Line 1 --
      IF NVL(c_emp_rec_new.address_line1,'$$') <> NVL(c_emp_rec_old.address_line1,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Line 1';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.address_line1;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.address_line1;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Line 2 --
      IF NVL(c_emp_rec_new.address_line2,'$$') <> NVL(c_emp_rec_old.address_line2,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Line 2';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.address_line2;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.address_line2;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Line 3 --
      IF NVL(c_emp_rec_new.address_line3,'$$') <> NVL(c_emp_rec_old.address_line3,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Line 3';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.address_line3;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.address_line3;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Town or City --
      IF NVL(c_emp_rec_new.town_or_city,'$$') <> NVL(c_emp_rec_old.town_or_city,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Town or City';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.town_or_city;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.town_or_city;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Region 1 --
      IF NVL(c_emp_rec_new.region_1,'$$') <> NVL(c_emp_rec_old.region_1,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Region 1';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.region_1;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.region_1;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Region 2 --
      IF NVL(c_emp_rec_new.region_2,'$$') <> NVL(c_emp_rec_old.region_2,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Region 2';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.region_2;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.region_2;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Region 3 --
      IF NVL(c_emp_rec_new.region_3,'$$') <> NVL(c_emp_rec_old.region_3,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Region 3';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.region_3;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.region_3;
         l_emp_chgs_tbl_rec.sort_seq2 := '030';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Postal Code --
      IF NVL(c_emp_rec_new.postal_code,'$$') <> NVL(c_emp_rec_old.postal_code,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Postal Code';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.postal_code;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.postal_code;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Country --
      IF NVL(c_emp_rec_new.country,'$$') <> NVL(c_emp_rec_old.country,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr Country';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.country;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.country;
         l_emp_chgs_tbl_rec.sort_seq2 := '040';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- NL House Number --
      IF NVL(c_emp_rec_new.nl_house_number,'$$') <> NVL(c_emp_rec_old.nl_house_number,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr NL House Number';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.nl_house_number;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.nl_house_number;
         l_emp_chgs_tbl_rec.sort_seq2 := '045';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- NL House Number Addition --
      IF NVL(c_emp_rec_new.nl_house_number_addition,'$$') <> NVL(c_emp_rec_old.nl_house_number_addition,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr NL House Number Add';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.nl_house_number_addition;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.nl_house_number_addition;
         l_emp_chgs_tbl_rec.sort_seq2 := '050';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- KR Address Line1 --
      IF NVL(c_emp_rec_new.kr_address_line1,'$$') <> NVL(c_emp_rec_old.kr_address_line1,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Addr KR Line1';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.kr_address_line1;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.kr_address_line1;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   ------------
   -- Phones --
   ------------
      l_emp_chgs_tbl_rec.sort_seq1 := '015';
      -- Phone - Home --
      IF NVL(c_emp_rec_new.home_phone,'$$') <> NVL(c_emp_rec_old.home_phone,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Home';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.home_phone;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.home_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Work --
      IF NVL(c_emp_rec_new.work_phone,'$$') <> NVL(c_emp_rec_old.work_phone,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Work';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.work_phone;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.work_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Home) --
      IF NVL(c_emp_rec_new.mobile_phone_home,'$$') <> NVL(c_emp_rec_old.mobile_phone_home,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Mobile (Home)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_mobile_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.mobile_phone_home;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.mobile_phone_home;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Work) --
      IF NVL(c_emp_rec_new.mobile_phone_work,'$$') <> NVL(c_emp_rec_old.mobile_phone_work,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Phone - Mobile (Work)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.phone_mobile_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.mobile_phone_work;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.mobile_phone_work;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   ----------------
   -- Assignment --
   ----------------
      l_emp_chgs_tbl_rec.sort_seq1 := '020';
      -- Organization --
      IF NVL(c_emp_rec_new.organization_name,'$$') <> NVL(c_emp_rec_old.organization_name,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Organization';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.organization_name;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.organization_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Position --
      IF NVL(c_emp_rec_new.position_name,'$$') <> NVL(c_emp_rec_old.position_name,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Position';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.position_name;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.position_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Job --
      IF NVL(c_emp_rec_new.job,'$$') <> NVL(c_emp_rec_old.job,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Job';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.job;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.job;
         l_emp_chgs_tbl_rec.sort_seq2 := '006';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Grade --
      IF NVL(c_emp_rec_new.grade_name,'$$') <> NVL(c_emp_rec_old.grade_name,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Grade';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.grade_name;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.grade_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Payroll --
      IF NVL(c_emp_rec_new.payroll_name,'$$') <> NVL(c_emp_rec_old.payroll_name,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Payroll';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.payroll_name;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.payroll_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Location --
      IF NVL(c_emp_rec_new.location_code,'$$') <> NVL(c_emp_rec_old.location_code,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Location';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.location_code;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.location_code;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Status --
      IF NVL(c_emp_rec_new.assignment_status,'$$') <> NVL(c_emp_rec_old.assignment_status,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Assignment Status';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.assignment_status;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.assignment_status;
         l_emp_chgs_tbl_rec.sort_seq2 := '030';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Category --
      IF NVL(c_emp_rec_new.assignment_category,'$$') <> NVL(c_emp_rec_old.assignment_category,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Assignment Category';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.assignment_category;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.assignment_category;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Supervisor --
      IF NVL(c_emp_rec_new.supervisor,'$$') <> NVL(c_emp_rec_old.supervisor,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Asg Supervisor';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.asg_eff_start_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.supervisor;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.supervisor;
         l_emp_chgs_tbl_rec.sort_seq2 := '040';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   -----------------
   -- Termination --
   -----------------
      l_emp_chgs_tbl_rec.sort_seq1 := '025';
      -- Actual Termination Date --
      IF c_emp_rec_new.actual_termination_date IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Term Actual Termination Date';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.actual_termination_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.actual_termination_date;
         l_emp_chgs_tbl_rec.old_value := NULL;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Leaving Reason --
      IF c_emp_rec_new.term_reason IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Term Leaving Reason';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.actual_termination_date;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.term_reason;
         l_emp_chgs_tbl_rec.old_value := NULL;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   -------------
   -- Salary --
   -------------
      IF NVL(c_emp_rec_new.sal_change_date,hr_general.end_of_time) <> NVL(c_emp_rec_old.sal_change_date,hr_general.end_of_time) THEN
         l_emp_chgs_tbl_rec.sort_seq1 := '030';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.sal_change_date;
         -- Change Date --
         l_emp_chgs_tbl_rec.field_name := 'Salary Change Date';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.sal_change_date;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.sal_change_date;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Salary --
         l_emp_chgs_tbl_rec.field_name := 'Salary Annual Salary';
         l_emp_chgs_tbl_rec.new_value := TRIM(TO_CHAR(c_emp_rec_new.proposed_salary_n,'999,999,999.00'));
         l_emp_chgs_tbl_rec.old_value := TRIM(TO_CHAR(c_emp_rec_old.proposed_salary_n,'999,999,999.00'));
         l_emp_chgs_tbl_rec.sort_seq2 := '002';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Hourly Rate --
         l_emp_chgs_tbl_rec.field_name := 'Salary Hourly Rate';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.hourly_rate;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.hourly_rate;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Currency --
         l_emp_chgs_tbl_rec.field_name := 'Salary Currency';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.output_currency_code;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.output_currency_code;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Change Reason --
         l_emp_chgs_tbl_rec.field_name := 'Salary Change Reason';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.proposal_reason;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.proposal_reason;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Approved --
         l_emp_chgs_tbl_rec.field_name := 'Salary Approved';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.approved;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.approved;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   -------------
   -- Costing --
   -------------
      l_emp_chgs_tbl_rec.sort_seq1 := '045';
      -- Legal Entity (Segment1) --
      IF NVL(c_emp_rec_new.cost_legal_entity,'$$') <> NVL(c_emp_rec_old.cost_legal_entity,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Legal Entity';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_legal_entity;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.cost_legal_entity;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Product Line (Segment2) --
      IF NVL(c_emp_rec_new.cost_product_line,'$$') <> NVL(c_emp_rec_old.cost_product_line,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Product Line';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_product_line;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.cost_product_line;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Business Unit (Segment3) --
      IF NVL(c_emp_rec_new.cost_business_unit,'$$') <> NVL(c_emp_rec_old.cost_business_unit,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Business Unit';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_business_unit;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.cost_business_unit;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Management Unit (Segment4) --
      IF NVL(c_emp_rec_new.cost_management_unit,'$$') <> NVL(c_emp_rec_old.cost_management_unit,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Management Unit';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_management_unit;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.cost_management_unit;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Department (Segment5) --
      IF NVL(c_emp_rec_new.cost_department,'$$') <> NVL(c_emp_rec_old.cost_department,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Department';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_department;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.cost_department;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Account (Segment6) --
      IF NVL(c_emp_rec_new.cost_account,'$$') <> NVL(c_emp_rec_old.cost_account,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Costing Account';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.cost_eff_dt;
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.cost_account;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.cost_account;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   ------------------
   -- Pay Method 1 --
   ------------------
      IF NVL(c_emp_rec_new.pppm1_eff_dt,hr_general.end_of_time) <> NVL(c_emp_rec_old.pppm1_eff_dt,hr_general.end_of_time) THEN
         l_emp_chgs_tbl_rec.sort_seq1 := '050';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.pppm1_eff_dt;
         -- Payment Method Name --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Name';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.pay_meth_name1;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.pay_meth_name1;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Priority --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Priority';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.priority1;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.priority1;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Amount --
         IF c_emp_rec_new.amount1 IS NOT NULL OR c_emp_rec_old.amount1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Amount';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.amount1;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.amount1;
            l_emp_chgs_tbl_rec.sort_seq2 := '010';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Percentage --
         IF c_emp_rec_new.percentage1 IS NOT NULL OR c_emp_rec_old.percentage1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method1 Percentage';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.percentage1;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.percentage1;
            l_emp_chgs_tbl_rec.sort_seq2 := '015';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 1 --
         IF c_emp_rec_new.bank_acct1_seg1 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg1';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg1;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg1;
            l_emp_chgs_tbl_rec.sort_seq2 := '020';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 2 --
         IF c_emp_rec_new.bank_acct1_seg2 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg2';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg2;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg2;
            l_emp_chgs_tbl_rec.sort_seq2 := '025';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 3 --
         IF c_emp_rec_new.bank_acct1_seg3 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg3 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg3';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg3;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg3;
            l_emp_chgs_tbl_rec.sort_seq2 := '030';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 4 --
         IF c_emp_rec_new.bank_acct1_seg4 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg4 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg4';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg4;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg4;
            l_emp_chgs_tbl_rec.sort_seq2 := '035';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 5 --
         IF c_emp_rec_new.bank_acct1_seg5 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg5 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg5';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg5;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg5;
            l_emp_chgs_tbl_rec.sort_seq2 := '040';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 6 --
         IF c_emp_rec_new.bank_acct1_seg6 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg6 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg6';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg6;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg6;
            l_emp_chgs_tbl_rec.sort_seq2 := '045';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 7 --
         IF c_emp_rec_new.bank_acct1_seg7 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg7 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg7';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg7;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg7;
            l_emp_chgs_tbl_rec.sort_seq2 := '050';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 8 --
         IF c_emp_rec_new.bank_acct1_seg8 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg8 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg8';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg8;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg8;
            l_emp_chgs_tbl_rec.sort_seq2 := '055';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 9 --
         IF c_emp_rec_new.bank_acct1_seg9 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg9 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg9';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg9;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg9;
            l_emp_chgs_tbl_rec.sort_seq2 := '060';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 10 --
         IF c_emp_rec_new.bank_acct1_seg10 IS NOT NULL OR c_emp_rec_old.bank_acct1_seg10 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank Acct1 Seg10';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct1_seg10;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct1_seg10;
            l_emp_chgs_tbl_rec.sort_seq2 := '065';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
      END IF;
   ------------------
   -- Pay Method 2 --
   ------------------
      IF NVL(c_emp_rec_new.pppm2_eff_dt,hr_general.end_of_time) <> NVL(c_emp_rec_old.pppm2_eff_dt,hr_general.end_of_time) THEN
         l_emp_chgs_tbl_rec.sort_seq1 := '055';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_emp_rec_new.pppm2_eff_dt;
         -- Payment Method Name --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Name';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.pay_meth_name2;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.pay_meth_name2;
         l_emp_chgs_tbl_rec.sort_seq2 := '000';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Priority --
         l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Priority';
         l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.priority2;
         l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.priority2;
         l_emp_chgs_tbl_rec.sort_seq2 := '005';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         -- Amount --
         IF c_emp_rec_new.amount2 IS NOT NULL OR c_emp_rec_old.amount2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Amount';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.amount2;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.amount2;
            l_emp_chgs_tbl_rec.sort_seq2 := '010';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Percentage --
         IF c_emp_rec_new.percentage2 IS NOT NULL OR c_emp_rec_old.percentage2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Pay Method2 Percentage';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.percentage2;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.percentage2;
            l_emp_chgs_tbl_rec.sort_seq2 := '015';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 1 --
         IF c_emp_rec_new.bank_acct2_seg1 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg1 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg1';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg1;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg1;
            l_emp_chgs_tbl_rec.sort_seq2 := '020';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 2 --
         IF c_emp_rec_new.bank_acct2_seg2 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg2 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg2';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg2;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg2;
            l_emp_chgs_tbl_rec.sort_seq2 := '025';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 3 --
         IF c_emp_rec_new.bank_acct2_seg3 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg3 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg3';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg3;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg3;
            l_emp_chgs_tbl_rec.sort_seq2 := '030';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 4 --
         IF c_emp_rec_new.bank_acct2_seg4 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg4 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg4';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg4;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg4;
            l_emp_chgs_tbl_rec.sort_seq2 := '035';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 5 --
         IF c_emp_rec_new.bank_acct2_seg5 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg5 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg5';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg5;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg5;
            l_emp_chgs_tbl_rec.sort_seq2 := '040';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 6 --
         IF c_emp_rec_new.bank_acct2_seg6 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg6 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg6';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg6;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg6;
            l_emp_chgs_tbl_rec.sort_seq2 := '045';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 7 --
         IF c_emp_rec_new.bank_acct2_seg7 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg7 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg7';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg7;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg7;
            l_emp_chgs_tbl_rec.sort_seq2 := '050';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 8 --
         IF c_emp_rec_new.bank_acct2_seg8 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg8 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg8';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg8;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg8;
            l_emp_chgs_tbl_rec.sort_seq2 := '055';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 9 --
         IF c_emp_rec_new.bank_acct2_seg9 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg9 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg9';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg9;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg9;
            l_emp_chgs_tbl_rec.sort_seq2 := '060';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
         -- Bank Acct 10 --
         IF c_emp_rec_new.bank_acct2_seg10 IS NOT NULL OR c_emp_rec_old.bank_acct2_seg10 IS NOT NULL THEN
            l_emp_chgs_tbl_rec.field_name := 'Bank_Acct2_Seg10';
            l_emp_chgs_tbl_rec.new_value := c_emp_rec_new.bank_acct2_seg10;
            l_emp_chgs_tbl_rec.old_value := c_emp_rec_old.bank_acct2_seg10;
            l_emp_chgs_tbl_rec.sort_seq2 := '065';
            insert_emp_chgs_table(l_emp_chgs_tbl_rec);
         END IF;
      END IF;
   END IF;

   CLOSE c_emp_old;
   COMMIT;

END LOOP;

---------------
-- Contacts --
---------------
FOR c_con_rec_new IN c_con_new(p_date_from, p_date_to, p_business_group_id)
LOOP
   l_emp_chgs_tbl_rec.business_group_id := c_con_rec_new.business_group_id;
   l_emp_chgs_tbl_rec.person_id := c_con_rec_new.per_person_id;
   l_emp_chgs_tbl_rec.employee_number := c_con_rec_new.employee_number;
   l_emp_chgs_tbl_rec.full_name := c_con_rec_new.full_name;
   IF ln_prev_person_id = c_con_rec_new.per_person_id THEN
      ln_count_contacts := ln_count_contacts + 1;
      l_emp_chgs_tbl_rec.chg_eff_dt := NULL;
      l_emp_chgs_tbl_rec.field_name := '-----';
      l_emp_chgs_tbl_rec.new_value := NULL;
      l_emp_chgs_tbl_rec.old_value := NULL;
      l_emp_chgs_tbl_rec.sort_seq2 := '999';
      insert_emp_chgs_table(l_emp_chgs_tbl_rec);
   ELSE
      ln_count_contacts := 1;
      ln_prev_person_id := c_con_rec_new.per_person_id;
   END IF;
   -- Get old data for the contact if exists --
   OPEN c_con_old(p_date_from, c_con_rec_new.per_person_id, c_con_rec_new.con_person_id);
   FETCH c_con_old INTO c_con_rec_old;
   IF c_con_old%NOTFOUND
   THEN -- NEW --
      l_emp_chgs_tbl_rec.sort_seq1 := '06'||ln_count_contacts;
      l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.con_eff_start_dt;
      l_emp_chgs_tbl_rec.old_value := NULL;
      -- Last Name --
      l_emp_chgs_tbl_rec.field_name := 'Contact Last Name';
      l_emp_chgs_tbl_rec.new_value := c_con_rec_new.last_name;
      l_emp_chgs_tbl_rec.sort_seq2 := '005';
      insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      -- First Name --
      IF c_con_rec_new.first_name IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact First Name';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.first_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Middle Names --
      IF c_con_rec_new.middle_names IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Middle Names';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.middle_names;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Gender --
      IF c_con_rec_new.gender IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Gender';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.gender;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Birth Date --
      IF c_con_rec_new.date_of_birth IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Birth Date';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.date_of_birth;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.date_start;
      -- Relationship --
      l_emp_chgs_tbl_rec.field_name := 'Contact Relationship';
      l_emp_chgs_tbl_rec.new_value := c_con_rec_new.relationship;
      l_emp_chgs_tbl_rec.sort_seq2 := '030';
      insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      -- Primary --
      IF c_con_rec_new.primary_contact_flag IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact is Primary?';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.primary_contact_flag;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Dependent --
      IF c_con_rec_new.dependent_flag IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact is Dependent?';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.dependent_flag;
         l_emp_chgs_tbl_rec.sort_seq2 := '040';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Beneficiary --
      IF c_con_rec_new.beneficiary_flag IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact is Beneficiary?';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.beneficiary_flag;
         l_emp_chgs_tbl_rec.sort_seq2 := '045';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      --------------------
      -- Contact Phones --
      --------------------
      -- Phone - Home --
      IF c_con_rec_new.home_phone IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Home';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.home_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '050';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Work --
      IF c_con_rec_new.work_phone IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Work';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.work_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Home) --
      IF c_con_rec_new.mobile_phone_home IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Mobile (Home)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_mobile_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.mobile_phone_home;
         l_emp_chgs_tbl_rec.sort_seq2 := '060';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Work) --
      IF c_con_rec_new.mobile_phone_work IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Mobile (Work)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_mobile_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.mobile_phone_work;
         l_emp_chgs_tbl_rec.sort_seq2 := '065';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
------------------------------
   ELSE -- Existing Contact --
------------------------------
      l_emp_chgs_tbl_rec.sort_seq1 := '06'||ln_count_contacts;
      l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.con_eff_start_dt;
      -- Last Name --
      l_emp_chgs_tbl_rec.field_name := 'Contact Last Name';
      l_emp_chgs_tbl_rec.new_value := c_con_rec_new.last_name;
      l_emp_chgs_tbl_rec.old_value := c_con_rec_old.last_name;
      l_emp_chgs_tbl_rec.sort_seq2 := '005';
      insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      -- First Name --
      IF c_con_rec_new.first_name IS NOT NULL OR c_con_rec_old.first_name IS NOT NULL THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact First Name';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.first_name;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.first_name;
         l_emp_chgs_tbl_rec.sort_seq2 := '010';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Middle Names --
      IF NVL(c_con_rec_new.middle_names,'$$') <> NVL(c_con_rec_old.middle_names,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Middle Names';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.middle_names;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.middle_names;
         l_emp_chgs_tbl_rec.sort_seq2 := '015';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Gender --
      IF NVL(c_con_rec_new.gender,'$$') <> NVL(c_con_rec_old.gender,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Gender';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.gender;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.gender;
         l_emp_chgs_tbl_rec.sort_seq2 := '020';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Birth Date --
      IF NVL(c_con_rec_new.date_of_birth,hr_general.end_of_time) <> NVL(c_con_rec_old.date_of_birth,hr_general.end_of_time) THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Birth Date';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.date_of_birth;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.date_of_birth;
         l_emp_chgs_tbl_rec.sort_seq2 := '025';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.date_start;
      -- Relationship --
      IF NVL(c_con_rec_new.relationship,'$$') <> NVL(c_con_rec_old.relationship,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Relationship';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.relationship;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.relationship;
         l_emp_chgs_tbl_rec.sort_seq2 := '030';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Primary --
      IF NVL(c_con_rec_new.primary_contact_flag,'$$') <> NVL(c_con_rec_old.primary_contact_flag,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact is Primary?';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.primary_contact_flag;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.primary_contact_flag;
         l_emp_chgs_tbl_rec.sort_seq2 := '035';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Dependent --
      IF NVL(c_con_rec_new.dependent_flag,'$$') <> NVL(c_con_rec_old.dependent_flag,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact is Dependent?';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.dependent_flag;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.dependent_flag;
         l_emp_chgs_tbl_rec.sort_seq2 := '040';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Beneficiary --
      IF NVL(c_con_rec_new.beneficiary_flag,'$$') <> NVL(c_con_rec_old.beneficiary_flag,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact is Beneficiary?';
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.beneficiary_flag;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.beneficiary_flag;
         l_emp_chgs_tbl_rec.sort_seq2 := '045';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      --------------------
      -- Contact Phones --
      --------------------
      -- Phone - Home --
      IF NVL(c_con_rec_new.home_phone,'$$') <> NVL(c_con_rec_old.home_phone,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Home';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.home_phone;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.home_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '050';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Work --
      IF NVL(c_con_rec_new.work_phone,'$$') <> NVL(c_con_rec_old.work_phone,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Work';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.work_phone;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.work_phone;
         l_emp_chgs_tbl_rec.sort_seq2 := '055';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Home) --
      IF NVL(c_con_rec_new.mobile_phone_home,'$$') <> NVL(c_con_rec_old.mobile_phone_home,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Mobile (Home)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_mobile_home_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.mobile_phone_home;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.mobile_phone_home;
         l_emp_chgs_tbl_rec.sort_seq2 := '060';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
      -- Phone - Mobile (Work) --
      IF NVL(c_con_rec_new.mobile_phone_work,'$$') <> NVL(c_con_rec_old.mobile_phone_work,'$$') THEN
         l_emp_chgs_tbl_rec.field_name := 'Contact Phone - Mobile (Work)';
         l_emp_chgs_tbl_rec.chg_eff_dt := c_con_rec_new.phone_mobile_work_date_from;
         l_emp_chgs_tbl_rec.new_value := c_con_rec_new.mobile_phone_work;
         l_emp_chgs_tbl_rec.old_value := c_con_rec_old.mobile_phone_work;
         l_emp_chgs_tbl_rec.sort_seq2 := '065';
         insert_emp_chgs_table(l_emp_chgs_tbl_rec);
      END IF;
   END IF;
   CLOSE c_con_old;
END LOOP;
COMMIT;


EXCEPTION
   WHEN OTHERS THEN
      IF c_emp_old%ISOPEN
      THEN
         CLOSE c_emp_old;
      END IF;

      IF c_con_old%ISOPEN
      THEN
         CLOSE c_con_old;
      END IF;

      ROLLBACK;

      fnd_file.put_line(fnd_file.LOG, '****************************************************');
      fnd_file.put_line(fnd_file.LOG, '*  *** ERROR - UNEXPECTED ERROR ***');
      fnd_file.put_line(fnd_file.LOG, '*      Pgm Location: '||g_pgm_location);
      fnd_file.put_line(fnd_file.LOG, '*      SQL Error Msg: '||SUBSTR(SQLERRM,1,200));
      fnd_file.put_line(fnd_file.LOG, '****************************************************');

END Process_Employee_Changes;


------------------------------------------------------------------------------------
-- P R O C E D U R E
-- Name: Main
-- Description: The controlling procedure
------------------------------------------------------------------------------------
PROCEDURE Main (p_errbuf            OUT VARCHAR2
               ,p_retcode           OUT NUMBER
               ,p_date_from         IN  DATE
               ,p_date_to           IN  DATE
               ,p_business_group_id IN  NUMBER)

IS

ld_date_from    DATE;
ld_date_to      DATE;

-------------------------------------------------------
-- B E G I N
-------------------------------------------------------
BEGIN

g_pgm_location := 'Main';

-- Clear xxha_hr_emp_changes Table
DELETE FROM xxha_hr_emp_changes;
COMMIT;


-- P R O C E S S   E M P L O Y E E   C H A N G E S --
process_employee_changes( p_date_from
                         ,p_date_to
                         ,p_business_group_id);

p_retcode := 0;

EXCEPTION
   WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.LOG, '****************************************************');
      fnd_file.put_line(fnd_file.LOG, '*  *** ERROR - UNEXPECTED ERROR ***');
      fnd_file.put_line(fnd_file.LOG, '*      Pgm Location: '||g_pgm_location);
      fnd_file.put_line(fnd_file.LOG, '*      SQL Error Msg: '||SUBSTR(SQLERRM,1,200));
      fnd_file.put_line(fnd_file.LOG, '****************************************************');
      p_errbuf := SQLERRM;
      p_retcode := 2;
      ROLLBACK;

END Main;

END xxha_hr_emp_chg_pkg;

/
