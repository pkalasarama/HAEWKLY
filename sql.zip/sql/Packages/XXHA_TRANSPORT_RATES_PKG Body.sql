create or replace PACKAGE BODY XXHA_TRANSPORT_RATES_PKG AS

/****************************************************************************************************************
*
* Package Name : XXHA_TRANSPORT_RATES_PKG
* Description:  This package will use XXHA_TRANSPORT_RATES_V to determine Transportation Charges 
* Notes:
*
* Modified:       Ver      Date            Modification
* -------------   -----    -----------     ----------------------------------------------------------------------
* BMarcoux        1.0      01-MAR-2016     Initial Package Creation
*
****************************************************************************************************************/

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_MAIN

PROCEDURE XXHA_TRANS_MAIN (P_SESSION_ID                   IN NUMBER
                         , P_header_tbl                   IN Header_Tbl_Type
                          ) IS


l_Count                           NUMBER := 0;

l_Multi_Processing                VARCHAR(01)   := NULL;
l_DLT_XXHA_TRANSPORT_TEMP_TBL     VARCHAR2(500) := NULL;
l_DLT_XXHA_TRANSPORT_RATES_CLC    VARCHAR2(500) := NULL;

l_SESSION_ID                      HAEMO.XXHA_TRANSPORT_RATES_CALCS.SESSION_ID%TYPE := NULL;
l_TRANS_MODE                      HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANS_MODE%TYPE := NULL;
l_PROVIDER                        HAEMO.XXHA_TRANSPORT_RATES_CALCS.PROVIDER%TYPE   := NULL;
l_LANE_TYPE                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.LANE_TYPE%TYPE  := NULL;
l_LANE_ID                         HAEMO.XXHA_TRANSPORT_RATES_CALCS.LANE_ID %TYPE   := NULL;

-- Cursor cur_0100
CURSOR cur_0100(
                P_SESSION_ID      HAEMO.XXHA_TRANSPORT_RATES_CALCS.SESSION_ID%TYPE
              , P_TRANS_MODE      HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANS_MODE%TYPE
                )
IS
SELECT
    SESSION_ID
  , TRANS_MODE
  , PROVIDER
  , LANE_TYPE
  , LANE_ID
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL XXHA
WHERE
    XXHA.SESSION_ID  = P_SESSION_ID
AND XXHA.TRANS_MODE  = P_TRANS_MODE
ORDER BY
    XXHA.SESSION_ID
  , XXHA.TRANS_MODE
  , XXHA.PROVIDER
  , XXHA.LANE_TYPE
  , XXHA.LANE_ID;

-- Cursor cur_0110
CURSOR cur_0110(
                P_SESSION_ID      HAEMO.XXHA_TRANSPORT_RATES_CALCS.SESSION_ID%TYPE
              , P_TRANS_MODE      HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANS_MODE%TYPE
                )
IS
SELECT
    SESSION_ID
  , TRANS_MODE
  , PROVIDER
  , LANE_TYPE
  , LANE_ID
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL XXHA
WHERE
    XXHA.SESSION_ID  = P_SESSION_ID
AND XXHA.TRANS_MODE  = P_TRANS_MODE
ORDER BY
    XXHA.SESSION_ID
  , XXHA.TRANS_MODE
  , XXHA.PROVIDER
  , XXHA.LANE_TYPE
  , XXHA.LANE_ID;

BEGIN

   -- TRUNCATE TABLE HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL for Session_ID
   l_DLT_XXHA_TRANSPORT_TEMP_TBL := 'DELETE FROM HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL WHERE SESSION_ID = ' || P_SESSION_ID;
   EXECUTE IMMEDIATE l_DLT_XXHA_TRANSPORT_TEMP_TBL;
   COMMIT;

   -- TRUNCATE TABLE HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL if CREATION_DATE was 2 or more days ago
   l_DLT_XXHA_TRANSPORT_TEMP_TBL := 'DELETE FROM HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL WHERE TRUNC(CREATION_DATE) <= ' || 'TRUNC(SYSDATE)-2';
   EXECUTE IMMEDIATE l_DLT_XXHA_TRANSPORT_TEMP_TBL;
   COMMIT;

   -- TRUNCATE TABLE HAEMO.XXHA_TRANSPORT_RATES_CALCS for Session_ID
   l_DLT_XXHA_TRANSPORT_RATES_CLC := 'DELETE FROM HAEMO.XXHA_TRANSPORT_RATES_CALCS WHERE SESSION_ID = ' || P_SESSION_ID;
   EXECUTE IMMEDIATE l_DLT_XXHA_TRANSPORT_RATES_CLC;
   COMMIT;

   -- TRUNCATE TABLE HAEMO.XXHA_TRANSPORT_RATES_CALCS if CREATION_DATE was 2 or more days ago
   l_DLT_XXHA_TRANSPORT_RATES_CLC := 'DELETE FROM HAEMO.XXHA_TRANSPORT_RATES_CALCS WHERE TRUNC(CREATION_DATE) <= ' || 'TRUNC(SYSDATE)-2';
   EXECUTE IMMEDIATE l_DLT_XXHA_TRANSPORT_RATES_CLC;
   COMMIT;

   -- DELETE FROM TABLE HAEMO.XXHA_TRANSPORT_RATES_CALCS for Session_ID
   l_DLT_XXHA_TRANSPORT_RATES_CLC := 'DELETE FROM HAEMO.XXHA_TRANSPORT_RATES_CALCS WHERE SESSION_ID = ' || P_SESSION_ID;
   EXECUTE IMMEDIATE l_DLT_XXHA_TRANSPORT_RATES_CLC;
   COMMIT;

   -- Process the data!
   IF P_header_tbl.COUNT <> 0 THEN
      FOR i IN P_header_tbl.first..P_header_tbl.last
      LOOP
         XXHA_SKID_PROCESSING(P_SESSION_ID, P_header_tbl, i);
      END LOOP;
   END IF;

   -- Initialize Values
   l_SESSION_ID       := -1234567890;
   l_PROVIDER         := '+-XXXXXXX-+';
   l_LANE_TYPE        := '+-XXXXXXX-+';
   l_LANE_ID          := '+-XXXXXXX-+';
   l_Count            := 0;
   l_Multi_Processing := 'N';
   l_TRANS_MODE       := 'AIR';

   -- Now see if multiple records exist for 'AIR'
   FOR recs IN cur_0100(P_SESSION_ID, l_TRANS_MODE)
   LOOP

      -- Setup break points
      IF (recs.SESSION_ID <> l_SESSION_ID) OR (recs.PROVIDER <> l_PROVIDER) OR (recs.LANE_TYPE <> l_LANE_TYPE) OR (recs.LANE_ID <> l_LANE_ID) THEN
         l_SESSION_ID := recs.SESSION_ID;
         l_PROVIDER   := recs.PROVIDER;
         l_LANE_TYPE  := recs.LANE_TYPE;
         l_LANE_ID    := recs.LANE_ID;
         l_Count      := 0;
      END IF;

      -- Determine if there are multiple records per SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID
      IF (recs.SESSION_ID = l_SESSION_ID) AND (recs.PROVIDER = l_PROVIDER) AND (recs.LANE_TYPE = l_LANE_TYPE) AND (recs.LANE_ID = l_LANE_ID) THEN
         l_Count := l_Count +1;
      END IF;

      -- If multiples found, we need to perform multi-processing
      IF l_Count > 1 THEN
         l_Multi_Processing := 'Y';
         EXIT;
      END IF;

   END LOOP;

   IF l_Multi_Processing = 'Y' THEN
      -- The records for 'AIR' in XXHA_TRANSPORT_RATES_TEMP_TBL do not contain valid values for Multi-Skid processing so delete them
      l_DLT_XXHA_TRANSPORT_TEMP_TBL := 'DELETE FROM HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL WHERE SESSION_ID = ' || P_SESSION_ID || ' AND TRANS_MODE = ''' || l_TRANS_MODE || '''';
      EXECUTE IMMEDIATE l_DLT_XXHA_TRANSPORT_TEMP_TBL;
      COMMIT;
      -- Process Multi-Skid
      XXHA_MULTI_SKID_AIR(P_SESSION_ID, l_TRANS_MODE);
   END IF;

   -- Initialize Values
   l_SESSION_ID       := -1234567890;
   l_PROVIDER         := '+-XXXXXXX-+';
   l_LANE_TYPE        := '+-XXXXXXX-+';
   l_LANE_ID          := '+-XXXXXXX-+';
   l_Count            := 0;
   l_Multi_Processing := 'N';
   l_TRANS_MODE       := 'LCL';

   -- Now see if multiple records exist for 'LCL'
   FOR recs IN cur_0110(P_SESSION_ID, l_TRANS_MODE)
   LOOP

      -- Setup break points
      IF (recs.SESSION_ID <> l_SESSION_ID) OR (recs.PROVIDER <> l_PROVIDER) OR (recs.LANE_TYPE <> l_LANE_TYPE) OR (recs.LANE_ID <> l_LANE_ID) THEN
         l_SESSION_ID := recs.SESSION_ID;
         l_PROVIDER   := recs.PROVIDER;
         l_LANE_TYPE  := recs.LANE_TYPE;
         l_LANE_ID    := recs.LANE_ID;
         l_Count      := 0;
      END IF;

      -- Determine if there are multiple records per SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID
      IF (recs.SESSION_ID = l_SESSION_ID) AND (recs.PROVIDER = l_PROVIDER) AND (recs.LANE_TYPE = l_LANE_TYPE) AND (recs.LANE_ID = l_LANE_ID) THEN
         l_Count := l_Count +1;
      END IF;

      -- If multiples found, we need to perform multi-processing
      IF l_Count > 1 THEN
         l_Multi_Processing := 'Y';
         EXIT;
      END IF;

   END LOOP;

   IF l_Multi_Processing = 'Y' THEN    
      -- The records for 'LCL' in XXHA_TRANSPORT_RATES_TEMP_TBL do not contain valid values for Multi-Skid processing so delete them
      l_DLT_XXHA_TRANSPORT_TEMP_TBL := 'DELETE FROM HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL WHERE SESSION_ID = ' || P_SESSION_ID || ' AND TRANS_MODE = ''' || l_TRANS_MODE || '''';
      EXECUTE IMMEDIATE l_DLT_XXHA_TRANSPORT_TEMP_TBL;
      COMMIT;
      -- Process Multi-Skid
      XXHA_MULTI_SKID_LCL(P_SESSION_ID, l_TRANS_MODE);
   END IF;

END XXHA_TRANS_MAIN;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_SKID_PROCESSING
PROCEDURE XXHA_SKID_PROCESSING (P_SESSION_ID                   IN NUMBER
                              , P_header_tbl                   IN Header_Tbl_Type
                              , P_Count                        IN NUMBER
                               ) IS

P_DATE_IN                         DATE;

P_LENGTH_INCHES                   NUMBER        := 0;
P_WIDTH_INCHES                    NUMBER        := 0;
P_HEIGHT_INCHES                   NUMBER        := 0;
P_ACTUAL_WEIGHT_LBS               NUMBER        := 0;
P_QUANTITY_PALLETS                NUMBER        := 0;

P_ORIGIN_CITY                     VARCHAR2(240) := NULL;
P_ORIGIN_STATE                    VARCHAR2(240) := NULL;
P_ORIGIN_COUNTRY                  VARCHAR2(240) := NULL;
P_DESTINATION_CITY                VARCHAR2(240) := NULL;
P_DESTINATION_STATE               VARCHAR2(240) := NULL;
P_DESTINATION_COUNTRY             VARCHAR2(240) := NULL;
P_FCL                             VARCHAR2(240) := NULL;
P_LCL                             VARCHAR2(240) := NULL;
P_AIR                             VARCHAR2(240) := NULL;
P_STD_METRIC                      VARCHAR2(240) := NULL;

-- Cursor cur_0200
CURSOR cur_0200(
                P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE
              , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE
              , P_ORIGIN_COUNTRY            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_COUNTRY%TYPE
              , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE
              , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE
              , P_DESTINATION_COUNTRY       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_COUNTRY%TYPE
              , P_DATE                      HAEMO.XXHA_TRANSPORT_RATES_V.EFFECTIVE_START_DATE%TYPE
               )
IS
SELECT 
    xxtr.TRANS_MODE
  , xxtr.PROVIDER
  , xxtr.SHIPPER_NAME
  , xxtr.COSIGNEE_NAME
  , xxtr.LANE_ID
  , xxtr.LANE_TYPE
  , xxtr.EQUIPMENT
  , xxtr.SERVICE
  , xxtr.ORIGIN_TYPE
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_V                 xxtr
WHERE
    UPPER(xxtr.ORIGIN_CITY)                    = UPPER(P_ORIGIN_CITY)
AND NVL(UPPER(xxtr.ORIGIN_STATE),'XXX')        = NVL(UPPER(P_ORIGIN_STATE),'XXX')
AND NVL(UPPER(xxtr.ORIGIN_COUNTRY),'XXX')      = NVL(UPPER(P_ORIGIN_COUNTRY),'XXX')
AND UPPER(xxtr.DESTINATION_CITY)               = UPPER(P_DESTINATION_CITY)
AND NVL(UPPER(xxtr.DESTINATION_STATE),'XXX')   = NVL(UPPER(P_DESTINATION_STATE),'XXX')
AND NVL(UPPER(xxtr.DESTINATION_COUNTRY),'XXX') = NVL(UPPER(P_DESTINATION_COUNTRY),'XXX')
AND P_DATE BETWEEN TRUNC(xxtr.Effective_Start_Date) AND NVL(TRUNC(xxtr.Effective_End_Date), '01-JAN-4715')
;

BEGIN

   P_ORIGIN_CITY         := P_header_tbl(P_Count).P_ORIGIN_CITY;
   P_ORIGIN_STATE        := P_header_tbl(P_Count).P_ORIGIN_STATE;
   P_ORIGIN_COUNTRY      := P_header_tbl(P_Count).P_ORIGIN_COUNTRY;
   P_DESTINATION_CITY    := P_header_tbl(P_Count).P_DESTINATION_CITY;
   P_DESTINATION_STATE   := P_header_tbl(P_Count).P_DESTINATION_STATE;
   P_DESTINATION_COUNTRY := P_header_tbl(P_Count).P_DESTINATION_COUNTRY;
   P_LENGTH_INCHES       := P_header_tbl(P_Count).P_LENGTH_INCHES;
   P_WIDTH_INCHES        := P_header_tbl(P_Count).P_WIDTH_INCHES;
   P_HEIGHT_INCHES       := P_header_tbl(P_Count).P_HEIGHT_INCHES;
   P_ACTUAL_WEIGHT_LBS   := P_header_tbl(P_Count).P_ACTUAL_WEIGHT_LBS;
   P_QUANTITY_PALLETS    := P_header_tbl(P_Count).P_QUANTITY_PALLETS;
   P_STD_METRIC          := P_header_tbl(P_Count).P_STD_METRIC;
   P_DATE_IN             := P_header_tbl(P_Count).P_DATE_IN;
   P_FCL                 := P_header_tbl(P_Count).P_FCL;
   P_LCL                 := P_header_tbl(P_Count).P_LCL;
   P_AIR                 := P_header_tbl(P_Count).P_AIR;

   g_Date                := P_header_tbl(P_Count).P_DATE_IN;

   FOR dta IN cur_0200(P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY, P_DATE_IN)
   LOOP

      -- Processing
      IF (dta.TRANS_MODE = 'FCL') AND (NVL(P_FCL,'N') = 'Y') THEN
         XXHA_TRANSPORT_RATES_PKG.XXHA_TRANS_FCL(P_SESSION_ID, P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY , dta.PROVIDER, dta.SHIPPER_NAME, dta.COSIGNEE_NAME, dta.LANE_ID, dta.LANE_TYPE, dta.EQUIPMENT, dta.SERVICE, dta.ORIGIN_TYPE, P_DATE_IN, P_QUANTITY_PALLETS);
      END IF;

      IF (dta.TRANS_MODE = 'LCL') AND (NVL(P_LCL,'N') = 'Y') THEN
         IF (P_LENGTH_INCHES IS NOT NULL) AND (P_WIDTH_INCHES IS NOT NULL) AND (P_HEIGHT_INCHES IS NOT NULL) AND (P_ACTUAL_WEIGHT_LBS IS NOT NULL) AND (P_QUANTITY_PALLETS IS NOT NULL) THEN
            XXHA_TRANSPORT_RATES_PKG.XXHA_TRANS_LCL(P_SESSION_ID, P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY , dta.PROVIDER, dta.SHIPPER_NAME, dta.COSIGNEE_NAME, dta.LANE_ID , dta.LANE_TYPE, dta.EQUIPMENT, dta.SERVICE, dta.ORIGIN_TYPE , P_LENGTH_INCHES, P_WIDTH_INCHES, P_HEIGHT_INCHES , P_ACTUAL_WEIGHT_LBS, P_QUANTITY_PALLETS, P_STD_METRIC, P_DATE_IN);
         END IF;
      END IF;

      IF (dta.TRANS_MODE = 'AIR') AND (NVL(P_AIR,'N') = 'Y') THEN
         IF (P_LENGTH_INCHES IS NOT NULL) AND (P_WIDTH_INCHES IS NOT NULL) AND (P_HEIGHT_INCHES IS NOT NULL) AND (P_ACTUAL_WEIGHT_LBS IS NOT NULL) AND (P_QUANTITY_PALLETS IS NOT NULL) THEN
            XXHA_TRANSPORT_RATES_PKG.XXHA_TRANS_AIR(P_SESSION_ID, P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY , dta.PROVIDER, dta.SHIPPER_NAME, dta.COSIGNEE_NAME, dta.LANE_ID , dta.LANE_TYPE, dta.EQUIPMENT, dta.SERVICE, dta.ORIGIN_TYPE , P_LENGTH_INCHES, P_WIDTH_INCHES, P_HEIGHT_INCHES , P_ACTUAL_WEIGHT_LBS, P_QUANTITY_PALLETS, P_STD_METRIC, P_DATE_IN, P_Count);
         END IF;
      END IF;

   END LOOP;

END XXHA_SKID_PROCESSING;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_FCL

PROCEDURE XXHA_TRANS_FCL (P_SESSION_ID                    IN NUMBER
                        , P_ORIGIN_CITY                   IN VARCHAR2
                        , P_ORIGIN_STATE                  IN VARCHAR2
                        , P_ORIGIN_COUNTRY                IN VARCHAR2
                        , P_DESTINATION_CITY              IN VARCHAR2
                        , P_DESTINATION_STATE             IN VARCHAR2
                        , P_DESTINATION_COUNTRY           IN VARCHAR2
                        , P_PROVIDER                      IN VARCHAR2
                        , P_SHIPPER_NAME                  IN VARCHAR2
                        , P_COSIGNEE_NAME                 IN VARCHAR2
                        , P_LANE_ID                       IN VARCHAR2
                        , P_LANE_TYPE                     IN VARCHAR2
                        , P_EQUIPMENT                     IN VARCHAR2
                        , P_SERVICE                       IN VARCHAR2
                        , P_ORIGIN_TYPE                   IN VARCHAR2
                        , P_DATE_IN                       IN DATE
                        , P_QTY_PALLETS                   IN NUMBER
                         ) IS

l_Count                                     NUMBER                                                      := 0;

l_ORIGIN_STATE                              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE              := NULL;
l_DESTINATION_STATE                         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE         := NULL;
l_SAIL_DAY_OF_WEEK                          HAEMO.XXHA_TRANSPORT_RATES_V.SAIL_DAY_OF_WEEK%TYPE          := NULL;
l_TOTAL_TRANSIT_DAYS_INLAND                 HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_INLAND%TYPE := NULL;
l_TOTAL_TRANSIT_DAYS_OCEAN                  HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_OCEAN%TYPE  := NULL;
l_TOTAL_COST                                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST%TYPE         := NULL;
l_TOTAL_COST_RND                            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE     := NULL;
l_TOTAL_COST_NUM                            HAEMO.XXHA_TRANSPORT_RATES_TBL.TOTAL_COST%TYPE              := NULL;
l_TOTAL_COST_ACCUM_NUM                      HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE     := NULL;

-- Cursor cur_0300
CURSOR cur_0300(
                P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE
              , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE
              , P_ORIGIN_COUNTRY            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_COUNTRY%TYPE
              , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE
              , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE
              , P_DESTINATION_COUNTRY       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_COUNTRY%TYPE
              , P_PROVIDER                  HAEMO.XXHA_TRANSPORT_RATES_V.PROVIDER%TYPE
              , P_SHIPPER_NAME              HAEMO.XXHA_TRANSPORT_RATES_V.SHIPPER_NAME%TYPE
              , P_COSIGNEE_NAME             HAEMO.XXHA_TRANSPORT_RATES_V.COSIGNEE_NAME%TYPE
              , P_LANE_ID                   HAEMO.XXHA_TRANSPORT_RATES_V.LANE_ID%TYPE
              , P_LANE_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_V.LANE_TYPE%TYPE
              , P_EQUIPMENT                 HAEMO.XXHA_TRANSPORT_RATES_V.EQUIPMENT%TYPE
              , P_ORIGIN_TYPE               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TYPE%TYPE
              , P_DATE                      HAEMO.XXHA_TRANSPORT_RATES_V.EFFECTIVE_START_DATE%TYPE
               )
IS
SELECT
    FCL.ORIGIN_STATE
  , FCL.DESTINATION_STATE
  , FCL.SAIL_DAY_OF_WEEK
  , FCL.TOTAL_TRANSIT_DAYS_INLAND
  , FCL.TOTAL_TRANSIT_DAYS_OCEAN
  , FCL.TOTAL_COST
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_V                FCL
WHERE
    FCL.TRANS_MODE                            = 'FCL'
AND UPPER(FCL.ORIGIN_CITY)                    = UPPER(P_ORIGIN_CITY)
AND NVL(UPPER(FCL.ORIGIN_STATE),'XXX')        = NVL(UPPER(P_ORIGIN_STATE),'XXX')
AND NVL(UPPER(FCL.ORIGIN_COUNTRY),'XXX')      = NVL(UPPER(P_ORIGIN_COUNTRY),'XXX')
AND UPPER(FCL.DESTINATION_CITY)               = UPPER(P_DESTINATION_CITY)
AND NVL(UPPER(FCL.DESTINATION_STATE),'XXX')   = NVL(UPPER(P_DESTINATION_STATE),'XXX')
AND NVL(UPPER(FCL.DESTINATION_COUNTRY),'XXX') = NVL(UPPER(P_DESTINATION_COUNTRY),'XXX')
AND FCL.PROVIDER                              = P_PROVIDER
AND FCL.SHIPPER_NAME                          = P_SHIPPER_NAME
AND FCL.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND NVL(FCL.LANE_ID, 'XXX')                   = NVL(P_LANE_ID, 'XXX')
AND NVL(FCL.LANE_TYPE,'XXX')                  = NVL(P_LANE_TYPE,'XXX')
AND NVL(FCL.EQUIPMENT,'XXX')                  = NVL(P_EQUIPMENT,'XXX')
AND NVL(FCL.ORIGIN_TYPE,'XXX')                = NVL(P_ORIGIN_TYPE,'XXX')
AND P_DATE BETWEEN TRUNC(fcl.Effective_Start_Date) AND NVL(TRUNC(fcl.Effective_End_Date), '01-JAN-4715')
;

-- Cursor cur_Count_FCL
CURSOR cur_Count_FCL(
                     P_SESSION_ID           HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SESSION_ID%TYPE
                   , P_TRANS_MODE           HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TRANS_MODE%TYPE
                   , P_PROVIDER             HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.PROVIDER%TYPE
                   , P_LANE_TYPE            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_TYPE%TYPE
                   , P_LANE_ID              HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_ID%TYPE
                   , P_EQUIPMENT            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.EQUIPMENT%TYPE
                   , P_SERVICE              HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SERVICE%TYPE
                   , P_ORIGIN_TYPE          HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_TYPE%TYPE
                   , P_SHIPPER_NAME         HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SHIPPER_NAME%TYPE
                   , P_ORIGIN_CITY          HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_CITY%TYPE
                   , P_ORIGIN_STATE         HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_STATE%TYPE
                   , P_COSIGNEE_NAME        HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.COSIGNEE_NAME%TYPE
                   , P_DESTINATION_CITY     HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_CITY%TYPE
                   , P_DESTINATION_STATE    HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_STATE%TYPE
                   , P_SAIL_DAY_OF_WEEK     HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SAIL_DAY_OF_WEEK%TYPE
                    )
IS
SELECT
    NVL(COUNT(*),0)
FROM
    HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL RATES
WHERE
    RATES.SESSION_ID                      = P_SESSION_ID
AND RATES.TRANS_MODE                      = P_TRANS_MODE
AND RATES.PROVIDER                        = P_PROVIDER
AND NVL(RATES.LANE_TYPE, 'XXX')           = NVL(P_LANE_TYPE, 'XXX') 
AND NVL(RATES.LANE_ID, 'XXX')             = NVL(P_LANE_ID, 'XXX') 
AND NVL(RATES.EQUIPMENT, 'XXX')           = NVL(P_EQUIPMENT, 'XXX') 
AND NVL(RATES.SERVICE, 'XXX')             = NVL(P_SERVICE, 'XXX') 
AND NVL(RATES.ORIGIN_TYPE, 'XXX')         = NVL(P_ORIGIN_TYPE,'XXX')
AND RATES.SHIPPER_NAME                    = P_SHIPPER_NAME
AND UPPER(RATES.ORIGIN_CITY)              = UPPER(P_ORIGIN_CITY)
AND NVL(RATES.ORIGIN_STATE, 'XXX')        = NVL(P_ORIGIN_STATE, 'XXX') 
AND RATES.COSIGNEE_NAME                   = P_COSIGNEE_NAME
AND UPPER(RATES.DESTINATION_CITY)         = UPPER(P_DESTINATION_CITY)
AND NVL(RATES.DESTINATION_STATE, 'XXX')   = NVL(P_DESTINATION_STATE, 'XXX') 
AND NVL(RATES.SAIL_DAY_OF_WEEK, 'XXX')    = NVL(P_SAIL_DAY_OF_WEEK, 'XXX') 
;

-- Cursor cur_Retrieve_FCL
CURSOR cur_Retrieve_FCL(
                        P_SESSION_ID        HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SESSION_ID%TYPE
                      , P_TRANS_MODE        HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TRANS_MODE%TYPE
                      , P_PROVIDER          HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.PROVIDER%TYPE
                      , P_LANE_TYPE         HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_TYPE%TYPE
                      , P_LANE_ID           HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_ID%TYPE
                      , P_EQUIPMENT         HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.EQUIPMENT%TYPE
                      , P_SERVICE           HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SERVICE%TYPE
                      , P_ORIGIN_TYPE       HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_TYPE%TYPE
                      , P_SHIPPER_NAME      HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SHIPPER_NAME%TYPE
                      , P_ORIGIN_CITY       HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_CITY%TYPE
                      , P_ORIGIN_STATE      HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_STATE%TYPE
                      , P_COSIGNEE_NAME     HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.COSIGNEE_NAME%TYPE
                      , P_DESTINATION_CITY  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_CITY%TYPE
                      , P_DESTINATION_STATE HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_STATE%TYPE
                      , P_SAIL_DAY_OF_WEEK  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SAIL_DAY_OF_WEEK%TYPE
                       )
IS
SELECT
    NVL(RATES.TOTAL_COST_NUM,0)
FROM
    HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL RATES
WHERE
    RATES.SESSION_ID                     = P_SESSION_ID
AND RATES.TRANS_MODE                     = P_TRANS_MODE
AND RATES.PROVIDER                       = P_PROVIDER
AND NVL(RATES.LANE_TYPE, 'XXX')          = NVL(P_LANE_TYPE, 'XXX') 
AND NVL(RATES.LANE_ID, 'XXX')            = NVL(P_LANE_ID, 'XXX') 
AND NVL(RATES.EQUIPMENT, 'XXX')          = NVL(P_EQUIPMENT, 'XXX') 
AND NVL(RATES.SERVICE, 'XXX')            = NVL(P_SERVICE, 'XXX') 
AND NVL(RATES.ORIGIN_TYPE, 'XXX')        = NVL(P_ORIGIN_TYPE,'XXX')
AND RATES.SHIPPER_NAME                   = P_SHIPPER_NAME
AND UPPER(RATES.ORIGIN_CITY)             = UPPER(P_ORIGIN_CITY)
AND NVL(RATES.ORIGIN_STATE, 'XXX')       = NVL(P_ORIGIN_STATE, 'XXX') 
AND RATES.COSIGNEE_NAME                  = P_COSIGNEE_NAME
AND UPPER(RATES.DESTINATION_CITY)        = UPPER(P_DESTINATION_CITY)
AND NVL(RATES.DESTINATION_STATE, 'XXX')  = NVL(P_DESTINATION_STATE, 'XXX') 
AND NVL(RATES.SAIL_DAY_OF_WEEK, 'XXX')   = NVL(P_SAIL_DAY_OF_WEEK, 'XXX') 
;

BEGIN

   -- Initialize Values
   l_ORIGIN_STATE               := NULL;
   l_DESTINATION_STATE          := NULL;
   l_SAIL_DAY_OF_WEEK           := NULL;
   l_TOTAL_TRANSIT_DAYS_INLAND  := NULL;
   l_TOTAL_TRANSIT_DAYS_OCEAN   := NULL;
   l_TOTAL_COST                 := NULL;
   l_TOTAL_COST_NUM             := 0;
   l_TOTAL_COST_RND             := 0;
   l_TOTAL_COST_ACCUM_NUM       := 0;
   l_Count                      := 0;

   -- Retrieve the data
   OPEN  cur_0300(P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY, P_PROVIDER, P_SHIPPER_NAME, P_COSIGNEE_NAME, P_LANE_ID, P_LANE_TYPE, P_EQUIPMENT, P_ORIGIN_TYPE, P_DATE_IN);
   FETCH cur_0300 INTO l_ORIGIN_STATE, l_DESTINATION_STATE, l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN, l_TOTAL_COST_NUM;
   CLOSE cur_0300;

   -- See if a record already exists in the table 'HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL'
   OPEN cur_Count_FCL(P_SESSION_ID, 'FCL', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME
              , UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE), l_SAIL_DAY_OF_WEEK);
   FETCH cur_Count_FCL INTO l_Count;
   CLOSE cur_Count_FCL;

   -- If no record exists then insert into HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL
   -- FCL (Full Container Load) is a single fee not dependent upong the Quantity being shipped
   IF NVL(l_count,0) = 0 THEN
      -- Round l_TOTAL_COST_NUM
      l_TOTAL_COST_RND := (ROUND(l_TOTAL_COST_NUM,0));
      -- Format l_TOTAL_COST_NUM from '123456789012' to '123,456,789,012'
      l_TOTAL_COST := TO_CHAR(l_TOTAL_COST_RND, '99,999,999,999,999,999,999,999');
      -- Write to table HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL for 'FCL'
      INSERT INTO HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL 
         (SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID, EQUIPMENT, SERVICE, ORIGIN_TYPE, SHIPPER_NAME, ORIGIN_CITY, ORIGIN_STATE, COSIGNEE_NAME, DESTINATION_CITY, DESTINATION_STATE, SAIL_DAY_OF_WEEK, TOTAL_TRANSIT_DAYS_INLAND, TOTAL_TRANSIT_DAYS_OCEAN, FLIGHTS_PER_WEEK, FLIGHT_FREQUENCY_NBR, TRANSIT_TIME_DAYS, TOTAL_COST, TOTAL_COST_NUM, CREATION_DATE)
      VALUES
         (P_SESSION_ID, 'FCL', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, UPPER(P_ORIGIN_CITY), UPPER(l_ORIGIN_STATE), P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(l_DESTINATION_STATE), l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN, NULL, NULL, NULL, l_TOTAL_COST, l_TOTAL_COST_RND, SYSDATE);
      COMMIT;
   END IF;

END XXHA_TRANS_FCL;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_LCL

PROCEDURE XXHA_TRANS_LCL (P_SESSION_ID                     IN NUMBER
                        , P_ORIGIN_CITY                    IN VARCHAR2
                        , P_ORIGIN_STATE                   IN VARCHAR2
                        , P_ORIGIN_COUNTRY                 IN VARCHAR2
                        , P_DESTINATION_CITY               IN VARCHAR2
                        , P_DESTINATION_STATE              IN VARCHAR2
                        , P_DESTINATION_COUNTRY            IN VARCHAR2
                        , P_PROVIDER                       IN VARCHAR2
                        , P_SHIPPER_NAME                   IN VARCHAR2
                        , P_COSIGNEE_NAME                  IN VARCHAR2
                        , P_LANE_ID                        IN VARCHAR2
                        , P_LANE_TYPE                      IN VARCHAR2
                        , P_EQUIPMENT                      IN VARCHAR2
                        , P_SERVICE                        IN VARCHAR2
                        , P_ORIGIN_TYPE                    IN VARCHAR2
                        , P_LENGTH_INCHES                  IN NUMBER
                        , P_WIDTH_INCHES                   IN NUMBER
                        , P_HEIGHT_INCHES                  IN NUMBER
                        , P_ACTUAL_WEIGHT_LBS              IN NUMBER
                        , P_QUANTITY_PALLETS               IN NUMBER
                        , P_STD_METRIC                     IN VARCHAR2
                        , P_DATE_IN                        IN DATE
                         ) IS

l_COUNT                                     NUMBER                                                      := 0;

l_SAIL_DAY_OF_WEEK                          HAEMO.XXHA_TRANSPORT_RATES_V.SAIL_DAY_OF_WEEK%TYPE          := NULL;
l_TOTAL_TRANSIT_DAYS_INLAND                 HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_INLAND%TYPE := NULL;
l_TOTAL_TRANSIT_DAYS_OCEAN                  HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_OCEAN%TYPE  := NULL;
l_TOTAL_COST                                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST%TYPE         := NULL;
l_TOTAL_COST_NUM                            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE     := NULL;

-- Cursor cur_0400
CURSOR cur_0400(
                P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE
              , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE
              , P_ORIGIN_COUNTRY            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_COUNTRY%TYPE
              , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE
              , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE
              , P_DESTINATION_COUNTRY       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_COUNTRY%TYPE
              , P_DATE                      HAEMO.XXHA_TRANSPORT_RATES_V.EFFECTIVE_START_DATE%TYPE
               )
IS
SELECT NVL(COUNT(*),0)
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_V                LCL
WHERE
    LCL.TRANS_MODE                            = 'LCL'
AND UPPER(LCL.ORIGIN_CITY)                    = UPPER(P_ORIGIN_CITY)
AND NVL(UPPER(LCL.ORIGIN_STATE),'XXX')        = NVL(UPPER(P_ORIGIN_STATE),'XXX')
AND NVL(UPPER(LCL.ORIGIN_COUNTRY),'XXX')      = NVL(UPPER(P_ORIGIN_COUNTRY),'XXX')
AND UPPER(LCL.DESTINATION_CITY)               = UPPER(P_DESTINATION_CITY)
AND NVL(UPPER(LCL.DESTINATION_STATE),'XXX')   = NVL(UPPER(P_DESTINATION_STATE),'XXX')
AND NVL(UPPER(LCL.DESTINATION_COUNTRY),'XXX') = NVL(UPPER(P_DESTINATION_COUNTRY),'XXX')
AND P_DATE BETWEEN TRUNC(LCL.Effective_Start_Date) AND NVL(TRUNC(LCL.Effective_End_Date), '01-JAN-4715')
;

BEGIN

   -- Retrieve the data
   OPEN  cur_0400(P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY, P_DATE_IN);
   FETCH cur_0400 INTO l_COUNT;
   CLOSE cur_0400;

   IF l_COUNT = 0 THEN
      l_TOTAL_COST     := '0';
      l_TOTAL_COST_NUM := 0;
   ELSE
      XXHA_TRANS_LCL_P(P_SESSION_ID, P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY
                     , P_PROVIDER, P_SHIPPER_NAME, P_COSIGNEE_NAME, P_LANE_ID
                     , P_LANE_TYPE, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE
                     , P_LENGTH_INCHES, P_WIDTH_INCHES, P_HEIGHT_INCHES
                     , P_ACTUAL_WEIGHT_LBS, P_QUANTITY_PALLETS, P_STD_METRIC, P_DATE_IN);
   END IF;

END XXHA_TRANS_LCL;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_LCL_P

PROCEDURE XXHA_TRANS_LCL_P (P_SESSION_ID                     IN NUMBER
                          , P_ORIGIN_CITY                    IN VARCHAR2
                          , P_ORIGIN_STATE                   IN VARCHAR2
                          , P_ORIGIN_COUNTRY                 IN VARCHAR2
                          , P_DESTINATION_CITY               IN VARCHAR2
                          , P_DESTINATION_STATE              IN VARCHAR2
                          , P_DESTINATION_COUNTRY            IN VARCHAR2
                          , P_PROVIDER                       IN VARCHAR2
                          , P_SHIPPER_NAME                   IN VARCHAR2
                          , P_COSIGNEE_NAME                  IN VARCHAR2
                          , P_LANE_ID                        IN VARCHAR2
                          , P_LANE_TYPE                      IN VARCHAR2
                          , P_EQUIPMENT                      IN VARCHAR2
                          , P_SERVICE                        IN VARCHAR2
                          , P_ORIGIN_TYPE                    IN VARCHAR2
                          , P_LENGTH_INCHES                  IN NUMBER
                          , P_WIDTH_INCHES                   IN NUMBER
                          , P_HEIGHT_INCHES                  IN NUMBER
                          , P_ACTUAL_WEIGHT_LBS              IN NUMBER
                          , P_QUANTITY_PALLETS               IN NUMBER
                          , P_STD_METRIC                     IN VARCHAR2
                          , P_DATE_IN                        IN DATE
                           ) IS

l_Count                           NUMBER       := 0;

l_ACTUAL_WEIGHT                   NUMBER(22,6) := 0;
l_LENGTH                          NUMBER(22,6) := 0;
l_WIDTH                           NUMBER(22,6) := 0;
l_HEIGHT                          NUMBER(22,6) := 0; 

P_ACTUAL_WGT_KGS                  NUMBER(22,6) := 0;
P_ACTUAL_WGT_KGS_REMAINDER        NUMBER(22,6) := 0;
P_ACTUAL_WGT_KGS_ROUND            NUMBER(22,0) := 0;
P_TOTAL_DIMENSIONS                NUMBER(22,2) := 0;
P_DIMENSION_WGT_KGS               NUMBER(22,6) := 0;
P_CUBIC_FEET                      NUMBER(22,8) := 0;
P_CUBIC_METERS                    NUMBER(22,8) := 0;
   
l_DOCUMENTATION_TOTAL             NUMBER(22,2) := 0;
l_TERM_HANDLING_FEE_MIN           NUMBER(22,2) := 0;
l_TRANS_MIN                       NUMBER(22,2) := 0;
l_TOTAL_MIN_CHARGE                NUMBER(22,2) := 0;
l_WM_CHARGE                       NUMBER(22,2) := 0;
l_CHARGE_BY_MEASURE               NUMBER(22,2) := 0;
l_CHARGE_BY_WEIGHT                NUMBER(22,2) := 0;

l_ORIGIN_CITY                     HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE                 := NULL;
l_ORIGIN_STATE                    HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE                := NULL;
l_DESTINATION_CITY                HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE            := NULL;
l_DESTINATION_STATE               HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE           := NULL;
l_PROVIDER                        HAEMO.XXHA_TRANSPORT_RATES_V.PROVIDER%TYPE                    := NULL;
l_LANE_TYPE                       HAEMO.XXHA_TRANSPORT_RATES_V.LANE_TYPE%TYPE                   := NULL;
l_SAIL_DAY_OF_WEEK                HAEMO.XXHA_TRANSPORT_RATES_V.SAIL_DAY_OF_WEEK%TYPE            := NULL;
l_TOTAL_TRANSIT_DAYS_INLAND       HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_INLAND%TYPE   := NULL;
l_TOTAL_TRANSIT_DAYS_OCEAN        HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_OCEAN%TYPE    := NULL;
l_TOTAL_COST                      HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST%TYPE           := NULL;

l_TOTAL_COST_NUM                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE       := 0;
l_TOTAL_COST_ACCUM_NUM            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE       := 0;
l_ORIGIN_PICKUP_MINIMUM           HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_PICKUP_MINIMUM%TYPE       := 0;
l_ORIGIN_INLAND_PER_WM            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_INLAND_PER_WM%TYPE        := 0;
l_ORIGIN_TERM_HANDLE_CHG_MIN      HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TERM_HANDLE_CHG_MIN%TYPE  := 0;
l_ORIGIN_TERM_HANDLE_CHG_WM       HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TERM_HANDLE_CHG_WM%TYPE   := 0;
l_ORIGIN_DOC_FEE                  HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_DOC_FEE%TYPE              := 0;
l_OCEAN_RATE_PER_MIN              HAEMO.XXHA_TRANSPORT_RATES_V.OCEAN_RATE_PER_MIN%TYPE          := 0;
l_OCEAN_RATE_PER_WM               HAEMO.XXHA_TRANSPORT_RATES_V.OCEAN_RATE_PER_WM%TYPE           := 0;
l_MINIMUM_AMT                     HAEMO.XXHA_TRANSPORT_RATES_V.MINIMUM_AMT%TYPE                 := 0;
l_OTHER_PER_WM                    HAEMO.XXHA_TRANSPORT_RATES_V.OTHER_PER_WM%TYPE                := 0;
l_OTHER_FLAT_FEE                  HAEMO.XXHA_TRANSPORT_RATES_V.OTHER_FLAT_FEE%TYPE              := 0;
l_DEST_DELIVERY_MIN               HAEMO.XXHA_TRANSPORT_RATES_V.DEST_DELIVERY_MIN%TYPE           := 0;
l_DEST_INLAND_PER_WM              HAEMO.XXHA_TRANSPORT_RATES_V.DEST_INLAND_PER_WM%TYPE          := 0;
l_DEST_TERM_HANDLE_CHG_MIN        HAEMO.XXHA_TRANSPORT_RATES_V.DEST_TERM_HANDLE_CHG_MIN%TYPE    := 0;
l_DEST_TERM_HANDLE_CHG_PER_WM     HAEMO.XXHA_TRANSPORT_RATES_V.DEST_TERM_HANDLE_CHG_PER_WM%TYPE := 0;
l_DEST_DOC_FEE                    HAEMO.XXHA_TRANSPORT_RATES_V.DEST_DOC_FEE%TYPE                := 0;

l_SESSION_ID                      HAEMO.XXHA_TRANSPORT_RATES_CALCS.SESSION_ID%TYPE              := NULL;
l_TRANS_MODE                      HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANS_MODE%TYPE              := NULL;
l_LANE_ID                         HAEMO.XXHA_TRANSPORT_RATES_CALCS.LANE_ID%TYPE                 := NULL;
l_EQUIPMENT                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.EQUIPMENT%TYPE               := NULL;
l_SERVICE                         HAEMO.XXHA_TRANSPORT_RATES_CALCS.SERVICE%TYPE                 := NULL;
l_ORIGIN_TYPE                     HAEMO.XXHA_TRANSPORT_RATES_CALCS.ORIGIN_TYPE%TYPE             := NULL;
l_SHIPPER_NAME                    HAEMO.XXHA_TRANSPORT_RATES_CALCS.SHIPPER_NAME%TYPE            := NULL;
l_COSIGNEE_NAME                   HAEMO.XXHA_TRANSPORT_RATES_CALCS.COSIGNEE_NAME%TYPE           := NULL;
l_FLIGHTS_PER_WEEK                HAEMO.XXHA_TRANSPORT_RATES_CALCS.FLIGHTS_PER_WEEK%TYPE        := NULL;
l_FLIGHT_FREQUENCY_NBR            HAEMO.XXHA_TRANSPORT_RATES_CALCS.FLIGHT_FREQUENCY_NBR%TYPE    := NULL;
l_TRANSIT_TIME_DAYS               HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANSIT_TIME_DAYS%TYPE       := NULL;
l_COLUMN_CR                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CR%TYPE               := 0;
l_COLUMN_CD                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CD%TYPE               := 0;
l_COLUMN_CO                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CO%TYPE               := 0;
l_COLUMN_CV                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CV%TYPE               := 0;
l_COLUMN_CW                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CW%TYPE               := 0;
l_COLUMN_CX                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CX%TYPE               := 0;
l_COLUMN_CY                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CY%TYPE               := 0;

-- Cursor cur_0500
CURSOR cur_0500(
                P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE
              , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE
              , P_ORIGIN_COUNTRY            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_COUNTRY%TYPE
              , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE
              , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE
              , P_DESTINATION_COUNTRY       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_COUNTRY%TYPE
              , P_PROVIDER                  HAEMO.XXHA_TRANSPORT_RATES_V.PROVIDER%TYPE
              , P_SHIPPER_NAME              HAEMO.XXHA_TRANSPORT_RATES_V.SHIPPER_NAME%TYPE
              , P_COSIGNEE_NAME             HAEMO.XXHA_TRANSPORT_RATES_V.COSIGNEE_NAME%TYPE
              , P_LANE_ID                   HAEMO.XXHA_TRANSPORT_RATES_V.LANE_ID%TYPE
              , P_LANE_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_V.LANE_TYPE%TYPE
              , P_EQUIPMENT                 HAEMO.XXHA_TRANSPORT_RATES_V.EQUIPMENT%TYPE
              , P_ORIGIN_TYPE               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TYPE%TYPE
              , P_DATE                      HAEMO.XXHA_TRANSPORT_RATES_V.EFFECTIVE_START_DATE%TYPE
               )
IS
SELECT 
    LCL.PROVIDER
  , LCL.LANE_TYPE
  , LCL.SAIL_DAY_OF_WEEK
  , LCL.TOTAL_TRANSIT_DAYS_INLAND
  , LCL.TOTAL_TRANSIT_DAYS_OCEAN
  , LCL.ORIGIN_PICKUP_MINIMUM
  , LCL.ORIGIN_INLAND_PER_WM
  , LCL.ORIGIN_TERM_HANDLE_CHG_MIN
  , LCL.ORIGIN_TERM_HANDLE_CHG_WM
  , LCL.ORIGIN_DOC_FEE
  , LCL.OCEAN_RATE_PER_MIN
  , LCL.OCEAN_RATE_PER_WM
  , LCL.MINIMUM_AMT
  , LCL.OTHER_PER_WM
  , LCL.OTHER_FLAT_FEE
  , LCL.DEST_DELIVERY_MIN
  , LCL.DEST_INLAND_PER_WM
  , LCL.DEST_TERM_HANDLE_CHG_MIN
  , LCL.DEST_TERM_HANDLE_CHG_PER_WM
  , LCL.DEST_DOC_FEE
  , LCL.ORIGIN_STATE
  , LCL.DESTINATION_STATE
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_V                LCL
WHERE
    LCL.TRANS_MODE                            = 'LCL'
AND UPPER(LCL.ORIGIN_CITY)                    = UPPER(P_ORIGIN_CITY)
AND NVL(UPPER(LCL.ORIGIN_STATE),'XXX')        = NVL(UPPER(P_ORIGIN_STATE),'XXX')
AND NVL(UPPER(LCL.ORIGIN_COUNTRY),'XXX')      = NVL(UPPER(P_ORIGIN_COUNTRY),'XXX')
AND UPPER(LCL.DESTINATION_CITY)               = UPPER(P_DESTINATION_CITY)
AND NVL(UPPER(LCL.DESTINATION_STATE),'XXX')   = NVL(UPPER(P_DESTINATION_STATE),'XXX')
AND NVL(UPPER(LCL.DESTINATION_COUNTRY),'XXX') = NVL(UPPER(P_DESTINATION_COUNTRY),'XXX')
AND LCL.PROVIDER                              = P_PROVIDER
AND LCL.SHIPPER_NAME                          = P_SHIPPER_NAME
AND LCL.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND LCL.LANE_ID                               = P_LANE_ID
AND NVL(LCL.LANE_TYPE,'XXX')                  = NVL(P_LANE_TYPE,'XXX')
AND NVL(LCL.EQUIPMENT,'XXX')                  = NVL(P_EQUIPMENT,'XXX')
AND NVL(LCL.ORIGIN_TYPE,'XXX')                = NVL(P_ORIGIN_TYPE,'XXX')
AND P_DATE BETWEEN TRUNC(LCL.Effective_Start_Date) AND NVL(TRUNC(LCL.Effective_End_Date), '01-JAN-4715')
;

-- Cursor cur_Count_LCL
CURSOR cur_Count_LCL(
                     P_SESSION_ID                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SESSION_ID%TYPE
                   , P_TRANS_MODE                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TRANS_MODE%TYPE
                   , P_PROVIDER                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.PROVIDER%TYPE
                   , P_LANE_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_TYPE%TYPE
                   , P_LANE_ID                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_ID%TYPE
                   , P_EQUIPMENT                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.EQUIPMENT%TYPE
                   , P_SERVICE                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SERVICE%TYPE
                   , P_ORIGIN_TYPE               HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_TYPE%TYPE
                   , P_SHIPPER_NAME              HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SHIPPER_NAME%TYPE
                   , P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_CITY%TYPE
                   , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_STATE%TYPE
                   , P_COSIGNEE_NAME             HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.COSIGNEE_NAME%TYPE
                   , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_CITY%TYPE
                   , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_STATE%TYPE
                    )
IS
SELECT
    NVL(COUNT(*),0)
FROM
    HAEMO.XXHA_TRANSPORT_RATES_CALCS RATES
WHERE
    RATES.SESSION_ID                            = P_SESSION_ID
AND RATES.TRANS_MODE                            = P_TRANS_MODE
AND RATES.PROVIDER                              = P_PROVIDER
AND NVL(RATES.LANE_TYPE, 'XXX')                 = NVL(P_LANE_TYPE, 'XXX') 
AND NVL(RATES.LANE_ID, 'XXX')                   = NVL(P_LANE_ID, 'XXX') 
AND NVL(RATES.EQUIPMENT, 'XXX')                 = NVL(P_EQUIPMENT, 'XXX') 
AND NVL(RATES.SERVICE, 'XXX')                   = NVL(P_SERVICE, 'XXX') 
AND RATES.ORIGIN_TYPE                           = P_ORIGIN_TYPE
AND RATES.SHIPPER_NAME                          = P_SHIPPER_NAME
AND RATES.ORIGIN_CITY                           = P_ORIGIN_CITY
AND NVL(RATES.ORIGIN_STATE, 'XXX')              = NVL(P_ORIGIN_STATE, 'XXX') 
AND RATES.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND RATES.DESTINATION_CITY                      = P_DESTINATION_CITY
AND NVL(RATES.DESTINATION_STATE, 'XXX')         = NVL(P_DESTINATION_STATE, 'XXX') 
;

-- Cursor cur_Retrieve_LCL
CURSOR cur_Retrieve_LCL(
                        P_SESSION_ID                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SESSION_ID%TYPE
                      , P_TRANS_MODE                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TRANS_MODE%TYPE
                      , P_PROVIDER                    HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.PROVIDER%TYPE
                      , P_LANE_TYPE                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_TYPE%TYPE
                      , P_LANE_ID                     HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_ID%TYPE
                      , P_EQUIPMENT                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.EQUIPMENT%TYPE
                      , P_SERVICE                     HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SERVICE%TYPE
                      , P_ORIGIN_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_TYPE%TYPE
                      , P_SHIPPER_NAME                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SHIPPER_NAME%TYPE
                      , P_ORIGIN_CITY                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_CITY%TYPE
                      , P_ORIGIN_STATE                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_STATE%TYPE
                      , P_COSIGNEE_NAME               HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.COSIGNEE_NAME%TYPE
                      , P_DESTINATION_CITY            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_CITY%TYPE
                      , P_DESTINATION_STATE           HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_STATE%TYPE
                       )
IS
SELECT
    SESSION_ID
  , TRANS_MODE
  , PROVIDER
  , LANE_TYPE
  , LANE_ID
  , ORIGIN_CITY
  , ORIGIN_STATE
  , DESTINATION_CITY
  , DESTINATION_STATE
  , EQUIPMENT
  , SERVICE
  , ORIGIN_TYPE
  , SHIPPER_NAME
  , COSIGNEE_NAME
  , SAIL_DAY_OF_WEEK
  , TOTAL_TRANSIT_DAYS_INLAND
  , TOTAL_TRANSIT_DAYS_OCEAN
  , FLIGHTS_PER_WEEK
  , FLIGHT_FREQUENCY_NBR
  , TRANSIT_TIME_DAYS
  , COLUMN_CR
  , COLUMN_CD
  , COLUMN_CO
  , COLUMN_CV
  , COLUMN_CW
  , COLUMN_CX
  , COLUMN_CY
FROM
    HAEMO.XXHA_TRANSPORT_RATES_CALCS RATES
WHERE
    RATES.SESSION_ID                            = P_SESSION_ID
AND RATES.TRANS_MODE                            = P_TRANS_MODE
AND RATES.PROVIDER                              = P_PROVIDER
AND NVL(RATES.LANE_TYPE, 'XXX')                 = NVL(P_LANE_TYPE, 'XXX') 
AND NVL(RATES.LANE_ID, 'XXX')                   = NVL(P_LANE_ID, 'XXX') 
AND NVL(RATES.EQUIPMENT, 'XXX')                 = NVL(P_EQUIPMENT, 'XXX') 
AND NVL(RATES.SERVICE, 'XXX')                   = NVL(P_SERVICE, 'XXX') 
AND RATES.ORIGIN_TYPE                           = P_ORIGIN_TYPE
AND RATES.SHIPPER_NAME                          = P_SHIPPER_NAME
AND RATES.ORIGIN_CITY                           = P_ORIGIN_CITY
AND NVL(RATES.ORIGIN_STATE, 'XXX')              = NVL(P_ORIGIN_STATE, 'XXX') 
AND RATES.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND RATES.DESTINATION_CITY                      = P_DESTINATION_CITY
AND NVL(RATES.DESTINATION_STATE, 'XXX')         = NVL(P_DESTINATION_STATE, 'XXX') 
;

BEGIN
   
   -- Retrieve the data
   OPEN  cur_0500(P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY, P_PROVIDER, P_SHIPPER_NAME, P_COSIGNEE_NAME, P_LANE_ID, P_LANE_TYPE, P_EQUIPMENT, P_ORIGIN_TYPE, P_DATE_IN);
   FETCH cur_0500 INTO 
                    l_PROVIDER
                  , l_LANE_TYPE
                  , l_SAIL_DAY_OF_WEEK
                  , l_TOTAL_TRANSIT_DAYS_INLAND
                  , l_TOTAL_TRANSIT_DAYS_OCEAN
                  , l_ORIGIN_PICKUP_MINIMUM
                  , l_ORIGIN_INLAND_PER_WM
                  , l_ORIGIN_TERM_HANDLE_CHG_MIN
                  , l_ORIGIN_TERM_HANDLE_CHG_WM
                  , l_ORIGIN_DOC_FEE
                  , l_OCEAN_RATE_PER_MIN
                  , l_OCEAN_RATE_PER_WM
                  , l_MINIMUM_AMT
                  , l_OTHER_PER_WM
                  , l_OTHER_FLAT_FEE
                  , l_DEST_DELIVERY_MIN
                  , l_DEST_INLAND_PER_WM
                  , l_DEST_TERM_HANDLE_CHG_MIN
                  , l_DEST_TERM_HANDLE_CHG_PER_WM
                  , l_DEST_DOC_FEE
                  , l_ORIGIN_STATE
                  , l_DESTINATION_STATE
                  ;

   l_ACTUAL_WEIGHT := P_ACTUAL_WEIGHT_LBS;

   -- If Metric data was sent, Convert to Std 
   IF P_STD_METRIC = 'M' THEN
      l_ACTUAL_WEIGHT := (P_ACTUAL_WEIGHT_LBS * 2.2046226);
   END IF;

   -- Calculate Total Actual Weight (KGs) - COLUMN CO
   P_ACTUAL_WGT_KGS              := ROUND((l_ACTUAL_WEIGHT / 2.2046226),6);
   P_ACTUAL_WGT_KGS_ROUND        := ROUND(P_ACTUAL_WGT_KGS,0);
   P_ACTUAL_WGT_KGS_REMAINDER    := (P_ACTUAL_WGT_KGS - P_ACTUAL_WGT_KGS_ROUND);
   -- If there is a remainder, roundup to next whole number
   IF P_ACTUAL_WGT_KGS_REMAINDER > 0 THEN
      P_ACTUAL_WGT_KGS := (P_ACTUAL_WGT_KGS_ROUND+1);
   ELSE
      P_ACTUAL_WGT_KGS := (P_ACTUAL_WGT_KGS_ROUND);
   END IF;

   l_LENGTH := (P_LENGTH_INCHES);
   l_WIDTH  := (P_WIDTH_INCHES);
   l_HEIGHT := (P_HEIGHT_INCHES);

   -- If Metric data was sent, Convert to Std 
   IF P_STD_METRIC = 'M' THEN
      l_LENGTH := (P_LENGTH_INCHES/2.54);
      l_WIDTH  := (P_WIDTH_INCHES/2.54);
      l_HEIGHT := (P_HEIGHT_INCHES/2.54);
   END IF;

   -- Calculate Total Dimension Weight (KGs) - COLUMN CP
   P_TOTAL_DIMENSIONS            := (l_LENGTH * l_WIDTH * l_HEIGHT);
   P_DIMENSION_WGT_KGS           := (P_TOTAL_DIMENSIONS / 366);

   -- Calculate Cubic Feet - COLUMN CQ
   P_CUBIC_FEET                  := ((l_LENGTH * l_WIDTH * l_HEIGHT)/1728) * P_QUANTITY_PALLETS;
   -- Calculate Cubic Feet - COLUMN CR
   P_CUBIC_METERS                := (P_CUBIC_FEET/35.314);

   -- Calculate Values
   l_DOCUMENTATION_TOTAL         := (l_DEST_DOC_FEE+l_ORIGIN_DOC_FEE);
   l_TERM_HANDLING_FEE_MIN       := (l_DEST_TERM_HANDLE_CHG_MIN + l_ORIGIN_TERM_HANDLE_CHG_MIN);
   l_TRANS_MIN                   := (l_DEST_DELIVERY_MIN + l_OCEAN_RATE_PER_MIN + l_ORIGIN_PICKUP_MINIMUM);
   l_TOTAL_MIN_CHARGE            := (l_TRANS_MIN + l_TERM_HANDLING_FEE_MIN + l_DOCUMENTATION_TOTAL + l_OTHER_FLAT_FEE);
   l_WM_CHARGE                   := (l_DEST_TERM_HANDLE_CHG_PER_WM + l_DEST_INLAND_PER_WM + l_OCEAN_RATE_PER_WM + l_ORIGIN_TERM_HANDLE_CHG_WM + l_ORIGIN_INLAND_PER_WM);
   l_CHARGE_BY_MEASURE           := ((l_WM_CHARGE*P_CUBIC_METERS) + l_OTHER_FLAT_FEE);
   l_CHARGE_BY_WEIGHT            := (((l_WM_CHARGE/1000)*(P_ACTUAL_WGT_KGS*P_QUANTITY_PALLETS)) + l_OTHER_FLAT_FEE);
   l_TOTAL_COST_NUM              := ROUND(GREATEST(l_CHARGE_BY_WEIGHT, l_CHARGE_BY_MEASURE, l_TOTAL_MIN_CHARGE),0);

   -- Initialize Values
   l_SAIL_DAY_OF_WEEK            := NULL;
   l_TOTAL_TRANSIT_DAYS_INLAND   := NULL;
   l_TOTAL_TRANSIT_DAYS_OCEAN    := NULL;
   l_TOTAL_COST                  := NULL;
   l_TOTAL_COST_ACCUM_NUM        := 0;
   l_Count                       := 0;

   -- See if a record already exists in the table 'HAEMO.XXHA_TRANSPORT_RATES_CALCS'
   OPEN cur_Count_LCL(P_SESSION_ID, 'LCL', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), 
                      P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE));
   FETCH cur_Count_LCL INTO l_Count;
   CLOSE cur_Count_LCL;

   -- If a record exists, accumulate the data
   IF NVL(l_count,0) > 0 THEN

      -- Retrieve data from existing record
      OPEN cur_Retrieve_LCL(P_SESSION_ID, 'LCL', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), 
                            P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE));
      FETCH cur_Retrieve_LCL INTO 
       l_SESSION_ID, l_TRANS_MODE, l_PROVIDER, l_LANE_TYPE, l_LANE_ID, l_ORIGIN_CITY, l_ORIGIN_STATE, l_DESTINATION_CITY, l_DESTINATION_STATE, l_EQUIPMENT
      ,l_SERVICE, l_ORIGIN_TYPE, l_SHIPPER_NAME, l_COSIGNEE_NAME, l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN, l_FLIGHTS_PER_WEEK, l_FLIGHT_FREQUENCY_NBR
      ,l_TRANSIT_TIME_DAYS, l_COLUMN_CR, l_COLUMN_CD, l_COLUMN_CO, l_COLUMN_CV, l_COLUMN_CW, l_COLUMN_CX, l_COLUMN_CY;
      CLOSE cur_Retrieve_LCL;

      -- Update existing record
      UPDATE HAEMO.XXHA_TRANSPORT_RATES_CALCS TEMP
      SET
          TEMP.COLUMN_CR = (l_COLUMN_CR + P_CUBIC_METERS)                                                                 -- Accumulated total of Cubic Meters for all records
        , TEMP.COLUMN_CD = l_COLUMN_CD                                                                                    -- First records Other flat fee
        , TEMP.COLUMN_CO = (l_COLUMN_CO + (P_ACTUAL_WGT_KGS * P_QUANTITY_PALLETS))                                        -- Accumulated total of all records Actual Weight (KGs) -- here
        , TEMP.COLUMN_CV = l_COLUMN_CV                                                                                    -- First records Total Min Charge
        , TEMP.COLUMN_CW = l_COLUMN_CW                                                                                    -- First record's W/M Charge
        , TEMP.COLUMN_CY = (((l_COLUMN_CW / 1000) * (l_COLUMN_CO + (P_ACTUAL_WGT_KGS*P_QUANTITY_PALLETS))) + l_COLUMN_CD) -- Charge By Weight ((CW/1000*CO)+CD)
        , TEMP.COLUMN_CX = ((l_COLUMN_CW * (l_COLUMN_CR + P_CUBIC_METERS)) + l_COLUMN_CD)                                 -- Charge by Measure (CW*CR)+CD
      WHERE
          TEMP.SESSION_ID                             = P_SESSION_ID
      AND TEMP.TRANS_MODE                             = 'LCL'
      AND TEMP.PROVIDER                               = P_PROVIDER
      AND NVL(TEMP.LANE_TYPE, 'XXX')                  = NVL(P_LANE_TYPE, 'XXX')
      AND NVL(TEMP.LANE_ID, 'XXX')                    = NVL(P_LANE_ID, 'XXX')
      AND NVL(TEMP.EQUIPMENT, 'XXX')                  = NVL(P_EQUIPMENT, 'XXX')
      AND NVL(TEMP.SERVICE, 'XXX')                    = NVL(P_SERVICE, 'XXX')
      AND TEMP.ORIGIN_TYPE                            = P_ORIGIN_TYPE
      AND TEMP.SHIPPER_NAME                           = P_SHIPPER_NAME
      AND TEMP.ORIGIN_CITY                            = UPPER(P_ORIGIN_CITY)
      AND NVL(TEMP.ORIGIN_STATE, 'XXX')               = NVL(UPPER(P_ORIGIN_STATE), 'XXX')
      AND TEMP.COSIGNEE_NAME                          = P_COSIGNEE_NAME
      AND TEMP.DESTINATION_CITY                       = UPPER(P_DESTINATION_CITY)
      AND NVL(TEMP.DESTINATION_STATE, 'XXX')          = NVL(UPPER(P_DESTINATION_STATE), 'XXX');
      COMMIT;
   ELSE
      -- Create Record in XXHA_TRANSPORT_RATES_CALCS
      INSERT INTO HAEMO.XXHA_TRANSPORT_RATES_CALCS
         (SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID, ORIGIN_CITY, ORIGIN_STATE, ORIGIN_COUNTRY
        , EQUIPMENT, SERVICE, ORIGIN_TYPE, SHIPPER_NAME, COSIGNEE_NAME, SAIL_DAY_OF_WEEK, TOTAL_TRANSIT_DAYS_INLAND, TOTAL_TRANSIT_DAYS_OCEAN
        , FLIGHTS_PER_WEEK, FLIGHT_FREQUENCY_NBR, TRANSIT_TIME_DAYS, DESTINATION_CITY, DESTINATION_STATE, DESTINATION_COUNTRY
        , COLUMN_CR, COLUMN_CD, COLUMN_CO, COLUMN_CV, COLUMN_CW, COLUMN_CX, COLUMN_CY, CREATION_DATE
         )
      VALUES
         (P_SESSION_ID, 'LCL', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), UPPER(P_ORIGIN_COUNTRY)
        , P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, P_COSIGNEE_NAME, l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN
        , NULL, NULL, NULL, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE), UPPER(P_DESTINATION_COUNTRY)
        , P_CUBIC_METERS, l_OTHER_FLAT_FEE, (P_ACTUAL_WGT_KGS * P_QUANTITY_PALLETS), l_TOTAL_MIN_CHARGE, l_WM_CHARGE, ((l_WM_CHARGE * P_CUBIC_METERS) + l_OTHER_FLAT_FEE), ((l_WM_CHARGE/1000 * (P_ACTUAL_WGT_KGS * P_QUANTITY_PALLETS)) + l_OTHER_FLAT_FEE), SYSDATE
         );
      COMMIT;
   END IF;

   -- Format l_TOTAL_COST_NUM from '123456789012' to '123,456,789,012'
   l_TOTAL_COST := TO_CHAR(l_TOTAL_COST_NUM, '99,999,999,999,999,999,999,999');

   -- Write to table HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL for 'LCL'
   INSERT INTO HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL 
      (SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID, EQUIPMENT, SERVICE, ORIGIN_TYPE, SHIPPER_NAME, ORIGIN_CITY, ORIGIN_STATE, COSIGNEE_NAME, DESTINATION_CITY, DESTINATION_STATE, SAIL_DAY_OF_WEEK, TOTAL_TRANSIT_DAYS_INLAND, TOTAL_TRANSIT_DAYS_OCEAN, FLIGHTS_PER_WEEK, FLIGHT_FREQUENCY_NBR, TRANSIT_TIME_DAYS, TOTAL_COST, TOTAL_COST_NUM, CREATION_DATE)
   VALUES
      (P_SESSION_ID, 'LCL', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), 
       P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE), l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN, NULL, NULL, NULL, l_TOTAL_COST, l_TOTAL_COST_NUM, SYSDATE);
   COMMIT;

   CLOSE cur_0500;

END XXHA_TRANS_LCL_P;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_AIR

PROCEDURE XXHA_TRANS_AIR (P_SESSION_ID                     IN NUMBER
                        , P_ORIGIN_CITY                    IN VARCHAR2
                        , P_ORIGIN_STATE                   IN VARCHAR2
                        , P_ORIGIN_COUNTRY                 IN VARCHAR2
                        , P_DESTINATION_CITY               IN VARCHAR2
                        , P_DESTINATION_STATE              IN VARCHAR2
                        , P_DESTINATION_COUNTRY            IN VARCHAR2
                        , P_PROVIDER                       IN VARCHAR2
                        , P_SHIPPER_NAME                   IN VARCHAR2
                        , P_COSIGNEE_NAME                  IN VARCHAR2
                        , P_LANE_ID                        IN VARCHAR2
                        , P_LANE_TYPE                      IN VARCHAR2
                        , P_EQUIPMENT                      IN VARCHAR2
                        , P_SERVICE                        IN VARCHAR2
                        , P_ORIGIN_TYPE                    IN VARCHAR2
                        , P_LENGTH_INCHES                  IN NUMBER
                        , P_WIDTH_INCHES                   IN NUMBER
                        , P_HEIGHT_INCHES                  IN NUMBER
                        , P_ACTUAL_WEIGHT_LBS              IN NUMBER
                        , P_QUANTITY_PALLETS               IN NUMBER
                        , P_STD_METRIC                     IN VARCHAR2
                        , P_DATE_IN                        IN DATE
                        , P_Count                          NUMBER
                         ) IS

l_COUNT                                     NUMBER := 0;

l_FLIGHTS_PER_WEEK                          HAEMO.XXHA_TRANSPORT_RATES_V.FLIGHTS_PER_WEEK%TYPE      := NULL;
l_FLIGHT_FREQUENCY_NBR                      HAEMO.XXHA_TRANSPORT_RATES_V.FLIGHT_FREQUENCY_NBR%TYPE  := NULL;
l_TRANSIT_TIME_DAYS                         HAEMO.XXHA_TRANSPORT_RATES_V.TRANSIT_TIME_DAYS%TYPE     := NULL;
l_TOTAL_COST                                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST%TYPE     := NULL;
l_TOTAL_COST_NUM                            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE := 0;
l_TOTAL_COST_ACCUM_NUM                      HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE := 0;

-- Cursor cur_0600
CURSOR cur_0600(
                P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE
              , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE
              , P_ORIGIN_COUNTRY            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_COUNTRY%TYPE
              , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE
              , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE
              , P_DESTINATION_COUNTRY       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_COUNTRY%TYPE
              , P_DATE                      HAEMO.XXHA_TRANSPORT_RATES_V.EFFECTIVE_START_DATE%TYPE
               )
IS
SELECT NVL(COUNT(*),0)
FROM
    HAEMO.XXHA_TRANSPORT_RATES_V                AIR
WHERE
    AIR.TRANS_MODE                            = 'AIR'
AND UPPER(AIR.ORIGIN_CITY)                    = UPPER(P_ORIGIN_CITY)
AND NVL(UPPER(AIR.ORIGIN_STATE),'XXX')        = NVL(UPPER(P_ORIGIN_STATE),'XXX')
AND NVL(UPPER(AIR.ORIGIN_COUNTRY),'XXX')      = NVL(UPPER(P_ORIGIN_COUNTRY),'XXX')
AND UPPER(AIR.DESTINATION_CITY)               = UPPER(P_DESTINATION_CITY)
AND NVL(UPPER(AIR.DESTINATION_STATE),'XXX')   = NVL(UPPER(P_DESTINATION_STATE),'XXX')
AND NVL(UPPER(AIR.DESTINATION_COUNTRY),'XXX') = NVL(UPPER(P_DESTINATION_COUNTRY),'XXX')
AND P_DATE BETWEEN TRUNC(AIR.Effective_Start_Date) AND NVL(TRUNC(AIR.Effective_End_Date), '01-JAN-4715')
;

BEGIN

   -- Retrieve the data
   OPEN  cur_0600(P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY, P_DATE_IN);
   FETCH cur_0600 INTO l_COUNT;
   CLOSE cur_0600;

   IF l_COUNT = 0 THEN
      l_TOTAL_COST     := '0';
      l_TOTAL_COST_NUM := 0;
   ELSE
      XXHA_TRANS_AIR_P(P_SESSION_ID, P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY
                     , P_PROVIDER, P_SHIPPER_NAME, P_COSIGNEE_NAME, P_LANE_ID
                     , P_LANE_TYPE, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE
                     , P_LENGTH_INCHES, P_WIDTH_INCHES, P_HEIGHT_INCHES
                     , P_ACTUAL_WEIGHT_LBS, P_QUANTITY_PALLETS, P_STD_METRIC, P_DATE_IN, P_Count);
   END IF;

END XXHA_TRANS_AIR;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_AIR_P

PROCEDURE XXHA_TRANS_AIR_P (P_SESSION_ID                   IN NUMBER
                          , P_ORIGIN_CITY                  IN VARCHAR2
                          , P_ORIGIN_STATE                 IN VARCHAR2
                          , P_ORIGIN_COUNTRY               IN VARCHAR2
                          , P_DESTINATION_CITY             IN VARCHAR2
                          , P_DESTINATION_STATE            IN VARCHAR2
                          , P_DESTINATION_COUNTRY          IN VARCHAR2
                          , P_PROVIDER                     IN VARCHAR2
                          , P_SHIPPER_NAME                 IN VARCHAR2
                          , P_COSIGNEE_NAME                IN VARCHAR2
                          , P_LANE_ID                      IN VARCHAR2
                          , P_LANE_TYPE                    IN VARCHAR2
                          , P_EQUIPMENT                    IN VARCHAR2
                          , P_SERVICE                      IN VARCHAR2
                          , P_ORIGIN_TYPE                  IN VARCHAR2
                          , P_LENGTH_INCHES                IN NUMBER
                          , P_WIDTH_INCHES                 IN NUMBER
                          , P_HEIGHT_INCHES                IN NUMBER
                          , P_ACTUAL_WEIGHT_LBS            IN NUMBER
                          , P_QUANTITY_PALLETS             IN NUMBER
                          , P_STD_METRIC                   IN VARCHAR2
                          , P_DATE_IN                      IN DATE
                          , P_COUNT                        NUMBER
                           ) IS

l_Count                           NUMBER       := 0;

l_ACTUAL_WEIGHT                   NUMBER(22,6) := 0;
l_LENGTH                          NUMBER(22,6) := 0;
l_WIDTH                           NUMBER(22,6) := 0;
l_HEIGHT                          NUMBER(22,6) := 0; 

P_ACTUAL_WGT_KGS                  NUMBER(22,6) := 0;
P_ACTUAL_WGT_KGS_REMAINDER        NUMBER(22,6) := 0;
P_ACTUAL_WGT_KGS_ROUND            NUMBER(22,0) := 0;
P_SHIPMENT_WGT_KGS                NUMBER(22,6) := 0;
P_TOTAL_DIMENSIONS                NUMBER(22,2) := 0;
P_DIMENSION_WGT_KGS               NUMBER(22,6) := 0;
P_AIR_FRT_BASED_ON_WGT_KGS        NUMBER(22,6) := 0;

l_TOTAL_ORIG_DEST_FEES_MIN        NUMBER(22,6) := 0;
l_TOTAL_ORIG_DEST_FEES_KG         NUMBER(22,6) := 0;
l_ORIG_DEST_FEES_AT_WGT           NUMBER(22,6) := 0;
l_AIR_FRT_BASED_ON_WGT_KGS        NUMBER(22,6) := 0;
l_FSC_AND_SECURITY_TOTAL          NUMBER(22,6) := 0;
l_CHG_BASED_ON_ALL_MIN_CHGS       NUMBER(22,6) := 0;
l_TOTAL_CHARGE_BASED_ON_KG        NUMBER(22,6) := 0;

l_TRANS_MODE                      HAEMO.XXHA_TRANSPORT_RATES_V.TRANS_MODE%TYPE                   := NULL;
l_PROVIDER                        HAEMO.XXHA_TRANSPORT_RATES_V.PROVIDER%TYPE                     := NULL;
l_LANE_TYPE                       HAEMO.XXHA_TRANSPORT_RATES_V.LANE_TYPE%TYPE                    := NULL;
l_LANE_ID                         HAEMO.XXHA_TRANSPORT_RATES_V.LANE_ID%TYPE                      := NULL;
l_LANE_REFERENCE                  HAEMO.XXHA_TRANSPORT_RATES_V.LANE_REFERENCE%TYPE               := NULL;
l_EQUIPMENT                       HAEMO.XXHA_TRANSPORT_RATES_V.EQUIPMENT%TYPE                    := NULL;
l_LANE_TYPE_MAJOR_LANE            HAEMO.XXHA_TRANSPORT_RATES_V.LANE_TYPE_MAJOR_LANE%TYPE         := NULL;
l_SERVICE                         HAEMO.XXHA_TRANSPORT_RATES_V.SERVICE%TYPE                      := NULL;
l_ORIGIN_TYPE                     HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TYPE%TYPE                  := NULL;
l_SHIPPER_NAME                    HAEMO.XXHA_TRANSPORT_RATES_V.SHIPPER_NAME%TYPE                 := NULL;
l_ORIGIN_CITY                     HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE                  := NULL;
l_ORIGIN_STATE                    HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE                 := NULL;
l_COSIGNEE_NAME                   HAEMO.XXHA_TRANSPORT_RATES_V.COSIGNEE_NAME%TYPE                := NULL;
l_DESTINATION_CITY                HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE             := NULL;
l_DESTINATION_STATE               HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE            := NULL;
l_SAIL_DAY_OF_WEEK                HAEMO.XXHA_TRANSPORT_RATES_V.SAIL_DAY_OF_WEEK%TYPE             := NULL;
l_TOTAL_TRANSIT_DAYS_INLAND       HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_INLAND%TYPE    := NULL;
l_TOTAL_TRANSIT_DAYS_OCEAN        HAEMO.XXHA_TRANSPORT_RATES_V.TOTAL_TRANSIT_DAYS_OCEAN%TYPE     := NULL;
l_ORIGIN_INLAND_MIN               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_INLAND_MIN%TYPE            := 0;
l_ORIGIN_INLAND_PER_KG            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_INLAND_PER_KG%TYPE         := 0;
l_ORIGIN_HANDLING_MIN             HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_HANDLING_MIN%TYPE          := 0;
l_ORIGIN_HANDLING_PER_KG          HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_HANDLING_PER_KG%TYPE       := 0;
l_ORIGIN_TERMINAL_MIN             HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TERMINAL_MIN%TYPE          := 0;
l_ORIGIN_TERMINAL_PER_KG          HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TERMINAL_PER_KG%TYPE       := 0;
l_ORIGIN_DOC_FEE_MIN              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_DOC_FEE_MIN%TYPE           := 0;
l_ORIGIN_DOC_FEE_PER_KG           HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_DOC_FEE_PER_KG%TYPE        := 0;
l_ORIGIN_OTHER_MIN                HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_OTHER_MIN%TYPE             := 0;
l_ORIGIN_OTHER_PER_KG             HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_OTHER_PER_KG%TYPE          := 0;
l_AIR_FREIGHT_MIN_KG              HAEMO.XXHA_TRANSPORT_RATES_V.AIR_FREIGHT_MIN_KG%TYPE           := 0;
l_KG_LE_45                        HAEMO.XXHA_TRANSPORT_RATES_V.KG_LE_45%TYPE                     := 0;
l_KG_GT_45                        HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_45%TYPE                     := 0;
l_KG_GT_100                       HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_100%TYPE                    := 0;
l_KG_GT_300                       HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_300%TYPE                    := 0;
l_KG_GT_500                       HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_500%TYPE                    := 0;
l_KG_GT_1000                      HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_1000%TYPE                   := 0;
l_KG_GT_2000                      HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_2000%TYPE                   := 0;
l_KG_GT_5000                      HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_5000%TYPE                   := 0;
l_KG_GT_10000                     HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_10000%TYPE                  := 0;
l_FUEL_SURCHARGE_PER_KG           HAEMO.XXHA_TRANSPORT_RATES_V.FUEL_SURCHARGE_PER_KG%TYPE        := 0;
l_SECURITY_SURCHARGE_PER_KG       HAEMO.XXHA_TRANSPORT_RATES_V.SECURITY_SURCHARGE_PER_KG%TYPE    := 0;
l_DESTINATION_INLAND_MIN          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_INLAND_MIN%TYPE       := 0;
l_DESTINATION_INLAND_PER_KG       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_INLAND_PER_KG%TYPE    := 0;
l_DESTINATION_HANDLING_MIN        HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_HANDLING_MIN%TYPE     := 0;
l_DESTINATION_HANDLING_PER_KG     HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_HANDLING_PER_KG%TYPE  := 0;
l_DESTINATION_TERMINAL_MIN        HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_TERMINAL_MIN%TYPE     := 0;
l_DESTINATION_TERMINAL_PER_KG     HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_TERMINAL_PER_KG%TYPE  := 0;
l_DESTINATION_DOC_FEE_MIN         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_DOC_FEE_MIN%TYPE      := 0;
l_DESTINATION_DOC_FEE_PER_KG      HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_DOC_FEE_PER_KG%TYPE   := 0;
l_DESTINATION_OTHER_MIN           HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_OTHER_MIN%TYPE        := 0;
l_DESTINATION_OTHER_PER_KG        HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_OTHER_PER_KG%TYPE     := 0;
l_FLIGHTS_PER_WEEK                HAEMO.XXHA_TRANSPORT_RATES_V.FLIGHTS_PER_WEEK%TYPE             := NULL;
l_FLIGHT_FREQUENCY_NBR            HAEMO.XXHA_TRANSPORT_RATES_V.FLIGHT_FREQUENCY_NBR%TYPE         := NULL;
l_TRANSIT_TIME_DAYS               HAEMO.XXHA_TRANSPORT_RATES_V.TRANSIT_TIME_DAYS%TYPE            := NULL;
l_TOTAL_COST                      HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST%TYPE            := NULL;
l_TOTAL_COST_NUM                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE        := 0;

l_SESSION_ID                      HAEMO.XXHA_TRANSPORT_RATES_CALCS.SESSION_ID%TYPE               := 0;
l_COLUMN_CR                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CR%TYPE                := 0;
l_COLUMN_CD                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CD%TYPE                := 0;
l_COLUMN_CO                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CO%TYPE                := 0;
l_COLUMN_CV                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CV%TYPE                := 0;
l_COLUMN_CW                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CW%TYPE                := 0;
l_COLUMN_CX                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CX%TYPE                := 0;
l_COLUMN_CY                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CY%TYPE                := 0;
l_COLUMN_CS                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CS%TYPE                := 0;
l_COLUMN_CT                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CT%TYPE                := 0;
l_COLUMN_DO                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_DO%TYPE                := 0;
l_COLUMN_DP                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_DP%TYPE                := 0;
l_COLUMN_EB                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EB%TYPE                := 0;
l_COLUMN_EC                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EC%TYPE                := 0;
l_COLUMN_EE                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EE%TYPE                := 0;

-- Cursor cur_0700
CURSOR cur_0700(
                P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE
              , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE
              , P_ORIGIN_COUNTRY            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_COUNTRY%TYPE
              , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE
              , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE
              , P_DESTINATION_COUNTRY       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_COUNTRY%TYPE
              , P_PROVIDER                  HAEMO.XXHA_TRANSPORT_RATES_V.PROVIDER%TYPE
              , P_SHIPPER_NAME              HAEMO.XXHA_TRANSPORT_RATES_V.SHIPPER_NAME%TYPE
              , P_COSIGNEE_NAME             HAEMO.XXHA_TRANSPORT_RATES_V.COSIGNEE_NAME%TYPE
              , P_LANE_ID                   HAEMO.XXHA_TRANSPORT_RATES_V.LANE_ID%TYPE
              , P_LANE_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_V.LANE_TYPE%TYPE
              , P_EQUIPMENT                 HAEMO.XXHA_TRANSPORT_RATES_V.EQUIPMENT%TYPE
              , P_ORIGIN_TYPE               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TYPE%TYPE
              , P_DATE                      HAEMO.XXHA_TRANSPORT_RATES_V.EFFECTIVE_START_DATE%TYPE
              )
IS
SELECT
    AIR.PROVIDER
  , AIR.LANE_TYPE
  , AIR.LANE_TYPE_MAJOR_LANE
  , AIR.LANE_ID
  , AIR.LANE_REFERENCE
  , AIR.TRANS_MODE
  , AIR.SERVICE
  , AIR.ORIGIN_TYPE
  , AIR.SHIPPER_NAME
  , AIR.ORIGIN_CITY
  , AIR.ORIGIN_STATE
  , AIR.DESTINATION_CITY
  , AIR.DESTINATION_STATE
  , AIR.ORIGIN_INLAND_MIN
  , AIR.ORIGIN_INLAND_PER_KG
  , AIR.ORIGIN_HANDLING_MIN
  , AIR.ORIGIN_HANDLING_PER_KG
  , AIR.ORIGIN_TERMINAL_MIN
  , AIR.ORIGIN_TERMINAL_PER_KG
  , AIR.ORIGIN_DOC_FEE_MIN
  , AIR.ORIGIN_DOC_FEE_PER_KG
  , AIR.ORIGIN_OTHER_MIN
  , AIR.ORIGIN_OTHER_PER_KG
  , AIR.AIR_FREIGHT_MIN_KG
  , AIR.KG_LE_45
  , AIR.KG_GT_45
  , AIR.KG_GT_100
  , AIR.KG_GT_300
  , AIR.KG_GT_500
  , AIR.KG_GT_1000
  , AIR.KG_GT_2000
  , AIR.KG_GT_5000
  , AIR.KG_GT_10000
  , AIR.FUEL_SURCHARGE_PER_KG
  , AIR.SECURITY_SURCHARGE_PER_KG
  , AIR.DESTINATION_INLAND_MIN
  , AIR.DESTINATION_INLAND_PER_KG
  , AIR.DESTINATION_HANDLING_MIN
  , AIR.DESTINATION_HANDLING_PER_KG
  , AIR.DESTINATION_TERMINAL_MIN
  , AIR.DESTINATION_TERMINAL_PER_KG
  , AIR.DESTINATION_DOC_FEE_MIN
  , AIR.DESTINATION_DOC_FEE_PER_KG
  , AIR.DESTINATION_OTHER_MIN
  , AIR.DESTINATION_OTHER_PER_KG
  , AIR.FLIGHTS_PER_WEEK
  , AIR.FLIGHT_FREQUENCY_NBR
  , AIR.TRANSIT_TIME_DAYS
FROM 
     HAEMO.XXHA_TRANSPORT_RATES_V               AIR
WHERE
    AIR.TRANS_MODE                            = 'AIR'
AND UPPER(AIR.ORIGIN_CITY)                    = UPPER(P_ORIGIN_CITY)
AND NVL(UPPER(AIR.ORIGIN_STATE),'XXX')        = NVL(UPPER(P_ORIGIN_STATE),'XXX')
AND NVL(UPPER(AIR.ORIGIN_COUNTRY),'XXX')      = NVL(UPPER(P_ORIGIN_COUNTRY),'XXX')
AND UPPER(AIR.DESTINATION_CITY)               = UPPER(P_DESTINATION_CITY)
AND NVL(UPPER(AIR.DESTINATION_STATE),'XXX')   = NVL(UPPER(P_DESTINATION_STATE),'XXX')
AND NVL(UPPER(AIR.DESTINATION_COUNTRY),'XXX') = NVL(UPPER(P_DESTINATION_COUNTRY),'XXX')
AND AIR.PROVIDER                              = P_PROVIDER
AND AIR.SHIPPER_NAME                          = P_SHIPPER_NAME
AND AIR.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND AIR.LANE_ID                               = P_LANE_ID
AND NVL(AIR.LANE_TYPE,'XXX')                  = NVL(P_LANE_TYPE,'XXX')
AND NVL(AIR.EQUIPMENT,'XXX')                  = NVL(P_EQUIPMENT,'XXX')
AND NVL(AIR.ORIGIN_TYPE,'XXX')                = NVL(P_ORIGIN_TYPE,'XXX')
AND P_DATE BETWEEN TRUNC(AIR.Effective_Start_Date) AND NVL(TRUNC(AIR.Effective_End_Date), '01-JAN-4715')
;

-- Cursor cur_Count_AIR
CURSOR cur_Count_AIR(
                     P_SESSION_ID                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SESSION_ID%TYPE
                   , P_TRANS_MODE                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TRANS_MODE%TYPE
                   , P_PROVIDER                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.PROVIDER%TYPE
                   , P_LANE_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_TYPE%TYPE
                   , P_LANE_ID                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_ID%TYPE
                   , P_EQUIPMENT                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.EQUIPMENT%TYPE
                   , P_SERVICE                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SERVICE%TYPE
                   , P_ORIGIN_TYPE               HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_TYPE%TYPE
                   , P_SHIPPER_NAME              HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SHIPPER_NAME%TYPE
                   , P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_CITY%TYPE
                   , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_STATE%TYPE
                   , P_COSIGNEE_NAME             HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.COSIGNEE_NAME%TYPE
                   , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_CITY%TYPE
                   , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_STATE%TYPE
                    )
IS
SELECT
    NVL(COUNT(*),0)
FROM
    HAEMO.XXHA_TRANSPORT_RATES_CALCS RATES
WHERE
    RATES.SESSION_ID                            = P_SESSION_ID
AND RATES.TRANS_MODE                            = P_TRANS_MODE
AND RATES.PROVIDER                              = P_PROVIDER
AND NVL(RATES.LANE_TYPE, 'XXX')                 = NVL(P_LANE_TYPE, 'XXX') 
AND NVL(RATES.LANE_ID, 'XXX')                   = NVL(P_LANE_ID, 'XXX') 
AND NVL(RATES.EQUIPMENT, 'XXX')                 = NVL(P_EQUIPMENT, 'XXX') 
AND NVL(RATES.SERVICE, 'XXX')                   = NVL(P_SERVICE, 'XXX') 
AND RATES.ORIGIN_TYPE                           = P_ORIGIN_TYPE
AND RATES.SHIPPER_NAME                          = P_SHIPPER_NAME
AND RATES.ORIGIN_CITY                           = P_ORIGIN_CITY
AND NVL(RATES.ORIGIN_STATE, 'XXX')              = NVL(P_ORIGIN_STATE, 'XXX') 
AND RATES.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND RATES.DESTINATION_CITY                      = P_DESTINATION_CITY
AND NVL(RATES.DESTINATION_STATE, 'XXX')         = NVL(P_DESTINATION_STATE, 'XXX') 
;

-- Cursor cur_Retrieve_AIR
CURSOR cur_Retrieve_AIR(
                        P_SESSION_ID                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SESSION_ID%TYPE
                      , P_TRANS_MODE                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TRANS_MODE%TYPE
                      , P_PROVIDER                    HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.PROVIDER%TYPE
                      , P_LANE_TYPE                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_TYPE%TYPE
                      , P_LANE_ID                     HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.LANE_ID%TYPE
                      , P_EQUIPMENT                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.EQUIPMENT%TYPE
                      , P_SERVICE                     HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SERVICE%TYPE
                      , P_ORIGIN_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_TYPE%TYPE
                      , P_SHIPPER_NAME                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.SHIPPER_NAME%TYPE
                      , P_ORIGIN_CITY                 HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_CITY%TYPE
                      , P_ORIGIN_STATE                HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.ORIGIN_STATE%TYPE
                      , P_COSIGNEE_NAME               HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.COSIGNEE_NAME%TYPE
                      , P_DESTINATION_CITY            HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_CITY%TYPE
                      , P_DESTINATION_STATE           HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.DESTINATION_STATE%TYPE
                       )
IS
SELECT
    SESSION_ID
  , TRANS_MODE
  , PROVIDER
  , LANE_TYPE
  , LANE_ID
  , ORIGIN_CITY
  , ORIGIN_STATE
  , DESTINATION_CITY
  , DESTINATION_STATE
  , EQUIPMENT
  , SERVICE
  , ORIGIN_TYPE
  , SHIPPER_NAME
  , COSIGNEE_NAME
  , SAIL_DAY_OF_WEEK
  , TOTAL_TRANSIT_DAYS_INLAND
  , TOTAL_TRANSIT_DAYS_OCEAN
  , FLIGHTS_PER_WEEK
  , FLIGHT_FREQUENCY_NBR
  , TRANSIT_TIME_DAYS
  , COLUMN_CR
  , COLUMN_CS
  , COLUMN_CT
  , COLUMN_DO
  , COLUMN_DP
  , COLUMN_EB
  , COLUMN_EC
  , COLUMN_EE
FROM
    HAEMO.XXHA_TRANSPORT_RATES_CALCS RATES
WHERE
    RATES.SESSION_ID                            = P_SESSION_ID
AND RATES.TRANS_MODE                            = P_TRANS_MODE
AND RATES.PROVIDER                              = P_PROVIDER
AND NVL(RATES.LANE_TYPE, 'XXX')                 = NVL(P_LANE_TYPE, 'XXX') 
AND NVL(RATES.LANE_ID, 'XXX')                   = NVL(P_LANE_ID, 'XXX') 
AND NVL(RATES.EQUIPMENT, 'XXX')                 = NVL(P_EQUIPMENT, 'XXX') 
AND NVL(RATES.SERVICE, 'XXX')                   = NVL(P_SERVICE, 'XXX') 
AND RATES.ORIGIN_TYPE                           = P_ORIGIN_TYPE
AND RATES.SHIPPER_NAME                          = P_SHIPPER_NAME
AND RATES.ORIGIN_CITY                           = P_ORIGIN_CITY
AND NVL(RATES.ORIGIN_STATE, 'XXX')              = NVL(P_ORIGIN_STATE, 'XXX') 
AND RATES.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND RATES.DESTINATION_CITY                      = P_DESTINATION_CITY
AND NVL(RATES.DESTINATION_STATE, 'XXX')         = NVL(P_DESTINATION_STATE, 'XXX') 
;

BEGIN
   
   -- Retrieve the data from XXHA_TRANSPORT_RATES_V
   OPEN  cur_0700(P_ORIGIN_CITY, P_ORIGIN_STATE, P_ORIGIN_COUNTRY, P_DESTINATION_CITY, P_DESTINATION_STATE, P_DESTINATION_COUNTRY, P_PROVIDER, P_SHIPPER_NAME, P_COSIGNEE_NAME, P_LANE_ID, P_LANE_TYPE, P_EQUIPMENT, P_ORIGIN_TYPE, P_DATE_IN);
   FETCH cur_0700 INTO 
                    l_PROVIDER
                  , l_LANE_TYPE
                  , l_LANE_TYPE_MAJOR_LANE
                  , l_LANE_ID
                  , l_LANE_REFERENCE
                  , l_TRANS_MODE
                  , l_SERVICE
                  , l_ORIGIN_TYPE
                  , l_SHIPPER_NAME
                  , l_ORIGIN_CITY
                  , l_ORIGIN_STATE
                  , l_DESTINATION_CITY
                  , l_DESTINATION_STATE
                  , l_ORIGIN_INLAND_MIN
                  , l_ORIGIN_INLAND_PER_KG
                  , l_ORIGIN_HANDLING_MIN
                  , l_ORIGIN_HANDLING_PER_KG
                  , l_ORIGIN_TERMINAL_MIN
                  , l_ORIGIN_TERMINAL_PER_KG
                  , l_ORIGIN_DOC_FEE_MIN
                  , l_ORIGIN_DOC_FEE_PER_KG
                  , l_ORIGIN_OTHER_MIN
                  , l_ORIGIN_OTHER_PER_KG
                  , l_AIR_FREIGHT_MIN_KG
                  , l_KG_LE_45
                  , l_KG_GT_45
                  , l_KG_GT_100
                  , l_KG_GT_300
                  , l_KG_GT_500
                  , l_KG_GT_1000
                  , l_KG_GT_2000
                  , l_KG_GT_5000
                  , l_KG_GT_10000
                  , l_FUEL_SURCHARGE_PER_KG
                  , l_SECURITY_SURCHARGE_PER_KG
                  , l_DESTINATION_INLAND_MIN
                  , l_DESTINATION_INLAND_PER_KG
                  , l_DESTINATION_HANDLING_MIN
                  , l_DESTINATION_HANDLING_PER_KG
                  , l_DESTINATION_TERMINAL_MIN
                  , l_DESTINATION_TERMINAL_PER_KG
                  , l_DESTINATION_DOC_FEE_MIN
                  , l_DESTINATION_DOC_FEE_PER_KG
                  , l_DESTINATION_OTHER_MIN
                  , l_DESTINATION_OTHER_PER_KG
                  , l_FLIGHTS_PER_WEEK
                  , l_FLIGHT_FREQUENCY_NBR
                  , l_TRANSIT_TIME_DAYS
                  ;
   CLOSE cur_0700;

   l_ACTUAL_WEIGHT := P_ACTUAL_WEIGHT_LBS;

   -- If Metric data was sent, Convert to Std
   IF P_STD_METRIC = 'M' THEN
      l_ACTUAL_WEIGHT := (P_ACTUAL_WEIGHT_LBS * 2.2046226);
   END IF;

   -- Calculate Total Actual Weight (KGs) - COLUMN CR
   P_ACTUAL_WGT_KGS             := ROUND((l_ACTUAL_WEIGHT / 2.2046226),6);
   P_ACTUAL_WGT_KGS_ROUND       := ROUND(P_ACTUAL_WGT_KGS,0);
   P_ACTUAL_WGT_KGS_REMAINDER   := (P_ACTUAL_WGT_KGS - P_ACTUAL_WGT_KGS_ROUND);
   -- If there is a remainder, roundup to next whole number
   IF P_ACTUAL_WGT_KGS_REMAINDER > 0 THEN
      P_ACTUAL_WGT_KGS := (P_ACTUAL_WGT_KGS_ROUND+1);
   ELSE
      P_ACTUAL_WGT_KGS := (P_ACTUAL_WGT_KGS_ROUND);
   END IF;

   P_ACTUAL_WGT_KGS             := (P_QUANTITY_PALLETS * P_ACTUAL_WGT_KGS);

   l_LENGTH := (P_LENGTH_INCHES);
   l_WIDTH  := (P_WIDTH_INCHES);
   l_HEIGHT := (P_HEIGHT_INCHES);

   -- If Metric data was sent, Convert to Std 
   IF P_STD_METRIC = 'M' THEN
      l_LENGTH := (P_LENGTH_INCHES/2.54);
      l_WIDTH  := (P_WIDTH_INCHES/2.54);
      l_HEIGHT := (P_HEIGHT_INCHES/2.54);
   END IF;

   -- Calculate Total Dimension Weight (KGs) - COLUMN CS
   P_TOTAL_DIMENSIONS           := (l_LENGTH * l_WIDTH * l_HEIGHT);
   P_DIMENSION_WGT_KGS          := (P_TOTAL_DIMENSIONS / 366);
   P_DIMENSION_WGT_KGS          := (P_QUANTITY_PALLETS * P_DIMENSION_WGT_KGS);

   -- Calculate Total Wgt Used for Shipment (KGs) - COLUMN CT
   P_SHIPMENT_WGT_KGS           := NVL(GREATEST(P_DIMENSION_WGT_KGS, P_ACTUAL_WGT_KGS),0);

   -- Calculate Total Orig/Dest Fees Min$ - COLUMN EB
   l_TOTAL_ORIG_DEST_FEES_MIN   := (l_DESTINATION_OTHER_MIN + l_DESTINATION_DOC_FEE_MIN + l_DESTINATION_TERMINAL_MIN + l_DESTINATION_HANDLING_MIN + 
                                    l_DESTINATION_INLAND_MIN + l_ORIGIN_OTHER_MIN + l_ORIGIN_DOC_FEE_MIN + l_ORIGIN_TERMINAL_MIN + l_ORIGIN_HANDLING_MIN + 
                                    l_ORIGIN_INLAND_MIN);

   -- Calculate Total Orig/Dest Fees $/KG - COLUMN EC
   l_TOTAL_ORIG_DEST_FEES_KG    := (l_DESTINATION_OTHER_PER_KG + l_DESTINATION_DOC_FEE_PER_KG + l_DESTINATION_TERMINAL_PER_KG + l_DESTINATION_HANDLING_PER_KG + 
                                    l_DESTINATION_INLAND_PER_KG + l_ORIGIN_OTHER_PER_KG + l_ORIGIN_DOC_FEE_PER_KG + l_ORIGIN_TERMINAL_PER_KG + 
                                    l_ORIGIN_HANDLING_PER_KG + l_ORIGIN_INLAND_PER_KG);

   -- Calculate Orig/Dest Fees $ at Wgt - COLUMN ED
   l_ORIG_DEST_FEES_AT_WGT      := NVL((l_TOTAL_ORIG_DEST_FEES_KG * GREATEST(P_ACTUAL_WGT_KGS, P_DIMENSION_WGT_KGS)),0);

   -- Calculate Min Chg Based on All Min Chg w/FSC AND Sec - COLUMN EF
   IF P_SHIPMENT_WGT_KGS <= 45 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_LE_45;
   ELSIF P_SHIPMENT_WGT_KGS <= 100 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_45;
   ELSIF P_SHIPMENT_WGT_KGS <= 300 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_100;
   ELSIF P_SHIPMENT_WGT_KGS <= 500 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_300;
   ELSIF P_SHIPMENT_WGT_KGS <= 1000 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_500;
   ELSIF P_SHIPMENT_WGT_KGS <= 2000 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_1000;
   ELSIF P_SHIPMENT_WGT_KGS <= 5000 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_2000;
   ELSIF P_SHIPMENT_WGT_KGS <= 10000 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_5000;
   ELSIF P_SHIPMENT_WGT_KGS >= 10001 THEN
      P_AIR_FRT_BASED_ON_WGT_KGS := l_KG_GT_10000;
   END IF;

   -- Calculate Air Freight at Wgt - COLUMN EG
   l_AIR_FRT_BASED_ON_WGT_KGS   := NVL((P_AIR_FRT_BASED_ON_WGT_KGS * GREATEST(P_ACTUAL_WGT_KGS, P_DIMENSION_WGT_KGS)),0);

   -- Calculate FSC AND Security Total - COLUMN EH - ((DO+DP)*MAX(CR,CS))
   l_FSC_AND_SECURITY_TOTAL     := NVL(((l_FUEL_SURCHARGE_PER_KG + l_SECURITY_SURCHARGE_PER_KG) * GREATEST(P_ACTUAL_WGT_KGS, P_DIMENSION_WGT_KGS)),0);

   -- Calculate Min Chg Based on All Min Chg w/FSC AND Sec - COLUMN EI (EB+EE+EH)
   l_CHG_BASED_ON_ALL_MIN_CHGS  := NVL((l_TOTAL_ORIG_DEST_FEES_MIN + l_AIR_FREIGHT_MIN_KG + l_FSC_AND_SECURITY_TOTAL),0);

   -- Calculate Total Charge based on $/KG - COLUMN EJ
   l_TOTAL_CHARGE_BASED_ON_KG   := NVL((l_ORIG_DEST_FEES_AT_WGT + l_AIR_FRT_BASED_ON_WGT_KGS + l_FSC_AND_SECURITY_TOTAL),0);

   -- Initialize Values
   l_TOTAL_COST                 := NULL;
   l_TOTAL_COST_NUM             := 0;
   l_Count                      := 0;

   -- Calculate Total Cost - COLUMN EK
   l_TOTAL_COST_NUM             := ROUND(GREATEST(l_CHG_BASED_ON_ALL_MIN_CHGS, l_TOTAL_CHARGE_BASED_ON_KG),0);

   -- See if a record already exists in the table 'HAEMO.XXHA_TRANSPORT_RATES_CALCS'
   OPEN cur_Count_AIR(P_SESSION_ID, 'AIR', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), 
                      P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE));
   FETCH cur_Count_AIR INTO l_Count;
   CLOSE cur_Count_AIR;

   -- If a record exists, accumulate the data
   IF NVL(l_count,0) > 0 THEN

      -- Retrieve data from existing record
      OPEN cur_Retrieve_AIR(P_SESSION_ID, 'AIR', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), 
                            P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE)); 
      FETCH cur_Retrieve_AIR INTO 
       l_SESSION_ID, l_TRANS_MODE, l_PROVIDER, l_LANE_TYPE, l_LANE_ID, l_ORIGIN_CITY, l_ORIGIN_STATE, l_DESTINATION_CITY, l_DESTINATION_STATE, l_EQUIPMENT
      ,l_SERVICE, l_ORIGIN_TYPE, l_SHIPPER_NAME, l_COSIGNEE_NAME, l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN, l_FLIGHTS_PER_WEEK, l_FLIGHT_FREQUENCY_NBR
      ,l_TRANSIT_TIME_DAYS, l_COLUMN_CR, l_COLUMN_CS, l_COLUMN_CT, l_COLUMN_DO, l_COLUMN_DP, l_COLUMN_EB, l_COLUMN_EC, l_COLUMN_EE;
      CLOSE cur_Retrieve_AIR;

      -- Update existing record
      UPDATE HAEMO.XXHA_TRANSPORT_RATES_CALCS TEMP
      SET
          TEMP.COLUMN_CR = (l_COLUMN_CR + P_ACTUAL_WGT_KGS)                     -- Accumulated total of Total Actual Weight (KGs)
        , TEMP.COLUMN_CS = (l_COLUMN_CS + P_DIMENSION_WGT_KGS)                  -- Total Dimensional Weight (KGs)
        , TEMP.COLUMN_CT = (l_COLUMN_CT + P_SHIPMENT_WGT_KGS)                   -- Total Wgt Used for Shipment (KGs)
      WHERE
          TEMP.SESSION_ID                             = P_SESSION_ID
      AND TEMP.TRANS_MODE                             = 'AIR'
      AND TEMP.PROVIDER                               = P_PROVIDER
      AND NVL(TEMP.LANE_TYPE, 'XXX')                  = NVL(P_LANE_TYPE, 'XXX')
      AND NVL(TEMP.LANE_ID, 'XXX')                    = NVL(P_LANE_ID, 'XXX')
      AND NVL(TEMP.EQUIPMENT, 'XXX')                  = NVL(P_EQUIPMENT, 'XXX')
      AND NVL(TEMP.SERVICE, 'XXX')                    = NVL(P_SERVICE, 'XXX')
      AND TEMP.ORIGIN_TYPE                            = P_ORIGIN_TYPE
      AND TEMP.SHIPPER_NAME                           = P_SHIPPER_NAME
      AND TEMP.ORIGIN_CITY                            = UPPER(P_ORIGIN_CITY)
      AND NVL(TEMP.ORIGIN_STATE, 'XXX')               = NVL(UPPER(P_ORIGIN_STATE), 'XXX')
      AND TEMP.COSIGNEE_NAME                          = P_COSIGNEE_NAME
      AND TEMP.DESTINATION_CITY                       = UPPER(P_DESTINATION_CITY)
      AND NVL(TEMP.DESTINATION_STATE, 'XXX')          = NVL(UPPER(P_DESTINATION_STATE), 'XXX');
      COMMIT;
   ELSE
      -- Create Record in XXHA_TRANSPORT_RATES_CALCS
      INSERT INTO HAEMO.XXHA_TRANSPORT_RATES_CALCS
         (SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID, ORIGIN_CITY, ORIGIN_STATE, ORIGIN_COUNTRY
        , EQUIPMENT, SERVICE, ORIGIN_TYPE, SHIPPER_NAME, COSIGNEE_NAME, SAIL_DAY_OF_WEEK, TOTAL_TRANSIT_DAYS_INLAND, TOTAL_TRANSIT_DAYS_OCEAN
        , FLIGHTS_PER_WEEK, FLIGHT_FREQUENCY_NBR, TRANSIT_TIME_DAYS, DESTINATION_CITY, DESTINATION_STATE, DESTINATION_COUNTRY
        , COLUMN_CR, COLUMN_CS, COLUMN_CT, COLUMN_DO, COLUMN_DP
        , COLUMN_EB, COLUMN_EC, COLUMN_EE, CREATION_DATE
         )
      VALUES
         (P_SESSION_ID, 'AIR', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, UPPER(P_ORIGIN_CITY), UPPER(P_ORIGIN_STATE), UPPER(P_ORIGIN_COUNTRY)
        , P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, P_COSIGNEE_NAME, l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN
        , l_FLIGHTS_PER_WEEK, l_FLIGHT_FREQUENCY_NBR, l_TRANSIT_TIME_DAYS, UPPER(P_DESTINATION_CITY), UPPER(P_DESTINATION_STATE), UPPER(P_DESTINATION_COUNTRY)
        , P_ACTUAL_WGT_KGS, P_DIMENSION_WGT_KGS, P_SHIPMENT_WGT_KGS, l_FUEL_SURCHARGE_PER_KG, l_SECURITY_SURCHARGE_PER_KG
        , l_TOTAL_ORIG_DEST_FEES_MIN, l_TOTAL_ORIG_DEST_FEES_KG, l_AIR_FREIGHT_MIN_KG, SYSDATE
         );
      COMMIT;
   END IF;

   -- Format l_TOTAL_COST_NUM from '123456789012' to '123,456,789,012'
   l_TOTAL_COST := TO_CHAR(l_TOTAL_COST_NUM, '99,999,999,999,999,999,999,999');

   -- Create Record in XXHA_TRANSPORT_RATES_TEMP_TBL
   INSERT INTO HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL 
      (SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID, EQUIPMENT, SERVICE, ORIGIN_TYPE, SHIPPER_NAME, ORIGIN_CITY, ORIGIN_STATE, COSIGNEE_NAME, DESTINATION_CITY, DESTINATION_STATE, SAIL_DAY_OF_WEEK, TOTAL_TRANSIT_DAYS_INLAND, TOTAL_TRANSIT_DAYS_OCEAN, FLIGHTS_PER_WEEK, FLIGHT_FREQUENCY_NBR, TRANSIT_TIME_DAYS, TOTAL_COST, TOTAL_COST_NUM, CREATION_DATE)
   VALUES
      (P_SESSION_ID, 'AIR', P_PROVIDER, P_LANE_TYPE, P_LANE_ID, P_EQUIPMENT, P_SERVICE, P_ORIGIN_TYPE, P_SHIPPER_NAME, UPPER(P_ORIGIN_CITY), UPPER(l_ORIGIN_STATE), P_COSIGNEE_NAME, UPPER(P_DESTINATION_CITY), UPPER(l_DESTINATION_STATE), NULL, NULL, NULL, l_FLIGHTS_PER_WEEK, l_FLIGHT_FREQUENCY_NBR, l_TRANSIT_TIME_DAYS, l_TOTAL_COST, l_TOTAL_COST_NUM, SYSDATE);
   COMMIT;

END XXHA_TRANS_AIR_P;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_MULTI_SKID_AIR

PROCEDURE XXHA_MULTI_SKID_AIR (P_SESSION_ID                   IN NUMBER
                             , P_TRANS_MODE                   IN VARCHAR2
                               ) IS

l_PROVIDER                        HAEMO.XXHA_TRANSPORT_RATES_CALCS.PROVIDER%TYPE                  := NULL;
l_LANE_TYPE                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.LANE_TYPE%TYPE                 := NULL;
l_LANE_ID                         HAEMO.XXHA_TRANSPORT_RATES_CALCS.LANE_ID%TYPE                   := NULL;
l_ORIGIN_CITY                     HAEMO.XXHA_TRANSPORT_RATES_CALCS.ORIGIN_CITY%TYPE               := NULL;
l_ORIGIN_STATE                    HAEMO.XXHA_TRANSPORT_RATES_CALCS.ORIGIN_STATE%TYPE              := NULL;
l_ORIGIN_COUNTRY                  HAEMO.XXHA_TRANSPORT_RATES_CALCS.ORIGIN_COUNTRY%TYPE            := NULL;
l_DESTINATION_CITY                HAEMO.XXHA_TRANSPORT_RATES_CALCS.DESTINATION_CITY%TYPE          := NULL;
l_DESTINATION_STATE               HAEMO.XXHA_TRANSPORT_RATES_CALCS.DESTINATION_STATE%TYPE         := NULL;
l_DESTINATION_COUNTRY             HAEMO.XXHA_TRANSPORT_RATES_CALCS.DESTINATION_COUNTRY%TYPE       := NULL;
l_EQUIPMENT                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.EQUIPMENT%TYPE                 := NULL;
l_SERVICE                         HAEMO.XXHA_TRANSPORT_RATES_CALCS.SERVICE%TYPE                   := NULL;
l_ORIGIN_TYPE                     HAEMO.XXHA_TRANSPORT_RATES_CALCS.ORIGIN_TYPE%TYPE               := NULL;
l_SHIPPER_NAME                    HAEMO.XXHA_TRANSPORT_RATES_CALCS.SHIPPER_NAME%TYPE              := NULL;
l_COSIGNEE_NAME                   HAEMO.XXHA_TRANSPORT_RATES_CALCS.COSIGNEE_NAME%TYPE             := NULL;
l_SAIL_DAY_OF_WEEK                HAEMO.XXHA_TRANSPORT_RATES_CALCS.SAIL_DAY_OF_WEEK%TYPE          := NULL;
l_TOTAL_TRANSIT_DAYS_INLAND       HAEMO.XXHA_TRANSPORT_RATES_CALCS.TOTAL_TRANSIT_DAYS_INLAND%TYPE := NULL;
l_TOTAL_TRANSIT_DAYS_OCEAN        HAEMO.XXHA_TRANSPORT_RATES_CALCS.TOTAL_TRANSIT_DAYS_OCEAN%TYPE  := NULL;
l_FLIGHTS_PER_WEEK                HAEMO.XXHA_TRANSPORT_RATES_CALCS.FLIGHTS_PER_WEEK%TYPE          := NULL;
l_FLIGHT_FREQUENCY_NBR            HAEMO.XXHA_TRANSPORT_RATES_CALCS.FLIGHT_FREQUENCY_NBR%TYPE      := NULL;
l_TRANSIT_TIME_DAYS               HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANSIT_TIME_DAYS%TYPE         := NULL;

l_COLUMN_CR                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CR%TYPE                 := 0;
l_COLUMN_CS                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CS%TYPE                 := 0;
l_COLUMN_CT                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_CT%TYPE                 := 0;
l_COLUMN_DO                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_DO%TYPE                 := 0;
l_COLUMN_DP                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_DP%TYPE                 := 0;
l_COLUMN_EB                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EB%TYPE                 := 0;
l_COLUMN_EC                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EC%TYPE                 := 0;
l_COLUMN_ED                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_ED%TYPE                 := 0;
l_COLUMN_EE                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EE%TYPE                 := 0;
l_COLUMN_EF                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EF%TYPE                 := 0;
l_COLUMN_EG                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EG%TYPE                 := 0;
l_COLUMN_EH                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EH%TYPE                 := 0;
l_COLUMN_EI                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EI%TYPE                 := 0;
l_COLUMN_EJ                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EJ%TYPE                 := 0;
l_COLUMN_EK                       HAEMO.XXHA_TRANSPORT_RATES_CALCS.COLUMN_EK%TYPE                 := 0;
l_COLUMN_EK_FMT                   HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST%TYPE             := NULL;

l_KG_LE_45                        HAEMO.XXHA_TRANSPORT_RATES_V.KG_LE_45%TYPE                      := 0;
l_KG_GT_45                        HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_45%TYPE                      := 0;
l_KG_GT_100                       HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_100%TYPE                     := 0;
l_KG_GT_300                       HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_300%TYPE                     := 0;
l_KG_GT_500                       HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_500%TYPE                     := 0;
l_KG_GT_1000                      HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_1000%TYPE                    := 0;
l_KG_GT_2000                      HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_2000%TYPE                    := 0;
l_KG_GT_5000                      HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_5000%TYPE                    := 0;
l_KG_GT_10000                     HAEMO.XXHA_TRANSPORT_RATES_V.KG_GT_10000%TYPE                   := 0;

-- Cursor cur_0800
CURSOR cur_0800(
                P_SESSION_ID      HAEMO.XXHA_TRANSPORT_RATES_CALCS.SESSION_ID%TYPE
              , P_TRANS_MODE      HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANS_MODE%TYPE
               )
IS
SELECT
    SESSION_ID
  , TRANS_MODE
  , PROVIDER
  , LANE_TYPE
  , LANE_ID
  , ORIGIN_CITY
  , ORIGIN_STATE
  , ORIGIN_COUNTRY
  , DESTINATION_CITY
  , DESTINATION_STATE
  , DESTINATION_COUNTRY
  , EQUIPMENT
  , SERVICE
  , ORIGIN_TYPE
  , SHIPPER_NAME
  , COSIGNEE_NAME
  , SAIL_DAY_OF_WEEK
  , TOTAL_TRANSIT_DAYS_INLAND
  , TOTAL_TRANSIT_DAYS_OCEAN
  , FLIGHTS_PER_WEEK
  , FLIGHT_FREQUENCY_NBR
  , TRANSIT_TIME_DAYS
  , COLUMN_CR
  , COLUMN_CS
  , COLUMN_CT
  , COLUMN_DO
  , COLUMN_DP
  , COLUMN_EB
  , COLUMN_EC
  , COLUMN_ED
  , COLUMN_EE
  , COLUMN_EF
  , COLUMN_EG
  , COLUMN_EH
  , COLUMN_EI
  , COLUMN_EJ
  , COLUMN_EK
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_CALCS XXHA
WHERE
    XXHA.SESSION_ID    = P_SESSION_ID
AND XXHA.TRANS_MODE    = P_TRANS_MODE
ORDER BY
    XXHA.SESSION_ID
  , XXHA.TRANS_MODE
  , XXHA.PROVIDER
  , XXHA.LANE_TYPE
  , XXHA.LANE_ID;

-- Cursor cur_0900
CURSOR cur_0900(
                P_ORIGIN_CITY               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_CITY%TYPE
              , P_ORIGIN_STATE              HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_STATE%TYPE
              , P_ORIGIN_COUNTRY            HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_COUNTRY%TYPE
              , P_DESTINATION_CITY          HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_CITY%TYPE
              , P_DESTINATION_STATE         HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_STATE%TYPE
              , P_DESTINATION_COUNTRY       HAEMO.XXHA_TRANSPORT_RATES_V.DESTINATION_COUNTRY%TYPE
              , P_PROVIDER                  HAEMO.XXHA_TRANSPORT_RATES_V.PROVIDER%TYPE
              , P_SHIPPER_NAME              HAEMO.XXHA_TRANSPORT_RATES_V.SHIPPER_NAME%TYPE
              , P_COSIGNEE_NAME             HAEMO.XXHA_TRANSPORT_RATES_V.COSIGNEE_NAME%TYPE
              , P_LANE_ID                   HAEMO.XXHA_TRANSPORT_RATES_V.LANE_ID%TYPE
              , P_LANE_TYPE                 HAEMO.XXHA_TRANSPORT_RATES_V.LANE_TYPE%TYPE
              , P_EQUIPMENT                 HAEMO.XXHA_TRANSPORT_RATES_V.EQUIPMENT%TYPE
              , P_ORIGIN_TYPE               HAEMO.XXHA_TRANSPORT_RATES_V.ORIGIN_TYPE%TYPE
              , P_DATE                      HAEMO.XXHA_TRANSPORT_RATES_V.EFFECTIVE_START_DATE%TYPE
              )
IS
SELECT
    AIR.KG_LE_45
  , AIR.KG_GT_45
  , AIR.KG_GT_100
  , AIR.KG_GT_300
  , AIR.KG_GT_500
  , AIR.KG_GT_1000
  , AIR.KG_GT_2000
  , AIR.KG_GT_5000
  , AIR.KG_GT_10000
FROM 
     HAEMO.XXHA_TRANSPORT_RATES_V               AIR
WHERE
    AIR.TRANS_MODE                            = 'AIR'
AND UPPER(AIR.ORIGIN_CITY)                    = UPPER(P_ORIGIN_CITY)
AND NVL(UPPER(AIR.ORIGIN_STATE),'XXX')        = NVL(UPPER(P_ORIGIN_STATE),'XXX')
AND NVL(UPPER(AIR.ORIGIN_COUNTRY),'XXX')      = NVL(UPPER(P_ORIGIN_COUNTRY),'XXX')
AND UPPER(AIR.DESTINATION_CITY)               = UPPER(P_DESTINATION_CITY)
AND NVL(UPPER(AIR.DESTINATION_STATE),'XXX')   = NVL(UPPER(P_DESTINATION_STATE),'XXX')
AND NVL(UPPER(AIR.DESTINATION_COUNTRY),'XXX') = NVL(UPPER(P_DESTINATION_COUNTRY),'XXX')
AND AIR.PROVIDER                              = P_PROVIDER
AND AIR.SHIPPER_NAME                          = P_SHIPPER_NAME
AND AIR.COSIGNEE_NAME                         = P_COSIGNEE_NAME
AND AIR.LANE_ID                               = P_LANE_ID
AND NVL(AIR.LANE_TYPE,'XXX')                  = NVL(P_LANE_TYPE,'XXX')
AND NVL(AIR.EQUIPMENT,'XXX')                  = NVL(P_EQUIPMENT,'XXX')
AND NVL(AIR.ORIGIN_TYPE,'XXX')                = NVL(P_ORIGIN_TYPE,'XXX')
AND P_DATE BETWEEN TRUNC(AIR.Effective_Start_Date) AND NVL(TRUNC(AIR.Effective_End_Date), '01-JAN-4715')
;

BEGIN

   -- Now Process the data
   FOR recs IN cur_0800(P_SESSION_ID, P_TRANS_MODE)
   LOOP

      l_PROVIDER                  := recs.PROVIDER;
      l_LANE_TYPE                 := recs.LANE_TYPE;
      l_LANE_ID                   := recs.LANE_ID;
      l_ORIGIN_CITY               := recs.ORIGIN_CITY;
      l_ORIGIN_STATE              := recs.ORIGIN_STATE;
      l_ORIGIN_COUNTRY            := recs.ORIGIN_COUNTRY;
      l_DESTINATION_CITY          := recs.DESTINATION_CITY;
      l_DESTINATION_STATE         := recs.DESTINATION_STATE;
      l_DESTINATION_COUNTRY       := recs.DESTINATION_COUNTRY;
      l_EQUIPMENT                 := recs.EQUIPMENT;
      l_SERVICE                   := recs.SERVICE;
      l_ORIGIN_TYPE               := recs.ORIGIN_TYPE;
      l_SHIPPER_NAME              := recs.SHIPPER_NAME;
      l_COSIGNEE_NAME             := recs.COSIGNEE_NAME;
      l_SAIL_DAY_OF_WEEK          := recs.SAIL_DAY_OF_WEEK;
      l_TOTAL_TRANSIT_DAYS_INLAND := recs.TOTAL_TRANSIT_DAYS_INLAND;
      l_TOTAL_TRANSIT_DAYS_OCEAN  := recs.TOTAL_TRANSIT_DAYS_OCEAN;
      l_FLIGHTS_PER_WEEK          := recs.FLIGHTS_PER_WEEK;
      l_FLIGHT_FREQUENCY_NBR      := recs.FLIGHT_FREQUENCY_NBR;
      l_TRANSIT_TIME_DAYS         := recs.TRANSIT_TIME_DAYS;
      l_COLUMN_DO                 := recs.COLUMN_DO;                            -- take first record as it's a fixed cost
      l_COLUMN_DP                 := recs.COLUMN_DP;                            -- take first record as it's a fixed cost
      l_COLUMN_EB                 := recs.COLUMN_EB;                            -- take first record as it's a fixed cost
      l_COLUMN_EC                 := recs.COLUMN_EC;                            -- take first record as it's a fixed cost
      l_COLUMN_EE                 := recs.COLUMN_EE;                            -- take first record as it's a fixed cost
      l_COLUMN_CR                 := recs.COLUMN_CR;                            -- Total Actual Weight (KGs)
      l_COLUMN_CS                 := recs.COLUMN_CS;                            -- Total Dimensional Weight (KGs)
      l_COLUMN_CT                 := recs.COLUMN_CT;                            -- Total Wgt Used for Shipment (KGs)

      -- Retrieve the data
      OPEN  cur_0900(l_ORIGIN_CITY, l_ORIGIN_STATE, l_ORIGIN_COUNTRY, l_DESTINATION_CITY, l_DESTINATION_STATE, l_DESTINATION_COUNTRY, l_PROVIDER, l_SHIPPER_NAME, l_COSIGNEE_NAME, l_LANE_ID, l_LANE_TYPE, l_EQUIPMENT, l_ORIGIN_TYPE, g_date);
      FETCH cur_0900 INTO 
                 l_KG_LE_45
               , l_KG_GT_45
               , l_KG_GT_100
               , l_KG_GT_300
               , l_KG_GT_500
               , l_KG_GT_1000
               , l_KG_GT_2000
               , l_KG_GT_5000
               , l_KG_GT_10000;
      CLOSE cur_0900;

      -- Calculate Min Chg Based on All Min Chg w/FSC AND Sec - COLUMN EF
      IF l_COLUMN_CT <= 45 THEN
         l_COLUMN_EF := l_KG_LE_45;
      ELSIF l_COLUMN_CT <= 100 THEN
         l_COLUMN_EF := l_KG_GT_45;
      ELSIF l_COLUMN_CT <= 300 THEN
         l_COLUMN_EF := l_KG_GT_100;
      ELSIF l_COLUMN_CT <= 500 THEN
         l_COLUMN_EF := l_KG_GT_300;
      ELSIF l_COLUMN_CT <= 1000 THEN
         l_COLUMN_EF := l_KG_GT_500;
      ELSIF l_COLUMN_CT <= 2000 THEN
         l_COLUMN_EF := l_KG_GT_1000;
      ELSIF l_COLUMN_CT <= 5000 THEN
         l_COLUMN_EF := l_KG_GT_2000;
      ELSIF l_COLUMN_CT <= 10000 THEN
         l_COLUMN_EF := l_KG_GT_5000;
      ELSIF l_COLUMN_CT >= 10001 THEN
         l_COLUMN_EF := l_KG_GT_10000;
      END IF;

      -- Orig/Dest Fees $ at Wgt
      l_COLUMN_ED  := (l_COLUMN_EC * GREATEST(l_COLUMN_CR, l_COLUMN_CS));
      -- Air Freight at Wgt
      l_COLUMN_EG  := (l_COLUMN_EF * GREATEST(l_COLUMN_CR, l_COLUMN_CS));
      -- FSC and Security Total
      l_COLUMN_EH  := (l_COLUMN_DO + l_COLUMN_DP) * GREATEST(l_COLUMN_CR, l_COLUMN_CS);
      -- Min Chg Based on All Min Chg w/FSC and Sec
      l_COLUMN_EI  := (l_COLUMN_EB + l_COLUMN_EE + l_COLUMN_EH);
      -- Total Charge based on $/KG
      l_COLUMN_EJ  := (l_COLUMN_ED + l_COLUMN_EG + l_COLUMN_EH);
      -- Total Cost
      l_COLUMN_EK  := GREATEST(l_COLUMN_EI, l_COLUMN_EJ);

      -- Format l_COLUMN_EK from '123456789012' to '123,456,789,012'
      l_COLUMN_EK_FMT := TO_CHAR(l_COLUMN_EK, '99,999,999,999,999,999,999,999');

      -- Create Record in XXHA_TRANSPORT_RATES_TEMP_TBL
      INSERT INTO HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL 
         (SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID, EQUIPMENT, SERVICE, ORIGIN_TYPE, SHIPPER_NAME
        , ORIGIN_CITY, ORIGIN_STATE, COSIGNEE_NAME, DESTINATION_CITY, DESTINATION_STATE
        , SAIL_DAY_OF_WEEK, TOTAL_TRANSIT_DAYS_INLAND, TOTAL_TRANSIT_DAYS_OCEAN, FLIGHTS_PER_WEEK, FLIGHT_FREQUENCY_NBR, TRANSIT_TIME_DAYS
        , TOTAL_COST, TOTAL_COST_NUM, CREATION_DATE)
      VALUES
         (P_SESSION_ID, P_TRANS_MODE, l_PROVIDER, l_LANE_TYPE, l_LANE_ID, l_EQUIPMENT, l_SERVICE, l_ORIGIN_TYPE, l_SHIPPER_NAME
        , UPPER(l_ORIGIN_CITY), UPPER(l_ORIGIN_STATE), l_COSIGNEE_NAME, UPPER(l_DESTINATION_CITY), UPPER(l_DESTINATION_STATE)
        , l_SAIL_DAY_OF_WEEK, l_TOTAL_TRANSIT_DAYS_INLAND, l_TOTAL_TRANSIT_DAYS_OCEAN, l_FLIGHTS_PER_WEEK, l_FLIGHT_FREQUENCY_NBR, l_TRANSIT_TIME_DAYS
        , l_COLUMN_EK_FMT, l_COLUMN_EK, SYSDATE);
      COMMIT;

      -- TEMPORARY START
      UPDATE HAEMO.XXHA_TRANSPORT_RATES_CALCS TEMP
      SET
          TEMP.COLUMN_ED = l_COLUMN_ED
        , TEMP.COLUMN_EF = l_COLUMN_EF
        , TEMP.COLUMN_EG = l_COLUMN_EG
        , TEMP.COLUMN_EH = l_COLUMN_EH
        , TEMP.COLUMN_EI = l_COLUMN_EI
        , TEMP.COLUMN_EJ = l_COLUMN_EJ
        , TEMP.COLUMN_EK = l_COLUMN_EK
      WHERE
          TEMP.SESSION_ID                             = P_SESSION_ID
      AND TEMP.TRANS_MODE                             = 'AIR'
      AND TEMP.PROVIDER                               = l_PROVIDER
      AND NVL(TEMP.LANE_TYPE, 'XXX')                  = NVL(l_LANE_TYPE, 'XXX')
      AND NVL(TEMP.LANE_ID, 'XXX')                    = NVL(l_LANE_ID, 'XXX')
      AND NVL(TEMP.EQUIPMENT, 'XXX')                  = NVL(l_EQUIPMENT, 'XXX')
      AND NVL(TEMP.SERVICE, 'XXX')                    = NVL(l_SERVICE, 'XXX')
      AND TEMP.ORIGIN_TYPE                            = l_ORIGIN_TYPE
      AND TEMP.SHIPPER_NAME                           = l_SHIPPER_NAME
      AND TEMP.ORIGIN_CITY                            = UPPER(l_ORIGIN_CITY)
      AND NVL(TEMP.ORIGIN_STATE, 'XXX')               = NVL(UPPER(l_ORIGIN_STATE), 'XXX')
      AND TEMP.COSIGNEE_NAME                          = l_COSIGNEE_NAME
      AND TEMP.DESTINATION_CITY                       = UPPER(l_DESTINATION_CITY)
      AND NVL(TEMP.DESTINATION_STATE, 'XXX')          = NVL(UPPER(l_DESTINATION_STATE), 'XXX');
      COMMIT;
      -- TEMPORARY END

   END LOOP;

END XXHA_MULTI_SKID_AIR;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_MULTI_SKID_LCL

PROCEDURE XXHA_MULTI_SKID_LCL (P_SESSION_ID                   IN NUMBER
                             , P_TRANS_MODE                   IN VARCHAR2
                               ) IS

l_TOTAL_COST_NUM                  HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST_NUM%TYPE         := 0;
l_TOTAL_COST                      HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL.TOTAL_COST%TYPE             := NULL;

-- Cursor cur_1000
CURSOR cur_1000(
                P_SESSION_ID      HAEMO.XXHA_TRANSPORT_RATES_CALCS.SESSION_ID%TYPE
              , P_TRANS_MODE      HAEMO.XXHA_TRANSPORT_RATES_CALCS.TRANS_MODE%TYPE
               )
IS
SELECT
    SESSION_ID
  , TRANS_MODE
  , PROVIDER
  , LANE_TYPE
  , LANE_ID
  , ORIGIN_CITY
  , ORIGIN_STATE
  , DESTINATION_CITY
  , DESTINATION_STATE
  , EQUIPMENT
  , SERVICE
  , ORIGIN_TYPE
  , SHIPPER_NAME
  , COSIGNEE_NAME
  , SAIL_DAY_OF_WEEK
  , TOTAL_TRANSIT_DAYS_INLAND
  , TOTAL_TRANSIT_DAYS_OCEAN
  , FLIGHTS_PER_WEEK
  , FLIGHT_FREQUENCY_NBR
  , TRANSIT_TIME_DAYS
  , COLUMN_CV
  , COLUMN_CX
  , COLUMN_CY
FROM 
    HAEMO.XXHA_TRANSPORT_RATES_CALCS XXHA
WHERE
    XXHA.SESSION_ID    = P_SESSION_ID
AND XXHA.TRANS_MODE    = P_TRANS_MODE
ORDER BY
    XXHA.SESSION_ID
  , XXHA.TRANS_MODE
  , XXHA.PROVIDER
  , XXHA.LANE_TYPE
  , XXHA.LANE_ID;

BEGIN

   -- Now Process the data
   FOR recs IN cur_1000(P_SESSION_ID, P_TRANS_MODE)
   LOOP

      -- Take the max of Charge By Weight(l_COLUMN_CY), Charge by Measure(l_COLUMN_CX) or Total Min Charge(l_COLUMN_CV)
      l_TOTAL_COST_NUM := ROUND(GREATEST(recs.COLUMN_CY, recs.COLUMN_CX, recs.COLUMN_CV),0);

      -- Format l_TOTAL_COST_NUM from '123456789012' to '123,456,789,012'
      l_TOTAL_COST := TO_CHAR(l_TOTAL_COST_NUM, '99,999,999,999,999,999,999,999');

      -- Create Record in XXHA_TRANSPORT_RATES_TEMP_TBL
      INSERT INTO HAEMO.XXHA_TRANSPORT_RATES_TEMP_TBL 
         (SESSION_ID, TRANS_MODE, PROVIDER, LANE_TYPE, LANE_ID, EQUIPMENT, SERVICE, ORIGIN_TYPE, SHIPPER_NAME
        , ORIGIN_CITY, ORIGIN_STATE, COSIGNEE_NAME, DESTINATION_CITY, DESTINATION_STATE
        , SAIL_DAY_OF_WEEK, TOTAL_TRANSIT_DAYS_INLAND, TOTAL_TRANSIT_DAYS_OCEAN, FLIGHTS_PER_WEEK, FLIGHT_FREQUENCY_NBR, TRANSIT_TIME_DAYS
        , TOTAL_COST, TOTAL_COST_NUM, CREATION_DATE)
      VALUES
         (P_SESSION_ID, P_TRANS_MODE, recs.PROVIDER, recs.LANE_TYPE, recs.LANE_ID, recs.EQUIPMENT, recs.SERVICE, recs.ORIGIN_TYPE, recs.SHIPPER_NAME
        , UPPER(recs.ORIGIN_CITY), UPPER(recs.ORIGIN_STATE), recs.COSIGNEE_NAME, UPPER(recs.DESTINATION_CITY), UPPER(recs.DESTINATION_STATE)
        , recs.SAIL_DAY_OF_WEEK, recs.TOTAL_TRANSIT_DAYS_INLAND, recs.TOTAL_TRANSIT_DAYS_OCEAN, recs.FLIGHTS_PER_WEEK, recs.FLIGHT_FREQUENCY_NBR, recs.TRANSIT_TIME_DAYS
        , l_TOTAL_COST, l_TOTAL_COST_NUM, SYSDATE);
      COMMIT;

   END LOOP;

END XXHA_MULTI_SKID_LCL;

END XXHA_TRANSPORT_RATES_PKG;