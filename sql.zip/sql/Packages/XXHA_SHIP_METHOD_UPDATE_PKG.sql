create or replace PACKAGE        "XXHA_SHIP_METHOD_UPDATE_PKG" 
  /*******************************************************************************************************
  * Object Name: XXHA_SHIP_METHOD_UPDATE_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package will be used to update order line ship method based on rateshop ID
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    27-AUG-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
AS
 
 PROCEDURE XXHA_SHIP_METHOD_UPDATE_PRC  (P_RATESHOP_ID     IN VARCHAR2,
										 P_SHIPPING_METHOD IN VARCHAR2,
										 P_ERROR_MESSAGE   OUT VARCHAR2);

END XXHA_SHIP_METHOD_UPDATE_PKG;
/

create or replace PACKAGE BODY        "XXHA_SHIP_METHOD_UPDATE_PKG" 
  /*******************************************************************************************************
  * Object Name: XXHA_SHIP_METHOD_UPDATE_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package will be used to update order line ship method based on rateshop ID
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    27-AUG-2015          Initial object creation.
  * Apps Associates    	1.1		  07-OCT-2015		   Modified value for attribute12
  *
  *
  *******************************************************************************************************/
AS
  PROCEDURE XXHA_SHIP_METHOD_UPDATE_PRC(
      P_RATESHOP_ID     IN VARCHAR2,
      P_SHIPPING_METHOD IN VARCHAR2,
      P_ERROR_MESSAGE OUT VARCHAR2)
  AS
    l_user_id NUMBER;
    l_resp_id NUMBER;
    l_appl_id NUMBER;
    l_header_rec_in oe_order_pub.header_rec_type;         -- pl/sql table and record definition to be used as IN parameters
    l_line_tbl_in oe_order_pub.line_tbl_type;             -- pl/sql table and record definition to be used as IN parameters
    l_action_request_tbl_in oe_order_pub.request_tbl_type;-- Used to assigining Book Order related input parameters
    l_header_rec_out oe_order_pub.header_rec_type;        -- pl/sql table and record definition to be used as OUT parameters
    l_line_tbl_out oe_order_pub.line_tbl_type;
    l_header_val_rec_out oe_order_pub.header_val_rec_type;
    l_header_adj_tbl_out oe_order_pub.header_adj_tbl_type;
    l_header_adj_val_tbl_out oe_order_pub.header_adj_val_tbl_type;
    l_header_price_att_tbl_out oe_order_pub.header_price_att_tbl_type;
    l_header_adj_att_tbl_out oe_order_pub.header_adj_att_tbl_type;
    l_header_adj_assoc_tbl_out oe_order_pub.header_adj_assoc_tbl_type;
    l_header_scredit_tbl_out oe_order_pub.header_scredit_tbl_type;
    l_header_scredit_val_tbl_out oe_order_pub.header_scredit_val_tbl_type;
    l_line_val_tbl_out oe_order_pub.line_val_tbl_type;
    l_line_adj_tbl_out oe_order_pub.line_adj_tbl_type;
    l_line_adj_val_tbl_out oe_order_pub.line_adj_val_tbl_type;
    l_line_price_att_tbl_out oe_order_pub.line_price_att_tbl_type;
    l_line_adj_att_tbl_out oe_order_pub.line_adj_att_tbl_type;
    l_line_adj_assoc_tbl_out oe_order_pub.line_adj_assoc_tbl_type;
    l_line_scredit_tbl_out oe_order_pub.line_scredit_tbl_type;
    l_line_scredit_val_tbl_out oe_order_pub.line_scredit_val_tbl_type;
    l_lot_serial_tbl_out oe_order_pub.lot_serial_tbl_type;
    l_lot_serial_val_tbl_out oe_order_pub.lot_serial_val_tbl_type;
    l_action_request_tbl_out oe_order_pub.request_tbl_type;
    l_chr_program_unit_name VARCHAR2 (100);         -- To store the package and procedure name for logging
    l_chr_ret_status        VARCHAR2 (1000) := NULL;-- To store the error message code returned by API
    l_msg_count             NUMBER          := 0;   -- To store the number of error messages API has encountered
    l_msg_data              VARCHAR2 (2000);        -- To store the error message text returned by API
    l_num_api_version       NUMBER := 1.0;          -- API version
    l_ship_method_code FND_LOOKUP_VALUES.lookup_code%type;
    CURSOR c_so_details
    IS
      SELECT OOH.ORDER_NUMBER,
        OOL.*,
        SHIP_METHOD.MEANING OLD_SHIPPING_METHOD
      FROM OE_ORDER_HEADERS_ALL OOH,
        OE_ORDER_LINES_ALL OOL,
        FND_LOOKUP_VALUES SHIP_METHOD
      WHERE 1                      = 1
      AND OOH.HEADER_ID            = OOL.HEADER_ID
      AND ool.cancelled_flag       ='N'
      AND OOl.SHIPPING_METHOD_CODE = SHIP_METHOD.LOOKUP_CODE
      AND SHIP_METHOD.LOOKUP_TYPE  = 'SHIP_METHOD'
      AND SHIP_METHOD.LANGUAGE     = USERENV('LANG')
      AND OOL.ATTRIBUTE10          = P_RATESHOP_ID ;
  BEGIN
    SELECT user_id INTO l_user_id FROM fnd_user WHERE user_name = 'WEBMETHODS'; --'WEBMETHODS'
    SELECT responsibility_id,
      application_id
    INTO l_resp_id,
      l_appl_id
    FROM fnd_responsibility_vl
    WHERE responsibility_name = 'US Order Management Super User OC';
    fnd_global.apps_initialize (l_user_id, l_resp_id, l_appl_id);
    BEGIN
      SELECT LOOKUP_CODE
      INTO l_ship_method_code
      FROM FND_LOOKUP_VALUES LV
      WHERE LANGUAGE  = userenv('LANG')
      AND LOOKUP_TYPE = 'SHIP_METHOD'
      AND meaning     = P_SHIPPING_METHOD;
    EXCEPTION
    WHEN OTHERS THEN
     -- dbms_output.put_line('Error occured while retrieving new ship method code with error: '||SQLERRM);
      P_ERROR_MESSAGE := 'Error occured while retrieving new ship method code '||P_SHIPPING_METHOD||' with error: '||SQLERRM;
    END;
    FOR iso_rec IN c_so_details
    LOOP
     -- IF P_SHIPPING_METHOD <> iso_rec.OLD_SHIPPING_METHOD THEN
        fnd_file.put_line(fnd_file.log,'Loop:Update ship method on order line: '||iso_rec.line_id);
        dbms_output.put_line('Loop:Update ship method on order line: '||iso_rec.line_id);
        l_line_tbl_in (1)                      := oe_order_pub.g_miss_line_rec;
        l_line_tbl_in (1).line_id              := iso_rec.line_id;
        l_line_tbl_in (1).shipping_method_code := l_ship_method_code;
        l_line_tbl_in (1).operation            := oe_globals.g_opr_update;
        l_line_tbl_in(1).attribute12           := 'Completed'; --'PRECISION RESPONSE'; --v1.1 Commented to modify attribute12 value as per change request
        oe_msg_pub.delete_msg;
        mo_global.init ('ONT');
        mo_global.set_policy_context ('S', iso_rec.org_id);
        oe_order_pub.process_order (p_api_version_number => l_num_api_version, p_org_id => mo_global.get_current_org_id, p_init_msg_list => fnd_api.g_false, p_return_values => fnd_api.g_false, p_action_commit => fnd_api.g_false, p_line_tbl => l_line_tbl_in, x_header_rec => l_header_rec_out, x_header_val_rec => l_header_val_rec_out, x_header_adj_tbl => l_header_adj_tbl_out, x_header_adj_val_tbl => l_header_adj_val_tbl_out, x_header_price_att_tbl => l_header_price_att_tbl_out, x_header_adj_att_tbl => l_header_adj_att_tbl_out, x_header_adj_assoc_tbl => l_header_adj_assoc_tbl_out, x_header_scredit_tbl => l_header_scredit_tbl_out, x_header_scredit_val_tbl=> l_header_scredit_val_tbl_out, x_line_tbl => l_line_tbl_out, x_line_val_tbl => l_line_val_tbl_out, x_line_adj_tbl => l_line_adj_tbl_out, x_line_adj_val_tbl => l_line_adj_val_tbl_out, x_line_price_att_tbl => l_line_price_att_tbl_out, x_line_adj_att_tbl => l_line_adj_att_tbl_out, x_line_adj_assoc_tbl => l_line_adj_assoc_tbl_out,
        x_line_scredit_tbl => l_line_scredit_tbl_out, x_line_scredit_val_tbl => l_line_scredit_val_tbl_out, x_lot_serial_tbl => l_lot_serial_tbl_out, x_lot_serial_val_tbl => l_lot_serial_val_tbl_out, x_action_request_tbl => l_action_request_tbl_out, x_return_status => l_chr_ret_status, x_msg_count => l_msg_count, x_msg_data => l_msg_data);
        l_msg_data          := NULL;
        IF l_chr_ret_status <> 'S' THEN
          FOR iindx IN 1 .. l_msg_count
          LOOP
            NULL;
            -- l_msg_data := l_msg_data||'.'oe_msg_pub.get (iindx);
          END LOOP;
        END IF;
        /*   DBMS_OUTPUT.ENABLE (10000);
        fnd_file.put_line(fnd_file.log,'Sales Order => '|| iso_rec.order_number ||' - Line Number => '|| iso_rec.line_number|| ' - Old Shipping Method => '|| iso_rec.old_shipping_method|| ' Having Line ID=> '|| iso_rec.line_id ||' is updated successfully with new shipping method=>' || P_SHIPPING_METHOD);
        fnd_file.put_line(fnd_file.log,'Return Status: '|| l_chr_ret_status);
        fnd_file.put_line(fnd_file.log,'Error Message: '|| l_msg_data);
        dbms_output.put_line('Sales Order => '|| iso_rec.order_number ||' - Line Number => '|| iso_rec.line_number|| ' - Old Shipping Method => '|| iso_rec.old_shipping_method|| ' Having Line ID=> '|| iso_rec.line_id ||' is updated successfully with new shipping method=>' || P_SHIPPING_METHOD);
        dbms_output.put_line('Return Status: '|| l_chr_ret_status);
        dbms_output.put_line('Error Message: '|| l_msg_data);*/
        IF l_msg_data     IS NOT NULL THEN
          P_ERROR_MESSAGE := P_ERROR_MESSAGE ||','|| l_msg_data;
        END IF;
      --END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
  WHEN OTHERS THEN
    /*   fnd_file.put_line(fnd_file.log,'Exception Occured :');
    fnd_file.put_line(fnd_file.log,SQLCODE ||':'||SQLERRM);
    fnd_file.put_line(fnd_file.log,'=======================================================');
    dbms_output.put_line('Exception Occured :');
    dbms_output.put_line(SQLCODE ||':'||SQLERRM);
    dbms_output.put_line('=======================================================');*/
    P_ERROR_MESSAGE := P_ERROR_MESSAGE ||','|| SQLCODE ||':'||SQLERRM;
  END;
END ;
/