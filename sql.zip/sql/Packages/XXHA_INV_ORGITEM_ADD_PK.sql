CREATE OR REPLACE PACKAGE        "XXHA_INV_ORGITEM_ADD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_INV_ORGITEM_ADD_PK                                   |
-- | Description  : The Incremental Item Add utility comprises multiple       |
-- |                components to assign items already defined in the master  |
-- |                org to individual inventory organizations.                |
-- |                 . Component 1 loads a staging table with rows that       |
-- |                   identify the target inventory item and orgs.  It is    |
-- |                   also responsible for cleanup of the staging table once |
-- |                   records have been processed.                           |
-- |                 . Component 2 populates the Oracle supplied seeded       |
-- |                   interface tables used for importing items.  Records    |
-- |                   are prevalidated prior to interfacing and the source   |
-- |                   staged records are flagged as they are processed       |
-- |                 . Component 3 is the standard Import Items concurrent    |
-- |                   program.                                               |
-- |                All 3 component are requested separately, so submission   |
-- |                is fully under user control. Another peripheral component |
-- |                is the common error reporting utility.                    |
-- | Purpose      : This package implements the Component 2 only.             |
-- | Invoked by   : Concurrent program XXHA_ORGITEM_ADD
-- |                                                                          |
-- |Change Record:                                                            |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  06-Jun-07   OCS            Initial release                           |
-- +==========================================================================+
as

---------------------------------------------------------------
-- Main executable routine for interfacing the seeded tables in
-- preparation for item import
---------------------------------------------------------------
procedure interface_org_items (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_debug  in  varchar2
        ,p_purge_errors  in  varchar2
        );

end XXHA_INV_ORGITEM_ADD_PK;

/


CREATE OR REPLACE PACKAGE BODY        "XXHA_INV_ORGITEM_ADD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_INV_ORGITEM_ADD_PK                                   |
-- | Description  : This package implements the 2nd component of the          |
-- |                Incremental Item Add utility which takes master inventory |
-- |                items and assigns them to inventory orgs based on target  |
-- |                organizations identified in a staging table.              |
-- |                A more complete description of the utility can be found   |
-- |                in the package specification.                             |
-- | Invoked by   : Concurrent executable XXHA_ORGITEM_ADD
-- |                                                                          |
-- |Change Record:                                                            |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  06-Jun-07   OCS            Initial release                           |
-- +==========================================================================+
as

-------------------------------------
-- Global Variables Declaration
-------------------------------------
e_abort  exception;
e_skip_item  exception;

gd_today  date := sysdate;
gc_program_name  varchar2(50) := 'XXHA_ORGITEM_ADD';       --Program Name In parameter for launch_error_prc procedure
gc_rec_identifier  varchar2(50) := 'Item No/Org';          --Record identifier In parameter for launch_error_prc procedure
gc_debug_flag  VARCHAR2(1);                                --Debug_flag for display debug
gc_log_msg  VARCHAR2(1000);                                --Log_msg to display msgs

gn_request_id            xxha_common_errors.request_id%TYPE := fnd_global.conc_request_id;--Request Id of running concurrent Program
gn_record_number         xxha_common_errors.record_number%TYPE;                   --Record_number of staging table
gc_record_identifier     xxha_common_errors.record_identifier%TYPE;               --Record identifier of staging table
gc_error_code            xxha_common_errors.error_code%TYPE;                      --Error_code insert in common error table
gc_error_msg             xxha_common_errors.error_msg%TYPE;                       --Error_msg  insert in common error table
gc_comments              xxha_common_errors.comments%TYPE;                        --Comments   insert in common error table
gc_table_name            xxha_common_errors.table_name%TYPE := 'HAEMO_ITEM_ADD';  --Variable to get Staging Table Name
gc_attribute1            xxha_common_errors.attribute1%TYPE;                      --Attribute1 insert in common error table
gc_attribute2            xxha_common_errors.attribute2%TYPE;                      --Attribute2 insert in common error table
gc_attribute3            xxha_common_errors.attribute3%TYPE;                      --Attribute3 insert in common error table
gc_attribute4            xxha_common_errors.attribute4%TYPE;                      --Attribute4 insert in common error table
gc_attribute5            xxha_common_errors.attribute5%TYPE;                      --Attribute5 insert in common error table
gc_status                VARCHAR2(2);                                             --Variable to get status flag of data insertion in common error table
gc_error_report          VARCHAR2(1) := 'N';                    --Error_report launch if its <> 'N'

gc_conc_name             fnd_concurrent_programs.concurrent_program_name%TYPE := 'XXHA_ORGITEM_ADD';   --Concurrent program name to delete the records from common error table
gn_coa_id                gl_sets_of_books.chart_of_accounts_id%type;

gc_material_sub_element  bom_resources.resource_code%TYPE                     := 'Material';           --Material Sub Element
gc_master_org            mtl_parameters.organization_code%TYPE                := 'MST';                --Master Organization Name
gc_process_flag          mtl_system_items_interface.process_flag%TYPE         := '1';                  --Default process_flag
gc_set_proc_id_mst       mtl_system_items_interface.set_process_id%TYPE       := 1;                    --Variable to get set process id for Master Inventory Org
gc_set_proc_id_child     mtl_system_items_interface.set_process_id%TYPE       := 2;                    --Variable to get set process id for Child Inventory Orgs
gc_trans_type_create     mtl_system_items_interface.transaction_type%TYPE     := 'CREATE';             --Default transaction_type

cursor gcu_stg is
  select  hia.*
         ,hia.oracleintfld1  organization_id
         ,hia.oracleintfld2  inventory_item_id
         ,hia.oraclecharfld2  product_line
         ,to_number(null)  cos_ccid
         ,to_number(null)  sales_ccid
         ,to_number(null)  expense_ccid
  from    haemo_item_add  hia
  where   oraclecharfld1 is null;
gr_stg_rec  gcu_stg%rowtype;

gr_msi_rec  mtl_system_items_b%rowtype;

---------------------------------------------------------------
-- Procedure to log errors using XXHA_COMMON_UTILITIES_PKG
---------------------------------------------------------------
procedure INSERT_ERROR_PRC
          is
begin
  gc_error_report:='Y';
  xxha_common_utilities_pkg.insert_error_prc(
              gn_request_id
             ,gn_record_number
             ,gc_record_identifier
             ,gc_error_code
             ,gc_error_msg
             ,gc_comments
             ,gc_table_name
             ,gc_attribute1
             ,gc_attribute2
             ,gc_attribute3
             ,gc_attribute4
             ,gc_attribute5
             ,gc_status
             );

exception
  when others then
     fnd_file.put_line(fnd_file.log,'Error in XXHA_INV_ITEM_CONV_PK.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
end INSERT_ERROR_PRC;

---------------------------------------------------------------
-- Procedure to log validation failures to be reported
---------------------------------------------------------------
procedure LOG_VALIDATION_FAILURES
          is
  -- Cursor for staged records which failed preliminary validation
  cursor lcu_err is
    select  *
    from    haemo_item_add
    where   oracleintfld8 = gn_request_id
    and     oraclecharfld8 is not null  -- error code
    order by oraclecharfld8;

begin
   for err_rec in lcu_err
   loop
      gc_record_identifier := err_rec.itemnbr||'/'||err_rec.invorg;
      gn_record_number := err_rec.oracleidentifier;

      gc_comments := null;
      gc_error_code := err_rec.oraclecharfld8;
      if (gc_error_code = 'SETUP-002') then
         gc_error_msg := 'Parameters for Organization '||err_rec.invorg||' have not been set up.';
      elsif (gc_error_code = 'SETUP-003') then
         gc_error_msg := 'Zero Cost flag (DFF Attribute6) is not set for Organization '||err_rec.invorg;
      elsif (gc_error_code = 'SETUP-004') then
         gc_error_msg := gc_material_sub_element||' Sub Element is not set for Organization '||err_rec.invorg;
      elsif (gc_error_code = 'SETUP-005') then
         gc_error_msg := 'Item '||err_rec.itemnbr||' is not yet assigned to the Master Organization';
      elsif (gc_error_code = 'SETUP-006') then
         gc_error_msg := 'Product Line DFF for item '||err_rec.itemnbr||' is not set.';
      end if;
      insert_error_prc;

      commit;
   end loop;

end LOG_VALIDATION_FAILURES;

---------------------------------------------------------------
-- Procedure to populate the Items Interface table
---------------------------------------------------------------
procedure LOAD_ITEM_INTERFACE
          is
begin
   insert into mtl_system_items_interface (
          acceptable_early_days
         ,acceptable_rate_decrease
         ,accounting_rule_id
         ,allow_express_delivery_flag
         ,allow_item_desc_update_flag
         ,allow_substitute_receipts_flag
         ,allow_unordered_receipts_flag
         ,allowed_units_lookup_code
         ,asn_autoexpire_flag
         ,asset_category_id
         ,asset_creation_code
         ,ato_forecast_control
         ,atp_components_flag
         ,atp_flag
         ,atp_rule_id
         ,attribute_category
         ,attribute1
         ,attribute10
         ,attribute11
         ,attribute12
         ,attribute13
         ,attribute14
         ,attribute15
         ,attribute2
         ,attribute3
         ,attribute4
         ,attribute5
         ,attribute6
         ,attribute7
         ,attribute8
         ,attribute9
         ,auto_created_config_flag
         ,auto_lot_alpha_prefix
         ,auto_reduce_mps
         ,auto_serial_alpha_prefix
         ,back_orderable_flag
         ,base_item_id
         ,base_warranty_service_id
         ,bom_enabled_flag
         ,bom_item_type
         ,build_in_wip_flag
         ,buyer_id
         ,carrying_cost
         ,catalog_status_flag
         ,check_shortages_flag
         ,collateral_flag
         ,comms_activation_reqd_flag
         ,comms_nl_trackable_flag
         ,config_match
         ,config_model_type
         ,config_orgs
         ,consigned_flag
         ,container_item_flag
         ,container_type_code
         ,continous_transfer
         ,contract_item_type_code
         ,convergence
         ,cost_of_sales_account
         ,costing_enabled_flag
         ,coupon_exempt_flag
         ,coverage_schedule_id
         ,create_supply_flag
         ,created_by
         ,creation_date
         ,critical_component_flag
         ,cum_manufacturing_lead_time
         ,cumulative_total_lead_time
         ,current_phase_id
         ,customer_order_enabled_flag
         ,customer_order_flag
         ,cycle_count_enabled_flag
         ,days_early_receipt_allowed
         ,days_late_receipt_allowed
         ,days_max_inv_supply
         ,days_max_inv_window
         ,days_tgt_inv_supply
         ,days_tgt_inv_window
         ,default_include_in_rollup_flag
         ,default_lot_status_id
         ,default_serial_status_id
         ,default_shipping_org
         ,default_so_source_type
         ,defect_tracking_on_flag
         ,demand_time_fence_code
         ,demand_time_fence_days
         ,description
         ,dimension_uom_code
         ,divergence
         ,downloadable_flag
         ,drp_planned_flag
         ,dual_uom_control
         ,dual_uom_deviation_high
         ,dual_uom_deviation_low
         ,eam_act_notification_flag
         ,eam_act_shutdown_status
         ,eam_activity_cause_code
         ,eam_activity_source_code
         ,eam_activity_type_code
         ,eam_item_type
         ,effectivity_control
         ,electronic_flag
         ,enabled_flag
         ,encumbrance_account
         ,end_assembly_pegging_flag
         ,end_date_active
         ,eng_item_flag
         ,engineering_date
         ,engineering_ecn_code
         ,engineering_item_id
         ,equipment_type
         ,event_flag
         ,exclude_from_budget_flag
         ,expense_account
         ,expense_billable_flag
         ,financing_allowed_flag
         ,fixed_days_supply
         ,fixed_lead_time
         ,fixed_lot_multiplier
         ,fixed_order_quantity
         ,forecast_horizon
         ,full_lead_time
         ,global_attribute_category
         ,global_attribute1
         ,global_attribute10
         ,global_attribute2
         ,global_attribute3
         ,global_attribute4
         ,global_attribute5
         ,global_attribute6
         ,global_attribute7
         ,global_attribute8
         ,global_attribute9
         ,hazard_class_id
         ,ib_item_instance_class
         ,indivisible_flag
         ,inspection_required_flag
         ,internal_order_enabled_flag
         ,internal_order_flag
         ,internal_volume
         ,inventory_asset_flag
         ,inventory_carry_penalty
         ,inventory_item_flag
         ,inventory_item_id
         ,inventory_item_status_code
         ,inventory_planning_code
         ,invoice_close_tolerance
         ,invoice_enabled_flag
         ,invoiceable_item_flag
         ,invoicing_rule_id
         ,item_catalog_group_id
         ,item_type
         ,last_update_date
         ,last_update_login
         ,last_updated_by
         ,lead_time_lot_size
         ,lifecycle_id
         ,list_price_per_unit
         ,location_control_code
         ,lot_control_code
         ,lot_merge_enabled
         ,lot_split_enabled
         ,lot_status_enabled
         ,lot_substitution_enabled
         ,lot_translate_enabled
         ,market_price
         ,material_billable_flag
         ,max_minmax_quantity
         ,max_warranty_amount
         ,maximum_load_weight
         ,maximum_order_quantity
         ,min_minmax_quantity
         ,minimum_fill_percent
         ,minimum_license_quantity
         ,minimum_order_quantity
         ,model_config_clause_name
         ,mrp_calculate_atp_flag
         ,mrp_planning_code
         ,mrp_safety_stock_code
         ,mrp_safety_stock_percent
         ,mtl_transactions_enabled_flag
         ,must_use_approved_vendor_flag
         ,negative_measurement_error
         ,new_revision_code
         ,ont_pricing_qty_source
         ,operation_slack_penalty
         ,order_cost
         ,orderable_on_web_flag
         ,organization_id
         ,outside_operation_flag
         ,outside_operation_uom_type
         ,over_return_tolerance
         ,over_shipment_tolerance
         ,overcompletion_tolerance_type
         ,overcompletion_tolerance_value
         ,overrun_percentage
         ,payment_terms_id
         ,pick_components_flag
         ,picking_rule_id
         ,planned_inv_point_flag
         ,planner_code
         ,planning_exception_set
         ,planning_make_buy_code
         ,planning_time_fence_code
         ,planning_time_fence_days
         ,positive_measurement_error
         ,postprocessing_lead_time
         ,preprocessing_lead_time
         ,preventive_maintenance_flag
         ,price_tolerance_percent
         ,primary_specialist_id
         ,primary_unit_of_measure
         ,primary_uom_code
         ,product_family_item_id
         ,program_application_id
         ,program_id
         ,program_update_date
         ,prorate_service_flag
         ,purchasing_enabled_flag
         ,purchasing_item_flag
         ,purchasing_tax_code
         ,qty_rcv_exception_code
         ,qty_rcv_tolerance
         ,receipt_days_exception_code
         ,receipt_required_flag
         ,receive_close_tolerance
         ,receiving_routing_id
         ,recovered_part_disp_code
         ,release_time_fence_code
         ,release_time_fence_days
         ,repetitive_planning_flag
         ,replenish_to_order_flag
         ,request_id
         ,reservable_type
         ,response_time_period_code
         ,response_time_value
         ,restrict_locators_code
         ,restrict_subinventories_code
         ,return_inspection_requirement
         ,returnable_flag
         ,revision_qty_control_code
         ,rfq_required_flag
         ,rounding_control_type
         ,rounding_factor
         ,safety_stock_bucket_days
         ,sales_account
         ,secondary_default_ind
         ,secondary_specialist_id
         ,secondary_uom_code
         ,segment1
         ,segment10
         ,segment11
         ,segment12
         ,segment13
         ,segment14
         ,segment15
         ,segment16
         ,segment17
         ,segment18
         ,segment19
         ,segment2
         ,segment20
         ,segment3
         ,segment4
         ,segment5
         ,segment6
         ,segment7
         ,segment8
         ,segment9
         ,serial_number_control_code
         ,serial_status_enabled
         ,serv_billing_enabled_flag
         ,serv_importance_level
         ,serv_req_enabled_code
         ,service_duration
         ,service_duration_period_code
         ,service_item_flag
         ,service_starting_delay
         ,serviceable_component_flag
         ,serviceable_item_class_id
         ,serviceable_product_flag
         ,shelf_life_code
         ,shelf_life_days
         ,ship_model_complete_flag
         ,shippable_item_flag
         ,shrinkage_rate
         ,so_authorization_flag
         ,so_transactions_flag
         ,source_organization_id
         ,source_subinventory
         ,source_type
         ,start_auto_lot_number
         ,start_auto_serial_number
         ,start_date_active
         ,std_lot_size
         ,stock_enabled_flag
         ,subscription_depend_flag
         ,substitution_window_code
         ,substitution_window_days
         ,summary_flag
         ,tax_code
         ,taxable_flag
         ,time_billable_flag
         ,tracking_quantity_ind
         ,un_number_id
         ,under_return_tolerance
         ,under_shipment_tolerance
         ,unit_height
         ,unit_length
         ,unit_of_issue
         ,unit_volume
         ,unit_weight
         ,unit_width
         ,usage_item_flag
         ,variable_lead_time
         ,vehicle_item_flag
         ,vendor_warranty_flag
         ,vmi_fixed_order_quantity
         ,vmi_forecast_type
         ,vmi_maximum_days
         ,vmi_maximum_units
         ,vmi_minimum_days
         ,vmi_minimum_units
         ,vol_discount_exempt_flag
         ,volume_uom_code
         ,warranty_vendor_id
         ,web_status
         ,weight_uom_code
         ,wh_update_date
         ,wip_supply_locator_id
         ,wip_supply_subinventory
         ,wip_supply_type
         ,set_process_id
         ,process_flag
         ,transaction_type
         ,material_cost
         ,material_sub_elem
         )
   values (
          gr_msi_rec.acceptable_early_days
         ,gr_msi_rec.acceptable_rate_decrease
         ,gr_msi_rec.accounting_rule_id
         ,gr_msi_rec.allow_express_delivery_flag
         ,gr_msi_rec.allow_item_desc_update_flag
         ,gr_msi_rec.allow_substitute_receipts_flag
         ,gr_msi_rec.allow_unordered_receipts_flag
         ,gr_msi_rec.allowed_units_lookup_code
         ,gr_msi_rec.asn_autoexpire_flag
         ,gr_msi_rec.asset_category_id
         ,gr_msi_rec.asset_creation_code
         ,gr_msi_rec.ato_forecast_control
         ,gr_msi_rec.atp_components_flag
         ,gr_msi_rec.atp_flag
         ,gr_msi_rec.atp_rule_id
         ,gr_msi_rec.attribute_category
         ,gr_msi_rec.attribute1
         ,gr_msi_rec.attribute10
         ,gr_msi_rec.attribute11
         ,gr_msi_rec.attribute12
         ,gr_msi_rec.attribute13
         ,gr_msi_rec.attribute14
         ,gr_msi_rec.attribute15
         ,gr_msi_rec.attribute2
         ,gr_msi_rec.attribute3
         ,gr_msi_rec.attribute4
         ,gr_msi_rec.attribute5
         ,gr_msi_rec.attribute6
         ,gr_msi_rec.attribute7
         ,gr_msi_rec.attribute8
         ,gr_msi_rec.attribute9
         ,gr_msi_rec.auto_created_config_flag
         ,gr_msi_rec.auto_lot_alpha_prefix
         ,gr_msi_rec.auto_reduce_mps
         ,gr_msi_rec.auto_serial_alpha_prefix
         ,gr_msi_rec.back_orderable_flag
         ,gr_msi_rec.base_item_id
         ,gr_msi_rec.base_warranty_service_id
         ,gr_msi_rec.bom_enabled_flag
         ,gr_msi_rec.bom_item_type
         ,gr_msi_rec.build_in_wip_flag
         ,gr_msi_rec.buyer_id
         ,gr_msi_rec.carrying_cost
         ,gr_msi_rec.catalog_status_flag
         ,gr_msi_rec.check_shortages_flag
         ,gr_msi_rec.collateral_flag
         ,gr_msi_rec.comms_activation_reqd_flag
         ,gr_msi_rec.comms_nl_trackable_flag
         ,gr_msi_rec.config_match
         ,gr_msi_rec.config_model_type
         ,gr_msi_rec.config_orgs
         ,gr_msi_rec.consigned_flag
         ,gr_msi_rec.container_item_flag
         ,gr_msi_rec.container_type_code
         ,gr_msi_rec.continous_transfer
         ,gr_msi_rec.contract_item_type_code
         ,gr_msi_rec.convergence
         ,gr_stg_rec.cos_ccid                   -- cost_of_sales_account
         ,gr_msi_rec.costing_enabled_flag
         ,gr_msi_rec.coupon_exempt_flag
         ,gr_msi_rec.coverage_schedule_id
         ,gr_msi_rec.create_supply_flag
         ,fnd_global.user_id                    -- created_by
         ,gd_today                              -- creation_date
         ,gr_msi_rec.critical_component_flag
         ,gr_msi_rec.cum_manufacturing_lead_time
         ,gr_msi_rec.cumulative_total_lead_time
         ,gr_msi_rec.current_phase_id
         ,gr_msi_rec.customer_order_enabled_flag
         ,gr_msi_rec.customer_order_flag
         ,gr_msi_rec.cycle_count_enabled_flag
         ,gr_msi_rec.days_early_receipt_allowed
         ,gr_msi_rec.days_late_receipt_allowed
         ,gr_msi_rec.days_max_inv_supply
         ,gr_msi_rec.days_max_inv_window
         ,gr_msi_rec.days_tgt_inv_supply
         ,gr_msi_rec.days_tgt_inv_window
         ,gr_msi_rec.default_include_in_rollup_flag
         ,gr_msi_rec.default_lot_status_id
         ,gr_msi_rec.default_serial_status_id
         ,gr_msi_rec.default_shipping_org
         ,gr_msi_rec.default_so_source_type
         ,gr_msi_rec.defect_tracking_on_flag
         ,gr_msi_rec.demand_time_fence_code
         ,gr_msi_rec.demand_time_fence_days
         ,gr_msi_rec.description
         ,gr_msi_rec.dimension_uom_code
         ,gr_msi_rec.divergence
         ,gr_msi_rec.downloadable_flag
         ,gr_msi_rec.drp_planned_flag
         ,gr_msi_rec.dual_uom_control
         ,gr_msi_rec.dual_uom_deviation_high
         ,gr_msi_rec.dual_uom_deviation_low
         ,gr_msi_rec.eam_act_notification_flag
         ,gr_msi_rec.eam_act_shutdown_status
         ,gr_msi_rec.eam_activity_cause_code
         ,gr_msi_rec.eam_activity_source_code
         ,gr_msi_rec.eam_activity_type_code
         ,gr_msi_rec.eam_item_type
         ,gr_msi_rec.effectivity_control
         ,gr_msi_rec.electronic_flag
         ,gr_msi_rec.enabled_flag
         ,gr_msi_rec.encumbrance_account
         ,gr_msi_rec.end_assembly_pegging_flag
         ,gr_msi_rec.end_date_active
         ,gr_msi_rec.eng_item_flag
         ,gr_msi_rec.engineering_date
         ,gr_msi_rec.engineering_ecn_code
         ,gr_msi_rec.engineering_item_id
         ,gr_msi_rec.equipment_type
         ,gr_msi_rec.event_flag
         ,gr_msi_rec.exclude_from_budget_flag
         ,gr_stg_rec.expense_ccid               -- expense_account
         ,gr_msi_rec.expense_billable_flag
         ,gr_msi_rec.financing_allowed_flag
         ,gr_msi_rec.fixed_days_supply
         ,gr_msi_rec.fixed_lead_time
         ,gr_msi_rec.fixed_lot_multiplier
         ,gr_msi_rec.fixed_order_quantity
         ,gr_msi_rec.forecast_horizon
         ,gr_msi_rec.full_lead_time
         ,gr_msi_rec.global_attribute_category
         ,gr_msi_rec.global_attribute1
         ,gr_msi_rec.global_attribute10
         ,gr_msi_rec.global_attribute2
         ,gr_msi_rec.global_attribute3
         ,gr_msi_rec.global_attribute4
         ,gr_msi_rec.global_attribute5
         ,gr_msi_rec.global_attribute6
         ,gr_msi_rec.global_attribute7
         ,gr_msi_rec.global_attribute8
         ,gr_msi_rec.global_attribute9
         ,gr_msi_rec.hazard_class_id
         ,gr_msi_rec.ib_item_instance_class
         ,gr_msi_rec.indivisible_flag
         ,gr_msi_rec.inspection_required_flag
         ,gr_msi_rec.internal_order_enabled_flag
         ,gr_msi_rec.internal_order_flag
         ,gr_msi_rec.internal_volume
         ,gr_msi_rec.inventory_asset_flag
         ,gr_msi_rec.inventory_carry_penalty
         ,gr_msi_rec.inventory_item_flag
         ,gr_msi_rec.inventory_item_id
         ,gr_msi_rec.inventory_item_status_code
         ,gr_msi_rec.inventory_planning_code
         ,gr_msi_rec.invoice_close_tolerance
         ,gr_msi_rec.invoice_enabled_flag
         ,gr_msi_rec.invoiceable_item_flag
         ,gr_msi_rec.invoicing_rule_id
         ,gr_msi_rec.item_catalog_group_id
         ,gr_msi_rec.item_type
         ,gd_today                              -- last_update_date
         ,null                                  -- last_update_login
         ,fnd_global.user_id                    -- last_updated_by
         ,gr_msi_rec.lead_time_lot_size
         ,gr_msi_rec.lifecycle_id
         ,gr_msi_rec.list_price_per_unit
         ,gr_msi_rec.location_control_code
         ,gr_msi_rec.lot_control_code
         ,gr_msi_rec.lot_merge_enabled
         ,gr_msi_rec.lot_split_enabled
         ,gr_msi_rec.lot_status_enabled
         ,gr_msi_rec.lot_substitution_enabled
         ,gr_msi_rec.lot_translate_enabled
         ,gr_msi_rec.market_price
         ,gr_msi_rec.material_billable_flag
         ,gr_msi_rec.max_minmax_quantity
         ,gr_msi_rec.max_warranty_amount
         ,gr_msi_rec.maximum_load_weight
         ,gr_msi_rec.maximum_order_quantity
         ,gr_msi_rec.min_minmax_quantity
         ,gr_msi_rec.minimum_fill_percent
         ,gr_msi_rec.minimum_license_quantity
         ,gr_msi_rec.minimum_order_quantity
         ,gr_msi_rec.model_config_clause_name
         ,gr_msi_rec.mrp_calculate_atp_flag
         ,gr_msi_rec.mrp_planning_code
         ,gr_msi_rec.mrp_safety_stock_code
         ,gr_msi_rec.mrp_safety_stock_percent
         ,gr_msi_rec.mtl_transactions_enabled_flag
         ,gr_msi_rec.must_use_approved_vendor_flag
         ,gr_msi_rec.negative_measurement_error
         ,gr_msi_rec.new_revision_code
         ,gr_msi_rec.ont_pricing_qty_source
         ,gr_msi_rec.operation_slack_penalty
         ,gr_msi_rec.order_cost
         ,gr_msi_rec.orderable_on_web_flag
         ,gr_stg_rec.organization_id            -- organization_id
         ,gr_msi_rec.outside_operation_flag
         ,gr_msi_rec.outside_operation_uom_type
         ,gr_msi_rec.over_return_tolerance
         ,gr_msi_rec.over_shipment_tolerance
         ,gr_msi_rec.overcompletion_tolerance_type
         ,gr_msi_rec.overcompletion_tolerance_value
         ,gr_msi_rec.overrun_percentage
         ,gr_msi_rec.payment_terms_id
         ,gr_msi_rec.pick_components_flag
         ,gr_msi_rec.picking_rule_id
         ,gr_msi_rec.planned_inv_point_flag
         ,gr_msi_rec.planner_code
         ,gr_msi_rec.planning_exception_set
         ,gr_msi_rec.planning_make_buy_code
         ,gr_msi_rec.planning_time_fence_code
         ,gr_msi_rec.planning_time_fence_days
         ,gr_msi_rec.positive_measurement_error
         ,gr_msi_rec.postprocessing_lead_time
         ,gr_msi_rec.preprocessing_lead_time
         ,gr_msi_rec.preventive_maintenance_flag
         ,gr_msi_rec.price_tolerance_percent
         ,gr_msi_rec.primary_specialist_id
         ,gr_msi_rec.primary_unit_of_measure
         ,gr_msi_rec.primary_uom_code
         ,gr_msi_rec.product_family_item_id
         ,gr_msi_rec.program_application_id
         ,gr_msi_rec.program_id
         ,gr_msi_rec.program_update_date
         ,gr_msi_rec.prorate_service_flag
         ,gr_msi_rec.purchasing_enabled_flag
         ,gr_msi_rec.purchasing_item_flag
         ,gr_msi_rec.purchasing_tax_code
         ,gr_msi_rec.qty_rcv_exception_code
         ,gr_msi_rec.qty_rcv_tolerance
         ,gr_msi_rec.receipt_days_exception_code
         ,gr_msi_rec.receipt_required_flag
         ,gr_msi_rec.receive_close_tolerance
         ,gr_msi_rec.receiving_routing_id
         ,gr_msi_rec.recovered_part_disp_code
         ,gr_msi_rec.release_time_fence_code
         ,gr_msi_rec.release_time_fence_days
         ,gr_msi_rec.repetitive_planning_flag
         ,gr_msi_rec.replenish_to_order_flag
         ,gr_msi_rec.request_id
         ,gr_msi_rec.reservable_type
         ,gr_msi_rec.response_time_period_code
         ,gr_msi_rec.response_time_value
         ,gr_msi_rec.restrict_locators_code
         ,gr_msi_rec.restrict_subinventories_code
         ,gr_msi_rec.return_inspection_requirement
         ,gr_msi_rec.returnable_flag
         ,gr_msi_rec.revision_qty_control_code
         ,gr_msi_rec.rfq_required_flag
         ,gr_msi_rec.rounding_control_type
         ,gr_msi_rec.rounding_factor
         ,gr_msi_rec.safety_stock_bucket_days
         ,gr_stg_rec.sales_ccid                 -- sales_account
         ,gr_msi_rec.secondary_default_ind
         ,gr_msi_rec.secondary_specialist_id
         ,gr_msi_rec.secondary_uom_code
         ,gr_msi_rec.segment1
         ,gr_msi_rec.segment10
         ,gr_msi_rec.segment11
         ,gr_msi_rec.segment12
         ,gr_msi_rec.segment13
         ,gr_msi_rec.segment14
         ,gr_msi_rec.segment15
         ,gr_msi_rec.segment16
         ,gr_msi_rec.segment17
         ,gr_msi_rec.segment18
         ,gr_msi_rec.segment19
         ,gr_msi_rec.segment2
         ,gr_msi_rec.segment20
         ,gr_msi_rec.segment3
         ,gr_msi_rec.segment4
         ,gr_msi_rec.segment5
         ,gr_msi_rec.segment6
         ,gr_msi_rec.segment7
         ,gr_msi_rec.segment8
         ,gr_msi_rec.segment9
         ,gr_msi_rec.serial_number_control_code
         ,gr_msi_rec.serial_status_enabled
         ,gr_msi_rec.serv_billing_enabled_flag
         ,gr_msi_rec.serv_importance_level
         ,gr_msi_rec.serv_req_enabled_code
         ,gr_msi_rec.service_duration
         ,gr_msi_rec.service_duration_period_code
         ,gr_msi_rec.service_item_flag
         ,gr_msi_rec.service_starting_delay
         ,gr_msi_rec.serviceable_component_flag
         ,gr_msi_rec.serviceable_item_class_id
         ,gr_msi_rec.serviceable_product_flag
         ,gr_msi_rec.shelf_life_code
         ,gr_msi_rec.shelf_life_days
         ,gr_msi_rec.ship_model_complete_flag
         ,gr_msi_rec.shippable_item_flag
         ,gr_msi_rec.shrinkage_rate
         ,gr_msi_rec.so_authorization_flag
         ,gr_msi_rec.so_transactions_flag
         ,gr_msi_rec.source_organization_id
         ,gr_msi_rec.source_subinventory
         ,gr_msi_rec.source_type
         ,gr_msi_rec.start_auto_lot_number
         ,gr_msi_rec.start_auto_serial_number
         ,gr_msi_rec.start_date_active
         ,gr_msi_rec.std_lot_size
         ,gr_msi_rec.stock_enabled_flag
         ,gr_msi_rec.subscription_depend_flag
         ,gr_msi_rec.substitution_window_code
         ,gr_msi_rec.substitution_window_days
         ,gr_msi_rec.summary_flag
         ,gr_msi_rec.tax_code
         ,gr_msi_rec.taxable_flag
         ,gr_msi_rec.time_billable_flag
         ,gr_msi_rec.tracking_quantity_ind
         ,gr_msi_rec.un_number_id
         ,gr_msi_rec.under_return_tolerance
         ,gr_msi_rec.under_shipment_tolerance
         ,gr_msi_rec.unit_height
         ,gr_msi_rec.unit_length
         ,gr_msi_rec.unit_of_issue
         ,gr_msi_rec.unit_volume
         ,gr_msi_rec.unit_weight
         ,gr_msi_rec.unit_width
         ,gr_msi_rec.usage_item_flag
         ,gr_msi_rec.variable_lead_time
         ,gr_msi_rec.vehicle_item_flag
         ,gr_msi_rec.vendor_warranty_flag
         ,gr_msi_rec.vmi_fixed_order_quantity
         ,gr_msi_rec.vmi_forecast_type
         ,gr_msi_rec.vmi_maximum_days
         ,gr_msi_rec.vmi_maximum_units
         ,gr_msi_rec.vmi_minimum_days
         ,gr_msi_rec.vmi_minimum_units
         ,gr_msi_rec.vol_discount_exempt_flag
         ,gr_msi_rec.volume_uom_code
         ,gr_msi_rec.warranty_vendor_id
         ,gr_msi_rec.web_status
         ,gr_msi_rec.weight_uom_code
         ,gr_msi_rec.wh_update_date
         ,gr_msi_rec.wip_supply_locator_id
         ,gr_msi_rec.wip_supply_subinventory
         ,gr_msi_rec.wip_supply_type
         ,gc_set_proc_id_child                  -- set_process_id
         ,gc_process_flag                       -- process_flag
         ,gc_trans_type_create                  -- transaction_type
         ,gr_stg_rec.invorg_itemcost            -- material_cost
         ,gc_material_sub_element               -- material_sub_element
         );

exception
  when others then
     fnd_file.put_line(fnd_file.log,'Error in XXHA_ORGITEM_ADD_PK.LOAD_ITEM_INTERFACE ' ||SQLERRM);
end LOAD_ITEM_INTERFACE;

-----------------------------------------------------------
-- Procedure to populate the Item Revision Interface
-----------------------------------------------------------
procedure LOAD_REVISIONS_INTERFACE is
  cursor lcu_rev (
            p_inventory_item_id  number
           ) is
    select  *
    from    mtl_item_revisions
    where   inventory_item_id = p_inventory_item_id
    and     organization_id
             = (select  organization_id
                from    mtl_parameters
                where   organization_code = gc_master_org
               );
begin
   for rev_rec in lcu_rev (gr_stg_rec.inventory_item_id)
   loop
      insert into mtl_item_revisions_interface (
             organization_id
            ,revision
            ,effectivity_date
            ,item_number
            ,last_update_date
            ,last_updated_by
            ,creation_date
            ,created_by
            ,last_update_login
            ,process_flag
            ,transaction_type
            ,set_process_id
            ,description
            ,revision_label
            )
      values (
             gr_stg_rec.organization_id         -- organization_id
            ,rev_rec.revision
            ,rev_rec.effectivity_date
            ,gr_stg_rec.itemnbr                 -- item_number
            ,gd_today                           -- last_update_date
            ,fnd_global.user_id                 -- last_updated_by
            ,gd_today                           -- creation_date
            ,fnd_global.user_id                 -- created_by
            ,null                               -- last_update_login
            ,gc_process_flag                    -- process_flag
            ,gc_trans_type_create               -- transaction_type
            ,gc_set_proc_id_child               -- set_process_id
            ,rev_rec.description
            ,rev_rec.revision_label
            );
   end loop;

exception
  when others then
     fnd_file.put_line(fnd_file.log,'Error in XXHA_ORGITEM_ADD_PK.LOAD_REVISIONS_INTERFACE ' ||SQLERRM);
end LOAD_REVISIONS_INTERFACE;

----------------------------------------------------------------------------
-- Get Chart Of Accounts ID based on profile setting for GL Sets Of Books
----------------------------------------------------------------------------
procedure GET_COA_ID (
         x_setup_err_flag  out  varchar2
        ) is
  ln_sob_id  number;
  ln_coa_id  number;

begin
  ln_sob_id := fnd_profile.value('GL_SET_OF_BKS_ID');
  select  chart_of_accounts_id
  into    ln_coa_id
  from    gl_sets_of_books
  where   set_of_books_id = ln_sob_id;

  gc_log_msg:='Derived Chart of Accounts Id = '||ln_coa_id;
  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

  gn_coa_id := ln_coa_id;

  x_setup_err_flag := 'N';

exception
  when no_data_found then
     x_setup_err_flag := 'Y';
     gc_error_code := 'SETUP-001';
     gc_error_msg := 'No match found for Set Of Books Id '||ln_sob_id;
     gc_comments := 'Check GL Set of Books profile set up for the user login';
     insert_error_prc;
     gc_log_msg := 'Unable to derive Chart of Accounts Id based on Set of Books Id '||ln_sob_id;
     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
     raise e_abort;
  when others then
     fnd_file.put_line(fnd_file.log,'Error fetching chart of accounts id is: '||sqlerrm);
     raise e_abort;
end GET_COA_ID;

---------------------------------------------------------------
-- Procedure to check setup of target organizations in
-- staging table.
---------------------------------------------------------------
procedure CHECK_ORG_SETUP (
         x_setup_err_flag  out  varchar2
        ) is

  -- fetches distinct list of target organizations from staging table
  cursor lcu_stg is
    select  distinct invorg
    from    haemo_item_add
    where   oraclecharfld1 is null;

  -- check for material sub element set up
  cursor lcu_val_material(
           p_organization_code  varchar2
          ) is
    select  'N'
    from    bom_resources  BR
           ,mtl_parameters  MP
    where   mp.organization_id = br.organization_id
    and     br.resource_code = gc_material_sub_element
    and     mp.organization_code = p_organization_code
    and     nvl(br.disable_date,sysdate) >= trunc(sysdate);

  lc_err_found  varchar2(1) := 'N';
  lc_err_flag  varchar2(1) := 'N';
  lc_err_code  varchar2(80);
  ln_org_id  number;
  lc_zero_cost_flag  varchar2(80);
  lc_temp_value  varchar2(1);       -- Placeholder for retrieved value
  e_done  exception;
  e_setup  exception;

begin
   ------------------------------------------------------------------------------
   -- Opening the cursor for distinct set of staged organizations
   ------------------------------------------------------------------------------
   for stg_rec in lcu_stg
   loop

      lc_err_flag := 'N';
      lc_err_code := null;
      ln_org_id := null;
      lc_zero_cost_flag := null;
      lc_temp_value := null;

      begin
         -----------------------------------------------------------------------
         -- Check that organization parameters have been defined
         -----------------------------------------------------------------------
         begin
            select  organization_id
                   ,attribute6   -- Zero Cost Flag
            into    ln_org_id
                   ,lc_zero_cost_flag
            from    mtl_parameters
            where   organization_code = stg_rec.invorg;

            gc_log_msg:='Flag returned from Check for parameters for Organization '||stg_rec.invorg||' is '||lc_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            -----------------------------------------------------------------------
            -- Check setup for Zero Cost flag (DFF attribute6)
            -----------------------------------------------------------------------
            if (lc_zero_cost_flag is null) then
               lc_err_flag := 'Y';
               lc_err_code := 'SETUP-003';
            end if;
            gc_log_msg:='Flag returned from Check for Zero Cost flag for Organization '||stg_rec.invorg||' is '||lc_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            if (lc_err_flag = 'Y') then
               raise e_done;
            end if;

            -----------------------------------------------------------------------
            -- Check setup of Material SubElement
            -----------------------------------------------------------------------
            open lcu_val_material(stg_rec.invorg);
            fetch lcu_val_material into lc_temp_value;
            if lcu_val_material%NOTFOUND then
               lc_err_flag := 'Y';
               lc_err_code := 'SETUP-004';
            end if;
            close lcu_val_material;
            gc_log_msg:='Flag returned from Check for Material SubElement for Organization '||stg_rec.invorg||' is '||lc_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            if (lc_err_flag = 'Y') then
               raise e_done;
            end if;

         exception
            when e_done then
               null;
            when no_data_found then
               lc_err_flag := 'Y';
               lc_err_code := 'SETUP-002';
               gc_log_msg:='Flag returned from Check for parameters for Organization '||stg_rec.invorg||' is '||lc_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         end;

      end;

      -- flag staged rows matching the organization
      update  haemo_item_add
      set     oraclecharfld1 = decode(lc_err_flag,'Y','VE',null)  -- status
             ,oraclecharfld8 = lc_err_code
             ,oracleintfld8 = gn_request_id
             ,oracleintfld1 = ln_org_id
      where   invorg = stg_rec.invorg
      and     oraclecharfld1 is null;

      if (lc_err_flag = 'Y') then
         lc_err_found := 'Y';
      end if;

   end loop;

   x_setup_err_flag := lc_err_found;

exception
   when others then
      fnd_file.put_line(fnd_file.log,'Error in XXHA_ORGITEM_ADD_PK.CHECK_ORG_SETUP ' ||SQLERRM);
      raise;
end CHECK_ORG_SETUP;

---------------------------------------------------------------
-- Procedure to check master organization items that form
-- the base for items in the staging table.
---------------------------------------------------------------
procedure CHECK_MASTER_ITEM (
         x_setup_err_flag  in out  varchar2
        ) is

  -- fetches distinct list of items from staging table
  cursor lcu_stg is
    select  distinct itemnbr
    from    haemo_item_add
    where   oraclecharfld1 is null;

  lc_err_found  varchar2(1) := 'N';
  lc_err_flag  varchar2(1) := 'N';
  lc_err_code  varchar2(80);
  ln_item_id  number;
  lc_product_line  varchar2(80);
  e_setup  exception;


begin
   ------------------------------------------------------------------------------
   -- Opening the cursor for distinct set of staged items
   ------------------------------------------------------------------------------
   for stg_rec in lcu_stg
   loop

      lc_err_flag := 'N';
      lc_err_code := null;
      ln_item_id := null;
      lc_product_line := null;

      begin
         -----------------------------------------------------------------------
         -- Check that item exists in master org
         -----------------------------------------------------------------------
         begin
            select  msi.inventory_item_id
            into    ln_item_id
            from    mtl_parameters  mp
                   ,mtl_system_items_b  msi
            where   mp.organization_code = gc_master_org
            and     msi.organization_id = mp.master_organization_id
            and     msi.segment1 = stg_rec.itemnbr;

            gc_log_msg:='Check for item '||stg_rec.itemnbr||' succeded';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            -----------------------------------------------------------------------
            -- Get Product Line from DFF for account generation
            -----------------------------------------------------------------------
            begin
               select  attribute1
               into    lc_product_line
               from    mtl_categories_b
               where   category_id
                        = (select  category_id
                           from    mtl_item_categories
  		           where   organization_id
                                    = (select  organization_id
                           	       from    mtl_parameters
                        	       where   organization_code = gc_master_org)
  		           and     inventory_item_id  = ln_item_id
                           and     category_set_id
                                    = (select  category_set_id
                         	       from    mtl_category_sets_vl
                         	       where   category_set_name = 'Inventory')
                          )
               and     attribute1 is not null;

               gc_log_msg:='Check for Product Line for item '||stg_rec.itemnbr||' succeded';
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            exception
               when no_data_found then
                  lc_err_code := 'SETUP-006';
                  gc_log_msg:='Check for Product Line for item '||stg_rec.itemnbr||' failed';
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                  raise e_setup;
            end;
         exception
            when no_data_found then
               lc_err_code := 'SETUP-005';
               gc_log_msg:='Check for item '||stg_rec.itemnbr||' failed';
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               raise e_setup;
         end;

      exception
         when e_setup then
            lc_err_flag := 'Y';
      end;

      -- flag staged rows matching the item
      update  haemo_item_add
      set     oraclecharfld1 = decode(lc_err_flag,'Y','VE',null)  -- status
             ,oraclecharfld8 = lc_err_code
             ,oracleintfld8 = gn_request_id
             ,oraclecharfld2 = lc_product_line
             ,oracleintfld2 = ln_item_id
      where   itemnbr = stg_rec.itemnbr
      and     oraclecharfld1 is null;

      if (lc_err_flag = 'Y') then
         lc_err_found := 'Y';
      end if;

   end loop;

   x_setup_err_flag := lc_err_found;

exception
   when others then
      fnd_file.put_line(fnd_file.log,'Error in XXHA_ORGITEM_ADD_PK.CHECK_MASTER_ITEM ' ||SQLERRM);
      raise;
end CHECK_MASTER_ITEM;

---------------------------------------------------------------
-- Procedure to check item is not already assigned and
-- is not already interfaced
---------------------------------------------------------------
procedure CHECK_ADD_ITEM (
         x_error_exists  out  varchar2
        ) is

  --Cursor to check item existance in Oracle Base table
  cursor lcu_val_item_exist(
            p_segment1  varchar2
           ,p_org_id  number
           ) is
    select  'N'
    from    mtl_system_items_b  MSIB
    where   msib.segment1 = p_segment1
    and     msib.organization_id = p_org_id;

  --Cursor to check item existence in Oracle Interface table
  cursor lcu_val_item_exist_int(
            p_segment1  varchar2
           ,p_org_id  number
           ) is
    select  'N'
    from    mtl_system_items_interface MSII
    where   msii.segment1 = p_segment1
    and     msii.organization_id = p_org_id
    and     msii.process_flag = gc_process_flag;

  lc_err_flag  varchar2(1) := 'N';  -- Error_flag for checking the setup
  lc_temp_value  varchar2(1);       -- Placeholder for retrieved value
  e_skip  exception;

begin
      -----------------------------------------------------------------------
      -- Validation of Item No for existance in Oracle Base table
      ----------------------------------------------------------------------
      lc_err_flag := 'N';
      open lcu_val_item_exist(gr_stg_rec.itemnbr,gr_stg_rec.organization_id);
      fetch lcu_val_item_exist into lc_temp_value;
      if lcu_val_item_exist%FOUND THEN
         lc_err_flag := 'Y';
         gc_error_code :='ITEM-26';
         gc_error_msg :='Item '||gr_stg_rec.itemnbr||' is already assigned to organization '||gr_stg_rec.invorg;
         gc_comments := null;
         insert_error_prc;
      end if;
      close lcu_val_item_exist;
      gc_log_msg:='Flag returned by the Item No validation for existence in Oracle Base table is '||lc_err_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      if (lc_err_flag = 'Y') then
         raise e_skip_item;
      end if;

      -----------------------------------------------------------------------
      -- Validation of Item No for existance in Interface table
      ----------------------------------------------------------------------
      lc_err_flag := 'N';
      open lcu_val_item_exist_int(gr_stg_rec.itemnbr,gr_stg_rec.organization_id);
      fetch lcu_val_item_exist_int into lc_temp_value;
      if lcu_val_item_exist_int%FOUND THEN
         lc_err_flag := 'Y';
         gc_error_code :='ITEM-27';
         gc_error_msg :='Item '||gr_stg_rec.itemnbr||' assignment to organization '||gr_stg_rec.invorg||' is already interfaced.';
         gc_comments := null;
         insert_error_prc;
      end if;
      close lcu_val_item_exist_int;
      gc_log_msg:='Flag returned by the Item No validation for existence in Interface table is '||lc_err_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      if (lc_err_flag = 'Y') then
         raise e_skip_item;
      end if;

      x_error_exists := 'N';

exception
   when e_skip_item then
      x_error_exists := 'Y';
      raise;
   when others then
      lc_err_flag := 'Y';
      gc_error_code := 'TECH-003';
      gc_error_msg := substr('Error occurred when checking target assignment '
                             ||'Item '||gr_stg_rec.itemnbr||' at '||gr_stg_rec.invorg
                             ||' : '||SQLERRM
                            ,1,2000);
      gc_comments := 'Report error to Contact System Administrator';
      insert_error_prc;

      fnd_file.put_line(fnd_file.log,'Error in XXHA_ORGITEM_ADD_PK.CHECK_ADD_ITEM ' ||SQLERRM);
      raise e_skip_item;
end CHECK_ADD_ITEM;

---------------------------------------------------------------
-- Procedure to derive and check account code combination
---------------------------------------------------------------
procedure DERIVE_ACCOUNT (
         p_acct_type  in  varchar2
        ,p_product_line  in  varchar2
        ,x_ccid  out  number
        ,x_error_exists  in out  varchar2
        ) is

  lc_acct_type_name  varchar2(30);
  lc_concat_segments  varchar2(100);
  ln_ccid  number;

  lc_err_flag  varchar2(1) := 'N';
  lc_temp_value  varchar2(1);
  e_done  exception;
  e_skip  exception;

begin
   if (p_acct_type = 'COS') then
      lc_acct_type_name := 'Cost Of Sales ';
   elsif (p_acct_type = 'SALES') then
      lc_acct_type_name := 'Sales ';
   elsif (p_acct_type = 'EXP') then
      lc_acct_type_name := 'Expense ';
   end if;

   ----------------------------------------
   -- Derive the new concatenated segments
   -----------------------------------------
   lc_err_flag := 'N';
   begin
      select  segment1
              ||'.'||p_product_line
              ||'.'||segment3
              ||'.'||segment4
              ||'.'||segment5
              ||'.'||segment6
              ||'.'||segment7
              ||'.'||segment8
              ||'.'||segment9
      into    lc_concat_segments
      from    gl_code_combinations glc
             ,mtl_parameters mp
      where   mp.organization_id = gr_stg_rec.organization_id
      and     glc.code_combination_id = decode(p_acct_type
                                              ,'COS',mp.cost_of_sales_account
                                              ,'SALES',mp.sales_account
                                              ,'EXP',mp.expense_account
                                              );
   exception
      when no_data_found then
         lc_err_flag := 'Y';
         gc_error_code := 'ITEM-31';
         gc_error_msg :=  'Concatenated Segments for '||lc_acct_type_name
                        ||' account for Organization '||gr_stg_rec.invorg||' is not found in Oracle';
         gc_comments := 'Please check concatenated segments against the organization';
         insert_error_prc;
      when others then
         lc_err_flag := 'Y';
         gc_error_code := 'TECH-001';
         gc_error_msg := substr('Error occurred when getting Segment Concatenation for '||lc_acct_type_name
                                ||' account for Org '||gr_stg_rec.invorg||' : '||SQLERRM
                               ,1,2000);
         gc_comments := 'Report error to Contact System Administrator';
         insert_error_prc;
         fnd_file.put_line(fnd_file.log,'Error deriving concatenated segments for organization '
                                      ||gr_stg_rec.invorg||' is: ' ||sqlerrm);
   end;
   gc_log_msg:='Flag returned by derivation of new concatenated segments for '||lc_acct_type_name||' account is '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   if (lc_err_flag = 'Y') then
      raise e_skip_item;
   end if;

   if (lc_concat_segments is not null) then
      -------------------------------------
      -- Derivation of CC_ID
      --------------------------------------
      lc_err_flag := 'N';
      begin
         ln_ccid:= FND_FLEX_EXT.GET_CCID(
                            'SQLGL'
                           ,'GL#'
                           ,gn_coa_id
                           ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
                           ,lc_concat_segments
                           );

         if (ln_ccid = 0) then
            lc_err_flag := 'Y';
            gc_error_code :='ITEM-32';
            gc_error_msg :=  'Invalid '||lc_acct_type_name
                           ||' account: '||lc_concat_segments
                           ||' [for organization '||gr_stg_rec.invorg||']';
            gc_comments := 'Please check the code combination';
            insert_error_prc;
         else
            x_ccid := ln_ccid;
         end if;
      exception
         when others then
            lc_err_flag := 'Y';
            gc_error_code := 'TECH-002';
            gc_error_msg := substr('Error occurred when getting CC_ID for '||lc_acct_type_name
                                   ||' account '||lc_concat_segments
                                   ||' for Org '||gr_stg_rec.invorg||' : '||SQLERRM
                                  ,1,2000);
            gc_comments := 'Report error to Contact System Administrator';
            insert_error_prc;
            fnd_file.put_line(fnd_file.log,'Error getting CCID for '||lc_concat_segments || ' is : ' ||sqlerrm);
      end;
      gc_log_msg := 'Flag returned by the CCID validation and derivation for '
                    ||lc_acct_type_name||' account is '||lc_err_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      if (lc_err_flag = 'Y') then
         raise e_skip_item;
      end if;
   end if;

   x_error_exists := 'N';
exception
   when e_skip_item then
      x_error_exists := 'Y';
      raise;
   when others then
      fnd_file.put_line(fnd_file.log,'Error in XXHA_ORGITEM_ADD_PK.DERIVE_ACCOUNT ' ||SQLERRM);
      raise;
end DERIVE_ACCOUNT;


---------------------------------------------------------------
-- Main driver routine for populating the seeded interface
-- tables in preparation for item import.  Invoked by
-- CP executable XXHA_ORGITEM_ADD
---------------------------------------------------------------
procedure INTERFACE_ORG_ITEMS (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_debug  in  varchar2
        ,p_purge_errors  in  varchar2
        ) is
  -- fetches staged rows not yet disqualified
  cursor lcu_stg is
    select  *
    from    haemo_item_add
    where   oraclecharfld1 is null;

  lc_error_exists          VARCHAR2(1) := 'N';
  lc_setup_err_flag        VARCHAR2(1) := 'N';  -- Variable to take Setup procedure Out parameter
  lc_validation_status     VARCHAR2(2);
  ln_cnt_validated  number := 0;
  ln_cnt_passed  number := 0;
  ln_cnt_failed  number := 0;

begin
  gn_request_id := fnd_global.conc_request_id;
  lc_error_exists :='N';                                 -- Error_exits flag initialise
  gc_debug_flag := p_debug;                            -- Debug Flag
  gc_log_msg  :='Start of INTERFACE_ORG_ITEMS ...';-- Indicator to show start of Validation Procedure
  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

  ------------------------------------------------------------------------
  -- If Purge Errors flag set to Y then purge all error records from
  -- XXHA_COMMON_ERRORS table which were generated during earlier
  -- runs of Incremental Item Add
  ------------------------------------------------------------------------
  if (p_purge_errors = 'Y') then
     xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>gc_conc_name);
  end if;

  ------------------------------------------------------------------------
  -- Fetch the Chart of Acconts Id based on the profile value for
  -- Set of Books.  If COA cannot be determined, it is considered a fatal
  -- error and causes the program to abort.
  ------------------------------------------------------------------------
  get_coa_id(x_setup_err_flag => lc_setup_err_flag);

  ------------------------------------------------------------------------
  -- Check setups for target organizations and master items
  ------------------------------------------------------------------------
  check_org_setup(x_setup_err_flag => lc_setup_err_flag);
  check_master_item(x_setup_err_flag => lc_setup_err_flag);
  log_validation_failures;

  ------------------------------------------------------------------------------
  -- Loop thru staged records not yet
  ------------------------------------------------------------------------------
  for x_stg_rec in gcu_stg
  loop
     begin
        gr_stg_rec := x_stg_rec;

        lc_validation_status := null;

        gc_record_identifier := gr_stg_rec.itemnbr||'/'||gr_stg_rec.invorg;
        gn_record_number := gr_stg_rec.oracleidentifier;

        check_add_item(x_error_exists => lc_error_exists);

        derive_account('COS',gr_stg_rec.product_line,gr_stg_rec.cos_ccid,lc_error_exists);
        derive_account('SALES',gr_stg_rec.product_line,gr_stg_rec.sales_ccid,lc_error_exists);
        derive_account('EXP',gr_stg_rec.product_line,gr_stg_rec.expense_ccid,lc_error_exists);

        --------------------------------------------
        -- get attributes of item in master org
        --------------------------------------------
        select  msi.*
        into    gr_msi_rec
        from    mtl_system_items_b  msi
        where   msi.organization_id
                 = (select  mp.organization_id
                    from    mtl_parameters  mp
                    where   mp.organization_code = gc_master_org
                   )
        and     msi.inventory_item_id = gr_stg_rec.inventory_item_id;

        load_item_interface;
        load_revisions_interface;

        --------------------------------------------
        -- set status as Xalidated with SUCCESS
        --------------------------------------------
        lc_validation_status := 'VS';

     exception
        when e_skip_item then
           --------------------------------------------
           -- set status as Xalidated with SUCCESS
           --------------------------------------------
           lc_validation_status := 'VE';
     end;


     ---------------------------------------------------
     -- update staged row with status, request id, etc
     ---------------------------------------------------
     update  haemo_item_add
     set     oraclecharfld1 = lc_validation_status
            ,oraclecharfld8 = decode(lc_validation_status,'VE',gc_error_code,oraclecharfld8)
            ,oracleintfld8 = gn_request_id
     where   oracleidentifier = gr_stg_rec.oracleidentifier
     and     oraclecharfld1 is null;

     commit;

  end loop;

  ----------------------------------------------------------------
  -- fetch statistics and log summary of data validation process
  ----------------------------------------------------------------
  select  count(1)
         ,sum(decode(oraclecharfld1,'VE',1,0))
         ,sum(decode(oraclecharfld1,'VS',1,0))
  into    ln_cnt_validated
         ,ln_cnt_failed
         ,ln_cnt_passed
  from    haemo_item_add
  where   oracleintfld8 = gn_request_id;

  fnd_file.put_line(fnd_file.log,rpad('*',80,'*'));
  fnd_file.put_line(fnd_file.log,'Validation Summary for Incremental Item Add ');
  fnd_file.put_line(fnd_file.log,rpad('*',80,'*'));
  fnd_file.put_line(fnd_file.log,'Records Validated                :  ' ||ln_cnt_validated);
  fnd_file.put_line(fnd_file.log,'Records Failed                   :  ' ||ln_cnt_failed);
  fnd_file.put_line(fnd_file.log,'Records Passed and Interfaced    :  ' ||ln_cnt_passed);

  -- if any records failed validation, complete with warning and launch error report
  if (nvl(ln_cnt_failed,0) > 0) then
     p_retcode := 1;
     xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
  end if;

exception
  when e_abort then
     p_retcode := 2;
     xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
  when others then
     fnd_file.put_line(fnd_file.log,'Error in XXHA_ORGITEM_ADD_PK.INTERFACE_ORG_ITEMS ' ||SQLERRM);
end INTERFACE_ORG_ITEMS;

end XXHA_INV_ORGITEM_ADD_PK;

/
