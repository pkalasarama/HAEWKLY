CREATE OR REPLACE package xxha_transfer_vendor_info 
/*****************************************************************************************
* Name/Purpose : xxha_transfer_vendor_info                                               *
* Description  : creates                                                                 *
*                package spec xxha_transfer_vendor_info                                  *
*                Copy/Transfer Site and contacts from one Org to Another                 *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 08-JUL-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
as
  procedure preload_sites(
    errbuf out varchar2,
    retcode out varchar2,  
    p_project varchar2,
    p_from_org_id number,
    p_to_org_id number,
    p_site_organization_id number,
    p_ship_to_location_id number,
    p_bill_to_location_id number);
  procedure load_sites_to_interface(
    errbuf out varchar2,
    retcode out varchar2,  
    p_project varchar2);
  procedure load_site_cont_to_interface(
    errbuf out varchar2,
    retcode out varchar2,  
    p_project varchar2,
    p_from_org_id number,
    p_to_org_id number);
end xxha_transfer_vendor_info;
/


CREATE OR REPLACE package body xxha_transfer_vendor_info 
/*****************************************************************************************
* Name/Purpose : xxha_transfer_vendor_info                                               *
* Description  : creates                                                                 *
*                package body xxha_transfer_vendor_info                                  *
*                Copy/Transfer Site and contacts from one Org to Another                 *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 08-JUL-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
is
procedure preload_sites(
  errbuf out varchar2,
  retcode out varchar2,  
  p_project varchar2,
  p_from_org_id number,
  p_to_org_id number,
  p_site_organization_id number,
  p_ship_to_location_id number,
  p_bill_to_location_id number) is
--select * from po_vendors where segment1 = '3383'
--select * from po_vendor_sites_all where vendor_id = 742015 and org_id = 2538
--v_project varchar2(100) := 'AEROSMITH';
--v_from_org_id number := 102;
--v_to_org_id number := 2538;
--v_site_organization_id number := 1194;
--v_ship_to_location_id number := 113940;
--v_bill_to_location_id number := 142;
v_project varchar2(100) := p_project;
v_from_org_id number := p_from_org_id;
v_to_org_id number := p_to_org_id;
v_site_organization_id number := p_site_organization_id;
v_ship_to_location_id number := p_ship_to_location_id;
v_bill_to_location_id number := p_bill_to_location_id;
cursor c1(x_from_org_id number, x_to_org_id number, x_site_organization_id number) is
select distinct ph.vendor_id --, ph.vendor_site_id
--ph.vendor_id 
--i.segment1
from haemo.xxha_aerosmith_buymake_items i, po_headers_all ph, po_lines_all pl, po_line_locations_all pll, po_vendors pv
where ph.org_id = x_from_org_id --102
and   ph.po_header_id = pl.po_header_id
and   pl.po_line_id = pll.po_line_id
and   pl.item_id = i.inventory_item_id
and   pll.ship_to_organization_id = x_site_organization_id --1194
and   ph.vendor_id = pv.vendor_id
--and   ph.end_date_active is null
and   pv.end_date_active is null
--and   i.buy_make = 'Buy'
and not exists (select 1 from po_vendor_sites_all new_pvs where new_pvs.org_id = x_to_org_id /* 2538 */ and new_pvs.vendor_id = ph.vendor_id group by vendor_id having count(1) > 0)
and exists (select 1 from po_vendor_sites_all old_pvs where old_pvs.org_id = x_from_org_id /* 102 */ and old_pvs.vendor_id = ph.vendor_id and old_pvs.inactive_date is null)
/*
and pv.segment1 in (
'3949',
'4026',
'4931',
'12071',
'4015'
)
*/
;
begin
  for v in c1(v_from_org_id, v_to_org_id, v_site_organization_id) loop
    savepoint sv_vendor;
    insert into haemo.xxha_SUPPLIERS(vendor_id, to_org_id, from_org_id, creation_date, project_name) values(v.vendor_id, v_to_org_id, v_from_org_id, sysdate, v_project);
    insert into haemo.xxha_SUPPLIERS_INT(vendor_interface_id, vendor_name, vendor_name_alt, segment1, enabled_flag, vendor_type_lookup_code, creation_date, project_name)
    select AP_SUPPLIERS_INT_S.nextval, vendor_name, vendor_name_alt, segment1, enabled_flag, vendor_type_lookup_code, sysdate, v_project
    from po_vendors 
    where vendor_id = v.vendor_id
    ;
    insert into haemo.xxha_SUPPLIER_SITES_INT(
            vendor_interface_id,
            vendor_id, vendor_site_code, 
            purchasing_site_flag, rfq_only_site_flag, pay_site_flag, attention_ar_flag,
            address_line1, address_line2, address_line3, city, state, zip, province, country, 
            area_code, phone, fax, fax_area_code, telex,
            ship_to_location_id, bill_to_location_id,
            ship_via_lookup_code, freight_terms_lookup_code, 
            payment_method_lookup_code, 
            --bank_account_name, bank_account_num, bank_num, bank_account_type, --??
            terms_date_basis,
            --accts_pay_code_combination_id, prepay_code_combination_id, --??
            pay_group_lookup_code, payment_priority, terms_id, invoice_amount_limit, pay_date_basis_lookup_code,
            always_take_disc_flag, invoice_currency_code, payment_currency_code, 
            hold_all_payments_flag, hold_future_payments_flag, hold_reason, hold_unmatched_invoices_flag,
            ap_tax_rounding_rule, auto_tax_calc_flag, auto_tax_calc_override, amount_includes_tax_flag,
            exclusive_payment_flag, tax_reporting_site_flag, 
            attribute_category, 
            attribute1, attribute2, attribute3, attribute4, attribute5, 
            attribute6, attribute7, attribute8, attribute9, attribute10, 
            attribute11, attribute12, attribute13, attribute14, attribute15,
            exclude_freight_from_discount, vat_registration_num, 
            --offset_vat_code, 
            org_id, --2538 org_id,
            language,
            allow_awt_flag, awt_group_id,
            edi_transaction_handling, edi_id_number, edi_payment_method, edi_payment_format, edi_remittance_method, 
            bank_charge_bearer, --...
            pcard_site_flag, match_option, country_of_origin_code, create_debit_memo_flag, offset_tax_flag,
            supplier_notif_method, email_address, remittance_email, 
            primary_pay_site_flag, 
            duns_number,
            tolerance_id, --, services_tolerance_id
            creation_date,
            project_name
    )
    select AP_SUPPLIERS_INT_S.currval,
            vendor_id, vendor_site_code, 
            purchasing_site_flag, rfq_only_site_flag, pay_site_flag, attention_ar_flag,
            address_line1, address_line2, address_line3, city, state, zip, province, country, 
            area_code, phone, fax, fax_area_code, telex,
            v_ship_to_location_id, v_bill_to_location_id,
            ship_via_lookup_code, freight_terms_lookup_code, 
            payment_method_lookup_code, 
            --bank_account_name, bank_account_num, bank_num, bank_account_type, --??
            terms_date_basis,
            --accts_pay_code_combination_id, prepay_code_combination_id, --??
            pay_group_lookup_code, payment_priority, terms_id, invoice_amount_limit, pay_date_basis_lookup_code,
            always_take_disc_flag, invoice_currency_code, payment_currency_code, 
            hold_all_payments_flag, hold_future_payments_flag, hold_reason, hold_unmatched_invoices_flag,
            ap_tax_rounding_rule, auto_tax_calc_flag, auto_tax_calc_override, amount_includes_tax_flag,
            exclusive_payment_flag, tax_reporting_site_flag, 
            attribute_category, 
            attribute1, attribute2, attribute3, attribute4, attribute5, 
            attribute6, attribute7, attribute8, attribute9, attribute10, 
            attribute11, attribute12, attribute13, attribute14, attribute15,
            exclude_freight_from_discount, vat_registration_num, 
            --offset_vat_code, 
            v_to_org_id, --  2538 org_id,
            language,
            allow_awt_flag, awt_group_id,
            edi_transaction_handling, edi_id_number, edi_payment_method, edi_payment_format, edi_remittance_method, 
            bank_charge_bearer, --...
            pcard_site_flag, match_option, country_of_origin_code, create_debit_memo_flag, offset_tax_flag,
            supplier_notif_method, email_address, remittance_email, 
            primary_pay_site_flag, 
            duns_number,
            tolerance_id, --, services_tolerance_id
            sysdate,
            v_project
    from po_vendor_sites_all where vendor_id = v.vendor_id and org_id = v_from_org_id and inactive_date is null
    ;
    if sql%rowcount = 0 then
       rollback to sv_vendor;
    end if;
  end loop;
end preload_sites;
procedure load_sites_to_interface(
  errbuf out varchar2,
  retcode out varchar2,  
  p_project varchar2) is
  v_project_name varchar2(50) := p_project;
begin
  insert into AP_SUPPLIERS_INT (vendor_interface_id, vendor_name, vendor_name_alt, segment1, enabled_flag, vendor_type_lookup_code)
  select vendor_interface_id, vendor_name, vendor_name_alt, segment1, enabled_flag, vendor_type_lookup_code
  from haemo.xxha_SUPPLIERS_INT 
  where project_name = v_project_name;
  insert into ap_supplier_sites_int(
          vendor_interface_id,
          vendor_id, vendor_site_code, 
          purchasing_site_flag, rfq_only_site_flag, pay_site_flag, attention_ar_flag,
          address_line1, address_line2, address_line3, city, state, zip, province, country, 
          area_code, phone, fax, fax_area_code, telex,
          ship_to_location_id, bill_to_location_id,
          ship_via_lookup_code, freight_terms_lookup_code, 
          payment_method_lookup_code, 
          --bank_account_name, bank_account_num, bank_num, bank_account_type, --??
          terms_date_basis,
          accts_pay_code_combination_id, prepay_code_combination_id, --??
          pay_group_lookup_code, payment_priority, terms_id, invoice_amount_limit, pay_date_basis_lookup_code,
          always_take_disc_flag, invoice_currency_code, payment_currency_code, 
          hold_all_payments_flag, hold_future_payments_flag, hold_reason, hold_unmatched_invoices_flag,
          ap_tax_rounding_rule, auto_tax_calc_flag, auto_tax_calc_override, amount_includes_tax_flag,
          exclusive_payment_flag, tax_reporting_site_flag, 
          attribute_category, 
          attribute1, attribute2, attribute3, attribute4, attribute5, 
          attribute6, attribute7, attribute8, attribute9, attribute10, 
          attribute11, attribute12, attribute13, attribute14, attribute15,
          exclude_freight_from_discount, vat_registration_num, 
          --offset_vat_code, 
          org_id, --2538 org_id,
          language,
          allow_awt_flag, awt_group_id,
          edi_transaction_handling, edi_id_number, edi_payment_method, edi_payment_format, edi_remittance_method, 
          bank_charge_bearer, --...
          pcard_site_flag, match_option, country_of_origin_code, create_debit_memo_flag, offset_tax_flag,
          supplier_notif_method, email_address, remittance_email, 
          primary_pay_site_flag, 
          duns_number,
          tolerance_id --, services_tolerance_id
  )
  select
          vendor_interface_id,
          vendor_id, vendor_site_code, 
          purchasing_site_flag, rfq_only_site_flag, pay_site_flag, attention_ar_flag,
          address_line1, address_line2, address_line3, city, state, zip, province, country, 
          area_code, phone, fax, fax_area_code, telex,
          ship_to_location_id, bill_to_location_id,
          ship_via_lookup_code, freight_terms_lookup_code, 
          payment_method_lookup_code, 
          --bank_account_name, bank_account_num, bank_num, bank_account_type, --??
          terms_date_basis,
          accts_pay_code_combination_id, prepay_code_combination_id, --??
          pay_group_lookup_code, payment_priority, terms_id, invoice_amount_limit, pay_date_basis_lookup_code,
          always_take_disc_flag, invoice_currency_code, payment_currency_code, 
          hold_all_payments_flag, hold_future_payments_flag, hold_reason, hold_unmatched_invoices_flag,
          ap_tax_rounding_rule, auto_tax_calc_flag, auto_tax_calc_override, amount_includes_tax_flag,
          exclusive_payment_flag, tax_reporting_site_flag, 
          attribute_category, 
          attribute1, attribute2, attribute3, attribute4, attribute5, 
          attribute6, attribute7, attribute8, attribute9, attribute10, 
          attribute11, attribute12, attribute13, attribute14, attribute15,
          exclude_freight_from_discount, vat_registration_num, 
          --offset_vat_code, 
          org_id, --2538 org_id,
          language,
          allow_awt_flag, awt_group_id,
          edi_transaction_handling, edi_id_number, edi_payment_method, edi_payment_format, edi_remittance_method, 
          bank_charge_bearer, --...
          pcard_site_flag, match_option, country_of_origin_code, create_debit_memo_flag, offset_tax_flag,
          supplier_notif_method, email_address, remittance_email, 
          primary_pay_site_flag, 
          duns_number,
          tolerance_id --, services_tolerance_id
  from haemo.xxha_SUPPLIER_SITES_INT
  where project_name = v_project_name;
end load_sites_to_interface;
procedure load_site_cont_to_interface(
  errbuf out varchar2,
  retcode out varchar2,  
  p_project varchar2,
  p_from_org_id number,
  p_to_org_id number
  ) is
  v_project_name varchar2(50) := p_project;
  v_from_org_id number := p_from_org_id;
  v_to_org_id number := p_to_org_id;
  cursor c1(x_project_name varchar2) is
  select distinct new_vendor_site_id 
  from haemo.xxha_supplier_sites_int i where processed = 'Y' and new_vendor_site_id is not null
  and  project_name = x_project_name
  and not exists (select 1 from PO_VENDOR_CONTACTS c where c.vendor_site_id = i.new_vendor_site_id)
  ;
begin
  update haemo.xxha_supplier_sites_int s
  set new_vendor_site_id = (select vendor_site_id from po_vendor_sites_all pvs 
                            where pvs.org_id = v_to_org_id and pvs.vendor_id = s.vendor_id and pvs.vendor_site_code = s.vendor_site_code
                            )
  where project_name = v_project_name;
  update haemo.xxha_supplier_sites_int s
  set processed = 'Y' 
  where new_vendor_site_id is not null
  and project_name = v_project_name;
  for i in c1(v_project_name) loop
    insert into AP_SUP_SITE_CONTACT_INT(
          vendor_site_id,
          vendor_site_code, -- pvs.*,
          org_id,
          inactive_date,
          first_name, middle_name, last_name, 
          prefix, title, mail_stop, area_code, phone,
          contact_name_alt, first_name_alt, last_name_alt, department, 
          email_address, url, alt_area_code, alt_phone, fax_area_code, fax
    )
    select --pvc.vendor_id, 
          new_site.vendor_site_id,
          pvs.vendor_site_code, -- pvs.*,
          v_to_org_id, -- 2538 org_id,
          --pvc.*,
          pvc.inactive_date,
          pvc.first_name, pvc.middle_name,
          pvc.last_name, pvc.prefix, pvc.title, pvc.mail_stop, pvc.area_code, pvc.phone,
          pvc.contact_name_alt, pvc.first_name_alt, pvc.last_name_alt, pvc.department, 
          pvc.email_address, pvc.url, pvc.alt_area_code, pvc.alt_phone, pvc.fax_area_code, pvc.fax
    from PO_VENDOR_CONTACTS pvc, po_vendor_sites_all pvs, po_vendor_sites_all new_site
    where pvs.vendor_site_id = pvc.vendor_site_id 
    --and   pvs.vendor_id = 742015 
    and   pvs.org_id = v_from_org_id
    and   pvc.inactive_date is null
    and   pvs.vendor_id = new_site.vendor_id
    and   pvs.vendor_site_code = new_site.vendor_site_code
    and   v_to_org_id = new_site.org_id 
    and   new_site.vendor_site_id = i.new_vendor_site_id;
  end loop;
end load_site_cont_to_interface;
end xxha_transfer_vendor_info;
/
