CREATE OR REPLACE PACKAGE
   XXHA_COMMON_UTILITIES_PKG
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |Name       : XXHA_COMMON_UTILITIES_PKG                             |                                                        |
-- |                                                                   |
-- |Description: Package consisting of all common utilities including  |
-- |             error handling                                        |
-- |                                                                   |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT1A   19-Sep-2006  Fajna K P       Initial draft version       |
-- |1.0       13-Nov-2006  Fajna K P       After review                |
-- +===================================================================+
AS

--Procedure to Insert the error records into Common Error Table
PROCEDURE INSERT_ERROR_PRC(
                            p_request_id        NUMBER
                           ,p_record_number     NUMBER
                           ,p_record_identifier VARCHAR2
                           ,p_error_code        VARCHAR2
                           ,p_error_msg         VARCHAR2
                           ,p_comments          VARCHAR2 DEFAULT NULL
                           ,p_table_name        VARCHAR2 DEFAULT NULL
                           ,p_attribute1        VARCHAR2 DEFAULT NULL
                           ,p_attribute2        VARCHAR2 DEFAULT NULL
                           ,p_attribute3        VARCHAR2 DEFAULT NULL
                           ,p_attribute4        VARCHAR2 DEFAULT NULL
                           ,p_attribute5        VARCHAR2 DEFAULT NULL
                           ,x_status      OUT   VARCHAR2
                         );

--Procedure to Delete the error records from the  Common Error table
PROCEDURE DELETE_ERROR_PRC(p_conc_name          VARCHAR2
                          );

--Procedure to Launch the Error Report
PROCEDURE LAUNCH_ERROR_REPORT_PRC(
                                  p_request_id IN OUT NUMBER
                                 ,p_concurrent_name   VARCHAR2
                                 ,p_record_identifier VARCHAR2
                                 );

--Procedure to Print the Debug Messages
PROCEDURE PRINT_MSG_PRC(p_debug   IN VARCHAR2
                       ,p_message IN VARCHAR2
                       );


END XXHA_COMMON_UTILITIES_PKG;

/


CREATE OR REPLACE PACKAGE BODY
   XXHA_COMMON_UTILITIES_PKG
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |                                                                   |
-- |                                                                   |
-- |Description:   Package body consisting of all common utilities     |
-- |               including error handling                            |
-- |                                                                   |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT1A   19-Sep-2006  Fajna K P       Initial draft version       |
-- |1.0       18-Oct-2006  Fajna K P       After review                |
-- +===================================================================+
AS

-- +===================================================================+
-- | Name       :   INSERT_ERROR_PRC                                   |
-- | Description: I Procedure to insert error into the                 |
-- |                xxha_common_errors table                           |
-- |                                                                   |
-- | Parameters :   p_request_id                                       |
-- |                p_record_number                                    |
-- |                p_record_identifier                                |
-- |                p_error_code                                       |
-- |                p_error_msg                                        |
-- |                p_comments                                         |
-- |                p_table_name                                       |
-- |                p_attribute1                                       |
-- |                p_attribute2                                       |
-- |                p_attribute3                                       |
-- |                p_attribute4                                       |
-- |                p_attribute5                                       |
-- |                x_status                                           |
-- |                                                                   |
-- | Returns    :   x_status                                           |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE INSERT_ERROR_PRC(
                          p_request_id        NUMBER
                         ,p_record_number     NUMBER
                         ,p_record_identifier VARCHAR2
                         ,p_error_code        VARCHAR2
                         ,p_error_msg         VARCHAR2
                         ,p_comments          VARCHAR2 DEFAULT NULL
                         ,p_table_name        VARCHAR2 DEFAULT NULL
                         ,p_attribute1        VARCHAR2 DEFAULT NULL
                         ,p_attribute2        VARCHAR2 DEFAULT NULL
                         ,p_attribute3        VARCHAR2 DEFAULT NULL
                         ,p_attribute4        VARCHAR2 DEFAULT NULL
                         ,p_attribute5        VARCHAR2 DEFAULT NULL
                         ,x_status      OUT   VARCHAR2
                         )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN

   --Inserting into Common Errors Table
   INSERT INTO XXHA_COMMON_ERRORS(
                                  request_id
                                 ,record_number
                                 ,record_identifier
                                 ,error_code
                                 ,error_msg
                                 ,comments
                                 ,table_name
                                 ,attribute1
                                 ,attribute2
                                 ,attribute3
                                 ,attribute4
                                 ,attribute5
                                 ,created_by
                                 ,creation_date
                                 ,last_updated_by
                                 ,last_update_login
                                 ,last_update_date
                                 )
                          VALUES (
                                  p_request_id
                                 ,p_record_number
                                 ,p_record_identifier
                                 ,p_error_code
                                 ,p_error_msg
                                 ,p_comments
                                 ,p_table_name
                                 ,p_attribute1
                                 ,p_attribute2
                                 ,p_attribute3
                                 ,p_attribute4
                                 ,p_attribute5
                                 ,FND_GLOBAL.USER_ID
                                 ,SYSDATE
                                 ,FND_GLOBAL.USER_ID
                                 ,FND_GLOBAL.USER_ID
                                 ,SYSDATE
                                 );
   COMMIT;
   x_status:='Y';
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in xxha_common_utilities_pkg.insert_error_prc: ' || SQLERRM);
   x_status:='N';
END INSERT_ERROR_PRC;


-- +===================================================================+
-- | Name       :   DELETE_ERROR_PRC                                   |
-- | Description:   Procedure to delete the error records from the     |
-- |                xxha_common_errors table                           |
-- |                to insert errors into error table                  |
-- |                                                                   |
-- | Parameters :   p_conc_name                                        |
-- |                                                                   |
-- |                                                                   |
-- | Returns    :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE DELETE_ERROR_PRC(p_conc_name       VARCHAR2
                          )
IS
PRAGMA AUTONOMOUS_TRANSACTION;

--Deleting from Common error Table depending on the Concurrent Program Passed
BEGIN
   DELETE
   FROM  xxha_common_errors
   WHERE request_id IN (
                        SELECT FCR.request_id
                        FROM   fnd_concurrent_requests FCR
                        WHERE  FCR.concurrent_program_id IN (
                                                             SELECT FCR1.concurrent_program_id
                                                             FROM   fnd_concurrent_programs FCR1
                                                             WHERE  FCR1.concurrent_program_name = p_conc_name
                                                            )
                       );

COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in xxha_common_utilities_pkg.delete_error_prc: ' || SQLERRM);
END DELETE_ERROR_PRC;

-- +===================================================================+
-- | Name       :   LAUNCH_ERROR_REPORT_PRC                            |
-- | Description:   Procedure to launch the error report based         |
-- |                on the request id                                  |
-- |                                                                   |
-- | Parameters :   p_request_id                                       |
-- |                p_concurrent_name                                  |
-- |                p_record_identifier                                |
-- |                                                                   |
-- | Returns    :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE LAUNCH_ERROR_REPORT_PRC( p_request_id IN OUT NUMBER
                                  ,p_concurrent_name   VARCHAR2
                                  ,p_record_identifier VARCHAR2
                                 )
IS
   ln_request_id NUMBER;
BEGIN

   --Submitting the Common Error Report
   ln_request_id := FND_REQUEST.SUBMIT_REQUEST('HAEMO'
                                              ,'XXHA_COMMON_ERROR_REPORT'
                                              ,'XXHA: Error Report'
                                              , SYSDATE
                                              , FALSE
                                              , p_request_id
                                              , p_concurrent_name
                                              , p_record_identifier
                                              );

   --Retrieving Request Id for the Error Report
   p_request_id:=ln_request_id;

   IF ln_request_id = 0 THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG, 'Cannot submit request for Error Report');
   END IF;

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in xxha_common_utilities_pkg.launch_error_report_prc: ' || SQLERRM);
END LAUNCH_ERROR_REPORT_PRC;

-- +===================================================================+
-- | Name       :   PRINT_MSG_PRC                                      |
-- | Description:   Procedure to print message to the log which        |
-- |                helps in debugging the script                      |
-- |                                                                   |
-- | Parameters :   p_debug                                            |
-- |                p_message                                          |
-- |                                                                   |
-- |                                                                   |
-- | Returns    :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +======================================================================+
PROCEDURE PRINT_MSG_PRC(p_debug   IN VARCHAR2
                       ,p_message IN VARCHAR2
                       )
IS
BEGIN

  --Logging the messages
  IF (p_debug  = 'Y') THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,p_message);
  END IF;

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error while writing the '||p_message||' to the log file. Error is '||SQLERRM);
END PRINT_MSG_PRC;

END XXHA_COMMON_UTILITIES_PKG;

/
