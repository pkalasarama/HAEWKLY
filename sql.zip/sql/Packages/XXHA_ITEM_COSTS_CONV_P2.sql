CREATE OR REPLACE package XXHA_ITEM_COSTS_CONV_P2
-- +===========================================================================+
-- | Name        : XXHA_INV_CONV_ITM_P2_PK                                     |
-- | Purpose     : Support the conversion of Item business object into EBS.    |
-- |                                                                           |
-- | Description : For this conversion, an object includes the item, item      |
-- |               assignments at organizations (including master [MST]),      |
-- |               item revisions and item category (primary classification    |
-- |               on MST item only).                                          |
-- |               Data is provided in 3 staging tables:                       |
-- |                  XXHA_ITEMS_CLEANED_STG                                   |
-- |                  XXHA_ITEM_INVORGS_STG                                    |
-- |                  XXHA_ITEM_REVISIONS_STG                                  |
-- |               Staged data is validated.  If all data is succcessfully     |
-- |               validated, the item objects are then moved to the open      |
-- |               interface tables.  If a single failure is detected, no      |
-- |               item objects are interfaced and an error report is launched |
-- |               as a separate concurrent request.                           |
-- |                                                                           |
-- |               Note: All or nothing approach!!                             |
-- |                                                                           |
-- | Comment     : This package interfaces item objects, it does not launch    |
-- |               standard Import Items program.  This must be done manually. |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20080923  1.0  Palash Kundu       Initial version                                  |
-- +===========================================================================+
AS
      -- Global Variables Declaration

      gn_record_number         xxha_common_errors.record_number%TYPE;                                          --Record_number of staging table
      gc_record_identifier     xxha_common_errors.record_identifier%TYPE;                                      --Record identifier of staging table
      gc_error_code            xxha_common_errors.error_code%TYPE;                                             --Error_code insert in common error table
      gc_error_msg             xxha_common_errors.error_msg%TYPE;                                              --Error_msg  insert in common error table
      gc_comments              xxha_common_errors.comments%TYPE;                                               --Comments   insert in common error table
      gc_attribute1            xxha_common_errors.attribute1%TYPE;                                             --Attribute1 insert in common error table
      gc_attribute2            xxha_common_errors.attribute2%TYPE;                                             --Attribute2 insert in common error table
      gc_attribute3            xxha_common_errors.attribute3%TYPE;                                             --Attribute3 insert in common error table
      gc_attribute4            xxha_common_errors.attribute4%TYPE;                                             --Attribute4 insert in common error table
      gc_attribute5            xxha_common_errors.attribute5%TYPE;                                             --Attribute5 insert in common error table
      gc_table_name            xxha_common_errors.table_name%TYPE;                                             --Variable to get Staging Table Name
      gc_status                VARCHAR2(2);                                                                    --Variable to get status flag of data insertion in common error table
      gc_conc_name             fnd_concurrent_programs.concurrent_program_name%TYPE :='XXHA_ITEM_CONV_P2';        --Concurrent program name to delete the records from common error table

gc_error_logged  varchar2(1);
gc_invorg_only_flag  varchar2(1);
gc_table_ITM  varchar2(30) := 'XXHA_ITEMS_CLEANED_STG';
gc_table_ORGITM  varchar2(30) := 'XXHA_ITEM_INVORGS_STG';
gc_table_ITMREV  varchar2(30) := 'XXHA_ITEM_REVISIONS_STG';
gc_valtype_SETUP  varchar2(30) := 'SETUP';
gc_valtype_DUPLICATE  varchar2(30) := 'DUPLICATE';
gc_valtype_ITM  varchar2(30) := 'ITM';
gc_valtype_ORGITM  varchar2(30) := 'ORGITM';
gc_valtype_ITMREV  varchar2(30) := 'ITMREV';

gn_user_id  fnd_user.user_id%type := fnd_global.user_id;
gc_material_sub_element  bom_resources.resource_code%type := 'Material';  -- Material Sub-Element
gc_debug_flag  varchar2(1);  --Debug_flag for display debug
gc_category_set_name  mtl_category_sets_tl.category_set_name%type :='Inventory';  --Default Category Set name
gn_process_flag  mtl_system_items_interface.process_flag%type := 1;  -- Default process_flag
gc_master_org  mtl_parameters.organization_code%type :='MST';  -- Master Organization Name
--      gc_template_d            mtl_item_templates.template_name%TYPE                :='Disposable Finished Goods'; --Template Name for Template Identifier D
--      gc_template_s            mtl_item_templates.template_name%TYPE                :='Parts - Non returnable';--Template Name for Template Identifier S
--      gc_template_n            mtl_item_templates.template_name%TYPE                :='Non-Inventory';         --Template Name for Template Identifier E
--      gc_template_e            mtl_item_templates.template_name%TYPE                :='Equipment Finished Goods';--Template Name for Template Identifier N
--      gc_template_r            mtl_item_templates.template_name%TYPE                :='Parts - Returnable';    --Template Name for Template Identifier R
      gc_language_code         fnd_languages.language_code%TYPE                     :='US';                    --Language_code
      gc_log_msg               VARCHAR2(1000);                                                                 --Log_msg to display msgs
      gc_error_report          VARCHAR2(1)                                          := 'N';                    --Error_report launch if its <>'N'
      gn_request_id            xxha_common_errors.request_id%TYPE                   := fnd_global.conc_request_id;--Request Id of running concurrent Program
      gc_program_name          VARCHAR2(50)                                         :='Item Conversion PreValidation';       --Program Name In parameter for launch_error_prc procedure
      gc_rec_identifier        VARCHAR2(50)                                         :='Item Number';           --Record identifier In parameter for launch_error_prc procedure
      gc_auto_lot_alpha_prefix mtl_system_items_interface.auto_lot_alpha_prefix%TYPE:='1';                     --Variable for auto_lot_alpha_prefix
      gc_start_auto_lot_number mtl_system_items_interface.start_auto_lot_number%TYPE:='1';                     --Variable for start_auto_lot_number
      gc_starting_revision     mtl_parameters.starting_revision%TYPE;                                          --Variable to get staring revision against the Inventory Orgs

      --Start of changes V1.1
gc_set_proc_id_mst       mtl_system_items_interface.set_process_id%type       := 1;                       --Variable to get set process id for Master Inventory Org
gc_set_proc_id_child     mtl_system_items_interface.set_process_id%type       := 2;                       --Variable to get set process id for Child Inventory Orgs
      --End of changes V1.1
      --Start of Changes V1.2
       gc_org_assigments_flag   VARCHAR2(10);
      --End of Changes V1.2

   ------------------------------------------------------------
   -- Global record counters
   ------------------------------------------------------------
   gn_cnt_dupitm  number := 0;
   gn_cnt_duporgitm  number := 0;
   gn_cnt_dupitmrev  number := 0;
   gn_cnt_read_itm  number := 0;
   gn_cnt_valid_itm  number := 0;
   gn_cnt_invalid_itm  number := 0;
   gn_cnt_read_oi  number := 0;
   gn_cnt_valid_oi  number := 0;
   gn_cnt_invalid_oi  number := 0;
   gn_cnt_read_rv  number := 0;
   gn_cnt_valid_rv  number := 0;
   gn_cnt_invalid_rv  number := 0;


gd_now  date;
gc_interface_error  varchar2(1);

gr_icSetup  xxha_inv_common_utilities_pk.gr_icSetupRec;

type g_itemStatusRec is record (
     code  mtl_item_status.inventory_item_status_code%type
    ,description  mtl_item_status.description%type
    );
type g_itemStatusTabType is table of g_itemStatusRec index by binary_integer;

gt_itemStatuses  xxha_inv_common_utilities_pk.g_itemStatusTabType;
g_item_status_list  varchar2(2000);



PROCEDURE pre_processing_item_cost
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_debug  in  varchar2
        ,p_purge_data  in  varchar2
        ,p_commit_flag  in  varchar2
		,p_force_commit in varchar2
        );


--PROCEDURE UPDATE_COST_TYPE;

--PROCEDURE LOAD_CST_ITEM_CST_DTLS_INT;

--PROCEDURE VALIDATE_ITEM_CST_DTLS_STG;

end XXHA_ITEM_COSTS_CONV_P2;
/


CREATE OR REPLACE package body      XXHA_ITEM_COSTS_CONV_P2
as
-- +===========================================================================+
-- | Name        : XXHA_ITEM_COSTS_CONV_P2                                    |
-- | Purpose     : Support the conversion of Item Cost business object into EBS.    |
-- |                                                                           |
-- | Description : For this conversion, an object includes the item, item      |
-- |               assignments at organizations (including master [MST]),      |
-- |               item revisions and item category (primary classification    |
-- |               of MST item.                                                |
-- |               Data is provided in 1 staging tables:                       |
-- |                  XXHA_ITEM_CST_DTLS_STG                                  |
-- |                                                     |
-- |                                                   |
-- |               Staged data is validated.  If all data is succcessfully     |
-- |               validated, the item objects are then moved to the open      |
-- |               interface tables.  If a single failure is detected, no      |
-- |               item objects are interfaced and an error report is launched |
-- |               as a separate concurrent request.                           |
-- |                                                                           |
-- |               Note: All or nothing approach!!                             |
-- |                                                                           |
-- | Comment     : This package interfaces item objects, it does not launch    |
-- |               standard Import Items program.  This must be done manually. |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20080915  1.0  Palash Kundu      Initial version                          |
-- | 20100301  2.0  Raj Reddy	      Changes for item cost upload             |
-- +===========================================================================+

   ------------------------------------------------------------
   -- Cursor for logged errors
   ------------------------------------------------------------
   cursor c_err (
           q_request_id  xxha_common_errors.request_id%type
          ,q_table_name  xxha_common_errors.table_name%type
          ,q_conc_name  xxha_common_errors.attribute4%type
          ,q_valtype  xxha_common_errors.attribute5%type
          ) is
     select  ce.error_code
            ,ce.error_msg
            ,count(1)  cnt
     from    xxha_common_errors  ce
     where   ce.request_id = q_request_id
     and     nvl(ce.table_name,'~!@') = nvl(q_table_name,nvl(ce.table_name,'~!@'))
     and     ce.attribute4 = q_conc_name
     and     ce.attribute5 = q_valtype
     group by ce.error_code
             ,ce.error_msg
     order by 1;


   ------------------------------------------------------------
   -- Cursor for staged items with status NEW
   ------------------------------------------------------------
   cursor c_newitm
             is
     SELECT  itm.*
            ,null  stock_enabled_flag   --YN
            ,null  mtl_transactions_enabled_flag   --YN
            ,to_number(null)  make_buy_code   --12
            ,to_number(null)  template_lot_control   --12
            ,itm.rowid
     FROM    xxha_items_cleaned_stg  itm
     where   itm.ci_flag = 'C'
     and     itm.status = 'NEW';
   newitm  c_newitm%rowtype;

   ------------------------------------------------------------
   -- Cursor for staged organizaton items with status NEW
   ------------------------------------------------------------
   cursor c_neworgitm (
            q_item_number  xxha_item_invorgs_stg.item_number%type
           ,q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           ,q_invorg_only_flag  varchar2
           ) is
     SELECT  orgitm.*
            ,orgitm.item_number||'/'||orgitm.inventory_org_code  org_item
            ,orgitm.rowid
     FROM    xxha_item_invorgs_stg  orgitm
     where   orgitm.ci_flag = 'C'
     and     orgitm.status = 'NEW'
     and     orgitm.item_number = q_item_number
     and     orgitm.item_record_id = q_item_record_id
     --and     orgitm.inventory_org_code != decode(q_invorg_only_flag,'Y','MST','-9-')
     order by decode(orgitm.inventory_org_code,'MST',1,9)
             ,orgitm.inventory_org_code;
   neworgitm  c_neworgitm%rowtype;

   ----------------------------------------------------------------------------
   -- Cursor for staged item revisions with status NEW
   -- At source, revisions are at the item level.  In Oracle, revisions are at
   -- the organization item level.
   -- So ... in EBS, revisions at all applicable inventory organization levels
   -- must be maintaixned at the same level as the master (MST) organization.
   ------------------------------------------------------------
   /*cursor c_newitmrev (
            q_item_number  xxha_item_invorgs_stg.item_number%type
           ,q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           ,q_invorg_only_flag  varchar2
           ) is
     SELECT  itmrev.*
            ,itmrev.item_number||'/'||itmrev.revision_no  item_rev
            ,itmrev.rowid
     FROM    xxha_item_revisions_stg  itmrev
     where   itmrev.ci_flag = 'C'
     and     itmrev.status = 'NEW'
     and     itmrev.item_number = q_item_number
     and     itmrev.item_record_id = q_item_record_id
     order by itmrev.revision_no;
   newitmrev  c_newitmrev%rowtype;
*/
--     TYPE XX_COMMON_ERROR IS RECORD OF XXHA_COMMON_ERRORS%ROWTYPE;



    TYPE XX_COMMON_ERROR_Tbl_Type IS TABLE OF XXHA_COMMON_ERRORS%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_COMMON_ERROR_TBL		XX_COMMON_ERROR_Tbl_Type;

   ------------------------------------------------------------
   -- Cursor for staged items objects that have been
   -- wholly and sucessfully validate
   ------------------------------------------------------------
  /* cursor c_vsitm
             is
      select  i.*
             ,i.rowid
      from    xxha_items_cleaned_stg  i
      where   1=1
      and     i.object_status = 'VALID'
      and     i.status = 'VS'
      and     i.ci_flag = 'C'
      order by i.item_number;
   vsitm  c_vsitm%rowtype;

   ------------------------------------------------------------
   -- Cursor for staged org items with status VS
   -- for a specific item ordered by org with MST first
   ------------------------------------------------------------
   cursor c_vsoi (
            q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           ,q_item_number  xxha_item_invorgs_stg.item_number%type
           ) is
      select  oi.*
             ,oi.rowid
      from    xxha_item_invorgs_stg  oi
      where   oi.item_record_id = q_item_record_id
      and     oi.item_number = q_item_number
      and     oi.status = 'VS'
      and     oi.ci_flag = 'C'
      and     oi.inventory_org_code <> decode(gc_invorg_only_flag,'Y','MST','-9-')
      order by decode(oi.inventory_org_code,'MST',1,9)
              ,oi.inventory_org_code;
   vsoi  c_vsoi%rowtype;
*/
   ------------------------------------------------------------
   -- Cursor for staged item revision with status VS
   -- for a specific item ordered by revision
   ------------------------------------------------------------
/*   cursor c_vsrv (
          --  q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           --,q_item_number  xxha_item_invorgs_stg.item_number%type
           ) is
      select  rv.*
             ,rv.rowid
      from    xxha_item_revisions_stg  rv
      where   rv.item_record_id = q_item_record_id
      and     rv.item_number = q_item_number
      and     rv.status = 'VS'
      and     rv.ci_flag = 'C'
      order by revision_no;
   vsrv  c_vsrv%rowtype;

*/
-- +=========================================================================
-- | Procedure to log errors in XXHA_COMMON_ERRORS table
-- +=========================================================================
procedure log_error
          is
begin
   gc_error_logged := 'Y';
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,gc_comments
                            ,gc_table_name
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
	dbms_output.put_line('error '||gc_error_code||gc_error_msg||gc_comments);
exception
   when others then
      fnd_file.put_line(fnd_file.log,'Error in XXHA_INV_CONV_ITM_P2_PK.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
end log_error;

procedure populate_common_error(error_msg varchar2) is
  l_error_counter number;
begin
dbms_output.put_line(' popu err small '||substr(error_msg,1,2000));
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := gn_record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := gc_error_code;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := gc_record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := gc_comments;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;
dbms_output.put_line(' popu err 2'||substr(error_msg,1,2000));

end populate_common_error;

procedure populate_common_error(error_msg varchar2,error_code varchar2,error_comments varchar2,record_number number,record_identifier varchar2) is
  l_error_counter number;
begin
dbms_output.put_line(' popu err large '||substr(error_msg,1,2000));
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := substr(error_code,1,20);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_comments,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;

end populate_common_error;


procedure log_all_errors IS
l_error_occured boolean := FALSE;
BEGIN
  dbms_output.put_line('All Error '||xx_common_error_tbl.count);
  FOR i IN 1..XX_COMMON_ERROR_TBL.COUNT LOOP
     l_error_occured := TRUE;
     gn_request_id :=  XX_COMMON_ERROR_TBL(i).request_id;
     gn_record_number := XX_COMMON_ERROR_TBL(i).record_number;
     gc_record_identifier := XX_COMMON_ERROR_TBL(i).record_identifier ;
     gc_error_code := XX_COMMON_ERROR_TBL(i).error_code;
     gc_error_msg := XX_COMMON_ERROR_TBL(i).error_msg;
     gc_comments  :=  XX_COMMON_ERROR_TBL(i).comments;
     gc_table_name :=  XX_COMMON_ERROR_TBL(i).table_name;
     gc_attribute1 :=  XX_COMMON_ERROR_TBL(i).attribute1;
     gc_attribute2 :=  XX_COMMON_ERROR_TBL(i).attribute2;
     gc_attribute3:=  XX_COMMON_ERROR_TBL(i).attribute3;
     gc_attribute4 :=  XX_COMMON_ERROR_TBL(i).attribute4;
     gc_attribute5 :=  XX_COMMON_ERROR_TBL(i).attribute5;

	 log_error;


  ENd LOOP;
  IF NOT l_error_occured THEN
    xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,'No Error Occured'
                            ,'XXHA_ITEM_CST_DTLS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
    gc_error_logged := 'N';
	dbms_output.put_line('No err ');
  END IF;

END;

-- +=========================================================================
-- | This procedure checks for duplicate staged records.
-- | Duplicate records are flagged as validation error.
-- | If at least duplicate in the batch was found, the other records are
-- | flagged to indicate aborted validation ... All or Nothing!
-- | A duplication error will abort the reuqest with 'Error' completion status.
-- +=========================================================================
procedure check_duplicates  is



   ------------------------------------------------------------
   -- Cursor to count duplicate staged organization items Costs
   ------------------------------------------------------------
   cursor c_dup2
             is
      select  x.item_number
             ,x.organization_code
			 ,cost_element
             ,count(1)  record_cnt
      from    xxha_item_cst_dtls_stg  x
      where   x.status = 'NEW'
      group by x.item_number
              ,x.organization_code
			  ,x.cost_element
      having count(1) > 1;



begin

   ------------------------------------------------------------
   -- Check for duplicate staged organization items
   ------------------------------------------------------------
   for dup2 in c_dup2  loop




         gc_record_identifier := dup2.item_number;
         gc_table_name := 'XXHA_ITEM_CST_DTLS_STG';
         gc_attribute5 := 'DUPLICATE';
         gc_error_code := 'DUP-02';
         gc_error_msg := 'Organization Item '||dup2.item_number||' Org '||dup2.organization_code||' Cost Element'||dup2.cost_element||' combo staged multiple times.';
         gc_comments := 'Merge/Remove duplicate records for Org Item '||gc_record_identifier||' - staged '||' multiple times.';
         log_error;

         update  xxha_item_cst_dtls_stg
         set     status = 'VE'
         where   item_number = dup2.item_number
		 and     organization_code = dup2.organization_code
		 and     cost_element = dup2.cost_element
         and     status = 'NEW';




   end loop;

end check_duplicates;


-- +=========================================================================
-- | This procedure buffers active item status codes in a pl/sql table
-- | The table of values will be used for validation.
-- +=========================================================================
procedure buffer_item_statuses
          is
   cursor c_st is
      select  inventory_item_status_code  item_status_code
             ,description
      from    mtl_item_status
      where   nvl(disable_date,TRUNC(SYSDATE)) >= TRUNC(SYSDATE);
   st_index  number := 0;

begin
   for strec in c_st
   loop
      st_index := st_index + 1;
      gt_itemStatuses(st_index).code := strec.item_status_code;
      gt_itemStatuses(st_index).description := strec.description;
      if (st_index = 1) then
         g_item_status_list := 'Values: '||strec.item_status_code;
      else
         g_item_status_list := g_item_status_list||', '||strec.item_status_code;
      end if;
   end loop;
   if (st_index = 0) then
      g_item_status_list := 'No active item statuses defined.';
   end if;
end buffer_item_statuses;

-- +=========================================================================
-- | Populate Items Table
-- +=========================================================================

procedure update_make_cost_type_id
is

cursor c_cst_dtls is
select *
  from xxha_item_cst_dtls_stg
  where error_flag <>  'PS'
  --and cost_type = 'CNVP1MAKE'
  ;
  l_cost_type_id number;
begin
  select cost_type_id
   into l_cost_type_id
   from cst_cost_types
   where cost_type = 'CNVP1MAKE';

  update xxha_item_cst_dtls_stg
  set cost_type_id = l_cost_type_id
  where cost_type = 'CNVP1MAKE'
  ;
  commit;
  select cost_type_id
   into l_cost_type_id
   from cst_cost_types
   where cost_type = 'CNVFRZ';

  update xxha_item_cst_dtls_stg
  set cost_type_id = l_cost_type_id
  where cost_type = 'CNVFRZ'
  ;
  commit;
  select cost_type_id
   into l_cost_type_id
   from cst_cost_types
   where cost_type = 'CNVMATL';

  update xxha_item_cst_dtls_stg
  set cost_type_id = l_cost_type_id
  where cost_type = 'CNVMATL'
  ;
  commit;


end;

PROCEDURE create_mtl_cost_type is
  cursor c_cst is
  select *
  from xxha_item_cst_dtls_stg
  where error_flag <>  'PS'
  and cost_element = 'Material'
  and cost_type = 'CNVP1MAKE'
  and item_number not in
  (select item_number from xxha_item_cst_dtls_stg where cost_type = 'CNVMATL' and error_flag <> 'PS');

  l_record_id number;
  l_cost_type_id number;

 BEGIN
   --CNVMATL
   select max(record_id)
   into l_record_id
   from xxha_item_cst_dtls_stg;

   select cost_type_id
   into l_cost_type_id
   from cst_cost_types
   where cost_type = 'CNVMATL';

   for v_cst in c_cst loop
   	   l_record_id := l_record_id +1;
	   insert into xxha_item_cst_dtls_stg (organization_code,cost_type,resource_code,cost_element,process_flag,item_number,record_id,usage_rate_or_amount,cost_type_id)
                                values(v_cst.organization_code,'CNVMATL',v_cst.resource_code,v_cst.cost_element,'1',v_cst.item_number,l_record_id,v_cst.usage_rate_or_amount,l_cost_type_id);
   end loop;
   commit;
   EXCEPTION
   when others then
      dbms_output.put_line('err '||substr(sqlerrm,1,1000));
	  populate_common_error('CNVMTL'||substr(sqlerrm,1,1000));

 END;


PROCEDURE UPDATE_COST_TYPE  IS
  cursor c_cst_dtls_stg is
  select *
  from xxha_item_cst_dtls_stg
  where error_flag <>  'PS'
  and cost_type_id is null;
  l_cost_type varchar2 (2000) := 'CNV';
  l_cost_type_id number;
  l_chk_num number;
  l_error_occured boolean;
BEGIN
   FOR v_cst_dtl_stg in c_cst_dtls_stg LOOP
     l_error_occured := false;
    l_cost_type := 'CNV';
	begin
	   select distinct 1
	   into l_chk_num
	   from cst_item_cost_details
	   where cost_type_id = 1
	   and inventory_item_id = v_cst_dtl_stg.inventory_item_id
	   and organization_id = v_cst_dtl_stg.organization_id;
	   l_cost_type := l_cost_type||'P1';
	 exception
	  when no_data_found then
	    l_cost_type := l_cost_type||'P2';
	  when others then
      	   dbms_output.put_line('err '||substr(sqlerrm,1,1000));
	  	   populate_common_error(v_cst_dtl_stg.record_id||'1UPDATE_COST_TYPE '||substr(sqlerrm,1,1000));
	 end;

	 IF v_cst_dtl_stg.based_on_rollup_flag = 1 THEN
	    l_cost_type := l_cost_type||'MAKE';
	 ELSE
	    l_cost_type := l_cost_type||'BUY';
	 END IF;
	 begin
	  select cost_type_id
	  into l_cost_type_id
	  from cst_cost_types
	  where cost_type = l_cost_type;

	  Update xxha_item_cst_dtls_stg
	 set cost_type = l_cost_type
	 ,cost_type_id = l_cost_type_id
	 where inventory_item_id = v_cst_dtl_stg.inventory_item_id
	 and organization_id = v_cst_dtl_stg.organization_id
	 and nvl(cost_type,'TEST') <> 'CNVMATL';


	 exception
	   when no_data_found then
	     l_error_occured := true;
		 populate_common_error('INVALID_COST_TYPE_DERIVATION',
		                                                       'CST_INVALID_COST_TYPE',
															  'Cost Type'||l_cost_type||' is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
		when others then
      dbms_output.put_line('err '||substr(sqlerrm,1,1000));
	  populate_common_error(v_cst_dtl_stg.record_id||'2UPDATE_COST_TYPE '||substr(sqlerrm,1,1000));

	 end;

	 IF l_error_occured THEN
	   Update xxha_item_cst_dtls_stg
	   set error_flag = 'VE'
	   where record_id = v_cst_dtl_stg.record_id;
	 END IF;

   END LOOP;
   EXCEPTION
   when others then
      dbms_output.put_line('err '||substr(sqlerrm,1,1000));
	  populate_common_error('UPDATE_COST_TYPE '||substr(sqlerrm,1,1000));

END UPDATE_COST_TYPE;


-- +=========================================================================
-- | Populate MTL_ITEM_CATEGORIES_INTERFACE
-- +=========================================================================
procedure load_cst_item_cst_dtls_int
          is
   e_abort  exception;
   cursor c_cst_stg is
   select *
   from xxha_item_cst_dtls_stg
   where error_flag <>'PS';
begin
  FOR v_cst_stg in c_cst_stg LOOP
    begin
	    INSERT INTO BOM.CST_ITEM_CST_DTLS_INTERFACE
		 ( INVENTORY_ITEM_ID,
		   COST_TYPE_ID,
		   GROUP_ID,
		   ORGANIZATION_ID,
		   LEVEL_TYPE,
		   RESOURCE_ID,
		   RESOURCE_RATE,
		   USAGE_RATE_OR_AMOUNT,
		   BASIS_TYPE,
		   BASIS_FACTOR,
		   NET_YIELD_OR_SHRINKAGE_FACTOR,
		   ITEM_COST,
		   COST_ELEMENT_ID,
		   ROLLUP_SOURCE_TYPE,
		   REQUEST_ID,
		   COST_TYPE,
		   PROGRAM_APPLICATION_ID,
		   PROGRAM_ID,
		   PROGRAM_UPDATE_DATE,
		   TRANSACTION_ID,
		   PROCESS_FLAG,
		   TRANSACTION_TYPE,
		   LOT_SIZE,
		   BASED_ON_ROLLUP_FLAG,
		   SHRINKAGE_RATE,
		   INVENTORY_ASSET_FLAG,
		   GROUP_DESCRIPTION
	     )
		 VALUES
		 (
	           v_cst_stg.INVENTORY_ITEM_ID,
		   v_cst_stg.COST_TYPE_ID,
		   nvl(v_cst_stg.GROUP_ID,v_cst_stg.COST_TYPE_ID),--v_cst_stg.GROUP_ID, Rev 2.0 changes
		   v_cst_stg.ORGANIZATION_ID,
		   v_cst_stg.LEVEL_TYPE,
		   v_cst_stg.RESOURCE_ID,
		   v_cst_stg.RESOURCE_RATE,
		   v_cst_stg.USAGE_RATE_OR_AMOUNT,
		   v_cst_stg.BASIS_TYPE,
		   v_cst_stg.BASIS_FACTOR,
		   v_cst_stg.NET_YIELD_OR_SHRINKAGE_FACTOR,
		   v_cst_stg.ITEM_COST,
		   v_cst_stg.COST_ELEMENT_ID,
		   v_cst_stg.ROLLUP_SOURCE_TYPE,
		   v_cst_stg.REQUEST_ID,
		   v_cst_stg.COST_TYPE,
		   v_cst_stg.PROGRAM_APPLICATION_ID,
		   v_cst_stg.PROGRAM_ID,
		   v_cst_stg.PROGRAM_UPDATE_DATE,
		   v_cst_stg.TRANSACTION_ID,
		   v_cst_stg.PROCESS_FLAG,
		   v_cst_stg.TRANSACTION_TYPE,
		   v_cst_stg.LOT_SIZE,
		   v_cst_stg.BASED_ON_ROLLUP_FLAG,
		   v_cst_stg.SHRINKAGE_RATE,
		   v_cst_stg.INVENTORY_ASSET_FLAG,
		   v_cst_stg.GROUP_DESCRIPTION); -- Rev 2.0 changes

		   update xxha_item_cst_dtls_stg
		   set error_flag = 'PS'
		   where record_id = v_cst_stg.record_id
		   and item_number =  v_cst_stg.item_number
		   and organization_code = v_cst_stg.organization_code
		   and cost_element = v_cst_stg.cost_element
		   and resource_code = v_cst_stg.resource_code;
    exception
	  when others then
	     populate_common_error(substr(sqlerrm,1,2000),
		                                                       'CST_INSERTFAILED',
															  'INSERT INTO CST FALIED',
															  v_cst_stg.record_id,
															  v_cst_stg.item_number||'/'||v_cst_stg.organization_code);

    end;
  ENd LOOP;

dbms_output.put_line('rev insert ok');
exception
   when others then
      fnd_file.put_line(fnd_file.log,'Error inserting into MTL_ITEM_REVISIONS_INTERFACE ...');
      fnd_file.put_line(fnd_file.log,SQLERRM);
	  dbms_output.put_line('rev insert ok err'||substr(SQLERRM,1,1000));
       populate_common_error(substr(sqlerrm,1,2000),
		                                                       'CST_INSERT FAILED',
															  'INSERT TO CST DTLS FAILED',
															  100000,
															  'WHEN OTHERS ERROR 100000');
end LOAD_CST_ITEM_CST_DTLS_INT;

Procedure chk_Buy_Item_Has_Bom IS

cursor c_get_items is
select *
from xxha_item_cst_dtls_stg;

cursor c_item_has_bom (q_item_number varchar2,q_organization_code varchar2 ) is
select assembly_item_id
from bom_bill_of_materials bom,mtl_system_items items,mtl_parameters param
where assembly_item_id = items.inventory_item_id
and bom.organization_id = items.organization_id
and items.segment1 = q_item_number
and items.organization_id = bom.organization_id
and items.organization_id = param.organization_id
and organization_code = q_organization_code
;
cursor c_item_has_rtg (q_item_number varchar2,q_organization_code varchar2 ) is
select assembly_item_id
from bom_operational_routings rtg,mtl_system_items items,mtl_parameters param
where assembly_item_id = items.inventory_item_id
and rtg.organization_id = items.organization_id
and items.segment1 = q_item_number
and items.organization_id = rtg.organization_id
and items.organization_id = param.organization_id
and organization_code = q_organization_code
;
Begin
  for v_get_items in c_get_items loop
    for v_item_has_bom in c_item_has_bom (v_get_items.item_number,v_get_items.organization_code ) loop
	  update xxha_item_cst_dtls_stg
	  set based_on_rollup_flag = 1
	  where item_number = v_get_items.item_number
	  and organization_code = v_get_items.organization_code
	  ;

	end loop;
    for v_item_has_rtg in c_item_has_rtg (v_get_items.item_number,v_get_items.organization_code ) loop
	  update xxha_item_cst_dtls_stg
	  set based_on_rollup_flag = 1
	  where item_number = v_get_items.item_number
	  and organization_code = v_get_items.organization_code
	  ;

	end loop;
  end loop;


End;

-- +=========================================================================
-- | Populate MTL_ITEM_CATEGORIES_INTERFACE
-- +=========================================================================
PROCEDURE validate_item_cst_dtls_stg IS


   l_validation_ok boolean := true;
  l_chk_num number;
  cursor c_cst_dtl_stg is
  select *
  from xxha_item_cst_dtls_stg
  where error_flag <> 'PS';
BEGIN
  UPDATE xxha_item_cst_dtls_stg item_cst_stg
  SET (inventory_item_id,lot_size,organization_id,based_on_rollup_flag,shrinkage_rate,inventory_asset_flag) =
  (Select  items.inventory_item_id,
           nvl(std_lot_size,1),
           items.organization_id,
		   planning_make_buy_code,
           nvl(shrinkage_rate, decode(planning_make_buy_code,2,0,0)),
           decode(inventory_asset_flag,'Y',1,'N',2,NULL,NULL)
   FROM mtl_system_items items,mtl_parameters param
   WHERE items.organization_id = param.organization_id
   AND param.organization_code = item_cst_stg.organization_code
   AND items.segment1 = item_cst_stg.item_number
   );
   chk_Buy_Item_Has_Bom;
   --check_duplicates;
   dbms_output.put_line('before up cst type');
   --update_cost_type;
     dbms_output.put_line('after up cst type');
  FOR v_cst_dtl_stg in c_cst_dtl_stg LOOP


	  l_validation_ok := true;
	  IF v_cst_dtl_stg.Organization_id is null AND v_cst_dtl_stg.organization_code is null THEN
	    l_validation_ok := false;
		populate_common_error(substrb(fnd_message.get_string('BOM','CST_NULL_ORGANIZATION'),1,240),
		                                                      'CST_NULL_ORGANIZATION',
															  'Organization Id and Organization Code is Null',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);

	  ELSE
	    begin
		   select 1
		   into l_chk_num
		   from mtl_parameters mp
           where (NVL(v_cst_dtl_stg .organization_id,mp.organization_id) = mp.organization_id)
           AND (NVL(v_cst_dtl_stg .organization_code,mp.organization_code) = mp.organization_code);

		   Update XXHA_ITEM_CST_DTLS_STG ct
		   SET organization_id = (select organization_id
                       		   	  FROM mtl_parameters mp
                                  WHERE mp.organization_code = ct.organization_code
                                 )
		   WHERE ct.organization_id is null;

	    exception
		  when no_data_found then
		    l_validation_ok := false;
		    populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_ORGANIZATION'),1,240),
		                                                      'CST_INVALID_ORGANIZATION',
															  'Organization Id or Organization Code is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);
		end;

	  END IF;
	 /*begin
	   Select 1
	   into l_chk_num
	   from MTL_PARAMETERS mp
	   WHERE mp.cost_organization_id <> mp.organization_id
       AND mp.organization_id = v_cst_dtl_stg .organization_id ;

	  exception
	    when no_data_found then
		  l_validation_ok := false;
		  populate_common_error(substrb(fnd_message.get_string('BOM','CST_NOT_COSTINGORG'),1,240),
		                                                       'CST_NOT_COSTINGORG',
															  'Organization Id or Organization Code is not Cost Org',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);

	  end;*/
	  IF v_cst_dtl_stg.inventory_item_id IS NULL AND v_cst_dtl_stg.item_number IS NULL THEN
	    l_validation_ok := false;
		populate_common_error(substrb(fnd_message.get_string('BOM','CST_NULL_ITEMID'),1,240),
		                                                       'CST_NULL_ITEMID',
															  'Inventory Item Id or Item Number is Null',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);


	  ELSIF v_cst_dtl_stg.inventory_item_id IS NULL THEN
	    begin
		  select 1
		  into l_chk_num
		  from mtl_system_items msi
                 where v_cst_dtl_stg.organization_id = msi.organization_id
                 AND v_cst_dtl_stg.inventory_item_id = msi.inventory_item_id;

		  Update XXHA_ITEM_CST_DTLS_STG ct
		   SET inventory_item_id = (select inventory_item_id
                       		   	  FROM mtl_system_items items
                                  WHERE items.organization_id = v_cst_dtl_stg.organization_id
								  and   items.segment1 = v_cst_dtl_stg.item_number
                                 )
		   WHERE ct.inventory_item_id is null;

		exception
		  WHEN no_data_found THEN
		     l_validation_ok := false;
		     populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_ITEM_ID'),1,240),
		                                                       'CST_INVALID_ITEM_ID',
															  'Inventory Item Id or Item Number is Not Valid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);

		end;


	  ELSIF v_cst_dtl_stg.item_number IS NULL THEN
	     Update XXHA_ITEM_CST_DTLS_STG ct
		   SET item_number = (select segment1
                       		   	  FROM mtl_system_items items
                                  WHERE items.organization_id = v_cst_dtl_stg.organization_id
								  and   items.inventory_item_id = v_cst_dtl_stg.inventory_item_id
                                 )
		   WHERE ct.item_number is null;
	  ELSE
	    begin
		  select 1
		  into l_chk_num
		  from mtl_system_items msi
                 where v_cst_dtl_stg.organization_id = msi.organization_id
                 AND v_cst_dtl_stg.inventory_item_id = msi.inventory_item_id;

		exception
		  WHEN no_data_found THEN
		     l_validation_ok := false;
		     populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_ITEM_ID'),1,240),
		                                                       'CST_INVALID_ITEM_ID',
															  'Inventory Item Id or Item Number is Not Valid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);

		end;

	  END IF;
	  IF v_cst_dtl_stg.inventory_asset_flag IS NULL THEN
	    l_validation_ok := false;
	    populate_common_error('Inventory_Assest_flag is Null',
		                                                       'CST_INV_ASSET_FLAG_IS_NULL',
															  'Inventory Asset Flag is Null',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);

	  ELSE
	    begin
	     select 1
		 into l_chk_num
		 from mtl_system_items msi
               where msi.inventory_item_id = v_cst_dtl_stg.inventory_item_id
               and msi.organization_id = v_cst_dtl_stg.organization_id
               and msi.inventory_asset_flag = 'Y';
		exception
		  when no_data_found then
		    l_validation_ok := false;
		    populate_common_error(substrb(fnd_message.get_string('BOM','CST_NOT_INVASSITEM'),1,240),
		                                                       'CST_NOT_INVASSITEM',
															  'Inventory Item not Inventory asset in this org',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);
		end;




	  END IF;
      IF v_cst_dtl_stg.cost_element IS NULL AND v_cst_dtl_stg.cost_element_id IS NULL THEN
	    l_validation_ok := false;
		populate_common_error(substrb(fnd_message.get_string('BOM','CST_NULL_COSTELEMENT'),1,240),
		                                                       'CST_NULL_COSTELEMENT',
															  'Cost Element AND Cost Element ID is NULL',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);

	  ELSE
	    begin

		  Select 1
		  into l_chk_num
		  from cst_cost_elements cce
		  where   NVL(v_cst_dtl_stg.cost_element_id,cce.cost_element_id)= cce.cost_element_id
				AND NVL(v_cst_dtl_stg.cost_element,cce.cost_element) = cce.cost_element;

		  Update xxha_item_cst_dtls_stg ct
		  set  ct.cost_element_id = (select cost_element_id from cst_cost_elements cce
                                     WHERE cce.cost_element = v_cst_dtl_stg.cost_element)

          WHERE ct.cost_element_id is null
		  and ct.cost_element = v_cst_dtl_stg.cost_element;

		exception
		  when no_data_found then
		    l_validation_ok := false;
		    populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_COSTELEMENT'),1,240),
		                                                       'CST_INVALID_COSTELEMENT',
															  'Cost Element OR Cost Element ID is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);
		end;
	  END IF;
	  IF v_cst_dtl_stg.resource_code IS NULL AND v_cst_dtl_stg.resource_id IS NULL THEN
	      l_validation_ok := false;
		  populate_common_error('CST_NULL_COST_SUB_ELEMENT',
		                                                       'CST_NULL_COST_SUB_ELEMENT',
															  'Cost Resource Code AND Cost Resource ID is Null',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code);
	  ELSE
	    begin
		 select 1
		 into l_chk_num
		 from bom_resources bm
                WHERE NVL(v_cst_dtl_stg.resource_id,bm.resource_id)=bm.resource_id
                AND NVL(v_cst_dtl_stg.resource_code,bm.resource_code)=bm.resource_code
                AND v_cst_dtl_stg.cost_element_id = bm.cost_element_id
                AND v_cst_dtl_stg.organization_id = bm.organization_id
				AND bm.functional_currency_flag = 1
				AND ((sysdate >= NVL(bm.disable_date,sysdate)) OR (bm.allow_costs_flag = 2));

		 Update xxha_item_cst_dtls_stg ct
		 set ct.resource_id = (select bm.resource_id
		                       from bom_resources bm
                      		   WHERE ct.resource_code = bm.resource_code
                      		   AND bm.organization_id = ct.organization_id
                      		   AND ct.cost_element_id = bm.cost_element_id
                     		   )
	     	WHERE ct.resource_id is null
		 AND ct.resource_code is not null;
		exception
		  when no_data_found then
		    l_validation_ok := false;
		    populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_SUBELEMENT'),1,240),
		                                                       'CST_INVALID_SUBELEMENT',
															  'Cost Resource Code OR Cost Resource ID is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
		end;

	  END IF;

	  /*IF v_cst_dtl_stg.cost_type is not null then
	    begin
	      select 1
		  into l_chk_num
		  from cst_item_costs cic
		  where    v_cst_dtl_stg.organization_id = cic.organization_id
                   and cic.cost_type_id = v_cst_dtl_stg.cost_type_id
                   and v_cst_dtl_stg.inventory_item_id = cic.inventory_item_id
                   AND (v_cst_dtl_stg.lot_size is null OR v_cst_dtl_stg.based_on_rollup_flag is null OR v_cst_dtl_stg.shrinkage_rate is null OR v_cst_dtl_stg.inventory_asset_flag is null);

		exception
		  when no_data_found then
		     l_validation_ok := false;
		     populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_DEFCSTTYPE'),1,240),
		                                                       'CST_INVALID_DEFCSTTYPE',
															  'Cost Type / Item Combo is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);

		end;
	  ENd IF;*/

	  IF v_cst_dtl_stg.usage_rate_or_amount IS NULL or nvl(v_cst_dtl_stg.usage_rate_or_amount,0) < 0 THEN
	     l_validation_ok := false;
		 populate_common_error(substrb(fnd_message.get_string('BOM','CST_NULL_USAGERTORAMT'),1,240),
		                                                       'CST_NULL_USAGERTORAMT',
															  'Cost is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
	  ENd IF;

	  IF ((v_cst_dtl_stg.cost_element_id IN (1,3,4,5,6) AND v_cst_dtl_stg.basis_type NOT IN (1,2)) OR (v_cst_dtl_stg.cost_element_id = 2 AND (v_cst_dtl_stg.basis_type <= 0 OR v_cst_dtl_stg.basis_type > 6))) THEN
	    l_validation_ok := false;
		populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_BASISTYPE'),1,240),
		                                                       'CST_INVALID_BASISTYPE',
															  'Cost Basis is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
	  END IF;

	  IF (v_cst_dtl_stg.shrinkage_rate < 0 OR v_cst_dtl_stg.shrinkage_rate >= 1) THEN
	    l_validation_ok := false;
		populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_SHRRATE'),1,240),
		                                                       'CST_INVALID_SHRRATE',
															  'Shrinkage Rate is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
	  END IF;
	  IF v_cst_dtl_stg.lot_size <= 0 THEN
	     l_validation_ok := false;
		 populate_common_error(substrb(fnd_message.get_string('BOM','CST_ZERO_LOTSIZE'),1,240),
		                                                       'CST_ZERO_LOTSIZE',
															  'Shrinkage Rate is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
	  ENd IF;
	  IF  v_cst_dtl_stg.based_on_rollup_flag NOT IN (1,2) THEN
	    l_validation_ok := false;
		populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_BASEDONRLP'),1,240),
		                                                       'CST_INVALID_BASEDONRLP',
															  'Shrinkage Rate is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
	  ENd IF;

	  IF v_cst_dtl_stg.inventory_asset_flag NOT IN (1,2) THEN
	     l_validation_ok := false;
		 populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_INVASSETFLG'),1,240),
		                                                       'CST_INVALID_INVASSETFLG',
															  'Inventory Assest Flag is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
	  ENd IF;

      IF nvl(v_cst_dtl_stg.resource_rate,0) <> 0 THEN
	     l_validation_ok := false;
		 populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_RESRATE'),1,240),
		                                                       'CST_INVALID_RESRATE',
															  'Resource Rate is Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);

	  END IF;

	  IF  v_cst_dtl_stg.based_on_rollup_flag <> 1 AND v_cst_dtl_stg.shrinkage_rate <> 0 THEN

	     l_validation_ok := false;
		 populate_common_error(substrb(fnd_message.get_string('BOM',' CST_INVALID_BUYITEM'),1,240),
		                                                       ' CST_INVALID_BUYITEM',
															  'Buy Item Invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);

	  END IF;
	  declare
	    l_chk_4_flag number := 0;
	  begin

	     select 1
		 into l_chk_4_flag
   		 from xxha_ITEM_CST_dtls_stg ct1
   		 where exists (select 1 from xxha_ITEM_CST_dtls_stg ct2 where
              ((NVL(ct1.based_on_rollup_flag,-1)<> NVL(ct2.based_on_rollup_flag,-1))
              OR (NVL(ct1.shrinkage_rate,-1) <> NVL(ct2.shrinkage_rate,-1))
              OR (NVL(ct1.inventory_asset_flag,-1) <> NVL(ct2.inventory_asset_flag,-1))
              OR (NVL(ct1.lot_size,-1) <> NVL(ct2.lot_size,-1)))
              AND ct1.organization_id = ct2.organization_id
              AND ct1.inventory_item_id = ct2.inventory_item_id
              AND ct1.cost_type_id = ct2.cost_type_id
              AND ct1.rowid <> ct2.rowid
			               )
			  and inventory_item_id = v_cst_dtl_stg.organization_id
			  and organization_id = v_cst_dtl_stg.organization_id	;

	      IF nvl(l_chk_4_flag,0) = 1 THEN
		    l_validation_ok := false;
			populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_CICFLAGS'),1,240),
		                                                       'CST_INVALID_CICFLAGS',
															  l_chk_4_flag||'chk flg'||'CICS Flag are invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
		  END IF;

	  exception
	    when no_data_found then
		  null;
		  /*populate_common_error(substrb(fnd_message.get_string('BOM','CST_INVALID_CICFLAGS'),1,240),
		                                                       'CST_INVALID_CICFLAGS',
															  'When No Data CICS Flag are invalid',
															  v_cst_dtl_stg.record_id,
															  v_cst_dtl_stg.item_number||'/'||v_cst_dtl_stg.organization_code||'/'||v_cst_dtl_stg.resource_code);
		*/
	  end;
	  dbms_output.put_line(' last upd ');
	  IF NOT l_validation_ok THEN
		    update xxha_item_cst_dtls_stg
			set error_flag = 'VE'
			where item_number =  v_cst_dtl_stg.item_number
			and organization_code =  v_cst_dtl_stg.organization_code;
		  ELSE
		     update xxha_item_cst_dtls_stg
			set error_flag = 'VS'
			where item_number =  v_cst_dtl_stg.item_number
			and organization_code =  v_cst_dtl_stg.organization_code
			and nvl(error_flag,'A') <> 'VE';
		  END IF;
			  dbms_output.put_line(' last upd 2');

  END LOOP;
--'


EXCEPTION

    when others then
      dbms_output.put_line('err '||substr(sqlerrm,1,1000));
	  populate_common_error('validate_item_cst_dtls_stg '||substr(sqlerrm,1,1000));
END validate_item_cst_dtls_stg;



-- +=========================================================================
-- | Populate Items Table
-- +=========================================================================
PROCEDURE pre_processing_item_cost
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_debug  in  varchar2
        ,p_purge_data  in  varchar2
        ,p_commit_flag  in  varchar2
		,p_force_commit in varchar2
        )
                  is

BEGIN
  dbms_output.put_line(' pre processing items ');
  gn_request_id := fnd_global.conc_request_id;  -- Concurrent request of validating program
   gc_attribute4 := gc_conc_name;
  update_make_cost_type_id;
  commit;
--   create_mtl_cost_type;
  validate_item_cst_dtls_stg;
  log_all_errors;
  commit;
  dbms_output.put_line('err?'||gc_error_logged);
  IF nvl(gc_error_logged,'N') <> 'Y' THEN
  dbms_output.put_line('load?');
    load_cst_item_cst_dtls_int;
  END IF;
  IF p_force_commit = 'Y' THEN
    load_cst_item_cst_dtls_int;
    commit;
  END IF;
  dbms_output.put_line(' validate items ');
  --populate_mst_items;
  dbms_output.put_line(' populate mst items ');
 -- update_item_category ;
  dbms_output.put_line(' update item cat ');
  IF p_commit_flag = 'Y' AND nvl(gc_error_logged,'N') <> 'Y' THEN
      dbms_output.put_line('Commit: ');
    Commit;
  ELSE
    begin
	 --dbms_output.put_line('Roll : ');

	Rollback;
	 dbms_output.put_line('Roll 1: ');
	 exception
	 when others then
	 null;
	 -- dbms_output.put_line('Roll 2: ');
	 end;
  END IF;
  dbms_output.put_line(' Start Interface Items ');
  --interface_items_rev_info;
  commit;
  dbms_output.put_line(' End Interface Items ');
 -- dbms_output.put_line('fnd_file.log',' Log all errors ');
  log_all_errors;
  commit;
EXCEPTION
WHEN OTHERS THEN
  populate_common_error('pre processing when others '||substr(sqlerrm,1,1000));
  log_all_errors;
  commit;
  dbms_output.put_line('Main When Others ');

END pre_processing_item_cost;


END XXHA_ITEM_COSTS_CONV_P2;
/
