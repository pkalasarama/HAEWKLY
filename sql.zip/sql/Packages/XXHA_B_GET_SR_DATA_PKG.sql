create or replace PACKAGE      XXHA_B_GET_SR_DATA_PKG
-- +=========================================================================================+
-- | Name        : XXHA_B_GET_SR_DATA_PKG                                                    |
-- | Purpose     : Runs insert-select statements to populate HAEMO schema                    |
-- |               tables (XXHA_B_SR_TASK_DEBRIEFS, XXHA_B_SR_LINE_NOTE_DATA)                |
-- |               for the Quality Data and Service Contracts Hyperion reports.              |
-- |                                                                                         |
-- | Tables Accessed :                                                                       |
-- | Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)           |
-- |                                                                                         |
-- | XXHA_B_SR_TASK_DEBRIEFS         D, I                                                    |
-- | XXHA_B_SR_LINE_NOTE_DATA        D, I                                                    |
-- |                                                                                         |
-- | History                                                                                 |
-- | =======                                                                                 |
-- | When      Rev  Who               What                                                   |
-- | --------  ---  --------          -------------------------------------------------      |
-- | 20150428  1.0  imenzies          CR# ESC114183 New Package based on old quality data    |
-- |                                  mart to suport service calls report                    |
-- | 20160704  1.1  vkaveti           INC#NC0080376 Added 30 DFF columns to the package      |
-- | 20170111  1.2  vkaveti           INC#INC0076354_INC0091000_INC0076354                   |
-- |                                  Added UDI and Bill-To/Ship-To Address changes          |
-- | 20170525  1.2  BMarcoux          Added new columns 'LAST_UPDATED_USERID' and            |
-- |                                    'LAST_UPDATED_USERNAME' to table                     |
-- |                                    'HAEMO.XXHA_B_SR_LINE_NOTE_DATA'                     |
-- +=========================================================================================+
AS
   PROCEDURE GET_SR_DATA (x_errbuf OUT VARCHAR2, x_retcode OUT VARCHAR2);
   
END XXHA_B_GET_SR_DATA_PKG;