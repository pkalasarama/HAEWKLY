CREATE OR REPLACE PACKAGE XXHA_PURGE_CUSTOMER_BALANCE AS

/******************************************************************************************************************
* Package Name : XXHA_PURGE_CUSTOMER_BALANCE                                                                      *
* Purpose      : This package provides a function to purge rows from the table 'XXHA_AR_CUSTOMER_BALANCE_ITF'.    *
*                This package will be used by the XML Report 'XXHA: Customer Open Balance Letter XX'.             *
*                It is called from within 'Report Triggers' > 'After Report'                                      *
*                                                                                                                 *
* Procedures   : AR_PURGE_CUSTOMER_BALANCE_ITF                                                                    *
*                                                                                                                 *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                 *
* - XXHA_AR_CUSTOMER_BALANCE_ITH      D                                                                           *
*                                                                                                                 *
* Change History                                                                                                  *
*                                                                                                                 *
* Ver        Date            Author               Description                                                     *
* ------     -----------     -----------------    ---------------                                                 *
* 1.0        15-APR-2010     BMarcoux             Initial Package creation.                                       *
*                                                                                                                 *
*******************************************************************************************************************/

  PROCEDURE AR_PURGE_CUSTOMER_BALANCE_ITF(
                                 p_request_id number
                                );

END XXHA_PURGE_CUSTOMER_BALANCE;

/


CREATE OR REPLACE PACKAGE BODY XXHA_PURGE_CUSTOMER_BALANCE AS

/******************************************************************************************************************
* Package Name : XXHA_PURGE_CUSTOMER_BALANCE                                                                      *
* Purpose      : This package provides a function to purge rows from the table 'XXHA_AR_CUSTOMER_BALANCE_ITF'.    *
*                This package will be used by the XML Report 'XXHA: Customer Open Balance Letter XX'.             *
*                It is called from within 'Report Triggers' > 'After Report'                                      *
*                                                                                                                 *
* Procedures   : AR_PURGE_CUSTOMER_BALANCE_ITF                                                                    *
*                                                                                                                 *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                 *
* - XXHA_AR_CUSTOMER_BALANCE_ITH      D                                                                           *
*                                                                                                                 *
* Change History                                                                                                  *
*                                                                                                                 *
* Ver        Date            Author               Description                                                     *
* ------     -----------     -----------------    ---------------                                                 *
* 1.0        15-APR-2010     BMarcoux             Initial Package creation.                                       *
*                                                                                                                 *
*******************************************************************************************************************/

  PROCEDURE AR_PURGE_CUSTOMER_BALANCE_ITF(
                                 p_request_id number
                                ) AS
  BEGIN

  DELETE FROM HAEMO.XXHA_AR_CUSTOMER_BALANCE_ITF
  WHERE Request_id = p_request_id;

  END AR_PURGE_CUSTOMER_BALANCE_ITF;

END XXHA_PURGE_CUSTOMER_BALANCE;

/
