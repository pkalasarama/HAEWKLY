create or replace 
PACKAGE        "XXHA_TALEO_EMP_TR_PKG" 
IS
/*#########################################################################
  ------------------------< Employee Validation >-------------------------------
  ##########################################################################*/
PROCEDURE EMPLOYEE_Validation(
    P_HR_EMP_REC IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE);
/*#########################################################################
  ------------------------< Create Employee >-------------------------------
  ##########################################################################*/
PROCEDURE Update_EMPLOYEE_INFO(
    P_HR_EMP_REC IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2); 
/*#########################################################################
------------------------< Create Employee Address>-------------------------
##########################################################################*/
PROCEDURE CREATE_EMPLOYEE_ADDRESS(
    P_HR_EMP_REC IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    P_ERR_MSG OUT VARCHAR2);
/*#########################################################################
------------------------< Create Contact>--------------------------
##########################################################################*/
PROCEDURE CREATE_CONTACT(
   P_HR_EMP_REC IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    L_LASTNAME  VARCHAR2,
    L_FIRSTNAME  VARCHAR2,
    L_MIDDLENAME VARCHAR2,    
    L_RELATIONSHIP VARCHAR2,
    --L_CONTACT_TYPE VARCHAR2,
    L_MARITAL_DATE DATE,
    L_PERSONAL_FLAG  VARCHAR2,
    L_NATIONAL_IDENTIFIER VARCHAR2,
    L_DATE_OF_BIRTH DATE,
    L_sex VARCHAR2,
    P_ERR_MSG OUT VARCHAR2);
/*#########################################################################
------------------< Create Person Extra Information>------------------------
##########################################################################*/
PROCEDURE CREATE_PERSON_EXTRA_INFO(
L_PERSONID number,
L_INFORMATION_TYPE VARCHAR2,
L_INFORMATION_CATEGORY  VARCHAR2,
L_INFORMATION1 VARCHAR2,
L_INFORMATION2 VARCHAR2,
L_INFORMATION3 VARCHAR2,
L_INFORMATION4 VARCHAR2,
L_INFORMATION5 VARCHAR2,
L_INFORMATION6 VARCHAR2,
L_INFORMATION7 VARCHAR2,
L_INFORMATION8 VARCHAR2,
L_INFORMATION9 VARCHAR2,
L_INFORMATION10 VARCHAR2,
L_INFORMATION11 VARCHAR2,
L_INFORMATION12 VARCHAR2,
L_INFORMATION13 VARCHAR2,
L_INFORMATION14 VARCHAR2,
L_INFORMATION15 VARCHAR2,
L_PERSON_EXTRA_INFO_ID OUT  NUMBER,
L_OBJECT_VERSION_NUMBER OUT NUMBER
);
/*#########################################################################
------------------< Create Employee Phone Details>------------------------
##########################################################################*/
PROCEDURE CREATE_EMP_PH_DETAILS(
    L_PHONE_TYPE VARCHAR2,
    L_PHONE_NUMBER VARCHAR2,
    L_CONTACT_PERSON_ID number,
    P_ERR_MSG OUT VARCHAR2);

/*#########################################################################
------------------< Create Qualification Details>------------------------
##########################################################################*/
PROCEDURE CREATE_Qualification_DETAILS(
    P_HR_EMP_REC IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    P_ERR_MSG OUT VARCHAR2);
	
/*#########################################################################
----------------------------< Main Procedure>-------------------------------
##########################################################################*/
PROCEDURE MAIN(
    ERRBUFF      VARCHAR2,
    retcode      NUMBER);
END;
/

create or replace 
PACKAGE BODY        "XXHA_TALEO_EMP_TR_PKG" 
IS
  /*#########################################################################
  Package : XXHA_TALEO_EMP_TR_PKG
  Date: 12/Jun/2015
  Description:This Package used to update Recruit interface employees and
  to create employee dependent details,
  Address, Phones, Contact Details(With Phone number),
  Highest Qualification and Extra Person Information
  Approach.
  Change Date:27/Jun/2015   Change Description    Version
  ---------------------------------------------------------------------------
  ##########################################################################*/
  G_PERSON_ID PER_ALL_PEOPLE_F.person_id%TYPE;
  G_SEQ_NO     NUMBER;
  G_ADDRESS_ID NUMBER;
  G_BUSINESS_GROUP_ID per_all_people_f.BUSINESS_GROUP_ID%type;
  G_BUSINESS_GROUP per_business_groups.NAME%Type;
  l_count NUMBER := 0;
  G_Employee_number per_all_people_f.EMPLOYEE_NUMBER%type;
  /*#########################################################################
  Employee Validation
  ##########################################################################*/
PROCEDURE EMPLOYEE_VALIDATION(
    P_HR_EMP_REC IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE)
IS
  LS_EMP_COUNT                NUMBER;
  LS_EMP_C1                   NUMBER;
  LS_EMP_C2                   NUMBER;
  LS_EMP_C3                   NUMBER;
  LS_EMP_C4                   NUMBER;
  LS_EMP_C5                   NUMBER;
  LS_EMP_C6                   NUMBER;
  LS_EMP_C7                   NUMBER;
  LS_EMP_C8                   NUMBER;
  LS_EMP_C9                   NUMBER;
  LS_EMP_C10                  NUMBER;
  LS_CONTACT_TYPE             VARCHAR2(100);
  LS_employee_number          VARCHAR2(100);
  LS_BUSINESS_GROUP_ID        NUMBER;
  LS_BUSINESS_GROUP           VARCHAR2(100);
  LS_MARITAL_STATUS           VARCHAR2(100);
  LS_EC_PHONE                 VARCHAR2(100);
  LS_NAME_PREFIX              VARCHAR2(100);
  LS_EEO_GENDER               VARCHAR2(100);
  LS_EEO_Ethnicity            VARCHAR2(100);
  LS_EEO_RACE                 VARCHAR2(100);
  LS_EEO_VETS100A             VARCHAR2(100);
  LS_EC_RELATIONSHIP          VARCHAR2(100);
  LS_EC_CONTACT_TYPE          VARCHAR2(100);
  LS_EC_CONTACT_TYPE2         VARCHAR2(100);
  LS_MY_RACE_ETHNIC_GROUP     VARCHAR2(100);
  LS_BLOOD_TYPE               VARCHAR2(100);
  LS_BIRTH_COUNTRY            VARCHAR2(100);
  LS_QUALIFICATION_TYPE_ID    NUMBER;
  LS_CITIZENSHIP              VARCHAR2(100);
  LS_MY_NEW_NRIC_COUNT        NUMBER;
  LS_MY_STATE                 VARCHAR2(30);
  LS_MX_STATE                 VARCHAR2(30); --Added
  LS_AU_STATE                 VARCHAR2(30); --Added
  LS_STATE_ABBREVIATION       VARCHAR2(30);
  LS_MY_BANK_NAME             VARCHAR2(150);
  LS_MY_BANK_ACCT_STATUS      VARCHAR2(150);
  LS_MY_CONT_TO_SOCSO         VARCHAR2(15);
  LS_My_Cont_To_Epf           VARCHAR2(15);
  LS_MY_TAX_FI_COMB_WITH_SPOU VARCHAR2(30);
  LS_MY_SPOUSE_WOR_STATUS     VARCHAR2(30);
  LS_MY_VISA_PERMIT_TYPE      VARCHAR2(150);
  LS_MY_VISA_ISSUING_STATE    VARCHAR2(150);
  LS_PASSPORT_COUNTRY         VARCHAR2(150);
  LS_EC2_RELATIONSHIP         VARCHAR2(150);
  LS_EC2_CONTACT_TYPE         VARCHAR2(150);
  LS_EC2_CONTACT_TYPE2        VARCHAR2(150);
  LS_MY_SPOUSE_NRIC_COUNT     VARCHAR2(150);
  LS_MY_SPOUSE_GENDER         VARCHAR2(15);
  LS_MY_PREVIOUS_EMPL_STATE   VARCHAR2(150);
  LS_object_version_number PER_ALL_PEOPLE_F.OBJECT_VERSION_NUMBER%TYPE;
  ls_assignment_id PER_ALL_ASSIGNMENTS_F.ASSIGNMENT_ID%TYPE;
  ls_person_id PER_ALL_PEOPLE_F.person_id%TYPE;
  LS_MY_CHILD1_GENDER  VARCHAR2(15);
  LS_MY_CHILD2_GENDER  VARCHAR2(15);
  LS_MY_CHILD3_GENDER  VARCHAR2(15);
  LS_MY_CHILD4_GENDER  VARCHAR2(15);
  LS_MY_CHILD5_GENDER  VARCHAR2(15);
  LS_MY_CHILD6_GENDER  VARCHAR2(15);
  LS_MY_CHILD7_GENDER  VARCHAR2(15);
  LS_MY_CHILD8_GENDER  VARCHAR2(15);
  LS_MY_CHILD9_GENDER  VARCHAR2(15);
  LS_MY_CHILD10_GENDER VARCHAR2(15);
  L_COUNTY_NAME        VARCHAR2(240);
  l_ca_province        NUMBER;
  --L_COUNTY_NAME           VARCHAR2(240);
  l_active NUMBER :=0;
  l_bg     NUMBER := 0;
BEGIN
  /*#########################################################################
  Added Validation to get employee number,
  Business group ID and to update the employee of
  Recruit file(Assignment_id,person_id,object_version_number)
  ##########################################################################*/
  LS_BUSINESS_GROUP   := NULL;
  G_BUSINESS_GROUP    := NULL;
  G_BUSINESS_GROUP_ID := NULL;
  
  -- Set Who columns and Request ID
  UPDATE XXHA_TALEO_EMP_TR_STG
  SET CREATION_date  = sysdate ,
    CREATED_BY       = fnd_global.user_id ,
    LAST_UPDATE_date = sysdate ,
    LAST_UPDATED_BY  = fnd_global.user_id,
    REQUEST_ID       = fnd_global.conc_request_id
  WHERE STATUS_STG   = 'N';
  fnd_file.put_line( apps.fnd_file.LOG, 'Concurrent Request ID: '||fnd_global.conc_request_id);
  BEGIN
    fnd_file.put_line(fnd_file.log,'IN Candidate Number Validation:'||P_HR_EMP_REC.candidate_number);
    IF P_HR_EMP_REC.candidate_number IS NOT NULL THEN
      SELECT PAPF.employee_number,
        PAPF.business_group_id,
        --Paaf.assignment_id,
        MAX(Paaf.assignment_id),
        Papf.person_id,
        MAX(papf.object_version_number)
      INTO LS_employee_number,
        LS_BUSINESS_GROUP_ID,
        LS_Assignment_Id,
        LS_person_id,
        LS_object_version_number
      FROM per_all_people_f PAPF,
        per_all_assignments_f paaf
      WHERE PAPF.attribute15    =P_HR_EMP_REC.candidate_number
      AND PAPF.person_id        =paaf.person_id
      AND PAPF.business_group_id=paaf.business_group_id
      AND TRUNC (sysdate) BETWEEN NVL ( PAPF.EFFECTIVE_START_DATE, TRUNC (SYSDATE)) AND NVL ( PAPF.EFFECTIVE_END_DATE, TRUNC (SYSDATE))
      AND TRUNC (sysdate) BETWEEN NVL ( paaf.EFFECTIVE_START_DATE, TRUNC (SYSDATE)) AND NVL ( paaf.EFFECTIVE_END_DATE, TRUNC (SYSDATE))
      GROUP BY PAPF.employee_number,
        PAPF.business_group_id,
        -- Paaf.assignment_id,
        Papf.person_id;
      G_BUSINESS_GROUP_ID := LS_BUSINESS_GROUP_ID;
      g_person_id         := LS_person_id;
      fnd_file.put_line(fnd_file.log,'G_BUSINESS_GROUP_ID : '||G_BUSINESS_GROUP_ID);
      fnd_file.put_line(fnd_file.log,'g_person_id : '||g_person_id);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_EMPLOYEE_NUMBER    =LS_employee_number,
        New_BUSINESS_GROUP_ID    =LS_BUSINESS_GROUP_ID,
        New_Assignment_Id        =LS_Assignment_Id,
        New_PERSON_ID            =LS_person_id,
        New_object_version_number=LS_object_version_number
      WHERE TRANSACTION_ID_STG   = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_employee_number : '||LS_employee_number);
      fnd_file.put_line(fnd_file.log,'LS_Assignment_Id : '||LS_Assignment_Id);
      IF G_BUSINESS_GROUP_ID IS NOT NULL THEN
        SELECT name
        INTO LS_BUSINESS_GROUP
        FROM per_business_groups
        WHERE business_group_id=G_BUSINESS_GROUP_ID;
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET New_business_group   = LS_BUSINESS_GROUP
        WHERE TRANSACTION_ID_STG = G_SEQ_NO;
        COMMIT;
        G_BUSINESS_GROUP:= LS_BUSINESS_GROUP;
        FND_FILE.PUT_LINE(FND_FILE.LOG,'Business Group:'||G_BUSINESS_GROUP);
      ELSE
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE',
          ERROR_CODE   = ERROR_CODE
          ||':BGP-100',
          ERROR_MSG = ERROR_MSG
          ||'Business group name is null, '
        WHERE TRANSACTION_ID_STG = G_SEQ_NO;
        COMMIT;
      END IF;
    END IF;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    fnd_file.put_line(fnd_file.log,'Candidate number validation error : No data found');
    UPDATE XXHA_TALEO_EMP_TR_STG
    SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':CND-101' ,
      ERROR_MSG = ERROR_MSG
      ||'Candidate number Val Err - No data found,'
    WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
    COMMIT;
  WHEN too_many_rows THEN
    fnd_file.put_line(fnd_file.log,'Exception occured in Candidate Number Validation:'||sqlerrm);
    UPDATE XXHA_TALEO_EMP_TR_STG
    SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':CNN-103' ,
      ERROR_MSG = ERROR_MSG
      ||'Candidate number Val Err - Multiple records with same Candidate Number, '
    WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
    COMMIT;
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception occured in Candidate Number Validation:'||sqlerrm);
    UPDATE XXHA_TALEO_EMP_TR_STG
    SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':CNN-102' ,
      ERROR_MSG = ERROR_MSG
      ||'Candidate number Val Err - In others, '
    WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
    COMMIT;
  END;
  IF LS_BUSINESS_GROUP IS NOT NULL THEN
    SELECT COUNT(1)
    INTO l_bg
    FROM hr_lookups
    WHERE lookup_type                 = 'XXHA_TALEO_TRANSITIONS_BG'
    AND lookup_code                   = LS_BUSINESS_GROUP
    AND enabled_flag                  = 'Y'
    AND NVL(end_date_active,sysdate) >= sysdate;
    IF l_bg                           > 0 THEN
      IF LS_BUSINESS_GROUP_ID        IS NOT NULL THEN
        BEGIN
          SELECT COUNT(*)
          INTO l_active
          FROM Per_All_People_F Papf,
            Hr.Per_Person_Type_Usages_F Pptu,
            Hr.Per_Person_Types Ppt
          WHERE 1                    =1
          AND Papf.Person_Id         = Pptu.Person_Id
          AND pptu.person_type_id    = ppt.person_type_id
          AND Papf.Business_Group_Id = LS_BUSINESS_GROUP_ID
          AND (Ppt.User_Person_Type LIKE 'Employee%'
          OR Ppt.User_Person_Type LIKE 'HAE Contingent Worker')
          AND PAPF.attribute15 =P_HR_EMP_REC.candidate_number
          AND TRUNC (sysdate) BETWEEN NVL ( PAPF.EFFECTIVE_START_DATE, TRUNC (SYSDATE)) AND NVL ( PAPF.EFFECTIVE_END_DATE, TRUNC (SYSDATE))
          AND TRUNC (sysdate) BETWEEN NVL ( pptu.EFFECTIVE_START_DATE, TRUNC (SYSDATE)) AND NVL ( pptu.EFFECTIVE_END_DATE, TRUNC (SYSDATE))
          AND PPT.active_flag ='Y'
          GROUP BY papf.person_id;
          IF l_active = 0 THEN
            fnd_file.put_line(fnd_file.log,'Candidate is not active:'||sqlerrm);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':CNN-201' ,
              ERROR_MSG = ERROR_MSG
              ||'Candidate is not active, '
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Active Candidate Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':CNN-202' ,
            ERROR_MSG = ERROR_MSG
            ||'Exception in Active Candidate validation, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
      END IF;
      /*#########################################################################
      Validation for Marital Status
      ##########################################################################*/
      /*BEGIN
      fnd_file.put_line(fnd_file.log,'IN Marital Status Validation:'||P_HR_EMP_REC.MARITAL_STATUS);
      IF P_HR_EMP_REC.MARITAL_STATUS IS Not NULL  and (g_business_group='BG_MY' or g_business_group='BG_MX') THEN
      select lookup_code
      into LS_MARITAL_STATUS
      from HR_LOOKUPS
      where lookup_type='MAR_STATUS'
      and enabled_flag = 'Y'
      and upper(meaning)=upper(P_HR_EMP_REC.MARITAL_STATUS);
      fnd_file.put_line(fnd_file.log,'LS_MARITAL_STATUS : '||LS_MARITAL_STATUS);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_MARITAL_STATUS=LS_MARITAL_STATUS
      WHERE TRANSACTION_ID_STG       = G_SEQ_NO;
      COMMIT;
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'Marital Status validation error : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':MRT-103' ,
      ERROR_MSG = ERROR_MSG
      ||'Marital Status Val Err - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Exception occured in Marital Status Validation:'||sqlerrm);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||'MRT-104' ,
      ERROR_MSG = ERROR_MSG
      ||'Marital Status Val Err - In others, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END;  */
      /*#########################################################################
      Validation for Title only for Malaysia
      ##########################################################################*/
      BEGIN
        fnd_file.put_line(fnd_file.log,'In Title Validation for Malaysia:'||P_HR_EMP_REC.MY_NAME_PREFIX);
        IF P_HR_EMP_REC.MY_NAME_PREFIX IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT lookup_code
          INTO LS_NAME_PREFIX
          FROM hr_lookups
          WHERE lookup_type='TITLE'
          AND enabled_flag = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
          AND upper(meaning)=upper(P_HR_EMP_REC.MY_NAME_PREFIX);
          fnd_file.put_line(fnd_file.log,'LS_NAME_PREFIX : '||LS_NAME_PREFIX);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_NAME_PREFIX      =LS_NAME_PREFIX
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_NAME_PREFIX validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MNP-105' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_NAME_PREFIX Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in MY_NAME_PREFIX Validation:'||sqlerrm);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MNP-106' ,
          ERROR_MSG = ERROR_MSG
          ||'My Name Prefix Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for EEO_Ethnicity  (Need to check)
      ##########################################################################*/
      BEGIN
        fnd_file.put_line(fnd_file.log,'In EEO_Ethnicity for US:'||P_HR_EMP_REC.EEO_ETHNICITY);
        IF P_HR_EMP_REC.EEO_ETHNICITY IS NOT NULL AND G_BUSINESS_GROUP ='BG_US' THEN
          SELECT lookup_code
          INTO LS_EEO_Ethnicity
          FROM hr_lookups
          WHERE lookup_type='YES_NO' --'US_ETHNIC_DISCLOSURE'
          AND enabled_flag = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
          AND upper(meaning)=upper(P_HR_EMP_REC.EEO_ETHNICITY);
          fnd_file.put_line(fnd_file.log,'LS_EEO_Ethnicity : '||LS_EEO_Ethnicity);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_EEO_ETHNICITY    =LS_EEO_Ethnicity
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'EEO_Ethnicity validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':ETH-107' ,
          ERROR_MSG = ERROR_MSG
          ||'EEO_Ethnicity Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in EEO_Ethnicity Validation:'||sqlerrm);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':ETH-108' ,
          ERROR_MSG = ERROR_MSG
          ||'EEO_Ethnicity Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      --Validation for EEO_RACE
      /*BEGIN
      fnd_file.put_line(fnd_file.log,'In EEO_RACE for US:'||P_HR_EMP_REC.EEO_RACE);
      IF P_HR_EMP_REC.EEO_RACE IS Not NULL  THEN
      select lookup_code
      into LS_EEO_RACE
      from hr_lookups
      where lookup_type='GHR_US_RACE_NATIONAL_ORIGIN'
      and enabled_flag = 'Y'
      and upper(meaning)=upper(P_HR_EMP_REC.EEO_RACE);
      --and upper(meaning)=upper('Asian Indian');
      fnd_file.put_line(fnd_file.log,'LS_EEO_RACE : '||LS_EEO_RACE);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET L_EEO_RACE=LS_EEO_RACE
      WHERE TRANSACTION_ID_STG       = G_SEQ_NO;
      COMMIT;
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'EEO_RACE validation error : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ERC-125' ,
      ERROR_MSG = ERROR_MSG
      ||'EEO_RACE Val Err - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Exception occured in EEO_RACE Validation:'||sqlerrm);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ERC-126' ,
      ERROR_MSG = ERROR_MSG
      ||'EEO_RACE Val Err - In others, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END;*/
      /*#########################################################################
      Validation for EEO_VETS100A
      ##########################################################################*/
      BEGIN
        fnd_file.put_line(fnd_file.log,'In EEO_VETS100A for US:'||P_HR_EMP_REC.EEO_VETS100A);
        IF P_HR_EMP_REC.EEO_VETS100A IS NOT NULL AND G_BUSINESS_GROUP='BG_US' THEN
          SELECT oracle_vets_code
          INTO LS_EEO_VETS100A
          FROM XXHA_TALEO_EMP_VETS
          WHERE upper(ORACLE_VETS_DESC)=upper(P_HR_EMP_REC.EEO_VETS100A);
          fnd_file.put_line(fnd_file.log,'LS_EEO_VETS100A : '||LS_EEO_VETS100A);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_EEO_VETS100A     =LS_EEO_VETS100A
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'EEO_VETS100A validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EVT-109' ,
          ERROR_MSG = ERROR_MSG
          ||'EEO_VETS100A Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in EEO_VETS100A Validation:'||sqlerrm);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EVT-110' ,
          ERROR_MSG = ERROR_MSG
          ||'EEO_VETS100A Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for Employee Spouse contacts for US
      EC_RELATIONSHIP,EC_LASTNAME,EC_CONTACT_TYPE,EC_CONTACT_TYPE2,EC_PHONE,EC_PHONE2
      ##########################################################################*/
      -- July-7th
      /*BEGIN
      IF (P_HR_EMP_REC.EC_RELATIONSHIP IS NOT NULL) AND (P_HR_EMP_REC.EC_LASTNAME IS NOT NULL) THEN
      SELECT HL.LOOKUP_CODE
      INTO LS_EC_RELATIONSHIP
      FROM HR_LOOKUPS HL
      WHERE UPPER(HL.MEANING)=UPPER(P_HR_EMP_REC.EC_RELATIONSHIP)
      and enabled_flag = 'Y'
      AND HL.LOOKUP_TYPE     = 'CONTACT';
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_EC_RELATIONSHIP=LS_EC_RELATIONSHIP
      WHERE TRANSACTION_ID_STG         = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_EC_RELATIONSHIP : '||LS_EC_RELATIONSHIP);
      --Validation for EC_CONTACT_TYPE  -- This is Mobile - Work (Phone Type)
      BEGIN
      IF P_HR_EMP_REC.EC_CONTACT_TYPE IS Not NULL  THEN
      SELECT HL.LOOKUP_CODE
      INTO LS_EC_CONTACT_TYPE
      FROM HR_LOOKUPS HL
      WHERE UPPER(HL.MEANING)=UPPER(P_HR_EMP_REC.EC_CONTACT_TYPE)
      and enabled_flag = 'Y'
      AND HL.LOOKUP_TYPE     = 'PHONE_TYPE';
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_EC_CONTACT_TYPE=LS_EC_CONTACT_TYPE
      WHERE TRANSACTION_ID_STG         = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_EC_CONTACT_TYPE : '||LS_EC_CONTACT_TYPE);
      -- 29-JUNE
      ELSE
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ECT-111' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_CONTACT_TYPE is Null,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      End if;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'EC_CONTACT_TYPE validation error : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ECT-112' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_CONTACT_TYPE Val Err - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'EC_CONTACT_TYPE validation error : In Others'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ECT-113' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_CONTACT_TYPE Val Err - In others,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END;
      --29-JUNE
      -- Validation for EC_PHONE
      BEGIN
      IF (P_HR_EMP_REC.EC_PHONE IS NULL) THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':EPH-114' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_PHONE is Null,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END IF;
      EXCEPTION
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Exception occured in Validating EC_PHONE:'||SQLERRM);
      END;
      --Validation for EC_CONTACT_TYPE2
      BEGIN
      IF P_HR_EMP_REC.EC_CONTACT_TYPE2 IS Not NULL  THEN
      SELECT HL.LOOKUP_CODE
      INTO LS_EC_CONTACT_TYPE2
      FROM HR_LOOKUPS HL
      WHERE UPPER(HL.MEANING)=UPPER(P_HR_EMP_REC.EC_CONTACT_TYPE2)
      and enabled_flag = 'Y'
      AND HL.LOOKUP_TYPE     = 'PHONE_TYPE';
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_EC_CONTACT_TYPE2=LS_EC_CONTACT_TYPE2
      WHERE TRANSACTION_ID_STG          = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_EC_CONTACT_TYPE2 : '||LS_EC_CONTACT_TYPE2);
      --29-JUNE
      ELSE
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ET2-115' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_CONTACT_TYPE2 is Null,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      End if;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'EC_CONTACT_TYPE2 validation error : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ET2-116' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_CONTACT_TYPE2 Val Err - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'EC_CONTACT_TYPE2 validation error : In Others'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ET2-117' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_CONTACT_TYPE2 Val Err - In others,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END;
      -- Validation for EC_PHONE2
      --29-JUNE
      BEGIN
      IF (P_HR_EMP_REC.EC_PHONE2 IS NULL) THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':EP2-118' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_PHONE2 is Null,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END IF;
      EXCEPTION
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Exception occured in Validating EC_PHONE2:'||SQLERRM);
      END;
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'EC_RELATIONSHIP validation error : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ECR-119' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_RELATIONSHIP Val Err - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'EC_RELATIONSHIP validation error : In Others'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':ECR-120' ,
      ERROR_MSG = ERROR_MSG
      ||'EC_RELATIONSHIP Val Err - In others,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END; */
      /*#########################################################################
      --Validation for Emergency contact for MY
      EC2_RELATIONSHIP,EC2_LASTNAME,EC2_CONTACT_TYPE,EC2_CONTACT_TYPE2,
      EC_PHONE1,EC2_ALTERNATEPHONE
      ##########################################################################*/
      BEGIN
        IF (P_HR_EMP_REC.EC2_RELATIONSHIP) IS NOT NULL AND (P_HR_EMP_REC.EC2_LASTNAME IS NOT NULL) AND g_business_group='BG_MY' THEN
          SELECT HL.LOOKUP_CODE
          INTO LS_EC2_RELATIONSHIP
          FROM HR_LOOKUPS HL
          WHERE UPPER(HL.MEANING)=UPPER(P_HR_EMP_REC.EC2_RELATIONSHIP)
          AND enabled_flag       = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(HL.start_date_active,TRUNC(sysdate)) AND NVL(HL.end_date_active,'31-DEC-4712') --July-9th
          AND HL.LOOKUP_TYPE = 'CONTACT';
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_EC2_RELATIONSHIP =LS_EC2_RELATIONSHIP
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_EC2_RELATIONSHIP : '||LS_EC2_RELATIONSHIP);
          --Validation for EC2_CONTACT_TYPE  -- This is Mobile - Work (Phone Type) EC2_CONTACT_TYPE
          BEGIN
            IF P_HR_EMP_REC.EC2_CONTACT_TYPE IS NOT NULL AND g_business_group='BG_MY' THEN
              SELECT HL.LOOKUP_CODE
              INTO LS_EC2_CONTACT_TYPE
              FROM HR_LOOKUPS HL
              WHERE UPPER(HL.MEANING)=UPPER(P_HR_EMP_REC.EC2_CONTACT_TYPE)
              AND enabled_flag       = 'Y'
              AND TRUNC(sysdate) BETWEEN NVL(HL.start_date_active,TRUNC(sysdate)) AND NVL(HL.end_date_active,'31-DEC-4712') --July-9th
              AND HL.LOOKUP_TYPE = 'PHONE_TYPE';
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET New_EC2_CONTACT_TYPE =LS_EC2_CONTACT_TYPE
              WHERE TRANSACTION_ID_STG = G_SEQ_NO;
              COMMIT;
              fnd_file.put_line(fnd_file.log,'LS_EC2_CONTACT_TYPE : '||LS_EC2_CONTACT_TYPE);
              /*else
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
              ERROR_CODE     = ERROR_CODE
              ||':EC2CT_Null-230' ,
              ERROR_MSG = ERROR_MSG
              ||'EC2_CONTACT_TYPE is Null,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;*/
            END IF;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            fnd_file.put_line(fnd_file.log,'EC2_CONTACT_TYPE validation error : No data found');
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':EC2-121' ,
              ERROR_MSG = ERROR_MSG
              ||'EC2_CONTACT_TYPE Val Err - No data found, '
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'EC2_CONTACT_TYPE validation error : In Others'||SQLERRM);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':EC2-122' ,
              ERROR_MSG = ERROR_MSG
              ||'EC2_CONTACT_TYPE Val Err - In others,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END;
          -- Validation for EC2_PHONE1
          --29-JUNE
          BEGIN
            IF (P_HR_EMP_REC.EC2_PHONE1 IS NULL) AND g_business_group='BG_MY' THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':EC2-123' ,
                ERROR_MSG = ERROR_MSG
                ||'EC2_PHONE1 is Null,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in Validating EC2_PHONE1:'||SQLERRM);
          END;
          --Validation for EC2_CONTACT_TYPE2
          BEGIN
            IF P_HR_EMP_REC.EC2_CONTACT_TYPE2 IS NOT NULL AND g_business_group='BG_MY' THEN
              SELECT HL.LOOKUP_CODE
              INTO LS_EC2_CONTACT_TYPE2
              FROM HR_LOOKUPS HL
              WHERE UPPER(HL.MEANING)=UPPER(P_HR_EMP_REC.EC2_CONTACT_TYPE2)
              AND enabled_flag       = 'Y'
              AND TRUNC(sysdate) BETWEEN NVL(HL.start_date_active,TRUNC(sysdate)) AND NVL(HL.end_date_active,'31-DEC-4712') --July-9th
              AND HL.LOOKUP_TYPE = 'PHONE_TYPE';
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET New_EC2_CONTACT_TYPE2=LS_EC2_CONTACT_TYPE2
              WHERE TRANSACTION_ID_STG = G_SEQ_NO;
              COMMIT;
              fnd_file.put_line(fnd_file.log,'LS_EC2_CONTACT_TYPE2 : '||LS_EC2_CONTACT_TYPE2);
              --29-JUNE
            ELSE
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':EC2-124' ,
                ERROR_MSG = ERROR_MSG
                ||'EC2_CONTACT_TYPE2 is Null,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            fnd_file.put_line(fnd_file.log,'EC2_CONTACT_TYPE2 validation error : No data found');
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':EC2-125' ,
              ERROR_MSG = ERROR_MSG
              ||'EC2_CONTACT_TYPE2 Val Err - No data found, '
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'EC2_CONTACT_TYPE2 validation error : In Others'||SQLERRM);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':EC2-126' ,
              ERROR_MSG = ERROR_MSG
              ||'EC2_CONTACT_TYPE2 Val Err - In others,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END;
          -- Validation for EC2_ALTERNATEPHONE
          --29-JUNE
          BEGIN
            IF (P_HR_EMP_REC.EC2_ALTERNATEPHONE IS NULL) AND g_business_group='BG_MY' THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':ECA-127' ,
                ERROR_MSG = ERROR_MSG
                ||'EC2_ALTERNATEPHONE is Null,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in Validating EC2_ALTERNATEPHONE:'||SQLERRM);
          END;
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'EC2_RELATIONSHIP validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EC2-128' ,
          ERROR_MSG = ERROR_MSG
          ||'EC2_RELATIONSHIP Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'EC2_RELATIONSHIP validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EC2-129' ,
          ERROR_MSG = ERROR_MSG
          ||'EC2_RELATIONSHIP Val Err - In others,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for MY_RACE_ETHNIC_GROUP
      ##########################################################################*/
      BEGIN
        IF P_HR_EMP_REC.MY_RACE_ETHNIC_GROUP IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT A.flex_value
          INTO LS_MY_RACE_ETHNIC_GROUP
          FROM fnd_flex_values_vl a,
            fnd_flex_value_sets b
          WHERE 1                  = 1
          AND a.FLEX_VALUE_SET_ID  = B.FLEX_VALUE_SET_ID
          AND a.enabled_flag       = 'Y'
          AND upper(a.DESCRIPTION) = UPPER(P_HR_EMP_REC.MY_RACE_ETHNIC_GROUP)
          AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
          AND B.FLEX_VALUE_SET_NAME = 'HAE_HR_MY_ETHNIC_GROUPS';
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_MY_RACE_ETHNIC_GROUP=LS_MY_RACE_ETHNIC_GROUP
          WHERE TRANSACTION_ID_STG    = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_MY_RACE_ETHNIC_GROUP : '||LS_MY_RACE_ETHNIC_GROUP);
          -- Not mandatory
          /* else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||',MyRETH_Null-217' ,
          ERROR_MSG = ERROR_MSG
          ||', MY_RACE_ETHNIC_GROUP is Null'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT; */
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_RACE_ETHNIC_GROUP validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':ECT-130' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_RACE_ETHNIC_GROUP Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'MY_RACE_ETHNIC_GROUP validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':ECT-131' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_RACE_ETHNIC_GROUP Val Err - In others,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for BLOOD_TYPE only for MY
      ##########################################################################*/
      BEGIN
        IF P_HR_EMP_REC.BLOOD_TYPE IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT HL.LOOKUP_CODE
          INTO LS_BLOOD_TYPE
          FROM HR_LOOKUPS HL
          WHERE UPPER(HL.MEANING)=UPPER(P_HR_EMP_REC.BLOOD_TYPE)
          AND enabled_flag       = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(HL.start_date_active,TRUNC(sysdate)) AND NVL(HL.end_date_active,'31-DEC-4712') --July-9th
          AND HL.LOOKUP_TYPE = 'BLOOD_TYPE';
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_BLOOD_TYPE       =LS_BLOOD_TYPE
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_BLOOD_TYPE : '||LS_BLOOD_TYPE);
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'BLOOD_TYPE validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':BLT-132' ,
          ERROR_MSG = ERROR_MSG
          ||'BLOOD_TYPE Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'BLOOD_TYPE validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':BLT-133' ,
          ERROR_MSG = ERROR_MSG
          ||'BLOOD_TYPE Val Err - In others,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for BIRTH_COUNTRY only for MY
      ##########################################################################*/
      BEGIN
        IF P_HR_EMP_REC.BIRTH_COUNTRY IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT TERRITORY_CODE
          INTO LS_BIRTH_COUNTRY
          FROM FND_TERRITORIES_VL
          WHERE upper(TERRITORY_SHORT_NAME) =upper(P_HR_EMP_REC.BIRTH_COUNTRY);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_BIRTH_COUNTRY    =LS_BIRTH_COUNTRY
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_BIRTH_COUNTRY : '||LS_BIRTH_COUNTRY);
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'BIRTH_COUNTRY validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':BCO-134' ,
          ERROR_MSG = ERROR_MSG
          ||'BIRTH_COUNTRY Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'BIRTH_COUNTRY validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':BCO-135' ,
          ERROR_MSG = ERROR_MSG
          ||'BIRTH_COUNTRY Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for MY_HI_EDUCATION only for MY
      ##########################################################################*/
      BEGIN
        IF P_HR_EMP_REC.MY_HI_EDUCATION IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT qualification_type_id
          INTO LS_qualification_type_id
          FROM PER_QUALIFICATION_TYPES
          WHERE Upper(Name) = Upper(P_HR_EMP_REC.MY_HI_EDUCATION);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_qualification_type_id=LS_qualification_type_id
          WHERE TRANSACTION_ID_STG     = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_qualification_type_id : '||LS_qualification_type_id);
          /*else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||':MyEDU_Null-218' ,
          ERROR_MSG = ERROR_MSG
          ||' MY_HI_EDUCATION is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT; */
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_HI_EDUCATION validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MHE-136' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_HI_EDUCATION Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'MY_HI_EDUCATION validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MHE137' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_HI_EDUCATION Val Err - In others,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for CITIZENSHIP only for MY
      ##########################################################################*/
      BEGIN
        IF P_HR_EMP_REC.CITIZENSHIP IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT TERRITORY_CODE
          INTO LS_CITIZENSHIP
          FROM FND_TERRITORIES_VL
          WHERE upper(TERRITORY_SHORT_NAME) =upper(P_HR_EMP_REC.CITIZENSHIP);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_CITIZENSHIP      =LS_CITIZENSHIP
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_CITIZENSHIP : '||LS_CITIZENSHIP);
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'LS_CITIZENSHIP validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':CZP-138',
          ERROR_MSG = ERROR_MSG
          ||'LS_CITIZENSHIP Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'LS_CITIZENSHIP validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':CZP-139' ,
          ERROR_MSG = ERROR_MSG
          ||'LS_CITIZENSHIP Val Err - In others,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for MY_NEW_NRIC = National IDENTIFIER only for Malaysia
      ##########################################################################*/
      BEGIN
        IF P_HR_EMP_REC.MY_NEW_NRIC IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT COUNT(*)
          INTO LS_MY_NEW_NRIC_COUNT
          FROM per_all_people_f
          WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_NEW_NRIC
          AND business_group_id     = G_BUSINESS_GROUP_ID
          AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
          IF LS_MY_NEW_NRIC_COUNT <> 0 THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':MNN-140',
              ERROR_MSG = ERROR_MSG
              ||'MY_NEW_NRIC SSN No Already Exist,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_NEW_NRIC validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MNN-141',
          ERROR_MSG = ERROR_MSG
          ||'MY_NEW_NRIC Val Err - No data found,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_NEW_NRIC SSN No Validation:'||SQLERRM);
      END;
      /*#########################################################################
      Validation for MY_CONT_TO_SOCSO in My Statutory Information for Malaysia
      ##########################################################################*/
      BEGIN
        fnd_file.put_line(fnd_file.log,'In MY_CONT_TO_SOCSO:'||P_HR_EMP_REC.MY_CONT_TO_SOCSO);
        IF P_HR_EMP_REC.MY_CONT_TO_SOCSO IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT lookup_code
          INTO LS_MY_CONT_TO_SOCSO
          FROM hr_lookups
          WHERE lookup_type='YES_NO'
          AND enabled_flag = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
          AND upper(meaning)=upper(P_HR_EMP_REC.MY_CONT_TO_SOCSO);
          fnd_file.put_line(fnd_file.log,'LS_MY_CONT_TO_SOCSO : '||LS_MY_CONT_TO_SOCSO);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_MY_CONT_TO_SOCSO =LS_MY_CONT_TO_SOCSO
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          /* else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||':SOCSO_Null-219' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_CONT_TO_SOCSO is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT; */
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_CONT_TO_SOCSO validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':SOC-142' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_CONT_TO_SOCSO Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in MY_CONT_TO_SOCSO Validation:'||sqlerrm);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':SOC-143',
          ERROR_MSG = ERROR_MSG
          ||'MY_CONT_TO_SOCSO Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*#########################################################################
      Validation for MY_CONT_TO_EPF in My Statutory Information for Malaysia
      ##########################################################################*/
      BEGIN
        fnd_file.put_line(fnd_file.log,'In MY_CONT_TO_EPF for US:'||P_HR_EMP_REC.MY_CONT_TO_EPF);
        IF P_HR_EMP_REC.MY_CONT_TO_EPF IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT lookup_code
          INTO LS_MY_CONT_TO_EPF
          FROM hr_lookups
          WHERE lookup_type='YES_NO'
          AND enabled_flag = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
          AND upper(meaning)=upper(P_HR_EMP_REC.MY_CONT_TO_EPF);
          fnd_file.put_line(fnd_file.log,'LS_MY_CONT_TO_EPF : '||LS_MY_CONT_TO_EPF);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_MY_CONT_TO_EPF   =LS_MY_CONT_TO_EPF
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          /*else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||':MEPF_Null-220' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_CONT_TO_EPF is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT; */
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_CONT_TO_EPF validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EPF-144' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_CONT_TO_EPF Val Err - No data found, '
        WHERE TRANSACTION_ID_STG =P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in MY_CONT_TO_EPF Validation:'||sqlerrm);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EPF-145',
          ERROR_MSG = ERROR_MSG
          ||'MY_CONT_TO_EPF Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*###################################################################################
      Validation for MY_TAX_FI_COMB_WITH_SPOU in My Information for Tax - Malaysia
      #####################################################################################*/
      BEGIN
        IF P_HR_EMP_REC.MY_TAX_FI_COMB_WITH_SPOU IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT A.flex_value
          INTO LS_MY_TAX_FI_COMB_WITH_SPOU
          FROM fnd_flex_values_vl a,
            fnd_flex_value_sets b
          WHERE 1                 = 1
          AND a.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
          AND a.enabled_flag      = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
          AND upper(a.DESCRIPTION)  = UPPER(P_HR_EMP_REC.MY_TAX_FI_COMB_WITH_SPOU)
          AND B.FLEX_VALUE_SET_NAME = 'HAE_YES_NO_NA';
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_MY_TAX_FI_COMB_WITH_SPOU=LS_MY_TAX_FI_COMB_WITH_SPOU
          WHERE TRANSACTION_ID_STG        = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_MY_TAX_FI_COMB_WITH_SPOU : '||LS_MY_TAX_FI_COMB_WITH_SPOU);
          /*else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||':MTAX_Null-221' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_TAX_FI_COMB_WITH_SPOU is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT; */
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_TAX_FI_COMB_WITH_SPOU validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':TWS-146' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_TAX_FI_COMB_WITH_SPOU Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'MY_TAX_FI_COMB_WITH_SPOU validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':TWS-147' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_TAX_FI_COMB_WITH_SPOU Val Err - In others,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*###################################################################################
      Validation for MY_SPOUSE_WOR_STATUS in My Information for Tax
      #####################################################################################*/
      BEGIN
        IF P_HR_EMP_REC.MY_SPOUSE_WOR_STATUS IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT A.flex_value
          INTO LS_MY_SPOUSE_WOR_STATUS
          FROM fnd_flex_values_vl a,
            fnd_flex_value_sets b
          WHERE 1                 = 1
          AND a.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
          AND a.enabled_flag      = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
          AND upper(a.DESCRIPTION)  = UPPER(P_HR_EMP_REC.MY_SPOUSE_WOR_STATUS)
          AND B.FLEX_VALUE_SET_NAME = 'HAE_YES_NO_NA';
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_MY_SPOUSE_WOR_STATUS=LS_MY_SPOUSE_WOR_STATUS
          WHERE TRANSACTION_ID_STG    = G_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'LS_MY_SPOUSE_WOR_STATUS : '||LS_MY_SPOUSE_WOR_STATUS);
          /* else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||':MSPO_Null-222' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_SPOUSE_WOR_STATUS is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT; */
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_SPOUSE_WOR_STATUS validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MWS-148' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_SPOUSE_WOR_STATUS Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'MY_SPOUSE_WOR_STATUS validation error : In Others'||SQLERRM);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MWS-149' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_SPOUSE_WOR_STATUS Val Err - In others,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*###################################################################################
      -- Validations for MY_NUM_OF_CHI_FOR_TAX checking for nulls
      #####################################################################################*/
      BEGIN
        IF (P_HR_EMP_REC.MY_NUM_OF_CHI_FOR_TAX IS NULL) AND G_BUSINESS_GROUP ='BG_MY'THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':TAX-180' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_NUM_OF_CHI_FOR_TAX is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_NUM_OF_CHI_FOR_TAX of the Employee:'||SQLERRM);
      END;
      /*###################################################################################
      -- Validations for MY_BANK_ACCOUNT_NUMBER and other details
      #####################################################################################*/
      /*BEGIN
      IF (P_HR_EMP_REC.MY_BANK_ACCOUNT_NUMBER IS NULL) and G_BUSINESS_GROUP ='BG_MY' THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':BAN-182' ,
      ERROR_MSG = ERROR_MSG
      ||'MY_BANK_ACCOUNT_NUMBER is Null,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END IF;
      EXCEPTION
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_BANK_ACCOUNT_NUMBER of the Employee:'||SQLERRM);
      END;*/
      /*###################################################################################
      --Validation for MY_BANK_NAME and other  details
      #####################################################################################*/
      IF (P_HR_EMP_REC.MY_BANK_ACCOUNT_NUMBER IS NOT NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
        BEGIN
          IF P_HR_EMP_REC.MY_BANK_NAME IS NOT NULL AND g_business_group='BG_MY' THEN
            SELECT A.flex_value
            INTO LS_MY_BANK_NAME
            FROM FND_FLEX_VALUES_VL a,
              fnd_flex_value_sets b
            WHERE 1                 = 1
            AND a.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
            AND a.enabled_flag      = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
            AND upper(a.DESCRIPTION)  = UPPER(P_HR_EMP_REC.MY_BANK_NAME)
            AND B.FLEX_VALUE_SET_NAME = 'HAE_HR_MY_BANK_NAMES';
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_BANK_NAME     = LS_MY_BANK_NAME
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'LS_MY_BANK_NAME : '||LS_MY_BANK_NAME);
            /*else
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
            ERROR_CODE     = ERROR_CODE
            ||':MYBN_Null-227' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_BANK_NAME is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT; */
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'MY_BANK_NAME validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':MYB-163' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_BANK_NAME Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'MY_BANK_NAME validation error : In Others'||SQLERRM);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':MYB-164' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_BANK_NAME Val Err - In others,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        /*###################################################################################
        --Validation for MY_BANK_ACCOUNT_STATUS
        #####################################################################################*/
        BEGIN
          IF P_HR_EMP_REC.MY_BANK_ACCOUNT_STATUS IS NOT NULL AND g_business_group='BG_MY' THEN
            SELECT A.flex_value
            INTO LS_MY_BANK_ACCT_STATUS
            FROM fnd_flex_values_vl a,
              fnd_flex_value_sets b
            WHERE 1                 = 1
            AND a.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
            AND a.enabled_flag      = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
            AND upper(a.DESCRIPTION)  = UPPER(P_HR_EMP_REC.MY_BANK_ACCOUNT_STATUS)
            AND B.FLEX_VALUE_SET_NAME = 'HAE_HR_MY_BANK_ACCOUNT_STATUS';
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_BANK_ACCT_STATUS = LS_MY_BANK_ACCT_STATUS
            WHERE TRANSACTION_ID_STG    = G_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'LS_MY_BANK_ACCT_STATUS : '||LS_MY_BANK_ACCT_STATUS);
            /*else
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
            ERROR_CODE     = ERROR_CODE
            ||':MYBAS_Null-228' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_BANK_ACCOUNT_STATUS is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT; */
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'MY_BANK_ACCOUNT_STATUS validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':MBS-165' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_BANK_ACCOUNT_STATUS Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'MY_BANK_ACCOUNT_STATUS validation error : In Others'||SQLERRM);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||'MBS-166' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_BANK_ACCOUNT_STATUS Val Err - In others,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        /*###################################################################################
        -- Validations for MY_BANK_SWIFT_CODE checking for nulls
        #####################################################################################*/
        BEGIN
          IF (P_HR_EMP_REC.MY_BANK_SWIFT_CODE IS NULL) AND G_BUSINESS_GROUP ='BG_MY'THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':BSC-181' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_BANK_SWIFT_CODE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_BANK_SWIFT_CODE of the Employee:'||SQLERRM);
        END;
      END IF;
      --###################################################################################
      -- Validation for PASSPORT_COUNTRY and others in Pass Port Details - Global
      --#####################################################################################
      IF P_HR_EMP_REC.PASSPORT_NUMBER IS NOT NULL THEN
        BEGIN
          IF P_HR_EMP_REC.PASSPORT_COUNTRY IS NOT NULL THEN
            SELECT TERRITORY_CODE
            INTO LS_PASSPORT_COUNTRY
            FROM FND_TERRITORIES_VL
            WHERE upper(TERRITORY_SHORT_NAME) =upper(P_HR_EMP_REC.PASSPORT_COUNTRY);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_PASSPORT_COUNTRY =LS_PASSPORT_COUNTRY
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'LS_PASSPORT_COUNTRY : '||LS_PASSPORT_COUNTRY);
          ELSE
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':PPC-156' ,
              ERROR_MSG = ERROR_MSG
              ||'PASSPORT_COUNTRY is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'PASSPORT_COUNTRY validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':PCG-157' ,
            ERROR_MSG = ERROR_MSG
            ||'PASSPORT_COUNTRY Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'PASSPORT_COUNTRY validation error : In Others'||SQLERRM);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':PCG-158' ,
            ERROR_MSG = ERROR_MSG
            ||'PASSPORT_COUNTRY Val Err - In others,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --###################################################################################
        -- Validations for MY_PASSPORT_ISSUE_DATE checking for nulls
        --#####################################################################################
        BEGIN
          IF P_HR_EMP_REC.MY_PASSPORT_ISSUE_DATE IS NULL THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':PAS-183' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_PASSPORT_ISSUE_DATE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_PASSPORT_ISSUE_DATE of the Employee:'||SQLERRM);
        END;
        --###################################################################################
        -- Validations for MY_PASSPORT_EXPIRY_DATE checking for nulls
        --#####################################################################################
        BEGIN
          IF P_HR_EMP_REC.MY_PASSPORT_EXPIRY_DATE IS NULL THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':PED-184' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_PASSPORT_EXPIRY_DATE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_PASSPORT_EXPIRY_DATE of the Employee:'||SQLERRM);
        END;
      END IF;
      IF P_HR_EMP_REC.MY_VISA_NUMBER IS NOT NULL AND G_BUSINESS_GROUP ='BG_MY' THEN
        /*###################################################################################
        Validation for MY_VISA_PERMIT_TYPE in My Visa Information
        #####################################################################################*/
        BEGIN
          IF P_HR_EMP_REC.MY_VISA_PERMIT_TYPE IS NOT NULL AND g_business_group='BG_MY' THEN
            SELECT A.flex_value
            INTO LS_MY_VISA_PERMIT_TYPE
            FROM fnd_flex_values_vl a,
              fnd_flex_value_sets b
            WHERE 1                 = 1
            AND a.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
            AND a.enabled_flag      = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
            AND upper(a.DESCRIPTION)  = UPPER(P_HR_EMP_REC.MY_VISA_PERMIT_TYPE)
            AND B.FLEX_VALUE_SET_NAME = 'HAE_HR_MY_VISA_PERMIT_TYPES';
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_VISA_PERMIT_TYPE=LS_MY_VISA_PERMIT_TYPE
            WHERE TRANSACTION_ID_STG   = G_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'LS_MY_VISA_PERMIT_TYPE : '||LS_MY_VISA_PERMIT_TYPE);
            /* else
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
            ERROR_CODE     = ERROR_CODE
            ||':MVPT_Null-223' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_VISA_PERMIT_TYPE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT; */
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'MY_VISA_PERMIT_TYPE validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':VPT-150' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_VISA_PERMIT_TYPE Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'MY_VISA_PERMIT_TYPE validation error : In Others'||SQLERRM);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':VPT-151' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_VISA_PERMIT_TYPE Val Err - In others,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        /*###################################################################################
        Validation for MY_VISA_ISSUING_STATE in My Visa Information
        #####################################################################################*/
        BEGIN
          IF P_HR_EMP_REC.MY_VISA_ISSUING_STATE IS NOT NULL AND g_business_group='BG_MY' THEN
            SELECT A.flex_value
            INTO LS_MY_VISA_ISSUING_STATE
            FROM fnd_flex_values_vl a,
              fnd_flex_value_sets b
            WHERE 1                 = 1
            AND a.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
            AND a.enabled_flag      = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
            AND upper(a.DESCRIPTION)  = UPPER(P_HR_EMP_REC.MY_VISA_ISSUING_STATE)
            AND B.FLEX_VALUE_SET_NAME = 'HAE_MY_STATES';
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_VISA_ISSUING_STATE=LS_MY_VISA_ISSUING_STATE
            WHERE TRANSACTION_ID_STG     = G_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'LS_MY_VISA_ISSUING_STATE : '||LS_MY_VISA_ISSUING_STATE);
            /* else
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
            ERROR_CODE     = ERROR_CODE
            ||':MVID_Null-224' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_VISA_ISSUING_STATE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT; */
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'MY_VISA_ISSUING_STATE validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':VIS-152' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_VISA_ISSUING_STATE Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'MY_VISA_ISSUING_STATE validation error : In Others'||SQLERRM);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':VIS-153' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_VISA_ISSUING_STATE Val Err - In others,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        /*###################################################################################
        -- Validations for MY_VISA_COUNTRY and others in My visa Information
        #####################################################################################*/
        BEGIN
          IF (P_HR_EMP_REC.MY_VISA_COUNTRY IS NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':MVC-185' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_VISA_COUNTRY is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_VISA_COUNTRY of the Employee:'||SQLERRM);
        END;
        /*###################################################################################
        -- Validations for MY_VISA_ISSUED_BY checking for nulls
        #####################################################################################*/
        BEGIN
          IF (P_HR_EMP_REC.MY_VISA_ISSUED_BY IS NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':VIS-186' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_VISA_ISSUED_BY is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_VISA_ISSUED_BY of the Employee:'||SQLERRM);
        END;
        /*###################################################################################
        -- Validations for MY_VISA_ISSUE_DATE checking for nulls
        #####################################################################################*/
        BEGIN
          IF (P_HR_EMP_REC.MY_VISA_ISSUE_DATE IS NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':VID-187' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_VISA_ISSUE_DATE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_VISA_ISSUE_DATE of the Employee:'||SQLERRM);
        END;
        /*###################################################################################
        -- Validations for MY_VISA_EXPIRY_DATE checking for nulls
        #####################################################################################*/
        BEGIN
          IF (P_HR_EMP_REC.MY_VISA_EXPIRY_DATE IS NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':VED-188' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_VISA_EXPIRY_DATE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_VISA_EXPIRY_DATE of the Employee:'||SQLERRM);
        END;
      END IF;
      IF (P_HR_EMP_REC.MY_PREVIOUS_EMPLOYER IS NOT NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
        /*###################################################################################
        Validation for MY_PREVIOUS_EMPL_STATE in My Prior Employment Income Details
        #####################################################################################*/
        BEGIN
          IF P_HR_EMP_REC.MY_PREVIOUS_EMPL_STATE IS NOT NULL AND g_business_group='BG_MY' THEN
            SELECT A.flex_value
            INTO LS_MY_PREVIOUS_EMPL_STATE
            FROM fnd_flex_values_vl a,
              fnd_flex_value_sets b
            WHERE 1                 = 1
            AND a.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
            AND a.enabled_flag      = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
            AND upper(a.DESCRIPTION)  = UPPER(P_HR_EMP_REC.MY_PREVIOUS_EMPL_STATE)
            AND B.FLEX_VALUE_SET_NAME = 'HAE_MY_STATES';
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_PREVIOUS_EMPL_STATE=LS_MY_PREVIOUS_EMPL_STATE
            WHERE TRANSACTION_ID_STG      = G_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'LS_MY_PREVIOUS_EMPL_STATE : '||LS_MY_PREVIOUS_EMPL_STATE);
            /* else
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
            ERROR_CODE     = ERROR_CODE
            ||':MPES_Null-225' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_PREVIOUS_EMPL_STATE is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT; */
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'MY_PREVIOUS_EMPL_STATE validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':PES-154' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_PREVIOUS_EMPL_STATE Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'MY_PREVIOUS_EMPL_STATE validation error : In Others'||SQLERRM);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':PES-155' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_PREVIOUS_EMPL_STATE Val Err - In others,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --###################################################################################
        -- Validations for MY_PREVIOUS_EMPL_STREET checking for nulls
        --#####################################################################################
        BEGIN
          IF (P_HR_EMP_REC.MY_PREVIOUS_EMPL_STREET IS NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':PES-191' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_PREVIOUS_EMPL_STREET is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_PREVIOUS_EMPL_STREET of the Employee:'||SQLERRM);
        END;
        --###################################################################################
        -- Validations for MY_PREVIOUS_EMPL_POSTAL checking for nulls
        --#####################################################################################
        BEGIN
          IF (P_HR_EMP_REC.MY_PREVIOUS_EMPL_POSTAL IS NULL) AND G_BUSINESS_GROUP ='BG_MY' THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':PPO-192' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_PREVIOUS_EMPL_POSTAL is Null,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_PREVIOUS_EMPL_POSTAL of the Employee:'||SQLERRM);
        END;
      END IF;
      /*###################################################################################
      --Validation for STATE_ABBREVIATION for US State
      --#####################################################################################
      BEGIN
      IF P_HR_EMP_REC.STATE_ABBREVIATION IS NOT NULL AND g_business_group = 'BG_US' THEN
      SELECT LOOKUP_CODE
      INTO LS_STATE_ABBREVIATION
      FROM FND_COMMON_LOOKUPS
      WHERE lookup_type = 'US_STATE'
      AND enabled_flag  = 'Y'
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      --AND upper(meaning) =upper(P_HR_EMP_REC.STATE_ABBREVIATION);
      AND upper(lookup_code) =upper(P_HR_EMP_REC.STATE_ABBREVIATION);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_STATE_ABBREVIATION=LS_STATE_ABBREVIATION
      WHERE TRANSACTION_ID_STG  = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_STATE_ABBREVIATION : '||LS_STATE_ABBREVIATION);
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'STATE_ABBREVIATION validation error : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':USS-159' ,
      ERROR_MSG = ERROR_MSG
      ||'STATE_ABBREVIATION Val Err - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'STATE_ABBREVIATION validation error : In Others'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':USS-160' ,
      ERROR_MSG = ERROR_MSG
      ||'STATE_ABBREVIATION Val Err - In others,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END;
      --###################################################################################
      --Validation for STATE_ABBREVIATION for MX State
      --#####################################################################################
      BEGIN
      IF P_HR_EMP_REC.STATE_ABBREVIATION IS NOT NULL AND g_business_group = 'BG_MX' THEN
      SELECT LOOKUP_CODE
      INTO LS_MX_STATE
      FROM FND_COMMON_LOOKUPS
      WHERE lookup_type = 'MX_STATE'
      AND enabled_flag  = 'Y'
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      --AND upper(meaning) =upper(P_HR_EMP_REC.STATE_ABBREVIATION);
      AND upper(lookup_code) =upper(P_HR_EMP_REC.STATE_ABBREVIATION);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_MX_STATE         =LS_MX_STATE
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_MX_STATE MX: '||LS_MX_STATE);
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'STATE_ABBREVIATION validation error for MX : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':MXS-227' ,
      ERROR_MSG = ERROR_MSG
      ||'STATE_ABBREVIATION Val Err for MX - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'STATE_ABBREVIATION validation error for MX: In Others'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':MXS-228' ,
      ERROR_MSG = ERROR_MSG
      ||'STATE_ABBREVIATION Val Err for MX- In others,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END;
      --###################################################################################
      --Validation for STATE_ABBREVIATION for AU State
      --#####################################################################################
      BEGIN
      IF P_HR_EMP_REC.STATE_ABBREVIATION IS NOT NULL AND g_business_group = 'BG_AU' THEN
      SELECT LOOKUP_CODE
      INTO LS_AU_STATE
      FROM FND_COMMON_LOOKUPS
      WHERE lookup_type = 'AU_STATE'
      AND enabled_flag  = 'Y'
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      --AND upper(meaning) =upper(P_HR_EMP_REC.STATE_ABBREVIATION);
      AND upper(lookup_code) =upper(P_HR_EMP_REC.STATE_ABBREVIATION);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_AU_STATE         =LS_AU_STATE
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_AU_STATE AU : '||LS_AU_STATE);
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'STATE_ABBREVIATION validation error for AU : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':AUS-229' ,
      ERROR_MSG = ERROR_MSG
      ||'STATE_ABBREVIATION Val Err for AU- No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'STATE_ABBREVIATION validation error for AU : In Others'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':AUS-230' ,
      ERROR_MSG = ERROR_MSG
      ||'STATE_ABBREVIATION Val Err for AU - In others,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END;
      --###################################################################################
      --Validation for My_State
      --#####################################################################################
      BEGIN
      IF P_HR_EMP_REC.MY_STATE IS NOT NULL AND g_business_group = 'BG_MY' THEN
      SELECT LOOKUP_CODE
      INTO LS_MY_STATE
      FROM FND_COMMON_LOOKUPS
      WHERE lookup_type = 'MY_STATE'
      AND enabled_flag  = 'Y'
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      --AND upper(meaning) =upper(P_HR_EMP_REC.MY_STATE);
      AND upper(lookup_code) =upper(P_HR_EMP_REC.MY_STATE);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_MY_STATE         =LS_MY_STATE
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
      fnd_file.put_line(fnd_file.log,'LS_MY_STATE : '||LS_MY_STATE);
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      fnd_file.put_line(fnd_file.log,'MY_STATE validation error : No data found');
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':MYS-161' ,
      ERROR_MSG = ERROR_MSG
      ||'MY_STATE Val Err - No data found, '
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'MY_STATE validation error : In Others'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE   = ERROR_CODE
      ||':MYS-162' ,
      ERROR_MSG = ERROR_MSG
      ||'MY_STATE Val Err - In others,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END; */
      --------- Validation on State ABB
      l_count := 0;
      BEGIN
        IF P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'CA' THEN
          SELECT COUNT(1)
          INTO L_count
          FROM FND_COMMON_LOOKUPS
          WHERE LOOKUP_TYPE LIKE 'CA_PROVINCE'
          AND lookup_code                        = P_HR_EMP_REC.STATE_ABBREVIATION
          AND P_HR_EMP_REC.STATE_ABBREVIATION   IS NOT NULL
          AND P_HR_EMP_REC.COUNTRY_ABBREVIATION IS NOT NULL
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
          AND enabled_flag ='Y';
          IF L_count       = 0 THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'ST100:',
              ERROR_MSG = ERROR_MSG
              ||'State not valid, '
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        ELSIF P_HR_EMP_REC.COUNTRY_ABBREVIATION IN ('MY','MX') THEN
          SELECT COUNT(1)
          INTO L_count
          FROM FND_COMMON_LOOKUPS
          WHERE LOOKUP_TYPE LIKE P_HR_EMP_REC.COUNTRY_ABBREVIATION
            ||'_STATE'
          AND description                        = P_HR_EMP_REC.STATE_ABBREVIATION
          AND P_HR_EMP_REC.STATE_ABBREVIATION   IS NOT NULL
          AND P_HR_EMP_REC.COUNTRY_ABBREVIATION IS NOT NULL
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
          AND enabled_flag ='Y';
          IF L_count       = 0 THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'ST101:',
              ERROR_MSG = ERROR_MSG
              ||'State not valid, '
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        ELSE
          SELECT COUNT(1)
          INTO L_count
          FROM FND_COMMON_LOOKUPS
          WHERE LOOKUP_TYPE LIKE P_HR_EMP_REC.COUNTRY_ABBREVIATION
            ||'_STATE'
          AND lookup_code                        = P_HR_EMP_REC.STATE_ABBREVIATION
          AND P_HR_EMP_REC.STATE_ABBREVIATION   IS NOT NULL
          AND P_HR_EMP_REC.COUNTRY_ABBREVIATION IS NOT NULL
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
          AND enabled_flag ='Y';
          IF L_count       = 0 THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'ST102:',
              ERROR_MSG = ERROR_MSG
              ||'State not valid, '
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        END IF;
      END;
      /*###################################################################################
      --Validation for MY_SPOUSE_SURNAME
      #####################################################################################*/
      BEGIN
        IF (P_HR_EMP_REC.MY_SPOUSE_SURNAME IS NULL) AND g_business_group='BG_MY' THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':MSS-167' ,
            ERROR_MSG = ERROR_MSG
            ||'MY_SPOUSE_SURNAME is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_SPOUSE_SURNAME:'||SQLERRM);
      END;
      /*###################################################################################
      -- Validation for MY_SPOUSE_NRIC
      #####################################################################################*/
      BEGIN
        IF g_business_group='BG_MY' THEN
          SELECT COUNT(*)
          INTO LS_MY_SPOUSE_NRIC_COUNT
          FROM per_all_people_f
          WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_SPOUSE_NRIC
          AND business_group_id     = G_BUSINESS_GROUP_ID
          AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
          IF LS_MY_SPOUSE_NRIC_COUNT <> 0 THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE' ,
              ERROR_CODE   = ERROR_CODE
              ||':NRC-168' ,
              ERROR_MSG = ERROR_MSG
              ||'MY_SPOUSE_NRIC No Already Exist,'
            WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
            COMMIT;
          END IF;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating Employee SSN No Validation:'||SQLERRM);
      END;
      /*###################################################################################
      --Validation for MY_SPOUSE_GENDER
      #####################################################################################*/
      BEGIN
        IF P_HR_EMP_REC.MY_SPOUSE_GENDER IS NOT NULL AND g_business_group='BG_MY' THEN
          SELECT lookup_code
          INTO LS_MY_SPOUSE_GENDER
          FROM Hr_Lookups
          WHERE Lookup_Type ='SEX'
          AND enabled_flag  = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
          AND upper(meaning)=upper(p_hr_emp_rec.MY_SPOUSE_GENDER);
          fnd_file.put_line(fnd_file.log,'LS_MY_SPOUSE_GENDER : '||LS_MY_SPOUSE_GENDER);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_MY_SPOUSE_GENDER =LS_MY_SPOUSE_GENDER
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          /* else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||':MSGEND_Null-232' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_SPOUSE_GENDER is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;*/
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'MY_SPOUSE_GENDER validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MSG-169' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_SPOUSE_GENDER Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in MY_SPOUSE_GENDER Validation:'||sqlerrm);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':MSG-170' ,
          ERROR_MSG = ERROR_MSG
          ||'MY_SPOUSE_GENDER Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*###################################################################################
      -- Validations for address checking for nulls
      #####################################################################################*/
      BEGIN
        IF P_HR_EMP_REC.ADDRESS IS NULL OR p_hr_emp_rec.CITY IS NULL OR p_hr_emp_rec.STATE_ABBREVIATION IS NULL OR p_hr_emp_rec.ZIP_CODE IS NULL THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE',
            Error_Code   = Error_Code
            ||':ADD-171',
            Error_Msg = Error_Msg
            ||'Address1-City-State and Zip Code are nulls, '
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        Fnd_File.Put_Line(Fnd_File.Log,'Exception occured in Address'||Sqlerrm);
      END;
      /*###################################################################################
      -- validation for Country Abbreviation for null
      #####################################################################################*/
      BEGIN
        IF p_hr_emp_rec.COUNTRY_ABBREVIATION IS NULL THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||':CAB-172',
            ERROR_MSG = ERROR_MSG
            ||'Country Abbreviation is null, '
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        Fnd_File.Put_Line(Fnd_File.Log,'Exception occured in Country Abbreviation'||Sqlerrm);
      END;
      /*###################################################################################
      -- Validation for Birth Date checking for nulls
      #####################################################################################*/
      --Commented July-6th
      /* BEGIN
      if p_hr_emp_rec.DATEOFBIRTH IS  NULL then
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE',
      ERROR_CODE     = ERROR_CODE
      ||':DOB-173',
      ERROR_MSG = ERROR_MSG
      ||'DOB is null,'
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
      END IF;
      EXCEPTION
      WHEN OTHERS THEN
      Fnd_File.Put_Line(Fnd_File.Log,'Exception occured in Date of Birth Validation'||Sqlerrm);
      END; */
      /*###################################################################################
      --Validation for EEO_GENDER
      #####################################################################################*/
      BEGIN
        IF P_HR_EMP_REC.EEO_GENDER IS NOT NULL THEN
          SELECT lookup_code
          INTO LS_EEO_GENDER
          FROM Hr_Lookups
          WHERE Lookup_Type ='SEX'
          AND enabled_flag  = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
          AND upper(meaning)=upper(p_hr_emp_rec.EEO_GENDER);
          fnd_file.put_line(fnd_file.log,'LS_EEO_GENDER : '||LS_EEO_GENDER);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET New_EEO_GENDER       =LS_EEO_GENDER
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
          --Commented July-6th
          /*else
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
          ERROR_CODE     = ERROR_CODE
          ||':EOG-174' ,
          ERROR_MSG = ERROR_MSG
          ||'EEO_GENDER is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;*/
        END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        fnd_file.put_line(fnd_file.log,'LS_EEO_GENDER validation error : No data found');
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EOG-175' ,
          ERROR_MSG = ERROR_MSG
          ||'LS_EEO_GENDER Val Err - No data found, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in LS_EEO_GENDER Validation:'||sqlerrm);
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
          ERROR_CODE   = ERROR_CODE
          ||':EOG-176' ,
          ERROR_MSG = ERROR_MSG
          ||'LS_EEO_GENDER Val Err - In others, '
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
      END;
      /*###################################################################################
      -- Validation for Candidate_number checking for nulls
      #####################################################################################*/
      BEGIN
        IF (P_HR_EMP_REC.Candidate_number IS NULL) THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':Cnd-177' ,
            ERROR_MSG = ERROR_MSG
            ||'Candidate_number is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating Candidate_number of the Employee:'||SQLERRM);
      END;
      /*###################################################################################
      -- Validation For EEO_RACE checking for nulls
      #####################################################################################*/
      BEGIN
        IF (P_HR_EMP_REC.EEO_RACE IS NULL) AND G_BUSINESS_GROUP ='BG_US' THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':RAC-178' ,
            ERROR_MSG = ERROR_MSG
            ||'EEO_RACE is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating EEO_RACE of the Employee:'||SQLERRM);
      END;
      /*###################################################################################
      -- Validations For EEO_Ethnicity checking for nulls
      #####################################################################################*/
      -- July-7th
      /*BEGIN
      IF (P_HR_EMP_REC.EEO_Ethnicity IS NULL) and G_BUSINESS_GROUP ='BG_US' THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE' ,
      ERROR_CODE     = ERROR_CODE
      ||':EOE-179' ,
      ERROR_MSG = ERROR_MSG
      ||'EEO_Ethnicity is Null,'
      WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
      COMMIT;
      END IF;
      EXCEPTION
      WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Exception occurred in Validating EEO_Ethnicity of the Employee:'||SQLERRM);
      END;*/
      /*###################################################################################
      --Validation for SSN = SOCIALSECURITYNUMBER
      #####################################################################################*/
      BEGIN
        SELECT COUNT(*)
        INTO LS_EMP_COUNT
        FROM per_all_people_f
        WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.SOCIALSECURITYNUMBER
        AND attribute15          <> P_HR_EMP_REC.Candidate_number --Added To process the record if the ssn number is same as of recruit file employee
        AND business_group_id     = G_BUSINESS_GROUP_ID
        AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
        IF LS_EMP_COUNT <> 0 THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':SSN-193' ,
            ERROR_MSG = ERROR_MSG
            ||'Emp SSN No Already Exist,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating Employee SSN No Validation:'||SQLERRM);
      END;
      /*###################################################################################
      --Validation for  Last Name of the Employee
      #####################################################################################*/
      BEGIN
        IF (P_HR_EMP_REC.LASTNAME IS NULL) THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':ELN-194' ,
            ERROR_MSG = ERROR_MSG
            ||'Emp Last Name is Null,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating Last Name of the Employee:'||SQLERRM);
      END;
      ------------------------------------------------------------
      --Validating SSN and Last Name OF Children 1 to 10
      -----------------------------------------------------------
      IF g_business_group='BG_MY' THEN
        --Validation for MY_CHILD1_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD1_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C1LN-103.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD1_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD1_LAST_NAME:'||SQLERRM);
        END; */
        --Validation for MY_CHILD1_NRIC
        IF (P_HR_EMP_REC.MY_CHILD1_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C1
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD1_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            fnd_file.put_line(fnd_file.log,'G_BUSINESS_GROUP_ID in child 1 G_BUSINESS_GROUP_ID:'||G_BUSINESS_GROUP_ID);
            IF LS_EMP_C1 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C1N-195' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 1 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C1:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD1_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD1_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD1_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD1_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD1_GENDER : '||LS_MY_CHILD1_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD1_GENDER =LS_MY_CHILD1_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD1_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C1G-196' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD1_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD1_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C1G-197' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD1_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD2_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD2_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C2LN-104.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD2_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD2_LAST_NAME:'||SQLERRM);
        END; */
        --Validation for MY_CHILD2_NRIC
        IF (P_HR_EMP_REC.MY_CHILD2_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C2
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD2_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID --FND_PROFILE.VALUE_SPECIFIC('PER_BUSINESS_GROUP_ID')
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C2 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C2N-198' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 2 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C2:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD2_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD2_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD2_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD2_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD2_GENDER : '||LS_MY_CHILD2_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD2_GENDER =LS_MY_CHILD2_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD2_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C2G-199' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD2_GENDER Val Err - No data found ,'
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD2_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C2G200' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD2_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD3_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD3_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C3LN-105.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD3_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD3_LAST_NAME:'||SQLERRM);
        END; */
        --Validation for MY_CHILD3_NRIC
        IF (P_HR_EMP_REC.MY_CHILD3_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C3
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD3_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C3 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C3N-201' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 3 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C3:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD3_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD3_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD3_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD3_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD3_GENDER : '||LS_MY_CHILD3_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD3_GENDER =LS_MY_CHILD3_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD3_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C3G-202' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD3_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD3_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C3G-203' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD3_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD4_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD4_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C4LN-106.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD4_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD4_LAST_NAME:'||SQLERRM);
        END;*/
        --Validation for MY_CHILD4_NRIC
        IF (P_HR_EMP_REC.MY_CHILD4_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C4
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD4_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C4 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C4N-204' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 4 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C4:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD4_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD4_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD4_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD4_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD4_GENDER : '||LS_MY_CHILD4_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD4_GENDER =LS_MY_CHILD4_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD4_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C4G-205' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD4_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD4_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C4G-206' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD4_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD5_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD5_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C5LN-107.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD5_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occurred in Validating MY_CHILD5_LAST_NAME:'||SQLERRM);
        END;*/
        --Validation for MY_CHILD5_NRIC
        IF (P_HR_EMP_REC.MY_CHILD5_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C5
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD5_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C5 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C5N-207' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 5 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C5:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD5_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD5_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD5_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD5_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD5_GENDER : '||LS_MY_CHILD5_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD5_GENDER =LS_MY_CHILD5_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD5_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C5G-208' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD5_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD5_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C5G-209' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD5_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD6_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD6_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C6LN-108.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD6_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD6_LAST_NAME:'||SQLERRM);
        END;*/
        --Validation for MY_CHILD6_NRIC
        IF (P_HR_EMP_REC.MY_CHILD6_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C6
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD6_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C6 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C6N-210' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 6 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C6:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD6_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD6_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD6_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD6_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD6_GENDER : '||LS_MY_CHILD6_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD6_GENDER =LS_MY_CHILD6_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD6_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C6G-211' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD6_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD6_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C6G-212' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD6_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD7_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD7_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C7LN-109.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD7_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD7_LAST_NAME:'||SQLERRM);
        END;*/
        --Validation for MY_CHILD7_NRIC
        IF (P_HR_EMP_REC.MY_CHILD7_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C7
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD7_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C7 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C7N-213' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 7 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C7:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD7_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD7_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD7_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD7_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD7_GENDER : '||LS_MY_CHILD7_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD7_GENDER =LS_MY_CHILD7_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD7_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C7G-214' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD7_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD7_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C7G-215' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD7_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD8_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD8_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C8LN-110.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD8_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD8_LAST_NAME:'||SQLERRM);
        END; */
        --Validation for MY_CHILD8_NRIC
        IF (P_HR_EMP_REC.MY_CHILD8_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C8
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD8_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C8 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C8N-216' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 8 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C8:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD8_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD8_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD8_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD8_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD8_GENDER : '||LS_MY_CHILD8_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD8_GENDER =LS_MY_CHILD8_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD8_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C8G-217' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD8_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD8_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C8G-218' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD8_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD9_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD9_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C9LN-111.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD9_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD9_LAST_NAME:'||SQLERRM);
        END;*/
        --Validation for MY_CHILD9_NRIC
        IF (P_HR_EMP_REC.MY_CHILD9_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C9
            FROM per_all_people_f
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD8_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C9 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C9N-119' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 9 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C9:'||SQLERRM);
          END;
        END IF;
        --Validation for MY_CHILD9_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD9_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD9_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD9_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD9_GENDER : '||LS_MY_CHILD9_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD9_GENDER =LS_MY_CHILD9_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD9_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C9G-220' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD9_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD9_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C9G-221' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD9_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
        --Validation for MY_CHILD10_LAST_NAME
        /*BEGIN
        IF (P_HR_EMP_REC.MY_CHILD10_LAST_NAME IS NULL) THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||':C10LN-112.0' ,
        ERROR_MSG = ERROR_MSG
        ||'MY_CHILD10_LAST_NAME is Null,'
        WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Validating MY_CHILD10_LAST_NAME:'||SQLERRM);
        END;*/
        --Validation for MY_CHILD10_NRIC
        IF (P_HR_EMP_REC.MY_CHILD10_LAST_NAME IS NOT NULL) THEN
          BEGIN
            SELECT COUNT(*)
            INTO LS_EMP_C10
            FROM PER_ALL_PEOPLE_F
            WHERE NATIONAL_IDENTIFIER = P_HR_EMP_REC.MY_CHILD10_NRIC
            AND business_group_id     = G_BUSINESS_GROUP_ID
            AND TRUNC(SYSDATE) BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE ;
            IF LS_EMP_C10 <> 0 THEN
              UPDATE XXHA_TALEO_EMP_TR_STG
              SET STATUS_STG = 'VE' ,
                ERROR_CODE   = ERROR_CODE
                ||':C10-222' ,
                ERROR_MSG = ERROR_MSG
                ||'Child 10 SSN Already Exist,'
              WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occured in getting count LS_EMP_C10:'||SQLERRM);
          END ;
        END IF;
        --Validation for MY_CHILD10_GENDER
        BEGIN
          IF P_HR_EMP_REC.MY_CHILD10_GENDER IS NOT NULL THEN
            SELECT lookup_code
            INTO LS_MY_CHILD10_GENDER
            FROM Hr_Lookups
            WHERE Lookup_Type ='SEX'
            AND enabled_flag  = 'Y'
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
            AND upper(meaning)=upper(p_hr_emp_rec.MY_CHILD10_GENDER);
            fnd_file.put_line(fnd_file.log,'LS_MY_CHILD10_GENDER : '||LS_MY_CHILD10_GENDER);
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET New_MY_CHILD10_GENDER=LS_MY_CHILD10_GENDER
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          fnd_file.put_line(fnd_file.log,'LS_MY_CHILD10_GENDER validation error : No data found');
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C10-223' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD10_GENDER Val Err - No data found, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in LS_MY_CHILD10_GENDER Validation:'||sqlerrm);
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE' ,
            ERROR_CODE   = ERROR_CODE
            ||':C10-224' ,
            ERROR_MSG = ERROR_MSG
            ||'LS_MY_CHILD10_GENDER Val Err - In others, '
          WHERE TRANSACTION_ID_STG = P_HR_EMP_REC.TRANSACTION_ID_STG;
          COMMIT;
        END;
      END IF;
      --Validating Postal COde length for MY
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE',
        ERROR_CODE   = ERROR_CODE
        ||'MY-225:',
        ERROR_MSG = ERROR_MSG
        ||'MY - Zip code length not valid, '
      WHERE TRANSACTION_ID_STG              = G_SEQ_NO
      AND P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'MY'
      AND LENGTH(zip_code)                 <> 5;
      COMMIT;
      --------- Get County for US
      /*IF P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'US' THEN
      BEGIN
      SELECT COUNTY_NAME
      INTO L_COUNTY_NAME
      FROM PAY_US_NEW_CITIES_V
      WHERE upper(city_name) = upper(P_HR_EMP_REC.city)
      AND STATE_ABBREV       = P_HR_EMP_REC.STATE_ABBREVIATION
      AND P_HR_EMP_REC.zip_code BETWEEN ZIP_START AND ZIP_END;
      fnd_file.put_line(fnd_file.log,'L_COUNTY_NAME:'||L_COUNTY_NAME);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET NEW_COUNTY_NAME      = L_COUNTY_NAME
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
      EXCEPTION
      WHEN OTHERS THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE',
      ERROR_CODE   = ERROR_CODE
      ||'AC-226:',
      ERROR_MSG = ERROR_MSG
      ||'County not found, '
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
      END;
      END IF; */
      --------- Get County for US
      IF P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'US' THEN
        BEGIN
          SELECT COUNTY_NAME
          INTO L_COUNTY_NAME
          FROM PAY_US_NEW_CITIES_V
          WHERE upper(city_name) = upper(P_HR_EMP_REC.city)
          AND STATE_ABBREV       = P_HR_EMP_REC.STATE_ABBREVIATION
          AND P_HR_EMP_REC.zip_code BETWEEN ZIP_START AND ZIP_END;
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET NEW_COUNTY_NAME      = L_COUNTY_NAME
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;
      ELSIF P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'CA' THEN
        BEGIN
          SELECT COUNT(1)
          INTO l_ca_province
          FROM PAY_US_NEW_CITIES_V c,
            hr_lookups l
          WHERE upper(c.city_name) = upper(P_HR_EMP_REC.city)
          AND P_HR_EMP_REC.zip_code BETWEEN c.ZIP_START AND c.ZIP_END
          AND c.state_NAME  = 'Canada'
          AND l.lookup_type = 'CA_PROVINCE'
          AND l.lookup_code = P_HR_EMP_REC.STATE_ABBREVIATION
          AND l.meaning     = c.county_name;
          IF l_ca_province  = 0 THEN
            UPDATE XXHA_TALEO_EMP_TR_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'PO100:',
              ERROR_MSG = ERROR_MSG
              ||'Province invalid, '
            WHERE TRANSACTION_ID_STG = G_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          --g_error:=1;
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'PO101:',
            ERROR_MSG = ERROR_MSG
            ||'Province not found, '
          WHERE TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        END;
      END IF;
      -- Updating the status to V where STATUS_STG is N
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG         = 'V'
      WHERE STATUS_STG       = 'N'
      AND TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
    ELSE
      fnd_file.put_line(fnd_file.log,'Business Group not enabled in the Lookup:'||SQLERRM);
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'VE',
        ERROR_CODE   = ERROR_CODE
        ||'VE100:',
        ERROR_MSG = ERROR_MSG
        ||'Business Group not enabled in the Lookup, '
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      COMMIT;
    END IF;
  END IF;
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  fnd_file.put_line(fnd_file.log,'Exception occured in procedure EMPLOYEE_VALIDATION:'||SQLERRM);
END EMPLOYEE_VALIDATION;
/*#########################################################################
----------------------------< Employee Update Procedure>-------------------
##########################################################################*/
PROCEDURE Update_EMPLOYEE_INFO(
    p_hr_emp_rec IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    P_ERR_MSG OUT VARCHAR2)
  --If P_ERR_MSG = 1 then Success, If P_ERR_MSG=2 then In Exception
IS
  L_OBJECT_NUMBER PER_ALL_PEOPLE_F.OBJECT_VERSION_NUMBER%TYPE;
  lc_dt_ud_mode VARCHAR2(100)                             := NULL;
  lc_employee_number PER_ALL_PEOPLE_F.EMPLOYEE_NUMBER%TYPE:=p_hr_emp_rec.New_EMPLOYEE_NUMBER;
  -- Out Variables for Find Date Track Mode API
  -- ----------------------------------------------------------------
  lb_correction           BOOLEAN;
  lb_update               BOOLEAN;
  lb_update_override      BOOLEAN;
  lb_update_change_insert BOOLEAN;
  -- Out Variables for Update Employee API
  -- -----------------------------------------------------------
  ld_effective_start_date DATE;
  ld_effective_end_date   DATE;
  lc_full_name PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
  ln_comment_id PER_ALL_PEOPLE_F.COMMENT_ID%TYPE;
  lb_name_combination_warning BOOLEAN;
  lb_assign_payroll_warning   BOOLEAN;
  lb_orig_hire_warning        BOOLEAN;
  l_context PER_ALL_PEOPLE_F.ATTRIBUTE_CATEGORY%TYPE;
  l_gender VARCHAR2(1);
  l_dob    DATE;
  l_ssn    VARCHAR2(240);
  --L_ERR_MSG               VARCHAR2(4000);
  --empexec    exception;
BEGIN
  --Code to get object version number
  BEGIN
    SELECT MAX (object_version_number)
    INTO L_OBJECT_NUMBER
    FROM per_all_people_f
    WHERE 1       = 1
    AND person_id = p_hr_emp_rec.New_PERSON_ID
    AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE)) ;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception while getting Object Version Number in Update_EMPLOYEE_INFO:'||L_OBJECT_NUMBER);
  END;
  fnd_file.put_line(fnd_file.log,'Object Version Number in Update_EMPLOYEE_INFO:'||L_OBJECT_NUMBER);
  fnd_file.put_line(fnd_file.log,'EMPLOYEE NUMBER: '||p_hr_emp_rec.New_EMPLOYEE_NUMBER);
  fnd_file.put_line(fnd_file.log,'Assignment_Id '||p_hr_emp_rec.New_Assignment_Id);
  --Added to get attribute category for email.
  BEGIN
    SELECT sex,
      DATE_OF_BIRTH,
      NATIONAL_IDENTIFIER
    INTO l_gender,
      l_dob,
      l_ssn
    FROM per_all_people_f
    WHERE 1       = 1
    AND person_id = p_hr_emp_rec.New_PERSON_ID
    AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE))
    AND OBJECT_VERSION_NUMBER = L_OBJECT_NUMBER;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception while getting DOB, SSN and Gender Update_EMPLOYEE_INFO:');
  END;
  BEGIN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_PEOPLE'
    AND descriptive_flex_context_name = p_hr_emp_rec.New_business_group --g_business_group
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'l_context:'||l_context);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception in getting attribute category ID:'||l_context);
  END;
  -- Find Date Track Mode
  -- --------------------------------
  BEGIN
    dt_api.find_dt_upd_modes ( p_effective_date =>to_date(sysdate), p_base_table_name => 'PER_ALL_ASSIGNMENTS_F', p_base_key_column => 'ASSIGNMENT_ID', p_base_key_value =>to_number(p_hr_emp_rec.New_Assignment_Id), --ln_assignment_id,
    -- Output data elements
    -- -------------------------------
    p_correction => lb_correction, p_update => lb_update, p_update_override => lb_update_override, p_update_change_insert => lb_update_change_insert );
    fnd_file.put_line(fnd_file.log,'Assignment_Id in dt_api: '||p_hr_emp_rec.New_Assignment_Id);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception of Date Track Mode');
  END;
  IF ( lb_update_override = TRUE OR lb_update_change_insert = TRUE ) THEN
    -- UPDATE_OVERRIDE
    -- ---------------------------------
    lc_dt_ud_mode := 'UPDATE_OVERRIDE';
  END IF;
  IF ( lb_correction = TRUE ) THEN
    -- CORRECTION
    -- ----------------------
    lc_dt_ud_mode := 'CORRECTION';
  END IF;
  IF ( lb_update = TRUE ) THEN
    -- UPDATE
    -- --------------
    lc_dt_ud_mode := 'UPDATE';
  END IF;
  --lc_dt_ud_mode := 'CORRECTION';
  fnd_file.put_line(fnd_file.log, 'New_PERSON_ID before update api: '||p_hr_emp_rec.New_PERSON_ID);
  -- Update Employee API
  -- ---------------------------------
  IF p_hr_emp_rec.New_business_group='BG_US' THEN
    fnd_file.put_line(fnd_file.log,'New_business_group: '|| p_hr_emp_rec.New_business_group);
    hr_person_api.update_us_person( p_effective_date =>to_date(sysdate), p_datetrack_update_mode =>lc_dt_ud_mode, p_person_id =>p_hr_emp_rec.New_PERSON_ID, p_last_name=>P_HR_EMP_REC.LASTNAME, P_FIRST_NAME =>P_HR_EMP_REC.FIRSTNAME, p_ss_number => NVL(P_HR_EMP_REC.SOCIALSECURITYNUMBER,L_SsN) , p_sex => NVL(P_HR_EMP_REC.new_eeo_gender,L_GENDER),
    --P_KNOWN_AS =>P_HR_EMP_REC.Preferred_Name,  -- July-7th
    p_veteran_status => P_HR_EMP_REC.New_EEO_VETS100A, p_vets100A =>P_HR_EMP_REC.New_EEO_VETS100A, p_date_of_birth =>NVL(P_HR_EMP_REC.DATEOFBIRTH,L_DOB),
    --p_email_address => P_HR_EMP_REC.EMAIL, -- July-7th
    p_attribute_category =>l_context, P_ATTRIBUTE15 => P_HR_EMP_REC.candidate_number,
    -- Output Data Elements
    -- ----------------------------------
    p_employee_number => lc_employee_number, p_object_version_number =>L_OBJECT_NUMBER, --ln_object_version_number,
    p_effective_start_date => ld_effective_start_date, p_effective_end_date => ld_effective_end_date, p_full_name => lc_full_name, p_comment_id => ln_comment_id, p_name_combination_warning => lb_name_combination_warning, p_assign_payroll_warning => lb_assign_payroll_warning, p_orig_hire_warning => lb_orig_hire_warning );
    --commit; commented on July-6th
    fnd_file.put_line(fnd_file.log,'L_OBJECT_NUMBER In Update employee: '||L_OBJECT_NUMBER);
  ELSE
    fnd_file.put_line(fnd_file.log,'Update person for MY and other');
    hr_person_api.update_person ( p_effective_date => to_date(sysdate), p_datetrack_update_mode =>lc_dt_ud_mode, p_person_id =>p_hr_emp_rec.New_PERSON_ID, --g_person_id,--
    p_last_name=>P_HR_EMP_REC.LASTNAME, P_FIRST_NAME =>P_HR_EMP_REC.FIRSTNAME, p_national_identifier =>NVL(P_HR_EMP_REC.SOCIALSECURITYNUMBER,L_SSN),
    --p_marital_status =>P_HR_EMP_REC.New_MARITAL_STATUS, -- July-7th
    --P_KNOWN_AS =>P_HR_EMP_REC.Preferred_Name,  -- July-7th
    p_sex => NVL(P_HR_EMP_REC.new_eeo_gender,L_GENDER), p_date_of_birth =>NVL(P_HR_EMP_REC.DATEOFBIRTH, L_DOB), P_COUNTRY_OF_BIRTH =>P_HR_EMP_REC.New_BIRTH_COUNTRY, P_REGION_OF_BIRTH =>P_HR_EMP_REC.MY_BIRTH_STATE, P_BLOOD_TYPE =>P_HR_EMP_REC.New_BLOOD_TYPE, p_attribute_category =>L_context, P_ATTRIBUTE15 =>P_HR_EMP_REC.candidate_number, P_ATTRIBUTE16 =>P_HR_EMP_REC.New_MY_RACE_ETHNIC_GROUP, P_ATTRIBUTE18 =>P_HR_EMP_REC.MY_OLD_NRIC, P_ATTRIBUTE20 =>P_HR_EMP_REC.New_CITIZENSHIP,
    ---
    -- Output Data Elements
    -- ----------------------------------
    p_employee_number => lc_employee_number, p_object_version_number =>L_OBJECT_NUMBER, --ln_object_version_number,
    p_effective_start_date => ld_effective_start_date, p_effective_end_date => ld_effective_end_date, p_full_name => lc_full_name, p_comment_id => ln_comment_id, p_name_combination_warning => lb_name_combination_warning, p_assign_payroll_warning => lb_assign_payroll_warning, p_orig_hire_warning => lb_orig_hire_warning );
    --commit; commented on July-6th
    G_Employee_number:=lc_employee_number; -- Can update employee number in staging table
    fnd_file.put_line(fnd_file.log,'Employee_number_after_update:'||G_Employee_number);
    fnd_file.put_line(fnd_file.log,'L_OBJECT_NUMBER In Update employee2: '||L_OBJECT_NUMBER);
  END IF;
  P_ERR_MSG:=1;
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  fnd_file.put_line('Error occured in PROCEDURE Update_EMPLOYEE_INFO'||fnd_file.log,SQLERRM);
  P_ERR_MSG:=2;
  --L_ERR_MSG:=sqlerrm;
  --raise empexec;
END;
--Added for restricting contingent worker fields
/*################################################################################################
----------------------------< Employee Update employee for Contingent Procedure>-------------------
##################################################################################################*/
PROCEDURE UPDATE_EMPLOYEE_CONTINGENT(
    p_hr_emp_rec IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    P_ERR_MSG OUT VARCHAR2)
IS
  L_OBJECT_NUMBER PER_ALL_PEOPLE_F.OBJECT_VERSION_NUMBER%TYPE;
  lc_dt_ud_mode VARCHAR2(100)                             := NULL;
  lc_employee_number PER_ALL_PEOPLE_F.EMPLOYEE_NUMBER%TYPE:=p_hr_emp_rec.New_EMPLOYEE_NUMBER;
  -- Out Variables for Find Date Track Mode API
  -- ----------------------------------------------------------------
  lb_correction           BOOLEAN;
  lb_update               BOOLEAN;
  lb_update_override      BOOLEAN;
  lb_update_change_insert BOOLEAN;
  -- Out Variables for Update Employee API
  -- -----------------------------------------------------------
  ld_effective_start_date DATE;
  ld_effective_end_date   DATE;
  lc_full_name PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
  ln_comment_id PER_ALL_PEOPLE_F.COMMENT_ID%TYPE;
  lb_name_combination_warning BOOLEAN;
  lb_assign_payroll_warning   BOOLEAN;
  lb_orig_hire_warning        BOOLEAN;
  l_context PER_ALL_PEOPLE_F.ATTRIBUTE_CATEGORY%TYPE;
  L_person_type_id Per_Person_Types.Person_type_id%TYPE;
  l_gender VARCHAR2(1);
  l_dob    DATE;
  l_ssn    VARCHAR2(240);
BEGIN
  --Code to get object version number
  BEGIN
    SELECT MAX (object_version_number)
    INTO L_OBJECT_NUMBER
    FROM per_all_people_f
    WHERE 1       = 1
    AND person_id = p_hr_emp_rec.New_PERSON_ID
    AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE)) ;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception while getting Object Version Number in UPDATE_EMPLOYEE_CONTINGENT:'||L_OBJECT_NUMBER);
  END;
  fnd_file.put_line(fnd_file.log,'Object Version Number in UPDATE_EMPLOYEE_CONTINGENT:'||L_OBJECT_NUMBER);
  fnd_file.put_line(fnd_file.log,'EMPLOYEE NUMBER in UPDATE_EMPLOYEE_CONTINGENT: '||p_hr_emp_rec.New_EMPLOYEE_NUMBER);
  fnd_file.put_line(fnd_file.log,'Assignment_Id in UPDATE_EMPLOYEE_CONTINGENT'||p_hr_emp_rec.New_Assignment_Id);
  --Added to get attribute category for email.
  BEGIN
    SELECT sex,
      DATE_OF_BIRTH,
      NATIONAL_IDENTIFIER
    INTO l_gender,
      l_dob,
      l_ssn
    FROM per_all_people_f
    WHERE 1       = 1
    AND person_id = p_hr_emp_rec.New_PERSON_ID
    AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE))
    AND OBJECT_VERSION_NUMBER = L_OBJECT_NUMBER;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception while getting DOB, SSN and Gender UPDATE_EMPLOYEE_CONTINGENT:');
  END;
  BEGIN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_PEOPLE'
    AND descriptive_flex_context_name = p_hr_emp_rec.New_business_group --g_business_group
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'l_context in UPDATE_EMPLOYEE_CONTINGENT:'||l_context);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception in getting attribute category ID in UPDATE_EMPLOYEE_CONTINGENT:'||l_context);
  END;
  -- Find Date Track Mode
  -- --------------------------------
  BEGIN
    dt_api.find_dt_upd_modes ( p_effective_date =>to_date(sysdate), p_base_table_name => 'PER_ALL_ASSIGNMENTS_F', p_base_key_column => 'ASSIGNMENT_ID', p_base_key_value =>to_number(p_hr_emp_rec.New_Assignment_Id), --ln_assignment_id,
    -- Output data elements
    -- -------------------------------
    p_correction => lb_correction, p_update => lb_update, p_update_override => lb_update_override, p_update_change_insert => lb_update_change_insert );
    fnd_file.put_line(fnd_file.log,'Assignment_Id in dt_api in UPDATE_EMPLOYEE_CONTINGENT: '||p_hr_emp_rec.New_Assignment_Id);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception of Date Track Mode in UPDATE_EMPLOYEE_CONTINGENT');
  END;
  IF ( lb_update_override = TRUE OR lb_update_change_insert = TRUE ) THEN
    -- UPDATE_OVERRIDE
    -- ---------------------------------
    lc_dt_ud_mode := 'UPDATE_OVERRIDE';
  END IF;
  IF ( lb_correction = TRUE ) THEN
    -- CORRECTION
    -- ----------------------
    lc_dt_ud_mode := 'CORRECTION';
  END IF;
  IF ( lb_update = TRUE ) THEN
    -- UPDATE
    -- --------------
    lc_dt_ud_mode := 'UPDATE';
  END IF;
  --lc_dt_ud_mode := 'CORRECTION';
  fnd_file.put_line(fnd_file.log, 'New_PERSON_ID before update api in UPDATE_EMPLOYEE_CONTINGENT: '||p_hr_emp_rec.New_PERSON_ID);
  SELECT person_type_id
  INTO L_person_type_id
  FROM Per_Person_Types
  WHERE user_person_type LIKE 'HAE Contingent Worker'
  AND business_group_id=p_hr_emp_rec.NEW_BUSINESS_GROUP_ID;
  -- Update Employee API
  -- ---------------------------------
  IF p_hr_emp_rec.New_business_group='BG_US' THEN
    fnd_file.put_line(fnd_file.log,'New_business_group: '|| p_hr_emp_rec.New_business_group);
    hr_person_api.update_us_person( p_effective_date =>to_date(sysdate), p_datetrack_update_mode =>lc_dt_ud_mode, p_person_id =>p_hr_emp_rec.New_PERSON_ID, p_last_name=>P_HR_EMP_REC.LASTNAME, P_FIRST_NAME =>P_HR_EMP_REC.FIRSTNAME, P_person_type_id => L_person_type_id,
    --p_ss_number => P_HR_EMP_REC.SOCIALSECURITYNUMBER ,
    --p_veteran_status => P_HR_EMP_REC.New_EEO_VETS100A,
    --p_vets100A =>P_HR_EMP_REC.New_EEO_VETS100A,
    p_sex => NVL(P_HR_EMP_REC.new_eeo_gender,L_GENDER), p_date_of_birth =>NVL(P_HR_EMP_REC.DATEOFBIRTH,L_DOB), p_attribute_category =>l_context, P_ATTRIBUTE15 => P_HR_EMP_REC.candidate_number,
    -- Output Data Elements
    -- ----------------------------------
    p_employee_number => lc_employee_number, p_object_version_number =>L_OBJECT_NUMBER, --ln_object_version_number,
    p_effective_start_date => ld_effective_start_date, p_effective_end_date => ld_effective_end_date, p_full_name => lc_full_name, p_comment_id => ln_comment_id, p_name_combination_warning => lb_name_combination_warning, p_assign_payroll_warning => lb_assign_payroll_warning, p_orig_hire_warning => lb_orig_hire_warning );
    --commit; commented on July-6th
    fnd_file.put_line(fnd_file.log,'L_OBJECT_NUMBER In Update employee in UPDATE_EMPLOYEE_CONTINGENT: '||L_OBJECT_NUMBER);
  ELSE
    fnd_file.put_line(fnd_file.log,'Update person for MY and other');
    hr_person_api.update_person ( p_effective_date => to_date(sysdate), p_datetrack_update_mode =>lc_dt_ud_mode, p_person_id =>p_hr_emp_rec.New_PERSON_ID, --g_person_id,--
    p_last_name=>P_HR_EMP_REC.LASTNAME, P_FIRST_NAME =>P_HR_EMP_REC.FIRSTNAME, P_person_type_id => L_person_type_id,
    --p_national_identifier =>P_HR_EMP_REC.SOCIALSECURITYNUMBER,
    p_sex => NVL(P_HR_EMP_REC.new_eeo_gender,L_GENDER), p_date_of_birth =>NVL(P_HR_EMP_REC.DATEOFBIRTH,L_DOB),
    --P_COUNTRY_OF_BIRTH =>P_HR_EMP_REC.New_BIRTH_COUNTRY,
    --P_REGION_OF_BIRTH =>P_HR_EMP_REC.MY_BIRTH_STATE,
    --P_BLOOD_TYPE =>P_HR_EMP_REC.New_BLOOD_TYPE,
    --p_attribute_category =>L_context,
    P_ATTRIBUTE15 =>P_HR_EMP_REC.candidate_number,
    --P_ATTRIBUTE16 =>P_HR_EMP_REC.New_MY_RACE_ETHNIC_GROUP,
    --P_ATTRIBUTE18 =>P_HR_EMP_REC.MY_OLD_NRIC,
    --P_ATTRIBUTE20 =>P_HR_EMP_REC.New_CITIZENSHIP,
    ---
    -- Output Data Elements
    -- ----------------------------------
    p_employee_number => lc_employee_number, p_object_version_number =>L_OBJECT_NUMBER, --ln_object_version_number,
    p_effective_start_date => ld_effective_start_date, p_effective_end_date => ld_effective_end_date, p_full_name => lc_full_name, p_comment_id => ln_comment_id, p_name_combination_warning => lb_name_combination_warning, p_assign_payroll_warning => lb_assign_payroll_warning, p_orig_hire_warning => lb_orig_hire_warning );
    G_Employee_number:=lc_employee_number; -- Can update employee number in staging table
    fnd_file.put_line(fnd_file.log,'Employee_number_after_update in UPDATE_EMPLOYEE_CONTINGENT:'||G_Employee_number);
    fnd_file.put_line(fnd_file.log,'L_OBJECT_NUMBER In Update employee2 in UPDATE_EMPLOYEE_CONTINGENT: '||L_OBJECT_NUMBER);
  END IF;
  P_ERR_MSG:=1;
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  fnd_file.put_line('Error occured in PROCEDURE UPDATE_EMPLOYEE_CONTINGENT'||fnd_file.log,SQLERRM);
  P_ERR_MSG:=2;
END;
---------------End of Contingent worker changes ---------------------------
/*#########################################################################
------------------------< Create Employee Address>-------------------------
##########################################################################*/
PROCEDURE Create_employee_address(
    p_hr_emp_rec IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  ln_address_id per_addresses.address_id%TYPE;
  LN_OBJECT_VERSION_NUMBER PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  L_STYLE        VARCHAR2(30);
  LS_COUNTY_NAME VARCHAR2(30);
  LS_COUNT       NUMBER      := 0;
  err_flag       VARCHAR2(1) := 'N';
  err_msg        VARCHAR2(2000);
  l_person_id    NUMBER;
  l_Addr         NUMBER;
  l_obj          NUMBER;
  CURSOR addr(ip_person_id IN NUMBER)
  IS
    SELECT *
    FROM per_addresses
    WHERE person_id  = ip_person_id
    AND date_to     IS NULL
    AND primary_flag = 'Y';
BEGIN
  G_SEQ_NO := P_HR_EMP_REC.TRANSACTION_ID_STG;
  P_ERR_MSG:=1;
  SELECT new_person_id
  INTO l_person_id
  FROM XXHA_TALEO_EMP_TR_STG
  WHERE TRANSACTION_ID_STG = p_hr_emp_rec.TRANSACTION_ID_STG;
  Fnd_File.Put_Line(Fnd_File.Log,'In Address - Person ID '||l_person_id);
  --- check if Address already exists
  SELECT COUNT(1)
  INTO l_addr
  FROM per_addresses
  WHERE person_id            = l_person_id
  AND address_line1          = P_HR_EMP_REC.address
  AND NVL(address_line2,'1') = NVL(P_HR_EMP_REC.address2,'1')
  AND country                = P_HR_EMP_REC.COUNTRY_ABBREVIATION
  AND postal_code            = P_HR_EMP_REC.zip_code
    --and town_or_city
    --and region_1
  AND date_to     IS NULL
  AND primary_flag = 'Y';
  Fnd_File.Put_Line(Fnd_File.Log,'In Address - l_addr '||l_addr);
  IF l_addr = 0 THEN
    FOR addr_rec IN addr (l_person_id)
    LOOP
      l_obj := addr_rec.object_version_number;
      Fnd_File.Put_Line(Fnd_File.Log,'In Address - Before Address End date '||addr_rec.address_id||' '||l_obj);
      hr_person_address_api.update_person_address (p_validate => false , p_effective_date =>TRUNC(sysdate) --P_HR_EMP_REC.offer_actual_start_Date
      --,p_validate_county               in     boolean  default true
      ,p_address_id => addr_rec.address_id , p_object_version_number => l_obj , p_date_from => addr_rec.date_from , p_date_to =>TRUNC(sysdate-1) --P_HR_EMP_REC.offer_actual_start_Date-1 --rec_addr.date_to
      -- Start of fix for Bug #2431588
      ,p_primary_flag => addr_rec.primary_flag--'N'
      -- End of fix for Bug #2431588
      ,p_address_type => addr_rec.address_type , p_comments => addr_rec.comments , p_address_line1 => addr_rec.address_line1 , p_address_line2 => addr_rec.address_line2 , p_address_line3 => addr_rec.address_line3 , p_town_or_city => addr_rec.town_or_city , p_region_1 => addr_rec.region_1 , p_region_2 => addr_rec.region_2 , p_region_3 => addr_rec.region_3 , p_postal_code => addr_rec.postal_code , p_country => addr_rec.country , p_party_id => addr_rec.party_id );
      Fnd_File.Put_Line(Fnd_File.Log,'In Address - Address End dated '||addr_rec.address_id||' '||l_obj);
    END LOOP;
    Fnd_File.Put_Line(Fnd_File.Log,'At Style:');
    -- Getting Address Style for US
    BEGIN
      SELECT DESCRIPTIVE_FLEX_CONTEXT_CODE
      INTO L_STYLE
      FROM fnd_descr_flex_contexts_tl
      WHERE DESCRIPTIVE_FLEXFIELD_NAME  = 'Address Location'
      AND language                      = USERENV('LANG')
      AND DESCRIPTIVE_FLEX_CONTEXT_CODE = P_HR_EMP_REC.COUNTRY_ABBREVIATION;
      Fnd_File.Put_Line(Fnd_File.Log,'At Style:'||L_STYLE);
    EXCEPTION
    WHEN no_data_found THEN
      SELECT DESCRIPTIVE_FLEX_CONTEXT_CODE
      INTO L_STYLE
      FROM fnd_descr_flex_contexts_tl
      WHERE DESCRIPTIVE_FLEXFIELD_NAME  = 'Address Location'
      AND language                      = USERENV('LANG')
      AND DESCRIPTIVE_FLEX_CONTEXT_CODE = P_HR_EMP_REC.COUNTRY_ABBREVIATION
        ||'_GLB';
    WHEN too_many_rows THEN
      Fnd_File.Put_Line(Fnd_File.Log,'Too Many Rows while fetching Address Style:'||sqlerrm);
    END;
    Fnd_File.Put_Line(Fnd_File.Log,'At County:');
    /*IF P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'US' THEN
    SELECT B.COUNTY_NAME
    INTO LS_COUNTY_NAME
    FROM pay_us_city_names a,
    pay_us_counties b,
    pay_us_states c,
    pay_us_zip_codes z
    WHERE a.state_code = c.state_code
    AND a.county_code  = b.county_code
    AND b.state_code   = c.state_code
    AND a.city_code    =z.city_code
    AND a.state_code   =z.state_code
    AND c.state_code   = z.state_code
    AND b.county_code  = Z.COUNTY_CODE
    AND A.COUNTY_CODE  =Z.COUNTY_CODE
    AND P_HR_EMP_REC.ZIP_CODE BETWEEN Z.ZIP_START AND z.zip_end
    AND (A.DISABLE = 'N'
    OR A.DISABLE  IS NULL)
    ORDER BY A.CITY_NAME,
    C.STATE_ABBREV,
    Z.ZIP_START;
    END IF;
    Fnd_File.Put_Line(Fnd_File.Log,'LS_COUNTY_NAME:'||LS_COUNTY_NAME); */
    -- Create Employee Address for US
    -- --------------------------------------
    IF P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'US' OR L_STYLE = 'US' THEN
      fnd_file.put_line(fnd_file.log,'P_COUNTY :'|| P_HR_EMP_REC.NEW_COUNTY_NAME);
      fnd_file.put_line(fnd_file.log,'P_COUNTY2 :'|| LS_COUNTY_NAME);
      HR_PERSON_ADDRESS_API.CREATE_US_PERSON_ADDRESS ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate,                                     --sysdate,
      P_PERSON_ID =>P_HR_EMP_REC.New_PERSON_ID,                                                                                              --G_PERSON_ID,
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM =>sysdate,                                                                                          --sysdate,
      P_DATE_TO => TO_DATE (NULL)                                                                                                            --,P_ADDRESS_TYPE                  =>     'PHCA' --Primary Home Country Address
      ,P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, P_ADDRESS_LINE2 => p_hr_emp_rec.address2, P_ADDRESS_LINE3 => '', P_CITY =>P_HR_EMP_REC.CITY, --Testing roll back
      --P_CITY =>P_HR_EMP_REC.CITY,
      P_STATE => P_HR_EMP_REC.STATE_ABBREVIATION,                                  --P_HR_EMP_REC.STATE_ABBREVIATION,
      P_ZIP_CODE => P_HR_EMP_REC.ZIP_CODE, P_COUNTY =>P_HR_EMP_REC.NEW_COUNTY_NAME --
      , P_COUNTRY => p_hr_emp_rec.COUNTRY_ABBREVIATION
      --outs
      , P_ADDRESS_ID => g_address_id, P_OBJECT_VERSION_NUMBER => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      -- Add individual Address procedures based on the address style
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'MY' THEN
      fnd_file.put_line(fnd_file.log,'In create_MY_person_address:');
      HR_PERSON_ADDRESS_API.create_MY_person_address ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, P_ADDRESS_LINE2 =>P_HR_EMP_REC.ADDRESS2, P_postal_CODE =>P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY, P_REGION =>P_HR_EMP_REC.New_MY_STATE, --'MY21', --P_HR_EMP_REC.STATE_ABBREVIATION, --
      --P_REGION =>'Pen', --Testing rollback
      P_COUNTRY =>p_hr_emp_rec.COUNTRY_ABBREVIATION,
      --outs
      P_ADDRESS_ID => g_address_id, P_OBJECT_VERSION_NUMBER => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG                            :=1;
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'MX' THEN
      HR_PERSON_ADDRESS_API.CREATE_MX_PERSON_ADDRESS ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_DATE_TO => TO_DATE (NULL) --,P_ADDRESS_TYPE                  =>     'PHCA' --Primary Home Country Address
      ,P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, P_ADDRESS_LINE2 => P_HR_EMP_REC.ADDRESS2, P_ADDRESS_LINE3 => '', P_CITY => P_HR_EMP_REC.CITY, P_STATE =>P_HR_EMP_REC.New_MX_STATE,                                             --P_HR_EMP_REC.STATE_ABBREVIATION,
      P_postal_CODE => P_HR_EMP_REC.ZIP_CODE, P_COUNTRY => p_hr_emp_rec.COUNTRY_ABBREVIATION
      --outs
      , P_ADDRESS_ID => g_address_id, P_OBJECT_VERSION_NUMBER => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG                            :=1;
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'CA' THEN
      --fnd_file.put_line(fnd_file.log,'P_PERSON_ID :'|| P_HR_EMP_REC.New_PERSON_ID);
      --fnd_file.put_line(fnd_file.log,'p_style :'|| L_STYLE);
      --fnd_file.put_line(fnd_file.log,'P_ADDRESS_LINE1 :'|| P_HR_EMP_REC.ADDRESS);
      --fnd_file.put_line(fnd_file.log,'p_address_line2 :'|| p_hr_emp_rec.address2);
      --fnd_file.put_line(fnd_file.log,'p_town_or_city :'|| P_HR_EMP_REC.CITY);
      --fnd_file.put_line(fnd_file.log,'p_region_1 :'|| P_HR_EMP_REC.STATE_ABBREVIATION);
      --fnd_file.put_line(fnd_file.log,'p_postal_code :'|| P_HR_EMP_REC.ZIP_CODE);
      --fnd_file.put_line(fnd_file.log,'p_country :'|| p_hr_emp_rec.COUNTRY_ABBREVIATION);
      hr_person_address_api.create_person_address ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, --'49401',
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, P_DATE_FROM => sysdate,
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2,
      --P_ADDRESS_LINE3 => 'Edmonton Centre',
      p_town_or_city => P_HR_EMP_REC.CITY, p_region_1 => P_HR_EMP_REC.STATE_ABBREVIATION, p_postal_code => P_HR_EMP_REC.ZIP_CODE,
      --                                            P_COUNTY => 'Alberta' ,
      p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG                            :=1;
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'AT' THEN --L_STYLE='AT_GLB' THEN
      hr_person_address_api.create_AT_person_address (  -- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------AU - Australia---------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'AU' THEN
      hr_person_address_api.create_AU_person_address (-- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, p_city => P_HR_EMP_REC.CITY, P_STATE =>P_HR_EMP_REC.New_AU_STATE, --P_HR_EMP_REC.STATE_ABBREVIATION,
      P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      -----------------------------------DE----------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'DE' THEN
      hr_person_address_api.create_DE_person_address (-- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY,
      --p_region
      p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ---------------------------Italy IT----------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'IT' THEN
      hr_person_address_api.create_IT_person_address (-- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y',
      --            P_STYLE => 'MY_GLB',
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE,
      --p_province
      p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------------- BE = Belgium ----------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'BE' THEN
      hr_person_address_api.create_BE_person_address (-- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y',
      --            P_STYLE => 'MY_GLB',
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------------- HK = hong kong ----------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'HK' THEN
      hr_person_address_api.create_HK_person_address (-- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2,
      --P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE,
      --p_city => P_HR_EMP_REC.CITY,
      p_district => P_HR_EMP_REC.STATE_ABBREVIATION, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------------- NL = Netherlands ----------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'NL' THEN
      hr_person_address_api.create_NL_person_address (-- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY,
      --p_region
      p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------------- SE = Sweden ----------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'SE' THEN
      hr_person_address_api.create_SE_person_address (-- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------------- GB = Great Britain ----------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'GB' THEN
      hr_person_address_api.create_GB_person_address (-- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', P_DATE_FROM => sysdate, P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, p_town => P_HR_EMP_REC.STATE_ABBREVIATION, p_county => LS_COUNTY_NAME, P_POSTCODE => P_HR_EMP_REC.ZIP_CODE,
      -- p_city => P_HR_EMP_REC.CITY,
      p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------- FR = France ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'FR' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'FR', --
      P_DATE_FROM => sysdate,
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, p_town_or_city => P_HR_EMP_REC.CITY, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------- JP = Japan ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'JP' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'JP_GLB', --
      P_DATE_FROM => sysdate,
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2,
      --p_town_or_city => P_HR_EMP_REC.CITY,
      p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      ------------------------------------- IN = INDIA ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'IN' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'IN_GLB', --
      P_DATE_FROM => sysdate,
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS,
      --p_address_line2 => p_hr_emp_rec.address2,
      --p_town_or_city => P_HR_EMP_REC.CITY,
      --p_postal_code => P_HR_EMP_REC.ZIP_CODE,
      p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  KR- Korea ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'KR' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'KR', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  CN- China ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'CN' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'CN_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  TW- Taiwan ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'TW' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'TW_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  CH- ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'CH' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      -------------------------------------- NZ- ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'NZ' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  SG- ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'SG' THEN
      hr_person_address_api.create_SG_person_address (-- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y',
      --p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_city => P_HR_EMP_REC.CITY,
      --P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION,
      p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  ES- ------------------------------
      /* elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'ES' THEN
      hr_person_address_api.create_ES_person_address (-- Input data elements
      P_VALIDATE => FALSE,
      P_EFFECTIVE_DATE => sysdate,
      P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID,
      P_PRIMARY_FLAG => 'Y',
      p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => sysdate,
      --P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS,
      --p_address_line2 => P_HR_EMP_REC.address2,
      p_city => P_HR_EMP_REC.CITY,
      --P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION,
      p_postal_code => P_HR_EMP_REC.ZIP_CODE,
      p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id,
      p_object_version_number => ln_object_version_number);
      commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id = g_address_id
      WHERE TRANSACTION_ID_STG     = G_SEQ_NO;
      commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id); */
      --------------------------------------  HU- ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'HU' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  RU- ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'RU' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  BR- ------------------------------
    elsif P_HR_EMP_REC.COUNTRY_ABBREVIATION = 'BR' THEN
      hr_person_address_api.create_person_address (                                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
      P_ERR_MSG:=1;
      --------------------------------------  CZ- Chek republic ------------------------------
    ELSE
      hr_person_address_api.create_person_address (                                                                                                                                                -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => sysdate, P_PERSON_ID => P_HR_EMP_REC.New_PERSON_ID, P_PRIMARY_FLAG => 'Y', p_style => 'GENERIC',                                                    --L_STYLE
      P_DATE_FROM => sysdate, P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.STATE_ABBREVIATION, --'Brno-venkov',
      p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.COUNTRY_ABBREVIATION,
      -- Output data elements
      -- --------------------------------
      p_address_id => g_address_id, p_object_version_number => ln_object_version_number);
      --commit;
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET New_address_id       = g_address_id
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| g_address_id);
    END IF;
    P_ERR_MSG:=1;
  ELSE
    fnd_file.put_line(fnd_file.log,'Address already exists');
  END IF;
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  fnd_file.put_line(fnd_file.log,'EXCEPTION Occured in Address Creation:"'||SQLERRM);
  P_ERR_MSG:=2;
  --L_ERR_MSG:=sqlerrm;
  --raise empexec;
END Create_employee_address;
/*#########################################################################
----------------------------< Create Employee Contact Details>-----------
##########################################################################*/
PROCEDURE CREATE_CONTACT(
    p_hr_emp_rec IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    L_LASTNAME     VARCHAR2,
    L_FIRSTNAME    VARCHAR2,
    L_MIDDLENAME   VARCHAR2,
    L_RELATIONSHIP VARCHAR2,
    --L_CONTACT_TYPE VARCHAR2,
    L_MARITAL_DATE        DATE,
    L_PERSONAL_FLAG       VARCHAR2,
    L_NATIONAL_IDENTIFIER VARCHAR2,
    L_DATE_OF_BIRTH       DATE,
    L_SEX                 VARCHAR2,
    P_ERR_MSG OUT VARCHAR2)
IS
  ln_contact_rel_id PER_CONTACT_RELATIONSHIPS.CONTACT_RELATIONSHIP_ID%TYPE;
  ln_ctr_object_ver_num PER_CONTACT_RELATIONSHIPS.OBJECT_VERSION_NUMBER%TYPE;
  ln_contact_person PER_ALL_PEOPLE_F.PERSON_ID%TYPE;
  ln_object_version_number PER_CONTACT_RELATIONSHIPS.OBJECT_VERSION_NUMBER%TYPE;
  ld_per_effective_start_date DATE;
  ld_per_effective_end_date   DATE;
  lc_full_name PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
  ln_per_comment_id PER_ALL_PEOPLE_F.COMMENT_ID%TYPE;
  LB_NAME_COMB_WARNING   BOOLEAN;
  lb_orig_hire_warning   BOOLEAN;
  l_primary_contact_flag VARCHAR2(10);
  --P_HR_EMP_REC XXHA_TALEO_EMP_TR_STG%ROWTYPE;
BEGIN
  -- Added to make primary contact flag 'Y' for Spouse
  IF L_RELATIONSHIP         ='S' THEN
    l_primary_contact_flag := 'Y';
  ELSE
    l_primary_contact_flag := 'N';
  END IF;
  FND_FILE.PUT_LINE(FND_FILE.log,'In create_contact Api: ');
  hr_contact_rel_api.create_contact ( P_START_DATE => sysdate,                                                                                                --SYSDATE,    --
  P_BUSINESS_GROUP_ID =>p_hr_emp_rec.New_BUSINESS_GROUP_ID,                                                                                                   --G_BUSINESS_GROUP_ID ,
  p_person_id =>P_HR_EMP_REC.New_PERSON_ID,                                                                                                                   --g_person_id, --
  P_CONTACT_TYPE =>L_RELATIONSHIP,                                                                                                                            --P_HR_EMP_REC.New_EC_RELATIONSHIP, --L_CONTACT_TYPE,  --
  P_DATE_START => L_MARITAL_DATE, P_LAST_NAME => L_LASTNAME, P_FIRST_NAME => L_FIRSTNAME, p_middle_names => L_MIDDLENAME, P_PERSONAL_FLAG => L_PERSONAL_FLAG, --'Y',
  p_primary_contact_flag => l_primary_contact_flag,                                                                                                           -- added aaa
  P_NATIONAL_IDENTIFIER => L_NATIONAL_IDENTIFIER , P_DATE_OF_BIRTH => L_DATE_OF_BIRTH, p_sex => L_SEX,
  -- Output data elements
  -- --------------------------------
  p_contact_relationship_id => ln_contact_rel_id, p_ctr_object_version_number => ln_ctr_object_ver_num, p_per_person_id => ln_contact_person, p_per_object_version_number => ln_object_version_number, p_per_effective_start_date => ld_per_effective_start_date, p_per_effective_end_date => ld_per_effective_end_date, p_full_name => lc_full_name, p_per_comment_id => ln_per_comment_id, p_name_combination_warning => lb_name_comb_warning, p_orig_hire_warning => lb_orig_hire_warning );
  --commit;
  P_ERR_MSG:=1;
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  FND_FILE.PUT_LINE(FND_FILE.log,'Error occured in PROCEDURE CREATE_CONTACT'||SQLERRM);
  P_ERR_MSG:=2;
END;
/*#########################################################################
----------------------------< Create Employee Extra Information>-----------
##########################################################################*/
PROCEDURE CREATE_PERSON_EXTRA_INFO(
    L_PERSONID             NUMBER,
    L_INFORMATION_TYPE     VARCHAR2,
    L_INFORMATION_CATEGORY VARCHAR2,
    L_INFORMATION1         VARCHAR2,
    L_INFORMATION2         VARCHAR2,
    L_INFORMATION3         VARCHAR2,
    L_INFORMATION4         VARCHAR2,
    L_INFORMATION5         VARCHAR2,
    L_INFORMATION6         VARCHAR2,
    L_INFORMATION7         VARCHAR2,
    L_INFORMATION8         VARCHAR2,
    L_INFORMATION9         VARCHAR2,
    L_INFORMATION10        VARCHAR2,
    L_INFORMATION11        VARCHAR2,
    L_INFORMATION12        VARCHAR2,
    L_INFORMATION13        VARCHAR2,
    L_INFORMATION14        VARCHAR2,
    L_INFORMATION15        VARCHAR2,
    L_PERSON_EXTRA_INFO_ID OUT NUMBER,
    L_object_version_number OUT NUMBER )
IS
  P_ERR_MSG    VARCHAR2(10);
  l_extra_info NUMBER;
  --P_HR_EMP_REC XXHA_TALEO_EMP_TR_STG%ROWTYPE;
BEGIN
  FND_FILE.PUT_LINE(FND_FILE.log,'New_PERSON_ID in Extra information:'||L_PERSONID);
  FND_FILE.PUT_LINE(FND_FILE.log,'g_person_id in Extra information'||g_person_id);
  SELECT COUNT(1)
  INTO l_extra_info
  FROM per_people_extra_info
  WHERE person_id      = L_PERSONID
  AND information_type = L_INFORMATION_TYPE;
  IF l_extra_info      = 0 THEN
    hr_person_extra_info_api.create_person_extra_info (p_validate => false , p_person_id =>L_PERSONID                                                                                                 --P_HR_EMP_REC.New_PERSON_ID --g_person_id
    ,P_INFORMATION_TYPE =>L_INFORMATION_TYPE                                                                                                                                                          -- this is same as your extra person information flex filed code.
    ,p_pei_attribute_category => NULL , P_PEI_INFORMATION_CATEGORY => L_INFORMATION_CATEGORY                                                                                                          -- this is same as your extra person information flex filed code.
    ,P_PEI_INFORMATION1 => L_INFORMATION1 , P_PEI_INFORMATION2 => L_INFORMATION2 , P_PEI_INFORMATION3 => L_INFORMATION3 , P_PEI_INFORMATION4 => L_INFORMATION4 , P_PEI_INFORMATION5 => L_INFORMATION5 -- L_COUNTRY
    ,P_PEI_INFORMATION6 => L_INFORMATION6 , P_PEI_INFORMATION7 => L_INFORMATION7 , P_PEI_INFORMATION8 => L_INFORMATION8                                                                               --L_NUMBER
    ,P_PEI_INFORMATION9 => L_INFORMATION9 , P_PEI_INFORMATION10 => L_INFORMATION10 , P_PEI_INFORMATION11 => L_INFORMATION11                                                                           --TO_CHAR(TO_DATE(L_INFORMATION11,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS')
    ,P_PEI_INFORMATION12 => L_INFORMATION12 , P_PEI_INFORMATION13 => L_INFORMATION13 , P_PEI_INFORMATION14 => L_INFORMATION14                                                                         --TO_CHAR(TO_DATE(L_INFORMATION14,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS')
    ,p_pei_information15 => L_INFORMATION15 , P_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID                                                                                                        -- out values
    ,P_OBJECT_VERSION_NUMBER => L_object_version_number );
    --commit;
    fnd_file.put_line(fnd_file.log,'L_INFORMATION_TYPE :' ||l_person_extra_info_id);
    P_ERR_MSG                 :=1;
    IF l_person_extra_info_id IS NULL THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'E' ,
        ERROR_MSG    = ERROR_MSG
        || ' ,E104 :Error while creating Employee extra info '
        || L_INFORMATION_CATEGORY
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
    END IF;
  ELSE
    BEGIN
      SELECT person_extra_info_id,
        object_version_number
      INTO l_person_extra_info_id,
        L_object_version_number
      FROM per_people_extra_info
      WHERE person_id      = L_PERSONID
      AND information_type = L_INFORMATION_TYPE;
      hr_person_extra_info_api.update_person_extra_info (p_validate => false , p_person_extra_info_id =>l_person_extra_info_id                                                                          --P_HR_EMP_REC.New_PERSON_ID --g_person_id
      ,P_OBJECT_VERSION_NUMBER => L_object_version_number                                                                                                                                               -- this is same as your extra person information flex filed code.
      ,p_pei_attribute_category => NULL , P_PEI_INFORMATION_CATEGORY => L_INFORMATION_CATEGORY                                                                                                          -- this is same as your extra person information flex filed code.
      ,P_PEI_INFORMATION1 => L_INFORMATION1 , P_PEI_INFORMATION2 => L_INFORMATION2 , P_PEI_INFORMATION3 => L_INFORMATION3 , P_PEI_INFORMATION4 => L_INFORMATION4 , P_PEI_INFORMATION5 => L_INFORMATION5 -- L_COUNTRY
      ,P_PEI_INFORMATION6 => L_INFORMATION6 , P_PEI_INFORMATION7 => L_INFORMATION7 , P_PEI_INFORMATION8 => L_INFORMATION8                                                                               --L_NUMBER
      ,P_PEI_INFORMATION9 => L_INFORMATION9 , P_PEI_INFORMATION10 => L_INFORMATION10 , P_PEI_INFORMATION11 => L_INFORMATION11                                                                           --TO_CHAR(TO_DATE(L_INFORMATION11,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS')
      ,P_PEI_INFORMATION12 => L_INFORMATION12 , P_PEI_INFORMATION13 => L_INFORMATION13 , P_PEI_INFORMATION14 => L_INFORMATION14                                                                         --TO_CHAR(TO_DATE(L_INFORMATION14,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS')
      ,p_pei_information15 => L_INFORMATION15                                                                                                                                                           -- out values
      );
      --commit;
      fnd_file.put_line(fnd_file.log,'L_INFORMATION_TYPE :' ||l_person_extra_info_id);
      P_ERR_MSG                 :=1;
      IF l_person_extra_info_id IS NULL THEN
        UPDATE XXHA_TALEO_EMP_TR_STG
        SET STATUS_STG = 'E' ,
          ERROR_MSG    = ERROR_MSG
          || ' ,E104 :Error while creating Employee extra info '
          || L_INFORMATION_CATEGORY
        WHERE TRANSACTION_ID_STG = G_SEQ_NO;
        P_ERR_MSG               :=2;
        --commit;
      END IF;
    EXCEPTION
    WHEN OTHERS THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'E' ,
        ERROR_MSG    = ERROR_MSG
        || 'Extra information not found '
        || L_INFORMATION_CATEGORY
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      P_ERR_MSG               :=2;
    END;
  END IF;
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  FND_FILE.PUT_LINE(FND_FILE.log,'Error occured in PROCEDURE CREATE_PERSON_EXTRA_INFO'||SQLERRM);
  P_ERR_MSG:=2;
END;
/*#########################################################################
----------------< Create or update Employee Phone Details>-----------------
##########################################################################*/
PROCEDURE CREATE_EMP_PH_DETAILS(
    L_PHONE_TYPE        VARCHAR2,
    L_phone_number      VARCHAR2,
    L_CONTACT_PERSON_ID NUMBER,
    P_ERR_MSG OUT VARCHAR2)
IS
  ln_phone_id PER_PHONES.PHONE_ID%TYPE;
  ln_object_version_number PER_PHONES.OBJECT_VERSION_NUMBER%TYPE;
BEGIN
  -- Create or Update Employee Phone Detail
  -- -----------------------------------------------------------
  hr_phone_api.create_or_update_phone ( P_DATE_FROM =>sysdate, --sysdate,
  P_PHONE_TYPE => L_PHONE_TYPE, p_phone_number => L_phone_number, p_parent_id =>L_CONTACT_PERSON_ID, P_PARENT_TABLE => 'PER_ALL_PEOPLE_F', p_effective_date => SYSDATE,
  -- Output data elements
  -- --------------------------------
  p_phone_id => ln_phone_id, P_OBJECT_VERSION_NUMBER => LN_OBJECT_VERSION_NUMBER );
  --commit;
  FND_FILE.PUT_LINE(FND_FILE.log,'ln_phone_id :'||LN_PHONE_ID);
  P_ERR_MSG      :=1;
  IF ln_phone_id IS NULL THEN
    UPDATE XXHA_TALEO_EMP_TR_STG
    SET STATUS_STG = 'E' ,
      ERROR_MSG    = ERROR_MSG
      || ' ,E105 :Error while creating Employee Phone Number '
    WHERE TRANSACTION_ID_STG = G_SEQ_NO;
    --commit;
  END IF;
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  FND_FILE.PUT_LINE(FND_FILE.log,'Error occured in PROCEDURE CREATE_EMP_PH_DETAILS'||SQLERRM);
  P_ERR_MSG:=2;
END;
/*#########################################################################
------------------< Create Qualification Details>------------------------
##########################################################################*/
PROCEDURE CREATE_Qualification_DETAILS(
    P_HR_EMP_REC IN OUT XXHA_TALEO_EMP_TR_STG%ROWTYPE,
    P_ERR_MSG OUT VARCHAR2)
IS
  Ln_qualification_id      NUMBER;
  ln_object_version_number NUMBER;
BEGIN
  IF P_HR_EMP_REC.New_business_group='BG_MY' THEN
    PER_QUALIFICATIONS_API.CREATE_QUALIFICATION(p_validate => false ,p_effective_date =>sysdate ,p_qualification_type_id => P_HR_EMP_REC.New_qualification_type_id ,p_business_group_id =>P_HR_EMP_REC.New_BUSINESS_GROUP_ID --g_business_group_id
    ,p_person_id =>P_HR_EMP_REC.New_PERSON_ID                                                                                                                                                                                --g_person_id
    ,p_qualification_id => Ln_qualification_id ,p_object_version_number => ln_object_version_number);
    --commit;
    fnd_file.put_line(fnd_file.log,'Ln_qualification_id :' ||Ln_qualification_id);
    P_ERR_MSG              :=1;
    IF Ln_qualification_id IS NULL THEN
      UPDATE XXHA_TALEO_EMP_TR_STG
      SET STATUS_STG = 'E' ,
        ERROR_MSG    = ERROR_MSG
        || ' ,E125 :Error while creating Qualification Details '
      WHERE TRANSACTION_ID_STG = G_SEQ_NO;
      --commit;
    END IF;
  END IF;
  FND_FILE.PUT_LINE(FND_FILE.log,'In PROCEDURE CREATE_Qualification_DETAILS');
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  FND_FILE.PUT_LINE(FND_FILE.log,'Error occured in PROCEDURE CREATE_Qualification_DETAILS'||SQLERRM);
  P_ERR_MSG:=2;
END;
--##########################################################################################################################
------------------< Pragma Autonomous Transaction for Updating the status when record is failed>------------------------
--##########################################################################################################################
PROCEDURE Update_Last_Error(
    P_STAT_STG IN VARCHAR2,
    P_ERR_COD  IN VARCHAR2,
    P_ERR_MSG  IN VARCHAR2,
    P_SEQ_NO   IN NUMBER)
IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  UPDATE XXHA_TALEO_EMP_TR_STG
  SET STATUS_STG = STATUS_STG
    ||':'
    ||P_STAT_STG,
    ERROR_CODE = ERROR_CODE
    ||':'
    ||P_ERR_COD,
    ERROR_MSG = ERROR_MSG
    ||':'
    ||P_ERR_MSG
  WHERE TRANSACTION_ID_STG = P_SEQ_NO;
  FND_FILE.PUT_LINE(FND_FILE.log,'In Update_Last_Error');
  COMMIT;
EXCEPTION
WHEN OTHERS THEN
  FND_FILE.PUT_LINE(FND_FILE.log,'In Update_Last_Error exception');
END Update_Last_Error;
/*#########################################################################
---------------------------< Main Procedure>-------------------------------
##########################################################################*/
PROCEDURE MAIN(
    errbuff VARCHAR2,
    retcode NUMBER)
IS
  -- Cursor to process new records
  CURSOR CUR_EMP_STG
  IS
    SELECT * FROM XXHA_TALEO_EMP_TR_STG WHERE STATUS_STG IN ('N');
  -- Cursor for Validated records
  CURSOR CUR_EMP_STG1
  IS
    SELECT * FROM XXHA_TALEO_EMP_TR_STG WHERE STATUS_STG = 'V';
  L_PERSON_ID per_all_people_f.PERSON_ID%type; --NUMBER;
  L_ROWID VARCHAR2(500);
  L_EMP_REC XXHA_TALEO_EMP_TR_STG%ROWTYPE;
  L_ERR_MSG               VARCHAR2(4000);
  L_PERSON_EXTRA_INFO_ID  NUMBER;
  L_object_version_number NUMBER;
  L_C_PERSON_ID           NUMBER;
  P_ERR_MSG_PH            VARCHAR2(200);
  --Added for Roll-back
  lv_err_msg           VARCHAR2(1000);
  empexec              EXCEPTION;
  l_empexec_status     VARCHAR2(2000);
  l_empexec_err_code   VARCHAR2(2000);
  l_empexec_err_msg    VARCHAR2(4000);
  l_empexec_seq_no     NUMBER;
  L_Ex_Contingent_Main NUMBER;
BEGIN
  /*#########################################################################
  ------------------< Opening Cursor to Validate Data>---------------
  ##########################################################################*/
  BEGIN
    OPEN CUR_EMP_STG;
    LOOP
      FETCH CUR_EMP_STG INTO L_EMP_REC;
      EXIT
    WHEN CUR_EMP_STG%NOTFOUND;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Before start Validation Proc');
      G_SEQ_NO := L_EMP_REC.TRANSACTION_ID_STG;
      EMPLOYEE_VALIDATION(L_emp_rec);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'After start Validation Proc');
    END LOOP;
    CLOSE CUR_EMP_STG;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception occured in Cursor to Validate Data:'||SQLERRM);
    dbms_output.put_line('Exception occured in Cursor to Validate Data:'||SQLERRM);
  END;
  /*#########################################################################
  ------------------< OPening Cursor to insert data using API>---------------
  ##########################################################################*/
  FND_FILE.PUT_LINE(FND_FILE.log,'***********************************************************************************');
  --DK
  BEGIN
    OPEN CUR_EMP_STG1;
    LOOP
      --Added
      BEGIN
        FETCH CUR_EMP_STG1 INTO L_EMP_REC;
        EXIT
      WHEN CUR_EMP_STG1%NOTFOUND;
        FND_FILE.PUT_LINE(FND_FILE.log,'Calling Update employee Creation for '||L_emp_rec.TRANSACTION_ID_STG);
        G_SEQ_NO  := L_emp_rec.TRANSACTION_ID_STG;
        L_ERR_MSG := NULL;
        --Query for Contingent WORKER
        BEGIN
          fnd_file.put_line(fnd_file.log,'Candidate_Number in Rehiring Contingent Worker:'||L_emp_rec.Candidate_Number);
          fnd_file.put_line(fnd_file.log,'BUSINESS_GROUP_ID in Rehiring Contingent Worker:'||L_emp_rec.NEW_BUSINESS_GROUP_ID);
          SELECT COUNT(*)
          INTO L_Ex_Contingent_Main
          FROM Per_All_People_F Papf,
            Hr.Per_Person_Type_Usages_F Pptu,
            Hr.Per_Person_Types Ppt
          WHERE 1                    =1
          AND Papf.Person_Id         = Pptu.Person_Id
          AND pptu.person_type_id    = ppt.person_type_id
          AND Papf.Business_Group_Id = L_emp_rec.NEW_BUSINESS_GROUP_ID
          AND Ppt.User_Person_Type LIKE 'HAE Contingent Worker'
          AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
          AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
          AND Papf.Attribute15=L_emp_rec.Candidate_Number
            --Added
          AND Upper(Papf.First_Name) = Upper(L_emp_rec.FIRSTNAME)
          AND upper(papf.last_name)  = upper(L_emp_rec.LASTNAME)
          AND ppt.active_flag        ='Y' ;
          fnd_file.put_line(fnd_file.log,'Count for contingent worker:'||L_Ex_Contingent_Main);
        EXCEPTION
        WHEN no_data_found THEN
          fnd_file.put_line(fnd_file.log,'In Exception- For contingent worker:'||sqlerrm);
        END;
        --#########################################################################
        ------------------< Calling Update Employee Information >----------------------------
        --##########################################################################
        IF L_Ex_Contingent_Main = 1 THEN
          BEGIN
            UPDATE_EMPLOYEE_CONTINGENT (p_hr_emp_rec => L_emp_rec, p_err_msg => l_err_msg );
            fnd_file.put_line(fnd_file.log,'After Calling employee Creation in UPDATE_EMPLOYEE_CONTINGENT');
            IF L_ERR_MSG =1 THEN
              fnd_file.put_line(fnd_file.log,'Update of an Employee is  Successful in UPDATE_EMPLOYEE_CONTINGENT');
            ELSE
              l_empexec_status   := ':E';
              l_empexec_err_code := ':E127';
              l_empexec_err_msg  := ':Error while Updating Employee Info in UPDATE_EMPLOYEE_CONTINGENT,';
              l_empexec_seq_no   := G_SEQ_NO;
              raise empexec;
              --commit;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occurred in  Calling Update API in UPDATE_EMPLOYEE_CONTINGENT:'||SQLERRM);
            --L_ERR_MSG:=sqlerrm;
            --raise empexec;
          END;
          L_ERR_MSG := NULL;
          --end;
          --#########################################################################
          ------------------< Calling Update Employee Information >----------------------------
          --##########################################################################
        ELSE
          BEGIN
            Update_EMPLOYEE_INFO (p_hr_emp_rec => L_emp_rec, p_err_msg => l_err_msg );
            fnd_file.put_line(fnd_file.log,'After Calling employee Creation');
            IF L_ERR_MSG =1 THEN
              fnd_file.put_line(fnd_file.log,'Update of an Employee is  Successful');
            ELSE
              --Update_Last_Error(':E',':E101',':Error while Updating Employee Info,',G_SEQ_NO);
              l_empexec_status   := ':E';
              l_empexec_err_code := ':E101';
              l_empexec_err_msg  := ':Error while Updating Employee Info,';
              l_empexec_seq_no   := G_SEQ_NO;
              raise empexec;
              --commit;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occurred in  Calling Update API:'||SQLERRM);
            --L_ERR_MSG:=sqlerrm;
            --raise empexec;
          END;
          L_ERR_MSG := NULL;
          --#########################################################################
          ------------------< Calling Create Employee Address API>-------------------
          --##########################################################################
          BEGIN
            fnd_file.put_line(fnd_file.log,'Calling employee Address creation');
            CREATE_EMPLOYEE_ADDRESS (P_HR_EMP_REC => L_emp_rec, P_ERR_MSG => L_ERR_MSG );
            fnd_file.put_line(fnd_file.log,'L_ERR_MSG after Calling Address:'||L_ERR_MSG);
            IF L_ERR_MSG = 1 THEN
              fnd_file.put_line(fnd_file.log,'employee Address Creation Successful');
            ELSE
              fnd_file.put_line(fnd_file.log,'employee Address Creation not Successful');
              --Update_Last_Error(':E',':E102',':Error while creating Employee Address,',G_SEQ_NO);
              l_empexec_status   := ':E';
              l_empexec_err_code := ':E102';
              l_empexec_err_msg  := ':Error while creating Employee Address,';
              l_empexec_seq_no   := G_SEQ_NO;
              raise empexec;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occurred in  Calling Employee address creation API:'||SQLERRM);
            --L_ERR_MSG:=sqlerrm;
            --raise empexec;
            fnd_file.put_line(fnd_file.log,'Exception in address after raise :'||SQLERRM);
          END;
          L_ERR_MSG := NULL;
          --Added July-6th
          --lv_err_msg:=null;
          -- DK
          -----------------------< Calling employee Home Phone details Creation Procedure >-------------------------------------------
          -- July-7th
          IF L_EMP_REC.HOME_PHONE IS NOT NULL THEN
            BEGIN
              fnd_file.put_line(fnd_file.log,' Phone 1 for Employee: '||L_EMP_REC.New_PERSON_ID);
              CREATE_EMP_PH_DETAILS('H1',L_EMP_REC.HOME_PHONE,L_EMP_REC.New_PERSON_ID,P_ERR_MSG_PH);
              IF P_ERR_MSG_PH =1 THEN
                fnd_file.put_line(fnd_file.log,'Employee Home Phone details creation is Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Employee Home Phone details before raise exception');
                raise empexec;
                UPDATE XXHA_TALEO_EMP_TR_STG
                SET STATUS_STG = 'E',
                  ERROR_CODE   = ERROR_CODE
                  ||':E125',
                  ERROR_MSG = ERROR_MSG
                  ||'Home phone load error, '
                WHERE TRANSACTION_ID_STG = G_SEQ_NO;
                --Commit;
              END IF; --err
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in  Calling Home Phone details creation API:'||SQLERRM);
              --Added July-6th
              --lv_err_msg:=sqlerrm;
              L_ERR_MSG:=sqlerrm;
              raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --Added July-6th
          --lv_err_msg:=null;
          -----------------------< Calling employee MOBILE Phone details Creation Procedure >-------------------------------------------
          IF L_EMP_REC.MOBILE_PHONE IS NOT NULL THEN
            BEGIN
              fnd_file.put_line(fnd_file.log,' Phone 2 for Employee: '||L_EMP_REC.New_PERSON_ID);
              CREATE_EMP_PH_DETAILS('MH',L_EMP_REC.MOBILE_PHONE,L_EMP_REC.New_PERSON_ID,P_ERR_MSG_PH);
              IF P_ERR_MSG_PH = 1 THEN
                fnd_file.put_line(fnd_file.log,'Employee Mobile Phone details creation is Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Employee Mobile Phone details before raise exception');
                raise empexec;
                UPDATE XXHA_TALEO_EMP_TR_STG
                SET STATUS_STG = 'E',
                  ERROR_CODE   = ERROR_CODE
                  ||':E126',
                  ERROR_MSG = ERROR_MSG
                  ||'Mobile phone load error, '
                WHERE TRANSACTION_ID_STG = G_SEQ_NO;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in  Calling Home Phone details creation API:'||SQLERRM);
              --Added July-6th
              --lv_err_msg:=sqlerrm;
              L_ERR_MSG:=sqlerrm;
              raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --Added July-6th
          --lv_err_msg:=null;
          --#########################################################################
          ------------< Calling Create Employee Contact API For Spouse Details Global>-------
          --##########################################################################
          -- July-7th
          IF L_EMP_REC.EC_LASTNAME IS NOT NULL AND L_emp_rec.New_business_group ='BG_US' THEN -- need to validate if condition aaa
            fnd_file.put_line(fnd_file.log,'Calling CREATE_CONTACT for Spouse, only for US');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.EC_LASTNAME, L_FIRSTNAME => L_EMP_REC.EC_FIRSTNAME, L_MIDDLENAME => L_EMP_REC.EC_MIDDLENAME, L_RELATIONSHIP =>L_EMP_REC.New_EC_RELATIONSHIP, --L_EMP_REC.EC_RELATIONSHIP,
              --l_CONTACT_TYPE => 'S',  --
              L_MARITAL_DATE => L_EMP_REC.MARITAL_DATE , L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => NULL, L_DATE_OF_BIRTH => NULL, L_SEX =>L_EMP_REC.New_EEO_GENDER, --NULL,
              P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG =1 THEN
                fnd_file.put_line(fnd_file.log,'Employee Spouse Creation successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Employee Spouse Creation before raise exception');
                raise empexec;
                UPDATE XXHA_TALEO_EMP_TR_STG
                SET STATUS_STG = 'E' ,
                  ERROR_CODE   = ERROR_CODE
                  ||':E103' ,
                  ERROR_MSG = ERROR_MSG
                  || 'Error while creating Employee spouse contact, '
                WHERE TRANSACTION_ID_STG = G_SEQ_NO;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in  Calling Employee Spouse creation API:'||SQLERRM);
              --Added July-6th
              --lv_err_msg:=sqlerrm;
              L_ERR_MSG:=sqlerrm;
              raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --Added July-6th
          --lv_err_msg:=null;
          --#########################################################################
          -----------< Calling API to Create Employee Spouse Details for MY>----------------
          --##########################################################################
          --DK
          fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Spouse My :'||L_EMP_REC.MY_SPOUSE_GIVEN_NAME);
          IF L_EMP_REC.MY_SPOUSE_GIVEN_NAME IS NOT NULL AND L_EMP_REC.New_business_group='BG_MY' THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Spouse');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_SPOUSE_GIVEN_NAME, L_FIRSTNAME => L_EMP_REC.MY_SPOUSE_SURNAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'S', --NULL,
              --L_CONTACT_TYPE => 'S',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_SPOUSE_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_SPOUSE_DATE_OF_BIRTH,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_SPOUSE_GENDER, --NULL,
              P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Employee CREATE_CONTACT for Spouse MY is Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Employee CREATE_CONTACT for before raise exception');
                --Update_Last_Error(':E',':E108',':Error while Updating Employee Info,',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E103';
                l_empexec_err_msg  := ':Error while Updating Employee Info,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                fnd_file.put_line(fnd_file.log,'Employee CREATE_CONTACT after Raise');
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in Calling API to Create Employee Spouse Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          ----< Calling Create Employee Contact API For Emergency Contact Details>----
          --##########################################################################
          fnd_file.put_line(fnd_file.LOG,'Calling Emergency_CONTACT :'||L_EMP_REC.EC2_LASTNAME);
          IF L_EMP_REC.EC2_LASTNAME IS NOT NULL AND L_EMP_REC.New_business_group='BG_MY' THEN
            fnd_file.put_line(fnd_file.log,'Calling CREATE_CONTACT for Emergency');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.EC2_LASTNAME, L_FIRSTNAME => L_EMP_REC.EC2_FIRSTNAME, L_MIDDLENAME => NULL,--L_EMP_REC.EC_MIDDLENAME,
              L_RELATIONSHIP =>L_EMP_REC.New_EC2_RELATIONSHIP,                                                                                             --'Emergency',
              --L_CONTACT_TYPE => 'EMRG',
              L_MARITAL_DATE => NULL, --L_EMP_REC.MARITAL_DATE ,
              L_PERSONAL_FLAG => 'Y', --'N'
              L_NATIONAL_IDENTIFIER => NULL, L_DATE_OF_BIRTH => NULL, L_SEX => NULL, P_ERR_MSG => L_ERR_MSG);
              IF L_ERR_MSG =1 THEN
                fnd_file.put_line(fnd_file.LOG,'Emergency contact Creation is Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Emergency contact Creation before raise exception');
                --Update_Last_Error(':E',':E104',':Error while creating Employee Emergency contact,',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E104';
                l_empexec_err_msg  := ':Error while creating Employee Emergency contact,';
                l_empexec_seq_no   := G_SEQ_NO;
                --raise empexec;
                --fnd_file.put_line(fnd_file.log,'Emergency contact Creation after Raise');
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in  Calling Employee Emergency Contact API:'||SQLERRM);
              L_ERR_MSG:=sqlerrm;
              raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          -----------------------< Calling Spouse Phone details for US Procedure >-----------------------
          BEGIN
            BEGIN
              fnd_file.put_line(fnd_file.log,'New_PERSON_ID in PER_CONTACT_RELATIONSHIPS:'||L_EMP_REC.New_PERSON_ID);
              SELECT CONTACT_PERSON_ID
              INTO L_C_PERSON_ID
              FROM PER_CONTACT_RELATIONSHIPS
              WHERE PERSON_ID          = L_EMP_REC.New_PERSON_ID --g_person_id
              AND primary_contact_flag = 'Y';
            EXCEPTION
            WHEN OTHERS THEN
              L_C_PERSON_ID := NULL; -- dkantem
              fnd_file.put_line(fnd_file.log,'No CONTACT_PERSON_ID');
            END;
            --#########################################################################
            ---------< Calling API to Create Spouse Contact EC_PHONE Details for US>----- H1 = Primary
            --##########################################################################
            IF L_EMP_REC.EC_PHONE IS NOT NULL AND L_EMP_REC.New_business_group = 'BG_US' THEN
              fnd_file.put_line(fnd_file.log,' Phone 3  EC_PHONE: '||L_EMP_REC.New_PERSON_ID); --g_person_id);
              BEGIN
                CREATE_EMP_PH_DETAILS('H1',L_EMP_REC.EC_PHONE,L_C_PERSON_ID,P_ERR_MSG_PH);
                fnd_file.put_line(fnd_file.log,'After entering phone details EC_PHONE for US'|| P_ERR_MSG_PH);
                IF P_ERR_MSG_PH = 1 THEN
                  fnd_file.put_line(fnd_file.log,'Creating phone details EC_PHONE for US is Successful');
                ELSE
                  fnd_file.put_line(fnd_file.log,'Phone details EC_PHONE before raise exception');
                  --Update_Last_Error(':E',':E105',':Error while creating Phone details for EC_PHONE,',G_SEQ_NO);
                  l_empexec_status   := ':E';
                  l_empexec_err_code := ':E105';
                  l_empexec_err_msg  := ':Error while creating Phone details for EC_PHONE,';
                  l_empexec_seq_no   := G_SEQ_NO;
                  raise empexec;
                  fnd_file.put_line(fnd_file.log,'Phone details EC_PHONE Creation after Raise');
                  --Commit;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                fnd_file.put_line(fnd_file.log,'Exception occured in  Calling EC_PHONE1 Details API:'||SQLERRM);
                --L_ERR_MSG:=sqlerrm;
                --raise empexec;
              END;
            END IF;
            L_ERR_MSG := NULL;
            --#########################################################################
            ---------< Calling API to Create Spouse Contact EC_PHONE2 Details for US>----- H1 = Primary
            --##########################################################################
            IF L_EMP_REC.EC_PHONE2 IS NOT NULL AND L_EMP_REC.New_business_group = 'BG_US' THEN
              fnd_file.put_line(fnd_file.log,' Phone 4  EC_PHONE2: '||L_EMP_REC.New_PERSON_ID); --g_person_id);
              BEGIN
                CREATE_EMP_PH_DETAILS('MH',L_EMP_REC.EC_PHONE2,L_C_PERSON_ID,P_ERR_MSG_PH);
                fnd_file.put_line(fnd_file.log,'After entering phone details EC_PHONE2 for US'|| P_ERR_MSG_PH);
                IF P_ERR_MSG_PH = 1 THEN
                  fnd_file.put_line(fnd_file.log,'Entering phone details EC_PHONE2 for US is SUCCESSFUL');
                ELSE
                  fnd_file.put_line(fnd_file.log,'Phone details EC_PHONE2 before raise exception');
                  --Update_Last_Error(':E',':E106',':Error while creating Phone details for EC_PHONE2,',G_SEQ_NO);
                  l_empexec_status   := ':E';
                  l_empexec_err_code := ':E106';
                  l_empexec_err_msg  := ':Error while creating Phone details for EC_PHONE2,';
                  l_empexec_seq_no   := G_SEQ_NO;
                  raise empexec;
                  fnd_file.put_line(fnd_file.log,'Phone details EC_PHONE2 Creation after Raise');
                  --Commit;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                fnd_file.put_line(fnd_file.log,'Exception occured in  Calling EC_PHONE2 Details API:'||SQLERRM);
                --L_ERR_MSG:=sqlerrm;
                --raise empexec;
              END;
            END IF;
            L_ERR_MSG := NULL;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occurred in block EC_PHONE,EC_PHONE2 phone details:'||SQLERRM);
            --L_ERR_MSG:=sqlerrm;
            --raise empexec;
          END;
          L_ERR_MSG := NULL;
          --#######################################################################
          -----------< Calling API to Create Phone Contact  Details for Emergency>-------
          --##########################################################################
          BEGIN
            BEGIN
              fnd_file.put_line(fnd_file.log,'New_PERSON_ID in PER_CONTACT_RELATIONSHIPS:'||L_EMP_REC.New_PERSON_ID);
              SELECT CONTACT_PERSON_ID
              INTO L_C_PERSON_ID
              FROM PER_CONTACT_RELATIONSHIPS
              WHERE PERSON_ID = L_EMP_REC.New_PERSON_ID --g_person_id
                --AND primary_contact_flag = 'Y';
              AND contact_type='EMRG';
            EXCEPTION
            WHEN OTHERS THEN
              L_C_PERSON_ID := NULL; -- dkantem
              fnd_file.put_line(fnd_file.log,'No CONTACT_PERSON_ID in Emergency');
            END;
            --#########################################################################
            -----------< Calling API to Create Employee Contact EC2_PHONE1  Details>-------------- H1 = Primary
            --##########################################################################
            IF L_EMP_REC.EC2_PHONE1 IS NOT NULL AND L_C_PERSON_ID IS NOT NULL -- dkantem
              THEN
              fnd_file.put_line(fnd_file.log,' Phone 5 '||l_c_person_id);
              fnd_file.put_line(fnd_file.log,'entering phone details for Contact:'||L_C_PERSON_ID);
              BEGIN
                CREATE_EMP_PH_DETAILS('H1',L_EMP_REC.EC2_PHONE1,L_C_PERSON_ID,P_ERR_MSG_PH); --
                fnd_file.put_line(fnd_file.LOG,'After entering phone details for contact '|| P_ERR_MSG_PH);
                IF P_ERR_MSG_PH =1 THEN
                  fnd_file.put_line(fnd_file.LOG,'Entering phone details for EC2_PHONE1 is SUCCESSFUL '|| P_ERR_MSG_PH);
                ELSE
                  fnd_file.put_line(fnd_file.log,'Entering phone details for EC2_PHONE1 before raise exception');
                  --Update_Last_Error(':E',':E107',':Error while creating Phone2 details',G_SEQ_NO);
                  l_empexec_status   := ':E';
                  l_empexec_err_code := ':E107';
                  l_empexec_err_msg  := ':Error while creating Phone2 details,';
                  l_empexec_seq_no   := G_SEQ_NO;
                  raise empexec;
                  fnd_file.put_line(fnd_file.log,'Entering phone details for EC2_PHONE1 Creation after Raise');
                  --Commit;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                fnd_file.put_line(fnd_file.log,'Exception occured in  Calling Create Employee Contact Phone  Details API:'||SQLERRM);
                --L_ERR_MSG:=sqlerrm;
                --raise empexec;
              END;
            END IF;
            L_ERR_MSG := NULL;
            --#########################################################################
            -----------< Calling API to Create Employee Contact EC2_ALTERNATEPHONE  Details>----- MH-Alternate
            --##########################################################################
            IF L_EMP_REC.EC2_ALTERNATEPHONE IS NOT NULL AND L_C_PERSON_ID IS NOT NULL --dkantem
              THEN
              fnd_file.put_line(fnd_file.LOG,'entering Mobile phone details');
              fnd_file.put_line(fnd_file.log,' Phone 6 '||l_c_person_id);
              BEGIN
                CREATE_EMP_PH_DETAILS('MH',L_EMP_REC.EC2_ALTERNATEPHONE,L_C_PERSON_ID,P_ERR_MSG_PH);
                fnd_file.put_line(fnd_file.LOG,'After entering Mobile phone details '|| P_ERR_MSG_PH);
                IF P_ERR_MSG_PH= 1 THEN
                  fnd_file.put_line(fnd_file.LOG,'Entering phone details for EC2_ALTERNATEPHONE is SUCCESSFUL '|| P_ERR_MSG_PH);
                ELSE
                  fnd_file.put_line(fnd_file.log,'Entering phone details for EC2_ALTERNATEPHONE before raise exception');
                  --Update_Last_Error(':E',':E108',':Error while creating Alternate details',G_SEQ_NO);
                  l_empexec_status   := ':E';
                  l_empexec_err_code := ':E108';
                  l_empexec_err_msg  := ':Error while creating Alternate details,';
                  l_empexec_seq_no   := G_SEQ_NO;
                  raise empexec;
                  fnd_file.put_line(fnd_file.log,'Entering phone details for EC2_ALTERNATEPHONE Creation after Raise');
                  --Commit;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                fnd_file.put_line(fnd_file.log,'Exception occured in calling Create Employee Contact Home Phone  Details API:'||SQLERRM);
                --L_ERR_MSG:=sqlerrm;
                --raise empexec;
              END;
            END IF;
            L_ERR_MSG := NULL;
          EXCEPTION
          WHEN OTHERS THEN
            fnd_file.put_line(fnd_file.log,'Exception occurred in block entering phone details:'||SQLERRM);
            --L_ERR_MSG:=sqlerrm;
            --raise empexec;
          END;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee First child Details>----------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD1_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 1');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD1_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD1_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD1_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD1_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD1_GENDER, P_ERR_MSG => L_ERR_MSG);
              -- --Commit;
              IF L_ERR_MSG =1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 1 Creation Successfully');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 1 Creation before raise exception');
                --Update_Last_Error(':E',':E109',':Error while creating Child1 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E109';
                l_empexec_err_msg  := ':Error while creating Child1 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in Calling API to Create Employee First child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Second child Details>----------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD2_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 2');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD2_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD2_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', -- NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD2_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD2_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD2_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 2 Creation Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 2 Creation before raise exception');
                --Update_Last_Error(':E',':E110',':Error while creating Child 2 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E110';
                l_empexec_err_msg  := ':Error while creating Child 2 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in Calling API to Create Employee Second child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Third child Details>----------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD3_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 3');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD3_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD3_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD3_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD3_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD3_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 3 Creation Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 3 Creation before raise exception');
                --Update_Last_Error(':E',':E111',':Error while creating Child 3 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E111';
                l_empexec_err_msg  := ':Error while creating Child 3 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in Calling API to Create Employee Third child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Fourth child Details>----------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD4_LAST_NAME IS NOT NULL THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Calling CREATE_CONTACT for Child 4');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD4_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD4_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD4_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD4_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD4_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 4 Creation Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 4 Creation before raise exception');
                --Update_Last_Error(':E',':E112',':Error while creating Child 4 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E112';
                l_empexec_err_msg  := ':Error while creating Child 4 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in Calling API to Create Employee Fourth child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Fifth child Details>----------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD5_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 5');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD5_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD5_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD5_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD5_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD5_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 5 Creation Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 5 Creation before raise exception');
                --Update_Last_Error(':E',':E113',':Error while creating Child 5 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E113';
                l_empexec_err_msg  := ':Error while creating Child 5 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in Calling API to Create Employee Fifth child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Sixth child Details>------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD6_LAST_NAME IS NOT NULL THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Calling CREATE_CONTACT for Child 6');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD6_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD6_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD6_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD6_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD6_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 6 Creation Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 6 Creation before raise exception');
                --Update_Last_Error(':E',':E114',':Error while creating Child 6 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E114';
                l_empexec_err_msg  := ':Error while creating Child 6 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in Calling API to Create Employee sixth child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Seventh child Details>------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD7_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 7');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD7_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD7_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', -- NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD7_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD7_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD7_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 7 Creation Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 7 Creation before raise exception');
                --Update_Last_Error(':E',':E115',':Error while creating Child 7 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E115';
                l_empexec_err_msg  := ':Error while creating Child 7 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in Calling API to Create Employee seventh child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Eighth child Details>------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD8_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 8');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD8_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD8_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD8_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD8_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD8_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 8 Creation Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 8 Creation before raise exception');
                --Update_Last_Error(':E',':E116',':Error while creating Child 8 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E116';
                l_empexec_err_msg  := ':Error while creating Child 8 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in Calling API to Create Employee Eighth child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Ninth child Details>------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD9_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 9');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD9_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD9_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD9_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD9_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD9_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 9 Creation Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 9 Creation before raise exception');
                --Update_Last_Error(':E',':E117',':Error while creating Child 9 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E117';
                l_empexec_err_msg  := ':Error while creating Child 9 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in Calling API to Create Employee Nineth child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Employee Tenth child Details>------------
          --##########################################################################
          IF L_EMP_REC.MY_CHILD10_LAST_NAME IS NOT NULL THEN
            fnd_file.put_line(fnd_file.LOG,'Calling CREATE_CONTACT for Child 10');
            BEGIN
              CREATE_CONTACT(p_hr_emp_rec => L_emp_rec, L_LASTNAME => L_EMP_REC.MY_CHILD10_LAST_NAME, L_FIRSTNAME => L_EMP_REC.MY_CHILD10_FIRST_NAME, L_MIDDLENAME => NULL, L_RELATIONSHIP =>'C', --NULL,
              --L_CONTACT_TYPE => 'C',
              L_MARITAL_DATE => NULL, L_PERSONAL_FLAG => 'Y', L_NATIONAL_IDENTIFIER => L_EMP_REC.MY_CHILD10_NRIC, L_DATE_OF_BIRTH => TO_DATE(L_EMP_REC.MY_CHILD10_DOB,'MM/DD/RRRR'), L_SEX => L_EMP_REC.New_MY_CHILD10_GENDER, P_ERR_MSG => L_ERR_MSG);
              --Commit;
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.LOG,'Child 10 Creation Successfull');
              ELSE
                fnd_file.put_line(fnd_file.log,'Child 10 Creation before raise exception');
                --Update_Last_Error(':E',':E118',':Error while creating Child 10 details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E118';
                l_empexec_err_msg  := ':Error while creating Child 10 details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in Calling API to Create Employee Tenth child Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          ------------------< Calling CREATE_Qualification_DETAILS  >----------------------------
          --##########################################################################
          IF L_emp_rec.New_business_group='BG_MY' THEN
            BEGIN
              CREATE_Qualification_DETAILS (p_hr_emp_rec => L_emp_rec, p_err_msg => l_err_msg );
              fnd_file.put_line(fnd_file.log,'After Calling Create Qualification Details Creation');
              IF L_ERR_MSG = 1 THEN
                fnd_file.put_line(fnd_file.log,'Qualification Details Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Qualification Details before raise exception');
                --Update_Last_Error(':E',':E111',':Error while creating Qualification Details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E119';
                l_empexec_err_msg  := ':Error while creating Qualification Details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in  Calling Qualification Details API:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          ---------------------Passport details----------
          --#########################################################################
          -----------< Calling API to Create Passport Details>-----------------------
          --##########################################################################
          IF L_EMP_REC.PASSPORT_NUMBER IS NOT NULL THEN
            BEGIN
              fnd_file.put_line(fnd_file.LOG,'Passport Details Start');
              CREATE_PERSON_EXTRA_INFO(L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'HAE_PASSPORT_DETAILS_GLB', L_INFORMATION_CATEGORY => 'HAE_PASSPORT_DETAILS_GLB', L_INFORMATION1 => NULL, L_INFORMATION2 => NULL, L_INFORMATION3 => NULL, L_INFORMATION4 => NULL, L_INFORMATION5 => L_EMP_REC.New_PASSPORT_COUNTRY, L_INFORMATION6 => NULL, L_INFORMATION7 => NULL, L_INFORMATION8 => L_EMP_REC.PASSPORT_NUMBER, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => TO_CHAR(TO_DATE(L_EMP_REC.MY_PASSPORT_ISSUE_DATE,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS'), L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => TO_CHAR(TO_DATE(L_EMP_REC.MY_PASSPORT_EXPIRY_DATE,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS'), L_INFORMATION15 => NULL, L_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
              L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        -- out values
              );
              --Commit;
              fnd_file.put_line(fnd_file.LOG,'Passport Details End');
              IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
                fnd_file.put_line(fnd_file.LOG,'Passport Details Creation is SUCCESSFUL');
              ELSE
                fnd_file.put_line(fnd_file.log,'Passport Details before raise exception');
                --Update_Last_Error(':E',':E112',':Error while creating Passport Details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E120';
                l_empexec_err_msg  := ':Error while creating Passport Details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in calling creating Passport Details :'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Visa Details>-----------------------
          --##########################################################################
          IF L_emp_rec.New_business_group='BG_MY' THEN
            BEGIN
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Visa Details Start');
              CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'MY_VISA_INFORMATION', L_INFORMATION_CATEGORY => 'MY_VISA_INFORMATION', L_INFORMATION1 => TO_CHAR(TO_DATE(L_EMP_REC.MY_VISA_ISSUE_DATE,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS'), L_INFORMATION2 => TO_CHAR(TO_DATE(L_EMP_REC.MY_VISA_EXPIRY_DATE,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS'), L_INFORMATION3 => L_EMP_REC.MY_VISA_COUNTRY, L_INFORMATION4 => L_EMP_REC.New_MY_VISA_PERMIT_TYPE, L_INFORMATION5 => L_EMP_REC.MY_VISA_NUMBER , L_INFORMATION6 => L_EMP_REC.MY_VISA_ISSUED_BY, L_INFORMATION7 => L_EMP_REC.New_MY_VISA_ISSUING_STATE, L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
              L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     -- out values
              );
              --Commit;
              fnd_file.put_line(fnd_file.LOG,'Visa Details End');
              IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
                fnd_file.put_line(fnd_file.LOG,'Visa Details is SUCCESSFUL');
              ELSE
                fnd_file.put_line(fnd_file.log,'Visa Details before raise exception');
                --Update_Last_Error(':E',':E113',':Error while creating Visa Details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E121';
                l_empexec_err_msg  := ':Error while creating Visa Details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in calling creating Visa Details :'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Bank details Details>-------------------
          --##########################################################################
          IF L_emp_rec.New_business_group='BG_MY' THEN
            BEGIN
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Bank Details Start');
              CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'MY_BANKING_DETAILS', L_INFORMATION_CATEGORY => 'MY_BANKING_DETAILS', L_INFORMATION1 => sysdate, L_INFORMATION2 => NULL, L_INFORMATION3 => L_EMP_REC.New_MY_BANK_NAME, --MY_BANK_NAME,
              L_INFORMATION4 => L_EMP_REC.MY_BANK_ACCOUNT_CITY, L_INFORMATION5 => L_EMP_REC.MY_BANK_POSTAL_CODE, L_INFORMATION6 => L_EMP_REC.MY_BANK_SWIFT_CODE, L_INFORMATION7 => L_EMP_REC.MY_BANK_ACCOUNT_NUMBER, L_INFORMATION8 => L_EMP_REC.New_MY_BANK_ACCT_STATUS,  --MY_BANK_ACCOUNT_STATUS,
              L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID ,                             -- out values
              L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                           -- out values
              );
              --Commit;
              fnd_file.put_line(fnd_file.LOG,'Bank Details End');
              IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
                fnd_file.put_line(fnd_file.LOG,'Bank Details is Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Bank Details before raise exception');
                --Update_Last_Error(':E',':E114',':Error while creating Bank Details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E122';
                l_empexec_err_msg  := ':Error while creating Bank Details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in procedure creating Bank Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create Information For Tax Details>------------
          --##########################################################################
          IF L_emp_rec.New_business_group='BG_MY' THEN
            BEGIN
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Information For Tax Start');
              CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'MY_INFORMATION_FOR_TAX', L_INFORMATION_CATEGORY => 'MY_INFORMATION_FOR_TAX', L_INFORMATION1 => sysdate, L_INFORMATION2 => sysdate,                                                                                                                                                                                                                                                   --NULL,
              L_INFORMATION3 => L_EMP_REC.MY_NUM_OF_CHI_FOR_TAX, L_INFORMATION4 => L_EMP_REC.New_MY_TAX_FI_COMB_WITH_SPOU, L_INFORMATION5 => L_EMP_REC.New_MY_SPOUSE_WOR_STATUS, L_INFORMATION6 => NULL, L_INFORMATION7 => NULL, L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
              L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                          -- out values
              );
              --Commit;
              fnd_file.put_line(fnd_file.LOG,'Information For Tax End');
              IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
                fnd_file.put_line(fnd_file.LOG,'Information For Tax is Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Information For Tax before raise exception');
                --Update_Last_Error(':E',':E115',':Error while Info for tax Details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E123';
                l_empexec_err_msg  := ':Error while Info for tax Details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in calling Information For Tax:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create IPrior Employment Income details>------
          --##########################################################################
          IF L_emp_rec.New_business_group='BG_MY' THEN
            BEGIN
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Prior Employment Income details Start');
              CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'MY_PRIOR_EMPLOYMENT_INCOME', L_INFORMATION_CATEGORY => 'MY_PRIOR_EMPLOYMENT_INCOME', L_INFORMATION1 => L_EMP_REC.MY_PREVIOUS_EMPLOYER, L_INFORMATION2 => L_EMP_REC.MY_PREVIOUS_EMPL_STREET, L_INFORMATION3 => L_EMP_REC.MY_PREVIOUS_EMPL_POSTAL, L_INFORMATION4 => L_EMP_REC.New_MY_PREVIOUS_EMPL_STATE, L_INFORMATION5 => NULL, L_INFORMATION6 => NULL, L_INFORMATION7 => NULL, L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
              L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               -- out values
              );
              --Commit;
              fnd_file.put_line(fnd_file.LOG,'Prior Employment Income details End');
              IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
                fnd_file.put_line(fnd_file.LOG,'Prior Employment Income details is Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'Prior Employment Income details before raise exception');
                --Update_Last_Error(':E',':E116',':Error Prior Employment Income details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E124';
                l_empexec_err_msg  := ':Error Prior Employment Income details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in processing Employment Income details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to US Ethnic Origin Details 1>-------------------
          --##########################################################################
          IF L_emp_rec.New_business_group='BG_US' THEN
            BEGIN
              FND_FILE.PUT_LINE(FND_FILE.LOG,'US Ethnic Origin Start');
              IF L_EMP_REC.EEO_RACE LIKE '%Hispanic%or%Latino' THEN
                CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'US_ETHNIC_ORIGIN', L_INFORMATION_CATEGORY => 'US_ETHNIC_ORIGIN', L_INFORMATION1 =>'Y', L_INFORMATION2 =>'N', L_INFORMATION3 => 'N', L_INFORMATION4 => 'N', L_INFORMATION5 => 'N', L_INFORMATION6 => 'N', L_INFORMATION7 => 'N', L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
                L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -- out values
                );
                --Commit;
              elsif L_EMP_REC.EEO_RACE LIKE '%American%Indian%Alaskan%' THEN
                CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'US_ETHNIC_ORIGIN', L_INFORMATION_CATEGORY => 'US_ETHNIC_ORIGIN', L_INFORMATION1 =>'N', L_INFORMATION2 =>'Y', L_INFORMATION3 => 'N', L_INFORMATION4 => 'N', L_INFORMATION5 => 'N', L_INFORMATION6 => 'N', L_INFORMATION7 => 'N', L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
                L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -- out values
                );
                --Commit;
              elsif L_EMP_REC.EEO_RACE LIKE '%Asian%' THEN
                CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'US_ETHNIC_ORIGIN', L_INFORMATION_CATEGORY => 'US_ETHNIC_ORIGIN', L_INFORMATION1 =>'N', L_INFORMATION2 =>'N', L_INFORMATION3 => 'Y', L_INFORMATION4 => 'N', L_INFORMATION5 => 'N', L_INFORMATION6 => 'N', L_INFORMATION7 => 'N', L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
                L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -- out values
                );
                --Commit;
              elsif L_EMP_REC.EEO_RACE LIKE '%Black%or%African%' THEN
                CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'US_ETHNIC_ORIGIN', L_INFORMATION_CATEGORY => 'US_ETHNIC_ORIGIN', L_INFORMATION1 =>'N', L_INFORMATION2 =>'N', L_INFORMATION3 => 'N', L_INFORMATION4 => 'Y', L_INFORMATION5 => 'N', L_INFORMATION6 => 'N', L_INFORMATION7 => 'N', L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
                L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -- out values
                );
                --Commit;
              elsif L_EMP_REC.EEO_RACE LIKE '%Native%or%other%' THEN
                CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'US_ETHNIC_ORIGIN', L_INFORMATION_CATEGORY => 'US_ETHNIC_ORIGIN', L_INFORMATION1 =>'N', L_INFORMATION2 =>'N', L_INFORMATION3 => 'N', L_INFORMATION4 => 'N', L_INFORMATION5 => 'Y', L_INFORMATION6 => 'N', L_INFORMATION7 => 'N', L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
                L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -- out values
                );
                --Commit;
              elsif L_EMP_REC.EEO_RACE LIKE '%White%' THEN
                CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'US_ETHNIC_ORIGIN', L_INFORMATION_CATEGORY => 'US_ETHNIC_ORIGIN', L_INFORMATION1 =>'N', L_INFORMATION2 =>'N', L_INFORMATION3 => 'N', L_INFORMATION4 => 'N', L_INFORMATION5 => 'N', L_INFORMATION6 => 'Y', L_INFORMATION7 => 'N', L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
                L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -- out values
                );
                --Commit;
              ELSE
                CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'US_ETHNIC_ORIGIN', L_INFORMATION_CATEGORY => 'US_ETHNIC_ORIGIN', L_INFORMATION1 =>'N', L_INFORMATION2 =>'N', L_INFORMATION3 => 'N', L_INFORMATION4 => 'N', L_INFORMATION5 => 'N', L_INFORMATION6 => 'N', L_INFORMATION7 => 'Y', L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
                L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              -- out values
                );
                --Commit;
              END IF;
              --fnd_file.put_line(fnd_file.LOG,'US Ethnic Origin');
              IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
                fnd_file.put_line(fnd_file.LOG,'US Ethnic Origin is Successful');
              ELSE
                fnd_file.put_line(fnd_file.log,'US Ethnic Origin before raise exception');
                --Update_Last_Error(':E',':E117',':Error while creating US Ethnic Origin Details',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E125';
                l_empexec_err_msg  := ':Error while creating US Ethnic Origin Details,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
              --End if;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occured in procedure creating US Ethnic Origin1 Details:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          L_ERR_MSG := NULL;
          --#########################################################################
          -----------< Calling API to Create MY Statutory Information>---------------
          --##########################################################################
          IF L_emp_rec.New_business_group='BG_MY' THEN
            BEGIN
              FND_FILE.PUT_LINE(FND_FILE.log,'MY Statutory Information Start');
              CREATE_PERSON_EXTRA_INFO( L_PERSONID =>L_EMP_REC.New_PERSON_ID, L_INFORMATION_TYPE => 'MY_STATUTORY_INFORMATION', L_INFORMATION_CATEGORY => 'MY_STATUTORY_INFORMATION', L_INFORMATION1 => sysdate, L_INFORMATION2 => NULL, L_Information3 => L_Emp_Rec.New_MY_CONT_TO_EPF, L_Information4 => L_Emp_Rec.My_Epf_No, L_Information5 => L_Emp_Rec.New_MY_CONT_TO_SOCSO, L_Information6 => L_Emp_Rec.My_Taxrefno13digit, L_INFORMATION7 => L_EMP_REC.MY_ZAKAT_FILE_NO, L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID , -- out values
              L_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         -- out values
              );
              --Commit;
              fnd_file.put_line(fnd_file.LOG,'MY Statutory Information End');
              IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
                fnd_file.put_line(fnd_file.LOG,'MY Statutory Information is SUCCESSFUL');
              ELSE
                fnd_file.put_line(fnd_file.log,'MY Statutory Information before raise exception');
                --Update_Last_Error(':E',':E118',':Error Statutory Information',G_SEQ_NO);
                l_empexec_status   := ':E';
                l_empexec_err_code := ':E126';
                l_empexec_err_msg  := ':Error Statutory Information,';
                l_empexec_seq_no   := G_SEQ_NO;
                raise empexec;
                --Commit;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              fnd_file.put_line(fnd_file.log,'Exception occurred in processing MY Statutory Information:'||SQLERRM);
              --L_ERR_MSG:=sqlerrm;
              --raise empexec;
            END;
          END IF;
          --L_ERR_MSG                 := NULL;
        END IF; --Added for Contingent
        fnd_file.put_line(fnd_file.log,'L_ERR_MSG :'||L_ERR_MSG);
        IF L_ERR_MSG IS NULL THEN
          UPDATE XXHA_TALEO_EMP_TR_STG
          SET STATUS_STG         ='L'
          WHERE STATUS_STG       ='V'
          AND TRANSACTION_ID_STG = G_SEQ_NO;
          COMMIT;
        END IF;
      EXCEPTION
      WHEN empexec THEN
        ROLLBACK; --to employee;
        fnd_file.put_line(fnd_file.log,'Rollback Exception:'||sqlerrm);
        Update_Last_Error(l_empexec_status,l_empexec_err_code,l_empexec_err_msg,l_empexec_seq_no);
        --commit;
      END;
    END LOOP;
    CLOSE CUR_EMP_STG1;
  END;
  --Added July-6th
EXCEPTION
WHEN OTHERS THEN
  --rollback; --to employee;
  fnd_file.put_line(fnd_file.log,'Main Exception:'||sqlerrm);
  --END;
End Main;
END XXHA_TALEO_EMP_TR_PKG;
/