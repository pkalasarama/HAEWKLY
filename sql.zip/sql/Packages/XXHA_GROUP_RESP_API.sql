CREATE OR REPLACE PACKAGE      xxha_group_resp_api
IS
--$Header$
/*******************************************************************************************
*Procedure Name: XXHA_GROUP_RESP_API
*
*Description: This package/procedure automates manual steps done for assigning a non-HR
*                 responsibility
*
*Created By: David Lund
*Date:   JUL-20-2012
*
*Modification Log:
*Developer           Ver   Date                     Description
*-----------------   ---  ------------------   ------------------------------------------------
* David Lund          1.0     Jul-20-2012           Created this Package/Procedure
* Don Browne          1.1     Mar-10-2014           Added end date and security group
*******************************************************************************************/
--
   PROCEDURE upload_resp (
      p_user_name             IN   VARCHAR2,
      p_responsibility_name   IN   VARCHAR2,
      p_start_date            IN   DATE DEFAULT NULL,
      p_end_date              IN   DATE DEFAULT NULL,
      p_security_group        IN   VARCHAR2 DEFAULT NULL
   );
END;
/


CREATE OR REPLACE PACKAGE BODY      xxha_group_resp_api
IS
--$Header$
/*******************************************************************************************
*Procedure Name: XXHA_GROUP_RESP_API
*
*Description: This package/procedure automates manual steps done for assigning a non-HR
*                 responsibility
*
*Created By: David Lund
*Date:   JUL-20-2012
*
*Modification Log:
*Developer           Ver   Date                     Description
*-----------------   ---  ------------------   ------------------------------------------------
* David Lund          1.0     Jul-20-2012           Created this Package/Procedure
* Don Browne          1.1     Mar-10-2014           Added end date and security group
*******************************************************************************************/
--
   PROCEDURE upload_resp (
      p_user_name             IN   VARCHAR2,
      p_responsibility_name   IN   VARCHAR2,
      p_start_date            IN   DATE DEFAULT NULL,
      p_end_date              IN   DATE DEFAULT NULL,
      p_security_group        IN   VARCHAR2 DEFAULT NULL
   )
   IS
      v_user_id             NUMBER;
      v_application_id      NUMBER;
      v_responsibility_id   NUMBER;
      v_start_date          DATE;
      v_end_date            DATE;
      v_exception_text      VARCHAR2 (500) := '';
      v_security_group_id   NUMBER:=0;
      v_orig_security_group_id   NUMBER;
   BEGIN
      BEGIN
         SELECT user_id
           INTO v_user_id
           FROM fnd_user
          WHERE user_name = p_user_name;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            v_exception_text := 'No User Found.';
      END;

      BEGIN
         SELECT application_id, responsibility_id
           INTO v_application_id, v_responsibility_id
           FROM fnd_responsibility_vl
          WHERE responsibility_name = p_responsibility_name;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            v_exception_text :=
                              v_exception_text || 'Responsibility Not Found.';
      END;

      IF p_security_group IS NOT NULL
      THEN
         BEGIN
            SELECT security_group_id
              INTO v_security_group_id
              FROM fnd_security_groups_tl
             WHERE LANGUAGE = 'US' AND security_group_name = p_security_group;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_exception_text :=
                              v_exception_text || 'Security Group Not Found.';
         END;
      END IF;

      IF v_exception_text IS NULL
      THEN
         BEGIN
            SELECT ur.start_date, ur.end_date, ur.security_group_id
              INTO v_start_date, v_end_date, v_orig_security_group_id
              FROM fnd_responsibility_tl r, fnd_user_resp_groups_direct ur
             WHERE r.responsibility_id = v_responsibility_id
               AND r.application_id = v_application_id
               AND r.LANGUAGE = 'US'
               AND ur.responsibility_id(+) = r.responsibility_id
               AND ur.responsibility_application_id(+) = r.application_id
               and ur.security_group_id(+) = v_security_group_id
               AND ur.user_id(+) = v_user_id;

            IF v_start_date IS NULL
            THEN
               fnd_user_resp_groups_api.insert_assignment
                          (user_id                            => v_user_id,
                           responsibility_id                  => v_responsibility_id,
                           responsibility_application_id      => v_application_id,
                           security_group_id                  => v_security_group_id,
                           start_date                         => NVL
                                                                    (p_start_date,
                                                                     SYSDATE
                                                                    ),
                           end_date                           => p_end_date,
                           description                        => 'Web ADI Assignment'
                          );
            ELSE
               -- start and end date updates
               fnd_user_resp_groups_api.update_assignment
                          (user_id                            => v_user_id,
                           responsibility_id                  => v_responsibility_id,
                           responsibility_application_id      => v_application_id,
                           security_group_id                  => v_orig_security_group_id,
                           start_date                         => nvl(p_start_date,v_start_date),
                           end_date                           => p_end_date,
                           description                        => 'Web ADI Assignment'
                          );
            END IF;
         END;
      ELSE
         fnd_message.set_name ('BNE', v_exception_text);
      END IF;
   END;
END;
/
