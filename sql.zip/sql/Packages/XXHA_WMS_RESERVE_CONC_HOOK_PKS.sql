
  CREATE OR REPLACE PACKAGE "APPS"."XXHA_WMS_RESERVE_CONC_HOOK" AUTHID CURRENT_USER as
  /*******************************************************************************************************
  * Object Name: XXHA_RATESHOP_ONDEMAND_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package is modified to restrict the outbound exception items for reservation in WMS orgs
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    27-APR-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/

-- Reserve Order Constants
RSV_RUN_SIMULATE            CONSTANT VARCHAR2(30) := 'SIMULATE';
RSV_RUN_RESERVE             CONSTANT VARCHAR2(30) := 'RESERVE';



Procedure Qty_Per_Business_Rule
(p_x_rsv_tbl           IN OUT NOCOPY /* file.sql.39 change */ XXHA_WMS_RESERVE_CONC.rsv_tbl_type);

Procedure Simulated_Results
(p_x_rsv_tbl           IN OUT NOCOPY /* file.sql.39 change */ XXHA_WMS_RESERVE_CONC.rsv_tbl_type);


END XXHA_WMS_RESERVE_CONC_HOOK;
/
