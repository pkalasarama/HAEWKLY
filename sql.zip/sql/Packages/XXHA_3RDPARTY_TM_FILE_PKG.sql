CREATE OR REPLACE PACKAGE xxha_3rdparty_tm_file_pkg IS
--	gc_owm_cust_name VARCHAR2(1000):=	'Owens'||' & '||'Minor';
--	gc_car_cust_name VARCHAR2(1000):=	'Cardinal';
	gc_owm_cust_name VARCHAR2(1000):=	'Owens'||' and '||'Minor';
	gc_car_cust_name VARCHAR2(1000):=	'Cardinal Health Medical Services';
	gn_request_id           NUMBER         :=FND_PROFILE.VALUE('CONC_REQUEST_ID');--Variable to hold Request id
gn_record_number        NUMBER;                                               --Variable to hold Record Number
gc_record_identifier    VARCHAR2(2000);                                       --Variable to hold Record Identifier
gc_err_rec_identifier   VARCHAR2(2000);                                       --Variable to hold Error Record Identifier
gc_error_code           VARCHAR2(2000);                                       --Variable to hold Error Code
gc_error_msg            VARCHAR2(2000);                                       --Variable to hold Error Message
gc_comments             VARCHAR2(2000);                                       --Variable to hold Comments
gc_table_name           VARCHAR2(2000) :=' ';                   --Variable to hold Table Name
gc_attribute1           VARCHAR2(2000);                                       --Variable to hold Attribute1
gc_attribute2           VARCHAR2(2000);                                       --Variable to hold Attribute2
gc_attribute3           VARCHAR2(2000);                                       --Variable to hold Attribute3
gc_attribute4           VARCHAR2(2000);                                       --Variable to hold Attribute4
gc_attribute5           VARCHAR2(2000);                                       --Variable to hold Attribute5
gc_status               VARCHAR2(2000);                                       --Variable to hold Status of the Insertion to Common Error Table
gc_con_name             VARCHAR2(240)  :=' ';         --Variable to hold Concurrent Program Name
gc_identifier           VARCHAR2(240)  :=' ';                    --Variable to hold the Identifier for the Error Report
gc_debug_flag           VARCHAR2(1);                                          --Variable to hold the Debug Flag
gc_log_msg              VARCHAR2(4000);                                       --Variable to hold the log Message
gn_record_id            NUMBER;                                               --Variable to hold the Record Id
gc_status_flag          VARCHAR2(150);                                        --Variable to hold the Status Flag
gc_api_status           VARCHAR2(20);                                         --Variable to hold the API Status
gc_car_xref             VARCHAR2(40)  := 'Cardinal Health';
gc_owm_xref             VARCHAR2(40)  := 'Owens and Minor Virginia';
gc_error_logged    VARCHAR2(2000);
gc_warning_logged    VARCHAR2(2000) := 'N';
g_cardinal_customer_number varchar2 (2000) := '9924';
g_owm_customer_number varchar2 (2000) := '9107';
g_cardinal_customer_id number := 226646;
g_cardinal_party_id number := 297614;
g_cardinal_party_name varchar2 (2000) := 'Cardinal Health Medical Services';
g_owm_customer_id number := 225829;
g_owm_party_id number := 290429;
g_owm_party_name varchar2 (2000) := 'Owens and Minor Virginia';
g_cardinal_party_site_id number := 361950;
g_owm_party_site_id number := 358182;
g_record_error_occured boolean;


procedure process_cardinal_trace_file
                                    (
									 x_err_buf  out  varchar2
                                     ,x_ret_code  out  varchar2
									 ,p_report_date varchar2
									 ,p_month_start_date varchar2
                   ,pp_dist  IN VARCHAR2
                   ,pp_partial_file IN VARCHAR2
									);
procedure process_owm_trace_file (
									 x_err_buf  out  varchar2
                                     ,x_ret_code  out  varchar2
									 ,p_report_date varchar2
									 ,p_month_start_date varchar2
                   ,pp_dist  IN VARCHAR2
                   ,pp_partial_file IN VARCHAR2
									);
procedure process_web_adi_trace_file
                                    (
--									 x_err_buf  out  varchar2
--                                     ,x_ret_code  out  varchar2
									 p_batch_number varchar2
--                   ,p_start_report_date varchar2
--									 ,p_end_report_date varchar2
									);

PROCEDURE INSERT_ERROR_PRC;
procedure get_3rdparty_owm(--errbuf  OUT VARCHAR2,
                           --retcode OUT NUMBER,
                           p_dist  IN VARCHAR2,
                           p_partial_file IN VARCHAR2,
                           p_report_date IN VARCHAR2)  ;
procedure populate_tm_3rdparty_stg_tbl(record_number number);
procedure populate_common_error(error_msg varchar2,error_code varchar2,error_comments varchar2,record_number number,record_identifier varchar2);
procedure populate_tm_3rd_success_tbl(record_number number);
procedure log_error;
procedure log_all_errors;
procedure chk_customer_exists
                            (
							legacy_customer_number varchar2
							,legacy_customer_name varchar2
							,l_legacy_address varchar2
							,customer_name out varchar2
							,customer_account_id out number
							,party_site_number out varchar2
							,l_ship_to_location out varchar2
							,l_customer_number out varchar2
							,x_customer_exists out boolean
							);
procedure chk_item_exists
                        (p_distributor varchar2
						,p_legacy_item_number IN OUT varchar2
						,p_customer_id number
						,x_oracle_item_number out varchar2
						,x_oracle_inventory_item_id out number
						,x_item_exists out boolean
						);
procedure chk_bsa_exists
                            (
							p_customer_id varchar2
							,p_customer_number varchar2
							,p_ordered_item  varchar2
							,p_order_date date
							,x_price_list_id out number
							,x_price_list_name out varchar2
							,x_line_bsa_no out varchar2
							,x_bsa_exists out boolean
							);
procedure get_selling_price(p_price_list_name varchar2
		  					,p_item_number varchar2
							,p_legacy_Item_Number varchar2
							,p_price_list_id number
							,p_inventory_item_id number
							,p_transaction_date date
							,x_selling_price out varchar2
							);
procedure update_partner_information(distributor varchar2);
procedure update_negative_quantity;
procedure get_order_number (p_trx_date date
                            ,p_record_number IN OUT Varchar2
                            ,x_order_number OUT varchar2
							);
procedure get_oracle_quantity
                                (
								 p_inventory_item_id number
								 ,p_legacy_uom IN OUT varchar2
								 ,p_legacy_quantity number
								 ,x_oracle_quantity OUT varchar2
								 ,x_oracle_uom out varchar2
								 );
procedure validate_cardinal_data;
procedure validate_owm_data;
procedure create_flat_records_owm;
END xxha_3rdparty_tm_file_pkg;
/


CREATE OR REPLACE PACKAGE BODY      xxha_3rdparty_tm_file_pkg
IS
--+=============================================================================+
--| Name        :    xxha_3rdparty_tm_file_pkg                                  |
--|                                                                             |
--| Description :   Procedure to validate and generat TM output                 |
--|                                                                             |
--|                                                                             |
--|  History            Author      Date        Change                          |
--|  Rel 1.1            P.Rajack    29-aug-07   Added parameter (partial file)  |
--|  Rel 2.0            D. Lund     01-MAY-2010 Multiple changes based on new   |
--|                                             requirements                    |
--|  Rel 2.1            D. Lund     21-MAY-2010 Changed BSA logic to exclude    |
--|                                             Terminated BSAs after 4/1/2010  |
--|  Rel 2.2a           D. Lund     07-APR-2011 expended customer name field    |
--|  Rel 3.0            D. Lund     10-AUG-2011 Added logic to allow partial    |
--|                                             batch processing                |
--|  Rel 4.0            D. Lund     16-SEP-2011 Added logic to look for items   |
--|                                             on the secondary price list for |
--|                                             the default US price list       |
--|  Rel 4.1            D. Lund     15-NOV-2011 Put back in message if default  |
--|                                             price list is used              |
--|                                                                             |
--|  Rel 4.2            D. Browne   27-Feb-2014 Reformat O&M and Cardinal files |
--|  Rel 4.3            D. Browne   27-Feb-2014 Changes for R12 and TCA         |
--|                                                                             |
--+=============================================================================+
   TYPE xx_common_error_tbl_type IS TABLE OF xxha_common_errors%ROWTYPE
      INDEX BY BINARY_INTEGER;

   xx_common_error_tbl         xx_common_error_tbl_type;

   TYPE xx_tm_3rdparty_stg_tbl_type IS TABLE OF xxha_3rdparty_car_stg%ROWTYPE
      INDEX BY BINARY_INTEGER;

   xx_tm_3rdparty_stg_tbl      xx_tm_3rdparty_stg_tbl_type;

   TYPE xx_tm_3rd_success_stg_tbl_type IS TABLE OF xxha_3rdparty_car_stg%ROWTYPE
      INDEX BY BINARY_INTEGER;

   xx_tm_3rd_success_stg_tbl   xx_tm_3rd_success_stg_tbl_type;

   PROCEDURE insert_error_prc
   IS
--|=============================================================================+
--| Name        :   INSERT_ERROR_PRC                                            |
--|                                                                             |
--| Description :   Procedure to call xxha_common_utilities.insert_error_prc    |
--|                                                                             |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN:    gn_request_id                                                      |
--|          gn_record_number                                                   |
--|          gc_err_rec_identifier                                              |
--|          gc_error_code                                                      |
--|          gc_error_msg                                                       |
--|          gc_comments                                                        |
--|          gc_table_name                                                      |
--|          gc_attribute1                                                      |
--|          gc_attribute2                                                      |
--|          gc_attribute3                                                      |
--|          gc_attribute4                                                      |
--|          gc_attribute5                                                      |
--|  OUT:    gc_status                                                          |
--|                                                                             |
--|  Returns :                                                                  |
--|=============================================================================+
   BEGIN
      xxha_common_utilities_pkg.insert_error_prc (gn_request_id,
                                                  gn_record_number,
                                                  gc_err_rec_identifier,
                                                  gc_error_code,
                                                  gc_error_msg,
                                                  gc_comments,
                                                  gc_table_name,
                                                  gc_attribute1,
                                                  gc_attribute2,
                                                  gc_attribute3,
                                                  gc_attribute4,
                                                  gc_attribute5,
                                                  gc_status
                                                 );
   EXCEPTION
      WHEN OTHERS
      THEN
         fnd_file.put_line
            (fnd_file.LOG,
                'Error in XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC. Error is: '
             || SQLERRM
            );
   END insert_error_prc;
   
    PROCEDURE chk_bsa_exists (
      p_customer_id             VARCHAR2,
      p_customer_number         VARCHAR2,
      p_ordered_item            VARCHAR2,
      p_order_date              DATE,
      x_price_list_id     OUT   NUMBER,
      x_price_list_name   OUT   VARCHAR2,
      x_line_bsa_no       OUT   VARCHAR2,
      x_bsa_exists        OUT   BOOLEAN
   )
   IS
      CURSOR c_bsa
      IS
       SELECT   NAME, blh.order_number,
                  NVL (bll.price_list_id, blh.price_list_id) price_list_id,
                  1 site_match, blh.flow_status_code
             FROM oe_blanket_headers_all blh,
                  oe_blanket_lines_all bll,
                  qp_list_headers_tl pl,
                  oe_blanket_lines_ext ext,
                  hz_cust_accounts hca,
                hz_parties hp,
                hz_cust_acct_sites hcas,
                hz_cust_site_uses hsu,
                hz_party_sites hps,
                hz_locations hl
            WHERE blh.header_id = bll.header_id
              AND blh.org_id = 102
              AND blh.sold_to_org_id = p_customer_id
              AND bll.ordered_item = p_ordered_item
              AND NVL (bll.price_list_id, blh.price_list_id) =
                                                             pl.list_header_id
              AND pl.LANGUAGE = 'US'
              AND ext.order_number = blh.order_number
              AND ext.line_number = bll.line_number
              AND TRUNC (NVL (ext.start_date_active, p_order_date)) <=
                                                          TRUNC (p_order_date)
              AND TRUNC (NVL (ext.end_date_active, p_order_date)) >=
                                                          TRUNC (p_order_date)
              AND hca.cust_account_id = blh.sold_to_org_id
              AND blh.ship_to_org_id =hsu.site_use_id
              AND (   (    p_order_date >= '01-APR-2010'
                       AND NVL (blh.flow_status_code, 'ACTIVE') <>
                                                                  'TERMINATED'
                      )
                   OR (p_order_date < '01-APR-2010')
                  )
            and hca.party_id = hp.party_id
            AND hp.status = 'A'
            AND hcas.status = 'A'
            AND hsu.status = 'A'
            AND hps.status = 'A'
            AND hca.status = 'A'
            AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
            AND hca.cust_account_id = hcas.cust_account_id
            AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
            AND hps.party_site_id = hcas.party_site_id
            AND hl.location_id = hps.location_id
            and hsu.attribute3 = p_customer_number
         UNION
         SELECT   NAME, blh.order_number,
                  NVL (bll.price_list_id, blh.price_list_id) price_list_id,
                  0 site_match, blh.flow_status_code
             FROM oe_blanket_headers_all blh,
                  oe_blanket_lines_all bll,
                  qp_list_headers_tl pl,
                  oe_blanket_lines_ext ext
            WHERE blh.header_id = bll.header_id
              AND blh.org_id = 102
              AND blh.sold_to_org_id = p_customer_id
              AND bll.ordered_item = p_ordered_item
              AND NVL (bll.price_list_id, blh.price_list_id) =
                                                             pl.list_header_id
              AND pl.LANGUAGE = 'US'
              AND ext.order_number = blh.order_number
              AND ext.line_number = bll.line_number
              AND blh.ship_to_org_id IS NULL
              AND TRUNC (NVL (ext.start_date_active, p_order_date)) <=
                                                          TRUNC (p_order_date)
              AND TRUNC (NVL (ext.end_date_active, p_order_date)) >=
                                                          TRUNC (p_order_date)
              AND (   (    p_order_date >= '01-APR-2010'
                       AND NVL (blh.flow_status_code, 'ACTIVE') <>
                                                                  'TERMINATED'
                      )
                   OR (p_order_date < '01-APR-2010')
                  )
         ORDER BY 4, 2 DESC;

      l_counter   NUMBER;
   BEGIN
      l_counter := 1;
      x_bsa_exists := FALSE;

      FOR v_bsa IN c_bsa
      LOOP
--   IF l_counter = 1 THEN
         x_price_list_name := v_bsa.NAME;
         x_line_bsa_no := v_bsa.order_number;
         x_bsa_exists := TRUE;
         x_price_list_id := v_bsa.price_list_id;
--   END IF;
         l_counter := l_counter + 1;
      END LOOP;

      IF NOT x_bsa_exists
      THEN
         populate_common_error
                 (   'WARNING: BSA Does Not Exist For Customer Number/Item '
                  || p_customer_number
                  || '/'
                  || p_ordered_item,
                  'DEFAULT_PRICE_LIST',
                  'Check BSA',
                  gn_record_number,
                  gc_record_identifier
                 );

         BEGIN
            SELECT a.price_list_id, pl.NAME
              INTO x_price_list_id, x_price_list_name
              FROM oe_transaction_types_tl t,
                   oe_transaction_types_all a,
                   qp_list_lines_v ll,
                   mtl_system_items_b i,
                   mtl_parameters p,
                   qp_price_lists_v pl
             WHERE t.transaction_type_id = a.transaction_type_id
               AND t.LANGUAGE = 'US'
               AND t.NAME = 'US Indirect Sales'
               AND a.price_list_id = ll.list_header_id
               AND a.price_list_id = pl.price_list_id
               AND ll.product_id = i.inventory_item_id
               AND i.segment1 = p_ordered_item
               AND i.organization_id = p.organization_id
               AND p.organization_code = 'MST'
               AND p_order_date BETWEEN NVL (ll.start_date_active,
                                             p_order_date
                                            )
                                    AND NVL (ll.end_date_active, p_order_date);
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               BEGIN
                  SELECT a.price_list_id
                    INTO x_price_list_id
                    FROM oe_transaction_types_tl t,
                         oe_transaction_types_all a,
                         qp_price_lists_v pl
                   WHERE t.transaction_type_id = a.transaction_type_id
                     AND t.LANGUAGE = 'US'
                     AND t.NAME = 'US Indirect Sales'
                     AND a.price_list_id = pl.price_list_id;

                  SELECT b.NAME, b.list_header_id
                    INTO x_price_list_name, x_price_list_id
                    FROM qp_list_lines_v ll,
                         mtl_system_items_b i,
                         mtl_parameters p,
                         qp_secondary_price_lists_v b
                   WHERE b.parent_price_list_id = x_price_list_id
                     AND b.list_header_id = ll.list_header_id
                     AND p_order_date BETWEEN ll.start_date_active
                                          AND NVL (ll.end_date_active,
                                                   TO_DATE ('01/01/2090',
                                                            'dd/mm/yyyy'
                                                           )
                                                  )
                     AND ll.product_attr_value = i.inventory_item_id
                     AND i.segment1 = p_ordered_item
                     AND i.organization_id = p.organization_id
                     AND p.organization_code = 'MST'
                     AND ll.product_attribute_context = 'ITEM'
                     AND ll.list_line_type_code = 'PLL'
                     AND NOT EXISTS (
                            SELECT NULL
                              FROM qp_secondary_price_lists_v b2
                             WHERE b.parent_price_list_id =
                                                       b2.parent_price_list_id
                               AND b.precedence > b2.precedence);

                  x_bsa_exists := TRUE;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     populate_common_error
                          (   'BSA Does Not Exist For Customer Number/Item '
                           || p_customer_number
                           || '/'
                           || p_ordered_item,
                           'NO_VALID_PRICE_LIST',
                           'Check BSA/Default Price List',
                           gn_record_number,
                           gc_record_identifier
                          );
                  WHEN OTHERS
                  THEN
                     populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                            'When Others',
                                            'When BSA Order Number',
                                            gn_record_number,
                                            gc_record_identifier
                                           );
               END;
         END;
      ELSE
         BEGIN
            SELECT l.NAME, l.price_list_id
              INTO x_price_list_name, x_price_list_id
              FROM qp_list_lines_v ll,
                   mtl_system_items_b i,
                   mtl_parameters p,
                   qp_price_lists_v l
             WHERE ll.list_header_id = x_price_list_id
               AND ll.list_header_id = l.price_list_id
               AND p_order_date BETWEEN ll.start_date_active
                                    AND NVL (ll.end_date_active,
                                             TO_DATE ('01/01/2090',
                                                      'dd/mm/yyyy'
                                                     )
                                            )
               AND ll.product_attr_value = i.inventory_item_id
               AND i.segment1 = p_ordered_item
               AND i.organization_id = p.organization_id
               AND p.organization_code = 'MST'
               AND ll.product_attribute_context = 'ITEM'
               AND ll.list_line_type_code = 'PLL';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               BEGIN
                  SELECT b.NAME, b.list_header_id
                    INTO x_price_list_name, x_price_list_id
                    FROM qp_list_lines_v ll,
                         mtl_system_items_b i,
                         mtl_parameters p,
                         qp_secondary_price_lists_v b
                   WHERE b.parent_price_list_id = x_price_list_id
                     AND b.list_header_id = ll.list_header_id
                     AND p_order_date BETWEEN ll.start_date_active
                                          AND NVL (ll.end_date_active,
                                                   TO_DATE ('01/01/2090',
                                                            'dd/mm/yyyy'
                                                           )
                                                  )
                     AND ll.product_attr_value = i.inventory_item_id
                     AND i.segment1 = p_ordered_item
                     AND i.organization_id = p.organization_id
                     AND p.organization_code = 'MST'
                     AND ll.product_attribute_context = 'ITEM'
                     AND ll.list_line_type_code = 'PLL'
                     AND NOT EXISTS (
                            SELECT NULL
                              FROM qp_secondary_price_lists_v b2
                             WHERE b.parent_price_list_id =
                                                       b2.parent_price_list_id
                               AND b.precedence > b2.precedence);
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     populate_common_error
                               (   'Item does not exist on BSA price lists '
                                || p_customer_number
                                || '/'
                                || p_ordered_item
                                || '/'
                                || x_line_bsa_no,
                                'NO_VALID_PRICE_LIST',
                                'Check BSA/Price List',
                                gn_record_number,
                                gc_record_identifier
                               );
                  WHEN OTHERS
                  THEN
                     populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                            'When Others',
                                            'When BSA Price List2',
                                            gn_record_number,
                                            gc_record_identifier
                                           );
               END;
--
            WHEN OTHERS
            THEN
               populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                      'When Others',
                                      'When BSA Price List1',
                                      gn_record_number,
                                      gc_record_identifier
                                     );
         END;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'log error',
                                'When Others chk bsa',
                                gn_record_number,
                                gc_record_identifier
                               );
   END;

--+=============================================================================+
--| Name        :    GET_3RDPARTY_OWM                                           |
--|                                                                             |
--| Description :   Procedure to validate and generat TM output                 |
--|                                                                             |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN:    errbuf                                                             |
--|          retcode                                                            |
--|  Returns :                                                                  |
--|  History            Author      Date        Change                          |
--|  Rel 1.1            P.Rajack    29-aug-07   Added parameter (partial file)  |
--|                                                                             |
--|                                                                             |
--|                                                                             |
--+=============================================================================+
   PROCEDURE get_3rdparty_owm (                        --errbuf  OUT VARCHAR2,
                                                       --retcode OUT NUMBER,
      p_dist           IN   VARCHAR2,
      p_partial_file   IN   VARCHAR2,
      p_report_date    IN   VARCHAR2
   )
   IS
      temp_char                   VARCHAR2 (10000);
      lc_sign                     VARCHAR2 (1);
      lc_qty                      VARCHAR2 (10);
      lc_val_flag                 VARCHAR2 (1)     := 'N';
      gn_child_request2_id        NUMBER           := 0;
      lc_logfile                  VARCHAR2 (10000);
      lc_validation_status_code   VARCHAR2 (10000);
      lc_rollback_flag            VARCHAR2 (1)     := 'N';
      l_error_count               NUMBER;
      l_pricelist                 VARCHAR2 (240);
      l_agree_type                VARCHAR2 (10);
      l_unit_price                NUMBER;
      l_purchase_price            NUMBER;
      l_start_date                DATE;                   -- added sept282007
      l_end_date                  DATE;                 -- ADDED SEPT-28-2007
      l_conversion_rate           NUMBER;                -- ADDED SEP-28-2007

-- delete xxha_3rdparty_owm_stg; -- delete haemo_car_3rd_party_data;
   --------------------------------------------------------------------------
   -- Main Cursor to get all the rcords from the staging table
   -----------------------------------------------------------
      CURSOR c1
      IS
         SELECT   d.item item, d.cusnbr cusnbr, d.quant quant,
                  d.record_number, d.record_type,
                  DECODE (d.uom, 'CS', 'Ca', d.uom) uom
             FROM xxha_3rdparty_owm_stg d
            WHERE p_dist = gc_owm_cust_name
              AND status IS NULL                                    -- rel 1.1
              AND record_type = '4'
         UNION ALL
         SELECT   d.item_no item, d.customer_number cusnbr,
                  TO_CHAR (d.quantity) quant, d.record_number, NULL,
                  DECODE (d.uom_code, 'CS', 'Ca', d.uom_code) uom
             FROM xxha_3rdparty_car_stg d        -- haemo_car_3rd_party_data d
            WHERE p_dist = gc_car_cust_name AND status IS NULL      -- rel 1.1
         ORDER BY record_number;

      r1                          c1%ROWTYPE;

--------------------------------------------------------------------------
-- This cursor will fetch the customer name and primary bill to site id for
-- the cardinal/Owens/Minor.Customr
---------------------------------------------------------------------------
      CURSOR c2
      IS
                                
    SELECT hp.party_name customer_name, hsu.site_use_id
           FROM hz_cust_accounts hca,
                hz_parties hp,
                hz_cust_acct_sites hcas,
                hz_cust_site_uses hsu,
                hz_party_sites hps,
                hz_locations hl
          WHERE hca.party_id = hp.party_id
            AND hp.status = 'A'
            AND hcas.status = 'A'
            AND hsu.status = 'A'
            AND hps.status = 'A'
            AND hca.status = 'A'
            AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
            AND hca.cust_account_id = hcas.cust_account_id
            AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
            AND site_use_code = 'BILL_TO'
            AND hps.party_site_id = hcas.party_site_id
            AND hl.location_id = hps.location_id
            AND hp.party_name =
                   DECODE (p_dist,
                           gc_owm_cust_name, gc_owm_cust_name,
                           gc_car_cust_name
                          );
                          

      r2                          c2%ROWTYPE;

--------------------------------------------------------------------------
-- This cursor will select the customer name and primary bill to city from
-- the end customer on the record.
--------------------------------------------------------------------------
      CURSOR c3
      IS
         SELECT hp.party_name customer_name, hl.city
           FROM hz_cust_accounts hca,
                hz_parties hp,
                hz_cust_acct_sites hcas,
                hz_cust_site_uses hsu,
                hz_party_sites hps,
                hz_locations hl
          WHERE hca.party_id = hp.party_id
            AND hp.status = 'A'
            AND hcas.status = 'A'
            AND hsu.status = 'A'
            AND hps.status = 'A'
            AND hca.status = 'A'
            AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
            AND hca.cust_account_id = hcas.cust_account_id
            AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
            --AND site_use_code = 'BILL_TO'
            AND hps.party_site_id = hcas.party_site_id
            AND hl.location_id = hps.location_id
            and hsu.attribute3 = r1.cusnbr;

      r3                          c3%ROWTYPE;

---------------------------------------------------------------------------
-- This cursor will find the cross referenced item for the item in the data
-- file.
---------------------------------------------------------------------------
      CURSOR c4
      IS
         SELECT i.segment1, i.inventory_item_id
           FROM mtl_system_items i, mtl_parameters p,
                mtl_cross_references_v c
          WHERE p.organization_id = i.organization_id
            AND c.inventory_item_id = i.inventory_item_id
            AND p.organization_code = 'MST'
            AND c.cross_reference_type =
                   DECODE (p_dist,
                           gc_owm_cust_name, gc_owm_xref,
                           gc_car_xref
                          )
            AND c.cross_reference = r1.item
         UNION ALL
         SELECT i.segment1, i.inventory_item_id
           FROM mtl_system_items i, mtl_parameters p
          WHERE p.organization_id = i.organization_id
            AND p.organization_code = 'MST'
            AND i.segment1 = r1.item
            AND NOT EXISTS (
                   SELECT NULL
                     FROM mtl_system_items i,
                          mtl_parameters p,
                          mtl_cross_references_v c
                    WHERE p.organization_id = i.organization_id
                      AND c.inventory_item_id = i.inventory_item_id
                      AND p.organization_code = 'MST'
                      AND c.cross_reference_type =
                             DECODE (p_dist,
                                     gc_owm_cust_name, gc_owm_xref,
                                     gc_car_xref
                                    )
                      AND c.cross_reference = r1.item);

      r4                          c4%ROWTYPE;

-- ---------------------------------------------------------------
-- This cursor gets the start and end date of the reporting period
-- --------------------------------------------------------------
      CURSOR c5
      IS
         SELECT start_date, end_date
           FROM gl_periods_v
          WHERE period_set_name = 'HAE_GLOBAL_CAL'
            AND period_name = p_report_date;

      r5                          c5%ROWTYPE;
      v_error_message             VARCHAR2 (150);
   BEGIN
      UPDATE xxha_3rdparty_owm_stg
         SET status = NULL
       WHERE status != 'VS';

      UPDATE xxha_3rdparty_car_stg                  --haemo_car_3rd_party_data
         SET status = NULL
       WHERE status != 'VS';

      IF p_partial_file = 'N'
      THEN                                                          -- rel 1.1
         IF p_dist <> gc_car_cust_name
         THEN
            gn_child_request2_id :=
               fnd_request.submit_request
                            (application      => 'HAEMO',
                             program          => 'XXHA_THRDPTY_LOADER',
                             description      => 'Owens/Minor Loader',
                             start_time       => TO_CHAR
                                                     (SYSDATE,
                                                      'DD-MON-YYYY HH24:MI:SS'
                                                     ),
                             sub_request      => FALSE
                            );
            COMMIT;

            LOOP
               BEGIN
                  SELECT fcr.logfile_name, fcr.status_code
                    INTO lc_logfile, lc_validation_status_code
                    FROM fnd_concurrent_requests fcr
                   WHERE fcr.request_id = gn_child_request2_id
--          AND    FCR.phase_code = 'C';
                     AND fcr.phase_code IN ('C', 'G');

                  EXIT WHEN lc_logfile IS NOT NULL;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     NULL;
               END;
            END LOOP;                                        --End of the Loop
         ELSE
            gn_child_request2_id :=
               fnd_request.submit_request
                            (application      => 'HAEMO',
                             program          => 'XXHA_CAR_LOAD',
                             description      => 'Cardinal Loader',
                             start_time       => TO_CHAR
                                                     (SYSDATE,
                                                      'DD-MON-YYYY HH24:MI:SS'
                                                     ),
                             sub_request      => FALSE
                            );
            COMMIT;

            LOOP
               BEGIN
                  SELECT fcr.logfile_name, fcr.status_code
                    INTO lc_logfile, lc_validation_status_code
                    FROM fnd_concurrent_requests fcr
                   WHERE fcr.request_id = gn_child_request2_id
                     AND fcr.phase_code = 'C';

                  EXIT WHEN lc_logfile IS NOT NULL;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     NULL;
               END;
            END LOOP;                                        --End of the Loop
         END IF;                            --IF p_dist<>gc_car_cust_name THEN
      END IF;                                -- partial_file parameter rel 1.1

      gc_status_flag := 'VS';
      gc_identifier := 'Distributor/Legacy_Invoice_Number';
                                                          --'Customer Number';
      gc_con_name := 'Cardinal File Validation';                       --'TM';

      OPEN c2;

      FETCH c2
       INTO r2;

      IF c2%NOTFOUND
      THEN
         gc_status_flag := 'VE';
         gc_error_code := 'SETUP-Err';

         IF p_dist = gc_owm_cust_name
         THEN
            gc_error_msg :=
               ' No data found for the Distributor Name: '
               || gc_owm_cust_name;
         ELSE
            gc_error_msg :=
               ' No data found for the Distributor Name: '
               || gc_car_cust_name;
         END IF;

         gc_comments := NULL;
         insert_error_prc;

         CLOSE c2;

         GOTO endproc;
      ELSE
         CLOSE c2;
      END IF;

      OPEN c1;

      LOOP
         FETCH c1
          INTO r1;

         gn_record_number := r1.record_number;
         gc_err_rec_identifier := r1.cusnbr;
         lc_rollback_flag := 'N';
         lc_val_flag := 'Y';
         EXIT WHEN c1%NOTFOUND;
         v_error_message := 'OK';
         gc_status_flag := 'VS';

         IF p_dist <> gc_car_cust_name
         THEN
            IF r1.record_type = '3'
            THEN
               lc_rollback_flag := 'N';

               -- fetch the customer name and city from the primary bill to address.
               OPEN c3;

               FETCH c3
                INTO r3;

               IF c3%NOTFOUND
               THEN
                  gc_status_flag := 'VE';
                  lc_rollback_flag := 'Y';
                  gc_error_code := 'TM01';
                  gc_error_msg :=
                        'No data found for the End customer: '
                     || r1.cusnbr
                     || ' for the Record number: '
                     || r1.record_number;
                  gc_comments := NULL;
                  insert_error_prc;

                  CLOSE c3;

                  GOTO endloop;
               ELSE
                  CLOSE c3;
               END IF;

-- get start date and end date of reporting period
               OPEN c5;

               FETCH c5
                INTO r5;

               IF c5%NOTFOUND
               THEN
                  gc_status_flag := 'VE';
                  lc_rollback_flag := 'Y';
                  gc_error_code := 'TM99';
                  gc_error_msg :=
                        'No start or end date found for reporting period - '
                     || p_report_date;
                  gc_comments := NULL;
                  insert_error_prc;

                  CLOSE c5;

                  GOTO endloop;
               ELSE
                  CLOSE c5;
               END IF;
            ELSE
               --Get the last char of the quantity
               SELECT SUBSTR (r1.quant, -1, 1)
                 INTO lc_sign
                 FROM DUAL;

               --Check if the Last Char falls in the below range and translate it to eith Positive/Negative Numbr
               IF lc_sign IN
                           ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', '{')
               THEN
                  SELECT REPLACE (SUBSTR (r1.quant, -2, 2),
                                  SUBSTR (r1.quant, -1, 1),
                                  DECODE (SUBSTR (r1.quant, -1, 1),
                                          'A', 1,
                                          'B', 2,
                                          'C', 3,
                                          'D', 4,
                                          'E', 5,
                                          'F', 6,
                                          'G', 7,
                                          'H', 8,
                                          'I', 9,
                                          '{', 0
                                         )
                                 )
                    INTO lc_qty
                    FROM DUAL;                                      --POSITIVE
               ELSE
                  SELECT    '-'
                         || REPLACE (SUBSTR (r1.quant, -2, 2),
                                     SUBSTR (r1.quant, -1, 1),
                                     DECODE (SUBSTR (r1.quant, -1, 1),
                                             'J', 1,
                                             'K', 2,
                                             'L', 3,
                                             'M', 4,
                                             'N', 5,
                                             'O', 6,
                                             'P', 7,
                                             'Q', 8,
                                             'R', 9,
                                             '}', 0
                                            )
                                    )
                    INTO lc_qty
                    FROM DUAL;                                      --NEGATIVE
               END IF;

               -- Validate Item  Owen and Minors
               OPEN c4;

               FETCH c4
                INTO r4;

               IF c4%NOTFOUND
               THEN
                  gc_status_flag := 'VE';
                  gc_error_code := 'TM02';
                  gc_error_msg :=
                        'Item cross reference not found for the Item: '
                     || r1.item
                     || ' for the Record number: '
                     || r1.record_number;
                  gc_comments := NULL;
                  insert_error_prc;

                  CLOSE c4;

                  GOTO endloop;
               ELSE
                  IF UPPER (r1.uom) != 'EA'
                  THEN                       -- convert uom logic 28-sep-2007
                     BEGIN
                        SELECT conversion_rate
                          INTO l_conversion_rate
                          FROM mtl_uom_conversions
                         WHERE UPPER (uom_code) = UPPER (r1.uom)
                           AND inventory_item_id = r4.inventory_item_id
                           AND NVL (disable_date, SYSDATE) >= SYSDATE;

                        lc_qty := lc_qty * l_conversion_rate;
                     EXCEPTION
                        WHEN NO_DATA_FOUND
                        THEN
                           gc_status_flag := 'VE';
                           gc_error_code := 'TM97';
                           gc_error_msg :=
                                 'No uom conversion record found for item - '
                              || r4.segment1;
                           insert_error_prc;
                        WHEN OTHERS
                        THEN
                           gc_status_flag := 'VE';
                           gc_error_code := 'TM96';
                           gc_error_msg := SUBSTR (SQLERRM, 1, 80);
                           insert_error_prc;
                     END;
                  ELSE
--              lc_qty := r1.quant;
                     NULL;
                  END IF;

                  CLOSE c4;
               END IF;
            END IF;   --r1.record_type='3'    -- owen and minors record type 3
         ELSE            --p_dist<>gc_car_cust_name THEN     -- it is cardinal
            lc_rollback_flag := 'N';

            OPEN c3;

            FETCH c3
             INTO r3;

            IF c3%NOTFOUND
            THEN
               gc_status_flag := 'VE';
               gc_error_code := 'TM01';
               gc_error_msg :=
                     'No data found for the End customer: '
                  || r1.cusnbr
                  || ' for the Record number: '
                  || r1.record_number;
               gc_comments := NULL;
               insert_error_prc;

               CLOSE c3;

               GOTO endloop;
            ELSE
               CLOSE c3;
            END IF;

            OPEN c5;

            FETCH c5
             INTO r5;

            IF c5%NOTFOUND
            THEN
               gc_status_flag := 'VE';
               lc_rollback_flag := 'Y';
               gc_error_code := 'TM98';
               gc_error_msg :=
                     'No start or end date found for reporting period - '
                  || p_report_date;
               gc_comments := NULL;
               insert_error_prc;

               CLOSE c5;

               GOTO endloop;
            ELSE
               CLOSE c5;
            END IF;

            -- Validate Item  for Cardinal
            OPEN c4;

            FETCH c4
             INTO r4;

            IF c4%NOTFOUND
            THEN
               gc_status_flag := 'VE';
               gc_error_code := 'TM02';
               gc_error_msg :=
                     'Item cross reference not found for the Item: '
                  || r1.item
                  || ' for the Record number: '
                  || r1.record_number;
               gc_comments := NULL;
               insert_error_prc;

               CLOSE c4;

               GOTO endloop;
            ELSE
               IF UPPER (r1.uom) != 'EA'
               THEN                          -- convert uom logic 28-sep-2007
                  BEGIN
                     SELECT conversion_rate
                       INTO l_conversion_rate
                       FROM mtl_uom_conversions
                      WHERE UPPER (uom_code) = UPPER (r1.uom)
                        AND inventory_item_id = r4.inventory_item_id
                        AND NVL (disable_date, SYSDATE) >= SYSDATE;

                     lc_qty := r1.quant * l_conversion_rate;
                  EXCEPTION
                     WHEN NO_DATA_FOUND
                     THEN
                        gc_status_flag := 'VE';
                        gc_error_code := 'TM97';
                        gc_error_msg :=
                              'No uom conversion record found for item - '
                           || r4.segment1;
                        insert_error_prc;
                     WHEN OTHERS
                     THEN
                        gc_status_flag := 'VE';
                        gc_error_code := 'TM96';
                        gc_error_msg := SUBSTR (SQLERRM, 1, 80);
                        insert_error_prc;
                  END;
               ELSE
                  lc_qty := r1.quant;
               END IF;

               l_purchase_price := 0;

               CLOSE c4;
            END IF;
         END IF;                               --p_dist<>gc_car_cust_name THEN

         <<endloop>>
-- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'ROLLBACK FLAG IS - '||lc_rollback_flag);
-- This is Cardinal's output file creation
         IF gc_status_flag = 'VS' AND lc_rollback_flag = 'N'
         THEN
            NULL;

            IF p_dist = gc_car_cust_name
            THEN
               UPDATE xxha_3rdparty_car_stg        --haemo_car_3rd_party_data
                  SET status = 'VS'
                WHERE record_number = r1.record_number;
            ELSE
               IF r1.record_type = '3'
               THEN
--      temp_char:='Chargeback' ||'~'||sysdate || '~' ||( sysdate + 30) || '~' ||r2.customer_name || '~' ||r2.site_use_id || '~' ||'US Dollar' ||'~'||'0'||'~'||r3.customer_name || '~' ||r3.city || '~' ||l_agree_type||'~'||l_pricelist||'~'||'0'||'~'||sysdate || '~';
                  temp_char :=
                        'Chargeback'
                     || '~'
                     || r5.start_date
                     || '~'
                     || r5.end_date
                     || '~'
                     || r2.customer_name
                     || '~'
                     || r2.site_use_id
                     || '~'
                     || 'US Dollar'
                     || '~'
                     || '0'
                     || '~'
                     || r3.customer_name
                     || '~'
                     || r3.city
                     || '~';
--  ||l_agree_type||'~'||l_pricelist||'~'||'0'||'~'||sysdate || '~';
                  NULL;
               ELSIF r1.record_type = '4'
               THEN
                  l_purchase_price := 0;

                  BEGIN
                     SELECT c.NAME
                       INTO l_pricelist
                       FROM oe_blanket_lines_v a,
                            oe_blanket_headers_v b,
                            qp_list_headers c
                      WHERE a.sold_to_org_id = b.sold_to_org_id
                        AND a.header_id = b.header_id
                        AND b.sold_to = r3.customer_name
                        AND a.ordered_item = r4.segment1
                        AND c.list_header_id = a.price_list_id
                        AND b.start_date_active =
                               (SELECT MAX (start_date_active)
                                  FROM oe_blanket_headers_v
                                 WHERE sold_to = r3.customer_name
                                   AND end_date_active IS NULL);

                     l_agree_type := 'Price List';
                  EXCEPTION
                     WHEN NO_DATA_FOUND
                     THEN
                        l_pricelist := NULL;
                        l_agree_type := NULL;
                     WHEN OTHERS
                     THEN
                        l_pricelist := NULL;
                        l_agree_type := NULL;
                  END;

               END IF;

               UPDATE xxha_3rdparty_owm_stg
                  SET status = 'VS'
                WHERE record_number = r1.record_number;
            END IF;                         --IF p_dist =gc_car_cust_name THEN
         ELSE             --FND_FILE.PUT_LINE(FND_FILE.LOG,'ERR IN PACKAGE ');
            IF p_dist <> gc_car_cust_name
            THEN
               UPDATE xxha_3rdparty_owm_stg
                  SET status = 'VE'
                WHERE record_number = r1.record_number;
            ELSE
               UPDATE xxha_3rdparty_car_stg        --haemo_car_3rd_party_data
                  SET status = 'VE'
                WHERE record_number = r1.record_number;
            END IF;
         END IF;    --IF gc_status_flag ='VS' AND lc_rollback_flag='N'    THEN
      END LOOP;                                                     --OPEN c1;

      CLOSE c1;

--END LOOP; --MAIN  FOR I IN 1..2 LOOP
      <<endproc>>
-- IF (gc_status_flag  <>'VS') THEN
      BEGIN
         SELECT COUNT (*)
           INTO l_error_count
           FROM xxha_common_errors
          WHERE request_id = gn_request_id;
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;

      IF l_error_count > 1
      THEN
--     xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
         fnd_file.put_line (fnd_file.LOG, 'Errorssss');
      END IF;

-- END IF;
      COMMIT;
   END get_3rdparty_owm;

   PROCEDURE populate_tm_3rdparty_stg_tbl (record_number NUMBER)
   IS
      l_tm_so_counter   NUMBER;
   BEGIN
      l_tm_so_counter := xx_tm_3rdparty_stg_tbl.COUNT;
      xx_tm_3rdparty_stg_tbl (l_tm_so_counter + 1).record_number :=
                                                                record_number;
   END populate_tm_3rdparty_stg_tbl;

   PROCEDURE populate_common_error (
      error_msg           VARCHAR2,
      ERROR_CODE          VARCHAR2,
      error_comments      VARCHAR2,
      record_number       NUMBER,
      record_identifier   VARCHAR2
   )
   IS
      l_error_counter   NUMBER;
   BEGIN
      IF ERROR_CODE = 'DEFAULT_PRICE_LIST'
      THEN
         gc_warning_logged := 'Y';
         g_record_error_occured := TRUE;
      ELSE
         gc_error_logged := 'Y';
         g_record_error_occured := TRUE;
      END IF;

      DBMS_OUTPUT.put_line (' popu err large ' || SUBSTR (error_msg, 1, 2000));
      l_error_counter := xx_common_error_tbl.COUNT;
      xx_common_error_tbl (l_error_counter + 1).error_msg :=
                                                   SUBSTR (error_msg, 1, 2000);
      xx_common_error_tbl (l_error_counter + 1).request_id := gn_request_id;
      xx_common_error_tbl (l_error_counter + 1).record_number := record_number;
      xx_common_error_tbl (l_error_counter + 1).ERROR_CODE :=
                                                    SUBSTR (ERROR_CODE, 1, 20);
      xx_common_error_tbl (l_error_counter + 1).record_identifier :=
                                                             record_identifier;
      xx_common_error_tbl (l_error_counter + 1).comments :=
                                              SUBSTR (error_comments, 1, 2000);
      xx_common_error_tbl (l_error_counter + 1).attribute4 := gc_attribute4;
      populate_tm_3rdparty_stg_tbl (record_number);
   END populate_common_error;

   PROCEDURE populate_tm_3rd_success_tbl (record_number NUMBER)
   IS
      l_tm_so_succ_counter   NUMBER;
   BEGIN
      l_tm_so_succ_counter := xx_tm_3rd_success_stg_tbl.COUNT;
      xx_tm_3rd_success_stg_tbl (l_tm_so_succ_counter + 1).record_number :=
                                                                record_number;
   END populate_tm_3rd_success_tbl;

   PROCEDURE log_error
   IS
   BEGIN
      IF gc_error_code = 'DEFAULT_PRICE_LIST'
      THEN
         gc_warning_logged := 'Y';
      ELSE
         gc_error_logged := 'Y';
      END IF;

      xxha_common_utilities_pkg.insert_error_prc (gn_request_id,
                                                  gn_record_number,
                                                  gc_record_identifier,
                                                  gc_error_code,
                                                  gc_error_msg,
                                                  gc_comments,
                                                  gc_table_name,
                                                  gc_attribute1,
                                                  gc_attribute2,
                                                  gc_attribute3,
                                                  gc_attribute4,
                                                  gc_attribute5,
                                                  gc_status
                                                 );
      DBMS_OUTPUT.put_line (   'error '
                            || gc_error_code
                            || gc_error_msg
                            || gc_comments
                           );
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'log error',
                                'When Others Log Error',
                                gn_record_number,
                                gc_record_identifier
                               );
         fnd_file.put_line
                 (fnd_file.LOG,
                     'Error in XXHA_TM_ORDER_PKG.INSERT_ERROR_PRC. Error is: '
                  || SQLERRM
                 );
   END log_error;

   PROCEDURE log_all_errors
   IS
      l_error_occured   BOOLEAN := FALSE;
      a                 NUMBER;
      b                 NUMBER;
   BEGIN
--a := XX_COMMON_ERROR_TBL.COUNT;-
--b:= XX_TM_SO_STG_TBL.COUNT;
      DBMS_OUTPUT.put_line ('All Error ' || xx_common_error_tbl.COUNT);

      FOR i IN 1 .. xx_common_error_tbl.COUNT
      LOOP
--  if XX_COMMON_ERROR_TBL(i).error_code != 'DEFAULT_PRICE_LIST' then
         l_error_occured := TRUE;
         gn_request_id := xx_common_error_tbl (i).request_id;
         gn_record_number := xx_common_error_tbl (i).record_number;
         gc_record_identifier := xx_common_error_tbl (i).record_identifier;
         gc_error_code := xx_common_error_tbl (i).ERROR_CODE;
         gc_error_msg := xx_common_error_tbl (i).error_msg;
         gc_comments := xx_common_error_tbl (i).comments;
         gc_table_name := xx_common_error_tbl (i).table_name;
         gc_attribute1 := xx_common_error_tbl (i).attribute1;
         gc_attribute2 := xx_common_error_tbl (i).attribute2;
         gc_attribute3 := xx_common_error_tbl (i).attribute3;
         gc_attribute4 := xx_common_error_tbl (i).attribute4;
         gc_attribute5 := xx_common_error_tbl (i).attribute5;
         log_error;
--  end if;
      END LOOP;

      IF NOT l_error_occured
      THEN
         xxha_common_utilities_pkg.insert_error_prc (gn_request_id,
                                                     gn_record_number,
                                                     gc_record_identifier,
                                                     gc_error_code,
                                                     gc_error_msg,
                                                     'No Error Occured',
                                                     'XXHA_TM_3rdparty_STG',
                                                     gc_attribute1,
                                                     gc_attribute2,
                                                     gc_attribute3,
                                                     gc_attribute4,
                                                     gc_attribute5,
                                                     gc_status
                                                    );
         gc_error_logged := 'N';
         DBMS_OUTPUT.put_line ('No err ');
      ELSE
         FOR i IN 1 .. xx_tm_3rdparty_stg_tbl.COUNT
         LOOP
            IF xx_tm_3rdparty_stg_tbl (i).record_number IS NOT NULL
            THEN
               DBMS_OUTPUT.put_line (   'VE------A '
                                     || xx_tm_3rdparty_stg_tbl (i).record_number
                                    );

               UPDATE xxha_3rdparty_car_stg
                  SET status = 'VE'
                WHERE record_number = xx_tm_3rdparty_stg_tbl (i).record_number
                  AND status <> 'VE';
            END IF;
         END LOOP;
      END IF;
   END log_all_errors;

   PROCEDURE chk_customer_exists (
      legacy_customer_number         VARCHAR2,
      legacy_customer_name           VARCHAR2,
      l_legacy_address               VARCHAR2,
      customer_name            OUT   VARCHAR2,
      customer_account_id      OUT   NUMBER,
      party_site_number        OUT   VARCHAR2,
      l_ship_to_location       OUT   VARCHAR2,
      l_customer_number        OUT   VARCHAR2,
      x_customer_exists        OUT   BOOLEAN
   )
   IS
      l_no_of_rows    NUMBER;
      l_site_number   VARCHAR2 (2000);

      CURSOR c_get_customer (q_legacy_customer_number VARCHAR2)
      IS        
         SELECT hp.party_name customer_name,
                hca.cust_account_id customer_id, party_site_number site_number, LOCATION,
                account_number customer_number
           FROM hz_cust_accounts hca,
                hz_parties hp,
                hz_cust_acct_sites hcas,
                hz_cust_site_uses hsu,
                hz_party_sites hps,
                hz_locations hl
          WHERE hca.party_id = hp.party_id
            AND hp.status = 'A'
            AND hcas.status = 'A'
            AND hsu.status = 'A'
            AND hps.status = 'A'
            AND hca.status = 'A'
            AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
            AND hca.cust_account_id = hcas.cust_account_id
            AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
            AND site_use_code = 'SHIP_TO'
            AND hps.party_site_id = hcas.party_site_id
            AND hl.location_id = hps.location_id
            AND hsu.attribute3 = q_legacy_customer_number;
                  
      
   BEGIN
      l_no_of_rows := 0;
      l_site_number := '';

      FOR v_get_customer IN c_get_customer (legacy_customer_number)
      LOOP
         l_no_of_rows := l_no_of_rows + 1;
         customer_name := v_get_customer.customer_name;
         customer_account_id := v_get_customer.customer_id;
         party_site_number := v_get_customer.site_number;
         l_ship_to_location := v_get_customer.LOCATION;
         l_customer_number := v_get_customer.customer_number;
         l_site_number := l_site_number || v_get_customer.site_number || ',';
         x_customer_exists := TRUE;
      END LOOP;

      IF l_no_of_rows > 1
      THEN
         x_customer_exists := FALSE;
         l_site_number :=
                         SUBSTR (l_site_number, 1, LENGTH (l_site_number) - 1);
         RAISE TOO_MANY_ROWS;
      END IF;

      IF l_no_of_rows = 0
      THEN
         RAISE NO_DATA_FOUND;
      END IF;

   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         populate_common_error (   legacy_customer_number
                                || ' '
                                || legacy_customer_name
                                || ' '
                                || l_legacy_address
                                || ' Does Not Exist',
                                'CUST_DO_NOT_EXIST',
                                'Check Customer',
                                gn_record_number,
                                gc_record_identifier
                               );
         x_customer_exists := FALSE;
      WHEN TOO_MANY_ROWS
      THEN
         populate_common_error
                    (   l_site_number
                     || ' Site_numbers exist for legacy_customer_number:-  '
                     || legacy_customer_number
                     || ' '
                     || l_legacy_address,
                     'Multiple Customers Exist',
                     'Multiple Customers Exists',
                     gn_record_number,
                     gc_record_identifier
                    );
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'log error',
                                'When Others chk cust',
                                gn_record_number,
                                gc_record_identifier
                               );
   END;

   PROCEDURE chk_item_exists (
      p_distributor                         VARCHAR2,
      p_legacy_item_number         IN OUT   VARCHAR2,
      p_customer_id                         NUMBER,
      x_oracle_item_number         OUT      VARCHAR2,
      x_oracle_inventory_item_id   OUT      NUMBER,
      x_item_exists                OUT      BOOLEAN
   )
   IS
      l_legacy_item_number   VARCHAR2 (2000);
   BEGIN
      IF p_distributor = 'OWM'
      THEN
         l_legacy_item_number :=
               SUBSTR (p_legacy_item_number,
                       1,
                       LENGTH (p_legacy_item_number) - 2
                      )
            || '-'
            || SUBSTR (p_legacy_item_number, -2, 2);
      ELSE
         l_legacy_item_number := p_legacy_item_number;
      END IF;

      BEGIN
         x_item_exists := FALSE;

         SELECT segment1, inventory_item_id
           INTO x_oracle_item_number, x_oracle_inventory_item_id
           FROM mtl_system_items_b
          WHERE segment1 = l_legacy_item_number AND organization_id = 103;

         x_item_exists := TRUE;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            x_item_exists := FALSE;
      END;

      BEGIN
         IF NOT x_item_exists
         THEN
            SELECT i.inventory_item_id, i.segment1
              INTO x_oracle_inventory_item_id, x_oracle_item_number
              FROM mtl_system_items i,
                   mtl_parameters p,
                   mtl_cross_references_v c
             WHERE p.organization_id = i.organization_id
               AND c.inventory_item_id = i.inventory_item_id
               AND p.organization_code = 'MST'
               AND c.cross_reference_type =
                      DECODE (p_distributor,
                              gc_owm_cust_name, gc_owm_xref,
                              gc_car_xref
                             )
               AND c.cross_reference = l_legacy_item_number;

            x_item_exists := TRUE;
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            populate_common_error (p_legacy_item_number || ' Does Not Exist',
                                   'ITEM_DO_NOT_EXIST',
                                   'Check Item',
                                   gn_record_number,
                                   gc_record_identifier
                                  );
            x_item_exists := FALSE;
         WHEN OTHERS
         THEN
            populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                   'log error',
                                   'When Others chk item',
                                   gn_record_number,
                                   gc_record_identifier
                                  );
      END;
   END;

  --bsa exists here

   PROCEDURE get_selling_price (
      p_price_list_name            VARCHAR2,
      p_item_number                VARCHAR2,
      p_legacy_item_number         VARCHAR2,
      p_price_list_id              NUMBER,
      p_inventory_item_id          NUMBER,
      p_transaction_date           DATE,
      x_selling_price        OUT   VARCHAR2
   )
   IS
   BEGIN
      SELECT operand
        INTO x_selling_price
        FROM qp_list_lines_v
       WHERE list_header_id = p_price_list_id
         AND product_attr_value = p_inventory_item_id
         AND product_attribute_context = 'ITEM'
         AND list_line_type_code = 'PLL'
         AND p_transaction_date BETWEEN NVL (start_date_active,
                                             p_transaction_date
                                            )
                                    AND NVL (end_date_active,
                                             p_transaction_date
                                            );
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
          fnd_file.put_line
            (fnd_file.LOG, p_price_list_id||':'||p_inventory_item_id||':'||p_transaction_date);
            
         populate_common_error
            (   'Price Does Not Exist For Price List Name / Oracle Item/ Legacy Item '
             || p_price_list_name
             || '/'
             || p_item_number
             || '/'
             || p_legacy_item_number,
             'SELLING_PRICE_DO_NOT_EXIST',
             'Check SELLING PRICE',
             gn_record_number,
             gc_record_identifier
            );
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'log error',
                                'When Others chk price',
                                gn_record_number,
                                gc_record_identifier
                               );
   END;

   PROCEDURE update_partner_information (distributor VARCHAR2)
   IS
   BEGIN
      IF distributor = 'CAR'
      THEN
         UPDATE xxha_3rdparty_car_stg
            SET partner_party_name = g_cardinal_party_name,
                partner_account_id = g_cardinal_customer_id,
                partner_site_id = g_cardinal_party_site_id
          WHERE NVL (status, 'NEW') <> 'PS';
      ELSE
         UPDATE xxha_3rdparty_owm_stg
            SET partner_party_name = g_owm_party_name,
                partner_account_id = g_owm_customer_id,
                partner_site_id = g_owm_party_site_id
          WHERE NVL (status, 'NEW') <> 'PS' AND record_type = '4';
      END IF;
   END;

   PROCEDURE update_negative_quantity
   IS
      CURSOR c_negative_quantity
      IS
         SELECT *
           FROM xxha_3rdparty_car_stg
          WHERE 1 = 1
                     --substr(quantity_sign,-1,1) = '-'
                AND NVL (status, 'NEW') <> 'PS';
   BEGIN
      FOR v_negative_quantity IN c_negative_quantity
      LOOP
         IF SUBSTR (v_negative_quantity.quantity_sign, -1, 1) = '-'
         THEN
            UPDATE xxha_3rdparty_car_stg
               SET legacy_quantity = '-' || v_negative_quantity.quantity
             WHERE record_number = v_negative_quantity.record_number;
         ELSE
            UPDATE xxha_3rdparty_car_stg
               SET legacy_quantity = v_negative_quantity.quantity
             WHERE record_number = v_negative_quantity.record_number;
         END IF;
      END LOOP;
   END;

   PROCEDURE get_order_number (
      p_trx_date                 DATE,
      p_record_number   IN OUT   VARCHAR2,
      x_order_number    OUT      VARCHAR2
   )
   IS
   BEGIN
      IF LENGTH (p_record_number) = 3
      THEN
         p_record_number := '0' || p_record_number;
      ELSIF LENGTH (p_record_number) = 2
      THEN
         p_record_number := '00' || p_record_number;
      ELSIF LENGTH (p_record_number) = 1
      THEN
         p_record_number := '000' || p_record_number;
      ELSE
         p_record_number := p_record_number;
      END IF;

      x_order_number :=
            TO_CHAR (p_trx_date, 'YYYY')
         || TO_CHAR (p_trx_date, 'MM')
         || p_record_number;
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'When Others',
                                'When Others Order Number',
                                gn_record_number,
                                gc_record_identifier
                               );
   END;

   PROCEDURE get_oracle_quantity (
      p_inventory_item_id            NUMBER,
      p_legacy_uom          IN OUT   VARCHAR2,
      p_legacy_quantity              NUMBER,
      x_oracle_quantity     OUT      VARCHAR2,
      x_oracle_uom          OUT      VARCHAR2
   )
   IS
      l_conversion_rate   VARCHAR2 (2000);
      l_oracle_quantity   VARCHAR2 (2000);
   BEGIN
      gc_record_identifier := 'A0 ' || gc_record_identifier;

      IF UPPER (p_legacy_uom) = 'CS'
      THEN
         p_legacy_uom := 'CA';
      END IF;

      IF UPPER (p_legacy_uom) <> 'EA'
      THEN
         gc_record_identifier := 'A1 ' || gc_record_identifier;

         SELECT TO_CHAR (conversion_rate)
           INTO l_conversion_rate
           FROM mtl_uom_conversions
          WHERE UPPER (uom_code) = UPPER (p_legacy_uom)
            AND inventory_item_id = p_inventory_item_id
            AND NVL (disable_date, SYSDATE) >= SYSDATE;

         x_oracle_quantity :=
            TO_CHAR (  TO_NUMBER (p_legacy_quantity)
                     * TO_NUMBER (l_conversion_rate)
                    );
         gc_record_identifier := 'A2 ' || gc_record_identifier;
         x_oracle_uom := 'EA';
      ELSE
         x_oracle_quantity := p_legacy_quantity;
         x_oracle_uom := 'EA';
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         populate_common_error
                        (   'Conversion Rate Doesn Not exist for Item / UOM'
                         || p_inventory_item_id
                         || '/'
                         || p_legacy_uom,
                         'UOM_CONVERSION_DO_NOT_EXIST',
                         'Check UOM Conversion',
                         gn_record_number,
                         gc_record_identifier
                        );
   END;

   PROCEDURE validate_cardinal_data
   IS
      CURSOR c_cardinal
      IS
         SELECT *
           FROM xxha_3rdparty_car_stg
          WHERE NVL (status, 'NEW') <> 'PS';

      l_customer_name                VARCHAR2 (2000);
      l_customer_id                  NUMBER;
      l_party_site_number            VARCHAR2 (2000);
      l_ship_to_location             VARCHAR2 (2000);
      l_x_customer_exists            BOOLEAN;
      l_x_oracle_item_number         VARCHAR2 (2000);
      l_x_oracle_inventory_item_id   NUMBER;
      l_x_item_exists                BOOLEAN;
      l_x_price_list_name            VARCHAR2 (2000);
      l_x_line_bsa_no                VARCHAR2 (2000);
      l_x_bsa_exists                 BOOLEAN;
      l_x_oracle_uom                 VARCHAR2 (2000);
      l_x_oracle_quantity            VARCHAR2 (2000);
      l_status                       VARCHAR2 (2000);
      l_customer_number              VARCHAR2 (2000);
      l_x_price_list_id              NUMBER;
      x_selling_price                VARCHAR2 (2000);
      l_x_order_number               VARCHAR2 (2000);
   BEGIN
      update_negative_quantity;
      update_partner_information ('CAR');

      FOR v_cardinal IN c_cardinal
      LOOP
         gn_record_number := v_cardinal.record_number;
         gc_record_identifier :=
            v_cardinal.distributor || '/' || v_cardinal.legacy_invoice_number;
         g_record_error_occured := FALSE;
         chk_customer_exists (v_cardinal.customer_number,
                              v_cardinal.customer_name,
                                 v_cardinal.address
                              || ','
                              || v_cardinal.city
                              || ','
                              || v_cardinal.state,
                              l_customer_name,
                              l_customer_id,
                              l_party_site_number,
                              l_ship_to_location,
                              l_customer_number,
                              l_x_customer_exists
                             );
         chk_item_exists ('Cardinal Health Medical Services',
                          v_cardinal.item_no,
                          v_cardinal.partner_account_id,
                          l_x_oracle_item_number,
                          l_x_oracle_inventory_item_id,
                          l_x_item_exists
                         );
         chk_bsa_exists (l_customer_id,
                         l_customer_number,
                         l_x_oracle_item_number,
                         TO_DATE (v_cardinal.trans_date),
                         l_x_price_list_id,
                         l_x_price_list_name,
                         l_x_line_bsa_no,
                         l_x_bsa_exists
                        );
         get_selling_price (l_x_price_list_name,
                            l_x_oracle_item_number,
                            v_cardinal.item_no,
                            l_x_price_list_id,
                            l_x_oracle_inventory_item_id,
                            TO_DATE (v_cardinal.trans_date),
                            x_selling_price
                           );
         get_oracle_quantity (l_x_oracle_inventory_item_id,
                              v_cardinal.uom_code,
                              v_cardinal.legacy_quantity,
                              l_x_oracle_quantity,
                              l_x_oracle_uom
                             );
         get_order_number
                (v_cardinal.period_start_date --to_date(v_cardinal.trans_date)
                                             ,
                 v_cardinal.record_number,
                 l_x_order_number
                );
         gc_record_identifier := 'B ' || gc_record_identifier;

         IF g_record_error_occured
         THEN
            l_status := 'VE';
         ELSE
            l_status := 'VS';
         END IF;

         UPDATE xxha_3rdparty_car_stg
            SET bill_to_account = l_customer_id,
                ship_to_location = l_ship_to_location,
                end_customer = l_customer_name,
                ship_to_site_number = l_party_site_number,
                oracle_item_number = l_x_oracle_item_number,
                line_bsa_no = l_x_line_bsa_no,
                aggrement_name = l_x_price_list_name,
                selling_price = x_selling_price,
                oracle_quantity = l_x_oracle_quantity,
                oracle_uom = l_x_oracle_uom,
                ship_to_attr3 = v_cardinal.customer_number
                                                          --,order_number = l_x_order_number
         ,
                status = l_status
          WHERE record_number = v_cardinal.record_number;

         gc_record_identifier := 'C ' || gc_record_identifier;

      END LOOP;
--exception
   END validate_cardinal_data;

   PROCEDURE validate_owm_data
   IS
      CURSOR c_owm
      IS
         SELECT *
           FROM xxha_3rdparty_owm_stg
          WHERE NVL (status, 'NEW') <> 'PS' AND record_type = '4';

      l_customer_name                VARCHAR2 (2000);
      l_customer_id                  NUMBER;
      l_party_site_number            VARCHAR2 (2000);
      l_ship_to_location             VARCHAR2 (2000);
      l_x_customer_exists            BOOLEAN;
      l_x_oracle_item_number         VARCHAR2 (2000);
      l_x_oracle_inventory_item_id   NUMBER;
      l_x_item_exists                BOOLEAN;
      l_x_price_list_name            VARCHAR2 (2000);
      l_x_line_bsa_no                VARCHAR2 (2000);
      l_x_bsa_exists                 BOOLEAN;
      l_x_oracle_uom                 VARCHAR2 (2000);
      l_x_oracle_quantity            VARCHAR2 (2000);
      l_status                       VARCHAR2 (2000);
      l_invoice_date                 VARCHAR2 (2000);
      l_customer_number              VARCHAR2 (2000);
      l_x_price_list_id              NUMBER;
      x_selling_price                VARCHAR2 (2000);
      l_x_order_number               VARCHAR2 (2000);
   BEGIN
      --update_negative_quantity;
      update_partner_information ('OWM');

      FOR v_owm IN c_owm
      LOOP
         DBMS_OUTPUT.put_line ('start1');
         gn_record_number := v_owm.record_number;
         gc_record_identifier :=
                      v_owm.distributor || '/' || v_owm.legacy_invoice_number;
         g_record_error_occured := FALSE;
         DBMS_OUTPUT.put_line ('start2');
         chk_customer_exists (v_owm.cusnbr,
                              v_owm.cusnme,
                                 v_owm.adr1
                              || ','
                              || v_owm.adr2
                              || ','
                              || v_owm.adr3
                              || ','
                              || v_owm.city
                              || ','
                              || v_owm.state
                              || ','
                              || v_owm.zipcde,
                              l_customer_name,
                              l_customer_id,
                              l_party_site_number,
                              l_ship_to_location,
                              l_customer_number,
                              l_x_customer_exists
                             );
         chk_item_exists ('Owens' || ' and ' || 'Minor',
                          v_owm.item,
                          v_owm.partner_account_id,
                          l_x_oracle_item_number,
                          l_x_oracle_inventory_item_id,
                          l_x_item_exists
                         );
         DBMS_OUTPUT.put_line ('start3');
         l_invoice_date := v_owm.dte;

         IF LENGTH (l_invoice_date) = 5
         THEN
            l_invoice_date := '0' || l_invoice_date;
         END IF;

         chk_bsa_exists (l_customer_id,
                         l_customer_number,
                         l_x_oracle_item_number,
                         TO_DATE (l_invoice_date, 'MMDDYY'),
                         l_x_price_list_id,
                         l_x_price_list_name,
                         l_x_line_bsa_no,
                         l_x_bsa_exists
                        );
         get_selling_price (l_x_price_list_name,
                            l_x_oracle_item_number,
                            v_owm.item,
                            l_x_price_list_id,
                            l_x_oracle_inventory_item_id,
                            TO_DATE (l_invoice_date, 'MMDDYY'),
                            x_selling_price
                           );
         get_oracle_quantity (l_x_oracle_inventory_item_id,
                              v_owm.uom,
                              v_owm.legacy_quantity,
                              l_x_oracle_quantity,
                              l_x_oracle_uom
                             );
         DBMS_OUTPUT.put_line ('start5');
         get_order_number
                   (v_owm.period_start_date --to_date(l_invoice_date,'MMDDYY')
                                           ,
                    v_owm.record_number,
                    l_x_order_number
                   );

         IF g_record_error_occured
         THEN
            l_status := 'VE';
         ELSE
            l_status := 'VS';
         END IF;

         UPDATE xxha_3rdparty_owm_stg
            SET bill_to_account = l_customer_id,
                ship_to_location = l_ship_to_location,
                end_customer = l_customer_name,
                ship_to_site_number = l_party_site_number,
                oracle_item_number = l_x_oracle_item_number,
                line_bsa_no = l_x_line_bsa_no,
                aggrement_name = l_x_price_list_name,
                selling_price = x_selling_price,
                oracle_quantity = l_x_oracle_quantity,
                oracle_uom = l_x_oracle_uom,
                ship_to_attr3 = v_owm.cusnbr,
                order_number = l_x_order_number,
                status = l_status
          WHERE record_number = v_owm.record_number AND record_type = '4';

         DBMS_OUTPUT.put_line ('start6');

      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'When Others',
                                'When Others Validate OWM',
                                gn_record_number,
                                gc_record_identifier
                               );
--exception
   END validate_owm_data;

   PROCEDURE create_flat_records_owm
   IS
      CURSOR c_owm
      IS
         SELECT   *
             FROM xxha_3rdparty_owm_stg
         ORDER BY record_number ASC;

      l_customer_number   VARCHAR2 (2000);
      l_customer_name     VARCHAR2 (2000);
      l_address1          VARCHAR2 (2000);
      l_address2          VARCHAR2 (2000);
      l_address3          VARCHAR2 (2000);
      l_city              VARCHAR2 (2000);
      l_state             VARCHAR2 (2000);
      l_zip_code          VARCHAR2 (2000);
      lc_sign             VARCHAR2 (2000);
      lc_qty              VARCHAR2 (2000);
      lc_purchase_price   VARCHAR2 (2000);
   BEGIN
      FOR v_owm IN c_owm
      LOOP
         IF v_owm.record_type = '3'
         THEN
            l_customer_number := v_owm.cusnbr;
            l_customer_name := v_owm.cusnme;
            l_address1 := v_owm.adr1;
            l_address2 := v_owm.adr2;
            l_address3 := v_owm.adr3;
            l_city := v_owm.city;
            l_state := v_owm.state;
            l_zip_code := v_owm.zipcde;
         END IF;

         IF v_owm.record_type = '4'
         THEN
            SELECT SUBSTR (v_owm.quant, -1, 1)
              INTO lc_sign
              FROM DUAL;

            --Check if the Last Char falls in the below range and translate it to eith Positive/Negative Numbr
            IF lc_sign IN ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', '{')
            THEN
               --  SELECT  to_number(REPLACE(SUBSTR(v_owm.quant,-2,2),SUBSTR(v_owm.quant,-1,1),DECODE(SUBSTR(v_owm.quant,-1,1),'A',1,'B',2,'C',3,'D',4,'E',5,'F',6,'G',7,'H',8,'I',9,'{',0)))
               SELECT TO_NUMBER (   SUBSTR (v_owm.quant,
                                            1,
                                            LENGTH (v_owm.quant) - 2
                                           )
                                 || REPLACE (SUBSTR (v_owm.quant, -2, 2),
                                             SUBSTR (v_owm.quant, -1, 1),
                                             DECODE (SUBSTR (v_owm.quant,
                                                             -1,
                                                             1
                                                            ),
                                                     'A', 1,
                                                     'B', 2,
                                                     'C', 3,
                                                     'D', 4,
                                                     'E', 5,
                                                     'F', 6,
                                                     'G', 7,
                                                     'H', 8,
                                                     'I', 9,
                                                     '{', 0
                                                    )
                                            )
                                )
                 INTO lc_qty
                 FROM DUAL;                                         --POSITIVE
            ELSE
               --SELECT  '-'||to_number(REPLACE(substr(v_owm.quant,-2,2),SUBSTR(v_owm.quant,-1,1),decode(SUBSTR(v_owm.quant,-1,1),'J',1,'K',2,'L',3,'M',4,'N',5,'O',6,'P',7,'Q',8,'R',9,'}',0)))
               SELECT    '-'
                      || TO_NUMBER (   SUBSTR (v_owm.quant,
                                               1,
                                               LENGTH (v_owm.quant) - 2
                                              )
                                    || REPLACE (SUBSTR (v_owm.quant, -2, 2),
                                                SUBSTR (v_owm.quant, -1, 1),
                                                DECODE (SUBSTR (v_owm.quant,
                                                                -1,
                                                                1
                                                               ),
                                                        'J', 1,
                                                        'K', 2,
                                                        'L', 3,
                                                        'M', 4,
                                                        'N', 5,
                                                        'O', 6,
                                                        'P', 7,
                                                        'Q', 8,
                                                        'R', 9,
                                                        '}', 0
                                                       )
                                               )
                                   )
                 INTO lc_qty
                 FROM DUAL;                                         --NEGATIVE
            END IF;

            SELECT SUBSTR (v_owm.purchase_price, -1, 1)
              INTO lc_sign
              FROM DUAL;

            --Check if the Last Char falls in the below range and translate it to eith Positive/Negative Numbr
            IF lc_sign IN ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', '{')
            THEN
               SELECT   TO_NUMBER
                             (   SUBSTR (v_owm.purchase_price,
                                         1,
                                         LENGTH (v_owm.purchase_price) - 2
                                        )
                              || (REPLACE
                                       (SUBSTR (v_owm.purchase_price, -2, 2),
                                        SUBSTR (v_owm.purchase_price, -1, 1),
                                        DECODE (SUBSTR (v_owm.purchase_price,
                                                        -1,
                                                        1
                                                       ),
                                                'A', 1,
                                                'B', 2,
                                                'C', 3,
                                                'D', 4,
                                                'E', 5,
                                                'F', 6,
                                                'G', 7,
                                                'H', 8,
                                                'I', 9,
                                                '{', 0
                                               )
                                       )
                                 )
                             )
                      / 1000
                 INTO lc_purchase_price
                 FROM DUAL;                                         --POSITIVE
            ELSE
               SELECT    '-'
                      ||   TO_NUMBER
                              (   SUBSTR (v_owm.purchase_price,
                                          1,
                                          LENGTH (v_owm.purchase_price) - 2
                                         )
                               || REPLACE
                                       (SUBSTR (v_owm.purchase_price, -2, 2),
                                        SUBSTR (v_owm.purchase_price, -1, 1),
                                        DECODE (SUBSTR (v_owm.purchase_price,
                                                        -1,
                                                        1
                                                       ),
                                                'J', 1,
                                                'K', 2,
                                                'L', 3,
                                                'M', 4,
                                                'N', 5,
                                                'O', 6,
                                                'P', 7,
                                                'Q', 8,
                                                'R', 9,
                                                '}', 0
                                               )
                                       )
                              )
                         / 1000
                 INTO lc_purchase_price
                 FROM DUAL;                                         --NEGATIVE
            END IF;

            --lc_purchase_price := substr(lc_purchase_price,1,length(lc_purchase_price)-3)||'.'||substr(lc_purchase_price,-3,3);
            UPDATE xxha_3rdparty_owm_stg
               SET cusnbr = l_customer_number,
                   cusnme = l_customer_name,
                   adr1 = l_address1,
                   adr2 = l_address2,
                   adr3 = l_address3,
                   city = l_city,
                   state = l_state,
                   zipcde = l_zip_code,
                   quantity_readable = lc_qty,
                   legacy_quantity = lc_qty,
                   purchase_price_parse = lc_purchase_price
             WHERE record_number = v_owm.record_number;
         END IF;
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'When Others',
                                'When Others Update OWM File',
                                gn_record_number,
                                gc_record_identifier
                               );
         ROLLBACK;
         log_all_errors;
         COMMIT;
   END create_flat_records_owm;

   PROCEDURE process_owm_trace_file (
      x_err_buf            OUT      VARCHAR2,
      x_ret_code           OUT      VARCHAR2,
      p_report_date                 VARCHAR2,
      p_month_start_date            VARCHAR2,
      pp_dist              IN       VARCHAR2,
      pp_partial_file      IN       VARCHAR2
   )
   IS
      conc_request          BOOLEAN;

      CURSOR c_report_date (q_report_date VARCHAR2)
      IS
         SELECT period_year,
                DECODE (LENGTH (period_num),
                        1, '0' || (period_num),
                        period_num
                       ) period_num
           FROM gl_periods_v
          WHERE period_set_name = 'HAE_GLOBAL_CAL'
            AND period_name = q_report_date;

      CURSOR c_get_owm_data
      IS
         SELECT *
           FROM xxha_3rdparty_owm_stg
          WHERE                                           --status = 'VS'  and
                record_type = '4';

      l_uom                 VARCHAR2 (2000);
      l_period_start_date   DATE;
      l_period_end_date     DATE;
      l_record_number       VARCHAR2 (2000);
      v_currency varchar2(25);
   BEGIN
      get_3rdparty_owm (pp_dist, pp_partial_file, p_report_date);

      FOR v_report_date IN c_report_date (p_report_date)
      LOOP
         SELECT TO_DATE (SUBSTR (p_month_start_date, 1, 10), 'YYYY/MM/DD'),
                  ADD_MONTHS ((TO_DATE (SUBSTR (p_month_start_date, 1, 10),
                                        'YYYY/MM/DD'
                                       )
                              ),
                              1
                             )
                - 1
           INTO l_period_start_date,
                l_period_end_date
           FROM DUAL;

         FOR v_get_owm_data IN c_get_owm_data
         LOOP
            l_record_number := v_get_owm_data.record_number;

            IF LENGTH (l_record_number) = 3
            THEN
               l_record_number := '0' || l_record_number;
            ELSIF LENGTH (l_record_number) = 2
            THEN
               l_record_number := '00' || l_record_number;
            ELSIF LENGTH (l_record_number) = 1
            THEN
               l_record_number := '000' || l_record_number;
            ELSE
               l_record_number := l_record_number;
            END IF;

            UPDATE xxha_3rdparty_owm_stg
               SET period_start_date = l_period_start_date,
                   period_end_date = l_period_end_date,
                   order_number =
                         v_report_date.period_year
                      || v_report_date.period_num
                      || l_record_number
             WHERE record_number = v_get_owm_data.record_number;

            COMMIT;
         END LOOP;
      END LOOP;

      create_flat_records_owm;
      COMMIT;
      validate_owm_data;
      COMMIT;
      log_all_errors;
      COMMIT;

      IF gc_error_logged = 'Y' OR gc_warning_logged = 'Y'
      THEN
         conc_request :=
            fnd_concurrent.set_completion_status
               ('WARNING',
                SUBSTRB
                   ((fnd_message.get_string
                        ('OWM',
                         'OWEN AND MINOR TRACE FILE VALIDATION FAILED. PLEASE CHECK ERROR REPORT'
                        )
                    ),
                    1,
                    240
                   )
               );
         xxha_common_utilities_pkg.launch_error_report_prc
                                          (gn_request_id,
                                           'OWM File Validation',
                                           'Distributor/Legacy_Invoice_Number'
                                          );
      END IF;

      IF gc_error_logged != 'Y' OR gc_error_logged IS NULL
      THEN
         fnd_file.put_line
               (fnd_file.output, 
                   'Haemonetics 3rd Party Customer Name'
                   || CHR (9)||
                   'Haemonetics End Cust Ship to Site Number'
                   || CHR (9)||
                   '3rd Party Number'	
                   || CHR (9)||
                   'DATE OF SALE'	
                   || CHR (9)||
                   'Customer or Internal Item'	
                   || CHR (9)||
                   'UOM' 
                   || CHR (9)||
                   'Quantity'	
                   || CHR (9)||
                   'Unit Price'
                   || CHR (9)||	
                   'Currency'
                   || CHR (9)||
                   'Dist/Service Provider AR Invoice Number');

         FOR v_get_owm_data IN c_get_owm_data
         LOOP
            if v_get_owm_data.currency='US Dollar' then
              v_currency :='USD';
            else
              v_currency:=v_get_owm_data.currency;
            end if;

            fnd_file.put_line
               (fnd_file.output,
                v_get_owm_data.partner_party_name
                || CHR (9)|| 
                v_get_owm_data.ship_to_site_number
                || CHR (9)|| 
                v_get_owm_data.ship_to_attr3
                || CHR (9)|| 
                TO_CHAR (TO_DATE (v_get_owm_data.dte, 'MMDDRR'),'MM/DD/YYYY')
                || CHR (9)|| 
                v_get_owm_data.oracle_item_number
                || CHR (9)||
                v_get_owm_data.oracle_uom 
                || CHR (9)|| 
                v_get_owm_data.oracle_quantity
                || CHR (9)|| 
                v_get_owm_data.selling_price
                || CHR (9)|| 
                v_currency
                || CHR (9)|| 
                v_get_owm_data.legacy_invoice_number                
               );
         END LOOP;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'When Others',
                                'When Others Process OWM',
                                gn_record_number,
                                gc_record_identifier
                               );
         ROLLBACK;
         log_all_errors;
         COMMIT;
   END;

   PROCEDURE process_cardinal_trace_file (
      x_err_buf            OUT      VARCHAR2,
      x_ret_code           OUT      VARCHAR2,
      p_report_date                 VARCHAR2,
      p_month_start_date            VARCHAR2,
      pp_dist              IN       VARCHAR2,
      pp_partial_file      IN       VARCHAR2
   )
   IS
      conc_request          BOOLEAN;

      CURSOR c_report_date (q_report_date VARCHAR2)
      IS
         SELECT period_year,
                DECODE (LENGTH (period_num),
                        1, '0' || (period_num),
                        period_num
                       ) period_num
           FROM gl_periods_v
          WHERE period_set_name = 'HAE_GLOBAL_CAL'
            AND period_name = q_report_date;

      CURSOR c_get_card_data
      IS
         SELECT *
           FROM xxha_3rdparty_car_stg;

      l_period_start_date   DATE;
      l_period_end_date     DATE;
      l_record_number       VARCHAR2 (2000);
      l_uom                 VARCHAR2 (2000);
      v_currency varchar2(25);
   BEGIN
      get_3rdparty_owm (pp_dist, pp_partial_file, p_report_date);

      FOR v_report_date IN c_report_date (p_report_date)
      LOOP
         SELECT TO_DATE (SUBSTR (p_month_start_date, 1, 10), 'YYYY/MM/DD'),
                  ADD_MONTHS ((TO_DATE (SUBSTR (p_month_start_date, 1, 10),
                                        'YYYY/MM/DD'
                                       )
                              ),
                              1
                             )
                - 1
           INTO l_period_start_date,
                l_period_end_date
           FROM DUAL;

         FOR v_get_card_data IN c_get_card_data
         LOOP
            l_record_number := v_get_card_data.record_number;

            IF LENGTH (l_record_number) = 3
            THEN
               l_record_number := '0' || l_record_number;
            ELSIF LENGTH (l_record_number) = 2
            THEN
               l_record_number := '00' || l_record_number;
            ELSIF LENGTH (l_record_number) = 1
            THEN
               l_record_number := '000' || l_record_number;
            ELSE
               l_record_number := l_record_number;
            END IF;

            UPDATE xxha_3rdparty_car_stg
               SET period_start_date = l_period_start_date,
                   period_end_date = l_period_end_date,
                   order_number =
                         v_report_date.period_year
                      || v_report_date.period_num
                      || l_record_number
             WHERE record_number = v_get_card_data.record_number;

            COMMIT;
         END LOOP;
      END LOOP;

      validate_cardinal_data;
      COMMIT;
      log_all_errors;
      COMMIT;
      fnd_file.put_line (fnd_file.LOG,
                            'warning '
                         || gc_warning_logged
                         || ' error '
                         || gc_error_logged
                        );

      IF gc_error_logged = 'Y' OR gc_warning_logged = 'Y'
      THEN
         conc_request :=
            fnd_concurrent.set_completion_status
               ('WARNING',
                SUBSTRB
                   ((fnd_message.get_string
                        ('CAR',
                         'CARDINAL TRACE FILE VALIDATION FAILED. PLEASE CHECK ERROR REPORT'
                        )
                    ),
                    1,
                    240
                   )
               );
         xxha_common_utilities_pkg.launch_error_report_prc
                                          (gn_request_id,
                                           'Cardinal File Validation',
                                           'Distributor/Legacy_Invoice_Number'
                                          );
      END IF;

      IF gc_error_logged != 'Y' OR gc_error_logged IS NULL
      THEN
                  fnd_file.put_line
               (fnd_file.output, 
                   'Haemonetics 3rd Party Customer Name'
                   || CHR (9)||
                   'Haemonetics End Cust Ship to Site Number'
                   || CHR (9)||
                   '3rd Party Number'	
                   || CHR (9)||
                   'DATE OF SALE'	
                   || CHR (9)||
                   'Customer or Internal Item'	
                   || CHR (9)||
                   'UOM' 
                   || CHR (9)||
                   'Quantity'	
                   || CHR (9)||
                   'Unit Price'
                   || CHR (9)||	
                   'Currency'
                   || CHR (9)||
                   'Dist/Service Provider AR Invoice Number');

        
         FOR v_get_card_data IN c_get_card_data
         LOOP
            if v_get_card_data.currency='US Dollar' then
              v_currency :='USD';
            else
              v_currency:=v_get_card_data.currency;
            end if;

            fnd_file.put_line
               (fnd_file.output,
                v_get_card_data.partner_party_name
                || CHR (9)|| 
                v_get_card_data.ship_to_site_number
                || CHR (9)|| 
                v_get_card_data.ship_to_attr3
                || CHR (9)|| 
                TO_CHAR (v_get_card_data.trans_date,'MM/DD/YYYY')
                || CHR (9)|| 
                v_get_card_data.oracle_item_number
                || CHR (9)||
                v_get_card_data.oracle_uom 
                || CHR (9)|| 
                v_get_card_data.oracle_quantity
                || CHR (9)|| 
                v_get_card_data.selling_price
                || CHR (9)|| 
                v_currency
                || CHR (9)|| 
                v_get_card_data.legacy_invoice_number                
               );
         END LOOP;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'When Others',
                                'When Others Process Cardinal',
                                gn_record_number,
                                gc_record_identifier
                               );
         ROLLBACK;
         log_all_errors;
         COMMIT;
   END;

   PROCEDURE process_web_adi_trace_file (p_batch_number VARCHAR2)
   IS
      conc_request   BOOLEAN;

      CURSOR c_web_adi_extract
      IS
         SELECT 'US Indirect Sales' order_type, v.item_number,
                NULL header_bsa_number, v.po_number,
                v.end_cust_bsa_number line_bsa_number, v.quantity,
                v.date_ordered transaction_date,
                v.price_list_id line_price_list_id, v.party_site_number,
                v.batch_number, v.inventory_item_id,
                v.bsa_line_number line_number,
                DECODE (GREATEST (v.quantity, 0),
                        0, 'US Indirect Sales Return',
                        'US Indirect Sales Line'
                       ) line_type,
                NULL salesrep_id
           FROM xxha_3rd_party_chargeback_v v
          WHERE                           --v.end_cust_bsa_number is not null
--and v.distributor_bsa_number is not null and
                v.batch_number = p_batch_number
            AND NOT EXISTS (
                   SELECT NULL
                     FROM oe_order_lines_all ol
                    WHERE NVL (ol.blanket_number, '999') =
                                            NVL (v.end_cust_bsa_number, '999')
                      AND ol.cust_po_number = v.po_number
                      AND ol.ordered_item = v.item_number
                      AND ol.request_date = v.date_ordered);

--
      l_quantity     NUMBER;
      l_line_type    VARCHAR2 (2000);
   BEGIN
      DELETE FROM xxha_tm_so_stg;

      gn_record_number := 1;
      gc_record_identifier := p_batch_number;

      FOR v_web_adi_extract IN c_web_adi_extract
      LOOP
         gn_record_number := 2;
         l_quantity := v_web_adi_extract.quantity;

         INSERT INTO xxha_tm_so_stg
                     (order_type,
                      item,
                      hdr_bsa_no,
                      quantity,
                      customer_po_number,
                      line_bsa_no,
                      line_type,
                      request_date,
                      party_site_number, return_warehouse,
                      return_reason, line_price_list_id,
                      hdr_attribute1,
                      inventory_item_id,
                      blanket_line_number,
                      salesrep_id
                     )
              VALUES (v_web_adi_extract.order_type                   -- header
                                                  ,
                      v_web_adi_extract.item_number
                                         -- header start date of p_report_date
                                                   ,
                      v_web_adi_extract.header_bsa_number
                                           -- header end date of p_report_date
                                                         ,
                      v_web_adi_extract.quantity,
                      v_web_adi_extract.po_number                    -- header
                                                 ,
                      v_web_adi_extract.line_bsa_number,
                      v_web_adi_extract.line_type,
                      TO_CHAR (v_web_adi_extract.transaction_date,
                               'DD-MON-YYYY'
                              ),
                      v_web_adi_extract.party_site_number, 'BTO',
                      'CANCELLATION', v_web_adi_extract.line_price_list_id,
                      v_web_adi_extract.batch_number,
                      v_web_adi_extract.inventory_item_id,
                      v_web_adi_extract.line_number,
                      v_web_adi_extract.salesrep_id
                     );

--
         COMMIT;
      END LOOP;

      gn_record_number := 3;
   EXCEPTION
      WHEN OTHERS
      THEN
         populate_common_error (SUBSTR (SQLERRM, 1, 2000),
                                'When Others',
                                'When Others WEB ADI Extract',
                                gn_record_number,
                                gc_record_identifier
                               );
         fnd_file.put_line (fnd_file.LOG, 'Rolling back');
         ROLLBACK;
         log_all_errors;
         COMMIT;
   END;
END xxha_3rdparty_tm_file_pkg;
/
