CREATE OR REPLACE PACKAGE      XXHA_SKIDSHEET_LABEL_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_SKIDSHEET_LABEL_PKG                                                 *
* Purpose      : This package create XML Data for Load                                   *
*                It is called from concurrent Request                                    *
*                                                                                        *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        26-May-2009     Amit Patel OCS       Initial Creation                       *
* 2.0        18-Aug-2010     Data Intensity       Changed code to fix bug                *
*                                                 Magic ticket 65357                     *
* 3.0        17-Jun-2011     Bruce Marcoux        Corrected parameter for packages:      *
*                                                 - DBMS_XMLQUERY.SETROWSETTAG           *
*                                                 - DBMS_XMLQUERY.SETROWTAG              *
*                                                                                        *
*****************************************************************************************/

PROCEDURE main(err_buf          out  VARCHAR2
              ,ret_code         OUT  VARCHAR2
              ,p_load_number    in   VARCHAR2
               );


END XXHA_SKIDSHEET_LABEL_PKG;
/


CREATE OR REPLACE PACKAGE BODY      XXHA_SKIDSHEET_LABEL_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_SKIDSHEET_LABEL_PKG                                                 *
* Purpose      : This package create XML Data for Load                                   *
*                It is called from concurrent Request                                    *
*                                                                                        *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
*                                                                                         *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        26-May-2009     Amit Patel OCS       Initial Creation                       *
* 2.0        07-Sep-2010     David Lund           Updated code to fix data related issue *
*                                                 see magic ticket 68382 for details     *
* 3.0        17-Jun-2011     Bruce Marcoux        Corrected parameter for packages:      *
*                                                 - DBMS_XMLQUERY.SETROWSETTAG           *
*                                                 - DBMS_XMLQUERY.SETROWTAG              *
*                                                                                        *
*****************************************************************************************/
PROCEDURE main(err_buf          out  VARCHAR2
              ,ret_code         OUT  VARCHAR2
              ,p_load_number    in   VARCHAR2
               ) AS

   v_result_query    XMLType;
   p_xmloutput       CLOB;
   v_queryctx        DBMS_XMLGEN.ctxHandle;
   v_result_query    XMLType;
   v_xmloutput       CLOB;

   v_query           VARCHAR2(4000);

   v_plan            VARCHAR2(1000) := 'CERT OF STERILIZATION%';
-- errorNum         NUMBER;
-- errorMSG         VARCHAR2(200);
-------------------DL changes 68382------------
    v_buffer           VARCHAR2(32000);
    v_amount           NUMBER := 10;
    v_offset           NUMBER := 1;
    v_sql_text         DBMS_XMLGEN.ctxHandle;
    v_start_pos number := 0;
    v_index number := 0;
    v_string varchar2(32767);
    v_read_length number := 480;
-------------------end DL changes------------
BEGIN
/*******************************************************************
        Built up an XML fragment from custom table
        ********************************************************************/
v_query := 'SELECT  qrv.character1 LOAD
                                                   ,qrv.character2   SKID
                                                   ,qrv.lot_number   LOT
                                                   ,msi.segment1     ITEM
                                                   ,qrv.revision     REV
                                                   ,qrv.quantity     QTY
                                            from    qa_results_v  qrv
                                                   ,mtl_system_items_b msi
                                            where   qrv.name like :p_plan and
                                                    qrv.character1 = :p_load_number and
                                                    qrv.item_id  = msi.inventory_item_id
                                            and     qrv.organization_id = msi.organization_id
                                            order by TO_NUMBER(qrv.character2, 99999)';

v_queryctx := dbms_xmlgen.newcontext(v_query);
/* R12 Upgrade Modified on 09/18/2012 by Venkatesh Sarangam, Rolta */
--       DBMS_XMLQUERY.SETBINDVALUE(v_queryctx, 'p_plan', v_plan);
         DBMS_XMLGEN.SETBINDVALUE(v_queryctx, 'p_plan', v_plan);
--       DBMS_XMLQUERY.SETBINDVALUE(v_queryctx, 'p_load_number', p_load_number);
         DBMS_XMLGEN.SETBINDVALUE(v_queryctx, 'p_load_number', p_load_number);
-- 3.0 - BMarcoux
/* R12 Upgrade Modified on 09/18/2012 by Venkatesh Sarangam, Rolta */
--       DBMS_XMLQUERY.SETROWSETTAG(ctxHdl => v_queryctx, tag => 'ROWSET');
--       DBMS_XMLQUERY.SETROWTAG(ctxHdl => v_queryctx, tag => 'ROW');
         DBMS_XMLGEN.SETROWSETTAG(ctx => v_queryctx, rowSetTagName => 'ROWSET');
         DBMS_XMLGEN.SETROWTAG(ctx => v_queryctx, rowTagName => 'ROW');
--         DBMS_XMLQUERY.SETROWSETTAG(ctx => v_queryctx, tag => 'ROWSET');
--         DBMS_XMLQUERY.SETROWTAG(ctx => v_queryctx, tag => 'ROW');
/* R12 Upgrade Modified on 09/18/2012 by Venkatesh Sarangam, Rolta */
--       v_xmloutput :=  DBMS_XMLQUERY.GETXML(v_queryctx);
         v_xmloutput :=  DBMS_XMLGEN.GETXML(v_queryctx);
        -------------------DL changes 68382------------
            v_amount := dbms_lob.getlength(v_xmloutput);
        if v_amount > 1 then
                  while v_start_pos <=  v_amount
                  loop
                   v_index := v_index + 1;
                   v_string :=  dbms_lob.substr(v_xmloutput,v_read_length,v_start_pos+1);
                   v_start_pos  := v_start_pos+v_read_length;
                   fnd_file.put(FND_FILE.OUTPUT, v_string);
                  end loop;
        else
        fnd_file.put_line(FND_FILE.log, 'Ven5');
              SELECT dbms_xmlgen.newContext('SELECT '' No data found'' DATA FROM dual')
                INTO v_sql_text
                from dual;
              v_xmloutput := dbms_xmlgen.getxml(v_sql_text);
              v_amount := dbms_lob.getlength(v_xmloutput);
              dbms_lob.read(v_xmloutput, v_amount, v_offset, v_buffer);
              fnd_file.put(fnd_file.output, v_buffer);

            end if;
-------------------end DL changes------------
/* R12 Upgrade Modified on 09/18/2012 by Venkatesh Sarangam, Rolta */
--       DBMS_XMLQUERY.closecontext(v_queryctx);
        DBMS_XMLGEN.closecontext(v_queryctx);
--  v_xmloutput := '<?xml version="1.0" encoding="UTF-8"?>'||chr(10)||v_xmloutput;
--commented out not needed DL 68382
--         fnd_file.put_line(FND_FILE.output, v_xmloutput);
--         fnd_file.put_line(FND_FILE.log, v_xmloutput);
EXCEPTION
  WHEN OTHERS THEN
/* R12 Upgrade Modified on 09/18/2012 by Venkatesh Sarangam, Rolta */
--      DBMS_XMLQuery.GETEXCEPTIONCONTENT(v_queryctx, errorNum, errorMSG);
--      fnd_file.put_line(FND_FILE.log, 'Exception :'||errorNum ||'  '||errorMSG);
        fnd_file.put_line(FND_FILE.log, 'Exception :'||SQLCODE ||'  '||SQLERRM);

END MAIN;
END XXHA_SKIDSHEET_LABEL_PKG;
/
