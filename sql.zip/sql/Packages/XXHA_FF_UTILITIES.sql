CREATE OR REPLACE PACKAGE      XXHA_FF_UTILITIES
AS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_FF_UTILITIES
*  Description:
*      This package is written to read the bonus payout data from the  EIT
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski    Created New.
*  02-MAR-2009       R. Sneep          Added Function get_sales_bonus_glb.
*
******************************************************************************/
FUNCTION get_bonus_payout
  ( P_ASSIGNMENT_ID NUMBER,  P_DATE_EARNED DATE)
  RETURN NUMBER;


FUNCTION get_sales_bonus_glb
  ( p_assignment_id NUMBER
   ,p_date_earned   DATE
  )
  RETURN NUMBER;


PROCEDURE update_salary( errbuf VARCHAR2, errcode NUMBER);


END;
/


CREATE OR REPLACE PACKAGE BODY XXHA_FF_UTILITIES
AS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_FF_UTILITIES
*  Function: get_bonus_payout
*  Description:
*      This package is written to read the bonus payout data from the  EIT
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*
******************************************************************************/
FUNCTION get_bonus_payout
( P_ASSIGNMENT_ID NUMBER,  P_DATE_EARNED DATE)
  RETURN NUMBER IS
CURSOR get_bonus_payout  IS
select TO_NUMBER(  NVL( pei.pei_information30, 0)   )
from per_people_extra_info pei,
per_all_assignments_f paaf
where pei.person_Id =  paaf.person_id
and TRUNC(SYSDATE) BETWEEN TRUNC (paaf.EFFECTIVE_START_DATE) AND TRUNC(paaf.EFFECTIVE_END_DATE)
and pei.pei_information_category = 'HAE_BONUS_GLB'
and pei.Information_type = 'HAE_BONUS_GLB'
AND paaf.assignment_id = p_assignment_id
AND    TO_CHAR(P_DATE_EARNED  ,'YYYY') = pei.pei_information1;
l_bonus_payout NUMBER;
L_RE varchar2(100);
BEGIN

OPEN get_bonus_payout;
FETCH  get_bonus_payout INTO l_bonus_payout;
IF get_bonus_payout%NOTFOUND
THEN  l_bonus_payout := 0;
 END IF;
CLOSE get_bonus_payout ;
RETURN l_bonus_payout;
EXCEPTION
WHEN OTHERS THEN RETURN 0;
END;


/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Function: get_sales_bonus_glb
*  Description:
*      This function gets the Target Bonus Amount for the year provided (date earned)
*      from the HAE_SALES_BONUS_GLB Person EIT
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  02-Mar-2009       R.Sneep           Created New.
*
******************************************************************************/
FUNCTION get_sales_bonus_glb
  ( p_assignment_id NUMBER
   ,p_date_earned   DATE
  )
RETURN NUMBER
IS

CURSOR target_amt_cur
IS
SELECT TO_NUMBER(NVL(pei.pei_information3, 0))
  FROM per_people_extra_info pei
      ,per_all_assignments_f paa
 WHERE pei.person_id =  paa.person_id
   AND paa.assignment_id = p_assignment_id
   AND pei.information_type = 'HAE_SALES_BONUS_GLB'
   AND TO_CHAR(p_date_earned,'YYYY') = SUBSTR(pei.pei_information1,1,4)
   AND TRUNC(SYSDATE) BETWEEN paa.effective_start_date AND paa.effective_end_date
ORDER BY fnd_date.canonical_to_date(pei_information1) DESC;

l_target_amount NUMBER;

BEGIN

OPEN target_amt_cur;
FETCH target_amt_cur INTO l_target_amount;
IF target_amt_cur%NOTFOUND
THEN
   l_target_amount := 0;
END IF;
CLOSE target_amt_cur;

RETURN l_target_amount;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 0;

END;


PROCEDURE update_salary( errbuf VARCHAR2, errcode NUMBER) --
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_FF_UTILITIES
*  Function: update_salary
*  Description:
*      This package is written to calculate salary rate and update salary table
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski    Created New.
*  29-JAN-2009       R. Sneep          Changed to also recalc hourly rate on asg change
*                                      and to only update when different than old rate.
*
******************************************************************************/

AS
-- OUT variables
  L_PAY_PROPOSAL_ID		NUMBER;
  L_OBJECT_VERSION_NUMBER	NUMBER;
  L_ELEMENT_ENTRY_ID		NUMBER;
  L_INV_NEXT_SAL_DATE_WARNING	BOOLEAN;
  L_PROPOSED_SALARY_WARNING	BOOLEAN;
  L_APPROVED_WARNING		BOOLEAN;
  L_PAYROLL_WARNING		BOOLEAN;
  L_RET VARCHAR2(100);
  L_RATE number;




CURSOR csr_get_sal_info
 IS
   SELECT ppf.employee_number
         ,ASSIGN.NORMAL_HOURS
         ,ASSIGN.ASSIGNMENT_ID
         ,ASSIGN.FREQUENCY
         ,PPP.LAST_CHANGE_DATE
         ,ppp.pay_proposal_id
         ,ppp.object_version_number
         ,NVL ( ppp.proposed_salary_n ,0),
                ROUND (
                       ((ppb.pay_annualization_factor * ppp.proposed_salary_n ) /
                        (NVL(assign.normal_hours,40) * DECODE(assign.frequency,'W',52,'D',365,'M',12,'Y',1,52)))
                     ,2) new_hourly_rate
         ,TO_NUMBER(NVL(ppp.attribute1,'0')) old_hourly_rate
    FROM PER_ALL_ASSIGNMENTS_F ASSIGN
        ,per_all_people_f ppf
        ,per_pay_proposals ppp
        ,per_pay_bases ppb
     WHERE PPF.CURRENT_EMP_OR_APL_FLAG = 'Y'
       and ppf.person_id = ASSIGN.person_id
       AND TRUNC(SYSDATE) BETWEEN ppf.effective_start_date AND ppf.effective_end_date
       AND TRUNC(SYSDATE) BETWEEN ASSIGN.effective_start_date AND ASSIGN.effective_end_date
       AND ppp.assignment_id = ASSIGN.assignment_id
       and ppb.pay_basis_id = ASSIGN.pay_basis_id
       AND (
            (ppp.LAST_UPDATE_DATE BETWEEN (sysdate - 0.05) AND SYSDATE)
           OR
            (assign.LAST_UPDATE_DATE BETWEEN (sysdate - 0.05) AND SYSDATE)
           )
          ;

BEGIN
FOR SAL_REC IN csr_get_sal_info
LOOP
 BEGIN
    L_PAY_PROPOSAL_ID := SAL_REC.pay_proposal_id;
    L_OBJECT_VERSION_NUMBER := SAL_REC.OBJECT_VERSION_NUMBER;

    IF sal_rec.old_hourly_rate <> sal_rec.new_hourly_rate
    THEN
     HR_MAINTAIN_PROPOSAL_API.update_salary_proposal
      (
        P_PAY_PROPOSAL_ID            => L_PAY_PROPOSAL_ID
       ,P_OBJECT_VERSION_NUMBER      => L_OBJECT_VERSION_NUMBER
       ,P_INV_NEXT_SAL_DATE_WARNING  => L_INV_NEXT_SAL_DATE_WARNING
       ,P_PROPOSED_SALARY_WARNING    => L_PROPOSED_SALARY_WARNING
       ,P_APPROVED_WARNING           => L_APPROVED_WARNING
       ,P_PAYROLL_WARNING            => L_PAYROLL_WARNING
       ,P_ATTRIBUTE1                 => TO_CHAR(sal_rec.new_hourly_rate)
   	  );
     COMMIT;
    END IF;

 EXCEPTION
 WHEN
 OTHERS THEN NULL;
 END;
END LOOP;
EXCEPTION
WHEN
OTHERS THEN NULL;
END update_salary;
END;
/
