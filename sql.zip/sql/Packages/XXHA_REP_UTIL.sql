CREATE OR REPLACE package XXHA_REP_UTIL is

   function XXHA_CC_MEANING(
P_VALU  in VARCHAR2 DEFAULT '8100') return varchar2;
END;

/


CREATE OR REPLACE package body XXHA_REP_UTIL is

/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_REP_UTIL
*  Function: check_for_empl_nbr_f
*  Description:
*      This package is written to support oracle reports
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*
******************************************************************************/


function XXHA_CC_MEANING(
P_VALU  in VARCHAR2 DEFAULT '8100') return varchar2 is


/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Function:   XXHA_CC_MEANING
*  Function: check_for_empl_nbr_f
*  Description:
*      This package is written to display description for Management Unit
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*
******************************************************************************/

  Result varchar2(500);
 CURSOR C_DESC IS
select distinct
vl_co.DESCRIPTION
  from
GL_CODE_COMBINATIONS GCC ,

APPS.FND_FLEX_VALUES_VL VL_CO,
FND_ID_FLEX_SEGMENTS S_CO


where

-- MU JOIN
 S_CO.ID_FLEX_NUM = 101
 AND S_CO.APPLICATION_iD = 101 --
 and  S_CO.Id_Flex_Code = 'GL#'   -- MU S4
 and S_CO.APPLICATION_COLUMN_NAME = 'SEGMENT4'  -- MU
 AND S_CO.FLEX_VALUE_SET_ID = VL_CO.FLEX_VALUE_SET_ID --  MU S4
  AND S_CO.FLEX_VALUE_SET_ID = 1010317
and VL_CO.FLEX_VALUE =  P_VALU  -- MU
 and VL_CO.FLEX_VALUE = gcc.segment4

AND
 VL_CO.DESCRIPTION  <> 'No Value Required'; --  MU S4





begin
FOR REC_DESC IN C_DESC
LOOP
Result := REC_DESC.DESCRIPTION ;
END LOOP;

  return(Result);
end XXHA_CC_MEANING;

END;

/
