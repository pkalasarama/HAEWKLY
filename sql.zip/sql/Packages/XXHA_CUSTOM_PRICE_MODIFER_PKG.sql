CREATE OR REPLACE PACKAGE APPS.XXHA_CUSTOM_PRICE_MODIFER_PKG
/*************************************************************************************************************
* Package Name : xxha_custom_price_modifer_pkg                                                               *
*                                                                                                            *
*                                                                                                            *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver     Date          Author            Description                                                        *
* ------  -----------   ----------------  ---------------                                                    *
* 1.0     04-Oct-2014   Harish Kollipara  Initial version                                                    *
* 2.0     24-NOV-2014   Harish Kollipara  added Handling discount                                            *
**************************************************************************************************************/

IS
   g_dim_weight_threshold   NUMBER;
   g_shipment_min_weight    NUMBER;


   PROCEDURE initialize_session;

   -- added by hkollipara 11/24/2014
   PROCEDURE apply_wb_handling_discount (p_delivery_id      IN     NUMBER,
                                         x_status_code         OUT VARCHAR2,
                                         x_status_message      OUT VARCHAR2);

   PROCEDURE apply_wb_freight_discount (p_delivery_id      IN     NUMBER,
                                        x_status_code         OUT VARCHAR2,
                                        x_status_message      OUT VARCHAR2);

   PROCEDURE mixed_wb_weight_calc (p_line_id IN NUMBER, p_wb_ratio OUT NUMBER);

   PROCEDURE mixed_wb_handling_calc (p_line_id IN NUMBER, p_handling_charge OUT NUMBER);

   FUNCTION get_handling_fee (p_handling_mode IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION get_postal_zone (p_organization_code VARCHAR2, p_ship_to_postal_code VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION get_actual_weight (p_line_id IN NUMBER)
      RETURN NUMBER;

   FUNCTION get_minimum_weight (p_zone IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION get_item_volume (p_item_id IN NUMBER)
      RETURN NUMBER;

   FUNCTION get_dimensional_weight (p_item_id NUMBER, p_org_id NUMBER, p_zone IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION is_container_type_defined (p_item_id NUMBER, p_org_id NUMBER)
      RETURN VARCHAR2;

   FUNCTION case_conversion_rate (p_item_id IN NUMBER, p_uom_from IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION check_base_conv_rate (p_item_id IN NUMBER)
      RETURN VARCHAR2;

   PROCEDURE get_modifier_list (p_freight_item_id      IN     NUMBER,
                                p_mod_list_header_id      OUT NUMBER,
                                p_mod_list_line_id        OUT NUMBER);

   PROCEDURE log_this (p_message       IN VARCHAR2,
                       p_delivery_id   IN NUMBER DEFAULT NULL,
                       p_process       IN VARCHAR2,
                       p_error_Code    IN VARCHAR2 DEFAULT NULL,
                       p_error_msg     IN VARCHAR2 DEFAULT NULL);
END xxha_custom_price_modifer_pkg;
/

CREATE OR REPLACE PACKAGE BODY APPS.xxha_custom_price_modifer_pkg
/*************************************************************************************************************
* Package Name : xxha_custom_price_modifer_pkg                                                               *
*                                                                                                            *
*                                                                                                            *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver        Date            Author            Description                                                   *
* ------     -----------     ----------------  ---------------                                               *
* 1.0        04-Oct-2014     Harish Kollipara  Initial version                                               *
* 2.0        21-Nov-2014     Harish Kollipara  Added Handling charges modifer                                *
*                                                                                                            *
**************************************************************************************************************/
IS
   PROCEDURE apply_wb_freight_discount (p_delivery_id      IN     NUMBER,
                                        --                                        p_user_id          IN NUMBER,
                                        --                                        p_responsibility_id IN NUMBER,
                                        x_status_code         OUT VARCHAR2,
                                        x_status_message      OUT VARCHAR2)
   IS
      i                           BINARY_INTEGER;
      l_order_line_id             oe_order_lines_all.line_id%TYPE;
      l_order_header_id           oe_order_lines_all.header_id%TYPE;
      l_list_header_id            qp_list_headers_tl.list_header_id%TYPE;
      l_mod_list_header_id        qp_list_headers_tl.list_header_id%TYPE;
      l_mod_list_line_id          qp_list_lines.list_line_id%TYPE;
      v_adj                       oe_order_adj_pvt.manual_adj_tbl_type;
      v_adj_hand                  oe_order_adj_pvt.manual_adj_tbl_type;
      v_header_id                 NUMBER;
      v_org_id                    NUMBER;
      l_file                      VARCHAR2 (100);
      l_return_status             VARCHAR2 (30);
      l_msg_data                  VARCHAR2 (256);
      l_msg_count                 NUMBER;
      l_msg_index                 NUMBER;
      l_data                      VARCHAR2 (2000);
      l_msg_index_out             NUMBER (10);
      l_header_rec                OE_Order_PUB.Header_Rec_Type;
      l_header_val_rec            OE_Order_PUB.Header_Val_Rec_Type;
      l_line_tbl                  OE_Order_PUB.Line_Tbl_Type;
      l_line_val_tbl              OE_Order_PUB.Line_Val_Tbl_Type;
      l_header_adj_tbl            OE_ORDER_PUB.Header_Adj_Tbl_Type;
      l_header_adj_val_tbl        OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
      l_header_price_att_tbl      OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
      l_header_adj_assoc_tbl      OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
      l_header_scredit_tbl        OE_ORDER_PUB.Header_Scredit_Tbl_Type;
      l_header_scredit_val_tbl    OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
      l_header_adj_att_tbl        OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
      l_Line_Adj_Tbl              OE_ORDER_PUB.Line_Adj_Tbl_Type;
      l_Line_Adj_Tbl_out          OE_ORDER_PUB.Line_Adj_Tbl_Type;
      l_Line_Adj_Val_Tbl          OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
      l_Line_Price_Att_Tbl        OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
      l_Line_Adj_Att_Tbl          OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
      l_Line_Adj_Assoc_Tbl        OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
      l_line_scredit_tbl          OE_ORDER_PUB.Line_Scredit_Tbl_Type;
      l_Line_scredit_val_Tbl      OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
      l_line_price_att_rec        OE_Order_PUB.Line_Price_Att_Rec_Type;
      l_Lot_Serial_Tbl            OE_ORDER_PUB.Lot_Serial_Tbl_Type;
      l_Lot_Serial_val_Tbl        OE_ORDER_PUB.Lot_Serial_val_Tbl_Type;
      l_Request_Tbl               OE_ORDER_PUB.Request_Tbl_Type;
      l_price_adj_id              NUMBER;
      l_file_val                  VARCHAR2 (60);
      l_unit_list_price           NUMBER;
      l_OPERAND                   qp_list_lines.operand%TYPE;
      l_freight_OPERAND           qp_list_lines.operand%TYPE;
      l_handling_OPERAND          qp_list_lines.operand%TYPE;
      l_freight_order             VARCHAR2 (10) := 'No';

      v_return_status             VARCHAR2 (2000);
      v_msg_count                 NUMBER;
      v_msg_data                  VARCHAR2 (2000);
      l_wb_ratio                  NUMBER;

      v_user_responsibility_id    NUMBER;
      v_user_id                   NUMBER;
      v_application_id            NUMBER;

      l_hand_unit_list_price      NUMBER;
      l_order_hand_line_id        NUMBER;
      l_freight_item_id           NUMBER;
      l_handling_item_id          NUMBER;
      l_hand_mod_list_line_id     NUMBER;
      l_hand_mod_list_header_id   NUMBER;
   BEGIN
      log_this (
         p_message       => 'START++:++ apply_wb_freight_discount for delivery ID: ' || p_delivery_id,
         p_delivery_id   => p_delivery_id,
         p_process       => 'apply_wb_freight_discount');

      initialize_session;

      /*
   mo_global.init ('ONT');

   --mo_global.set_policy_context ('S', 102);

   BEGIN
      SELECT application_id
        INTO v_application_id
        FROM fnd_application
       WHERE application_short_name = 'ONT';

      SELECT responsibility_id
        INTO v_user_responsibility_id
        FROM fnd_responsibility_vl
       WHERE responsibility_name = 'WW Order Management Super User OC';

      SELECT user_id
        INTO v_user_id
        FROM fnd_user
       WHERE user_name = 'WEBMETHODS';
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;

   --fnd_global.apps_initialize (27016, 50237, 660);

   fnd_global.apps_initialize (v_user_id, v_user_responsibility_id, v_application_id);*/


      BEGIN
         SELECT DISTINCT 'Yes'
           INTO l_freight_order
           FROM wsh_delivery_details wdd, wsh_dlvb_dlvy_v deliv, oe_order_headers_all ooh
          WHERE     wdd.delivery_detail_id = deliv.delivery_detail_id
                AND deliv.delivery_id = p_delivery_id
                AND wdd.source_header_id = ooh.header_id
                AND ooh.freight_terms_code = 'MXD_WBPAID_HAE_DUE';
      /* SELECT DISTINCT 'Yes'
         INTO l_freight_order
         FROM wsh_delivery_details wdd,
              oe_order_lines_all ool,
              wsh_dlvb_dlvy_v deliv,
              oe_order_headers_all ooh
        WHERE     wdd.delivery_detail_id = deliv.delivery_detail_id
              AND ool.header_id = ooh.header_id
              AND deliv.delivery_id = p_delivery_id
              AND wdd.source_line_id = ool.line_id
              AND ooh.freight_terms_code = 'MXD_WBPAID_HAE_DUE';*/
      --         SELECT 'Yes'
      --           INTO l_freight_order
      --           FROM oe_order_headers_all ooh
      --          WHERE ooh.header_id = l_order_header_id AND ooh.freight_terms_code = 'MXD_WBPAID_HAE_DUE';
      EXCEPTION
         WHEN OTHERS
         THEN
            l_freight_order := 'No';
            l_order_line_id := NULL;
            l_order_header_id := NULL;
            x_status_code := 'S'; -- hk 10/23/14 changed this to S as webmethods is throwing an error
            log_this (
               p_message       => 'l_freight_order flag: ' || l_freight_order,
               p_delivery_id   => l_order_line_id,
               p_process       => 'apply_wb_freight_discount',
               p_error_msg     => x_status_message || '; '
                                 || 'Freight Terms on Sales order is not Mixed WB Prepaid HAE Prepay Add');
      --            x_status_message :=
      --                  x_status_message
      --               || '; '
      --               || 'Freight Terms on Sales order is not Mixed WB Prepaid HAE Prepay Add';
      END;

      log_this (p_message       => 'l_freight_order flag: ' || l_freight_order,
                p_delivery_id   => l_order_line_id,
                p_process       => 'apply_wb_freight_discount');

      IF l_freight_order = 'Yes'
      THEN
         BEGIN
            SELECT ool.line_id,
                   ool.header_id,
                   ool.unit_list_price,
                   ool.org_id,
                   ool.inventory_item_id
              INTO l_order_line_id,
                   l_order_header_id,
                   l_unit_list_price,
                   v_org_id,
                   l_freight_item_id
              FROM wsh_delivery_details wdd, oe_order_lines_all ool, wsh_dlvb_dlvy_v deliv
             WHERE     wdd.delivery_detail_id = deliv.delivery_detail_id
                   AND deliv.delivery_id = p_delivery_id
                   AND wdd.source_line_id = ool.line_id
                   AND ool.inventory_item_id = 2          ------ comment HK: remove hardcoding here.
                   --and msi.segment1= 'FREIGHT'
                   AND ool.flow_status_code <> 'CANCELLED';
         EXCEPTION
            WHEN OTHERS
            THEN
               l_order_line_id := NULL;
               l_order_header_id := NULL;
               x_status_code := 'E';
               x_status_message := 'No FREIGHT Line in the delivery';
               log_this (
                  p_message       =>   'No frieght line in this delivery: '
                                    || p_delivery_id
                                    || ' Error- '
                                    || SQLERRM,
                  p_delivery_id   => p_delivery_id,
                  p_process       => 'apply_wb_freight_discount',
                  p_error_msg     => 'No FREIGHT Line in the delivery');
         END;

         --hkollipara 11/24/2014
         BEGIN
            SELECT ool.line_id, ool.unit_list_price, ool.inventory_item_id
              INTO l_order_hand_line_id, l_hand_unit_list_price, l_handling_item_id
              FROM wsh_delivery_details wdd, oe_order_lines_all ool, wsh_dlvb_dlvy_v deliv
             WHERE     wdd.delivery_detail_id = deliv.delivery_detail_id
                   AND deliv.delivery_id = p_delivery_id
                   AND wdd.source_line_id = ool.line_id
                   AND ool.ordered_item = 'HANDLING'
                   AND ool.flow_status_code <> 'CANCELLED';
         EXCEPTION
            WHEN OTHERS
            THEN
               l_order_line_id := NULL;
               l_order_header_id := NULL;
               --               x_status_code := 'E';
               --               x_status_message := 'No HANDLING Line in the delivery';
               log_this (
                  p_message       =>   'No handling line in this delivery: '
                                    || p_delivery_id
                                    || ' Error- '
                                    || SQLERRM,
                  p_delivery_id   => p_delivery_id,
                  p_process       => 'apply_wb_freight_discount',
                  p_error_msg     => 'No HANDLING Line in the delivery');
         END;

         mo_global.set_policy_context ('S', v_org_id);
         log_this (p_message       => 'Freight line ID: ' || l_order_line_id,
                   p_delivery_id   => l_order_line_id,
                   p_process       => 'apply_wb_freight_discount');

         --- added this 10/7/14.
         -- 11/25/2014 added function to get modifier pL
         -- get FR modifiers
         get_modifier_list (l_freight_item_id, l_mod_list_header_id, l_mod_list_line_id);
         -- handling modifier
         get_modifier_list (l_handling_item_id, l_hand_mod_list_header_id, l_hand_mod_list_line_id);


         IF l_order_line_id IS NOT NULL AND l_freight_order = 'Yes'
         THEN
            BEGIN
               Oe_Order_Adj_Pvt.get_manual_adjustments (
                  p_header_id        => l_order_header_id,
                  p_line_id          => l_order_line_id,
                  p_line_rec         => oe_order_pub.g_miss_line_rec,
                  p_level            => 'LINE',
                  p_pbh_mode         => 'CHILD',
                  p_cross_order      => 'N',
                  p_line_level       => 'N',
                  x_manual_adj_tbl   => v_adj,
                  x_return_status    => v_return_status,
                  x_header_id        => v_header_id,
                  p_freight_flag     => FALSE,
                  p_called_from      => 'test');
            EXCEPTION
               WHEN OTHERS
               THEN
                  log_this (
                     p_message       => 'Error in freight price request API.',
                     p_delivery_id   => l_order_line_id,
                     p_process       => 'apply_wb_freight_discount',
                     p_error_msg     =>   x_status_message
                                       || '; '
                                       || 'Error fetching freight price .Price request API failed.');
                  x_status_code := 'E';
                  x_status_message :=
                        x_status_message
                     || '; '
                     || 'Error fetching freight discount price .Price request API failed.';
            END;


            IF v_return_status = 'S'
            THEN
               FOR i IN 1 .. v_adj.COUNT
               LOOP
                  IF v_adj (i).list_header_id = l_mod_list_header_id
                     AND v_adj (i).list_line_id = l_mod_list_line_id
                  THEN
                     l_freight_operand := v_adj (i).operand;
                  END IF;
               END LOOP;
            END IF;


            IF l_order_hand_line_id IS NOT NULL AND l_freight_order = 'Yes'
            THEN
               BEGIN
                  Oe_Order_Adj_Pvt.get_manual_adjustments (
                     p_header_id        => l_order_header_id,
                     p_line_id          => l_order_hand_line_id,
                     p_line_rec         => oe_order_pub.g_miss_line_rec,
                     p_level            => 'LINE',
                     p_pbh_mode         => 'CHILD',
                     p_cross_order      => 'N',
                     p_line_level       => 'N',
                     x_manual_adj_tbl   => v_adj_hand,
                     x_return_status    => v_return_status,
                     x_header_id        => v_header_id,
                     p_freight_flag     => FALSE,
                     p_called_from      => 'test');
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     log_this (
                        p_message       => 'Error in handling price request API.',
                        p_delivery_id   => l_order_line_id,
                        p_process       => 'apply_wb_freight_discount',
                        p_error_msg     => x_status_message || '; '
                                          || 'Error fetching handling discount price .Price request API failed.');
                     x_status_code := 'E';
                     x_status_message :=
                           x_status_message
                        || '; '
                        || 'Error fetching handling discount price .Price request API failed.';
               END;
            END IF;

            IF v_return_status = 'S'
            THEN
               FOR i IN 1 .. v_adj.COUNT
               LOOP
                  IF v_adj_hand (i).list_header_id = l_hand_mod_list_header_id
                     AND v_adj_hand (i).list_line_id = l_hand_mod_list_line_id
                  THEN
                     l_handling_operand := NVL (v_adj_hand (i).operand, 0);
                  END IF;
               END LOOP;
            END IF;


            log_this (p_message       => 'Freight Operand value: ' || l_freight_operand,
                      p_delivery_id   => l_order_line_id,
                      p_process       => 'apply_wb_freight_discount');
            log_this (p_message       => 'Handling Operand value: ' || l_handling_operand,
                      p_delivery_id   => l_order_line_id,
                      p_process       => 'apply_wb_freight_discount');

            IF l_freight_operand IS NOT NULL AND l_handling_operand IS NOT NULL
            THEN
               BEGIN
                  log_this (p_message       => 'Calling Process Order API',
                            p_delivery_id   => l_order_line_id,
                            p_process       => 'apply_wb_freight_discount');

                  Oe_Msg_Pub.initialize;

                  l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
                  l_header_rec.header_id := l_order_header_id;
                  --               l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;

                  l_line_tbl := oe_order_pub.G_MISS_LINE_TBL;

                  IF l_order_line_id IS NOT NULL
                  THEN
                     l_line_tbl (1) := OE_ORDER_PUB.G_MISS_LINE_REC;
                     l_line_tbl (1).header_id := l_order_header_id;
                     L_Line_Tbl (1).Line_Id := l_order_line_id;
                     l_Line_price_Att_tbl (1) := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_REC;

                     l_Line_Adj_Tbl (1) := OE_ORDER_PUB.G_MISS_LINE_ADJ_REC;
                     l_Line_Adj_Tbl_out (1) := OE_ORDER_PUB.G_MISS_LINE_ADJ_REC;
                     l_Line_Adj_Tbl (1).operation := OE_GLOBALS.G_OPR_CREATE;
                     l_Line_Adj_Tbl (1).header_id := l_order_header_id; --header_id of the sales order
                     l_Line_Adj_Tbl (1).line_id := l_order_line_id; --line_id of the sales order line
                     l_Line_Adj_Tbl (1).line_index := 1;
                     l_Line_Adj_Tbl (1).automatic_flag := FND_API.G_MISS_CHAR;
                     l_Line_Adj_Tbl (1).applied_flag := 'Y';
                     l_Line_Adj_Tbl (1).update_allowed := 'Y';
                     l_Line_Adj_Tbl (1).list_header_id := l_mod_list_header_id; --list_header_id of the adjustment
                     l_Line_Adj_Tbl (1).list_line_id := l_mod_list_line_id; --list_line_id of the adjustment
                     l_Line_Adj_Tbl (1).list_line_type_code := 'DIS';
                     l_line_adj_tbl (1).modifier_level_code := 'LINE';
                     l_Line_Adj_Tbl (1).arithmetic_operator := 'AMT';
                     l_Line_Adj_Tbl (1).operand := l_freight_operand;
                     l_Line_Adj_Tbl (1).list_line_no := TO_CHAR (l_mod_list_line_id);
                  END IF;

                  IF l_order_hand_line_id IS NOT NULL
                  THEN
                     l_line_tbl (2) := OE_ORDER_PUB.G_MISS_LINE_REC;
                     l_line_tbl (2).header_id := l_order_header_id;
                     L_Line_Tbl (2).Line_Id := l_order_hand_line_id;
                     l_Line_price_Att_tbl (2) := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_REC;

                     l_Line_Adj_Tbl (2) := OE_ORDER_PUB.G_MISS_LINE_ADJ_REC;
                     l_Line_Adj_Tbl_out (2) := OE_ORDER_PUB.G_MISS_LINE_ADJ_REC;
                     l_Line_Adj_Tbl (2).operation := OE_GLOBALS.G_OPR_CREATE;
                     l_Line_Adj_Tbl (2).header_id := l_order_header_id; --header_id of the sales order
                     l_Line_Adj_Tbl (2).line_id := l_order_hand_line_id; --line_id of the sales order line
                     l_Line_Adj_Tbl (2).line_index := 1;
                     l_Line_Adj_Tbl (2).automatic_flag := FND_API.G_MISS_CHAR;
                     l_Line_Adj_Tbl (2).applied_flag := 'Y';
                     l_Line_Adj_Tbl (2).update_allowed := 'Y';
                     l_Line_Adj_Tbl (2).list_header_id := l_hand_mod_list_header_id; --list_header_id of the adjustment
                     l_Line_Adj_Tbl (2).list_line_id := l_hand_mod_list_line_id; --list_line_id of the adjustment
                     l_Line_Adj_Tbl (2).list_line_type_code := 'DIS';
                     l_line_adj_tbl (2).modifier_level_code := 'LINE';
                     l_Line_Adj_Tbl (2).arithmetic_operator := 'AMT';
                     l_Line_Adj_Tbl (2).operand := l_handling_operand;
                     l_Line_Adj_Tbl (2).list_line_no := TO_CHAR (l_hand_mod_list_line_id);
                  END IF;


                  l_line_scredit_tbl (1) := oe_order_pub.g_miss_line_scredit_rec;
                  oe_order_pub.process_order (
                     p_api_version_number       => 1.0,
                     p_init_msg_list            => FND_API.G_TRUE,
                     p_org_id                   => v_org_id,
                     p_return_values            => FND_API.G_TRUE,
                     p_action_commit            => FND_API.G_TRUE,
                     p_header_rec               => l_header_rec,
                     p_header_val_rec           => l_header_val_rec,
                     p_line_tbl                 => l_line_tbl,
                     p_line_adj_tbl             => l_line_adj_tbl,
                     p_line_scredit_tbl         => l_line_scredit_tbl,
                     x_return_status            => l_return_status,
                     x_msg_count                => l_msg_count,
                     x_msg_data                 => l_msg_data,
                     x_header_rec               => l_header_rec,
                     x_header_val_rec           => l_header_val_rec,
                     x_header_adj_tbl           => l_header_adj_tbl,
                     x_header_adj_val_tbl       => l_header_adj_val_tbl,
                     x_header_price_att_tbl     => l_header_price_att_tbl,
                     x_header_adj_att_tbl       => l_header_adj_att_tbl,
                     x_header_adj_assoc_tbl     => l_header_adj_assoc_tbl,
                     x_header_scredit_tbl       => l_header_scredit_tbl,
                     x_header_scredit_val_tbl   => l_header_scredit_val_tbl,
                     x_line_tbl                 => l_line_tbl,
                     x_line_val_tbl             => l_line_val_tbl,
                     x_line_adj_tbl             => l_line_adj_tbl_out,
                     x_line_adj_val_tbl         => l_line_adj_val_tbl,
                     x_line_price_att_tbl       => l_line_price_att_tbl,
                     x_line_adj_att_tbl         => l_line_adj_att_tbl,
                     x_line_adj_assoc_tbl       => l_line_adj_assoc_tbl,
                     x_line_scredit_tbl         => l_line_scredit_tbl,
                     x_line_scredit_val_tbl     => l_line_scredit_val_tbl,
                     x_lot_serial_tbl           => l_lot_serial_tbl,
                     x_lot_serial_val_tbl       => l_lot_serial_val_tbl,
                     x_action_request_tbl       => l_request_tbl);



                  IF l_return_status = fnd_api.g_ret_sts_success
                  THEN
                     COMMIT;
                     log_this (p_message       => 'Order Import API Success',
                               p_delivery_id   => l_order_line_id,
                               p_process       => 'apply_wb_freight_discount');
                  ELSE
                     log_this (p_message       => 'Error in Order Import API',
                               p_delivery_id   => l_order_line_id,
                               p_process       => 'apply_wb_freight_discount',
                               p_error_msg     => v_msg_data);

                     ROLLBACK;

                     FOR i IN 1 .. l_msg_count
                     LOOP
                        Oe_Msg_Pub.get (p_msg_index       => i,
                                        p_encoded         => Fnd_Api.G_FALSE,
                                        p_data            => l_msg_data,
                                        p_msg_index_out   => l_msg_index_out);

                        --  l_msg_data := oe_msg_pub.get (p_msg_index => i, p_encoded => 'F');
                        DBMS_OUTPUT.put_line (i || ') ' || l_msg_data);
                     END LOOP;

                     x_status_code := 'E';
                     x_status_message := l_msg_data;
                  END IF;

                  i := l_line_adj_tbl_out.FIRST;

                  IF i IS NOT NULL
                  THEN
                     x_status_code := 'S';
                     x_status_message := '';
                  ELSE
                     x_status_code := 'E';
                     x_status_message := 'Cannot create a Price Adjustment line';
                  END IF;

                  oe_debug_pub.debug_off;
               --               DBMS_OUTPUT.PUT_LINE ('Completion of API');
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     log_this (p_message       => 'Error applying adjustment ' || SQLERRM,
                               p_delivery_id   => l_order_line_id,
                               p_process       => 'apply_wb_freight_discount',
                               p_error_msg     => 'MIXED FREIGHT DISCOUNT WB_HAE');
               END;
            END IF;
         END IF;
      END IF;

      log_this (p_message       => 'END++:++ apply_wb_freight_discount procedure.',
                p_delivery_id   => l_order_line_id,
                p_process       => 'apply_wb_freight_discount');
   EXCEPTION
      WHEN OTHERS
      THEN
         log_this (p_message       => 'Error in apply_wb_freight_discount: ' || SQLERRM,
                   p_delivery_id   => l_order_line_id,
                   p_process       => 'apply_wb_freight_discount');
   END apply_wb_freight_discount;

   PROCEDURE log_this (p_message       IN VARCHAR2,
                       p_delivery_id   IN NUMBER DEFAULT NULL,
                       p_process       IN VARCHAR2,
                       p_error_Code    IN VARCHAR2 DEFAULT NULL,
                       p_error_msg     IN VARCHAR2 DEFAULT NULL)
   IS
      x_status     VARCHAR2 (2000) := '';
      l_sequence   NUMBER;
   BEGIN
      SELECT xxha_mixed_wb_log_seq.NEXTVAL INTO l_sequence FROM DUAL;

      DBMS_OUTPUT.put_line (
            'Delivery/Line ID: '
         || p_delivery_id
         || ' ::: Process: '
         || p_process
         || ' ::: Message: '
         || p_message
         || ' :::: Error: '
         || p_error_msg);

      SELECT xxha_mixed_wb_log_seq.NEXTVAL INTO l_sequence FROM DUAL;

      xxha_common_utilities_pkg.insert_error_prc (-99999,
                                                  l_sequence,
                                                  p_delivery_id,
                                                  p_error_Code,
                                                  p_error_msg,
                                                  p_message,
                                                  'MIXED_WB_PRICING_FORMULA',
                                                  p_process,
                                                  '',
                                                  '',
                                                  '',
                                                  '',
                                                  x_status);
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;

   FUNCTION get_equalized_weight (p_organization_code   IN VARCHAR2,
                                  p_zone                IN VARCHAR2,
                                  p_weight              IN NUMBER)
      RETURN NUMBER
   IS
      l_weight   NUMBER := 0;
   BEGIN
      SELECT tag
        INTO l_weight
        FROM fnd_lookup_values_vl
       WHERE     1 = 1
             AND lookup_type = 'MIX_FREIGHT_RATE_EQ_FACTOR'
             AND enabled_flag = 'Y'
             AND SYSDATE BETWEEN start_date_active AND NVL (end_date_active, SYSDATE + 1)
             AND description = TO_CHAR (p_weight)
             AND SUBSTR (LOOKUP_CODE,
                         1,
                         INSTR (LOOKUP_CODE,
                                '.',
                                1,
                                1)
                         - 1) = p_organization_code
             AND SUBSTR (LOOKUP_CODE,
                         INSTR (LOOKUP_CODE,
                                '.',
                                1,
                                1)
                         + 1,
                         ( (INSTR (LOOKUP_CODE,
                                   '.',
                                   2,
                                   2)
                            - 1)
                          - (INSTR (LOOKUP_CODE,
                                    '.',
                                    1,
                                    1)))) = p_zone;

      RETURN TO_NUMBER (l_weight);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END get_equalized_weight;


   FUNCTION get_handling_fee (p_handling_mode IN VARCHAR2)
      RETURN NUMBER
   IS
      l_handling_fee   NUMBER := 0;
   BEGIN
      SELECT TO_NUMBER (tag)
        INTO l_handling_fee
        FROM fnd_lookup_values_vl
       WHERE     1 = 1
             AND lookup_type = 'HAE_HANDLING_FEE'
             AND enabled_flag = 'Y'
             AND SYSDATE BETWEEN start_date_active AND NVL (end_date_active, SYSDATE + 1)
             AND lookup_code = p_handling_mode;

      RETURN l_handling_fee;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END get_handling_fee;

   FUNCTION is_container_type_defined (p_item_id NUMBER, p_org_id NUMBER)
      RETURN VARCHAR2
   IS
      l_cont_type   VARCHAR2 (200);
   BEGIN
      SELECT NVL (msi_org.container_type_code, msi_mst.container_type_code)
        INTO l_cont_type
        FROM mtl_system_items_b msi_org, mtl_system_items_b msi_mst
       WHERE     msi_org.inventory_item_id = p_item_id
             AND msi_org.organization_id = p_org_id
             AND msi_org.inventory_item_id = msi_mst.inventory_item_id
             AND msi_mst.organization_id = 103;

      IF l_cont_type IS NULL
      THEN
         RETURN 'N';
      ELSE
         RETURN 'Y';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'N';
   END;

   FUNCTION get_postal_zone (p_organization_code VARCHAR2, p_ship_to_postal_code VARCHAR2)
      RETURN VARCHAR2
   IS
      v_zone   fnd_lookup_values_vl.tag%TYPE;
   BEGIN
      SELECT tag
        INTO v_zone
        FROM fnd_lookup_values_vl
       WHERE     1 = 1
             AND lookup_type = 'FEDEX_GROUND_SHIPPING_ZONE'
             AND enabled_flag = 'Y'
             AND SYSDATE BETWEEN start_date_active AND NVL (end_date_active, SYSDATE + 1)
             AND INSTR (lookup_code, p_organization_code) = 1
             AND TO_CHAR (p_ship_to_postal_code) BETWEEN meaning AND description;

      --      DBMS_OUTPUT.put_line ('postal_zone: ' || v_zone);
      RETURN v_zone;
   EXCEPTION
      WHEN OTHERS
      THEN
         --         DBMS_OUTPUT.put_line ('defaulting postal_zone: DEFAULT.GROUND');
         RETURN 'DEFAULT.GROUND';
   END get_postal_zone;

   FUNCTION get_actual_weight (p_line_id IN NUMBER)
      RETURN NUMBER
   IS
      l_weight   NUMBER := 0;
   BEGIN
      SELECT DISTINCT DECODE (NVL (msi.container_type_code, weight.container_type_code),
                              NULL, NVL (inv_convert.inv_um_convert (
                                            item_id         => msi.inventory_item_id,
                                            PRECISION       => 9,
                                            from_quantity   => NVL (msi.unit_weight, 0),
                                            from_unit       => NVL (msi.weight_uom_code, 'Kg'),
                                            to_unit         => 'Lbs',
                                            from_name       => NULL,
                                            to_name         => NULL),
                                         0),
                              DECODE (this_ship_dtl.src_requested_quantity_uom,
                                      'Ea', DECODE (check_base_conv_rate (msi.inventory_item_id),
                                                    'Y', NVL (inv_convert.inv_um_convert (
                                                                 item_id         => msi.inventory_item_id,
                                                                 PRECISION       => 9,
                                                                 from_quantity   => NVL (
                                                                                      msi.unit_volume,
                                                                                      0),
                                                                 from_unit       => NVL (
                                                                                      msi.volume_uom_code,
                                                                                      'Kg'),
                                                                 to_unit         => 'Lbs',
                                                                 from_name       => NULL,
                                                                 to_name         => NULL),
                                                              0),
                                                    NVL (inv_convert.inv_um_convert (
                                                            item_id         => msi.inventory_item_id,
                                                            PRECISION       => 9,
                                                            from_quantity   => NVL (msi.unit_weight,
                                                                                    0),
                                                            from_unit       => NVL (
                                                                                 msi.weight_uom_code,
                                                                                 'Kg'),
                                                            to_unit         => 'Lbs',
                                                            from_name       => NULL,
                                                            to_name         => NULL),
                                                         0)),
                                      'Ca', NVL (inv_convert.inv_um_convert (
                                                    item_id         => msi.inventory_item_id,
                                                    PRECISION       => 9,
                                                    from_quantity   => NVL (msi.unit_volume, 0),
                                                    from_unit       => NVL (msi.volume_uom_code,
                                                                            'Kg'),
                                                    to_unit         => 'Lbs',
                                                    from_name       => NULL,
                                                    to_name         => NULL),
                                                 0),
                                      'DO', NVL (inv_convert.inv_um_convert (
                                                    item_id         => msi.inventory_item_id,
                                                    PRECISION       => 9,
                                                    from_quantity   => NVL (msi.unit_volume, 0),
                                                    from_unit       => NVL (msi.volume_uom_code,
                                                                            'Kg'),
                                                    to_unit         => 'Lbs',
                                                    from_name       => NULL,
                                                    to_name         => NULL),
                                                 0)))
        INTO l_weight
        FROM oe_order_lines_all ool,
             wsh_dlvb_dlvy_v this_shipment,
             wsh_delivery_details this_ship_dtl,
             mtl_system_items msi,
             mtl_system_items weight,
             hr_organization_units hou
       WHERE     ool.inventory_item_id = msi.inventory_item_id
             AND weight.organization_id = hou.organization_id
             AND weight.inventory_item_id = msi.inventory_item_id
             AND hou.NAME = 'Haemonetics Global Item Master'
             AND msi.organization_id = ool.ship_from_org_id
             AND this_ship_dtl.delivery_detail_id = this_shipment.delivery_detail_id
             AND this_ship_dtl.source_line_id = ool.line_id
             AND ool.line_id = p_line_id;

      RETURN NVL (l_weight, 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END get_actual_weight;

   /*  thisis the old wrking formula that returns act weight per line qty
   FUNCTION get_actual_weight (p_line_id IN NUMBER)
         RETURN NUMBER
      IS
         l_weight   NUMBER := 0;
      BEGIN
         SELECT DECODE (NVL (msi.container_type_code, weight.container_type_code),
                        NULL, NVL (inv_convert.inv_um_convert (
                                      item_id         => msi.inventory_item_id,
                                      PRECISION       => 9,
                                      from_quantity   => NVL (this_ship_dtl.src_requested_quantity, 0)
                                                        * NVL (msi.unit_weight, 0),
                                      from_unit       => NVL (msi.weight_uom_code, 'Kg'),
                                      to_unit         => 'Lbs',
                                      from_name       => NULL,
                                      to_name         => NULL),
                                   0),
                        DECODE (this_ship_dtl.src_requested_quantity_uom,
                                'Ea', DECODE (xxha_check_base_conv_rate (msi.inventory_item_id),
                                              'Y', NVL (inv_convert.inv_um_convert (
                                                           item_id         => msi.inventory_item_id,
                                                           PRECISION       => 9,
                                                           from_quantity   => (NVL (
                                                                                  this_ship_dtl.src_requested_quantity,
                                                                                  0)
                                                                               / xxha_get_base_conv_rate (
                                                                                    msi.inventory_item_id))
                                                                             * NVL (msi.unit_volume,
                                                                                    0),
                                                           from_unit       => NVL (msi.volume_uom_code,
                                                                                   'Kg'),
                                                           to_unit         => 'Lbs',
                                                           from_name       => NULL,
                                                           to_name         => NULL),
                                                        0),
                                              NVL (inv_convert.inv_um_convert (
                                                      item_id         => msi.inventory_item_id,
                                                      PRECISION       => 9,
                                                      from_quantity   => NVL (
                                                                           this_ship_dtl.src_requested_quantity,
                                                                           0)
                                                                        * NVL (msi.unit_weight, 0),
                                                      from_unit       => NVL (msi.weight_uom_code,
                                                                              'Kg'),
                                                      to_unit         => 'Lbs',
                                                      from_name       => NULL,
                                                      to_name         => NULL),
                                                   0)),
                                'Ca', NVL (inv_convert.inv_um_convert (
                                              item_id         => msi.inventory_item_id,
                                              PRECISION       => 9,
                                              from_quantity   => NVL (
                                                                   this_ship_dtl.src_requested_quantity,
                                                                   0)
                                                                * NVL (msi.unit_volume, 0),
                                              from_unit       => NVL (msi.volume_uom_code, 'Kg'),
                                              to_unit         => 'Lbs',
                                              from_name       => NULL,
                                              to_name         => NULL),
                                           0),
                                'DO', NVL (inv_convert.inv_um_convert (
                                              item_id         => msi.inventory_item_id,
                                              PRECISION       => 9,
                                              from_quantity   => NVL (
                                                                   this_ship_dtl.src_requested_quantity,
                                                                   0)
                                                                * NVL (msi.unit_volume, 0),
                                              from_unit       => NVL (msi.volume_uom_code, 'Kg'),
                                              to_unit         => 'Lbs',
                                              from_name       => NULL,
                                              to_name         => NULL),
                                           0)))
           INTO l_weight
           FROM oe_order_lines_all ool,
                wsh_dlvb_dlvy_v this_shipment,
                wsh_delivery_details this_ship_dtl,
                mtl_system_items msi,
                mtl_system_items weight,
                hr_organization_units hou
          WHERE     ool.inventory_item_id = msi.inventory_item_id
                AND weight.organization_id = hou.organization_id
                AND weight.inventory_item_id = msi.inventory_item_id
                AND hou.NAME = 'Haemonetics Global Item Master'
                AND msi.organization_id = ool.ship_from_org_id
                AND this_ship_dtl.delivery_detail_id = this_shipment.delivery_detail_id
                AND this_ship_dtl.source_line_id = ool.line_id
                AND ool.line_id = p_line_id;

         RETURN NVL (l_weight, 0);
      EXCEPTION
         WHEN OTHERS
         THEN
            RETURN 0;
      END get_actual_weight;*/
   FUNCTION get_minimum_weight (p_zone IN VARCHAR2)
      RETURN NUMBER
   IS
      v_zone         VARCHAR2 (100);
      v_min_weight   NUMBER;
   BEGIN
      SELECT TO_NUMBER (TAG)
        INTO v_min_weight
        FROM fnd_lookup_values_vl
       WHERE     1 = 1
             AND ENABLED_FLAG = 'Y'
             AND SYSDATE BETWEEN start_Date_active AND NVL (end_date_Active, SYSDATE + 1)
             AND lookup_type = 'FEDEX_SHIPPING_ZONE_MIN_WEIGHT'
             AND meaning = p_zone;

      g_shipment_min_weight := v_min_weight;
      RETURN v_min_weight;
   EXCEPTION
      WHEN OTHERS
      THEN
         g_shipment_min_weight := 0;
         --         DBMS_OUTPUT.put_line ('get_minimum_weight: vmin excp: ' || SQLERRM);
         RETURN 0;
   END get_minimum_weight;

   FUNCTION get_item_volume (p_item_id IN NUMBER)
      RETURN NUMBER
   IS
      l_case_volume   NUMBER := 0;
   BEGIN
      BEGIN
         SELECT ROUND (LENGTH) * ROUND (width) * ROUND (height)
           INTO l_case_volume
           FROM mtl_uom_conversions
          WHERE 1 = 1 AND unit_of_measure = 'Case' AND inventory_item_id = p_item_id;

         RETURN l_case_volume;
      EXCEPTION
         WHEN OTHERS
         THEN
            RETURN 0;                          -- mostly 0 but I have to confirm this scenario ---hk
      END;
   END get_item_volume;

   FUNCTION get_item_volume_nonr (p_item_id IN NUMBER)
      RETURN NUMBER
   IS
      l_case_volume   NUMBER := 0;
   BEGIN
      BEGIN
         SELECT LENGTH * width * height
           INTO l_case_volume
           FROM mtl_uom_conversions
          WHERE 1 = 1 AND unit_of_measure = 'Case' AND inventory_item_id = p_item_id;

         RETURN l_case_volume;
      EXCEPTION
         WHEN OTHERS
         THEN
            RETURN 0;                          -- mostly 0 but I have to confirm this scenario ---hk
      END;
   END get_item_volume_nonr;

   FUNCTION get_dimensional_weight (p_item_id NUMBER, p_org_id NUMBER, p_zone IN VARCHAR2)
      RETURN NUMBER
   IS
      l_cont_type           mtl_system_items_b.container_type_code%TYPE;
      l_case_volume         NUMBER;
      v_dim_weight_factor   NUMBER;
      v_dim_weight          NUMBER := 0;
   BEGIN
      BEGIN
         SELECT TO_NUMBER (TAG)
           INTO v_dim_weight_factor
           FROM fnd_lookup_values_vl
          WHERE     1 = 1
                AND ENABLED_FLAG = 'Y'
                AND SYSDATE BETWEEN start_Date_active AND NVL (end_date_Active, SYSDATE + 1)
                AND lookup_type = 'DIMENSIONAL_WEIGHT_FACTOR'
                AND meaning = p_zone;
      --         RETURN v_dim_weight_factor;
      EXCEPTION
         WHEN OTHERS
         THEN
            RETURN 0;
      END;

      l_case_volume := get_item_volume (p_item_id);             -- added this function hk 11/25/2014

      IF NVL (l_case_volume, 0) >= g_dim_weight_threshold
      THEN
         v_dim_weight := ROUND (l_case_volume / v_dim_weight_factor);
      ELSE
         RETURN 0;
      END IF;

      RETURN v_dim_weight;                                            -- multiply this with quantity
   END get_dimensional_weight;

   PROCEDURE set_dim_weight_threshold
   IS
   BEGIN
      SELECT TO_NUMBER (tag)
        INTO g_dim_weight_threshold
        FROM fnd_lookup_values_vl
       WHERE     1 = 1
             AND enabled_flag = 'Y'
             AND SYSDATE BETWEEN start_Date_active AND NVL (end_date_Active, SYSDATE + 1)
             AND lookup_type = 'DIMENSIONAL_WEIGHT_THRESHOLD'
             AND lookup_code = 'GROUND';
   EXCEPTION
      WHEN OTHERS
      THEN
         g_dim_weight_threshold := 1;
   END set_dim_weight_threshold;

   FUNCTION check_base_conv_rate (p_item_id IN NUMBER)
      RETURN VARCHAR2
   IS
      l_conv_rate   NUMBER;
   BEGIN
      SELECT conv.conversion_rate
        INTO l_conv_rate
        FROM MTL_UOM_CONVERSIONS conv, mtl_units_of_measure_vl uom
       WHERE     1 = 1
             AND p_item_id = conv.INVENTORY_ITEM_ID
             AND conv.uom_class = uom.uom_class
             AND uom.base_uom_flag = 'Y'
             AND conv.uom_code = 'Ca'
             AND UOM.UOM_CODE = 'Ea';

      IF l_conv_rate > 0
      THEN
         RETURN 'Y';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'N';
   END check_base_conv_rate;

   FUNCTION case_conversion_rate (p_item_id IN NUMBER, p_uom_from IN VARCHAR2)
      RETURN NUMBER
   IS
      l_conv_rate   NUMBER;
   BEGIN
      SELECT conv.conversion_rate
        INTO l_conv_rate
        FROM mtl_uom_conversions conv, mtl_units_of_measure_vl uom
       WHERE     1 = 1
             AND conv.inventory_item_id = p_item_id
             AND conv.uom_class = uom.uom_class
             AND uom.base_uom_flag = 'Y'
             AND conv.uom_code = 'Ca'
             AND uom.uom_code = p_uom_from;

      RETURN l_conv_rate;
   EXCEPTION
      --      WHEN NO_DATA_FOUND
      --      THEN
      --         RETURN NULL;
      WHEN OTHERS
      THEN
         RETURN NULL;
   END case_conversion_rate;

   PROCEDURE mixed_wb_weight_calc (p_line_id IN NUMBER, p_wb_ratio OUT NUMBER)
   IS
      CURSOR cur_lines
      IS
         SELECT ooh.header_id,
                ool.line_id,
                ool.line_number,
                msi.segment1 item_number,
                msi.inventory_item_id,
                mc.segment1 item_category,
                wnd.mode_of_transport,
                ship_from_org.organization_code,
                ship_from_org.organization_id,
                hl_ship.postal_code ship_to_postal_code,
                ool.ship_to_org_id,
                hrl_ship_from.postal_code ship_from_postal_code,
                '' postal_zone,
                '' actual_weight,
                '' minimum_weight,
                '' dimensional_weight,
                '' final_weight,
                '' max_weight,
                this_ship_dtl.requested_quantity,
                this_ship_dtl.requested_quantity_uom,
                NVL (msi.container_type_code, msi_mst.container_type_code) container_type_code
           FROM oe_order_headers_all ooh,
                oe_order_lines_all ool,
                wsh_delivery_details wdd,
                wsh_dlvb_dlvy_v freight_line,
                wsh_dlvb_dlvy_v this_shipment,
                wsh_delivery_details this_ship_dtl,
                wsh_new_deliveries wnd,
                wsh_delivery_assignments wda,
                mtl_system_items msi,
                mtl_item_categories mic,
                mtl_category_sets mcs,
                mtl_categories mc,
                hz_cust_site_uses_all hcs_ship,
                hz_cust_acct_sites_all hca_ship,
                hz_party_sites hps_ship,
                hz_parties hp_ship,
                hz_locations hl_ship,
                mtl_parameters ship_from_org,
                hr_locations_all hrl_ship_from,
                hr_organization_units hou,
                mtl_system_items msi_mst
          WHERE     1 = 1
                AND ool.header_id = ooh.header_id
                AND wdd.delivery_detail_id = freight_line.delivery_detail_id
                AND freight_line.delivery_id = this_shipment.delivery_id
                AND this_ship_dtl.delivery_detail_id = this_shipment.delivery_detail_id
                AND this_ship_dtl.source_line_id = ool.line_id
                AND wdd.source_line_id = p_line_id                                        -- 5100974
                AND wdd.source_header_id = ool.header_id
                AND wda.delivery_detail_id = wdd.delivery_detail_id
                AND wda.delivery_id = wnd.delivery_id
                AND msi.inventory_item_id = ool.inventory_item_id
                AND msi.organization_id = ool.ship_from_org_id
                AND mic.inventory_item_id = msi.inventory_item_id
                AND mic.organization_id = msi.organization_id
                AND mic.category_set_id = mcs.category_set_id
                AND mcs.category_set_name = 'Inventory'
                AND ool.ordered_item NOT IN ('FREIGHT', 'HANDLING')
                AND mc.category_id = mic.category_id
                AND msi_mst.inventory_item_id = ool.inventory_item_id
                AND msi_mst.organization_id = hou.organization_id
                AND hou.NAME = 'Haemonetics Global Item Master'
                AND ool.ship_to_org_id = hcs_ship.site_use_id
                AND hcs_ship.cust_acct_site_id = hca_ship.cust_acct_site_id
                AND hca_ship.party_site_id = hps_ship.party_site_id
                AND hps_ship.party_id = hp_ship.party_id
                AND hps_ship.location_id = hl_ship.location_id
                AND ool.ship_from_org_id = ship_from_org.organization_id
                AND hrl_ship_from.inventory_organization_id = ship_from_org.organization_id;

      TYPE order_rec IS RECORD
      (
         header_id                    oe_order_lines_all.header_id%TYPE,
         line_id                      oe_order_lines_all.line_id%TYPE,
         line_number                  oe_order_lines_all.line_number%TYPE,
         item_number                  mtl_system_items.segment1%TYPE,
         inventory_item_id            mtl_system_items.inventory_item_id%TYPE,
         item_category                mtl_categories.segment1%TYPE,
         mode_of_transport            wsh_delivery_details.mode_of_transport%TYPE,
         organization_code            mtl_parameters.organization_code%TYPE,
         ship_from_org_id             mtl_parameters.organization_id%TYPE,
         ship_to_postal_code          hz_locations.postal_code%TYPE,
         ship_to_org_id               mtl_parameters.organization_id%TYPE,
         ship_from_postal_code        hr_locations_all.postal_code%TYPE,
         postal_zone                  VARCHAR2 (100),
         actual_weight                NUMBER,
         minimum_weight               NUMBER,
         dimensional_weight           NUMBER,
         final_weight                 NUMBER,
         max_weight                   NUMBER,
         src_requested_quantity       wsh_delivery_details.src_requested_quantity%TYPE,
         src_requested_quantity_uom   wsh_delivery_details.src_requested_quantity_uom%TYPE,
         container_type_code          mtl_system_items.container_type_code%TYPE
      );

      TYPE order_tbl IS TABLE OF order_rec
                           INDEX BY BINARY_INTEGER;

      order_lines                order_tbl;

      l_wb_weight                NUMBER := 0;
      l_total_weight             NUMBER := 0;
      l_container_type_defined   VARCHAR2 (10);
      l_case_conversion_rate     NUMBER;
      l_ratio                    NUMBER := 0;
      l_dim_wt_per_case          NUMBER := 0;
      l_min_wt_per_case          NUMBER := 0;
      l_equilzation_factor       NUMBER := 0;
      l_max_weight_percase       NUMBER := 0;
      l_act_wt_per_case          NUMBER := 0;
   BEGIN
      g_shipment_min_weight := 0;
      set_dim_weight_threshold;

      log_this (p_message       => 'in mixed_wb_weight_calc',
                p_delivery_id   => p_line_id,
                p_process       => 'mixed_wb_weight_calc');

      OPEN cur_lines;

      FETCH cur_lines
      BULK COLLECT INTO order_lines;

      --      limit 10000;
      --      EXIT WHEN cur_lines%NOTFOUND;
      CLOSE cur_lines;

      IF order_lines.COUNT < 1
      THEN
         log_this (p_message       => 'cur_lines does not fetch lines',
                   p_delivery_id   => p_line_id,
                   p_process       => 'mixed_wb_weight_calc',
                   p_error_msg     => 'cur_lines does not fetch lines');
      END IF;

      FOR i IN order_lines.FIRST .. order_lines.LAST
      LOOP
         l_case_conversion_rate := '';
         l_dim_wt_per_case := 0;
         l_min_wt_per_case := 0;
         l_act_wt_per_case := 0;
         l_equilzation_factor := 0;
         l_max_weight_percase := 0;
         log_this (
            p_message       =>   '**Processing Line: '
                              || order_lines (i).line_number
                              || ' | Item Num: '
                              || order_lines (i).item_number
                              || ' | Line ID: '
                              || order_lines (i).line_id
                              || ' | Item ID: '
                              || order_lines (i).inventory_item_id
                              || ' | Category: '
                              || order_lines (i).item_category
                              || ' | Trans Mode: '
                              || order_lines (i).mode_of_transport
                              || ' | Org code: '
                              || order_lines (i).organization_code
                              || ' | Ship To ID: '
                              || order_lines (i).ship_to_org_id
                              || ' | Ship To zip: '
                              || order_lines (i).ship_to_postal_code
                              || ' | Qty: '
                              || order_lines (i).src_requested_quantity
                              || ' | UOM: '
                              || order_lines (i).src_requested_quantity_uom
                              || ' | Cont Code: '
                              || order_lines (i).container_type_code,
            p_delivery_id   => p_line_id,
            p_process       => 'mixed_wb_weight_calc');



         IF order_lines (i).src_requested_quantity_uom = 'Ca'
         THEN
            l_case_conversion_rate := 1;
         ELSE
            l_case_conversion_rate :=
               case_conversion_rate (order_lines (i).inventory_item_id,
                                     order_lines (i).src_requested_quantity_uom);
         END IF;

         log_this (p_message       => 'Case Conv rate (Case -> req UOM): ' || l_case_conversion_rate,
                   p_delivery_id   => p_line_id,
                   p_process       => 'mixed_wb_weight_calc');
         -- actual weight calc
         l_act_wt_per_case := CEIL (get_actual_weight (order_lines (i).line_id));
         order_lines (i).actual_weight :=
            (order_lines (i).src_requested_quantity
             / NVL (l_case_conversion_rate, order_lines (i).src_requested_quantity))
            * l_act_wt_per_case;


         IF UPPER (order_lines (i).mode_of_transport) = 'PARCEL'
         THEN
            order_lines (i).postal_zone :=
               get_postal_zone (order_lines (i).organization_code,
                                order_lines (i).ship_to_postal_code);

            log_this (p_message       => 'Postal Zone: ' || order_lines (i).postal_zone,
                      p_delivery_id   => p_line_id,
                      p_process       => 'mixed_wb_weight_calc');

            --minimum weight calc
            l_min_wt_per_case := get_minimum_weight (order_lines (i).postal_zone);
            order_lines (i).minimum_weight :=
               (order_lines (i).src_requested_quantity
                / NVL (l_case_conversion_rate, order_lines (i).src_requested_quantity))
               * l_min_wt_per_case;

            log_this (p_message       => 'Minimum Weight per case: ' || l_min_wt_per_case,
                      p_delivery_id   => p_line_id,
                      p_process       => 'mixed_wb_weight_calc');

            --dimnsional weight calc
            IF order_lines (i).container_type_code IS NOT NULL
            THEN
               l_dim_wt_per_case :=
                  get_dimensional_weight (order_lines (i).inventory_item_id,
                                          order_lines (i).ship_from_org_id,
                                          order_lines (i).postal_zone);
               log_this (p_message       => 'Dimensional Weight per case: ' || l_dim_wt_per_case,
                         p_delivery_id   => p_line_id,
                         p_process       => 'mixed_wb_weight_calc');
               order_lines (i).dimensional_weight :=
                  (order_lines (i).src_requested_quantity
                   / NVL (l_case_conversion_rate, order_lines (i).src_requested_quantity))
                  * l_dim_wt_per_case;
            ELSE
               order_lines (i).dimensional_weight := 0;
            END IF;
         ELSE
            log_this (
               p_message       => 'Mode of Transport is not Parcel. Defaulting DIM and MIN wts to 0',
               p_delivery_id   => p_line_id,
               p_process       => 'mixed_wb_weight_calc');
            order_lines (i).minimum_weight := 0;
            order_lines (i).dimensional_weight := 0;
         END IF;

         log_this (p_message       => 'Actual Weight per case: ' || l_act_wt_per_case,
                   p_delivery_id   => p_line_id,
                   p_process       => 'mixed_wb_weight_calc');
         order_lines (i).max_weight :=
            CEIL (GREATEST (NVL (order_lines (i).actual_weight, 0),
                            NVL (order_lines (i).minimum_weight, 0),
                            NVL (order_lines (i).dimensional_weight, 0),
                            g_shipment_min_weight));

         IF UPPER (order_lines (i).mode_of_transport) = 'PARCEL'
         THEN
            l_max_weight_percase :=
               ROUND (GREATEST (NVL (l_dim_wt_per_case, 0),
                                NVL (l_min_wt_per_case, 0),
                                NVL (l_act_wt_per_case, 0),
                                g_shipment_min_weight));

            l_equilzation_factor :=
               get_equalized_weight (order_lines (i).organization_code,
                                     order_lines (i).postal_zone,
                                     l_max_weight_percase);
            log_this (
               p_message       =>   'Max weight per case: '
                                 || l_max_weight_percase
                                 || ' | Equalization factor per case: '
                                 || l_equilzation_factor,
               p_delivery_id   => p_line_id,
               p_process       => 'mixed_wb_weight_calc');
         ELSE
            l_equilzation_factor := 0;
         END IF;


         order_lines (i).final_weight :=
            order_lines (i).max_weight + (l_equilzation_factor * order_lines (i).max_weight);

         l_total_weight := l_total_weight + order_lines (i).final_weight;

         IF order_lines (i).item_category = 'WB'
         THEN
            l_wb_weight := l_wb_weight + order_lines (i).final_weight;
         END IF;


         log_this (
            p_message       =>   '***Calculated Weights for this line::::: Item: '
                              || order_lines (i).item_number
                              || ' | act: '
                              || order_lines (i).actual_weight
                              || ' | min: '
                              || order_lines (i).minimum_weight
                              || ' | dim: '
                              || order_lines (i).dimensional_weight
                              || ' | max: '
                              || order_lines (i).max_weight
                              || ' |||| Final Weight for this line: '
                              || order_lines (i).final_weight,
            p_delivery_id   => p_line_id,
            p_process       => 'mixed_wb_weight_calc');
      END LOOP;

      log_this (
         p_message       =>   'Whole Blood weight: '
                           || l_wb_weight
                           || ' | Total Weight: '
                           || l_total_weight,
         p_delivery_id   => p_line_id,
         p_process       => 'mixed_wb_weight_calc');

      IF l_total_weight <> 0
      THEN
         p_wb_ratio := l_wb_weight / l_total_weight;
      ELSE
         p_wb_ratio := 0;
      END IF;

      log_this (p_message       => 'Whole Blood ratio: ' || p_wb_ratio,
                p_delivery_id   => p_line_id,
                p_process       => 'mixed_wb_weight_calc');
   EXCEPTION
      WHEN OTHERS
      THEN
         p_wb_ratio := 0;
         log_this (
            p_message       => 'Error in main exception of mixed_wb_weight_calc: ' || SQLERRM,
            p_delivery_id   => p_line_id,
            p_process       => 'mixed_wb_weight_calc',
            p_error_msg     => 'Error in main exception of mixed_wb_weight_calc: ' || SQLERRM);
   END mixed_wb_weight_calc;

   PROCEDURE mixed_wb_handling_calc (p_line_id IN NUMBER, p_handling_charge OUT NUMBER)
   IS
      CURSOR cur_lines
      IS
         SELECT DISTINCT
                ooh.header_id,
                ool.line_id,
                ool.line_number,
                msi.segment1 item_number,
                msi.inventory_item_id,
                mc.segment1 item_category,
                wnd.mode_of_transport,                                       --wdd.mode_of_transport
                ship_from_org.organization_code,
                ship_from_org.organization_id,
                ool.ship_to_org_id,
                this_ship_dtl.requested_quantity,
                this_ship_dtl.requested_quantity_uom,
                this_ship_dtl.src_requested_quantity,
                this_ship_dtl.src_requested_quantity_uom,
                NVL (msi.container_type_code, msi_mst.container_type_code) container_type_code,
                ool.unit_list_price,
                '' AS volume,
                '' AS no_of_cases
           FROM oe_order_headers_all ooh,
                oe_order_lines_all ool,
                wsh_delivery_details wdd,
                wsh_dlvb_dlvy_v freight_line,
                wsh_dlvb_dlvy_v this_shipment,
                WSH_DELIVERABLES_V this_ship_dtl,
                wsh_new_deliveries wnd,
                wsh_delivery_assignments wda,
                mtl_system_items msi,
                mtl_item_categories mic,
                mtl_category_sets mcs,
                mtl_categories mc,
                mtl_parameters ship_from_org,
                hr_organization_units hou,
                mtl_system_items msi_mst
          WHERE     1 = 1
                AND ool.header_id = ooh.header_id
                AND wdd.delivery_detail_id = freight_line.delivery_detail_id
                AND freight_line.delivery_id = this_shipment.delivery_id
                AND this_ship_dtl.delivery_detail_id = this_shipment.delivery_detail_id
                AND this_ship_dtl.source_line_id = ool.line_id
                AND wdd.source_line_id = p_line_id                                        -- 5447448
                AND wdd.source_header_id = ool.header_id
                AND wda.delivery_detail_id = wdd.delivery_detail_id
                AND wda.delivery_id = wnd.delivery_id
                AND msi.inventory_item_id = ool.inventory_item_id
                AND msi.organization_id = ool.ship_from_org_id
                AND mic.inventory_item_id = msi.inventory_item_id
                AND mic.organization_id = msi.organization_id
                AND mic.category_set_id = mcs.category_set_id
                AND mcs.category_set_name = 'Inventory'
                AND ool.ordered_item NOT IN ('FREIGHT', 'HANDLING')
                AND mc.category_id = mic.category_id
                AND msi_mst.inventory_item_id = ool.inventory_item_id
                AND msi_mst.organization_id = hou.organization_id
                AND hou.NAME = 'Haemonetics Global Item Master'
                AND ool.ship_from_org_id = ship_from_org.organization_id;

      TYPE order_rec IS RECORD
      (
         header_id                    oe_order_lines_all.header_id%TYPE,
         line_id                      oe_order_lines_all.line_id%TYPE,
         line_number                  oe_order_lines_all.line_number%TYPE,
         item_number                  mtl_system_items.segment1%TYPE,
         inventory_item_id            mtl_system_items.inventory_item_id%TYPE,
         item_category                mtl_categories.segment1%TYPE,
         mode_of_transport            wsh_delivery_details.mode_of_transport%TYPE,
         organization_code            mtl_parameters.organization_code%TYPE,
         ship_from_org_id             mtl_parameters.organization_id%TYPE,
         ship_to_org_id               mtl_parameters.organization_id%TYPE,
         requested_quantity           wsh_delivery_details.requested_quantity%TYPE,
         requested_quantity_uom       wsh_delivery_details.requested_quantity_uom%TYPE,
         src_requested_quantity       wsh_delivery_details.src_requested_quantity%TYPE,
         src_requested_quantity_uom   wsh_delivery_details.src_requested_quantity_uom%TYPE,
         container_type_code          mtl_system_items.container_type_code%TYPE,
         unit_list_price              oe_order_lines_all.unit_list_price%TYPE,
         volume                       NUMBER,
         no_of_cases                  NUMBER
      );

      TYPE order_tbl IS TABLE OF order_rec
                           INDEX BY BINARY_INTEGER;

      order_lines                 order_tbl;
      l_case_conversion_rate      NUMBER;
      l_mode_of_transport         VARCHAR2 (200);
      l_wb_volume                 NUMBER;
      l_total_volume              NUMBER;
      l_total_cases               NUMBER;
      l_wb_cases                  NUMBER;
      l_handling_list_price       oe_order_lines_all.unit_list_price%TYPE;
      l_discount_percent          NUMBER;
      l_handling_fee_per_pallet   NUMBER;
   BEGIN
      log_this (p_message       => 'in mixed_wb_handling_calc',
                p_delivery_id   => p_line_id,
                p_process       => 'mixed_wb_handling_calc');

      BEGIN
         OPEN cur_lines;

         FETCH cur_lines
         BULK COLLECT INTO order_lines;

         --      limit 10000;
         --      EXIT WHEN cur_lines%NOTFOUND;
         CLOSE cur_lines;
      EXCEPTION
         WHEN OTHERS
         THEN
            log_this (p_message       => 'Cursor error: ' || SQLERRM,
                      p_delivery_id   => p_line_id,
                      p_process       => 'mixed_wb_handling_calc');
      END;

      l_total_volume := 0;
      l_wb_volume := 0;
      l_wb_cases := 0;
      l_total_cases := 0;

      SELECT unit_list_price
        INTO l_handling_list_price
        FROM oe_order_lines_all ool
       WHERE 1 = 1 AND line_id = p_line_id;

      FOR i IN order_lines.FIRST .. order_lines.LAST
      LOOP
         l_case_conversion_rate := '';
         log_this (
            p_message       =>   '**Processing Line: '
                              || order_lines (i).line_number
                              || ' | Item Num: '
                              || order_lines (i).item_number
                              || ' | Line ID: '
                              || order_lines (i).line_id
                              || ' | Item ID: '
                              || order_lines (i).inventory_item_id
                              || ' | Category: '
                              || order_lines (i).item_category
                              || ' | Trans Mode: '
                              || order_lines (i).mode_of_transport
                              || ' | Org code: '
                              || order_lines (i).organization_code
                              || ' | Ship To ID: '
                              || order_lines (i).ship_to_org_id
                              || ' | Req Qty: '
                              || order_lines (i).requested_quantity
                              || ' | Req UOM: '
                              || order_lines (i).requested_quantity_uom
                              || ' | Cont Code: '
                              || order_lines (i).container_type_code
                              || ' | List Price: '
                              || order_lines (i).unit_list_price,
            p_delivery_id   => p_line_id,
            p_process       => 'mixed_wb_handling_calc');



         IF order_lines (i).requested_quantity_uom = 'Ca'
         THEN
            l_case_conversion_rate := 1;
         ELSE
            l_case_conversion_rate :=
               case_conversion_rate (order_lines (i).inventory_item_id,
                                     order_lines (i).requested_quantity_uom);
         END IF;

         log_this (p_message       => 'Case Conv rate (Case -> req UOM): ' || l_case_conversion_rate,
                   p_delivery_id   => p_line_id,
                   p_process       => 'mixed_wb_handling_calc');

         IF UPPER (order_lines (i).mode_of_transport) = 'LTL'
         THEN
            l_mode_of_transport := 'LTL';
            order_lines (i).volume :=
               get_item_volume_nonr (order_lines (i).inventory_item_id)
               * (order_lines (i).requested_quantity
                  / NVL (l_case_conversion_rate, order_lines (i).requested_quantity));

            l_total_volume := order_lines (i).volume + l_total_volume;

            IF order_lines (i).item_category = 'WB'
            THEN
               l_wb_volume := l_wb_volume + order_lines (i).volume;
            END IF;

            log_this (
               p_message       =>   '***Calculated units for this line::::: Item: '
                                 || order_lines (i).item_number
                                 || ' | volume: '
                                 || order_lines (i).volume,
               p_delivery_id   => p_line_id,
               p_process       => 'mixed_wb_handling_calc');
         ELSIF UPPER (order_lines (i).mode_of_transport) = 'PARCEL'
         THEN
            l_mode_of_transport := 'PARCEL';
            order_lines (i).no_of_cases :=
               (order_lines (i).requested_quantity
                / NVL (l_case_conversion_rate, order_lines (i).requested_quantity));

            IF order_lines (i).item_category = 'WB'
            THEN
               l_wb_cases := l_wb_cases + order_lines (i).no_of_cases;
            END IF;

            l_total_cases := l_total_cases + order_lines (i).no_of_cases;
            log_this (
               p_message       =>   '***Calculated units for this line::::: Item: '
                                 || order_lines (i).item_number
                                 || ' | cases: '
                                 || order_lines (i).no_of_cases,
               p_delivery_id   => p_line_id,
               p_process       => 'mixed_wb_handling_calc');
         END IF;
      --         log_this (p_message       => 'Actual Weight er case: ' || l_act_wt_per_case,
      --                   p_delivery_id   => p_line_id,
      --                   p_process       => 'mixed_wb_handling_calc');

      END LOOP;


      log_this (p_message       => 'Delivery Mode of trasport: ' || l_mode_of_transport,
                p_delivery_id   => p_line_id,
                p_process       => 'mixed_wb_handling_calc');

      IF l_mode_of_transport = 'LTL'
      THEN
         l_handling_fee_per_pallet := get_handling_fee ('LTL.PALLET');

         BEGIN
            l_discount_percent := l_wb_volume / l_total_volume;
            p_handling_charge :=
               (CEIL (
                   (l_handling_list_price - (l_handling_list_price * l_discount_percent))
                   / l_handling_fee_per_pallet))
               * l_handling_fee_per_pallet;
         EXCEPTION
            WHEN OTHERS
            THEN
               NULL;
         END;

         log_this (
            p_message       =>   '******Calculated units for this delivery::::: '
                              || 'Handling Fee Per Pallet: '
                              || l_handling_fee_per_pallet
                              || ' | Discount Percent: '
                              || l_discount_percent
                              || ' | WB Volume: '
                              || l_wb_volume
                              || ' |Total Volume: '
                              || l_total_volume
                              || ' | List Price: '
                              || l_handling_list_price
                              || ' | Handling Charge: '
                              || p_handling_charge,
            p_delivery_id   => p_line_id,
            p_process       => 'mixed_wb_handling_calc');
      ELSIF l_mode_of_transport = 'PARCEL'
      THEN
         l_discount_percent := l_wb_cases / l_total_cases;
         p_handling_charge := l_handling_list_price - (l_discount_percent * l_handling_list_price);

         log_this (
            p_message       =>   '******Calculated units for this PARCEL delivery::::: '
                              || ' | Discount Percent: '
                              || l_discount_percent
                              || ' | WB Cases: '
                              || l_wb_cases
                              || ' |Total Cases: '
                              || l_total_cases
                              || ' | List Price: '
                              || l_handling_list_price
                              || ' | Handling Charge: '
                              || p_handling_charge,
            p_delivery_id   => p_line_id,
            p_process       => 'mixed_wb_handling_calc');
      END IF;
   --      return l_handling_charge;


   EXCEPTION
      WHEN OTHERS
      THEN
         p_handling_charge := l_handling_list_price;
         log_this (
            p_message       => 'Error in main exception of mixed_wb_handling_calc: ' || SQLERRM,
            p_delivery_id   => p_line_id,
            p_process       => 'mixed_wb_handling_calc',
            p_error_msg     => 'Error in main exception of mixed_wb_handling_calc: ' || SQLERRM);
   END mixed_wb_handling_calc;

   PROCEDURE initialize_session
   IS
      v_application_id           fnd_application.application_id%TYPE;
      v_user_responsibility_id   fnd_responsibility_vl.responsibility_id%TYPE;
      v_user_id                  fnd_user.user_id%TYPE;
   BEGIN
      mo_global.init ('ONT');

      BEGIN
         SELECT application_id
           INTO v_application_id
           FROM fnd_application
          WHERE application_short_name = 'ONT';

         SELECT responsibility_id
           INTO v_user_responsibility_id
           FROM fnd_responsibility_vl
          WHERE responsibility_name = 'WW Order Management Super User OC';

         SELECT user_id
           INTO v_user_id
           FROM fnd_user
          WHERE user_name = 'WEBMETHODS';
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;

      fnd_global.apps_initialize (v_user_id, v_user_responsibility_id, v_application_id);
   EXCEPTION
      WHEN OTHERS
      THEN
         log_this (p_message       => 'Error in initialize_session: ' || SQLERRM,
                   p_delivery_id   => 1,
                   p_process       => 'initialize_session',
                   p_error_msg     => 'Error in initialize_session: ' || SQLERRM);
   END initialize_session;


   PROCEDURE get_modifier_list (p_freight_item_id      IN     NUMBER,
                                p_mod_list_header_id      OUT NUMBER,
                                p_mod_list_line_id        OUT NUMBER)
   IS
      l_mod_list_header_id   NUMBER;
      l_mod_list_line_id     NUMBER;
   BEGIN
      SELECT qph.list_header_id, qpl.list_line_id
        INTO p_mod_list_header_id, p_mod_list_line_id
        FROM qp_list_headers_tl qph, qp_list_lines qpl, qp_pricing_attributes qpa
       WHERE     qph.name = 'MIXED FREIGHT DISCOUNT WB_HAE'
             AND qph.language = 'US'
             AND qph.list_header_id = qpl.list_header_id
             AND qpl.list_line_id = qpa.list_line_id
             AND qpa.product_attr_value = TO_CHAR (p_freight_item_id);
   EXCEPTION
      WHEN OTHERS
      THEN
         log_this (p_message       => 'Error finding WB Pricelist',
                   p_delivery_id   => p_freight_item_id,
                   p_process       => 'get_price_lists',
                   p_error_msg     => 'MIXED FREIGHT DISCOUNT WB_HAE');
   END get_modifier_list;



   --hkollipara 11/21/2014 code changes for handling modifier
   PROCEDURE apply_wb_handling_discount (p_delivery_id      IN     NUMBER,
                                         x_status_code         OUT VARCHAR2,
                                         x_status_message      OUT VARCHAR2)
   IS
   BEGIN
      NULL;
   END apply_wb_handling_discount;
END xxha_custom_price_modifer_pkg;
/
