CREATE OR REPLACE package XXHA_SUBINV_PROCESS_OHB
-- +===========================================================================+
-- | Name        : XXHA_SUBINV_PROCESS_OHB                                     |
-- | Purpose     : Support the conversion of Item business object into EBS.    |
-- |                                                                           |
-- | Description : For this conversion, an object includes the item, item      |
-- |               assignments at organizations (including master [MST]),      |
-- |               item revisions and item category (primary classification    |
-- |               on MST item only).                                          |
-- |               
-- |               Staged data is validated.  If all data is succcessfully     |
-- |               validated, the item objects are then moved to the open      |
-- |               interface tables.  If a single failure is detected, no      |
-- |               item objects are interfaced and an error report is launched |
-- |               as a separate concurrent request.                           |
-- |                                                                           |
-- |               Note: All or nothing approach!!                             |
-- |                                                                           |
-- | Comment     : This package interfaces item objects, it does not launch    |
-- |               standard Import Items program.  This must be done manually. |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- |                                                                           |
-- +===========================================================================+
AS

PROCEDURE issue_ohb_serial
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
		,p_org_code varchar2
		,p_subinventory_code varchar2
        );

PROCEDURE issue_ohb_non_serial
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
		,p_org_code varchar2
		,p_subinventory_code varchar2
        );	
Procedure receipt_ohb_serial(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );		
Procedure receipt_ohb_non_serial(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );		
procedure pre_rcpt_run_val 
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );
procedure  post_issue_run_val
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );
procedure clean_interface_tbl(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );						
end XXHA_SUBINV_PROCESS_OHB;
/


CREATE OR REPLACE package body      XXHA_SUBINV_PROCESS_OHB
as
-- +===========================================================================+
-- | Name        : XXHA_SUBINV_PROCESS_OHB                                    |
-- | Purpose     : Support the conversion of Item business object into EBS.    |
-- |                                                                           |
-- | Description : For this conversion, an object includes the item, item      |
-- |               assignments at organizations (including master [MST]),      |
-- |               item revisions and item category (primary classification    |
-- |               of MST item.                                                |
-- |                                                 |
-- |               Staged data is validated.  If all data is succcessfully     |
-- |               validated, the item objects are then moved to the open      |
-- |               interface tables.  If a single failure is detected, no      |
-- |               item objects are interfaced and an error report is launched |
-- |               as a separate concurrent request.                           |
-- |                                                                           |
-- |               Note: All or nothing approach!!                             |
-- |                                                                           |
-- | Comment     : This package interfaces item objects, it does not launch    |
-- |               standard Import Items program.  This must be done manually. |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- |15-Jun-2009 1.1 Palash Kundu Changed the program to pick the correct First |
-- | segment for the account string                                            |
-- +===========================================================================+


procedure log_error (org_id number,org_code varchar2,error_code varchar2,error_msg varchar2,comments varchar2)
		          is
		l_status varchar2 (2000);		  
		begin
		 
		   xxha_common_utilities_pkg.insert_error_prc(
		                             fnd_global.CONC_REQUEST_ID
		                            ,org_id
		                            ,org_code
		                            ,error_code
		                            ,error_msg
		                            ,comments
		                            ,''
		                            ,''
		                            ,''
		                            ,''
		                            ,''
		                            ,''
		                            ,l_status
		                            );

		
		   
end log_error;

procedure clean_interface_tbl(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ) 
is

begin
delete from mtl_serial_numbers_interface where source_code in ('Ph1 OHB Cleanup SINV Issue','Ph1 OHB Cleanup SINV Issue2','Ph1 OHB Cleanup SINV RCPT','Ph1 OHB Cleanup SINV RCPT2');
commit;
delete from mtl_transaction_lots_interface where source_code in ('Ph1 OHB Cleanup SINV Issue','Ph1 OHB Cleanup SINV Issue2','Ph1 OHB Cleanup SINV RCPT','Ph1 OHB Cleanup SINV RCPT2');
commit;
delete from mtl_transactions_interface where source_code in ('Ph1 OHB Cleanup SINV Issue','Ph1 OHB Cleanup SINV Issue2','Ph1 OHB Cleanup SINV RCPT','Ph1 OHB Cleanup SINV RCPT2');
commit;
end;
procedure pre_rcpt_run_val 
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
IS
cursor c_chk_err is
select distinct transaction_interface_id from XXHA_MTL_TRANSACTIONS_INT_STG
where error_code = 'VS_ISSUE'
;

cursor c_chk_int_err (q_transaction_interface_id number) is
select distinct transaction_interface_id,error_explanation 
from MTL_TRANSACTIONS_INTERFACE
where transaction_interface_id = q_transaction_interface_id
;
l_error_explanation varchar2 (2000);
l_error_code varchar2 (240);
begin
  for v_chk_err in c_chk_err loop
    l_error_explanation := null;
	l_error_code := 'PS_ISSUE';
    for v_chk_int_err in c_chk_int_err(v_chk_err.transaction_interface_id) loop
	  l_error_explanation := v_chk_int_err.error_explanation;
	  l_error_code := 'ERR_ISSUE';
	end loop;
	update xxha_mtl_transactions_int_stg
	set error_code = l_error_code,
	error_explanation = l_error_explanation
	where transaction_interface_id = v_chk_err.transaction_interface_id
	;
  end loop;
  commit;
end;

procedure  post_issue_run_val
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
IS
cursor c_chk_acct_period is
select distinct organization_id from XXHA_MTL_TRANSACTIONS_INT_STG
;
l_inv_acct_period_status varchar2 (2000);
l_org_code varchar2 (2000);
begin
  for v_chk_acct_period in c_chk_acct_period loop
    select  status
	into l_inv_acct_period_status
	from ORG_ACCT_PERIODS_V per
	where organization_id = v_chk_acct_period.organization_id
	and sysdate between start_date and end_date
	; 
	select organization_code
	into l_org_code
	from mtl_parameters
	where organization_id = v_chk_acct_period.organization_id
	;
	IF l_inv_acct_period_status != 'Open' THEN
	 log_error (v_chk_acct_period.organization_id,l_org_code,'XXHA_SINV_OHB_ERROR','ACCT Period is not Open','Accounting Period is Not Open');
	END IF;
  end loop;
end;

PROCEDURE issue_ohb_serial
         (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
		,p_org_code varchar2
		,p_subinventory_code varchar2
        )
IS
  
  cursor c_ohb_ser is
select organization_code,items.segment1 item_number,items.description item_description,primary_uom_code,ser.inventory_item_id,last_transaction_id trx_id,ser.current_organization_id organization_id,'1' transaction_quantity,current_subinventory_code subinventory_code,revision,current_locator_id locator_id, lot_number
,serial_number fr_serial_number,serial_number to_serial_number--,ser.*
,decode(serial_number_control_code,1,'No serial number control',2,'Predefined serial numbers',5,'Dynamic entry at inventory receipt',6,'Dynamic entry at sales order issue') oracle_Serial_Control
from mtl_serial_numbers ser,mtl_parameters param,mtl_system_items items
where ser.current_organization_id = param.organization_id
and items.inventory_item_id = ser.inventory_item_id
and current_status = 3
--and items.segment1 = '06002-110-NA-EW'
--and organization_code = 'BTO'
and items.serial_number_control_code in (5)
and items.organization_id = ser.current_organization_id
and organization_code||current_subinventory_code like
p_org_code||p_subinventory_code
/*('JPL%HP%P%M')
or
organization_code||current_subinventory_code like
('JPL%BC%P%M')
or organization_code||current_subinventory_code 
in
('ATOFG'
,'ATSDEPOTFR'
,'ATSMRB'
,'ATSParts'
,'ATSRepaired'
,'ATVFG'
,'AVOFG'
,'AVOMRB'
,'AVOStage'
,'BESDEPOTFR'
,'BESFSE001'
,'BESMRB'
,'BTOFG'
,'BTOMRB'
,'GSOFG'
,'BTORETURNS'
,'BTSDEP001'
,'BTSFSE001'
,'BTSFSE002'
,'BTSFSE003'
,'BTSFSE004'
,'BTSFSE005'
,'BTSFSE006'
,'BTSFSE008'
,'BTSFSE009'
,'BTSFSE010'
,'BTSFSE011'
,'BTSFSE012'
,'BTSFSE013'
,'BTSFSE014'
,'BTSFSE015'
,'BTSFSE016'
,'BTSFSE017'
,'BTSFSE018'
,'BTSFSE019'
,'BTSFSE020'
,'BTSFSE021'
,'BTSFSE022'
,'BTSFSE023'
,'BTSMFGWHSE'
,'BTSMRB'
,'BTSMRB-CParts'
,'BTSParts'
,'BTSRTS'
,'BTSRepaired'
,'BTSStage'
,'CHOFG'
,'CHSDEPOTFR'
,'CHSFSE001'
,'CHSFSE002'
,'CHSMRB'
,'CHSParts'
,'CHSRepaired'
,'CN1FSE001'
,'CN1FSE002'
,'CN1FSE003'
,'CN1MRB'
,'CN1Parts'
,'CN1Repaired'
,'CN1Stage'
,'CN2FSE001'
,'CN2MRB'
,'CN2Parts'
,'CN2Repaired'
,'CN2Stage'
,'CN3FSE001'
,'CN3MRB'
,'CN3Parts'
,'CN3Repaired'
,'CN3Stage'
,'CNOFG'
,'CNOStage'
,'CNSBeijing'
,'CNSChengDu'
,'CNSFSE005'
,'CNSGuangzhou'
,'CNSParts'
,'CNSRepaired'
,'CNSStage'
,'CZOFG'
,'CZOStage'
,'CZSDEPOTFR'
,'CZSFSE001'
,'CZSFSE002'
,'CZSParts'
,'CZSRepaired'
,'CZVFG'
,'DESDEPOTFR'
,'DESFSE001'
,'DESFSE002'
,'DESFSE003'
,'DESFSE004'
,'DESFSE005'
,'DESFSE006'
,'DESFSE007'
,'DESFSE008'
,'DESFSE009'
,'DESFSE010'
,'DESFSE011'
,'DESFSE012'
,'DESFSE013'
,'DESFSE014'
,'DESMRB'
,'DESParts'
,'DESRepaired'
,'DESStage'
,'DEVFG'
,'EDCFG'
,'EDCFG-DIST'
,'EDCSTRATEGIC'
,'EDCStage'
,'FROFG'
,'FROStage'
,'FRSDEP001'
,'FRSFSE001'
,'FRSFSE002'
,'FRSFSE003'
,'FRSFSE004'
,'FRSFSE005'
,'FRSFSE006'
,'FRSFSE007'
,'FRSFSE008'
,'FRSFSE009'
,'FRSFSE010'
,'FRSFSE011'
,'FRSMRB'
,'FRSParts'
,'FRSRepaired'
,'FRSStage'
,'FRVFG'
,'GBOFG'
,'GBSDEPOTFR'
,'GBSFSE001'
,'GBSFSE002'
,'GBSFSE003'
,'GBSMRB'
,'GBSParts'
,'GBSRepaired'
,'GBSStage'
,'GBXFG'
,'GBXStage'
,'HKOFG'
,'HKSFSE001'
,'HKSParts'
,'HKSRepaired'
,'HKSStage'
,'HMOFG'
,'HMSFSE001'
,'HMSMRB'
,'HMSParts'
,'ILOFG'
,'ITSDEPOTFR'
,'ITSFSE001'
,'ITSFSE002'
,'ITSFSE003'
,'ITSFSE004'
,'ITSFSE008'
,'ITSFSE009'
,'ITSFSE011'
,'ITSFSE013'
,'ITSFSE014'
,'ITSFSE015'
,'ITSFSE016'
,'ITSFSE017'
,'ITSFSE018'
,'ITSMRB'
,'ITSParts'
,'ITSRepaired'
,'ITVFG'
,'JPCFG'
,'JPLFukuoka'
,'JPLHPWH'
,'JPLHemonex'
,'JPLHiroshima'
,'JPLKanazawa'
,'JPLLogistics'
,'JPLNagoya'
,'JPLOsaka'
,'JPLQA'
,'JPLSapporo'
,'JPLSendai'
,'JPLTokyo'
,'JPOBox Change'
,'JPOClassify'
,'JPOFG'
,'JPOFraction'
,'JPOInspection'
,'JPOKLS Damage'
,'JPOLimit A'
,'JPOLimit B'
,'JPOLimit D'
,'JPOMRB Damage'
,'JPOOsaka'
,'JPOPO Return'
,'JPOQuality'
,'JPOSO Return'
,'JPOSampling'
,'JPOShipped'
,'JPOStage'
,'JPOStop'
,'JPOTokyo'
,'JPOYamanashi'
,'JPSDEP001'
,'JPSFSE001'
,'JPSFSE002'
,'JPSFSE004'
,'JPSFSE008'
,'JPSFSE010'
,'JPSFSE013'
,'JPSFSE014'
,'JPSFSE017'
,'JPSFSE018'
,'JPSFSE019'
,'JPSFSE022'
,'JPSFSE023'
,'JPSFSE024'
,'JPSFSE025'
,'JPSFSE026'
,'JPSFSE032'
,'JPSFSE033'
,'JPSFSE036'
,'JPSFSE038'
,'JPSFSE039'
,'JPSFSE040'
,'JPSFSE041'
,'JPSFSE042'
,'JPSParts'
,'JPSTOKYO'
,'JPSVENDOR'
,'MSOFG'
,'MSOMRB'
,'NLSDEPOTFR'
,'NLSFSE001'
,'NLSFSE002'
,'NLSFSE004'
,'NLSFSE005'
,'NLSMRB'
,'NLSParts'
,'NLSRepaired'
,'PTO1OHIOW'
,'PTOFG'
,'PTOMRB'
,'PTORETURNS'
,'PTOUnallocate'
,'SESDEPOTFR'
,'SESFSE001'
,'SESFSE002'
,'SESMRB'
,'SESParts'
,'SESRepaired'
,'SEVFG'
,'SEVMRB'
,'SIOFG'
,'STOFG'
,'STOIntran RAW'
,'STOIntran WIP'
,'STOIntrans FG'
,'STOMRB'
,'STORAW'
,'STORTS'
,'STORefurb FG'
,'STOStage'
,'STOWIP'
,'TWOFG'
,'TWSFSE003'
,'TWSKaohsiung'
,'TWSParts'
,'TWSRepaired'
,'UNOFG'
,'USEFG'
,'USEIntrans FG'
,'USEMRB'
,'USEStage'
))*/
;

  lc_material_transactions_id number;
 l_uom_code varchar2 (2000);
 l_cc_id number; 
BEGIN
 select code_combination_id
 into l_cc_id 
from gl_code_combinations_KFV
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000'
;	   
  FOR v_get_ohb in c_ohb_ser LOOP
  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;
 	 
		 
 /* select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;
*/
l_uom_code := v_get_ohb.primary_uom_code;
--FOR v_get_serial IN c_get_serial(v_get_ohb.create_transaction_id) LOOP
INSERT INTO mtl_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
													  ,to_serial_number
													  ,source_code
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,fnd_global.user_id
                                                     ,SYSDATE
                                                     ,fnd_global.user_id
                                                     ,lc_material_transactions_id
                                                     ,v_get_ohb.fr_serial_number
													 ,v_get_ohb.to_serial_number
													 ,'Ph1 OHB Cleanup SINV Issue'
                                                     );
INSERT INTO xxha_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
													  ,to_serial_number
													  ,source_code
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,fnd_global.user_id
                                                     ,SYSDATE
                                                     ,fnd_global.user_id
                                                     ,lc_material_transactions_id
                                                     ,v_get_ohb.fr_serial_number
													 ,v_get_ohb.to_serial_number
													 ,'Ph1 OHB Cleanup SINV Issue'
                                                     );
--END LOOP;													 													 


IF v_get_ohb.lot_number is not null then
 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,''
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV Issue'
                                                       );
													   
													   INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,''
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV Issue'
                                                       );

end if;

    insert into XXHA_MTL_TRANSACTIONS_INT_STG
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
													,error_code
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
												   ,'VS_ISSUE'
                                                  );

  
insert into mtl_transactions_interface
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV Issue'--'OHB Lot Control Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
  
  END LOOP;

commit;


  

END;		

PROCEDURE issue_ohb_non_serial
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
		,p_org_code varchar2
		,p_subinventory_code varchar2
        )
IS

cursor c_ohb is
select organization_code,items.segment1 item_number,items.description item_description,ohb.inventory_item_id,create_transaction_id,ohb.organization_id,transaction_quantity,subinventory_code,ohb.revision,locator_id,ohb.lot_number 
,expiration_date--,serial_number
from mtl_onhand_quantities ohb,mtl_system_items items,mtl_parameters param
,mtl_lot_numbers lot
--,mtl_serial_numbers ser
where 1=1
and items.inventory_item_id = ohb.inventory_item_id
and items.organization_id = ohb.organization_id
and items.serial_number_control_code not in (5)
and items.organization_id = param.organization_id
and lot.inventory_item_id(+) = ohb.inventory_item_id
and lot.organization_id(+) = ohb.organization_id
and lot.lot_number(+) = ohb.lot_number
--and ser.last_transaction_id(+) = ohb.create_transaction_id
and organization_code||subinventory_code like p_org_code||p_subinventory_code
/*('JPL%HP%P%M')
or
organization_code||subinventory_code like
('JPL%BC%P%M')
or organization_code||subinventory_code in
('ATOFG'
,'ATSDEPOTFR'
,'ATSMRB'
,'ATSParts'
,'ATSRepaired'
,'ATVFG'
,'AVOFG'
,'AVOMRB'
,'AVOStage'
,'GSOFG'
,'BESDEPOTFR'
,'BESFSE001'
,'BESMRB'
,'BTOFG'
,'BTOMRB'
,'BTORETURNS'
,'BTSDEP001'
,'BTSFSE001'
,'BTSFSE002'
,'BTSFSE003'
,'BTSFSE004'
,'BTSFSE005'
,'BTSFSE006'
,'BTSFSE008'
,'BTSFSE009'
,'BTSFSE010'
,'BTSFSE011'
,'BTSFSE012'
,'BTSFSE013'
,'BTSFSE014'
,'BTSFSE015'
,'BTSFSE016'
,'BTSFSE017'
,'BTSFSE018'
,'BTSFSE019'
,'BTSFSE020'
,'BTSFSE021'
,'BTSFSE022'
,'BTSFSE023'
,'BTSMFGWHSE'
,'BTSMRB'
,'BTSMRB-CParts'
,'BTSParts'
,'BTSRTS'
,'BTSRepaired'
,'BTSStage'
,'CHOFG'
,'CHSDEPOTFR'
,'CHSFSE001'
,'CHSFSE002'
,'CHSMRB'
,'CHSParts'
,'CHSRepaired'
,'CN1FSE001'
,'CN1FSE002'
,'CN1FSE003'
,'CN1MRB'
,'CN1Parts'
,'CN1Repaired'
,'CN1Stage'
,'CN2FSE001'
,'CN2MRB'
,'CN2Parts'
,'CN2Repaired'
,'CN2Stage'
,'CN3FSE001'
,'CN3MRB'
,'CN3Parts'
,'CN3Repaired'
,'CN3Stage'
,'CNOFG'
,'CNOStage'
,'CNSBeijing'
,'CNSChengDu'
,'CNSFSE005'
,'CNSGuangzhou'
,'CNSParts'
,'CNSRepaired'
,'CNSStage'
,'CZOFG'
,'CZOStage'
,'CZSDEPOTFR'
,'CZSFSE001'
,'CZSFSE002'
,'CZSParts'
,'CZSRepaired'
,'CZVFG'
,'DESDEPOTFR'
,'DESFSE001'
,'DESFSE002'
,'DESFSE003'
,'DESFSE004'
,'DESFSE005'
,'DESFSE006'
,'DESFSE007'
,'DESFSE008'
,'DESFSE009'
,'DESFSE010'
,'DESFSE011'
,'DESFSE012'
,'DESFSE013'
,'DESFSE014'
,'DESMRB'
,'DESParts'
,'DESRepaired'
,'DESStage'
,'DEVFG'
,'EDCFG'
,'EDCFG-DIST'
,'EDCSTRATEGIC'
,'EDCStage'
,'FROFG'
,'FROStage'
,'FRSDEP001'
,'FRSFSE001'
,'FRSFSE002'
,'FRSFSE003'
,'FRSFSE004'
,'FRSFSE005'
,'FRSFSE006'
,'FRSFSE007'
,'FRSFSE008'
,'FRSFSE009'
,'FRSFSE010'
,'FRSFSE011'
,'FRSMRB'
,'FRSParts'
,'FRSRepaired'
,'FRSStage'
,'FRVFG'
,'GBOFG'
,'GBSDEPOTFR'
,'GBSFSE001'
,'GBSFSE002'
,'GBSFSE003'
,'GBSMRB'
,'GBSParts'
,'GBSRepaired'
,'GBSStage'
,'GBXFG'
,'GBXStage'
,'HKOFG'
,'HKSFSE001'
,'HKSParts'
,'HKSRepaired'
,'HKSStage'
,'HMOFG'
,'HMSFSE001'
,'HMSMRB'
,'HMSParts'
,'ILOFG'
,'ITSDEPOTFR'
,'ITSFSE001'
,'ITSFSE002'
,'ITSFSE003'
,'ITSFSE004'
,'ITSFSE008'
,'ITSFSE009'
,'ITSFSE011'
,'ITSFSE013'
,'ITSFSE014'
,'ITSFSE015'
,'ITSFSE016'
,'ITSFSE017'
,'ITSFSE018'
,'ITSMRB'
,'ITSParts'
,'ITSRepaired'
,'ITVFG'
,'JPCFG'
,'JPLFukuoka'
,'JPLHPWH'
,'JPLHemonex'
,'JPLHiroshima'
,'JPLKanazawa'
,'JPLLogistics'
,'JPLNagoya'
,'JPLOsaka'
,'JPLQA'
,'JPLSapporo'
,'JPLSendai'
,'JPLTokyo'
,'JPOBox Change'
,'JPOClassify'
,'JPOFG'
,'JPOFraction'
,'JPOInspection'
,'JPOKLS Damage'
,'JPOLimit A'
,'JPOLimit B'
,'JPOLimit D'
,'JPOMRB Damage'
,'JPOOsaka'
,'JPOPO Return'
,'JPOQuality'
,'JPOSO Return'
,'JPOSampling'
,'JPOShipped'
,'JPOStage'
,'JPOStop'
,'JPOTokyo'
,'JPOYamanashi'
,'JPSDEP001'
,'JPSFSE001'
,'JPSFSE002'
,'JPSFSE004'
,'JPSFSE008'
,'JPSFSE010'
,'JPSFSE013'
,'JPSFSE014'
,'JPSFSE017'
,'JPSFSE018'
,'JPSFSE019'
,'JPSFSE022'
,'JPSFSE023'
,'JPSFSE024'
,'JPSFSE025'
,'JPSFSE026'
,'JPSFSE032'
,'JPSFSE033'
,'JPSFSE036'
,'JPSFSE038'
,'JPSFSE039'
,'JPSFSE040'
,'JPSFSE041'
,'JPSFSE042'
,'JPSParts'
,'JPSTOKYO'
,'JPSVENDOR'
,'MSOFG'
,'MSOMRB'
,'NLSDEPOTFR'
,'NLSFSE001'
,'NLSFSE002'
,'NLSFSE004'
,'NLSFSE005'
,'NLSMRB'
,'NLSParts'
,'NLSRepaired'
,'PTO1OHIOW'
,'PTOFG'
,'PTOMRB'
,'PTORETURNS'
,'PTOUnallocate'
,'SESDEPOTFR'
,'SESFSE001'
,'SESFSE002'
,'SESMRB'
,'SESParts'
,'SESRepaired'
,'SEVFG'
,'SEVMRB'
,'SIOFG'
,'STOFG'
,'STOIntran RAW'
,'STOIntran WIP'
,'STOIntrans FG'
,'STOMRB'
,'STORAW'
,'STORTS'
,'STORefurb FG'
,'STOStage'
,'STOWIP'
,'TWOFG'
,'TWSFSE003'
,'TWSKaohsiung'
,'TWSParts'
,'TWSRepaired'
,'UNOFG'
,'USEFG'
,'USEIntrans FG'
,'USEMRB'
,'USEStage'
))*/
;
lc_material_transactions_id number;
 l_uom_code varchar2 (2000);
 l_cc_id number;
BEGIN
select code_combination_id
 into l_cc_id 
from gl_code_combinations_KFV
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000'
;
 FOR v_get_ohb in c_ohb LOOP
  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;
		 
  select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;
		 
--l_uom_code := v_get_ohb.primary_uom_code;

IF v_get_ohb.lot_number is not null then
 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV Issue2'
                                                       );
													   
													   INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV Issue2'
                                                       );

end if;

    insert into XXHA_MTL_TRANSACTIONS_INT_STG
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
													,error_code
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV Issue2'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
												   ,'VS_ISSUE'
                                                  );

  
insert into mtl_transactions_interface
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV Issue2'--'OHB Lot Control Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
  
  END LOOP;

commit;


END;

Procedure receipt_ohb_serial(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
is
cursor c_ohb_ser is
select * from xxha_serial_numbers_interface
where transaction_interface_id in
(select transaction_interface_id from XXHA_MTL_TRANSACTIONS_INT_STG where error_code = 'PS_ISSUE')
;

cursor c_ohb_lot (q_trx_id number)is
select *  from XXHA_MTL_TRANSACTIONS_LOT_STG
where transaction_interface_id = q_trx_id
;

cursor c_ohb (q_trx_id number)is
select *  from XXHA_MTL_TRANSACTIONS_INT_STG
where transaction_interface_id = q_trx_id
;
lc_material_transactions_id number;
 l_uom_code varchar2 (2000);
  l_first_segment1 varchar2 (2000);
  l_cc_id number;
begin
  select code_combination_id
 into l_cc_id 
from gl_code_combinations_KFV
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000'
;		 		 

  
  FOR v_ohb_ser in c_ohb_ser LOOP
  
  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;
 
   /* select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;
*/

--FOR v_get_serial IN c_get_serial(v_get_ohb.create_transaction_id) LOOP
INSERT INTO mtl_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
													  ,to_serial_number
													  ,source_code
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,fnd_global.user_id
                                                     ,SYSDATE
                                                     ,fnd_global.user_id
                                                     ,lc_material_transactions_id
                                                     ,v_ohb_ser.fm_serial_number
													 ,v_ohb_ser.to_serial_number
													 ,'Ph1 OHB Cleanup SINV RCPT'
                                                     );
INSERT INTO xxha_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
													  ,to_serial_number
													  ,source_code
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,fnd_global.user_id
                                                     ,SYSDATE
                                                     ,fnd_global.user_id
                                                     ,lc_material_transactions_id
                                                     ,v_ohb_ser.fm_serial_number
													 ,v_ohb_ser.to_serial_number
													 ,'Ph1 OHB Cleanup SINV RCPT'
                                                     );
--END LOOP;													 													 

for v_ohb_lot in c_ohb_lot (v_ohb_ser.transaction_interface_id) loop

 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_ohb_lot.lot_number
                                                       ,v_ohb_lot.lot_expiration_date
                                                       ,v_ohb_lot.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV RCPT'
                                                       );
													   
													   INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_ohb_lot.lot_number
                                                       ,v_ohb_lot.lot_expiration_date
                                                       ,v_ohb_lot.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV RCPT'
                                                       );

end loop;
for v_ohb in c_ohb (v_ohb_ser.transaction_interface_id)loop
    select acct.segment1
  into l_first_segment1
from apps.mtl_parameters param,apps.gl_code_combinations acct
where acct.code_combination_id = material_account
and organization_id = v_ohb.organization_id;

select code_combination_id
into l_cc_id
from apps.gl_code_combinations
where segment1 = l_first_segment1
and segment2 = '000'
and segment3 = '000'
and segment4 = '0000'
and segment5 = '0000'
and segment6 = '131400'
and segment7 = '000'
and segment8 = '000000'
and segment9 = '000000' 
;

	insert into XXHA_MTL_TRANSACTIONS_INT_STG
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV RCPT'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_ohb.inventory_item_id
                                                   ,v_ohb.revision
                                                   ,v_ohb.organization_id
                                                   ,v_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_ohb.transaction_quantity*-1
                                                   ,v_ohb.transaction_uom
                                                   ,sysdate
                                                   ,42
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
insert into mtl_transactions_interface
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV RCPT'--'OHB Lot Control Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_ohb.inventory_item_id
                                                   ,v_ohb.revision
                                                   ,v_ohb.organization_id
                                                   ,v_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_ohb.transaction_quantity*-1
                                                   ,v_ohb.transaction_uom
                                                   ,sysdate
                                                   ,42
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
      update XXHA_MTL_TRANSACTIONS_INT_STG
	  set error_code = 'VS_RCPT'
	  where transaction_interface_id = v_ohb_ser.transaction_interface_id
	  ;
    end loop;
  END LOOP;

commit;



end;		

Procedure receipt_ohb_non_serial(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
is
cursor c_ohb_ser is
select * from xxha_serial_numbers_interface
;

cursor c_ohb_lot (q_trx_id number)is
select *  from XXHA_MTL_TRANSACTIONS_LOT_STG
where transaction_interface_id = q_trx_id
;

cursor c_ohb is
select *  from XXHA_MTL_TRANSACTIONS_INT_STG
where transaction_interface_id not in
(select transaction_interface_id from xxha_serial_numbers_interface)
and error_code  = 'PS_ISSUE'
;
/*cursor c_get_ohb is
select inventory_item_id,create_transaction_id,organization_id,transaction_quantity,subinventory_code,revision,locator_id,lot_number 
 from apps.mtl_onhand_quantities
where transaction_quantity >=1
and organization_id = 106
and subinventory_code is not null
;*/
--select * from mtl_parameters where organization_code = 'AVO'



/*cursor c_get_ohb is
select inventory_item_id,create_transaction_id,organization_id,transaction_quantity,subinventory_code,revision,locator_id 
from mtl_onhand_quantities 
where organization_id = 694
order by inventory_item_id
;*/
/*
cursor c_get_serial (q_transaction_id number)is
select min(serial_number)fr_serial_number,max(serial_number) to_serial_number
 from mtl_serial_numbers
where last_transaction_id = q_transaction_id
;
*/
 lc_material_transactions_id number;
 l_uom_code varchar2 (2000);
 l_cc_id number;
 l_first_segment1 varchar2 (2000); 
begin
  select code_combination_id
 into l_cc_id 
from gl_code_combinations_KFV
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000'
;
  FOR v_ohb in c_ohb LOOP
  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;
   select acct.segment1
  into l_first_segment1
from apps.mtl_parameters param,apps.gl_code_combinations acct
where acct.code_combination_id = material_account
and organization_id = v_ohb.organization_id;

select code_combination_id
into l_cc_id
from apps.gl_code_combinations
where segment1 = l_first_segment1
and segment2 = '000'
and segment3 = '000'
and segment4 = '0000'
and segment5 = '0000'
and segment6 = '131400'
and segment7 = '000'
and segment8 = '000000'
and segment9 = '000000' 
;			 	 
 /* select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;
*/


											 													 

for v_ohb_lot in c_ohb_lot (v_ohb.transaction_interface_id) loop

 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
														
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_ohb_lot.lot_number
                                                       ,v_ohb_lot.lot_expiration_date
                                                       ,v_ohb_lot.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV RCPT2'
                                                       );
													   
													   INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_ohb_lot.lot_number
                                                       ,v_ohb_lot.lot_expiration_date
                                                       ,v_ohb_lot.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 OHB Cleanup SINV RCPT2'
                                                       );

end loop;

    insert into XXHA_MTL_TRANSACTIONS_INT_STG
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV RCPT2'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_ohb.inventory_item_id
                                                   ,v_ohb.revision
                                                   ,v_ohb.organization_id
                                                   ,v_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_ohb.transaction_quantity*-1
                                                   ,v_ohb.transaction_uom
                                                   ,sysdate
                                                   ,42
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
insert into mtl_transactions_interface
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 OHB Cleanup SINV RCPT2'--'OHB Lot Control Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_ohb.inventory_item_id
                                                   ,v_ohb.revision
                                                   ,v_ohb.organization_id
                                                   ,v_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_ohb.transaction_quantity*-1
                                                   ,v_ohb.transaction_uom
                                                   ,sysdate
                                                   ,42
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
    update XXHA_MTL_TRANSACTIONS_INT_STG
	  set error_code = 'VS_RCPT'
	  where transaction_interface_id = v_ohb.transaction_interface_id
	  ;
  END LOOP;

commit;


End;

END XXHA_SUBINV_PROCESS_OHB;
/
