CREATE OR REPLACE package      XXHA_BOM_CONV_PKG
as
-- +=============================================================================+
-- | Name             :  XXHA_BOM_CONV_BLL_PK
-- | Description      :  This package supports the processing of BOM routings and
-- |                     bills information staged for conversion.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-07-09  L.Richards     Initial release
-- +=============================================================================+

-- +=====================
-- | Global variables
-- +=====================

   -----------------------------------
   -- Common Errors placeholders
   -----------------------------------
   gn_request_id            xxha_common_errors.request_id%type := fnd_global.conc_request_id;  --Request ID of running concurrent program
   gn_record_number         xxha_common_errors.record_number%type;       --Record number of staged record
   gc_record_identifier     xxha_common_errors.record_identifier%type;   --Record identifier of staged record
   gc_error_code            xxha_common_errors.error_code%type;          --Error Code for detected error
   gc_error_msg             xxha_common_errors.error_msg%type;           --Description of error
   gc_comments              xxha_common_errors.comments%type;            --Comment related to error
   gc_table_name            xxha_common_errors.table_name%type;          --Staging table name
   gc_attribute1            xxha_common_errors.attribute1%type;          --Attribute1
   gc_attribute2            xxha_common_errors.attribute2%type;          --Attribute2
   gc_attribute3            xxha_common_errors.attribute3%type;          --Attribute3
   gc_attribute4            xxha_common_errors.attribute4%type;          --Attribute4 stores the concurrent program name
   gc_attribute5            xxha_common_errors.attribute5%type;          --Attribute5 stores the validated (eg. ROUTING, OPERATION, RESOURCE, BILL, INVCOMP, SUBCOMP)
   gc_error_logged  varchar2(1);
   -----------------------------------
   -- Constants
   -----------------------------------
   gc_table_RTG             xxha_common_errors.table_name%type := 'XXHA_BOM_ROUTING_OPS_STG';  --Staging table for routings
   gc_table_RTGOP           xxha_common_errors.table_name%type := 'XXHA_BOM_ROUTING_OPS_STG';  --Staging table for routing operations
   gc_table_OPRES           xxha_common_errors.table_name%type := 'XXHA_BOM_OP_RESOURCES_STG'; --Staging table for operation resources
   gc_table_BILL            xxha_common_errors.table_name%type := 'XXHA_BOM_INV_COMPS_STG';    --Staging table for bills
   gc_table_INVCOMP         xxha_common_errors.table_name%type := 'XXHA_BOM_INV_COMPS_STG';    --Staging table for bill components
   gc_table_SUBCOMP         xxha_common_errors.table_name%type := 'XXHA_BOM_SUB_COMPS_STG';    --Staging table for substitute components
   gc_conc_name_BILL        xxha_common_errors.attribute4%type := 'XXHA_BOM_BILLS_CONV';       --CP name for Bills conversion
   gc_conc_name_RTG         xxha_common_errors.attribute4%type := 'XXHA_BOM_RTGS_CONV';        --CP name for Routings conversion
   gc_valtype_RTG           xxha_common_errors.attribute5%type := 'ROUTING';                   --Validation type for routings
   gc_valtype_RTGOP         xxha_common_errors.attribute5%type := 'OPERATION';                 --Validation type for routing operations
   gc_valtype_OPRES         xxha_common_errors.attribute5%type := 'RESOURCE';                  --Validation type for operation resources
   gc_valtype_BILL          xxha_common_errors.attribute5%type := 'BILL';                      --Validation type for bills
   gc_valtype_INVCOMP       xxha_common_errors.attribute5%type := 'INVCOMP';                   --Validation type for bill components
   gc_valtype_SUBCOMP       xxha_common_errors.attribute5%type := 'SUBCOMP';                   --Validation type for substitute components
   gc_org_code_MST          mtl_parameters.organization_code%type := 'MST';                   --Master Organization Code
   gn_org_id_MST            mtl_parameters.organization_id%type := 103;                     --Master Organization Id
   gc_language_code         fnd_languages.language_code%type := 'US';                    --Language_code
   gc_assembly_item_number   varchar2 (2000);
   -----------------------------------
   -- Other placeholder variables
   -----------------------------------
   gc_org_code              mtl_parameters.organization_code%type;        --Current Org being processed
   gc_debug_flag            VARCHAR2(1);                                  --Debug_flag for display debug
   gc_conc_name             xxha_common_errors.attribute4%type;           --CP name placeholder to delete the records from common error table
   gn_user_id               fnd_user.user_id%type := FND_GLOBAL.USER_ID;  --User name for running conversion program
   gc_log_msg               VARCHAR2(1000);                               --Log_msg to display msgs
   gc_error_report          VARCHAR2(1) := 'N';                           --Error_report launch if its <>'N'
   --gc_program_name          VARCHAR2(50) := 'Item Conversion';          --Program Name In parameter for launch_error_prc procedure
   --gc_rec_identifier        VARCHAR2(50) := 'Item Number';              --Record identifier In parameter for launch_error_prc procedure
   --gc_starting_revision     mtl_parameters.starting_revision%type;      --Variable to get staring revision against the Inventory Orgs

   gc_now                   date;
   gc_status                VARCHAR2(2);                              --Variable to get status flag of data insertion in common error table
   gc_transaction_type      mtl_system_items_interface.transaction_type%type := 'CREATE';   --Default transaction_type
   gc_process_flag          mtl_system_items_interface.process_flag%type := '1';            --Default process_flag

-- +==============================================================================+
-- | Name       : process_bill_info
-- |
-- | Description: Procedure to process staged Bill info in preparation for
-- |              importing.  It drives the following actions:
-- |               . Validate staged records
-- |               . Update staged records with internal IDs matching user-friendly values
-- |               . Call launch program for reporting errors (if any)
-- |               . Populate interface tables if no errors found
-- |
-- | PARAMETERS:
-- |   IN: p_org_code
-- |       p_debug_flag
-- |       p_purge_flag
-- |  OUT: x_err_buf
-- |       x_ret_code
-- |
-- | SCOPE: PUBLIC
-- |
-- +==============================================================================+
/*PROCEDURE process_bill_info (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_org_code  in  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
        );

END XXHA_BOM_CONV_PKG;  -- package body
*/
/*PROCEDURE populate_bom_component
		  					 	(l_bom_component_tbl        IN OUT           Bom_Bo_Pub.Bom_Comps_Tbl_Type
								,p_assembly_item_number     IN               VARCHAR2
								,p_component_item_number     IN              VARCHAR2
								,p_org_code					   				 VARCHAR2
								,l_bom_sub_component_tbl    OUT              Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
								,p_error_message_list       IN OUT 			 Error_handler.error_tbl_type
								,p_chk_eror					OUT    			 BOOLEAN
								);
PROCEDURE populate_bom_sub_comp
		   						( p_bom_sub_component_tbl    IN OUT Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
								 ,p_org_code				 IN		VARCHAR2
								 ,p_assembly_item_number	 IN		VARCHAR2
								 ,p_component_item_number	 IN		VARCHAR2
								 ,l_error_message_list       in out Error_handler.error_tbl_type
								 ,l_x_return_status          out VARCHAR2
  								 ,l_x_msg_count              out NUMBER
								 ,p_x_sub_comp_exist         OUT  BOOLEAN);

*/
/*PROCEDURE CALL_BOM_API
	 		   				   	 (l_bom_header_rec           Bom_Bo_Pub.Bom_Head_Rec_Type
  								 ,l_bom_revision_tbl         Bom_Bo_Pub.Bom_Revision_Tbl_Type
  								 ,l_bom_component_tbl        Bom_Bo_Pub.Bom_Comps_Tbl_Type
  								 ,l_bom_ref_designator_tbl   Bom_Bo_Pub.Bom_Ref_Designator_Tbl_type
  								 ,l_bom_sub_component_tbl    Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
								 ,l_error_message_list       in out Error_handler.error_tbl_type
								 ,l_x_bom_header_rec         out Bom_Bo_Pub.bom_Head_Rec_Type
								 ,l_x_bom_revision_tbl       out Bom_Bo_Pub.Bom_Revision_Tbl_Type
  								 ,l_x_bom_component_tbl      out Bom_Bo_pub.Bom_Comps_Tbl_Type
  								 ,l_x_bom_ref_designator_tbl out Bom_Bo_Pub.Bom_Ref_Designator_Tbl_Type
  								 ,l_x_bom_sub_component_tbl  out Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
								 ,l_x_return_status          out VARCHAR2
  								 ,l_x_msg_count              out NUMBER) ;

*/
/*PROCEDURE populate_bom_header
		  					 	(l_org_code					VARCHAR2
								,l_error_message_list       in out Error_handler.error_tbl_type
								,l_chk_eror					out BOOLEAN
								);		*/
PROCEDURE convert_bom (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
    --    ,p_org_code  in  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
		,p_commit      in   varchar2
		,p_force_commit      in   varchar2
        );



END XXHA_BOM_CONV_PKG;  -- package spec

/


CREATE OR REPLACE package body XXHA_BOM_CONV_PKG
		as
		-- +=============================================================================+
		-- | Name             :  XXHA_BOM_CONV_BLL_PK
		-- | Description      :  This package supports the processing of BOM routings and
		-- |                     bills information staged for conversion.
		-- |
		-- |History:
		-- |  Version  When        Who            What
		-- |  -------  ----------  -------------  ---------------------------------------
		-- |  1.0      2008-09-09  Palash Kundu     Initial release
		-- +=============================================================================+

		  -- Cursor for errored records
		  /*cursor c_err (
		           q_request_id  xxha_common_errors.request_id%type
		          ,q_table_name  xxha_common_errors.table_name%type
		          ,q_conc_name  xxha_common_errors.attribute4%type
		          ,q_validation_type  xxha_common_errors.attribute5%type
		          ) is
		    select  ce.error_code
		           ,ce.error_msg
		           ,count(1)  cnt
		    from    xxha_common_errors  ce
		    where   ce.request_id = q_request_id
		    and     ce.table_name = q_table_name
		    and     ce.attribute4 = q_conc_name
		    and     ce.attribute5 = q_validation_type
		    group by ce.error_code
		            ,ce.error_msg
		    order by 1;
		*/
		---------------------------------------------------------------------------
		---Error Handling
		---------------------------------------------------------------------------


		    TYPE XX_COMMON_ERROR_Tbl_Type IS TABLE OF XXHA_COMMON_ERRORS%ROWTYPE
		            INDEX BY BINARY_INTEGER;
			XX_COMMON_ERROR_TBL		XX_COMMON_ERROR_Tbl_Type;
			TYPE XX_BOM_STG_Tbl_Type IS TABLE OF XXHA_BOM_INV_COMPS_STG%ROWTYPE
		            INDEX BY BINARY_INTEGER;
			XX_BOM_STG_TBL		XX_BOM_STG_Tbl_Type;
			TYPE XX_BOM_SUCCESS_STG_Tbl_Type IS TABLE OF XXHA_BOM_INV_COMPS_STG%ROWTYPE
		            INDEX BY BINARY_INTEGER;
			XX_BOM_SUCCESS_STG_TBL		XX_BOM_SUCCESS_STG_Tbl_Type;

		procedure populate_common_error(error_msg varchar2,error_code varchar2,error_comments varchar2,record_number number,record_identifier varchar2) is
		  l_error_counter number;
		begin
		gc_error_logged := 'Y';
		dbms_output.put_line(' popu err large '||substr(error_msg,1,2000));
		   l_error_counter := XX_COMMON_ERROR_TBL.count;
					 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
					 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
					 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := record_number;
					 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := substr(error_code,1,20);
					 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := record_identifier;
					 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_comments,1,2000);
					 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;

		end populate_common_error;

		procedure populate_bom_success_stg_tbl(assembly_item_number varchar2) is
		  l_bom_succ_counter number;
		begin
		   l_bom_succ_counter :=XX_BOM_SUCCESS_STG_TBL.count;
					 XX_BOM_SUCCESS_STG_TBL(l_bom_succ_counter+1).assembly_item_number := assembly_item_number;

		end populate_bom_success_stg_tbl;

		procedure populate_bom_stg_tbl(assembly_item_number varchar2) is
		  l_bom_counter number;
		begin
		   l_bom_counter :=XX_BOM_STG_TBL.count;
					 XX_BOM_STG_TBL(l_bom_counter+1).assembly_item_number := assembly_item_number;

		end populate_bom_stg_tbl;

		procedure log_error
		          is
		begin
		   gc_error_logged := 'Y';
		   xxha_common_utilities_pkg.insert_error_prc(
		                             gn_request_id
		                            ,gn_record_number
		                            ,gc_record_identifier
		                            ,gc_error_code
		                            ,gc_error_msg
		                            ,gc_comments
		                            ,gc_table_name
		                            ,gc_attribute1
		                            ,gc_attribute2
		                            ,gc_attribute3
		                            ,gc_attribute4
		                            ,gc_attribute5
		                            ,gc_status
		                            );
			dbms_output.put_line('error '||gc_error_code||gc_error_msg||gc_comments);
		exception
		   when others then
		      populate_common_error(substr(sqlerrm,1,2000),'log error','When Others Log Error',gn_record_number,gc_record_identifier);
			  fnd_file.put_line(fnd_file.log,'Error in XXHA_BOM_CONV_PKG.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
		end log_error;





		procedure log_all_errors IS
		l_error_occured boolean := FALSE;
		a number;
		b number;
		BEGIN
		a := XX_COMMON_ERROR_TBL.COUNT;
		b:= XX_BOM_STG_TBL.COUNT;
		  dbms_output.put_line('All Error '||xx_common_error_tbl.count);

		  FOR i IN 1..XX_COMMON_ERROR_TBL.COUNT LOOP
		     l_error_occured := TRUE;
		     gn_request_id :=  XX_COMMON_ERROR_TBL(i).request_id;
		     gn_record_number := XX_COMMON_ERROR_TBL(i).record_number;
		     gc_record_identifier := XX_COMMON_ERROR_TBL(i).record_identifier ;
		     gc_error_code := XX_COMMON_ERROR_TBL(i).error_code;
		     gc_error_msg := XX_COMMON_ERROR_TBL(i).error_msg;
		     gc_comments  :=  XX_COMMON_ERROR_TBL(i).comments;
		     gc_table_name :=  XX_COMMON_ERROR_TBL(i).table_name;
		     gc_attribute1 :=  XX_COMMON_ERROR_TBL(i).attribute1;
		     gc_attribute2 :=  XX_COMMON_ERROR_TBL(i).attribute2;
		     gc_attribute3:=  XX_COMMON_ERROR_TBL(i).attribute3;
		     gc_attribute4 :=  XX_COMMON_ERROR_TBL(i).attribute4;
		     gc_attribute5 :=  XX_COMMON_ERROR_TBL(i).attribute5;

			 log_error;



		  ENd LOOP;

		  IF NOT l_error_occured THEN
		    xxha_common_utilities_pkg.insert_error_prc(
		                             gn_request_id
		                            ,gn_record_number
		                            ,gc_record_identifier
		                            ,gc_error_code
		                            ,gc_error_msg
		                            ,'No Error Occured'
		                            ,'XXHA_BOM_INV_COMPS_STG'
		                            ,gc_attribute1
		                            ,gc_attribute2
		                            ,gc_attribute3
		                            ,gc_attribute4
		                            ,gc_attribute5
		                            ,gc_status
		                            );
		    gc_error_logged := 'N';
			dbms_output.put_line('No err ');
		  ELSE
		    FOR i IN 1..XX_BOM_STG_TBL.COUNT LOOP
			  IF XX_BOM_STG_TBL(i).assembly_item_number IS NOT NULL THEN
			    update xxha_bom_inv_comps_stg
			    set bl_status = 'VE'
				,ic_status = 'VE'
			    where assembly_item_number = XX_BOM_STG_TBL(i).assembly_item_number
				and bl_status <> 'VE';
			  END IF;
			END LOOP;
		  END IF;

		END log_all_errors;











		-----------------------------------------------------------------------------
		----CALL_BOM_API
		-----------------------------------------------------------------------------

		 PROCEDURE CALL_BOM_API
			 		   				   	 (l_bom_header_rec           Bom_Bo_Pub.Bom_Head_Rec_Type
		  								 ,l_bom_revision_tbl         Bom_Bo_Pub.Bom_Revision_Tbl_Type
		  								 ,l_bom_component_tbl        Bom_Bo_Pub.Bom_Comps_Tbl_Type
		  								 ,l_bom_ref_designator_tbl   Bom_Bo_Pub.Bom_Ref_Designator_Tbl_type
		  								 ,l_bom_sub_component_tbl    Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
										 ,l_error_message_list       in out Error_handler.error_tbl_type
										 ,l_x_bom_header_rec         out Bom_Bo_Pub.bom_Head_Rec_Type
										 ,l_x_bom_revision_tbl       out Bom_Bo_Pub.Bom_Revision_Tbl_Type
		  								 ,l_x_bom_component_tbl      out Bom_Bo_pub.Bom_Comps_Tbl_Type
		  								 ,l_x_bom_ref_designator_tbl out Bom_Bo_Pub.Bom_Ref_Designator_Tbl_Type
		  								 ,l_x_bom_sub_component_tbl  out Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
										 ,l_x_return_status          out VARCHAR2
		  								 ,l_x_msg_count              out NUMBER) IS


		  BEGIN
		  	   dbms_output.put_line('Call API '	);
			 --IF nvl(gc_assembly_item_number,'N')<>l_bom_header_rec.assembly_item_name THEN
			   BOM_BO_PUB.Process_Bom
		              (  p_bo_identifier          => 'BOM'
		               , p_api_version_number     => 1.0                 --  This parameter is required. It is used by the
		                                                                 --  API to compare the version number of incoming
		                                                                 --  calls to its current version number.
		               , p_init_msg_list          => TRUE                --  This parameter is set to TRUE, allows callers to
		                                                                 --  to request that the API do the initialization
		                                                                 --  of message list on their behalf.
		               , p_bom_header_rec         => l_bom_header_rec    --  This is a set of data structures that represent
		                                                                 --  the incoming business objects. This is a record
		                                                                 --  that holds the Bill of Materials header for the
		                                                                 --  BOM
		               , p_bom_revision_tbl       => l_bom_revision_tbl  --  All the p*_tbl parameters are data structure
		                                                                 --  that represent incoming business objects They
		                                                                 --  are PL/SQL tables of records  that hold records
		                                                                 --  for each of the other entities.
		               , p_bom_component_tbl      => l_bom_component_tbl
		               , p_bom_ref_designator_tbl => l_bom_ref_designator_tbl
		               , p_bom_sub_component_tbl  => l_bom_sub_component_tbl
		               , x_bom_header_rec         => l_x_bom_header_rec  --  All the x*_tbl parameters are data structure
		                                                                 --  that represent outgoing business objects They
		                                                                 --  are PL/SQL tables of records  that hold records
		                                                                 --  for each of the other entities except now they
		                                                                 --  have all the changes that the import program
		                                                                 -- made to it through all the steps.
		               , x_bom_revision_tbl       => l_x_bom_revision_tbl
		               , x_bom_component_tbl      => l_x_bom_component_tbl
		               , x_bom_ref_designator_tbl => l_x_bom_ref_designator_tbl
		               , x_bom_sub_component_tbl  => l_x_bom_sub_component_tbl
		               , x_return_status          => l_x_return_status   --  This is a flag that indicates the state of the
		                                                                 --  whole business object after the import.
		                                                                 --  'S' - Success
		                                                                 --  'E' - Error
		                                                                 --  'F' - Fatal Error
		                                                                 --  'U' - Unexpected Error
		               , x_msg_count              => l_x_msg_count       --  This holds the number of messages in the API
		                                                                 --  message stack after the import.
		               , p_debug                  => 'N'
		               , p_output_dir             => ''
		               , p_debug_filename         => ''
		               );
					   dbms_output.put_line('Call API sucess '||l_x_return_status);
					   /**** Error messages ****/
		                 --error_handler.initialize;
						-- populate_common_error(l_bom_ref_designator_tbl.count||'A'||l_bom_ref_designator_tbl(1).assembly_item_name,'A','X',1,1);
					      Error_Handler.Get_message_list(l_error_message_list);

					      if l_x_return_status <> 'S'  then
					         --  Error Processing
							 IF  nvl(gc_assembly_item_number, 'N') <>  l_bom_header_rec.assembly_item_name THEN
							   populate_bom_stg_tbl(l_bom_header_rec.assembly_item_name);
							   gc_assembly_item_number := l_bom_header_rec.assembly_item_name;
							 END IF;
					         for i  in 1..l_x_msg_count loop
							     populate_common_error(l_error_message_list(i).message_text,l_x_return_status,'BOM_API_ERROR',gn_record_number,gc_record_identifier);
								 --populate_common_error(l_error_message_list(i).message_text||'%'||l_bom_header_rec.transaction_type||l_bom_ref_designator_tbl(1).organization_code||l_bom_ref_designator_tbl(1).transaction_type||l_bom_component_tbl(1).transaction_type||l_x_bom_ref_designator_tbl(1).operation_sequence_number||l_x_bom_ref_designator_tbl(1).assembly_item_name||l_x_bom_ref_designator_tbl(1).component_item_name||';'||l_bom_component_tbl(1).assembly_item_name||'A'||l_bom_component_tbl.count,l_x_return_status,'BOM_API_ERROR',gn_record_number,gc_record_identifier);
					             dbms_output.put_line(TO_CHAR(i)||' MESSAGE TEXT  '||SUBSTR(l_error_message_list(i).message_text,1,250));
					             dbms_output.put_line(TO_CHAR(i)||' MESSAGE TYPE  '||l_error_message_list(i).message_type);
					         end loop;
					         --  The business object APIs do not issue commits or rollbacks. It is the responsibility of
					         --  the calling code to issue them. This ensures that parts of the transactions are not left
					         --  in the database. If an error occurs, the whole transaction is rolled back.
					        -- rollback;
					        dbms_output.put_line('Rollback = ');
					      else

						     populate_bom_success_stg_tbl(l_bom_header_rec.assembly_item_name);
					         --commit;
					       /*  if l_bom_sub_component_tbl.count > 0 then
							 	CALL_BOM_SUB_COMP_API
			 		   				   	 (l_bom_sub_component_tbl
										 ,l_error_message_list
										 ,l_x_bom_header_rec
										 ,l_x_bom_revision_tbl
		  								 ,l_x_bom_component_tbl
		  								 ,l_x_bom_ref_designator_tbl
		  								 ,l_x_bom_sub_component_tbl
										 ,l_x_return_status
		  								 ,l_x_msg_count);

								Error_Handler.Get_message_list(l_error_message_list);

							      if l_x_return_status <> 'S'  then
							         --  Error Processing
							         for i  in 1..l_x_msg_count loop
							             dbms_output.put_line(TO_CHAR(i)||' MESSAGE TEXT  '||SUBSTR(l_error_message_list(i).message_text,1,250));
							             dbms_output.put_line(TO_CHAR(i)||' MESSAGE TYPE  '||l_error_message_list(i).message_type);
							         end loop;
							         --  The business object APIs do not issue commits or rollbacks. It is the responsibility of
							         --  the calling code to issue them. This ensures that parts of the transactions are not left
							         --  in the database. If an error occurs, the whole transaction is rolled back.
							         rollback;
							        dbms_output.put_line('Sub Comp Rollback = ');
							      else
								     dbms_output.put_line('Sub Comp Commit = ');
							         commit;
								  end if;


							 end if;*/
							  dbms_output.put_line('API Commit = ');
					      end if;
				--END IF;
		  EXCEPTION
		    when others then
			    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others Call Bom API'||l_x_return_status,gn_record_number,gc_record_identifier);
			  dbms_output.put_line('Call API Exception '	);

		  END CALL_BOM_API;



		-----------------------------------------------------------------------------
		----POPULATE_BOM_SUB_COMP
		-----------------------------------------------------------------------------
		PROCEDURE  populate_bom_sub_comp
				   						( p_bom_sub_component_tbl    IN OUT Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
										 ,p_org_code				 IN		VARCHAR2
										 ,p_assembly_item_number	 IN		VARCHAR2
										 ,p_component_item_number	 IN		VARCHAR2
										 ,l_error_message_list       in out Error_handler.error_tbl_type
										 ,l_x_return_status          out VARCHAR2
		  								 ,l_x_msg_count              out NUMBER
										 ,p_x_sub_comp_exist         OUT  BOOLEAN) IS

		            cursor c_bom_sub_comp (	 q_org_code  VARCHAR2
									,q_assembly_item_number VARCHAR2
									,q_component_item_number VARCHAR2
		          					) is
		    		select   subcomp_item_number_1,bom_sub_comp.subcomp_item_number_2,bom_sub_comp.subcomp_item_number_3
					        ,bom_sub_comp.subcomp_quantity_1,bom_sub_comp.subcomp_quantity_2,bom_sub_comp.subcomp_quantity_3
					        ,bom_sub_comp.alternate_bom_designator, bom_sub_comp.operation_seq_num, bom_sub_comp.effectivity_date_iface
		           	from    xxha_bom_inv_comps_stg  bom_sub_comp
		    		where   bom_sub_comp.bl_status <> 'PS'
		    		and     bom_sub_comp.ic_status <> 'PS'
		    		and     bom_sub_comp.ci_flag = 'C'
		    		and     bom_sub_comp.organization_code = q_org_code
					and     bom_sub_comp.assembly_item_number = q_assembly_item_number
					and     bom_sub_comp.component_item_number = q_component_item_number;
			l_sub_comp_item_number VARCHAR2(1000);
			l_sub_comp_quantity VARCHAR2(1000);
			l_chk_sub_comp       BOOLEAN;
			l_tbl_counter        NUMBER;
			v_out_item_id  			 NUMBER;
		  			v_err_cd    				 VARCHAR2(1000);
		  			v_err_msg    				 VARCHAR2(1000);
		  			v_out_item_at_org  			 BOOLEAN;
		  BEGIN
		    dbms_output.put_line('POPULATE_BOM_SUB_COMP ');
			p_x_sub_comp_exist := FALSE;
			FOR v_bom_sub_comp in c_bom_sub_comp (p_org_code,p_assembly_item_number,p_component_item_number) LOOP
			  IF v_bom_sub_comp.subcomp_item_number_1 IS NOT NULL OR v_bom_sub_comp.subcomp_item_number_2 IS NOT NULL OR v_bom_sub_comp.subcomp_item_number_3 IS NOT NULL THEN
			  	 l_tbl_counter := 1;
				 FOR j in 1..3 LOOP
				   l_chk_sub_comp  := FALSE;
				   IF j =1 AND v_bom_sub_comp.subcomp_item_number_1 IS NOT NULL THEN
				      l_sub_comp_item_number := v_bom_sub_comp.subcomp_item_number_1;
					  l_sub_comp_quantity := v_bom_sub_comp.subcomp_quantity_1;
					  l_chk_sub_comp := TRUE;
				   ELSIF j =2 AND v_bom_sub_comp.subcomp_item_number_2 IS NOT NULL THEN
				      l_sub_comp_item_number := v_bom_sub_comp.subcomp_item_number_2;
					  l_sub_comp_quantity := v_bom_sub_comp.subcomp_quantity_2;
					  l_chk_sub_comp := TRUE;
				   ELSIF j =3 AND v_bom_sub_comp.subcomp_item_number_3 IS NOT NULL THEN
				      l_sub_comp_item_number := v_bom_sub_comp.subcomp_item_number_3;
					  l_sub_comp_quantity := v_bom_sub_comp.subcomp_quantity_3;
					  l_chk_sub_comp := TRUE;
				   ELSE
				     dbms_output.put_line('Do Nothing ');
				   END IF;
				   IF l_chk_sub_comp THEN
				     dbms_output.put_line('Sub Comp Load '||to_char(j)||p_bom_sub_component_tbl.count);
					 gc_record_identifier := gc_record_identifier||'SubComp'||l_sub_comp_item_number;
					  XXHA_BOM_COMMON_UTILITIES_PK.CHK_ITEM_AT_ORG (
													         p_org_code
													        ,l_sub_comp_item_number
													        ,v_out_item_id
															,v_err_cd
															,v_err_msg
															,v_out_item_at_org
															) ;
					  IF v_out_item_at_org THEN
							 p_bom_sub_component_tbl(p_bom_sub_component_tbl.count+1).organization_code 	:= p_org_code;
							 dbms_output.put_line('Sub Comp Load2 '||to_char(j)||p_bom_sub_component_tbl.count);
						     p_bom_sub_component_tbl(l_tbl_counter).assembly_item_name := p_assembly_item_number;
						     p_bom_sub_component_tbl(l_tbl_counter).alternate_bom_code   := v_bom_sub_comp.alternate_bom_designator;
						     p_bom_sub_component_tbl(l_tbl_counter).operation_sequence_number    := v_bom_sub_comp.operation_seq_num;
						     p_bom_sub_component_tbl(l_tbl_counter).component_item_name     := p_component_item_number;
						     p_bom_sub_component_tbl(l_tbl_counter).substitute_component_name    := l_sub_comp_item_number;
						     p_bom_sub_component_tbl(l_tbl_counter).substitute_item_quantity        := l_sub_comp_quantity;
							 p_bom_sub_component_tbl(l_tbl_counter).start_effective_date        := sysdate;
							 p_bom_sub_component_tbl(l_tbl_counter).transaction_type        := 'CREATE';
							 p_x_sub_comp_exist := TRUE;
							 l_tbl_counter := l_tbl_counter + 1;
					  ELSE
					    gc_record_identifier := l_sub_comp_item_number||'/'||p_org_code;

						populate_common_error(substr(sqlerrm,1,2000),'BOM SubCom Chk Item' ,'Item Do Not Exist',gn_record_number,gc_record_identifier);
					   IF  nvl(gc_assembly_item_number, 'N') <>  p_assembly_item_number THEN
						populate_bom_stg_tbl(p_assembly_item_number);
						gc_assembly_item_number :=  p_assembly_item_number;
					   END IF;



					  END IF;
				   END IF;
				 END LOOP;
			     dbms_output.put_line('End Sub Comp '||p_bom_sub_component_tbl.count);

			  END IF;

			END LOOP;
		  Exception
		    When Others then
			    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others Populate Bom Sub Comp',gn_record_number,gc_record_identifier);
		  END populate_bom_sub_comp;


		-----------------------------------------------------------------------------
		----POPULATE_BOM_REF_DESIGNATOR
		-----------------------------------------------------------------------------
		PROCEDURE  populate_bom_ref_designator
				   						( l_bom_ref_designator_tbl   IN OUT Bom_Bo_Pub.Bom_Ref_Designator_Tbl_type
										 ,p_org_code				 IN		VARCHAR2
										 ,p_assembly_item_number	 IN		VARCHAR2
										 ,p_component_item_number	 IN		VARCHAR2
										 ,p_op_seq_num IN varchar2
										 ,l_error_message_list       in out Error_handler.error_tbl_type
										 ,l_x_return_status          out VARCHAR2
		  								 ,l_x_msg_count              out NUMBER
										 ,p_x_ref_designator_exist         OUT  BOOLEAN) IS

		            cursor c_bom_ref_designator (	 q_org_code  VARCHAR2
									,q_assembly_item_number VARCHAR2
									,q_component_item_number VARCHAR2
		          					) is
		    		select  organization_code,assembly_item_number,component_item_number,reference_designator,operation_seq_num
		           	from    xxha_bom_inv_comps_stg  bom_sub_comp
		    		where   bom_sub_comp.bl_status <> 'PS'
		    		and     bom_sub_comp.ic_status <> 'PS'
		    		--and     bom_sub_comp.ci_flag = 'C'
		    		and     bom_sub_comp.organization_code = q_org_code
					and     bom_sub_comp.assembly_item_number = q_assembly_item_number
					and     bom_sub_comp.component_item_number = q_component_item_number
					and reference_designator is not null
					;
			--l_sub_comp_item_number VARCHAR2(1000);
			--l_sub_comp_quantity VARCHAR2(1000);
			--l_chk_sub_comp       BOOLEAN;
			l_tbl_counter        NUMBER;
			v_out_item_id  			 NUMBER;
		  			v_err_cd    				 VARCHAR2(1000);
		  			v_err_msg    				 VARCHAR2(1000);
		  			v_out_item_at_org  			 BOOLEAN;
		  BEGIN
		    dbms_output.put_line('POPULATE_BOM_SUB_COMP ');
			p_x_ref_designator_exist := FALSE;
--			l_bom_ref_designator_tbl.delete;
			FOR v_bom_ref_designator in c_bom_ref_designator (p_org_code,p_assembly_item_number,p_component_item_number) LOOP
			  p_x_ref_designator_exist := TRUE;
			  --l_bom_ref_designator_tbl(l_bom_ref_designator_tbl.count+1).assembly_item_name := v_bom_ref_designator.assembly_item_number;
			  l_bom_ref_designator_tbl(1).component_item_name := v_bom_ref_designator.component_item_number;
			  l_bom_ref_designator_tbl(1).organization_code := v_bom_ref_designator.organization_code;
			  			  l_bom_ref_designator_tbl(1).reference_designator_name := v_bom_ref_designator.reference_designator;
			  l_bom_ref_designator_tbl(1).Transaction_type := 'CREATE';
			  l_bom_ref_designator_tbl(1).assembly_item_name := v_bom_ref_designator.assembly_item_number;
			  l_bom_ref_designator_tbl(1).operation_sequence_number := p_op_seq_num;--v_bom_ref_designator.operation_seq_num;
			  l_bom_ref_designator_tbl(1).start_effective_date := sysdate;


			END LOOP;

		  Exception
		    When Others then
			    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others Populate Bom Ref Designator',gn_record_number,gc_record_identifier);
		  END populate_bom_ref_designator;


		-----------------------------------------------------------------------------
		----Populate BOM Component
		-----------------------------------------------------------------------------

		PROCEDURE populate_bom_component
				  					 	(l_bom_component_tbl        IN OUT           Bom_Bo_Pub.Bom_Comps_Tbl_Type
										,p_assembly_item_number     IN               VARCHAR2
										,p_component_item_number     IN              VARCHAR2
										,p_org_code					   				 VARCHAR2
										--,l_bom_sub_component_tbl    OUT              Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type
										,l_bom_ref_designator_tbl   OUT Bom_Bo_Pub.Bom_Ref_Designator_Tbl_type
										,p_error_message_list       IN OUT 			 Error_handler.error_tbl_type
										,p_chk_eror					OUT    			 BOOLEAN
										)


			IS
			     -- Cursor for validated bills comp
				  cursor c_bom_comp (
		           		 			q_org_code  VARCHAR2
									,q_assembly_item_number VARCHAR2
									,q_component_item_number VARCHAR2
		          					) is
		    		select  bom_comp.*
		           ,bom_comp.rowid
		    	   	from    xxha_bom_inv_comps_stg  bom_comp
		    		where   bom_comp.bl_status <> 'PS'
		    		and     bom_comp.ic_status <> 'PS'
		    		and     bom_comp.ci_flag = 'C'
		    		and     bom_comp.organization_code = nvl(q_org_code,bom_comp.organization_code)
					and assembly_item_number = q_assembly_item_number
					and component_item_number = q_component_item_number;

					v_org_code                 VARCHAR2(1000);
		  			v_out_item_id  			 NUMBER;
		  			v_err_cd    				 VARCHAR2(1000);
		  			v_err_msg    				 VARCHAR2(1000);
		  			v_out_item_at_org  			 BOOLEAN;
		  			v_comp_sequence_id  		 NUMBER;
		  			v_out_comp_found 			 BOOLEAN;
					l_x_sub_comp_exist           BOOLEAN;
					l_x_return_status            VARCHAR2(1000);
		  			l_x_msg_count                NUMBER;
					l_trx_type                   VARCHAR2(1000);
					l_x_effectivity_date         DATE;
		            --l_bom_ref_designator_tbl   Bom_Bo_Pub.Bom_Ref_Designator_Tbl_type;
					p_x_ref_designator_exist boolean;
					l_ops_seq_num varchar2 (2000);
			BEGIN
			  dbms_output.put_line('Populate Bom Component '	);
	--		  l_bom_component_tbl.delete;
			   FOR v_bom_comp in c_bom_comp (p_org_code,p_assembly_item_number,p_component_item_number)loop
		   	   	   dbms_output.put_line('Print Assly Item '||v_bom_comp.assembly_item_number);
				 --  l_bom_sub_component_tbl    := Bom_Bo_Pub.G_MISS_BOM_SUB_COMPONENT_TBL;
				   l_bom_ref_designator_tbl   :=  Bom_Bo_Pub.G_Miss_Bom_Ref_Designator_Tbl;

			   	   XXHA_BOM_COMMON_UTILITIES_PK.CHK_ITEM_AT_ORG (
													         v_bom_comp.organization_code
													        ,v_bom_comp.component_item_number
													        ,v_out_item_id
															,v_err_cd
															,v_err_msg
															,v_out_item_at_org
															) ;

					XXHA_BOM_COMMON_UTILITIES_PK.bill_comp_found (
		         										 v_bom_comp.organization_code
														 ,p_assembly_item_number
														 ,v_bom_comp.alternate_bom_designator
		        										,v_out_item_id
		        										,l_x_effectivity_date
														,v_out_comp_found
		        										);
					XXHA_BOM_COMMON_UTILITIES_PK.CHK_RTG_OPS_SEQ
					                                           ( p_assembly_item_number
						  									   ,p_org_code
						  									   ,l_ops_seq_num
						 									   );
					dbms_output.put_line('After Chk Comp '||v_out_item_id||' eff '||l_x_effectivity_date);
					gc_record_identifier := gc_record_identifier||'Comp'||v_bom_comp.component_item_number;
					IF v_out_item_at_org  THEN --Item at Org and No Bill Present
				        dbms_output.put_line('After Chk Comp Found '||v_bom_comp.organization_code||p_assembly_item_number||v_bom_comp.alternate_bom_designator||v_out_item_id );
				   	    l_bom_component_tbl(1).Organization_CODE          := p_org_code;
				        l_bom_component_tbl(1).Assembly_Item_name         := p_assembly_item_number;
				        IF v_out_comp_found THEN
						  l_bom_component_tbl(1).Start_effective_date       := l_x_effectivity_date;--greatest(nvl(v_bom_comp.effectivity_date,trunc(sysdate)),trunc(sysdate));
						ELSE
						  l_bom_component_tbl(1).Start_effective_date       := sysdate;--greatest(nvl(v_bom_comp.effectivity_date,trunc(sysdate)),trunc(sysdate));
				        END IF;
						l_bom_component_tbl(1).Component_Item_Name        := v_bom_comp.component_item_number;
				        l_bom_component_tbl(1).Alternate_bom_code         := v_bom_comp.alternate_bom_designator;
						l_bom_component_tbl(1).Auto_request_material      := v_bom_comp.auto_request_material;
				        l_bom_component_tbl(1).projected_yield            := v_bom_comp.component_yield_factor;
				        l_bom_component_tbl(1).planning_percent           := v_bom_comp.planning_factor;
				        l_bom_component_tbl(1).check_atp                  := v_bom_comp.check_atp;
				        l_bom_component_tbl(1).Include_In_Cost_Rollup     := nvl(v_bom_comp.include_in_cost_rollup,1);
				        l_bom_component_tbl(1).Wip_Supply_Type            := v_bom_comp.wip_supply_type;
				        l_bom_component_tbl(1).So_Basis                   := v_bom_comp.so_basis;
						l_bom_component_tbl(1).supply_subinventory        := v_bom_comp.supply_subinventory;
				        l_bom_component_tbl(1).Optional                   := v_bom_comp.optional;
				        l_bom_component_tbl(1).Mutually_Exclusive         := v_bom_comp.mutually_exclusive_options;
				        l_bom_component_tbl(1).Required_To_Ship           := v_bom_comp.required_to_ship;
				        l_bom_component_tbl(1).Required_For_Revenue       := v_bom_comp.required_for_revenue;
				        l_bom_component_tbl(1).Include_On_Ship_Docs       := v_bom_comp.include_on_ship_docs;
				        l_bom_component_tbl(1).Shipping_allowed           := v_bom_comp.shipping_allowed;
				        l_bom_component_tbl(1).Location_Name              := v_bom_comp.location_name;
				        l_bom_component_tbl(1).Minimum_Allowed_Quantity   := v_bom_comp.low_quantity;
				        l_bom_component_tbl(1).Maximum_Allowed_Quantity   := v_bom_comp.high_quantity;
				        l_bom_component_tbl(1).Comments                   := v_bom_comp.component_remarks;
				        l_bom_component_tbl(1).Item_Sequence_Number       := v_bom_comp.item_num;
						IF l_ops_seq_num = 1  THEN
				          l_bom_component_tbl(1).operation_Sequence_Number  := l_ops_seq_num;--v_bom_comp.operation_seq_num;
						ELSE
						  l_bom_component_tbl(1).operation_Sequence_Number  := v_bom_comp.operation_seq_num;
						END IF;
				        IF v_out_comp_found THEN
						  l_bom_component_tbl(1).Transaction_Type           := 'UPDATE';
						ELSE
						  l_bom_component_tbl(1).Transaction_Type           := 'CREATE';
						END IF;
				        l_bom_component_tbl(1).Quantity_Per_Assembly      := v_bom_comp.component_quantity;
				        l_bom_component_tbl(1).return_status              := NULL;

					   dbms_output.put_line('chk comp'||v_out_item_id||v_err_cd||v_err_msg||'eff dt '||l_x_effectivity_date);
				       /* populate_bom_sub_comp
				   						( l_bom_sub_component_tbl
										 ,p_org_code
										 ,p_assembly_item_number
										 ,v_bom_comp.component_item_number
										 ,p_error_message_list
										 ,l_x_return_status
		  								 ,l_x_msg_count
										 ,l_x_sub_comp_exist); */
						populate_bom_ref_designator
				   						( l_bom_ref_designator_tbl
										 ,p_org_code
										 ,p_assembly_item_number
										 ,p_component_item_number
										 , l_bom_component_tbl(1).operation_Sequence_Number
										 ,p_error_message_list
										 ,l_x_return_status
		  								 ,l_x_msg_count
										 ,p_x_ref_designator_exist
										 ) ;

				   ELSE
				       gc_record_identifier := v_bom_comp.component_item_number || '/'||v_bom_comp.organization_code;
					   populate_common_error(substr(sqlerrm,1,2000),'BOM Comp Chk Item' ,'Item Do Not Exist',gn_record_number,gc_record_identifier);
					   IF  nvl(gc_assembly_item_number, 'N') <>  v_bom_comp.assembly_item_number THEN
					     populate_bom_stg_tbl(v_bom_comp.assembly_item_number);
			             gc_assembly_item_number :=v_bom_comp.assembly_item_number;
					   ENd IF;
				   	   dbms_output.put_line('chk comp item False'||p_assembly_item_number||p_org_code);
				   END IF;



		   	   END LOOP;
			Exception
			When Others Then
			    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others populate bom comp',gn_record_number,gc_record_identifier);
			END populate_bom_component;


		-----------------------------------------------------------------------------
		----Populate BOM Header
		-----------------------------------------------------------------------------

		PROCEDURE populate_bom_header
				  					 	(--l_org_code					VARCHAR2
										--,
										l_error_message_list       in out Error_handler.error_tbl_type
										,l_chk_eror					out BOOLEAN
										)
			IS
			     -- Cursor for validated bills
				  cursor c_bom_hdr --(
				           --q_org_code  varchar2
				          --)
						  is
				    select  distinct
				            bom_hdr.organization_code
				           ,bom_hdr.assembly_item_number
				           ,bom_hdr.alternate_bom_designator
				           ,bom_hdr.revision
				           ,bom_hdr.specific_assembly_comment
				           ,bom_hdr.organization_id
				           ,bom_hdr.assembly_item_id
				           ,bom_hdr.bill_trx_type
						   --,bom_hdr.record_id
				    from    xxha_bom_inv_comps_stg  bom_hdr
				    where   bom_hdr.bl_status <> 'PS'
				    and     bom_hdr.ci_flag = 'C'
					--and bom_hdr.assembly_item_number = '38662-00'--'0995E-00'----'3610121'--'11382-00'
					--and organization_code = 'BTO'
				    --and     bom_hdr.organization_code = nvl(q_org_code,bom_hdr.organization_code)
					;

					cursor c_bom_comp_item (
		           		 			q_org_code  VARCHAR2
									,q_assembly_item_number VARCHAR2
									) is
		    		select  bom_comp.component_item_number
		           	from    xxha_bom_inv_comps_stg  bom_comp
		    		where   bom_comp.bl_status <> 'PS'
		    		and     bom_comp.ic_status <> 'PS'
		    		and     bom_comp.ci_flag = 'C'
		    		and     bom_comp.organization_code = nvl(q_org_code,bom_comp.organization_code)
					and assembly_item_number = q_assembly_item_number
					;

					v_org_code                 VARCHAR2(1000);
		  			v_out_item_id  			 NUMBER;
		  			v_err_cd    				 VARCHAR2(1000);
		  			v_err_msg    				 VARCHAR2(1000);
		  			v_out_item_at_org  			 BOOLEAN;
		  			v_bill_sequence_id  		 NUMBER;
		  			v_out_bill_found 			 BOOLEAN;
					l_bom_component_tbl          Bom_Bo_Pub.Bom_Comps_Tbl_Type;
					l_chk_comp_error             BOOLEAN;
					l_bom_header_rec             Bom_Bo_Pub.Bom_Head_Rec_Type;
					l_bom_revision_tbl         Bom_Bo_Pub.Bom_Revision_Tbl_Type;
					l_bom_ref_designator_tbl   Bom_Bo_Pub.Bom_Ref_Designator_Tbl_type;
					l_bom_sub_component_tbl    Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type;
					l_x_bom_header_rec          Bom_Bo_Pub.bom_Head_Rec_Type;
					l_x_bom_revision_tbl        Bom_Bo_Pub.Bom_Revision_Tbl_Type;
		  			l_x_bom_component_tbl       Bom_Bo_pub.Bom_Comps_Tbl_Type;
		  			l_x_bom_ref_designator_tbl  Bom_Bo_Pub.Bom_Ref_Designator_Tbl_Type;
				    l_x_bom_sub_component_tbl   Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type;
					l_x_return_status           Varchar2(2000);
					l_x_msg_count           NUMBER;
					l_trx_type               VARCHAR2(1000);
					l_component_number       NUMBER;

			BEGIN
			  dbms_output.put_line('Populate Bom Header '	);
			   FOR v_bom_hdr in c_bom_hdr loop
		   	   	   --gn_record_number := v_bom_hdr.assembly_item_number;
			           gc_record_identifier := v_bom_hdr.assembly_item_number||' '||v_bom_hdr.organization_code;
				   dbms_output.put_line(v_bom_hdr.assembly_item_number);
			   	   l_bom_header_rec             := Bom_Bo_Pub.G_MISS_BOM_HEADER_REC;
				   XXHA_BOM_COMMON_UTILITIES_PK.CHK_ITEM_AT_ORG (
													         v_bom_hdr.organization_code
													        ,v_bom_hdr.assembly_item_number
													        ,v_out_item_id
															,v_err_cd
															,v_err_msg
															,v_out_item_at_org
															) ;
					XXHA_BOM_COMMON_UTILITIES_PK.bill_found (
		         										 v_bom_hdr.organization_code
		        										,v_out_item_id
		        										,v_bom_hdr.alternate_bom_designator
		        										,v_bill_sequence_id
														,v_out_bill_found
		        										);
					IF v_out_bill_found then
					  l_trx_type := 'UPDATE';
					ELSE
					  l_trx_type := 'CREATE';
					END IF;
					dbms_output.put_line('Bom Hdr '||l_trx_type);
					IF v_out_item_at_org  THEN --Item at Org and No Bill Present

				   	   l_bom_header_rec.Assembly_item_name := v_bom_hdr.assembly_item_number;
		      	   	   l_bom_header_rec.Organization_code  := v_bom_hdr.organization_code;
		      	   	   l_bom_header_rec.Assembly_type      := 1;
				   	   l_bom_header_rec.alternate_bom_code := v_bom_hdr.alternate_bom_designator;
		      	   	   l_bom_header_rec.assembly_comment := v_bom_hdr.specific_assembly_comment;
				   	   l_bom_header_rec.Transaction_Type   := l_trx_type;
		      	   	   l_Bom_Header_Rec.Return_Status      := NULL;
				   	   dbms_output.put_line('chk item True1'||v_out_item_id||v_err_cd||v_err_msg);
					   l_component_number := 0;

					   l_bom_component_tbl := Bom_Bo_Pub.G_MISS_BOM_COMPONENT_TBL;
					   FOR v_bom_comp_item in c_bom_comp_item(v_bom_hdr.organization_code,v_bom_hdr.assembly_item_number) LOOP
		--------------------------------------------------
		                   XXHA_BOM_COMMON_UTILITIES_PK.CHK_ITEM_AT_ORG (
													         v_bom_hdr.organization_code
													        ,v_bom_comp_item.component_item_number
													        ,v_out_item_id
															,v_err_cd
															,v_err_msg
															,v_out_item_at_org);
						 IF v_out_item_at_org THEN


		                     gc_record_identifier := v_bom_hdr.assembly_item_number||' '||v_bom_hdr.organization_code;
		--------------------------------------------------

						   dbms_output.put_line('comp loop');
						   l_component_number := l_component_number + 1;
						   IF l_component_number > 1 THEN
						     l_bom_header_rec.Transaction_Type   := 'UPDATE';
						   END IF;
						   l_chk_comp_error    := FALSE;
						   populate_bom_component
				  					 	(l_bom_component_tbl
										,v_bom_hdr.assembly_item_number
										,v_bom_comp_item.component_item_number
										,v_bom_hdr.organization_code
										,l_bom_ref_designator_tbl--l_bom_sub_component_tbl
										,l_error_message_list
										,l_chk_comp_error
										);
						   call_bom_api
			 		   				   	 (l_bom_header_rec
		  								 ,l_bom_revision_tbl
		  								 ,l_bom_component_tbl
		  								 ,l_bom_ref_designator_tbl
		  								 ,l_bom_sub_component_tbl
										 ,l_error_message_list
										 ,l_x_bom_header_rec
										 ,l_x_bom_revision_tbl
		  								 ,l_x_bom_component_tbl
		  								 ,l_x_bom_ref_designator_tbl
		  								 ,l_x_bom_sub_component_tbl
										 ,l_x_return_status
		  								 ,l_x_msg_count) ;
		---------------------------------------------------------------
					     ELSE
						   gc_record_identifier := v_bom_comp_item.component_item_number || '/'||v_bom_hdr.organization_code;
					       populate_common_error(substr(sqlerrm,1,2000),'BOM Comp Chk Item' ,'Item Do Not Exist',gn_record_number,gc_record_identifier);
					       IF  nvl(gc_assembly_item_number, 'N') <> v_bom_hdr.assembly_item_number THEN
					         populate_bom_stg_tbl(v_bom_hdr.assembly_item_number);
			                 gc_assembly_item_number :=v_bom_hdr.assembly_item_number;
					       ENd IF;

						 END IF;
		----------------------------------------------------------------
					   END LOOP;


				   ELSE
				      gc_record_identifier := v_bom_hdr.assembly_item_number || '/'||v_bom_hdr.organization_code;
					  populate_common_error(substr(sqlerrm,1,2000),'Bom Header Chk Item' ,'Item Do Not Exist',gn_record_number,gc_record_identifier);

					  IF  nvl(gc_assembly_item_number, 'N') <>  v_bom_hdr.assembly_item_number THEN
						populate_bom_stg_tbl(v_bom_hdr.assembly_item_number);
						gc_assembly_item_number :=  v_bom_hdr.assembly_item_number;
					   END IF;
				   	   dbms_output.put_line('chk item False'||v_bom_hdr.assembly_item_number||v_bom_hdr.organization_code);
				   END IF;



		   	   END LOOP;
			Exception
			When Others then
			    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others populate bom hdr',gn_record_number,gc_record_identifier);
			END populate_bom_header;


		-----------------------------------------------------------------------------
		----CONVERT BOM
		-----------------------------------------------------------------------------

		PROCEDURE convert_bom (
		         x_err_buf  out  varchar2
		        ,x_ret_code  out  varchar2
		       -- ,p_org_code  in  varchar2
		        ,p_debug_flag  in  varchar2
		        ,p_purge_flag  in  varchar2
				,p_commit      in   varchar2
				,p_force_commit      in   varchar2
		        ) IS
			l_error_message_list       Error_handler.error_tbl_type;
			l_chk_eror					BOOLEAN;
			conc_request boolean;
		BEGIN
		     dbms_output.put_line('convert_bom');
			 gc_error_logged := 'N';
			 populate_bom_header
				  					 	(--p_org_code
										--,
										l_error_message_list
										,l_chk_eror
										);
		     IF p_commit = 'Y' AND (nvl(gc_error_logged,'N') <> 'Y' or nvl(p_force_commit,'N')  = 'Y')
			 THEN

			   dbms_output.put_line('Commit');
			    FOR i IN 1..XX_BOM_SUCCESS_STG_TBL.COUNT LOOP
			      IF XX_BOM_SUCCESS_STG_TBL(i).assembly_item_number IS NOT NULL THEN
			        update xxha_bom_inv_comps_stg
			        set bl_status = 'PS'
				    ,ic_status = 'PS'
			        where assembly_item_number = XX_BOM_SUCCESS_STG_TBL(i).assembly_item_number
				    and bl_status <> 'PS';
			      END IF;
			    END LOOP;
				Commit;
			 ELSE
			   Rollback;
			   dbms_output.put_line('Roll');
			   FOR i IN 1..XX_BOM_SUCCESS_STG_TBL.COUNT LOOP
			      IF XX_BOM_SUCCESS_STG_TBL(i).assembly_item_number IS NOT NULL THEN
			        update xxha_bom_inv_comps_stg
			        set bl_status = 'VS'
				    ,ic_status = 'VS'
			        where assembly_item_number = XX_BOM_SUCCESS_STG_TBL(i).assembly_item_number
				    and bl_status <> 'VS';
			      END IF;
			    END LOOP;

			 END IF;
			 log_all_errors;
			 commit;
			 IF nvl(gc_error_logged,'N') = 'Y' THEN
			   CONC_REQUEST := fnd_concurrent.set_completion_status('WARNING',substrb((fnd_message.get_string('BOM','EXCEPTION_OCCURED_CHK_COMMON_ERROR_TBL')),1,240));
			   xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,'Convert BOM','Record ID');

			 END IF;
		Exception

		When Others Then
		  populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others Convert Bom',gn_record_number,gc_record_identifier);
		  Rollback;
		  log_all_errors;
		  commit;
		end Convert_Bom;
		END XXHA_BOM_CONV_PKG;  -- package body

/
