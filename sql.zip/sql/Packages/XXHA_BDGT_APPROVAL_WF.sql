CREATE OR REPLACE PACKAGE xxha_bdgt_approval_wf
AS
--Version 3.0
/*****************************************************************************************

* Package Name : xxha_bdgt_approval_wf                                                   *

* Purpose      : Xxha_bdgt_approval_wf package is called from XXHA PA Budget
                 Workflow Process. This package is used for finding
                 the approvers for the Approved Cost Budget and Approved Revenue Budget  *

*                                                                                        *

*                                                                                        *

* Change History                                                                         *

*                                                                                        *

* Ver        Date            Author              Description                             *

* ------    -----------    -----------------    ---------------                          *

* 1.0        08-Feb-2011    Vishal Kumar           Initial Creation                      *

* 2.0        23-Feb-2011    Vishal Kumar          Added Project Acct as Final Approval

* 3.0        15-Jun-2011    Vishal Kumar          Added procedure PA_ASSIGN_WF                                                                                   *

*****************************************************************************************/

procedure costbgtapprv_wf(    itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2    );

                procedure PA_ASSIGN_WF(itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2);
END xxha_bdgt_approval_wf;

/


CREATE OR REPLACE package body      xxha_bdgt_approval_wf as

--Version 4.0
/*****************************************************************************************

* Package Name : xxha_bdgt_approval_wf                                                   *

* Purpose      : Xxha_bdgt_approval_wf package is called from XXHA PA Budget
                 Workflow Process. This package is used for finding
                 the approvers for the Approved Cost Budget and Approved Revenue Budget  *

*                                                                                        *

*                                                                                        *

* Change History                                                                         *

*                                                                                        *

* Ver        Date            Author              Description                             *

* ------    -----------    -----------------    ---------------                          *

* 1.0        08-Feb-2011    Vishal Kumar           Initial Creation                      *

* 2.0        23-Feb-2011    Vishal Kumar          Added Project Acct as Final Approval

* 3.0        15-Jun-2011    Vishal Kumar          Added procedure PA_ASSIGN_WF           *
* 4.0        11-Sep-2011    Vishal Kumar          Introduced Logic to allow same person on
						different roles to approve the Budget    *

*****************************************************************************************/

procedure costbgtapprv_wf(    itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2    )

                IS


      l_project_id  NUMBER;

      L_CNT NUMBER;
      L_CNT2 NUMBER;


l_workflow_started_by_id        NUMBER;
l_budget_type_code        pa_budget_types.budget_type_code%TYPE;

                BEGIN


  l_workflow_started_by_id := wf_engine.GetItemAttrNumber(itemtype      => itemtype,
                                    itemkey       => itemkey,
                                    aname          => 'WORKFLOW_STARTED_BY_ID' );





    l_budget_type_code := wf_engine.GetItemAttrText(itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'BUDGET_TYPE_CODE' );

                 l_project_id := wf_engine.GetItemAttrNumber(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PROJECT_ID' );

                        IF l_budget_type_code ='AR' THEN

                select COUNT(*) INTO  L_CNT   from pa_budget_versions where project_id=l_project_id AND BUDGET_STATUS_CODE IN ('B') AND BUDGET_TYPE_CODE IN ('AC');

                IF L_CNT <>0 THEN


                resultout := wf_engine.eng_completed||':'||'Y';

                ELSIF  L_CNT = 0 THEN


                    resultout := wf_engine.eng_completed||':'||'N';
                END IF;

                ELSE
                resultout := wf_engine.eng_completed||':'||'Y';
                END IF;

                EXCEPTION

WHEN FND_API.G_EXC_ERROR
    THEN
    resultout := wf_engine.eng_completed||':'||'Y';
    WF_CORE.CONTEXT('PA_BUDGET_WF','IS COST BUDGET APPROVED?', itemtype, itemkey, to_char(actid), funcmode);
       --- RAISE;

WHEN FND_API.G_EXC_UNEXPECTED_ERROR
    THEN
    resultout := wf_engine.eng_completed||':'||'Y';
    WF_CORE.CONTEXT('PA_BUDGET_WF','IS COST BUDGET APPROVED?', itemtype, itemkey, to_char(actid), funcmode);
     ---   RAISE;

WHEN OTHERS
    THEN
    resultout := wf_engine.eng_completed||':'||'Y';
    WF_CORE.CONTEXT('PA_BUDGET_WF','IS COST BUDGET APPROVED?', itemtype, itemkey, to_char(actid), funcmode);
   --- RAISE;


END costbgtapprv_wf;


PROCEDURE pa_assign_wf (
   itemtype    IN              VARCHAR2,
   itemkey     IN              VARCHAR2,
   actid       IN              NUMBER,
   funcmode    IN              VARCHAR2,
   resultout   OUT NOCOPY      VARCHAR2
)
IS
   l_project_id                NUMBER;
   l_cnt                       NUMBER;
   l_cnt2                      NUMBER;
   l_proj_stus_code            VARCHAR2 (100);
   l_workflow_started_by_id    NUMBER;
   l_project_role_type         VARCHAR2 (100);
   l_workflow_performer_id     NUMBER;
   l_workflow_notifier_id      NUMBER;
   l_workflow_performer_name   VARCHAR2 (100);
   l_workflow_notifier_name    VARCHAR2 (100);
   l_budget_type_code          pa_budget_types.budget_type_code%TYPE;
   lv_init_role_name           VARCHAR2 (20)               := 'XXHA_BDGT_ROLE';
   lv_init_role_dispname       VARCHAR2 (50)               := 'XXHA_BDGT_ROLE';

   l_cnt3 number;
   l_cnt4 number;

   l_profile_cnt number;
BEGIN
   l_workflow_started_by_id :=
      wf_engine.getitemattrnumber (itemtype      => itemtype,
                                   itemkey       => itemkey,
                                   aname         => 'WORKFLOW_STARTED_BY_ID'
                                  );
   l_project_id :=
      wf_engine.getitemattrnumber (itemtype      => itemtype,
                                   itemkey       => itemkey,
                                   aname         => 'PROJECT_ID'
                                  );
   l_budget_type_code :=
      wf_engine.getitemattrtext (itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname         => 'BUDGET_TYPE_CODE'
                                );

--                                l_proj_stus_code := wf_engine.GetItemAttrText(itemtype      => itemtype,
--                                itemkey       => itemkey,
--                                aname          => 'PROJECT_STATUS_CODE' );
--   INSERT INTO xxha_workflow_track2
--        VALUES (l_project_id , 1);

--   SELECT   project_role_type, COUNT (*)
--       INTO l_project_role_type, l_cnt
--       FROM pa_project_players ppa, fnd_user fu
--      WHERE ppa.project_id = l_project_id
--        AND ppa.person_id = fu.employee_id
--        AND fu.user_id = l_workflow_started_by_id
--        and sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
--        and ROWNUM=1
--   GROUP BY project_role_type;

--   if l_cnt=0 then

   --   resultout := wf_engine.eng_completed||':'||'N';

    --- insert into xxha_workflow_track2 VALUES (l_project_role_type,'l_cnt'||l_cnt );

   --      insert into xxha_workflow_track VALUES (L_CNT,2,l_project_id );

select count(*) into  l_profile_cnt from fnd_profile_options_tl f , fnd_profile_options e ,fnd_profile_option_values a,fnd_user d
WHERE  f.USER_PROFILE_OPTION_NAME = 'PA: Cross Project User -- Update'
and  f.PROFILE_OPTION_NAME=e.profile_option_name
and e.profile_option_id = a.profile_option_id
and a.level_value = d.user_id
and d.user_id=l_workflow_started_by_id
and a.PROFILE_OPTION_VALUE='Y'
and rownum=1;

        if l_profile_cnt =0 then

                SELECT count(*)
                 INTO l_cnt
                 FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
                     AND ppa.person_id = fu.employee_id
                     AND fu.user_id = l_workflow_started_by_id
                        AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
                        and rownum=1;
               if l_cnt=0
               then
                 resultout := wf_engine.eng_completed||':'||'N';

               else
               SELECT project_role_type
              INTO l_project_role_type
              FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
              and rownum=1;
              end if;

         elsif l_profile_cnt <>0 then
              SELECT count(*)
              INTO l_cnt
              FROM pa_project_players ppa, fnd_user fu
             WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
               and rownum=1;
               if l_cnt <>0
                then
                 SELECT project_role_type
              INTO l_project_role_type
              FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
              and rownum=1;
              end if;

        end if;

SELECT COUNT(*) INTO l_cnt3
 FROM pa_budget_versions pbv
 WHERE last_update_date||VERSION_NUMBER IN (SELECT   MAX (last_update_date||VERSION_NUMBER)
                                FROM pa_budget_versions
                               WHERE project_id = pbv.project_id
                               and budget_status_code='B'
                               and budget_type_code='AC' )
                               and pbv.budget_status_code='B'
                               and pbv.budget_type_code='AC'
                            and pbv.project_id=l_project_id
   AND pbv.budget_type_code IS NOT NULL;


   SELECT COUNT(*) INTO l_cnt4
 FROM pa_budget_versions pbv
 WHERE last_update_date||VERSION_NUMBER IN (SELECT   MAX (last_update_date||VERSION_NUMBER)
                                FROM pa_budget_versions
                               WHERE project_id = pbv.project_id
                               and budget_status_code='B'
                               and budget_type_code='AR' )
                                and pbv.budget_status_code='B'
                               and pbv.budget_type_code='AR'
                            and pbv.project_id=l_project_id
   AND pbv.budget_type_code IS NOT NULL;


      ---- insert into xxha_workflow_track2 VALUES ('l_cnt3'||l_cnt3,'l_cnt4'||l_budget_type_code );

   IF (l_budget_type_code = 'AC' and l_cnt3=0 )
   THEN
         ----insert into xxha_workflow_track2 VALUES ('l_cnt3-a'||l_cnt3,'l_cnt4-a'||l_cnt4 );
      IF (l_project_role_type = '1000' or l_profile_cnt <>0)
      THEN

      -----insert into xxha_workflow_track2 VALUES ('l_cnt3-b'||l_cnt3,'l_cnt4-b'||l_project_role_type );
         SELECT person_id
           INTO l_workflow_performer_id
           FROM pa_project_players
          WHERE project_role_type = 'PROGRAM MANAGER'
            AND project_id = l_project_id
            AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

           ---- insert into xxha_workflow_track2 VALUES ('l_cnt3-c'||l_cnt3,'l_cnt4-c'||l_workflow_performer_id);

         SELECT person_id
           INTO l_workflow_notifier_id
           FROM pa_project_players
          WHERE project_role_type = 'PROJECT MANAGER'
            AND project_id = l_project_id
            AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

           -----  insert into xxha_workflow_track2 VALUES ('l_cnt3-d'||l_cnt3,'l_cnt4-d'||l_workflow_notifier_id);

         SELECT f.user_name
           INTO l_workflow_performer_name
           FROM fnd_user f, pa_employees e
          WHERE f.employee_id = l_workflow_performer_id
            AND f.employee_id = e.person_id
            AND ROWNUM=1;


 -----insert into xxha_workflow_track2 VALUES ('l_cnt3-e'||l_cnt3,'l_cnt4-e'||l_workflow_performer_name);
         SELECT f.user_name
           INTO l_workflow_notifier_name
           FROM fnd_user f, pa_employees e,per_all_people_f ppf1
          WHERE f.employee_id = l_workflow_notifier_id
            AND f.employee_id = e.person_id
             and  ppf1.person_id = f.employee_id
            and e.person_id=ppf1.person_id
             AND     sysdate between ppf1.effective_start_date and ppf1.effective_end_date
              and ROWNUM=1;

            --- insert into xxha_workflow_track2 VALUES ('l_cnt3-f'||l_cnt3,'l_cnt4-f'||l_workflow_notifier_name);

         wf_engine.setitemattrtext (itemtype      => itemtype,
                                    itemkey       => itemkey,
                                    aname         => 'PROGRAM_MANAGER',
                                    avalue        => l_workflow_performer_name
                                   );

         ----INSERT INTO xxha_workflow_track2   VALUES (l_workflow_performer_name, 3);

         wf_engine.setitemattrtext (itemtype      => itemtype,
                                    itemkey       => itemkey,
                                    aname         => 'PROJECT_MANAGER',
                                    avalue        => l_workflow_notifier_name
                                   );

        ---- INSERT INTO xxha_workflow_track2  VALUES (l_workflow_notifier_name, 4);

         wf_directory.removeusersfromadhocrole (role_name      => lv_init_role_name);
         if l_workflow_performer_name=l_workflow_notifier_name then


                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                 else

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_notifier_name);


                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                              end if;


         resultout := wf_engine.eng_completed || ':' || 'I';
      ELSE

         resultout := wf_engine.eng_completed || ':' || 'F';
      END IF;
   ELSIF ( l_budget_type_code = 'AR' and l_cnt4=0 )

        THEN

      IF (l_project_role_type = '1000' or l_profile_cnt <>0)
      THEN
         SELECT person_id
           INTO l_workflow_performer_id
           FROM pa_project_players
          WHERE project_role_type = 'PROGRAM MANAGER'
            AND project_id = l_project_id
            AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

         SELECT person_id
           INTO l_workflow_notifier_id
           FROM pa_project_players
          WHERE project_role_type = 'PROJECT MANAGER'
            AND project_id = l_project_id
            AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

         SELECT f.user_name
           INTO l_workflow_performer_name
           FROM fnd_user f, pa_employees e
          WHERE f.employee_id = l_workflow_performer_id
            AND f.employee_id = e.person_id
            and ROWNUM=1;

         SELECT f.user_name
           INTO l_workflow_notifier_name
           FROM fnd_user f, pa_employees e
          WHERE f.employee_id = l_workflow_notifier_id
            AND f.employee_id = e.person_id
            and ROWNUM=1;

         wf_engine.setitemattrtext (itemtype      => itemtype,
                                    itemkey       => itemkey,
                                    aname         => 'PROGRAM_MANAGER',
                                    avalue        => l_workflow_performer_name
                                   );

--         INSERT INTO xxha_workflow_track2
--              VALUES (l_workflow_performer_name,5);

         wf_engine.setitemattrtext (itemtype      => itemtype,
                                    itemkey       => itemkey,
                                    aname         => 'PROJECT_MANAGER',
                                    avalue        => l_workflow_notifier_name
                                   );

--         INSERT INTO xxha_workflow_track2
--              VALUES (l_workflow_notifier_name, 6);

         wf_directory.removeusersfromadhocrole (role_name      => lv_init_role_name);
         if l_workflow_performer_name=l_workflow_notifier_name then


                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                 else

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_notifier_name);


                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                              end if;


         resultout := wf_engine.eng_completed || ':' || 'I';
      ELSE
         resultout := wf_engine.eng_completed || ':' || 'F';
      END IF;

        ELSIF (L_CNT3=1 OR L_CNT4=1)
        THEN
--     INSERT INTO xxha_workflow_track2
--           VALUES (l_cnt2, 'L_CNT2  ' || '  ' || '7');

      IF l_budget_type_code = 'AC'
      THEN
--       INSERT INTO xxha_workflow_track2
--           VALUES (l_cnt2, 'L_CNT2A  ' || '  ' || '7A');

         IF (   l_project_role_type = '1000'
             OR l_project_role_type = 'PROJECT MANAGER' or l_profile_cnt <>0
            )
         THEN
--            INSERT INTO xxha_workflow_track2
--                 VALUES (l_project_role_type,
--                         'l_project_role_type  ' || '  ' || '6B');

            SELECT person_id
              INTO l_workflow_performer_id
              FROM pa_project_players
             WHERE project_role_type = '1000'
               AND project_id = l_project_id
               AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

            SELECT person_id
              INTO l_workflow_notifier_id
              FROM pa_project_players
             WHERE project_role_type = 'PROJECT MANAGER'
               AND project_id = l_project_id
               AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

            SELECT f.user_name
              INTO l_workflow_performer_name
              FROM fnd_user f, pa_employees e
             WHERE f.employee_id = l_workflow_performer_id
               AND f.employee_id = e.person_id
               and ROWNUM=1;

            SELECT f.user_name
              INTO l_workflow_notifier_name
              FROM fnd_user f, pa_employees e
             WHERE f.employee_id = l_workflow_notifier_id
               AND f.employee_id = e.person_id
               and ROWNUM=1;

            wf_engine.setitemattrtext (itemtype      => itemtype,
                                       itemkey       => itemkey,
                                       aname         => 'PROJ_ACCT',
                                       avalue        => l_workflow_performer_name
                                      );
                ---- insert into xxha_workflow_track2 VALUES (l_workflow_performer_name,8 );

                         wf_engine.SetItemAttrText
                        (itemtype  => itemtype,
                 itemkey   => itemkey,
             aname        => 'PROJECT_MANAGER',
             avalue        =>  l_workflow_notifier_name);

                ----- insert into xxha_workflow_track2 VALUES (l_workflow_notifier_name,9 );
            wf_directory.removeusersfromadhocrole
                                               (role_name      => lv_init_role_name);
            wf_directory.adduserstoadhocrole (lv_init_role_name,
                                              l_workflow_notifier_name
                                             );
            -----  WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_notifier_name);
            wf_engine.setitemattrtext (itemtype      => itemtype,
                                       itemkey       => itemkey,
                                       aname         => 'INITIATOR_ROLE',
                                       avalue        => lv_init_role_name
                                      );


            resultout := wf_engine.eng_completed || ':' || 'R';

                else

--                 INSERT INTO xxha_workflow_track2
--           VALUES (l_cnt2, 'L_CNT2C  ' || '  ' || '5C');

                resultout := wf_engine.eng_completed || ':' || 'F';

            end if;
      ELSIF l_budget_type_code = 'AR'


         THEN
            IF (l_project_role_type = '1000' or l_profile_cnt <>0)
            THEN
--               INSERT INTO xxha_workflow_track2
--                    VALUES (l_project_role_type||' '||l_budget_type_code,
--                            'l_project_role_type l_budget_type_code ' || '  ' || '10');

               SELECT person_id
                 INTO l_workflow_performer_id
                 FROM pa_project_players
                WHERE project_role_type = '1000'
                  AND project_id = l_project_id
                  AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

               SELECT person_id
                 INTO l_workflow_notifier_id
                 FROM pa_project_players
                WHERE project_role_type = 'PROJECT MANAGER'
                  AND project_id = l_project_id
                  AND sysdate between start_date_active and nvl(end_date_active, sysdate+1);

               SELECT f.user_name
                 INTO l_workflow_performer_name
                 FROM fnd_user f, pa_employees e
                WHERE f.employee_id = l_workflow_performer_id
                  AND f.employee_id = e.person_id
                  and ROWNUM=1;

               SELECT f.user_name
                 INTO l_workflow_notifier_name
                 FROM fnd_user f, pa_employees e
                WHERE f.employee_id = l_workflow_notifier_id
                  AND f.employee_id = e.person_id
                  and ROWNUM=1;

                wf_engine.SetItemAttrText
                        (itemtype  => itemtype,
                 itemkey   => itemkey,
             aname        => 'PROJ_ACCT',
             avalue        =>  l_workflow_performer_name);

--               INSERT INTO xxha_workflow_track
--                    VALUES (l_workflow_performer_name, 11);

               wf_engine.setitemattrtext (itemtype      => itemtype,
                                          itemkey       => itemkey,
                                          aname         => 'PROJECT_MANAGER',
                                          avalue        => l_workflow_notifier_name
                                         );

--               INSERT INTO xxha_workflow_track2
--                    VALUES (l_workflow_notifier_name, 12);

               wf_directory.removeusersfromadhocrole (role_name      => lv_init_role_name);

               ---    WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);
               wf_directory.adduserstoadhocrole (lv_init_role_name,
                                                 l_workflow_notifier_name
                                                );
               wf_engine.setitemattrtext (itemtype      => itemtype,
                                          itemkey       => itemkey,
                                          aname         => 'INITIATOR_ROLE',
                                          avalue        => lv_init_role_name
                                         );
               resultout := wf_engine.eng_completed || ':' || 'R';
            ELSE

--            INSERT INTO xxha_workflow_track2
--                    VALUES(l_project_role_type,13);

               resultout := wf_engine.eng_completed || ':' || 'F';

         END IF;

         else
          resultout := wf_engine.eng_completed || ':' || 'F';
      END IF;
       else
        resultout := wf_engine.eng_completed || ':' || 'F';
   END IF;
EXCEPTION
   WHEN fnd_api.g_exc_error
   THEN

    resultout := wf_engine.eng_completed || ':' || 'F';
      wf_core.CONTEXT ('xxha_bdgt_approval_wf',
                       'PA_ASSIGN_WF1',
                       itemtype,
                       itemkey,
                       TO_CHAR (actid),
                       funcmode
                      );
    ----  RAISE;
   WHEN fnd_api.g_exc_unexpected_error
   THEN

    resultout := wf_engine.eng_completed || ':' || 'F';
      wf_core.CONTEXT ('xxha_bdgt_approval_wf',
                       'PA_ASSIGN_WF2',
                       itemtype,
                       itemkey,
                       TO_CHAR (actid),
                       funcmode
                      );
     --- RAISE;
   WHEN NO_DATA_FOUND
   THEN
      resultout := wf_engine.eng_completed || ':' || 'F';
      wf_core.CONTEXT ('xxha_bdgt_approval_wf',
                       'PA_ASSIGN_WF2',
                       itemtype,
                       itemkey,
                       TO_CHAR (actid),
                       funcmode
                      );
   WHEN OTHERS
   THEN
        resultout := wf_engine.eng_completed||':'||'F';
      wf_core.CONTEXT ('xxha_bdgt_approval_wf',
                       'PA_ASSIGN_WF4',
                       itemtype,
                       itemkey,
                       TO_CHAR (actid),
                       funcmode
                      );
     -- RAISE;
END pa_assign_wf;

END xxha_bdgt_approval_wf;

/
