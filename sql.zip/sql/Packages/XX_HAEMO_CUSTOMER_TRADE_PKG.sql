CREATE OR REPLACE PACKAGE XX_HAEMO_CUSTOMER_TRADE_PKG AUTHID CURRENT_USER AS
--Version 1.0
/*****************************************************************************************
* Package Name : XX_HAEMO_CUSTOMER_TRADE_PKG                                             *
* Purpose      : This package updates table column XX_HAEMO_SALES_REVENUE.TRADE_FLAG.    *
*                It is called by package XX_HAEMO_GET_SALES_DATA_PKG as a                *
*                post-processing step after XX_HAEMO_SALES_REVENUE is populated.         *
*                It was later adapted to also update new columns                         *
*                   SOLD_TO_SITE_USE_ID                                                  *
*                   ORDER_TYPE                                                           *
*                   ORDER_LINE_TYPE                                                      *
*                   END_CUSTOMER_ID                                                      *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
* XX_HAEMO_SALES_REVENUE  S, U                                                           *
* XX_HAEMO_SHIPTO_CUST_DETAILS   S                                                       *
* XX_HAEMO_BILLTO_CUST_DETAILS   S                                                       *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* Draft 1A   04-Dec-2007     Rakesh Sawarkar      Initial Creation                       *
* 1.0        01-Feb-2008     L.Richards           Adapted to update additional columns   *
*                                                 as noted above                         *
*****************************************************************************************/
-- Procedure used to get the main data
--
PROCEDURE main (
	 p_trx_number  in  xx_haemo_sales_revenue.trx_number%type
	);


END XX_HAEMO_CUSTOMER_TRADE_PKG;
/


CREATE OR REPLACE PACKAGE BODY      XX_HAEMO_CUSTOMER_TRADE_PKG AS
/*****************************************************************************************
* Package Name : XX_HAEMO_CUSTOMER_TRADE_PKG                                             *
* Purpose      : This package updates table column XX_HAEMO_SALES_REVENUE.TRADE_FLAG.    *
*                It is called by package XX_HAEMO_GET_SALES_DATA_PKG as a                *
*                post-processing step after XX_HAEMO_SALES_REVENUE is populated.         *
*                It was later adapted to also update new columns                         *
*                   SOLD_TO_SITE_USE_ID        (Rev 1.0)                                 *
*                   ORDER_TYPE                 (Rev 1.0)                                 *
*                   END_CUSTOMER_ID            (Rev 1.0)                                 *
*                   ORDER_LINE_TYPE            (Rev 1.0)                                 *
*                   CURRENT_SALESREP_ID        (Rev 2.0)                                 *
*                   CURRENT_SALESREP_NAME      (Rev 2.0)                                 *
*                   CURRENT_SALESREP_NUMBER    (Rev 2.0)                                 *
*                   BLANKET_NUMBER             (Rev 2.0)                                 *
*                   BLANKET_LINE_NUMBER        (Rev 2.0)                                 *
*                   ORDER_ORG_ID               (Rev 2.1)                                 *
*                                                                                        *
*                                                                                        *
* Called From  : Invoked by XX_HAEMO_GET_SALES_DATA_PKG which is registered as           *
*                concurrent program XXHA: Populate Sales Revenue Data                    *
*                                                                                        *
* Parameters             Type       Description                                          *
*                                                                                        *
* Tables Accessed                                                                        *
* -----------------                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
* XX_HAEMO_SALES_REVENUE  S, U                                                           *
* XX_HAEMO_CUST_DETAILS   S                                                              *
*                                                                                        *
*  Change History                                                                        *
*  -----------------                                                                     *
*  Version         Date             Author              Description                      *
*  ---------       ------------     ---------------     ---------------------------      *
*  Draft 1A        04-Dec-2007      Rakesh Sawarkar     Initial Creation                 *
*  1.0             04-Feb-2008      L.Richards          Adapted to update new columns    *
*                                                       as noted above                   *
*  2.0             06-Mar-2008      L.Richards          Adapted to update new columns    *
*                                                       as noted above                   *
*  2.1             21-Apr-2008      L.Richards          Modify DERIVE_CURRENT_SALESREP   *
*                                                       to accomodate change in default  *
*                                                       rules implemented for Haemoscope *
*                                                       go-live.                         *
*                                                       Note: Previously 'Always' was    *
*                                                             the assumed defaulting     *
*                                                             condition.  This changed   *
*                                                             with HScope go-live.       *
*                                                       Aside ... for performance, this  *
*                                                       version will cache driving       *
*                                                       factors and resulting salesrep   *
*                                                       info.  Subsequent derivation try *
*                                                       to first retrive from cache.     *
*                                                       Aside ... populate new column    *
*                                                           ORDER_ORG_ID                 *
*  4.0             15-Sep-2008      K.Budziszewski      Implemented salesrep overrides   *
*  4.1             08-Jan-2009      IPadela             changed the logic for setting the*
*                                                       intercompany flag based on the   *
*                                                       bill to cust type instead of the *
*                                                       Invoice type name                *
* 4.2              11-May-09        I.Padela            Changed logic to derive the overr*
*                                                       ide salesrep so as to fix the bug*
*                                                       in the logic                     *
*                                                       Logic: Specification
                                                        for XX_HAEMO_SLS_REP_OVERRIDE
                                                        (bill to and ship to site use),
                                                        in order of priority:
                                                        1) BILLTO_SITE_USE_ID is NOT null
                                                        and SHIPTO_SITE_USE_ID is NOT null:
                                                        should match only the specific bill
                                                        to - ship to combination for
                                                        salesrep override.
                                                        2) BILLTO_SITE_USE_ID is NOT null
                                                        and SHIPTO_SITE_USE_ID is null:
                                                        should match the specific bill to and
                                                        any ship to (including null) for
                                                        salesrep override.
                                                        3) BILLTO_SITE_USE_ID is null and
                                                        SHIPTO_SITE_USE_ID is NOT null:
                                                        should match the specific ship to
                                                        and any bill to for salesrep
                                                        override
                                                        (assumes bill to cannot be null).
                                                        Additional notes:
                                                        -  BILLTO_SITE_USE_ID is null and
                                                        SHIPTO_SITE_USE_ID is null should be
                                                        ignored or not allowed
                                                        - order of priority means that if
                                                        1 applies then 2 should not be applied
  4.3              21-Apr-11        E.Rossing           Modified CUR_GET_DATA to only retrieve
                                                        last two years of data when q_trx_number
                                                        is NULL.
  4.4               22-Mar-2012      ERossing           Modified last-two-years limit to use ADDMONTHS
                                                        instead of INTERVAL in calculation to work around
                                                        leap year bug.
  4.5		            24-Jul-2013	     IPadela	      	  Added an extra join in the order header query as
							                                          the order number is no more unique within an Oper Unit now
                        03-Feb-2014     IMenzies        fixed derive_current_salesrep to use R12 Multi-Org functionality
                        26-Jun-2014     IMenzies        always get salesrep name from resource table
******************************************************************************************/
cursor cur_get_data (
           q_trx_number  xx_haemo_sales_revenue.trx_number%type
          ) is
    SELECT  xhsr.rowid
           ,XHSR.SHIP_TO_CUSTOMER_ID
           ,XHSR.BILL_TO_CUSTOMER_ID
           ,XHSR.TRX_NUMBER
           ,XHSR.CUSTOMER_TRX_ID
           ,xhsr.organization_id  org_id
           ,xhsr.interface_header_attribute1  order_number
           ,xhsr.interface_line_attribute6  line_id
           -- placeholders for current salesrep derivation
           ,xhsr.sales_order_source
           ,xhsr.intercompany_flag
           ,xhsr.ship_to_site_use_id
           ,xhsr.bill_to_site_use_id
           -- placeholders for derived values
           ,null  trade_flag
           ,to_number(null)  sold_to_site_use_id  --<Rev 1.0>
           ,null  order_type  --<Rev 1.0>
           ,to_number(null)  end_customer_id  --<Rev 1.0>
           ,null  order_line_type  --<Rev 1.0>
           ,to_number(null)  hdr_agreement_id
           ,to_number(null)  hdr_ship_to_org_id
           ,to_number(null)  hdr_sold_to_org_id
           ,to_number(null)  hdr_invoice_to_org_id
           ,to_number(null)  hdr_sold_to_site_use_id
           ,to_number(null)  hdr_blanket_number
           ,to_number(null)  hdr_org_id  --<Rev 2.1>
           ,to_number(null)  hdr_header_id  --<Rev 2.1>
           ,to_number(null)  lin_agreement_id
           ,to_number(null)  lin_ship_to_org_id
           ,to_number(null)  lin_invoice_to_org_id
           ,to_number(null)  lin_sold_to_org_id
           ,to_number(null)  lin_blanket_number
           ,to_number(null)  lin_blanket_line_number
           ,to_number(null)  lin_header_id
           ,to_number(null)  lin_org_id  --<Rev 2.1>
           ,to_number(null)  blanket_number  --<Rev 2.0>
           ,to_number(null)  blanket_line_number  --<Rev 2.0>
           ,to_number(null)  current_salesrep_id  --<Rev 2.0>
           ,null  current_salesrep_name  --<Rev 2.0>
           ,null  current_salesrep_number  --<Rev 2.0>
           ,null  current_salesrep_source  --<Rev 2.0>
           ,to_number(null)  order_org_id  --<Rev 2.1>
           ,inventory_item_id
    FROM    XX_HAEMO_SALES_REVENUE  xhsr
    where   trx_number = nvl(q_trx_number,trx_number)
	--Rev 4.3 - Eric Rossing - 4/21/11 - Only return last six months of records when q_trx_number is null
--    AND gl_date>= (CASE WHEN q_trx_number IS NULL THEN sysdate - interval '24' month ELSE GL_DATE END);
  -- Rev 4.4 ERossing - 3/22/12 modified calculation to use ADD_MONTHS instead
	AND gl_date>= (CASE WHEN q_trx_number IS NULL THEN ADD_MONTHS(SYSDATE,-24) ELSE GL_DATE END);

type gc_defaultRuleRec is record (
     src_type  oe_def_attr_def_rules.src_type%type
    ,database_object_name  oe_def_attr_def_rules.database_object_name%type
    ,src_database_object_name  oe_def_attr_def_rules.src_database_object_name%type
    ,src_profile_option  oe_def_attr_def_rules.src_profile_option%type
    ,src_constant_value  oe_def_attr_def_rules.src_constant_value%type  -- <Rev 2.1>
    ,condition_id  oe_def_attr_condns.condition_id%type  -- <Rev 2.1>
    ,number_of_elements  oe_def_conditions.number_of_elements%type  -- <Rev 2.1>
    );
type gc_defaultRuleTabType is table of gc_defaultRuleRec index by binary_integer;
gt_defRules_lin  gc_defaultRuleTabType;
gt_defRules_hdr  gc_defaultRuleTabType;
-- <Rev 2.1
type gc_defaultCondRec is record (
     group_number  oe_def_condn_elems.group_number%type
    ,attribute_code  oe_def_condn_elems.attribute_code%type
    ,value_op  oe_def_condn_elems.value_op%type
    ,value_string  oe_def_condn_elems.value_string%type
    ,data_type  all_tab_columns.data_type%type
    );
type gc_defaultCondTabType is table of gc_defaultCondRec index by binary_integer;
gt_defConditions  gc_defaultCondTabType;
gt_defConditions_empty  gc_defaultCondTabType;
g_condition_id_cached  oe_def_condn_elems.condition_id%type := fnd_api.g_miss_num;
g_db_object_cached  oe_def_attr_def_rules.database_object_name%type := fnd_api.g_miss_char;
g_sql  varchar2(4000);
-- structure for caching derived Salesrep for specific attribite values
type g_cachedSalerepRec is record (
     org_id  number
    ,intercompany_flag  varchar2(1)
    ,sales_order_source  ra_customer_trx_lines_all.sales_order_source%type
    ,bill_to_site_use_id  number
    ,ship_to_site_use_id  number
    ,lin_agreement_id  number
    ,lin_ship_to_org_id  number
    ,lin_invoice_to_org_id  number
    ,lin_sold_to_org_id  number
    ,lin_blanket_number  number
    ,lin_blanket_line_number  number
    ,lin_header_id  number
    ,hdr_agreement_id  number
    ,hdr_ship_to_org_id  number
    ,hdr_invoice_to_org_id  number
    ,hdr_sold_to_org_id  number
    ,hdr_blanket_number  number
    ,hdr_sold_to_site_use_id  number
    ,hdr_header_id  number
    ,current_salesrep_id  number
    ,current_salesrep_name  ra_salesreps_all.name%type
    ,current_salesrep_number  ra_salesreps_all.salesrep_number%type
    ,current_salesrep_source  varchar2(40)
    );
gr_cached  g_cachedSalerepRec;
-- Rev 2.1>
--IPadela 01/08/09 Rev 4.1
g_Is_InterCo  varchar2(1);
-----------------------------------------------
-- append one string to another
-----------------------------------------------
procedure append_str (
         x_string  in out  varchar2
        ,p_to_add  in  varchar2
  ) is
  l_number number;
begin
  x_string := x_string||p_to_add;
end append_str;
-----------------------------------------------
-- check if a string is numeric
-----------------------------------------------
function isnumeric (
   p_string  in  varchar2
  ) return number is
  l_number number;
begin
  l_number := p_string;
  return 1;
exception
  when others then
     return 0;
end isnumeric;
-----------------------------------------------------------
-- <Rev 2.1 : Check to see if defaulting condition is met
-----------------------------------------------------------
function defaulting_condition_met (
         prec  in  cur_get_data%rowtype
        ,p_condition_id  in  oe_def_condn_elems.condition_id%type
        ,p_element_count  oe_def_conditions.number_of_elements%type
        ,p_database_object_name  in  oe_def_conditions.database_object_name%type
        ) return boolean
          is
cursor c_dc (
           q_condition_id  oe_def_condn_elems.condition_id%type
          ,q_database_object_name  oe_def_conditions.database_object_name%type
          ) is
    select  ce.group_number
           ,ce.attribute_code
           ,ce.value_op
           ,ce.value_string
           ,tc.data_type
    from    oe_def_condn_elems  ce
           ,all_tab_columns  tc
    where   ce.condition_id = q_condition_id
    and     tc.table_name = q_database_object_name
    and     tc.column_name = ce.attribute_code
    order by ce.group_number
            ,ce.condition_element_id;
ln_index  number := 0;
  l_group_number_brk  oe_def_condn_elems.group_number%type;
  l_sql  varchar2(4000);
  l_pk_filter  varchar2(1000);
  l_pairing  varchar2(4000);
  l_condition_str  varchar2(4000);
  l_condition_result  varchar2(1);
  l_result  boolean;
begin
  -- is condition Always or Other with no elements
  --  0 = Always
  if (p_condition_id = 0  or  (p_condition_id > 0 and p_element_count = 0) ) then

     l_result := TRUE;
elsif (p_database_object_name = 'OE_AK_ORDER_HEADERS_V'  and  prec.hdr_header_id is null) then
l_result := FALSE;
elsif (p_database_object_name = 'OE_AK_ORDER_LINES_V'  and  prec.lin_header_id is null) then
l_result := FALSE;
else
 -- if not already buffered, build the sql and cache the defaulting conditions and constructed sql
 if (   p_condition_id <> g_condition_id_cached
         or p_database_object_name <> g_db_object_cached) then
gt_defConditions := gt_defConditions_empty;
for dcrec in c_dc (p_condition_id,p_database_object_name)
 loop
           ln_index := ln_index + 1;
           gt_defConditions(ln_index).group_number := dcrec.group_number;
           gt_defConditions(ln_index).attribute_code := dcrec.attribute_code;
           gt_defConditions(ln_index).value_op := dcrec.value_op;
           gt_defConditions(ln_index).value_string := dcrec.value_string;
           gt_defConditions(ln_index).data_type := dcrec.data_type;
        end loop;
 -- initialize control break variable
        l_group_number_brk := fnd_api.g_miss_num;  -- initialize control break variable
-- build sql to check condition
   if (p_database_object_name = 'OE_AK_ORDER_HEADERS_V') then
           l_pk_filter := 'header_id=##PKVALUE##';
        elsif (p_database_object_name = 'OE_AK_ORDER_LINES_V') then
           l_pk_filter := 'line_id=##PKVALUE##';
        end if;
        l_sql := 'select ''T'' from '||p_database_object_name||' where '||l_pk_filter;
        l_condition_str := null;
        l_condition_result := 'F';
-- loop thru elements to build sql
        -- note: distinct groups are  ORed,
        --       conditions within a group are  ANDed
        for i in 1..gt_defConditions.count
        loop
           -- build condition
           if (gt_defConditions(i).data_type = 'NUMBER') then
              l_pairing := gt_defConditions(i).attribute_code||gt_defConditions(i).value_op||gt_defConditions(i).value_string;
           elsif (gt_defConditions(i).data_type like '%CHAR%') then
              l_pairing := gt_defConditions(i).attribute_code||gt_defConditions(i).value_op||''''||
              gt_defConditions(i).value_string
              ||'''';
elsif (gt_defConditions(i).data_type = 'DATE') then
              l_pairing := gt_defConditions(i).attribute_code||gt_defConditions(i).value_op||'to_char('''
              ||gt_defConditions(i).value_string||''')';
end if;
 if (gt_defConditions(i).group_number <> l_group_number_brk) then
              if (l_group_number_brk = fnd_api.g_miss_num) then
                 l_condition_str := ' (';
              else
                 append_str(l_condition_str,') OR (');
              end if;
              l_group_number_brk := gt_defConditions(i).group_number;
           else
              append_str(l_condition_str,' AND ');
           end if;

           append_str(l_condition_str,l_pairing);
        end loop;
append_str(l_condition_str,')');
 l_sql := l_sql||' and ('||l_condition_str||')';
 -- cache constructed sql
        g_condition_id_cached := p_condition_id;
        g_db_object_cached := p_database_object_name;
        g_sql := l_sql;
end if;
l_sql := g_sql;
     if (p_database_object_name = 'OE_AK_ORDER_HEADERS_V') then
        l_sql :=  replace(l_sql, '##PKVALUE##' , prec.hdr_header_id);
     elsif (p_database_object_name = 'OE_AK_ORDER_LINES_V') then
        l_sql :=  replace(l_sql, '##PKVALUE##' , prec.line_id);
     end if;
 begin
 execute immediate l_sql into l_condition_result;
        l_result := TRUE;
     exception
        when no_data_found then
           l_result := FALSE;
     end;
end if;
return (l_result);
end defaulting_condition_met;
-- Rev 2.1>
-----------------------------------------------
-- apply header defaulting rules for salesrep
-----------------------------------------------
procedure apply_header_default_rules (
   xrec  in out  cur_get_data%rowtype
  ) is
  e_skip  exception;
begin
   if (xrec.current_salesrep_id is not null) then
      raise e_skip;  -- salesrep already set, so just skip
   end if;
for i in 1..gt_defRules_hdr.count
   loop
 begin
         -- <Rev 2.1 : defaulting condition is not met then skip the rule
         if (not defaulting_condition_met(
                            xrec
                           ,gt_defRules_hdr(i).condition_id
                           ,gt_defRules_hdr(i).number_of_elements
                           ,gt_defRules_hdr(i).database_object_name) ) then
            raise e_skip;
         end if;
         -- Rev 2.1>
if (gt_defRules_hdr(i).src_type = 'RELATED_RECORD') then
            if (gt_defRules_hdr(i).src_database_object_name = 'OE_AGREEMENTS_V') then
               if ont_agreement_def_util.sync_agreement_cache (p_agreement_id => xrec.hdr_agreement_id ) = 1 then
                  xrec.current_salesrep_id := ont_agreement_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Header AGREEMENT';
               end if;
            elsif (gt_defRules_hdr(i).src_database_object_name = 'OE_AK_SHIP_TO_ORGS_V') then
               if ont_ship_to_org_def_util.sync_ship_to_org_cache (p_organization_id => xrec.hdr_ship_to_org_id ) = 1 then
                  xrec.current_salesrep_id := ont_ship_to_org_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Header SHIPTO';
               end if;
            elsif (gt_defRules_hdr(i).src_database_object_name = 'OE_AK_INVOICE_TO_ORGS_V') then
               if ont_inv_org_def_util.sync_inv_org_cache (p_organization_id => xrec.hdr_invoice_to_org_id ) = 1 then
                  xrec.current_salesrep_id := ont_inv_org_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Header BILLTO';
               end if;
            elsif (gt_defrules_hdr(i).src_database_object_name = 'OE_AK_SOLD_TO_ORGS_V') then
               if ont_sold_to_org_def_util.sync_sold_to_org_cache (p_organization_id => xrec.hdr_sold_to_org_id , p_ORG_ID => NULL ) = 1 then
                  xrec.current_salesrep_id := ont_sold_to_org_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Header SOLDTO';
               end if;
            elsif (gt_defRules_hdr(i).src_database_object_name = 'OE_AK_BLANKET_HEADERS_V') then
               if ont_blanket_header_def_util.sync_blanket_header_cache (p_order_number => xrec.hdr_blanket_number ) = 1 then
                  xrec.current_salesrep_id := ont_blanket_header_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Header BLANKET';
               end if;
            elsif (gt_defRules_hdr(i).src_database_object_name = 'OE_AK_SOLD_TO_SITE_USES_V') then
               if ont_sold_to_su_def_util.sync_sold_to_su_cache (p_sold_to_site_use_id => xrec.hdr_sold_to_site_use_id ) = 1 then
                  xrec.current_salesrep_id := ont_sold_to_su_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Header SOLDTO SITE';
               end if;
            end if;
         elsif (gt_defRules_hdr(i).src_type = 'PROFILE_OPTION') then
            xrec.current_salesrep_id := fnd_number.canonical_to_number (FND_PROFILE.VALUE(gt_defRules_hdr(i).src_profile_option));
            xrec.current_salesrep_source := 'DefaultRule Header PROFILE';
         elsif (gt_defRules_hdr(i).src_constant_value is not null) then
            xrec.current_salesrep_id := gt_defRules_hdr(i).src_constant_value;
            xrec.current_salesrep_source := 'DefaultRule Header CONSTANT';
         end if;
if (xrec.current_salesrep_id is not null) then
exit;  -- salesrep found, so exit loop
end if;
exception
when e_skip then
       null;
      end;
end loop;
exception
   when e_skip then
      null;
end apply_header_default_rules;
-----------------------------------------------
-- apply line defaulting rules for salesrep
-----------------------------------------------
procedure apply_line_default_rules (
   xrec  in out  cur_get_data%rowtype
  ) is
  e_skip  exception;
begin
   for i in 1..gt_defRules_lin.count
   loop
      begin

         -- <Rev 2.1 : defaulting condition is not met then skip the rule
         if (not defaulting_condition_met(
                            xrec
                           ,gt_defRules_lin(i).condition_id
                           ,gt_defRules_lin(i).number_of_elements
                           ,gt_defRules_lin(i).database_object_name) ) then
            raise e_skip;
         end if;
         -- Rev 2.1>

         if (gt_defRules_lin(i).src_type = 'RELATED_RECORD') then
            if (gt_defRules_lin(i).src_database_object_name = 'OE_AGREEMENTS_V') then
               if ont_agreement_def_util.sync_agreement_cache (p_agreement_id => xrec.lin_agreement_id ) = 1 then
                  xrec.current_salesrep_id := ont_agreement_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Line AGREEMENT';
               end if;
            elsif (gt_defRules_lin(i).src_database_object_name = 'OE_AK_SHIP_TO_ORGS_V') then
               if ont_ship_to_org_def_util.sync_ship_to_org_cache (p_organization_id => xrec.lin_ship_to_org_id ) = 1 then
                  xrec.current_salesrep_id := ont_ship_to_org_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Line SHIPTO';
               end if;
            elsif (gt_defRules_lin(i).src_database_object_name = 'OE_AK_INVOICE_TO_ORGS_V') then
               if ont_inv_org_def_util.sync_inv_org_cache (p_organization_id => xrec.lin_invoice_to_org_id ) = 1 then
                  xrec.current_salesrep_id := ont_inv_org_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Line BILLTO';
               end if;
            elsif (gt_defrules_lin(i).src_database_object_name = 'OE_AK_SOLD_TO_ORGS_V') then
               if ont_sold_to_org_def_util.sync_sold_to_org_cache (p_organization_id => xrec.lin_sold_to_org_id , p_ORG_ID => NULL) = 1 then
                  xrec.current_salesrep_id := ont_sold_to_org_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Line SOLDTO';
               end if;
            elsif (gt_defRules_lin(i).src_database_object_name = 'OE_AK_BLANKET_LINES_V') then
               if ont_blanket_line_def_util.sync_blanket_line_cache (p_order_number => xrec.lin_blanket_number
                                                                    ,p_line_number => xrec.lin_blanket_line_number ) = 1 then
                  xrec.current_salesrep_id := ont_blanket_line_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Line BLANKET LINE';
               end if;
            elsif (gt_defRules_lin(i).src_database_object_name = 'OE_AK_BLANKET_HEADERS_V') then
               if ont_blanket_header_def_util.sync_blanket_header_cache (p_order_number => xrec.lin_blanket_number ) = 1 then
                  xrec.current_salesrep_id := ont_blanket_header_def_util.g_cached_record.salesrep_id;
                  xrec.current_salesrep_source := 'DefaultRule Line BLANKET HDR';
               end if;

               -- NOTE: we want what it would be now, so ...
            elsif (gt_defRules_lin(i).src_database_object_name = 'OE_AK_ORDER_HEADERS_V') then
               -- <Rev 2.1
               /***********
               -- do not take from header as is, but let it fall thru to derive based on header default rules
               NULL;
               --if ont_header_def_util.sync_header_cache (p_header_id => xrec.lin_header_id ) = 1 then
               --   xrec.current_salesrep_id := ont_header_def_util.g_cached_record.salesrep_id;
               --end if;
               ***********/

               apply_header_default_rules(xrec);

               -- Rev 2.1>
            end if;
         elsif (gt_defRules_lin(i).src_type = 'PROFILE_OPTION') then
            xrec.current_salesrep_id := fnd_number.canonical_to_number (FND_PROFILE.VALUE(gt_defRules_lin(i).src_profile_option));
            xrec.current_salesrep_source := 'DefaultRule Line PROFILE';
         end if;

         if (xrec.current_salesrep_id is not null) then

            exit;  -- salesrep found, so exit loop

         end if;

      exception
         when e_skip then
            null;
      end;

   end loop;
end apply_line_default_rules;
PROCEDURE get_override_salesrep (p_org_id  IN      NUMBER,
                                 xrec      IN OUT  cur_get_data%ROWTYPE
  ) IS
    CURSOR get_shipto (p_product_line IN VARCHAR2,
                       p_ship_to_site_use_id IN NUMBER) IS
    SELECT salesrep_id
      FROM haemo.xx_haemo_sls_rep_override
     WHERE product_line = p_product_line
       AND shipto_site_use_id = p_ship_to_site_use_id
       AND billto_site_use_id is null;

    CURSOR get_billto (p_product_line IN VARCHAR2,
                       p_bill_to_site_use_id IN NUMBER) IS
    SELECT salesrep_id
      FROM haemo.xx_haemo_sls_rep_override
     WHERE product_line = p_product_line
       AND billto_site_use_id = p_bill_to_site_use_id
       AND shipto_site_use_id is null;

    -- New cursor Rev 4.2
    CURSOR get_salesrep ( p_product_line IN VARCHAR2,
                          p_bill_to_site_use_id IN NUMBER,
                          p_ship_to_site_use_id IN NUMBER) IS
     SELECT salesrep_id
      FROM haemo.xx_haemo_sls_rep_override
     WHERE product_line = p_product_line
       AND shipto_site_use_id = p_ship_to_site_use_id
       AND billto_site_use_id = p_bill_to_site_use_id;

  v_salesrep_id   haemo.xx_haemo_sls_rep_override.salesrep_id%TYPE;
  v_product_line VARCHAR2(25);
BEGIN
  v_salesrep_id  := NULL;
  v_product_line := NULL;

  /* get the inventory product line */
  SELECT MAX(product_line)
    INTO v_product_line
    FROM haemo.XX_HAEMO_ITEM_DETAILS
   WHERE inventory_item_id =  xrec.inventory_item_id;

-- new logic as per Rev 4.2

  IF v_product_line IS NOT NULL
  THEN

	OPEN get_salesrep(v_product_line,xrec.bill_to_site_use_id,xrec.ship_to_site_use_id);

	FETCH get_salesrep INTO v_salesrep_id;

		IF get_salesrep%NOTFOUND THEN

			OPEN get_billto(v_product_line,xrec.bill_to_site_use_id);

			FETCH get_billto INTO v_salesrep_id;

				   IF get_billto%NOTFOUND THEN

					OPEN get_shipto(v_product_line,xrec.ship_to_site_use_id);
					FETCH get_shipto INTO v_salesrep_id;
						   IF get_shipto%NOTFOUND THEN
						     v_salesrep_id := NULL;
						   ELSE
							xrec.current_salesrep_source := 'Sales Rep Override';
						   END IF;
					CLOSE get_shipto;

				   ELSE
xrec.current_salesrep_source := 'Sales Rep Override';
END IF;
CLOSE 	get_billto;
ELSE
xrec.current_salesrep_source := 'Sales Rep Override';
END IF;
CLOSE get_salesrep;
 END IF;
/* OLD LOGIC
-----------------------------------
   check for a shipto override
  OPEN get_shipto(v_product_line,xrec.ship_to_site_use_id);
  FETCH get_shipto INTO v_salesrep_id;
  IF get_shipto%NOTFOUND THEN
    v_salesrep_id := NULL;
  ELSE
    xrec.current_salesrep_source := 'Sales Rep Override';
  END IF;
  CLOSE get_shipto;

  --if no shipto override found, loop for the bill to
  IF v_salesrep_id IS NULL THEN
    OPEN get_billto(v_product_line,xrec.bill_to_site_use_id);
    FETCH get_billto INTO v_salesrep_id;
    IF get_billto%NOTFOUND THEN
      v_salesrep_id := NULL;
    ELSE
      xrec.current_salesrep_source := 'Sales Rep Override';
    END IF;
    CLOSE get_billto;
  END IF;
-----------------------------------
*/
IF v_salesrep_id IS NOT NULL THEN
  xrec.current_salesrep_id := v_salesrep_id;
begin
  if (xrec.current_salesrep_id is not null) then
 /*select  name
                 ,salesrep_number
          into    xrec.current_salesrep_name
                 ,xrec.current_salesrep_number
          from    ra_salesreps
          where   salesrep_id = xrec.current_salesrep_id;*/

          -- Rev 4.2 changed this script to get the correct sales rep name
          select  RES.RESOURCE_NAME
                    ,js.salesrep_number
             into    xrec.current_salesrep_name
                    ,xrec.current_salesrep_number
             from   jtf_rs_salesreps js inner join JTF_RS_RESOURCE_EXTNS_VL RES
                    on js.RESOURCE_ID = RES.RESOURCE_ID
             where   js.salesrep_id = xrec.current_salesrep_id;

       end if;
       -- end Rev 4.2
    exception
       when no_data_found then
          begin
             select  max(RES.RESOURCE_NAME)
                    ,max(salesrep_number)
             into    xrec.current_salesrep_name
                    ,xrec.current_salesrep_number
             from    jtf_rs_salesreps js inner join JTF_RS_RESOURCE_EXTNS_VL RES
                    on js.RESOURCE_ID = RES.RESOURCE_ID
             where   js.salesrep_id = xrec.current_salesrep_id;
          exception
             when others then
                null;
          end;
       when others then
          null;
    end;

  END IF;

  EXCEPTION
    WHEN others THEN
      NULL;  -- return with no changes to the salesrep.

END;
-----------------------------------------------
-- derive salesrep based on default rules
-----------------------------------------------
procedure derive_current_salesrep (
         p_org_id  in  number
  ,xrec  in out  cur_get_data%rowtype
  ) is

  l_org_id_sav  varchar2(30);

  e_done  exception;

begin
  -- if driving attributes already cached, retrieve salesrep from cache
  if (    nvl(p_org_id,fnd_api.g_miss_num) = nvl(gr_cached.org_id,fnd_api.g_miss_num)
      and nvl(xrec.intercompany_flag,fnd_api.g_miss_char) = nvl(gr_cached.intercompany_flag,fnd_api.g_miss_char)
      and nvl(xrec.sales_order_source,fnd_api.g_miss_char) = nvl(gr_cached.sales_order_source,fnd_api.g_miss_char)
      and nvl(xrec.bill_to_site_use_id,fnd_api.g_miss_num) = nvl(gr_cached.bill_to_site_use_id,fnd_api.g_miss_num)
      and nvl(xrec.ship_to_site_use_id,fnd_api.g_miss_num) = nvl(gr_cached.ship_to_site_use_id,fnd_api.g_miss_num)
      and nvl(xrec.lin_agreement_id,fnd_api.g_miss_num) = nvl(gr_cached.lin_agreement_id,fnd_api.g_miss_num)
      and nvl(xrec.lin_ship_to_org_id,fnd_api.g_miss_num) = nvl(gr_cached.lin_ship_to_org_id,fnd_api.g_miss_num)
      and nvl(xrec.lin_invoice_to_org_id,fnd_api.g_miss_num) = nvl(gr_cached.lin_invoice_to_org_id,fnd_api.g_miss_num)
      and nvl(xrec.lin_sold_to_org_id,fnd_api.g_miss_num) = nvl(gr_cached.lin_sold_to_org_id,fnd_api.g_miss_num)
      and nvl(xrec.lin_blanket_number,fnd_api.g_miss_num) = nvl(gr_cached.lin_blanket_number,fnd_api.g_miss_num)
      and nvl(xrec.lin_blanket_line_number,fnd_api.g_miss_num) = nvl(gr_cached.lin_blanket_line_number,fnd_api.g_miss_num)
      and nvl(xrec.lin_header_id,fnd_api.g_miss_num) = nvl(gr_cached.lin_header_id,fnd_api.g_miss_num)
      and nvl(xrec.hdr_agreement_id,fnd_api.g_miss_num) = nvl(gr_cached.hdr_agreement_id,fnd_api.g_miss_num)
      and nvl(xrec.hdr_ship_to_org_id,fnd_api.g_miss_num) = nvl(gr_cached.hdr_ship_to_org_id,fnd_api.g_miss_num)
      and nvl(xrec.hdr_invoice_to_org_id,fnd_api.g_miss_num) = nvl(gr_cached.hdr_invoice_to_org_id,fnd_api.g_miss_num)
      and nvl(xrec.hdr_sold_to_org_id,fnd_api.g_miss_num) = nvl(gr_cached.hdr_sold_to_org_id,fnd_api.g_miss_num)
      and nvl(xrec.hdr_blanket_number,fnd_api.g_miss_num) = nvl(gr_cached.hdr_blanket_number,fnd_api.g_miss_num)
      and nvl(xrec.hdr_sold_to_site_use_id,fnd_api.g_miss_num) = nvl(gr_cached.hdr_sold_to_site_use_id,fnd_api.g_miss_num)
      and nvl(xrec.hdr_header_id,fnd_api.g_miss_num) = nvl(gr_cached.hdr_header_id,fnd_api.g_miss_num) ) then
     xrec.current_salesrep_id := gr_cached.current_salesrep_id;
     xrec.current_salesrep_name := gr_cached.current_salesrep_name;
     xrec.current_salesrep_number := gr_cached.current_salesrep_number;
     xrec.current_salesrep_source := gr_cached.current_salesrep_source;
raise e_done;
  end if;
-- buffer session Org ID setting
  fnd_profile.get('ORG_ID',l_org_id_sav);
-- is this an Intercompany transaction?
  -- IPadela 01/08/09 Rev 4.1
  --if (xrec.intercompany_flag = 'Y') then
  select  (case when billto_customer_type = 'Internal' then 'Y' else 'N' end)
  into    g_Is_InterCo
  from    xx_haemo_billto_cust_details
  where   billto_site_use_id = xrec.bill_to_site_use_id;
  if (g_Is_InterCo = 'Y') then
  -- end Rev 4.1
 -- temporarily switch session Org ID to access multi-org views
     MO_GLOBAL.SET_POLICY_CONTEXT('S',p_org_id);
-- set to No Sales Contract ...
     xrec.current_salesrep_id := -3;  -- No Sales Credit
     xrec.current_salesrep_source := 'Intercompany NSC';
-- is TRX sourced from Contracts or Manually Entered?
  elsif (   xrec.sales_order_source is null   -- sourced from Manual Entry
      or xrec.sales_order_source = 'OKS_CONTRACTS'   -- sourced from Contracts
     ) then
-- set prefix for Current Salesrep Source
  if (xrec.sales_order_source is null) then
        xrec.current_salesrep_source := 'ManualEntry ';
     else
        xrec.current_salesrep_source := 'Contract ';
     end if;
-- temporarily switch session Org ID to access multi-org views
     MO_GLOBAL.SET_POLICY_CONTEXT('S',xrec.org_id);
-- get salesrep assigned at customer site use ...
     begin
        select   primary_salesrep_id
                ,xrec.current_salesrep_source||'BILLTO'
        into     xrec.current_salesrep_id
                ,xrec.current_salesrep_source
        from     hz_site_uses_v  su
        where    site_use_id = xrec.bill_to_site_use_id
        and      primary_salesrep_id is not null;
xrec.current_salesrep_source := xrec.current_salesrep_source||'BILLTO';
 exception
        when no_data_found then
           begin
              select   primary_salesrep_id
                      ,xrec.current_salesrep_source||'SHIPTO'
              into     xrec.current_salesrep_id
                      ,xrec.current_salesrep_source
              from     hz_site_uses_v  su
              where    site_use_id = xrec.ship_to_site_use_id
              and      primary_salesrep_id is not null;

           exception
              when no_data_found then
                 xrec.current_salesrep_id := -3;   -- No Sales Credit
                 xrec.current_salesrep_source := xrec.current_salesrep_source||'NSC';
           end;
     end;
-- not Intercompany and not sourced from Contracts or manual entry ... so, apply default rules
  else
     -- temporarily switch session Org ID to access multi-org views
     MO_GLOBAL.SET_POLICY_CONTEXT('S',p_org_id);

     apply_line_default_rules(xrec);
     apply_header_default_rules(xrec);
end if;
begin
     if (xrec.current_salesrep_id is not null) then

        select  name
               ,salesrep_number
        into    xrec.current_salesrep_name
               ,xrec.current_salesrep_number
        from    ra_salesreps
        where   salesrep_id = xrec.current_salesrep_id;

     end if;
  exception
     when no_data_found then
        begin
           select  max(RES.RESOURCE_NAME)
                    ,max(salesrep_number)
             into    xrec.current_salesrep_name
                    ,xrec.current_salesrep_number
             from    jtf_rs_salesreps js inner join JTF_RS_RESOURCE_EXTNS_VL RES
                    on js.RESOURCE_ID = RES.RESOURCE_ID
             where   js.salesrep_id = xrec.current_salesrep_id;
        exception
           when others then
              null;
        end;
     when others then
        null;
  end;
-- cache current salesrep
  gr_cached.org_id := p_org_id;
  gr_cached.intercompany_flag := xrec.intercompany_flag;
  gr_cached.sales_order_source := xrec.sales_order_source;
  gr_cached.bill_to_site_use_id := xrec.bill_to_site_use_id;
  gr_cached.ship_to_site_use_id := xrec.ship_to_site_use_id;
  gr_cached.lin_agreement_id := xrec.lin_agreement_id;
  gr_cached.lin_ship_to_org_id := xrec.lin_ship_to_org_id;
  gr_cached.lin_invoice_to_org_id := xrec.lin_invoice_to_org_id;
  gr_cached.lin_sold_to_org_id := xrec.lin_sold_to_org_id;
  gr_cached.lin_blanket_number := xrec.lin_blanket_number;
  gr_cached.lin_blanket_line_number := xrec.lin_blanket_line_number;
  gr_cached.lin_header_id := xrec.lin_header_id;
  gr_cached.hdr_agreement_id := xrec.hdr_agreement_id;
  gr_cached.hdr_ship_to_org_id := xrec.hdr_ship_to_org_id;
  gr_cached.hdr_invoice_to_org_id := xrec.hdr_invoice_to_org_id;
  gr_cached.hdr_sold_to_org_id := xrec.hdr_sold_to_org_id;
  gr_cached.hdr_blanket_number := xrec.hdr_blanket_number;
  gr_cached.hdr_sold_to_site_use_id := xrec.hdr_sold_to_site_use_id;
  gr_cached.hdr_header_id := xrec.hdr_header_id;
gr_cached.current_salesrep_id := xrec.current_salesrep_id;
  gr_cached.current_salesrep_name := xrec.current_salesrep_name;
  gr_cached.current_salesrep_number := xrec.current_salesrep_number;
  gr_cached.current_salesrep_source := xrec.current_salesrep_source;
-- restore session Org ID setting
  MO_GLOBAL.SET_POLICY_CONTEXT('S',l_org_id_sav);
exception
  when e_done then
     null;
end derive_current_salesrep;
PROCEDURE main (
   p_trx_number  in  xx_haemo_sales_revenue.trx_number%type
  )
IS
-- Declaring local variables for procedure
  --
  --
  lv_ship_to_class_code    VARCHAR2(30) := NULL;
  lv_bill_to_class_code    VARCHAR2(30) := NULL;
  lv_flag      VARCHAR2(1) := NULL;
  ln_index  number := 0;
  ln_org_id  number;
e_skip  exception;
CURSOR cur_ship_to (cp_ship_to_customer_id NUMBER)
           IS
    SELECT  UPPER(SHIP_XHCD.SHIPTO_CUSTOMER_CLASS_CODE)
    FROM    XX_HAEMO_SHIPTO_CUST_DETAILS SHIP_XHCD
    WHERE   SHIP_XHCD.SHIPTO_CUSTOMER_ID = cp_ship_to_customer_id;

  CURSOR cur_bill_to (cp_bill_to_customer_id NUMBER)
           IS
    SELECT UPPER(BILL_XHCD.BILLTO_CUSTOMER_CLASS_CODE)
    FROM XX_HAEMO_BILLTO_CUST_DETAILS BILL_XHCD
    WHERE BILL_XHCD.BILLTO_CUSTOMER_ID = cp_bill_to_customer_id;
-- <Rev 2.0 : cursor for default rules for salesrep derivation
  cursor c_df (
           q_database_object_name  oe_def_attr_def_rules.database_object_name%type
          ) is
    select  r.src_type
           ,r.database_object_name
           ,r.src_database_object_name
           ,r.src_profile_option
           ,r.src_constant_value  -- <Rev 2.1>
           ,ac.condition_id  -- <Rev 2.1>
           ,c.number_of_elements  -- <Rev 2.1>
    from    oe_def_attr_condns  ac
           ,oe_def_attr_def_rules  r
           ,oe_def_conditions  c
    where   ac.database_object_name = q_database_object_name
    and     ac.attribute_code = 'SALESREP_ID'
    and     ac.enabled_flag = 'Y'
    and     r.attr_def_condition_id = ac.attr_def_condition_id
    and     c.condition_id = ac.condition_id
    and     c.database_object_name = r.database_object_name
    order by  ac.database_object_name  desc
             ,ac.precedence  -- <Rev 2.1>
             ,r.sequence_no;
  -- Rev 2.0>
BEGIN
  -- <Rev 2.0 : buffer default rules for salesrep derivation

  -- buffer salesrep derivation default rules driven by header
  for dfrec in c_df('OE_AK_ORDER_LINES_V')
  loop
     ln_index := ln_index + 1;
     gt_defRules_lin(ln_index).src_type := dfrec.src_type;
     gt_defRules_lin(ln_index).database_object_name := dfrec.database_object_name;
     gt_defRules_lin(ln_index).src_database_object_name := dfrec.src_database_object_name;
     gt_defRules_lin(ln_index).src_profile_option := dfrec.src_profile_option;
     -- <Rev 2.1 : buffer defaulting conditions
     gt_defRules_lin(ln_index).src_constant_value := dfrec.src_constant_value;
     gt_defRules_lin(ln_index).condition_id := dfrec.condition_id;
     gt_defRules_lin(ln_index).number_of_elements := dfrec.number_of_elements;
     -- Rev 2.1>
  end loop;

  -- buffer salesrep derivation default rules driven by line
  ln_index := 0;
  for dfrec in c_df('OE_AK_ORDER_HEADERS_V')
  loop
     ln_index := ln_index + 1;
     gt_defRules_hdr(ln_index).src_type := dfrec.src_type;
     gt_defRules_hdr(ln_index).database_object_name := dfrec.database_object_name;
     gt_defRules_hdr(ln_index).src_database_object_name := dfrec.src_database_object_name;
     gt_defRules_hdr(ln_index).src_profile_option := dfrec.src_profile_option;
     -- <Rev 2.1 : buffer defaulting conditions
     gt_defRules_hdr(ln_index).src_constant_value := dfrec.src_constant_value;
     gt_defRules_hdr(ln_index).condition_id := dfrec.condition_id;
     gt_defRules_hdr(ln_index).number_of_elements := dfrec.number_of_elements;
     -- Rev 2.1>
  end loop;
  -- Rev 2.0>
-- initialize cache for derived salesrep
  gr_cached.org_id := fnd_api.g_miss_num;
  gr_cached.intercompany_flag := fnd_api.g_miss_char;
  gr_cached.sales_order_source := fnd_api.g_miss_char;
  gr_cached.bill_to_site_use_id := fnd_api.g_miss_num;
  gr_cached.ship_to_site_use_id := fnd_api.g_miss_num;
  gr_cached.lin_agreement_id := fnd_api.g_miss_num;
  gr_cached.lin_ship_to_org_id := fnd_api.g_miss_num;
  gr_cached.lin_invoice_to_org_id := fnd_api.g_miss_num;
  gr_cached.lin_sold_to_org_id := fnd_api.g_miss_num;
  gr_cached.lin_blanket_number := fnd_api.g_miss_num;
  gr_cached.lin_blanket_line_number := fnd_api.g_miss_num;
  gr_cached.lin_header_id := fnd_api.g_miss_num;
  gr_cached.hdr_agreement_id := fnd_api.g_miss_num;
  gr_cached.hdr_ship_to_org_id := fnd_api.g_miss_num;
  gr_cached.hdr_invoice_to_org_id := fnd_api.g_miss_num;
  gr_cached.hdr_sold_to_org_id := fnd_api.g_miss_num;
  gr_cached.hdr_blanket_number := fnd_api.g_miss_num;
  gr_cached.hdr_sold_to_site_use_id := fnd_api.g_miss_num;
  gr_cached.hdr_header_id := fnd_api.g_miss_num;
  gr_cached.current_salesrep_id := fnd_api.g_miss_num;
  gr_cached.current_salesrep_name := fnd_api.g_miss_char;
  gr_cached.current_salesrep_number := fnd_api.g_miss_char;
  gr_cached.current_salesrep_source := fnd_api.g_miss_char;
FOR rec_get_data IN cur_get_data (p_trx_number)
  LOOP
-- Determine value for TRADE_FLAG
     lv_ship_to_class_code := NULL;
     lv_bill_to_class_code := NULL;
     lv_flag := NULL;
OPEN cur_ship_to (cp_ship_to_customer_id => rec_get_data.ship_to_customer_id);
     FETCH cur_ship_to INTO lv_ship_to_class_code;
     CLOSE cur_ship_to;
OPEN cur_bill_to (cp_bill_to_customer_id => rec_get_data.bill_to_customer_id);
     FETCH cur_bill_to INTO lv_bill_to_class_code;
     CLOSE cur_bill_to;

     IF (   lv_bill_to_class_code IN ('NON -TRADE', 'INHOUSE')
         OR lv_ship_to_class_code IN ('NON -TRADE', 'INHOUSE') ) THEN
        rec_get_data.trade_flag := 'N';
     ELSE
        rec_get_data.trade_flag := 'Y';
     END IF;
begin
        ln_org_id := null;

        -- if not numeric, skip fetching the attribute values
        if (isnumeric(nvl(rec_get_data.order_number,'null')) = 0) then
           raise e_skip;
        end if;
-- fetch attributes derived from Order Line
        begin
           select  tl2.name
                  ,oea.attribute1
                  ,oel.org_id
                  ,oel.agreement_id
                  ,oel.ship_to_org_id
                  ,oel.invoice_to_org_id
                  ,oel.sold_to_org_id
                  ,oel.blanket_number
                  ,oel.blanket_line_number
                  ,oel.header_id
           into    rec_get_data.order_line_type
                  ,rec_get_data.end_customer_id
                  ,rec_get_data.lin_org_id
                  ,rec_get_data.lin_agreement_id
                  ,rec_get_data.lin_ship_to_org_id
                  ,rec_get_data.lin_invoice_to_org_id
                  ,rec_get_data.lin_sold_to_org_id
                  ,rec_get_data.lin_blanket_number
                  ,rec_get_data.lin_blanket_line_number
                  ,rec_get_data.lin_header_id
           from    oe_order_lines_all  oel
                  ,oe_agreements_b  oea
                  ,oe_transaction_types_tl  tl2
           where   oel.line_id = to_number(rec_get_data.line_id)
           and     oea.agreement_id(+) = oel.agreement_id
           and     tl2.transaction_type_id (+) = oel.line_type_id
           and     tl2.language (+) = 'US';

        exception
           when no_data_found then
              null;
        end;
--<Rev 2.1 : check that matched line matches to the order ...
    -- if the LINE_ID was found and matches to the order header,
        -- keep fetched line attributes; if it does not match to the order header,
        -- discard fetched line attributes and prepare to fetch header
-- was line found?
        if (rec_get_data.lin_org_id is not null) then
           ln_org_id := rec_get_data.lin_org_id;
-- find order header
           begin
              select  oeh.org_id
                     ,oeh.header_id
              into    rec_get_data.hdr_org_id
                     ,rec_get_data.hdr_header_id
              from    oe_order_headers_all  oeh
              where   oeh.order_number = to_number(rec_get_data.order_number)
              and     oeh.org_id = rec_get_data.lin_org_id
              -- Rev 4.5 IPadela 07/24/13 - added and extra join in the order header query as the order number is no more unique within an Oper Unit now
              and exists (select 1 from oe_order_lines_all l where oeh.header_id = l.header_id and l.line_id = to_number(rec_get_data.line_id));

           exception
              when no_data_found then
                 null;
           end;
--    was an order header not found
           -- or found but not matched to line?
           if (   rec_get_data.hdr_org_id is null
               or (    rec_get_data.hdr_org_id is not null
                   and rec_get_data.hdr_header_id <> rec_get_data.lin_header_id) )then
ln_org_id := rec_get_data.org_id;
-- discard fetched order line attributes
              rec_get_data.order_line_type := null;
              rec_get_data.end_customer_id := null;
              rec_get_data.lin_org_id := null;
              rec_get_data.lin_agreement_id := null;
              rec_get_data.lin_ship_to_org_id := null;
              rec_get_data.lin_invoice_to_org_id := null;
              rec_get_data.lin_sold_to_org_id := null;
              rec_get_data.lin_blanket_number := null;
              rec_get_data.lin_blanket_line_number := null;
              rec_get_data.lin_header_id := null;
              rec_get_data.hdr_org_id := null;
              rec_get_data.hdr_header_id := null;
end if;
else  -- line not found
           ln_org_id := rec_get_data.org_id;
        end if;
-- fetch attributes derived from Order Header
        begin
           select  oeh.sold_to_site_use_id
                  ,tl1.name
                  ,oeh.agreement_id
                  ,oeh.ship_to_org_id
                  ,oeh.sold_to_org_id
                  ,oeh.invoice_to_org_id
                  ,oeh.sold_to_site_use_id
                  ,oeh.blanket_number
                  ,oeh.org_id  --<Rev 2.1>
                  ,oeh.org_id  --<Rev 2.1>
                  ,oeh.header_id  --<Rev 2.1>
           into    rec_get_data.sold_to_site_use_id
                  ,rec_get_data.order_type
                  ,rec_get_data.hdr_agreement_id
                  ,rec_get_data.hdr_ship_to_org_id
                  ,rec_get_data.hdr_sold_to_org_id
                  ,rec_get_data.hdr_invoice_to_org_id
                  ,rec_get_data.hdr_sold_to_site_use_id
                  ,rec_get_data.hdr_blanket_number
                  ,rec_get_data.order_org_id  --<Rev 2.1>
                  ,rec_get_data.hdr_org_id  --<Rev 2.1>
                  ,rec_get_data.hdr_header_id  --<Rev 2.1>
           from    oe_order_headers_all  oeh
                  ,oe_transaction_types_tl  tl1
           where   oeh.order_number = to_number(rec_get_data.order_number)
           and     oeh.org_id = ln_org_id
           and     tl1.transaction_type_id(+) = oeh.order_type_id
           and     tl1.language(+) = 'US'
           -- Rev 4.5 IPadela 07/24/13 - added and extra join in the order header query as the order number is no more unique within an Oper Unit now
           and exists (select 1 from oe_order_lines_all l where oeh.header_id = l.header_id and l.line_id = to_number(rec_get_data.line_id))
           ;

        exception
           when no_data_found then
              null;
        end;
exception
        when e_skip then null;
     end;

     derive_current_salesrep(ln_org_id,rec_get_data);
     get_override_salesrep ( ln_org_id,rec_get_data);
rec_get_data.blanket_number := nvl(rec_get_data.lin_blanket_number,rec_get_data.hdr_blanket_number);
     rec_get_data.blanket_line_number := rec_get_data.lin_blanket_line_number;
UPDATE  XX_HAEMO_SALES_REVENUE
     SET     -- Initial
             TRADE_FLAG = rec_get_data.trade_flag
             -- Rev 1.0
            ,sold_to_site_use_id = rec_get_data.sold_to_site_use_id
            ,order_type = rec_get_data.order_type
            ,end_customer_id = rec_get_data.end_customer_id
            ,order_line_type = rec_get_data.order_line_type
             -- Rev 2.0
            ,blanket_number = rec_get_data.blanket_number
            ,blanket_line_number = rec_get_data.blanket_line_number
            ,current_salesrep_id = rec_get_data.current_salesrep_id
            ,current_salesrep_name = rec_get_data.current_salesrep_name
            ,current_salesrep_number = rec_get_data.current_salesrep_number
            ,current_salesrep_source = rec_get_data.current_salesrep_source
             -- Rev 2.1
            ,order_org_id = rec_get_data.order_org_id
            -- Rev 4.1
            ,intercompany_flag = g_Is_InterCo
     WHERE   rowid = rec_get_data.rowid;
COMMIT;
END LOOP;
end main;
END XX_HAEMO_CUSTOMER_TRADE_PKG;
/
