create or replace PACKAGE BODY XXHA_SERV_REQ_CLOSE_PKG
AS


/***********************************************************************************************************************************
* Package Name : XXHA_SERV_REQ_CLOSE_PKG                                                                                           *
*                                                                                                                                  *
* Purpose      : This package will process all Service Requests (and Depot Repair Orders, if they exist) that are determined       *
*                 to be eligible for closure based upon selected criteria.                                                         *
*                                                                                                                                  *
* Procedures   : TRANSACTION_MAIN                                                                                                  *
*                CHECK_DR_SR_TASKS_DAYS                                                                                            *
*                CHECK_DR_SR_TASK_STATUS                                                                                           *
*                EDITS_PRE_PROCESS                                                                                                 *
*                EDITS_SR_WITH_DR                                                                                                  *
*                EDITS_SR_WITHOUT_DR                                                                                               *
*                DEBRIEF_PROCESS_WITH_DR                                                                                           *
*                DEBRIEF_PROCESS_WITHOUT_DR                                                                                        *
*                DEBRIEF_TASK_STATUS_UPDATE                                                                                        *
*                DEBRIEF_TASK_ASSIGN_UPDATE                                                                                        *
*                DEBRIEF_SUBMIT_CONCURRENT_PGM                                                                                     *
*                FIND_RECENT_SR                                                                                                    *
*                UPDATE_OM_INTERFACE                                                                                               *
*                ORDER_SUBMIT_DETERMINATION                                                                                        *
*                ORDER_SUBMIT_WITHOUT_CC                                                                                           *
*                ORDER_SUBMIT_WITH_CC                                                                                              *
*                ORDER_UPDATE_WITH_CC                                                                                              *
*                ORDER_UPDATE_SET_TO_BOOKED                                                                                        *
*                UPDATE_LOGISTIC_LINES_FOR_DR                                                                                      *
*                CLOSE_DEPOT_REPAIR_ORDERS                                                                                         *
*                EDITS_POST_PROCESS                                                                                                *
*                EDITS_POST_SR_WITH_DR                                                                                             *
*                EDITS_POST_SR_WITHOUT_DR                                                                                          *
*                CLOSE_SERVICE_REQUEST                                                                                             *
*                REPORT_SUBMISSION                                                                                                 *
*                WRITE_HEADER                                                                                                      *
*                WRITE_DETAIL                                                                                                      *
*                                                                                                                                  *
* Change History                                                                                                                   *
*                                                                                                                                  *
* Ver        Date            Author                    Description                                                                 *
* ------     -----------     ----------------------    -----------------------------------------------                             *
* 1.0        29-JUN-2016     Bruce Marcoux             Initial Package creation                                                    *
*                                                                                                                                  *
* 2.0        04-APR-2017     Bruce Marcoux             ESC115336/INC0104753 - Concurrent program does not end                      *
*                                                        Issue was with code in the procedure 'DEBRIEF_SUBMIT_CONCURRENT_PGM'      *
*                                                        as it was looping when checking the status of the submitted debrief.      *
*                                                        Modified code to check Status_Code for the submitted program.  If         *
*                                                        Status_Code has 'E' or 'D', code will drop out of loop that checks        *
*                                                        the job for completion and will return an error to the calling            *
*                                                        procedure.  The calling procedures were modified to check for an          *
*                                                        error and handle it accordingly.                                          *
*                                                                                                                                  *
* 3.0        04-MAY-2017     Bruce Marcoux             INC0106532 - Service Request Closure program taking longer than normal      *
*                                                        to process.                                                               *
*                                                        Modified code to not write out debug statements.  Processing will         *
*                                                        check P_Debug for value instead of always writing debugs to table.        *
*                                                        Commented out unncessary FND_FILE.PUT_LINE statements.                    *
*                                                                                                                                  *
* 4.0        17-MAY-2017     Bruce Marcoux              INC0107158 - Task Assignment Error Message unclear                         *
*                                                        Corrected code when checking DFF's Context Value for Task Assingments     *
*                                                        and Task Assignments Additional.                                          *
*                                                        Checking additional columns:                                              *
*                                                        AND fdfv1.context_required_flag           = 'Y'                           *
*                                                        AND fdfv1.context_user_override_flag      = 'Y'                           *
*                                                        AND fdfcv1.enabled_flag                   = 'Y'                           *
*                                                        AND fdfcuv1.display_flag                  = 'Y'                           * 
*                                                        AND fdfcuv1.enabled_flag                  = 'Y'                           *
*                                                                                                                                  *
* 5.0        06-JUN-2017     Bruce Marcoux              INC0107201 - Service Batch - Records processed with errors email not sent. *
*                                                        Modification to place spreadsheets on server and be picked up by          *
*                                                        WebMethods processing and placed on shared drive instead of being         *
*                                                        emailed as an attachment. Added PARM: P_REPORT_PROGRAM_ID.                *
************************************************************************************************************************************/

--------------------------------------------------------------------------------
-- TRANSACTION_MAIN

PROCEDURE TRANSACTION_MAIN(x_errbuf                        OUT VARCHAR2
                         , x_retcode                       OUT VARCHAR2
                         , P_Process_Type                  IN  VARCHAR2
                         , P_Operating_Unit_Group          IN  VARCHAR2
                         , P_Concurrent_Program_Name       IN  VARCHAR2
                         , P_Service_Request_Nbr           IN  VARCHAR2
                         , P_Org_ID                        IN  NUMBER
                         , P_Debug                         IN  VARCHAR2
                         , P_Concurrent_Pgm                IN  VARCHAR2
                         , P_Template_Code                 IN  VARCHAR2
                         , P_Value_Set_ID                  IN  NUMBER
                         , P_Task_Number_Days              IN  NUMBER
                         , P_SR_Creation_Date              IN  VARCHAR2
                         , P_SR_Creation_Date_To           IN  VARCHAR2
                         , P_Purge_Number_Days             IN  NUMBER
                         , P_EMAIL_SERVER                  IN  VARCHAR2
                         , P_EMAIL_PORT                    IN  VARCHAR2
                         , P_TEST_EMAIL_ACCOUNT            IN  VARCHAR2
                         , P_PRODUCTION_INSTANCE_DB_NAME   IN  VARCHAR2
                         , P_Value_Set_ID_EMail            IN  NUMBER
                         , P_REPORT_PROGRAM_ID             IN  NUMBER
                         ) AS

l_Count                           NUMBER                                        := 0;
l_errbuf                          VARCHAR2(2000)                                := NULL;
l_retcode                         VARCHAR2(2000)                                := NULL;
l_DLT_XXHA_SERV_REQ_CLOSE_HDR     VARCHAR2(500)                                 := NULL;
l_DLT_XXHA_SERV_REQ_CLOSE_DTL     VARCHAR2(500)                                 := NULL;

l_CLOSE_DR_API_Error              XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_DR_SR_TASKS_PROCESS             XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_DR_SR_TASK_STATUS_PROCESS       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_UPDATE_OM_API_Error             XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Order_API_Error                 XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_DR_API_Error                    XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Close_Depot_Repair_Order        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_EDITS_PRE_PROCESS         XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_EDITS_POST_PROCESS        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_CLOSE_SERVICE_REQUEST     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Setup_Error                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_SR_Creation_Date                CS_SR_Incidents_V.Creation_Date%TYPE          := NULL;
l_SR_Creation_Date_To             CS_SR_Incidents_V.Creation_Date%TYPE          := NULL;

-- Cursor to retrieve Session ID and SYSDATE
CURSOR cur_0020
IS
SELECT
    SYS_CONTEXT('userenv', 'sessionid') Session_ID 
  , SYSDATE
FROM
    DUAL
;

-- Retrieve Application_Short_Name for Concurrent Program passed in ('CSFUPDATE')
CURSOR cur_0040
IS
SELECT
    FA.Application_Short_Name
FROM
    fnd_Concurrent_Programs       FCP
  , fnd_Application               FA
WHERE
    FCP.Application_ID          = FA.Application_ID
AND FCP.Concurrent_Program_Name = g_Concurrent_Program_Name
;

-- Cursor to retrieve Service Request Data
CURSOR cur_0060
IS
SELECT
    csi.Org_ID
  , hou.name                           ORG_NAME 
  , csi.Inventory_Item_ID
  , itm.Segment1
  , ccs.Serial_Number
  , csi.Incident_Date
  , csi.Incident_ID
  , csi.Incident_Number
  , csi.Incident_Status_ID
  , csi.Status_Code
  , csi.closed_Flag
  , csi.Incident_Type_ID
  , csi.Contract_Number
  , csi.Contract_ID
  , (DECODE(csi.incident_location_type, 'HZ_PARTY_SITE', 
           (SELECT hl.country  FROM apps.hz_party_sites hps
                                  , apps.hz_locations   hl
                              WHERE hps.party_site_id = csi.incident_location_id
                                AND hl.location_id    = hps.location_id),
                                        'HZ_LOCATION',
           (SELECT hl1.country FROM apps.hz_locations   hl1
                              WHERE hl1.location_id   = csi.incident_location_id), 
                                         NULL)) Incident_country
  , citv.name                          INCIDENT_TYPE
  , hri.Attribute2
  , hri.Attribute3
  , msib_svc.segment1                  CONTRACT_TYPE_ITEM
FROM
    CS_SR_Incidents_V                  csi 
  , csi_item_instances                 ccs
  , mtl_system_items_b                 itm
  , cs_incident_types_vl               citv
  , Hr_Operating_Units                 hou
  , okc_k_headers_all_b                okhab
  , okc_k_lines_b                      oklb
  , okc_k_items                        oki
  , mtl_system_items_b                 msib_svc
  , (SELECT
           hou.organization_ID             Org_ID
         , hroi.Attribute2
         , hroi.Attribute3
      FROM
           Hr_Operating_Units              hou
         , HR_ORGANIZATION_INFORMATION_V   hroi
     WHERE
           HOU.ORGANIZATION_ID           = hroi.ORGANIZATION_ID
       AND org_information_context       = 'Operating Unit Information'
       AND hroi.Attribute_Category(+)    = 'Operating Unit'
       AND UPPER(hroi.Attribute1)        = UPPER(P_Operating_Unit_Group)) hri
  , (SELECT
           VL.FLEX_VALUE
      FROM
           fnd_flex_value_Sets         ST
         , fnd_flex_values_vl          VL
     WHERE
           ST.flex_value_set_id      = P_Value_Set_ID
       AND ST.flex_value_set_id      = VL.flex_value_set_id
       AND TRUNC(SYSDATE)            BETWEEN NVL(TRUNC(VL.Start_Date_Active),TRUNC(SYSDATE-1)) AND NVL(TRUNC(VL.End_Date_Active),TRUNC(SYSDATE+1))  
       AND NVL(VL.Enabled_Flag, 'N') = 'Y')  VLF
WHERE
    csi.Org_ID                       = hou.Organization_ID
AND csi.Incident_Type_ID             = citv.Incident_Type_ID(+)
AND UPPER(csi.Status_Code)           NOT IN ('CLOSED', 'CANCELLED BY SYSTEM', 'CANCELLED BY USER')
AND csi.customer_product_ID          = ccs.instance_ID(+)
AND csi.Inventory_Item_ID            = itm.Inventory_item_ID
AND itm.Organization_id              = 103
AND csi.Org_ID                       = hri.Org_ID
AND csi.Org_ID                       = NVL(P_Org_ID, csi.Org_ID)
AND csi.Incident_Number              = NVL(P_Service_Request_Nbr, csi.Incident_Number)
AND okhab.id(+)                      = csi.contract_id
AND oklb.id(+)                       = csi.contract_service_id
AND oki.cle_id(+)                    = oklb.id
AND oki.jtot_object1_code(+)         = 'OKX_SERVICE'
AND msib_svc.inventory_item_id(+)    = oki.object1_id1
AND msib_svc.organization_id(+)      = 103
AND msib_svc.segment1                = vlf.FLEX_VALUE
AND TRUNC(csi.Creation_Date)         >= TRUNC(l_SR_Creation_Date)
AND TRUNC(csi.Creation_Date)         <= NVL(TRUNC(l_SR_Creation_Date_To), TRUNC(SYSDATE+1))

ORDER BY
    csi.Org_ID
  , csi.Incident_ID
;

-- Cursor to retrieve record count in reporting header table
CURSOR cur_0080
IS
SELECT
    NVL(COUNT(*),0)
FROM
    XXHA_SERV_REQ_CLOSE_HDR HDR
WHERE
    HDR.Creation_Date     = g_sysdate
AND HDR.Created_BY        = g_Current_User_ID
AND HDR.Session_ID        = g_Session_ID
;

BEGIN

   -- Purge data that is older than x number of days (as defined in P_Purge_Number_Days)
   l_DLT_XXHA_SERV_REQ_CLOSE_HDR := 'DELETE FROM HAEMO.XXHA_SERV_REQ_CLOSE_HDR HDR WHERE TRUNC(HDR.CREATION_DATE) <= ' || 'TRUNC(SYSDATE) -' || P_Purge_Number_Days;
   EXECUTE IMMEDIATE l_DLT_XXHA_SERV_REQ_CLOSE_HDR;
   COMMIT;

   -- Purge data that is older than x number of days (as defined in P_Purge_Number_Days)
   l_DLT_XXHA_SERV_REQ_CLOSE_DTL := 'DELETE FROM HAEMO.XXHA_SERV_REQ_CLOSE_DTL DTL WHERE TRUNC(DTL.CREATION_DATE) <= ' || 'TRUNC(SYSDATE) -' || P_Purge_Number_Days;
   EXECUTE IMMEDIATE l_DLT_XXHA_SERV_REQ_CLOSE_DTL;
   COMMIT;

   -- Set g_Sequence_Nbr_HDR, l_SR_Creation_Date
   g_Sequence_Nbr_HDR          := 1;
   l_SR_Creation_Date          := FND_DATE.CANONICAL_TO_DATE(P_SR_Creation_Date);

   -- Only perform CANONICAL_TO_DATE is there is a value
   IF P_SR_Creation_Date_To IS NOT NULL THEN
      l_SR_Creation_Date_To   := FND_DATE.CANONICAL_TO_DATE(P_SR_Creation_Date_To);
   ELSE
      l_SR_Creation_Date_To   := NULL;
   END IF;

   -- Retrieve current User_ID, Responsibility_ID and Resp_Appl_ID
   FND_GLOBAL.APPS_INITIALIZE(FND_GLOBAL.USER_ID, FND_GLOBAL.RESP_ID, FND_GLOBAL.RESP_APPL_ID);
   g_Current_User_ID           := fnd_profile.value('USER_ID');
   g_Current_Responsibility_ID := fnd_profile.value('RESP_ID');
   g_Current_Resp_Appl_ID      := fnd_profile.value('RESP_APPL_ID');

   -- Set Global Variables
   g_Value_Set_ID              := P_Value_Set_ID;
   g_Operating_Unit_Group      := p_Operating_Unit_Group;
   g_Concurrent_Program_Name   := P_Concurrent_Program_Name;
   g_Process_Type              := p_Process_Type;
   g_Debug                     := NVL(P_Debug, 'NO');

   -- Retrieve Session ID and SYSDATE
   OPEN cur_0020;
   FETCH cur_0020 INTO g_Session_ID, g_SysDate;
   CLOSE cur_0020;

   -- Show Parameters
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Process_Type:                              ' || P_Process_Type);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Operating_Unit_Group:                      ' || P_Operating_Unit_Group);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Concurrent_Program_Name:                   ' || P_Concurrent_Program_Name);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Incident_Nbr:                              ' || NVL(P_Service_Request_Nbr, 'N/A'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Org_ID:                                    ' || NVL(P_Org_ID, NULL));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Debug:                                     ' || NVL(P_Debug, 'NO'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Task_Number_Days:                          ' || P_Task_Number_Days);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_SR_Creation_Date_From:                     ' || l_SR_Creation_Date);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_SR_Creation_Date_To:                       ' || l_SR_Creation_Date_To);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Purge_Number_Days:                         ' || P_Purge_Number_Days);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Session_ID:                                  ' || g_Session_ID);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'                                             ');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Current_User_ID:                           ' || g_Current_User_ID);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Current_Responsibility_ID:                 ' || g_Current_Responsibility_ID);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Current_Resp_Appl_ID:                      ' || g_Current_Resp_Appl_ID);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'                                             ');

   -- Retrieve Application_Short_Name for Concurrent Program passed in ('CSFUPDATE')
   OPEN cur_0040;
   FETCH cur_0040 INTO g_Application_Short_Name;
   CLOSE cur_0040;

   IF g_Application_Short_Name IS NULL THEN
      l_Setup_Error := 'Y';
      WRITE_HEADER(-999, -999, -999, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, l_Setup_Error);
      l_Error_Message := ('Setup Issue: Concurrent_Program_Name for ' || '''Debrief Posting Program''' || ' IS NULL');
      WRITE_DETAIL(-999, -999, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- If no Setup errors then process the data
   IF NVL(l_Setup_Error, 'N') = 'N' THEN
      -- Cursor to retrieve Service Request Data
      FOR dta020 IN cur_0060
      LOOP
         -- Write out Service Request Number that's being processed
         l_Error_Message := ('Processing Service Request#: ' || dta020.Incident_Number);
         WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
         -- Initialize l_DR_SR_TASKS_PROCESS, l_DR_SR_TASK_STATUS_PROCESS
         l_DR_SR_TASKS_PROCESS       := NULL;
         l_DR_SR_TASK_STATUS_PROCESS := NULL;
         -- Perform CHECK_DR_SR_TASKS_DAYS
         CHECK_DR_SR_TASKS_DAYS(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, dta020.Incident_Type, P_Task_Number_Days, l_DR_SR_TASKS_PROCESS);
         -- Perform CHECK_DR_SR_TASK_STATUS
         CHECK_DR_SR_TASK_STATUS(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, dta020.Incident_Type, l_DR_SR_TASK_STATUS_PROCESS);
         -- Check to see if we want to process (If either l_DR_SR_TASKS_PROCESS or l_DR_SR_TASK_STATUS_PROCESS is 'X', exclude from processing)
         IF NVL(l_DR_SR_TASKS_PROCESS, 'P') = 'X' OR NVL(l_DR_SR_TASK_STATUS_PROCESS, 'P') = 'X' THEN
            l_Error_Message := ('l_DR_SR_TASK_STATUS_PROCESS: ' || l_DR_SR_TASK_STATUS_PROCESS);
            WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            l_Error_Message := ('l_DR_SR_TASKS_PROCESS: ' || l_DR_SR_TASKS_PROCESS);
            WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         ELSE
            l_Error_EDITS_PRE_PROCESS      := 'N';
            l_Error_EDITS_POST_PROCESS     := 'N';
            l_Order_API_Error              := 'N';
            l_DR_API_Error                 := 'N';
            l_Error_CLOSE_SERVICE_REQUEST  := 'N';
            l_Close_Depot_Repair_Order     := NULL;
            MO_GLOBAL.SET_POLICY_CONTEXT('S',dta020.Org_ID);                    -- Set Policy Context Org_ID based upon Org_ID in data
            MO_GLOBAL.INIT('CSD');                                              -- Set Application Name
            g_SCT_Responsibility_Name := dta020.Attribute2;                     -- Set SCT Responsibility Name
            g_FSE_Responsibility_Name := dta020.Attribute3;                     -- Set FSE Responsibility Name
            -- EDITS_PRE_PROCESS
            EDITS_PRE_PROCESS(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, dta020.Incident_Type, l_Error_EDITS_PRE_PROCESS);
            l_Error_Message := ('l_Error_EDITS_PRE_PROCESS: ' || l_Error_EDITS_PRE_PROCESS);
            WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            l_Error_Message := ('P_Process_Type: ' || P_Process_Type);
            WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            IF (P_Process_Type = 'U') THEN
               UPDATE_OM_INTERFACE(dta020.Org_ID , dta020.Incident_ID, dta020.Incident_Number, NULL , NULL, NULL, NULL, l_UPDATE_OM_API_Error);
               --FIND_RECENT_SR(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, dta020.Inventory_Item_ID, dta020.Serial_Number, dta020.Incident_Date, dta020.Incident_Type, l_Order_API_Error);
               IF NVL(l_Order_API_Error, 'N') = 'N' THEN
                  -- If no Errors on Edits and no Errors on Order Creates then close the Depot Repair Orders
                  IF dta020.Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') THEN
                     UPDATE_LOGISTIC_LINES_FOR_DR(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, l_Close_Depot_Repair_Order, l_DR_API_Error);
                  END IF;
               END IF;
            END IF;
            -- Perform Post Process Edits
            EDITS_POST_PROCESS(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, dta020.Incident_Type, l_Error_EDITS_POST_PROCESS);
            -- Close the Service Request
            IF (l_Error_EDITS_PRE_PROCESS = 'N') AND (NVL(l_Error_EDITS_POST_PROCESS, 'N') = 'N') AND NVL(l_DR_API_Error, 'N') = 'N' THEN
               IF (P_Process_Type = 'U') THEN 
                  IF NVL(l_Close_Depot_Repair_Order, 'N') = 'Y' THEN
                     CLOSE_DEPOT_REPAIR_ORDERS(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, l_CLOSE_DR_API_Error);
                  ELSE
                     l_Error_Message := ('Depot Repair Order will NOT be closed for Service Request#: ' || dta020.Incident_Number);
                     WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
                  END IF;
                  CLOSE_SERVICE_REQUEST(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, l_Error_CLOSE_SERVICE_REQUEST);
               ELSE
                  l_Error_Message := ('CLOSE_DEPOT_REPAIR_ORDERS/CLOSE_SERVICE_REQUEST were not performed - Process Type: ' || P_Process_Type);
                  WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               END IF;
            ELSE
               l_Error_Message := ('l_Error_EDITS_PRE_PROCESS: ' || l_Error_EDITS_PRE_PROCESS);
               WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               l_Error_Message := ('l_Error_EDITS_POST_PROCESS: ' || l_Error_EDITS_POST_PROCESS);
               WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               l_Error_Message := ('l_DR_API_Error: ' || l_DR_API_Error);
               WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               l_Error_Message := ('Errors exist for Service Request#: ' || dta020.Incident_Number);
               WRITE_DETAIL(dta020.Org_ID, dta020.Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
            END IF;
            -- Write Header Record
            IF (NVL(l_Error_EDITS_PRE_PROCESS, 'N') = 'Y') OR (NVL(l_Error_EDITS_POST_PROCESS, 'N') = 'Y') OR (NVL(l_Order_API_Error, 'N') = 'Y') OR (NVL(l_DR_API_Error, 'N') = 'Y')  OR (NVL(l_Error_CLOSE_SERVICE_REQUEST, 'N') = 'Y') OR (NVL(l_CLOSE_DR_API_Error, 'N') = 'Y') THEN
               WRITE_HEADER(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, dta020.Incident_Status_ID, dta020.Status_Code, dta020.Closed_Flag, dta020.Incident_Type_ID, dta020.Incident_Type, dta020.Inventory_Item_ID, dta020.Segment1, dta020.Serial_Number, dta020.Contract_ID, dta020.Contract_Number, dta020.Incident_country, 'Y');
            ELSE
               WRITE_HEADER(dta020.Org_ID, dta020.Incident_ID, dta020.Incident_Number, dta020.Incident_Status_ID, dta020.Status_Code, dta020.Closed_Flag, dta020.Incident_Type_ID, dta020.Incident_Type, dta020.Inventory_Item_ID, dta020.Segment1, dta020.Serial_Number, dta020.Contract_ID, dta020.Contract_Number, dta020.Incident_country, 'N');
            END IF;
         END IF;
      END LOOP;
   END IF;

   -- Perform COMMIT at end of processing
   COMMIT;

   -- Initialize l_Count
   l_Count := 0;

   -- Cursor to retrieve record count in reporting header table
   OPEN cur_0080;
   FETCH cur_0080 INTO l_Count;
   CLOSE cur_0080;

   FND_FILE.PUT_LINE(FND_FILE.LOG,'Service Requests Records Processed: ' || l_Count);

   -- Submit Report
   REPORT_SUBMISSION(g_Session_ID, g_Current_User_ID, P_CONCURRENT_PGM, P_TEMPLATE_CODE, P_Debug, P_EMAIL_SERVER, P_EMAIL_PORT, P_TEST_EMAIL_ACCOUNT, P_PRODUCTION_INSTANCE_DB_NAME, P_Value_Set_ID_EMail, P_REPORT_PROGRAM_ID);

END TRANSACTION_MAIN;

--------------------------------------------------------------------------------
-- CHECK_DR_SR_TASKS_DAYS 

PROCEDURE CHECK_DR_SR_TASKS_DAYS(p_Org_ID                  IN  NUMBER
                               , p_Incident_ID             IN  NUMBER
                               , p_Incident_Number         IN  VARCHAR2
                               , p_Incident_Type           IN  VARCHAR2
                               , p_Task_Number_Days        IN  NUMBER
                               , P_CHECK_DR_SR_TASKS_DAYS  OUT VARCHAR2
) IS

l_Count_SR_Tasks                  NUMBER                                        := 0;
l_Count_DR_Tasks                  NUMBER                                        := 0;

l_CHECK_DR_SR_TASKS_DAYS          XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;

-- Cursor to determine if tasks exist for Repair Order
-- that were last updated in the past number of x days (as defined in p_Task_Number_Days)
CURSOR cur_0100
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v            cr
  , CSD_Tasks                ct
  , csf_debrief_tasks_v      csf
WHERE
    cr.SR_Org_ID           = p_Org_ID 
AND cr.Incident_ID         = p_Incident_ID
AND cr.Repair_Line_ID      = CT.Repair_Line_ID
AND cr.Incident_ID         = csf.Incident_ID
AND CSF.SOURCE_TYPE_CODE   = 'DR'
AND (TRUNC(SYSDATE) - TRUNC(csf.last_Update_Date)) <= p_Task_Number_Days
;

-- Cursor to determine if tasks exist for Service Requests
-- that were last updated in the past number of x days (as defined in p_Task_Number_Days)
CURSOR cur_0120
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V        csi 
  , cs_sr_tasks_v            cst
  , csf_debrief_tasks_v      csf
WHERE
    csi.Org_ID             = p_Org_ID 
AND csi.Incident_ID        = p_Incident_ID
AND csi.Incident_ID        = cst.source_object_ID
AND csi.Incident_ID        = csf.Incident_ID
AND CSF.SOURCE_TYPE_CODE   = 'SR'
AND (TRUNC(SYSDATE) - TRUNC(cst.last_Update_Date)) <= p_Task_Number_Days
;

BEGIN

   l_Error_Message := ('Entering CHECK_DR_SR_TASKS_DAYS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_CHECK_DR_SR_TASKS_DAYS, l_Count_DR_Tasks, l_Count_SR_Tasks
   l_CHECK_DR_SR_TASKS_DAYS := NULL;
   l_Count_DR_Tasks         := 0;
   l_Count_SR_Tasks         := 0;

   -- Cursor to determine if tasks exist for Repair Order
   -- that were last updated in the past number of x days (as defined in p_Task_Number_Days)
   OPEN cur_0100;
   FETCH cur_0100 INTO l_Count_DR_Tasks;
   CLOSE cur_0100;

   -- Cursor to determine if tasks exist for Service Requests
   -- that were last updated in the past number of x days (as defined in p_Task_Number_Days)
   OPEN cur_0120;
   FETCH cur_0120 INTO l_Count_SR_Tasks;
   CLOSE cur_0120;

   -- Send back Output Parameter
   -- If p_Task_Number_Days = 0 then always process
   -- If p_Task_Number_Days > 0 and if either DR or SR has tasks that were last updated in the past x days (as defined in 'p_Task_Number_Days')
   -- then we don't want to process those SR's
   IF (p_Task_Number_Days = 0) THEN
      l_CHECK_DR_SR_TASKS_DAYS := 'P';
   ELSIF (NVL(l_Count_DR_Tasks, 0) > 0) OR
         (NVL(l_Count_SR_Tasks, 0) > 0) THEN
      l_CHECK_DR_SR_TASKS_DAYS := 'X';
   ELSE
      l_CHECK_DR_SR_TASKS_DAYS := 'P';      
   END IF;

   l_Error_Message := ('Service Request#: ' || p_Incident_Number || ': Process SR Flag: ' || l_CHECK_DR_SR_TASKS_DAYS);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If we are not going to process the SR, still need to write out a header record and detail record but identify with 'X' for error (excluded from processing)
   IF (l_CHECK_DR_SR_TASKS_DAYS = 'X') THEN
      WRITE_HEADER(p_Org_ID, p_Incident_ID, p_Incident_Number, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'X');
      l_Error_Message := ('Service Request#: ' || p_Incident_Number || ' ' || 'will be excluded from processing, DR or SR has tasks that were last updated in the past ' || p_Task_Number_Days || ' days.');
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
   END IF;

   -- Send back Output Parameter
   P_CHECK_DR_SR_TASKS_DAYS := l_CHECK_DR_SR_TASKS_DAYS;

   l_Error_Message := ('Exiting CHECK_DR_SR_TASKS_DAYS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END CHECK_DR_SR_TASKS_DAYS;

--------------------------------------------------------------------------------
-- CHECK_DR_SR_TASK_STATUS

PROCEDURE CHECK_DR_SR_TASK_STATUS(p_Org_ID                      IN  NUMBER
                                , p_Incident_ID                 IN  NUMBER
                                , p_Incident_Number             IN  VARCHAR2
                                , p_Incident_Type               IN  VARCHAR2
                                , P_CHECK_DR_SR_TASK_STATUS     OUT VARCHAR2
) IS

l_Count                           NUMBER                                        := 0;
l_SR_Has_Tasks                    VARCHAR2(01)                                  := NULL;
l_DR_Has_Tasks                    VARCHAR2(01)                                  := NULL;
l_DR_Exists                       VARCHAR2(01)                                  := NULL;

l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Exclude_Record_DR               XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Exclude_Record_SR               XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_CHECK_DR_SR_TASK_STATUS         XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;

-- Cursor to retrieve count of Depot Repair Orders for a Service Request
CURSOR cur_0130
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v            cr
WHERE
    cr.SR_Org_ID           = p_Org_ID
AND cr.Incident_ID         = p_Incident_ID
;

-- Cursor to determine if tasks exist for Depot Repair Orders
CURSOR cur_0140
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v            cr
  , CSD_Tasks                ct
  , csf_debrief_tasks_v      csf
WHERE
    cr.SR_Org_ID           = p_Org_ID
AND cr.Incident_ID         = p_Incident_ID
AND cr.Repair_Line_ID      = CT.Repair_Line_ID
AND cr.Incident_ID         = csf.Incident_ID
AND CSF.SOURCE_TYPE_CODE   = 'DR'
;

-- Cursor to retrieve Status of tasks for Depot Repair Orders
-- Note that we are not including 'csf_debrief_headers' as
-- tasks in 'Assigned' Status may not have a record in 'csf_debrief_headers'
CURSOR cur_0160
IS
SELECT
    csi1.Org_ID
  , csi1.incident_ID
  , csi1.incident_number
  , jtv1.task_ID
  , jtv1.task_number
  , jtv1.Object_Version_Number
  , jtv1.Task_Status_ID
  , jts1.name                     "TASK_STATUS"
FROM
    CS_SR_Incidents_V              csi1
  , csd_repairs_V                  cr1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = cr1.incident_ID
AND cr1.repair_line_ID           = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'DR'
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
;

-- Cursor to determine if tasks exist for Service Requests
CURSOR cur_0180
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V        csi 
  , cs_sr_tasks_v            cst
  , csf_debrief_tasks_v      csf
WHERE
    csi.Org_ID             = p_Org_ID 
AND csi.Incident_ID        = p_Incident_ID
AND csi.Incident_ID        = cst.source_object_ID
AND csi.Incident_ID        = csf.Incident_ID
AND CSF.SOURCE_TYPE_CODE   = 'SR'
;

-- Cursor to retrieve Status of tasks for Service Requests
-- Note that we are not including 'csf_debrief_headers' as
-- tasks in 'Assigned' Status may not have a record in 'csf_debrief_headers'
CURSOR cur_0200
IS
SELECT
    jtv2.Task_ID
  , jtv2.Task_Number
  , jtv2.Object_Version_Number
  , jts2.name                     "TASK_STATUS"
FROM
    CS_SR_Incidents_V              csi2
  , jtf_tasks_vl                   jtv2
  , jtf_task_assignments           jta2
  , JTF_RS_RESOURCE_EXTNS          jrs2
  , JTF_TASK_STATUSES_VL           jts2
WHERE
    csi2.Org_ID                  = p_Org_ID
AND csi2.incident_ID             = p_Incident_ID
AND csi2.incident_ID             = jtv2.source_object_ID
AND jtv2.Source_Object_Type_Code = 'SR'
AND jtv2.task_ID                 = jta2.task_ID
AND jtv2.Task_Status_ID          = jts2.Task_Status_ID
AND jta2.resource_ID             = jrs2.resource_ID
;

BEGIN

   l_Error_Message := ('Entering CHECK_DR_SR_TASK_STATUS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Exclude_Record_DR, l_Exclude_Record_SR, l_CHECK_DR_SR_TASK_STATUS, l_DR_Has_Tasks, l_SR_Has_Tasks, l_DR_Exists, l_Count
   l_Exclude_Record_DR       := NULL;
   l_Exclude_Record_SR       := NULL;
   l_CHECK_DR_SR_TASK_STATUS := NULL;
   l_DR_Has_Tasks            := NULL;
   l_SR_Has_Tasks            := NULL;
   l_DR_Exists               := NULL;
   l_Count                   := 0;

   l_Error_Message := ('Incident Type for Service Request#: ' || p_Incident_Number || ', ' || p_Incident_Type);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Check if Depot Repair Order exists
   IF p_Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') THEN

      -- Cursor to retrieve count of Depot Repair Orders for a Service Request
      -- If no Depot Repair Order exists for a Service Request, exclude the record from processing
      OPEN cur_0130;
      FETCH cur_0130 INTO l_Count;
      IF (l_Count > 0) THEN
         l_DR_Exists         := 'Y';
      ELSE
         l_DR_Exists         := 'N';
         l_Exclude_Record_DR := 'Y';
      END IF;
      CLOSE cur_0130;

   END IF;

   -- Check Task Status for Depot Repair Order if it exists
   IF p_Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') AND (l_DR_Exists = 'Y') THEN 

      -- Initialize l_Count
      l_Count     := 0;

      -- Cursor to determine if tasks exist for Depot Repair Order
      OPEN cur_0140;
      FETCH cur_0140 INTO l_Count;
      IF (l_Count > 0) THEN
         l_DR_Has_Tasks := 'Y';
      ELSE
         l_DR_Has_Tasks := 'N';
      END IF;
      CLOSE cur_0140;

      l_Error_Message := 'DR_Has_Tasks: ' || l_DR_Has_Tasks || ' , Nbr of Tasks: ' || l_Count;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If tasks exist for Repair Order then check status
      IF NVL(l_DR_Has_Tasks, 'N') = 'Y' THEN
         -- Cursor to retrieve Status of tasks for Repair Order 
         FOR dta040 IN cur_0160
         LOOP
            -- If any task is in 'Assigned' status then exclude record
            IF UPPER(dta040.TASK_STATUS) IN ('ASSIGNED') THEN
               l_Exclude_Record_DR := 'Y';
               l_Error_Message     := ('Task(s) associated with the Depot Repair Order have status other than Completed, Closed or Cancelled: ' || dta040.TASK_STATUS || ', Task Number: ' || dta040.Task_Number);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
               EXIT;
            END IF;
         END LOOP;
      END IF;
   END IF; -- IF p_Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') THEN

   l_Error_Message := 'l_Exclude_Record For DR: ' || NVL(l_Exclude_Record_DR, 'N/A');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Check Task Status for Service Request but only if we haven't already exluded the record
   IF NVL(l_Exclude_Record_DR, 'N') = 'N' THEN

      -- Initialize l_Count
      l_Count := 0;

      -- Cursor to determine if tasks exist for Service Requests
      OPEN cur_0180;
      FETCH cur_0180 INTO l_Count;
      IF (l_Count > 0) THEN
         l_SR_Has_Tasks := 'Y';
      ELSE
         l_SR_Has_Tasks := 'N';
      END IF;
      CLOSE cur_0180;

      l_Error_Message := 'SR_Has_Tasks: ' || l_SR_Has_Tasks || ' , Nbr of Tasks: ' || l_Count;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If tasks do not exist for Service Request then exclude record
      IF p_Incident_Type NOT IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') THEN
         IF (l_SR_Has_Tasks = 'N') THEN
            l_Exclude_Record_SR := 'Y';
         END IF;
      END IF;

      -- If tasks exist for Service Request then check status
      IF (l_SR_Has_Tasks = 'Y') THEN
         -- Cursor to retrieve Status of tasks for Service Request
         FOR dta060 IN cur_0200
         LOOP
            -- If any task is in 'Assigned' status then exclude record
            IF UPPER(dta060.TASK_STATUS) IN ('ASSIGNED') THEN
               l_Exclude_Record_SR := 'Y';
               l_Error_Message  := ('Task(s) associated with the Service Request have status other than Completed, Closed or Cancelled: ' || dta060.TASK_STATUS || ', Task Number: ' || dta060.Task_Number);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
               EXIT;
            END IF;
         END LOOP;
      END IF;
   END IF; -- IF l_Exclude_Record = 'N' THEN

   l_Error_Message := 'l_Exclude_Record For SR: ' || NVL(l_Exclude_Record_SR, 'N/A');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_CHECK_DR_SR_TASK_STATUS to 'P'
   l_CHECK_DR_SR_TASK_STATUS := 'P';

   -- If DR already selected to be excluded from processing
   IF NVL(l_Exclude_Record_DR, 'N') = 'Y' THEN
      -- If DR has tasks then exclusion was due to tasks in Assigned Status
      IF NVL(l_DR_Has_Tasks, 'N') = 'Y' THEN
         l_CHECK_DR_SR_TASK_STATUS := 'X';
         WRITE_HEADER(p_Org_ID, p_Incident_ID, p_Incident_Number, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'X');
         l_Error_Message := ('Service Request#: ' || p_Incident_Number || ' will be excluded from processing, RO Task(s) exist in Assigned Status');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
      END IF;
      IF NVL(l_DR_Exists, 'N') = 'N' THEN
         l_CHECK_DR_SR_TASK_STATUS := 'X';
         WRITE_HEADER(p_Org_ID, p_Incident_ID, p_Incident_Number, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'X');
         l_Error_Message := ('Service Request#: ' || p_Incident_Number || ' will be excluded from processing, no Depot Repair Order exists');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
      END IF;
   END IF;

   -- If SR already selected to be excluded from processing
   IF NVL(l_Exclude_Record_SR, 'N') = 'Y' THEN
      -- If SR has tasks then exclusion was due to tasks in Assigned Status
      IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
         l_CHECK_DR_SR_TASK_STATUS := 'X';
         WRITE_HEADER(p_Org_ID, p_Incident_ID, p_Incident_Number, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'X');
         l_Error_Message := ('Service Request#: ' || p_Incident_Number || ' will be excluded from processing, SR Task(s) exist in Assigned Status');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
      END IF;
   END IF;

   -- If Processing Field Service Request without Depot Repair Order and NO tasks exist for the Field Service Request then exclude record from processing
   IF p_Incident_Type NOT IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') THEN
      IF NVL(l_SR_Has_Tasks, 'N') = 'N' THEN
         l_CHECK_DR_SR_TASK_STATUS := 'X';
         WRITE_HEADER(p_Org_ID, p_Incident_ID, p_Incident_Number, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'X');
         l_Error_Message := ('Service Request#: ' || p_Incident_Number || ' will be excluded from processing, no SR Task(s) exist');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
      END IF;
   END IF;

   l_Error_Message := 'l_CHECK_DR_SR_TASK_STATUS: ' || l_CHECK_DR_SR_TASK_STATUS;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Send back Output Parameter
   P_CHECK_DR_SR_TASK_STATUS := l_CHECK_DR_SR_TASK_STATUS;

   l_Error_Message := ('Exiting CHECK_DR_SR_TASK_STATUS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END CHECK_DR_SR_TASK_STATUS;

--------------------------------------------------------------------------------
-- EDITS_PRE_PROCESS 

PROCEDURE EDITS_PRE_PROCESS(p_Org_ID                       IN  NUMBER
                          , p_Incident_ID                  IN  NUMBER
                          , p_Incident_Number              IN  VARCHAR2
                          , p_Incident_Type                IN  VARCHAR2
                          , P_EDITS_PRE_PROCESS            OUT VARCHAR2
) IS

l_Error_SCT_Responsibility        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_FSE_Responsibility        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_EDITS_SR_WITH_DR          XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_EDITS_SR_WITHOUT_DR       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_EDITS_PRE_PROCESS               XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;

BEGIN

   l_Error_Message := ('Entering EDITS_PRE_PROCESS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_EDITS_PRE_PROCESS
   l_EDITS_PRE_PROCESS := NULL;

   -- Check to see that SCT_Responsibility_Name and FSE_Responsibility_Name have values
   IF (g_SCT_Responsibility_Name IS NULL) THEN
      l_Error_SCT_Responsibility := 'Y';
      l_Error_Message := ('SCT_Responsibility_Name is NULL for Org ' || p_Org_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   ELSIF (g_FSE_Responsibility_Name IS NULL) THEN
      l_Error_FSE_Responsibility := 'Y';
      l_Error_Message := ('FSE_Responsibility_Name is NULL for Org ' || p_Org_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Process Edits if there are no Setup Errors
   IF (NVL(l_Error_SCT_Responsibility,'N') = 'N') AND (NVL(l_Error_FSE_Responsibility,'N') = 'N') THEN
      IF p_Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') THEN
         EDITS_SR_WITH_DR(p_Org_ID, p_Incident_ID, p_Incident_Number, l_Error_EDITS_SR_WITH_DR);
      ELSE
         EDITS_SR_WITHOUT_DR(p_Org_ID, p_Incident_ID, p_Incident_Number, l_Error_EDITS_SR_WITHOUT_DR);
      END IF;
   END IF;

   -- Set Output Error Parameter
   IF (NVL(l_Error_SCT_Responsibility, 'N')  = 'Y') OR
      (NVL(l_Error_FSE_Responsibility, 'N')  = 'Y') OR
      (NVL(l_Error_EDITS_SR_WITH_DR, 'N')    = 'Y') OR
      (NVL(l_Error_EDITS_SR_WITHOUT_DR, 'N') = 'Y') THEN
      l_EDITS_PRE_PROCESS := 'Y';
   ELSE
      l_EDITS_PRE_PROCESS := 'N';
   END IF;

   -- Send back Output Error Parameter
   P_EDITS_PRE_PROCESS := l_EDITS_PRE_PROCESS;

   l_Error_Message := ('Exiting EDITS_PRE_PROCESS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END EDITS_PRE_PROCESS;

--------------------------------------------------------------------------------
-- EDITS_SR_WITH_DR

PROCEDURE EDITS_SR_WITH_DR(p_Org_ID                        IN  NUMBER
                         , p_Incident_ID                   IN  NUMBER
                         , p_Incident_Number               IN  VARCHAR2
                         , P_EDITS_SR_WITH_DR              OUT VARCHAR2
) IS

l_Count_Open                      NUMBER                                        := 0;
l_Count_All                       NUMBER                                        := 0;
l_Count                           NUMBER                                        := 0;
l_Process_DR                      VARCHAR2(01)                                  := NULL;
l_Process_SR                      VARCHAR2(01)                                  := NULL;
l_SR_Has_Tasks                    VARCHAR2(01)                                  := NULL;
l_DR_Has_Tasks                    VARCHAR2(01)                                  := NULL;
l_DR_Exists                       VARCHAR2(01)                                  := NULL;

l_API_Error_1                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_2                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_DR                        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_DR_TASKS                  XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR                        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_EDITS_SR_WITH_DR                XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Incident_ID                     csd_repairs_v.Incident_ID%TYPE                := NULL;
l_Incident_Number                 csd_repairs_v.Incident_Number%TYPE            := NULL;
l_Repair_Number                   csd_repairs_v.Repair_Number%TYPE              := NULL;

-- Cursor to retrieve count of Depot Repair Orders for a Service Request
CURSOR cur_0220
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v            cr
WHERE
    cr.SR_Org_ID           = p_Org_ID
AND cr.Incident_ID         = p_Incident_ID
;

-- Cursor to retrieve count of Depot Repair Orders for a Service Request
-- where Repair Order status is not 'Closed' or 'Cancelled'
CURSOR cur_0240
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v            cr1
WHERE
    cr1.SR_Org_ID          = p_Org_ID
AND cr1.Incident_ID        = p_Incident_ID
AND cr1.Status             NOT IN ('Closed', 'Cancelled')
;

-- Cursor to determine if tasks exist for Repair Order
CURSOR cur_0260
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v            cr
  , CSD_Tasks                ct
  , csf_debrief_tasks_v      csf
WHERE
    cr.SR_Org_ID           = p_Org_ID
AND cr.Incident_ID         = p_Incident_ID
AND cr.Repair_Line_ID      = CT.Repair_Line_ID
AND cr.Incident_ID         = csf.Incident_ID
AND CSF.SOURCE_TYPE_CODE   = 'DR'
;

-- Cursor to retrieve Status of tasks for Repair Order 
CURSOR cur_0280
IS
SELECT
    csi1.Org_ID
  , csi1.incident_ID
  , csi1.incident_number
  , jtv1.task_ID
  , jtv1.task_number
  , jtv1.Object_Version_Number
  , jtv1.Task_Status_ID
  , jts1.name                     "TASK_STATUS"
FROM
    CS_SR_Incidents_V              csi1
  , csd_repairs_V                  cr1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = cr1.incident_ID
AND cr1.repair_line_ID           = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'DR'
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID
;

-- Cursor to determine if tasks exist for Service Requests
CURSOR cur_0300
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V        csi2 
  , cs_sr_tasks_v            cst2
  , csf_debrief_tasks_v      csf2
WHERE
    csi2.Org_ID            = p_Org_ID 
AND csi2.Incident_ID       = p_Incident_ID
AND csi2.Incident_ID       = cst2.source_object_ID
AND csi2.Incident_ID       = csf2.Incident_ID
AND CSF2.SOURCE_TYPE_CODE  = 'SR'
;

-- Cursor to retrieve Debrief Task Status for Service Requests
CURSOR cur_0320
IS
SELECT
    jtv3.Task_ID
  , jtv3.Task_Number
  , jtv3.Object_Version_Number
  , jts3.name                     "TASK_STATUS"
FROM
    CS_SR_Incidents_V              csi3
  , jtf_tasks_vl                   jtv3
  , jtf_task_assignments           jta3
  , JTF_RS_RESOURCE_EXTNS          jrs3
  , JTF_TASK_STATUSES_VL           jts3
  , csf_debrief_headers            cdh3
WHERE
    csi3.Org_ID                  = p_Org_ID
AND csi3.incident_ID             = p_Incident_ID
AND csi3.incident_ID             = jtv3.source_object_ID
AND jtv3.Source_Object_Type_Code = 'SR'
AND jtv3.task_ID                 = jta3.task_ID
AND jtv3.Task_Status_ID          = jts3.Task_Status_ID
AND jta3.resource_ID             = jrs3.resource_ID
AND jta3.Task_Assignment_ID      = cdh3.Task_Assignment_ID
;

BEGIN

   l_Error_Message := ('Entering EDITS_SR_WITH_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Count_All, l_DR_Exists, l_EDITS_SR_WITH_DR
   l_Count_All        := 0;
   l_DR_Exists        := NULL;
   l_EDITS_SR_WITH_DR := NULL;

   -- Cursor to retrieve count of Depot Repair Orders for a Service Request
   OPEN cur_0220;
   FETCH cur_0220 INTO l_Count_All;
   IF (l_Count_All > 0) THEN
      l_DR_Exists := 'Y';
   ELSE
      l_DR_Exists := 'N';
   END IF;
   CLOSE cur_0220;

   l_Error_Message := 'DR_Exists: ' || l_DR_Exists;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   IF (l_DR_Exists = 'N') THEN
      l_Error_Message := 'Repair Order does not exist for Service Request: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Initialize l_Count_Open
   l_Count_Open  := 0;
   l_API_Error_1 := NULL;

   -- Retrieve record count of Depot Repair Orders for a Service Request
   -- where Repair Order status is not 'Closed' or 'Cancelled'
   OPEN cur_0240;
   FETCH cur_0240 INTO l_Count_Open;
   CLOSE cur_0240;

   l_Error_Message := 'Depot Repair Orders for Service Request, Count_Open: ' || l_Count_Open || ', Count_All: ' || l_Count_All;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If Depot Repair Order exists for a Service Request and Depot Repair Orders exist with a status other than 'Closed' or 'Cancelled'
   IF (l_DR_Exists = 'Y') AND (l_Count_Open > 0) THEN
      l_Error_Message := 'Depot Repair Order exists with a status other than Closed or Cancelled for Service Request: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
   END IF;

   -- Initialize l_Count and l_DR_Has_Tasks
   l_Count        := 0;
   l_DR_Has_Tasks := NULL;

   -- Check to see if any tasks exist for Repair Order
   IF (l_DR_Exists = 'Y') THEN
      -- Cursor to determine if tasks exist for Repair Order
      OPEN cur_0260;
      FETCH cur_0260 INTO l_Count;
      IF l_Count > 0 THEN
         l_DR_Has_Tasks := 'Y';
      ELSE
         l_DR_Has_Tasks := 'N';
      END IF;
      CLOSE cur_0260;
   END IF;

   l_Error_Message := 'DR_Has_Tasks: ' || l_DR_Has_Tasks || ' , Nbr of Tasks: ' || l_Count;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If tasks exist for Repair Order then check status
   IF (l_DR_Exists = 'Y') AND (l_DR_Has_Tasks = 'Y') THEN
      -- Cursor to retrieve Status of tasks for Repair Order 
      FOR dta080 IN cur_0280
      LOOP
         -- If any task is NOT IN ('Completed', 'Closed', 'Cancelled') then Error the record
         IF (UPPER(dta080.TASK_STATUS) NOT IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            l_Error_DR_TASKS := 'Y';
            l_Error_Message  := ('Task(s) associated with the Depot Repair Order have status other than Completed, Closed or Cancelled: ' || dta080.TASK_STATUS || ', Task Number: ' || dta080.Task_Number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSIF (UPPER(dta080.Task_Status) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            -- Call DEBRIEF_PROCESS_WITH_DR if g_Process_Type = 'U'
            IF (g_Process_Type = 'U') THEN
               DEBRIEF_PROCESS_WITH_DR(p_Org_ID, p_Incident_ID, p_Incident_Number, dta080.Task_ID, l_API_Error_1);
            END IF;
         END IF;

         l_Error_Message := ('DR_Exists: ' || l_DR_Exists || ', ' || 'DR_Has_Tasks: ' || l_DR_Has_Tasks);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         l_Error_Message := ('Task associated with Repair Order has status: ' || dta080.Task_Status);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If any errors, exit loop
         IF NVL(l_API_Error_1, 'N') = 'Y' THEN
            EXIT;
         END IF;

      END LOOP;
   END IF;

   -- Initialize l_Count, l_SR_Has_Tasks, l_Error_SR, l_API_Error_2
   l_Count        := 0;
   l_SR_Has_Tasks := NULL;
   l_Error_SR     := NULL;
   l_API_Error_2  := NULL;

   -- Check to see if any tasks exist for Service Requests
   OPEN cur_0300;
   FETCH cur_0300 INTO l_Count;
   IF (l_Count > 0) THEN
      l_SR_Has_Tasks := 'Y';
   ELSE
      l_SR_Has_Tasks := 'N';
   END IF;
   CLOSE cur_0300;

   l_Error_Message := 'SR_Has_Tasks: ' || l_SR_Has_Tasks;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If tasks exist for Service Request then check status
   IF (l_SR_Has_Tasks = 'Y') THEN
      -- Cursor to retrieve Status of tasks for Service Request
      FOR dta100 IN cur_0320
      LOOP
         -- If any task is NOT IN ('Completed', 'Closed', 'Cancelled') then Error the record
         IF (UPPER(dta100.TASK_STATUS) NOT IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            l_Error_SR      := 'Y';
            l_Error_Message := ('Task(s) associated with the Service Request have status other than Completed, Closed or Cancelled: ' || dta100.TASK_STATUS || ', Task Number: ' || dta100.Task_Number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSIF (UPPER(dta100.Task_Status) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            -- Call DEBRIEF_PROCESS_WITH_DR if g_Process_Type = 'U'
            IF (g_Process_Type = 'U') THEN
               DEBRIEF_PROCESS_WITH_DR(p_Org_ID, p_Incident_ID, p_Incident_Number, dta100.Task_ID, l_API_Error_2);
            END IF;
         END IF;

         l_Error_Message := ('Task associated with Service Request has status: ' || dta100.TASK_STATUS);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If any errors, exit loop
         IF NVL(l_API_Error_2, 'N') = 'Y' THEN
            EXIT;
         END IF;

      END LOOP;
   END IF;

   -- Set Output Error Parameter
   IF (NVL(l_Error_DR, 'N') = 'Y') OR (NVL(l_Error_DR_TASKS, 'N') = 'Y') OR (NVL(l_Error_SR, 'N') = 'Y') OR (NVL(l_API_Error_1, 'N') = 'Y') OR (NVL(l_API_Error_2, 'N') = 'Y') THEN
      l_EDITS_SR_WITH_DR := 'Y';
   ELSE
      l_EDITS_SR_WITH_DR := 'N';
   END IF;

   -- Send back Output Error Parameter
   P_EDITS_SR_WITH_DR := l_EDITS_SR_WITH_DR;

   l_Error_Message := ('Exiting EDITS_SR_WITH_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END EDITS_SR_WITH_DR;

--------------------------------------------------------------------------------
-- EDITS_SR_WITHOUT_DR

PROCEDURE EDITS_SR_WITHOUT_DR(p_Org_ID                     IN  NUMBER
                            , p_Incident_ID                IN  NUMBER
                            , p_Incident_Number            IN  VARCHAR2
                            , P_EDITS_SR_WITHOUT_DR        OUT VARCHAR2
) IS

l_Count                           NUMBER                                        := 0;
l_SR_Has_Tasks                    VARCHAR2(01)                                  := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Tasks                  XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Task_Status            XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_EDITS_SR_WITHOUT_DR             XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_source_object_ID                cs_sr_tasks_v.source_object_ID%TYPE           := NULL;

-- Cursor to determine if tasks exist for Service Request 
CURSOR cur_0340
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V        csi 
  , cs_sr_tasks_v            cst
  , csf_debrief_tasks_v      csf
WHERE
    csi.Org_ID             = p_Org_ID
AND csi.Incident_ID        = p_Incident_ID
AND csi.Incident_ID        = cst.source_object_ID
AND csi.Incident_ID        = csf.Incident_ID
AND CSF.SOURCE_TYPE_CODE   = 'SR'
;

-- Cursor to retrieve Debrief Task Status for Service Requests
CURSOR cur_0360
IS
SELECT
    jtv1.Task_ID
  , jtv1.Task_Number
  , jtv1.Object_Version_Number
  , jts1.name                     "TASK_STATUS"
FROM
    CS_SR_Incidents_V              csi1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'SR'
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID
;

BEGIN

   l_Error_Message := ('Entering EDITS_SR_WITHOUT_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Count, l_Error_SR_Tasks, l_EDITS_SR_WITHOUT_DR, l_SR_Has_Tasks, l_API_Error, l_Error_SR_Task_Status
   l_Count                := 0;
   l_Error_SR_Tasks       := NULL;
   l_EDITS_SR_WITHOUT_DR  := NULL;
   l_SR_Has_Tasks         := NULL;
   l_API_Error            := NULL;
   l_Error_SR_Task_Status := NULL;

   -- Check to see if any tasks exist for Service Requests,  If not found in cur_0340 then no tasks exist
   OPEN cur_0340;
   FETCH cur_0340 INTO l_Count;
   IF (l_Count > 0) THEN
      l_SR_Has_Tasks := 'Y';
   ELSE
      l_SR_Has_Tasks := 'N';
   END IF;
   CLOSE cur_0340;

   l_Error_Message := 'SR_Has_Tasks: ' || l_SR_Has_Tasks;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Cursor to retrieve Status of tasks for Service Request
   IF (l_SR_Has_Tasks = 'Y') THEN
      FOR dta120 IN cur_0360
      LOOP
         -- If any task is NOT IN ('Completed', 'Closed', 'Cancelled') then Error the record
         IF (UPPER(dta120.TASK_STATUS) NOT IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            l_Error_SR_Task_Status := 'Y';
            l_Error_Message        := ('Task(s) associated with Service Request has status other than Completed, Closed or Cancelled: ' || dta120.TASK_STATUS);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSIF (UPPER(dta120.TASK_STATUS) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            -- Call DEBRIEF_PROCESS_WITHOUT_DR if g_Process_Type = 'U'
            IF (g_Process_Type = 'U') THEN
               DEBRIEF_PROCESS_WITHOUT_DR(p_Org_ID, p_Incident_ID, p_Incident_Number, dta120.Task_ID, l_API_Error);
            END IF;
         END IF;

         l_Error_Message := ('Task associated with Service Request has status: ' || dta120.TASK_STATUS);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If any errors, exit loop
         IF NVL(l_API_Error, 'N') = 'Y' THEN
            EXIT;
         END IF;

      END LOOP;
   END IF;

   -- Set Output Parameter
   IF (NVL(l_Error_SR_Tasks, 'N') = 'Y') OR (NVL(l_Error_SR_Task_Status, 'N') = 'Y') OR (NVL(l_API_Error, 'N') = 'Y') THEN
      l_EDITS_SR_WITHOUT_DR := 'Y';
   ELSE
      l_EDITS_SR_WITHOUT_DR := 'N';
   END IF;

   -- Send back Output Error Parameter
   P_EDITS_SR_WITHOUT_DR := l_EDITS_SR_WITHOUT_DR;

   l_Error_Message := ('Exiting EDITS_SR_WITHOUT_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END EDITS_SR_WITHOUT_DR;

--------------------------------------------------------------------------------
-- DEBRIEF_PROCESS_WITH_DR

PROCEDURE DEBRIEF_PROCESS_WITH_DR(p_Org_ID                   IN  NUMBER
                                , p_Incident_ID              IN  NUMBER
                                , p_Incident_Number          IN  VARCHAR2
                                , p_Task_ID                  IN  NUMBER
                                , P_DEBRIEF_PROCESS_WITH_DR  OUT VARCHAR2
) IS

l_Debrief_Exsits_For_SR           VARCHAR2(01)                                  := NULL;
l_Debrief_Exsits_For_DR           VARCHAR2(01)                                  := NULL;

l_API_Error_1                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_2                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_3                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_4                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_5                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_6                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_7                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_Error_8                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_error_9                     XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL; -- 2017/04/04 - Added l_API_error_9
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Incident_Number                 csd_repairs_v.Incident_Number%TYPE            := NULL;
l_Debrief_Number                  csf_debrief_headers.Debrief_Number%TYPE       := NULL;
l_Debrief_Header_ID               csf_debrief_headers.DEBRIEF_HEADER_ID%TYPE    := NULL;
l_Object_Version_Number_DR        jtf_tasks_vl.Object_Version_Number%TYPE       := NULL;
l_User_ID                         FND_User.User_ID%TYPE                         := NULL;
l_Task_Status_SR                  JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Assignment_Task_Status_SR       JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Debrief_Status_SR               csf_debrief_headers.Processed_flag%TYPE       := NULL;
l_Task_Status_DR                  JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Assignment_Task_Status_DR       JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Debrief_Status_DR               csf_debrief_headers.Processed_flag%TYPE       := NULL;

-- Cursor for Debrief (Service Request)
CURSOR cur_0380
IS
SELECT
    csi1.incident_number
  , CDH1.DEBRIEF_NUMBER
  , CDH1.DEBRIEF_HEADER_ID
  , jrs1.User_ID
  , jts1.name                     "TASK_STATUS"
  , jts11.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh1.Processed_flag           "DEBRIEF_STATUS"
FROM
    CS_SR_Incidents_V              csi1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , JTF_TASK_STATUSES_VL           jts11
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND jtv1.Task_ID                 = p_Task_ID
AND csi1.incident_ID             = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'SR'
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND JTA1.ASSIGNMENT_STATUS_ID    = jts11.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID
;

-- Cursor for Debrief (Repair Order)
CURSOR cur_0400
IS
SELECT
    csi2.incident_number
  , CDH2.DEBRIEF_NUMBER
  , CDH2.DEBRIEF_HEADER_ID
  , jrs2.User_ID
  , jts2.name                     "TASK_STATUS"
  , jts21.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh2.Processed_flag           "DEBRIEF_STATUS"
FROM
    CS_SR_Incidents_V              csi2
  , csd_repairs_V                  cr2
  , jtf_tasks_vl                   jtv2
  , jtf_task_assignments           jta2
  , JTF_RS_RESOURCE_EXTNS          jrs2
  , JTF_TASK_STATUSES_VL           jts2
  , JTF_TASK_STATUSES_VL           jts21
  , csf_debrief_headers            cdh2
WHERE
    csi2.Org_ID                  = p_Org_ID
AND csi2.incident_ID             = p_Incident_ID
AND jtv2.Task_ID                 = p_Task_ID
AND csi2.incident_ID             = cr2.incident_ID
AND cr2.repair_line_ID           = jtv2.source_object_ID
AND jtv2.Source_Object_Type_Code = 'DR'
AND jtv2.task_ID                 = jta2.task_ID
AND jtv2.Task_Status_ID          = jts2.Task_Status_ID
AND JTA2.ASSIGNMENT_STATUS_ID    = jts21.Task_Status_ID
AND jta2.resource_ID             = jrs2.resource_ID
AND jta2.Task_Assignment_ID      = cdh2.Task_Assignment_ID
;

BEGIN

   l_Error_Message := ('Entering DEBRIEF_PROCESS_WITH_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_API_error_1, l_API_error_2, l_API_error_3, l_API_error_4, l_API_error_5, l_API_error_6, l_API_error_7, l_API_error_8
   -- l_Incident_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Debrief_Exsits_For_SR, l_Debrief_Exsits_For_DR, l_Task_Status_SR, 
   l_API_error_1                := NULL;
   l_API_error_2                := NULL;
   l_API_error_3                := NULL;
   l_API_error_4                := NULL;
   l_API_error_5                := NULL;
   l_API_error_6                := NULL;
   l_API_error_7                := NULL;
   l_API_error_8                := NULL;
   l_API_error_9                := NULL;                                        -- 2017/04/04 - Added l_API_error_9
   l_Incident_Number            := NULL;
   l_Debrief_Number             := NULL;
   l_Debrief_Header_ID          := NULL;
   l_User_ID                    := NULL;
   l_Debrief_Exsits_For_SR      := NULL;
   l_Debrief_Exsits_For_DR      := NULL;
   l_Task_Status_SR             := NULL;
   l_Assignment_Task_Status_SR  := NULL;
   l_Debrief_Status_SR          := NULL;
   l_Task_Status_DR             := NULL;
   l_Assignment_Task_Status_DR  := NULL;
   l_Debrief_Status_DR          := NULL;
   
   -- Cursor for Debrief (Service Request)
   OPEN cur_0380;
   FETCH cur_0380 INTO l_Incident_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR;
   IF cur_0380%FOUND THEN
      l_Debrief_Exsits_For_SR := 'Y';
   ELSE
      l_Debrief_Exsits_For_SR := 'N';
   END IF;
   CLOSE cur_0380;

   IF (l_Debrief_Exsits_For_SR = 'Y') THEN 
      l_Error_Message := ('Debrief Exsits For SR: ' || l_Debrief_Exsits_For_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Incident_Number: ' || l_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Number: ' || l_Debrief_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Header_ID: ' || l_Debrief_Header_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_User_ID: ' || l_User_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Task_Status_SR: ' || l_Task_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Assignment_Task_Status_SR: ' || l_Assignment_Task_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Status_SR: ' || l_Debrief_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('p_Task_ID: ' || p_Task_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   -- Cursor for Debrief (Repair Order)
   OPEN cur_0400;
   FETCH cur_0400 INTO l_Incident_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_DR, l_Assignment_Task_Status_DR, l_Debrief_Status_DR;
   IF cur_0400%FOUND THEN
      l_Debrief_Exsits_For_DR := 'Y';
   ELSE
      l_Debrief_Exsits_For_DR := 'N';
   END IF;
   CLOSE cur_0400;

   IF (l_Debrief_Exsits_For_DR = 'Y') THEN 
      l_Error_Message := ('Debrief Exsits For DR: ' || l_Debrief_Exsits_For_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Incident_Number: ' || l_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Number: ' || l_Debrief_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Header_ID: ' || l_Debrief_Header_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_User_ID: ' || l_User_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Task_Status_DR: ' || l_Task_Status_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Assignment_Task_Status_DR: ' || l_Assignment_Task_Status_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Status_DR: ' || l_Debrief_Status_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('p_Task_ID: ' || p_Task_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   l_Error_Message := ('Debrief Exsits For SR: ' || NVL(l_Debrief_Exsits_For_SR, 'N'));
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := ('Debrief Exsits For DR: ' || NVL(l_Debrief_Exsits_For_DR, 'N'));
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   l_Error_Message := ('Processing DR Debrief - Start');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request')
   IF (NVL(l_Debrief_Exsits_For_DR, 'N') = 'Y')  AND (g_Process_Type = 'U') THEN
      -- If Debrief was 'COMPLETED W/ERRORS', then resubmit Debrief w/1
      IF (UPPER(l_Assignment_Task_Status_DR) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) AND (UPPER(l_Debrief_Status_DR) = 'COMPLETED W/ERRORS') THEN
         -- Submit Update Debrief lines with '1'
         DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 1.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'SCT', l_API_error_9); -- 2017/04/04 - Added l_API_error_9
      END IF;
      -- If Assignment_Task_Status is 'COMPLETED' and Debrief Status is 'COMPLETED', then resubmit Debrief w/2 
      IF (UPPER(l_Assignment_Task_Status_DR) = 'COMPLETED') AND (UPPER(l_Debrief_Status_DR) = 'COMPLETED') THEN
         -- Submit Update Debrief lines with '2'
         DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 2.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'SCT', l_API_error_9); -- 2017/04/04 - Added l_API_error_9
         -- Only process if no error returned from DEBRIEF_SUBMIT_CONCURRENT_PGM
         IF NVL(l_API_error_9, 'N') = 'N' THEN 
            -- Update Debrief Task Status to 'Closed'
            DEBRIEF_TASK_STATUS_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'DR', l_API_error_1);
            -- Update Debrief Task Assignment Status to 'Closed'
            DEBRIEF_TASK_ASSIGN_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'DR', l_API_error_2);
         END IF;
      ELSE
         l_Error_Message := ('Assignment_Task_Status_DR: ' || l_Assignment_Task_Status_DR || ', Debrief Status Code: ' || l_Debrief_Status_DR);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      END IF;
   END IF;

   -- If Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') AND Debrief Status was previously 'COMPLETED W/ERRORS', see if Debrief Status is now 'COMPLETED'
   IF (NVL(l_Debrief_Exsits_For_DR, 'N') = 'Y')  AND (g_Process_Type = 'U') THEN
      IF (UPPER(l_Assignment_Task_Status_DR) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) AND (UPPER(l_Debrief_Status_DR) = 'COMPLETED W/ERRORS') THEN
         -- Initialize l_Incident_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_DR, l_Assignment_Task_Status_DR, l_Debrief_Status_DR
         l_Incident_Number            := NULL;
         l_Debrief_Number             := NULL;
         l_Debrief_Header_ID          := NULL;
         l_User_ID                    := NULL;
         l_Task_Status_DR             := NULL;
         l_Assignment_Task_Status_DR  := NULL;
         l_Debrief_Status_DR          := NULL;

         -- Cursor for Debrief (Repair Order)
         OPEN cur_0400;
         FETCH cur_0400 INTO l_Incident_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_DR, l_Assignment_Task_Status_DR, l_Debrief_Status_DR;
         CLOSE cur_0400;

         -- If Assignment_Task_Status is 'COMPLETED' and Debrief Status is 'COMPLETED', then resubmit Debrief w/2
         -- If Debrief Status is still 'COMPLETED W/ERRORS' after resubmit, it will be reported in 'EDITS_POST_PROCESS'
         IF (UPPER(l_Assignment_Task_Status_DR) = 'COMPLETED') AND (UPPER(l_Debrief_Status_DR) = 'COMPLETED') THEN
            -- Submit Update Debrief lines with '2'
            DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 2.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'SCT', l_API_error_9); -- 2017/04/04 - Added l_API_error_9
            -- Only process if no error returned from DEBRIEF_SUBMIT_CONCURRENT_PGM
            IF NVL(l_API_error_9, 'N') = 'N' THEN 
               -- Update Debrief Task Status to 'Closed'
               DEBRIEF_TASK_STATUS_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'DR', l_API_error_3);
               -- Update Debrief Task Assignment Status to 'Closed'
               DEBRIEF_TASK_ASSIGN_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'DR', l_API_error_4);
            END IF;
         END IF;
      END IF;
   END IF;

   l_Error_Message := ('Processing DR Debrief - End');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   l_Error_Message := ('Processing SR Debrief - Start');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If Incident_Type NOT IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request')
   IF (NVL(l_Debrief_Exsits_For_SR, 'N') = 'Y') AND (g_Process_Type = 'U') THEN
      IF (UPPER(l_Assignment_Task_Status_SR) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED W/ERRORS') THEN
         -- If Debrief was 'COMPLETED W/ERRORS', then resubmit Debrief w/1
         DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 1.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'FSE', l_API_error_9); -- 2017/04/04 - Added l_API_error_9
      END IF;
      IF (UPPER(l_Assignment_Task_Status_SR) = 'COMPLETED') AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED') THEN
         -- Submit Update Debrief lines with '2'
         DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 2.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'FSE', l_API_error_9); -- 2017/04/04 - Added l_API_error_9
         -- Only process if no error returned from DEBRIEF_SUBMIT_CONCURRENT_PGM
         IF NVL(l_API_error_9, 'N') = 'N' THEN 
            -- Update Debrief Task Status to 'Closed'
            DEBRIEF_TASK_STATUS_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_error_5);
            -- Update Debrief Task Assignment Status to 'Closed'
            DEBRIEF_TASK_ASSIGN_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_error_6); 
         END IF;
      ELSE
         l_Error_Message := ('Assignment_Task_Status_SR: ' || l_Assignment_Task_Status_SR || ', Debrief Status Code: ' || l_Debrief_Status_SR);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      END IF;
   END IF;

   -- If Incident_Type NOT IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') AND Debrief Status was previously 'COMPLETED W/ERRORS', see if Debrief Status is now 'COMPLETED'
   IF (NVL(l_Debrief_Exsits_For_SR, 'N') = 'Y') AND (g_Process_Type = 'U') THEN
      IF (UPPER(l_Assignment_Task_Status_SR) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED W/ERRORS') THEN
         -- Initialize l_Incident_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR
         l_Incident_Number            := NULL;
         l_Debrief_Number             := NULL;
         l_Debrief_Header_ID          := NULL;
         l_User_ID                    := NULL;
         l_Task_Status_SR             := NULL;
         l_Assignment_Task_Status_SR  := NULL;
         l_Debrief_Status_SR          := NULL;

         -- Cursor for Debrief (Service Request)
         OPEN cur_0380;
         FETCH cur_0380 INTO l_Incident_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR;
         CLOSE cur_0380;

         -- If Assignment_Task_Status is 'COMPLETED' and Debrief Status is 'COMPLETED', then resubmit Debrief w/2 
         -- If Debrief Status is still 'COMPLETED W/ERRORS' after resubmit, it will be reported in 'EDITS_POST_PROCESS'
         IF (UPPER(l_Assignment_Task_Status_SR) = 'COMPLETED') AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED') THEN
            -- Submit Update Debrief lines with '2'
            DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 2.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'FSE', l_API_error_9); -- 2017/04/04 - Added l_API_error_9
            -- Only process if no error returned from DEBRIEF_SUBMIT_CONCURRENT_PGM
            IF NVL(l_API_error_9, 'N') = 'N' THEN 
               -- Update Debrief Task Status to 'Closed'
               DEBRIEF_TASK_STATUS_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_error_7);
               -- Update Debrief Task Assignment Status to 'Closed'
               DEBRIEF_TASK_ASSIGN_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_error_8);
            END IF;
         END IF;
      END IF;
   END IF;

   l_Error_Message := ('Processing SR Debrief - End');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Send back Output Error Parameter
   IF (NVL(l_API_Error_1, 'N') = 'Y') OR (NVL(l_API_Error_2, 'N') = 'Y') OR (NVL(l_API_Error_3, 'N') = 'Y') OR (NVL(l_API_Error_4, 'N') = 'Y') OR (NVL(l_API_Error_5, 'N') = 'Y') OR (NVL(l_API_Error_6, 'N') = 'Y') OR (NVL(l_API_Error_7, 'N') = 'Y') OR (NVL(l_API_Error_8, 'N') = 'Y')  OR (NVL(l_API_Error_9, 'N') = 'Y') THEN -- 2017/04/04 - Added '(NVL(l_API_Error_9, 'N') = 'Y')'
      P_DEBRIEF_PROCESS_WITH_DR := 'Y';
   ELSE
      P_DEBRIEF_PROCESS_WITH_DR := 'N';
   END IF;

   l_Error_Message := ('Exiting DEBRIEF_PROCESS_WITH_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END DEBRIEF_PROCESS_WITH_DR;

--------------------------------------------------------------------------------
-- DEBRIEF_PROCESS_WITHOUT_DR

PROCEDURE DEBRIEF_PROCESS_WITHOUT_DR(p_Org_ID                      IN  NUMBER
                                   , p_Incident_ID                 IN  NUMBER
                                   , p_Incident_Number             IN  VARCHAR2
                                   , p_Task_ID                     IN  NUMBER
                                   , P_DEBRIEF_PROCESS_WITHOUT_DR  OUT VARCHAR2
) IS

l_Debrief_Exsits_For_SR           VARCHAR2(01)                                  := NULL;

l_API_SR_TASK_STATUS_Error        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_UPDATE_TASK_Error1          XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_UPDATE_ASSIGN_Error1        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_UPDATE_TASK_Error2          XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_API_UPDATE_ASSIGN_Error2        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Incident_Number                 csd_repairs_v.Incident_Number%TYPE            := NULL;
l_Debrief_Number                  csf_debrief_headers.Debrief_Number%TYPE       := NULL;
l_Debrief_Header_ID               csf_debrief_headers.DEBRIEF_HEADER_ID%TYPE    := NULL;
l_Task_ID                         jtf_tasks_b.Task_ID%TYPE                      := NULL;
l_Object_Version_Number           jtf_tasks_b.Object_Version_Number%TYPE        := NULL;
l_User_ID                         FND_User.User_ID%TYPE                         := NULL;
l_Task_Status_SR                  JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Assignment_Task_Status_SR       JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Debrief_Status_SR               csf_debrief_headers.Processed_flag%TYPE       := NULL;
l_API_error_10                    XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL; -- 2017/04/04 - Added l_API_error_10

-- Cursor for Debrief (Service Request)
CURSOR cur_0420
IS
SELECT
    csi.incident_number
  , jtv.task_ID
  , jtv.Object_Version_Number
  , CDH.DEBRIEF_NUMBER
  , CDH.DEBRIEF_HEADER_ID
  , jrs.User_ID
  , jts.name                     "TASK_STATUS"
  , jts1.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh.Processed_flag           "DEBRIEF_STATUS"
FROM
    CS_SR_Incidents_V             csi 
  , jtf_tasks_vl                  jtv
  , jtf_task_assignments          jta
  , JTF_RS_RESOURCE_EXTNS         jrs
  , JTF_TASK_STATUSES_VL          jts
  , JTF_TASK_STATUSES_VL          jts1
  , csf_debrief_headers           cdh
WHERE
    csi.Org_ID                  = p_Org_ID
AND csi.incident_ID             = p_Incident_ID
AND jtv.Task_ID                 = p_Task_ID
AND csi.incident_ID             = jtv.source_object_ID
AND jtv.Source_Object_Type_Code = 'SR'
AND jtv.task_ID                 = jta.task_ID
AND jtv.Task_Status_ID          = jts.Task_Status_ID
AND JTA.ASSIGNMENT_STATUS_ID    = jts1.Task_Status_ID
AND jta.resource_ID             = jrs.resource_ID
AND jta.Task_Assignment_ID      = cdh.Task_Assignment_ID
;

BEGIN

   l_Error_Message := ('Entering DEBRIEF_PROCESS_WITHOUT_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_API_SR_TASK_STATUS_Error, l_API_UPDATE_TASK_Error1, l_API_UPDATE_ASSIGN_Error1, l_API_UPDATE_TASK_Error2, 
   -- l_API_UPDATE_ASSIGN_Error2, l_Incident_Number , l_Task_ID, l_Object_Version_Number, l_Debrief_Number, l_Debrief_Header_ID,
   -- l_User_ID, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR, l_Debrief_Exsits_For_SR 
   l_API_SR_TASK_STATUS_Error  := NULL;
   l_API_UPDATE_TASK_Error1    := NULL;
   l_API_UPDATE_ASSIGN_Error1  := NULL;
   l_API_UPDATE_TASK_Error2    := NULL;
   l_API_UPDATE_ASSIGN_Error2  := NULL;
   l_Incident_Number           := NULL;
   l_Task_ID                   := NULL;
   l_Object_Version_Number     := NULL;
   l_Debrief_Number            := NULL;
   l_Debrief_Header_ID         := NULL;
   l_User_ID                   := NULL;
   l_Task_Status_SR            := NULL;
   l_Assignment_Task_Status_SR := NULL;
   l_Debrief_Status_SR         := NULL;
   l_Debrief_Exsits_For_SR     := NULL;

   -- Cursor for Debrief (Service Request)
   OPEN cur_0420;
   FETCH cur_0420 INTO l_Incident_Number, l_Task_ID, l_Object_Version_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR;
   IF cur_0420%FOUND THEN
      l_Debrief_Exsits_For_SR := 'Y';
   ELSE
      l_Debrief_Exsits_For_SR := 'N';
   END IF;
   CLOSE cur_0420;

   IF (l_Debrief_Exsits_For_SR = 'Y') THEN
      l_Error_Message := ('DEBRIEF_PROCESS_WITHOUT_DR for Service Request#: ' || l_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Debrief Exsits For SR: ' || l_Debrief_Exsits_For_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Task_Status_SR: ' || l_Task_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Assignment_Task_Status_SR: ' || l_Assignment_Task_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Debrief_Status_SR: ' || l_Debrief_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Task_ID: ' || l_Task_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   l_Error_Message := ('Processing SR Debrief - Start');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   IF (NVL(l_Debrief_Exsits_For_SR, 'N') = 'Y') AND (g_Process_Type = 'U') THEN
      IF (UPPER(l_Assignment_Task_Status_SR) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED W/ERRORS') THEN
         -- If Debrief was 'COMPLETED W/ERRORS', then resubmit Debrief w/1
         DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 1.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'FSE', l_API_error_10); -- 2017/04/04 - Added l_API_error_10
      END IF;
      -- If Assignment_Task_Status is 'COMPLETED' and Debrief Status is 'COMPLETED', then resubmit Debrief w/2 
      IF (UPPER(l_Assignment_Task_Status_SR) = 'COMPLETED') AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED') THEN
         -- Submit Update Debrief lines with '2'
         DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 2.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'FSE', l_API_error_10); -- 2017/04/04 - Added l_API_error_10
         -- Only process if no error returned from DEBRIEF_SUBMIT_CONCURRENT_PGM
         IF NVL(l_API_error_10, 'N') = 'N' THEN 
            -- Update Debrief Task Status to 'Closed'
            DEBRIEF_TASK_STATUS_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_UPDATE_TASK_Error1);
            -- Update Debrief Task Assignment Status to 'Closed'
            DEBRIEF_TASK_ASSIGN_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_UPDATE_ASSIGN_Error1);
         END IF;
      ELSE
         l_Error_Message := ('Assignment_Task_Status_SR: ' || l_Assignment_Task_Status_SR || ', Debrief Status Code: ' || l_Debrief_Status_SR);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      END IF;
   END IF;

   -- If Debrief Status was previously 'COMPLETED W/ERRORS', see if Debrief Status is now 'COMPLETED'
   IF (NVL(l_Debrief_Exsits_For_SR, 'N') = 'Y') AND (g_Process_Type = 'U') THEN
      IF (UPPER(l_Assignment_Task_Status_SR) IN ('COMPLETED', 'CLOSED', 'CANCELLED')) AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED W/ERRORS') THEN
         -- Initialize l_Incident_Number, l_Task_ID, l_Object_Version_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR
         l_Incident_Number            := NULL;
         l_Task_ID                    := NULL;
         l_Object_Version_Number      := NULL;
         l_Debrief_Number             := NULL;
         l_Debrief_Header_ID          := NULL;
         l_User_ID                    := NULL;
         l_Task_Status_SR             := NULL;
         l_Assignment_Task_Status_SR  := NULL;
         l_Debrief_Status_SR          := NULL;

         -- Cursor for Debrief (Service Request)
         OPEN cur_0420;
         FETCH cur_0420 INTO l_Incident_Number, l_Task_ID, l_Object_Version_Number, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR;
         CLOSE cur_0420;

         -- If Assignment_Task_Status is 'COMPLETED' and Debrief Status is 'COMPLETED', then resubmit Debrief w/2 
         -- If Debrief Status is still 'COMPLETED W/ERRORS' after resubmit, it will be reported in 'EDITS_POST_PROCESS'
         IF (UPPER(l_Assignment_Task_Status_SR) = 'COMPLETED') AND (UPPER(l_Debrief_Status_SR) = 'COMPLETED') THEN
            -- Submit Update Debrief lines with '2'
            DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID, p_Incident_ID, 2.0, l_Debrief_Number, l_Debrief_Header_ID, l_User_ID, 'SCT', l_API_error_10); -- 2017/04/04 - Added l_API_error_10
            -- Only process if no error returned from DEBRIEF_SUBMIT_CONCURRENT_PGM
            IF NVL(l_API_error_10, 'N') = 'N' THEN 
               -- Update Debrief Task Status to 'Closed'
               DEBRIEF_TASK_STATUS_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_UPDATE_TASK_Error2);
               -- Update Debrief Task Assignment Status to 'Closed'
               DEBRIEF_TASK_ASSIGN_UPDATE(p_Org_ID, p_Incident_ID, l_Incident_Number, p_Task_ID, 'SR', l_API_UPDATE_ASSIGN_Error2);
            END IF;
         END IF;
      END IF;
   END IF;

   l_Error_Message := ('Processing SR Debrief - End');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Send back Output Error Parameter
   IF (NVL(l_API_UPDATE_TASK_Error1, 'N') = 'Y') OR (NVL(l_API_UPDATE_ASSIGN_Error1, 'N') = 'Y') OR (NVL(l_API_UPDATE_TASK_Error2, 'N') = 'Y') OR (NVL(l_API_UPDATE_ASSIGN_Error2, 'N') = 'Y') OR (NVL(l_API_error_10, 'N') = 'Y') THEN -- 2017/04/04 - Added '(NVL(l_API_error_10, 'N') = 'Y')'
      P_DEBRIEF_PROCESS_WITHOUT_DR := 'Y';
   ELSE
      P_DEBRIEF_PROCESS_WITHOUT_DR := 'N';
   END IF;

   l_Error_Message := ('Exiting DEBRIEF_PROCESS_WITHOUT_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END DEBRIEF_PROCESS_WITHOUT_DR;

--------------------------------------------------------------------------------
-- DEBRIEF_TASK_STATUS_UPDATE

PROCEDURE DEBRIEF_TASK_STATUS_UPDATE(p_Org_ID                        IN  NUMBER
                                   , p_Incident_ID                   IN  NUMBER
                                   , p_Incident_Number               IN  VARCHAR2
                                   , p_Task_ID                       IN  NUMBER
                                   , p_Source_Object_Type_Code       IN  VARCHAR2
                                   , P_DEBRIEF_TASK_STATUS_UPDATE    OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Task_ID                         jtf_tasks_vl.Task_ID%TYPE                     := NULL;
l_Task_Number                     jtf_tasks_vl.Task_Number%TYPE                 := NULL;
l_DEBRIEF_NUMBER                  csf_debrief_headers.DEBRIEF_NUMBER%TYPE       := NULL;
l_DEBRIEF_HEADER_ID               csf_debrief_headers.DEBRIEF_HEADER_ID%TYPE    := NULL;
l_User_ID                         JTF_RS_RESOURCE_EXTNS.User_ID%TYPE            := NULL;
l_TASK_STATUS                     JTF_TASK_STATUSES_VL.name%TYPE                := NULL;
l_ASSIGNMENT_TASK_STATUS          JTF_TASK_STATUSES_VL.name%TYPE                := NULL;
l_DEBRIEF_STATUS                  csf_debrief_headers.Processed_flag%TYPE       := NULL;
l_Source_Object_Type_Code         jtf_tasks_vl.Source_Object_Type_Code%TYPE     := NULL;
l_Object_Version_Number           cs_sr_tasks_v.Object_Version_Number%TYPE      := NULL;
l_Task_Status_ID_Closed           cs_sr_tasks_v.Task_Status_ID%TYPE             := 9;   -- 'Closed'

CURSOR cur_0422
IS
SELECT
    csi1.Org_ID
  , csi1.incident_ID
  , jtv1.task_ID
  , jtv1.task_number
  , CDH1.DEBRIEF_NUMBER
  , CDH1.DEBRIEF_HEADER_ID
  , jrs1.User_ID
  , jts1.name                     "TASK_STATUS"
  , jts11.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh1.Processed_flag           "DEBRIEF_STATUS"
  , jtv1.Source_Object_Type_Code
  , jtv1.Object_Version_Number
FROM
    CS_SR_Incidents_V              csi1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , JTF_TASK_STATUSES_VL           jts11
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = p_Source_Object_Type_Code
AND jtv1.task_ID                 = p_Task_ID
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND JTA1.ASSIGNMENT_STATUS_ID    = jts11.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID

UNION

SELECT
    csi2.Org_ID
  , csi2.incident_ID
  , jtv2.task_ID
  , jtv2.task_number
  , CDH2.DEBRIEF_NUMBER
  , CDH2.DEBRIEF_HEADER_ID
  , jrs2.User_ID
  , jts2.name                     "TASK_STATUS"
  , jts21.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh2.Processed_flag           "DEBRIEF_STATUS"
  , jtv2.Source_Object_Type_Code
  , jtv2.Object_Version_Number
FROM
    CS_SR_Incidents_V              csi2
  , csd_repairs_V                  cr2
  , jtf_tasks_vl                   jtv2
  , jtf_task_assignments           jta2
  , JTF_RS_RESOURCE_EXTNS          jrs2
  , JTF_TASK_STATUSES_VL           jts2
  , JTF_TASK_STATUSES_VL           jts21
  , csf_debrief_headers            cdh2
WHERE
    csi2.Org_ID                  = p_Org_ID
AND csi2.incident_ID             = p_Incident_ID
AND csi2.incident_ID             = cr2.incident_ID
AND cr2.repair_line_ID           = jtv2.source_object_ID
AND jtv2.Source_Object_Type_Code = p_Source_Object_Type_Code
AND jtv2.task_ID                 = p_Task_ID
AND jtv2.task_ID                 = jta2.task_ID
AND jtv2.Task_Status_ID          = jts2.Task_Status_ID
AND JTA2.ASSIGNMENT_STATUS_ID    = jts21.Task_Status_ID
AND jta2.resource_ID             = jrs2.resource_ID
AND jta2.Task_Assignment_ID      = cdh2.Task_Assignment_ID
;

BEGIN

   l_Error_Message := ('Entering DEBRIEF_TASK_STATUS_UPDATE for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Reset Context back to Original Information
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, g_Current_Responsibility_ID, g_Current_Resp_Appl_ID);
   MO_GLOBAL.INIT('CSR');

   -- Initialize l_API_Error, l_API_Return_Status, l_Org_ID, l_Incident_ID, l_Task_ID, l_Task_Number, l_DEBRIEF_NUMBER, l_DEBRIEF_HEADER_ID, l_User_ID, 
   -- l_TASK_STATUS, l_ASSIGNMENT_TASK_STATUS, l_DEBRIEF_STATUS, l_Source_Object_Type_Code, l_Object_Version_Number
   l_API_Error               := NULL;
   l_API_Return_Status       := NULL;
   l_Org_ID                  := NULL;
   l_Incident_ID             := NULL;
   l_Task_ID                 := NULL;
   l_Task_Number             := NULL;
   l_DEBRIEF_NUMBER          := NULL;
   l_DEBRIEF_HEADER_ID       := NULL;
   l_User_ID                 := NULL;
   l_TASK_STATUS             := NULL;
   l_ASSIGNMENT_TASK_STATUS  := NULL;
   l_DEBRIEF_STATUS          := NULL;
   l_Source_Object_Type_Code := NULL;
   l_Object_Version_Number   := NULL;

   -- Retrieve Tasks
   OPEN cur_0422;
   FETCH cur_0422 INTO l_Org_ID, l_incident_ID, l_task_ID, l_task_number, l_DEBRIEF_NUMBER, l_DEBRIEF_HEADER_ID, l_User_ID, l_TASK_STATUS, l_ASSIGNMENT_TASK_STATUS, l_DEBRIEF_STATUS, l_Source_Object_Type_Code, l_Object_Version_Number;
   CLOSE cur_0422;

   l_Error_Message := 'Parameter Source_Object_Type_Code: ' || p_Source_Object_Type_Code;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := 'Source_Object_Type_Code: ' || l_Source_Object_Type_Code;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   l_Error_Message := 'TASK_STATUS: ' || l_TASK_STATUS;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := 'ASSIGNMENT_TASK_STATUS: ' || l_ASSIGNMENT_TASK_STATUS;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := 'DEBRIEF_STATUS: ' || l_DEBRIEF_STATUS;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   BEGIN

   IF ((p_Source_Object_Type_Code = l_Source_Object_Type_Code) AND (UPPER(l_TASK_STATUS) <> 'CLOSED')) THEN 
   BEGIN

      -- Call API
      JTF_TASKS_PUB.UPDATE_TASK(
        p_api_version            => 1.0
      , p_init_msg_list          => fnd_api.g_true
      , p_commit                 => fnd_api.g_false
      , p_Object_Version_Number  => l_Object_Version_Number
      , p_task_ID                => l_Task_ID
      , p_task_number            => l_Task_Number
      , p_task_status_ID         => l_Task_Status_ID_Closed
      , x_return_status          => l_api_return_status
      , x_msg_count              => l_api_msg_count
      , x_msg_data               => l_api_msg_data
      , p_enable_workflow        => NULL
      , p_abort_workflow         => NULL);

      l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If successful, was there a message sent back?
      IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
         COMMIT;
         l_API_Error     := 'N';
         l_Error_Message := ('Debrief Task Status updated for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;

      -- If unsuccessful, was there a message sent back?
      ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
         ROLLBACK;
         l_API_Error     := 'Y';
         l_Error_Message := ('Debrief Task Status not updated for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         l_Error_Message := ('ROLLBACK performed');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         END LOOP;
      END IF;

   -- Catch any Errors
   EXCEPTION WHEN OTHERS THEN
      l_API_Error     := 'N';
      l_Error_Message := 'Exception occurred for API: JTF_TASKS_PUB.UPDATE_TASK (Debrief) for Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

   END;
   END IF;

   END;

   -- Send back Output Error Parameter
   P_DEBRIEF_TASK_STATUS_UPDATE := (NVL(l_API_Error, 'N'));

   l_Error_Message := ('Exiting DEBRIEF_TASK_STATUS_UPDATE for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END DEBRIEF_TASK_STATUS_UPDATE;

--------------------------------------------------------------------------------
-- DEBRIEF_TASK_ASSIGN_UPDATE

PROCEDURE DEBRIEF_TASK_ASSIGN_UPDATE(p_Org_ID                        IN  NUMBER
                                   , p_Incident_ID                   IN  NUMBER
                                   , p_Incident_Number               IN  VARCHAR2
                                   , p_Task_ID                       IN  NUMBER
                                   , p_Source_Object_Type_Code       IN  VARCHAR2
                                   , P_DEBRIEF_TASK_ASSIGN_UPDATE    OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Task_ID                         jtf_tasks_vl.Task_ID%TYPE                     := NULL;
l_Task_Number                     jtf_tasks_vl.Task_Number%TYPE                 := NULL;
l_DEBRIEF_NUMBER                  csf_debrief_headers.DEBRIEF_NUMBER%TYPE       := NULL;
l_DEBRIEF_HEADER_ID               csf_debrief_headers.DEBRIEF_HEADER_ID%TYPE    := NULL;
l_User_ID                         JTF_RS_RESOURCE_EXTNS.User_ID%TYPE            := NULL;
l_TASK_STATUS                     JTF_TASK_STATUSES_VL.name%TYPE                := NULL;
l_ASSIGNMENT_TASK_STATUS          JTF_TASK_STATUSES_VL.name%TYPE                := NULL;
l_DEBRIEF_STATUS                  csf_debrief_headers.Processed_flag%TYPE       := NULL;
l_Source_Object_Type_Code         jtf_tasks_vl.Source_Object_Type_Code%TYPE     := NULL;
l_Task_Assignment_ID              jtf_task_assignments.Task_Assignment_ID%TYPE  := NULL;
l_Object_Version_Number           cs_sr_tasks_v.Object_Version_Number%TYPE      := NULL;
l_Task_Status_ID_Closed           cs_sr_tasks_v.Task_Status_ID%TYPE             := 9;   -- 'Closed'

-- Retrieve Task Assignments
CURSOR cur_0424
IS
SELECT
    csi1.Org_ID
  , csi1.incident_ID
  , jtv1.task_ID
  , jtv1.task_number
  , CDH1.DEBRIEF_NUMBER
  , CDH1.DEBRIEF_HEADER_ID
  , jrs1.User_ID
  , jts1.name                     "TASK_STATUS"
  , jts11.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh1.Processed_flag           "DEBRIEF_STATUS"
  , jtv1.Source_Object_Type_Code
  , jta1.Task_Assignment_ID
  , jta1.object_version_number
FROM
    CS_SR_Incidents_V              csi1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , JTF_TASK_STATUSES_VL           jts11
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'SR'
AND jtv1.task_ID                 = p_Task_ID
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND JTA1.ASSIGNMENT_STATUS_ID    = jts11.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID

UNION

SELECT
    csi2.Org_ID
  , csi2.incident_ID
  , jtv2.task_ID
  , jtv2.task_number
  , CDH2.DEBRIEF_NUMBER
  , CDH2.DEBRIEF_HEADER_ID
  , jrs2.User_ID
  , jts2.name                     "TASK_STATUS"
  , jts21.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh2.Processed_flag           "DEBRIEF_STATUS"
  , jtv2.Source_Object_Type_Code
  , jta2.Task_Assignment_ID
  , jta2.object_version_number
FROM
    CS_SR_Incidents_V              csi2
  , csd_repairs_V                  cr2
  , jtf_tasks_vl                   jtv2
  , jtf_task_assignments           jta2
  , JTF_RS_RESOURCE_EXTNS          jrs2
  , JTF_TASK_STATUSES_VL           jts2
  , JTF_TASK_STATUSES_VL           jts21
  , csf_debrief_headers            cdh2
WHERE
    csi2.Org_ID                  = p_Org_ID
AND csi2.incident_ID             = p_Incident_ID
AND csi2.incident_ID             = cr2.incident_ID
AND cr2.repair_line_ID           = jtv2.source_object_ID
AND jtv2.Source_Object_Type_Code = 'DR'
AND jtv2.task_ID                 = p_Task_ID
AND jtv2.task_ID                 = jta2.task_ID
AND jtv2.Task_Status_ID          = jts2.Task_Status_ID
AND JTA2.ASSIGNMENT_STATUS_ID    = jts21.Task_Status_ID
AND jta2.resource_ID             = jrs2.resource_ID
AND jta2.Task_Assignment_ID      = cdh2.Task_Assignment_ID
;

BEGIN

   l_Error_Message := ('Entering DEBRIEF_TASK_ASSIGN_UPDATE for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Reset Context back to Original Information
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, g_Current_Responsibility_ID, g_Current_Resp_Appl_ID);
   MO_GLOBAL.INIT('CSR');

   -- Initialize l_API_Error, l_API_Return_Status, l_Org_ID, l_Incident_ID, l_Task_ID, l_Task_Number, l_DEBRIEF_NUMBER, l_DEBRIEF_HEADER_ID, l_User_ID, 
   -- l_TASK_STATUS, l_ASSIGNMENT_TASK_STATUS, l_DEBRIEF_STATUS, l_Source_Object_Type_Code, l_Task_Assignment_ID, l_Object_Version_Number
   l_API_Error               := NULL;
   l_API_Return_Status       := NULL;
   l_Org_ID                  := NULL;
   l_Incident_ID             := NULL;
   l_Task_ID                 := NULL;
   l_Task_Number             := NULL;
   l_DEBRIEF_NUMBER          := NULL;
   l_DEBRIEF_HEADER_ID       := NULL;
   l_User_ID                 := NULL;
   l_TASK_STATUS             := NULL;
   l_ASSIGNMENT_TASK_STATUS  := NULL;
   l_DEBRIEF_STATUS          := NULL;
   l_Source_Object_Type_Code := NULL;
   l_Task_Assignment_ID      := NULL;
   l_Object_Version_Number   := NULL;

   -- Retrieve Task Assignments
   OPEN cur_0424;
   FETCH cur_0424 INTO l_Org_ID, l_incident_ID, l_task_ID, l_task_number, l_DEBRIEF_NUMBER, l_DEBRIEF_HEADER_ID, l_User_ID, l_TASK_STATUS, l_ASSIGNMENT_TASK_STATUS, l_DEBRIEF_STATUS, l_Source_Object_Type_Code, l_Task_Assignment_ID, l_Object_Version_Number;
   CLOSE cur_0424;

   l_Error_Message := 'Parameter Source_Object_Type_Code: ' || p_Source_Object_Type_Code;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := 'Service Request Source_Object_Type_Code: ' || l_Source_Object_Type_Code;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   l_Error_Message := 'TASK_STATUS: ' || l_TASK_STATUS;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := 'ASSIGNMENT_TASK_STATUS: ' || l_ASSIGNMENT_TASK_STATUS;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := 'DEBRIEF_STATUS: ' || l_DEBRIEF_STATUS;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   BEGIN

   IF ((p_Source_Object_Type_Code = l_Source_Object_Type_Code) AND (UPPER(l_ASSIGNMENT_TASK_STATUS) <> 'CLOSED')) THEN
   BEGIN

      -- Call API
      JTF_TASK_ASSIGNMENTS_PUB.Update_Task_Assignment(
        p_api_version                 => 1.0
      , p_Object_Version_Number       => l_Object_Version_Number
      , p_init_msg_list               => fnd_api.g_true
      , p_commit                      => fnd_api.g_false
      , p_Task_Assignment_ID          => l_Task_Assignment_ID
      , p_task_id                     => l_task_id
      , p_task_number                 => l_task_number
      , p_assignment_status_id        => l_Task_Status_ID_Closed
      , x_return_status               => l_api_return_status
      , x_msg_count                   => l_api_msg_count
      , x_msg_data                    => l_api_msg_data
      , p_enable_workflow             => NULL
      , p_abort_workflow              => NULL);

      l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If successful, was there a message sent back?
      IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
         COMMIT;
         l_API_Error     := 'N';
         l_Error_Message := ('Debrief Task Assignment Status updated for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;

      -- If unsuccessful, was there a message sent back?
      ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
         ROLLBACK;
         l_API_Error     := 'Y';
         l_Error_Message := ('Debrief Task Assignment Status not updated for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         l_Error_Message := ('ROLLBACK performed');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
      END IF;

   -- Catch any Errors
   EXCEPTION WHEN OTHERS THEN
      l_API_Error     := 'N';
      l_Error_Message := 'Exception occurred for API: JTF_TASK_ASSIGNMENTS_PUB.UPDATE_TASK_ASSIGNMENT (Debrief) for Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

   END;

   END IF;
   END;

   -- Send back Output Error Parameter
   P_DEBRIEF_TASK_ASSIGN_UPDATE := (NVL(l_API_Error, 'N'));

   l_Error_Message := ('Exiting DEBRIEF_TASK_ASSIGN_UPDATE for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END DEBRIEF_TASK_ASSIGN_UPDATE;

--------------------------------------------------------------------------------
-- DEBRIEF_SUBMIT_CONCURRENT_PGM

PROCEDURE DEBRIEF_SUBMIT_CONCURRENT_PGM(p_Org_ID                     IN  NUMBER
                                      , p_Incident_ID                IN  NUMBER
                                      , P_API_Version                IN  NUMBER
                                      , P_Debrief_Number             IN  VARCHAR2
                                      , P_Debrief_Header_ID          IN  NUMBER
                                      , P_User_ID                    IN  NUMBER
                                      , P_Type                       IN  VARCHAR2
                                      , P_DEBRIEF_SUBMIT_CONCURRENT  OUT VARCHAR2
) IS

l_SCT_Responsibility_ID           fnd_responsibility.responsibility_ID%TYPE     := NULL;
l_SCT_Application_ID              fnd_responsibility.Application_ID%TYPE        := NULL;
l_FSE_Responsibility_ID           fnd_responsibility.responsibility_ID%TYPE     := NULL;
l_FSE_Application_ID              fnd_responsibility.Application_ID%TYPE        := NULL;
l_Responsibility_ID               fnd_responsibility.responsibility_ID%TYPE     := NULL;
l_Application_ID                  fnd_responsibility.Application_ID%TYPE        := NULL;
l_Request_ID                      fnd_concurrent_requests.Request_ID%TYPE       := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;

l_Requested_ID                    fnd_concurrent_requests.Request_ID%TYPE             := NULL;
l_Request_Date                    fnd_concurrent_requests.Request_Date%TYPE           := NULL;
l_Actual_Start_Date               fnd_concurrent_requests.Actual_Start_Date%TYPE      := NULL;
l_Actual_Completion_Date          fnd_concurrent_requests.Actual_Completion_Date%TYPE := NULL;
l_Phase_Code                      fnd_concurrent_requests.Phase_Code%TYPE             := NULL; -- 'C','Completed', 'P','Unknown', 'R','Running')
l_Status_Code                     fnd_concurrent_requests.Status_Code%TYPE            := NULL; -- 'A','Waiting', 'B','Resuming', 'C','Normal', 'D','Cancelled', 'E','Error', 'F','Scheduled', 'G','Warning', 'H','On Hold', 'I','Normal', 'M','No Manager', 'Q','Standby', 'R','Normal' ,'S','Suspended', 'T','Terminating', 'U','Disabled', 'W','Paused', 'X','Terminated', 'Z','Waiting'
l_Completion_Text                 fnd_concurrent_requests.Completion_Text%TYPE        := NULL; 

-- Find Concurrent Program
CURSOR cur_0430 (p_REQUEST_ID fnd_concurrent_requests.REQUEST_ID%TYPE)
IS
SELECT
    fcr.REQUEST_ID
  , fcr.Request_Date
  , fcr.actual_start_date
  , fcr.actual_completion_date
  , fcr.Phase_Code
  , fcr.Status_Code                                                             -- 2017/04/04 - Added Status Code
  , fcr.Completion_Text                                                         -- 2017/04/04 - Added Completion Text
FROM 
    apps.fnd_concurrent_requests fcr
WHERE
    fcr.REQUEST_ID = p_REQUEST_ID
;

BEGIN

   -- Initialize l_API_Error
   l_API_Error               := NULL;

   l_Error_Message := ('Entering DEBRIEF_SUBMIT_CONCURRENT_PGM for Debrief Number: ' || P_Debrief_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Retrieve Responsibility_ID and Application_ID for the SCT Responsibility_Name
   SELECT
       frtl.responsibility_ID
     , frx.application_ID
   INTO
       l_SCT_Responsibility_ID
     , l_SCT_Application_ID
   FROM
       fnd_responsibility            frx
     , fnd_responsibility_tl         frtl
   WHERE
       frtl.responsibility_ID      = frx.responsibility_ID
   AND frtl.language               = 'US'
   AND frtl.responsibility_name    = g_SCT_Responsibility_Name;

   -- Retrieve Responsibility_ID and Application_ID for the FSE Responsibility_Name
   SELECT
       frtl1.responsibility_ID
     , frx1.application_ID
   INTO
       l_FSE_Responsibility_ID
     , l_FSE_Application_ID
   FROM
       fnd_responsibility            frx1
     , fnd_responsibility_tl         frtl1
   WHERE
       frtl1.responsibility_ID     = frx1.responsibility_ID
   AND frtl1.language              = 'US'
   AND frtl1.responsibility_name   = g_FSE_Responsibility_Name;

   -- Determine which Responsiblity to be used
   IF (P_Type = 'SCT') THEN
      l_responsibility_ID := l_SCT_responsibility_ID;
      l_application_ID    := l_SCT_application_ID;
   ELSIF (P_Type = 'FSE') THEN
      l_responsibility_ID := l_FSE_responsibility_ID;
      l_application_ID    := l_FSE_application_ID;
   ELSE
      l_responsibility_ID := NULL;
      l_application_ID    := NULL;
   END IF;

   -- If data retrieved, then submit the Concurrent Program
   IF (l_responsibility_ID IS NOT NULL) AND (l_application_ID IS NOT NULL) AND (g_Application_Short_Name IS NOT NULL) THEN

      -- Set Context to FSE_Responsibility/SCT_Responsibility
      FND_GLOBAL.APPS_INITIALIZE(P_user_ID, l_responsibility_ID, l_application_ID);
      MO_GLOBAL.INIT('CSF');
      MO_GLOBAL.SET_POLICY_CONTEXT('S',P_Org_ID);

      --FND_FILE.PUT_LINE(FND_FILE.LOG,'P_user_ID:                                ' || P_user_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'l_responsibility_ID:                      ' || l_responsibility_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'l_application_ID:                         ' || l_application_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'                                          ');

      -- Submit Concurrent Request
      l_request_ID := fnd_request.submit_request
      (
        application  => g_APPLICATION_SHORT_NAME
      , program      => g_Concurrent_Program_Name
      , description  => 'CSF:Update Debrief Lines'
      , start_time   => sysdate
      , sub_request  => FALSE
      , argument1    => P_API_Version
      , argument2    => p_DEBRIEF_HEADER_ID
      , argument3    => P_Incident_ID
      );
      COMMIT;

      --FND_FILE.PUT_LINE(FND_FILE.LOG,'P_Org_ID:                                 ' || P_Org_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'P_user_ID:                                ' || P_user_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'l_responsibility_ID:                      ' || l_responsibility_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'l_application_ID:                         ' || l_application_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'g_SCT_Responsibility_Name:                ' || g_SCT_Responsibility_Name);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'g_FSE_Responsibility_Name:                ' || g_FSE_Responsibility_Name);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Application_Short_Name:                 ' || g_Application_Short_Name);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Concurrent_Progam_Name:                 ' || g_Concurrent_Program_Name);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'Debrief submitted for Debrief Number:     ' || P_Debrief_Number || ' with API: ' || P_API_Version || ' , Concurrent Request ID: ' || l_request_ID);
      --FND_FILE.PUT_LINE(FND_FILE.LOG,'                                          ');

      l_Error_Message := ('Debrief was submitted for Debrief Number: ' || P_Debrief_Number || ' with API: ' || P_API_Version || ' , Concurrent Request ID: ' || l_request_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);

      -- Initialize l_Requested_ID, l_Request_Date, l_Actual_Start_Date, l_Actual_Completion_Date, l_Phase_Code, l_Satus_Code
      l_Requested_ID           := NULL;
      l_Request_Date           := NULL;
      l_Actual_Start_Date      := NULL;
      l_Actual_Completion_Date := NULL;
      l_Phase_Code             := NULL;
      l_Status_Code            := NULL;

      -- Wait 10 seconds before checking for completion of Concurrent Request
      DBMS_LOCK.sleep(10);

      -- Wait for Concurrent Request to complete before continuing on
      LOOP
         OPEN cur_0430(l_request_ID);
         FETCH cur_0430 INTO l_Requested_ID, l_Request_Date, l_Actual_Start_Date, l_Actual_Completion_Date, l_Phase_Code, l_Status_Code, l_Completion_Text; -- 2017/04/04 - Added Status Code, Completion Text
         IF l_Actual_Completion_Date IS NOT NULL THEN
            l_Error_Message := ('Concurrent Request completed, Request ID: ' || l_request_ID || ', Phase Code: ' || l_Phase_Code || ', Status Code: ' || l_Status_Code);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         ELSE
            IF l_Status_Code IN ('D','E') THEN -- 'D','Cancelled', 'E','Error'
               l_Error_Message := ('Concurrent Request was Cancelled or was in Error, Request ID: ' || l_request_ID || ', Phase Code: ' || l_Phase_Code || ', Status Code: ' || l_Status_Code);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               l_Error_Message := ('Concurrent Request Error: ' || l_Completion_Text);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               l_Error_Message := ('Debrief could not be submitted for Debrief Number: ' || P_Debrief_Number);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               l_API_Error     := 'Y';
               EXIT; -- Drop out of the loop
            ELSE
               l_Error_Message := ('Concurrent Request HAS NOT completed, Request ID: ' || l_request_ID || ', Phase Code: ' || l_Phase_Code || ', Status Code: ' || l_Status_Code);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               l_Error_Message := ('Waiting 5 seconds before re-checking Concurrent Request Status');
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               DBMS_LOCK.sleep(5); -- Wait 5 seconds before trying again
            END IF;
         END IF;
         EXIT WHEN l_Actual_Completion_Date IS NOT NULL;
         CLOSE cur_0430;
      END LOOP;
   ELSE
      l_Error_Message := ('Debrief was not submitted for Debrief Number: ' || P_Debrief_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      l_Error_Message := ('FSE/SCT Responsibility setup information not found for Org: ' || P_Org_ID);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Reset Context back to Original Information
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, g_Current_Responsibility_ID, g_Current_Resp_Appl_ID);
   --FND_FILE.PUT_LINE(FND_FILE.LOG,'Re-Set Environment Context                ');
   --FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Current_User_ID:                        ' || g_Current_User_ID);
   --FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Current_Responsibility_ID:              ' || g_Current_Responsibility_ID);
   --FND_FILE.PUT_LINE(FND_FILE.LOG,'g_Current_Resp_Appl_ID:                   ' || g_Current_Resp_Appl_ID);
   --FND_FILE.PUT_LINE(FND_FILE.LOG,'                                          ');

   l_Error_Message := ('Performed Context Reset for User_ID, Responsibility_ID and Responsibility_Application_ID');
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := ('g_Current_User_ID: ' || g_Current_User_ID);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := ('g_Current_Responsibility_ID: ' || g_Current_Responsibility_ID);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   l_Error_Message := ('g_Current_Resp_Appl_ID: ' || g_Current_Resp_Appl_ID);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Send back Output Error Parameter
   P_DEBRIEF_SUBMIT_CONCURRENT := (NVL(l_API_Error, 'N'));

   l_Error_Message := ('Exiting DEBRIEF_SUBMIT_CONCURRENT_PGM for Debrief Number: ' || P_Debrief_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END DEBRIEF_SUBMIT_CONCURRENT_PGM;

--------------------------------------------------------------------------------
-- FIND_RECENT_SR (NOT CURRENTLY ACTIVE)

PROCEDURE FIND_RECENT_SR(p_Org_ID                          IN  NUMBER
                       , p_Incident_ID                     IN  NUMBER
                       , p_Incident_Number                 IN  VARCHAR2
                       , p_Inventory_Item_ID               IN  NUMBER
                       , p_Serial_Number                   IN  VARCHAR2
                       , p_Incident_Date                   IN  DATE
                       , p_Incident_Type                   IN  VARCHAR2
                       , P_FIND_RECENT_SR                  OUT VARCHAR2
) IS

l_Days                            NUMBER                                        := 0;
l_Other_SR_Found                  VARCHAR2(01)                                  := NULL;

l_Update_OM_API_Error             XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Order_API_Error                 XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_FIND_RECENT_SR                  XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number                 CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Inventory_Item_ID               CS_SR_Incidents_V.Inventory_Item_ID%TYPE      := NULL;
l_Serial_Number                   csi_item_instances.serial_number%TYPE         := NULL;
l_Date_Closed                     CS_SR_Incidents_V.Date_Closed%TYPE            := NULL;
l_Incident_Date                   CS_SR_Incidents_V.Incident_Date%TYPE          := NULL;
l_Item_Number                     MTL_SYSTEM_ITEMS_B.SEGMENT1%TYPE              := NULL;

-- Find other Service Requests for same Item/Serial Number within 30 days (+/-)
CURSOR cur_0440
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , csi.Inventory_Item_ID
  , itm.Segment1
  , ccs.Serial_Number
  , csi.Date_Closed
  , csi.Incident_Date
  , (TRUNC(p_Incident_Date) - TRUNC(csi.Date_Closed))
FROM
    CS_SR_Incidents_V          csi
  , csi_item_instances         ccs
  , MTL_SYSTEM_ITEMS_B         itm
WHERE
    csi.Org_ID               = p_Org_ID
AND csi.Inventory_Item_ID    = p_Inventory_Item_ID
AND csi.Inventory_Item_ID    = itm.Inventory_Item_ID
AND itm.Organization_ID      = 103
AND csi.Customer_Product_ID  = ccs.Instance_ID
AND ccs.Serial_Number        = p_Serial_Number
AND csi.Date_Closed          IS NOT NULL
-- Within 30 days (+/-)
AND (
    (TRUNC(p_Incident_Date) - TRUNC(csi.INCIDENT_DATE)) <=  30
 OR (TRUNC(p_Incident_Date) - TRUNC(csi.INCIDENT_DATE)) >= -30
    )
ORDER BY
    csi.Date_Closed DESC
;

BEGIN

   l_Error_Message := ('Entering FIND_RECENT_SR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initalize l_FIND_RECENT_SR, l_Org_ID, l_Incident_ID, l_Incident_Number, l_Inventory_Item_ID, l_Item_Number, 
   -- l_Serial_Number, l_Date_Closed, l_Incident_Date, l_Days, l_Other_SR_Found
   l_FIND_RECENT_SR    := 'N';
   l_Org_ID            := NULL;
   l_Incident_ID       := NULL;
   l_Incident_Number   := NULL;
   l_Inventory_Item_ID := NULL;
   l_Item_Number       := NULL;
   l_Serial_Number     := NULL;
   l_Date_Closed       := NULL;
   l_Incident_Date     := NULL;
   l_Days              := NULL;
   l_Other_SR_Found    := NULL;

   -- Find other Service Requests for same Item/Serial Number within 30 days (+/-)
   OPEN cur_0440;
   FETCH cur_0440 INTO l_Org_ID, l_Incident_ID, l_Incident_Number, l_Inventory_Item_ID, l_Item_Number, l_Serial_Number, l_Date_Closed, l_Incident_Date, l_Days;
   IF cur_0440%FOUND THEN
      l_Other_SR_Found := 'Y';
   ELSE
      l_Other_SR_Found := 'N';
   END IF;
   CLOSE cur_0440;

   l_Error_Message := ('Org_ID: ' || p_Org_ID || ', Inventory_Item_ID: ' || p_Inventory_Item_ID || ', Serial_Number: ' || p_Serial_Number || ', Incident_ID: ' || p_Incident_ID || ', Incident_Date: ' || p_Incident_Date);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   IF (l_Other_SR_Found = 'Y') THEN
      l_Error_Message := ('Other_SR_Found:   ' || l_Other_SR_Found);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Other Service Request#: ' || l_Incident_Number);
      WRITE_DETAIL(l_Org_ID, l_Incident_Number, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Item#:            ' || l_Item_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Serial#:          ' || l_Serial_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Date Closed:      ' || l_Date_Closed);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Incident Date:    ' || p_Incident_Date);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('Days:             ' || l_Days);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   ELSE
      l_Error_Message := ('Other_SR_Found:   ' || l_Other_SR_Found);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   IF (l_Other_SR_Found = 'N') THEN
      UPDATE_OM_INTERFACE(p_Org_ID , p_Incident_ID, p_Incident_Number, p_Inventory_Item_ID , p_Serial_Number, p_Incident_Date, p_Incident_Type, l_Update_OM_API_Error);
      ORDER_SUBMIT_DETERMINATION(p_Org_ID , p_Incident_ID, p_Incident_Number, p_Inventory_Item_ID , p_Serial_Number, p_Incident_Date, p_Incident_Type, l_Order_API_Error);
   END IF;

   -- Set Output Parameter
   IF (NVL(l_Update_OM_API_Error, 'N') = 'Y') OR (NVL(l_Order_API_Error, 'N') = 'Y') THEN
      l_FIND_RECENT_SR := 'Y';
   ELSE
      l_FIND_RECENT_SR := 'N';
   END IF;

   -- Send back Output Error Parameter
   P_FIND_RECENT_SR := l_FIND_RECENT_SR;

   l_Error_Message := ('Exiting FIND_RECENT_SR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END FIND_RECENT_SR;

--------------------------------------------------------------------------------
-- UPDATE_OM_INTERFACE

PROCEDURE UPDATE_OM_INTERFACE(p_Org_ID                     IN  NUMBER
                            , p_Incident_ID                IN  NUMBER
                            , p_Incident_Number            IN  VARCHAR2
                            , p_Inventory_Item_ID          IN  NUMBER
                            , p_Serial_Number              IN  VARCHAR2
                            , p_Incident_Date              IN  DATE
                            , p_Incident_Type              IN  VARCHAR2
                            , P_UPDATE_OM_INTERFACE        OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                         := 0;
l_API_Msg_Index_Out               NUMBER                                         := 0;
l_API_Version                     NUMBER                                         := 1.0;
l_API_Msg_Data                    VARCHAR2(2000)                                 := NULL;
l_API_Return_Status               VARCHAR2(2000)                                 := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE      := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE     := NULL;
l_Object_Version_Number           CS_CHARGE_DETAILS_V.Object_Version_Number%TYPE := NULL;
l_Charges_REC                     CS_CHARGE_DETAILS_PUB.CHARGES_REC_TYPE         := NULL;

-- Cursor to retrieve where INTERFACE_TO_OE_FLAG = 'Y'
-- and Source_Code = 'SD'
CURSOR cur_0460
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , csc.INTERFACE_TO_OE_FLAG
  , csc.PARTY_ID
  , csc.ACCOUNT_ID
  , csc.LINE_NUMBER
  , csc.INVENTORY_ITEM_ID
  , csc.SERIAL_NUMBER
  , csc.ORDER_HEADER_ID
  , csc.ORDER_LINE_ID
  , csc.Object_Version_Number
  , csc.ESTIMATE_DETAIL_ID
  , csc.CREATION_DATE
  , csc.AFTER_WARRANTY_COST
  , csc.Source_Code
  , CSC.ORIGINAL_SOURCE_CODE_MEANING
FROM
    CS_SR_Incidents_V           csi
  , CS_CHARGE_DETAILS_V         csc
WHERE
    csi.Org_ID                = p_Org_ID
AND csi.Incident_ID           = p_Incident_ID
AND csi.Incident_ID           = csc.Incident_ID
--AND csc.AFTER_WARRANTY_COST   = 0
AND csc.INTERFACE_TO_OE_FLAG  = 'Y'
AND csc.Source_Code           = 'SD'
;

BEGIN

   l_Error_Message := ('Entering UPDATE_OM_INTERFACE for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_API_Error
   l_API_Error := NULL;

   -- Reset Context back to Original Information
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, g_Current_Responsibility_ID, g_Current_Resp_Appl_ID);
   MO_GLOBAL.INIT('CSR');

   -- Cursor to retrieve where INTERFACE_TO_OE_FLAG = 'Y' and Source_Code = 'SD'
   FOR dta140 IN cur_0460
   LOOP

      BEGIN

         L_CHARGES_REC.ESTIMATE_DETAIL_ID     := dta140.ESTIMATE_DETAIL_ID;
         L_CHARGES_REC.incident_id            := dta140.incident_id;
         L_CHARGES_REC.INTERFACE_TO_OE_FLAG   := 'N';                           -- Uncheck the flag!

         -- Call API
         CS_Charge_Details_PUB.Update_Charge_Details( 
           P_API_VERSION            => l_API_Version
         , p_init_msg_list          => fnd_api.g_true
         , p_commit                 => fnd_api.g_false
         , p_validation_level       => FND_API.G_VALID_LEVEL_FULL
         , X_RETURN_STATUS          => l_API_Return_Status
         , X_MSG_COUNT              => l_API_Msg_Count
         , x_Object_Version_Number  => l_Object_Version_Number
         , X_MSG_DATA               => l_api_Msg_Data
         , p_resp_appl_id           => FND_GLOBAL.RESP_APPL_ID
         , p_resp_id                => FND_GLOBAL.RESP_ID
         , p_user_id                => FND_GLOBAL.USER_ID
         , P_CHARGES_REC            => L_CHARGES_REC);

         l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If successful, was there a message sent back?
         IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
            COMMIT;
            l_API_Error     := 'N';
            l_Error_Message := ('INTERFACE_TO_OE_FLAG was updated for Service Request#: ' || dta140.Incident_Number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
            LOOP
               FND_MSG_PUB.GET(
                 P_MSG_INDEX      => L_INDEX
               , P_ENCODED        => 'F'
               , P_DATA           => l_Error_Message
               , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
               IF l_Error_Message IS NULL THEN
                  EXIT;
               END IF;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            END LOOP;

         -- If unsuccessful, was there a message sent back?
         ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
            ROLLBACK;
            l_API_Error     := 'Y';
            l_Error_Message := ('INTERFACE_TO_OE_FLAG was not updated for Service Request#: ' || dta140.Incident_Number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
            l_Error_Message := ('ROLLBACK performed');
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
            LOOP
               FND_MSG_PUB.GET(
                 P_MSG_INDEX      => L_INDEX
               , P_ENCODED        => 'F'
               , P_DATA           => l_Error_Message
               , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
               IF l_Error_Message IS NULL THEN
                  EXIT;
               END IF;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            END LOOP;
         END IF;
  
      -- Catch any Errors
      EXCEPTION WHEN OTHERS THEN
         l_API_Error     := 'Y';
         l_Error_Message := 'Exception occurred for API: CS_Charge_Details_PUB.Update_Charge_Details for Service Request#: ' || dta140.Incident_Number;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

      END;

      -- If any errors, exit loop
      IF NVL(l_API_Error, 'N') = 'Y' THEN
         EXIT;
      END IF;

   END LOOP;

   -- Send back Output Error Parameter
   P_UPDATE_OM_INTERFACE := NVL(l_API_Error, 'N');

   l_Error_Message := ('Exiting UPDATE_OM_INTERFACE for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END UPDATE_OM_INTERFACE;

--------------------------------------------------------------------------------
-- ORDER_SUBMIT_DETERMINATION (NOT CURRENTLY ACTIVE)

PROCEDURE ORDER_SUBMIT_DETERMINATION(p_Org_ID                        IN  NUMBER
                                   , p_Incident_ID                   IN  NUMBER
                                   , p_Incident_Number               IN  VARCHAR2
                                   , p_Inventory_Item_ID             IN  NUMBER
                                   , p_Serial_Number                 IN  VARCHAR2
                                   , p_Incident_Date                 IN  DATE
                                   , p_Incident_Type                 IN  VARCHAR2
                                   , P_ORDER_SUBMIT_DETERMINATION    OUT VARCHAR2
) IS

l_CC_EXISTS                       VARCHAR2(01)                                  := NULL;

l_Order_API_Error                 XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number                 CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Account_ID                      CS_SR_Incidents_V.Account_ID%TYPE             := NULL;
l_Customer_ID                     CS_SR_Incidents_V.Customer_ID%TYPE            := NULL;
l_CC_CARD_NUMBER                  CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_1%TYPE   := NULL;
l_CC_CARD_EXP_DATE                CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_2%TYPE   := NULL;
l_CC_CARD_TYPE                    CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_3%TYPE   := NULL;
l_CC_CARD_SECURITY_CODE           CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_4%TYPE   := NULL;
l_CC_CARD_HOLDER_NAME             CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_5%TYPE   := NULL;

-- Cursor to determine if CC Information exists
CURSOR cur_0480
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , csi.Account_ID
  , csi.Customer_ID
  , csi.EXTERNAL_ATTRIBUTE_1  -- CC Number
  , csi.EXTERNAL_ATTRIBUTE_2  -- CC Exp Date
  , csi.EXTERNAL_ATTRIBUTE_3  -- CC Type
  , csi.EXTERNAL_ATTRIBUTE_4  -- CC Security Code (SID)
  , csi.EXTERNAL_ATTRIBUTE_5  -- CC Name on Card
FROM
    CS_SR_Incidents_V          csi
WHERE
    csi.Org_ID               = p_Org_ID
AND csi.Incident_ID          = p_Incident_ID
AND csi.EXTERNAL_ATTRIBUTE_1 IS NOT NULL
AND csi.EXTERNAL_ATTRIBUTE_2 IS NOT NULL
AND csi.EXTERNAL_ATTRIBUTE_3 IS NOT NULL
AND csi.EXTERNAL_ATTRIBUTE_4 IS NOT NULL
AND csi.EXTERNAL_ATTRIBUTE_5 IS NOT NULL
;

BEGIN

   l_Error_Message := ('Entering ORDER_SUBMIT_DETERMINATION for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Order_API_Error, l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID, l_CC_CARD_NUMBER, 
   -- l_CC_CARD_EXP_DATE, l_CC_CARD_TYPE, l_CC_CARD_SECURITY_CODE, l_CC_CARD_HOLDER_NAME, l_CC_EXISTS
   l_Order_API_Error       := NULL;
   l_Org_ID                := NULL;
   l_Incident_ID           := NULL;
   l_Incident_Number       := NULL;
   l_Account_ID            := NULL;
   l_Customer_ID           := NULL;
   l_CC_CARD_NUMBER        := NULL;
   l_CC_CARD_EXP_DATE      := NULL;
   l_CC_CARD_TYPE          := NULL;
   l_CC_CARD_SECURITY_CODE := NULL;
   l_CC_CARD_HOLDER_NAME   := NULL;
   l_CC_EXISTS             := NULL;

   -- Cursor to determine if CC Information exists
   OPEN cur_0480;
   FETCH cur_0480 INTO l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID, l_CC_CARD_NUMBER, l_CC_CARD_EXP_DATE, l_CC_CARD_TYPE, l_CC_CARD_SECURITY_CODE, l_CC_CARD_HOLDER_NAME;
   IF cur_0480%FOUND THEN
      l_CC_EXISTS := 'Y';
   ELSE
      l_CC_EXISTS := 'N';
   END IF;
   CLOSE cur_0480;

   -- If no CC Information exists, Call ORDER_SUBMIT_WITHOUT_CC else Call ORDER_SUBMIT_WITH_CC
   IF (l_CC_EXISTS = 'N') THEN
      l_Error_Message := ('Processing ORDER_SUBMIT_WITHOUT_CC for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
      ORDER_SUBMIT_WITHOUT_CC(p_Org_ID , p_Incident_ID, p_Incident_Number, p_Inventory_Item_ID , p_Serial_Number, p_Incident_Date, p_Incident_Type, l_Order_API_Error);
   ELSE
      l_Error_Message := ('Processing ORDER_SUBMIT_WITH_CC for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
      ORDER_SUBMIT_WITH_CC(p_Org_ID , p_Incident_ID, p_Incident_Number, p_Inventory_Item_ID , p_Serial_Number, p_Incident_Date, p_Incident_Type, l_Order_API_Error);
   END IF;

   -- Reset Context back to Original Information
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, g_Current_Responsibility_ID, g_Current_Resp_Appl_ID);
   MO_GLOBAL.INIT('CSR');

   -- Send back Output Error Parameter
   P_ORDER_SUBMIT_DETERMINATION := NVL(l_Order_API_Error, 'N');

   l_Error_Message := ('Exiting ORDER_SUBMIT_DETERMINATION for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END ORDER_SUBMIT_DETERMINATION;

--------------------------------------------------------------------------------
-- ORDER_SUBMIT_WITHOUT_CC (NOT CURRENTLY ACTIVE)

PROCEDURE ORDER_SUBMIT_WITHOUT_CC(p_Org_ID                      IN  NUMBER
                                , p_Incident_ID                 IN  NUMBER
                                , p_Incident_Number             IN  VARCHAR2
                                , p_Inventory_Item_ID           IN  NUMBER
                                , p_Serial_Number               IN  VARCHAR2
                                , p_Incident_Date               IN  DATE
                                , p_Incident_Type               IN  VARCHAR2
                                , P_ORDER_SUBMIT_WITHOUT_CC     OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
l_API_Version                     NUMBER                                        := 1.0;
l_CC_EXISTS                       VARCHAR2(01)                                  := NULL;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_Order_API_Error                 XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number                 CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Account_ID                      CS_SR_Incidents_V.Account_ID%TYPE             := NULL;
l_Customer_ID                     CS_SR_Incidents_V.Customer_ID%TYPE            := NULL;
l_FSE_Responsibility_ID           fnd_responsibility.responsibility_ID%TYPE     := NULL;
l_FSE_Application_ID              fnd_responsibility.Application_ID%TYPE        := NULL;
l_order_header_ID                 CS_CHARGE_DETAILS_V.order_header_ID%TYPE      := NULL;
l_Order_number                    Oe_Order_headers_ALL.Order_number%TYPE        := NULL;

-- Cursor to Retrieve Responsibility_ID and Application_ID for the FSE Responsibility_Name
CURSOR cur_0500
IS
SELECT
    frtl.responsibility_ID
  , frx.application_ID
FROM
    fnd_responsibility            frx
  , fnd_responsibility_tl         frtl
WHERE
    frtl.responsibility_ID      = frx.responsibility_ID
AND frtl.language               = 'US'
AND frtl.responsibility_name    = g_FSE_Responsibility_Name
;
   
-- Cursor to retrieve Incident and Account Information
CURSOR cur_0520
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , csi.Account_ID
  , csi.Customer_ID
FROM
    CS_SR_Incidents_V     csi
WHERE
    csi.Org_ID          = p_Org_ID
AND csi.Incident_ID     = p_Incident_ID
;

-- Cursor to retrieve Order Number from Service Charge Details
CURSOR cur_0540
IS
SELECT DISTINCT
    csc.order_header_ID
  , oeh.Order_number
FROM
    CS_CHARGE_DETAILS_V     csc
  , Oe_Order_headers_ALL    oeh
WHERE
    csc.Org_ID            = p_Org_ID
AND csc.Incident_ID       = p_Incident_ID
AND csc.order_header_ID   = oeh.header_ID
AND csc.Line_status       = 'SUBMITTED'
AND csc.TOTAL_ESTIMATE    <> 0
;

BEGIN

   l_Error_Message := ('Entering ORDER_SUBMIT_WITHOUT_CC for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Order_API_Error, l_FSE_Responsibility_ID, l_FSE_Application_ID
   l_Order_API_Error       := NULL;
   l_FSE_Responsibility_ID := NULL;
   l_FSE_Application_ID    := NULL;

   -- Cursor to Retrieve Responsibility_ID and Application_ID for the FSE Responsibility_Name
   OPEN cur_0500;
   FETCH cur_0500 INTO l_FSE_Responsibility_ID, l_FSE_Application_ID;
   CLOSE cur_0500;

   -- Set Context to FSE_Responsibility
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, l_FSE_Responsibility_ID, l_FSE_Application_ID);
   MO_GLOBAL.INIT('ONT');
   MO_GLOBAL.SET_POLICY_CONTEXT('S', p_Org_ID);

   -- Initialize l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID
   l_Org_ID          := NULL;
   l_Incident_ID     := NULL;
   l_Incident_Number := NULL;
   l_Account_ID      := NULL;
   l_Customer_ID     := NULL;

   -- Cursor to retrieve Incident and Account Information
   OPEN cur_0520;
   FETCH cur_0520 INTO l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID;
   CLOSE cur_0520;

   BEGIN

      -- Call API
      CS_Charge_Create_Order_PUB.SUBMIT_ORDER(
        p_api_version          => l_API_VERSION
      , p_init_msg_list        => FND_API.G_TRUE
      , p_commit               => FND_API.G_FALSE                               --Don't Commit!!
      , p_validation_level     => FND_API.G_VALID_LEVEL_NONE
      , p_incident_id          => l_Incident_ID
      , p_party_id             => l_Customer_ID
      , p_account_id           => l_Account_ID
      , p_book_order_flag      => FND_API.G_TRUE                                -- Book the Order!
      , p_submit_source        => NULL
      , p_submit_from_system   => 'SR'
      , x_return_status        => l_API_Return_Status
      , x_msg_count            => l_API_Msg_Count
      , x_msg_data             => l_API_Msg_Data);

      l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If successful, was there a message sent back?
      IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
         COMMIT;
         l_Order_API_Error := 'N';
         l_Error_Message   := ('Order was created for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;

         -- Initialize l_Order_Header_ID, l_Order_Number
         l_Order_Header_ID := NULL;
         l_Order_Number    := NULL;

         -- Cursor to retrieve Order Number from Service Charge Details
         OPEN cur_0540;
         FETCH cur_0540 INTO l_Order_Header_ID, l_Order_Number;
         CLOSE cur_0540;

         l_Error_Message := ('Order Number: ' || l_Order_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);

      -- If unsuccessful, was there a message sent back?
      ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
         ROLLBACK;
         l_Order_API_Error := 'Y';
         l_Error_Message   := ('No Order was created for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         l_Error_Message := ('ROLLBACK performed');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
      END IF;

   -- Catch any Errors
   EXCEPTION WHEN OTHERS THEN
      l_Order_API_Error:= 'Y';
      l_Error_Message    := 'Exception occurred for API: CS_Charge_Create_Order_PUB.SUBMIT_ORDER for Service Request#: ' || p_Incident_ID;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

   END;

   -- Send back Output Error Parameter
   P_ORDER_SUBMIT_WITHOUT_CC := NVL(l_Order_API_Error, 'N');

   l_Error_Message := ('Exiting ORDER_SUBMIT_WITHOUT_CC for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END ORDER_SUBMIT_WITHOUT_CC;

--------------------------------------------------------------------------------
-- ORDER_SUBMIT_WITH_CC (NOT CURRENTLY ACTIVE)

PROCEDURE ORDER_SUBMIT_WITH_CC(p_Org_ID                    IN  NUMBER
                             , p_Incident_ID               IN  NUMBER
                             , p_Incident_Number           IN  VARCHAR2
                             , p_Inventory_Item_ID         IN  NUMBER
                             , p_Serial_Number             IN  VARCHAR2
                             , p_Incident_Date             IN  DATE
                             , p_Incident_Type             IN  VARCHAR2
                             , P_ORDER_SUBMIT_WITH_CC      OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
l_API_Version                     NUMBER                                        := 1.0;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_Order_API_Error                 XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number                 CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Account_ID                      CS_SR_Incidents_V.Account_ID%TYPE             := NULL;
l_Customer_ID                     CS_SR_Incidents_V.Customer_ID%TYPE            := NULL;
l_CC_CARD_NUMBER                  CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_1%TYPE   := NULL;
l_CC_CARD_EXP_DATE                CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_2%TYPE   := NULL;
l_CC_CARD_TYPE                    CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_3%TYPE   := NULL;
l_CC_CARD_SECURITY_CODE           CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_4%TYPE   := NULL;
l_CC_CARD_HOLDER_NAME             CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_5%TYPE   := NULL;
l_FSE_Responsibility_ID           fnd_responsibility.responsibility_ID%TYPE     := NULL;
l_FSE_Application_ID              fnd_responsibility.Application_ID%TYPE        := NULL;
l_CS_Org_ID                       CS_CHARGE_DETAILS_V.Org_ID%TYPE               := NULL;
l_Order_Number                    Oe_Order_headers_ALL.Order_Number%TYPE        := NULL;
l_Header_ID                       Oe_Order_headers_ALL.Header_ID%TYPE           := NULL;

-- Retrieve Responsibility_ID and Application_ID for the FSE Responsibility_Name
CURSOR cur_0560
IS
SELECT
    frtl.responsibility_ID
  , frx.application_ID
FROM
    fnd_responsibility            frx
  , fnd_responsibility_tl         frtl
WHERE
    frtl.responsibility_ID      = frx.responsibility_ID
AND frtl.language               = 'US'
AND frtl.responsibility_name    = g_FSE_Responsibility_Name
;
   
-- Cursor to retrieve Incident and Account Information
CURSOR cur_0580
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , csi.Account_ID
  , csi.Customer_ID
  , csi.EXTERNAL_ATTRIBUTE_1  -- CC Number
  , csi.EXTERNAL_ATTRIBUTE_2  -- CC Exp Date
  , csi.EXTERNAL_ATTRIBUTE_3  -- CC Type (i.e. Visa, MasterCard) 
  , csi.EXTERNAL_ATTRIBUTE_4  -- CC Security Code (SID)
  , csi.EXTERNAL_ATTRIBUTE_5  -- CC Name on Card
FROM
    CS_SR_Incidents_V       csi
WHERE
    csi.Org_ID            = p_Org_ID
AND csi.Incident_ID       = p_Incident_ID
;

-- Cursor to retrieve Order Number from Service Charge Details
CURSOR cur_0600
IS
SELECT DISTINCT
    csc.Org_ID
  , oeh.Order_Number
  , oeh.Header_ID
from
    CS_CHARGE_DETAILS_V     csc
  , Oe_Order_headers_ALL    oeh
where
    csc.Org_ID            = p_Org_ID
AND csc.Incident_ID       = p_Incident_ID
AND csc.order_header_ID   = oeh.header_ID
AND csc.Line_status       = 'SUBMITTED'
;

BEGIN

   l_Error_Message := ('Entering ORDER_SUBMIT_WITH_CC for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Order_API_Error, l_FSE_Responsibility_ID, l_FSE_Application_ID
   l_Order_API_Error       := NULL;
   l_FSE_Responsibility_ID := NULL;
   l_FSE_Application_ID    := NULL;

   -- Retrieve Responsibility_ID and Application_ID for the FSE Responsibility_Name
   OPEN cur_0560;
   FETCH cur_0560 INTO l_FSE_Responsibility_ID, l_FSE_Application_ID;
   CLOSE cur_0560;

   -- Set Context to FSE_Responsibility
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, l_FSE_Responsibility_ID, l_FSE_Application_ID);
   MO_GLOBAL.INIT('ONT');
   MO_GLOBAL.SET_POLICY_CONTEXT('S', p_Org_ID);

   -- Initialize l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID, l_CC_CARD_NUMBER, l_CC_CARD_EXP_DATE, 
   -- l_CC_CARD_TYPE, l_CC_CARD_SECURITY_CODE, l_CC_CARD_HOLDER_NAME
   l_Org_ID                := NULL;
   l_Incident_ID           := NULL;
   l_Incident_Number       := NULL;
   l_Account_ID            := NULL;
   l_Customer_ID           := NULL;
   l_CC_CARD_NUMBER        := NULL;
   l_CC_CARD_EXP_DATE      := NULL;
   l_CC_CARD_TYPE          := NULL;
   l_CC_CARD_SECURITY_CODE := NULL;
   l_CC_CARD_HOLDER_NAME   := NULL;

   -- Cursor to retrieve Incident and Account Information
   OPEN cur_0580;
   FETCH cur_0580 INTO l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID, l_CC_CARD_NUMBER, l_CC_CARD_EXP_DATE, l_CC_CARD_TYPE, l_CC_CARD_SECURITY_CODE, l_CC_CARD_HOLDER_NAME;
   CLOSE cur_0580;

   BEGIN

      -- Call API
      CS_Charge_Create_Order_PUB.SUBMIT_ORDER(
        p_api_version        => l_API_Version
      , p_init_msg_list      => FND_API.G_TRUE
      , p_commit             => FND_API.G_FALSE                                 -- Don't Commit!!
      , p_validation_level   => FND_API.G_VALID_LEVEL_NONE
      , p_incident_id        => l_Incident_ID
      , p_party_id           => l_Customer_ID
      , p_account_id         => l_Account_ID
      , p_book_order_flag    => NULL                                            -- Don't Book the Order!!
      , p_submit_source      => NULL
      , p_submit_from_system => 'SR'
      , x_return_status      => l_api_return_status
      , x_msg_count          => l_api_msg_count
      , x_msg_data           => l_api_msg_data);

      l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If successful, was there a message sent back?
      IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
         --COMMIT to be performed in ORDER_UPDATE_SET_TO_BOOKED
         l_Order_API_Error := 'N';
         l_Error_Message   := ('Order was created for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
         -- Initialize l_CS_Org_ID, l_Order_Number, l_Header_ID
         l_CS_Org_ID    := NULL;
         l_Order_Number := NULL;
         l_Header_ID    := NULL;
         -- Cursor to retrieve Order Number from Service Charge Details
         OPEN cur_0600;
         FETCH cur_0600 INTO l_CS_Org_ID, l_Order_Number, l_Header_ID;
         CLOSE cur_0600;
         l_Error_Message := ('Order Number: ' || l_Order_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         -- Update Order with CC
         ORDER_UPDATE_WITH_CC(p_Org_ID , p_Incident_ID, p_Incident_Number, p_Inventory_Item_ID, p_Serial_Number, p_Incident_Date, p_Incident_Type, l_Order_Number, l_Header_ID, l_Order_API_Error);

      -- If unsuccessful, was there a message sent back?
      ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
         ROLLBACK;
         l_Order_API_Error := 'Y';
         l_Error_Message   := ('No Order was created for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         l_Error_Message := ('ROLLBACK performed');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
      END IF;

   -- Catch any Errors
   EXCEPTION WHEN OTHERS THEN
      l_Order_API_Error := 'Y';
      l_Error_Message   := 'Exception occurred for API: CS_Charge_Create_Order_PUB.SUBMIT_ORDER for Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

   END;

   -- Send back Output Error Parameter
   P_ORDER_SUBMIT_WITH_CC := NVL(l_Order_API_Error, 'N');

   l_Error_Message := ('Exiting ORDER_SUBMIT_WITH_CC for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END ORDER_SUBMIT_WITH_CC;

--------------------------------------------------------------------------------
-- ORDER_UPDATE_WITH_CC (NOT CURRENTLY ACTIVE)

PROCEDURE ORDER_UPDATE_WITH_CC(p_Org_ID                    IN  NUMBER
                             , p_Incident_ID               IN  NUMBER
                             , p_Incident_Number           IN  VARCHAR2
                             , p_Inventory_Item_ID         IN  NUMBER
                             , p_Serial_Number             IN  VARCHAR2
                             , p_Incident_Date             IN  DATE
                             , p_Incident_Type             IN  VARCHAR2
                             , p_Order_Number              IN  VARCHAR2
                             , p_Header_ID                 IN  NUMBER
                             , P_ORDER_UPDATE_WITH_CC      OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
v_api_version_number              NUMBER                                        := 1.0;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_Order_API_Error                 XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;

-- CC Information
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number                 CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Account_ID                      CS_SR_Incidents_V.Account_ID%TYPE             := NULL;
l_Customer_ID                     CS_SR_Incidents_V.Customer_ID%TYPE            := NULL;
l_CC_CARD_NUMBER                  CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_1%TYPE   := NULL;
l_CC_CARD_EXP_DATE                CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_2%TYPE   := NULL;
l_CC_CARD_TYPE                    CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_3%TYPE   := NULL;
l_CC_CARD_SECURITY_CODE           CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_4%TYPE   := NULL;
l_CC_CARD_HOLDER_NAME             CS_SR_Incidents_V.EXTERNAL_ATTRIBUTE_5%TYPE   := NULL;

-- IN Variables --
v_header_rec                      oe_order_pub.header_rec_type;
v_line_tbl                        oe_order_pub.line_tbl_type;
v_action_request_tbl              oe_order_pub.request_tbl_type;
v_line_adj_tbl                    oe_order_pub.line_adj_tbl_type;
v_line_val_tbl                    OE_ORDER_PUB.Line_Val_Tbl_Type;
v_old_header_payment_rec          OE_ORDER_PUB.Header_Payment_Rec_Type;
v_old_header_payment_tbl          OE_ORDER_PUB.Header_Payment_Tbl_Type          := OE_ORDER_PUB.G_MISS_HEADER_PAYMENT_TBL;
v_header_payment_rec              OE_ORDER_PUB.Header_Payment_Rec_Type;
v_header_payment_tbl              OE_ORDER_PUB.Header_Payment_Tbl_Type          := OE_ORDER_PUB.G_MISS_HEADER_PAYMENT_TBL;
v_Line_Payment_Tbl_Type           OE_ORDER_PUB.Line_Payment_Tbl_Type;
v_Line_Payment_Val_Tbl_Type       OE_ORDER_PUB.Line_Payment_Val_Tbl_Type;
v_Header_Payment_val_rec          OE_ORDER_PUB.Header_Payment_Val_Rec_Type;
v_Header_Payment_val_tbl          OE_ORDER_PUB.Header_Payment_Val_Tbl_Type      := OE_ORDER_PUB.G_MISS_HEADER_PAYMENT_VAL_TBL;
v_Header_Payment_Val_Tbl_Type     OE_ORDER_PUB.Header_Payment_Val_Tbl_Type;

-- OUT Variables --
v_header_rec_out                  oe_order_pub.header_rec_type;
v_header_val_rec_out              oe_order_pub.header_val_rec_type;
v_header_adj_tbl_out              oe_order_pub.header_adj_tbl_type;
v_header_adj_val_tbl_out          oe_order_pub.header_adj_val_tbl_type;
v_header_price_att_tbl_out        oe_order_pub.header_price_att_tbl_type;
v_header_adj_att_tbl_out          oe_order_pub.header_adj_att_tbl_type;
v_header_adj_assoc_tbl_out        oe_order_pub.header_adj_assoc_tbl_type;
v_header_scredit_tbl_out          oe_order_pub.header_scredit_tbl_type;
v_header_scredit_val_tbl_out      oe_order_pub.header_scredit_val_tbl_type;
v_line_tbl_out                    oe_order_pub.line_tbl_type;
v_line_val_tbl_out                oe_order_pub.line_val_tbl_type;
v_line_adj_tbl_out                oe_order_pub.line_adj_tbl_type;
v_line_adj_val_tbl_out            oe_order_pub.line_adj_val_tbl_type;
v_line_price_att_tbl_out          oe_order_pub.line_price_att_tbl_type;
v_line_adj_att_tbl_out            oe_order_pub.line_adj_att_tbl_type;
v_line_adj_assoc_tbl_out          oe_order_pub.line_adj_assoc_tbl_type;
v_line_scredit_tbl_out            oe_order_pub.line_scredit_tbl_type;
v_line_scredit_val_tbl_out        oe_order_pub.line_scredit_val_tbl_type;
v_lot_serial_tbl_out              oe_order_pub.lot_serial_tbl_type;
v_lot_serial_val_tbl_out          oe_order_pub.lot_serial_val_tbl_type;
v_action_request_tbl_out          oe_order_pub.request_tbl_type;
v_header_payment_tbl_out          OE_ORDER_PUB.Header_Payment_Tbl_Type;
v_Header_Payment_Val_Tbl_TypeO    OE_ORDER_PUB.Header_Payment_Val_Tbl_Type;
v_Line_Payment_Tbl_Type_out       OE_ORDER_PUB.Line_Payment_Tbl_Type;
v_Line_Payment_Val_Tbl_TypeO      OE_ORDER_PUB.Line_Payment_Val_Tbl_Type;

-- Cursor to retrieve Incident and Account Information
CURSOR cur_0620
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , csi.Account_ID
  , csi.Customer_ID
  , csi.EXTERNAL_ATTRIBUTE_1  -- CC Number
  , csi.EXTERNAL_ATTRIBUTE_2  -- CC Exp Date
  , csi.EXTERNAL_ATTRIBUTE_3  -- CC Type (i.e. Visa, MasterCard) 
  , csi.EXTERNAL_ATTRIBUTE_4  -- CC Security Code (SID)
  , csi.EXTERNAL_ATTRIBUTE_5  -- CC Name on Card
FROM
    CS_SR_Incidents_V       csi
WHERE
    csi.Org_ID            = p_Org_ID
AND csi.Incident_ID       = p_Incident_ID
;

BEGIN

   l_Error_Message := ('Entering ORDER_UPDATE_WITH_CC for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Order_API_Error, l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID, l_CC_CARD_NUMBER, 
   -- l_CC_CARD_EXP_DATE, l_CC_CARD_TYPE, l_CC_CARD_SECURITY_CODE, l_CC_CARD_HOLDER_NAME
   l_Order_API_Error       := NULL;
   l_Org_ID                := NULL;
   l_Incident_ID           := NULL;
   l_Incident_Number       := NULL;
   l_Account_ID            := NULL;
   l_Customer_ID           := NULL;
   l_CC_CARD_NUMBER        := NULL;
   l_CC_CARD_EXP_DATE      := NULL;
   l_CC_CARD_TYPE          := NULL;
   l_CC_CARD_SECURITY_CODE := NULL;
   l_CC_CARD_HOLDER_NAME   := NULL;

   -- Cursor to retrieve Incident and Account Information
   OPEN cur_0620;
   FETCH cur_0620 INTO l_Org_ID, l_Incident_ID, l_Incident_Number, l_Account_ID, l_Customer_ID, l_CC_CARD_NUMBER, l_CC_CARD_EXP_DATE, l_CC_CARD_TYPE, l_CC_CARD_SECURITY_CODE, l_CC_CARD_HOLDER_NAME;
   CLOSE cur_0620;

   -- Header Record --
   v_header_rec                                     := oe_order_pub.g_miss_header_rec;
   v_header_rec.operation                           := OE_GLOBALS.G_OPR_UPDATE;
   v_header_rec.header_id                           := p_Header_ID;
   v_header_rec.cust_po_number                      := TO_CHAR(v_header_rec.header_id);
   v_header_rec.Org_ID                              := p_Org_ID;

   -- Action Request --
   v_action_request_tbl(1)                          := oe_order_pub.g_miss_request_rec;

   -- Line Record --
   v_line_tbl(1)                                    := oe_order_pub.g_miss_line_rec;

   -- Payment Val Record --
   v_Header_Payment_val_tbl(1)                      := OE_ORDER_PUB.G_MISS_HEADER_PAYMENT_VAL_REC;

   -- Old Order Payment --
   v_old_header_payment_rec                         := OE_ORDER_PUB.g_miss_header_payment_rec;
   v_old_header_payment_tbl(1)                      := v_old_header_payment_rec;

   -- Order Payment --
   v_header_payment_rec.header_id                   := p_Header_ID;
   v_header_payment_rec.payment_number              := 1;
   v_header_payment_rec.TRXN_EXTENSION_ID           := NULL;
   v_header_payment_rec.payment_type_Code           := 'CREDIT_CARD';

   v_header_payment_rec.Credit_card_number          := l_CC_CARD_NUMBER;
   v_header_payment_rec.credit_card_code            := l_CC_CARD_TYPE;
   v_header_payment_rec.credit_card_holder_name     := l_CC_CARD_HOLDER_NAME;
   v_header_payment_rec.credit_card_expiration_date := l_CC_CARD_EXP_DATE;      -- needs to be: TO_DATE('31-AUG-2022', 'dd-mon-yyyy');

   v_header_payment_rec.payment_level_code          := 'ORDER';
   v_header_payment_rec.operation                   := OE_GLOBALS.G_OPR_CREATE;
   v_header_payment_rec.payment_collection_event    := 'INVOICE';
   v_header_payment_rec.CC_INSTRUMENT_ID            := NULL;
   v_header_payment_rec.cc_instrument_assignment_id := NULL;
   v_header_payment_tbl(1)                          := v_header_payment_rec;

   BEGIN

      -- Call API to update the header details of an existing Order
      OE_ORDER_PUB.PROCESS_ORDER(
        p_Org_ID                      => p_Org_ID
      , p_api_version_number          => v_api_version_number
      , p_init_msg_list               => fnd_api.g_false
      , p_return_values               => fnd_api.g_false
      , p_action_commit               => fnd_api.g_false
      , p_header_rec                  => v_header_rec
      , p_line_tbl                    => v_line_tbl
      , p_action_request_tbl          => v_action_request_tbl
      , p_Header_Payment_tbl          => v_header_payment_tbl
      , p_old_Header_Payment_tbl      => v_old_header_payment_tbl
      -- OUT variables
      , x_header_rec                  => v_header_rec_out
      , x_header_val_rec              => v_header_val_rec_out
      , x_header_adj_tbl              => v_header_adj_tbl_out
      , x_header_adj_val_tbl          => v_header_adj_val_tbl_out
      , x_header_price_att_tbl        => v_header_price_att_tbl_out
      , x_header_adj_att_tbl          => v_header_adj_att_tbl_out
      , x_header_adj_assoc_tbl        => v_header_adj_assoc_tbl_out
      , x_header_scredit_tbl          => v_header_scredit_tbl_out
      , x_header_scredit_val_tbl      => v_header_scredit_val_tbl_out
      , x_Header_Payment_tbl          => v_header_payment_tbl_out
      , x_Header_Payment_val_tbl      => v_Header_Payment_Val_Tbl_TypeO
      , x_line_tbl                    => v_line_tbl_out
      , x_line_val_tbl                => v_line_val_tbl_out
      , x_line_adj_tbl                => v_line_adj_tbl_out
      , x_line_adj_val_tbl            => v_line_adj_val_tbl_out
      , x_line_price_att_tbl          => v_line_price_att_tbl_out
      , x_line_adj_att_tbl            => v_line_adj_att_tbl_out
      , x_line_adj_assoc_tbl          => v_line_adj_assoc_tbl_out
      , x_line_scredit_tbl            => v_line_scredit_tbl_out
      , x_line_scredit_val_tbl        => v_line_scredit_val_tbl_out
      , x_Line_Payment_tbl            => v_Line_Payment_Tbl_Type_out
      , x_Line_Payment_val_tbl        => v_Line_Payment_Val_Tbl_TypeO
      , x_lot_serial_tbl              => v_lot_serial_tbl_out
      , x_lot_serial_val_tbl          => v_lot_serial_val_tbl_out
      , x_action_request_tbl          => v_action_request_tbl_out
      , x_return_status               => l_api_return_status
      , x_msg_count                   => l_api_msg_count
      , x_msg_data                    => l_api_msg_data);

      l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If successful, was there a message sent back?
      IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
         --COMMIT to be performed in ORDER_UPDATE_SET_TO_BOOKED
         l_Order_API_Error := 'N';
         l_Error_Message   := ('Order was updated with CC Information: ' || p_Order_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
         -- Update Order to Booked
         ORDER_UPDATE_SET_TO_BOOKED(p_Org_ID , p_Incident_ID, p_Incident_Number, p_Inventory_Item_ID, p_Serial_Number, p_Incident_Date, p_Incident_Type, p_Order_Number, p_Header_ID, l_Order_API_Error);

      -- If unsuccessful, was there a message sent back?
      ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
         ROLLBACK;
         l_Order_API_Error := 'Y';
         l_Error_Message   := ('Order was not updated with CC Information: ' || p_Order_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         l_Error_Message := ('ROLLBACK performed');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
      END IF;

   -- Catch any Errors
   EXCEPTION WHEN OTHERS THEN
      l_Order_API_Error := 'Y';
      l_Error_Message   := 'Exception occurred for API: OE_ORDER_PUB.PROCESS_ORDER: ' || p_Order_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

   END;

   -- Send back Output Error Parameter
   P_ORDER_UPDATE_WITH_CC := NVL(l_Order_API_Error, 'N');

   l_Error_Message := ('Exiting ORDER_UPDATE_WITH_CC for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END ORDER_UPDATE_WITH_CC;

--------------------------------------------------------------------------------
-- ORDER_UPDATE_SET_TO_BOOKED (NOT CURRENTLY ACTIVE)

PROCEDURE ORDER_UPDATE_SET_TO_BOOKED(p_Org_ID                      IN  NUMBER
                                   , p_Incident_ID                 IN  NUMBER
                                   , p_Incident_Number             IN  VARCHAR2
                                   , p_Inventory_Item_ID           IN  NUMBER
                                   , p_Serial_Number               IN  VARCHAR2
                                   , p_Incident_Date               IN  DATE
                                   , p_Incident_Type               IN  VARCHAR2
                                   , p_Order_Number                IN  VARCHAR2
                                   , p_Header_ID                   IN  NUMBER
                                   , P_ORDER_UPDATE_SET_TO_BOOKED  OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
v_api_version_number              NUMBER                                        := 1.0;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_Order_API_Error                 XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;

-- IN Variables --
v_header_rec                      oe_order_pub.header_rec_type;
v_line_tbl                        oe_order_pub.line_tbl_type;
v_action_request_tbl              oe_order_pub.request_tbl_type;
v_line_adj_tbl                    oe_order_pub.line_adj_tbl_type;

-- OUT Variables --
v_header_rec_out                  oe_order_pub.header_rec_type;
v_header_val_rec_out              oe_order_pub.header_val_rec_type;
v_header_adj_tbl_out              oe_order_pub.header_adj_tbl_type;
v_header_adj_val_tbl_out          oe_order_pub.header_adj_val_tbl_type;
v_header_price_att_tbl_out        oe_order_pub.header_price_att_tbl_type;
v_header_adj_att_tbl_out          oe_order_pub.header_adj_att_tbl_type;
v_header_adj_assoc_tbl_out        oe_order_pub.header_adj_assoc_tbl_type;
v_header_scredit_tbl_out          oe_order_pub.header_scredit_tbl_type;
v_header_scredit_val_tbl_out      oe_order_pub.header_scredit_val_tbl_type;
v_line_tbl_out                    oe_order_pub.line_tbl_type;
v_line_val_tbl_out                oe_order_pub.line_val_tbl_type;
v_line_adj_tbl_out                oe_order_pub.line_adj_tbl_type;
v_line_adj_val_tbl_out            oe_order_pub.line_adj_val_tbl_type;
v_line_price_att_tbl_out          oe_order_pub.line_price_att_tbl_type;
v_line_adj_att_tbl_out            oe_order_pub.line_adj_att_tbl_type;
v_line_adj_assoc_tbl_out          oe_order_pub.line_adj_assoc_tbl_type;
v_line_scredit_tbl_out            oe_order_pub.line_scredit_tbl_type;
v_line_scredit_val_tbl_out        oe_order_pub.line_scredit_val_tbl_type;
v_lot_serial_tbl_out              oe_order_pub.lot_serial_tbl_type;
v_lot_serial_val_tbl_out          oe_order_pub.lot_serial_val_tbl_type;
v_action_request_tbl_out          oe_order_pub.request_tbl_type;

BEGIN

   l_Error_Message := ('Entering ORDER_UPDATE_SET_TO_BOOKED for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Order_API_Error
   l_Order_API_Error := NULL;

   -- Header Record --
   v_header_rec.header_id               := p_Header_ID; 
   v_header_rec.Org_ID                  := p_Org_ID;

   -- Action Request --
   v_action_request_tbl(1)              := oe_order_pub.g_miss_request_rec;
   v_action_request_tbl(1).request_type := OE_GLOBALS.G_BOOK_ORDER;
   v_action_request_tbl(1).entity_code  := OE_GLOBALS.G_ENTITY_HEADER;
   v_action_request_tbl(1).entity_id    := p_Header_ID;

   -- Line Record --
   v_line_tbl(1)                        := oe_order_pub.g_miss_line_rec;

   BEGIN

      -- Call API to update the header details of an existing Order
      OE_ORDER_PUB.PROCESS_ORDER(
        p_Org_ID                      => p_Org_ID
      , p_api_version_number          => v_api_version_number
      , p_init_msg_list               => fnd_api.g_false
      , p_return_values               => fnd_api.g_false
      , p_action_commit               => fnd_api.g_false
      , p_header_rec                  => v_header_rec
      , p_line_tbl                    => v_line_tbl
      , p_action_request_tbl          => v_action_request_tbl
      , p_line_adj_tbl                => v_line_adj_tbl
      -- OUT variables
      , x_header_rec                  => v_header_rec_out
      , x_header_val_rec              => v_header_val_rec_out
      , x_header_adj_tbl              => v_header_adj_tbl_out
      , x_header_adj_val_tbl          => v_header_adj_val_tbl_out
      , x_header_price_att_tbl        => v_header_price_att_tbl_out
      , x_header_adj_att_tbl          => v_header_adj_att_tbl_out
      , x_header_adj_assoc_tbl        => v_header_adj_assoc_tbl_out
      , x_header_scredit_tbl          => v_header_scredit_tbl_out
      , x_header_scredit_val_tbl      => v_header_scredit_val_tbl_out
      , x_line_tbl                    => v_line_tbl_out
      , x_line_val_tbl                => v_line_val_tbl_out
      , x_line_adj_tbl                => v_line_adj_tbl_out
      , x_line_adj_val_tbl            => v_line_adj_val_tbl_out
      , x_line_price_att_tbl          => v_line_price_att_tbl_out
      , x_line_adj_att_tbl            => v_line_adj_att_tbl_out
      , x_line_adj_assoc_tbl          => v_line_adj_assoc_tbl_out
      , x_line_scredit_tbl            => v_line_scredit_tbl_out
      , x_line_scredit_val_tbl        => v_line_scredit_val_tbl_out
      , x_lot_serial_tbl              => v_lot_serial_tbl_out
      , x_lot_serial_val_tbl          => v_lot_serial_val_tbl_out
      , x_action_request_tbl          => v_action_request_tbl_out
      , x_return_status               => l_api_return_status
      , x_msg_count                   => l_api_msg_count
      , x_msg_data                    => l_api_msg_data);

      l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If successful, was there a message sent back?
      IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
         COMMIT;
         l_Order_API_Error := 'N';
         l_Error_Message   := ('Order was updated to Booked: ' || p_Order_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;

      -- If unsuccessful, was there a message sent back?
      ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
         ROLLBACK;
         l_Order_API_Error := 'Y';
         l_Error_Message   := ('Order was not updated to Booked: ' || p_Order_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         l_Error_Message := ('ROLLBACK performed');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
      END IF;

   -- Catch any Errors
   EXCEPTION WHEN OTHERS THEN
      l_Order_API_Error := 'Y';
      l_Error_Message   := 'Exception occurred for API: OE_ORDER_PUB.PROCESS_ORDER for Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

   END;

   -- Send back Output Error Parameter
   P_ORDER_UPDATE_SET_TO_BOOKED := NVL(l_Order_API_Error, 'N');

   l_Error_Message := ('Exiting ORDER_UPDATE_SET_TO_BOOKED for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END ORDER_UPDATE_SET_TO_BOOKED;

--------------------------------------------------------------------------------
-- UPDATE_LOGISTIC_LINES_FOR_DR

PROCEDURE UPDATE_LOGISTIC_LINES_FOR_DR(p_Org_ID                         IN  NUMBER
                                     , p_Incident_ID                    IN  NUMBER
                                     , p_Incident_Number                IN  VARCHAR2
                                     , p_Close_Depot_Repair_Order       OUT VARCHAR2
                                     , p_UPDATE_LOGISTIC_LINES_FOR_DR   OUT VARCHAR2
) IS

l_success_status                  VARCHAR2(01)                                  := '0';
l_warning_status                  VARCHAR2(01)                                  := '1';
l_error_status                    VARCHAR2(01)                                  := '2';
l_Close_Repair_Order              VARCHAR2(01)                                  := NULL;
l_Close_Repair_Order_Task         VARCHAR2(01)                                  := NULL;
l_Close_Depot_Repair_Order        VARCHAR2(01)                                  := NULL;
l_errbuf                          VARCHAR2(2000)                                := NULL;
l_retcode                         VARCHAR2(2000)                                := NULL;

l_DR_API_Error                    XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
L_UPDATE_LOGISTIC_LINES_FOR_DR    XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;

-- Cursor to retrieve records where Status of the Repair Order Logistic Line does not match the Status of the associated Sales Order Line
CURSOR cur_0640
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , ptxn.REPAIR_NUMBER
  , ptxn.Action_Type
  , ptxn.Transaction_Status
  , ptxn.Prod_txn_status
  , ptxn.Repair_Line_ID
  , oeh.Order_Number
  , OEL.LINE_ID
  , OEL.FLOW_STATUS_CODE
FROM
    CS_SR_Incidents_V        csi 
  , csd_repairs_v            cr
  , CSD_PRODUCT_TXNS_V       ptxn
  , Oe_Order_headers_ALL     oeh
  , Oe_Order_Lines_ALL       oel
WHERE
    csi.Org_ID             = p_Org_ID
AND csi.Incident_ID        = p_Incident_ID
AND csi.Incident_ID        = cr.Incident_ID
AND cr.REPAIR_NUMBER       = ptxn.REPAIR_NUMBER
AND cr.repair_line_id      = ptxn.repair_line_id
AND ptxn.Order_Header_ID   = oeh.Header_ID
AND ptxn.Order_Line_ID     = OEL.LINE_ID
AND ((OEL.FLOW_STATUS_CODE IN ('SHIPPED', 'CANCELLED', 'CLOSED')
AND   ptxn.Action_Type     = 'SHIP'
AND   OEL.FLOW_STATUS_CODE <> ptxn.Prod_txn_status)
OR   (OEL.FLOW_STATUS_CODE IN ('RECEIVED', 'CANCELLED', 'CLOSED')
AND   ptxn.Action_Type     = 'RMA'
AND   OEL.FLOW_STATUS_CODE <> ptxn.Prod_txn_status))
;

-- Cursor to determine if all lines are 'SHIPPED/RECEIVED/CANCELLED' 
CURSOR cur_0660
IS
SELECT
    csi1.Org_ID
  , csi1.Incident_ID
  , csi1.Incident_Number
  , ptxn1.Action_Type
  , ptxn1.Transaction_Status
  , ptxn1.Prod_txn_status
  , cr1.REPAIR_NUMBER
  , cr1.repair_line_Id
FROM
    CS_SR_Incidents_V        csi1
  , CSD_Repairs_V            cr1
  , CSD_PRODUCT_TXNS_V       ptxn1
WHERE
    csi1.Org_ID            = p_Org_ID
AND csi1.Incident_ID       = p_Incident_ID
AND csi1.Incident_ID       = cr1.Incident_ID
AND cr1.REPAIR_NUMBER      = ptxn1.REPAIR_NUMBER
AND cr1.repair_line_id     = ptxn1.repair_line_id
;

-- Cursor to determine Task Status, Assignment Task Status and Debrief Status
CURSOR cur_0670
IS
SELECT
    csi2.Org_ID
  , csi2.incident_ID
  , cr2.REPAIR_NUMBER
  , jtv2.task_ID
  , jtv2.task_number
  , CDH2.DEBRIEF_NUMBER
  , CDH2.DEBRIEF_HEADER_ID
  , jrs2.User_ID
  , jts2.name                     "TASK_STATUS"
  , jts21.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh2.Processed_flag           "DEBRIEF_STATUS"
  , jtv2.Source_Object_Type_Code
  , jtv2.Object_Version_Number
FROM
    CS_SR_Incidents_V              csi2
  , csd_repairs_V                  cr2
  , jtf_tasks_vl                   jtv2
  , jtf_task_assignments           jta2
  , JTF_RS_RESOURCE_EXTNS          jrs2
  , JTF_TASK_STATUSES_VL           jts2
  , JTF_TASK_STATUSES_VL           jts21
  , csf_debrief_headers            cdh2
WHERE
    csi2.Org_ID                  = p_Org_ID
AND csi2.incident_ID             = p_Incident_ID
AND csi2.incident_ID             = cr2.incident_ID
AND cr2.repair_line_ID           = jtv2.source_object_ID
AND jtv2.Source_Object_Type_Code = 'DR'
AND jtv2.task_ID                 = jta2.task_ID
AND jtv2.Task_Status_ID          = jts2.Task_Status_ID
AND JTA2.ASSIGNMENT_STATUS_ID    = jts21.Task_Status_ID
AND jta2.resource_ID             = jrs2.resource_ID
AND jta2.Task_Assignment_ID      = cdh2.Task_Assignment_ID
;

BEGIN

   l_Error_Message := ('Entering UPDATE_LOGISTIC_LINES_FOR_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_DR_API_Error, L_UPDATE_LOGISTIC_LINES_FOR_DR, l_Close_Repair_Order, l_Close_Repair_Order_Task, l_Close_Depot_Repair_Order
   l_DR_API_Error                 := NULL;
   L_UPDATE_LOGISTIC_LINES_FOR_DR := NULL;
   l_Close_Repair_Order           := NULL;
   l_Close_Repair_Order_Task      := NULL;
   l_Close_Depot_Repair_Order     := NULL;

   -- Cursor to retrieve records where Status of the Repair Order Logistic Line does not match the Status of the associated Sales Order Line
   FOR dta160 IN cur_0640
   LOOP

      -- 'SHIP'
      IF dta160.Action_Type = 'SHIP' THEN

         BEGIN

            -- Call API
            CSD_UPDATE_PROGRAMS_PVT.SHIP_UPDATE_CONC_PROG(
              errbuf                 => l_errbuf
            , retcode                => l_retcode
            , p_order_type           => NULL
            , p_order_header_id      => NULL
            , p_repair_line_id       => dta160.Repair_Line_ID
            , p_past_num_of_days     => NULL);

            l_Error_Message := ('Return_Code: ' || (l_retcode || ', Error Buffer: ' || l_errbuf));
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

            -- If successful
            IF l_retcode = l_success_status THEN
               COMMIT;
               l_DR_API_Error  := 'N';
               l_Error_Message := ('CSD_UPDATE_PROGRAMS_PVT.SHIP_UPDATE_CONC_PROG - Success for Repair Number: ' || dta160.REPAIR_NUMBER);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               IF l_errbuf IS NOT NULL THEN
                  l_Error_Message := (l_errbuf);
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               END IF;

            -- If warning
            ELSIF l_retcode = l_warning_status THEN
               COMMIT;
               l_DR_API_Error  := 'N';
               l_Error_Message := ('CSD_UPDATE_PROGRAMS_PVT.SHIP_UPDATE_CONC_PROG - Warning for Repair Number: ' || dta160.REPAIR_NUMBER);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
               IF l_errbuf IS NOT NULL THEN
                  l_Error_Message := (l_errbuf);
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
               END IF;

            -- If error
            ELSIF l_retcode = l_error_status THEN
               ROLLBACK;
               l_DR_API_Error  := 'Y';
               l_Error_Message := ('CSD_UPDATE_PROGRAMS_PVT.SHIP_UPDATE_CONC_PROG - Failure for Repair Number: ' || dta160.REPAIR_NUMBER);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               l_Error_Message := ('ROLLBACK performed');
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               IF l_errbuf IS NOT NULL THEN
                  l_Error_Message := (l_errbuf);
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
            END IF;

         -- Catch any Errors
         EXCEPTION WHEN OTHERS THEN
            l_DR_API_Error  := 'Y';
            l_Error_Message := 'Exception occurred for API: CSD_UPDATE_PROGRAMS_PVT.SHIP_UPDATE_CONC_PROG for Repair Number: ' || dta160.REPAIR_NUMBER;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

         END;

      END IF;

      -- 'RMA'
      IF dta160.Action_Type = 'RMA' THEN

         BEGIN

            -- Call API
            CSD_UPDATE_PROGRAMS_PVT.RECEIPTS_UPDATE_CONC_PROG(
              errbuf                 => l_errbuf
            , retcode                => l_retcode
            , p_order_type           => NULL
            , p_order_header_id      => NULL
            , p_repair_line_id       => dta160.Repair_Line_ID
            , p_past_num_of_days     => NULL);

            l_Error_Message := ('Return_Code: ' || (l_retcode || ', Error Buffer: ' || l_errbuf));
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

            -- If successful
            IF l_retcode = l_success_status THEN
               COMMIT;
               l_DR_API_Error  := 'N';
               l_Error_Message := ('CSD_UPDATE_PROGRAMS_PVT.RECEIPTS_UPDATE_CONC_PROG - Success for Repair Number: ' || dta160.REPAIR_NUMBER);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               IF l_errbuf IS NOT NULL THEN
                  l_Error_Message    := (l_errbuf);
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               END IF;

            -- If warning
            ELSIF l_retcode = l_warning_status THEN
               COMMIT;
               l_DR_API_Error  := 'N';
               l_Error_Message := ('CSD_UPDATE_PROGRAMS_PVT.RECEIPTS_UPDATE_CONC_PROG - Warning for Repair Number: ' || dta160.REPAIR_NUMBER);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               IF l_errbuf IS NOT NULL THEN
                  l_Error_Message := (l_errbuf);
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;

            -- If error
            ELSIF l_retcode = l_error_status THEN
               ROLLBACK;
               l_DR_API_Error  := 'Y';
               l_Error_Message := ('CSD_UPDATE_PROGRAMS_PVT.RECEIPTS_UPDATE_CONC_PROG - Failure for Repair Number: ' || dta160.REPAIR_NUMBER);
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               l_Error_Message := ('ROLLBACK performed');
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               IF l_errbuf IS NOT NULL THEN
                  l_Error_Message := (l_errbuf);
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
            END IF;

         -- Catch any Errors
         EXCEPTION WHEN OTHERS THEN
            l_DR_API_Error  := 'Y';
            l_Error_Message := 'Exception occurred for API: CSD_UPDATE_PROGRAMS_PVT.RECEIPTS_UPDATE_CONC_PROG for Repair Number: ' || dta160.REPAIR_NUMBER;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

         END;

      END IF;

      -- If any errors, exit loop
      IF NVL(l_DR_API_Error, 'N') = 'Y' THEN
         EXIT;
      END IF;

   END LOOP;

   -- If no API Errors, then check if all lines are 'SHIPPED/RECEIVED/CANCELLED'
   IF NVL(l_DR_API_Error, 'N') = 'N' THEN
      -- Initialize l_Close_Repair_Order to 'Y'
      l_Close_Repair_Order := 'Y';
      FOR dta180 IN cur_0660
      LOOP
         IF UPPER(dta180.Transaction_Status) NOT IN ('SHIPPED', 'RECEIVED', 'CANCELLED') THEN
            l_Close_Repair_Order := 'N';
            l_Error_Message := 'Transaction Status: ' || dta180.Transaction_Status || ' for Repair Number: ' || dta180.REPAIR_NUMBER;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
            l_Error_Message := 'l_Close_Repair_Order: ' || l_Close_Repair_Order;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            EXIT;
         ELSE
            l_Error_Message := 'Transaction Status: ' || dta180.Transaction_Status || ' for Repair Number: ' || dta180.REPAIR_NUMBER;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            l_Error_Message := 'l_Close_Repair_Order: ' || l_Close_Repair_Order;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END IF;
      END LOOP;
   END IF;

   IF NVL(l_DR_API_Error, 'N') = 'N' THEN
      -- Initialize l_Close_Repair_Order_Task to 'Y'
      l_Close_Repair_Order_Task := 'Y';
      FOR dta190 IN cur_0670
      LOOP
         l_Error_Message := 'Task Status: ' || dta190.TASK_STATUS || ' for Repair Number: ' || dta190.REPAIR_NUMBER;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         l_Error_Message := 'Assignment Task Status: ' || dta190.ASSIGNMENT_TASK_STATUS || ' for Repair Number: ' || dta190.REPAIR_NUMBER;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         l_Error_Message := 'Debrief Status: ' || dta190.DEBRIEF_STATUS || ' for Repair Number: ' || dta190.REPAIR_NUMBER;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         IF (UPPER(dta190.DEBRIEF_STATUS) = 'COMPLETED') THEN
            IF (UPPER(dta190.TASK_STATUS) NOT IN ('CLOSED', 'CANCELLED')) THEN
               l_Close_Repair_Order_Task := 'N';
               l_Error_Message := 'l_Close_Repair_Order_Task: ' || l_Close_Repair_Order_Task || ' for Repair Number: ' || dta190.REPAIR_NUMBER;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
               l_Error_Message := 'Logistic lines not fulfilled, status is: ' || dta190.TASK_STATUS || ' for Repair Number: ' || dta190.REPAIR_NUMBER;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               EXIT;
            END IF;
         ELSE
            l_Close_Repair_Order_Task := 'N';
            l_Error_Message := 'Debrief Status is: ' || dta190.DEBRIEF_STATUS || ' for Repair Number: ' || dta190.REPAIR_NUMBER;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
            l_Error_Message := 'l_Close_Repair_Order_Task: ' || l_Close_Repair_Order_Task || ' for Repair Number: ' || dta190.REPAIR_NUMBER;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END IF;
      END LOOP;
   END IF;

   -- Set Flag (l_Close_Depot_Repair_Order) to Close Repair Order if all lines are 'SHIPPED/RECEIVED/CANCELLED' AND Tasks are 'CLOSED' or 'CANCELLED' and Debrief Status is 'COMPLETED' and no API Error
   IF (NVL(l_Close_Repair_Order, 'N') = 'Y') AND (NVL(l_Close_Repair_Order_Task, 'N') = 'Y') AND NVL(l_DR_API_Error, 'N') = 'N' THEN
      l_Close_Depot_Repair_Order := 'Y';
   ELSE
      l_Close_Depot_Repair_Order := 'N';
   END IF;

   -- Set Output Parameter p_Close_Depot_Repair_Order
   p_Close_Depot_Repair_Order := l_Close_Depot_Repair_Order;

   l_Error_Message := ('Close Depot Repair Order Parameter: ' || l_Close_Depot_Repair_Order);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Set Output Error Parameter to 'Y' if API Error (l_DR_API_Error) or
   -- Transaction_Status NOT IN ('SHIPPED', 'RECEIVED', 'CANCELLED')(l_Close_Repair_Order) or Tasks are NOT 'CLOSED' or 'CANCELLED'
   IF (NVL(l_DR_API_Error, 'N') = 'Y') OR (NVL(l_Close_Repair_Order, 'N') = 'N') OR (NVL(l_Close_Repair_Order_Task, 'N') = 'N')  THEN
      l_UPDATE_LOGISTIC_LINES_FOR_DR := 'Y';
   ELSE
      l_UPDATE_LOGISTIC_LINES_FOR_DR := 'N';
   END IF;

   -- Send back Output Error Parameter
   P_UPDATE_LOGISTIC_LINES_FOR_DR := L_UPDATE_LOGISTIC_LINES_FOR_DR;

   l_Error_Message := ('P_UPDATE_LOGISTIC_LINES_FOR_DR: ' || P_UPDATE_LOGISTIC_LINES_FOR_DR);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   l_Error_Message := ('Exiting UPDATE_LOGISTIC_LINES_FOR_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END UPDATE_LOGISTIC_LINES_FOR_DR;

--------------------------------------------------------------------------------
-- CLOSE_DEPOT_REPAIR_ORDERS

PROCEDURE CLOSE_DEPOT_REPAIR_ORDERS(p_Org_ID                     IN  NUMBER
                                  , p_Incident_ID                IN  NUMBER
                                  , p_Incident_Number            IN  VARCHAR2
                                  , P_CLOSE_DEPOT_REPAIR_ORDERS  OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
l_Object_Version_Number           NUMBER                                        := 0;
l_API_Version_Number              NUMBER                                        := 1.0;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;

l_REPAIR_STATUS_REC               CSD_REPAIRS_PUB.REPAIR_STATUS_REC_TYPE;
l_status_control_rec              CSD_REPAIRS_PUB.STATUS_UPD_CONTROL_REC_TYPE;

-- Cursor to retrieve Depot Repair Orders to Close
CURSOR cur_0680
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , cr.REPAIR_NUMBER
  , cr.repair_line_Id
  , cr.Status
  , cr.STATUS_MEANING
  , cr.FLOW_STATUS_CODE
  , cr.FLOW_STATUS
  , cr.Date_closed
  , cr.Object_Version_Number
FROM
    CS_SR_Incidents_V        csi 
  , csd_repairs_v            cr
WHERE
    csi.Org_ID             = p_Org_ID
AND csi.Incident_ID        = p_Incident_ID
AND csi.Incident_ID        = cr.Incident_ID
;

BEGIN

   l_Error_Message := ('Entering CLOSE_DEPOT_REPAIR_ORDERS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_API_Error
   l_API_Error := NULL;

   -- Reset Context back to Original Information
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, g_Current_Responsibility_ID, g_Current_Resp_Appl_ID);
   MO_GLOBAL.INIT('CSR');

   -- Cursor to retrieve Depot Repair Orders to Close
   FOR dta200 IN cur_0680
   LOOP

      l_Error_Message := ('STATUS_MEANING for Depot Repair Orders to Close - Service Request#: ' || p_Incident_Number || ', STATUS_MEANING: ' || dta200.STATUS_MEANING);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   
      -- Only process if STATUS_MEANING = 'OPEN' (Valid Values: Closed, Draft, Open)
      IF UPPER(dta200.STATUS_MEANING) = 'OPEN' THEN

      BEGIN

         l_REPAIR_STATUS_REC.repair_line_id        := dta200.repair_line_Id;
         l_REPAIR_STATUS_REC.repair_number         := dta200.repair_number;
         l_REPAIR_STATUS_REC.Object_Version_Number := dta200.Object_Version_Number;
         l_REPAIR_STATUS_REC.repair_status_id      := 1000;                     -- Set to Closed

         -- Call API
         CSD_REPAIRS_PUB.UPDATE_RO_STATUS(
           P_Api_Version            => 1.0
         , P_Commit                 => fnd_api.g_false
         , P_Init_Msg_List          => fnd_api.g_true
         , X_Return_Status          => l_api_return_status
         , X_Msg_Count              => l_api_msg_count
         , X_Msg_Data               => l_api_msg_data
         , P_REPAIR_STATUS_Rec      => l_REPAIR_STATUS_REC
         , P_STATUS_UPD_CONTROL_REC => l_status_control_rec
         , X_Object_Version_Number  => l_Object_Version_Number
         );

         l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
            COMMIT;
            l_API_Error     := 'N';
            l_Error_Message := ('Repair Order Closed for Service Request#: ' || p_Incident_Number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
            FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
            LOOP
               FND_MSG_PUB.GET(
                 P_MSG_INDEX      => L_INDEX
               , P_ENCODED        => 'F'
               , P_DATA           => l_Error_Message
               , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
               IF l_Error_Message IS NULL THEN
                  EXIT;
               END IF;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            END LOOP;
         ELSIF l_api_return_status = Fnd_Api.G_RET_STS_UNEXP_ERROR THEN
            ROLLBACK;
            l_API_Error     := 'Y';
            l_Error_Message := ('Repair Order NOT Closed for Service Request#: ' || p_Incident_Number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
            l_Error_Message := ('ROLLBACK performed');
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
            LOOP
               FND_MSG_PUB.GET(
                 P_MSG_INDEX      => L_INDEX
               , P_ENCODED        => 'F'
               , P_DATA           => l_Error_Message
               , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
               IF l_Error_Message IS NULL THEN
                  EXIT;
               END IF;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            END LOOP;
         ELSE
            ROLLBACK;
            l_API_Error     := 'Y';
            l_Error_Message := ('Repair Order NOT Closed for Service Request#: ' || p_Incident_Number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
            l_Error_Message := ('ROLLBACK performed');
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
            LOOP
               FND_MSG_PUB.GET(
                 P_MSG_INDEX      => L_INDEX
               , P_ENCODED        => 'F'
               , P_DATA           => l_Error_Message
               , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
               IF l_Error_Message IS NULL THEN
                   EXIT;
               END IF;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
            END LOOP;
         END IF;

         -- Catch any Errors
         EXCEPTION WHEN OTHERS THEN
            l_API_Error     := 'Y';
            l_Error_Message := 'Exception occurred for CSD_REPAIRS_PUB.UPDATE_DR_STATUS for Service Request#: ' || p_Incident_Number;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

      END;
      
      END IF;

   END LOOP;

   -- Send back Output Error Parameter
   P_CLOSE_DEPOT_REPAIR_ORDERS := NVL(l_API_Error, 'N');

   l_Error_Message := ('Exiting CLOSE_DEPOT_REPAIR_ORDERS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END CLOSE_DEPOT_REPAIR_ORDERS;

--------------------------------------------------------------------------------
-- EDITS_POST_PROCESS 

PROCEDURE EDITS_POST_PROCESS(p_Org_ID                      IN  NUMBER
                           , p_Incident_ID                 IN  NUMBER
                           , p_Incident_Number             IN  VARCHAR2
                           , p_Incident_Type               IN  VARCHAR2
                           , P_EDITS_POST_PROCESS          OUT VARCHAR2
) IS

l_Error_POST_SR_WITH_DR           XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_POST_SR_WITHOUT_DR        XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_EDITS_POST_PROCESS              XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;

BEGIN

   l_Error_Message := ('Entering EDITS_POST_PROCESS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_EDITS_POST_PROCESS to 'N'
   l_EDITS_POST_PROCESS := 'N';

   IF p_Incident_Type IN ('Depot Repair', 'HMS-Depot Repair', 'Customer Service Request') THEN
      EDITS_POST_SR_WITH_DR(p_Org_ID, p_Incident_ID, p_Incident_Number, l_Error_POST_SR_WITH_DR);
   ELSE
      EDITS_POST_SR_WITHOUT_DR(p_Org_ID, p_Incident_ID, p_Incident_Number, l_Error_POST_SR_WITHOUT_DR);
   END IF;

   -- Set Output Parameter
   IF (NVL(l_Error_POST_SR_WITH_DR, 'N') = 'Y') OR (NVL(l_Error_POST_SR_WITHOUT_DR, 'N') = 'Y') THEN
      l_EDITS_POST_PROCESS := 'Y';
   END IF;

   -- Send back Output Error Parameter
   P_EDITS_POST_PROCESS := l_EDITS_POST_PROCESS;

   l_Error_Message := ('Exiting EDITS_POST_PROCESS for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END EDITS_POST_PROCESS;

--------------------------------------------------------------------------------
-- EDITS_POST_SR_WITH_DR

PROCEDURE EDITS_POST_SR_WITH_DR(p_Org_ID                   IN  NUMBER
                              , p_Incident_ID              IN  NUMBER
                              , p_Incident_Number          IN  VARCHAR2
                              , p_EDITS_POST_SR_WITH_DR    OUT VARCHAR2
) IS

l_Count_Open                      NUMBER                                        := 0;
l_Count_All                       NUMBER                                        := 0;
l_Count                           NUMBER                                        := 0;
l_DR_Exists                       VARCHAR2(01)                                  := NULL;
l_Debrief_Exsits_For_SR           VARCHAR2(01)                                  := NULL;
l_Debrief_Exsits_For_DR           VARCHAR2(01)                                  := NULL;
l_DR_DFF_TAI_Error                VARCHAR2(01)                                  := NULL;
l_DR_DFF_TAAI_Error               VARCHAR2(01)                                  := NULL;
l_SR_DFF_TAI_Error                VARCHAR2(01)                                  := NULL;
l_SR_DFF_TAAI_Error               VARCHAR2(01)                                  := NULL;
l_SR_Has_Tasks                    VARCHAR2(01)                                  := NULL;
l_DR_Has_Tasks                    VARCHAR2(01)                                  := NULL;
l_Resolution_Descr_Optional       VARCHAR2(01)                                  := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_source_object_ID                cs_sr_tasks_v.source_object_ID%TYPE           := NULL;
l_Interface_To_OE_Flag            CS_CHARGE_DETAILS_V.INTERFACE_TO_OE_FLAG%TYPE := NULL;
l_Error_Debrief_SR                XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Debrief_DR                XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Problem_Codes_Pop         XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_PIR_REVIEW                XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_PIR_REVIEW_ASSOC          XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Problem_Codes_Entry       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Tasks                  XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Tasks_Status           XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_DR_Tasks_Status           XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Unsubmitted            XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Resolution_Note_Type      XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Incident_ID                     csd_repairs_v.Incident_ID%TYPE                := NULL;
l_Incident_Number                 csd_repairs_v.Incident_Number%TYPE            := NULL;
l_Repair_Number                   csd_repairs_v.Repair_Number%TYPE              := NULL;
l_Debrief_Number                  csf_debrief_headers.Debrief_Number%TYPE       := NULL;
l_CONTEXT_VALUE                   jtf_tasks_b.Attribute_Category%TYPE           := NULL;

l_Task_Status_SR                  JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Assignment_Task_Status_SR       JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Debrief_Status_SR               csf_debrief_headers.Processed_flag%TYPE       := NULL;
l_Task_Status_DR                  JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Assignment_Task_Status_DR       JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Debrief_Status_DR               csf_debrief_headers.Processed_flag%TYPE       := NULL;

l_IncProbCode1                    CS_SR_Incidents_V.incident_attribute_1%TYPE   := NULL;
l_IncProbCode2                    CS_SR_Incidents_V.incident_attribute_7%TYPE   := NULL;
l_IncProbCode3                    CS_SR_Incidents_V.incident_attribute_8%TYPE   := NULL;
l_IncProbCode4                    CS_SR_Incidents_V.incident_attribute_9%TYPE   := NULL;
l_IncProbCode5                    CS_SR_Incidents_V.incident_attribute_10%TYPE  := NULL;
l_IncResCode1                     CS_SR_Incidents_V.incident_attribute_11%TYPE  := NULL;
l_IncResCode2                     CS_SR_Incidents_V.incident_attribute_12%TYPE  := NULL;
l_IncResCode3                     CS_SR_Incidents_V.incident_attribute_13%TYPE  := NULL;
l_IncResCode4                     CS_SR_Incidents_V.incident_attribute_14%TYPE  := NULL;
l_IncResCode5                     CS_SR_Incidents_V.incident_attribute_15%TYPE  := NULL;
l_PROCESS_PHASE                   CS_SR_Incidents_V.incident_attribute_2%TYPE   := NULL;
l_DEATH                           CS_SR_Incidents_V.incident_attribute_3%TYPE   := NULL;
l_POTENTIAL_INJURY                CS_SR_Incidents_V.incident_attribute_4%TYPE   := NULL;
l_HIGH_RISK_COMPLAINT             CS_SR_Incidents_V.incident_attribute_5%TYPE   := NULL;
l_HOSPITALIZATION                 CS_SR_Incidents_V.incident_attribute_6%TYPE   := NULL;
l_PIR_REVIEW                      CS_SR_Incidents_V.incident_context%TYPE       := NULL;
l_Incident_ID_SR                  CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number_SR              CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Inventory_Item_ID               CS_SR_Incidents_V.Inventory_Item_ID%TYPE      := NULL;
l_Incident_Type_ID                CS_SR_Incidents_V.Incident_Type_ID%TYPE       := NULL;
l_Problem_Code                    CS_SR_Incidents_V.Problem_Code%TYPE           := NULL;
l_Resolution_Code                 CS_SR_Incidents_V.Resolution_Code%TYPE        := NULL;
l_PIR_TEXT                        VARCHAR2(500)                                 := NULL;

-- Cursor for Debrief (Service Request)
CURSOR cur_0700
IS
SELECT
    csi.incident_number
  , CDH.DEBRIEF_NUMBER
  , jts1.name                    "TASK_STATUS"
  , jts1.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh.Processed_flag           "DEBRIEF_STATUS"
FROM
    CS_SR_Incidents_V             csi 
  , jtf_tasks_vl                  jtv
  , jtf_task_assignments          jta
  , JTF_RS_RESOURCE_EXTNS         jrs
  , JTF_TASK_STATUSES_VL          jts
  , JTF_TASK_STATUSES_VL          jts1
  , csf_debrief_headers           cdh
WHERE
    csi.Org_ID                  = p_Org_ID
AND csi.incident_ID             = p_Incident_ID
AND csi.incident_ID             = jtv.source_object_ID
AND jtv.Source_Object_Type_Code = 'SR'
AND jtv.task_ID                 = jta.task_ID
AND jtv.Task_Status_ID          = jts.Task_Status_ID
AND JTA.ASSIGNMENT_STATUS_ID    = jts1.Task_Status_ID
AND jta.resource_ID             = jrs.resource_ID
AND jta.Task_Assignment_ID      = cdh.Task_Assignment_ID
;

-- Cursor for Debrief (Repair Order)
CURSOR cur_0720
IS
SELECT
    csi1.incident_number
  , CDH1.DEBRIEF_NUMBER
  , cr1.repair_number
  , jts1.name                     "TASK_STATUS"
  , jts11.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh1.Processed_flag           "DEBRIEF_STATUS"
FROM
    CS_SR_Incidents_V              csi1
  , csd_repairs_V                  cr1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , JTF_TASK_STATUSES_VL           jts11
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = cr1.incident_ID
AND cr1.repair_line_ID           = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'DR'
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND JTA1.ASSIGNMENT_STATUS_ID    = jts11.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID
;

-- Service Repair Readings/Observations
CURSOR cur_0740
IS
SELECT
    csi2.incident_attribute_1    "IncProbCode1"
  , csi2.incident_attribute_7    "IncProbCode2"
  , csi2.incident_attribute_8    "IncProbCode3"
  , csi2.incident_attribute_9    "IncProbCode4"
  , csi2.incident_attribute_10   "IncProbCode5"
  , csi2.incident_attribute_11   "IncResCode1"
  , csi2.incident_attribute_12   "IncResCode2"
  , csi2.incident_attribute_13   "IncResCode3"
  , csi2.incident_attribute_14   "IncResCode4"
  , csi2.incident_attribute_15   "IncResCode5"
  , csi2.incident_context        "PIR_REVIEW"
  , csi2.incident_attribute_2    "PROCESS_PHASE"
  , csi2.incident_attribute_3    "DEATH"
  , csi2.incident_attribute_4    "POTENTIAL_INJURY"
  , csi2.incident_attribute_5    "HIGH_RISK_COMPLAINT"
  , csi2.incident_attribute_6    "HOSPITALIZATION"
  , csi2.Incident_ID
  , csi2.Incident_Number
  , csi2.Inventory_Item_ID
  , csi2.Incident_Type_ID
  , csi2.Problem_Code
  , csi2.Resolution_Code
FROM
    CS_SR_Incidents_V             csi2
WHERE
    csi2.Org_ID                 = p_Org_ID
AND csi2.incident_ID            = p_Incident_ID
;

-- Cursor to check CONTEXT_VALUE for Repair Order Task additional information
CURSOR cur_0760
IS
SELECT
    cr3.Incident_ID
  , cr3.Incident_Number
  , cr3.Attribute_Category  "CONTEXT_VALUE"
FROM
    CS_SR_Incidents_V        csi3
  , csd_repairs_V            cr3
WHERE
    csi3.Org_ID            = p_Org_ID
AND csi3.incident_ID       = p_Incident_ID
AND csi3.incident_ID       = cr3.incident_ID
;

-- Repair Order (Depot Repair) Readings/Observations
CURSOR cur_0800
IS
SELECT
    cr4.Incident_ID
  , cr4.Incident_Number
  , cr4.Repair_Number
  , cr4.Attribute_Category "CONTEXT_VALUE"
  , cr4.Attribute1
  , cr4.Attribute2
  , cr4.Attribute3
  , cr4.Attribute4
  , cr4.Attribute5
  , cr4.Attribute6
  , cr4.Attribute7
  , cr4.Attribute8
  , cr4.Attribute9
  , cr4.Attribute10
  , cr4.Attribute11
  , cr4.Attribute12
  , cr4.Attribute13
  , cr4.Attribute14
  , cr4.Attribute15
  , cr4.Attribute16
  , cr4.Attribute17
  , cr4.Attribute18
  , cr4.Attribute19
  , cr4.Attribute20
  , cr4.Attribute21
  , cr4.Attribute22
  , cr4.Attribute23
  , cr4.Attribute24
  , cr4.Attribute25
  , cr4.Attribute26
  , cr4.Attribute27
  , cr4.Attribute28
  , cr4.Attribute29
  , cr4.Attribute30
FROM
    CS_SR_Incidents_V       csi4
  , csd_repairs_V           cr4
WHERE
    csi4.Org_ID           = p_Org_ID
AND csi4.incident_ID      = p_Incident_ID
AND csi4.incident_ID      = cr4.incident_ID
;

-- Retrieve DFF's for Context Value (from cur_0800)
CURSOR cur_0820 (p_Context_Value csd_repairs_V.Attribute_Category%TYPE)
IS
SELECT
    fav1.application_name                  "APPLICATION"
  , fdfv1.title                            "TITLE"
  , fdfv1.context_required_flag            "ENTRY_REQUIRED"
  , fdfv1.context_user_override_flag       "DISPLAYED"
  , fdfcv1.enabled_flag                    "ENABLED"
  , fdfcv1.descriptive_flex_context_code   "CONTEXT_CODE"
  , fdfcuv1.column_seq_num                 "SQE_NUMBER"
  , fdfcuv1.end_user_column_name           "USER_COLUMN_NAME"
  , fdfcuv1.application_column_name        "COLUMN_NAME"
  , fdfcuv1.description                    "COLUMN_DESCRIPTION"
FROM
    fnd_descriptive_flexs_vl                fdfv1
  , fnd_descr_flex_contexts_vl              fdfcv1
  , fnd_descr_flex_col_usage_vl             fdfcuv1
  , fnd_application_vl                      fav1
  , fnd_flex_value_sets                     ffvsv1
  , fnd_flex_value_sets                     ffvsv11
WHERE
    fdfv1.title                           IN ('Repair Orders')
AND fdfcv1.descriptive_flexfield_name     = fdfv1.descriptive_flexfield_name
AND fdfcv1.descriptive_flex_context_code  = p_Context_Value
AND fdfcuv1.descriptive_flexfield_name    = fdfcv1.descriptive_flexfield_name
AND fdfcuv1.descriptive_flex_context_code = fdfcv1.descriptive_flex_context_code
AND fav1.application_id                   = fdfv1.application_id
AND ffvsv1.flex_value_set_id(+)           = fdfv1.context_override_value_set_id
AND ffvsv11.flex_value_set_id(+)          = fdfcuv1.flex_value_set_id
-- 17-MAY-2017 - New code to check additional flags
AND fdfv1.context_required_flag           = 'Y'
AND fdfv1.context_user_override_flag      = 'Y'
AND fdfcv1.enabled_flag                   = 'Y'
AND fdfcuv1.display_flag                  = 'Y'
AND fdfcuv1.enabled_flag                  = 'Y'

ORDER BY 
    fdfv1.title
  , fdfcv1.descriptive_flex_context_code
  , fdfcuv1.column_seq_num
;

-- Cursor to determine if tasks exist for Repair Order
CURSOR cur_0830
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v             cr41
  , CSD_Tasks                 ct41
  , csf_debrief_tasks_v       csf41
WHERE
    cr41.SR_Org_ID          = p_Org_ID
AND cr41.Incident_ID        = p_Incident_ID
AND cr41.Repair_Line_ID     = CT41.Repair_Line_ID
AND cr41.Incident_ID        = csf41.Incident_ID
AND CSF41.SOURCE_TYPE_CODE  = 'DR'
;

-- Cursor to retrieve Status of tasks for Repair Ordert and
-- CONTEXT_VALUE for Repair Order Task additional information
CURSOR cur_0833
IS
SELECT
    jts1.name                     "TASK_STATUS"
  , jtv1.Task_ID
  , jtv1.Task_Number
  , jtv1.Object_Version_Number
  , jta1.Attribute_Category       "CONTEXT_VALUE"
FROM
    CS_SR_Incidents_V              csi1
  , csd_repairs_V                  cr1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = cr1.incident_ID
AND cr1.repair_line_ID           = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'DR'
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID
;

-- Repair Order (Depot Repair) Readings/Observations
CURSOR cur_0880
IS
SELECT
    csi6.Incident_ID
  , csi6.Incident_Number
  , cr6.Repair_Number
  , jta6.Attribute_Category       "CONTEXT_VALUE"
  , jta6.attribute1
  , jta6.attribute2
  , jta6.attribute3
  , jta6.attribute4
  , jta6.attribute5
  , jta6.attribute6
  , jta6.attribute7
  , jta6.attribute8
  , jta6.attribute9
  , jta6.attribute10
  , jta6.attribute11
  , jta6.attribute12
  , jta6.attribute13
  , jta6.attribute14
  , jta6.attribute15
FROM
    CS_SR_Incidents_V              csi6
  , csd_repairs_V                  cr6
  , jtf_tasks_b                    jtb6
  , jtf_task_assignments           jta6
WHERE
    csi6.Org_ID                  = p_Org_ID
AND csi6.incident_ID             = p_Incident_ID
AND csi6.incident_id             = cr6.incident_id
AND cr6.repair_line_id           = jtb6.source_object_id
AND jtb6.Source_Object_Type_Code = 'DR'
AND jtb6.task_id                 = jta6.task_id
;

-- Retrieve DFF's for Context Value (from cur_0880)
CURSOR cur_0900 (p_Context_Value csd_repairs_V.Attribute_Category%TYPE)
IS
SELECT
    fav3.application_name                  "APPLICATION"
  , fdfv3.title                            "TITLE"
  , fdfv3.context_required_flag            "ENTRY_REQUIRED"
  , fdfv3.context_user_override_flag       "DISPLAYED"
  , fdfcv3.enabled_flag                    "ENABLED"
  , fdfcv3.descriptive_flex_context_code   "CONTEXT_CODE"
  , fdfcuv3.column_seq_num                 "SQE_NUMBER"
  , fdfcuv3.end_user_column_name           "USER_COLUMN_NAME"
  , fdfcuv3.application_column_name        "COLUMN_NAME"
  , fdfcuv3.description                    "COLUMN_DESCRIPTION"
FROM
    fnd_descriptive_flexs_vl                fdfv3
  , fnd_descr_flex_contexts_vl              fdfcv3
  , fnd_descr_flex_col_usage_vl             fdfcuv3
  , fnd_application_vl                      fav3
  , fnd_flex_value_sets                     ffvsv3
  , fnd_flex_value_sets                     ffvsv13
WHERE
    fdfv3.title                           IN ('Task assignments additional information')
AND fdfcv3.descriptive_flexfield_name     = fdfv3.descriptive_flexfield_name
AND fdfcv3.descriptive_flex_context_code  = p_Context_Value
AND fdfcuv3.descriptive_flexfield_name    = fdfcv3.descriptive_flexfield_name
AND fdfcuv3.descriptive_flex_context_code = fdfcv3.descriptive_flex_context_code
AND fav3.application_id                   = fdfv3.application_id
AND ffvsv3.flex_value_set_id(+)           = fdfv3.context_override_value_set_id
AND ffvsv13.flex_value_set_id(+)          = fdfcuv3.flex_value_set_id
-- 17-MAY-2017 - New code to check additional flags
AND fdfv3.context_required_flag           = 'Y'
AND fdfv3.context_user_override_flag      = 'Y'
AND fdfcv3.enabled_flag                   = 'Y'
AND fdfcuv3.display_flag                  = 'Y'
AND fdfcuv3.enabled_flag                  = 'Y'
ORDER BY 
    fdfv3.title
  , fdfcv3.descriptive_flex_context_code
  , fdfcuv3.column_seq_num
;

-- Cursor to determine if tasks exist for Service Request 
CURSOR cur_0920
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V        csi7
  , cs_sr_tasks_v            cst7
  , csf_debrief_tasks_v      csf7
WHERE
    csi7.Org_ID            = p_Org_ID
AND csi7.Incident_ID       = p_Incident_ID
AND csi7.Incident_ID       = cst7.source_object_ID
AND csi7.Incident_ID       = csf7.Incident_ID
AND CSF7.SOURCE_TYPE_CODE  = 'SR'
;

-- Cursor to retrieve Status of tasks for Service Request 
CURSOR cur_0940
IS
SELECT
    jts8.name                     "TASK_STATUS"
  , jtv8.Task_ID
  , jtv8.Task_Number
  , jtv8.Object_Version_Number
  , cst8.Attribute_Category       "CONTEXT_VALUE"
FROM
    CS_SR_Incidents_V              csi8
  , jtf_tasks_vl                   jtv8
  , jtf_task_assignments           jta8
  , JTF_RS_RESOURCE_EXTNS          jrs8
  , JTF_TASK_STATUSES_VL           jts8
  , csf_debrief_headers            cdh8
  , cs_sr_tasks_v                  cst8
WHERE
    csi8.Org_ID                  = p_Org_ID
AND csi8.incident_ID             = p_Incident_ID
AND csi8.incident_ID             = jtv8.source_object_ID
AND jtv8.Source_Object_Type_Code = 'SR'
AND jtv8.task_ID                 = jta8.task_ID
AND jtv8.Task_Status_ID          = jts8.Task_Status_ID
AND jta8.resource_ID             = jrs8.resource_ID
AND jta8.Task_Assignment_ID      = cdh8.Task_Assignment_ID
AND csi8.Incident_ID             = cst8.source_object_ID
;

-- Cursor to retrieve Service Request Readings/Observations (Tasks additional information)
CURSOR cur_1000
IS
SELECT
    csi10.Incident_ID
  , csi10.Incident_Number
  , cst10.task_ID
  , cst10.task_number
  , cst10.Attribute_Category "CONTEXT_VALUE"
  , cst10.Attribute1
  , cst10.Attribute2
  , cst10.Attribute3
  , cst10.Attribute4
  , cst10.Attribute5
  , cst10.Attribute6
  , cst10.Attribute7
  , cst10.Attribute8
  , cst10.Attribute9
  , cst10.Attribute10
  , cst10.Attribute11
  , cst10.Attribute12
  , cst10.Attribute13
  , cst10.Attribute14
  , cst10.Attribute15
FROM
    CS_SR_Incidents_V         csi10
  , cs_sr_tasks_v             cst10
WHERE
    csi10.Org_ID            = p_Org_ID
AND csi10.Incident_ID       = p_Incident_ID
AND csi10.Incident_ID       = cst10.source_object_ID
;

-- Retrieve DFF's for Context Value (from cur_1000)
CURSOR cur_1020 (p_Context_Value csd_repairs_V.Attribute_Category%TYPE)
IS
SELECT
    fav5.application_name                  "APPLICATION"
  , fdfv5.title                            "TITLE"
  , fdfv5.context_required_flag            "ENTRY_REQUIRED"
  , fdfv5.context_user_override_flag       "DISPLAYED"
  , fdfcv5.enabled_flag                    "ENABLED"
  , fdfcv5.descriptive_flex_context_code   "CONTEXT_CODE"
  , fdfcuv5.column_seq_num                 "SQE_NUMBER"
  , fdfcuv5.end_user_column_name           "USER_COLUMN_NAME"
  , fdfcuv5.application_column_name        "COLUMN_NAME"
  , fdfcuv5.description                    "COLUMN_DESCRIPTION"
FROM
    fnd_descriptive_flexs_vl                fdfv5
  , fnd_descr_flex_contexts_vl              fdfcv5
  , fnd_descr_flex_col_usage_vl             fdfcuv5
  , fnd_application_vl                      fav5
  , fnd_flex_value_sets                     ffvsv5
  , fnd_flex_value_sets                     ffvsv15
WHERE
    fdfv5.title                           IN ('Tasks additional information')
AND fdfcv5.descriptive_flexfield_name     = fdfv5.descriptive_flexfield_name
AND fdfcv5.descriptive_flex_context_code  = p_Context_Value
AND fdfcuv5.descriptive_flexfield_name    = fdfcv5.descriptive_flexfield_name
AND fdfcuv5.descriptive_flex_context_code = fdfcv5.descriptive_flex_context_code
AND fav5.application_id                   = fdfv5.application_id
AND ffvsv5.flex_value_set_id(+)           = fdfv5.context_override_value_set_id
AND ffvsv15.flex_value_set_id(+)          = fdfcuv5.flex_value_set_id
-- 17-MAY-2017 - New code to check additional flags
AND fdfv5.context_required_flag           = 'Y'
AND fdfv5.context_user_override_flag      = 'Y'
AND fdfcv5.enabled_flag                   = 'Y'
AND fdfcuv5.display_flag                  = 'Y'
AND fdfcuv5.enabled_flag                  = 'Y'
ORDER BY 
    fdfv5.title
  , fdfcv5.descriptive_flex_context_code
  , fdfcuv5.column_seq_num
;

-- Cursor to retrieve Status of tasks for Service Request and
-- CONTEXT_VALUE for Service Request Task additional information
CURSOR cur_1040
IS
SELECT
    jts6.name                     "TASK_STATUS"
  , jtv6.Task_ID
  , jtv6.Task_Number
  , jtv6.Object_Version_Number
  , cst6.Attribute_Category       "CONTEXT_VALUE"
FROM
    CS_SR_Incidents_V              csi6
  , jtf_tasks_vl                   jtv6
  , jtf_task_assignments           jta6
  , JTF_RS_RESOURCE_EXTNS          jrs6
  , JTF_TASK_STATUSES_VL           jts6
  , csf_debrief_headers            cdh6
  , cs_sr_tasks_v                  cst6
WHERE
    csi6.Org_ID                  = p_Org_ID
AND csi6.incident_ID             = p_Incident_ID
AND csi6.incident_ID             = jtv6.source_object_ID
AND jtv6.Source_Object_Type_Code = 'SR'
AND jtv6.task_ID                 = jta6.task_ID
AND jtv6.Task_Status_ID          = jts6.Task_Status_ID
AND jta6.resource_ID             = jrs6.resource_ID
AND jta6.Task_Assignment_ID      = cdh6.Task_Assignment_ID
AND csi6.Incident_ID             = cst6.source_object_ID
;

-- Cursor to retrieve Service Request Readings/Observations (Task assignment additional information)
CURSOR cur_1080
IS
SELECT
    csi12.Incident_ID
  , csi12.Incident_Number
  , jta12.Attribute_Category       "CONTEXT_VALUE"
  , jta12.attribute1
  , jta12.attribute2
  , jta12.attribute3
  , jta12.attribute4
  , jta12.attribute5
  , jta12.attribute6
  , jta12.attribute7
  , jta12.attribute8
  , jta12.attribute9
  , jta12.attribute10
  , jta12.attribute11
  , jta12.attribute12
  , jta12.attribute13
  , jta12.attribute14
  , jta12.attribute15
FROM
    CS_SR_Incidents_V               csi12
  , jtf_tasks_b                     jtb12
  , jtf_task_assignments            jta12
WHERE
    csi12.Org_ID                  = p_Org_ID
AND csi12.Incident_ID             = p_Incident_ID
AND csi12.incident_id             = jtb12.source_object_id
AND jtb12.Source_Object_Type_Code = 'SR'
AND jtb12.task_id                 = jta12.task_id
;

-- Retrieve DFF's for Context Value (from cur_1080)
CURSOR cur_1100 (p_Context_Value csd_repairs_V.Attribute_Category%TYPE)
IS
SELECT
    fav7.application_name                  "APPLICATION"
  , fdfv7.title                            "TITLE"
  , fdfv7.context_required_flag            "ENTRY_REQUIRED"
  , fdfv7.context_user_override_flag       "DISPLAYED"
  , fdfcv7.enabled_flag                    "ENABLED"
  , fdfcv7.descriptive_flex_context_code   "CONTEXT_CODE"
  , fdfcuv7.column_seq_num                 "SQE_NUMBER"
  , fdfcuv7.end_user_column_name           "USER_COLUMN_NAME"
  , fdfcuv7.application_column_name        "COLUMN_NAME"
  , fdfcuv7.description                    "COLUMN_DESCRIPTION"
FROM
    fnd_descriptive_flexs_vl                fdfv7
  , fnd_descr_flex_contexts_vl              fdfcv7
  , fnd_descr_flex_col_usage_vl             fdfcuv7
  , fnd_application_vl                      fav7
  , fnd_flex_value_sets                     ffvsv7
  , fnd_flex_value_sets                     ffvsv17
WHERE
    fdfv7.title                           IN ('Task assignments additional information')
AND fdfcv7.descriptive_flexfield_name     = fdfv7.descriptive_flexfield_name
AND fdfcv7.descriptive_flex_context_code  = p_Context_Value
AND fdfcuv7.descriptive_flexfield_name    = fdfcv7.descriptive_flexfield_name
AND fdfcuv7.descriptive_flex_context_code = fdfcv7.descriptive_flex_context_code
AND fav7.application_id                   = fdfv7.application_id
AND ffvsv7.flex_value_set_id(+)           = fdfv7.context_override_value_set_id
AND ffvsv17.flex_value_set_id(+)          = fdfcuv7.flex_value_set_id
-- 17-MAY-2017 - New code to check additional flags
AND fdfv7.context_required_flag           = 'Y'
AND fdfv7.context_user_override_flag      = 'Y'
AND fdfcv7.enabled_flag                   = 'Y'
AND fdfcuv7.display_flag                  = 'Y'
AND fdfcuv7.enabled_flag                  = 'Y'
ORDER BY 
    fdfv7.title
  , fdfcv7.descriptive_flex_context_code
  , fdfcuv7.column_seq_num
;

-- Cursor to retrieve count of Depot Repair Orders for a Service Request
CURSOR cur_1120
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v           cr13
WHERE
    cr13.SR_Org_ID        = p_Org_ID
AND cr13.Incident_ID      = p_Incident_ID
;

-- Cursor to retrieve count of Depot Repair Orders for a Service Request
-- where Repair Order status is not 'Closed' or 'Cancelled'
CURSOR cur_1140
IS
SELECT
    NVL(COUNT(*),0)
FROM
    csd_repairs_v           cr14
WHERE
    cr14.SR_Org_ID        = p_Org_ID
AND cr14.Incident_ID      = p_Incident_ID
AND UPPER(cr14.Status)    NOT IN ('CLOSED', 'CANCELLED')
;

-- Cursor to determine if there are any un-submitted charges pending
CURSOR cur_1160
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V           csi15
  , CS_CHARGE_DETAILS_V         csc15
WHERE
    csi15.Org_ID              = p_Org_ID
AND csi15.Incident_ID         = p_Incident_ID
AND csi15.Incident_ID         = csc15.Incident_ID
AND UPPER(csc15.LINE_STATUS) <> 'SUBMITTED'
AND csc15.TOTAL_ESTIMATE     <> 0
;

-- Cursor to determine if at least one Note Type 'Resolution' exists for Service Request#
CURSOR cur_1180
IS
SELECT
    NVL(COUNT(*),0)
FROM
    cs_sr_Notes_v           csn16
WHERE
    csn16.Incident_ID     = p_Incident_ID
AND csn16.Note_Type_Code  = 'CS_RESOLUTION'
;

-- Retrieve Attribute2 from 'CSD_REPAIR_TYPES_VL' to determine if Resolution Description is Optional
-- If NULL value, set to 'N'
CURSOR cur_1190
IS
SELECT
    NVL(crtv17.attribute2, 'N')
FROM
    CS_SR_Incidents_V              csi17
  , csd_repairs_V                  cr17
  , CSD_REPAIR_TYPES_VL            crtv17
WHERE
    csi17.Org_ID                 = p_Org_ID
AND csi17.incident_ID            = p_Incident_ID
AND csi17.incident_ID            = cr17.incident_ID
AND cr17.repair_type_id          = crtv17.repair_type_id
;

-- Cursor to retrieve where INTERFACE_TO_OE_FLAG = 'Y'
-- and AFTER_WARRANTY_COST equals *ZERO
CURSOR cur_1200
IS
SELECT
    csi16.Org_ID
  , csi16.Incident_ID
  , csi16.Incident_Number
  , csc16.INTERFACE_TO_OE_FLAG
  , csc16.PARTY_ID
  , csc16.ACCOUNT_ID
  , csc16.LINE_NUMBER
  , csc16.INVENTORY_ITEM_ID
  , csc16.SERIAL_NUMBER
  , csc16.ORDER_HEADER_ID
  , csc16.ORDER_LINE_ID
  , csc16.Object_Version_Number
  , csc16.ESTIMATE_DETAIL_ID
  , csc16.CREATION_DATE
  , csc16.AFTER_WARRANTY_COST
FROM
    CS_SR_Incidents_V           csi16
  , CS_CHARGE_DETAILS_V         csc16
WHERE
    csi16.Org_ID                = p_Org_ID
AND csi16.Incident_ID           = p_Incident_ID
AND csi16.Incident_ID           = csc16.Incident_ID
--AND csc16.AFTER_WARRANTY_COST   = 0
AND csc16.INTERFACE_TO_OE_FLAG  = 'Y'
ORDER BY
    csi16.Org_ID
  , csi16.Incident_ID
  , csc16.PARTY_ID
  , csc16.ACCOUNT_ID
  , csc16.LINE_NUMBER
;

BEGIN

   l_Error_Message := ('Entering EDITS_POST_SR_WITH_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Incident_Number, l_Debrief_Number, l_Debrief_Status_Code_SR, l_Debrief_Exsits_For_SR, l_Debrief_Exsits_For_DR
   l_Incident_Number           := NULL;
   l_Debrief_Number            := NULL;
   l_Task_Status_SR            := NULL;
   l_Assignment_Task_Status_SR := NULL;
   l_Debrief_Exsits_For_SR     := NULL;

   -- Cursor for Debrief (Service Request)
   OPEN cur_0700;
   FETCH cur_0700 INTO l_Incident_Number, l_Debrief_Number, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR;
   IF cur_0700%FOUND THEN
      l_Debrief_Exsits_For_SR := 'Y';
   ELSE
      l_Debrief_Exsits_For_SR := 'N';
   END IF;
   CLOSE cur_0700;

   IF (l_Debrief_Exsits_For_SR = 'Y') THEN
      l_Error_Message := ('Debrief exists for SR: ' || l_Debrief_Exsits_For_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Incident_Number: ' || l_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Number: ' || l_Debrief_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Task_Status_SR: ' || l_Task_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Assignment_Task_Status_SR: ' || l_Assignment_Task_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Status_SR: ' || l_Debrief_Status_SR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   -- Initialize l_Incident_Number, l_Debrief_Number, l_repair_number, l_Task_Status_DR, l_Assignment_Task_Status_DR, l_Debrief_Exsits_For_DR, l_Debrief_Status_DR
   l_Incident_Number           := NULL;
   l_Debrief_Number            := NULL;
   l_repair_number             := NULL;
   l_Task_Status_DR            := NULL;
   l_Assignment_Task_Status_DR := NULL;
   l_Debrief_Exsits_For_DR     := NULL;
   l_Debrief_Status_DR         := NULL;

   -- Cursor for Debrief (Repair Order)
   OPEN cur_0720;
   FETCH cur_0720 INTO l_Incident_Number, l_Debrief_Number, l_repair_number, l_Task_Status_DR, l_Assignment_Task_Status_DR, l_Debrief_Status_DR;
   IF cur_0720%FOUND THEN
      l_Debrief_Exsits_For_DR := 'Y';
   ELSE
      l_Debrief_Exsits_For_DR := 'N';
   END IF;
   CLOSE cur_0720;

   IF (l_Debrief_Exsits_For_DR = 'Y') THEN
      l_Error_Message := ('Debrief exists for DR: ' || l_Debrief_Exsits_For_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Incident_Number: ' || l_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Number: ' || l_Debrief_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Task_Status_DR: ' || l_Task_Status_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Assignment_Task_Status_DR: ' || l_Assignment_Task_Status_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      l_Error_Message := ('l_Debrief_Status_DR: ' || l_Debrief_Status_DR);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   IF (l_Debrief_Exsits_For_SR = 'Y') THEN
      IF (UPPER(l_Debrief_Status_SR) = 'COMPLETED W/ERRORS') THEN
         l_Error_Debrief_SR := 'Y';
         l_Error_Message    := ('Debrief exists with Status: ' || 'COMPLETED W/ERRORS ' || 'for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      END IF;
   END IF;

   IF (NVL(l_Debrief_Exsits_For_DR, 'N') = 'Y') THEN
      IF (UPPER(l_Debrief_Status_DR) = 'COMPLETED W/ERRORS') THEN
         l_Error_Debrief_DR := 'Y';
         l_Error_Message    := ('Debrief exists with Status: ' || 'COMPLETED W/ERRORS ' || 'for DR#: ' || l_repair_number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      END IF;
   END IF;

   -- Initialize
   l_IncProbCode1        := NULL;
   l_IncProbCode2        := NULL;
   l_IncProbCode3        := NULL;
   l_IncProbCode4        := NULL;
   l_IncProbCode5        := NULL;
   l_IncResCode1         := NULL;
   l_IncResCode2         := NULL;
   l_IncResCode3         := NULL;
   l_IncResCode4         := NULL;
   l_IncResCode5         := NULL;
   l_PIR_REVIEW          := NULL;
   l_PROCESS_PHASE       := NULL;
   l_DEATH               := NULL;
   l_POTENTIAL_INJURY    := NULL;
   l_HIGH_RISK_COMPLAINT := NULL;
   l_HOSPITALIZATION     := NULL;
   l_Incident_ID_SR      := NULL;
   l_Incident_Number_SR  := NULL;
   l_Inventory_Item_ID   := NULL;
   l_Incident_Type_ID    := NULL;
   l_Problem_Code        := NULL;
   l_Resolution_Code     := NULL;

   -- Service Repair Readings/Observations
   OPEN cur_0740;
   FETCH cur_0740 INTO l_IncProbCode1, l_IncProbCode2, l_IncProbCode3, l_IncProbCode4, l_IncProbCode5,
                       l_IncResCode1, l_IncResCode2, l_IncResCode3, l_IncResCode4, l_IncResCode5, 
                       l_PIR_REVIEW, l_PROCESS_PHASE, l_DEATH, l_POTENTIAL_INJURY, l_HIGH_RISK_COMPLAINT, l_HOSPITALIZATION,
                       l_Incident_ID_SR, l_Incident_Number_SR, l_Inventory_Item_ID, l_Incident_Type_ID, l_Problem_Code, l_Resolution_Code;
   CLOSE cur_0740;

   -- Initialize l_PIR_TEXT
   l_PIR_TEXT := NULL;

   -- First, check to ensure Problem Codes and Resolution Codes are populated correctly
   l_PIR_TEXT := XXHA_PIR_FF_VALIDATE(
                                       l_Incident_ID_SR
                                     , l_Incident_Number_SR
                                     , l_Inventory_Item_ID
                                     , l_Incident_Type_ID
                                     , l_Problem_Code
                                     , l_Resolution_Code
                                     , l_IncProbCode1
                                     , l_IncProbCode2
                                     , l_IncProbCode3
                                     , l_IncProbCode4
                                     , l_IncProbCode5
                                     , l_IncResCode1
                                     , l_IncResCode2
                                     , l_IncResCode3
                                     , l_IncResCode4
                                     , l_IncResCode5);

   l_Error_Message := 'PIR TEXT: ' || RTRIM(l_PIR_TEXT);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Error_Problem_Codes_Pop
   l_Error_Problem_Codes_Pop := NULL;
   l_Error_PIR_REVIEW_ASSOC  := NULL;

   IF RTRIM(UPPER(l_PIR_TEXT)) <> 'NOERROR' THEN
      l_Error_Problem_Codes_Pop := 'Y';
      l_Error_Message           := RTRIM(l_PIR_TEXT);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      l_Error_Message           := ('Problem Codes and Resolution Codes are not populated correctly for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   ELSE
      l_Error_Message := RTRIM(l_PIR_TEXT);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   -- Next, check that Problem_Code and Resolution_Code are populated
   IF (l_Problem_Code IS NULL) THEN
      l_Error_Problem_Codes_Pop := 'Y';
      l_Error_Message           := ('Problem Code is not populated correctly for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;
   IF (l_Resolution_Code IS NULL) THEN
      l_Error_Problem_Codes_Pop := 'Y';
      l_Error_Message           := ('Resolution Code is not populated correctly for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Finally, check if PIR Review is 'Y' or 'M'.  If so, ensure associated values are populated correctly
   IF (NVL(l_PIR_REVIEW, 'N') = 'Y') OR (NVL(l_PIR_REVIEW, 'N') = 'M') THEN
      IF (l_PROCESS_PHASE IS NULL) OR (l_DEATH IS NULL) OR (l_POTENTIAL_INJURY IS NULL) OR (l_HIGH_RISK_COMPLAINT IS NULL) OR (l_HOSPITALIZATION IS NULL) THEN
         l_Error_PIR_REVIEW_ASSOC := 'Y';
         l_Error_Message          := ('Associated PIR fields are not populated correctly for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      END IF;
   END IF;

   -- Initialize l_Incident_ID, l_Incident_Number, l_CONTEXT_VALUE, l_Count, l_DR_DFF_TAI_Error
   l_Incident_ID      := 0;
   l_Incident_Number  := NULL;
   l_CONTEXT_VALUE    := NULL;
   l_Count            := 0;
   l_DR_DFF_TAI_Error := 'N';

   -- Check CONTEXT_VALUE for Repair Order Task additional information
   OPEN cur_0760;
   FETCH cur_0760 INTO l_Incident_ID, l_Incident_Number, l_CONTEXT_VALUE;
   CLOSE cur_0760;

   -- If l_CONTEXT_VALUE contains a NULL Value, set to '<NO ENTRY>'
   l_CONTEXT_VALUE := NVL(l_CONTEXT_VALUE, '<NO ENTRY>');
   l_Error_Message := 'Repair Order Readings/Observations - l_CONTEXT_VALUE for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If no value in l_CONTEXT_VALUE, mark as Error
   IF UPPER(l_CONTEXT_VALUE) = '<NO ENTRY>' THEN
      l_Error_Message := 'Repair Order Readings/Observations - l_CONTEXT_VALUE IS NOT ENTERED for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- If No Entries required (l_CONTEXT_VALUE = 'NONE') then perform checks
   IF (UPPER(l_CONTEXT_VALUE) <> 'NONE') THEN
      -- Perform Repair Order (Depot Repair) Readings/Observations
      FOR dta220 IN cur_0800
      LOOP
         -- Check DFF's against Repair Order Readings/Observations for required entries
         IF (dta220.Context_Value IS NOT NULL) THEN
            FOR dta240 IN cur_0820 (dta220.Context_Value)
            LOOP
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE1') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute1 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute1/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE2') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute2 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute2/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE3') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute3 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute3/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE4') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute4 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute4/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE5') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute5 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute5/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE6') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute6 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute6/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE7') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute7 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute7/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE8') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute8 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute8/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE9') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute9 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute9/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE10') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute10 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute10/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE11') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute11 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute11/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE12') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute12 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute12/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE13') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute13 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute13/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE14') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute14 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute14/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE15') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute15 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute15/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE16') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute16 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute16/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE17') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute17 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute17/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE18') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute18 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute18/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE19') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute19 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute19/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE20') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute20 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute20/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE21') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute21 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute21/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE22') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute22 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute22/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE23') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute23 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute23/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE24') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute24 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute24/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE25') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute25 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute25/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE26') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute26 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute26/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE27') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute27 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute27/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE28') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute28 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute28/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE29') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute29 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute29/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
               IF (dta240.COLUMN_NAME = 'ATTRIBUTE30') AND (dta240.ENTRY_REQUIRED = 'Y') AND (dta220.Attribute30 IS NULL) THEN
                  l_DR_DFF_TAI_Error := 'Y';
                  l_Error_Message := 'Attribute30/Repair Order Additional information: ' || dta240.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta220.Repair_Number || ' / ' || dta220.Incident_Number;
                  WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
               END IF;
            END LOOP; -- FOR dta240 IN cur_0820 (dta220.Context_Value)
         END IF; -- If (dta220.Context_Value IS NOT NULL)
      END LOOP; -- FOR dta220 IN cur_0800
   END IF; -- If (UPPER(l_CONTEXT_VALUE) <> 'NONE')

   -- Initialize l_Count, l_DR_Has_Tasks
   l_Count        := 0;
   l_DR_Has_Tasks := NULL;

   -- Cursor to determine if tasks exist for Repair Order
   OPEN cur_0830;
   FETCH cur_0830 INTO l_Count;
   IF l_Count > 0 THEN
      l_DR_Has_Tasks := 'Y';
   ELSE
      l_DR_Has_Tasks := 'N';
   END IF;
   CLOSE cur_0830;

   -- Initialize l_CONTEXT_VALUE
   l_CONTEXT_VALUE := NULL;

   l_Error_Message := 'l_DR_Has_Tasks: ' || l_DR_Has_Tasks;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If no task exists for the Repair Order, there is no need to check for Task assignment additional information
   IF NVL(l_DR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta250 IN cur_0833
      LOOP
         -- If l_CONTEXT_VALUE contains a NULL Value, set to '<NO ENTRY>'
         l_CONTEXT_VALUE := NVL(dta250.CONTEXT_VALUE, '<NO ENTRY>');
         l_Error_Message := 'Repair Order Task assignment additional information-CONTEXT_VALUE for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number: ' || dta250.task_number;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         l_Error_Message := ('Task associated with Repair Order has status: ' || dta250.TASK_STATUS || ', Task Number: ' || dta250.task_number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
      END LOOP;
   END IF;

   -- Initialize l_CONTEXT_VALUE, l_Error_DR_Tasks_Status, l_DR_DFF_TAAI_Error
   l_CONTEXT_VALUE         := NULL;
   l_Error_DR_Tasks_Status := 'N';
   l_DR_DFF_TAAI_Error     := 'N'; 

   -- If tasks exists for the Repair Order
   IF NVL(l_DR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta250 IN cur_0833
      LOOP

         -- If CONTEXT_VALUE contains a NULL Value, set Error
         IF NVL(dta250.CONTEXT_VALUE, '<NO ENTRY>') = '<NO ENTRY>' THEN
            l_Error_DR_Tasks_Status := 'Y';
            l_CONTEXT_VALUE         := NVL(dta250.CONTEXT_VALUE, '<NO ENTRY>');
            l_Error_Message         := 'Repair Order Task assignment additional information-CONTEXT_VALUE for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number: ' || dta250.task_number;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            -- If No Entries required (l_CONTEXT_VALUE = 'NONE')
            IF (UPPER(dta250.CONTEXT_VALUE) <> 'NONE') THEN
            -- If the Task Status not equal to 'CANCELLED' then perform checks
            IF (UPPER(dta250.TASK_STATUS) <> 'CANCELLED') THEN

            l_Error_Message := 'Task associated with Repair Order has status: '  || dta250.TASK_STATUS;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

               -- Perform Repair Order (Depot Repair) Readings/Observations
               FOR dta260 IN cur_0880
               LOOP
                  -- Check DFF's against Repair Order Readings/Observations for required entries
                  IF (dta260.Context_Value IS NOT NULL) THEN
                     FOR dta280 IN cur_0900 (dta260.Context_Value)
                     LOOP
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE1') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute1 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute1/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE2') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute2 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute2/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE3') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute3 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute3/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE4') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute4 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute4/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE5') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute5 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute5/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE6') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute6 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute6/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE7') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute7 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute7/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE8') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute8 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute8/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE9') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute9 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute9/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE10') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute10 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute10/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE11') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute11 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute11/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE12') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute12 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute12/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE13') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute13 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute13/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE14') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute14 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute14/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta280.COLUMN_NAME = 'ATTRIBUTE15') AND (dta280.ENTRY_REQUIRED = 'Y') AND (dta260.Attribute15 IS NULL) THEN
                           l_DR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute15/Repair Order Task assignment additional information: ' || dta280.COLUMN_DESCRIPTION || ' requires entry for Repair Number/Service Request: ' || dta260.Repair_Number || ' / ' || dta260.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                     END LOOP; -- FOR dta280 IN cur_0900 (dta260.Context_Value)
                  END IF; -- IF (dta260.Context_Value IS NOT NULL)
               END LOOP; -- dta260 IN cur_0880
            END IF; -- IF (UPPER(dta250.TASK_STATUS) <> 'CANCELLED')
            END IF; -- IF (UPPER(dta250.CONTEXT_VALUE) <> 'NONE')
         END IF; -- IF NVL(dta250.CONTEXT_VALUE, '<NO ENTRY>') = '<NO ENTRY>'
      END LOOP; -- dta250 IN cur_0833
   END IF;  -- IF l_DR_Has_Tasks = 'Y'

   -- Initialize l_Count, l_SR_Has_Tasks, l_Error_SR_Tasks, l_Error_SR_Tasks_Status
   l_Count                 := 0;
   l_SR_Has_Tasks          := NULL;
   l_Error_SR_Tasks        := NULL;
   l_Error_SR_Tasks_Status := NULL;

   -- Check if tasks exist for Service Request (It's not an error if it's a Depot Repair SR)
   OPEN cur_0920;
   FETCH cur_0920 INTO l_Count;
   IF (l_Count = 0) THEN
      l_SR_Has_Tasks   := 'N';
      l_Error_Message  := 'There are no tasks associated with Service Request: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   ELSE
      l_SR_Has_Tasks  := 'Y';
      l_Error_Message := 'There are tasks associated with Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;
   CLOSE cur_0920;

   -- Initialize l_CONTEXT_VALUE
   l_CONTEXT_VALUE := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta300 IN cur_0940
      LOOP
         -- If l_CONTEXT_VALUE contains a NULL Value, set to '<NO ENTRY>'
         l_CONTEXT_VALUE := NVL(dta300.CONTEXT_VALUE, '<NO ENTRY>');
         l_Error_Message := 'Service Request Task additional information-CONTEXT_VALUE for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number: ' || dta300.task_number;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If any task is NOT IN ('Completed', 'Closed', 'Cancelled') then Error the record
         IF (UPPER(dta300.TASK_STATUS) NOT IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_Error_Message         := ('Task(s) associated with Service Request has status other than Completed, Closed or Cancelled: ' || dta300.TASK_STATUS || ', Task Number: ' || dta300.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            l_Error_Message := ('Task associated with Service Request has status: ' || dta300.TASK_STATUS || ', Task Number: ' || dta300.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END IF;
      END LOOP;
   END IF;

   -- Initialize l_SR_DFF_TAI_Error, l_CONTEXT_VALUE
   l_SR_DFF_TAI_Error := 'N';
   l_CONTEXT_VALUE    := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta300 IN cur_0940
      LOOP

         -- If CONTEXT_VALUE contains a NULL Value, set Error
         IF (UPPER(NVL(dta300.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>') THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_CONTEXT_VALUE         := NVL(dta300.CONTEXT_VALUE, '<NO ENTRY>');
            l_Error_Message         := 'Service Request Task additional information-CONTEXT_VALUE IS NOT ENTERED for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number' || dta300.task_number;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            -- If No Entries required (l_CONTEXT_VALUE = 'NONE')
            IF (UPPER(dta300.CONTEXT_VALUE) <> 'NONE') THEN
            -- If the Task Status not equal to 'CANCELLED' (Attributes are not mandatory when 'CANCELLED')
            --IF (UPPER(dta300.TASK_STATUS) <> 'CANCELLED') THEN

               l_Error_Message := 'Task associated with Service Request has status: '  || dta300.TASK_STATUS;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

               -- Perform Service Request Readings/Observations (Tasks additional information)
               FOR dta320 IN cur_1000
               LOOP
                  -- Check DFF's against Service Request Readings/Observations for required entries
                  IF (dta320.Context_Value IS NOT NULL) THEN
                     FOR dta340 IN cur_1020 (dta320.Context_Value)
                     LOOP
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE1') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute1 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute1/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE2') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute2 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute2/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE3') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute3 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute3/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE4') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute4 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute4/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE5') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute5 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute5/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE6') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute6 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute6/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE7') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute7 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute7/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE8') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute8 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute8/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE9') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute9 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute9/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE10') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute10 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute10/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE11') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute11 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute11/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE12') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute12 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute12/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE13') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute13 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute13/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE14') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute14 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute14/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta340.COLUMN_NAME = 'ATTRIBUTE15') AND (dta340.ENTRY_REQUIRED = 'Y') AND (dta320.Attribute15 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute15/Service Request Task additional information: ' || dta340.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta320.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                     END LOOP; -- FOR dta340 IN cur_1020 (dta320.Context_Value)
                  END IF; -- IF (dta440.Context_Value IS NOT NULL)
               END LOOP; -- FOR dta320 IN cur_1000
            --END IF; -- IF (UPPER(dta420.TASK_STATUS) <> 'CANCELLED')
            END IF; -- IF (UPPER(dta300.CONTEXT_VALUE) <> 'NONE')
         END IF; -- IF (UPPER(NVL(dta300.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>') THEN
      END LOOP; -- FOR dta300 IN cur_0940
   END IF; -- IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN

   -- Initialize l_CONTEXT_VALUE
   l_CONTEXT_VALUE := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta350 IN cur_1040
      LOOP
         -- If l_CONTEXT_VALUE contains a NULL Value, set to '<NO ENTRY>'
         l_CONTEXT_VALUE := NVL(dta350.CONTEXT_VALUE, '<NO ENTRY>');
         l_Error_Message := 'Service Request Task additional information-CONTEXT_VALUE for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number: ' || dta350.task_number;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If any task is NOT IN ('Completed', 'Closed', 'Cancelled') then Error the record
         IF (UPPER(dta350.TASK_STATUS) NOT IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_Error_Message         := ('Task(s) associated with Service Request has status other than Completed, Closed or Cancelled: ' || dta350.TASK_STATUS || ', Task Number: ' || dta350.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            l_Error_Message := ('Task associated with Service Request has status: ' || dta350.TASK_STATUS || ', Task Number: ' || dta350.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END IF;
      END LOOP;
   END IF;

   -- Initialize l_SR_DFF_TAAI_Error, l_CONTEXT_VALUE
   l_SR_DFF_TAAI_Error := 'N';
   l_CONTEXT_VALUE     := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta350 IN cur_1040
      LOOP

         -- If CONTEXT_VALUE contains a NULL Value, set Error
         IF (UPPER(NVL(dta350.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>') THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_CONTEXT_VALUE         := NVL(dta350.CONTEXT_VALUE, '<NO ENTRY>');
            l_Error_Message         := 'Service Request Task assignment additional information-CONTEXT_VALUE IS NOT ENTERED for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number' || dta350.task_number;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            -- If No Entries required (l_CONTEXT_VALUE = 'NONE')
            IF (UPPER(dta350.CONTEXT_VALUE) <> 'NONE') THEN
            -- If the Tasks Status not equal to 'CANCELLED' then perform checks
            IF (UPPER(dta350.TASK_STATUS) <> 'CANCELLED') THEN

               l_Error_Message := 'Task associated with Service Request has status: '  || dta350.TASK_STATUS;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

               -- Perform Service Request Readings/Observations (Task assignment additional information)
               FOR dta360 IN cur_1080
               LOOP
                  -- Check DFF's against Service Request Readings/Observations for required entries
                  IF (dta360.Context_Value IS NOT NULL) THEN
                     FOR dta380 IN cur_1100 (dta360.Context_Value)
                     LOOP
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE1') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute1 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute1/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE2') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute2 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute2/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE3') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute3 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute3/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE4') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute4 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute4/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE5') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute5 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute5/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE6') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute6 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute6/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE7') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute7 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute7/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE8') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute8 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute8/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE9') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute9 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute9/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE10') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute10 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute10/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE11') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute11 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute11/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE12') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute12 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute12/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE13') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute13 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute13/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE14') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute14 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute14/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta380.COLUMN_NAME = 'ATTRIBUTE15') AND (dta380.ENTRY_REQUIRED = 'Y') AND (dta360.Attribute15 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute15/Service Request Task assignment additional information: ' || dta380.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta360.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                     END LOOP; -- FOR dta380 IN cur_1100 (dta360.Context_Value)
                  END IF; -- IF (dta360.Context_Value IS NOT NULL)
               END LOOP; -- FOR dta360 IN cur_1080
            END IF; -- IF (UPPER(dta350.TASK_STATUS) <> 'CANCELLED')
            END IF; -- IF (UPPER(dta350.CONTEXT_VALUE) <> 'NONE')
         END IF; -- IF (UPPER(NVL(dta350.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>'
      END LOOP; -- FOR dta350 IN cur_1040
   END IF; -- IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN

   -- Initialize l_Count_All and l_DR_Exists
   l_Count_All := 0;
   l_DR_Exists := NULL;

   -- Cursor to retrieve count of Depot Repair Orders for a Service Request
   OPEN cur_1120;
   FETCH cur_1120 INTO l_Count_All;
   IF (l_Count_All > 0) THEN
      l_DR_Exists  := 'Y';
   ELSE
      l_DR_Exists  := 'N';
   END IF;
   CLOSE cur_1120;

   l_Error_Message := 'DR_Exists: ' || l_DR_Exists;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Count_Open
   l_Count_Open := 0;

   -- Retrieve record count of Depot Repair Orders for a Service Request 
   -- where Repair Order status is not 'Closed' or 'Cancelled'
   OPEN cur_1140;
   FETCH cur_1140 INTO l_Count_Open;
   CLOSE cur_1140;

   l_Error_Message := 'Depot Repair Orders for Service Request, Count_Open: ' || l_Count_Open || ', Count_All: ' || l_Count_All;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Count
   l_Count := 0;

   -- Cursor to determine if there are any un-submitted charges pending
   OPEN cur_1160;
   FETCH cur_1160 INTO l_Count;
   CLOSE cur_1160;

   IF (l_Count > 0) THEN
      l_Error_SR_Unsubmitted := 'Y';
      l_Error_Message        := 'There are un-submitted charges pending for Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Initialize l_Count
   l_Count := 0;

   -- Cursor to determine if at least one Note Type 'Resolution' exists for Service Request#
   OPEN cur_1180;
   FETCH cur_1180 INTO l_Count;
   CLOSE cur_1180;

   -- Initialize l_Resolution_Descr_Optional
   l_Resolution_Descr_Optional := NULL;

   -- Cursor to determine if Resolution Description is Optional
   OPEN cur_1190;
   FETCH cur_1190 INTO l_Resolution_Descr_Optional;
   CLOSE cur_1190;

   l_Error_Message        := 'Resolution Description Optional Flag for Service Request#: ' || p_Incident_Number || ', Resolution_Descr_Optional: ' || l_Resolution_Descr_Optional;
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- If l_Resolution_Descr_Optional = 'N' then we will require a Resolution Note Type to exist
   IF l_Resolution_Descr_Optional = 'N' THEN
      IF (l_Count = 0) AND (NVL(l_DR_Exists, 'N') = 'Y') THEN
         l_Error_Resolution_Note_Type := 'Y';
         l_Error_Message              := 'At least one ' || '''Resolution Description''' || ' Note Type must exist for Service Request#: ' || p_Incident_Number;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      END IF;
   END IF;

   -- Initialize l_Interface_To_OE_Flag
   l_Interface_To_OE_Flag := NULL;

   -- Send back Output Error Parameter
   IF (NVL(l_Error_Debrief_SR, 'N') = 'Y')     OR (NVL(l_Error_Debrief_DR, 'N') = 'Y')           OR (NVL(l_Error_Problem_Codes_Pop, 'N') = 'Y')   OR 
      (NVL(l_Error_PIR_REVIEW, 'N') = 'Y')     OR (NVL(l_Error_PIR_REVIEW_ASSOC, 'N') = 'Y')     OR (NVL(l_Error_Problem_Codes_Entry, 'N') = 'Y') OR 
      (NVL(l_Error_SR_Tasks, 'N') = 'Y')       OR (NVL(l_Error_SR_Tasks_Status, 'N') = 'Y')      OR (NVL(l_Error_DR_Tasks_Status, 'N') = 'Y')     OR 
      (NVL(l_Error_SR_Unsubmitted, 'N') = 'Y') OR (NVL(l_Error_Resolution_Note_Type, 'N') = 'Y') OR (NVL(l_DR_DFF_TAI_Error, 'N') = 'Y')          OR
      (NVL(l_DR_DFF_TAAI_Error, 'N') = 'Y')    OR (NVL(l_SR_DFF_TAI_Error, 'N') = 'Y')           OR (NVL(l_SR_DFF_TAAI_Error, 'N') = 'Y')         OR
      (NVL(l_Interface_To_OE_Flag, 'N') = 'Y') THEN
      p_EDITS_POST_SR_WITH_DR := 'Y';
   ELSE
      p_EDITS_POST_SR_WITH_DR := 'N';
   END IF;

   l_Error_Message := ('Exiting EDITS_POST_SR_WITH_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END EDITS_POST_SR_WITH_DR;

--------------------------------------------------------------------------------
-- EDITS_POST_SR_WITHOUT_DR

PROCEDURE EDITS_POST_SR_WITHOUT_DR(p_Org_ID                     IN  NUMBER
                                 , p_Incident_ID                IN  NUMBER
                                 , p_Incident_Number            IN  VARCHAR2
                                 , P_EDITS_POST_SR_WITHOUT_DR   OUT VARCHAR2
) IS

l_Count                           NUMBER                                        := 0;
l_SR_Has_Tasks                    VARCHAR2(01)                                  := NULL;
l_Debrief_Exsits_For_SR           VARCHAR2(01)                                  := NULL;
l_SR_DFF_TAI_Error                VARCHAR2(01)                                  := NULL;
l_SR_DFF_TAAI_Error               VARCHAR2(01)                                  := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Interface_To_OE_Flag            CS_CHARGE_DETAILS_V.INTERFACE_TO_OE_FLAG%TYPE := NULL;
l_source_object_ID                cs_sr_tasks_v.source_object_ID%TYPE           := NULL;
l_Error_Debrief_SR                XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Problem_Codes_Pop         XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_PIR_REVIEW                XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_PIR_REVIEW_ASSOC          XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Problem_Codes_Entry       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Tasks                  XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Tasks_Status           XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_SR_Unsubmitted            XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Resolution_Note_Type      XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Incident_ID                     csd_repairs_v.Incident_ID%TYPE                := NULL;
l_Incident_Number                 csd_repairs_v.Incident_Number%TYPE            := NULL;
l_Repair_Number                   csd_repairs_v.Repair_Number%TYPE              := NULL;
l_Debrief_Number                  csf_debrief_headers.Debrief_Number%TYPE       := NULL;

l_Task_Status_SR                  JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Assignment_Task_Status_SR       JTF_TASK_STATUSES_VL.Name%TYPE                := NULL;
l_Debrief_Status_SR               csf_debrief_headers.Processed_flag%TYPE       := NULL;

l_IncProbCode1                    CS_SR_Incidents_V.incident_attribute_1%TYPE   := NULL;
l_IncProbCode2                    CS_SR_Incidents_V.incident_attribute_7%TYPE   := NULL;
l_IncProbCode3                    CS_SR_Incidents_V.incident_attribute_8%TYPE   := NULL;
l_IncProbCode4                    CS_SR_Incidents_V.incident_attribute_9%TYPE   := NULL;
l_IncProbCode5                    CS_SR_Incidents_V.incident_attribute_10%TYPE  := NULL;
l_IncResCode1                     CS_SR_Incidents_V.incident_attribute_11%TYPE  := NULL;
l_IncResCode2                     CS_SR_Incidents_V.incident_attribute_12%TYPE  := NULL;
l_IncResCode3                     CS_SR_Incidents_V.incident_attribute_13%TYPE  := NULL;
l_IncResCode4                     CS_SR_Incidents_V.incident_attribute_14%TYPE  := NULL;
l_IncResCode5                     CS_SR_Incidents_V.incident_attribute_15%TYPE  := NULL;
l_PROCESS_PHASE                   CS_SR_Incidents_V.incident_attribute_2%TYPE   := NULL;
l_DEATH                           CS_SR_Incidents_V.incident_attribute_3%TYPE   := NULL;
l_POTENTIAL_INJURY                CS_SR_Incidents_V.incident_attribute_3%TYPE   := NULL;
l_HIGH_RISK_COMPLAINT             CS_SR_Incidents_V.incident_attribute_5%TYPE   := NULL;
l_HOSPITALIZATION                 CS_SR_Incidents_V.incident_attribute_6%TYPE   := NULL;
l_PIR_REVIEW                      CS_SR_Incidents_V.incident_context%TYPE       := NULL;
l_Incident_ID_SR                  CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number_SR              CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Inventory_Item_ID               CS_SR_Incidents_V.Inventory_Item_ID%TYPE      := NULL;
l_Incident_Type_ID                CS_SR_Incidents_V.Incident_Type_ID%TYPE       := NULL;
l_Problem_Code                    CS_SR_Incidents_V.Problem_Code%TYPE           := NULL;
l_Resolution_Code                 CS_SR_Incidents_V.Resolution_Code%TYPE        := NULL;
l_PIR_TEXT                        VARCHAR2(500)                                 := NULL;

l_DR_Incident_ID                  csd_repairs_V.Incident_ID%TYPE                := NULL;
l_DR_Incident_Number              csd_repairs_V.Incident_Number%TYPE            := NULL;
l_Context_Value                   csd_repairs_V.Attribute_Category%TYPE         := NULL;
l_Attribute1                      csd_repairs_V.Attribute1%TYPE                 := NULL;
l_Attribute2                      csd_repairs_V.Attribute2%TYPE                 := NULL;
l_Attribute3                      csd_repairs_V.Attribute3%TYPE                 := NULL;
l_Attribute4                      csd_repairs_V.Attribute4%TYPE                 := NULL;
l_Attribute5                      csd_repairs_V.Attribute5%TYPE                 := NULL;
l_Attribute6                      csd_repairs_V.Attribute6%TYPE                 := NULL;
l_Attribute7                      csd_repairs_V.Attribute7%TYPE                 := NULL;
l_Attribute8                      csd_repairs_V.Attribute8%TYPE                 := NULL;
l_Attribute9                      csd_repairs_V.Attribute9%TYPE                 := NULL;
l_Attribute10                     csd_repairs_V.Attribute10%TYPE                := NULL;
l_Attribute11                     csd_repairs_V.Attribute11%TYPE                := NULL;
l_Attribute12                     csd_repairs_V.Attribute12%TYPE                := NULL;
l_Attribute13                     csd_repairs_V.Attribute13%TYPE                := NULL;
l_Attribute14                     csd_repairs_V.Attribute14%TYPE                := NULL;
l_Attribute15                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute16                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute17                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute18                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute19                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute20                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute21                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute22                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute23                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute24                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute25                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute26                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute27                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute28                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute29                     csd_repairs_V.Attribute15%TYPE                := NULL;
l_Attribute30                     csd_repairs_V.Attribute15%TYPE                := NULL;

-- Cursor for Debrief (Service Request)
CURSOR cur_1220
IS
SELECT
    csi1.incident_number
  , CDH1.DEBRIEF_NUMBER
  , jts1.name                     "TASK_STATUS"
  , jts11.name                    "ASSIGNMENT_TASK_STATUS"
  , cdh1.Processed_flag           "DEBRIEF_STATUS"
FROM
    CS_SR_Incidents_V              csi1
  , jtf_tasks_vl                   jtv1
  , jtf_task_assignments           jta1
  , JTF_RS_RESOURCE_EXTNS          jrs1
  , JTF_TASK_STATUSES_VL           jts1
  , JTF_TASK_STATUSES_VL           jts11
  , csf_debrief_headers            cdh1
WHERE
    csi1.Org_ID                  = p_Org_ID
AND csi1.incident_ID             = p_Incident_ID
AND csi1.incident_ID             = jtv1.source_object_ID
AND jtv1.Source_Object_Type_Code = 'SR'
AND jtv1.task_ID                 = jta1.task_ID
AND jtv1.Task_Status_ID          = jts1.Task_Status_ID
AND JTA1.ASSIGNMENT_STATUS_ID    = jts11.Task_Status_ID
AND jta1.resource_ID             = jrs1.resource_ID
AND jta1.Task_Assignment_ID      = cdh1.Task_Assignment_ID
;

-- Service Repair Readings/Observations
CURSOR cur_1240
IS
SELECT
    csi2.incident_attribute_1    "IncProbCode1"
  , csi2.incident_attribute_7    "IncProbCode2"
  , csi2.incident_attribute_8    "IncProbCode3"
  , csi2.incident_attribute_9    "IncProbCode4"
  , csi2.incident_attribute_10   "IncProbCode5"
  , csi2.incident_attribute_11   "IncResCode1"
  , csi2.incident_attribute_12   "IncResCode2"
  , csi2.incident_attribute_13   "IncResCode3"
  , csi2.incident_attribute_14   "IncResCode4"
  , csi2.incident_attribute_15   "IncResCode5"
  , csi2.incident_context        "PIR_REVIEW"
  , csi2.incident_attribute_2    "PROCESS_PHASE"
  , csi2.incident_attribute_3    "DEATH"
  , csi2.incident_attribute_4    "POTENTIAL_INJURY"
  , csi2.incident_attribute_5    "HIGH_RISK_COMPLAINT"
  , csi2.incident_attribute_6    "HOSPITALIZATION"
  , csi2.Incident_ID
  , csi2.Incident_Number
  , csi2.Inventory_Item_ID
  , csi2.Incident_Type_ID
  , csi2.Problem_Code
  , csi2.Resolution_Code
FROM
    CS_SR_Incidents_V             csi2
WHERE
    csi2.Org_ID                 = p_Org_ID
AND csi2.incident_ID            = p_Incident_ID
;

-- Cursor to determine if tasks exist for Service Request 
CURSOR cur_1260
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V       csi3
  , cs_sr_tasks_v           cst3
  , csf_debrief_tasks_v     csf3
WHERE
    csi3.Org_ID           = p_Org_ID
AND csi3.Incident_ID      = p_Incident_ID
AND csi3.Incident_ID      = cst3.source_object_ID
AND csi3.Incident_ID      = csf3.Incident_ID
AND CSF3.SOURCE_TYPE_CODE = 'SR'
;

-- Cursor to retrieve Status of tasks for Service Request and
-- CONTEXT_VALUE for Service Request Task additional information
CURSOR cur_1280
IS
SELECT
    jts4.name                     "TASK_STATUS"
  , jtv4.Task_ID
  , jtv4.Task_Number
  , jtv4.Object_Version_Number
  , cst4.Attribute_Category       "CONTEXT_VALUE"
FROM
    CS_SR_Incidents_V              csi4
  , jtf_tasks_vl                   jtv4
  , jtf_task_assignments           jta4
  , JTF_RS_RESOURCE_EXTNS          jrs4
  , JTF_TASK_STATUSES_VL           jts4
  , csf_debrief_headers            cdh4
  , cs_sr_tasks_v                  cst4
WHERE
    csi4.Org_ID                  = p_Org_ID
AND csi4.incident_ID             = p_Incident_ID
AND csi4.incident_ID             = jtv4.source_object_ID
AND jtv4.Source_Object_Type_Code = 'SR'
AND jtv4.task_ID                 = jta4.task_ID
AND jtv4.Task_Status_ID          = jts4.Task_Status_ID
AND jta4.resource_ID             = jrs4.resource_ID
AND jta4.Task_Assignment_ID      = cdh4.Task_Assignment_ID
AND csi4.Incident_ID             = cst4.source_object_ID
;

-- Cursor to retrieve Service Request Readings/Observations (Tasks additional information)
CURSOR cur_1340
IS
SELECT
    csi6.Incident_ID
  , csi6.Incident_Number
  , cst6.task_ID
  , cst6.task_number
  , cst6.Attribute_Category  "CONTEXT_VALUE"
  , cst6.Attribute1
  , cst6.Attribute2
  , cst6.Attribute3
  , cst6.Attribute4
  , cst6.Attribute5
  , cst6.Attribute6
  , cst6.Attribute7
  , cst6.Attribute8
  , cst6.Attribute9
  , cst6.Attribute10
  , cst6.Attribute11
  , cst6.Attribute12
  , cst6.Attribute13
  , cst6.Attribute14
  , cst6.Attribute15
FROM
    CS_SR_Incidents_V         csi6
  , cs_sr_tasks_v             cst6
WHERE
    csi6.Org_ID             = p_Org_ID
AND csi6.Incident_ID        = p_Incident_ID
AND csi6.Incident_ID        = cst6.source_object_ID
;

-- Retrieve DFF's for Context Value (from cur_1340)
CURSOR cur_1360 (p_Context_Value csd_repairs_V.Attribute_Category%TYPE)
IS
SELECT
    fav2.application_name                  "APPLICATION"
  , fdfv2.title                            "TITLE"
  , fdfv2.context_required_flag            "ENTRY_REQUIRED"
  , fdfv2.context_user_override_flag       "DISPLAYED"
  , fdfcv2.enabled_flag                    "ENABLED"
  , fdfcv2.descriptive_flex_context_code   "CONTEXT_CODE"
  , fdfcuv2.column_seq_num                 "SQE_NUMBER"
  , fdfcuv2.end_user_column_name           "USER_COLUMN_NAME"
  , fdfcuv2.application_column_name        "COLUMN_NAME"
  , fdfcuv2.description                    "COLUMN_DESCRIPTION"
FROM
    fnd_descriptive_flexs_vl                fdfv2
  , fnd_descr_flex_contexts_vl              fdfcv2
  , fnd_descr_flex_col_usage_vl             fdfcuv2
  , fnd_application_vl                      fav2
  , fnd_flex_value_sets                     ffvsv2
  , fnd_flex_value_sets                     ffvsv12
WHERE
    fdfv2.title                           IN ('Tasks additional information')
AND fdfcv2.descriptive_flexfield_name     = fdfv2.descriptive_flexfield_name
AND fdfcv2.descriptive_flex_context_code  = p_Context_Value
AND fdfcuv2.descriptive_flexfield_name    = fdfcv2.descriptive_flexfield_name
AND fdfcuv2.descriptive_flex_context_code = fdfcv2.descriptive_flex_context_code
AND fav2.application_id                   = fdfv2.application_id
AND ffvsv2.flex_value_set_id(+)           = fdfv2.context_override_value_set_id
AND ffvsv12.flex_value_set_id(+)          = fdfcuv2.flex_value_set_id
-- 17-MAY-2017 - New code to check additional flags
AND fdfv2.context_required_flag           = 'Y'
AND fdfv2.context_user_override_flag      = 'Y'
AND fdfcv2.enabled_flag                   = 'Y'
AND fdfcuv2.display_flag                  = 'Y'
AND fdfcuv2.enabled_flag                  = 'Y'
ORDER BY 
    fdfv2.title
  , fdfcv2.descriptive_flex_context_code
  , fdfcuv2.column_seq_num
;

-- Cursor to retrieve Status of tasks for Service Request and
-- CONTEXT_VALUE for Service Request Task additional information
CURSOR cur_1380
IS
SELECT
    jts6.name                     "TASK_STATUS"
  , jtv6.Task_ID
  , jtv6.Task_Number
  , jtv6.Object_Version_Number
  , cst6.Attribute_Category       "CONTEXT_VALUE"
FROM
    CS_SR_Incidents_V              csi6
  , jtf_tasks_vl                   jtv6
  , jtf_task_assignments           jta6
  , JTF_RS_RESOURCE_EXTNS          jrs6
  , JTF_TASK_STATUSES_VL           jts6
  , csf_debrief_headers            cdh6
  , cs_sr_tasks_v                  cst6
WHERE
    csi6.Org_ID                  = p_Org_ID
AND csi6.incident_ID             = p_Incident_ID
AND csi6.incident_ID             = jtv6.source_object_ID
AND jtv6.Source_Object_Type_Code = 'SR'
AND jtv6.task_ID                 = jta6.task_ID
AND jtv6.Task_Status_ID          = jts6.Task_Status_ID
AND jta6.resource_ID             = jrs6.resource_ID
AND jta6.Task_Assignment_ID      = cdh6.Task_Assignment_ID
AND csi6.Incident_ID             = cst6.source_object_ID
;

-- Cursor to retrieve Service Request Readings/Observations (Task assignment additional information)
CURSOR cur_1420
IS
SELECT
    csi12.Incident_ID
  , csi12.Incident_Number
  , jta12.Attribute_Category       "CONTEXT_VALUE"
  , jta12.attribute1
  , jta12.attribute2
  , jta12.attribute3
  , jta12.attribute4
  , jta12.attribute5
  , jta12.attribute6
  , jta12.attribute7
  , jta12.attribute8
  , jta12.attribute9
  , jta12.attribute10
  , jta12.attribute11
  , jta12.attribute12
  , jta12.attribute13
  , jta12.attribute14
  , jta12.attribute15
FROM
    CS_SR_Incidents_V               csi12
  , jtf_tasks_b                     jtb12
  , jtf_task_assignments            jta12
WHERE
    csi12.Org_ID                  = p_Org_ID
AND csi12.Incident_ID             = p_Incident_ID
AND csi12.incident_id             = jtb12.source_object_id
AND jtb12.Source_Object_Type_Code = 'SR'
AND jtb12.task_id                 = jta12.task_id
;

-- Retrieve DFF's for Context Value (from cur_1420)
CURSOR cur_1440 (p_Context_Value csd_repairs_V.Attribute_Category%TYPE)
IS
SELECT
    fav7.application_name                  "APPLICATION"
  , fdfv7.title                            "TITLE"
  , fdfv7.context_required_flag            "ENTRY_REQUIRED"
  , fdfv7.context_user_override_flag       "DISPLAYED"
  , fdfcv7.enabled_flag                    "ENABLED"
  , fdfcv7.descriptive_flex_context_code   "CONTEXT_CODE"
  , fdfcuv7.column_seq_num                 "SQE_NUMBER"
  , fdfcuv7.end_user_column_name           "USER_COLUMN_NAME"
  , fdfcuv7.application_column_name        "COLUMN_NAME"
  , fdfcuv7.description                    "COLUMN_DESCRIPTION"
FROM
    fnd_descriptive_flexs_vl                fdfv7
  , fnd_descr_flex_contexts_vl              fdfcv7
  , fnd_descr_flex_col_usage_vl             fdfcuv7
  , fnd_application_vl                      fav7
  , fnd_flex_value_sets                     ffvsv7
  , fnd_flex_value_sets                     ffvsv17
WHERE
    fdfv7.title                           IN ('Task assignments additional information')
AND fdfcv7.descriptive_flexfield_name     = fdfv7.descriptive_flexfield_name
AND fdfcv7.descriptive_flex_context_code  = p_Context_Value
AND fdfcuv7.descriptive_flexfield_name    = fdfcv7.descriptive_flexfield_name
AND fdfcuv7.descriptive_flex_context_code = fdfcv7.descriptive_flex_context_code
AND fav7.application_id                   = fdfv7.application_id
AND ffvsv7.flex_value_set_id(+)           = fdfv7.context_override_value_set_id
AND ffvsv17.flex_value_set_id(+)          = fdfcuv7.flex_value_set_id
-- 17-MAY-2017 - New code to check additional flags
AND fdfv7.context_required_flag           = 'Y'
AND fdfv7.context_user_override_flag      = 'Y'
AND fdfcv7.enabled_flag                   = 'Y'
AND fdfcuv7.display_flag                  = 'Y'
AND fdfcuv7.enabled_flag                  = 'Y'
ORDER BY 
    fdfv7.title
  , fdfcv7.descriptive_flex_context_code
  , fdfcuv7.column_seq_num
;

-- Cursor to determine if there are any un-submitted charges pending
CURSOR cur_1460
IS
SELECT
    NVL(COUNT(*),0)
FROM
    CS_SR_Incidents_V       csi9
  , CS_CHARGE_DETAILS_V     csc9
WHERE
    csi9.Org_ID           = p_Org_ID
AND csi9.Incident_ID      = p_Incident_ID
AND csi9.Incident_ID      = csc9.Incident_ID
AND csc9.LINE_STATUS      <> 'SUBMITTED'
AND csc9.TOTAL_ESTIMATE   <> 0
;

-- Cursor to determine if at least one Note Type 'Resolution' exists for Service Request#
CURSOR cur_1480 
IS
SELECT
    NVL(COUNT(*),0)
FROM
    cs_sr_Notes_v           csn10
WHERE
    csn10.Incident_ID     = p_Incident_ID
AND csn10.Note_Type_Code  = 'CS_RESOLUTION'
;

-- Cursor to retrieve where INTERFACE_TO_OE_FLAG = 'Y'
-- and AFTER_WARRANTY_COST equals *ZERO
CURSOR cur_1500
IS
SELECT
    csi.Org_ID
  , csi.Incident_ID
  , csi.Incident_Number
  , csc.INTERFACE_TO_OE_FLAG
  , csc.PARTY_ID
  , csc.ACCOUNT_ID
  , csc.LINE_NUMBER
  , csc.INVENTORY_ITEM_ID
  , csc.SERIAL_NUMBER
  , csc.ORDER_HEADER_ID
  , csc.ORDER_LINE_ID
  , csc.Object_Version_Number
  , csc.ESTIMATE_DETAIL_ID
  , csc.CREATION_DATE
  , csc.AFTER_WARRANTY_COST
FROM
    CS_SR_Incidents_V           csi
  , CS_CHARGE_DETAILS_V         csc
WHERE
    csi.Org_ID                = p_Org_ID
AND csi.Incident_ID           = p_Incident_ID
AND csi.Incident_ID           = csc.Incident_ID
--AND csc.AFTER_WARRANTY_COST   = 0
AND csc.INTERFACE_TO_OE_FLAG  = 'Y'
ORDER BY
    csi.Org_ID
  , csi.Incident_ID
  , csc.LINE_NUMBER
;

BEGIN

   l_Error_Message := ('Entering EDITS_POST_SR_WITHOUT_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Incident_Number, l_Debrief_Number, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR, l_Debrief_Exsits_For_SR, l_Error_Debrief_SR
   l_Incident_Number           := NULL;
   l_Debrief_Number            := NULL;
   l_Task_Status_SR            := NULL;
   l_Assignment_Task_Status_SR := NULL;
   l_Debrief_Status_SR         := NULL;
   l_Debrief_Exsits_For_SR     := NULL;
   l_Error_Debrief_SR          := NULL;

   -- Cursor for Debrief (Service Request)
   OPEN cur_1220;
   FETCH cur_1220 INTO l_Incident_Number, l_Debrief_Number, l_Task_Status_SR, l_Assignment_Task_Status_SR, l_Debrief_Status_SR;
   IF cur_1220%FOUND THEN
      l_Debrief_Exsits_For_SR := 'Y';
   ELSE
      l_Debrief_Exsits_For_SR := 'N';
   END IF;
   CLOSE cur_1220;

   IF (l_Debrief_Exsits_For_SR = 'Y') THEN
      IF (UPPER(l_Debrief_Status_SR) = 'COMPLETED W/ERRORS') THEN
         l_Error_Debrief_SR := 'Y';
         l_Error_Message    := ('Debrief exists with Status: ' || 'COMPLETED W/ERRORS ' || 'for Service Request#: ' || l_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      END IF;
   END IF;

   -- Initialize
   l_IncProbCode1            := NULL;
   l_IncProbCode2            := NULL;
   l_IncProbCode3            := NULL;
   l_IncProbCode4            := NULL;
   l_IncProbCode5            := NULL;
   l_IncResCode1             := NULL;
   l_IncResCode2             := NULL;
   l_IncResCode3             := NULL;
   l_IncResCode4             := NULL;
   l_IncResCode5             := NULL;
   l_PIR_REVIEW              := NULL;
   l_PROCESS_PHASE           := NULL;
   l_DEATH                   := NULL;
   l_POTENTIAL_INJURY        := NULL;
   l_HIGH_RISK_COMPLAINT     := NULL;
   l_HOSPITALIZATION         := NULL;
   l_Incident_ID_SR          := NULL;
   l_Incident_Number_SR      := NULL;
   l_Inventory_Item_ID       := NULL;
   l_Incident_Type_ID        := NULL;
   l_Problem_Code            := NULL;
   l_Resolution_Code         := NULL;

   -- Service Repair Readings/Observations
   OPEN cur_1240;
   FETCH cur_1240 INTO l_IncProbCode1, l_IncProbCode2, l_IncProbCode3, l_IncProbCode4, l_IncProbCode5,
                       l_IncResCode1, l_IncResCode2, l_IncResCode3, l_IncResCode4, l_IncResCode5, 
                       l_PIR_REVIEW, l_PROCESS_PHASE, l_DEATH, l_POTENTIAL_INJURY, l_HIGH_RISK_COMPLAINT, l_HOSPITALIZATION,
                       l_Incident_ID_SR, l_Incident_Number_SR, l_Inventory_Item_ID, l_Incident_Type_ID, l_Problem_Code, l_Resolution_Code;
   CLOSE cur_1240;

   -- Initialize l_PIR_TEXT
   l_PIR_TEXT := NULL;

   -- First, check to ensure Problem Codes and Resolution Codes are populated correctly
   l_PIR_TEXT := XXHA_PIR_FF_VALIDATE( l_Incident_ID_SR
                                     , l_Incident_Number_SR
                                     , l_Inventory_Item_ID
                                     , l_Incident_Type_ID
                                     , l_Problem_Code
                                     , l_Resolution_Code
                                     , l_IncProbCode1
                                     , l_IncProbCode2
                                     , l_IncProbCode3
                                     , l_IncProbCode4
                                     , l_IncProbCode5
                                     , l_IncResCode1
                                     , l_IncResCode2
                                     , l_IncResCode3
                                     , l_IncResCode4
                                     , l_IncResCode5);

   l_Error_Message := 'PIR TEXT: ' || RTRIM(l_PIR_TEXT);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_Error_Problem_Codes_Pop
   l_Error_Problem_Codes_Pop := NULL;
   l_Error_PIR_REVIEW_ASSOC  := NULL;

   IF RTRIM(UPPER(l_PIR_TEXT)) <> 'NOERROR' THEN
      l_Error_Problem_Codes_Pop := 'Y';
      l_Error_Message           := RTRIM(l_PIR_TEXT);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      l_Error_Message           := ('Problem Codes and Resolution Codes are not populated correctly for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   ELSE
      l_Error_Message := RTRIM(l_PIR_TEXT);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;

   -- Next, check that Problem_Code and Resolution_Code are populated
   IF (l_Problem_Code IS NULL) THEN
      l_Error_Problem_Codes_Pop := 'Y';
      l_Error_Message           := ('Problem Code is not populated correctly for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;
   IF (l_Resolution_Code IS NULL) THEN
      l_Error_Problem_Codes_Pop := 'Y';
      l_Error_Message           := ('Resolution Code is not populated correctly for Service Request#: ' || p_Incident_Number);
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Finally, check if PIR Review is 'Y' or 'M'.  If so, ensure associated values are populated correctly
   IF (NVL(l_PIR_REVIEW, 'N') = 'Y') OR (NVL(l_PIR_REVIEW, 'N') = 'M') THEN
      IF (l_PROCESS_PHASE IS NULL) OR (l_DEATH IS NULL) OR (l_POTENTIAL_INJURY IS NULL) OR (l_HIGH_RISK_COMPLAINT IS NULL) OR (l_HOSPITALIZATION IS NULL) THEN
         l_Error_PIR_REVIEW_ASSOC := 'Y';
         l_Error_Message          := ('Associated PIR fields are not populated correctly for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
      END IF;
   END IF;

   -- Initialize l_Count, l_SR_Has_Tasks, l_Error_SR_Tasks, l_Error_SR_Tasks_Status
   l_Count                 := 0;
   l_SR_Has_Tasks          := NULL;
   l_Error_SR_Tasks        := NULL;
   l_Error_SR_Tasks_Status := NULL;

   -- Check if tasks exist for Service Request
   OPEN cur_1260;
   FETCH cur_1260 INTO l_Count;
   IF (l_Count = 0) THEN
      l_Error_SR_Tasks := 'Y';
      l_SR_Has_Tasks   := 'N';
      l_Error_Message  := 'There are no tasks associated with Service Request: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   ELSE
      l_SR_Has_Tasks  := 'Y';
      l_Error_Message := 'There are tasks associated with Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
   END IF;
   CLOSE cur_1260;

   -- Initialize l_CONTEXT_VALUE
   l_CONTEXT_VALUE := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta420 IN cur_1280
      LOOP
         -- If l_CONTEXT_VALUE contains a NULL Value, set to '<NO ENTRY>'
         l_CONTEXT_VALUE := NVL(dta420.CONTEXT_VALUE, '<NO ENTRY>');
         l_Error_Message := 'Service Request Task additional information-CONTEXT_VALUE for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number: ' || dta420.task_number;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If any task is NOT IN ('Completed', 'Closed', 'Cancelled') then Error the record
         IF (UPPER(dta420.TASK_STATUS) NOT IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_Error_Message         := ('Task(s) associated with Service Request has status other than Completed, Closed or Cancelled: ' || dta420.TASK_STATUS || ', Task Number: ' || dta420.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            l_Error_Message := ('Task associated with Service Request has status: ' || dta420.TASK_STATUS || ', Task Number: ' || dta420.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END IF;
      END LOOP;
   END IF;

   -- Initialize l_SR_DFF_TAI_Error, l_CONTEXT_VALUE
   l_SR_DFF_TAI_Error := 'N';
   l_CONTEXT_VALUE    := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta420 IN cur_1280
      LOOP

         -- If CONTEXT_VALUE contains a NULL Value, set Error
         IF (UPPER(NVL(dta420.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>') THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_CONTEXT_VALUE         := NVL(dta420.CONTEXT_VALUE, '<NO ENTRY>');
            l_Error_Message         := 'Service Request Task additional information-CONTEXT_VALUE IS NOT ENTERED for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number' || dta420.task_number;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            -- If No Entries required (l_CONTEXT_VALUE = 'NONE')
            IF (UPPER(dta420.CONTEXT_VALUE) <> 'NONE') THEN
            -- If the Task Status not equal to 'CANCELLED' (Attributes are not mandatory when 'CANCELLED')
            --IF (UPPER(dta420.TASK_STATUS) <> 'CANCELLED') THEN

               -- Perform Service Request Readings/Observations  (Tasks additional information)
               FOR dta440 IN cur_1340
               LOOP
                  -- Check DFF's against Service Request Readings/Observations for required entries
                  IF (dta440.Context_Value IS NOT NULL) THEN
                     FOR dta460 IN cur_1360 (dta440.Context_Value)
                     LOOP
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE1') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute1 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute1/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE2') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute2 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute2/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE3') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute3 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute3/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE4') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute4 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute4/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE5') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute5 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute5/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE6') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute6 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute6/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE7') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute7 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute7/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE8') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute8 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute8/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE9') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute9 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute9/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE10') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute10 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute10/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE11') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute11 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute11/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE12') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute12 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute12/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE13') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute13 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute13/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE14') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute14 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute14/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta460.COLUMN_NAME = 'ATTRIBUTE15') AND (dta460.ENTRY_REQUIRED = 'Y') AND (dta440.Attribute15 IS NULL) THEN
                           l_SR_DFF_TAI_Error := 'Y';
                           l_Error_Message := 'Attribute15/Service Request Task additional information: ' || dta460.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta440.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                     END LOOP; -- FOR dta460 IN cur_1360 (dta440.Context_Value)
                  END IF; -- IF (dta440.Context_Value IS NOT NULL)
               END LOOP; -- FOR dta440 IN cur_1340
            --END IF; -- IF (UPPER(dta420.TASK_STATUS) <> 'CANCELLED')
            END IF; -- IF (UPPER(dta420.CONTEXT_VALUE) <> 'NONE')
         END IF; -- IF UPPER(NVL(dta420.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>'
      END LOOP; -- FOR dta420 IN cur_1280
   END IF; -- IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN

   -- Initialize l_CONTEXT_VALUE
   l_CONTEXT_VALUE := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta470 IN cur_1380
      LOOP
         -- If l_CONTEXT_VALUE contains a NULL Value, set to '<NO ENTRY>'
         l_CONTEXT_VALUE := NVL(dta470.CONTEXT_VALUE, '<NO ENTRY>');
         l_Error_Message := 'Service Request Task additional information-CONTEXT_VALUE for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number: ' || dta470.task_number;
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

         -- If any task is NOT IN ('Completed', 'Closed', 'Cancelled') then Error the record
         IF (UPPER(dta470.TASK_STATUS) NOT IN ('COMPLETED', 'CLOSED', 'CANCELLED')) THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_Error_Message         := ('Task(s) associated with Service Request has status other than Completed, Closed or Cancelled: ' || dta470.TASK_STATUS || ', Task Number: ' || dta470.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            l_Error_Message := ('Task associated with Service Request has status: ' || dta470.TASK_STATUS || ', Task Number: ' || dta470.task_number);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END IF;
      END LOOP;
   END IF;

   -- Initialize l_SR_DFF_TAAI_Error, l_CONTEXT_VALUE
   l_SR_DFF_TAAI_Error := 'N';
   l_CONTEXT_VALUE     := NULL;

   -- Only check values if the SR has tasks
   IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN
      FOR dta470 IN cur_1380
      LOOP

         -- If CONTEXT_VALUE contains a NULL Value, set Error
         IF (UPPER(NVL(dta470.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>') THEN
            l_Error_SR_Tasks_Status := 'Y';
            l_CONTEXT_VALUE         := NVL(dta470.CONTEXT_VALUE, '<NO ENTRY>');
            l_Error_Message         := 'Service Request Task assignment additional information-CONTEXT_VALUE IS NOT ENTERED for Incident#: ' || p_Incident_Number || ' CONTEXT_VALUE: ' || l_CONTEXT_VALUE || ', Task Number' || dta470.task_number;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         ELSE
            -- If No Entries required (l_CONTEXT_VALUE = 'NONE')
            IF (UPPER(dta470.CONTEXT_VALUE) <> 'NONE') THEN
            -- If the Tasks Status not equal to 'CANCELLED' then perform checks
            IF (UPPER(dta470.TASK_STATUS) <> 'CANCELLED') THEN

               l_Error_Message := 'Task associated with Service Request has status: '  || dta470.TASK_STATUS;
               WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

               -- Perform Service Request Readings/Observations (Task assignment additional information)
               FOR dta480 IN cur_1420
               LOOP
                  -- Check DFF's against Service Request Readings/Observations for required entries
                  IF (dta480.Context_Value IS NOT NULL) THEN
                     FOR dta500 IN cur_1440 (dta480.Context_Value)
                     LOOP
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE1') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute1 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute1/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE2') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute2 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute2/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE3') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute3 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute3/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE4') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute4 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute4/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE5') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute5 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute5/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE6') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute6 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute6/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE7') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute7 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute7/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE8') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute8 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute8/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE9') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute9 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute9/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE10') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute10 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute10/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE11') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute11 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute11/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE12') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute12 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute12/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE13') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute13 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute13/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE14') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute14 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute14/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                        IF (dta500.COLUMN_NAME = 'ATTRIBUTE15') AND (dta500.ENTRY_REQUIRED = 'Y') AND (dta480.Attribute15 IS NULL) THEN
                           l_SR_DFF_TAAI_Error := 'Y';
                           l_Error_Message := 'Attribute15/Service Request Task assignment additional information: ' || dta500.COLUMN_DESCRIPTION || ' requires entry for Service Request: ' || dta480.Incident_Number;
                           WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
                        END IF;
                     END LOOP; -- FOR dta500 IN cur_1440 (dta480.Context_Value)
                  END IF; -- IF (dta480.Context_Value IS NOT NULL)
               END LOOP; -- FOR dta480 IN cur_1420
            END IF; -- IF (UPPER(dta470.TASK_STATUS) <> 'CANCELLED')
            END IF; -- IF (UPPER(dta470.CONTEXT_VALUE) <> 'NONE')
         END IF; -- IF (UPPER(NVL(dta470.CONTEXT_VALUE, '<NO ENTRY>')) = '<NO ENTRY>'
      END LOOP; -- FOR dta470 IN cur_1380
   END IF; -- IF NVL(l_SR_Has_Tasks, 'N') = 'Y' THEN

   -- Initialize l_Count
   l_Count                      := 0;
   l_Error_SR_Unsubmitted       := NULL;
   l_Error_Resolution_Note_Type := NULL;

   -- Cursor to determine if there are any un-submitted charges pending
   OPEN cur_1460;
   FETCH cur_1460 INTO l_Count;
   CLOSE cur_1460;

   IF (l_Count > 0) THEN
      l_Error_SR_Unsubmitted := 'Y';
      l_Error_Message        := 'There are un-submitted charges pending for Service Request#: ' || l_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Initialize l_Count
   l_Count := 0;

   -- Cursor to determine if at least one Note Type 'Resolution' exists for Service Request#
   OPEN cur_1480;
   FETCH cur_1480 INTO l_Count;
   CLOSE cur_1480;

   IF (l_Count = 0) THEN
      l_Error_Resolution_Note_Type := 'Y';
      l_Error_Message              := 'At least one ' || '''Resolution Description''' || ' Note Type must exist for Service Request#: ' || l_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
   END IF;

   -- Initialize l_Interface_To_OE_Flag
   l_Interface_To_OE_Flag := NULL;

   -- Cursor to retrieve where INTERFACE_TO_OE_FLAG = 'Y'
   FOR dta510 IN cur_1500
   LOOP
      IF dta510.INTERFACE_TO_OE_FLAG = 'Y' THEN
         IF g_Process_Type = 'U' THEN
            l_Interface_To_OE_Flag := 'N';
            l_Error_Message := ('The Interface To OE Flag is checked for Service Request#: ' || p_Incident_Number || ', Line Nbr: ' || dta510.LINE_NUMBER);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         ELSE
            l_Interface_To_OE_Flag := 'N';
            l_Error_Message := ('The Interface To OE Flag is checked for Service Request#: ' || p_Incident_Number || ', Line Nbr: ' || dta510.LINE_NUMBER);
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END IF;
      END IF;
   END LOOP;

   -- Send back Output Error Parameter
   IF (NVL(l_Error_Debrief_SR, 'N') = 'Y')       OR (NVL(l_Error_Problem_Codes_Pop, 'N') = 'Y')   OR (NVL(l_Error_PIR_REVIEW, 'N') = 'Y')           OR 
      (NVL(l_Error_PIR_REVIEW_ASSOC, 'N') = 'Y') OR (NVL(l_Error_Problem_Codes_Entry, 'N') = 'Y') OR (NVL(l_Error_SR_Tasks, 'N') = 'Y')             OR
      (NVL(l_Error_SR_Tasks_Status, 'N') = 'Y')  OR (NVL(l_Error_SR_Unsubmitted, 'N') = 'Y')      OR (NVL(l_Error_Resolution_Note_Type, 'N') = 'Y') OR
      (NVL(l_SR_DFF_TAI_Error, 'N') = 'Y')       OR (NVL(l_SR_DFF_TAAI_Error, 'N') = 'Y')         OR (NVL(l_Interface_To_OE_Flag, 'N') = 'Y') THEN
      P_EDITS_POST_SR_WITHOUT_DR := 'Y';
   ELSE
      P_EDITS_POST_SR_WITHOUT_DR := 'N';
   END IF;

   l_Error_Message := ('Exiting EDITS_POST_SR_WITHOUT_DR for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END EDITS_POST_SR_WITHOUT_DR;

--------------------------------------------------------------------------------
-- CLOSE_SERVICE_REQUEST

PROCEDURE CLOSE_SERVICE_REQUEST(p_Org_ID                   IN  NUMBER
                              , p_Incident_ID              IN  NUMBER
                              , p_Incident_Number          IN  VARCHAR2
                              , P_CLOSE_SERVICE_REQUEST    OUT VARCHAR2
) IS

l_API_Msg_Count                   NUMBER                                        := 0;
l_API_Msg_Index_Out               NUMBER                                        := 0;
l_Interaction_ID                  NUMBER                                        := 0;
l_API_Msg_Data                    VARCHAR2(2000)                                := NULL;
l_API_Return_Status               VARCHAR2(2000)                                := NULL;

l_API_Error                       XXHA_SERV_REQ_CLOSE_HDR.Errors_Exist%TYPE     := NULL;
l_Error_Message                   XXHA_SERV_REQ_CLOSE_DTL.Error_Message%TYPE    := NULL;
l_Object_Version_Number           CS_SR_Incidents_V.Object_Version_Number%TYPE  := NULL;

-- Cursor to retrieve Object_Version_Number
CURSOR cur_1520
IS
SELECT
    csi.Object_Version_Number
FROM
    CS_SR_Incidents_V           csi
WHERE
    csi.Org_ID                = p_Org_ID
AND csi.Incident_ID           = p_Incident_ID
;

BEGIN

   l_Error_Message := ('Entering CLOSE_SERVICE_REQUEST for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

   -- Initialize l_API_Error
   l_API_Error := NULL;

   -- Reset Context back to Original Information
   FND_GLOBAL.APPS_INITIALIZE(g_Current_User_ID, g_Current_Responsibility_ID, g_Current_Resp_Appl_ID);
   MO_GLOBAL.INIT('CSR');

   -- Initialize l_Object_Version_Number
   l_Object_Version_Number := NULL;

   OPEN cur_1520;
   FETCH cur_1520 INTO l_Object_Version_Number;
   CLOSE cur_1520;

   BEGIN

      -- Call API
      CS_ServiceRequest_PUB.Update_Status(
        p_api_version                => 2.0
      , p_init_msg_list              => FND_API.G_FALSE
      , p_commit                     => FND_API.G_FALSE
      , x_return_status              => l_API_Return_Status
      , x_msg_count                  => l_API_Msg_Count
      , x_msg_data                   => l_API_Msg_Data
      , p_resp_appl_id               => g_Current_Resp_Appl_ID
      , p_resp_id                    => g_Current_Responsibility_ID
      , p_user_id                    => g_Current_User_ID
      , p_login_id                   => g_Current_User_ID
      , p_request_id                 => p_Incident_ID
      , p_request_number             => NULL
      , p_Object_Version_Number      => l_Object_Version_Number
      , p_status_id                  => 2                                       -- 1=Open, 2=Closed
      , p_status                     => NULL
      , p_closed_date                => SYSDATE
      , p_audit_comments             => NULL
      , p_called_by_workflow         => FND_API.G_FALSE
      , p_workflow_process_id        => NULL
      , p_comments                   => NULL
      , p_public_comment_flag        => NULL
      , p_validate_sr_closure        => 'N'
      , p_auto_close_child_entities  => 'N'
      , x_interaction_id             => l_interaction_id
      );

      l_Error_Message := ('Return_Status: ' || (l_api_return_status || ', Message Data: ' || l_api_msg_data));
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

      -- If successful, was there a message sent back?
      IF l_api_return_status = FND_API.G_RET_STS_SUCCESS THEN
         COMMIT;
         l_API_Error     := 'N';
         l_Error_Message := ('Closure performed for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_INF, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;

      -- If unsuccessful, was there a message sent back?
      ELSIF l_api_return_status <> FND_API.G_RET_STS_SUCCESS THEN
         ROLLBACK;
         l_API_Error     := 'Y';
         l_Error_Message := ('Closure was not performed for Service Request#: ' || p_Incident_Number);
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);
         l_Error_Message := ('ROLLBACK performed');
         WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         FOR L_INDEX IN 1 .. FND_MSG_PUB.Count_Msg
         LOOP
            FND_MSG_PUB.GET(
              P_MSG_INDEX      => L_INDEX
            , P_ENCODED        => 'F'
            , P_DATA           => l_Error_Message
            , P_MSG_INDEX_OUT  => l_API_Msg_Index_Out);
            IF l_Error_Message IS NULL THEN
               EXIT;
            END IF;
            WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);
         END LOOP;
      END IF;

   -- Catch any Errors
   EXCEPTION WHEN OTHERS THEN
      l_API_Error     := 'Y';
      l_Error_Message := 'Exception occurred for API: CS_ServiceRequest_PUB.Update_Status (Service Request) for Service Request#: ' || p_Incident_Number;
      WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_ERR, l_Error_Message);

   END;

   -- Send back Output Error Parameter
   P_CLOSE_SERVICE_REQUEST := NVL(l_API_Error, 'N');

   l_Error_Message := ('Exiting CLOSE_SERVICE_REQUEST for Service Request#: ' || p_Incident_Number);
   WRITE_DETAIL(p_Org_ID, p_Incident_ID, NULL, g_Error_Type_DBG, l_Error_Message);

END CLOSE_SERVICE_REQUEST;

--------------------------------------------------------------------------------
-- REPORT_SUBMISSION

PROCEDURE REPORT_SUBMISSION(P_Session_ID                   IN  NUMBER
                          , P_Current_User_ID              IN  NUMBER
                          , P_CONCURRENT_PGM               IN  VARCHAR2
                          , P_TEMPLATE_CODE                IN  VARCHAR2
                          , P_Debug                        IN  VARCHAR2
                          , P_EMAIL_SERVER                 IN  VARCHAR2
                          , P_EMAIL_PORT                   IN  VARCHAR2
                          , P_TEST_EMAIL_ACCOUNT           IN  VARCHAR2
                          , P_PRODUCTION_INSTANCE_DB_NAME  IN  VARCHAR2
                          , P_Value_Set_ID_EMail           IN  NUMBER
                          , P_REPORT_PROGRAM_ID            IN  NUMBER
) IS

l_Record_Count_Y                  NUMBER                                        := 0;
l_Record_Count_N                  NUMBER                                        := 0;
l_Record_Count_X                  NUMBER                                        := 0;
l_errbuf                          VARCHAR2(2000)                                := NULL;
l_retcode                         VARCHAR2(2000)                                := NULL;

-- Cursor to retrieve record counts based upon the value in XXHA_SERV_REQ_CLOSE_HDR.ERRORS_EXIST and Org_ID
CURSOR cur_1540 (C_ERRORS_EXIST XXHA_SERV_REQ_CLOSE_HDR.ERRORS_EXIST%TYPE, C_ORG_ID XXHA_SERV_REQ_CLOSE_HDR.ORG_ID%TYPE)
IS
SELECT
    NVL(COUNT(*),0)
FROM
    XXHA_SERV_REQ_CLOSE_HDR   HDR
WHERE
    HDR.Session_ID          = P_Session_ID
AND HDR.CREATED_BY          = P_Current_User_ID
AND HDR.ERRORS_EXIST        = C_ERRORS_EXIST
AND HDR.ORG_ID              = C_Org_ID
;

-- Cursor to retrieve records for each Org
CURSOR cur_1550
IS
SELECT DISTINCT
    HDR.ORG_ID              "ORG_ID"
  , HOU.NAME                "ORG_NAME"
  , HDR.SESSION_ID
  , HDR.Created_BY
  , HDR.PROCESS_TYPE
  , HDR.ERRORS_EXIST
  , HDR.CREATION_DATE
FROM
    XXHA_SERV_REQ_CLOSE_HDR  HDR
  , HR_OPERATING_UNITS       HOU
WHERE
    HDR.Session_ID         = P_Session_ID
AND HDR.CREATED_BY         = P_Current_User_ID
AND HDR.ORG_ID             = hou.Organization_ID(+)
;

BEGIN

   --FND_FILE.PUT_LINE(FND_FILE.LOG, ' ');

   -- Cursor to read each Org to determine if we need to create dummy records for each type (Errors, No Errors, Excluded)
   FOR dta520 in cur_1550
   LOOP

         -- Initialize l_Record_Count_N
         l_Record_Count_N := 0;

         -- Determine if any non error records exist
         OPEN cur_1540('N',dta520.Org_ID);
         FETCH cur_1540 INTO l_Record_Count_N;
         CLOSE cur_1540;
         IF (l_Record_Count_N = 0) THEN
            -- Write dummy detail/header record
            INSERT INTO XXHA_SERV_REQ_CLOSE_DTL(Org_ID, Incident_ID, ERROR_TYPE, SESSION_ID, Created_BY, PROCESS_TYPE, CREATION_DATE, SEQUENCE_NBR, ERROR_MESSAGE)   VALUES(dta520.Org_ID, 1, 'INF', dta520.SESSION_ID, dta520.Created_BY, dta520.PROCESS_TYPE, dta520.CREATION_DATE, 1, 'No Processed Records Exist');
            INSERT INTO XXHA_SERV_REQ_CLOSE_HDR(Org_ID, INCIDENT_ID, ERRORS_EXIST, SESSION_ID, Created_BY, PROCESS_TYPE, CREATION_DATE, SEQUENCE_NBR) VALUES(dta520.Org_ID, 1, 'N', dta520.SESSION_ID, dta520.Created_BY, dta520.PROCESS_TYPE, dta520.CREATION_DATE, 1);
         END IF;

         -- Initialize l_Record_Count_Y
         l_Record_Count_Y := 0;

         -- Determine if any error records exist
         OPEN cur_1540('Y',dta520.Org_ID);
         FETCH cur_1540 INTO l_Record_Count_Y;
         CLOSE cur_1540;
         IF (l_Record_Count_Y = 0) THEN
            -- Write dummy detail/header record
            INSERT INTO XXHA_SERV_REQ_CLOSE_DTL(Org_ID, Incident_ID, ERROR_TYPE, SESSION_ID, Created_BY, PROCESS_TYPE, CREATION_DATE, SEQUENCE_NBR, ERROR_MESSAGE)   VALUES(dta520.Org_ID, 2, 'INF', dta520.SESSION_ID, dta520.Created_BY, dta520.PROCESS_TYPE, dta520.CREATION_DATE, 1, 'No Error Records Exist');
            INSERT INTO XXHA_SERV_REQ_CLOSE_HDR(Org_ID, INCIDENT_ID, ERRORS_EXIST, SESSION_ID, Created_BY, PROCESS_TYPE, CREATION_DATE, SEQUENCE_NBR) VALUES(dta520.Org_ID, 2, 'Y', dta520.SESSION_ID, dta520.Created_BY, dta520.PROCESS_TYPE, dta520.CREATION_DATE, 1);
         END IF;

         -- Initialize l_Record_Count_X
         l_Record_Count_X := 0;

         -- Determine if any excluded records exist
         OPEN cur_1540('X',dta520.Org_ID);
         FETCH cur_1540 INTO l_Record_Count_X;
         CLOSE cur_1540;
         IF (l_Record_Count_X = 0) THEN
            -- Write dummy detail/header record
            INSERT INTO XXHA_SERV_REQ_CLOSE_DTL(Org_ID, Incident_ID, ERROR_TYPE, SESSION_ID, Created_BY, PROCESS_TYPE, CREATION_DATE, SEQUENCE_NBR, ERROR_MESSAGE)   VALUES(dta520.Org_ID, 3, 'INF', dta520.SESSION_ID, dta520.Created_BY, dta520.PROCESS_TYPE, dta520.CREATION_DATE, 1, 'No Excluded Records Exist');
            INSERT INTO XXHA_SERV_REQ_CLOSE_HDR(Org_ID, INCIDENT_ID, ERRORS_EXIST, SESSION_ID, Created_BY, PROCESS_TYPE, CREATION_DATE, SEQUENCE_NBR) VALUES(dta520.Org_ID, 3, 'X', dta520.SESSION_ID, dta520.Created_BY, dta520.PROCESS_TYPE, dta520.CREATION_DATE, 1);
         END IF;

   END LOOP;

   -- Submit Report
   XXHA_SERV_REQ_CLOSE_SUBMIT_PKG.Process_PGM(l_errbuf, l_retcode, p_Session_ID, P_CONCURRENT_PGM, P_TEMPLATE_CODE, P_Debug, P_EMAIL_SERVER, P_EMAIL_PORT, P_TEST_EMAIL_ACCOUNT, P_PRODUCTION_INSTANCE_DB_NAME, P_Value_Set_ID_EMail, P_REPORT_PROGRAM_ID);

END REPORT_SUBMISSION;

--------------------------------------------------------------------------------
-- WRITE_HEADER

PROCEDURE WRITE_HEADER(p_Org_ID                            IN  NUMBER
                     , p_Incident_ID                       IN  NUMBER
                     , p_Incident_Number                   IN  VARCHAR2
                     , p_Incident_Status_ID                IN  NUMBER
                     , p_Status_Code                       IN  VARCHAR2
                     , p_Closed_Flag                       IN  VARCHAR2
                     , p_Incident_Type_ID                  IN  NUMBER
                     , p_Incident_Type                     IN  VARCHAR2
                     , p_Inventory_Item_ID                 IN  NUMBER
                     , p_Inventory_Item_Number             IN  VARCHAR2
                     , p_Inventory_Item_Serial_Number      IN  VARCHAR2
                     , p_Contract_ID                       IN  NUMBER
                     , p_Contract_Number                   IN  VARCHAR2
                     , p_Country                           IN  VARCHAR2
                     , p_Errors_Exist                      IN  VARCHAR2
) IS

l_Item_Serial_Number              csi_item_instances.serial_number%TYPE         := NULL;
l_Org_ID                          CS_SR_Incidents_V.Org_ID%TYPE                 := NULL;
l_ORG_NAME                        Hr_Operating_Units.name%TYPE                  := NULL;
l_Inventory_Item_ID               CS_SR_Incidents_V.Inventory_Item_ID%TYPE      := NULL;
l_Inventory_Item_Number           mtl_system_items_b.Segment1%TYPE              := NULL;
l_Serial_Number                   csi_item_instances.Serial_Number%TYPE         := NULL;
l_Incident_Date                   CS_SR_Incidents_V.Incident_Date%TYPE          := NULL;
l_Incident_ID                     CS_SR_Incidents_V.Incident_ID%TYPE            := NULL;
l_Incident_Number                 CS_SR_Incidents_V.Incident_Number%TYPE        := NULL;
l_Incident_Status_ID              CS_SR_Incidents_V.Incident_Status_ID%TYPE     := NULL;
l_Status_Code                     CS_SR_Incidents_V.Status_Code%TYPE            := NULL;
l_closed_Flag                     CS_SR_Incidents_V.closed_Flag%TYPE            := NULL;
l_Incident_Type_ID                CS_SR_Incidents_V.Incident_Type_ID%TYPE       := NULL;
l_Contract_Number                 CS_SR_Incidents_V.Contract_Number%TYPE        := NULL;
l_Contract_ID                     CS_SR_Incidents_V.Contract_ID%TYPE            := NULL;
l_country                         hz_locations.country%TYPE                     := NULL;
l_INCIDENT_TYPE                   cs_incident_types_vl.name%TYPE                := NULL; 
l_Attribute2                      HR_ORGANIZATION_INFORMATION_V.Attribute2%TYPE := NULL;
l_Attribute3                      HR_ORGANIZATION_INFORMATION_V.Attribute3%TYPE := NULL;
l_CONTRACT_TYPE_ITEM              mtl_system_items_b.segment1%TYPE              := NULL;

-- Cursor to retrieve Service Request Data
CURSOR cur_1560
IS
SELECT
    csi.Org_ID
  , hou.name                           ORG_NAME 
  , csi.Inventory_Item_ID
  , itm.Segment1
  , ccs.Serial_Number
  , csi.Incident_Date
  , csi.Incident_ID
  , csi.Incident_Number
  , csi.Incident_Status_ID
  , csi.Status_Code
  , csi.closed_Flag
  , csi.Incident_Type_ID
  , csi.Contract_Number
  , csi.Contract_ID
  , (DECODE(csi.incident_location_type, 'HZ_PARTY_SITE', 
           (SELECT hl.country  FROM apps.hz_party_sites hps
                                  , apps.hz_locations   hl
                              WHERE hps.party_site_id = csi.incident_location_id
                                AND hl.location_id    = hps.location_id),
                                        'HZ_LOCATION',
           (SELECT hl1.country FROM apps.hz_locations   hl1
                              WHERE hl1.location_id   = csi.incident_location_id), 
                                         NULL)) Incident_country
  , citv.name                          INCIDENT_TYPE
  , hri.Attribute2
  , hri.Attribute3
  , msib_svc.segment1                  CONTRACT_TYPE_ITEM
FROM
    CS_SR_Incidents_V                  csi 
  , csi_item_instances                 ccs
  , mtl_system_items_b                 itm
  , cs_incident_types_vl               citv
  , Hr_Operating_Units                 hou
  , okc_k_headers_all_b                okhab
  , okc_k_lines_b                      oklb
  , okc_k_items                        oki
  , mtl_system_items_b                 msib_svc
  , (SELECT
           hou.organization_ID             Org_ID
         , hroi.Attribute2
         , hroi.Attribute3
      FROM
           Hr_Operating_Units              hou
         , HR_ORGANIZATION_INFORMATION_V   hroi
     WHERE
           HOU.ORGANIZATION_ID           = hroi.ORGANIZATION_ID
       AND org_information_context       = 'Operating Unit Information'
       AND hroi.Attribute_Category(+)    = 'Operating Unit'
       AND UPPER(hroi.Attribute1)        = UPPER(g_Operating_Unit_Group)) hri
  , (SELECT
           VL.FLEX_VALUE
      FROM
           fnd_flex_value_Sets         ST
         , fnd_flex_values_vl          VL
     WHERE
           ST.flex_value_set_id      = g_Value_Set_ID
       AND ST.flex_value_set_id      = VL.flex_value_set_id
       AND TRUNC(SYSDATE)            BETWEEN NVL(TRUNC(VL.Start_Date_Active),TRUNC(SYSDATE-1)) AND NVL(TRUNC(VL.End_Date_Active),TRUNC(SYSDATE+1))  
       AND NVL(VL.Enabled_Flag, 'N') = 'Y')  VLF
WHERE
    csi.Org_ID                       = p_Org_ID
AND csi.incident_ID                  = p_Incident_ID
AND csi.Org_ID                       = hou.Organization_ID
AND csi.Incident_Type_ID             = citv.Incident_Type_ID(+)
AND csi.customer_product_ID          = ccs.instance_ID(+)
AND csi.Inventory_Item_ID            = itm.Inventory_item_ID
AND itm.Organization_id              = 103
AND csi.Org_ID                       = hri.Org_ID
AND okhab.id(+)                      = csi.contract_id
AND oklb.id(+)                       = csi.contract_service_id
AND oki.cle_id(+)                    = oklb.id
AND oki.jtot_object1_code(+)         = 'OKX_SERVICE'
AND msib_svc.inventory_item_id(+)    = oki.object1_id1
AND msib_svc.organization_id(+)      = 103
AND msib_svc.segment1                = vlf.FLEX_VALUE
;

BEGIN

   -- Format the Serial Number as some serial numbers have an 'E' which Excel will try to convert (i.e. 12E074 to 1.2E+75)

   -- If record is to be excluded, we need to retrieve the data
   IF p_Errors_Exist = 'X' THEN
      OPEN cur_1560;
      FETCH cur_1560 INTO l_Org_ID, l_ORG_NAME, l_Inventory_Item_ID, l_Inventory_Item_Number, l_Serial_Number, l_Incident_Date, l_Incident_ID, l_Incident_Number, l_Incident_Status_ID, l_Status_Code, l_closed_Flag, l_Incident_Type_ID, l_Contract_Number, l_Contract_ID, l_country, l_INCIDENT_TYPE, l_Attribute2, l_Attribute3, l_CONTRACT_TYPE_ITEM;
      CLOSE cur_1560;
      l_Item_Serial_Number := (''''||l_Serial_Number);
      -- Write to table HAEMO.XXHA_SERV_REQ_CLOSE_HDR
      INSERT INTO XXHA_SERV_REQ_CLOSE_HDR
         (Org_ID, INCIDENT_ID, SERVICE_REQUEST_NUMBER, SERVICE_REQUEST_STATUS_ID, SERVICE_REQUEST_STATUS_CODE, SERVICE_REQUEST_CLOSED_FLAG, SERVICE_REQUEST_TYPE_ID, SERVICE_REQUEST_TYPE,
          INVENTORY_ITEM_ID, INVENTORY_ITEM_NUMBER, INVENTORY_ITEM_SERIAL_NUMBER, CONTRACT_ID, CONTRACT_NUMBER, COUNTRY,
          ERRORS_EXIST, SEQUENCE_NBR, SESSION_ID, PROCESS_TYPE, CREATION_DATE, CREATED_BY)
      VALUES
         (p_Org_ID, p_Incident_ID, l_Incident_Number, l_Incident_Status_ID, l_Status_Code, l_Closed_Flag, l_Incident_Type_ID, l_Incident_Type,
          l_Inventory_Item_ID, l_Inventory_Item_Number, l_Item_Serial_Number, l_Contract_ID, l_Contract_Number, l_Country,
          NVL(p_ERRORS_EXIST, 'N'), g_Sequence_Nbr_HDR, g_Session_ID, g_Process_Type, g_sysdate, g_Current_User_ID);
   ELSE
      -- We have all the data being sent in parameters, write to table HAEMO.XXHA_SERV_REQ_CLOSE_HDR
      l_Item_Serial_Number := (''''||p_Inventory_Item_Serial_Number);
      INSERT INTO XXHA_SERV_REQ_CLOSE_HDR
         (Org_ID, INCIDENT_ID, SERVICE_REQUEST_NUMBER, SERVICE_REQUEST_STATUS_ID, SERVICE_REQUEST_STATUS_CODE, SERVICE_REQUEST_CLOSED_FLAG, SERVICE_REQUEST_TYPE_ID, SERVICE_REQUEST_TYPE,
          INVENTORY_ITEM_ID, INVENTORY_ITEM_NUMBER, INVENTORY_ITEM_SERIAL_NUMBER, CONTRACT_ID, CONTRACT_NUMBER, COUNTRY,
          ERRORS_EXIST, SEQUENCE_NBR, SESSION_ID, PROCESS_TYPE, CREATION_DATE, CREATED_BY)
      VALUES
         (p_Org_ID, p_Incident_ID, p_Incident_Number, p_Incident_Status_ID, p_Status_Code, p_Closed_Flag, p_Incident_Type_ID, p_Incident_Type,
          p_Inventory_Item_ID, p_Inventory_Item_Number, l_Item_Serial_Number, p_Contract_ID, p_Contract_Number, p_Country,
          NVL(p_ERRORS_EXIST, 'N'), g_Sequence_Nbr_HDR, g_Session_ID, g_Process_Type, g_sysdate, g_Current_User_ID);
   END IF;

   -- Increment the Header Sequence Nbr
   g_Sequence_Nbr_HDR := g_Sequence_Nbr_HDR + 1;

   COMMIT;

END WRITE_HEADER;

--------------------------------------------------------------------------------
-- WRITE_DETAIL

PROCEDURE WRITE_DETAIL(p_Org_ID                            IN  NUMBER
                     , p_Incident_ID                       IN  NUMBER
                     , p_Amount                            IN  NUMBER
                     , p_Error_Type                        IN  VARCHAR2
                     , p_Error_Message                     IN  VARCHAR2
) IS

l_Sequence_Number                 XXHA_SERV_REQ_CLOSE_DTL.SEQUENCE_NBR%TYPE     := 0;
l_Process                         VARCHAR2 (01)                                 := NULL;

-- Cursor to get the last Sequence Number in the detail table for Session, Org, Incident and User
CURSOR cur_1580
IS
SELECT
    NVL(SEQUENCE_NBR,0)
FROM
    XXHA_SERV_REQ_CLOSE_DTL  DTLS
WHERE
    DTLS.Session_ID        = g_Session_ID
AND DTLS.ORG_ID            = p_Org_ID
AND DTLS.Incident_ID       = p_Incident_ID
AND DTLS.CREATED_BY        = g_Current_User_ID
ORDER BY
    SEQUENCE_NBR DESC
;

BEGIN

   -- Set default value for l_Process
   l_Process := 'Y';

   -- If not in Debug node and it's a Debug Message, ignore
   IF NVL(g_Debug,'NO') = 'NO' AND p_Error_Type = g_Error_Type_DBG THEN
      l_Process := 'N';
   END IF;

   IF l_Process = 'Y' THEN
      -- Cursor to get the last Sequence Number in the detail table for Session, Org, Incident and User
      OPEN cur_1580;
      FETCH cur_1580 INTO l_Sequence_Number;
      CLOSE cur_1580;
      -- Write to table HAEMO.XXHA_SERV_REQ_CLOSE_DTL
      INSERT INTO XXHA_SERV_REQ_CLOSE_DTL(Org_ID, Incident_ID, Error_Message, ERROR_TYPE, SESSION_ID, PROCESS_TYPE, CREATION_DATE, CREATED_BY, SEQUENCE_NBR)
      VALUES(p_Org_ID, p_Incident_ID, p_Error_Message, p_Error_Type, g_Session_ID, g_Process_Type, g_sysdate, g_Current_User_ID, (l_Sequence_Number+1));
      COMMIT;
   END IF;

END WRITE_DETAIL;

END XXHA_SERV_REQ_CLOSE_PKG;