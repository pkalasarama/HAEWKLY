CREATE OR REPLACE PACKAGE
   XXHA_ATTACH_DOCUMENTS_PK
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |                                                                   |
-- |Name         :XXHA_ATTACH_DOCUMENTS_PK                             |
-- |                                                                   |
-- |Description  :Package to attach documents for the Hedaer           |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  20-Nov-2006 Fajna K P        Initial draft version       |
-- |1.0       23-Nov-2006 Fajna K P        After Review                |
-- +===================================================================+
AS

--GlobalVariables
gn_request_id          xxha_common_errors.request_id%TYPE        := FND_GLOBAL.CONC_REQUEST_ID;   -- Concurrent Request Id of the Program
gc_program_name        VARCHAR2(1000)                            :='Attach Documents';            -- Program Name that appears in the Error Report
gc_record_identify     xxha_common_errors.record_identifier%TYPE :='Attach Documents';            -- Record identifier of staging table
gn_record_number       xxha_common_errors.record_number%TYPE;                                     -- Record_number of staging table
gc_record_identifier   xxha_common_errors.record_identifier%TYPE;                                 -- Record identifier of staging table
gc_error_code          xxha_common_errors.error_code%TYPE;                                        -- Error_code insert in common error table
gc_error_msg           xxha_common_errors.error_msg%TYPE;                                         -- Error_msg  insert in common error table
gc_comments            xxha_common_errors.comments%TYPE;                                          -- Comments   insert in common error table
gc_table_name          xxha_common_errors.table_name%TYPE;                                        -- Table name  insert in common error table
gc_attribute1          xxha_common_errors.attribute1%TYPE;                                        -- Attribute1 insert in common error table
gc_attribute2          xxha_common_errors.attribute2%TYPE;                                        -- Attribute2 insert in common error table
gc_attribute3          xxha_common_errors.attribute3%TYPE;                                        -- Attribute3 insert in common error table
gc_attribute4          xxha_common_errors.attribute4%TYPE;                                        -- Attribute4 insert in common error table
gc_attribute5          xxha_common_errors.attribute5%TYPE;                                        -- Attribute5 insert in common error table
gc_status              VARCHAR2(2);                                                               -- Variable to get status flag of data insertion in common error table
gc_operating_unit      oe_headers_iface_all.sold_from_org_id%TYPE := FND_PROFILE.VALUE('ORG_ID'); -- Variable to store the Operating Unit
gc_operating_unit_name oe_headers_iface_all.sold_from_org%TYPE;                                   -- Variable to get the Operating unit Name
gc_con_prg_shot_name   fnd_concurrent_programs.concurrent_program_name%TYPE     :='XXHA_ATTACH_DOCUMENTS';
gc_category_name       fnd_document_categories.name%TYPE          :='OE_PRINT_CATEGORY';          -- Variable to store the default Document Category
gc_entity_name         VARCHAR2(100)                              :='OE_ORDER_HEADERS';           -- Variable to store the default Entity Name
gn_user_id             fnd_user.user_id%TYPE                      := FND_GLOBAL.USER_ID;          -- Variable to store the User Id
gc_debug_flag          VARCHAR2(1);                                                               -- Variable to store Debug Status
gc_log_msg             VARCHAR2(3000);                                                            -- Variable to store Log Status

--Procedure to process attachments
PROCEDURE PROCESS_ATTACHMENTS (
                               x_err_buf       OUT VARCHAR2
                              ,x_ret_code      OUT VARCHAR2
                              ,p_debug         IN VARCHAR2
                              ,p_purge_data    IN VARCHAR2
                              );

END XXHA_ATTACH_DOCUMENTS_PK;

/


CREATE OR REPLACE PACKAGE BODY
   XXHA_ATTACH_DOCUMENTS_PK
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |                                                                   |
-- |Name         :XXHA_ATTACH_DOCUMENTS_PK                             |
-- |                                                                   |
-- |Description  :Package to attach documents for the Hedaer           |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  20-Nov-2006 Fajna K P        Initial draft version       |
-- |1.0       23-Nov-2006 Fajna K P        After Review                |
-- |                                                                   |
-- +===================================================================+
AS


-- +===================================================================+
-- | Name        :  UPDATE_RECORD_STATUS                               |
-- | Description :  Procedure to update  the status of processed       |
-- |                records                                            |
-- | Call From   :  The Procedure is called from PROCESS_SALES_ORDERS  |
-- |                Procedure                                          |
-- | Parameters  :                                                     |
-- |  IN         :  p_status_flag                                      |
-- |                p_record_id                                        |
-- |                p_request_id                                       |
-- | Returns     :  NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE UPDATE_RECORD_STATUS(
                               p_status_flag  IN      VARCHAR2
                              ,p_request_id   IN      NUMBER
                              ,p_record_id    IN      NUMBER
                              )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
      UPDATE  usbpcs_order_notes_cleaned UOC
      SET     UOC.oraclecharfld1   =   p_status_flag
             ,UOC.oracleintfld8    =   p_request_id
      WHERE   UOC.oracleidentifier =   p_record_id
      AND     UOC.notetype='O';


   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_ATTACH_DOCUMENTS_PK.UPDATE_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_RECORD_STATUS;

-- +===================================================================+
-- | Name       :   INSERT_ERROR_MSG                                   |
-- | Description:   Procedure to call xxsc_common_utilities            |
-- |                to insert errors into error table                  |
-- |                records                                            |
-- | Call From  :   The Procedure is called from INSERT_ATTACHMENTS    |
-- |                and PROCESS_ATTACHMENTS Procedures                 |
-- | Parameters :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- | Returns    :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE INSERT_ERROR_MSG
IS
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gn_request_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                            );

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_MSG. Error is: ' ||SQLERRM);
END INSERT_ERROR_MSG;


-- +===================================================================+
-- | Name            : INSERT_ATTACHMENTS                              |
-- | Description     : Procedure that calls API                        |
-- | Call From       : The Procedure is called from PROCESS_ATTACHMENTS|
-- |                   Procedure                                       |
-- | Parameters      :                                                 |
-- |  OUT            : x_err_buf                                       |
-- |                   x_ret_code                                      |
-- |                   x_error_flag                                    |
-- |                   x_document_id                                   |
-- |                   x_media_id                                      |
-- |                   x_row_id                                        |
-- |  IN             : p_pk1_value                                     |
-- |                   p_category_id                                   |
-- |                   p_debug                                         |
-- |                   p_seq_num                                       |
-- |                   p_attribute1                                    |
-- |                   p_attribute2                                    |
-- |                   p_attribute3                                    |
-- |                   p_attribute4                                    |
-- |                   p_description                                   |
-- |                                                                  |
-- | Returns         : x_ret_code                                      |
-- |                   x_err_buf                                       |
-- |                   x_error_flag                                    |
-- |                                                                   |
-- +===================================================================+
PROCEDURE INSERT_ATTACHMENTS (x_err_buf        OUT VARCHAR2
                             ,x_ret_code       OUT VARCHAR2
                             ,x_error_flag     OUT VARCHAR2
                             ,p_pk1_value      IN  VARCHAR2
                             ,p_category_id    IN  VARCHAR2
                             ,p_seq_num        IN  NUMBER
                             ,p_attribute1     IN  VARCHAR2
                             ,p_attribute2     IN  VARCHAR2
                             ,p_attribute3     IN  VARCHAR2
                             ,p_attribute4     IN  VARCHAR2
                             ,p_debug          IN  VARCHAR2
                             ,p_description    IN  VARCHAR2
                             ,x_document_id    OUT VARCHAR2
                             ,x_media_id       OUT VARCHAR2
                             ,x_row_id         OUT VARCHAR2
                             )

IS
--Declare variables
ln_attached_document_id  VARCHAR2(10);         --Variable to store the next attachment id

BEGIN
   --Selects the latest Attachment Document Id
   SELECT fnd_attached_documents_s.nextval
   INTO   ln_attached_document_id
   FROM   dual;


   --Call API to insert data into FND_ATTACHED_DOCUMENTS
   fnd_attached_documents_pkg.Insert_Row(
                                          X_Rowid                        => x_row_id
                                         ,X_attached_document_id         => ln_attached_document_id
                                         ,X_document_id                  => x_document_id
                                         ,X_creation_date                => SYSDATE
                                         ,X_created_by                   => gn_user_id
                                         ,X_last_update_date             => SYSDATE
                                         ,X_last_updated_by              => gn_user_id
                                         ,X_last_update_login            => gn_user_id
                                         ,X_seq_num                      => p_seq_num
                                         ,X_entity_name                  => gc_entity_name
                                         ,X_column1                      => NULL
                                         ,X_pk1_value                    => p_pk1_value -- Header Id of the Order Header
                                         ,X_pk2_value                    => NULL
                                         ,X_pk3_value                    => NULL
                                         ,X_pk4_value                    => NULL
                                         ,X_pk5_value                    => NULL
                                         ,X_automatically_added_flag     => 'N'
                                         ,X_request_id                   => NULL
                                         ,X_program_application_id       => NULL
                                         ,X_program_id                   => NULL
                                         ,X_program_update_date          => NULL
                                         ,X_Attribute_Category           => NULL
                                         ,X_Attribute1                   => p_attribute1
                                         ,X_Attribute2                   => p_attribute2
                                         ,X_Attribute3                   => p_attribute3
                                         ,X_Attribute4                   => p_attribute4
                                         ,X_Attribute5                   => NULL
                                         ,X_Attribute6                   => NULL
                                         ,X_Attribute7                   => NULL
                                         ,X_Attribute8                   => NULL
                                         ,X_Attribute9                   => NULL
                                         ,X_Attribute10                  => NULL
                                         ,X_Attribute11                  => NULL
                                         ,X_Attribute12                  => NULL
                                         ,X_Attribute13                  => NULL
                                         ,X_Attribute14                  => NULL
                                         ,X_Attribute15                  => NULL
                                         ,X_datatype_id                  => 2
                                         ,X_category_id                  => p_category_id
                                         ,X_security_type                => 4
                                         ,X_security_id                  => NULL
                                         ,X_publish_flag                 => 'Y'
                                         ,X_image_type                   => NULL
                                         ,X_storage_type                 => NULL
                                         ,X_usage_type                   => 'O'
                                         ,X_language                     => 'US'
                                         ,X_description                  => p_description
                                         ,X_file_name                    => NULL
                                         ,X_media_id                     => x_media_id
                                         ,X_doc_attribute_Category       => NULL
                                         ,X_doc_attribute1               => NULL
                                         ,X_doc_attribute2               => NULL
                                         ,X_doc_attribute3               => NULL
                                         ,X_doc_attribute4               => NULL
                                         ,X_doc_attribute5               => NULL
                                         ,X_doc_attribute6               => NULL
                                         ,X_doc_attribute7               => NULL
                                         ,X_doc_attribute8               => NULL
                                         ,X_doc_attribute9               => NULL
                                         ,X_doc_attribute10              => NULL
                                         ,X_doc_attribute11              => NULL
                                         ,X_doc_attribute12              => NULL
                                         ,X_doc_attribute13              => NULL
                                         ,X_doc_attribute14              => NULL
                                         ,X_doc_attribute15              => NULL
                                         ,X_create_doc                   => 'N'
                                        );

x_error_flag:='N';
EXCEPTION
WHEN OTHERS THEN
   x_error_flag:='Y';
   gc_error_code       :=   'API_ERROR';
   gc_error_msg        :=    SQLERRM;
   gc_comments         :=   'API- fnd_attached_documents_pkg.Insert_Row';
   INSERT_ERROR_MSG;
   ROLLBACK;
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_ATTACH_DOCUMENTS_PK.INSERT_ATTACHMENTS. Error is: ' ||SQLERRM);
   x_err_buf :=SQLERRM;

END INSERT_ATTACHMENTS;

-- +===================================================================+
-- | Name          : PROCESS_ATTACHMENTS                               |
-- | Description   : Procedure  to attach documents  for the header    |
-- | Call From     : This procedure is registered as Concurrent        |
-- |                 Program Executable file name                      |
-- |                                                                   |
-- | Parameters    :                                                   |
-- |  OUT          : x_err_buf                                         |
-- |                 x_ret_code                                        |
-- |  IN           : p_debug                                           |
-- |                 p_purge_data                                      |
-- | Returns       : NONE                                              |
-- |                                                                   |
-- +===================================================================+
PROCEDURE PROCESS_ATTACHMENTS (
                               x_err_buf       OUT VARCHAR2
                              ,x_ret_code      OUT VARCHAR2
                              ,p_debug         IN VARCHAR2
                              ,p_purge_data    IN VARCHAR2
                              )
IS
lc_setup_op_unit_err_flag     VARCHAR2(1):='N'; --Variable to store Operating Unit Set Up Error Flag
lc_category_setup_err_flag    VARCHAR2(1):='N'; --Variable to store Category Set Up Error Flag
lc_setup_error_flag           VARCHAR2(1):='N'; --Variable to store Set Up Error Flag
lc_header_id_err_flag         VARCHAR2(1):='N'; --Variable to store Header Id Error Flag
lc_header_id_holder_flag      VARCHAR2(1):='N'; --Variable to store Header Id Error Holder Flag
lc_api_err_flag               VARCHAR2(1):='N'; --Variable to store API Error Flag
x_error_flag                  VARCHAR2(1);      --Variable to store API Error Status
lc_error_flag                 VARCHAR2(1):='N'; --Variable to store the API Error Flag
ln_category_id                NUMBER:=0;        --Variable to store category_id
ln_header_id                  NUMBER:=0;        --Variable to store header_id
ln_note_rec_fetched           NUMBER:=0;        --Variable to store number of fetched records
ln_note_rec_processed         NUMBER:=0;        --Variable to store number of processed records
ln_note_rec_invalid           NUMBER:=0;        --Variable to store number of invalid records
ln_error_count                NUMBER:=0;        --Variable to store errored records
x_document_id                 VARCHAR2(100);    --Variable to store document Id
x_media_id                    VARCHAR2(100);    --Variable to store media Id
x_row_id                      VARCHAR2(100);    --Variable to store Row Id
ln_row_count                  NUMBER:=0;        --Variable to store Count of records API Processed

-------------------------------------------------------
--Cursor to get all the Notes at the Order Header Level
-------------------------------------------------------
CURSOR  lcu_get_order_notes(p_operating_unit VARCHAR2)
IS
SELECT  *
FROM    usbpcs_order_notes_cleaned UONC
WHERE   UONC.oraclegenuse1=p_operating_unit
AND     UONC.oraclecharfld1 IS NULL
AND     UONC.notetype='O';

--------------------------------------------------------
--Cursor to check if the Operating Unit has been defined
--------------------------------------------------------
CURSOR  lcu_chk_operating_unit(p_operating_unit NUMBER)
IS
SELECT  HOU.name
FROM    hr_operating_units HOU
WHERE   SYSDATE BETWEEN NVL(HOU.date_from,SYSDATE) AND NVL(HOU.date_to,SYSDATE+1)
AND     organization_id = p_operating_unit;

----------------------------------------------------------------------
--Cursor to get the category for document category 'OE_PRINT_CATEGORY'
----------------------------------------------------------------------
CURSOR  lcu_category(p_category_name VARCHAR2)
IS
SELECT  category_id
FROM    fnd_document_categories FDC
WHERE   FDC.name = gc_category_name;

-------------------------------------------------
--Cursor to get the Header Id for the Note Number
-------------------------------------------------
CURSOR  lcu_header_id(p_note_number VARCHAR2)
IS
SELECT  OOHA.header_id
FROM    oe_order_headers_all OOHA
WHERE   OOHA.orig_sys_document_ref=p_note_number;

-------------------------------------------
--Cursor to get total count of Note records
-------------------------------------------
CURSOR   lcu_get_note_rec_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_order_notes_cleaned UONC
WHERE    UONC.oraclegenuse1=p_operating_unit
AND      UONC.notetype='O';

----------------------------------------------------------------------------
--Cursor to get total count of Note records which got Processed Successfully
----------------------------------------------------------------------------
CURSOR lcu_get_note_processed_count(p_operating_unit VARCHAR2)
IS
SELECT COUNT(1)
FROM   usbpcs_order_notes_cleaned UONC
WHERE  UONC.oraclecharfld1='PS'
AND    UONC.oraclegenuse1=p_operating_unit
AND    UONC.notetype='O';

-----------------------------------------------------------------------
--Cursor to get total count of Note records which got failed Processing
-----------------------------------------------------------------------
CURSOR lcu_get_note_invalid_count(p_operating_unit VARCHAR2)
IS
SELECT COUNT(1)
FROM   usbpcs_order_notes_cleaned UONC
WHERE  UONC.oraclecharfld1='PE'
AND    UONC.oraclegenuse1=p_operating_unit
AND    UONC.notetype='O';

----------------------------------------------
--Cursor to get total count of Errored records
----------------------------------------------
CURSOR  lcu_get_errored_rec_count(p_request_id VARCHAR2)
IS
SELECT  COUNT(1)
FROM    xxha_common_errors XCE
WHERE   XCE.request_id =  p_request_id;

BEGIN
   gc_log_msg:='*************START OF PROCESS ATTACHMENTS PROCEDURE*************';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --Assign the debug parameter to the global variable
   gc_debug_flag        :=p_debug;

   --Initialize the record variables
   gn_record_number     :=NULL;
   gc_record_identifier :=NULL;
   gc_table_name        :='USBPCS_ORDER_NOTES_CLEANED';

   ----------------------------------------
   -- Purge the record from the error table
   ----------------------------------------
   IF (NVL(p_purge_data,'N') = 'Y') THEN
      xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>gc_con_prg_shot_name);
   END IF;--end of purging data

   ------------------------------------
   --Check if Operating Unit is defined
   ------------------------------------
   gc_log_msg:='Operating unit: '||gc_operating_unit;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   lc_setup_op_unit_err_flag:='N';
   lc_category_setup_err_flag:='N';
   lc_setup_error_flag:='N';
   ln_row_count:=0;

   OPEN  lcu_chk_operating_unit(gc_operating_unit);
   FETCH lcu_chk_operating_unit INTO gc_operating_unit_name;
      IF (lcu_chk_operating_unit%NOTFOUND) THEN
         --Log error
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='Operating Unit: '||gc_operating_unit_name||' is Invalid';
         gc_comments   :='Please define the Operating Unit';
         INSERT_ERROR_MSG;
         lc_setup_op_unit_err_flag:='Y';
      END IF; --lcu_chk_operating_unit%NOTFOUND
   CLOSE lcu_chk_operating_unit;

   gc_log_msg:='Flag returned by the Operating Unit cursor: '||lc_setup_op_unit_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ----------------
   --Validate setup
   ----------------
   OPEN  lcu_category(gc_category_name);
   FETCH lcu_category INTO ln_category_id;
      IF lcu_category%NOTFOUND THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='Document Category: '||gc_category_name||' is Invalid';
        gc_comments   :='Please define the Document Category';
        INSERT_ERROR_MSG;
        lc_category_setup_err_flag:='Y';
      END IF;
   CLOSE lcu_category;
   gc_log_msg:='Flag returned by the Document Category cursor: '||lc_category_setup_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --If set up Error Program completes in error
   IF (lc_category_setup_err_flag='Y' OR lc_setup_op_unit_err_flag='Y') THEN
      lc_setup_error_flag:='Y';
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_record_identify);
      x_ret_code:=2;
      RETURN;
   END IF;

   --If set up done, then perform validation
   IF (lc_setup_error_flag='N') THEN
      FOR lr_order_notes IN lcu_get_order_notes(gc_operating_unit_name)
      LOOP
         --Reinitialise the Variables
         ln_header_id         := 0;
         x_error_flag         :='N';
         lc_header_id_err_flag:='N';
         gn_record_number     := lr_order_notes.oracleidentifier;
         gc_record_identifier := lr_order_notes.notenumber;
         x_document_id        := NULL;
         x_media_id           := NULL;
         x_row_id             := NULL;

         gc_log_msg:='Processing Record: '||lr_order_notes.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------------------------------------------------------
         -- Deriving Header Id corresponding to note number in the table
         ---------------------------------------------------------------

         OPEN  lcu_header_id(lr_order_notes.notenumber);
         FETCH lcu_header_id INTO ln_header_id;
            IF lcu_header_id%NOTFOUND THEN
              --Log error message
               gc_error_code :='PA01';
               gc_error_msg  :='Unable to find Sales Order for the Orig System Document Reference: '||lr_order_notes.notenumber;
               gc_comments   :='Please check the existence of Order ';
               INSERT_ERROR_MSG;
               lc_header_id_err_flag:='Y';
               gc_log_msg:='lc_header_id_err_flag  for Record:'||lr_order_notes.oracleidentifier||' is '||lc_header_id_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
             END IF;
         CLOSE lcu_header_id;

         --Call procedure to attch the notes if no error while deriving the header Id
         IF lc_header_id_err_flag <>'Y' THEN

            INSERT_ATTACHMENTS ( p_pk1_value   => ln_header_id
                                ,p_category_id => ln_category_id
                                ,p_debug       => p_debug
                                ,p_description => lr_order_notes.notedescription
                                ,p_seq_num     => lr_order_notes.noteseqnbr
                                ,p_attribute1  => lr_order_notes.printonack
                                ,p_attribute2  => lr_order_notes.printonpic
                                ,p_attribute3  => lr_order_notes.printoninv
                                ,p_attribute4  => lr_order_notes.printoncuststatements
                                ,x_error_flag  => x_error_flag
                                ,x_err_buf     => x_err_buf
                                ,x_ret_code    => x_ret_code
                                ,x_document_id => x_document_id
                                ,x_media_id    => x_media_id
                                ,x_row_id      => x_row_id
                               );

            gc_log_msg:='Flag Returned by API  is: '||x_error_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         END IF;

         --Updating Status depending on Error
         IF (x_error_flag <>'Y' AND lc_header_id_err_flag<>'Y') THEN
            UPDATE_RECORD_STATUS('PS',gn_request_id,lr_order_notes.oracleidentifier);

            gc_log_msg:='Updating status of record to PS';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         ELSE
            lc_error_flag:='Y';
            UPDATE_RECORD_STATUS('PE',gn_request_id,lr_order_notes.oracleidentifier);

            gc_log_msg:='Updating status of record to PE';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         END IF;


         --Incrementing count of API Processed Records
         IF (x_row_id IS NOT NULL) THEN
            ln_row_count:=ln_row_count+1;
         END IF;

      END LOOP;--End of lcu_get_order_notes
   END IF;

   gc_log_msg:='Count of records API went through: '||ln_row_count;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


   --Reinitialize the Variables
   ln_note_rec_fetched  :=0;
   ln_note_rec_processed:=0;
   ln_note_rec_invalid  :=0;


   --Get the Total Number of Note records
   OPEN  lcu_get_note_rec_count(gc_operating_unit_name);
   FETCH lcu_get_note_rec_count INTO ln_note_rec_fetched;
   CLOSE lcu_get_note_rec_count;

   --Get Total Number of Note records Processed successfully
   OPEN lcu_get_note_processed_count(gc_operating_unit_name);
   FETCH lcu_get_note_processed_count INTO ln_note_rec_processed;
   CLOSE lcu_get_note_processed_count;

   --Get Total Number of header records failed validation
   OPEN lcu_get_note_invalid_count(gc_operating_unit_name);
   FETCH lcu_get_note_invalid_count INTO ln_note_rec_invalid;
   CLOSE lcu_get_note_invalid_count;

   --Summary information of Header Records Processed
   --===============================================
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of Note Records Processed ');
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Header Records Fetched       :    ' ||ln_note_rec_fetched);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Header Records Processed     :    ' ||ln_note_rec_processed );
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Header Records Errored out   :    ' ||(ln_note_rec_invalid));

   --Committing if no Error found else rollback
   IF (lc_error_flag <>'Y'  ) THEN
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*******************************************');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'All the Records Are Processed and Committed');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*******************************************');
   ELSE
      ROLLBACK;
      x_ret_code:=1;
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_record_identify);

      FND_FILE.PUT_LINE(FND_FILE.LOG,'*********************************************');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'All the Records Are Processed and Rolled Back');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*********************************************');
      RETURN;
   END IF;

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_ATTACH_DOCUMENTS_PK.PROCESS_ATTACHMENTS. Error is: ' ||SQLERRM);
   x_err_buf:=SQLERRM;
   x_ret_code:=2;
   ROLLBACK;
END PROCESS_ATTACHMENTS;

END XXHA_ATTACH_DOCUMENTS_PK;


/
