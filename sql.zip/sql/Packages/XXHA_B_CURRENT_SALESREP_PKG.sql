CREATE OR REPLACE PACKAGE      XXHA_B_CURRENT_SALESREP_PKG AUTHID CURRENT_USER AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_B_CURRENT_SALESREP_PKG                                             *
* Purpose      : This package populates XXHA_B_CURRENT_SALESREP for extract to OBIEE.    *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
* XXHA_B_CURRENT_SALESREP_STG  D,I,S                                                     *
* XXHA_B_CURRENT_SALESREP  D,I                                                           *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        19-Sep-2014     I. Menzies           Initial version                        *
*                                                                                        *
*****************************************************************************************/
-- Procedure used to populate current salesrep table
--
PROCEDURE GET_CURRENT_REPS(x_errbuf          OUT VARCHAR2,
                           x_retcode         OUT NUMBER
               );


END XXHA_B_CURRENT_SALESREP_PKG;
/


CREATE OR REPLACE PACKAGE BODY      XXHA_B_CURRENT_SALESREP_PKG
AS
   --Version 1.0
   /*****************************************************************************************
   * Package Name : XXHA_B_CURRENT_SALESREP_PKG                                             *
   * Purpose      : This package populates XXHA_B_CURRENT_SALESREP for extract to OBIEE.    *
   *                                                                                        *
   * Procedures   :                                                                         *
   * ---------------------                                                                  *
   *                                                                                        *
   * Tables Accessed :                                                                      *
   * Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
   *                                                                                        *
   * XXHA_B_CURRENT_SALESREP_STG  D,I,S                                                     *
   * XXHA_B_CURRENT_SALESREP  D,I                                                           *
   *                                                                                        *
   * Change History                                                                         *
   *                                                                                        *
   * Ver        Date            Author               Description                            *
   * ------     -----------     -----------------    ---------------                        *
   * 1.0        19-Sep-2014     I. Menzies           Initial version                        *
   *                                                                                        *
   *****************************************************************************************/
   -- Procedure used to populate current salesrep table
   --
   PROCEDURE GET_CURRENT_REPS (x_errbuf OUT VARCHAR2, x_retcode OUT NUMBER)
   IS
   BEGIN
      EXECUTE IMMEDIATE 'TRUNCATE TABLE HAEMO.XXHA_B_CURRENT_SALESREP_STG';

      fnd_file.put_line (
         fnd_file.LOG,
            'Truncated XXHA_B_CURRENT_SALESREP_STG table: '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));

      INSERT INTO haemo.xxha_b_current_salesrep_stg (customer_trx_line_id,
                                                     current_salesrep_id,
                                                     current_salesrep_source,
                                                     current_salesrep_name,
                                                     current_bus_unit,
                                                     current_mu)
         SELECT rct.customer_trx_line_id,
                current_salesrep_id,
                current_salesrep_source,
                res.resource_name current_salesrep_name,
                gcc.segment3 current_bus_unit,
                gcc.segment4 current_mu
           FROM (SELECT rct.customer_trx_line_id,
                        rct.org_id,
                        CASE
                           WHEN hca.CUSTOMER_TYPE = 'I'
                           THEN
                              -3
                           WHEN sro_sb.salesrep_id IS NOT NULL
                           THEN
                              sro_sb.salesrep_id
                           WHEN sro_b.salesrep_id IS NOT NULL
                           THEN
                              sro_b.salesrep_id
                           WHEN    rct.sales_order_source IS NULL
                                OR rct.sales_order_source = 'OKS_CONTRACTS'
                           THEN
                              COALESCE (hcsu_b.primary_salesrep_id,
                                        hcsu_s.primary_salesrep_id,
                                        -3)
                           ELSE
                              COALESCE (oea_l.salesrep_id,
                                        oea_h.salesrep_id,
                                        hcsu_os.primary_salesrep_id,
                                        hcsu_i.primary_salesrep_id,
                                        -3)
                        END
                           current_salesrep_id,
                        CASE
                           WHEN hca.CUSTOMER_TYPE = 'I'
                           THEN
                              'Intercompany NSC'
                           WHEN    sro_sb.salesrep_id IS NOT NULL
                                OR sro_b.salesrep_id IS NOT NULL
                           THEN
                              'Sales Rep Override'
                           WHEN rct.sales_order_source IS NULL
                           THEN
                                 'ManualEntry '
                              || CASE
                                    WHEN hcsu_b.primary_salesrep_id
                                            IS NOT NULL
                                    THEN
                                       'BILLTO'
                                    WHEN hcsu_s.primary_salesrep_id
                                            IS NOT NULL
                                    THEN
                                       'SHIPTO'
                                    ELSE
                                       'NSC'
                                 END
                           WHEN rct.sales_order_source = 'OKS_CONTRACTS'
                           THEN
                                 'Contract '
                              || CASE
                                    WHEN hcsu_b.primary_salesrep_id
                                            IS NOT NULL
                                    THEN
                                       'BILLTO'
                                    WHEN hcsu_s.primary_salesrep_id
                                            IS NOT NULL
                                    THEN
                                       'SHIPTO'
                                    ELSE
                                       'NSC'
                                 END
                           WHEN oea_l.salesrep_id IS NOT NULL
                           THEN
                              'DefaultRule Line AGREEMENT'
                           WHEN oea_h.salesrep_id IS NOT NULL
                           THEN
                              'DefaultRule Header AGREEMENT'
                           WHEN hcsu_os.primary_salesrep_id IS NOT NULL
                           THEN
                              'DefaultRule Header SHIPTO'
                           WHEN hcsu_i.primary_salesrep_id IS NOT NULL
                           THEN
                              'DefaultRule Header BILLTO'
                           ELSE
                              'DefaultRule Header Profile'
                        END
                           current_salesrep_source
                   FROM (SELECT rctl.customer_trx_line_id,
                                rctl.org_id,
                                rctl.sales_order_source,
                                rct.bill_to_site_use_id,
                                rct.ship_to_site_use_id,
                                DECODE (
                                   rctl.interface_line_context,
                                   'ORDER ENTRY', rctl.interface_line_attribute6)
                                   ool_line_id,
                                mc.segment1 product_line
                           FROM ra_customer_trx_lines_all rctl,
                                ra_customer_trx_all rct,
                                mtl_item_categories mic,
                                mtl_categories mc
                          WHERE     1 = 1
                                AND rct.complete_flag = 'Y'
                                AND rctl.customer_trx_id =
                                       rct.customer_trx_id
                                AND rctl.line_type IN ('LINE', 'FREIGHT')
                                AND EXISTS
                                       (SELECT 0
                                          FROM ra_cust_trx_line_gl_dist_all rctgl
                                         WHERE     1 = 1
                                               AND rctgl.customer_trx_line_id =
                                                      rctl.customer_trx_line_id
                                               AND rctgl.account_class IN ('REV',
                                                                           'FREIGHT')
                                               AND rctgl.account_set_flag =
                                                      'N'
                                               AND rctgl.gl_date >=
                                                      (ADD_MONTHS (SYSDATE,
                                                                   -24)))
                                AND rctl.inventory_item_id =
                                       mic.inventory_item_id(+)
                                AND mic.organization_id(+) = 103
                                AND mic.category_set_id(+) = 1
                                AND mc.category_id(+) = mic.category_id) rct,
                        hz_cust_site_uses_all hcsu_b,
                        hz_cust_acct_sites_all hcas,
                        hz_cust_accounts hca,
                        hz_cust_site_uses_all hcsu_s,
                        hz_cust_site_uses_all hcsu_i,
                        hz_cust_site_uses_all hcsu_os,
                        oe_order_lines_all ool,
                        oe_agreements_b oea_l,
                        oe_order_headers_all ooh,
                        oe_agreements_b oea_h,
                        haemo.xx_haemo_sls_rep_override sro_sb,
                        haemo.xx_haemo_sls_rep_override sro_b
                  WHERE     1 = 1
                        AND rct.bill_to_site_use_id = hcsu_b.site_use_id(+)
                        AND hcsu_b.cust_acct_site_id =
                               hcas.cust_acct_site_id(+)
                        AND hcas.cust_account_id = hca.cust_account_id(+)
                        AND rct.ship_to_site_use_id = hcsu_s.site_use_id(+)
                        AND rct.ool_line_id = ool.line_id(+)
                        AND ool.agreement_id = oea_l.agreement_id(+)
                        AND ool.header_id = ooh.header_id(+)
                        AND ooh.agreement_id = oea_h.agreement_id(+)
                        AND ooh.invoice_to_org_id = hcsu_i.site_use_id(+)
                        AND ooh.ship_to_org_id = hcsu_os.site_use_id(+)
                        AND sro_sb.billto_site_use_id(+) =
                               rct.bill_to_site_use_id
                        AND sro_sb.shipto_site_use_id(+) =
                               rct.ship_to_site_use_id
                        AND sro_sb.product_line(+) = rct.product_line
                        AND sro_b.billto_site_use_id(+) =
                               rct.bill_to_site_use_id
                        AND sro_b.shipto_site_use_id(+) IS NULL
                        AND sro_b.product_line(+) = rct.product_line) rct,
                jtf_rs_salesreps rs,
                jtf_rs_resource_extns_vl res,
                gl_code_combinations gcc
          WHERE     rct.current_salesrep_id = rs.salesrep_id(+)
                AND rct.org_id = rs.org_id(+)
                AND rs.resource_id = res.resource_id(+)
                AND rs.gl_id_rev = gcc.code_combination_id(+);

      COMMIT;

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            SQL%ROWCOUNT
         || ' - Records Successfully inserted in XXHA_B_CURRENT_SALESREP_STG '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));

      MERGE INTO haemo.xxha_b_current_salesrep a
           USING (SELECT customer_trx_line_id,
                         current_salesrep_id,
                         current_salesrep_source,
                         current_salesrep_name,
                         current_bus_unit,
                         current_mu
                    FROM haemo.xxha_b_current_salesrep_stg
                  MINUS
                  SELECT customer_trx_line_id,
                         current_salesrep_id,
                         current_salesrep_source,
                         current_salesrep_name,
                         current_bus_unit,
                         current_mu
                    FROM haemo.xxha_b_current_salesrep) b
              ON (a.customer_trx_line_id = b.customer_trx_line_id)
      WHEN NOT MATCHED
      THEN
         INSERT     (customer_trx_line_id,
                     current_salesrep_id,
                     current_salesrep_source,
                     current_salesrep_name,
                     current_bus_unit,
                     current_mu,
                     last_update_date)
             VALUES (b.customer_trx_line_id,
                     b.current_salesrep_id,
                     b.current_salesrep_source,
                     b.current_salesrep_name,
                     b.current_bus_unit,
                     b.current_mu,
                     SYSDATE)
      WHEN MATCHED
      THEN
         UPDATE SET a.current_salesrep_id = b.current_salesrep_id,
                    a.current_salesrep_source = b.current_salesrep_source,
                    a.current_salesrep_name = b.current_salesrep_name,
                    a.current_bus_unit = b.current_bus_unit,
                    a.current_mu = b.current_mu,
                    a.last_update_date = SYSDATE;

      COMMIT;

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            SQL%ROWCOUNT
         || ' - Records Successfully merged into XXHA_B_CURRENT_SALESREP '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));

      x_retcode := 0;
   EXCEPTION
      WHEN OTHERS
      THEN
         x_errbuf :=
               'Encountered Error.'
            || SQLERRM
            || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS');
         x_retcode := 2;
         FND_FILE.PUT_LINE (FND_FILE.LOG, x_errbuf);
   END GET_CURRENT_REPS;
END XXHA_B_CURRENT_SALESREP_PKG;
/
