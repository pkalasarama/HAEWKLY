CREATE OR REPLACE PACKAGE XXHA_FORMAT_PHONE_NBR AS 

/*********************************************************************************************
* Package Name : XXHA_FORMAT_PHONE_NBR                                                       *
* Purpose      : This package provides functions to format a Phone Number.                   *
*                                                                                            *
* Used By      : XXHA: Sales Order Acknowledgment Report XX                                  *
*                                                                                            *
* PROCEDURE    : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        16-MAR-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
*********************************************************************************************/

PROCEDURE PROCESS_DATA(
                         p_Phone_Country_Code   IN  VARCHAR2
                      ,  p_Phone_Area_Code      IN  VARCHAR2
                      ,  p_Phone_Number         IN  VARCHAR2
                      ,  p_Phone_Extension_txt  IN  VARCHAR2
                      ,  p_Phone_Extension      IN  VARCHAR2
                      ,  p_Phone_Formatted      OUT VARCHAR2
                      );

END XXHA_FORMAT_PHONE_NBR;
/


CREATE OR REPLACE PACKAGE BODY XXHA_FORMAT_PHONE_NBR AS

/*********************************************************************************************
* Package Name : XXHA_ADDRESS_COMPRESS_PK                                                    *
* Purpose      : This package provides functions to format a Phone Number.                   *
*                                                                                            *
* PROCEDURE    : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        16-MAR-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
*********************************************************************************************/

PROCEDURE PROCESS_DATA(
                         p_Phone_Country_Code   IN  VARCHAR2
                      ,  p_Phone_Area_Code      IN  VARCHAR2
                      ,  p_Phone_Number         IN  VARCHAR2
                      ,  p_Phone_Extension_txt  IN  VARCHAR2
                      ,  p_Phone_Extension      IN  VARCHAR2
                      ,  p_Phone_Formatted      OUT VARCHAR2
                      )  IS

l_Phone_Country_Code    HZ_CONTACT_POINTS.PHONE_COUNTRY_CODE%TYPE   := NULL;
l_Phone_Area_Code       HZ_CONTACT_POINTS.PHONE_AREA_CODE%TYPE      := NULL;
l_Phone_Number          HZ_CONTACT_POINTS.PHONE_NUMBER%TYPE         := NULL;
l_Phone_Extension_txt   VARCHAR2(25)                                := NULL;
l_Phone_Extension       HZ_CONTACT_POINTS.PHONE_EXTENSION%TYPE      := NULL;
l_Phone_Formatted       VARCHAR2(240)                               := NULL;

  BEGIN

    -- Move Parameters to local variables
    l_Phone_Country_Code  := p_Phone_Country_Code;
    l_Phone_Area_Code     := p_Phone_Area_Code;
    l_Phone_Number        := p_Phone_Number;
    l_Phone_Extension_txt := p_Phone_Extension_txt;
    l_Phone_Extension     := p_Phone_Extension;

    -- Initialize output
    p_Phone_Formatted := NULL;

    -- Country Code '(86) '
    IF l_Phone_Country_Code IS NOT NULL THEN
       l_Phone_Formatted   := (l_Phone_Formatted || '(' || l_Phone_Country_Code || ') ');
    END IF;

    -- Area Code '(86) 01-'
    IF l_Phone_Area_Code IS NOT NULL THEN
       l_Phone_Formatted   := (l_Phone_Formatted || l_Phone_Area_Code || '-');
    END IF;

    -- Phone Number '(86) 01-1234567'
    IF l_Phone_Number IS NOT NULL THEN
       l_Phone_Formatted   := (l_Phone_Formatted || l_Phone_Number);
    END IF;

    -- Phone Extension '(86) 01-1234567 Ext 1234'
    IF l_Phone_Extension IS NOT NULL THEN
       IF l_Phone_Extension_txt IS NOT NULL THEN
          l_Phone_Formatted   := (l_Phone_Formatted || ' ' || l_Phone_Extension_txt || ' ' || l_Phone_Extension);
       ELSE
          l_Phone_Formatted   := (l_Phone_Formatted || ' ' || l_Phone_Extension);
       END IF;
    END IF;

    -- Move to output
    p_Phone_Formatted   := l_Phone_Formatted;

  END PROCESS_DATA;

END XXHA_FORMAT_PHONE_NBR;
/
