CREATE OR REPLACE PACKAGE XXHA_POWF_PROFIT_OPTIMIZE_PKG as
/*===========================================================================
  PACKAGE NAME:        XXHA_POWF_PROFIT_OPTIMIZE_PKG

  DESCRIPTION:        Package Generate Approvla List for Profit Optimization
                      base upon Transactional Approver

  CLIENT/SERVER:      SERVER

  LIBRARY NAME        NONE

  OWNER:              Amit Patel

  HISTORY:            30-March-09      Initial Creation


  ===========================================================================*/

PROCEDURE profit_optimize_enabled_check (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2);

PROCEDURE set_forward_to (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2);
PROCEDURE profit_optimize_required (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2);
PROCEDURE check_responsibility (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2);

PROCEDURE non_req_po_not_allowed (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2);

PROCEDURE inv_expense_not_allowed (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2);


END XXHA_POWF_PROFIT_OPTIMIZE_PKG;

/


CREATE OR REPLACE PACKAGE BODY      XXHA_POWF_PROFIT_OPTIMIZE_PKG as

/*===========================================================================
  PACKAGE NAME:        XXHA_POWF_PROFIT_OPTIMIZE_PKG

  DESCRIPTION:        Package Generate Approvla List for Profit Optimization
                      base upon Transactional Approver

  CLIENT/SERVER:      SERVER

  LIBRARY NAME        NONE

  OWNER:              Amit Patel

  HISTORY:            30-March-09      Initial Creation
  Sreeram             02-Sep-09        Modified the package to address the changes for PO Approval Process
					                   (to elimante the hardcoding for Operating units to check for requisition before pO can be approved
									   ,To override the requisition requirement for cancelled lines)
                      20-sep-09        removed the condition to check for the closed lines in profit optimization


  ===========================================================================*/

/***************************************************************************************/
PROCEDURE profit_optimize_enabled_check  (itemtype    IN     VARCHAR2
                                        ,itemkey     IN     VARCHAR2
                                        ,actid       IN     NUMBER
                                        ,funcmode    IN     VARCHAR2
                                        ,resultout   OUT    VARCHAR2)
IS

   v_enabled_flag             VARCHAR2(1);

   x_progress                 VARCHAR2(1000);

BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

   x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.profit_optimize_enabled_check:01 Profit Optimization Enabled Check';
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


       v_enabled_flag := FND_PROFILE.VALUE('HAE_PROFIT_OPTIMIZATION_ENABLED');

       -- Profit Optimization Customization executed only if above profile option set to 'YES'


        IF      NVL(v_enabled_flag, 'N') = 'Y'  THEN

                resultout := wf_engine.eng_completed || ':' || 'Y';

       ELSE
                resultout := wf_engine.eng_completed || ':' || 'N';

       END IF;


EXCEPTION
    WHEN others THEN

      x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.profit_optimize_enabled_check ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_POWF_PROFIT_OPTIMIZE_PKG', 'profit_optimize_enabled_check',
                itemtype, itemkey, x_progress);
      RAISE;

END profit_optimize_enabled_check;
/***************************************************************************************/
PROCEDURE profit_optimize_required (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2)
IS

  v_po_header_id                 NUMBER;
  v_preparer_id                  NUMBER;
  v_org_id                       NUMBER;

  v_document_subtype             VARCHAR2(25);
  v_document_type             VARCHAR2(25);

  v_required_flag               VARCHAR2(1);
  v_destination_type_code       VARCHAR2(25);
  v_item_id                     NUMBER;

  x_progress                   VARCHAR2(1000);

  -- For Standard PO

   CURSOR c_po_shipment(p_po_header_id NUMBER,
                           p_org_id NUMBER)  IS
   select    pda.destination_type_code
     from    po_distributions_all    pda,
             po_line_locations_all   plla
    where    pda.line_location_id = plla.line_location_id
--     and     NVL(plla.closed_code, 'X') not like '%CLOSED%' commented to address the PO issue in GBX
      AND    NVL(plla.cancel_flag, 'N')=  'N'
      and    pda.po_header_id  = p_po_header_id
      AND    pda.org_id        = p_org_id
 order by    pda.po_header_id,
             pda.po_line_id,
             pda.line_location_id,
             pda.po_distribution_id;

  -- For Blancket PA

  -- Added logic for Blanket PA on 05/20/2009 Amit Patel

  CURSOR c_po_line(p_po_header_id NUMBER,
                         p_org_id NUMBER)  IS
  select     pla.item_id
     from    po_headers_all   pha,
             po_lines_all      pla
    where    pha.po_header_id = pla.po_header_id
     and     NVL(pla.closed_code,'X') not like '%CLOSED%'
      AND    NVL(pla.cancel_flag, 'N') = 'N'
      and    pha.po_header_id  = p_po_header_id
      AND    pla.org_id        = p_org_id
 order by    pla.po_header_id,
             pla.po_line_id;

  -- Blanket Release

  -- Added logic for Blanket PA on 05/20/2009 Amit Patel

  CURSOR c_po_release(p_po_header_id NUMBER,
                         p_org_id NUMBER)  IS
  select     pla.item_id
     from    po_releases_all   pha,
             po_lines_all      pla
    where    pha.po_header_id = pla.po_header_id
     and     NVL(pla.closed_code,'X') not like '%CLOSED%'
      AND    NVL(pla.cancel_flag, 'N') = 'N'
      and    pha.po_release_id  = p_po_header_id
      AND    pla.org_id        = p_org_id
 order by    pla.po_header_id,
             pla.po_line_id;


BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

    v_po_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'DOCUMENT_ID');


     v_org_id        := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'ORG_ID');

     v_document_subtype       := wf_engine.GetItemAttrText(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'DOCUMENT_SUBTYPE');

     v_document_type       := wf_engine.GetItemAttrText(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'DOCUMENT_TYPE');


            x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.profit_optimize_required:01 Profit Optimize Required';
            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

        -- Document type is 'STANDARD PO',then destinatin type code on Distribution on firs open line should be INVENTORY

           IF  v_document_subtype = 'STANDARD' tHEN

                    OPEN c_po_shipment(v_po_header_id, v_org_id);
                    LOOP

                    FETCH c_po_shipment INTO v_destination_type_code;

                      EXIT WHEN c_po_shipment%NOTFOUND;

                            x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.profit_optimize_required:02 Shipment Cursor opened ';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                 IF  v_destination_type_code  = 'INVENTORY' THEN


                                         resultout := wf_engine.eng_completed || ':' || 'Y';
                                 ELSE

                                         resultout := wf_engine.eng_completed || ':' || 'N';

                                 END IF;

                     EXIT;

                    END LOOP;

             -- Document type is 'BLANKET PA',then item id should not be blank on firt open line.

           ELSIF     v_document_subtype = 'BLANKET' THEN

                -- Added logic for Blanket PA on 05/20/2009 Amit Patel

               IF  v_document_type = 'RELEASE' THEN

                    -- For Blanket Release

                    OPEN c_po_release(v_po_header_id, v_org_id);
                    LOOP
                    FETCH c_po_release INTO      v_item_id;

                      EXIT WHEN c_po_release%NOTFOUND;

                            x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.profit_optimize_required:03 Release Cursor opened ';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                 IF  v_item_id IS NOT NULL THEN

                                         resultout := wf_engine.eng_completed || ':' || 'Y';

                                 ELSE
                                         resultout := wf_engine.eng_completed || ':' || 'N';

                                 END IF;

                     EXIT;

                    END LOOP;


               ELSE    ---    For Blancke Purchase Agreement

                    OPEN c_po_line(v_po_header_id, v_org_id);
                    LOOP
                    FETCH c_po_line INTO      v_item_id;

                      EXIT WHEN c_po_line%NOTFOUND;

                            x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.profit_optimize_required:03 Line Cursor opened ';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                 IF  v_item_id IS NOT NULL THEN

                                         resultout := wf_engine.eng_completed || ':' || 'Y';

                                 ELSE
                                         resultout := wf_engine.eng_completed || ':' || 'N';


                                 END IF;

                     EXIT;

                    END LOOP;

                     -- Added logic for Blanket PA on 05/20/2009 Amit Patel

               END IF;
           eLSE

              --Document type is 'CONTRACT PA' OR 'PLANNED PO, are not allowed with 'Inventory Buyer' Responsibility.

                   resultout := wf_engine.eng_completed || ':' || 'N';

           end IF;

EXCEPTION
    WHEN others THEN

     x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.profit_optimize_required: User Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_POWF_PROFIT_OPTIMIZE_PKG', 'profit_optimize_required',
                itemtype, itemkey, x_progress);
      RAISE;

END profit_optimize_required;
/***************************************************************************************/
PROCEDURE set_forward_to (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2)
IS

  v_po_header_id                 NUMBER;
  v_preparer_id                  NUMBER;
  v_org_id                       NUMBER;

  v_transaction_supervisor_id    NUMBER(20);
  v_display_name                VARCHAR2(100);

  x_progress                   VARCHAR2(1000);



BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

    v_po_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'DOCUMENT_ID');

     v_org_id        := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'ORG_ID');


     v_transaction_supervisor_id := FND_PROFILE.VALUE('HAE_TRANSACTION_SUPERVISOR');


    x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.set_forward_to:01 Set Forward To';
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


       IF    v_transaction_supervisor_id IS NOT NULL THEN

                BEGIN
                       SELECT   full_name
                         INTO   v_display_name
                         FROM   PER_PEOPLE_F
                         WHERE  person_id = v_transaction_supervisor_id
                         AND    trunc(sysdate) BETWEEN effective_start_date
                                                   AND effective_end_date;

                         wf_engine.SetItemAttrText ( itemtype   => itemType,
                                             itemkey    => itemkey,
                                             aname      => 'FORWARD_TO_USERNAME',
                                             avalue     => v_display_name);

                          wf_engine.SetItemAttrText ( itemtype   => itemType,
                                             itemkey    => itemkey,
                                             aname      => 'FORWARD_TO_DISPLAY_NAME',
                                             avalue     => v_display_name);



                          Wf_engine.SetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'FORWARD_TO_ID'
                                                   ,avalue    => v_transaction_supervisor_id);


                END;


             resultout := wf_engine.eng_completed || ':' || 'Y';

        ELSE

               resultout := wf_engine.eng_completed || ':' || 'N';

        END IF;


EXCEPTION
    WHEN others THEN

     x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.set_forward_to: User Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_POWF_PROFIT_OPTIMIZE_PKG', 'set_forward_to',
                itemtype, itemkey, x_progress);

      resultout := wf_engine.eng_completed || ':' || 'N';


END set_forward_to;

/***************************************************************************************/

PROCEDURE check_responsibility (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2)
IS

  v_responsibility_id          NUMBER;
  v_responsibility_name        VARCHAR2(100);

  x_progress                   VARCHAR2(1000);

BEGIN

            IF (funcmode != Wf_Engine.eng_run)
            THEN
                --  Do nothing in cancel or timeout mode
                resultout := Wf_Engine.eng_null;
                --
                RETURN;
            END IF;

                x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.check_responsibility:01 Check Responsibility';
                PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


                v_responsibility_name := FND_PROFILE.VALUE('RESP_NAME');

                v_responsibility_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                                 itemkey  => itemkey,
                                                                 aname    => 'RESPONSIBILITY_ID');



                --Profit Optimization apply only for custom resonpsility 'Inventory Buyer'

                    IF UPPER(v_responsibility_name) = 'INVENTORY BUYER' THEN


                            resultout := wf_engine.eng_completed || ':' || 'Y';
                    ELSE

                            resultout := wf_engine.eng_completed || ':' || 'N';

                    end IF;

EXCEPTION
    WHEN others THEN

     x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.check_responsibility: User Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_POWF_PROFIT_OPTIMIZE_PKG', 'check_responsibility',
                itemtype, itemkey, x_progress);
      RAISE;

END check_responsibility;

/***************************************************************************************/

PROCEDURE non_req_po_not_allowed(itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2)
IS

  v_total_dist_count          NUMBER  := 0;   -- Amit Patel 06/09/2009
  v_req_dist_count            NUMBER  := 0;   -- Amit Patel 06/09/2009

  v_po_header_id              NUMBER;
  v_org_id                    NUMBER;
  v_document_subtype          VARCHAR2(25);
  v_document_type             VARCHAR2(25);
  v_release_num               NUMBER;
  v_doc_creation_method       VARCHAR2(25);

  x_progress                   VARCHAR2(1000);

BEGIN

            IF (funcmode != Wf_Engine.eng_run)
            THEN
                --  Do nothing in cancel or timeout mode
                resultout := Wf_Engine.eng_null;
                --
                RETURN;
            END IF;

                x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.non_req_po_not_allowed;:01 Non Requistion PO not Allowed';
                PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                v_po_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'DOCUMENT_ID');


                v_org_id        := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'ORG_ID');

                 v_document_subtype       := wf_engine.GetItemAttrText(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'DOCUMENT_SUBTYPE');

                 v_document_type       := wf_engine.GetItemAttrText(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'DOCUMENT_TYPE');


                 v_release_num        := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'RELEASE_NUM');

       --- Changed on 05/06/2009 Amit Patel

            BEGIN

                select  document_creation_method
                  INTO  v_doc_creation_method
                  from  po_headers_all
                 where  po_header_id = v_po_header_id
                  and   org_id =  v_org_id;

            EXCEPTION

                  WHEN OTHERS THEN

                     NULL;


           END;

    --  Bypass Requisition Validation if it is Converted PO   05/03/2009 Amit Patel

       IF  NVL(v_doc_creation_method, 'X') <> 'PDOI' THEN


            IF v_document_subtype IN ('STANDARD', 'BLANKET') THEN


                  -- Added logic for Blanket Release on 05/06/2009 Amit Patel


                    IF  v_document_type = 'RELEASE' THEN

                             -- Get the count of distribution on Release
                                  select   count(*)
                                    INTO   v_total_dist_count
                                    from   po_distributions_all  pd
                                          ,po_releases_all       pr
                                   where   pd.po_header_id  = pr.po_header_id
                                     and   pd.po_release_id = pr.po_release_id
									                   and not exists (select 'A' from po_lines_all pl,po_line_locations_all pll  --Added by sreeram to override exclude the cancel lines
									                  where pl.po_line_id = pd.po_line_id
													  and   pd.line_location_id = pll.LINE_LOCATION_ID
													  and   (pl.CANCEL_FLAG = 'Y' or pll.cancel_flag = 'Y'))
                                     and   pd.po_release_id  = v_po_header_id
                                     and   pd.org_id        =  v_org_id
                                     and   pr.release_num   = v_release_num;

                            -- Get the count of distribution from Requisition on RELEASE

                                   select   count(*)
                                     INTO   v_req_dist_count
                                     from   po_distributions_all  pd
                                           ,po_releases_all       pr
                                    where   pd.po_header_id  = pr.po_header_id
                                      and   pd.po_release_id = pr.po_release_id
									  and not exists (select 'A' from po_lines_all pl,po_line_locations_all pll
									                  where pl.po_line_id = pd.po_line_id
													  and   pd.line_location_id = pll.LINE_LOCATION_ID
													  and   (pl.CANCEL_FLAG = 'Y' or pll.cancel_flag = 'Y'))
                                      and   pd.po_release_id = v_po_header_id
                                      and   pd.org_id =  v_org_id
                                      and   pr.release_num =  v_release_num
                                       and  pd.req_distribution_id is not null;

                             -- Added by Amit Patel  06/09/2009

                    ELSIF     v_document_type = 'PO'      THEN
                                       -- Get the count of distribution on PO

                                                    select  count (*)
                                                      INTO  v_total_dist_count
                                                      from  po_distributions_all pd
                                                     where  po_header_id = v_po_header_id
                                                      and   org_id =  v_org_id
									 and not exists (select 'A' from po_lines_all pl,po_line_locations_all pll
									                  where pl.po_line_id = pd.po_line_id
													  and   pd.line_location_id = pll.LINE_LOCATION_ID
													  and   (pl.CANCEL_FLAG = 'Y' or pll.cancel_flag = 'Y'));
                            
                                       -- Get the count of distribution from Requisition on PO

                                                    select  count (*)
                                                      INTO  v_req_dist_count
                                                      from  po_distributions_all pd
                                                     where  po_header_id = v_po_header_id
                                                      and   org_id =  v_org_id
                                                      and   req_distribution_id IS NOT NULL
									 and not exists (select 'A' from po_lines_all pl,po_line_locations_all pll
									                  where pl.po_line_id = pd.po_line_id
													  and   pd.line_location_id = pll.LINE_LOCATION_ID
													  and   (pl.CANCEL_FLAG = 'Y' or pll.cancel_flag = 'Y'));


                    ELSE  ---- This is for BPA 06/09/2009

                            v_total_dist_count          := 0;   -- Amit Patel 06/09/2009
                            v_req_dist_count            := 0;   -- Amit Patel 06/09/2009



                     END IF;

                --Profit Optimization apply only for custom resonpsility 'Inventory Buyer'
                    IF v_total_dist_count = v_req_dist_count THEN


                            resultout := wf_engine.eng_completed || ':' || 'Y';
                    ELSE

                            resultout := wf_engine.eng_completed || ':' || 'N';

                    end IF;

             ELSE

                   resultout := wf_engine.eng_completed || ':' || 'Y';

             END IF;

       ELSE

                   resultout := wf_engine.eng_completed || ':' || 'Y';

       END IF;

EXCEPTION
    WHEN others THEN

     x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.non_req_po_not_allowed;: User Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_POWF_PROFIT_OPTIMIZE_PKG', 'Non Req PO not Allowed',
                itemtype, itemkey, x_progress);
      RAISE;

END non_req_po_not_allowed;

/***************************************************************************************/

PROCEDURE inv_expense_not_allowed(itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2)
IS

  v_po_header_id                 NUMBER;

  v_org_id                       NUMBER;

  v_document_subtype             VARCHAR2(25);
  v_document_type                VARCHAR2(25);
  v_release_num                  NUMBER;

  v_inventory_flag               VARCHAR2(1)   := 'N';
  v_expense_flag                 VARCHAR2(1)   := 'N';

  v_destination_type_code        VARCHAR2(25);
  v_org_name                     VARCHAR2(25);

  x_progress                     VARCHAR2(1000);

   CURSOR c_po_shipment(p_po_header_id  NUMBER,
                        p_org_id        NUMBER)  IS
   select    DISTINCT pda.destination_type_code
     from    po_distributions_all    pda,
             po_line_locations_all   plla
    where    pda.line_location_id = plla.line_location_id
     and     NVL(plla.closed_code, 'X') not like '%CLOSED%'
      AND    NVL(plla.cancel_flag, 'N')=  'N'
      and    pda.po_header_id  = p_po_header_id
      AND    pda.org_id        = p_org_id;

 CURSOR c_po_release(p_po_header_id NUMBER,
                     p_org_id       NUMBER,
                     p_release_num  NUMBER)  IS
   select    DISTINCT pda.destination_type_code
     from    po_distributions_all    pda,
             po_line_locations_all   plla,
             po_releases_all         pra
    where    pda.line_location_id = plla.line_location_id
      AND    pda.po_header_id     = pra.po_header_id
      and    pda.po_release_id    = pra.po_release_id
     and     nvl(plla.closed_code, 'X') not like '%CLOSED%'
     AND    NVL(plla.cancel_flag, 'N')=  'N'
      and    pra.po_release_id  = p_po_header_id
      and    pra.release_num   = p_release_num
      AND    pda.org_id        = p_org_id;


BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

    v_po_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'DOCUMENT_ID');


     v_org_id        := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'ORG_ID');

     v_document_subtype       := wf_engine.GetItemAttrText(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'DOCUMENT_SUBTYPE');

     v_document_type       := wf_engine.GetItemAttrText(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'DOCUMENT_TYPE');


     v_release_num        := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'RELEASE_NUM');


            x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.inv_expense_not_allowed:01 Inv_Expense_Not_Allowed';
            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


            -- Get operating Unit of PO

--            select SUBSTR(name, -5)
              Select nvl(attribute1,'NO')
              INTO v_org_name
--              from hr_operating_units commented by sreeram to remove the hard coding
              From HR_ALL_ORGANIZATION_UNITS
             where organization_id = v_org_id;


--       IF     v_org_name in ('US OU', 'CH OU', 'ST OU', 'GB OU') THEN commnted by sreeram for removing OU hardcoding
       IF     v_org_name = 'YES' THEN

        -- Document type is 'STANDARD PO',then destinatin type code on Distribution on open lines should be INVENTORY

           IF  v_document_subtype in ( 'STANDARD', 'BLANKET') tHEN

             -- Added for Release  on 05/06/2009 Amit Patel

               IF  v_document_type = 'RELEASE' THEN

                    OPEN c_po_release(v_po_header_id, v_org_id,v_release_num);
                    LOOP

                    FETCH c_po_release INTO v_destination_type_code;

                      EXIT WHEN c_po_release%NOTFOUND;

                            x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.inv_expense_not_allowed:01 Release Cursor opened ';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                 IF  v_destination_type_code  = 'INVENTORY' THEN

                                        v_inventory_flag := 'Y';

                                 ELSE

                                        v_expense_flag  := 'Y';

                                 END IF;


                    END LOOP;

                     -- Added for Release  on 05/06/2009 Amit Patel
               ELSE


                    OPEN c_po_shipment(v_po_header_id, v_org_id);
                    LOOP

                    FETCH c_po_shipment INTO v_destination_type_code;

                      EXIT WHEN c_po_shipment%NOTFOUND;

                            x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.inv_expense_not_allowed:02 Shipment Cursor opened ';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                 IF  v_destination_type_code  = 'INVENTORY' THEN

                                        v_inventory_flag := 'Y';

                                 ELSE

                                        v_expense_flag  := 'Y';

                                 END IF;


                    END LOOP;

               END IF;

                         ---  only Inventory items
               IF  v_inventory_flag = 'Y' and  v_expense_flag  = 'N' tHEN

                    resultout := wf_engine.eng_completed || ':' || 'Y';


                    -- Only Non Inventory items
               ELSIF  v_inventory_flag = 'N' and  v_expense_flag  = 'Y' tHEN

                    resultout := wf_engine.eng_completed || ':' || 'N';

                    --Set Workflow Attribute to Y for all Expense items on PO

                        wf_engine.SetItemAttrText ( itemtype   => itemType,
                                                 itemkey    => itemkey,
                                                 aname      => 'XXHA_EXPENSE_FLAG',
                                                 avalue     => 'Y');

                    --- Inventory and Non Inventory items
               ELSIF

                   v_inventory_flag = 'Y' and  v_expense_flag  = 'Y' tHEN

                    resultout := wf_engine.eng_completed || ':' || 'N';

               ELSE    -- All other type of documents

                  -- v_inventory_flag = 'N' and  v_expense_flag  = 'N'

                   resultout := wf_engine.eng_completed || ':' || 'Y';

               END IF;

           ELSE

             resultout := wf_engine.eng_completed || ':' || 'Y';

          END IF;

      ELSE

           resultout := wf_engine.eng_completed || ':' || 'Y';

      END IF;


EXCEPTION
    WHEN others THEN

     x_progress := 'XXHA_POWF_PROFIT_OPTIMIZE_PKG.inv_expense_not_allowed: User Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_POWF_PROFIT_OPTIMIZE_PKG', 'inv_expense_not_allowed',
                itemtype, itemkey, x_progress);
      RAISE;


END inv_expense_not_allowed;

END XXHA_POWF_PROFIT_OPTIMIZE_PKG;
/
