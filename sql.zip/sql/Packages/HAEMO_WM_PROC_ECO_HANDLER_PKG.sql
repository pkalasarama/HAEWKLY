CREATE OR REPLACE PACKAGE Haemo_Wm_Proc_Eco_Handler_Pkg AUTHID CURRENT_USER 
-- +=====================================================================================+
-- | Name        : Haemo_Wm_Proc_Eco_Handler_Pkg                 	                 |
-- | Purpose     : Support the Interface of ECO into EBS.    				 |
-- |                                                             	                 |
-- | Description : Procedure to determine calling parameters for 			 |
-- |		   Processing ECOs Concurrent Request					 |
-- |		   Takes in the mandatory and optional parameters required for 		 |
-- |		   Processing ECOs Concurrent Request.					 |
-- |                                                                           		 |
-- |                                            					 |
-- |                                                                           		 |
-- | Comment     : This package is called to execute XXHA_ECO_PROCESS_ECO package.       |
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who       What                                             		 |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 20091021  1.0  Vasil S. Valkov   Initial version.					 |
-- +=====================================================================================+
AS
PROCEDURE HAEMO_WM_HANDLE_PROC_ECO( p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg  OUT VARCHAR
			    ) ;

END Haemo_Wm_Proc_Eco_Handler_Pkg;
/


CREATE OR REPLACE PACKAGE BODY Haemo_Wm_Proc_Eco_Handler_Pkg 
AS
-- +=====================================================================================+
-- | Name        : Haemo_Wm_Proc_Eco_Handler_Pkg                 	                 |
-- | Purpose     : Support the Interface of ECO into EBS.    				 |
-- |                                                             	                 |
-- | Description : Procedure to determine calling parameters for 			 |
-- |		   Processing ECOs Concurrent Request					 |
-- |		   Takes in the mandatory and optional parameters required for 		 |
-- |		   Processing ECOs Concurrent Request.					 |
-- |                                                                           		 |
-- |                                            					 |
-- |                                                                           		 |
-- | Comment     : This package is called to execute XXHA_ECO_PROCESS_ECO package.       |
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who       What                                             		 |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 20091021  1.0  Vasil S. Valkov   Initial version.					 |
-- +=====================================================================================+

PROCEDURE HAEMO_WM_HANDLE_PROC_ECO(p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg OUT VARCHAR
			    )
IS
	v_program  				   VARCHAR2(20):='XXHA_ECO_CREATE_ECO'; -- XXHA_ECO_CREATE_ECO Program
	v_application		   	   	   VARCHAR2(20):='HAEMO'; -- Application
	v_application_id		           NUMBER;
	v_user_id				   NUMBER;
	v_user_responsibility_id                   NUMBER;


BEGIN

	  -- Fetch Application id for INV Application
	  v_errmsg:='Fetching Application id';

	  SELECT application_id
	  INTO   v_application_id
	  FROM   fnd_application
	  WHERE  application_short_name = v_application;

	  -- Fetch the User Id
	  v_errmsg:='Fetching the User Id';

	  v_user_id:=wm_conc_request_pkg.get_user_id(p_user);

	  -- Fetch the Responsibility Id
	  v_errmsg:='Fetching the Responsibility Id';

	  v_user_responsibility_id:=wm_conc_request_pkg.get_user_responsibility_id(p_user_responsibility);

           -- Initialize environment

	  Fnd_Global.apps_initialize(v_user_id,v_user_responsibility_id,v_application_id);

          v_errmsg:='Calling Submit Request';

	  -- Call to submit request

	  wm_conc_request_pkg.wm_request_submit(v_application_id,
	  					 v_user_responsibility_id,
	  					 v_user_id,
	  					 v_application,
			  			 v_program,
			  			 v_status,
						 v_request_id,
						 NULL,
			  			 NULL,
			  			 o_message,
						 v_errmsg
           			  	     	 );



EXCEPTION
 WHEN OTHERS THEN
 v_errmsg:=v_errmsg||SQLERRM;
 v_status:='FAILED';

END HAEMO_WM_HANDLE_PROC_ECO;

END Haemo_Wm_Proc_Eco_Handler_Pkg;
/
