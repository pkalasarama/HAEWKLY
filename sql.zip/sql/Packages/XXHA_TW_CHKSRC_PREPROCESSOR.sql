CREATE OR REPLACE package XXHA_TW_ChkSrc_Preprocessor as

--+===========================================================================+
-- | Name : XXHA_TW_ChkSrc_Preprocessor.pck |
-- | Purpose : Generate Correct GUI number |
-- | |
-- | Comment :  |
-- | |
-- | History |
-- | ======= |
-- | When Rev Who What |
-- | -------- --- -------- ------------------------------------------------ |
-- | 20110829 1.0 Maria Lavrentieva Initial version |
-- | 20110831 1.1 Maria Lavrentieva Corrected Interco bug |
--+===========================================================================+

  PROCEDURE MAIN(errbuf      OUT VARCHAR2,
                 retcode     OUT NUMBER,
                 org_code    varchar2,
                 source_name varchar2);
end XXHA_TW_ChkSrc_Preprocessor;
/


CREATE OR REPLACE package body XXHA_TW_ChkSrc_Preprocessor as
--+===========================================================================+
-- | Name : XXHA_TW_ChkSrc_Preprocessor.pck |
-- | Purpose : Generate Correct GUI number |
-- | |
-- | Comment :  |
-- | |
-- | History |
-- | ======= |
-- | When Rev Who What |
-- | -------- --- -------- ------------------------------------------------ |
-- | 20110829 1.0 Maria Lavrentieva Initial version |
-- | 20110831 1.1 Maria Lavrentieva Corrected Interco bug |
--+===========================================================================+
PROCEDURE MAIN(errbuf   OUT VARCHAR2,
                 retcode  OUT NUMBER,
                 org_code varchar2 ,
                 source_name varchar2) is
    amount number;
  begin
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Organization - ' || org_code);
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'TW Source Name - '||source_name);

    update ra_interface_lines_all i
       set batch_source_name = source_name,
           uom_code          = (select primary_uom_code
                                  from mtl_system_items_b m
                                 where m.inventory_item_id =
                                       i.inventory_item_id
                                   and m.organization_id = org_code) --103)--number
     where batch_source_name = 'OKS_CONTRACTS'
       and i.org_id = 243
       and cust_trx_type_id in (1304, 1305)
       and not exists
/* R12 Upgrade Modified on 09/24/2012 by Venkatesh Sarangam, Rolta */
     /*(select 1
              from OKC_K_HEADERS_B khb
             where khb.contract_number = i.interface_line_attribute1
               and khb.estimated_amount = '0'
               and i.amount = '0');*/
       (select 1
              from OKC_K_HEADERS_ALL_B khb
             where khb.contract_number = i.interface_line_attribute1
               and KHB.ESTIMATED_AMOUNT = '0'
               and i.amount = '0');
 update ra_interface_lines_all i
       set batch_source_name = source_name
     where batch_source_name = 'Order Management'
       and i.org_id = 243
       and not exists
     (select 1
              from oe_order_headers_all h
             where oe_totals_grp.get_order_total(h.header_id, NULL, 'ALL') = '0'
               and h.order_number = i.interface_line_attribute1
               and i.amount = '0'
               and h.org_id = i.org_id)
       and cust_trx_type_id in (1304, 1305);
update ra_interface_lines_all i
       set batch_source_name = source_name, cust_trx_type_id = '1304'
     where batch_source_name = 'Order Management'
       and i.org_id = 243
       and (select h.order_type_id
              from oe_order_headers_all h
             where h.order_number = i.interface_line_attribute1
               and h.org_id = i.org_id) = 1235
       and not exists
     (select 1
              from oe_order_headers_all h
             where oe_totals_grp.get_order_total(h.header_id, NULL, 'ALL') = '0'
               and h.order_number = i.interface_line_attribute1
               and i.amount = '0'
               and h.org_id = i.org_id)
       and (select ca.attribute5
              from HZ_CUST_ACCOUNTS ca, oe_order_lines_all l
             where l.sold_to_org_id = ca.cust_account_id
               and l.org_id = i.org_id
               and l.line_id = i.interface_line_attribute6) = 'Duplicate';
update ra_interface_lines_all i
       set batch_source_name = source_name, cust_trx_type_id = '1305'
     where batch_source_name = 'Order Management'
       and i.org_id = 243
       and (select h.order_type_id
              from oe_order_headers_all h
             where h.order_number = i.interface_line_attribute1
               and h.org_id = i.org_id) = 1235
       and not exists
     (select 1
              from oe_order_headers_all h
             where oe_totals_grp.get_order_total(h.header_id, NULL, 'ALL') = '0'
               and h.order_number = i.interface_line_attribute1
               and i.amount = '0'
               and h.org_id = i.org_id)
       and (select ca.attribute5
              from HZ_CUST_ACCOUNTS ca, oe_order_lines_all l
             where l.sold_to_org_id = ca.cust_account_id
               and l.org_id = i.org_id
               and l.line_id = i.interface_line_attribute6) = 'Triplicate';
update ra_interface_lines_all i
       set batch_source_name = source_name, cust_trx_type_id = '1304'
     where batch_source_name = 'Intercompany'
       and i.org_id = 243;
commit;
exception
    when others then
      FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error :' || substr(sqlerrm, 1, 80));
      retcode := 3;
      rollback;
  end;
end XXHA_TW_ChkSrc_Preprocessor;
/
