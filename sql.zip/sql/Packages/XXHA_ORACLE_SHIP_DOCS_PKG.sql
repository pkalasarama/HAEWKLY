/********************************************************************************************************
    * Object Name: XXHA_ORACLE_SHIP_DOCS_PKG
    * Object Type: Package 
    * Description: This package is created for Shipping Documents Requirement and it calls the shipping 
	*              reports.
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    25-JAN-2015          Initial object creation.
*******************************************************************************************************/  

create or replace 
PACKAGE XXHA_ORACLE_SHIP_DOCS_PKG
AS
  PROCEDURE XXHA_DROP_REPORT_PRC(
      p_deliv_id    IN NUMBER,
      p_doc_printer IN VARCHAR2);
  PROCEDURE XXHA_ORACLE_SHIP_DOCS(
      p_deliv_id    IN NUMBER,
      p_doc_printer IN VARCHAR2 );
END XXHA_ORACLE_SHIP_DOCS_PKG;
/

create or replace 
PACKAGE BODY XXHA_ORACLE_SHIP_DOCS_PKG
AS
 PROCEDURE XXHA_DROP_REPORT_PRC(
      p_deliv_id    IN NUMBER,
      p_doc_printer IN VARCHAR2 )
  AS
    l_user_id1             NUMBER         := to_number(fnd_profile.value('USER_ID'));
    l_resp_id1             NUMBER         := NULL;
    l_resp_appl_id1        NUMBER         := NULL;
    l_responsibility_name1 VARCHAR2 (255) := 'US Order Management Super User OC';
    l_option_return1       BOOLEAN;
    lc_boolean1            BOOLEAN;
    ln_request_id1         NUMBER;
    l_orgn_id              NUMBER;
  BEGIN
   begin
    	SELECT DISTINCT organization_id 
	 INTO l_orgn_id
	FROM wsh_delivery_assignments wda,
	  wsh_delivery_details wdd
	WHERE wda.delivery_id      = p_deliv_id
	AND wda.delivery_detail_id = wdd.delivery_detail_id;
    EXCEPTION
    WHEN OTHERS THEN
	--DBMS_OUTPUT.PUT_LINE('Error occured in retrieving organization ID for delivery ID '||p_delivery_id);
	fnd_file.put_line(fnd_file.log, 'Error occured in retrieving organization ID for delivery ID '||p_deliv_id);
	end;
    BEGIN
      SELECT frt.application_id,
        frt.responsibility_id
      INTO l_resp_appl_id1,
        l_resp_id1
      FROM fnd_responsibility_tl frt
      WHERE frt.LANGUAGE          = 'US'
      AND frt.responsibility_name = l_responsibility_name1;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_resp_appl_id1 := '';
      l_resp_id1      := '';
    END;
    fnd_global.apps_initialize (user_id => l_user_id1, resp_id => l_resp_id1, resp_appl_id => l_resp_appl_id1);
    --fnd_global.apps_initialize (29067,20420,1);
    l_option_return1 := fnd_request.set_print_options (printer => p_doc_printer, style => NULL, copies => 1, save_output => TRUE, print_together => 'N' );
    DBMS_OUTPUT.put_line ('Printer:' || p_doc_printer);
    lc_boolean1 := fnd_request.add_layout ( template_appl_name => 'HAEMO', template_code => 'XXHA_WMSDRPREP', template_language => 'en', --Use language from template definition
    template_territory => 'US',                                                                                                          --Use territory from template definition
    output_format => 'PDF'                                                                                                               --Use output format from template definition
    );
    ln_request_id1 := fnd_request.submit_request ( 'HAEMO' -- Application
    , 'XXHA_WMSDRPREP'                                     -- Program
    , NULL                                                 -- Description
    , NULL                                                 -- Start Time
    , FALSE                                                -- Sub Request
    , l_orgn_id , p_deliv_id );
    COMMIT;
    IF ln_request_id1 = 0 THEN
      DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
    END IF;
  END;
PROCEDURE xxha_oracle_ship_docs(
    p_deliv_id IN NUMBER,
    p_doc_printer IN VARCHAR2)
AS
  l_user_id             NUMBER         := to_number(fnd_profile.value('USER_ID'));
  l_resp_id             NUMBER         := NULL;
  l_resp_appl_id        NUMBER         := NULL;
  l_responsibility_name VARCHAR2 (255) := 'US Order Management Super User OC';
  --local variables for calling XXHA Shipping Documents Program
  l_doc_printer   VARCHAR2(50);
  l_lookup_code   VARCHAR2(250);
  l_option_return BOOLEAN;
  ln_request_id   NUMBER;
 BEGIN
  BEGIN
    SELECT frt.application_id,
      frt.responsibility_id
    INTO l_resp_appl_id,
      l_resp_id
    FROM fnd_responsibility_tl frt
    WHERE frt.LANGUAGE          = 'US'
    AND frt.responsibility_name = l_responsibility_name;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    l_resp_appl_id := '';
    l_resp_id      := '';
  END;
  fnd_global.apps_initialize (user_id => l_user_id, resp_id => l_resp_id, resp_appl_id => l_resp_appl_id );
 SELECT --wdd.attribute4, 
        flv.lookup_code 
 INTO   --l_doc_printer,
        l_lookup_code
      FROM wsh_carrier_services_v wcs,
        wsh_delivery_details wdd ,
        wsh_delivery_assignments wda,
        wsh_new_deliveries wnd,
        wsh_lookups wl,
        org_organization_definitions ood,
        fnd_lookup_values_vl flv 
      WHERE wcs.carrier_id       = wdd.carrier_id
      AND wdd.delivery_detail_id = wda.delivery_detail_id
      AND wda.delivery_id        = wnd.delivery_id
      AND wdd.organization_id    = ood.organization_id
      AND wda.delivery_id        = p_deliv_id
      AND wdd.mode_of_transport  = wl.lookup_code
      AND wl.lookup_type(+)      = 'XXHA_WSH_BOL_MODE_OF_TRANSPORT'
      and flv.lookup_type        = 'XXHA_WMS_SHIPPING_DOCS'
      and flv.tag             =  DECODE(upper(wdd.mode_of_transport),'PARCEL',wdd.mode_of_transport,'NP')
      and flv.description        = ood.organization_code
      AND wl.enabled_flag        = 'Y'
      and flv.enabled_flag       = 'Y'
    --  AND wdd.attribute4 IS NOT NULL
     -- AND wdd.attribute4 = p_doc_printer
      AND rownum          = 1
      GROUP BY 
       --wdd.attribute4,
       flv.lookup_code ;
 ln_request_id := fnd_request.submit_request ( 'HAEMO' -- Application
  , l_lookup_code                                       -- Program
  , NULL                                                -- Description
  , NULL                                                -- Start Time
  , FALSE                                               -- Sub Request
  , p_deliv_id                                          -- Delivery ID
  , p_doc_printer                                       -- Shipping docs printer
  );
  COMMIT;
  IF ln_request_id = 0 THEN
    DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
  END IF;
END xxha_oracle_ship_docs;
  
END XXHA_ORACLE_SHIP_DOCS_PKG;
/