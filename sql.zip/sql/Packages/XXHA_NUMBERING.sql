CREATE OR REPLACE package XXHA_NUMBERING
AS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_NUMBERING
*  Description:
*      This package is written maintain employee number across bus groups
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*
******************************************************************************/
FUNCTION check_for_empl_nbr_f (p_business_group_id IN NUMBER,
                                   p_party_id          IN NUMBER)
RETURN VARCHAR2;
END XXHA_NUMBERING;

/


CREATE OR REPLACE package BODY XXHA_NUMBERING
AS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_NUMBERING
*  Function: check_for_empl_nbr_f
*  Description:
*      This package is written maintain employee number across bus groups
*
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  21-SEP-2008       Peter Gutowski      Created New.
*
******************************************************************************/


FUNCTION check_for_empl_nbr_f (p_business_group_id IN NUMBER,
                                   p_party_id          IN NUMBER)
RETURN VARCHAR2
AS
lc_err_msg           VARCHAR2(100);
lc_status            VARCHAR2(1);
l_return_info        VARCHAR2(25);
w_status             VARCHAR2(1);
h_number             VARCHAR2(20);
h_error              VARCHAR2(5);
h_count              NUMBER;

CURSOR get_employee_number
is
select distinct nvl(pap.employee_number, 'NULL')
             from per_all_people_f pap
            , per_person_types ppt
        where pap.party_id = p_party_id
        and sysdate between pap.effective_start_date
        and pap.effective_end_date
          and pap.person_type_id = ppt.person_type_id
          and ppt.system_person_type in ('EMP', 'EMP_APL', 'EX_EMP', 'EX_EMP_APL');
BEGIN
-- GET A NEW NUMBE FROM GLOBAL SEQUENCE
IF p_party_id = 0 THEN
         select to_char(PER_GLOBAL_EMP_NUM_S.NEXTVAL)
           into h_number
           from dual;
           -- GET EE NUMBER
   ELSE


  OPEN    get_employee_number;
  FETCH get_employee_number INTO h_number;
  IF get_employee_number%NOTFOUND
   THEN
      select to_char(PER_GLOBAL_EMP_NUM_S.NEXTVAL)
              into h_number
              from dual;
    END IF;


   END IF;

 select count(*)
     into h_count
     from per_all_people_f pap
    where pap.employee_number = h_number
      and pap.business_group_id = p_business_group_id;
   IF h_count <> 0 THEN
       h_error:='DUP';
   ELSE
       h_error:='OK';
   END IF;
   l_return_info:=rpad(h_number, 20)||h_error;
  RETURN l_return_info;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
      l_return_info:=rpad('0', 20)||'ERR';
      RETURN l_return_info;
  WHEN OTHERS THEN
      lc_err_msg     := SUBSTR(SQLERRM(SQLCODE),1,100);
      Hr_Utility.SET_LOCATION('***** lc_err_msg = '||lc_err_msg,20);
      l_return_info:=rpad('0', 20)||'ERR';
      RETURN l_return_info;
END;

END XXHA_NUMBERING;

/
