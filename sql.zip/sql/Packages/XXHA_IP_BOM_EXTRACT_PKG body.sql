create or replace PACKAGE BODY XXHA_IP_BOM_EXTRACT_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_IP_BOM_EXTRACT_PKG                                                                                *
* Purpose      : This package provides a function to process the BOM data.                                              *
*                                                                                                                       *
* Procedures   : XXHA_IP_BOM_EXPLODER                                                                                   *
*                XXHA_IP_BOM_EXPLODER_COMPONENT                                                                         *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        22-SEP-2017     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_PROCESS_DATA

PROCEDURE XXHA_PROCESS_DATA(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2) AS

BEGIN

   BEGIN

      -- Perform BOM Explosion
      XXHA_IP_BOM_EXPLODER(
          errbuf
         ,errcode);

      -- Remove non-components
      XXHA_IP_BOM_EXPLODER_COMPONENT(
          errbuf
         ,errcode);

   END;

END XXHA_PROCESS_DATA;


--------------------------------------------------------------------------------
-- PROCEDURE XXHA_IP_BOM_EXPLODER

PROCEDURE XXHA_IP_BOM_EXPLODER(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2) AS

   v_org_id                       org_organization_definitions.organization_id%TYPE;
   v_err_msg                      VARCHAR2 (1000);
   v_err_code                     NUMBER;
   p_grp_id                       NUMBER;
   v_sucess                       NUMBER;
   v_count                        NUMBER                                        := 0;
   v_list                         NUMBER;
   truncate_temp                  VARCHAR2 (1000);
   no_updates                     EXCEPTION;

   CURSOR c_boms
   IS
   SELECT 
     bom.assembly_item_id      item_id
   , bom.organization_id
   , bom.bill_sequence_id
   , bom.alternate_bom_designator
   FROM 
     mtl_system_items          msi
   , bom_bill_of_materials     bom
   WHERE
       bom.assembly_item_id  = msi.inventory_item_id
   AND bom.organization_id   = msi.organization_id
   AND NVL(msi.attribute8,'No') = 'Yes'
   AND EXISTS
   (SELECT NULL
      FROM apps.XXHA_IP_BOM_WIP_V   WIP
     WHERE WIP.organization_ID    = bom.organization_id
       AND WIP.inventory_item_id  = bom.assembly_item_id
   );

   x_sql   VARCHAR2 (500);
   x_seq   NUMBER;
   x_count NUMBER:= 0;

BEGIN

   fnd_file.put_line (fnd_file.output, 'Program Start date and Time: ' || TO_CHAR (SYSDATE, 'DD-MON-RR HH:MI:SS') );

   BEGIN
   fnd_file.put_line (fnd_file.output, 'TRUNCATING TABLE apps.XXHA_IP_BOM_EXPLOSION');
   x_sql   := 'TRUNCATE TABLE apps.XXHA_IP_BOM_EXPLOSION';
   EXECUTE IMMEDIATE x_sql;
           EXCEPTION
                WHEN OTHERS THEN fnd_file.put_line (fnd_file.output, 'TRUNCATE TABLE apps.XXHA_IP_BOM_EXPLOSION - Failed');
   END;

   BEGIN
   fnd_file.put_line (fnd_file.output, 'CREATING INDEX apps.XXHA_IP_BOM_EXPLOSION_N1 ON apps.XXHA_IP_BOM_EXPLOSION');
   x_sql := 'CREATE INDEX apps.XXHA_IP_BOM_EXPLOSION_N1 ON apps.XXHA_IP_BOM_EXPLOSION (organization_id, top_item_id)';
   EXECUTE IMMEDIATE x_sql;
           EXCEPTION
                WHEN OTHERS THEN fnd_file.put_line (fnd_file.output, 'CREATE INDEX apps.XXHA_IP_BOM_EXPLOSION_N1 ON apps.XXHA_IP_BOM_EXPLOSION - Failed');
   END;

   BEGIN
   fnd_file.put_line (fnd_file.output, 'CREATING INDEX apps.XXHA_IP_BOM_EXPLOSION_N2 ON apps.XXHA_IP_BOM_EXPLOSION');
   x_sql := 'CREATE INDEX apps.XXHA_IP_BOM_EXPLOSION_N2 ON apps.XXHA_IP_BOM_EXPLOSION (organization_id, component_item_id)';
   EXECUTE IMMEDIATE x_sql;
           EXCEPTION
                WHEN OTHERS THEN fnd_file.put_line (fnd_file.output, 'CREATE INDEX apps.XXHA_IP_BOM_EXPLOSION_N2 ON apps.XXHA_IP_BOM_EXPLOSION - Failed');
   END;

   FOR v_items IN c_boms
   LOOP

      v_sucess := 0;

      SELECT bom_lists_s.NEXTVAL INTO v_list FROM DUAL;
      INSERT INTO bom_lists
      (   sequence_id
        , assembly_item_id
        , alternate_designator                                                  -- (aka alternate_bom_designator)
      )

      SELECT DISTINCT 
          v_list
        , bboms.assembly_item_id
        , bboms.alternate_bom_designator
      FROM 
          bom_bill_of_materials     bboms
        , mtl_system_items_b        msis
      WHERE 
          bboms.organization_id   = v_items.organization_id
      AND bboms.assembly_item_id  = v_items.item_id
      AND NVL(bboms.alternate_bom_designator,'+0+9') 
                                  = NVL(v_items.alternate_bom_designator,'+0+9')
      AND msis.inventory_item_id  = bboms.assembly_item_id
      AND msis.organization_id    = bboms.organization_id
      AND msis.bom_enabled_flag   = 'Y';

      p_grp_id := 0;

      SELECT bom_explosion_temp_s.NEXTVAL         INTO p_grp_id FROM DUAL;
      SELECT bom_explosion_temp_session_s.NEXTVAL INTO x_seq    FROM DUAL;
      v_org_id := v_items.organization_id;

      BEGIN

         bompexpl.explosion_report(
           verify_flag                           => 2
         , org_id                                => v_org_id
         , order_by                              => 1
         , list_id                               => v_list
         , grp_id                                => p_grp_id
         , session_id                            => x_seq
         , levels_to_explode                     => 20
         , bom_or_eng                            => 1                                                          -- 1='BOM'
         , impl_flag                             => 1                                                          -- 1=implemented only
         , plan_factor_flag                      => 2
         , incl_lt_flag                          => 2
         , explode_option                        => 3                                                          -- 3�Current and Future
         , module                                => 2                                                          -- 2=BOM
         , cst_type_id                           => 0                                                          -- Cost type ID for cost explosion.
         , std_comp_flag                         => 2                                                          -- 1�Explode only standard components/2�All components
         , expl_qty                              => 1
         , report_option                         => 0
         , req_id                                => 0
         , cst_rlp_id                            => 0
         , lock_flag                             => 1
         , rollup_option                         => 0
         , alt_rtg_desg                          => ''
         , alt_desg                              => ''
         , rev_date                              => TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
         , err_msg                               => v_err_msg
         , ERROR_CODE                            => v_err_code
         );

         IF v_err_msg IS NOT NULL THEN
            fnd_file.put_line (fnd_file.LOG, 'Group Id: ' || p_grp_id || '; Error_Message: ' || v_err_msg || '--' || v_err_code );
         ELSE
            BEGIN
            --  Delete from list table
            DELETE
            FROM bom_lists
            WHERE sequence_id = v_list;

            -- Load up XXHA_IP_BOM_EXPLOSION table
            INSERT INTO apps.XXHA_IP_BOM_EXPLOSION
            SELECT * FROM BOM_EXPLOSION_TEMP WHERE GROUP_ID = p_grp_id;

            DELETE FROM BOM_EXPLOSION_TEMP WHERE GROUP_ID = p_grp_id;

            v_count := v_count + 1;
            COMMIT;

            EXCEPTION
                 WHEN OTHERS THEN
                      NULL;
            END;
         END IF;

      END;

   END LOOP;

   fnd_file.put_line (fnd_file.output, 'Program completion date and Time: ' || TO_CHAR (SYSDATE, 'DD-MON-RR HH:MI:SS') );
   fnd_file.put_line (fnd_file.output, 'Noumber of records processed:     ' || v_count );

   BEGIN
   fnd_file.put_line (fnd_file.output, 'DROPPING INDEX apps.XXHA_IP_BOM_EXPLOSION_N1');
   x_sql   := 'DROP INDEX apps.XXHA_IP_BOM_EXPLOSION_N1';
   EXECUTE IMMEDIATE x_sql;
           EXCEPTION
                WHEN OTHERS THEN fnd_file.put_line (fnd_file.output, 'DROP INDEX apps.XXHA_IP_BOM_EXPLOSION_N1 - Failed');
   END;

   BEGIN
   fnd_file.put_line (fnd_file.output, 'DROPPING INDEX apps.XXHA_IP_BOM_EXPLOSION_N2');
   x_sql   := 'DROP INDEX apps.XXHA_IP_BOM_EXPLOSION_N2';
   EXECUTE IMMEDIATE x_sql;
           EXCEPTION
                WHEN OTHERS THEN fnd_file.put_line (fnd_file.output, 'DROP INDEX apps.XXHA_IP_BOM_EXPLOSION_N2 - Failed');
   END;

EXCEPTION
     WHEN no_updates THEN
          fnd_file.put_line (fnd_file.output, 'Program failed. Please rerun program.' );

END XXHA_IP_BOM_EXPLODER;


--------------------------------------------------------------------------------
-- PROCEDURE XXHA_IP_BOM_EXPLODER_COMPONENT

PROCEDURE XXHA_IP_BOM_EXPLODER_COMPONENT(
          errbuf         OUT VARCHAR2
         ,errcode        OUT VARCHAR2) AS

   l_ASSEMBLY_ITEM_ID              apps.XXHA_IP_BOM_EXPLOSION.ASSEMBLY_ITEM_ID%TYPE  := NULL;
   l_COMPONENT_ITEM_ID             apps.XXHA_IP_BOM_EXPLOSION.COMPONENT_ITEM_ID%TYPE := NULL;
   l_SORT_ORDER                    apps.XXHA_IP_BOM_EXPLOSION.SORT_ORDER%TYPE        := NULL;
   l_LENGTH_SORT_ORDER             NUMBER                                            := NULL;
   l_BOM_KEY_HOLD                  VARCHAR2(250)                                     := NULL;
   l_FIRST_TIME                    VARCHAR2(01)                                      := 'Y';

-- Cursor to retrieve data
CURSOR c_data IS
SELECT
   EXP.ORGANIZATION_ID
 , EXP.GROUP_ID
 , EXP.top_bill_sequence_id
 , EXP.TOP_ALTERNATE_DESIGNATOR
 , EXP.TOP_ITEM_ID 
 , LENGTH(EXP.SORT_ORDER) LENGTH_SORT_ORDER
 , EXP.SORT_ORDER
 , EXP.PLAN_LEVEL
 , EXP.ASSEMBLY_ITEM_ID
 , EXP.COMPONENT_ITEM_ID
 , EXP.SELECT_FLAG
FROM
   apps.XXHA_IP_BOM_EXPLOSION EXP
ORDER BY
   EXP.ORGANIZATION_ID
 , EXP.GROUP_ID
 , EXP.top_bill_sequence_id
 , EXP.top_item_id
 , EXP.sort_order      DESC
-- Note that SORT_ORDER is DESCENDING!!
;

BEGIN

   -- Set SELECT_FLAG to 'Y' for all records
   -- Program will perform exception processing to Set SELECT_FLAG to 'N'
   UPDATE apps.XXHA_IP_BOM_EXPLOSION
      SET SELECT_FLAG = 'Y';
   COMMIT;

   -- Set SELECT_FLAG to 'N' if Plan_level = 0
   UPDATE apps.XXHA_IP_BOM_EXPLOSION
      SET SELECT_FLAG = 'N'
    WHERE Plan_level  = 0;
   COMMIT;

   BEGIN

   FOR dta IN c_data 
   LOOP

      -- Set up break points
      IF l_FIRST_TIME = 'Y' THEN
         l_ASSEMBLY_ITEM_ID   := dta.ASSEMBLY_ITEM_ID;
         l_COMPONENT_ITEM_ID  := dta.COMPONENT_ITEM_ID;
         l_LENGTH_SORT_ORDER  := dta.LENGTH_SORT_ORDER;
         l_SORT_ORDER         := dta.SORT_ORDER;
         l_FIRST_TIME         := 'N';
      -- If current sort order length is less than the previous sort order length
      -- then update SELECT_FLAG to 'N' (these are assembly items)
      ELSIF dta.LENGTH_SORT_ORDER < l_LENGTH_SORT_ORDER THEN
         UPDATE apps.XXHA_IP_BOM_EXPLOSION EXP
            SET EXP.SELECT_FLAG = 'N'
          WHERE 1=1
            AND EXP.GROUP_ID             = dta.GROUP_ID
            AND EXP.ORGANIZATION_ID      = dta.ORGANIZATION_ID
            AND EXP.top_bill_sequence_id = dta.top_bill_sequence_id
            AND EXP.TOP_ITEM_ID          = dta.TOP_ITEM_ID
            AND EXP.ASSEMBLY_ITEM_ID     = dta.ASSEMBLY_ITEM_ID
            AND EXP.COMPONENT_ITEM_ID    = dta.COMPONENT_ITEM_ID
            AND EXP.SORT_ORDER           = dta.SORT_ORDER;
          COMMIT;
         -- Re-set Breaks
         l_ASSEMBLY_ITEM_ID   := dta.ASSEMBLY_ITEM_ID;
         l_COMPONENT_ITEM_ID  := dta.COMPONENT_ITEM_ID;
         l_LENGTH_SORT_ORDER  := dta.LENGTH_SORT_ORDER;
         l_SORT_ORDER         := dta.SORT_ORDER;
      -- If current sort order length is greater than previous sort order length
      -- then don't update but set breaks (these are components)
      ELSIF dta.LENGTH_SORT_ORDER > l_LENGTH_SORT_ORDER THEN
         -- Re-set Breaks
         l_ASSEMBLY_ITEM_ID   := dta.ASSEMBLY_ITEM_ID;
         l_COMPONENT_ITEM_ID  := dta.COMPONENT_ITEM_ID;
         l_LENGTH_SORT_ORDER  := dta.LENGTH_SORT_ORDER;
         l_SORT_ORDER         := dta.SORT_ORDER;
      -- If current sort order length is equal to the previous sort order length
      -- and the sort order is equal to the previous sort order
      -- then update SELECT_FLAG to 'N' (these are assembly items)
      ELSIF dta.LENGTH_SORT_ORDER = l_LENGTH_SORT_ORDER AND dta.SORT_ORDER = l_SORT_ORDER THEN
         UPDATE apps.XXHA_IP_BOM_EXPLOSION EXP
            SET EXP.SELECT_FLAG = 'N'
          WHERE 1=1
            AND EXP.GROUP_ID             = dta.GROUP_ID
            AND EXP.ORGANIZATION_ID      = dta.ORGANIZATION_ID
            AND EXP.top_bill_sequence_id = dta.top_bill_sequence_id
            AND EXP.TOP_ITEM_ID          = dta.TOP_ITEM_ID
            AND EXP.ASSEMBLY_ITEM_ID     = dta.ASSEMBLY_ITEM_ID
            AND EXP.COMPONENT_ITEM_ID    = dta.COMPONENT_ITEM_ID
            AND EXP.SORT_ORDER           = dta.SORT_ORDER;
          COMMIT;
         -- Re-set Breaks
         l_ASSEMBLY_ITEM_ID   := dta.ASSEMBLY_ITEM_ID;
         l_COMPONENT_ITEM_ID  := dta.COMPONENT_ITEM_ID;
         l_LENGTH_SORT_ORDER  := dta.LENGTH_SORT_ORDER;
         l_SORT_ORDER         := dta.SORT_ORDER;
      END IF;

   END LOOP;

    -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             fnd_file.put_line (fnd_file.output, 'Error: '||SQLERRM);
   END;

END XXHA_IP_BOM_EXPLODER_COMPONENT;

END XXHA_IP_BOM_EXTRACT_PKG;