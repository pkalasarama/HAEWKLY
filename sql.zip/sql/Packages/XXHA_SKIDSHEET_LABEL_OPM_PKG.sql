CREATE OR REPLACE PACKAGE      XXHA_SKIDSHEET_LABEL_OPM_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_SKIDSHEET_LABEL_OPM_PKG                                                 *
* Purpose      : This package create XML Data for Load                                   *
*                It is called from concurrent Request                                    *
*                                                                                        *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        26-Sep-2009     R. George   OCS      Initial Creation                       *
* 2.0        07-Sep-2010     David Lund           Updated code to fix data related issue *
*                                                 see magic ticket 68382 for details     *
* 3.0        17-Jun-2011     Bruce Marcoux        Corrected parameter for packages:      *
*                                                 - DBMS_XMLQUERY.SETROWSETTAG           *
*                                                 - DBMS_XMLQUERY.SETROWTAG              *
*                                                                                        *
*****************************************************************************************/

PROCEDURE main(err_buf          out  VARCHAR2
              ,ret_code         OUT  VARCHAR2
              ,p_lot_num    in   VARCHAR2
               );


END XXHA_SKIDSHEET_LABEL_OPM_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_SKIDSHEET_LABEL_OPM_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_SKIDSHEET_LABEL_OPM_PKG                                                 *
* Purpose      : This package create XML Data for Load                                   *
*                It is called from concurrent Request                                    *
*                                                                                        *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        26-Sep-2009     R. George   OCS      Initial Creation                       *
* 2.0        18-Aug-2010     Data Intensity       Changed code to fix bug                *
*                                                 Magic ticket 65357                     *
* 3.0        17-Jun-2011     Bruce Marcoux        Corrected parameter for packages:      *
*                                                 - DBMS_XMLQUERY.SETROWSETTAG           *
*                                                 - DBMS_XMLQUERY.SETROWTAG              *
*                                                                                        *
*****************************************************************************************/
PROCEDURE main(err_buf          out  VARCHAR2
              ,ret_code         OUT  VARCHAR2
              ,p_lot_num    in   VARCHAR2
               ) AS
v_result_query    XMLType;
   p_xmloutput       CLOB;
/* R12 Upgrade Modified on 09/20/2012 by Venkatesh Sarangam, Rolta */
-- v_queryctx        DBMS_XMLQUERY.ctxtype;
-- errorNum         NUMBER;
-- errorMSG         VARCHAR2(200);
   v_queryctx        DBMS_XMLQUERY.ctxHandle;
   v_result_query    XMLType;
   v_xmloutput       CLOB;

   v_query           VARCHAR2(4000);

   v_plan            VARCHAR2(1000) := 'QUARANTINE ENTRY COLLECTION%';
-------------------DI changes------------
    v_buffer           VARCHAR2(32000);
    v_amount           NUMBER := 10;
    v_offset           NUMBER := 1;
    v_sql_text         DBMS_XMLGEN.ctxHandle;
    v_start_pos number := 0;
    v_index number := 0;
    v_string varchar2(32767);
    v_read_length number := 480;
-------------------DI changes------------
BEGIN
/*******************************************************************
        Built up an XML fragment from custom table
        ********************************************************************/
v_query := 'SELECT  qrv.character2 STERILIZER_CYCLE_NUMBER
                                                   ,qrv.character1   PALLET
                                                   ,qrv.character5   LOT
                                                   ,msi.segment1     ITEM
                                                   ,qrv.revision     REV
                                                   ,qrv.quantity     QTY
                              from    qa_results_v  qrv ,
                                      mtl_system_items_b msi
                                            where   qrv.name like :p_plan and
                                                    qrv.character5 = :p_lot_num and
                                                    qrv.item_id  = msi.inventory_item_id
                                            and     qrv.organization_id = msi.organization_id
                                            order by qrv.character2';
/* R12 Upgrade Modified on 09/20/2012 by Venkatesh Sarangam, Rolta */
--       v_queryctx := DBMS_XMLQUERY.newContext(v_query);
--       DBMS_XMLQUERY.SETBINDVALUE(v_queryctx, 'p_plan', v_plan);
--       DBMS_XMLQUERY.SETBINDVALUE(V_QUERYCTX, 'p_lot_num', P_LOT_NUM);
         V_QUERYCTX := DBMS_XMLGEN.NEWCONTEXT(V_QUERY);
         DBMS_XMLGEN.SETBINDVALUE(V_QUERYCTX, 'p_plan', V_PLAN);
         DBMS_XMLGEN.SETBINDVALUE(V_QUERYCTX, 'p_lot_num', P_LOT_NUM);
-- 3.0 - BMarcoux
--         DBMS_XMLQUERY.SETROWSETTAG(ctxHdl => v_queryctx, tag => 'ROWSET');
--         DBMS_XMLQUERY.SETROWTAG(ctxHdl => v_queryctx, tag => 'ROW');
         DBMS_XMLGEN.SETROWSETTAG(CTX => V_QUERYCTX, ROWSETTAGNAME => 'ROWSET');
         DBMS_XMLGEN.SETROWTAG(ctx => v_queryctx, rowtagname => 'ROW');
--         DBMS_XMLQUERY.SETROWSETTAG(ctx => v_queryctx, tag => 'ROWSET');
--         DBMS_XMLQUERY.SETROWTAG(ctx => v_queryctx, tag => 'ROW');

--       v_xmloutput :=  DBMS_XMLQUERY.GETXML(v_queryctx);
        v_xmloutput :=  DBMS_XMLGEN.GETXML(v_queryctx);
-------------------DI changes------------
            v_amount := dbms_lob.getlength(v_xmloutput);
        if v_amount > 1 then
                  while v_start_pos <=  v_amount
                  loop
                   v_index := v_index + 1;
                   v_string :=  dbms_lob.substr(v_xmloutput,v_read_length,v_start_pos+1);
                   v_start_pos  := v_start_pos+v_read_length;
                   fnd_file.put(FND_FILE.OUTPUT, v_string);
                  end loop;
        else
              SELECT dbms_xmlgen.newContext('SELECT '' No data found'' DATA FROM dual')
                INTO v_sql_text
                FROM DUAL;
              v_xmloutput := dbms_xmlgen.getxml(v_sql_text);
              v_amount := dbms_lob.getlength(v_xmloutput);
              dbms_lob.read(v_xmloutput, v_amount, v_offset, v_buffer);
              fnd_file.put(FND_FILE.OUTPUT, v_buffer);
            end if;
-------------------DI changes------------
/* R12 Upgrade Modified on 09/20/2012 by Venkatesh Sarangam, Rolta */
--       DBMS_XMLQUERY.closecontext(v_queryctx);
         DBMS_XMLGEN.closecontext(v_queryctx);

       --  v_xmloutput := '<?xml version="1.0" encoding="UTF-8"?>'||chr(10)||v_xmloutput;
-------------------DI changes------------
--         fnd_file.put_line(FND_FILE.output, v_xmloutput);
--         fnd_file.put_line(FND_FILE.log, v_xmloutput);
-------------------DI changes------------
EXCEPTION
 WHEN OTHERS THEN
/* R12 Upgrade Modified on 09/20/2012 by Venkatesh Sarangam, Rolta */
       -- DBMS_XMLQuery.GETEXCEPTIONCONTENT(v_queryctx, errorNum, errorMSG)
--fnd_file.put_line(FND_FILE.log, 'Exception :'||errorNum ||'  '||errorMSG);
        fnd_file.put_line(FND_FILE.log, 'Exception :'||SQLCODE ||'  '||SQLERRM);
END MAIN;
END XXHA_SKIDSHEET_LABEL_OPM_PKG;
/
