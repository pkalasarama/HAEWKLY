CREATE OR REPLACE PACKAGE      XXHA_AP_POSITIVE_PAY_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_AP_POSITIVE_PAY_PKG
* Purpose      : This procedure generates positive pay output file
*
*
*
*
*
*
* Tables Accessed:
* ----------------
* Access Type (I - Insert, S - Select, U - Update, D - Delete)
* AP_BANK_ACCOUNTS - Select
* AP_BANK_BRANCHES - Select
* AP_CHECKS        - Select
* AP_CHECK_STOCKS  - Select
* AP_CHECKS_ALL    - Update
*
* Change History:
* ----------------
* Ver        Date            Author               Description
* ------     -----------     -----------------    ---------------
* 1.0        02-Mar-2009     Suresh Ramamoorthy  Initial Creation
* 2.0        23-Mar-2009     Suresh Ramamoorthy  Added Bank Account Number parameter
* 3.0        09-Apr-2009     Suresh Ramamoorthy  Added two input parameters for check start and end dates
*****************************************************************************************/

PROCEDURE gen_ppay (
                   errbuf               OUT  VARCHAR2
               ,   retcode              OUT  VARCHAR2
	           ,   p_bank_name          IN   varchar2
			   ,   p_bank_acct_number   IN   varchar2
               ,   p_check_start_date   IN   date
			   ,   p_check_end_date     IN   date
               ) ;

END XXHA_AP_POSITIVE_PAY_PKG;

/


CREATE OR REPLACE PACKAGE BODY      XXHA_AP_POSITIVE_PAY_PKG  AS
/***********************************************************************************************************************************
* Package Name : XXHA_AP_POSITIVE_PAY_PKG
* Purpose      : This procedure generates positive pay output file
*
*
*
*
*
*
* Tables Accessed:
* ----------------
* Access Type (I - Insert, S - Select, U - Update, D - Delete)
* AP_BANK_ACCOUNTS - Select
* AP_BANK_BRANCHES - Select
* AP_CHECKS        - Select
* AP_CHECK_STOCKS  - Select
* AP_CHECKS_ALL    - Update
*
* Change History:
* ----------------
* Ver        Date            Author               Description
* ------     -----------     -----------------    ---------------
* 1.0        02-Mar-2009     Suresh Ramamoorthy  Initial Creation
* 2.0        23-Mar-2009     Suresh Ramamoorthy  Added Bank Account Number parameter
* 3.0        01-Apr-2009     Suresh Ramamoorthy  Added an NVL clause to p_bank_acct_number in cursor cur_bank_account definition
* 4.0        09-Apr-2009     Suresh Ramamoorthy  Added two input parameters for check start and end dates
* 5.0        05-May-2009     Suresh Ramamoorthy  Per Bin Zheng removed all references to UTL utility to make it simpler and to avoid UTL setups
* 6.0        12-May-2009     Suresh Ramamoorthy  Handled the values OVERFLOW,SETUP,SPOILED in the STATUS_LOOKUP_CODE of AP_CHECKS to be sent as VOID
* 7.0        19-May-2009     Suresh Ramamoorthy  Fixed the void count for the values OVERFLOW,SETUP,SPOILED in the STATUS_LOOKUP_CODE of AP_CHECKS that are sent as VOID
* 8.0        25-SEP-2012     Sboppana  REmediated the code to suit to R12 instance
***********************************************************************************************************************************/
PROCEDURE gen_ppay (
                   errbuf              OUT  VARCHAR2
               ,   retcode             OUT  VARCHAR2
			   ,   p_bank_name	       IN   varchar2
               ,   p_bank_acct_number  IN   varchar2
               ,   p_check_start_date  IN   date
			   ,   p_check_end_date    IN   date
               )
IS
CURSOR cur_bank_account IS
/*select DISTINCT abb.BANK_NUM
,      aba.BANK_ACCOUNT_NUM
from   ap_bank_accounts aba
,      ap_bank_branches abb
where  aba.bank_branch_id = abb.bank_branch_id
and    abb.bank_name = NVL(p_bank_name,'Mellon Bank, NA')
and    aba.bank_account_num = NVL(p_bank_acct_number,'0910602') ;*/
select DISTINCT ABB.BRANCH_NUMBER
,      aba.BANK_ACCOUNT_NUM
from
 ce_bank_accounts aba ,
  ce_bank_branches_v abb
where  aba.bank_branch_id = abb.branch_party_id
and    abb.bank_name = NVL(p_bank_name,'Mellon Bank, NA')
and    aba.bank_account_num = NVL(p_bank_acct_number,'0910602');
--/* R12 Upgrade Modified on 09/25/2012 by Sreeram Boppana, Rolta */
-- Per Elena LaFrance's 12-MAR-09 e-mail we should only use account 0910602 which is Braintree checking
CURSOR cur_check_content(p_org_id IN number, p_bank_num IN VARCHAR2, p_bank_acct_num IN VARCHAR2) IS
/*select lpad(abb.BANK_NUM,10,0) BANK_NUM -- Oracle Standard Report had substr to 9 characters, but Mellon bank has 10 characters
,      aba.BANK_ACCOUNT_NUM raw_bank_account_num
,	   REPLACE(aba.BANK_ACCOUNT_NUM,'-') bank_account_num
,      ac.CHECK_NUMBER
,	   ac.check_id
,	   ac.check_stock_id
,      ac.AMOUNT raw_amount
,      LPAD(TRIM(TO_CHAR(ac.amount * 100)),10,'0') amount
,      ac.CHECK_DATE
,      rpad(ac.VENDOR_NAME,60) VENDOR_NAME
,	   rpad(ac.address_line1,60) VENDOR_ADDRESS
,      decode(ac.STATUS_LOOKUP_CODE,'ISSUED','NEGOTIABLE',ac.STATUS_LOOKUP_CODE) STATUS_LOOKUP_CODE
,      ac.CURRENCY_CODE
from   ap_checks ac
,      ap_check_stocks acs
,      ap_bank_accounts aba
,      ap_bank_branches abb
where 1 = 1
   and ac.payment_method_lookup_code = 'CHECK'
   and ac.check_stock_id = acs.check_stock_id
   and acs.bank_account_id = aba.bank_account_id
   and aba.bank_branch_id = abb.bank_branch_id
   and abb.bank_num = p_bank_num
   and aba.bank_account_num = p_bank_acct_num
   and ac.org_id = p_org_id
   AND (
        (trunc(ac.check_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
         OR
        (trunc(ac.void_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
       )
order by 1,2,3 ;*/
select
  lpad(CBB.BRANCH_NUMBER,10,0) BANK_NUM -- Oracle Standard Report had substr to 9 characters, but Mellon bank has 10 characters
,      ba.BANK_ACCOUNT_NUM raw_bank_account_num
,	   REPLACE(ba.BANK_ACCOUNT_NUM,'-') bank_account_num
,      ac.CHECK_NUMBER
,	   ac.check_id
,	   ac.PAYMENT_DOCUMENT_ID check_stock_id
,      ac.AMOUNT raw_amount
,      LPAD(TRIM(TO_CHAR(ac.amount * 100)),10,'0') amount
,      ac.CHECK_DATE
,      rpad(ac.VENDOR_NAME,60) VENDOR_NAME
,	   rpad(ac.address_line1,60) VENDOR_ADDRESS
,      decode(ac.STATUS_LOOKUP_CODE,'ISSUED','NEGOTIABLE',ac.STATUS_LOOKUP_CODE) STATUS_LOOKUP_CODE
,      ac.CURRENCY_CODE
FROM ce_payment_documents pd ,
    ce_bank_accounts ba ,
  ce_bank_branches_v cbb,
  ap_Checks_all ac
  WHERE ac.payment_method_lookup_code = 'CHECK'
AND pd.internal_bank_account_id           = ba.bank_account_id
and ba.bank_branch_id = cbb.branch_party_id
and PD.PAYMENT_DOCUMENT_ID = AC.PAYMENT_DOCUMENT_ID
and cbb.branch_number = p_bank_num
   and ba.bank_account_num = p_bank_acct_num
   and ac.org_id = p_org_id
   AND (
        (trunc(ac.check_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
         OR
        (trunc(ac.void_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
       )
order by 1,2,3 ;
--/* R12 Upgrade Modified on 09/25/2012 by Sreeram Boppana, Rolta */
l_company_name    CONSTANT varchar2(10) NOT NULL := 'HAEMONETIC';
l_receiving_loc   CONSTANT varchar2(10) NOT NULL := 'MELLONBANK';
l_rx_bank_branch  varchar2(10);

-- file  definition
l_file             UTL_FILE.FILE_TYPE;
l_file_name        VARCHAR2(100) := NULL;
l_file_name_log    VARCHAR2(100) := NULL;
-- file paths
-- See version 5.0 comments
-- l_file_path        VARCHAR2(200) := FND_PROFILE.VALUE('UTL_FILE_LOG');
-- l_dest_path        VARCHAR2(200) := FND_PROFILE.VALUE('UTL_FILE_OUT');
l_org_id      	   NUMBER;
l_header_rec  	   varchar2(250);
l_service_rec 	   varchar2(250);
l_service_tot_rec  varchar2(250);
l_detail_rec  	   varchar2(250);
l_trailer_rec  	   varchar2(250);
l_status_lookup_code_val NUMBER := 0;
l_add_issue_count  NUMBER := 0;
l_tot_issue_amount NUMBER := 0;
l_void_issue_count NUMBER := 0;
l_tot_void_amount  NUMBER := 0;
l_tot_record_count NUMBER := 0;
l_user_id          NUMBER := 0;
BEGIN
  -- Deriving the organizaiton id and user_id
  FND_CLIENT_INFO.SET_ORG_CONTEXT(FND_PROFILE.VALUE('ORG_ID'));
  l_org_id  := FND_PROFILE.VALUE('ORG_ID');
  l_user_id := FND_GLOBAL.user_id ;
  -- See version 5.0 comments
  /*
  -- Creating the File Name Specified
  BEGIN
    SELECT  'XXHA'||TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS')||'.dat'
    INTO    l_file_name
    FROM    dual;
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Positive Pay File created in '||l_dest_path||
                   ' Directory and file name is  '||l_file_name);
  EXCEPTION
      WHEN OTHERS THEN
        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error'||SUBSTR(SQLERRM,1,100));
        errbuf :='Error in defining file name';
  END;
  */
  -- See version 5.0 comments
  /*
  -- opening the file to write
  BEGIN
   l_file := UTL_FILE.FOPEN(l_file_path,l_file_name ,'w','32767');
  EXCEPTION
   WHEN UTL_FILE.WRITE_ERROR THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR writing data '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR writing data '||SUBSTR(SQLERRM,1,100));
    errbuf :='Errors while writing file';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
   WHEN UTL_FILE.INVALID_PATH THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid Path '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR Invalid Path '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Errors Invalid Path';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
   WHEN UTL_FILE.INVALID_MODE THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid Mode '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR Invalid Mode '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Errors Invalid mode';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
   WHEN UTL_FILE.READ_ERROR THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR in reading the data '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR in reading the data '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Unknown Errors in reading the file ';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
   WHEN UTL_FILE.INVALID_FILENAME THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid File Name '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' -  ERROR Invalid File Name data '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Error Invalid File Name';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
   WHEN UTL_FILE.INVALID_OPERATION THEN
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'Error'||SUBSTR(SQLERRM,1,200));
    ROLLBACK;
    errbuf :='Error Invalid Operation';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
    RETURN;
   WHEN OTHERS THEN
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'Error'||SUBSTR(SQLERRM,1,200));
    ROLLBACK;
    errbuf :='Unknown Errors';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
  END; -- done with file handling
  */
  l_header_rec := '1'||RPAD(' ',2,' ')||RPAD(l_receiving_loc,10,' ')||RPAD(l_company_name,10,' ')||RPAD(to_char(sysdate,'YYMMDD'),6,' ')||
           RPAD(to_char(sysdate,'HH24MI'),4,' ')||RPAD(' ',209,' ');
  fnd_file.put_line(FND_FILE.OUTPUT,l_header_rec);
  -- See version 5.0 comments
  -- utl_file.put_line(l_file,l_header_rec);
  l_service_rec := '2'||RPAD(0,30,0)||'100'||'242'||'0242'||'1'||RPAD('',200,'');
  fnd_file.put_line(FND_FILE.OUTPUT,l_service_rec);
  -- See version 5.0 comments
  -- utl_file.put_line(l_file,l_service_rec);
  FOR c_bank_acct in cur_bank_account
  LOOP
   l_void_issue_count := 0;
   l_tot_void_amount  := 0;
   l_add_issue_count  := 0;
   l_tot_issue_amount := 0;
      FOR c_details in cur_check_content(l_org_id,c_bank_acct.branch_number,c_bank_acct.bank_account_num)
      LOOP
        l_detail_rec := NULL ;
		-- Brian Schlott and Mary Dicey (Mellon Bank) confirmed the below logic via e-mail dated 4/1/2009 3:02pm EDT
		IF lpad(c_details.bank_num,10,0) = '0043000261' THEN
          l_rx_bank_branch := 'MELLONWEST'; -- for Pittsburgh
		ELSIF lpad(c_details.bank_num,10,0) = '0031000037' THEN
          l_rx_bank_branch := 'MELLONEAST';  -- for Philadelphia
		ELSIF lpad(c_details.bank_num,10,0) = '0011001234' THEN
          l_rx_bank_branch := 'MELLONTRUS';  -- for Boston
        ELSE l_rx_bank_branch := 'BOSTONNOW '; -- for Boston-Third party recon
		END IF ;
		-- IF c_details.status_lookup_code = 'VOIDED' THEN
        -- Refer to version 6.0 comments in Modification History above
        IF c_details.status_lookup_code in ('OVERFLOW','VOIDED','SETUP','SPOILED') THEN
          l_status_lookup_code_val := 6 ;
		ELSE
		  l_status_lookup_code_val := 2 ;
		END IF ;
    	l_detail_rec := '6'||to_char(LPAD(l_status_lookup_code_val,1,0))||RPAD(l_company_name,10,' ')||RPAD(l_rx_bank_branch,10,' ')||
    	                to_char(LPAD(c_details.bank_account_num,10,0))||to_char(LPAD(c_details.check_number,10,0))||to_char(LPAD(c_details.amount,10,0))||
    					TO_CHAR(c_details.check_date,'YYMMDD')||RPAD(' ',10,' ')||RPAD(' ',5,' ')||RPAD(' ',49,' ')||
    					RPAD(c_details.vendor_name,60,' ')||RPAD(c_details.vendor_address,60,' ');
		-- This update is required as per the standard Oracle report AFTER_REPORT trigger which does the same
        UPDATE ap_checks_all
        SET    positive_pay_status_code = DECODE(status_lookup_code,
			   							  		'NEGOTIABLE','SENT AS NEGOTIABLE',
        		  						   	 	'ISSUED', 'SENT AS NEGOTIABLE',
        										'CLEARED','SENT AS NEGOTIABLE',
        										'CLEARED BUT UNACCOUNTED', 'SENT AS NEGOTIABLE',
											    'RECONCILED','SENT AS NEGOTIABLE',
                          						'RECONCILED UNACCOUNTED','SENT AS NEGOTIABLE',
											    'VOIDED','SENT AS VOIDED',
											    'SPOILED' ,'SENT AS VOIDED',
                          						'SET UP','SENT AS VOIDED',
                          						'OVERFLOW','SENT AS VOIDED')
        ,      last_updated_by  = l_user_id
        ,      last_update_date = sysdate
        WHERE check_id = c_details.check_id
        AND   check_number = c_details.check_number
        AND   PAYMENT_DOCUMENT_ID = c_details.check_stock_id ;
        --AND   check_stock_id = c_details.check_stock_id ;
--/* R12 Upgrade Modified on 10/01/2012 by SBoppana, Rolta */
		l_tot_record_count := l_tot_record_count + 1;
        -- if c_details.status_lookup_code = 'VOIDED' then
        -- Refer to version 7.0 comments in Modification History above
        if c_details.status_lookup_code in ('OVERFLOW','VOIDED','SETUP','SPOILED') then
    	  l_void_issue_count := l_void_issue_count + 1;
		  l_tot_void_amount  := l_tot_void_amount + NVL(c_details.amount,0);
    	else
    	  l_add_issue_count  := l_add_issue_count + 1 ;
		  l_tot_issue_amount := l_tot_issue_amount + NVL(c_details.amount,0);
    	end if;
        fnd_file.put_line(FND_FILE.OUTPUT,l_detail_rec);
        -- See version 5.0 comments
        -- utl_file.put_line(l_file,l_detail_rec);
      END LOOP ;
	  fnd_file.put_line(FND_FILE.LOG,'DEBUG: l_add_issue_count:'||l_add_issue_count||'; l_tot_issue_amount:'||l_tot_issue_amount||'; l_void_issue_count:'||l_void_issue_count||'; l_tot_void_amount:'||l_tot_void_amount);
	  l_service_tot_rec := '8'||LPAD(l_add_issue_count,10,0)||LPAD(l_tot_issue_amount,12,0)||
	                   LPAD(l_void_issue_count,10,0)||LPAD(l_tot_void_amount,12,0)||RPAD(' ',197,' ');
      fnd_file.put_line(FND_FILE.OUTPUT,l_service_tot_rec);
      -- See version 5.0 comments
      -- utl_file.put_line(l_file,l_service_tot_rec);
  END LOOP ;
  l_trailer_rec := '9'||LPAD(l_tot_record_count,6,0)||RPAD(' ',235,' ');
  fnd_file.put_line(FND_FILE.OUTPUT,l_trailer_rec);
  -- See version 5.0 comments
  -- utl_file.put_line(l_file,l_trailer_rec);
  -- utl_file.fclose(l_file);
  IF NVL(l_tot_record_count,0) = 0 THEN
     -- See version 5.0 comments
     -- utl_file.fremove(l_file_path, l_file_name);
     -- FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'No File was created because of ' ||to_char(l_tot_record_count) || ' records ');
     FND_FILE.PUT_LINE( FND_FILE.LOG, 'No File was created because of ' ||to_char(l_tot_record_count) || ' records ');
  ELSE
    -- See version 5.0 comments
    /*
     BEGIN
       utl_file.fcopy(l_file_path,l_file_name,l_dest_path,l_file_name);
     EXCEPTION
       WHEN UTL_FILE.WRITE_ERROR THEN
         FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR copying data to out directory '||SUBSTR(SQLERRM,1,100));
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR copying data to out directory '||SUBSTR(SQLERRM,1,100));
         ROLLBACK;
         errbuf :='ERROR writing files';
         retcode := -1;
         UTL_FILE.FCLOSE(l_file);
         RETURN;
      WHEN UTL_FILE.INVALID_PATH THEN
         FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid Copy Path '||SUBSTR(SQLERRM,1,100));
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR Invalid Copy Path '||SUBSTR(SQLERRM,1,100));
         ROLLBACK;
         errbuf :='ERROR  Invalid Copy Path';
         retcode := -1;
         UTL_FILE.FCLOSE(l_file);
         RETURN;
      WHEN UTL_FILE.INVALID_MODE THEN
         FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid Mode to Copy to out directory '||SUBSTR(SQLERRM,1,100));
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR Invalid Mode to Copy to out directory '||SUBSTR(SQLERRM,1,100));
         ROLLBACK;
         errbuf :='ERROR Invalid Mode to Copy to out directory';
         retcode := -1;
         UTL_FILE.FCLOSE(l_file);
         RETURN;
      WHEN UTL_FILE.READ_ERROR THEN
         FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR reading data from out directory '||SUBSTR(SQLERRM,1,100));
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR reading data from out directory '||SUBSTR(SQLERRM,1,100));
         ROLLBACK;
         errbuf :='ERROR reading data from out directory ';
         retcode := -1;
         UTL_FILE.FCLOSE(l_file);
         RETURN;
      WHEN UTL_FILE.INVALID_FILENAME THEN
         FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid File Name to Copy'||SUBSTR(SQLERRM,1,100));
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' - ERROR Invalid File Name data to Copy'||SUBSTR(SQLERRM,1,100));
         ROLLBACK;
         errbuf:='ERROR Invalid File Name to Copy';
  		 retcode := -1;
  		 UTL_FILE.FCLOSE(l_file);
 		 RETURN;
   	  WHEN UTL_FILE.INVALID_OPERATION THEN
   	  	 FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'Error'||SUBSTR(SQLERRM,1,200));
         ROLLBACK;
   		 errbuf :='Error Invalid Operation';
   		 retcode := -1;
   		 UTL_FILE.FCLOSE(l_file);
   		 RETURN;
   	  WHEN OTHERS THEN
   	  	 FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'Error'||SUBSTR(SQLERRM,1,200));
   		 ROLLBACK;
   		 errbuf :='Unknown Errors';
   		 retcode := -1;
   		 UTL_FILE.FCLOSE(l_file);
   		 RETURN;
     END;
    */
   null;
   END IF;
  commit; -- Commit is required for the AP_CHECKS update
  -- Outer Block exception
  EXCEPTION
    WHEN OTHERS THEN
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -Unexpected error '||SQLERRM);
       FND_FILE.PUT_LINE(FND_FILE.LOG,' Unexpected error : '||SQLERRM);
	   IF cur_bank_account%ISOPEN THEN
           CLOSE cur_bank_account;
       END IF;
	   IF cur_check_content%ISOPEN THEN
           CLOSE cur_check_content;
       END IF;
       -- See version 5.0 comments
	   -- UTL_FILE.FCLOSE_ALL;    -- close the file
       errbuf :='Unknown Errors occured';
       retcode := -1;
 END gen_ppay;
END XXHA_AP_POSITIVE_PAY_PKG;
/
