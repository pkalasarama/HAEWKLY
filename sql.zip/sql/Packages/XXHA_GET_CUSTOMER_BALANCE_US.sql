CREATE OR REPLACE PACKAGE XXHA_GET_CUSTOMER_BALANCE_US AUTHID CURRENT_USER AS

/*************************************************************************************************************
* Package Name : XXHA_GET_CUSTOMER_BALANCE_US                                                                *
* Purpose      : This package provides functions to create the table 'XXHA_AR_CUSTOMER_BALANCE_ITF'.         *
*                This package will be used by the XML Report 'XXHA: Customer Open Balance Letter XX'.        *
*                It is called from within 'Report Triggers' > 'Before Report'                                *
*                                                                                                            *
* Procedures   : ar_get_customer_balance                                                                     *
*                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)            *
* - XXHA_AR_CUSTOMER_BALANCE_ITF      U                                                                      *
* - hz_cust_accounts                  S                                                                      *
* - hz_parties party                  S                                                                      *
* - hz_cust_acct_sites                S                                                                      *
* - hz_party_sites                    S                                                                      *
* - hz_locations                      S                                                                      *
* - hz_cust_site_uses                 S                                                                      *
* - ar_payment_schedules              S                                                                      *
* - hr_all_organization_units         S                                                                      *
* - hr_operating_units                S                                                                      *
* - ar_system_parameters              S                                                                      *
* - fnd_languages                     S                                                                      *
* - gl_sets_of_books                  S                                                                      *
* - ar_receivable_applications        S                                                                      *
* - ar_adjustments                    S                                                                      *
* - ar_cash_receipts                  S                                                                      *
* - ar_cash_receipt_history           S                                                                      *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver        Date            Author               Description                                                *
* ------     -----------     -----------------    ---------------                                            *
* 1.0        22-JUN-2010     BMarcoux             Modification to package to add BillTo Customer,            *
*                                                   Due Date and Days Late to the table                      *
*                                                   'XXHA_AR_CUSTOMER_BALANCE_ITF'. Also removed code        *
*                                                   that wrote to table when processing unapplied            *
*                                                   receipts.                                                *
*                                                                                                            *
* 2.0        17-JAN-2011     BMarcoux             Removed call to ARPT_SQL_FUNC_UTIL.GET_FIRST_REAL_DUE_DATE *
*                                                   that was used to retrieve the Due Date.  Instead, using  *
*                                                   ar_payment_schedules.due_date which holds the correct    *
*                                                   value.                                                   *
*                                                                                                            *
* 3.0        09-JUN-2011     BMarcoux             Added new processing to allow selection of HSS Invoices,   *
*                                                   non-HSS Invoices or All Invoices.                        *
*                                                                                                            *
* 4.0        02-MAR-2012     BMarcoux             Added new code to allow processing of accounts with        *
*                                                   multiple BillTo's.  If a customer has multiple BillTo    *
*                                                   records and one of the BillTo's has the business use of  *
*                                                   'STMTS' then this BillTo will be used to consolidate the *
*                                                   Invoices for reporting.  Conversely, if a customer has   *
*                                                   multiple BillTo's but none are set up with the business  *
*                                                   use of 'STMTS' then each BillTo's Invoices will be       *
*                                                   reported on the statement.                               *
*                                                                                                            *
* 5.0        13-JUN-2012     BMarcoux             Correction to update Location Address information when     *
*                                                   over-writing the Customer BillTo Information when        *
*                                                   processing 'STATEMENTS'.                                 *
*                                                                                                            *
* 6.0        25-FEB-2011     BMarcoux             Added new processing to allow selection of RxC Invoices.   *
*                                                                                                            *
* 7.0        04-Oct-2012     Venkatesh Sarangam   R12 Upgrade                                                *
*                                                                                                            *
* 7.1        07-May-2014     DBROWNE              Fix for moac, R12 Upgrade                                  *
*                                                                                                            *
**************************************************************************************************************/

 /* $Header: arxcobls.pls 120.3 2005/10/30 04:42:54 appldev ship $ */

 g_org_id number := FND_PROFILE.VALUE('ORG_ID');

 procedure ar_get_customer_balance
                                 (
                                 p_request_id number
                                ,p_set_of_books_id number
                                ,p_as_of_date in date
                                ,p_customer_name_from in varchar
                                ,p_customer_name_to in varchar
                                ,p_customer_number_low in varchar
                                ,p_customer_number_high in varchar
                                ,p_currency in varchar
                                ,p_min_invoice_balance in number
                                ,p_min_open_balance in number
                                ,p_account_credits varchar
                                ,p_account_receipts varchar
                                ,p_unapp_receipts varchar
                                ,p_uncleared_receipts varchar
                                ,p_ref_no in varchar
                                ,p_debug_flag in  varchar
                                ,p_trace_flag in varchar
                                ,p_transaction in varchar           --3.0
                                ,p_flex_value_set_id in number      --3.0
                                ,p_flex_value_set_id_rxc in number  --6.0
                                 );

 end XXHA_GET_CUSTOMER_BALANCE_US;
/


CREATE OR REPLACE PACKAGE BODY      xxha_get_customer_balance_us
AS
/*************************************************************************************************************
* Package Name : XXHA_GET_CUSTOMER_BALANCE_US                                                                *
* Purpose      : This package provides functions to create the table 'XXHA_AR_CUSTOMER_BALANCE_ITF'.         *
*                This package will be used by the XML Report 'XXHA: Customer Open Balance Letter XX'.        *
*                It is called from within 'Report Triggers' > 'Before Report'                                *
*                                                                                                            *
* Procedures   : ar_get_customer_balance                                                                     *
*                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)            *
* - XXHA_AR_CUSTOMER_BALANCE_ITF      U                                                                      *
* - hz_cust_accounts                  S                                                                      *
* - hz_parties party                  S                                                                      *
* - hz_cust_acct_sites                S                                                                      *
* - hz_party_sites                    S                                                                      *
* - hz_locations                      S                                                                      *
* - hz_cust_site_uses                 S                                                                      *
* - ar_payment_schedules              S                                                                      *
* - hr_all_organization_units         S                                                                      *
* - hr_operating_units                S                                                                      *
* - ar_system_parameters              S                                                                      *
* - fnd_languages                     S                                                                      *
* - gl_sets_of_books                  S                                                                      *
* - ar_receivable_applications        S                                                                      *
* - ar_adjustments                    S                                                                      *
* - ar_cash_receipts                  S                                                                      *
* - ar_cash_receipt_history           S                                                                      *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver        Date            Author               Description                                                *
* ------     -----------     -----------------    ---------------                                            *
* 1.0        22-JUN-2010     BMarcoux             Modification to package to add BillTo Customer,            *
*                                                   Due Date and Days Late to the table                      *
*                                                   'XXHA_AR_CUSTOMER_BALANCE_ITF'. Also removed code        *
*                                                   that wrote to table when processing unapplied            *
*                                                   receipts.                                                *
*                                                                                                            *
* 2.0        17-JAN-2011     BMarcoux             Removed call to ARPT_SQL_FUNC_UTIL.GET_FIRST_REAL_DUE_DATE *
*                                                   that was used to retrieve the Due Date.  Instead, using  *
*                                                   ar_payment_schedules.due_date which holds the correct    *
*                                                   value.                                                   *
*                                                                                                            *
* 3.0        09-JUN-2011     BMarcoux             Added new processing to allow selection of HSS Invoices,   *
*                                                   non-HSS Invoices or All Invoices.                        *
*                                                                                                            *
* 4.0        02-MAR-2012     BMarcoux             Added new code to allow processing of accounts with        *
*                                                   multiple BillTo's.  If a customer has multiple BillTo    *
*                                                   records and one of the BillTo's has the business use of  *
*                                                   'STMTS' then this BillTo will be used to consolidate the *
*                                                   Invoices for reporting.  Conversely, if a customer has   *
*                                                   multiple BillTo's but none are set up with the business  *
*                                                   use of 'STMTS' then each BillTo's Invoices will be       *
*                                                   reported on the statement.                               *
*                                                                                                            *
* 5.0        13-JUN-2012     BMarcoux             Correction to update Location Address information when     *
*                                                   over-writing the Customer BillTo Information when        *
*                                                   processing 'STATEMENTS'.                                 *
*                                                                                                            *
* 6.0        25-FEB-2011     BMarcoux             Added new processing to allow selection of RxC Invoices.   *
*                                                                                                            *
* 7.0        04-Oct-2012     Venkatesh Sarangam   R12 Upgrade                                                *
*                                                                                                            *
* 7.1        07-May-2014     DBROWNE              Fix for moac, R12 Upgrade                                  *
*                                                                                                            *
**************************************************************************************************************/

/* $Header: arxcoblb.pls 120.7 2005/08/18 06:38:36 salladi ship $ *//*------------------------------------------------------------------------------
 Procedure AR_GET_CUSTOMER_BALANCE calulates the customer balance
 based on the parameters entered. It then inserts one row for each invoice,
 credit memo, unapplied receipts,on account receipts and uncleared receipts
 used for calculating the customer balance into the table AR_CUSTOMER_BALANCE_ITF
 --------------------------------------------------------------------------------*/
 /* bug2466471 : Re-create PROCEDURE ar_get_customer_balance.

 At first, get amount_due_original of ps of transactions.

  After that, get application and adjustment information of which gl_date is earliner than p_as_of_date in order to get invoice balance as of p_as_of_date.

  Also, get unapplied and on-account receipts of which gl_date is earlier than p_as_of_date. (Of course, don't get application , unapplied and on-account information of uncleared receipt if p_uncleared_receipts is not 'Y'.)

  And get customer balance on basis of unapplied and on-account receipts and invoice balance as of p_as_of_date.

  Finally, insert these record into AR_CUSTOMER_BALANCE_ITF table.
 */

   /* bug 2657118 Changed the logic, instead of comparing as_of_date  with gl_date of
   transactions and as well as receipts , we'll now compare  as_of_date with trx_date and apply_date whatever may be applicable.
   */
   PROCEDURE ar_get_customer_balance (
      p_request_id              IN   NUMBER,
      p_set_of_books_id         IN   NUMBER,
      p_as_of_date              IN   DATE,
      p_customer_name_from      IN   VARCHAR,
      p_customer_name_to        IN   VARCHAR,
      p_customer_number_low     IN   VARCHAR,
      p_customer_number_high    IN   VARCHAR,
      p_currency                IN   VARCHAR,
      p_min_invoice_balance     IN   NUMBER,
      p_min_open_balance        IN   NUMBER,
      p_account_credits              VARCHAR,
      p_account_receipts             VARCHAR,
      p_unapp_receipts               VARCHAR,
      p_uncleared_receipts           VARCHAR,
      p_ref_no                       VARCHAR,
      p_debug_flag              IN   VARCHAR,
      p_trace_flag              IN   VARCHAR,
      p_transaction             IN   VARCHAR                            --3.0
                                            ,
      p_flex_value_set_id       IN   NUMBER                             --3.0
                                           ,
      p_flex_value_set_id_rxc   IN   NUMBER                             --6.0
   )
   IS
---l_organization_name           gl_sets_of_books.NAME%TYPE;---11I CODE MODIFIED
      l_organization_name             gl_ledgers.NAME%TYPE; ---R12 Remediated
      l_organization_loc_id           hr_all_organization_units.location_id%TYPE;
      --- l_functional_currency_code    gl_sets_of_books.currency_code%type;---11I CODE MODIFIED
      l_functional_currency_code      gl_ledgers.currency_code%TYPE;
      ---R12 Remediated
      l_session_language              VARCHAR2 (40);    /* For MLS changes */
      l_base_language                 VARCHAR2 (40);    /* For MLS changes */
      l_cus_open_bal                  NUMBER;
      l_inv_open_bal                  NUMBER;
      l_amount_adj                    NUMBER;
      l_amount_applied                NUMBER;
      l_earned_discount_taken         NUMBER;
      l_unearned_discount_taken       NUMBER;
      l_rev_amount_applied            NUMBER;
      l_rev_earned_discount_taken     NUMBER;
      l_rev_unearned_discount_taken   NUMBER;
      l_amount_credited               NUMBER;
      l_on_acct_receipts              NUMBER;
      l_unapp_receipts                NUMBER;
      l_rev_on_acct_receipts          NUMBER;
      l_rev_unapp_receipts            NUMBER;
      l_amount_applied_cm             NUMBER;                  /*bug4502121*/
      l_due_date                      DATE;                            -- 1.0
      l_days_late                     NUMBER;                          -- 1.0
      l_stmt_billto                   hz_party_sites.party_site_number%TYPE;
      -- 4.0
      l_count                         NUMBER;                          -- 4.0
      l_address1                      hz_locations.address1%TYPE;      -- 5.0
      l_address2                      hz_locations.address2%TYPE;      -- 5.0
      l_address3                      hz_locations.address3%TYPE;      -- 5.0
      l_address4                      hz_locations.address4%TYPE;      -- 5.0
      l_city                          hz_locations.city%TYPE;          -- 5.0
      l_state                         hz_locations.state%TYPE;         -- 5.0
      l_postal_code                   hz_locations.postal_code%TYPE;   -- 5.0
      l_country                       hz_locations.country%TYPE;       -- 5.0
      l_language                      hz_locations.LANGUAGE%TYPE;      -- 5.0

--  Selects the customer id in the given range of parameters
      CURSOR cusinfo
      IS
         SELECT cust_acct.cust_account_id customer_id,
                cust_acct.account_number, party.party_name,
                party.tax_reference
           FROM hz_cust_accounts cust_acct, hz_parties party
          WHERE cust_acct.party_id = party.party_id
            AND (   p_customer_name_from IS NULL
                 OR UPPER (party.party_name) >= UPPER (p_customer_name_from)
                )
            AND (   p_customer_name_to IS NULL
                 OR UPPER (party.party_name) <= UPPER (p_customer_name_to)
                )
            AND (   p_customer_number_low IS NULL
                 OR UPPER (cust_acct.account_number) >=
                                                 UPPER (p_customer_number_low)
                )
            AND (   p_customer_number_high IS NULL
                 OR UPPER (cust_acct.account_number) <=
                                                UPPER (p_customer_number_high)
                );

      CURSOR siteinfo (p_customer_id ar_payment_schedules.customer_id%TYPE)
      IS
         SELECT site_uses.site_use_id, acct_site.translated_customer_name,
                loc.address1, loc.address2, loc.address3, loc.address4,
                loc.city, loc.state, loc.postal_code, loc.country,
                loc.LANGUAGE, party_site.party_site_number
           FROM hz_cust_acct_sites acct_site,
                hz_party_sites party_site,
                hz_locations loc,
                hz_cust_site_uses site_uses
          WHERE acct_site.cust_account_id = p_customer_id
            AND NVL (acct_site.status, 'A') = 'A'
            AND acct_site.bill_to_flag IN ('Y', 'P')
            AND acct_site.party_site_id = party_site.party_site_id
            AND loc.location_id = party_site.location_id
            AND NVL (site_uses.status, 'A') = 'A'
            AND acct_site.cust_acct_site_id = site_uses.cust_acct_site_id
            AND site_uses.site_use_code = 'BILL_TO';

--       AND  nvl(loc.language,p_base_language)=p_session_language;
--Selects all the currency for a customer site
      CURSOR curinfo (
         p_customer_id   ar_payment_schedules.customer_id%TYPE,
         p_site_use_id   ar_payment_schedules.customer_site_use_id%TYPE
      )
      IS
         SELECT DISTINCT (invoice_currency_code) currency_code
                    FROM ar_payment_schedules ps
                   WHERE ps.customer_id = p_customer_id
                     AND ps.customer_site_use_id = p_site_use_id
                     AND ps.invoice_currency_code =
                                    NVL (p_currency, ps.invoice_currency_code);

      --selects invoices
       -- 2.0 - Removed call to function and replaced with value from ar_payment_schedules.due_date
      CURSOR tot_inv (
         p_customer_id   ar_payment_schedules.customer_id%TYPE,
         p_site_use_id   ar_payment_schedules.customer_site_use_id%TYPE,
         p_currency      ar_payment_schedules.invoice_currency_code%TYPE,
         p_as_of_date    ar_payment_schedules.trx_date%TYPE
      )
      IS
         SELECT ps.payment_schedule_id, ps.CLASS, ps.trx_number, ps.trx_date,
                ps.customer_trx_id, ps.invoice_currency_code,
                ps.amount_due_original, ps.due_date                     -- 2.0
                                                   ,
                tt.NAME "TRANSACTION_TYPE"                              -- 3.0
                                          ,
                bs.NAME "BATCH_SOURCE"                                  -- 3.0
           FROM ar_payment_schedules ps,
                ra_customer_trx rcta                                -- 3.0
                                        ,
                ra_cust_trx_types tt                                -- 3.0
                                        ,
                ra_batch_sources bs                                     -- 3.0
          WHERE TRUNC (ps.trx_date) <= p_as_of_date
            AND ps.CLASS NOT IN
                        ('PMT', DECODE (p_account_credits, 'Y', 'PMT', 'CM'))
            AND ps.invoice_currency_code = p_currency
            AND ps.customer_id = p_customer_id
            AND ps.customer_site_use_id = p_site_use_id
            AND ps.actual_date_closed > p_as_of_date
            AND ps.trx_number = rcta.trx_number                         -- 3.0
            AND ps.customer_trx_id = rcta.customer_trx_id               -- 3.0
            AND rcta.cust_trx_type_id = tt.cust_trx_type_id             -- 3.0
            AND rcta.org_id = tt.org_id                                 -- 3.0
            AND rcta.batch_source_id = bs.batch_source_id               -- 3.0
            AND rcta.org_id = bs.org_id                                 -- 3.0
            AND p_transaction = 'All'                                   -- 3.0
         UNION ALL
         SELECT ps.payment_schedule_id, ps.CLASS, ps.trx_number, ps.trx_date,
                ps.customer_trx_id, ps.invoice_currency_code,
                ps.amount_due_original, ps.due_date                     -- 2.0
                                                   ,
                tt.NAME "TRANSACTION_TYPE"                              -- 3.0
                                          ,
                bs.NAME "BATCH_SOURCE"                                  -- 3.0
           FROM ar_payment_schedules ps,
                ra_customer_trx rcta                                -- 3.0
                                        ,
                ra_cust_trx_types tt                                -- 3.0
                                        ,
                ra_batch_sources bs                                     -- 3.0
          WHERE TRUNC (ps.trx_date) <= p_as_of_date
            AND ps.CLASS NOT IN
                        ('PMT', DECODE (p_account_credits, 'Y', 'PMT', 'CM'))
            AND ps.invoice_currency_code = p_currency
            AND ps.customer_id = p_customer_id
            AND ps.customer_site_use_id = p_site_use_id
            AND ps.actual_date_closed > p_as_of_date
            AND ps.trx_number = rcta.trx_number                         -- 3.0
            AND ps.customer_trx_id = rcta.customer_trx_id               -- 3.0
            AND rcta.cust_trx_type_id = tt.cust_trx_type_id             -- 3.0
            AND rcta.org_id = tt.org_id                                 -- 3.0
            AND rcta.batch_source_id = bs.batch_source_id               -- 3.0
            AND rcta.org_id = bs.org_id                                 -- 3.0
            AND p_transaction = 'Only HSS'                              -- 3.0
            AND (   (SELECT UPPER (RTRIM (tt.NAME))                     -- 3.0
                       FROM                                             -- 3.0
                            ra_cust_trx_types rctp1                 -- 3.0
                                                       ,
                            ra_customer_trx rcta1                   -- 3.0
                      WHERE rcta.customer_trx_id = rcta1.customer_trx_id
                        -- 3.0
                        AND rcta1.cust_trx_type_id = rctp1.cust_trx_type_id
                        -- 3.0
                        AND rcta1.org_id = rctp1.org_id)                -- 3.0
                                                        IN (
                       SELECT (UPPER (RTRIM (vl.flex_value)))           -- 3.0
                         FROM fnd_flex_value_sets st                    -- 3.0
                                                    ,
                              fnd_flex_values_vl vl                     -- 3.0
                        WHERE st.flex_value_set_id = p_flex_value_set_id
                          -- 3.0
                          AND st.flex_value_set_id = vl.flex_value_set_id
                          -- 3.0
                          AND vl.enabled_flag = 'Y')                    -- 3.0
                 OR RTRIM (bs.NAME) IN ('Conversion_CM1', 'Conversion_Inv1')
                )                                                       -- 3.0
         UNION ALL
         SELECT ps.payment_schedule_id, ps.CLASS, ps.trx_number, ps.trx_date,
                ps.customer_trx_id, ps.invoice_currency_code,
                ps.amount_due_original, ps.due_date                     -- 2.0
                                                   ,
                tt.NAME "TRANSACTION_TYPE"                              -- 3.0
                                          ,
                bs.NAME "BATCH_SOURCE"                                  -- 3.0
           FROM ar_payment_schedules ps,
                ra_customer_trx rcta                                -- 3.0
                                        ,
                ra_cust_trx_types tt                                -- 3.0
                                        ,
                ra_batch_sources bs                                     -- 3.0
          WHERE TRUNC (ps.trx_date) <= p_as_of_date
            AND ps.CLASS NOT IN
                        ('PMT', DECODE (p_account_credits, 'Y', 'PMT', 'CM'))
            AND ps.invoice_currency_code = p_currency
            AND ps.customer_id = p_customer_id
            AND ps.customer_site_use_id = p_site_use_id
            AND ps.actual_date_closed > p_as_of_date
            AND ps.trx_number = rcta.trx_number                         -- 3.0
            AND ps.customer_trx_id = rcta.customer_trx_id               -- 3.0
            AND rcta.cust_trx_type_id = tt.cust_trx_type_id             -- 3.0
            AND rcta.org_id = tt.org_id                                 -- 3.0
            AND rcta.batch_source_id = bs.batch_source_id               -- 3.0
            AND rcta.org_id = bs.org_id                                 -- 3.0
            AND p_transaction = 'Exclude HSS null'
            --'Exclude HSS null'                     -- 3.0
            AND (    (    (SELECT UPPER (RTRIM (tt.NAME))               -- 3.0
                             FROM                                       -- 3.0
                                  ra_cust_trx_types rctp1           -- 3.0
                                                             ,
                                  ra_customer_trx rcta1             -- 3.0
                            WHERE rcta.customer_trx_id = rcta1.customer_trx_id
                              -- 3.0
                              AND rcta1.cust_trx_type_id =
                                                        rctp1.cust_trx_type_id
                              -- 3.0
                              AND rcta1.org_id = rctp1.org_id)          -- 3.0
                                                              NOT IN (
                             SELECT (UPPER (RTRIM (vl.flex_value)))     -- 3.0
                               FROM fnd_flex_value_sets st              -- 3.0
                                                          ,
                                    fnd_flex_values_vl vl               -- 3.0
                              WHERE st.flex_value_set_id = p_flex_value_set_id
                                -- 3.0
                                AND st.flex_value_set_id =
                                                          vl.flex_value_set_id
                                -- 3.0
                                AND vl.enabled_flag = 'Y')              -- 3.0
                      AND RTRIM (bs.NAME) NOT IN
                                        ('Conversion_CM1', 'Conversion_Inv1')
                     )                                                  -- 3.0
                 AND (    (SELECT UPPER (RTRIM (tt.NAME))               -- 6.0
                             FROM                                       -- 6.0
                                  ra_cust_trx_types rctp1           -- 6.0
                                                             ,
                                  ra_customer_trx rcta1             -- 6.0
                            WHERE rcta.customer_trx_id = rcta1.customer_trx_id
                              -- 6.0
                              AND rcta1.cust_trx_type_id =
                                                        rctp1.cust_trx_type_id
                              -- 6.0
                              AND rcta1.org_id = rctp1.org_id)          -- 6.0
                                                              NOT IN (
                             SELECT (UPPER (RTRIM (vl.flex_value)))     -- 6.0
                               FROM fnd_flex_value_sets st              -- 6.0
                                                          ,
                                    fnd_flex_values_vl vl               -- 6.0
                              WHERE st.flex_value_set_id =
                                                       p_flex_value_set_id_rxc
                                -- 6.0
                                AND st.flex_value_set_id =
                                                          vl.flex_value_set_id
                                -- 6.0
                                AND vl.enabled_flag = 'Y')              -- 6.0
                      AND RTRIM (bs.NAME) NOT IN
                                    ('Conversion_CM_RX', 'Conversion_Inv_RX')
                     )
                )                                                       -- 6.0
         UNION ALL
-- 6.0 - Processing for RxC Transactions
         SELECT ps.payment_schedule_id, ps.CLASS, ps.trx_number, ps.trx_date,
                ps.customer_trx_id, ps.invoice_currency_code,
                ps.amount_due_original, ps.due_date,
                tt.NAME "TRANSACTION_TYPE", bs.NAME "BATCH_SOURCE"
           FROM ar_payment_schedules ps,
                ra_customer_trx rcta,
                ra_cust_trx_types tt,
                ra_batch_sources bs
          WHERE TRUNC (ps.trx_date) <= p_as_of_date
            AND ps.CLASS NOT IN
                        ('PMT', DECODE (p_account_credits, 'Y', 'PMT', 'CM'))
            AND ps.invoice_currency_code = p_currency
            AND ps.customer_id = p_customer_id
            AND ps.customer_site_use_id = p_site_use_id
            AND ps.actual_date_closed > p_as_of_date
            AND ps.trx_number = rcta.trx_number
            AND ps.customer_trx_id = rcta.customer_trx_id
            AND rcta.cust_trx_type_id = tt.cust_trx_type_id
            AND rcta.org_id = tt.org_id
            AND rcta.batch_source_id = bs.batch_source_id
            AND rcta.org_id = bs.org_id
            AND p_transaction = 'Only RxC'
            AND (   (SELECT UPPER (RTRIM (tt.NAME))
                       FROM ra_cust_trx_types rctp1,
                            ra_customer_trx rcta1
                      WHERE rcta.customer_trx_id = rcta1.customer_trx_id
                        AND rcta1.cust_trx_type_id = rctp1.cust_trx_type_id
                        AND rcta1.org_id = rctp1.org_id) IN (
                       SELECT (UPPER (RTRIM (vl.flex_value)))
                         FROM fnd_flex_value_sets st, fnd_flex_values_vl vl
                        WHERE st.flex_value_set_id = p_flex_value_set_id_rxc
                          AND st.flex_value_set_id = vl.flex_value_set_id
                          AND vl.enabled_flag = 'Y')
                 OR RTRIM (bs.NAME) IN
                                    ('Conversion_CM_RX', 'Conversion_Inv_RX')
                );
-- OLD CODE
--    SELECT  payment_schedule_id,
--            class,
--            trx_number,
--            trx_date,
--            customer_trx_id,
--            invoice_currency_code,
--            amount_due_original,
--            due_date                                                            -- 2.0
--      FROM  ar_payment_schedules ps
--     WHERE  TRUNC(ps.trx_date) <= p_as_of_date
--       AND  ps.class not in ( 'PMT' ,DECODE(p_account_credits, 'Y', 'PMT','CM') )
--       AND  ps.invoice_currency_code=p_currency
--       AND  ps.customer_id= p_customer_id
--       AND  PS.customer_site_use_id=p_site_use_id
--       AND  ps.actual_date_closed > p_as_of_date  ;
--AR CUSTOMER BALANCE PROC BEGINS
   BEGIN
       
      BEGIN
         SELECT hou.location_id
           INTO l_organization_loc_id
           FROM hr_all_organization_units hou,
                hr_operating_units ho,
                ar_system_parameters ar
          WHERE ho.set_of_books_id = ar.set_of_books_id
            AND ho.organization_id = hou.organization_id;
      EXCEPTION
         WHEN OTHERS
         THEN
            fnd_file.put_line (fnd_file.LOG,
                               'Failed on location_id lookup ' || SQLERRM
                              );
            raise_application_error (-20001, 'See log');
      END;

      SELECT SUBSTRB (USERENV ('LANG'), 1, 4)
        INTO l_session_language
        FROM DUAL;

      BEGIN
         SELECT language_code
           INTO l_base_language
           FROM fnd_languages
          WHERE installed_flag = 'B';
      EXCEPTION
         WHEN OTHERS
         THEN
            fnd_file.put_line (fnd_file.LOG,
                               'Failed on language code query ' || SQLERRM
                              );
            raise_application_error (-20001, 'See log');
      END;

      BEGIN
         SELECT sob.NAME
           INTO l_organization_name
           FROM                   ---gl_sets_of_books  sob---11i code modified
                gl_ledgers sob                               ---R12 Remediated
                              ,
                ar_system_parameters ar
          WHERE
                ---sob.set_of_books_id  = ar.set_of_books_id;---11i code modified
                sob.ledger_id = ar.set_of_books_id;
      ---R12 Remediated
      EXCEPTION
         WHEN OTHERS
         THEN
            fnd_file.put_line (fnd_file.LOG,
                               'Failed on SOB lookup ' || SQLERRM
                              );
            raise_application_error (-20001, 'See log');
      END;

      BEGIN
         SELECT currency_code
           INTO l_functional_currency_code
           FROM                   ---gl_sets_of_books  sob---11i code modified
                gl_ledgers sob                               ---R12 Remediated
                              ,
                ar_system_parameters ar
          WHERE
                ---sob.set_of_books_id  = ar.set_of_books_id;---11i code modified
                sob.ledger_id = ar.set_of_books_id;
      ---R12 Remediated
      EXCEPTION
         WHEN OTHERS
         THEN
            fnd_file.put_line (fnd_file.LOG,
                               'Failed on currency code  lookup ' || SQLERRM||' for '||g_org_id
                              );
            raise_application_error (-20001, 'See log');
      END;

-- customer
      FOR cusinfo_rec IN cusinfo
      LOOP
-- site
         FOR siteinfo_rec IN siteinfo (cusinfo_rec.customer_id)
         LOOP
-- currency
            FOR currency_rec IN curinfo (cusinfo_rec.customer_id,
                                         siteinfo_rec.site_use_id
                                        )
            LOOP
               l_cus_open_bal := 0;
               l_unapp_receipts := 0;
               l_on_acct_receipts := 0;
               l_rev_unapp_receipts := 0;
               l_rev_on_acct_receipts := 0;

               -- invoice
               FOR tot_inv_rec IN tot_inv (cusinfo_rec.customer_id,
                                           siteinfo_rec.site_use_id,
                                           currency_rec.currency_code,
                                           p_as_of_date
                                          )
               LOOP
                  BEGIN
                     l_inv_open_bal := 0;
                     l_amount_applied := 0;
                     l_earned_discount_taken := 0;
                     l_unearned_discount_taken := 0;
                     l_rev_amount_applied := 0;
                     l_rev_earned_discount_taken := 0;
                     l_rev_unearned_discount_taken := 0;
                     l_amount_credited := 0;
                     l_amount_applied_cm := 0;                 /*bug4502121*/
                     l_due_date := NULL;                               -- 1.0
                     l_days_late := 0;                                 -- 1.0

-- For CM, get application
                     SELECT NVL (SUM (amount_applied), 0) amount_applied
                       INTO l_amount_applied_cm                 /*bug4502121*/
                       FROM ar_receivable_applications
                      WHERE payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                        AND apply_date <= p_as_of_date
                        AND status || '' = 'APP';

                     IF UPPER (p_uncleared_receipts) = 'Y'
                     THEN
                        -- Cash Application
                        SELECT NVL (SUM (amount_applied), 0) amount_applied,
                               NVL (SUM (earned_discount_taken), 0)
                                                        earned_discount_taken,
                               NVL (SUM (unearned_discount_taken), 0)
                                                      unearned_discount_taken
                          INTO l_amount_applied,
                               l_earned_discount_taken,
                               l_unearned_discount_taken
                          FROM ar_receivable_applications ra
                         WHERE applied_payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                           AND apply_date <= p_as_of_date
                           AND status || '' = 'APP'
                           AND application_type = 'CASH'
                           AND NOT EXISTS (
                                  SELECT 'reversed'
                                    FROM ar_cash_receipt_history crh
                                   WHERE ra.cash_receipt_id =
                                                           crh.cash_receipt_id
                                     AND crh.status = 'REVERSED'
                                     AND crh.trx_date + 0 <= p_as_of_date);
                     ELSE
                        -- Cash Application
                        SELECT NVL (SUM (amount_applied), 0) amount_applied,
                               NVL (SUM (earned_discount_taken), 0)
                                                        earned_discount_taken,
                               NVL (SUM (unearned_discount_taken), 0)
                                                      unearned_discount_taken
                          INTO l_amount_applied,
                               l_earned_discount_taken,
                               l_unearned_discount_taken
                          FROM ar_receivable_applications ra
                         WHERE applied_payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                           AND apply_date <= p_as_of_date
                           AND status || '' = 'APP'
                           AND application_type = 'CASH'
                           AND NOT EXISTS (
                                  SELECT 'reversed'
                                    FROM ar_cash_receipt_history crh
                                   WHERE ra.cash_receipt_id =
                                                           crh.cash_receipt_id
                                     AND crh.status = 'REVERSED'
                                     AND crh.trx_date + 0 <= p_as_of_date)
                           AND EXISTS (
                                  SELECT 'cleared'
                                    FROM ar_cash_receipt_history crh
                                   WHERE ra.cash_receipt_id =
                                                           crh.cash_receipt_id
                                     AND crh.status = 'CLEARED'
                                     AND crh.trx_date + 0 <= p_as_of_date);
                     END IF;

                     l_amount_applied :=
                                       l_amount_applied + l_rev_amount_applied;

-- CM Application
                     SELECT NVL (SUM (amount_applied), 0) amount_applied
                       INTO l_amount_credited
                       FROM ar_receivable_applications
                      WHERE applied_payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                        AND apply_date <= p_as_of_date
                        AND status || '' = 'APP'
                        AND application_type = 'CM';

-- Adjustment
                     SELECT NVL (SUM (amount), 0)
                       INTO l_amount_adj
                       FROM ar_adjustments
                      WHERE payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                        AND apply_date + 0 <= p_as_of_date
                        AND status = 'A';

-- invoice balance
                     l_inv_open_bal :=
                          tot_inv_rec.amount_due_original
                        - l_amount_applied
                        - l_earned_discount_taken
                        - l_unearned_discount_taken
                        - l_amount_credited
                        + l_amount_applied_cm                   /*bug4502121*/
                        + l_amount_adj;

-- p_min_invoice_balance is not effective in on-account cm
                     IF    (    l_inv_open_bal >=
                                                NVL (p_min_invoice_balance, 0)
                            AND l_inv_open_bal <> 0
                           )
                        OR (tot_inv_rec.CLASS = 'CM')
                     THEN
                        l_cus_open_bal := l_cus_open_bal + l_inv_open_bal;
-- 2.0 - Removed call to function and replaced with value from ar_payment_schedules.due_date
                        l_due_date := tot_inv_rec.due_date;
-- 1.0 - Moved code from within rdf to here
-- 2.0 - Removed call to function and replaced with value from ar_payment_schedules.due_date
--   SELECT ARPT_SQL_FUNC_UTIL.GET_FIRST_REAL_DUE_DATE(rcta.CUSTOMER_TRX_ID, rcta.TERM_ID, rcta.TRX_DATE)
--     INTO l_Due_Date
--     FROM ra_customer_trx_all rcta
--    WHERE rcta.customer_trx_id = tot_inv_rec.customer_trx_id;
-- Determine Number of days Late
                        l_days_late := TRUNC (SYSDATE) - TRUNC (l_due_date);

-- If Number of days late is negative (not overdue), then make the value *ZERO
                        IF l_days_late < 0
                        THEN
                           l_days_late := 0;
                        END IF;

--------------------------------------------------------------------------------
-- 4.0 Start of new processing
                        l_stmt_billto := NULL;
-- 5.0 Start of new processing
                        l_address1 := NULL;
                        l_address2 := NULL;
                        l_address3 := NULL;
                        l_address4 := NULL;
                        l_city := NULL;
                        l_state := NULL;
                        l_postal_code := NULL;
                        l_country := NULL;
                        l_language := NULL;

-- Determine if the Customer has a site use code = STMTS (Statements) and select first occurance
                        BEGIN
                           SELECT ps.party_site_number, loc.address1     --5.0
                                                                    ,
                                  loc.address2                           --5.0
                                              , loc.address3             --5.0
                                                            ,
                                  loc.address4                           --5.0
                                              , loc.city                 --5.0
                                                        ,
                                  loc.state                              --5.0
                                           , loc.postal_code             --5.0
                                                            ,
                                  loc.country                            --5.0
                                             , loc.LANGUAGE              --5.0
                             INTO l_stmt_billto, l_address1              --5.0
                                                           ,
                                  l_address2                             --5.0
                                            , l_address3                 --5.0
                                                        ,
                                  l_address4                             --5.0
                                            , l_city                     --5.0
                                                    ,
                                  l_state                                --5.0
                                         , l_postal_code                 --5.0
                                                        ,
                                  l_country                              --5.0
                                           , l_language                  --5.0
                             FROM hz_cust_accounts cust,
                                  hz_cust_acct_sites cas,
                                  hz_cust_site_uses su,
                                  hz_party_sites ps,
                                  hz_locations loc                      -- 5.0
                            WHERE cust.account_number =
                                                    cusinfo_rec.account_number
                              AND cust.cust_account_id = cas.cust_account_id
                              AND NVL (cas.status, 'A') = 'A'
                              AND cas.bill_to_flag IN ('Y', 'P')
                              AND cas.cust_acct_site_id = su.cust_acct_site_id
                              AND cas.party_site_id = ps.party_site_id
                              AND ps.location_id = loc.location_id       --5.0
                              AND su.site_use_code = 'STMTS'
                              AND NVL (su.status, 'A') = 'A'
                              AND ROWNUM = 1;
                        EXCEPTION
                           WHEN NO_DATA_FOUND
                           THEN
                              l_stmt_billto := NULL;
                              l_address1 := NULL;                       --5.0
                              l_address2 := NULL;                       --5.0
                              l_address3 := NULL;                       --5.0
                              l_address4 := NULL;                       --5.0
                              l_city := NULL;                           --5.0
                              l_state := NULL;                          --5.0
                              l_postal_code := NULL;                    --5.0
                              l_country := NULL;                        --5.0
                              l_language := NULL;                       --5.0
                           WHEN OTHERS
                           THEN
                              raise_application_error
                                 (-99999,
                                     'Unknown Exception in Customer processing to retrieve STMTS Cust Site Uses - Cust: '
                                  || TO_CHAR (cusinfo_rec.account_number)
                                 );
                        END;

-- 4.0 End of new processing
--------------------------------------------------------------------------------

                        --------------------------------------------------------------------------------
-- 5.0 Start of new processing
-- If there is not a 'STATEMENT' record for the customer
                        IF l_stmt_billto IS NULL
                        THEN
                           INSERT INTO xxha_ar_customer_balance_itf
                                       (request_id, as_of_date,
                                        organization_name,
                                        org_location_id,
                                        functional_currency_code,
                                        customer_name,
                                        customer_number,
                                        billto_number,                  -- 1.0
                                        tax_reference_num,
                                        address_line1,
                                        address_line2,
                                        address_line3,
                                        address_line4,
                                        city,
                                        state,
                                        zip,
                                        country,
                                        LANGUAGE,
                                        trans_type,
                                        trx_number,
                                        transaction_date,
                                        customer_trx_id,
                                        trx_currency_code,
                                        trans_amount,
                                        trans_amount_remaining,
                                        receipt_amount,
                                        adjustment_amount,
                                        earned_discount_amount,
                                        unearned_discount_amount,
                                        invoice_credit_amount, bank_charge,
                                        on_account_credit_amount,
                                        on_account_receipts,
                                        unapplied_receipts, due_date,   -- 1.0
                                        days_late                       -- 1.0
                                       )
                                VALUES (p_request_id, p_as_of_date,
                                        l_organization_name,
                                        l_organization_loc_id,
                                        l_functional_currency_code,
                                        NVL
                                           (siteinfo_rec.translated_customer_name,
                                            cusinfo_rec.party_name
                                           ),
                                        cusinfo_rec.account_number,
                                        siteinfo_rec.party_site_number,
                                        -- 1.0 , 4.0
                                        cusinfo_rec.tax_reference,
                                        siteinfo_rec.address1,
                                        siteinfo_rec.address2,
                                        siteinfo_rec.address3,
                                        siteinfo_rec.address4,
                                        siteinfo_rec.city,
                                        siteinfo_rec.state,
                                        siteinfo_rec.postal_code,
                                        siteinfo_rec.country,
                                        siteinfo_rec.LANGUAGE,
                                        tot_inv_rec.CLASS,
                                        tot_inv_rec.trx_number,
                                        tot_inv_rec.trx_date,
                                        tot_inv_rec.customer_trx_id,
                                        tot_inv_rec.invoice_currency_code,
                                        DECODE
                                           (tot_inv_rec.CLASS,
                                            'CM', 0,
                                            NVL
                                               (tot_inv_rec.amount_due_original,
                                                0
                                               )
                                           ),
                                        DECODE (tot_inv_rec.CLASS,
                                                'CM', 0,
                                                NVL (l_inv_open_bal, 0)
                                               ),
                                        NVL (l_amount_applied, 0),
                                        NVL (l_amount_adj, 0),
                                        NVL (l_earned_discount_taken, 0),
                                        NVL (l_unearned_discount_taken, 0),
                                        NVL (l_amount_credited, 0), 0,
                                        DECODE (tot_inv_rec.CLASS,
                                                'CM', NVL (l_inv_open_bal, 0),
                                                0
                                               ),
                                        0,
                                        0, l_due_date,                  -- 1.0
                                        l_days_late                     -- 1.0
                                       );
                        END IF;

-- If there is a 'STATEMENT' record for the customer
                        IF l_stmt_billto IS NOT NULL
                        THEN
                           INSERT INTO xxha_ar_customer_balance_itf
                                       (request_id, as_of_date,
                                        organization_name,
                                        org_location_id,
                                        functional_currency_code,
                                        customer_name,
                                        customer_number,
                                        billto_number,
                                        tax_reference_num,
                                        address_line1, address_line2,
                                        address_line3, address_line4, city,
                                        state, zip, country,
                                        LANGUAGE, trans_type,
                                        trx_number,
                                        transaction_date,
                                        customer_trx_id,
                                        trx_currency_code,
                                        trans_amount,
                                        trans_amount_remaining,
                                        receipt_amount,
                                        adjustment_amount,
                                        earned_discount_amount,
                                        unearned_discount_amount,
                                        invoice_credit_amount, bank_charge,
                                        on_account_credit_amount,
                                        on_account_receipts,
                                        unapplied_receipts, due_date,   -- 1.0
                                        days_late                       -- 1.0
                                       )
                                VALUES (p_request_id, p_as_of_date,
                                        l_organization_name,
                                        l_organization_loc_id,
                                        l_functional_currency_code,
                                        NVL
                                           (siteinfo_rec.translated_customer_name,
                                            cusinfo_rec.party_name
                                           ),
                                        cusinfo_rec.account_number,
                                        l_stmt_billto,
                                        cusinfo_rec.tax_reference,
                                        l_address1, l_address2,
                                        l_address3, l_address4, l_city,
                                        l_state, l_postal_code, l_country,
                                        l_language, tot_inv_rec.CLASS,
                                        tot_inv_rec.trx_number,
                                        tot_inv_rec.trx_date,
                                        tot_inv_rec.customer_trx_id,
                                        tot_inv_rec.invoice_currency_code,
                                        DECODE
                                           (tot_inv_rec.CLASS,
                                            'CM', 0,
                                            NVL
                                               (tot_inv_rec.amount_due_original,
                                                0
                                               )
                                           ),
                                        DECODE (tot_inv_rec.CLASS,
                                                'CM', 0,
                                                NVL (l_inv_open_bal, 0)
                                               ),
                                        NVL (l_amount_applied, 0),
                                        NVL (l_amount_adj, 0),
                                        NVL (l_earned_discount_taken, 0),
                                        NVL (l_unearned_discount_taken, 0),
                                        NVL (l_amount_credited, 0), 0,
                                        DECODE (tot_inv_rec.CLASS,
                                                'CM', NVL (l_inv_open_bal, 0),
                                                0
                                               ),
                                        0,
                                        0, l_due_date,                  -- 1.0
                                        l_days_late                     -- 1.0
                                       );
                        END IF;
-- 5.0 End of new processing
--------------------------------------------------------------------------------
                     END IF;
                  END;
-- tot_inv
               END LOOP;

-- unapplied receipt and on account receipt
               IF UPPER (p_uncleared_receipts) = 'Y'
               THEN
                  SELECT NVL (SUM (DECODE (ra.status,
                                           'ACC', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             ),
                         NVL (SUM (DECODE (ra.status,
                                           'UNAPP', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             )
                    INTO l_on_acct_receipts,
                         l_unapp_receipts
                    FROM ar_receivable_applications ra, ar_cash_receipts cr
                   WHERE ra.cash_receipt_id = cr.cash_receipt_id
                     AND cr.pay_from_customer = cusinfo_rec.customer_id
                     AND cr.customer_site_use_id = siteinfo_rec.site_use_id
                     AND cr.currency_code = currency_rec.currency_code
                     AND ra.apply_date + 0 <= p_as_of_date
                     AND ra.status IN ('ACC', 'UNAPP')
                     AND NOT EXISTS (
                            SELECT 'reversed'
                              FROM ar_cash_receipt_history crh
                             WHERE ra.cash_receipt_id = crh.cash_receipt_id
                               AND crh.status = 'REVERSED'
                               AND crh.trx_date + 0 <= p_as_of_date);
               ELSE
                  /* bug3692732 : Added cr.pay_from_customer = cusinfo_rec.customer_id to where clause
                                  to prevent FTS on table ar_cash_receipts */
                  SELECT NVL (SUM (DECODE (ra.status,
                                           'ACC', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             ),
                         NVL (SUM (DECODE (ra.status,
                                           'UNAPP', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             )
                    INTO l_on_acct_receipts,
                         l_unapp_receipts
                    FROM ar_receivable_applications ra, ar_cash_receipts cr
                   WHERE ra.cash_receipt_id = cr.cash_receipt_id
                     AND cr.pay_from_customer = cusinfo_rec.customer_id
                     AND cr.currency_code = currency_rec.currency_code
                     AND cr.customer_site_use_id = siteinfo_rec.site_use_id
                     AND apply_date + 0 <= p_as_of_date
                     AND ra.status IN ('ACC', 'UNAPP')
                     AND NOT EXISTS (
                            SELECT 'reversed'
                              FROM ar_cash_receipt_history crh
                             WHERE ra.cash_receipt_id = crh.cash_receipt_id
                               AND crh.status = 'REVERSED'
                               AND crh.trx_date + 0 <= p_as_of_date)
                     AND EXISTS (
                            SELECT 'cleared'
                              FROM ar_cash_receipt_history crh
                             WHERE ra.cash_receipt_id = crh.cash_receipt_id
                               AND crh.status = 'CLEARED'
                               AND crh.trx_date + 0 <= p_as_of_date);
               END IF;

               IF UPPER (p_account_receipts) = 'Y'
               THEN
                  l_on_acct_receipts :=
                                  l_on_acct_receipts + l_rev_on_acct_receipts;
               ELSE
                  l_on_acct_receipts := 0;
               END IF;

               IF UPPER (p_unapp_receipts) = 'Y'
               THEN
                  l_unapp_receipts := l_unapp_receipts + l_rev_unapp_receipts;
               ELSE
                  l_unapp_receipts := 0;
               END IF;

               l_cus_open_bal :=
                        l_cus_open_bal - l_on_acct_receipts - l_unapp_receipts;
-- 1.0
               l_due_date := NULL;
               l_days_late := 0;

--             IF ( l_unapp_receipts <> 0 ) OR ( l_on_acct_receipts <> 0 )
--             THEN
--               INSERT INTO XXHA_AR_CUSTOMER_BALANCE_ITF(Request_id,
--                                             as_of_date,
--                                             organization_name,
--                                             org_location_id,
--                                             functional_currency_code,
--                                             customer_name,
--                                             customer_number,
--                                             billto_number,                     -- 1.0
--                                             tax_reference_num,
--                                             address_line1,
--                                             address_line2,
--                                             address_line3,
--                                             address_line4,
--                                             city,
--                                             state,
--                                             zip,
--                                             country,
--                                             language,
--                                             trans_type,
--                                             trx_number,
--                                             transaction_date,
--                                             customer_trx_id,
--                                             trx_currency_code,
--                                             trans_amount,
--                                             trans_amount_remaining,
--                                             receipt_amount,
--                                             adjustment_amount,
--                                             earned_discount_amount,
--                                             unearned_discount_amount,
--                                             invoice_credit_amount,
--                                             bank_charge,
--                                             on_account_credit_amount,
--                                             on_account_receipts,
--                                             unapplied_receipts,
--                                             Due_Date,                           -- 1.0
--                                             Days_Late)                          -- 1.0
--                VALUES (p_request_id,
--                       p_as_of_date,
--                       l_organization_name,
--                       l_organization_loc_id,
--                       l_functional_currency_code,
--                       nvl(siteinfo_rec.translated_customer_name,cusinfo_rec.party_name),
--                       cusinfo_rec.account_number,
--                       siteinfo_rec.party_site_number,                          -- 1.0
--                       cusinfo_rec.tax_reference,
--                       siteinfo_rec.address1,
--                       siteinfo_rec.address2,
--                       siteinfo_rec.address3,
--                       siteinfo_rec.address4,
--                       siteinfo_rec.city,
--                       siteinfo_rec.state,
--                       siteinfo_rec.postal_code,
--                       siteinfo_rec.country,
--                       siteinfo_rec.language,
--                       'PMT' ,
--                       'On Account Receipt' ,
--                       p_as_of_date,
--                       0,
--                       currency_rec.currency_code,
--                       0,
--                       0,
--                       0,
--                       0,
--                       0,
--                       0,
--                       0,
--                       0,
--                       0,
--                       l_on_acct_receipts*(-1),
--                       l_unapp_receipts*(-1),
--                       l_Due_Date,                                              -- 1.0
--                       l_Days_Late) ;                                           -- 1.0
--             END IF;
               IF     (l_cus_open_bal >= NVL (p_min_open_balance, 0))
                  AND (l_cus_open_bal <> 0)
               THEN
                  COMMIT;
               ELSE
                  -- rollback for all inserted record for this site.
                  ROLLBACK;
               END IF;
-- currency
            END LOOP;
-- siteinfo
         END LOOP;
-- cusinfo
      END LOOP;
   END;
--End AR_CUSTOMER_BALANCE
END xxha_get_customer_balance_us;
/
