CREATE OR REPLACE PACKAGE xxha_order_default
/*****************************************************************************************
* Name/Purpose : xxha_order_default
* Description  : creates                                                                 *
*                package xxha_order_default                                              *
*                Feild sales service default ship method for timely delivery             *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
AS
FUNCTION xxha_get_shipping_method( p_database_object_name IN VARCHAR2,
                                      p_attribute_code       IN VARCHAR2 )
RETURN VARCHAR2 ;
END xxha_order_default;
/


CREATE OR REPLACE PACKAGE BODY xxha_order_default
/*****************************************************************************************
* Name/Purpose : xxha_order_default
* Description  : creates                                                                 *
*                package body xxha_order_default                                         *
*                Feild sales service default ship method for timely delivery             *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
AS
G_PKG_NAME                    CONSTANT VARCHAR2(30) := 'XXHA_ORDER_DEFAULT';
FUNCTION xxha_get_shipping_method( p_database_object_name IN VARCHAR2,
                                      p_attribute_code       IN VARCHAR2 )
RETURN VARCHAR2
IS
  cursor c1(x_order_type_line_id number) is
  select wcs.ship_method_code, flex.days_less_than
  from wsh_carrier_services_v wcs, wsh_carriers_v wc,
  (
  select --flex_value, one, 
       substr(one,1, instr(one,'*',1,1)-1) order_type_id,
       --two,
       substr(two,1, instr(two,'*',1,1)-1) order_line_type_id,
       --three,
       to_number(substr(three,1, instr(three,'*',1,1)-1)) days_less_than,
       --four,
       substr(four,1, instr(four,'*',1,1)-1) freight_code,
       --five
       substr(five,1, instr(five,'*',1,1)-1) ship_method_meaning
  from (
        select ffv.flex_value, substr(ffv.flex_value,1, instr(ffv.flex_value,'*',1)) one,
               substr(ffv.flex_value, instr(ffv.flex_value,'*',1,1)+1) two,
               substr(ffv.flex_value, instr(ffv.flex_value,'*',1,2)+1) three,
               substr(ffv.flex_value, instr(ffv.flex_value,'*',1,3)+1)||'*' four,
               substr(ffv.flex_value, instr(ffv.flex_value,'*',1,4)+1)||'*' five
               , ffv.*
        from fnd_flex_values_vl ffv, fnd_flex_value_sets ffvs
        where ffvs.flex_value_set_id = ffv.flex_value_set_id
        and   ffvs.flex_value_set_name = 'XXHA_CSP_SHIPMETHOD'
        and   ffv.enabled_flag = 'Y'
        and   trunc(sysdate) between nvl(ffv.start_date_active, trunc(sysdate)) and nvl(ffv.end_date_active, trunc(sysdate))
    )
  ) flex
  where wcs.carrier_id = wc.carrier_id
  and   wc.freight_code = flex.freight_code --'FEDEX'
  and   wcs.ship_method_meaning = flex.ship_method_meaning --'FedEx-Standard Overnight - US' -- ship_method
  and   flex.order_line_type_id = to_char(x_order_type_line_id)
  order by days_less_than;
  v_shipmethod_rec c1%rowtype;
  v_test varchar2(100);
Begin
  --IF ONT_LINE_DEF_HDLR.g_record.line_type_id = 2234 THEN
    open c1(ONT_LINE_DEF_HDLR.g_record.line_type_id);
    while(true) loop
      fetch c1 into v_shipmethod_rec;
      if c1%NOTFOUND then
        close c1;
        return null;
        exit;
      end if;
      if ONT_LINE_DEF_HDLR.g_record.request_date - TRUNC ( SYSDATE ) < v_shipmethod_rec.days_less_than then
        close c1;
        return v_shipmethod_rec.ship_method_code;
      end if;
    end loop;
    Close C1;
  --end if;
  return null;
EXCEPTION
  WHEN OTHERS THEN
    IF OE_MSG_PUB.Check_Msg_Level (OE_MSG_PUB.G_MSG_LVL_UNEXP_ERROR) THEN
      OE_MSG_PUB.Add_Exc_Msg( G_PKG_NAME, 'XXHA_GET_SHIPPING_METHOD' ) ;
    END IF ;
    RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
END xxha_get_shipping_method ;
END xxha_order_default ;
/
