CREATE OR REPLACE PACKAGE XXHA_RAXINV_ACCS_PKG AS

/**********************************************************************************************
* Package Name : XXHA_RAXINV_ACCS_PKG                                                         *
* Purpose      : This package provides a function to retrieve counts for ACCS Items to        *
*                be processed.  This package will be used by the XML Report                   *
*                'XXHA: AR Invoice Report ACCS' (XXHA_RAXINV_ACCS).                           *
*                                                                                             *
* Procedures   :  P_Count_Items                                                               *
*                                                                                             *
* Tables Accessed                Access Type(I - Insert, S - Select, U - Update, D - Delete)  *
* ra_customer_trx_lines_all      S                                                            *
* MTL_System_Items_B             S                                                            *
* MTL_ITEM_Categories_V          S                                                            *
*                                                                                             *
* Change History                                                                              *
*                                                                                             *
* Ver        Date            Author               Description                                 *
* ------     -----------     -----------------    ---------------                             *
* 1.0        29-DEC-2009     B. Marcoux           Initial Version                             *
**********************************************************************************************/

/* globals for cache */
gv_count              NUMBER           := NULL;

/* ************************************************************************************ */
PROCEDURE P_Count_Items (P_org_id        IN RA_Customer_Trx_Lines_All.Org_ID%TYPE,
                         P_cust_trx_id   IN RA_Customer_Trx_Lines_All.Customer_Trx_ID%TYPE,
                         P_count         OUT NUMBER) ;                    

FUNCTION F_Items        (P_org_id        IN RA_Customer_Trx_Lines_All.Org_ID%TYPE,
                         P_cust_trx_id   IN RA_Customer_Trx_Lines_All.Customer_Trx_ID%TYPE)
RETURN NUMBER;

END XXHA_RAXINV_ACCS_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_RAXINV_ACCS_PKG AS

/**********************************************************************************************
* Body Name    : XXHA_RAXINV_ACCS_PKG Body                                                    *
* Purpose      : This function provides the ability to retrieve counts for ACCS Items to      *
*                be processed.  This function will be used by the XML Report                  *
*                'XXHA: AR Invoice Report ACCS' (XXHA_RAXINV_ACCS) to determine if            *
*                a TEG Item exists on an Invoice.                                             *
*                                                                                             *
* Procedures   :  P_Count_Items                                                               *
*                                                                                             *
* Tables Accessed                Access Type(I - Insert, S - Select, U - Update, D - Delete)  *
* ra_customer_trx_lines_all      S                                                            *
* MTL_System_Items_B             S                                                            *
* MTL_ITEM_Categories_V          S                                                            *
*                                                                                             *
* Change History                                                                              *
*                                                                                             *
* Ver        Date            Author               Description                                 *
* ------     -----------     -----------------    ---------------                             *
* 1.0        29-DEC-2009     B. Marcoux           Initial Version                             *
**********************************************************************************************/

PROCEDURE P_Count_Items (P_org_id        IN RA_Customer_Trx_Lines_All.Org_ID%TYPE,
                         P_cust_trx_id   IN RA_Customer_Trx_Lines_All.Customer_Trx_ID%TYPE,
                         P_count         OUT NUMBER)  AS
BEGIN

SELECT COUNT(*)

INTO
    p_count

FROM 
     APPS.ra_customer_trx_lines_all  rctla
,    APPS.MTL_System_Items_B		     item
,    APPS.MTL_ITEM_Categories_V		   cat
WHERE
     rctla.org_id                  = P_org_id                
AND  rctla.customer_trx_id         = P_cust_trx_id
AND  ITEM.Organization_ID	   = 103
AND  ITEM.Inventory_Item_ID        = rctla.INVENTORY_ITEM_ID
AND  CAT.Organization_ID           = ITEM.Organization_ID
AND  CAT.Inventory_Item_ID         = ITEM.Inventory_Item_ID
AND  CAT.Category_Set_Name         = 'Inventory' 
AND  CAT.Category_Concat_Segs	   LIKE 'TEG%'
AND
(SELECT DISTINCT SUBSTR(CAT.Category_Concat_Segs,1,3)
FROM
   APPS.MTL_System_Items_B		  ITEM,
   APPS.MTL_ITEM_Categories_V		CAT,
  (SELECT MAX(Cat2.Last_Update_Date)	AS MaxUpdateDate
            , Cat2.Organization_ID
            , Cat2.Inventory_ITEM_ID
            , Cat2.Category_Set_Name
         FROM 
              APPS.MTL_Item_Categories_V   Cat2
     GROUP BY
              Cat2.Last_Update_Date
            , Cat2.Organization_ID              
            , Cat2.Inventory_ITEM_ID
            , Cat2.Category_Set_Name)    Maxresult
WHERE 
     CAT.Last_Update_Date			         = Maxresult.MaxUpdateDate
AND  CAT.Inventory_Item_ID			       = Maxresult.Inventory_Item_ID
AND  CAT.Organization_ID			         = Maxresult.Organization_ID
AND  Maxresult.Category_Set_Name       = 'Inventory'
AND  Maxresult.Organization_ID		     = ITEM.Organization_ID
AND  Maxresult.Inventory_Item_ID	     = ITEM.Inventory_Item_ID
AND  ITEM.Organization_ID			         = 103
AND  CAT.Category_Concat_Segs		       LIKE 'TEG%') = 'TEG'
;

END P_Count_Items;

FUNCTION F_Items        (P_org_id        IN RA_Customer_Trx_Lines_All.Org_ID%TYPE,
                         P_cust_trx_id   IN RA_Customer_Trx_Lines_All.Customer_Trx_ID%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_Items(P_org_id, P_cust_trx_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;
       
END F_Items;

END XXHA_RAXINV_ACCS_PKG;
/
