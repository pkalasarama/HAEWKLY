CREATE OR REPLACE PACKAGE        "XXHA_AR_CUST_SLSREP_MASSUPD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_AR_CUST_SLSREP_MASSUPD_PK                            |
-- | Description  : The Customer Salesrep Mass Update scans for customer site |
-- |                use records based on Operating Unit, Salesrep and         |
-- |                optionally Customer if supplied.                          |
-- |                For qualifiying records, a seeded API is called to        |
-- |                update the site use record to assign a new salesrep       |
-- |                                                                          |
-- | Invoked by   : Concurrent program XXHA_CUST_SLSREP_MASSUPD               |
-- |                                                                          |
-- |History:                                                                  |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  03-Dec-07   OCS            Initial release                           |
-- |2.0  10-SEP-14   DI             Corrected call to API as it needed to     |
-- |                                  have cust_acct_site_id.                 |
-- +==========================================================================+
as

---------------------------------------------------------------
-- Main executable routine for drivng the Customer Salesrep Update
---------------------------------------------------------------
procedure main (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_org_id  in  number  -- operating unit org id
        ,p_salesrep_id_old  in  number
        ,p_salesrep_id_new  in  number
        ,p_cust_account_id  in  number
        ,p_mode  in  varchar2  -- R(report only), U(pdate)
        ,p_debug  in  varchar2  -- Y(es), N(o)
        );

end XXHA_AR_CUST_SLSREP_MASSUPD_PK;
/


CREATE OR REPLACE PACKAGE BODY "XXHA_AR_CUST_SLSREP_MASSUPD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_AR_CUST_SLSREP_MASSUPD_PK                            |
-- | Description  : This package mass updates the salesrep info on customer   |
-- |                site use profiles.  Refer to package spec for a more      |
-- |                complete description.                                     |
-- |                                                                          |
-- | Invoked by   : Concurrent executable XXHA_CUST_SLSREP_MASSUPD            |
-- |                                                                          |
-- |History:                                                                  |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  03-DEC-07   OCS            Initial release                           |
-- |2.0  10-SEP-14   DI             Corrected call to API as it needed to     |
-- |                                  have cust_acct_site_id.                 |
-- +==========================================================================+
as

-------------------------------------
-- Global Variables Declaration
-------------------------------------
e_abort  exception;
e_skip  exception;

gd_today  date := sysdate;
gc_program_name  varchar2(50) := 'XXHA_AR_CUST_SLSREP_MASSUPD';  -- Program Name In parameter for launch_error_prc procedure
gc_debug_flag  varchar2(1);                                  -- Debug_flag for display debug
gc_log_msg  varchar2(1000);                                  -- Log_msg to display msgs
gc_api_status  varchar2(20);
gn_cnt_read  number := 0;
gn_cnt_ok  number := 0;
gn_cnt_notok  number := 0;
gc_error_msg  xxha_common_errors.error_msg%type;

cursor gcu_sr (
           q_org_id  number
          ,q_salesrep_id  number
          ) is
  select  name
  from    jtf_rs_salesreps
  where   org_id = q_org_id
  and     salesrep_id = q_salesrep_id;

cursor gcu_ca (
           q_cust_account_id  number
          ) is
  select  party_name
  from    hz_cust_accounts  ca
         ,hz_parties  p
  where   ca.cust_account_id = q_cust_account_id
  and     p.party_id = ca.party_id;

-- fetches matching customer site use info
cursor gcu_prf (
           q_org_id  number
          ,q_salesrep_id_old  number
          ,q_cust_account_id  number
          ) is
  select  ca.account_number  customer_number
         ,p.party_name  customer_name
         ,ps.party_site_number  site_number
         ,l.address1||decode(l.address2,null,null,', '||l.address2)
                    ||decode(l.address3,null,null,', '||l.address3)  short_addr
         ,csu.site_use_id
         ,csu.object_version_number
         ,csu.site_use_code
         ,csu.location
-- Added cas.cust_acct_site_id to selection
         ,cas.cust_acct_site_id
  from    hz_cust_site_uses_all  csu
         ,hz_cust_acct_sites_all  cas
         ,hz_party_sites  ps
         ,hz_locations  l
         ,hz_cust_accounts  ca
         ,hz_parties  p
  where   1=1
  and     csu.org_id = q_org_id
  and     csu.primary_salesrep_id = q_salesrep_id_old
  and     cas.cust_acct_site_id = csu.cust_acct_site_id
  and     cas.cust_account_id = nvl(q_cust_account_id,cas.cust_account_id)
  and     ca.cust_account_id = cas.cust_account_id
  and     p.party_id = ca.party_id
  and     ps.party_site_id = cas.party_site_id
  and     l.location_id = ps.location_id
  order by  customer_name, customer_number, short_addr, csu.location;

gr_prf_rec  gcu_prf%rowtype;


------------------------------------------------------------------
-- Main driver routine for processing customer site use profiles
-- with aim of updating the salesrep assignment.
------------------------------------------------------------------
procedure main (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_org_id  in  number  -- operating unit org id
        ,p_salesrep_id_old  in  number
        ,p_salesrep_id_new  in  number
        ,p_cust_account_id  in  number
        ,p_mode  in  varchar2  -- R(report only), U(pdate)
        ,p_debug  in  varchar2  -- Y(es), N(o)
        ) is

  -- declaration for API hz_cust_account_site_v2pub.update_cust_site_use
  lr_cust_site_use_rec  hz_cust_account_site_v2pub.cust_site_use_rec_type;

  -- common return variables
  ln_count  number;
  lc_data  varchar2(4000);

  -- local variables
  ln_ovn  number;  -- object version number
  lc_salesrep_name_old  jtf_rs_salesreps.name%type;
  lc_salesrep_name_new  jtf_rs_salesreps.name%type;
  lc_customer_name  hz_parties.party_name%type;
  lc_customer_number_brk  hz_cust_accounts.account_number%type := '~!@#';
  lc_short_addr_brk  varchar2(2000) := '~!@#';
  lc_err_code  varchar2(30);
  lc_err_msg  varchar2(1000);

  e_mode  exception;

begin
  gc_debug_flag := p_debug;          -- Debug Flag
  gc_log_msg  :='Start of MAIN ...'; -- Indicator to show start of Validation Procedure
  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

  open gcu_sr (p_org_id, p_salesrep_id_old);
  fetch gcu_sr into lc_salesrep_name_old;
  close gcu_sr;

  open gcu_sr (p_org_id, p_salesrep_id_new);
  fetch gcu_sr into lc_salesrep_name_new;
  close gcu_sr;

  if (p_cust_account_id is not null) then
     open gcu_ca (p_cust_account_id);
     fetch gcu_ca into lc_customer_name;
     close gcu_ca;
  end if;

  fnd_file.put_line(fnd_file.output,'Old Salesrep : '||lc_salesrep_name_old);
  fnd_file.put_line(fnd_file.output,'New Salesrep : '||lc_salesrep_name_new);
  fnd_file.put_line(fnd_file.output,'Customer     : '||lc_customer_name);
  fnd_file.put_line(fnd_file.output,'');


  if (p_mode = 'R') then
     fnd_file.put_line(fnd_file.output,'Executing in REPORT ONLY mode - no changes will be saved');
     fnd_file.put_line(fnd_file.output,'========================================================');
  elsif (p_mode = 'U') then
     fnd_file.put_line(fnd_file.output,'Executing in UPDATE mode - changes will be saved');
     fnd_file.put_line(fnd_file.output,'================================================');
  else
     lc_err_msg := 'Execution mode not recognized.  Valid modes are R (Report Only) and U (Update)';
     raise e_mode;
  end if;
  fnd_file.put_line(fnd_file.output,' ');

  ------------------------------------------------------------------------------
  -- Loop thru customer site use records
  ------------------------------------------------------------------------------
  for x_prf_rec in gcu_prf (p_org_id, p_salesrep_id_old, p_cust_account_id)
  loop
     gn_cnt_read := gn_cnt_read + 1;

     ln_ovn := null;
     lc_err_code := null;
     lc_err_msg := null;

     begin
        gr_prf_rec := x_prf_rec;

        -- output record being processed
        if (gr_prf_rec.customer_number <> lc_customer_number_brk) then
           fnd_file.put_line(fnd_file.output,gr_prf_rec.customer_name||'  ['||gr_prf_rec.customer_number||']' );
           lc_customer_number_brk := gr_prf_rec.customer_number;
           lc_short_addr_brk := '~!@#';
        end if;
        if (gr_prf_rec.short_addr <> lc_short_addr_brk) then
           fnd_file.put_line(fnd_file.output,'.....  '||gr_prf_rec.short_addr||'  ['||gr_prf_rec.site_number||']' );
           lc_short_addr_brk := gr_prf_rec.short_addr;
        end if;
        fnd_file.put_line(fnd_file.output,'            '||gr_prf_rec.site_use_code||' : '||gr_prf_rec.location);


        gc_log_msg  :='Processing .. '||gr_prf_rec.customer_name||' ('||gr_prf_rec.customer_number||')  '||gr_prf_rec.short_addr
                                 ||' '||gr_prf_rec.location;
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

        -- running in update mode?
        if (p_mode = 'U') then

           -- prep for API call
           lr_cust_site_use_rec := null;
           lr_cust_site_use_rec.site_use_id := gr_prf_rec.site_use_id;
           lr_cust_site_use_rec.primary_salesrep_id := p_salesrep_id_new;
-- Added code to set cust_acct_site_id for API
           lr_cust_site_use_rec.cust_acct_site_id := gr_prf_rec.cust_acct_site_id;
           ln_ovn := gr_prf_rec.object_version_number;

           -- call API to set new value
           hz_cust_account_site_v2pub.update_cust_site_use (
                     p_init_msg_list => FND_API.G_FALSE
                    ,p_cust_site_use_rec => lr_cust_site_use_rec
                    ,p_object_version_number => ln_ovn
                    ,x_return_status => gc_api_status
                    ,x_msg_count => ln_count
                    ,x_msg_data => lc_data
                    );

           if (gc_api_status = FND_API.G_RET_STS_SUCCESS) then
              gn_cnt_ok := gn_cnt_ok + 1;
           else
              -- must be an error ...
              gn_cnt_notok := gn_cnt_notok + 1;

              fnd_file.put_line(fnd_file.log
                      ,'Customer: '||gr_prf_rec.customer_name||' ('||gr_prf_rec.customer_number||')  '
                                   ||'  Error in API  hz_cust_account_site_v2pub.UPDATE_CUST_SITE_USE'
                      );
              fnd_file.put_line(fnd_file.log
                      ,'......... '||gr_prf_rec.short_addr
                      );
              fnd_file.put_line(fnd_file.log
                      ,'.................. '||gr_prf_rec.site_use_code||' : '||gr_prf_rec.location
                      );
              if (ln_count >= 1) THEN
                 for i in 1..ln_count
                 loop
                    gc_error_msg := SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                    fnd_file.put_line(fnd_file.output,gc_error_msg);
                 end loop;
              end if;
           end if;
        end if;  -- update mode is U
     end;

     -- is process running in update mode?
     if (p_mode = 'U') then
        commit;
     end if;

  end loop;

  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,'************************************************');
  fnd_file.put_line(fnd_file.output,'Statistics for Customer Salesrep Mass Update');
  fnd_file.put_line(fnd_file.output,'************************************************');
  fnd_file.put_line(fnd_file.output,'Records Read               :  ' ||gn_cnt_read);
  fnd_file.put_line(fnd_file.output,'Successful Updates         :  ' ||gn_cnt_ok);
  fnd_file.put_line(fnd_file.output,'Failed Updates             :  ' ||gn_cnt_notok);

exception
  when e_abort then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,'Below is a summary of processing prior to termination');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,rpad('*',70,'*'));
     fnd_file.put_line(fnd_file.output,'Statistics for Customer Salesrep Mass Update ');
     fnd_file.put_line(fnd_file.output,rpad('*',70,'*'));
     fnd_file.put_line(fnd_file.output,'Records Read               :  ' ||gn_cnt_read);
     fnd_file.put_line(fnd_file.output,'Successful Updates         :  ' ||gn_cnt_ok);
     fnd_file.put_line(fnd_file.output,'Failed Updates             :  ' ||gn_cnt_notok);
  when e_mode then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'No records processed');
  when others then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,'Error in XXHA_AR_CUST_SLSREP_MASSUPD_PK.MAIN ' ||SQLERRM);
end MAIN;

end XXHA_AR_CUST_SLSREP_MASSUPD_PK;
/
