CREATE OR REPLACE PACKAGE      xxha_om_blanket_val
IS
/**********************************************************************************************************************************
*
* Package:      xxha_om_blanket_val
* Description:  called by forms personalization on OM screen, determines if blanket assoc. with a line is for the same customer
*               that the order was created for.  
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    27-Feb-2014  Initial Creation
*
**********************************************************************************************************************************/
   FUNCTION xxha_om_blanket_sold_to (
      p_inventory_item_id   IN   NUMBER,
      p_blanket             IN   VARCHAR2
   )
      RETURN NUMBER;

   FUNCTION xxha_blanket_msg (
      p_inventory_item_id   IN   NUMBER,
      p_blanket             IN   VARCHAR2,
      p_sold_to_org_id      IN   NUMBER
   )
      RETURN VARCHAR2;
END;
/


CREATE OR REPLACE PACKAGE BODY      xxha_om_blanket_val
IS
/**********************************************************************************************************************************
*
* Package:      xxha_om_blanket_val
* Description:  called by forms personalization on OM screen, determines if blanket assoc. with a line is for the same customer
*               that the order was created for.  
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    27-Feb-2014  Initial Creation
*
**********************************************************************************************************************************/
   FUNCTION xxha_om_blanket_sold_to (
      p_inventory_item_id   IN   NUMBER,
      p_blanket             IN   VARCHAR2
   )
      RETURN NUMBER
   IS
      v_return   NUMBER;
   BEGIN
      SELECT sold_to_org_id
        INTO v_return
        FROM oe_blanket_lines_v
       WHERE inventory_item_id = p_inventory_item_id
         AND order_number = p_blanket
         AND NVL (flow_status_code, 'NOT_TERMINATED') = 'ACTIVE'
         AND NVL (on_hold_flag, 'N') = 'N'
         AND TRUNC (SYSDATE) BETWEEN start_date_active
                                 AND NVL (end_date_active, SYSDATE + 1);

      RETURN v_return;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END;

   FUNCTION get_cust_name (p_org IN NUMBER)
      RETURN VARCHAR2
   IS
      v_return   VARCHAR2 (255);
   BEGIN
      SELECT hp.party_name
        INTO v_return
        FROM hz_cust_accounts_all hca, hz_parties hp
       WHERE cust_account_id = p_org AND hca.party_id = hp.party_id;

      RETURN v_return;
   END;

   FUNCTION xxha_blanket_msg (
      p_inventory_item_id   IN   NUMBER,
      p_blanket             IN   VARCHAR2,
      p_sold_to_org_id      IN   NUMBER
   )
      RETURN VARCHAR2
   IS
      v_return         VARCHAR2 (255);
      v_blanket_cust   VARCHAR2 (255);
      v_order_cust     VARCHAR2 (255);
   BEGIN
      v_blanket_cust :=
         get_cust_name (xxha_om_blanket_sold_to (p_inventory_item_id,
                                                 p_blanket
                                                )
                       );
      v_order_cust := get_cust_name (p_sold_to_org_id);
      RETURN    'Blanket Order Customer,  "'
             || v_blanket_cust
             || '" is different than Sales Order Customer,  "'
             || v_order_cust
             || '"';
   END;
END;
/
