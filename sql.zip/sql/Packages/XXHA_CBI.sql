CREATE OR REPLACE PACKAGE XXHA_CBI
AS
  FUNCTION XXHA_SOLD_TO_SITE (p_order NUMBER)
  RETURN VARCHAR2;
END XXHA_CBI;

/


CREATE OR REPLACE PACKAGE BODY XXHA_CBI
AS
FUNCTION XXHA_SOLD_TO_SITE (p_order number) RETURN VARCHAR2 IS
lp_order_type_id number;
lp_service_id number;
lp_sold_to varchar2(240);
begin
    select ---raa.address1 ---11I CODE MODIFIED
           HL.ADDRESS1     ---r12 REMEDIATED
    into   lp_sold_to
    from   ---ra_site_uses_all ra ---11I CODE MODIFIED
          hz_cust_site_uses_all ra---r12 REMEDIATED
        , oe_order_headers_all ooha
		   ---, ra_addresses raa---11I CODE MODIFIED
       ,hz_party_sites hps---r12 REMEDIATED
       ,hz_locations hl---r12 REMEDIATED
       ,hz_cust_acct_sites_all HCASA
    where  ooha.sold_to_site_use_id = ra.site_use_id---r12 REMEDIATED
       and hcasa.cust_acct_site_id = ra.cust_acct_site_id---r12 REMEDIATED
       and hps.location_id         = hl.location_id---r12 REMEDIATED
       and hps.party_site_id       = hcasa.party_site_id---r12 REMEDIATED
       and ooha.org_id = 156
       and ooha.order_number = p_order
		   and ra.site_use_code = 'SOLD_TO';
		   ---and ra.address_id = raa.address_id;---11I CODE MODIFIED
return lp_sold_to;
exception
   when others then
           return null;
END XXHA_SOLD_TO_SITE;
end xxha_cbi;
/
