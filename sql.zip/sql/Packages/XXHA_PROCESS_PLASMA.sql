CREATE OR REPLACE package xxha_process_plasma
/*****************************************************************************************
* Name/Purpose : xxha_process_plasma                                                     *
* Description  : creates                                                                 *
*                package spec xxha_process_plasma                                        *
*                Plasma Process                                              *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-MAR-2013     Trish Tetreault      Initial Creation                                  *
* 01-MAR-2013     Manuel Fernandes     Updates per requirement                           *
*                                                                                        *
*****************************************************************************************/
as
 Sr_Header_Id Number := Null;
 conc_request_id Number := null;
 TYPE error_rec IS RECORD (error_message	  VARCHAR2(255));
 TYPE error_table_type IS TABLE OF error_rec INDEX BY BINARY_INTEGER;
 error_table error_table_type;
  function process(p_id number) return number;
  procedure process_conc(Err_Buf Out Varchar2, Ret_Code Out Number, p_id number);
end;
/


CREATE OR REPLACE package body xxha_process_plasma
/*****************************************************************************************
* Name/Purpose : xxha_process_plasma                                                     *
* Description  : creates                                                                 *
*                package body xxha_process_plasma                                        *
*                Plasma Process                                              *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-MAR-2013     Trish Tetreault      Initial Creation                                  *
* 01-MAR-2013     Manuel Fernandes     Updates per requirement                           *
* 07-MAy-2014     Rolta                REmdiated code has been updated to validate the   *
*                                      Items instalbase trackability based on master organization, 
*                                      instead of current owned organization
***************************************************************************************/
As
  procedure dbms_output_put_line(p_error_message varchar2) is
    v_error_message varchar2(2000);
  begin
    v_error_message := replace(p_error_message,chr(0),' ');
    fnd_file.put_line(fnd_file.log, v_error_message);
    dbms_output.put_line(v_error_message);
  end;
  procedure dbms_output_put_out(p_error_message varchar2) is
    v_error_message varchar2(2000);
    v_index number;
  begin
    v_error_message := replace(p_error_message,chr(0),' ');
    fnd_file.put_line(fnd_file.output, v_error_message);
    dbms_output_put_line(v_error_message);
    if length(v_error_message) <= 200 then
      error_table(error_table.count +1).error_message := v_error_message;
    else
      v_index := 1;
      While(V_Index <= Length(V_Error_Message)) Loop
        error_table(error_table.count +1).error_message := substr(v_error_message, v_index, 200);
        v_index := v_index + 200;
      end loop;
    end if;
  End;
  Procedure Display_output
  Is
  v_request_id number;
  Begin
    V_REQUEST_ID := CONC_REQUEST_ID;
    --fnd_file.put_line(fnd_file.output, 'Custom error1'||sqlerrm);
    for i in 1..error_table.count loop
      insert into haemo.xxha_sr_header_errors(sr_header_id, concurrent_request_id, error_sequence, error_message)
      Values(Sr_Header_Id, V_Request_Id, I, Error_Table(I).Error_Message);
      --fnd_file.put_line(fnd_file.output, Error_Table(I).Error_Message);
    END LOOP;
    --fnd_file.put_line(fnd_file.log, 'Custom error2'||sqlerrm);
  end;
  procedure do_rollback is
  Begin
    Rollback;
    display_output;
    commit;
  End;
  Procedure Display_Success_Results(p_Sr_Header_Id Number)
  Is
  Cursor C_Sr_Lines(X_Sr_Header_Id Number) Is
  Select id, Serial_Number, Incident_Number From Xxha_Sr_Lines_V Where Sr_Header_Id = X_Sr_Header_Id And Incident_Id Is Not Null Order By Id;
  Cursor C_sparepart_Orders(X_Sr_Line_Id Number) Is
  Select Distinct Order_Number From Xxha_Sr_Line_Spares_V Spares, Csd_Product_Txns_V P1
  Where spares.repair_line_id = P1.repair_line_id
  And   spares.sr_Line_Id =  X_Sr_Line_Id; --209697
  v_found boolean;
  Begin
    Dbms_Output_Put_Out('Reference # '|| To_Char(P_Sr_Header_Id));
    Dbms_Output_Put_Out(Rpad('',Length('Reference # '|| To_Char(P_Sr_Header_Id)),'-'));
    Dbms_Output_Put_Out(Rpad( 'Serial # ', 30 ) || Rpad('Service Request # ', 30 ) || Rpad('Order # ', 30 ));
    For I In C_Sr_Lines(P_Sr_Header_Id) Loop
     V_Found := False;
     For R In C_Sparepart_Orders(I.id) Loop
       V_Found := True;
       Dbms_Output_Put_Out(Rpad(I.Serial_Number, 30) || Rpad(I.Incident_Number, 30 ) || Rpad(r.order_Number, 30));
     End Loop;
     If Not V_Found Then
       Dbms_Output_Put_Out(Rpad(I.Incident_Number, 30 ) || Rpad(I.Serial_Number, 30));
     end if;
    End Loop;
    display_output;
  end;
  function process(p_id number) return number is
  v_request_id number;
  v_boolean boolean;
  v_user_name varchar2(100) := null;
  begin
    if p_id is null then
      return null;
    end if;
    v_user_name := fnd_global.user_name;
    v_boolean := FND_REQUEST.set_options;
    --v_boolean := FND_REQUEST.set_print_options(copies=>1);
    --dbms_output_put_out('Debug Notify user '|| fnd_global.user_id);
    v_boolean := FND_REQUEST.ADD_NOTIFICATION(fnd_global.user_name);
    if not v_boolean then
       dbms_output_put_out('Notify user failed for '|| fnd_global.user_name);
    end if;
    v_request_id := FND_REQUEST.SUBMIT_REQUEST('HAEMO','XXHA_PROCESS_PLASMA','XXHA SR Plasma Process Init',SYSDATE,FALSE,to_char(p_id));
    return v_request_id;
  end;
  procedure process_conc(Err_Buf Out Varchar2, Ret_Code Out Number, p_id number)
  is
    --p_id number := 2;
    p_status_id number := 1;
    --p_severity_id number := 4;
    p_severity_id number;
    --p_incident_type_id number := 11002;
    p_incident_type_id number;
    --p_sr_creation_channel varchar2(100) := 'PHONE';
    p_sr_creation_channel varchar2(100);
    p_resp_appl_id number := 20003;
    p_resp_id number := 51279;
    p_user_id number := 11752;
    p_list_price_id number;
    v_incident_id number;
    V_ORDER_HEADER_ID NUMBER;
    /*V_OBJECT_VERSION_NUMBER   NUMBER;
		V_ORDER_HEADER_IDout         NUMBER;
		v_order_line_id           NUMBER;*/
    
    cursor c_sr_headers(x_id number) is
    select * from XXHA_SR_HEADERS_V h where 1 = 1 and h.id = x_id
    -- do not process if any line has service request created
    and not exists (select 1 from haemo.xxha_sr_lines l where l.sr_header_id = h.id and l.incident_id is not null)
    -- process if there is at least 1 line
    and exists (select 1 from haemo.xxha_sr_lines l where l.sr_header_id = h.id and l.incident_id is null)
    --process if lines have spares
    and exists (select 1 from haemo.xxha_sr_lines l where l.sr_header_id = h.id and l.incident_id is null and exists (select 1 from haemo.xxha_sr_line_spares sp where sp.sr_line_id = l.id and repair_line_id is null))
    -- do not process if there is a line with no spares
    and not exists (select 1 from haemo.xxha_sr_lines l where l.sr_header_id = h.id and l.incident_id is null and not exists (select 1 from haemo.xxha_sr_line_spares sp where sp.sr_line_id = l.id and repair_line_id is null))
    ;
    cursor c_sr_lines(x_sr_header_id number) is
    select * from XXHA_SR_lines_V where sr_header_id = x_sr_header_id;
    cursor c_sr_line_spares(x_sr_line_id number) is
    select * from XXHA_SR_line_spares_V where sr_line_id = x_sr_line_id;
    type error_rec is record (
      error_event varchar2(100),
      error_message varchar2(2000)
    );
  begin
    --FND_GLOBAL.APPS_INITIALIZE(user_id => p_user_id,resp_id => p_resp_id,resp_appl_id => p_resp_appl_id);
    sr_header_id := p_id;
    delete haemo.xxha_sr_header_errors
    where sr_header_id = p_id;
    commit;
    dbms_output_put_line('Processing Ref # '|| to_char(p_id));
    p_resp_appl_id := fnd_global.resp_appl_id;
    p_resp_id := fnd_global.resp_id;
    P_User_Id := Fnd_Global.User_Id;
    conc_request_id := fnd_global.conc_request_id;
    p_incident_type_id := fnd_profile.value('XXHA_CS_CP_ORDERS_SR_TYPE');
    if p_incident_type_id is null then
       --p_incident_type_id := 11002;
       dbms_output_put_out('Profile value XXHA_CS_CP_ORDERS_SR_TYPE not available');
       ret_code := 2;
       return;
    end if;
    p_severity_id := fnd_profile.value('XXHA_CS_CP_SR_SEVERITY');
    if p_severity_id is null then
       --p_severity_id := 4;
       dbms_output_put_out('Profile value XXHA_CS_CP_SR_SEVERITY not available');
       ret_code := 2;
       return;
    end if;
    p_sr_creation_channel := fnd_profile.value('XXHA_CS_CP_SR_CHANNEL');
    if p_sr_creation_channel is null then
       --p_sr_creation_channel := 'PHONE';
       dbms_output_put_out('Profile value XXHA_CS_CP_SR_CHANNEL not available');
       ret_code := 2;
       return;
    end if;
    p_list_price_id := fnd_profile.value('XXHA_CS_CP_PRICE_LIST');
    if p_list_price_id is null then
      --p_list_price_id := 738099;
      dbms_output_put_out('Profile value XXHA_CS_CP_PRICE_LIST not available');
      ret_code := 2;
      return;
    end if;
    for h in c_sr_headers(p_id) loop
      for l in c_sr_lines(h.id) loop
        -- create request here
        declare
          lx_msg_count NUMBER;
          lx_msg_data VARCHAR2(2000);
          lx_request_id NUMBER;
          lx_request_number VARCHAR2(50);
          lx_interaction_id NUMBER;
          lx_workflow_process_id NUMBER;
          lx_msg_index_out NUMBER;
          lx_return_status VARCHAR2(1);
          l_service_request_rec CS_ServiceRequest_PUB.service_request_rec_type;
          l_notes_table CS_SERVICEREQUEST_PUB.notes_table;
          l_contacts_tab CS_SERVICEREQUEST_PUB.contacts_table;
        begin
          -- Populate the SR Record type
          CS_SERVICEREQUEST_PUB.initialize_rec(l_service_request_rec);
          l_notes_table(1).note_type := 'CS_PROBLEM';
          --l_notes_table(1).note_type := 'Problem Description';
          l_notes_table(1).note := l.problem_summary;
          l_service_request_rec.request_date := sysdate; --to_date('30-AUG-2004 16:27:34', 'dd-MON-YYYY HH24:MI:SS');
          l_service_request_rec.incident_occurred_date := sysdate;
          l_service_request_rec.type_id := p_incident_type_id; --86;
          l_service_request_rec.status_id := p_status_id;
          l_service_request_rec.severity_id := p_severity_id;
          l_service_request_rec.summary := l.problem_summary;
          l_service_request_rec.caller_type := 'ORGANIZATION';
          l_service_request_rec.customer_id := h.party_id;
          l_service_request_rec.verify_cp_flag := 'Y';
          L_Service_Request_Rec.Verify_Cp_Flag := FND_API.G_MISS_CHAR; --'N';
          l_service_request_rec.sr_creation_channel := p_sr_creation_channel; --'PHONE';
          l_service_request_rec.owner_id := h.owner_id;
          --???????? l_service_request_rec.owner_group_id := 100000463;
          --l_service_request_rec.inventory_org_id := l.current_organization_id;
          l_service_request_rec.inventory_org_id := l.inv_organization_id; --103; --l.current_organization_id;
          L_Service_Request_Rec.Inventory_Item_Id := L.Inventory_Item_Id;
          L_Service_Request_Rec.inv_platform_org_id := l.current_organization_id;
          --l_service_request_rec.inv_item_revision := l.inventory_revision;
          L_Service_Request_Rec.Category_Id := L.Product_Category_Id;
          l_service_request_rec.category_set_id := l.category_set_id;
          --l_service_request_rec.current_serial_number := l.serial_number; -- 08K287
          --l_service_request_rec.cp_ref_number := l.instance_number;
          l_service_request_rec.customer_product_id := l.instance_id;
          --select * from csi_item_instances where serial_number = '08K287'
          --L_Service_Request_Rec.Purchase_Order_Num := H.Customer_Po_Num;
          L_Service_Request_Rec.cust_po_number := H.Customer_Po_Num;
          l_service_request_rec.problem_code := l.problem_code;
          l_service_request_rec.resolution_code := l.resolution_code;
          l_service_request_rec.account_id := h.cust_account_id;
          l_service_request_rec.bill_to_account_id := h.cust_account_id;
          l_service_request_rec.ship_to_account_id := h.cust_account_id;
          l_service_request_rec.bill_to_party_id := h.party_id;
          l_service_request_rec.ship_to_party_id := h.party_id;
          l_service_request_rec.bill_to_site_id := h.bill_to_party_site_id;
          l_service_request_rec.ship_to_site_id := h.ship_to_party_site_id;
          --l_service_request_rec.bill_to_site_use_id := h.bill_to_site_use_id;
          --l_service_request_rec.ship_to_site_use_id := h.ship_to_site_use_id;
          l_service_request_rec.install_site_id := h.install_party_site_id;
          l_service_request_rec.incident_location_id := h.install_location_id;
          l_service_request_rec.contract_id := l.contract_id;
          l_service_request_rec.contract_service_id := l.service_line_id;
          l_service_request_rec.request_context := l.incident_context;
          l_service_request_rec.request_attribute_2 := l.incident_attribute_2;
          l_service_request_rec.request_attribute_3 := l.incident_attribute_3;
          l_service_request_rec.request_attribute_4 := l.incident_attribute_4;
          l_service_request_rec.request_attribute_5 := l.incident_attribute_5;
          l_service_request_rec.request_attribute_6 := l.incident_attribute_6;
          --
          declare
            contact_i number := 1;
          BEGIN
            L_CONTACTS_TAB.DELETE;
            --dbms_output_put_out('start of SR creation');
            if h.contact_point_id is not null then
              l_contacts_tab(contact_i).party_id := h.rel_contact_party_id; --8475; ******This one needs to be saved
              l_contacts_tab(contact_i).contact_point_id := h.contact_point_id; --7908;
              l_contacts_tab(contact_i).CONTACT_POINT_TYPE := h.contact_point_type; --'EMAIL';
              l_contacts_tab(contact_i).PRIMARY_FLAG := 'Y'; --h.contact_point_primary_flag; --'Y';
              l_contacts_tab(contact_i).CONTACT_TYPE := h.contact_relationship_type; --'PARTY_RELATIONSHIP';
              contact_i := contact_i +1;
            end if;
            --
            -- lets keep email for later
            if h.contact_point_id_email is not null then
              l_contacts_tab(contact_i).party_id := h.rel_contact_party_id; --8475; ******This one needs to be saved
              l_contacts_tab(contact_i).contact_point_id := h.contact_point_id_email; --7908;
              l_contacts_tab(contact_i).CONTACT_POINT_TYPE := 'EMAIL';
              if contact_i = 1 then
                l_contacts_tab(contact_i).PRIMARY_FLAG := 'Y'; --h.contact_point_primary_flag; --'Y';
              else
                l_contacts_tab(contact_i).PRIMARY_FLAG := 'N'; --h.contact_point_primary_flag; --'Y';
              end if;
              l_contacts_tab(contact_i).CONTACT_TYPE := h.contact_relationship_type; --'PARTY_RELATIONSHIP';
            end if;
          end;
          dbms_output_put_line('Before calling Public SR API');
          Cs_Servicerequest_Pub.Create_Servicerequest (
          p_api_version => 2.0,
          p_init_msg_list => FND_API.G_TRUE,
          p_commit => FND_API.G_FALSE,
          x_return_status => lx_return_status,
          x_msg_count => lx_msg_count,
          x_msg_data => lx_msg_data,
          p_resp_appl_id => p_resp_appl_id,
          p_resp_id => p_resp_id,
          p_user_id => p_user_id,
          p_login_id => NULL,
          --p_org_id => 204,
          p_request_id => NULL,
          p_request_number => NULL,
          p_service_request_rec => l_service_request_rec,
          p_notes => l_notes_table,
          p_contacts => l_contacts_tab,
          x_request_id => lx_request_id,
          x_request_number => lx_request_number,
          x_interaction_id => lx_interaction_id,
          x_workflow_process_id => lx_workflow_process_id );
          --dbms_output_put_out('Return Status : ' || lx_return_status);
          Dbms_Output_Put_Line('Inserted request id: ' || Lx_Request_Id );
          --Dbms_Output_Put_Line('Inserted request num : ' || Lx_Request_Number );
          Dbms_Output_Put_Line('Service Request Number '||Lx_Request_Number);
          --dbms_output_put_line('Interaction ID : ' || lx_interaction_id );
          IF (lx_return_status = FND_API.G_RET_STS_SUCCESS) then
            update haemo.xxha_sr_lines set incident_id = lx_request_id --incident_number = lx_request_number
            where rowid = l.row_id;
            v_incident_id := lx_request_id;
          end if;
          IF (lx_return_status <> FND_API.G_RET_STS_SUCCESS) then
            IF (FND_MSG_PUB.Count_Msg > 1) THEN
              --Display all the error messages
              FOR j in 1..FND_MSG_PUB.Count_Msg LOOP
                FND_MSG_PUB.Get(
                p_msg_index => j,
                p_encoded => 'F',
                p_data => lx_msg_data,
                p_msg_index_out => lx_msg_index_out);
                dbms_output_put_out(lx_msg_data);
              END LOOP;
            ELSE
              --Only one error
              FND_MSG_PUB.Get(
              p_msg_index => 1,
              p_encoded => 'F',
              p_data => lx_msg_data,
              p_msg_index_out => lx_msg_index_out);
              dbms_output_put_out(lx_msg_data);
              dbms_output_put_out(lx_msg_index_out);
            END IF;
            Dbms_Output_Put_Out('Service Request Creation Failed - Request process will be undone'||L.Serial_Number);
            Dbms_Output_Put_Out('Problem Code'||L.Problem_Code);
            Dbms_Output_Put_Out('inventory_item_id'||to_char(L.inventory_item_id));
            ret_code := 2;
            ERR_BUF := 'Service Request Creation Failed Serial # '||L.SERIAL_NUMBER;
            do_rollback; -- commented by sreeram
            return;
          END IF;
        exception
          when others then dbms_output_put_out('Database error ' || sqlerrm);
        end;
        if v_incident_id is null then
          dbms_output_put_out('SR Creation failed');
          return;
        end if;
        -- service request creation ended
        for r in c_sr_line_spares(l.id) loop
          -- create repair orders here
          --dbms_output_put_out('start of create repair orders');
          Declare
            -- spare part "36917-00" may have serial number
            --Select * From xxha_sr_line_spares_v
            lx_msg_count NUMBER;
            lx_msg_data VARCHAR2(2000);
            lx_repair_line_id NUMBER default NULL;
            lx_repair_number VARCHAR2(50) default null;
            lx_return_status VARCHAR2(1) default NULL;
            lx_msg_index_out NUMBER;
            L_Ro_Rec Csd_Repairs_Pub.Repln_Rec_Type;
            l_comms_trackable_flag  MTL_SYSTEM_ITEMS.comms_nl_trackable_flag %type;
          BEGIN
            -- Populate the SR Record type
            l_comms_trackable_flag := null;
            dbms_output_put_line('spare part id'||r.Spare_Part_Id);
           -- dbms_output_put_line('l.inv_master_organization_id'||l.inv_master_organization_id);
            -- added by sreeram 327
             SELECT nvl(comms_nl_trackable_flag, 'N') comms_nl_trackable_flag into l_comms_trackable_flag
             FROM MTL_SYSTEM_ITEMS
             WHERE organization_id = l.inv_master_organization_id--  changed to master organization from current org 5/7/2014
             AND inventory_item_id = r.Spare_Part_Id;

            dbms_output_put_line('l_comms_trackable_flag'||l_comms_trackable_flag);
            --end of added by sreeram 327
            --l_ro_rec.customer_product_id := 170648; -- uncommented by sreeram
            L_Ro_Rec.Repair_Type_Id := R.Repair_Type_Id; --2;
            l_ro_rec.incident_id := v_incident_id; --1417028; --27608;
            --L_Ro_Rec.Auto_Process_Rma := 'Y';
            L_Ro_Rec.Quantity := R.Quantity; --1;
            L_Ro_Rec.Inventory_Item_Id := R.Spare_Part_Id; --149; --103210;
            l_ro_rec.item_revision := r.spare_part_revision; --149; --103210;
            l_ro_rec.unit_of_measure := r.primary_uom_code;
            l_ro_rec.status := 'O';
            l_ro_rec.currency_code := 'USD';
            L_Ro_Rec.Approval_Required_Flag := 'N';
            l_ro_rec.serial_number := r.return_serial_number; --'NULL'; --'0603A3622A-PR02';
            
            dbms_output_put_line('instance id'||l.instance_id);
            dbms_output_put_line('l_comms_trackable_flag'||l_comms_trackable_flag);
          if l_comms_trackable_flag = 'Y' then
            --l_ro_rec.instance_id := l.instance_id;--170648;-- uncommented by sreeram 327
            l_ro_rec.customer_product_id := l.instance_id; -- uncommented by sreeram 328
          else 
             l_ro_rec.instance_id := null;
            
          end if;
          dbms_output_put_line('l_ro_rec.instance_id'||l_ro_rec.instance_id);
            L_ro_Rec.Repair_Mode := 'TASK';
            l_ro_rec.PRICE_LIST_HEADER_ID := nvl(h.price_list_id,p_list_price_id); --738099; --r.price_list_id;
            l_ro_Rec.ATTRIBUTE_CATEGORY := r.depot_repair_context;
            dbms_output_put_line('before calling public API csd_repairs_pub');
            csd_repairs_pub.create_repair_order
            (
            p_api_version_number => 1.0,
            p_init_msg_list => FND_API.G_TRUE,
            p_commit => FND_API.G_FALSE,
            p_validation_level => fnd_api.G_VALID_LEVEL_FULL,
            p_repair_line_id => NULL,
            p_repln_rec => l_ro_rec,
            x_return_status => lx_return_status,
            x_msg_count => lx_msg_count,
            x_msg_data => lx_msg_data,
            x_repair_line_id => lx_repair_line_id,
            x_repair_number => lx_repair_number
            );
            dbms_output_put_line('Return Status : ' || lx_return_status);
            dbms_output_put_line('Inserted repair_line_id : ' || lx_repair_line_id );
            dbms_output_put_line('Inserted repair_number : ' || lx_repair_number );
            IF (lx_return_status = FND_API.G_RET_STS_SUCCESS) THEN
              update haemo.xxha_sr_line_spares set repair_line_id = lx_repair_line_id where rowid = r.row_id;
            end if;
            IF (lx_return_status <> FND_API.G_RET_STS_SUCCESS) THEN
              IF (FND_MSG_PUB.Count_Msg > 1) THEN
                --Display all the error messages
                FOR j in 1..FND_MSG_PUB.Count_Msg LOOP
                  FND_MSG_PUB.Get( p_msg_index => j,
                  p_encoded => 'F', p_data => lx_msg_data,
                  p_msg_index_out => lx_msg_index_out);
                  dbms_output_put_out(lx_msg_data);
                END LOOP;
              ELSE
                --Only one error
                FND_MSG_PUB.Get( p_msg_index => 1,
                p_encoded => 'F',
                p_data => lx_msg_data,
                p_msg_index_out => lx_msg_index_out);
                dbms_output_put_out(lx_msg_data);
                dbms_output_put_out(lx_msg_index_out);
              END IF;
              dbms_output_put_out('Repair Order Creation Failed - Request process will be undone');
              ret_code := 2;
              err_buf := 'Repair Order Creation Failed Serial # '||l.serial_number || ' Repair Item # '||r.spare_part;
              do_rollback;
              return;
            End If;
          Exception
            WHEN others then dbms_output_put_out('Database Error ' || sqlerrm);
            --commit;
          END;
        end loop;
        
        -- run spares loop gain for logistics
        for r in c_sr_line_spares(l.id) loop
          -- create default logistics here
          DECLARE
            l_return_status varchar2(32767) ;
            l_msg_count number ;
            l_msg_data varchar2(32767);
            l_repair_line_id number;
            l_msg_index_out number;
          BEGIN
            l_repair_line_id := r.repair_line_id; --input the correct repair line id
            --dbms_output_put_out('at default r.repair_line_id'||r.repair_line_id);
            --dbms_output_put_out('at default repair line id'||l_repair_line_id);
            DBMS_OUTPUT_PUT_LINE('Calling CSD_LOGISTICS_PUB.Create_Default_Logistics');
            CSD_LOGISTICS_PUB.Create_Default_Logistics(
            p_api_version => 1.0,
            p_commit => 'F',
            p_init_msg_list => 'T',
            p_validation_level => fnd_api.g_valid_level_full, --g_valid_level_full
            x_return_status => l_return_status,
            x_msg_count => l_msg_count,
            x_msg_data => l_msg_data,
            p_repair_line_id => l_repair_line_id
            );
            dbms_output_put_line(SubStr('Return Status of call : ' || l_return_status,1,255) ) ;
            dbms_output_put_line(SubStr('Msg Count : ' || l_msg_count,1,255) ) ;
            dbms_output_put_line(SubStr('Msg Data : ' || l_msg_data,1,255) ) ;
            IF (nvl(l_return_status,'S') != 'S') THEN
              dbms_output_put_out(SubStr('Number of Error Messages : '||to_char(l_msg_count),1,255));
              --IF (FND_MSG_PUB.Count_Msg > 1) THEN
              IF (l_msg_count > 1) THEN
                --Display all the error messages
                --FOR j in 1..FND_MSG_PUB.Count_Msg LOOP
                FOR j in 1..l_msg_count LOOP
                  FND_MSG_PUB.Get( p_msg_index => j,
                  p_encoded => 'F', p_data => l_msg_data,
                  p_msg_index_out => l_msg_index_out);
                  dbms_output_put_out(l_msg_data);
                END LOOP;
              ELSE
                --Only one error
                --dbms_output_put_out(l_msg_data);
                FND_MSG_PUB.Get( p_msg_index => 1,
                p_encoded => 'F',
                p_data => l_msg_data,
                p_msg_index_out => l_msg_index_out);
                dbms_output_put_out(l_msg_data);
                --dbms_output_put_out(l_msg_index_out);
              END IF;
              dbms_output_put_out('Default Logistics Creation Failed - Request process will be undone');
              ret_code := 2;
              ERR_BUF := 'Default Logistics Creation Failed Serial # '||L.SERIAL_NUMBER || ' Repair Item # '||R.SPARE_PART;
              do_rollback; -- commented by sreeram
              return;
            end if;
          end;
        end loop;
      END LOOP;
     --commit; -- added by sreeram for testing 3/27
      /**************************************************/
      /* add to single order                            */
       declare
        cursor c_all_repairs(x_sr_header_id number) is
        select r.*, l.serial_number from xxha_sr_headers_v h, xxha_sr_lines_v l, xxha_sr_line_spares_v r
        where h.id = l.sr_header_id and l.id = r.sr_line_id
        and h.id = x_sr_header_id
        order by repair_line_id;
        cursor c_prodtxn(x_repair_line_id number) is
        select * from CSD_PRODUCT_TXNS_V p1
        where p1.repair_line_id = x_repair_line_id
        order by p1.product_transaction_id;
        v_dummy number;
      begin
      v_order_header_id := null;
      /*
      declare
        p_resp_appl_id number := 20003;
        p_resp_id number := 51279;
        p_user_id number := 11752;
      begin
        FND_GLOBAL.APPS_INITIALIZE(user_id => p_user_id,resp_id => p_resp_id,resp_appl_id => p_resp_appl_id);
      end;
      */
      for r in c_all_repairs(h.id) loop
        dbms_output_put_line('repair_line_id ' || to_char(r.repair_line_id));
        for t in c_prodtxn(r.repair_line_id) loop
          DBMS_OUTPUT_PUT_LINE('prodTXN ' || TO_CHAR(T.PRODUCT_TRANSACTION_ID));
          dbms_output_put_line('order header id ' ||nvl(t.order_header_id,999));
          
        DBMS_OUTPUT_PUT_LINE('t.order_header_id   '||t.order_header_id);
          if t.order_header_id is not null then
            V_Order_Header_Id := T.Order_Header_Id;
            --dbms_output_put_out('Order found process is being ignored');
            Goto Next_Line;
            --dbms_output_put_line('Continue failed?');
          END IF;
      DBMS_OUTPUT_PUT_LINE('V_order_header_id   '||v_order_header_id);          
          DECLARE
            l_return_status varchar2(32767) ;
            l_msg_count number ;
            l_msg_data varchar2(32767);
            l_repair_line_id number;
            l_msg_index_out number;
            L_UPDATEPRODUCTTRXN_REC CSD_LOGISTICS_PUB.UPD_PRODTXN_REC_TYPE;
            L_OBJECT_VERSION_NUMBER NUMBER;
            L_ORDER_HEADER_ID  NUMBER;
						L_ORDER_LINE_ID number;
            
            BEGIN
           
              l_UpdateProductTrxn_Rec.Product_Transaction_ID := t.Product_Transaction_ID; --enter the correct input value
              l_UpdateProductTrxn_Rec.Interface_To_OM_Flag := 'Y'; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.BOOK_SALES_ORDER_FLAG := 'Y'; --enter the correct input value
              
              if v_order_header_id is not null then
                l_UpdateProductTrxn_Rec.Add_To_Order_Id := v_order_header_id; --100669; --enter the correct input value
                L_UPDATEPRODUCTTRXN_REC.NEW_ORDER_FLAG := 'N'; --enter the correct input value
              ELSE
                L_UPDATEPRODUCTTRXN_REC.ADD_TO_ORDER_ID := FND_API.G_MISS_NUM; --100669; --enter the correct input value
                l_UpdateProductTrxn_Rec.New_Order_Flag := 'Y'; --enter the correct input value
              END IF;
              DBMS_OUTPUT_PUT_LINE('l_UpdateProductTrxn_Rec.Add_To_Order_Id   '||l_UpdateProductTrxn_Rec.Add_To_Order_Id);          
              DBMS_OUTPUT_PUT_LINE('l_UpdateProductTrxn_Rec.New_Order_Flag   '||l_UpdateProductTrxn_Rec.New_Order_Flag);          
              
              L_UPDATEPRODUCTTRXN_REC.OBJECT_VERSION_NUMBER := T.OBJECT_VERSION_NUMBER; --enter the correct input value from csd_product_transaction table.
              dbms_output_put_line('T.OBJECT_VERSION_NUMBER  '||T.OBJECT_VERSION_NUMBER);
              --l_UpdateProductTrxn_Rec.Locator_ID := '666'; --enter the correct input value
              --l_UpdateProductTrxn_Rec.Lot_Number := '777'; --enter the correct input value
              
              dbms_output_put_line('t.source_Instance_Id  '||t.source_Instance_Id);
                            if t.source_Instance_Id <>FND_API.G_MISS_NUM then 
              l_UpdateProductTrxn_Rec.source_Instance_Id := t.source_Instance_Id; --added by sreeram 327
              end if;
              dbms_output_put_line('l_UpdateProductTrxn_Rec.source_Instance_Id  '||l_UpdateProductTrxn_Rec.source_Instance_Id);
              if t.non_source_Instance_Id <>FND_API.G_MISS_NUM then
              l_UpdateProductTrxn_Rec.non_source_Instance_Id := t.non_source_Instance_Id; --added by sreeram 327
              end if;
              /*
              l_UpdateProductTrxn_Rec.Action_Type := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.Action_Code := FND_API.G_MISS_CHAR; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.INVENTORY_ITEM_ID := FND_API.G_MISS_NUM; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.TXN_BILLING_TYPE_ID := FND_API.G_MISS_NUM; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.PRICE_LIST_ID := FND_API.G_MISS_NUM; --enter the correct input value
              l_UpdateProductTrxn_Rec.Quantity := FND_API.G_MISS_NUM; --enter the correct input value
              l_UpdateProductTrxn_Rec.Revision := FND_API.G_MISS_CHAR; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.SOURCE_SERIAL_NUMBER := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.source_Instance_Id := FND_API.G_MISS_NUM; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.NON_SOURCE_SERIAL_NUMBER := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.non_source_Instance_Id := FND_API.G_MISS_NUM; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.LOT_NUMBER := FND_API.G_MISS_CHAR; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.SUB_INVENTORY := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.Return_Reason := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.Return_By_Date := FND_API.G_MISS_DATE; --enter the correct input value
              
              
                L_Updateproducttrxn_Rec.Po_Number := FND_API.G_MISS_CHAR; --enter the correct input value
              
              
              l_UpdateProductTrxn_Rec.Invoice_To_Org_Id := FND_API.G_MISS_NUM; --enter the correct input value
              l_UpdateProductTrxn_Rec.Ship_To_Org_Id := FND_API.G_MISS_NUM; --enter the correct input value
              l_UpdateProductTrxn_Rec.Unit_Of_Measure_Code := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.Charge := FND_API.G_MISS_NUM; --enter the correct input value
              l_UpdateProductTrxn_Rec.Interface_To_OM_Flag := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.Book_Sales_Order_Flag := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.No_Charge_Flag := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.New_Order_Flag := FND_API.G_MISS_CHAR; --enter the correct input value
              l_UpdateProductTrxn_Rec.Add_To_Order_Id := FND_API.G_MISS_NUM; --enter the correct input value
              l_UpdateProductTrxn_Rec.Locator_ID := FND_API.G_MISS_NUM; --enter the correct input value
              L_UPDATEPRODUCTTRXN_REC.OBJECT_VERSION_NUMBER := FND_API.G_MISS_NUM; --enter the correct input value
              */
              DBMS_OUTPUT_PUT_LINE('Calling CSD_LOGISTICS_PUB.Update_Logistics_Line');
/*              CSD_LOGISTICS_PUB.Update_Logistics_Line(
                p_api_version => 1.0,
                p_commit => 'F',
                P_INIT_MSG_LIST => 'T',
                --p_validation_level => fnd_api.g_valid_level_full, --fnd_api.g_valid_level_none
                x_return_status => l_return_status,
                x_msg_count => l_msg_count,
                X_MSG_DATA => L_MSG_DATA,
                P_UPD_PRODTXN_REC => L_UPDATEPRODUCTTRXN_REC,
                X_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER,
                X_ORDER_HEADER_ID  => L_ORDER_HEADER_ID,
								X_ORDER_LINE_ID => l_ORDER_LINE_ID );
  */              
                
                CSD_LOGISTICS_PUB.Update_Logistics_Line( 
	p_api_version => 1.0, 
	p_commit => 'F', 
	p_init_msg_list => 'T', 
	--p_validation_level => fnd_api.g_valid_level_full, 
	--fnd_api.g_valid_level_none 
	x_return_status => l_return_status, 
	x_msg_count => l_msg_count, 
	x_msg_data => l_msg_data, 
	p_Upd_ProdTxn_Rec => l_UpdateProductTrxn_Rec,
	x_object_version_number =>l_object_version_number,
	x_order_header_id => l_order_header_id,
	x_order_line_id =>  l_order_line_id
); 

                
              DBMS_OUTPUT_PUT_LINE(SUBSTR('Return Status of call : ' || L_RETURN_STATUS,1,255) ) ;
              DBMS_OUTPUT_PUT_LINE(SUBSTR('Msg Count : ' || L_MSG_COUNT,1,255) ) ;
              DBMS_OUTPUT_PUT_LINE(SUBSTR('Msg Data : ' || L_MSG_DATA,1,255) ) ;
              DBMS_OUTPUT_PUT_LINE(SUBSTR('order no : ' || L_ORDER_HEADER_ID,1,255) ) ;
              dbms_output_put_line(SubStr('order line no : ' || l_ORDER_LINE_ID,1,255) ) ;
              
              IF (nvl(l_return_status,'S') != 'S') THEN
                dbms_output_put_out(SubStr('Number of Error Messages : '||to_char(l_msg_count),1,255));
                --dbms_output_put_out(l_msg_data);
                FOR i in 1..l_msg_count LOOP
                  FND_MSG_PUB.Get(p_msg_index => i,
                  p_encoded => 'F',
                  p_data => l_msg_data,
                  p_msg_index_out => l_msg_index_out );
                  dbms_output_put_out(SubStr('message data ='||l_msg_data,1,255));
                End LOOP;
                ret_code := 2;
                ERR_BUF := 'Order Creation Logistics API Failed Serial # '||R.SERIAL_NUMBER|| ' spare # ' || R.SPARE_PART;
                do_rollback; --commented by sreeram
                return;
              END IF;
              IF (nvl(l_return_status,'S') = 'S') THEN
                begin
                  select order_header_id into v_dummy from CSD_PRODUCT_TXNS_V where product_transaction_id = t.product_transaction_id;
                  if v_order_header_id is null then
                    if v_dummy is null then
                      -- error - order not created
                      dbms_output_put_out('Error order not created');
                      ret_code := 2;
                      err_buf := 'Order Not Created By Logistics API Serial # '||r.serial_number|| ' spare # ' || r.spare_part;
                      do_rollback; --commented by sreeram
                      return;
                    else
                      v_order_header_id := v_dummy;
                    end if;
                  else
                    IF V_ORDER_HEADER_ID != V_DUMMY THEN
                      dbms_output_put_out('error order mismatch found prodTrn Id '||to_char(t.product_transaction_id));
                      dbms_output_put_line('add to '|| to_char(v_order_header_id));
                      dbms_output_put_line('added to '|| to_char(v_dummy));
                      ret_code := 2;
                      ERR_BUF := 'New Order Creation Attempted By Logistics API Serial # '||R.SERIAL_NUMBER|| ' spare # ' || R.SPARE_PART;
                      do_rollback; --commented dby sreeram
                      return;
                    end if;
                  end if;
                end;
              END if;
            END;
            <<next_line>>
            null;
          end loop;
        end loop;
      end;
      /**************************************************/
      /**************************************************/
      /* Update Shipping method, freight terms, shipping instructions to order line */
      If V_Order_Header_Id Is Not Null And
        (h.ship_method_code is not null or h.freight_terms_code is not null or h.shipping_instructions is not null)
      then
        DECLARE
          l_header_rec OE_ORDER_PUB.Header_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_REC;
          l_line_tbl OE_ORDER_PUB.Line_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_TBL;
          l_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type := OE_ORDER_PUB.G_MISS_REQUEST_TBL;
          l_header_adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL;
          l_line_adj_tbl OE_ORDER_PUB.line_adj_tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL;
          l_header_scr_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL;
          l_line_scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL;
          l_request_rec OE_ORDER_PUB.Request_Rec_Type ;
          l_return_status VARCHAR2(1000);
          l_msg_count NUMBER;
          l_msg_data VARCHAR2(1000);
          p_api_version_number NUMBER :=1.0;
          p_init_msg_list VARCHAR2(10) := FND_API.G_FALSE;
          p_return_values VARCHAR2(10) := FND_API.G_FALSE;
          p_action_commit VARCHAR2(10) := FND_API.G_FALSE;
          x_return_status VARCHAR2(1);
          x_msg_count NUMBER;
          x_msg_data VARCHAR2(100);
          /*
          p_header_rec OE_ORDER_PUB.Header_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_REC;
          p_old_header_rec OE_ORDER_PUB.Header_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_REC;
          p_header_val_rec OE_ORDER_PUB.Header_Val_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_VAL_REC;
          p_old_header_val_rec OE_ORDER_PUB.Header_Val_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_VAL_REC;
          p_Header_Adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL;
          p_old_Header_Adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL;
          p_Header_Adj_val_tbl OE_ORDER_PUB.Header_Adj_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_VAL_TBL;
          p_old_Header_Adj_val_tbl OE_ORDER_PUB.Header_Adj_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_VAL_TBL;
          p_Header_price_Att_tbl OE_ORDER_PUB.Header_Price_Att_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_PRICE_ATT_TBL;
          p_old_Header_Price_Att_tbl OE_ORDER_PUB.Header_Price_Att_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_PRICE_ATT_TBL;
          p_Header_Adj_Att_tbl OE_ORDER_PUB.Header_Adj_Att_Tbl_Type :=  OE_ORDER_PUB.G_MISS_HEADER_ADJ_ATT_TBL;
          p_old_Header_Adj_Att_tbl OE_ORDER_PUB.Header_Adj_Att_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ATT_TBL;
          p_Header_Adj_Assoc_tbl OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ASSOC_TBL;
          p_old_Header_Adj_Assoc_tbl OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ASSOC_TBL;
          p_Header_Scredit_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL;
          p_old_Header_Scredit_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL;
          p_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_VAL_TBL;
          p_old_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_VAL_TBL;
          p_line_tbl OE_ORDER_PUB.Line_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_TBL;
          p_old_line_tbl OE_ORDER_PUB.Line_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_TBL;
          p_line_val_tbl OE_ORDER_PUB.Line_Val_Tbl_Type :=  OE_ORDER_PUB.G_MISS_LINE_VAL_TBL;
          p_old_line_val_tbl OE_ORDER_PUB.Line_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_VAL_TBL;
          p_Line_Adj_tbl OE_ORDER_PUB.Line_Adj_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL;
          p_old_Line_Adj_tbl OE_ORDER_PUB.Line_Adj_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL;
          p_Line_Adj_val_tbl OE_ORDER_PUB.Line_Adj_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_VAL_TBL;
          p_old_Line_Adj_val_tbl OE_ORDER_PUB.Line_Adj_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_VAL_TBL;
          p_Line_price_Att_tbl OE_ORDER_PUB.Line_Price_Att_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_TBL;
          p_old_Line_Price_Att_tbl OE_ORDER_PUB.Line_Price_Att_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_TBL;
          p_Line_Adj_Att_tbl OE_ORDER_PUB.Line_Adj_Att_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_ATT_TBL;
          p_old_Line_Adj_Att_tbl OE_ORDER_PUB.Line_Adj_Att_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_ATT_TBL;
          p_Line_Adj_Assoc_tbl OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_ASSOC_TBL;
          p_old_Line_Adj_Assoc_tbl OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_ADJ_ASSOC_TBL;
          p_Line_Scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL;
          p_old_Line_Scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL;
          p_Line_Scredit_val_tbl OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_VAL_TBL;
          p_old_Line_Scredit_val_tbl OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_VAL_TBL;
          p_Lot_Serial_tbl OE_ORDER_PUB.Lot_Serial_Tbl_Type := OE_ORDER_PUB.G_MISS_LOT_SERIAL_TBL;
          p_old_Lot_Serial_tbl OE_ORDER_PUB.Lot_Serial_Tbl_Type := OE_ORDER_PUB.G_MISS_LOT_SERIAL_TBL;
          p_Lot_Serial_val_tbl OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_LOT_SERIAL_VAL_TBL;
          p_old_Lot_Serial_val_tbl OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type := OE_ORDER_PUB.G_MISS_LOT_SERIAL_VAL_TBL;
          p_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type := OE_ORDER_PUB.G_MISS_REQUEST_TBL;
          */
          x_header_val_rec OE_ORDER_PUB.Header_Val_Rec_Type;
          x_Header_Adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type;
          x_Header_Adj_val_tbl OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
          x_Header_price_Att_tbl OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
          x_Header_Adj_Att_tbl OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
          x_Header_Adj_Assoc_tbl OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
          x_Header_Scredit_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type;
          x_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
          x_line_val_tbl OE_ORDER_PUB.Line_Val_Tbl_Type;
          x_Line_Adj_tbl OE_ORDER_PUB.Line_Adj_Tbl_Type;
          x_Line_Adj_val_tbl OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
          x_Line_price_Att_tbl OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
          x_Line_Adj_Att_tbl OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
          x_Line_Adj_Assoc_tbl OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
          x_Line_Scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type;
          x_Line_Scredit_val_tbl OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
          x_Lot_Serial_tbl OE_ORDER_PUB.Lot_Serial_Tbl_Type;
          x_Lot_Serial_val_tbl OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type;
          x_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type;
          X_DEBUG_FILE VARCHAR2(100);
          l_line_tbl_index NUMBER;
          L_MSG_INDEX_OUT NUMBER(10);
          
          X_header_rec OE_ORDER_PUB.Header_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_REC;
          X_LINE_TBL OE_ORDER_PUB.LINE_TBL_TYPE := OE_ORDER_PUB.G_MISS_LINE_TBL;
          lX_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type := OE_ORDER_PUB.G_MISS_REQUEST_TBL;
          
          Cursor C_Headers(X_Header_Id Number) Is
          Select Header_Id, Order_Number, Shipping_Method_Code, Freight_Carrier_Code, Freight_Terms_Code, Shipping_Instructions From Oe_Order_Headers_All Where header_id = x_header_id; --and order_number = 8244784;
          cursor c_lines(x_header_id number) is
          select line_id, line_number, shipping_method_code, freight_carrier_code, freight_terms_code, shipping_instructions from oe_order_lines_all
          --where header_id = 1777126
          where header_id = x_header_id
          ;
        BEGIN
          /*
          declare
            p_resp_appl_id number := 20003;
            p_resp_id number := 51279;
            p_user_id number := 11752;
          begin
            FND_GLOBAL.APPS_INITIALIZE(user_id => p_user_id,resp_id => p_resp_id,resp_appl_id => p_resp_appl_id);
          end;
          */
          
          FND_FILE.PUT_LINE(FND_FILE.LOG, 'fndglobal user id'||FND_GLOBAL.USER_ID);
          FND_FILE.PUT_LINE(FND_FILE.LOG, 'fndglobal resp id'||FND_GLOBAL.RESP_ID);
          FND_FILE.PUT_LINE(FND_FILE.LOG, 'fndglobal resp appl id'||FND_GLOBAL.RESP_APPL_ID);
          FND_FILE.PUT_LINE(FND_FILE.LOG, 'fnd profile org id'||TO_CHAR(FND_PROFILE.VALUE('ORG_ID')));
          FND_GLOBAL.APPS_INITIALIZE(FND_GLOBAL.USER_ID,FND_GLOBAL.RESP_ID,FND_GLOBAL.RESP_APPL_ID);
          
          MO_GLOBAL.INIT('ONT'); -- Required for R12 
          
          MO_GLOBAL.SET_POLICY_CONTEXT('S', 102 ); -- Required for R12

          
          OE_MSG_PUB.INITIALIZE;
          oe_debug_pub.initialize;
          X_DEBUG_FILE := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
          OE_DEBUG_PUB.SETDEBUGLEVEL(5); -- Use 5 for the most debuging output, I warn  you its a lot of data
          DBMS_OUTPUT_PUT_LINE('START OF NEW DEBUG'||X_DEBUG_FILE);
          FND_FILE.PUT_LINE(FND_FILE.LOG,'File name '||OE_DEBUG_PUB.G_DIR||'/'||OE_DEBUG_PUB.G_FILE);
          
          for o in c_headers(v_order_header_id) loop
            l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
            l_line_tbl := OE_ORDER_PUB.G_MISS_LINE_TBL;
            l_action_request_tbl := OE_ORDER_PUB.G_MISS_REQUEST_TBL;
            l_header_adj_tbl := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL;
            l_line_adj_tbl := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL;
            l_header_scr_tbl := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL;
            l_line_scredit_tbl := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL;
            -------- HEADER UPDATE START ----------
            l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
            l_header_rec.header_id := o.header_id;
            IF H.SHIP_METHOD_CODE IS NOT NULL THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG, 'ship method code'|| H.SHIP_METHOD_CODE);
            FND_FILE.PUT_LINE(FND_FILE.LOG, 'freight code'|| h.freight_code);
              l_header_rec.shipping_method_code := h.ship_method_code;
              l_header_rec.freight_carrier_code := h.freight_code;
            end if;
            if h.freight_terms_code is not null then
             L_HEADER_REC.FREIGHT_TERMS_CODE := H.FREIGHT_TERMS_CODE;
             FND_FILE.PUT_LINE(FND_FILE.LOG, 'freight terms code'|| h.FREIGHT_TERMS_CODE);
            end if;
            IF H.SHIPPING_INSTRUCTIONS IS NOT NULL THEN
             FND_FILE.PUT_LINE(FND_FILE.LOG, 'SHIPPING_INSTRUCTIONS'|| h.SHIPPING_INSTRUCTIONS);
              l_header_rec.shipping_instructions := h.shipping_instructions;
            End If;
              --p_header_rec.change_reason := 'Not provided';
              -- Indicates to process order that this is an update operation
              l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;
              OE_ORDER_PUB.process_order (
              p_api_version_number => 1.0
              , p_init_msg_list => fnd_api.g_false
              , p_return_values => fnd_api.g_false
              , p_action_commit => fnd_api.g_false
              , x_return_status => l_return_status
              , x_msg_count => l_msg_count
              , x_msg_data => l_msg_data
              , p_header_rec => l_header_rec
              , p_line_tbl => l_line_tbl
              , p_action_request_tbl => l_action_request_tbl
              -- OUT PARAMETERS
              , x_header_rec => x_header_rec
              , x_header_val_rec => x_header_val_rec
              , x_Header_Adj_tbl => x_Header_Adj_tbl
              , x_Header_Adj_val_tbl => x_Header_Adj_val_tbl
              , x_Header_price_Att_tbl => x_Header_price_Att_tbl
              , x_Header_Adj_Att_tbl => x_Header_Adj_Att_tbl
              , x_Header_Adj_Assoc_tbl => x_Header_Adj_Assoc_tbl
              , x_Header_Scredit_tbl => x_Header_Scredit_tbl
              , X_HEADER_SCREDIT_VAL_TBL => X_HEADER_SCREDIT_VAL_TBL
              , x_line_tbl => x_line_tbl
              , x_line_val_tbl => x_line_val_tbl
              , x_Line_Adj_tbl => x_Line_Adj_tbl
              , x_Line_Adj_val_tbl => x_Line_Adj_val_tbl
              , x_Line_price_Att_tbl => x_Line_price_Att_tbl
              , x_Line_Adj_Att_tbl => x_Line_Adj_Att_tbl
              , x_Line_Adj_Assoc_tbl => x_Line_Adj_Assoc_tbl
              , x_Line_Scredit_tbl => x_Line_Scredit_tbl
              , X_LINE_SCREDIT_VAL_TBL => X_LINE_SCREDIT_VAL_TBL
              , X_LOT_SERIAL_TBL => X_LOT_SERIAL_TBL
              , X_LOT_SERIAL_VAL_TBL => X_LOT_SERIAL_VAL_TBL
              , x_action_request_tbl => lx_action_request_tbl
              );
              IF l_return_status = FND_API.G_RET_STS_SUCCESS THEN
                dbms_output_put_line('Order Shipping Method, Freight Terms, Shipping Inst update successful Order # '|| to_char(o.order_number));
              ELSE
                dbms_output_put_out('Order Shipping Method, Freight Terms, Shipping Inst update Failed Order # '|| to_char(o.order_number));
                dbms_output_put_out(l_msg_data);
                FOR i IN 1 .. l_msg_count LOOP
                  Oe_Msg_Pub.get( p_msg_index => i
                  , p_encoded => Fnd_Api.G_FALSE
                  , p_data => l_msg_data
                  , p_msg_index_out => l_msg_index_out);
                  dbms_output_put_out('message is: ' || l_msg_data);
                  dbms_output_put_out('message index is: ' || l_msg_index_out);
                END LOOP;
              END IF;
            -------- HEADER UPDATE END ----------
            -------- EACH LINE UPDATE END -----------
            l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
            l_line_tbl_index :=0;
            for l in c_lines(o.header_id) loop
              --This is to UPDATE order line
              l_line_tbl_index :=l_line_tbl_index +1;
              -- Changed attributes
              l_line_tbl(l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
              --l_line_tbl(l_line_tbl_index).invoice_to_org_id := 322;
              if h.ship_method_code is not null then
                l_line_tbl(l_line_tbl_index).shipping_method_code := h.ship_method_code;
                L_LINE_TBL(L_LINE_TBL_INDEX).FREIGHT_CARRIER_CODE := H.FREIGHT_CODE;
                
              end if;
              if h.freight_terms_code is not null then
               l_line_tbl(l_line_tbl_index).freight_terms_code := h.freight_terms_code;
              end if;
              if h.shipping_instructions is not null then
                l_line_tbl(l_line_tbl_index).shipping_instructions := h.shipping_instructions;
              END IF;
              FND_FILE.PUT_LINE(FND_FILE.LOG, 'SHIPPING_INSTRUCTIONS'|| h.SHIPPING_INSTRUCTIONS);
              FND_FILE.PUT_LINE(FND_FILE.LOG, 'freight terms code'|| H.FREIGHT_TERMS_CODE);
              FND_FILE.PUT_LINE(FND_FILE.LOG, 'ship method code'|| H.SHIP_METHOD_CODE);
              FND_FILE.PUT_LINE(FND_FILE.LOG, 'freight code'|| h.freight_code);
              -- Primary key of the entity i.e. the order line
              l_line_tbl(l_line_tbl_index).line_id := l.line_id;
              l_line_tbl(l_line_tbl_index).change_reason := 'Not provided';
              -- Indicates to process order that this is an update operation
              l_line_tbl(l_line_tbl_index).operation := OE_GLOBALS.G_OPR_UPDATE;
              -- CALL TO PROCESS ORDER
              OE_ORDER_PUB.process_order (
              p_api_version_number => 1.0
              , p_init_msg_list => fnd_api.g_false
              , p_return_values => fnd_api.g_false
              , p_action_commit => fnd_api.g_false
              , x_return_status => l_return_status
              , x_msg_count => l_msg_count
              , x_msg_data => l_msg_data
              , p_header_rec => l_header_rec
              , p_line_tbl => l_line_tbl
              , p_action_request_tbl => l_action_request_tbl
              -- OUT PARAMETERS
              , x_header_rec => x_header_rec
              , x_header_val_rec => x_header_val_rec
              , x_Header_Adj_tbl => x_Header_Adj_tbl
              , x_Header_Adj_val_tbl => x_Header_Adj_val_tbl
              , x_Header_price_Att_tbl => x_Header_price_Att_tbl
              , x_Header_Adj_Att_tbl => x_Header_Adj_Att_tbl
              , X_HEADER_ADJ_ASSOC_TBL => X_HEADER_ADJ_ASSOC_TBL
              , x_Header_Scredit_tbl => x_Header_Scredit_tbl
              , X_HEADER_SCREDIT_VAL_TBL => X_HEADER_SCREDIT_VAL_TBL
              , x_line_tbl => x_line_tbl
              , x_line_val_tbl => x_line_val_tbl
              , X_LINE_ADJ_TBL => X_LINE_ADJ_TBL
              , x_Line_Adj_val_tbl => x_Line_Adj_val_tbl
              , x_Line_price_Att_tbl => x_Line_price_Att_tbl
              , x_Line_Adj_Att_tbl => x_Line_Adj_Att_tbl
              , x_Line_Adj_Assoc_tbl => x_Line_Adj_Assoc_tbl
              , x_Line_Scredit_tbl => x_Line_Scredit_tbl
              , x_Line_Scredit_val_tbl => x_Line_Scredit_val_tbl
              , x_Lot_Serial_tbl => x_Lot_Serial_tbl
              , X_LOT_SERIAL_VAL_TBL => X_LOT_SERIAL_VAL_TBL
              , x_action_request_tbl => lx_action_request_tbl
              );
              --dbms_output_put_line('OM Debug file: ' ||oe_debug_pub.G_DIR||'/'||oe_debug_pub.G_FILE);
              -- Check the return status
              IF l_return_status = FND_API.G_RET_STS_SUCCESS THEN
                dbms_output_put_line('Order Line update Sucessful Order # '|| to_char(o.order_number) ||'Line # '||to_char(l.line_number));
              ELSE
                dbms_output_put_out('Order Line update Failed Order # '|| to_char(o.order_number) ||'Line # '||to_char(l.line_number));
                DBMS_OUTPUT_PUT_OUT(L_MSG_DATA);
                FOR i IN 1 .. l_msg_count LOOP
                  OE_MSG_PUB.GET( P_MSG_INDEX => I
                  , p_encoded => Fnd_Api.G_FALSE
                  , p_data => l_msg_data
                  , p_msg_index_out => l_msg_index_out);
                  dbms_output_put_out('message is: ' || l_msg_data);
                  dbms_output_put_out('message index is: ' || l_msg_index_out);
                END LOOP;
              END IF;
            end loop;
            -------- EACH LINE UPDATE END -----------
          end loop;
        END;
      End If;
      -- display SR#s is there are any
       --dbms_output_put_out('header id: ' || h.id); added and commented by sreeram
      Display_Success_Results(h.id);
    end loop;
  END;
end;
/
