CREATE OR REPLACE package XXHA_OH_SR_CONTROL_ISSUE_PKG
as
    PROCEDURE MAIN(
	       err_buf      out  VARCHAR2
              ,ret_code     OUT  VARCHAR2
              ,p_commit_flag  IN   VARCHAR2 DEFAULT 'Y'
              );
end XXHA_OH_SR_CONTROL_ISSUE_PKG;
/


CREATE OR REPLACE package body XXHA_OH_SR_CONTROL_ISSUE_PKG
as
    PROCEDURE MAIN(
	       err_buf      out  VARCHAR2
              ,ret_code     OUT  VARCHAR2
              ,p_commit_flag  IN   VARCHAR2 DEFAULT 'Y'
              ) is

        Cursor c_ohb is
           select organization_code,
                  items.segment1 item_number,
                  items.description item_description,
                  ohb.inventory_item_id,
                  create_transaction_id,
                  ohb.organization_id,
                  transaction_quantity,
                  subinventory_code,
                  ohb.revision,locator_id,
                  ohb.lot_number 
                  ,expiration_date--,serial_number
           from mtl_onhand_quantities ohb,
                mtl_system_items items,
                mtl_parameters param
                ,mtl_lot_numbers lot
           where 1=1
and items.inventory_item_id = ohb.inventory_item_id
and items.organization_id = ohb.organization_id
and items.serial_number_control_code not in (5)
and items.organization_id = param.organization_id
and lot.inventory_item_id(+) = ohb.inventory_item_id
and lot.organization_id(+) = ohb.organization_id
and lot.lot_number(+) = ohb.lot_number
and items.segment1 in (
'6601008',
'6601010',
'01919-XX',
'100275-00',
'100276-00',
'100418-00',
'101035-00',
'101157-02',
'101369-01',
'101551-00',
'101555-00',
'101558-00',
'101568-00',
'101569-00',
'101607-00',
'101989-00',
'102074-01',
'102237-00',
'102238-00',
'102239-00',
'102384-00',
'102645-00',
'103173-01',
'103690-01',
'105466-00',
'105467-00',
'105507-00',
'34435-00',
'35159-01',
'35159-02',
'35159-03',
'35159-04',
'35192-00',
'35200-00',
'35200-01',
'35203-00',
'35206-00',
'35209-00',
'35215-00',
'35218-00',
'36443-00',
'36443-01',
'36443-02',
'36557-00',
'36557-01',
'36557-02',
'36557-03',
'36557-04',
'36560-00',
'36734-00',
'36734-01',
'36740-00',
'36743-00',
'36823-00',
'36917-00',
'36919-00',
'36926-00',
'36928-00',
'36930-00',
'36931-00',
'36931-05',
'36935-00',
'36946-00',
'36965-00',
'37009-00',
'37010-00',
'37049-00',
'37107-00',
'37107-05',
'37136-00',
'37187-00',
'37199-00',
'37303-00',
'37347-00',
'37365-00',
'37382-00',
'37383-00',
'37390-00',
'37436-00',
'37440-00',
'37458-00',
'37558-00',
'37558-01',
'37607-00',
'37657-00',
'37854-00',
'37904-00',
'38036-00',
'38040-00',
'38054-00',
'38055-00',
'38057-00',
'38108-00',
'38118-00',
'38125-00',
'38243-00',
'38308-00',
'38308-02',
'38355-00',
'38870-00',
'39207-00',
'39208-01',
'39208-02',
'39269-00',
'39292-00',
'39293-00',
'39379-00',
'39390-00',
'39436-00',
'39627-00',
'39832-00',
'39971-00',
'47432-00',
'47434-00',
'47497-00',
'48059-00',
'48060-00',
'48073-00',
'48099-00',
'48102-00',
'48124-00',
'48221-00',
'48257-00',
'48343-00',
'48414-00',
'48415-00',
'48438-00',
'48459-00',
'48542-00',
'48792-00',
'48846-00',
'48886-00',
'48895-00',
'49084-00',
'49488-00',
'49730-00',
'50063-01',
'50132-00',
'50134-00',
'50160-01',
'50197-00',
'50313-00',
'50362-00',
'50440-00',
'50454-01',
'50454-02',
'50505-00',
'50507-00',
'50515-00',
'50550-01',
'50561-01',
'50568-00',
'50609-00',
'50611-00',
'50630-01',
'50646-00',
'50648-00',
'50651-00',
'50656-00',
'50668-00',
'50681-00',
'50830-01',
'50846-01',
'50902-00',
'51103-00',
'51104-00',
'51161-00',
'51201-00',
'51315-00',
'51433-00',
'51649-01',
'51659-01',
'51664-01',
'51674-01',
'51867-00',
'52241-01',
'52273-00',
'52358-00',
'52480-01',
'52497-00',
'52512-00',
'52606-00',
'52740-02',
'52769-01',
'52769-02',
'52774-01',
'52818-00',
'52818-01',
'52852-00',
'52863-00',
'52864-00',
'52867-00',
'52874-00',
'52877-00',
'53051-00',
'53082-02',
'53208-00',
'6601008',
'85736-00',
'86051-00',
'86054-00',
'86102-00',
'86158-01',
'86198-01',
'86198-02',
'86237-00',
'BIO-940228',
'BIO-940229',
'BIO-940230',
'BIO-940320',
'BIO-940340',
'BIO-940410',
'BIO-940411',
'BIO-940428',
'BIO-940432',
'BIO-940540',
'S-24901000-00',
'S-24901100-00',
'T0012-00',
'T0012-01',
'T0453-00',
'T0825-00',
'T1207-00',
'T1227-00',
'T1294-00',
'T1295-00',
'T1392-00',
'T1394-00',
'T1542-00',
'37108-00',
'48068-00',
'50133-00',
'50054-00',
'101552-00',
'37606-00',
'37700-00'
);
 

  lc_code_combination_id   number;
  lc_transaction_type_id   number;
  lc_transaction_action_id number;
  lc_transaction_source_type_id  number;
  lc_material_transactions_id number;
  lc_count number := 0;
  lc_locator_id   number;
  lc_reason_id    number;
  l_uom_code      varchar2(40);

BEGIN


select code_combination_id
into lc_code_combination_id
from gl_code_combinations_kfv
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000';


begin
    select reason_id
    into   lc_reason_id
    from MTL_TRANSACTION_REASONS
    where reason_name = 'SN CNV';

    exception
    when others
    then null;
end;




 FOR v_get_ohb in c_ohb LOOP

  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;

             

  select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;

             
IF v_get_ohb.lot_number is not null then

 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
                                                         ,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,-1
                                                       ,SYSDATE
                                                       ,-1
                                                       ,'INV ADJ ISSUE'
                                                       );

  INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
                                                        ,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,-1
                                                       ,SYSDATE
                                                       ,-1
                                                       ,'INV ADJ ISSUE'
                                                       );

end if;

insert into mtl_transactions_interface
      (						     last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                    ,locator_id
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    , reason_id
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,-1
                                                   ,SYSDATE
                                                   ,-1
                                                   ,'INV ADJ ISSUE'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                   ,v_get_ohb.locator_id
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,lc_code_combination_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   ,lc_reason_id
                                                  );

 

  
insert into XXHA_MTL_TRANSACTIONS_INT_STG
      (						     last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                    ,locator_id
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    , reason_id
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,-1
                                                   ,SYSDATE
                                                   ,-1
                                                   ,'INV ADJ ISSUE'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                   ,v_get_ohb.locator_id
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,lc_code_combination_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   ,lc_reason_id
                                                  );

  

  END LOOP;
commit;

END MAIN;
END XXHA_OH_SR_CONTROL_ISSUE_PKG;
/
