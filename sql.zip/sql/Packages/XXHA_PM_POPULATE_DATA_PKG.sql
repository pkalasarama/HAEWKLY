CREATE OR REPLACE package XXHA_PM_POPULATE_DATA_PKG
-- +================================================================================+
-- | Name        : XXHA_PM_POPULATE_DATA_PKG                                        |
-- | Purpose     : Runs insert-select statements to populate HAEMO schema           |
-- |               tables (XXHA_PM_FIELD_SERVICE_DATA)                              |
-- |               for the On-Time Preventive Maintenance Hyperion report.          |
-- |                                                                                |
-- | Tables Accessed :                                                              |
-- | Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)  |
-- |                                                                                |
-- | XXHA_PM_FIELD_SERVICE_DATA         D, I                                        |
-- |                                                                                |
-- | History                                                                        |
-- | =======                                                                        |
-- | When      Rev  Who               What                                          |
-- | --------  ---  --------          --------------------------------------------- |
-- | 20111013  1.0  Vasil S. Valkov   Initial version
-- | 20140306  2.0  Umamahesh         Modified the code because of performence issue |
-- +================================================================================+
AS

PROCEDURE GET_PM_FIELD_SERVICE_DATA
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
         );



end XXHA_PM_POPULATE_DATA_PKG;
/


CREATE OR REPLACE package body XXHA_PM_POPULATE_DATA_PKG
-- +================================================================================+
-- | Name        : XXHA_PM_POPULATE_DATA_PKG                                        |
-- | Purpose     : Runs insert-select statements to populate HAEMO schema           |
-- |               tables (XXHA_PM_FIELD_SERVICE_DATA)                              |
-- |               for the On-Time Preventive Maintenance Hyperion report.          |
-- |                                                                                |
-- | Tables Accessed :                                                              |
-- | Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)  |
-- |                                                                                |
-- | XXHA_PM_FIELD_SERVICE_DATA         D, I                                        |
-- |                                                                                |
-- | History                                                                        |
-- | =======                                                                        |
-- | When      Rev  Who               What                                          |
-- | --------  ---  --------          --------------------------------------------- |
-- | 20111013  1.0  Vasil S. Valkov   Initial version                 		          |
-- | 11/21/12  2.0  IPadela           changed the joins in the cursor cur_get_pm_data
-- |                                  to get the incident status from cs_incident_statuses
-- |                                  as per input from SKalmanker                  |
-- | 01/10/13  3.0  IPadela           if it is a Depot Repair call, get the task and debrief
-- |                                  details from the depot tasks tables           |
-- |                                  as per input from SKalmanker                  |
-- | 06/01/14  4.0  Umamahesh         Modified the code because of performence issue |
-- +================================================================================+
as
PROCEDURE GET_PM_FIELD_SERVICE_DATA
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
         ) IS

	 CURSOR C IS
    SELECT AL2.INCIDENT_ID,
  AL2.INCIDENT_NUMBER,
  AL2.INCIDENT_DATE,
  AL2.INCIDENT_OCCURRED_DATE Reported_Date,
  AL3.PARTY_NAME Customer_Name,
  AL3.PARTY_NUMBER,
  AL4.ACCOUNT_NUMBER,
  AL5.INSTANCE_ID,
  AL5.INSTANCE_NUMBER,
  AL5.SERIAL_NUMBER,
  AL6.SEGMENT1 Inventory_Item,
  AL6.DESCRIPTION Inventory_Item_Description,
  AL6.INVENTORY_ITEM_ID,
  AL7.MACHINE_GROUPING,
  AL5.EXTERNAL_REFERENCE,
--  AL1.INCIDENT_OWNER,
--  AL1.INCIDENT_STATUS_MEANING,
--  AL1.SEVERITY,
--  AL1.INCIDENT_TYPE,
  al35.resource_name incident_owner,
  -- 2.0 IPadela
  --al36.meaning incident_status_meaning,
  al36.name incident_status_meaning,
  --end
  al37.name severity,
  al38.name incident_type,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS1, 'HZ_PARTY_SITE', AL15.ADDRESS1, 'INTERNAL_SITE', AL16.ADDRESS_LINE_1, 'INVENTORY', AL16.ADDRESS_LINE_1, 'VENDOR_SITE', AL17.ADDRESS_LINE1, NULL ) Install_At_Address1,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS2, 'HZ_PARTY_SITE', AL15.ADDRESS2, 'INTERNAL_SITE', AL16.ADDRESS_LINE_2, 'INVENTORY', AL16.ADDRESS_LINE_2, 'VENDOR_SITE', AL17.ADDRESS_LINE2, NULL ) Install_At_Address2,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS3, 'HZ_PARTY_SITE', AL15.ADDRESS3, 'INTERNAL_SITE', AL16.ADDRESS_LINE_3, 'INVENTORY', AL16.ADDRESS_LINE_3, 'VENDOR_SITE', AL17.ADDRESS_LINE3, NULL ) Install_At_Address3,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS4, 'HZ_PARTY_SITE', AL15.ADDRESS4, 'INTERNAL_SITE', NULL, 'INVENTORY', NULL, 'VENDOR_SITE', NULL, NULL ) Install_At_Address4,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.CITY, 'HZ_PARTY_SITE', AL15.CITY, 'INTERNAL_SITE', AL16.TOWN_OR_CITY, 'INVENTORY', AL16.TOWN_OR_CITY, 'VENDOR_SITE', AL17.CITY, NULL ) Install_At_CITY,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.STATE, 'HZ_PARTY_SITE', AL15.STATE, 'INTERNAL_SITE', NULL, 'INVENTORY', NULL, 'VENDOR_SITE', AL17.STATE, NULL ) Install_At_STATE,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.POSTAL_CODE, 'HZ_PARTY_SITE', AL15.POSTAL_CODE, 'INTERNAL_SITE', AL16.POSTAL_CODE, 'INVENTORY', AL16.POSTAL_CODE, 'VENDOR_SITE', AL17.ZIP, NULL ) Install_At_POSTAL_CODE,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL14.PARTY_SITE_NUMBER, 'HZ_PARTY_SITE', AL13.PARTY_SITE_NUMBER, NULL ) Install_At_SITE_NUMBER,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.COUNTRY, 'HZ_PARTY_SITE', AL15.COUNTRY, 'INTERNAL_SITE', AL16.COUNTRY, 'INVENTORY', AL16.COUNTRY, 'VENDOR_SITE', AL17.COUNTRY, NULL ) Install_At_COUNTRY,
  AL8.ADDRESS1 Bill_To_Address1,
  AL8.ADDRESS2 Bill_To_Address2,
  AL8.ADDRESS3 Bill_To_Address3,
  AL8.ADDRESS4 Bill_To_Address4,
  AL8.CITY Bill_To_CITY,
  AL8.STATE Bill_To_STATE,
  AL8.POSTAL_CODE Bill_To_POSTAL_CODE,
  AL8.COUNTRY Bill_To_COUNTRY,
  AL9.PARTY_SITE_NUMBER Bill_To_SITE_NUMBER,
  AL11.ADDRESS1 Ship_To_Address1,
  AL11.ADDRESS2 Ship_To_Address2,
  AL11.ADDRESS3 Ship_To_Address3,
  AL11.ADDRESS4 Ship_To_Address4,
  AL11.CITY Ship_To_CITY,
  AL11.STATE Ship_To_STATE,
  AL11.POSTAL_CODE Ship_To_POSTAL_CODE,
  AL11.COUNTRY Ship_To_COUNTRY,
  AL10.PARTY_SITE_NUMBER Ship_To_SITE_NUMBER,
  AL2.CONTRACT_NUMBER,
  al40.contract_number_modifier,
  AL19.SERVICE_NAME CONTRACT_TYPE,
  AL2.INCIDENT_ATTRIBUTE_1 Hospital_Dealer_Location,
  AL2.INCIDENT_CONTEXT PIR_Review,
  AL2.INCIDENT_ATTRIBUTE_2 Process_Phase,
  AL2.INCIDENT_ATTRIBUTE_3 Involves_Death,
  AL2.INCIDENT_ATTRIBUTE_4 Involves_Injury,
  AL2.INCIDENT_ATTRIBUTE_5 Risk_Complaint,
  AL2.INCIDENT_ATTRIBUTE_6 Extended_hospitalization,
  AL2.SUMMARY Problem_Summary,
  AL2.PROBLEM_CODE,
  AL20.MEANING Problem_Code_Meaning,
  AL20.DESCRIPTION Problem_Code_Description,
  AL2.RESOLUTION_SUMMARY Resolution_Summary,
  AL2.RESOLUTION_CODE,
  AL21.MEANING Resolution_Code_Meaning,
  AL21.DESCRIPTION Resolution_Code_Description,
  al2.close_date,

  --3.0 IPadela
  DECODE ( al38.name, 'Depot Repair',AL34.Task_id, AL24.TASK_ID) TASK_ID,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_NUMBER, AL24.TASK_NUMBER) TASK_NUMBER,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_STATUS, AL24.TASK_STATUS) TASK_STATUS,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_PRIORITY, AL24.TASK_PRIORITY) TASK_PRIORITY,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_NAME, AL24.TASK_NAME) TASK_NAME,
  DECODE ( al38.name, 'Depot Repair',AL34.OWNER_TYPE, AL24.OWNER_TYPE) OWNER_TYPE,
  DECODE ( al38.name, 'Depot Repair',AL34.OWNER, AL24.OWNER) OWNER,
  DECODE ( al38.name, 'Depot Repair',AL42.RESOURCE_TYPE_NAME, AL25.RESOURCE_TYPE_NAME) task_assignee_type,
  DECODE ( al38.name, 'Depot Repair',AL42.TASK_ASSIGNMENT_ID, AL25.TASK_ASSIGNMENT_ID) TASK_ASSIGNMENT_ID,
  DECODE ( al38.name, 'Depot Repair',AL42.RESOURCE_NAME, AL25.RESOURCE_NAME) RESOURCE_NAME,
  --end

  AL26.USER_NAME logged_by,
  AL24.PLANNED_START_DATE,
  AL24.PLANNED_END_DATE,
  AL24.SCHEDULED_START_DATE,
  al24.scheduled_end_date,
  --AL24.ACTUAL_START_DATE,
  --3.0 IPadela
  decode ( al38.name, 'Depot Repair', al34.actual_start_date, al24.actual_start_date ) actual_start_date,
  --end
--  DECODE ( AL1.INCIDENT_TYPE, 'Depot Repair', al34.actual_end_date, al24.actual_end_date ) actual_end_date,
  DECODE ( al38.name, 'Depot Repair', al34.actual_end_date, al24.actual_end_date ) actual_end_date,
--  AL24.ACTUAL_END_DATE,
--  AL30.labor_hours,
--  AL30.expense_value,
--  AL30.expense_currency,
  --AL25.DEBRIEF_NUMBER,
  --AL25.debrief_header_id,
  --al30.debrief_line_id,
  --3.0 IPadela
  DECODE ( al38.name, 'Depot Repair',AL42.DEBRIEF_NUMBER, AL25.DEBRIEF_NUMBER) DEBRIEF_NUMBER,
  DECODE ( al38.name, 'Depot Repair',AL42.debrief_header_id, AL25.debrief_header_id) debrief_header_id,
  decode ( al38.name, 'Depot Repair',al44.debrief_line_id, al30.debrief_line_id) debrief_line_id,
  --end
  AL27.TOTAL_SUBMITTED,
  AL2.CREATION_DATE,
  AL2.LAST_UPDATE_DATE,
  al29.user_name modified_by,
  --AL24.TASK_TYPE,
  --AL28.PROCESSED_FLAG Debrief_Status,
  --3.0 IPadela
  DECODE ( al38.name, 'Depot Repair', AL34.TASK_TYPE, AL24.TASK_TYPE) TASK_TYPE,
  decode ( al38.name, 'Depot Repair', al43.processed_flag, al28.processed_flag) debrief_status,
  --end
  AL31.person_first_name,
  AL31.person_last_name,
  al31.contact_phone_email,
  --al35.billing_type,
  --3.0 IPadela
  decode ( al38.name, 'Depot Repair', al45.billing_type, al35.billing_type) billing_type,
  --end
  al39.organization_id operating_unit_id,
  al39.name operating_unit,
  AL41.RESOURCE_NAME INCIDENT_GROUP
 --BULK COLLECT INTO v_rec_data_new
FROM --HAEMO.XXHA_QD_QUALITY_NOTE_DATA AL1,
  APPS.CS_INCIDENTS_ALL_VL AL2,
  APPS.HZ_PARTIES AL3,
  APPS.HZ_CUST_ACCOUNTS AL4,
  APPS.CSI_ITEM_INSTANCES AL5,
  APPS.MTL_SYSTEM_ITEMS_B AL6,
  HAEMO.XXHA_QD_MACHINE_GROUPS AL7,
  APPS.HZ_LOCATIONS AL8,
  APPS.HZ_PARTY_SITES AL9,
  APPS.HZ_PARTY_SITES AL10,
  APPS.HZ_LOCATIONS AL11,
  APPS.HZ_LOCATIONS AL12,
  APPS.HZ_PARTY_SITES AL13,
  APPS.HZ_PARTY_SITES AL14,
  APPS.HZ_LOCATIONS AL15,
  APPS.HR_LOCATIONS_ALL AL16,
 --- APPS.PO_VENDOR_SITES_ALL AL17,---11i code modified
  APPS.AP_SUPPLIER_SITES_ALL AL17,---R12 Remediated
--  APPS.OKS_AUTH_LINES_V AL18,
  APPS.OKS_LINE_DETAILS_V AL19,
  APPS.CS_LOOKUPS AL20,
  APPS.CS_LOOKUPS AL21,
  APPS.CS_INCIDENT_LINKS AL22,
  APPS.CS_SR_TASKS_V AL24,
  APPS.CSF_DEBRIEF_TASKS_V AL25,
  APPS.FND_USER AL26,
  APPS.CS_CHARGE_DETAILS_V AL27,
  APPS.CSF_DEBRIEF_HEADERS AL28,
  APPS.FND_USER AL29,
  APPS.CSF_DEBRIEF_LINES AL30,
  APPS.CS_TXN_BILLING_TYPES AL35,
--  (SELECT D29AL1.DEBRIEF_HEADER_ID AS debrief_header_id,
--    SUM( D29AL1.QUANTITY )         AS total_labor_hours,
--    SUM( D29AL1.EXPENSE_AMOUNT )   AS total_expense_value,
--    MAX( D29AL1.CURRENCY_CODE )    AS expense_currency
--	d29al1.quantity as labor_hours,
--	d29al1.expense_amount as expense_value,
--	d29al1.currency_code as expense_currency,
--	d29al2.billing_type as debrief_type
--  FROM APPS.CSF_DEBRIEF_LINES D29AL1,
--    APPS.CS_TXN_BILLING_TYPES D29AL2
--  WHERE (D29AL1.TRANSACTION_TYPE_ID=D29AL2.TRANSACTION_TYPE_ID)
--  AND (D29AL2.BILLING_TYPE        <>'M')
--  GROUP BY D29AL1.DEBRIEF_HEADER_ID
--  ) AL30,
  XXHA_PM_DATA_V AL31,
  apps.ahl_unit_effectivities_b al32,
  apps.csd_repairs al33,
  apps.csd_repair_tasks_v al34,
  apps.jtf_rs_all_resources_vl al35,
  -- 2.0 IPadela
  --apps.cs_lookups al36,
  apps.cs_incident_statuses al36,
  --end
  apps.cs_incident_severities_vl al37,
  apps.cs_incident_types_vl al38,
  apps.hr_operating_units al39,
  apps.oks_auth_headers_v al40,
  apps.cs_sr_owners_v al41
  --3.0 IPadela
  ,APPS.CSF_DEBRIEF_TASKS_V AL42,
  APPS.CSF_DEBRIEF_HEADERS AL43,
  APPS.CSF_DEBRIEF_LINES AL44,
  apps.cs_txn_billing_types al45
  --end
WHERE ( AL2.CUSTOMER_ID          = AL3.PARTY_ID (+)
AND AL2.ACCOUNT_ID               = AL4.CUST_ACCOUNT_ID (+)
AND AL2.CUSTOMER_PRODUCT_ID      = AL5.INSTANCE_ID (+)
AND AL2.INVENTORY_ITEM_ID        = AL6.INVENTORY_ITEM_ID (+)
AND AL2.INV_ORGANIZATION_ID      = AL6.ORGANIZATION_ID (+)
AND AL8.LOCATION_ID (+)          = AL9.LOCATION_ID
AND AL2.BILL_TO_SITE_ID          = AL9.PARTY_SITE_ID (+)
AND AL2.SHIP_TO_SITE_ID          = AL10.PARTY_SITE_ID (+)
AND AL10.LOCATION_ID             = AL11.LOCATION_ID (+)
AND AL2.INCIDENT_LOCATION_ID     = AL12.LOCATION_ID (+)
AND AL2.INCIDENT_LOCATION_ID     = AL13.PARTY_SITE_ID (+)
AND AL12.LOCATION_ID             = AL14.LOCATION_ID (+)
AND AL15.LOCATION_ID (+)         = AL13.LOCATION_ID
AND AL2.INCIDENT_LOCATION_ID     = AL16.LOCATION_ID (+)
AND AL2.INCIDENT_LOCATION_ID     = AL17.VENDOR_SITE_ID (+)
--AND AL2.CONTRACT_ID              = AL18.CHR_ID (+)
--AND AL18.ID                      = AL19.LINE_ID (+)
and al2.contract_service_id      = al19.line_id(+)
AND AL2.PROBLEM_CODE             = AL20.LOOKUP_CODE (+)
AND AL21.LOOKUP_CODE (+)         = AL2.RESOLUTION_CODE
AND AL2.INCIDENT_ID              = AL24.SOURCE_OBJECT_ID (+)
AND AL2.INCIDENT_NUMBER          = AL24.SOURCE_OBJECT_NAME (+)
AND AL24.TASK_ID                 = AL25.TASK_ID (+)
AND AL2.INCIDENT_ID              = AL27.INCIDENT_ID (+)
AND AL31.incident_id (+)         = AL2.INCIDENT_ID
--AND AL1.INCIDENT_ID              =AL2.INCIDENT_ID
AND AL6.SEGMENT1                 =AL7.MACHINE_ITEM_NUMBER(+)
AND AL22.SUBJECT_ID              =AL2.INCIDENT_ID
AND AL2.CREATED_BY               =AL26.USER_ID
AND AL25.DEBRIEF_HEADER_ID       =AL28.DEBRIEF_HEADER_ID(+)
AND AL2.LAST_UPDATED_BY          =AL29.USER_ID
AND al25.debrief_header_id = al30.debrief_header_id(+)
and al30.transaction_type_id = al35.transaction_type_id(+)
and al22.object_id = al32.unit_effectivity_id(+)
and al2.incident_id = al33.incident_id(+)
and al33.repair_line_id = al34.source_object_id(+)
and al33.repair_number = al34.source_object_name(+)
and al2.incident_owner_id = al35.resource_id(+)
--2.0 IPadela
--and al2.status_flag = al36.lookup_code
and al2.incident_status_id = al36.incident_status_id
--end
and al2.incident_severity_id = al37.incident_severity_id
AND al2.incident_type_id = al38.incident_type_id
and al2.org_id = al39.organization_id
and al2.contract_id = al40.id(+)
and al2.owner_group_id = al41.resource_id(+)
)
AND AL22.SUBJECT_TYPE            ='SR'
AND AL22.LINK_TYPE_ID            =6
AND AL22.OBJECT_TYPE             ='AHL_UMP_EFF'
AND AL27.INTERFACE_TO_OE_FLAG(+) ='Y'
--2.0 IPadela
--and (al36.lookup_type = 'CSZ_SRCH_STATUS_FLAG_CODE' OR al36.lookup_type IS NULL)
-- end
--3.0 IPadela
AND AL34.TASK_ID                 = AL42.TASK_ID (+)
AND AL42.DEBRIEF_HEADER_ID       =AL43.DEBRIEF_HEADER_ID(+)
AND AL42.DEBRIEF_HEADER_ID = AL44.DEBRIEF_HEADER_ID(+)
AND AL44.TRANSACTION_TYPE_ID = AL45.TRANSACTION_TYPE_ID(+)
--and rownum<=40000;
  ;
    TYPE ARRAY IS TABLE OF C%ROWTYPE;
    v_rec_data_new ARRAY;
    l_errors number;
    l_errno    number;
    l_msg    varchar2(4000);
    l_idx    number;
BEGIN
  execute immediate 'truncate table HAEMO.XXHA_PM_FIELD_SERVICE_DATA';
    open c;
    LOOP
        fetch c bulk collect into v_rec_data_new limit 10000;
        begin
            FORALL I IN 1 .. v_rec_data_new.COUNT SAVE EXCEPTIONS
                INSERT INTO HAEMO.XXHA_PM_FIELD_SERVICE_DATA(
                                                INCIDENT_ID,
                                                INCIDENT_NUMBER,
                                                INCIDENT_DATE,
                                                REPORTED_DATE,
                                                CUSTOMER_NAME,
                                                PARTY_NUMBER,
                                                ACCOUNT_NUMBER,
                                                INSTANCE_ID,
                                                INSTANCE_NUMBER,
                                                SERIAL_NUMBER,
                                                INVENTORY_ITEM,
                                                INVENTORY_ITEM_DESCRIPTION,
                                                INVENTORY_ITEM_ID,
                                                MACHINE_GROUPING,
                                                EXTERNAL_REFERENCE,
                                                INCIDENT_OWNER,
                                                INCIDENT_STATUS_MEANING,
                                                SEVERITY,
                                                INCIDENT_TYPE,
                                                INSTALL_AT_ADDRESS1,
                                                INSTALL_AT_ADDRESS2,
                                                INSTALL_AT_ADDRESS3,
                                                INSTALL_AT_ADDRESS4,
                                                INSTALL_AT_CITY,
                                                INSTALL_AT_STATE,
                                                INSTALL_AT_POSTAL_CODE,
                                                INSTALL_AT_SITE_NUMBER,
                                                INSTALL_AT_COUNTRY,
                                                BILL_TO_ADDRESS1,
                                                BILL_TO_ADDRESS2,
                                                BILL_TO_ADDRESS3,
                                                BILL_TO_ADDRESS4,
                                                BILL_TO_CITY,
                                                BILL_TO_STATE,
                                                BILL_TO_POSTAL_CODE,
                                                BILL_TO_COUNTRY,
                                                BILL_TO_SITE_NUMBER,
                                                SHIP_TO_ADDRESS1,
                                                SHIP_TO_ADDRESS2,
                                                SHIP_TO_ADDRESS3,
                                                SHIP_TO_ADDRESS4,
                                                SHIP_TO_CITY,
                                                SHIP_TO_STATE,
                                                SHIP_TO_POSTAL_CODE,
                                                SHIP_TO_COUNTRY,
                                                SHIP_TO_SITE_NUMBER,
                                                CONTRACT_NUMBER,
                                                CONTRACT_NUMBER_MODIFIER,
                                                CONTRACT_TYPE,
                                                HOSPITAL_DEALER_LOCATION,
                                                PIR_REVIEW,
                                                PROCESS_PHASE,
                                                INVOLVES_DEATH,
                                                INVOLVES_INJURY,
                                                RISK_COMPLAINT,
                                                EXTENDED_HOSPITALIZATION,
                                                PROBLEM_SUMMARY,
                                                PROBLEM_CODE,
                                                PROBLEM_CODE_MEANING,
                                                PROBLEM_CODE_DESCRIPTION,
                                                RESOLUTION_SUMMARY,
                                                RESOLUTION_CODE,
                                                RESOLUTION_CODE_MEANING,
                                                RESOLUTION_CODE_DESCRIPTION,
                                                CLOSE_DATE,
                                                TASK_ID,
                                                TASK_NUMBER,
                                                TASK_STATUS,
                                                TASK_PRIORITY,
                                                TASK_NAME,
                                                OWNER_TYPE,
                                                OWNER,
                                                TASK_ASSIGNEE_TYPE,
                                                TASK_ASSIGNMENT_ID,
                                                RESOURCE_NAME,
                                                LOGGED_BY,
                                                PLANNED_START_DATE,
                                                PLANNED_END_DATE,
                                                SCHEDULED_START_DATE,
                                                SCHEDULED_END_DATE,
                                                ACTUAL_START_DATE,
                                                ACTUAL_END_DATE,
--                                             LABOR_HOURS,
--                                             EXPENSE_VALUE,
--                                             EXPENSE_CURRENCY,
                                                DEBRIEF_NUMBER,
                                                DEBRIEF_HEADER_ID,
                                                DEBRIEF_LINE_ID,
                                                TOTAL_SUBMITTED,
                                                CREATION_DATE,
                                                LAST_UPDATE_DATE,
                                                MODIFIED_BY,
                                                TASK_TYPE,
                                                DEBRIEF_STATUS,
                                                PERSON_FIRST_NAME,
                                                PERSON_LAST_NAME,
                                                CONTACT_PHONE_EMAIL,
                                                BILLING_TYPE,
                                                OPERATING_UNIT_ID,
                                                OPERATING_UNIT,
                                                INCIDENT_GROUP
                                                )
                                                values(v_rec_data_new(i).incident_id,
                                                v_rec_data_new(i).incident_number,
                                                v_rec_data_new(i).incident_date,
                                                v_rec_data_new(i).reported_date,
                                                v_rec_data_new(i).customer_name,
                                                v_rec_data_new(i).party_number,
                                                v_rec_data_new(i).account_number,
                                                v_rec_data_new(i).instance_id,
                                                v_rec_data_new(i).instance_number,
                                                v_rec_data_new(i).serial_number,
                                                v_rec_data_new(i).inventory_item,
                                                v_rec_data_new(i).inventory_item_description,
                                                v_rec_data_new(i).inventory_item_id,
                                                v_rec_data_new(i).machine_grouping,
                                                v_rec_data_new(i).external_reference,
                                                v_rec_data_new(i).incident_owner,
                                                v_rec_data_new(i).incident_status_meaning,
                                                v_rec_data_new(i).severity,
                                                v_rec_data_new(i).incident_type,
                                                v_rec_data_new(i).install_at_address1,
                                                v_rec_data_new(i).install_at_address2,
                                                v_rec_data_new(i).install_at_address3,
                                                v_rec_data_new(i).install_at_address4,
                                                v_rec_data_new(i).install_at_city,
                                                v_rec_data_new(i).install_at_state,
                                                v_rec_data_new(i).install_at_postal_code,
                                                v_rec_data_new(i).install_at_site_number,
                                                v_rec_data_new(i).install_at_country,
                                                v_rec_data_new(i).bill_to_address1,
                                                v_rec_data_new(i).bill_to_address2,
                                                v_rec_data_new(i).bill_to_address3,
                                                v_rec_data_new(i).bill_to_address4,
                                                v_rec_data_new(i).bill_to_city,
                                                v_rec_data_new(i).bill_to_state,
                                                v_rec_data_new(i).bill_to_postal_code,
                                                v_rec_data_new(i).bill_to_country,
                                                v_rec_data_new(i).bill_to_site_number,
                                                v_rec_data_new(i).ship_to_address1,
                                                v_rec_data_new(i).ship_to_address2,
                                                v_rec_data_new(i).ship_to_address3,
                                                v_rec_data_new(i).ship_to_address4,
                                                v_rec_data_new(i).ship_to_city,
                                                v_rec_data_new(i).ship_to_state,
                                                v_rec_data_new(i).ship_to_postal_code,
                                                v_rec_data_new(i).ship_to_country,
                                                v_rec_data_new(i).ship_to_site_number,
                                                v_rec_data_new(i).contract_number,
                                                v_rec_data_new(i).contract_number_modifier,
                                                v_rec_data_new(i).contract_type,
                                                v_rec_data_new(i).hospital_dealer_location,
                                                v_rec_data_new(i).pir_review,
                                                v_rec_data_new(i).process_phase,
                                                v_rec_data_new(i).involves_death,
                                                v_rec_data_new(i).involves_injury,
                                                v_rec_data_new(i).risk_complaint,
                                                v_rec_data_new(i).extended_hospitalization,
                                                v_rec_data_new(i).problem_summary,
                                                v_rec_data_new(i).problem_code,
                                                v_rec_data_new(i).problem_code_meaning,
                                                v_rec_data_new(i).problem_code_description,
                                                v_rec_data_new(i).resolution_summary,
                                                v_rec_data_new(i).resolution_code,
                                                v_rec_data_new(i).resolution_code_meaning,
                                                v_rec_data_new(i).resolution_code_description,
                                                v_rec_data_new(i).close_date,
                                                v_rec_data_new(i).task_id,
                                                v_rec_data_new(i).task_number,
                                                v_rec_data_new(i).task_status,
                                                v_rec_data_new(i).task_priority,
                                                v_rec_data_new(i).task_name,
                                                v_rec_data_new(i).owner_type,
                                                v_rec_data_new(i).owner,
                                                v_rec_data_new(i).task_assignee_type,
                                                v_rec_data_new(i).task_assignment_id,
                                                v_rec_data_new(i).resource_name,
                                                v_rec_data_new(i).logged_by,
                                                v_rec_data_new(i).planned_start_date,
                                                v_rec_data_new(i).planned_end_date,
                                                v_rec_data_new(i).scheduled_start_date,
                                                v_rec_data_new(i).scheduled_end_date,
                                                v_rec_data_new(i).actual_start_date,
                                                v_rec_data_new(i).actual_end_date,
--                                             v_rec_data_new(i).labor_hours,
--                                             v_rec_data_new(i).expense_value,
--                                             v_rec_data_new(i).expense_currency,
                                                v_rec_data_new(i).debrief_number,
                                                v_rec_data_new(i).debrief_header_id,
                                                v_rec_data_new(i).debrief_line_id,
                                                v_rec_data_new(i).total_submitted,
                                                v_rec_data_new(i).creation_date,
                                                v_rec_data_new(i).last_update_date,
                                                v_rec_data_new(i).modified_by,
                                                v_rec_data_new(i).task_type,
                                                v_rec_data_new(i).debrief_status,
                                                v_rec_data_new(i).person_first_name,
                                                v_rec_data_new(i).person_last_name,
                                                v_rec_data_new(i).contact_phone_email,
                                                v_rec_data_new(i).billing_type,
                                                v_rec_data_new(I).OPERATING_UNIT_ID,
                                                v_rec_data_new(i).OPERATING_UNIT,
                                                v_rec_data_new(i).incident_group
                                                );
        EXCEPTION
            WHEN OTHERS  THEN
               IF SQLCODE = -24381 THEN
                l_errors := sql%bulk_exceptions.count;
                for i in 1 .. l_errors
                loop
                    l_errno := sql%bulk_exceptions(i).error_code;
                    L_MSG   := SQLERRM(-L_ERRNO);
                    L_IDX   := SQL%BULK_EXCEPTIONS(i).ERROR_INDEX;
                   INSERT INTO XXHA_TMP_TBL_ERR(incident_id) values(v_rec_data_new(l_idx).incident_id);
                END LOOP;
              END IF;
        end;
        exit when c%notfound;
    end loop;
    close c;
END;
/*ln_record_count NUMBER := 0;
cursor cur_get_pm_data is
SELECT AL2.INCIDENT_ID,
  AL2.INCIDENT_NUMBER,
  AL2.INCIDENT_DATE,
  AL2.INCIDENT_OCCURRED_DATE Reported_Date,
  AL3.PARTY_NAME Customer_Name,
  AL3.PARTY_NUMBER,
  AL4.ACCOUNT_NUMBER,
  AL5.INSTANCE_ID,
  AL5.INSTANCE_NUMBER,
  AL5.SERIAL_NUMBER,
  AL6.SEGMENT1 Inventory_Item,
  AL6.DESCRIPTION Inventory_Item_Description,
  AL6.INVENTORY_ITEM_ID,
  AL7.MACHINE_GROUPING,
  AL5.EXTERNAL_REFERENCE,
--  AL1.INCIDENT_OWNER,
--  AL1.INCIDENT_STATUS_MEANING,
--  AL1.SEVERITY,
--  AL1.INCIDENT_TYPE,
  al35.resource_name incident_owner,
  -- 2.0 IPadela
  --al36.meaning incident_status_meaning,
  al36.name incident_status_meaning,
  --end
  al37.name severity,
  al38.name incident_type,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS1, 'HZ_PARTY_SITE', AL15.ADDRESS1, 'INTERNAL_SITE', AL16.ADDRESS_LINE_1, 'INVENTORY', AL16.ADDRESS_LINE_1, 'VENDOR_SITE', AL17.ADDRESS_LINE1, NULL ) Install_At_Address1,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS2, 'HZ_PARTY_SITE', AL15.ADDRESS2, 'INTERNAL_SITE', AL16.ADDRESS_LINE_2, 'INVENTORY', AL16.ADDRESS_LINE_2, 'VENDOR_SITE', AL17.ADDRESS_LINE2, NULL ) Install_At_Address2,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS3, 'HZ_PARTY_SITE', AL15.ADDRESS3, 'INTERNAL_SITE', AL16.ADDRESS_LINE_3, 'INVENTORY', AL16.ADDRESS_LINE_3, 'VENDOR_SITE', AL17.ADDRESS_LINE3, NULL ) Install_At_Address3,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.ADDRESS4, 'HZ_PARTY_SITE', AL15.ADDRESS4, 'INTERNAL_SITE', NULL, 'INVENTORY', NULL, 'VENDOR_SITE', NULL, NULL ) Install_At_Address4,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.CITY, 'HZ_PARTY_SITE', AL15.CITY, 'INTERNAL_SITE', AL16.TOWN_OR_CITY, 'INVENTORY', AL16.TOWN_OR_CITY, 'VENDOR_SITE', AL17.CITY, NULL ) Install_At_CITY,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.STATE, 'HZ_PARTY_SITE', AL15.STATE, 'INTERNAL_SITE', NULL, 'INVENTORY', NULL, 'VENDOR_SITE', AL17.STATE, NULL ) Install_At_STATE,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.POSTAL_CODE, 'HZ_PARTY_SITE', AL15.POSTAL_CODE, 'INTERNAL_SITE', AL16.POSTAL_CODE, 'INVENTORY', AL16.POSTAL_CODE, 'VENDOR_SITE', AL17.ZIP, NULL ) Install_At_POSTAL_CODE,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL14.PARTY_SITE_NUMBER, 'HZ_PARTY_SITE', AL13.PARTY_SITE_NUMBER, NULL ) Install_At_SITE_NUMBER,
  DECODE ( AL2.INCIDENT_LOCATION_TYPE, 'HZ_LOCATION', AL12.COUNTRY, 'HZ_PARTY_SITE', AL15.COUNTRY, 'INTERNAL_SITE', AL16.COUNTRY, 'INVENTORY', AL16.COUNTRY, 'VENDOR_SITE', AL17.COUNTRY, NULL ) Install_At_COUNTRY,
  AL8.ADDRESS1 Bill_To_Address1,
  AL8.ADDRESS2 Bill_To_Address2,
  AL8.ADDRESS3 Bill_To_Address3,
  AL8.ADDRESS4 Bill_To_Address4,
  AL8.CITY Bill_To_CITY,
  AL8.STATE Bill_To_STATE,
  AL8.POSTAL_CODE Bill_To_POSTAL_CODE,
  AL8.COUNTRY Bill_To_COUNTRY,
  AL9.PARTY_SITE_NUMBER Bill_To_SITE_NUMBER,
  AL11.ADDRESS1 Ship_To_Address1,
  AL11.ADDRESS2 Ship_To_Address2,
  AL11.ADDRESS3 Ship_To_Address3,
  AL11.ADDRESS4 Ship_To_Address4,
  AL11.CITY Ship_To_CITY,
  AL11.STATE Ship_To_STATE,
  AL11.POSTAL_CODE Ship_To_POSTAL_CODE,
  AL11.COUNTRY Ship_To_COUNTRY,
  AL10.PARTY_SITE_NUMBER Ship_To_SITE_NUMBER,
  AL2.CONTRACT_NUMBER,
  al40.contract_number_modifier,
  AL19.SERVICE_NAME CONTRACT_TYPE,
  AL2.INCIDENT_ATTRIBUTE_1 Hospital_Dealer_Location,
  AL2.INCIDENT_CONTEXT PIR_Review,
  AL2.INCIDENT_ATTRIBUTE_2 Process_Phase,
  AL2.INCIDENT_ATTRIBUTE_3 Involves_Death,
  AL2.INCIDENT_ATTRIBUTE_4 Involves_Injury,
  AL2.INCIDENT_ATTRIBUTE_5 Risk_Complaint,
  AL2.INCIDENT_ATTRIBUTE_6 Extended_hospitalization,
  AL2.SUMMARY Problem_Summary,
  AL2.PROBLEM_CODE,
  AL20.MEANING Problem_Code_Meaning,
  AL20.DESCRIPTION Problem_Code_Description,
  AL2.RESOLUTION_SUMMARY Resolution_Summary,
  AL2.RESOLUTION_CODE,
  AL21.MEANING Resolution_Code_Meaning,
  AL21.DESCRIPTION Resolution_Code_Description,
  al2.close_date,

  --3.0 IPadela
  DECODE ( al38.name, 'Depot Repair',AL34.Task_id, AL24.TASK_ID) TASK_ID,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_NUMBER, AL24.TASK_NUMBER) TASK_NUMBER,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_STATUS, AL24.TASK_STATUS) TASK_STATUS,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_PRIORITY, AL24.TASK_PRIORITY) TASK_PRIORITY,
  DECODE ( al38.name, 'Depot Repair',AL34.TASK_NAME, AL24.TASK_NAME) TASK_NAME,
  DECODE ( al38.name, 'Depot Repair',AL34.OWNER_TYPE, AL24.OWNER_TYPE) OWNER_TYPE,
  DECODE ( al38.name, 'Depot Repair',AL34.OWNER, AL24.OWNER) OWNER,
  DECODE ( al38.name, 'Depot Repair',AL42.RESOURCE_TYPE_NAME, AL25.RESOURCE_TYPE_NAME) task_assignee_type,
  DECODE ( al38.name, 'Depot Repair',AL42.TASK_ASSIGNMENT_ID, AL25.TASK_ASSIGNMENT_ID) TASK_ASSIGNMENT_ID,
  DECODE ( al38.name, 'Depot Repair',AL42.RESOURCE_NAME, AL25.RESOURCE_NAME) RESOURCE_NAME,
  --end

  AL26.USER_NAME logged_by,
  AL24.PLANNED_START_DATE,
  AL24.PLANNED_END_DATE,
  AL24.SCHEDULED_START_DATE,
  al24.scheduled_end_date,
  --AL24.ACTUAL_START_DATE,
  --3.0 IPadela
  decode ( al38.name, 'Depot Repair', al34.actual_start_date, al24.actual_start_date ) actual_start_date,
  --end
--  DECODE ( AL1.INCIDENT_TYPE, 'Depot Repair', al34.actual_end_date, al24.actual_end_date ) actual_end_date,
  DECODE ( al38.name, 'Depot Repair', al34.actual_end_date, al24.actual_end_date ) actual_end_date,
--  AL24.ACTUAL_END_DATE,
--  AL30.labor_hours,
--  AL30.expense_value,
--  AL30.expense_currency,
  --AL25.DEBRIEF_NUMBER,
  --AL25.debrief_header_id,
  --al30.debrief_line_id,
  --3.0 IPadela
  DECODE ( al38.name, 'Depot Repair',AL42.DEBRIEF_NUMBER, AL25.DEBRIEF_NUMBER) DEBRIEF_NUMBER,
  DECODE ( al38.name, 'Depot Repair',AL42.debrief_header_id, AL25.debrief_header_id) debrief_header_id,
  decode ( al38.name, 'Depot Repair',al44.debrief_line_id, al30.debrief_line_id) debrief_line_id,
  --end
  AL27.TOTAL_SUBMITTED,
  AL2.CREATION_DATE,
  AL2.LAST_UPDATE_DATE,
  al29.user_name modified_by,
  --AL24.TASK_TYPE,
  --AL28.PROCESSED_FLAG Debrief_Status,
  --3.0 IPadela
  DECODE ( al38.name, 'Depot Repair', AL34.TASK_TYPE, AL24.TASK_TYPE) TASK_TYPE,
  decode ( al38.name, 'Depot Repair', al43.processed_flag, al28.processed_flag) debrief_status,
  --end
  AL31.person_first_name,
  AL31.person_last_name,
  al31.contact_phone_email,
  --al35.billing_type,
  --3.0 IPadela
  decode ( al38.name, 'Depot Repair', al45.billing_type, al35.billing_type) billing_type,
  --end
  al39.organization_id operating_unit_id,
  al39.name operating_unit,
  al41.resource_name incident_group
FROM --HAEMO.XXHA_QD_QUALITY_NOTE_DATA AL1,
  APPS.CS_INCIDENTS_ALL_VL AL2,
  APPS.HZ_PARTIES AL3,
  APPS.HZ_CUST_ACCOUNTS AL4,
  APPS.CSI_ITEM_INSTANCES AL5,
  APPS.MTL_SYSTEM_ITEMS_B AL6,
  HAEMO.XXHA_QD_MACHINE_GROUPS AL7,
  APPS.HZ_LOCATIONS AL8,
  APPS.HZ_PARTY_SITES AL9,
  APPS.HZ_PARTY_SITES AL10,
  APPS.HZ_LOCATIONS AL11,
  APPS.HZ_LOCATIONS AL12,
  APPS.HZ_PARTY_SITES AL13,
  APPS.HZ_PARTY_SITES AL14,
  APPS.HZ_LOCATIONS AL15,
  APPS.HR_LOCATIONS_ALL AL16,
 --- APPS.PO_VENDOR_SITES_ALL AL17,---11i code modified
  APPS.AP_SUPPLIER_SITES_ALL AL17,---R12 Remediated
--  APPS.OKS_AUTH_LINES_V AL18,
  APPS.OKS_LINE_DETAILS_V AL19,
  APPS.CS_LOOKUPS AL20,
  APPS.CS_LOOKUPS AL21,
  APPS.CS_INCIDENT_LINKS AL22,
  APPS.CS_SR_TASKS_V AL24,
  APPS.CSF_DEBRIEF_TASKS_V AL25,
  APPS.FND_USER AL26,
  APPS.CS_CHARGE_DETAILS_V AL27,
  APPS.CSF_DEBRIEF_HEADERS AL28,
  APPS.FND_USER AL29,
  APPS.CSF_DEBRIEF_LINES AL30,
  APPS.CS_TXN_BILLING_TYPES AL35,
--  (SELECT D29AL1.DEBRIEF_HEADER_ID AS debrief_header_id,
--    SUM( D29AL1.QUANTITY )         AS total_labor_hours,
--    SUM( D29AL1.EXPENSE_AMOUNT )   AS total_expense_value,
--    MAX( D29AL1.CURRENCY_CODE )    AS expense_currency
--	d29al1.quantity as labor_hours,
--	d29al1.expense_amount as expense_value,
--	d29al1.currency_code as expense_currency,
--	d29al2.billing_type as debrief_type
--  FROM APPS.CSF_DEBRIEF_LINES D29AL1,
--    APPS.CS_TXN_BILLING_TYPES D29AL2
--  WHERE (D29AL1.TRANSACTION_TYPE_ID=D29AL2.TRANSACTION_TYPE_ID)
--  AND (D29AL2.BILLING_TYPE        <>'M')
--  GROUP BY D29AL1.DEBRIEF_HEADER_ID
--  ) AL30,
  (SELECT D30AL1.INCIDENT_ID                                                                                                                                AS incident_id,
    DECODE ( D30AL1.CONTACT_TYPE, 'PERSON', D30AL2.PERSON_FIRST_NAME, 'PARTY_RELATIONSHIP', D30AL4.PERSON_FIRST_NAME, 'EMPLOYEE', D30AL5.FIRST_NAME, NULL ) AS person_first_name,
    DECODE ( D30AL1.CONTACT_TYPE, 'PERSON', D30AL2.PERSON_LAST_NAME, 'PARTY_RELATIONSHIP', D30AL4.PERSON_LAST_NAME, 'EMPLOYEE', D30AL5.LAST_NAME, NULL )    AS person_last_name,
 D30AL1.PRIMARY_FLAG                                                                                                                                     AS primary_flag,
    D30AL1.CONTACT_TYPE                                                                                                                                     AS contact_type,
 D30AL1.CONTACT_POINT_TYPE                                                                                                                               AS contact_point_type,
 DECODE( D30AL1.CONTACT_TYPE, 'EMPLOYEE', D30AL7.PHONE_NUMBER, DECODE(D30AL1.CONTACT_POINT_TYPE , 'EMAIL', D30AL6.EMAIL_ADDRESS, 'WEB', D30AL6.EMAIL_ADDRESS, D30AL6.PHONE_COUNTRY_CODE
    || DECODE(D30AL6.PHONE_AREA_CODE , '' , '' , '-'
    || D30AL6.PHONE_AREA_CODE
    || '-' )
    || D30AL6.PHONE_NUMBER) ) AS contact_phone_email
  FROM APPS.CS_HZ_SR_CONTACT_POINTS D30AL1,
    APPS.HZ_PARTIES D30AL2,
    APPS.HZ_RELATIONSHIPS D30AL3,
    APPS.HZ_PARTIES D30AL4,
    APPS.PER_PEOPLE_X D30AL5,
    APPS.HZ_CONTACT_POINTS D30AL6,
    APPS.PER_PHONES D30AL7
  WHERE ( D30AL1.PARTY_ID        = D30AL3.PARTY_ID (+)
  AND D30AL2.PARTY_ID (+)        = D30AL1.PARTY_ID
  AND D30AL3.SUBJECT_ID          = D30AL4.PARTY_ID (+)
  AND D30AL1.PARTY_ID            = D30AL5.PERSON_ID (+)
  AND D30AL6.CONTACT_POINT_ID (+)= D30AL1.CONTACT_POINT_ID
  AND D30AL5.PERSON_ID           = D30AL7.PARENT_ID (+))
  AND ((D30AL1.PRIMARY_FLAG      ='Y'
  AND D30AL3.DIRECTIONAL_FLAG(+) ='F'
  AND D30AL7.PHONE_TYPE(+)       ='W1'))
  ) AL31,
  apps.ahl_unit_effectivities_b al32,
  apps.csd_repairs al33,
  apps.csd_repair_tasks_v al34,
  apps.jtf_rs_all_resources_vl al35,
  -- 2.0 IPadela
  --apps.cs_lookups al36,
  apps.cs_incident_statuses al36,
  --end
  apps.cs_incident_severities_vl al37,
  apps.cs_incident_types_vl al38,
  apps.hr_operating_units al39,
  apps.oks_auth_headers_v al40,
  apps.cs_sr_owners_v al41
  --3.0 IPadela
  ,APPS.CSF_DEBRIEF_TASKS_V AL42,
  APPS.CSF_DEBRIEF_HEADERS AL43,
  APPS.CSF_DEBRIEF_LINES AL44,
  apps.cs_txn_billing_types al45
  --end
WHERE ( AL2.CUSTOMER_ID          = AL3.PARTY_ID (+)
AND AL2.ACCOUNT_ID               = AL4.CUST_ACCOUNT_ID (+)
AND AL2.CUSTOMER_PRODUCT_ID      = AL5.INSTANCE_ID (+)
AND AL2.INVENTORY_ITEM_ID        = AL6.INVENTORY_ITEM_ID (+)
AND AL2.INV_ORGANIZATION_ID      = AL6.ORGANIZATION_ID (+)
AND AL8.LOCATION_ID (+)          = AL9.LOCATION_ID
AND AL2.BILL_TO_SITE_ID          = AL9.PARTY_SITE_ID (+)
AND AL2.SHIP_TO_SITE_ID          = AL10.PARTY_SITE_ID (+)
AND AL10.LOCATION_ID             = AL11.LOCATION_ID (+)
AND AL2.INCIDENT_LOCATION_ID     = AL12.LOCATION_ID (+)
AND AL2.INCIDENT_LOCATION_ID     = AL13.PARTY_SITE_ID (+)
AND AL12.LOCATION_ID             = AL14.LOCATION_ID (+)
AND AL15.LOCATION_ID (+)         = AL13.LOCATION_ID
AND AL2.INCIDENT_LOCATION_ID     = AL16.LOCATION_ID (+)
AND AL2.INCIDENT_LOCATION_ID     = AL17.VENDOR_SITE_ID (+)
--AND AL2.CONTRACT_ID              = AL18.CHR_ID (+)
--AND AL18.ID                      = AL19.LINE_ID (+)
and al2.contract_service_id      = al19.line_id(+)
AND AL2.PROBLEM_CODE             = AL20.LOOKUP_CODE (+)
AND AL21.LOOKUP_CODE (+)         = AL2.RESOLUTION_CODE
AND AL2.INCIDENT_ID              = AL24.SOURCE_OBJECT_ID (+)
AND AL2.INCIDENT_NUMBER          = AL24.SOURCE_OBJECT_NAME (+)
AND AL24.TASK_ID                 = AL25.TASK_ID (+)
AND AL2.INCIDENT_ID              = AL27.INCIDENT_ID (+)
AND AL31.incident_id (+)         = AL2.INCIDENT_ID
--AND AL1.INCIDENT_ID              =AL2.INCIDENT_ID
AND AL6.SEGMENT1                 =AL7.MACHINE_ITEM_NUMBER(+)
AND AL22.SUBJECT_ID              =AL2.INCIDENT_ID
AND AL2.CREATED_BY               =AL26.USER_ID
AND AL25.DEBRIEF_HEADER_ID       =AL28.DEBRIEF_HEADER_ID(+)
AND AL2.LAST_UPDATED_BY          =AL29.USER_ID
AND al25.debrief_header_id = al30.debrief_header_id(+)
and al30.transaction_type_id = al35.transaction_type_id(+)
and al22.object_id = al32.unit_effectivity_id(+)
and al2.incident_id = al33.incident_id(+)
and al33.repair_line_id = al34.source_object_id(+)
and al33.repair_number = al34.source_object_name(+)
and al2.incident_owner_id = al35.resource_id(+)
--2.0 IPadela
--and al2.status_flag = al36.lookup_code
and al2.incident_status_id = al36.incident_status_id
--end
and al2.incident_severity_id = al37.incident_severity_id
AND al2.incident_type_id = al38.incident_type_id
and al2.org_id = al39.organization_id
and al2.contract_id = al40.id(+)
and al2.owner_group_id = al41.resource_id(+)
)
AND AL22.SUBJECT_TYPE            ='SR'
AND AL22.LINK_TYPE_ID            =6
AND AL22.OBJECT_TYPE             ='AHL_UMP_EFF'
AND AL27.INTERFACE_TO_OE_FLAG(+) ='Y'
--2.0 IPadela
--and (al36.lookup_type = 'CSZ_SRCH_STATUS_FLAG_CODE' OR al36.lookup_type IS NULL)
-- end
--3.0 IPadela
AND AL34.TASK_ID                 = AL42.TASK_ID (+)
AND AL42.DEBRIEF_HEADER_ID       =AL43.DEBRIEF_HEADER_ID(+)
AND al42.debrief_header_id = al44.debrief_header_id(+)
and al44.transaction_type_id = al45.transaction_type_id(+)
--end
--and AL2.CLOSE_DATE >= ADD_MONTHS(SYSDATE, -12)
--and AL2.INCIDENT_NUMBER = '485892'
;
begin
execute immediate('alter session set "_optimizer_cost_based_transformation"=off');
execute immediate 'truncate table haemo.XXHA_PM_FIELD_SERVICE_DATA';
--  execute immediate 'delete from haemo.XXHA_PM_FIELD_SERVICE_DATA where close_date >= add_months(sysdate, -12)';
ln_record_count := 0;
 FOR get_pm_data in cur_get_pm_data
    LOOP
      BEGIN
      	insert into haemo.XXHA_PM_FIELD_SERVICE_DATA(
			INCIDENT_ID,
			INCIDENT_NUMBER,
			INCIDENT_DATE,
			REPORTED_DATE,
			CUSTOMER_NAME,
			PARTY_NUMBER,
			ACCOUNT_NUMBER,
			INSTANCE_ID,
			INSTANCE_NUMBER,
			SERIAL_NUMBER,
			INVENTORY_ITEM,
			INVENTORY_ITEM_DESCRIPTION,
			INVENTORY_ITEM_ID,
			MACHINE_GROUPING,
			EXTERNAL_REFERENCE,
			INCIDENT_OWNER,
			INCIDENT_STATUS_MEANING,
			SEVERITY,
			INCIDENT_TYPE,
			INSTALL_AT_ADDRESS1,
			INSTALL_AT_ADDRESS2,
			INSTALL_AT_ADDRESS3,
			INSTALL_AT_ADDRESS4,
			INSTALL_AT_CITY,
			INSTALL_AT_STATE,
			INSTALL_AT_POSTAL_CODE,
			INSTALL_AT_SITE_NUMBER,
			INSTALL_AT_COUNTRY,
			BILL_TO_ADDRESS1,
			BILL_TO_ADDRESS2,
			BILL_TO_ADDRESS3,
			BILL_TO_ADDRESS4,
			BILL_TO_CITY,
			BILL_TO_STATE,
			BILL_TO_POSTAL_CODE,
			BILL_TO_COUNTRY,
			BILL_TO_SITE_NUMBER,
			SHIP_TO_ADDRESS1,
			SHIP_TO_ADDRESS2,
			SHIP_TO_ADDRESS3,
			SHIP_TO_ADDRESS4,
			SHIP_TO_CITY,
			SHIP_TO_STATE,
			SHIP_TO_POSTAL_CODE,
			SHIP_TO_COUNTRY,
			SHIP_TO_SITE_NUMBER,
			CONTRACT_NUMBER,
			CONTRACT_NUMBER_MODIFIER,
			CONTRACT_TYPE,
			HOSPITAL_DEALER_LOCATION,
			PIR_REVIEW,
			PROCESS_PHASE,
			INVOLVES_DEATH,
			INVOLVES_INJURY,
			RISK_COMPLAINT,
			EXTENDED_HOSPITALIZATION,
			PROBLEM_SUMMARY,
			PROBLEM_CODE,
			PROBLEM_CODE_MEANING,
			PROBLEM_CODE_DESCRIPTION,
			RESOLUTION_SUMMARY,
			RESOLUTION_CODE,
			RESOLUTION_CODE_MEANING,
			RESOLUTION_CODE_DESCRIPTION,
			CLOSE_DATE,
			TASK_ID,
			TASK_NUMBER,
			TASK_STATUS,
			TASK_PRIORITY,
			TASK_NAME,
			OWNER_TYPE,
			OWNER,
			TASK_ASSIGNEE_TYPE,
			TASK_ASSIGNMENT_ID,
			RESOURCE_NAME,
			LOGGED_BY,
			PLANNED_START_DATE,
			PLANNED_END_DATE,
			SCHEDULED_START_DATE,
			SCHEDULED_END_DATE,
			ACTUAL_START_DATE,
			ACTUAL_END_DATE,
--			LABOR_HOURS,
--			EXPENSE_VALUE,
--			EXPENSE_CURRENCY,
			DEBRIEF_NUMBER,
			DEBRIEF_HEADER_ID,
			DEBRIEF_LINE_ID,
			TOTAL_SUBMITTED,
			CREATION_DATE,
			LAST_UPDATE_DATE,
			MODIFIED_BY,
			TASK_TYPE,
			DEBRIEF_STATUS,
			PERSON_FIRST_NAME,
			PERSON_LAST_NAME,
			CONTACT_PHONE_EMAIL,
			BILLING_TYPE,
			OPERATING_UNIT_ID,
			OPERATING_UNIT,
			INCIDENT_GROUP
			)
			values(
			get_pm_data.incident_id,
			get_pm_data.incident_number,
			get_pm_data.incident_date,
			get_pm_data.reported_date,
			get_pm_data.customer_name,
			get_pm_data.party_number,
			get_pm_data.account_number,
			get_pm_data.instance_id,
			get_pm_data.instance_number,
			get_pm_data.serial_number,
			get_pm_data.inventory_item,
			get_pm_data.inventory_item_description,
			get_pm_data.inventory_item_id,
			get_pm_data.machine_grouping,
			get_pm_data.external_reference,
			get_pm_data.incident_owner,
			get_pm_data.incident_status_meaning,
			get_pm_data.severity,
			get_pm_data.incident_type,
			get_pm_data.install_at_address1,
			get_pm_data.install_at_address2,
			get_pm_data.install_at_address3,
			get_pm_data.install_at_address4,
			get_pm_data.install_at_city,
			get_pm_data.install_at_state,
			get_pm_data.install_at_postal_code,
			get_pm_data.install_at_site_number,
			get_pm_data.install_at_country,
			get_pm_data.bill_to_address1,
			get_pm_data.bill_to_address2,
			get_pm_data.bill_to_address3,
			get_pm_data.bill_to_address4,
			get_pm_data.bill_to_city,
			get_pm_data.bill_to_state,
			get_pm_data.bill_to_postal_code,
			get_pm_data.bill_to_country,
			get_pm_data.bill_to_site_number,
			get_pm_data.ship_to_address1,
			get_pm_data.ship_to_address2,
			get_pm_data.ship_to_address3,
			get_pm_data.ship_to_address4,
			get_pm_data.ship_to_city,
			get_pm_data.ship_to_state,
			get_pm_data.ship_to_postal_code,
			get_pm_data.ship_to_country,
			get_pm_data.ship_to_site_number,
			get_pm_data.contract_number,
			get_pm_data.contract_number_modifier,
			get_pm_data.contract_type,
			get_pm_data.hospital_dealer_location,
			get_pm_data.pir_review,
			get_pm_data.process_phase,
			get_pm_data.involves_death,
			get_pm_data.involves_injury,
			get_pm_data.risk_complaint,
			get_pm_data.extended_hospitalization,
			get_pm_data.problem_summary,
			get_pm_data.problem_code,
			get_pm_data.problem_code_meaning,
			get_pm_data.problem_code_description,
			get_pm_data.resolution_summary,
			get_pm_data.resolution_code,
			get_pm_data.resolution_code_meaning,
			get_pm_data.resolution_code_description,
			get_pm_data.close_date,
			get_pm_data.task_id,
			get_pm_data.task_number,
			get_pm_data.task_status,
			get_pm_data.task_priority,
			get_pm_data.task_name,
			get_pm_data.owner_type,
			get_pm_data.owner,
			get_pm_data.task_assignee_type,
			get_pm_data.task_assignment_id,
			get_pm_data.resource_name,
			get_pm_data.logged_by,
			get_pm_data.planned_start_date,
			get_pm_data.planned_end_date,
			get_pm_data.scheduled_start_date,
			get_pm_data.scheduled_end_date,
			get_pm_data.actual_start_date,
			get_pm_data.actual_end_date,
--			get_pm_data.labor_hours,
--			get_pm_data.expense_value,
--			get_pm_data.expense_currency,
			get_pm_data.debrief_number,
			get_pm_data.debrief_header_id,
			get_pm_data.debrief_line_id,
			get_pm_data.total_submitted,
			get_pm_data.creation_date,
			get_pm_data.last_update_date,
			get_pm_data.modified_by,
			get_pm_data.task_type,
			get_pm_data.debrief_status,
			get_pm_data.person_first_name,
			get_pm_data.person_last_name,
			get_pm_data.contact_phone_email,
			get_pm_data.billing_type,
			get_pm_data.operating_unit_id,
			get_pm_data.operating_unit,
			get_pm_data.incident_group
			);
	  EXCEPTION
	  WHEN OTHERS THEN
		FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XXHA_PM_FIELD_SERVICE_DATA for SR ' || get_pm_data.incident_number || ': ' || SQLERRM);
	  END;
	ln_record_count := ln_record_count + 1;
END LOOP;
  COMMIT;
  FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XXHA_PM_FIELD_SERVICE_DATA '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));
end; -- end BEGIN*/
END XXHA_PM_POPULATE_DATA_PKG;
/
