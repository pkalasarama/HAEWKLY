CREATE OR REPLACE package XXHA_INV_CONV_ITM_P2_API
-- +===========================================================================+
-- | Name        : XXHA_INV_CONV_ITM_P2_PK                                     |
-- | Purpose     : Support the conversion of Item business object into EBS.    |
-- |                                                                           |
-- | Description : For this conversion, an object includes the item, item      |
-- |               assignments at organizations (including master [MST]),      |
-- |               item revisions and item category (primary classification    |
-- |               on MST item only).                                          |
-- |               Data is provided in 3 staging tables:                       |
-- |                  XXHA_ITEMS_CLEANED_STG                                   |
-- |                  XXHA_ITEM_INVORGS_STG                                    |
-- |                  XXHA_ITEM_REVISIONS_STG                                  |
-- |               Staged data is validated.  If all data is succcessfully     |
-- |               validated, the item objects are then moved to the open      |
-- |               interface tables.  If a single failure is detected, no      |
-- |               item objects are interfaced and an error report is launched |
-- |               as a separate concurrent request.                           |
-- |                                                                           |
-- |               Note: All or nothing approach!!                             |
-- |                                                                           |
-- | Comment     : This package interfaces item objects, it does not launch    |
-- |               standard Import Items program.  This must be done manually. |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20080818  1.0  OCS       Initial version                                  |
-- +===========================================================================+
AS
      -- Global Variables Declaration

      gn_record_number         xxha_common_errors.record_number%TYPE;                                          --Record_number of staging table
      gc_record_identifier     xxha_common_errors.record_identifier%TYPE;                                      --Record identifier of staging table
      gc_error_code            xxha_common_errors.error_code%TYPE;                                             --Error_code insert in common error table
      gc_error_msg             xxha_common_errors.error_msg%TYPE;                                              --Error_msg  insert in common error table
      gc_comments              xxha_common_errors.comments%TYPE;                                               --Comments   insert in common error table
      gc_attribute1            xxha_common_errors.attribute1%TYPE;                                             --Attribute1 insert in common error table
      gc_attribute2            xxha_common_errors.attribute2%TYPE;                                             --Attribute2 insert in common error table
      gc_attribute3            xxha_common_errors.attribute3%TYPE;                                             --Attribute3 insert in common error table
      gc_attribute4            xxha_common_errors.attribute4%TYPE;                                             --Attribute4 insert in common error table
      gc_attribute5            xxha_common_errors.attribute5%TYPE;                                             --Attribute5 insert in common error table
      gc_table_name            xxha_common_errors.table_name%TYPE;                                             --Variable to get Staging Table Name
      gc_status                VARCHAR2(2);                                                                    --Variable to get status flag of data insertion in common error table
      gc_conc_name             fnd_concurrent_programs.concurrent_program_name%TYPE :='XXHA_ITEM_CONV_P2';        --Concurrent program name to delete the records from common error table

gc_error_logged  varchar2(1);
gc_invorg_only_flag  varchar2(1);
gc_table_ITM  varchar2(30) := 'XXHA_ITEMS_CLEANED_STG';
gc_table_ORGITM  varchar2(30) := 'XXHA_ITEM_INVORGS_STG';
gc_table_ITMREV  varchar2(30) := 'XXHA_ITEM_REVISIONS_STG';
gc_valtype_SETUP  varchar2(30) := 'SETUP';
gc_valtype_DUPLICATE  varchar2(30) := 'DUPLICATE';
gc_valtype_ITM  varchar2(30) := 'ITM';
gc_valtype_ORGITM  varchar2(30) := 'ORGITM';
gc_valtype_ITMREV  varchar2(30) := 'ITMREV';

gn_user_id  fnd_user.user_id%type := fnd_global.user_id;
gc_material_sub_element  bom_resources.resource_code%type := 'Material';  -- Material Sub-Element
gc_debug_flag  varchar2(1);  --Debug_flag for display debug
gc_category_set_name  mtl_category_sets_tl.category_set_name%type :='Inventory';  --Default Category Set name
gn_process_flag  mtl_system_items_interface.process_flag%type := 1;  -- Default process_flag
gc_master_org  mtl_parameters.organization_code%type :='MST';  -- Master Organization Name
--      gc_template_d            mtl_item_templates.template_name%TYPE                :='Disposable Finished Goods'; --Template Name for Template Identifier D
--      gc_template_s            mtl_item_templates.template_name%TYPE                :='Parts - Non returnable';--Template Name for Template Identifier S
--      gc_template_n            mtl_item_templates.template_name%TYPE                :='Non-Inventory';         --Template Name for Template Identifier E
--      gc_template_e            mtl_item_templates.template_name%TYPE                :='Equipment Finished Goods';--Template Name for Template Identifier N
--      gc_template_r            mtl_item_templates.template_name%TYPE                :='Parts - Returnable';    --Template Name for Template Identifier R
      gc_language_code         fnd_languages.language_code%TYPE                     :='US';                    --Language_code
      gc_log_msg               VARCHAR2(1000);                                                                 --Log_msg to display msgs
      gc_error_report          VARCHAR2(1)                                          := 'N';                    --Error_report launch if its <>'N'
      gn_request_id            xxha_common_errors.request_id%TYPE                   := fnd_global.conc_request_id;--Request Id of running concurrent Program
      gc_program_name          VARCHAR2(50)                                         :='Item Conversion PreValidation';       --Program Name In parameter for launch_error_prc procedure
      gc_rec_identifier        VARCHAR2(50)                                         :='Item Number';           --Record identifier In parameter for launch_error_prc procedure
      gc_auto_lot_alpha_prefix mtl_system_items_interface.auto_lot_alpha_prefix%TYPE:='1';                     --Variable for auto_lot_alpha_prefix
      gc_start_auto_lot_number mtl_system_items_interface.start_auto_lot_number%TYPE:='1';                     --Variable for start_auto_lot_number
      gc_starting_revision     mtl_parameters.starting_revision%TYPE;                                          --Variable to get staring revision against the Inventory Orgs

      --Start of changes V1.1
gc_set_proc_id_mst       mtl_system_items_interface.set_process_id%type       := 1;                       --Variable to get set process id for Master Inventory Org
gc_set_proc_id_child     mtl_system_items_interface.set_process_id%type       := 2;                       --Variable to get set process id for Child Inventory Orgs
      --End of changes V1.1
      --Start of Changes V1.2
       gc_org_assigments_flag   VARCHAR2(10);
      --End of Changes V1.2

   ------------------------------------------------------------
   -- Global record counters
   ------------------------------------------------------------
   gn_cnt_dupitm  number := 0;
   gn_cnt_duporgitm  number := 0;
   gn_cnt_dupitmrev  number := 0;
   gn_cnt_read_itm  number := 0;
   gn_cnt_valid_itm  number := 0;
   gn_cnt_invalid_itm  number := 0;
   gn_cnt_read_oi  number := 0;
   gn_cnt_valid_oi  number := 0;
   gn_cnt_invalid_oi  number := 0;
   gn_cnt_read_rv  number := 0;
   gn_cnt_valid_rv  number := 0;
   gn_cnt_invalid_rv  number := 0;


gd_now  date;
gc_interface_error  varchar2(1);

gr_icSetup  xxha_inv_common_utilities_pk.gr_icSetupRec;

type g_itemStatusRec is record (
     code  mtl_item_status.inventory_item_status_code%type
    ,description  mtl_item_status.description%type
    );
type g_itemStatusTabType is table of g_itemStatusRec index by binary_integer;

gt_itemStatuses  xxha_inv_common_utilities_pk.g_itemStatusTabType;
g_item_status_list  varchar2(2000);

Procedure issue_ohb_serial
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );

Procedure issue_ohb_non_serial
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );

PROCEDURE pre_processing_items
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_debug  in  varchar2
        ,p_purge_data  in  varchar2
        ,p_commit_flag  in  varchar2
        );

PROCEDURE processing_items
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_commit_flag  in  varchar2
		,p_validate_flag in varchar2
		,p_convert_items in varchar2
		,p_update_inv_category in varchar2
		,p_update_po_category in varchar2
		,p_process_item_rev in varchar2
		,p_force_commit in varchar2
        );
Procedure Update_US_PUR_Tax
(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );
Procedure Update_Serial_Numbers
(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );
Procedure Update_Lot_Prefix
(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );
PROCEDURE upd_stg_tables
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_stmt1 in varchar2
		,p_table_name  in  varchar2
		,p_stmt2 in varchar2);

PROCEDURE issue_ohb_non_ser_ser_control
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );

end XXHA_INV_CONV_ITM_P2_API;

/


CREATE OR REPLACE package body      XXHA_INV_CONV_ITM_P2_API
as
-- +===========================================================================+
-- | Name        : XXHA_INV_CONV_ITM_P2_PK                                     |
-- | Purpose     : Support the conversion of Item business object into EBS.    |
-- |                                                                           |
-- | Description : For this conversion, an object includes the item, item      |
-- |               assignments at organizations (including master [MST]),      |
-- |               item revisions and item category (primary classification    |
-- |               of MST item.                                                |
-- |               Data is provided in 3 staging tables:                       |
-- |                  XXHA_ITEMS_CLEANED_STG                                   |
-- |                  XXHA_ITEM_INVORGS_STG                                    |
-- |                  XXHA_ITEM_REVISIONS_STG                                  |
-- |               Staged data is validated.  If all data is succcessfully     |
-- |               validated, the item objects are processed 				   |
-- |                                                                           |
-- |                                                                           |
-- | Comment     : This package interfaces item objects, it does not launch    |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20080915  1.0  Palash Kundu      Initial version                          |
-- | 20090215  1.1  Palash Kundu      Made changes as per Item Testing         |
-- | 20090415  1.1  Palash Kundu      Made changes as per ECO Testing          |
-- | 20090501  1.2  Palash Kundu      Changed code to accomodate Fastpack DFF  |
-- | 20090615  1.3  Palash Kundu      Changed code to accomodate Non Rev Org Assignment  |
-- +===========================================================================+

   ------------------------------------------------------------
   -- Cursor for logged errors
   ------------------------------------------------------------
   cursor c_err (
           q_request_id  xxha_common_errors.request_id%type
          ,q_table_name  xxha_common_errors.table_name%type
          ,q_conc_name  xxha_common_errors.attribute4%type
          ,q_valtype  xxha_common_errors.attribute5%type
          ) is
     select  ce.error_code
            ,ce.error_msg
            ,count(1)  cnt
     from    xxha_common_errors  ce
     where   ce.request_id = q_request_id
     and     nvl(ce.table_name,'~!@') = nvl(q_table_name,nvl(ce.table_name,'~!@'))
     and     ce.attribute4 = q_conc_name
     and     ce.attribute5 = q_valtype
     group by ce.error_code
             ,ce.error_msg
     order by 1;


   ------------------------------------------------------------
   -- Cursor for staged items with status NEW
   ------------------------------------------------------------
   cursor c_newitm 
             is
     SELECT  itm.*
            ,null  stock_enabled_flag   --YN
            ,null  mtl_transactions_enabled_flag   --YN
            ,to_number(null)  make_buy_code   --12
            ,to_number(null)  template_lot_control   --12
            ,itm.rowid
     FROM    xxha_items_cleaned_stg  itm
     where   itm.ci_flag = 'C'
     and     itm.status <> 'PS';
   newitm  c_newitm%rowtype;

   ------------------------------------------------------------
   -- Cursor for staged organizaton items with status NEW
   ------------------------------------------------------------
   cursor c_neworgitm (
            q_item_number  xxha_item_invorgs_stg.item_number%type
           ,q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           ,q_invorg_only_flag  varchar2
           ) is
     SELECT  orgitm.*
            ,orgitm.item_number||'/'||orgitm.inventory_org_code  org_item
            ,orgitm.rowid
     FROM    xxha_item_invorgs_stg  orgitm
     where   orgitm.ci_flag = 'C'
     and     orgitm.status <> 'PS'
     and     orgitm.item_number = q_item_number
     and     orgitm.item_record_id = q_item_record_id
     --and     orgitm.inventory_org_code != decode(q_invorg_only_flag,'Y','MST','-9-')
     order by decode(orgitm.inventory_org_code,'MST',1,9)
             ,orgitm.inventory_org_code;
   neworgitm  c_neworgitm%rowtype;

   ----------------------------------------------------------------------------
   -- Cursor for staged item revisions with status NEW
   -- At source, revisions are at the item level.  In Oracle, revisions are at
   -- the organization item level.
   -- So ... in EBS, revisions at all applicable inventory organization levels
   -- must be maintaixned at the same level as the master (MST) organization.
   ------------------------------------------------------------
   cursor c_newitmrev (
            q_item_number  xxha_item_invorgs_stg.item_number%type
           ,q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           ,q_invorg_only_flag  varchar2
           ) is
     SELECT  itmrev.*
            ,itmrev.item_number||'/'||itmrev.revision_no  item_rev
            ,itmrev.rowid
     FROM    xxha_item_revisions_stg  itmrev
     where   itmrev.ci_flag = 'C'
     and     itmrev.status <> 'PS'
     and     itmrev.item_number = q_item_number
     and     itmrev.item_record_id = q_item_record_id
     order by itmrev.revision_no;
   newitmrev  c_newitmrev%rowtype;

--     TYPE XX_COMMON_ERROR IS RECORD OF XXHA_COMMON_ERRORS%ROWTYPE;



    TYPE XX_COMMON_ERROR_Tbl_Type IS TABLE OF XXHA_COMMON_ERRORS%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_COMMON_ERROR_TBL		XX_COMMON_ERROR_Tbl_Type;
    
	TYPE XX_ITEM_SUCCESS_Tbl_Type IS TABLE OF XXHA_ITEM_INVORGS_STG%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_ITEM_SUCCESS_TBL		XX_ITEM_SUCCESS_Tbl_Type;

   ------------------------------------------------------------
   -- Cursor for staged items objects that have been
   -- wholly and sucessfully validate
   ------------------------------------------------------------
  /* cursor c_vsitm
             is
      select  i.*
             ,i.rowid
      from    xxha_items_cleaned_stg  i
      where   1=1
      and     i.object_status = 'VALID'
      and     i.status = 'VS'
      and     i.ci_flag = 'C'
      order by i.item_number;
   vsitm  c_vsitm%rowtype;

   ------------------------------------------------------------
   -- Cursor for staged org items with status VS
   -- for a specific item ordered by org with MST first
   ------------------------------------------------------------
   cursor c_vsoi (
            q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           ,q_item_number  xxha_item_invorgs_stg.item_number%type
           ) is
      select  oi.*
             ,oi.rowid
      from    xxha_item_invorgs_stg  oi
      where   oi.item_record_id = q_item_record_id
      and     oi.item_number = q_item_number
      and     oi.status = 'VS'
      and     oi.ci_flag = 'C'
      and     oi.inventory_org_code <> decode(gc_invorg_only_flag,'Y','MST','-9-')
      order by decode(oi.inventory_org_code,'MST',1,9)
              ,oi.inventory_org_code;
   vsoi  c_vsoi%rowtype;
*/
   ------------------------------------------------------------
   -- Cursor for staged item revision with status VS
   -- for a specific item ordered by revision
   ------------------------------------------------------------
/*   cursor c_vsrv (
          --  q_item_record_id  xxha_item_invorgs_stg.item_record_id%type
           --,q_item_number  xxha_item_invorgs_stg.item_number%type
           ) is
      select  rv.*
             ,rv.rowid
      from    xxha_item_revisions_stg  rv
      where   rv.item_record_id = q_item_record_id
      and     rv.item_number = q_item_number
      and     rv.status = 'VS'
      and     rv.ci_flag = 'C'
      order by revision_no;
   vsrv  c_vsrv%rowtype;

*/
-- +=========================================================================
-- | Procedure to log errors in XXHA_COMMON_ERRORS table
-- +=========================================================================

l_force_commit varchar2 (2000);
l_process_revision varchar2 (2000);


procedure log_error
          is
begin
   gc_error_logged := 'Y';
   gc_table_name := 'XXHA_ECO_ITEMS_STG';
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,gc_comments
                            ,gc_table_name
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
	dbms_output.put_line('error '||gc_error_code||gc_error_msg||gc_comments);						
exception
   when others then
      fnd_file.put_line(fnd_file.log,'Error in XXHA_INV_CONV_ITM_P2_PK.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
end log_error;

procedure populate_item_success_stg_tbl(item_number varchar2,organization_code varchar2,api_status varchar2) is
  l_inv_succ_counter number;
begin
   l_inv_succ_counter :=XX_ITEM_SUCCESS_TBL.count;
			 XX_ITEM_SUCCESS_TBL(l_inv_succ_counter+1).item_number := item_number;
			 XX_ITEM_SUCCESS_TBL(l_inv_succ_counter+1).inventory_org_code := organization_code;
			XX_ITEM_SUCCESS_TBL(l_inv_succ_counter+1).api_status := api_status;
			XX_ITEM_SUCCESS_TBL(l_inv_succ_counter+1).record_id := gn_record_number;
			 
end populate_item_success_stg_tbl;

procedure populate_common_error(error_msg varchar2) is
  l_error_counter number;
begin
dbms_output.put_line(' popu err '||substr(error_msg,1,2000));
gc_error_logged := 'Y';
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := gn_record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := gc_error_code;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := gc_record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;

end populate_common_error;
procedure populate_common_error(error_msg varchar2,error_code varchar2,error_comments varchar2,record_number number,record_identifier varchar2) is
  l_error_counter number;
begin
gc_error_logged := 'Y';
--dbms_output.put_line(' popu err large '||substr(error_msg,1,2000));
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := substr(error_code,1,20);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_comments,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;

end populate_common_error;


procedure log_all_errors IS
l_error_occured boolean := FALSE;
BEGIN
  dbms_output.put_line('All Error '||xx_common_error_tbl.count);
  FOR i IN 1..XX_COMMON_ERROR_TBL.COUNT LOOP
     l_error_occured := true;
	 gc_error_logged := 'N';
	 gn_request_id :=  XX_COMMON_ERROR_TBL(i).request_id;
     gn_record_number := XX_COMMON_ERROR_TBL(i).record_number;
     gc_record_identifier := XX_COMMON_ERROR_TBL(i).record_identifier ;
     gc_error_code := XX_COMMON_ERROR_TBL(i).error_code;
     gc_error_msg := XX_COMMON_ERROR_TBL(i).error_msg;
     gc_comments  :=  XX_COMMON_ERROR_TBL(i).comments;
     gc_table_name :=  XX_COMMON_ERROR_TBL(i).table_name;
     gc_attribute1 :=  XX_COMMON_ERROR_TBL(i).attribute1;
     gc_attribute2 :=  XX_COMMON_ERROR_TBL(i).attribute2;
     gc_attribute3:=  XX_COMMON_ERROR_TBL(i).attribute3;
     gc_attribute4 :=  XX_COMMON_ERROR_TBL(i).attribute4;
     gc_attribute5 :=  XX_COMMON_ERROR_TBL(i).attribute5;
    
	 log_error;                       
     
	 update xxha_item_invorgs_stg
	 set status = 'VE'
	 where record_id = gn_record_number
	 and status <> 'PS'
	 ;
	 
  
  ENd LOOP;
  IF NOT l_error_occured THEN
    xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,'S'--gc_error_code
                            ,gc_error_msg
                            ,'ITEM SUCCESS'--'No Error Occured'
                            ,'XXHA_ECO_ITEMS_STG'--'XXHA_ITEMS_CLEANED_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
    gc_error_logged := 'N';
	
  END IF;
 
END;

-- +=========================================================================
-- | This procedure checks for duplicate staged records.
-- | Duplicate records are flagged as validation error.
-- | If at least duplicate in the batch was found, the other records are
-- | flagged to indicate aborted validation ... All or Nothing!
-- | A duplication error will abort the reuqest with 'Error' completion status.
-- +=========================================================================

procedure call_item_rev_api (
                            p_item_id Number
							,p_organization_id Number
						   ,x_message_list   in out     Error_Handler.Error_Tbl_Type
						   ,x_return_status out VARCHAR2
						   ,x_msg_data out VARCHAR2
						   ,x_msg_count  out NUMBER 
	                     ) IS

  l_start_rev varchar2 (2000);
BEGIN
  dbms_output.put_line('Start Call Item Rev API ');
  begin
   select starting_revision
   into l_start_rev
   from mtl_parameters
   where organization_id = p_organization_id
   ;
  exception
  when others then
    l_start_rev := '-';
  end;
  	  INV_ITEM_REVISION_PUB.Delete_Item_Revision
											(  p_api_version            =>1.0
											,  p_init_msg_list           =>FND_API.g_TRUE
											,  p_commit                  =>FND_API.g_FALSE
											,  p_validation_level        => FND_API.g_VALID_LEVEL_FULL
											,  x_return_status           =>x_return_status
											,  x_msg_count               =>x_msg_count
											,  x_msg_data                =>x_msg_data
											,  p_inventory_item_id       =>p_item_id
											,  p_organization_id         =>p_organization_id
											,  p_revision                =>l_start_rev--'-'
											,  p_object_version_number   =>1
											);
	
	  DBMS_OUTPUT.PUT_LINE('==================================');
	  DBMS_OUTPUT.PUT_LINE('Return Status ==>'||x_return_status);
	
	  IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	     
	   
	         DBMS_OUTPUT.PUT_LINE('Inventory Item Id :'||to_char(p_item_Id));
	  		 DBMS_OUTPUT.PUT_LINE('Organization Id   :'||to_char(p_Organization_Id));
	    
	  ELSE
	      DBMS_OUTPUT.PUT_LINE('Error Messages :');
	      Error_Handler.GET_MESSAGE_LIST(x_message_list=>x_message_list);
	      FOR i IN 1..x_message_list.COUNT LOOP
	         DBMS_OUTPUT.PUT_LINE(x_message_list(i).message_text);
			populate_common_error(x_message_list(i).message_text);
			 --gc_error_msg := x_message_list(i).message_text;
			 --log_error;
	      END LOOP;
	  END IF;
	   DBMS_OUTPUT.PUT_LINE('==================================');
EXCEPTION
	   WHEN OTHERS THEN
	      DBMS_OUTPUT.PUT_LINE('Exception Occured :');
	      DBMS_OUTPUT.PUT_LINE(SQLCODE ||':'||SQLERRM);
	      DBMS_OUTPUT.PUT_LINE('=====================================');



END call_item_rev_api;

--Call Item API Procedure
procedure call_item_api (
                            l_item_table EGO_Item_PUB.Item_Tbl_Type
						   ,x_item_table out EGO_Item_PUB.Item_Tbl_Type
						   ,x_message_list   in out     Error_Handler.Error_Tbl_Type
						   ,x_return_status out VARCHAR2
						   ,x_msg_count  out NUMBER 
	                     ) IS

    x_msg_data varchar2 (2000);
	l_x_message_list        Error_Handler.Error_Tbl_Type;
BEGIN
  dbms_output.put_line('Start Call Item API ');
  	 error_handler.initialize;
	 x_message_list.delete;
	  EGO_ITEM_PUB.Process_Items(
	         p_api_version           => 1.0
	         ,p_init_msg_list         => FND_API.g_TRUE
	         ,p_commit                => FND_API.g_FALSE
	         ,p_Item_Tbl              => l_item_table
	         ,x_Item_Tbl              => x_item_table
	         ,x_return_status         => x_return_status
	         ,x_msg_count             => x_msg_count);
	
	  --DBMS_OUTPUT.PUT_LINE('==================================');
	  DBMS_OUTPUT.PUT_LINE('Return Status ==>'||x_return_status);
	
	  
	  --rollback;
	  IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	  populate_item_success_stg_tbl(l_item_table(l_item_table.count).segment1,l_item_table(l_item_table.count).organization_code,'S');
	  IF l_force_commit = 'Y' THEN
	    commit;   
	  END IF;	
	    FOR i IN 1..x_item_table.COUNT LOOP
	       NULL;
		 --    DBMS_OUTPUT.PUT_LINE('Inventory Item Id :'||to_char(x_item_table(i).Inventory_Item_Id));
	  		-- DBMS_OUTPUT.PUT_LINE('Organization Id   :'||to_char(x_item_table(i).Organization_Id));
	    END LOOP;
	  
		  IF   l_item_table(1).transaction_type = 'CREATE' THEN
			call_item_rev_api (
	                            x_item_table(1).Inventory_Item_Id
								,x_item_table(1).Organization_Id
							   ,x_message_list
							   ,x_return_status
							   ,x_msg_data
							   ,x_msg_count 
		                     );
		  END IF;	
		  				 
	  
	  ELSE
	  populate_item_success_stg_tbl(l_item_table(l_item_table.count).segment1,l_item_table(l_item_table.count).organization_code,'E');
	      DBMS_OUTPUT.PUT_LINE('Error Messages :');
	      Error_Handler.GET_MESSAGE_LIST(x_message_list=>x_message_list);
	      FOR i IN 1..x_message_list.COUNT LOOP
	         DBMS_OUTPUT.PUT_LINE(x_message_list(i).message_text);
			--populate_common_error(x_message_list(i).message_text);
			 populate_common_error(x_message_list(i).message_text,x_return_status,l_item_table(l_item_table.count).segment1||l_item_table(l_item_table.count).organization_code||l_item_table(l_item_table.count).primary_uom_code||x_return_status||l_item_table(l_item_table.count).unit_of_issue||'2'||'ITEM_API_ERROR',gn_record_number,gc_record_identifier);
			 --gc_error_msg := x_message_list(i).message_text;
			 --log_error;
	      END LOOP;
	  END IF;
	  
	  
	   --DBMS_OUTPUT.PUT_LINE('==================================');
EXCEPTION
	   WHEN OTHERS THEN
	      populate_common_error('Call Item API Others '||substr(sqlerrm,1,1000));
	      DBMS_OUTPUT.PUT_LINE('Exception Occured :');
	      DBMS_OUTPUT.PUT_LINE(SQLCODE ||':'||SQLERRM);
	      DBMS_OUTPUT.PUT_LINE('=====================================');



END call_item_api;


--Call Item Org Assign API

PROCEDURE  CALL_ITEM_ORG_ASSIGN_API (
                            l_x_message_list   in out     Error_Handler.Error_Tbl_Type
						   ,x_return_status out VARCHAR2
						   ,x_msg_count  out NUMBER 
	                     ) IS




        l_api_version		 NUMBER := 1.0; 
           
	l_user_id		NUMBER := -1;
	l_resp_id		NUMBER := -1;
	l_application_id	NUMBER := -1;
        l_rowcnt		NUMBER := 1;
        l_user_name		VARCHAR2(30) ;
        l_resp_name		VARCHAR2(30) := 'EGO_DEVELOPMENT_MANAGER';
		p_organization_code varchar2(30);    
    l_item_org_assignment_tbl  EGO_ITEM_PUB.ITEM_ORG_ASSIGNMENT_TBL_TYPE;  
        CURSOR c_org_items IS
        SELECT * 
        FROM xxha_item_invorgs_stg 
        WHERE inventory_org_code <> 'MST';

BEGIN
 
	-- Get the user_id
	-- FND_GLOBAL.APPS_INITIALIZE(USER_ID=>-1,RESP_ID=>51087,RESP_APPL_ID=>20003);
	dbms_output.put_line('Initialized applications context: '|| l_user_id || ' '|| l_resp_id ||' '|| l_application_id );
        
        -- call API to assign Items
       DBMS_OUTPUT.PUT_LINE('===========================================');
               
  
      FOR v_itm_org_assign IN c_org_items LOOP
          DBMS_OUTPUT.PUT_LINE('Calling EGO_ITEM_PUB.Process_Item_Org_Assignment API'||v_itm_org_assign.item_number||v_itm_org_assign.inventory_org_code);
		  l_item_org_assignment_tbl(l_rowcnt).ITEM_NUMBER          := v_itm_org_assign.item_number;
          l_item_org_assignment_tbl(l_rowcnt).ORGANIZATION_CODE    := v_itm_org_assign.inventory_org_code;
         
          EGO_ITEM_PUB.PROCESS_ITEM_ORG_ASSIGNMENTS( 
             P_API_VERSION          => l_api_version
          ,  P_INIT_MSG_LIST        => FND_API.G_TRUE
          ,  P_COMMIT               => FND_API.G_FALSE
          ,  P_ITEM_ORG_ASSIGNMENT_TBL => l_item_org_assignment_tbl
          ,  X_RETURN_STATUS        => x_return_status
          ,  X_MSG_COUNT            => x_msg_count
       );
	    
	  END LOOP;
      
      
       
       DBMS_OUTPUT.PUT_LINE('=========================================');
       DBMS_OUTPUT.PUT_LINE('Return Status: '||x_return_status);

       IF (x_return_status <> FND_API.G_RET_STS_SUCCESS) THEN
	   
          DBMS_OUTPUT.PUT_LINE('Error Messages :');
          Error_Handler.GET_MESSAGE_LIST(x_message_list=>l_x_message_list);
          FOR i IN 1..l_x_message_list.COUNT LOOP
             DBMS_OUTPUT.PUT_LINE(l_x_message_list(i).message_text);
          END LOOP;
       END IF;
       DBMS_OUTPUT.PUT_LINE('=========================================');       
        
EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE('Exception Occured :');
          DBMS_OUTPUT.PUT_LINE(SQLCODE ||':'||SQLERRM);
          DBMS_OUTPUT.PUT_LINE('========================================');
END call_item_org_assign_api;


-- +=========================================================================
-- | This procedure buffers active item status codes in a pl/sql table
-- | The table of values will be used for validation. 
-- +=========================================================================
procedure buffer_item_statuses
          is
   cursor c_st is
      select  inventory_item_status_code  item_status_code
             ,description
      from    mtl_item_status
      where   nvl(disable_date,TRUNC(SYSDATE)) >= TRUNC(SYSDATE);
   st_index  number := 0;

begin
   for strec in c_st
   loop
      st_index := st_index + 1;
      gt_itemStatuses(st_index).code := strec.item_status_code;
      gt_itemStatuses(st_index).description := strec.description;
      if (st_index = 1) then
         g_item_status_list := 'Values: '||strec.item_status_code;
      else
         g_item_status_list := g_item_status_list||', '||strec.item_status_code;
      end if;
   end loop;
   if (st_index = 0) then
      g_item_status_list := 'No active item statuses defined.';
   end if;
end buffer_item_statuses;


-- Check if Item exists

procedure chk_item_exists
is
cursor c_items_invorgs_stg is
select * from xxha_item_invorgs_stg
where status <>  'PS'
and exist_in_oracle is null
;
cursor c_item_exists_in_oracle(q_item_number varchar2,q_org_code varchar2) is
select segment1
from mtl_system_items items,mtl_parameters param
where items.organization_id = param.organization_id
and items.segment1 = q_item_number
and param.organization_code = q_org_code
;
l_exist_in_oracle varchar2 (2000);
l_new_template_code varchar2 (2000);
begin
for v_items_invorgs_stg in c_items_invorgs_stg loop
  l_exist_in_oracle := 'NO';
  l_new_template_code:= v_items_invorgs_stg.template_code;
  IF substr(l_new_template_code,1,1) = 'C' THEN
  	 l_new_template_code := substr(l_new_template_code,2,length(l_new_template_code));
  END IF;	 
  
  for v_item_exists_in_oracle in c_item_exists_in_oracle(v_items_invorgs_stg.item_number,v_items_invorgs_stg.inventory_org_code) loop
    l_exist_in_oracle := 'YES';
	l_new_template_code := 'C'||l_new_template_code;
  end loop;
  update xxha_item_invorgs_stg
  set exist_in_oracle = l_exist_in_oracle
  ,template_code = l_new_template_code
  where record_id = v_items_invorgs_stg.record_id
  ;
end loop;
  commit;
end;

-- Populate existing Category

procedure populate_existing_category 
is
cursor c_items_inv_orgs is
select distinct item_number
from xxha_item_invorgs_stg
where exist_in_oracle <> 'YES'
and status <> 'PS'
and item_number in
(select item_number from xxha_item_invorgs_stg where inventory_org_code = 'MST' and exist_in_oracle = 'YES');

cursor c_items_cleaned (q_item_number varchar2) is
select *
from xxha_items_cleaned_stg
where item_number = q_item_number;

cursor c_get_item_category (q_item_number varchar2) is
select cat.segment1,cat.segment2,cat.segment3,cat.segment4 ,cat.category_id
from mtl_item_categories_v cat,mtl_system_items items
where items.segment1 = q_item_number
and cat.organization_id = 103
and items.inventory_item_id = cat.inventory_item_id
and items.organization_id = cat.organization_id
and category_set_id =1
and structure_id = 101;

begin
  for v_item_inv_orgs in c_items_inv_orgs loop
    for v_items_cleaned in c_items_cleaned (v_item_inv_orgs.item_number) loop
	  -- IF  (v_items_cleaned.item_product_line = 'MS' and v_items_cleaned.item_product_type = 'Misc' and v_items_cleaned.item_product_subtype = 'Misc' and v_items_cleaned.item_platform = 'Misc') THEN
	     for v_get_item_category in c_get_item_category (v_items_cleaned.item_number) loop  
	       update xxha_items_cleaned_stg
		   set item_product_line= v_get_item_category.segment1
		   , item_product_type= v_get_item_category.segment2
		   ,item_product_subtype= v_get_item_category.segment3
		   ,item_platform= v_get_item_category.segment4
		   ,category_id= v_get_item_category.category_id
		   where record_id = v_items_cleaned.record_id;
		 
		 end loop;
	  -- END IF;
	end loop; 
    
  end loop;
  commit;
end;
-- +=========================================================================
-- | Updtae Item Category
-- +=========================================================================
PROCEDURE update_item_category   
                            is
   
     cursor c_items_invorgs_stg
             is
      select * 
	  from	   xxha_item_invorgs_stg
	  where  nvl(inv_cat_status,'NEW') <> 'PS';
	  
	  cursor c_items_cleaned_stg(q_item_number varchar2)
	  is
	  select category_id
	  from xxha_items_cleaned_stg
	  where item_number = q_item_number;

      x_category_id    number;
	  x_organization_id  number;
	  x_inventory_id  number;
      x_category_exists    boolean;
	  x_return_status     VARCHAR2(1000);
      x_error_code        NUMBER;
      x_msg_count        NUMBER;
      x_msg_data        VARCHAR2(1000);
      l_api_version		 NUMBER := 1.0; 
      l_init_msg_list		 VARCHAR2(2) := FND_API.G_TRUE; 
      l_commit		 VARCHAR2(2) := FND_API.G_TRUE;
	  l_new_category_id number;
	     x_message_list        Error_Handler.Error_Tbl_Type;
BEGIN
  dbms_output.put_line(' populate items tbl ');
  gr_icSetup.category_set_id := 1;
  FOR v_items_invorgs_stg in c_items_invorgs_stg LOOP
  gn_record_number := v_items_invorgs_stg.record_id;
	  gc_record_identifier := v_items_invorgs_stg.item_number||' '||v_items_invorgs_stg.inventory_org_code;
    XXHA_INV_COMMON_UTILITIES_PK.GET_ITEM_CATEGORY(v_items_invorgs_stg.inventory_org_code
        ,v_items_invorgs_stg.item_number
		,gr_icSetup.category_set_id
        ,x_category_id  
		,x_organization_id
		,x_inventory_id
        ,x_category_exists);
	IF x_category_exists AND nvl( v_items_invorgs_stg.exist_in_oracle,'NO') <> 'YES' THEN
	  FOR v_items_cleaned_stg in c_items_cleaned_stg(v_items_invorgs_stg.item_number) LOOP
	    l_new_category_id := v_items_cleaned_stg.category_id;
	  END LOOP;
	  INV_ITEM_CATEGORY_PUB.Update_Category_Assignment  (
												     p_api_version        =>l_api_version 
												    ,p_init_msg_list     => FND_API.G_TRUE
												    ,p_commit            => FND_API.G_FALSE
												    ,p_category_id      =>l_new_category_id
												    ,p_old_category_id   =>x_category_id
												    ,p_category_set_id=>gr_icSetup.category_set_id
												    ,p_inventory_item_id =>x_inventory_id
												    ,p_organization_id   =>x_organization_id
												    ,x_return_status=>x_return_status
												    ,x_errorcode =>x_error_code
												    ,x_msg_count =>x_msg_count 
												    ,x_msg_data   =>x_msg_data
  												 );
	  IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	     update xxha_item_invorgs_stg
		 set inv_cat_status = 'PS'
		 where record_id = v_items_invorgs_stg.record_id
		 ;
	    
	         DBMS_OUTPUT.PUT_LINE('Inventory Item Id :'||x_Inventory_Id);
	  		 DBMS_OUTPUT.PUT_LINE('Organization Id   :'||x_Organization_Id);
	    
	  ELSE
	      DBMS_OUTPUT.PUT_LINE('Error Messages :');
	      Error_Handler.GET_MESSAGE_LIST(x_message_list=>x_message_list);
	      FOR i IN 1..x_message_list.COUNT LOOP
	         DBMS_OUTPUT.PUT_LINE(x_message_list(i).message_text);
			populate_common_error(x_message_list(i).message_text);
			 --gc_error_msg := x_message_list(i).message_text;
			 --log_error;
	      END LOOP;
	  END IF;											 
	ELSE
	  null;
	  --populate_common_error('Category Doesnt Exist For '||v_items_invorgs_stg.item_number||' '||v_items_invorgs_stg.inventory_org_code);
	ENd IF;	
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    populate_common_error('update item cat others '||substr(sqlerrm,1,1000));  
END update_item_category;

-- +=========================================================================
-- | Update PO Item Category
-- +=========================================================================
PROCEDURE update_po_item_category   
                            is
   cursor c_items_cleaned_stg
             is
      select * 
	  from	   xxha_items_cleaned_stg
	  where  nvl(po_cat_status,'NEW') <> 'PS'
	  and hae_purchasing_category is not null
	  ;
  cursor c_item_id (q_item_number varchar2 )is
  select inventory_item_id
  from mtl_system_items
  where organization_id =  103
  and segment1 = q_item_number
  ;	  
	  

      x_category_id    number;
	  x_organization_id  number;
	  x_inventory_id  number;
      x_category_exists    boolean;
	  x_return_status     VARCHAR2(1000);
      x_error_code        NUMBER;
      x_msg_count        NUMBER;
      x_msg_data        VARCHAR2(1000);
      l_api_version		 NUMBER := 1.0; 
      l_init_msg_list		 VARCHAR2(2) := FND_API.G_TRUE; 
      l_commit		 VARCHAR2(2) := FND_API.G_TRUE;
	  l_new_category_id number;
	     x_message_list        Error_Handler.Error_Tbl_Type;
	l_purchasing_cat_set_id number;
	l_structure_id number;
	l_item_id number;
		 
BEGIN
  dbms_output.put_line(' populate items tbl ');
--populate_common_error('Purchasing Category 1');
  
  
  begin
  select category_set_id,structure_id
  into l_purchasing_cat_set_id,l_structure_id
  from mtl_category_sets
  where category_set_name = 'Purchasing'
  ;
  exception
  when no_data_found then
    populate_common_error('Purchasing Category Set Not Setup '||substr(sqlerrm,1,1000));
  end;
  
  FOR v_items_cleaned_stg in c_items_cleaned_stg LOOP
--populate_common_error('Purchasing Category 2');  
  gn_record_number := v_items_cleaned_stg.record_id;
  gc_record_identifier := v_items_cleaned_stg.item_number||' '||'MST';
  l_new_category_id := null;
  begin
   select category_id
  into l_new_category_id
  from mtl_categories
  where structure_id = l_structure_id
  and segment1 = trim(v_items_cleaned_stg.hae_purchasing_category)
  ;
  exception
  when no_data_found then
    populate_common_error('Purchasing Category '||v_items_cleaned_stg.hae_purchasing_category||' Not Setup '||substr(sqlerrm,1,1000));
  end;
    XXHA_INV_COMMON_UTILITIES_PK.GET_ITEM_CATEGORY('MST'
        ,v_items_cleaned_stg.item_number
		,l_purchasing_cat_set_id
        ,x_category_id  
		,x_organization_id
		,x_inventory_id
        ,x_category_exists);
	IF x_category_exists THEN
 -- populate_common_error('Purchasing Category 3');	  
	    
	  
	  INV_ITEM_CATEGORY_PUB.Update_Category_Assignment  (
												     p_api_version        =>l_api_version 
												    ,p_init_msg_list     => FND_API.G_TRUE
												    ,p_commit            => FND_API.G_FALSE
												    ,p_category_id      =>l_new_category_id
												    ,p_old_category_id   =>x_category_id
												    ,p_category_set_id=>l_purchasing_cat_set_id
												    ,p_inventory_item_id =>x_inventory_id
												    ,p_organization_id   =>x_organization_id
												    ,x_return_status=>x_return_status
												    ,x_errorcode =>x_error_code
												    ,x_msg_count =>x_msg_count 
												    ,x_msg_data   =>x_msg_data
  												 );
	  IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	         update xxha_items_cleaned_stg
			 set po_cat_status = 'PS'
			 where record_id = v_items_cleaned_stg.record_id
			 ;
	    
	         DBMS_OUTPUT.PUT_LINE('Inventory Item Id :'||x_Inventory_Id);
	  		 DBMS_OUTPUT.PUT_LINE('Organization Id   :'||x_Organization_Id);
	    
	  ELSE
	  
	      DBMS_OUTPUT.PUT_LINE('Error Messages :');
	      Error_Handler.GET_MESSAGE_LIST(x_message_list=>x_message_list);
	      FOR i IN 1..x_message_list.COUNT LOOP
	         DBMS_OUTPUT.PUT_LINE(x_message_list(i).message_text);
			populate_common_error(x_message_list(i).message_text);
			 --gc_error_msg := x_message_list(i).message_text;
			 --log_error;
	      END LOOP;
	  END IF;											 
	ELSE
     for v_item_id in c_item_id (v_items_cleaned_stg.item_number) loop
       l_item_id := v_item_id.inventory_item_id;
     end loop;  
  --populate_common_error('Purchasing Category 4'||l_new_category_id||'a '||l_purchasing_cat_set_id||'b '||v_items_cleaned_stg.inventory_item_id||'c '||x_inventory_id);	
	  INV_ITEM_CATEGORY_PUB.create_Category_Assignment  (
									p_api_version        =>l_api_version
								    ,p_init_msg_list      => FND_API.G_TRUE
								    ,p_commit           => FND_API.G_FALSE
								    ,x_return_status =>x_return_status
								    ,x_errorcode =>x_error_code
								   ,x_msg_count =>x_msg_count 
								    ,x_msg_data   =>x_msg_data
								   ,p_category_id      =>l_new_category_id
								    ,p_category_set_id=>l_purchasing_cat_set_id
								    ,p_inventory_item_id=>l_item_id--v_items_cleaned_stg.inventory_item_id
								    ,p_organization_id=>103
									);
	  IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	         update xxha_items_cleaned_stg
			 set po_cat_status = 'PS'
			 where record_id = v_items_cleaned_stg.record_id
			 ;
	    
	         DBMS_OUTPUT.PUT_LINE('Inventory Item Id :'||x_Inventory_Id);
	  		 DBMS_OUTPUT.PUT_LINE('Organization Id   :'||x_Organization_Id);
	    
	  ELSE
	      DBMS_OUTPUT.PUT_LINE('Error Messages :');
	      Error_Handler.GET_MESSAGE_LIST(x_message_list=>x_message_list);
	      FOR i IN 1..x_message_list.COUNT LOOP
	         DBMS_OUTPUT.PUT_LINE(x_message_list(i).message_text);
			populate_common_error(x_message_list(i).message_text);
			 --gc_error_msg := x_message_list(i).message_text;
			 --log_error;
	      END LOOP;
	  END IF;		
	  --populate_common_error('Category Doesnt Exist For '||v_items_invorgs_stg.item_number||' '||v_items_invorgs_stg.inventory_org_code);
	ENd IF;	
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    populate_common_error('update item cat others '||substr(sqlerrm,1,1000));  
END update_po_item_category;

-- +=========================================================================
-- | Populate Org Items Table
-- +=========================================================================
PROCEDURE populate_org_items 
                  is
   
   ------------------------------------------------------------
   -- Cursor for staged items objects that have been
   -- wholly and sucessfully validate
   ------------------------------------------------------------
   
   
   cursor c_items_invorgs_stg
             is
      select * 
	  from	   xxha_item_invorgs_stg itm_invorg
	  where 1=1
	  and status <> 'PS'
	  /*and item_number||' '||inventory_org_code in
		(
		select record_identifier from xxha_common_errors
		where request_id = 7553588
		)*/
	  --and item_number in (select distinct item_number from xxha_item_invorgs_stg where api_status = 'E')
	  --and  record_id in  (14798,15093)
	  --and item_number in ('10-Test1-111798')--'36651-00' ,'37546-05' ,'38718-00'  ,'51582-00')--('49440-00','47336-00')--('PN 07-022','PN 02-307','PN 04-013','PN 04-014','PN 07-033')--('103535-01','36378-00','85861-00')--'103889-00','104199-00','104199-00')
	 --and outside_processing_item = 'Y'
	 --and record_id in (select record_number from xxha_common_errors where request_id = 7656868)
	 -- and item_number  in (select segment1 from mtl_system_items where organization_id = 103)
	  --where  inventory_org_code <> 'MST'
	 -- and inv_org_id <> 103
	 -- and item_number||inv_org_id not in
	 -- (select items.segment1||organization_id from mtl_system_items items
	 -- 		  where organization_id in (574,694,107,104,314,184)
			  --where items.organization_id = param.organization_id
	  --)
	  ;
	  
	cursor c_items_cleaned_stg(q_item_number varchar2)
             is
      select * 
	  from	   xxha_items_cleaned_stg itm_cleaned
	  where item_number = q_item_number
	  --where status = 'VS'
	  --and item_number in ('35870-01','36071-00','36194-00')
	  --where  inventory_org_code <> 'MST'
	  ;
     	  
	  
   l_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_Inventory_Item_Id   mtl_system_items_b.inventory_item_id%TYPE;
   x_Organization_Id     mtl_system_items_b.organization_id%TYPE;
   x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
   x_inv_item_id   NUMBER;
   l_item_exists         BOOLEAN;
   l_template_name       VARCHAR2(2000);
   l_oracle_p1_uom_code varchar2 (2000);
   l_unit_of_issue varchar2 (2000);
   l_unit_of_issue_valid boolean;
   l_lot_control_code number;
   l_serial_control_code number;
   l_inv_cat varchar2 (2000);
BEGIN
  dbms_output.put_line('Start Populate Org Items ');
  FOR v_items_inv_orgs_stg in c_items_invorgs_stg LOOP
    l_item_table.delete;
	 -- FND_GLOBAL.APPS_INITIALIZE(USER_ID=>-1,RESP_ID=>51087,RESP_APPL_ID=>20003);
      XXHA_INV_COMMON_UTILITIES_PK.check_item_at_org_uom (
         v_items_inv_orgs_stg.inv_org_id
        ,v_items_inv_orgs_stg.item_number
        ,x_inv_item_id
        ,l_oracle_p1_uom_code
		,l_item_exists
		
        );
   --FIRST Item definition
      IF l_item_exists THEN 
   	    l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
      ELSE
	     l_item_table(1).Transaction_Type            := 'CREATE'; -- Replace this with 'UPDATE' for update transaction.
		 l_item_table(1).cost_of_sales_account := nvl(v_items_inv_orgs_stg.orgitm_cos_cc_id,EGO_ITEM_PUB.G_MISS_NUM);
	     l_item_table(1).expense_account            := nvl(v_items_inv_orgs_stg.orgitm_expense_cc_id,EGO_ITEM_PUB.G_MISS_NUM);
	     l_item_table(1).sales_account        := nvl(v_items_inv_orgs_stg.orgitm_sales_cc_id,EGO_ITEM_PUB.G_MISS_NUM);
	  END IF;
	  XXHA_INV_COMMON_UTILITIES_PK.GET_TEMPLATE_CODE(v_items_inv_orgs_stg.template_code,l_template_name);
	  dbms_output.put_line(v_items_inv_orgs_stg.inventory_org_code);
	  l_lot_control_code := 0;
	  FOR v_items_cleaned_stg in c_items_cleaned_stg ( v_items_inv_orgs_stg.item_number) LOOP
	   -- XXHA_INV_COMMON_UTILITIES_PK.GET_TEMPLATE_CODE(v_items_cleaned_stg.template_code,l_template_name);
	     l_item_table(1).Attribute1                 := nvl(v_items_cleaned_stg.sterilization_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  	 l_item_table(1).Attribute2                 := nvl(v_items_cleaned_stg.jan_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  	 l_item_table(1).Attribute3                 := nvl(v_items_cleaned_stg.temprhreq,EGO_ITEM_PUB.G_MISS_CHAR);
	  	 l_item_table(1).Attribute4                 := nvl(v_items_cleaned_stg.japan_categories,EGO_ITEM_PUB.G_MISS_CHAR);
	  	 l_item_table(1).Attribute15                := nvl(v_items_cleaned_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
		 l_item_table(1).Attribute5                := nvl(v_items_cleaned_stg.fastpack,EGO_ITEM_PUB.G_MISS_CHAR);
		 l_item_table(1).inventory_item_status_code                := nvl(v_items_cleaned_stg.item_status,EGO_ITEM_PUB.G_MISS_CHAR);
		 l_inv_cat := v_items_cleaned_stg.item_product_line||'.'||v_items_cleaned_stg.item_product_type||'.'||v_items_cleaned_stg.item_product_subtype;--||'.'||v_items_cleaned_stg.item_platform;
	     IF v_items_cleaned_stg.lot_control is not null THEN
		   l_lot_control_code  := v_items_cleaned_stg.lot_control;
		 ELSE
		   l_lot_control_code := 0;
		 END IF;
		 IF NOT l_item_exists THEN
		   l_oracle_p1_uom_code := v_items_cleaned_stg.primary_uom;
		 END IF;  
		 gc_attribute3 := v_items_cleaned_stg.charuserfield1;
	  END LOOP;
	  
	   dbms_output.put_line(v_items_inv_orgs_stg.inventory_org_code||' Tem '||l_template_name);
	  l_item_table(1).Segment1                    := v_items_inv_orgs_stg.item_number;
      l_item_table(1).Organization_Code           := v_items_inv_orgs_stg.inventory_org_code;
	  l_item_table(1).Template_Name           := l_template_name;
	  --l_item_table(1).allowed_units_lookup_code   := v_items_inv_orgs_stg.conversions;
	  l_item_table(1).Attribute7                 := nvl(v_items_inv_orgs_stg.supplier_no_agile,ego_item_pub.g_miss_char);
	  l_item_table(1).Attribute8                 := nvl(v_items_inv_orgs_stg.supplier_no_bpcs,EGO_ITEM_PUB.G_MISS_CHAR);
	  
	  ---add attribute14---
	  IF l_item_table(1).Transaction_Type            = 'CREATE' AND l_item_table(1).Organization_Code = 'MST' THEN
	  l_item_table(1).Attribute14                := l_inv_cat;--'SV.Serv.Disp.Misc';--nvl(v_items_cleaned_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  END IF;
	  ---add end
	  IF nvl(l_lot_control_code,0)  = 2 THEN
	    l_item_table(1).auto_lot_alpha_prefix        := l_item_table(1).Organization_Code ;--v_items_inv_orgs_stg.starting_lot_prefix;
	    l_item_table(1).start_auto_lot_number        := '100';--v_items_inv_orgs_stg.starting_lot_number;
	  END IF;
	 -- l_item_table(1).purchasing_item_flag        := v_items_inv_orgs_stg.purchased;
	  l_item_table(1).taxable_flag        := nvl(v_items_inv_orgs_stg.taxable,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).purchasing_tax_code        := nvl(v_items_inv_orgs_stg.purchasing_tax_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).buyer_id        := nvl(v_items_inv_orgs_stg.buyer_id,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).planner_code        := nvl(v_items_inv_orgs_stg.planner,EGO_ITEM_PUB.G_MISS_CHAR);
	  --l_item_table(1).planning_make_buy_code        := nvl(v_items_inv_orgs_stg.make_or_buy,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).source_organization_id        := nvl(v_items_inv_orgs_stg.source_org_id,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).preprocessing_lead_time        := nvl(v_items_inv_orgs_stg.preprocessing_lead_time,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).full_lead_time        := nvl(v_items_inv_orgs_stg.processing_lead_time,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).default_shipping_org        := nvl(v_items_inv_orgs_stg.default_shipping_org_id,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).tax_code        := nvl(v_items_inv_orgs_stg.tax_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  
	  l_item_table(1).payment_terms_id        := nvl(v_items_inv_orgs_stg.payment_terms_id,EGO_ITEM_PUB.G_MISS_NUM);
	  --->-----
	  l_item_table(1).RECOVERED_PART_DISP_CODE        := nvl(v_items_inv_orgs_stg.recovered_part_disposition,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).DEFECT_TRACKING_ON_FLAG        := nvl(v_items_inv_orgs_stg.enable_defect_tracking,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).PICK_COMPONENTS_FLAG        := nvl(v_items_inv_orgs_stg.pick_components,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).fixed_lead_time        := nvl(v_items_inv_orgs_stg.fixed_lead_time,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).postprocessing_lead_time        := nvl(v_items_inv_orgs_stg.postprocessing_lead_time,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).DAYS_MAX_INV_WINDOW        := nvl(v_items_inv_orgs_stg.target_inventory_window,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).DAYS_TGT_INV_WINDOW        := nvl(v_items_inv_orgs_stg.target_inventory_days_supply,EGO_ITEM_PUB.G_MISS_NUM);
	  	  l_item_table(1).forecast_horizon        := nvl(v_items_inv_orgs_stg.window_days,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).vmi_forecast_type        := nvl(v_items_inv_orgs_stg.forecast_type,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).mrp_safety_stock_percent        := nvl(v_items_inv_orgs_stg.safety_stock_percent,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).safety_stock_bucket_days        := nvl(v_items_inv_orgs_stg.safety_stock_bucket_days,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).mrp_safety_stock_code        := nvl(v_items_inv_orgs_stg.safety_stock,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).source_type        := nvl(v_items_inv_orgs_stg.source_type,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).max_minmax_quantity        := nvl(v_items_inv_orgs_stg.minmax_maximum_qty,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).min_minmax_quantity        := nvl(v_items_inv_orgs_stg.minmax_minimum_qty,EGO_ITEM_PUB.G_MISS_NUM);
	   ---add attribute14---
	  IF l_item_table(1).Transaction_Type            = 'CREATE' AND l_item_table(1).Organization_Code = 'MST' THEN
	  l_item_table(1).Attribute14                := l_inv_cat;--'SV.Serv.Disp.Misc';--nvl(v_items_cleaned_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  END IF;
	  IF l_item_table(1).Transaction_Type            = 'CREATE' AND l_item_table(1).Organization_Code in ('BTO','AVO','PTO','BDO','HMO','BTS','CAO','HMS','JPC','MSO','SIO','SIO','UNO','UPO') THEN
	  l_item_table(1).purchasing_tax_code                := 'Exempt-Inv';--'SV.Serv.Disp.Misc';--nvl(v_items_cleaned_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).taxable_flag                := 'Y';
	  END IF;
	  --'
	  ---add end
	  ---FEB 
	  --IF nvl(v_items_inv_orgs_stg.minmax_maximum_qty,0) > 0 or nvl(v_items_inv_orgs_stg.minmax_minimum_qty,0) > 0 THEN
	    l_item_table(1).source_type        := 2;
		l_item_table(1).inventory_planning_code        :=2; 
	  --END IF;
	  ---FEB ENd
	  --l_item_table(1).outside_operation_uom_type        := nvl(v_items_inv_orgs_stg.outside_processing_unit_type,EGO_ITEM_PUB.G_MISS_CHAR);
	  --l_item_table(1).outside_operation_flag        := nvl(v_items_inv_orgs_stg.outside_processing_item,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute1                 := nvl(v_items_inv_orgs_stg.sterilization_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute2                 := nvl(v_items_inv_orgs_stg.jan_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute3                 := nvl(v_items_inv_orgs_stg.temprhreq,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute4                 := nvl(v_items_inv_orgs_stg.japan_categories,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute7                 := nvl(v_items_inv_orgs_stg.supplier_no_agile,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute8                 := nvl(v_items_inv_orgs_stg.supplier_no_bpcs,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute15                := nvl(v_items_inv_orgs_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	 -- l_item_table(1).Attribute5                := nvl(v_items_cleaned_stg.fastpack,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute_Category                := nvl(to_char(v_items_inv_orgs_stg.inv_org_id),EGO_ITEM_PUB.G_MISS_CHAR);
	  
	  	 l_unit_of_issue := v_items_inv_orgs_stg.unit_of_issue;
	  IF l_unit_of_issue is not null then	
		 XXHA_INV_COMMON_UTILITIES_PK.check_unit_of_issue(v_items_inv_orgs_stg.item_number
                             ,l_oracle_p1_uom_code
                            ,l_unit_of_issue
							,l_unit_of_issue_valid);
	  ELSE
	  	  l_unit_of_issue_valid := false;
	  END IF;
	  IF l_unit_of_issue_valid THEN
	   l_item_table(1).unit_of_issue := l_unit_of_issue;
	  END IF;
	  
	  IF v_items_inv_orgs_stg.serial_number_generation is not null  THEN
	    l_item_table(1).serial_number_control_code                := v_items_inv_orgs_stg.serial_number_generation;
		IF l_item_table(1).serial_number_control_code  <> 1 THEN
		  l_item_table(1).START_AUTO_SERIAL_NUMBER := '1000';
		  l_item_table(1).AUTO_SERIAL_ALPHA_PREFIX :=  l_item_table(1).Organization_Code;
		END IF;
	  END IF;
	  --->---
	  gn_record_number := v_items_inv_orgs_stg.record_id;
	  gc_record_identifier := v_items_inv_orgs_stg.item_number||' '||v_items_inv_orgs_stg.inventory_org_code;
	  call_item_api (
                            l_item_table
						   ,x_item_table
						   ,x_message_list
						   ,x_return_status
						   ,x_msg_count 
	                     );
	  
	  
	  
	  
	  	
	
	  DBMS_OUTPUT.PUT_LINE('=====================================');
	  DBMS_OUTPUT.PUT_LINE('Org Item Calling EGO_ITEM_PUB.Process_Items API');
	
		
	
  END LOOP;
EXCEPTION

  WHEN OTHERS THEN
    populate_common_error(' populate org items others '||substr(sqlerrm,1,1000));
END populate_org_items;

------>>---------------------------------------------------------------------
-- +=========================================================================
-- | Populate Item Inv Asset
-- +=========================================================================
PROCEDURE populate_items_inv_asset 
                  is
   
   ------------------------------------------------------------
   -- Cursor for staged items objects that have been
   -- wholly and sucessfully validate
   ------------------------------------------------------------
   
   
   cursor c_items_invorgs_stg
             is
      select record_id,item_number,inventory_org_code,costing_enabled_flag from 
		xxha_item_invorgs_stg xxha,mtl_system_items items,mtl_parameters param
		where param.organization_id = items.organization_id
		and param.organization_code = inventory_org_code
		and segment1 = item_number
		and inventory_asset_flag = 'N'
	    and status <> 'PS'
		and inventory_org_code <> 'MST'
	  /*and item_number||' '||inventory_org_code in
		(
		select record_identifier from xxha_common_errors
		where request_id = 7553588
		)*/
	  --and item_number in (select distinct item_number from xxha_item_invorgs_stg where api_status = 'E')
	  --and item_number in ('05835-00')--'103889-00','104199-00','104199-00')
	 -- and item_number  in (select segment1 from mtl_system_items where organization_id = 103)
	  --where  inventory_org_code <> 'MST'
	  ;
	  
	
	  --and item_number in ('35870-01','36071-00','36194-00')
	  --where  inventory_org_code <> 'MST'
	  
     	  
	  
   l_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_Inventory_Item_Id   mtl_system_items_b.inventory_item_id%TYPE;
   x_Organization_Id     mtl_system_items_b.organization_id%TYPE;
   x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
   x_inv_item_id   NUMBER;
   l_item_exists         BOOLEAN;
   l_template_name       VARCHAR2(2000);
   l_oracle_p1_uom_code varchar2 (2000);
BEGIN
  dbms_output.put_line('Start Populate Org Items ');
  FOR v_items_inv_orgs_stg in c_items_invorgs_stg LOOP
    l_item_table.delete;
	 -- FND_GLOBAL.APPS_INITIALIZE(USER_ID=>-1,RESP_ID=>51087,RESP_APPL_ID=>20003);
      
   --FIRST Item definition
   
   	    l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
		l_item_table(1).Segment1                    := v_items_inv_orgs_stg.item_number;
        l_item_table(1).Organization_Code           := v_items_inv_orgs_stg.inventory_org_code;
        l_item_table(1).inventory_asset_flag        := 'Y';
	    IF v_items_inv_orgs_stg.costing_enabled_flag = 'N' THEN
		  l_item_table(1).costing_enabled_flag        := 'Y';
		END IF;
	  
	  
	  --->-----
	  
	  --->---
	  gn_record_number := v_items_inv_orgs_stg.record_id;
	  gc_record_identifier := v_items_inv_orgs_stg.item_number||' '||v_items_inv_orgs_stg.inventory_org_code;
	  call_item_api (
                            l_item_table
						   ,x_item_table
						   ,x_message_list
						   ,x_return_status
						   ,x_msg_count 
	                     );
	  
	  
	  
	  
	  	
	
	  DBMS_OUTPUT.PUT_LINE('=====================================');
	  DBMS_OUTPUT.PUT_LINE('Org Item Calling EGO_ITEM_PUB.Process_Items API');
	
		
	
  END LOOP;
EXCEPTION

  WHEN OTHERS THEN
    populate_common_error(' populate org items others '||substr(sqlerrm,1,1000));
END populate_items_inv_asset;

------>>--------------------------------------------------------------------

-- +=========================================================================
-- | Populate MST Items Table
-- +=========================================================================
PROCEDURE populate_mst_items 
                  is
   
   ------------------------------------------------------------
   -- Cursor for staged items objects that have been
   -- wholly and sucessfully validate
   ------------------------------------------------------------
   
   
   cursor c_items_invorgs_stg
             is
      select * 
	  from	   xxha_item_invorgs_stg itm_invorg
	  where  inventory_org_code = 'MST'
	  and status <> 'PS'
	  /*and item_number||' '||inventory_org_code in
			(
			select record_identifier from xxha_common_errors
			where request_id = 7553588
			)*/
	  --and record_id in  (14798,15093)
	  --and item_number in ('36651-00' ,'37546-05' ,'38718-00'  ,'51582-00')--('103889-00','104199-00','104199-00')
	  --and item_number in ('00697-00')--('49440-00','47336-00')--('PN 07-022','PN 02-307','PN 04-013','PN 04-014','PN 07-033')
	  --and outside_processing_item = 'Y'
	  --and record_id in (select record_number from xxha_common_errors where request_id = 7656868)
	  ----and item_number in (select distinct item_number from xxha_item_invorgs_stg where api_status = 'E')
	 -- and item_number  in (select segment1 from mtl_system_items where organization_id = 103)
	  --and inv_org_id <> 103
	  --and item_number||inv_org_id not in
	  --(select items.segment1||organization_id from mtl_system_items items
	  --where organization_id in (574,694,107,104,314,184)
	  --where items.organization_id = param.organization_id
	 -- )
	  ;
	  
	  
	cursor c_items_cleaned_stg (q_item_number varchar2)  
	  is
	  select * 
	  from xxha_items_cleaned_stg itm_cleaned
	  where item_number = q_item_number
	  --and  status = 'VS'
	  --and item_number in ('35870-01','36071-00','36194-00')
	  ;
	  
	l_item_table          EGO_Item_PUB.Item_Tbl_Type;  
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_Inventory_Item_Id   mtl_system_items_b.inventory_item_id%TYPE;
   x_Organization_Id     mtl_system_items_b.organization_id%TYPE;
   x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
   l_item_exists         boolean;
   x_inv_item_id   number;
   l_template_name     varchar2(2000);
   l_unit_of_issue varchar2 (2000);
   l_num varchar2 (2000);
   l_oracle_p1_uom_code varchar2 (2000);
   l_unit_of_issue_valid boolean;
BEGIN
  dbms_output.put_line('Start Populate MST Items ');
  l_num:= '1';
  FOR v_items_inv_orgs_stg in c_items_invorgs_stg LOOP
    FOR v_items_cleaned_stg in c_items_cleaned_stg(v_items_inv_orgs_stg.item_number) LOOP
	  --FND_GLOBAL.APPS_INITIALIZE(USER_ID=>-1,RESP_ID=>51087,RESP_APPL_ID=>20003);
	  l_unit_of_issue_valid := false;
  l_item_table.delete;
  l_num:= '2';
      XXHA_INV_COMMON_UTILITIES_PK.check_item_at_org_uom (
         v_items_inv_orgs_stg.inv_org_id
        ,v_items_inv_orgs_stg.item_number
        ,x_inv_item_id
		,l_oracle_p1_uom_code
        ,l_item_exists
        );
	 -- XXHA_INV_COMMON_UTILITIES_PK.GET_TEMPLATE_CODE(v_items_cleaned_stg.template_code,l_template_name);
	  XXHA_INV_COMMON_UTILITIES_PK.GET_TEMPLATE_CODE(v_items_inv_orgs_stg.template_code,l_template_name);	
   --FIRST Item definition
   dbms_output.put_line('--Template '||v_items_cleaned_stg.template_code||l_template_name||' '||v_items_inv_orgs_stg.item_number||v_items_cleaned_stg.primary_uom);
  l_num:= '3';
      IF l_item_exists THEN
   	l_num:= '4';
	IF l_unit_of_issue is not null then
	l_unit_of_issue := v_items_inv_orgs_stg.unit_of_issue;
	XXHA_INV_COMMON_UTILITIES_PK.check_unit_of_issue(v_items_inv_orgs_stg.item_number
                             ,l_oracle_p1_uom_code--v_items_cleaned_stg.primary_uom
                            ,l_unit_of_issue
							,l_unit_of_issue_valid);
	ELSE
	  l_unit_of_issue_valid := false;
	END IF;						
	    l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
		l_item_table(1).Segment1                    := v_items_inv_orgs_stg.item_number;
      --l_item_table(1).Description                 := nvl(v_items_cleaned_stg.description,EGO_ITEM_PUB.G_MISS_CHAR);
	  --l_item_table(1).Long_Description            := nvl(v_items_cleaned_stg.description,EGO_ITEM_PUB.G_MISS_CHAR);
	  --l_item_table(1).primary_uom_code            := nvl(v_items_cleaned_stg.primary_uom,EGO_ITEM_PUB.G_MISS_CHAR);
      l_item_table(1).Organization_Code           := v_items_inv_orgs_stg.inventory_org_code;
	  l_item_table(1).inventory_item_status_code  := nvl(v_items_cleaned_stg.item_status,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Template_Name               := l_template_name;
	  l_num:= '5';
	  l_item_table(1).Attribute1                 := nvl(v_items_inv_orgs_stg.sterilization_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute2                 := nvl(v_items_inv_orgs_stg.jan_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute3                 := nvl(v_items_inv_orgs_stg.temprhreq,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute4                 := nvl(v_items_inv_orgs_stg.japan_categories,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute7                 := nvl(v_items_inv_orgs_stg.supplier_no_agile,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '6';
	  l_item_table(1).Attribute5                := nvl(v_items_cleaned_stg.fastpack,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute8                 := nvl(v_items_inv_orgs_stg.supplier_no_bpcs,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '61';
	  l_item_table(1).Attribute15                := nvl(v_items_inv_orgs_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '62';
	  l_item_table(1).weight_uom_code        := nvl(v_items_cleaned_stg.weight_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '63';
	  l_item_table(1).unit_weight        := nvl(v_items_cleaned_stg.unit_weight,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '64';
	  l_item_table(1).volume_uom_code        := nvl(v_items_cleaned_stg.volume_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '65';
	  l_item_table(1).unit_volume        := nvl(v_items_cleaned_stg.unit_volume,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '66';
	  IF l_unit_of_issue_valid THEN
	   l_item_table(1).unit_of_issue        := nvl(l_unit_of_issue,EGO_ITEM_PUB.G_MISS_CHAR);
	  END IF; 
	   IF l_unit_of_issue is not null then
	  l_item_table(1).unit_length        := nvl(v_items_cleaned_stg.length,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '67';
	  l_item_table(1).unit_width        := nvl(v_items_cleaned_stg.width,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '68';
	  l_item_table(1).unit_height        := nvl(v_items_cleaned_stg.height,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '69';
	  end if;
	  ELSE
	  l_num:= '7';
	  
	    l_item_table(1).Transaction_Type            := 'CREATE'; -- Replace this with 'UPDATE' for update transaction.
	    l_item_table(1).Segment1                    := v_items_inv_orgs_stg.item_number;
      l_item_table(1).Description                 := v_items_cleaned_stg.description;
	  l_item_table(1).Long_Description            := v_items_cleaned_stg.description;
	  l_item_table(1).primary_uom_code            := v_items_cleaned_stg.primary_uom;
      l_item_table(1).Organization_Code           := v_items_inv_orgs_stg.inventory_org_code;
	  l_item_table(1).inventory_item_status_code  := v_items_cleaned_stg.item_status;
	  l_item_table(1).secondary_uom_code          := v_items_cleaned_stg.secondary_uom;
	  l_num:= '8';
	  l_item_table(1).allowed_units_lookup_code   := nvl(v_items_inv_orgs_stg.conversions,ego_item_pub.g_miss_num);
	  l_item_table(1).Template_Name               := l_template_name;
	  l_item_table(1).Attribute1                 := v_items_cleaned_stg.sterilization_code;
	  l_item_table(1).Attribute2                 := v_items_cleaned_stg.jan_code;
	  l_item_table(1).Attribute3                 := v_items_cleaned_stg.temprhreq;
	  l_item_table(1).Attribute4                 := v_items_cleaned_stg.japan_categories;
	  l_item_table(1).Attribute5                := nvl(v_items_cleaned_stg.fastpack,EGO_ITEM_PUB.G_MISS_CHAR);
	 l_num:= '9';
	  l_item_table(1).Attribute7                 := v_items_inv_orgs_stg.supplier_no_agile;
	  l_item_table(1).Attribute8                 := v_items_inv_orgs_stg.supplier_no_bpcs;
	  l_item_table(1).Attribute15                := v_items_cleaned_stg.invoice_uom;
--	  l_item_table(1).REVISION_QTY_CONTROL_CODE  := nvl(v_items_cleaned_stg.revision_control,ego_item_pub.g_miss_num);
	  l_item_table(1).shelf_life_code            := nvl(v_items_cleaned_stg.lot_expiration,ego_item_pub.g_miss_num);
	  --l_item_table(1).lot_control_code           := nvl(v_items_cleaned_stg.lot_control,ego_item_pub.g_miss_num);
	--  l_item_table(1).SERIAL_NUMBER_CONTROL_CODE := nvl(v_items_cleaned_stg.serial_number_generation,ego_item_pub.g_miss_num);
	 -- l_item_table(1).auto_lot_alpha_prefix        := v_items_inv_orgs_stg.starting_lot_prefix;
	 -- l_item_table(1).start_auto_lot_number        := v_items_inv_orgs_stg.starting_lot_number;
	  l_item_table(1).cost_of_sales_account := v_items_inv_orgs_stg.orgitm_cos_cc_id;
	  l_item_table(1).outside_operation_flag    := v_items_cleaned_stg.outside_processing_item;
	  l_item_table(1).outside_operation_uom_type        := v_items_cleaned_stg.outside_processing_unit_type;
	  l_num:= '10';
	  l_unit_of_issue := v_items_inv_orgs_stg.unit_of_issue ;
	  IF l_unit_of_issue is not null THEN
	    
		XXHA_INV_COMMON_UTILITIES_PK.check_unit_of_issue(v_items_inv_orgs_stg.item_number
                             ,v_items_cleaned_stg.primary_uom
                            ,l_unit_of_issue
							,l_unit_of_issue_valid);
	  ELSE
	    l_unit_of_issue_valid := false;
	  END IF;						
	  
	  l_num:= '11';
	  IF l_unit_of_issue_valid then
	  
	    l_item_table(1).unit_of_issue        := (l_unit_of_issue);--v_items_cleaned_stg.unit_of_issue;
      END IF;
	  l_item_table(1).expense_account            := v_items_inv_orgs_stg.orgitm_expense_cc_id;
	  l_item_table(1).purchasing_item_flag        := v_items_inv_orgs_stg.purchased;
	  l_item_table(1).taxable_flag        := v_items_inv_orgs_stg.taxable;
	  l_item_table(1).purchasing_tax_code        := v_items_inv_orgs_stg.purchasing_tax_code;
	  l_item_table(1).buyer_id        := v_items_inv_orgs_stg.buyer_id;
	  l_item_table(1).weight_uom_code        := v_items_cleaned_stg.weight_uom;
	  l_item_table(1).unit_weight        := v_items_cleaned_stg.unit_weight;
	  l_item_table(1).volume_uom_code        := v_items_cleaned_stg.volume_uom;
	  l_item_table(1).unit_volume        := v_items_cleaned_stg.unit_volume;
	  l_item_table(1).vehicle_item_flag        := v_items_cleaned_stg.vehicle;
	  l_num:= '12';
	  l_item_table(1).container_item_flag        := v_items_cleaned_stg.container;
	  l_item_table(1).container_type_code        := v_items_cleaned_stg.container_type;
	  l_item_table(1).internal_volume        := v_items_cleaned_stg.internal_volume;
	  l_item_table(1).maximum_load_weight        := v_items_cleaned_stg.maximum_load_weight;
	  l_item_table(1).minimum_fill_percent        := v_items_cleaned_stg.minimum_fill_percentage;
	  l_item_table(1).dimension_uom_code        := v_items_cleaned_stg.dimension_uom;
	  IF l_unit_of_issue is not null then
	  l_item_table(1).unit_length        := v_items_cleaned_stg.length;
	  l_item_table(1).unit_width        := v_items_cleaned_stg.width;
	  l_item_table(1).unit_height        := v_items_cleaned_stg.height;
	  end if;
	  l_item_table(1).min_minmax_quantity        := v_items_cleaned_stg.minmax_minimum_qty;
	  l_item_table(1).max_minmax_quantity        := v_items_cleaned_stg.minmax_maximum_qty;
	  l_item_table(1).source_type        := v_items_cleaned_stg.sourcE_type;
	  l_item_table(1).mrp_safety_stock_code        := nvl(v_items_cleaned_stg.safety_stock,ego_item_pub.g_miss_num);
	  l_item_table(1).safety_stock_bucket_days        := v_items_cleaned_stg.safety_stock_bucket_days;
	  l_item_table(1).mrp_safety_stock_percent        := v_items_cleaned_stg.safety_stock_percent;
	  l_item_table(1).vmi_forecast_type        := v_items_cleaned_stg.forecast_type;
	  l_item_table(1).forecast_horizon        := v_items_cleaned_stg.window_days;
	  l_num:= '13';
	  l_item_table(1).planner_code        := v_items_inv_orgs_stg.planner;
	  --l_item_table(1).planning_make_buy_code        := nvl(v_items_inv_orgs_stg.make_or_buy,ego_item_pub.g_miss_num);
	  l_item_table(1).source_organization_id        := v_items_inv_orgs_stg.source_org_id;
	  l_item_table(1).days_tgt_inv_supply        := v_items_cleaned_stg.target_inventory_days_supply;
	  l_item_table(1).days_tgt_inv_window        := v_items_cleaned_stg.target_inventory_window;
	  l_item_table(1).postprocessing_lead_time        := v_items_cleaned_stg.postprocessing_lead_time;
	  l_item_table(1).fixed_lead_time        := v_items_cleaned_stg.fixed_lead_time;
	  l_item_table(1).pick_components_flag        := v_items_cleaned_stg.pick_components;
	  l_item_table(1).default_shipping_org        := v_items_inv_orgs_stg.default_shipping_org_id;
	  l_item_table(1).tax_code        := v_items_inv_orgs_stg.tax_code;
	  l_item_table(1).sales_account        := v_items_inv_orgs_stg.orgitm_sales_cc_id;
	  l_item_table(1).payment_terms_id        := v_items_inv_orgs_stg.payment_terms_id;
	  l_item_table(1).serv_req_enabled_code        := v_items_cleaned_stg.service_request_code;
	  l_item_table(1).serviceable_product_flag        := v_items_cleaned_stg.enable_contract_coverage;
	  l_item_table(1).defect_tracking_on_flag        := v_items_cleaned_stg.enable_defect_tracking;
	  l_item_table(1).serv_billing_enabled_flag        := v_items_cleaned_stg.enable_service_billing;
	  l_item_table(1).recovered_part_disp_code        := v_items_cleaned_stg.recovered_part_disposition;
	  l_num:= '14';
	  l_item_table(1).material_billable_flag        := v_items_cleaned_stg.billing_type;
	  l_item_table(1).lifecycle_id        := v_items_cleaned_stg.lifecycle_id;
	  END IF;
	  --->-----
	  l_num:= '141';
	  l_item_table(1).RECOVERED_PART_DISP_CODE        := nvl(v_items_inv_orgs_stg.recovered_part_disposition,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '142';
	  l_item_table(1).DEFECT_TRACKING_ON_FLAG        := nvl(v_items_inv_orgs_stg.enable_defect_tracking,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).PICK_COMPONENTS_FLAG        := nvl(v_items_inv_orgs_stg.pick_components,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).fixed_lead_time        := nvl(v_items_inv_orgs_stg.fixed_lead_time,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '143';
	  l_item_table(1).postprocessing_lead_time        := nvl(v_items_inv_orgs_stg.postprocessing_lead_time,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).DAYS_MAX_INV_WINDOW        := nvl(v_items_inv_orgs_stg.target_inventory_window,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).DAYS_TGT_INV_WINDOW        := nvl(v_items_inv_orgs_stg.target_inventory_days_supply,EGO_ITEM_PUB.G_MISS_NUM);
	  	  l_item_table(1).forecast_horizon        := nvl(v_items_inv_orgs_stg.window_days,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).vmi_forecast_type        := nvl(v_items_inv_orgs_stg.forecast_type,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '144';
	  l_item_table(1).mrp_safety_stock_percent        := nvl(v_items_inv_orgs_stg.safety_stock_percent,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).safety_stock_bucket_days        := nvl(v_items_inv_orgs_stg.safety_stock_bucket_days,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).mrp_safety_stock_code        := nvl(v_items_inv_orgs_stg.safety_stock,EGO_ITEM_PUB.G_MISS_NUM);
	  l_item_table(1).source_type        := nvl(v_items_inv_orgs_stg.source_type,EGO_ITEM_PUB.G_MISS_NUM);
	  l_num:= '145';
	  l_item_table(1).max_minmax_quantity        := nvl(v_items_inv_orgs_stg.minmax_maximum_qty,EGO_ITEM_PUB.G_MISS_NUM);
	 l_num:= '1451';
	  l_item_table(1).min_minmax_quantity        := nvl(v_items_inv_orgs_stg.minmax_minimum_qty,EGO_ITEM_PUB.G_MISS_NUM);
	 l_num:= '1452';
	  
	  l_item_table(1).outside_operation_flag        := nvl(v_items_cleaned_stg.outside_processing_item,EGO_ITEM_PUB.G_MISS_CHAR);
	  
	  l_item_table(1).outside_operation_uom_type        := nvl(v_items_cleaned_stg.outside_processing_unit_type,EGO_ITEM_PUB.G_MISS_CHAR);
	  
	  l_num:= '1453';
	  
	  l_num:= '1454';
	  l_item_table(1).Attribute_Category                 := '103';
	  l_item_table(1).Attribute1                 := nvl(v_items_inv_orgs_stg.sterilization_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  
	  l_num:= '1455';
	  l_item_table(1).Attribute2                 := nvl(v_items_inv_orgs_stg.jan_code,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '1456';
	  l_item_table(1).Attribute3                 := nvl(v_items_inv_orgs_stg.temprhreq,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '1457';
	  l_item_table(1).Attribute4                 := nvl(v_items_inv_orgs_stg.japan_categories,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_num:= '150';
	  l_item_table(1).Attribute7                 := nvl(v_items_inv_orgs_stg.supplier_no_agile,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute8                 := nvl(v_items_inv_orgs_stg.supplier_no_bpcs,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute5                := nvl(v_items_cleaned_stg.fastpack,EGO_ITEM_PUB.G_MISS_CHAR);
	  l_item_table(1).Attribute15                := nvl(v_items_inv_orgs_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  ---add attribute14---
	  IF l_item_table(1).Transaction_Type            = 'CREATE' AND l_item_table(1).Organization_Code = 'MST' THEN
	  IF v_items_cleaned_stg.item_product_line is not null then
	    l_item_table(1).Attribute14                := v_items_cleaned_stg.item_product_line||'.'||v_items_cleaned_stg.item_product_type||'.'||v_items_cleaned_stg.item_product_subtype;--||'.'||v_items_cleaned_stg.item_platform;--'SV.Serv.Disp.Misc';--nvl(v_items_cleaned_stg.invoice_uom,EGO_ITEM_PUB.G_MISS_CHAR);
	  END IF;
	  l_item_table(1).shelf_life_days            := (v_items_inv_orgs_stg.item_cost);
	  END IF;
	  ---add end
	  --->---
	  dbms_output.put_line('MST Trx Type'||v_items_inv_orgs_stg.inv_org_id||v_items_inv_orgs_stg.item_number||l_item_table(1).Transaction_Type );
	  
	  gn_record_number := v_items_inv_orgs_stg.record_id;
	  gc_record_identifier := v_items_inv_orgs_stg.item_number||' '||v_items_inv_orgs_stg.inventory_org_code;
	  CALL_ITEM_API (
                            l_item_table
						   ,x_item_table
						   ,x_message_list
						   ,x_return_status
						   ,x_msg_count 
	                     ) ;
	DBMS_OUTPUT.PUT_LINE('==============2=======================');					 
	  
	  /*
	  CALL_ITEM_ORG_ASSIGN_API (
                            x_message_list
						   ,x_return_status
						   ,x_msg_count 
	                     ) ;*/
	 --					 
	  
	  	
	
	  DBMS_OUTPUT.PUT_LINE('=====================================');
	  DBMS_OUTPUT.PUT_LINE('Calling EGO_ITEM_PUB.Process_Items API');
	
		
		END LOOP;
  END LOOP;
  l_num:= '16';
     populate_org_items ;
EXCEPTION
WHEN OTHERS THEN
  populate_common_error(l_num||'populate_mst_items others '||substr(sqlerrm,1,1000));
 
END populate_mst_items;

-- +=========================================================================
-- | Check Lot Control Items Has On Hand
-- +=========================================================================
procedure chk_Lot_OHB is
cursor c_get_lot_ohb_items is
select distinct item_number,record_id
from xxha_item_invorgs_stg stgitm,mtl_system_items items
where 1=1
and  items.segment1 = item_number
and items.organization_id = 103
and items.lot_control_code = 1
and stgitm.status <> 'PS'
--and template_code in ('LCI','PD','DSA')
and exists (select nvl(attribute_value,1) lot_control_code
	 --into l_make_or_buy
	 from mtl_item_templates temp,mtl_item_templ_attributes_v attr
	 where temp.template_id = attr.template_id
	and template_name  like stgitm.template_code||'%'--l_template_name 
	and attribute_name = 'MTL_SYSTEM_ITEMS.LOT_CONTROL_CODE'
	and nvl(attribute_value,1) = 2
)
and items.inventory_item_id in
(select inventory_item_id from mtl_onhand_quantities where inventory_item_id = items.inventory_item_id) 
;	 

/*select distinct item_number,record_id 
from xxha_item_invorgs_stg stgitm,mtl_system_items items
where 1=1
and  items.segment1 = item_number
and items.organization_id = 103
and items.lot_control_code = 1
and stgitm.status <> 'PS'
and template_code in ('LCI','PD','DSA')
and items.inventory_item_id in
(select inventory_item_id from mtl_onhand_quantities where inventory_item_id = items.inventory_item_id) 
;
*/
begin
for v_get_lot_ohb_items in c_get_lot_ohb_items loop
  
  update xxha_items_cleaned_stg
  set status = 'VE'
  where item_number = v_get_lot_ohb_items.item_number;
  update xxha_item_invorgs_stg
  set status = 'VE'
  where item_number = v_get_lot_ohb_items.item_number;
  populate_common_error('Lot Control cannot be made Full Control as OHB exists','E','LOT_CONTROL_ERROR',v_get_lot_ohb_items.record_id,v_get_lot_ohb_items.item_number||'/'||'MST');
end loop;
end;





-- +=========================================================================
-- | Populate Load ITem Revision Data
-- +========================================================================= 
procedure load_mtl_item_revisions_intf (
         p_effectivity_date  mtl_item_revisions_interface.effectivity_date%type
        ,p_set_process_id  mtl_item_revisions_interface.set_process_id%type
		,p_inventory_item_id  mtl_item_revisions_interface.inventory_item_id%type
		,p_item_number  mtl_item_revisions_interface.item_number%type
		,p_inv_org_id  mtl_item_revisions_interface.organization_id%type
		,p_inventory_org_code  mtl_item_revisions_interface.organization_code%type
		,p_revision_no  mtl_item_revisions_interface.revision%type
		,p_description  mtl_item_revisions_interface.description%type
		,p_trx_type  mtl_item_revisions_interface.transaction_type%type
        ) is
   
begin
  
   --insert into mtl_item_revisions_interface (
   insert into xxha_item_revisions_int_stg (
          inventory_item_id
         ,item_number
         ,organization_id
         ,organization_code
         ,revision
         ,effectivity_date
         ,description
         ,last_update_date
         ,last_updated_by
         ,creation_date
         ,created_by
         ,transaction_type
         ,process_flag
         ,set_process_id
		 ,implementation_date
		 )
   values (
          p_inventory_item_id
         ,p_item_number
         ,p_inv_org_id
         ,p_inventory_org_code
         ,p_revision_no
         ,p_effectivity_date
         ,p_description
         ,gd_now
         ,gn_user_id
         ,gd_now
         ,gn_user_id
         ,p_trx_type
         ,gn_process_flag
         ,p_set_process_id
		 ,p_effectivity_date
         );

     
end load_mtl_item_revisions_intf;

-- +=========================================================================
-- | Load Revision to Std Rev Interface
-- +=========================================================================
procedure load_item_revisions_intf 
         is
   cursor c_get_rev is
   select * from xxha_item_revisions_int_stg
   where transaction_type= 'CREATE'
   ;
begin
  for v_get_rev in c_get_rev loop
   insert into mtl_item_revisions_interface (
          inventory_item_id
         ,item_number
         ,organization_id
         ,organization_code
         ,revision
         ,effectivity_date
         ,description
         ,last_update_date
         ,last_updated_by
         ,creation_date
         ,created_by
         ,transaction_type
         ,process_flag
         ,set_process_id
		 ,implementation_date
		 )
   values (
          v_get_rev.inventory_item_id
         ,v_get_rev.item_number
         ,v_get_rev.organization_id
         ,v_get_rev.organization_code
         ,v_get_rev.revision
         ,v_get_rev.effectivity_date
         ,v_get_rev.description
         ,gd_now
         ,gn_user_id
         ,gd_now
         ,gn_user_id
         ,v_get_rev.transaction_type
         ,gn_process_flag
         ,v_get_rev.set_process_id
		 ,v_get_rev.effectivity_date
         );
	end loop;	 

end load_item_revisions_intf;

-- +=========================================================================
-- | Post Item Rev Validation
-- +=========================================================================

procedure item_rev_post_validation
is
  /*cursor c_item_post_revision is
  select * from xxha_item_revisions_int_stg
  where  organization_code = 'BDO'
    ;*/
  cursor c_item_post_revision is
  select * from xxha_item_invorgs_stg
  where  exist_in_oracle NOT IN ('YES')-- 'NO'
  and status <> 'PS'
  and item_number in
  (select item_number from xxha_item_invorgs_stg where exist_in_oracle = 'YES' and inventory_org_code = 'MST')
    ;	
	
   cursor c_get_item_id (q_item_number varchar2)is
  select inventory_item_id
  from mtl_system_items
  where segment1 = q_item_number
  and organization_id = 103
  ;	
		
  --cursor c_get_mst_rev (q_inventory_item_id number,q_revision varchar2)is
  cursor c_get_mst_rev (q_inventory_item_id number,q_organization_code varchar2)is
  select inventory_item_id,organization_id,revision,implementation_date,effectivity_date,description from mtl_item_revisions
  where inventory_item_id = q_inventory_item_id
  and organization_id = 103
  and inventory_item_id||revision not in 
  (select distinct inventory_item_id||revision from xxha_item_revisions_int_stg where organization_code = q_organization_code)
  ;
  /*(select distinct inventory_item_id||revision from xxha_item_revisions_int_stg  where  organization_code = 'BDO'
  and inventory_item_id = q_inventory_item_id)
  ;*/
 l_item_id number;
begin
  for v_item_post_revision in c_item_post_revision loop
   for v_item_id in c_get_item_id(v_item_post_revision.item_number) loop
     l_item_id := v_item_id.inventory_item_id;
   end loop;
    --for v_get_mst_rev in c_get_mst_rev(v_item_post_revision.inventory_item_id,v_item_post_revision.inventory_org_code) loop
	for v_get_mst_rev in c_get_mst_rev(l_item_id,v_item_post_revision.inventory_org_code) loop
	  insert into xxha_item_revisions_int_stg
	  (inventory_item_id,organization_id,revision,last_updated_by,created_by,implementation_date,effectivity_date,description,item_number,organization_code,process_flag,transaction_type,set_process_id)
	  values
	   (v_get_mst_rev.inventory_item_id,v_item_post_revision.inv_org_id,v_get_mst_rev.revision,fnd_global.user_id,fnd_global.user_id,v_get_mst_rev.implementation_date,v_get_mst_rev.effectivity_date,v_get_mst_rev.description,v_item_post_revision.item_number,v_item_post_revision.inventory_org_code,'1','CREATE','100000')
	   ;
	end loop;
  end loop;
  commit;
end;

-- +=========================================================================
-- | Populate Item Rev Trx Type
-- +=========================================================================

procedure item_rev_trx_type is
  cursor c_item_revision is
  select * from xxha_item_revisions_int_stg
  ;
  cursor c_get_existing_rev (q_inventory_item_id number,q_revision varchar2,q_organization_id number)is
  select inventory_item_id,organization_id,revision
  from mtl_item_revisions
  where inventory_item_id = q_inventory_item_id
  and organization_id = q_organization_id
  and revision = q_revision
  ;
begin
  for v_item_revision in c_item_revision loop
    for v_get_existing_rev in c_get_existing_rev(v_item_revision.inventory_item_id,v_item_revision.revision,v_item_revision.organization_id) loop
	   update xxha_item_revisions_int_stg
	   set transaction_type = 'UPDATE'
	   where inventory_item_id = v_item_revision.inventory_item_id
	   and organization_id = v_item_revision.organization_id
	   and revision = v_item_revision.revision
	   ;
	 
	 end loop;
  end loop;	 
  commit;
end;

-- +=========================================================================
-- | Process ITem Rev
-- +=========================================================================

procedure process_item_rev 
is 

begin
item_rev_post_validation;
item_rev_trx_type;
load_item_revisions_intf;
end;

procedure interface_items_rev_info
          is
   lb_1st_rev  boolean;
   ld_effective_date_prv  date;
   ld_effective_date  date;
   i  number;
   ln_set_process_id  mtl_system_items_interface.set_process_id%type;
   ln_cnt_read_itm  number := 0;
   ln_cnt_read_oi  number := 0;
   ln_cnt_itmcat  number := 0;
   ln_cnt_read_rv  number := 0;
   e_abort  exception;
   
   cursor c_vsrv  is
      select  distinct rv.*
             --,rv.rowid
			 ,item_invorgs.starting_revision
			 ,item_invorgs.inventory_org_code
			 ,item_invorgs.inv_org_id
			 ,items_cleaned.start_date_active
      from    xxha_item_revisions_stg  rv,xxha_item_invorgs_stg item_invorgs,xxha_items_cleaned_stg items_cleaned
      where   1=1
	  --AND     rv.item_record_id = item_invorgs.record_id
      and     rv.item_number = item_invorgs.item_number
	  and     rv.item_number = items_cleaned.item_number
      and     rv.status <> 'PS'
      and     rv.ci_flag = 'C'
	  --and rv.item_number = '100418-00'
      order by revision_no;

begin
   dbms_output.put_line('Performing Interface_Items_rev_Info');
   gc_log_msg := 'Performing Interface_Items_Info';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

  

               ---------------------------------------------------
               -- At this point, the items have been interfaced.
               -- About to manage interfacing of revisions
               ---------------------------------------------------
               lb_1st_rev := true;
               ld_effective_date_prv := null;

               ------------------------------------------
               -- scan thru revisions for each item/org
               ------------------------------------------
               for xvsrv in c_vsrv (
				   )
               loop
                  begin
                     ln_cnt_read_rv := ln_cnt_read_rv + 1;
                     --vsrv := xvsrv;

                     ld_effective_date := null;

                     -----------------------------------------------------------------
                     -- If this is the first revision and it is new, check whether a
                     -- revision already exists for the starting rev for the Org.
                     -- If it does not, create the starting revision
                     -----------------------------------------------------------------
                     if (lb_1st_rev) then
                        if (    xvsrv.trx_type = 'CREATE'
                            and xvsrv.revision_no > xvsrv.starting_revision) then
                           xxha_inv_common_utilities_pk.check_on_orgitem_starting_rev(
                                                        xvsrv.item_number
                                                       ,xvsrv.inventory_item_id
                                                       ,xvsrv.start_date_active
                                                       ,xvsrv.inventory_org_code
                                                       ,xvsrv.inv_org_id
                                                       ,xvsrv.starting_revision
                                                       ,nvl(ln_set_process_id,'100000')
                                                       ,gd_now
                                                       ,gn_user_id
                                                       ,'Y'  -- create interface record
                                                       );
                           lb_1st_rev := false;
                           ld_effective_date_prv := xvsrv.start_date_active;
                        end if;
                     end if;
 dbms_output.put_line('Performing Interface_Items_rev_Info Trx Tye '||xvsrv.trx_type );
                     -----------------------------------------------------------------
                     -- Since Agile is system of record and feeds the interface, revisions
                     -- should never be future dates when staged.  Also, if revision
                     -- is found to already exist in Oracle, ignore it (ie. no update).
                     -- Only interface for new revisions.
                     -----------------------------------------------------------------
                     if (xvsrv.trx_type = 'CREATE') then

                        ------------------------------------------
                        -- Determine effectivity date to use
                        ------------------------------------------

                        -- Did previous iteration interface the revision?
                        if (xvsrv.effective_date_iface is not null) then
                           -- yes, so use same effective date
                           ld_effective_date := xvsrv.effective_date_iface;
                        else
                           -- no, use staged effective date but adjust for valid chronology
                           if (xvsrv.effective_date is null) then
                              if (ld_effective_date_prv is not null) then
                                 -- add a minute to last effective date used
                                 ld_effective_date := ld_effective_date_prv + (1 / (24 * 60));
                              else
                                 ld_effective_date := sysdate;
                              end if;
                           else
                              if (ld_effective_date_prv is not null) then
                                 -- add a minute to greater of staged date and last effective date used
                                 ld_effective_date := greatest(xvsrv.effective_date,ld_effective_date_prv)
                                                        + (1 / (24 * 60));
                              else
                                 ld_effective_date := xvsrv.effective_date;
                              end if;
                           end if;
                        end if;

--                        load_mtl_item_revisions_intf(ld_effective_date,ln_set_process_id);
                       IF ((nvl(gc_error_logged,'N') <> 'Y' OR l_force_commit = 'Y') AND l_process_revision = 'Y') THEN
							load_mtl_item_revisions_intf (  nvl(xvsrv.effective_date,ld_effective_date)
													        ,nvl(ln_set_process_id,'100001')
															,xvsrv.inventory_item_id
															,xvsrv.item_number
															,xvsrv.inv_org_id
															,xvsrv.inventory_org_code
															,xvsrv.revision_no
															,xvsrv.description
															,xvsrv.trx_type
													        ) ;
															
						END IF; 
                        ld_effective_date_prv := ld_effective_date;
                        xvsrv.effective_date_iface := ld_effective_date;

                     end if;

                     -------------------------------------------
                     -- Update status on staged revision record
                     -------------------------------------------
                     begin
	                     IF nvl(gc_error_logged,'N') <> 'Y' THEN 
						    update  xxha_item_revisions_stg
	                        set     status = 'PS'
	                               ,effective_date_iface = xvsrv.effective_date_iface
	                              -- ,request_id = gn_request_id
	                        where   record_id = xvsrv.record_id;
						  END IF;	
                     exception
                        when others then
                           populate_common_error('update rev process others '||substr(sqlerrm,1,1000));
						   dbms_output.put_line(substr(sqlerrm,1,1000));
						   fnd_file.put_line(fnd_file.log,'Error updating into XXHA_ITEM_REVISIONS_STG ...');
                           fnd_file.put_line(fnd_file.log,SQLERRM);
                           --raise e_abort;
                     end;

                  end;

               end loop;  -- vsrv

               -------------------------------------------
               -- Update status on staged revision record
               -------------------------------------------
              -- begin
                --  update  xxha_item_invorgs_stg
                  --set     status = 'PS'
                    --     ,request_id = gn_request_id
                  --where   rowid = vsoi.rowid;
               --exception
                 -- when others then
                   --  fnd_file.put_line(fnd_file.log,'Error updating into XXHA_ITEM_INVORGS_STG ...');
                     --fnd_file.put_line(fnd_file.log,SQLERRM);
                     --raise e_abort;
          --     end;
            --end;

         --end loop;  -- vsoi

         -------------------------------------------
         -- Update status on staged revision record
         -------------------------------------------
         --begin
           -- update  xxha_items_cleaned_stg
            --set     status = 'PS'
              --     ,request_id = gn_request_id
            --where   rowid = vsitm.rowid;
         --exception
           -- when others then
             --  fnd_file.put_line(fnd_file.log,'Error updating into XXHA_ITEMS_CLEANED_STG ...');
               --fnd_file.put_line(fnd_file.log,SQLERRM);
               --raise e_abort;
         --end;
     --end;
  -- end loop;  -- vsitm

   -------------------------------------------------------------------------
   -- Summary Of Interfacing Process
   -------------------------------------------------------------------------
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Items Interfacing Summary');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'MTL_SYSTEM_ITEMS    : '||ln_cnt_read_oi||'  ('||ln_cnt_read_itm||') Items');
   fnd_file.put_line(fnd_file.output,'MTL_ITEM_CATEGORIES : '||ln_cnt_itmcat ||'  (at MST only)');
   fnd_file.put_line(fnd_file.output,'MTL_ITEM_REVISIONS  : '||ln_cnt_read_rv);
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));

exception
  when e_abort then
     gc_interface_error := 'Y';
  when others then
     populate_common_error('interf items rev others '||substr(sqlerrm,1,1000));
	 fnd_file.put_line(fnd_file.log,'Error while trying to Interface_Items_Info ...');
     fnd_file.put_line(fnd_file.log,SQLERRM);
	    dbms_output.put_line('Performing Interface_Items_rev_Info Error'||substr(sqlerrm,1,1000));
     gc_interface_error := 'Y';
end interface_items_rev_info;


-- +=========================================================================
-- |  This procedure validates item revisions info staged for conversion.
-- +========================================================================= 
PROCEDURE validate_item_revisions (
         x_validation_status  out  varchar2
        ,p_max_org_starting_rev  in  varchar2
        ) is

   lc_validation_status  varchar2(5);

BEGIN
   gc_log_msg := 'Performing Validate_Item_Revisions';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   -- scan thru xxha_item_revisions_stg in ascending order
   for xitmrev in c_newitmrev (newitm.item_number,newitm.record_id,gc_invorg_only_flag)
   loop
      gn_cnt_read_rv := gn_cnt_read_rv + 1;

      newitmrev := xitmrev;
      newitmrev.inventory_item_id := newitm.inventory_item_id;

      gc_record_identifier := newitmrev.item_number||'/'||newitmrev.revision_no;
      gn_record_number := newitmrev.record_id;
      gc_table_name := gc_table_ITMREV;
      gc_error_code := null;
      gc_error_msg := null;
      gc_comments := null;
      lc_validation_status := null;

      gc_error_logged := 'N';

      begin  -- item revision validation
         if (not xxha_inv_common_utilities_pk.compare_w_org_starting_rev_ok(newitmrev.item_rev
                                             ,newitmrev.item_number,newitmrev.revision_no,p_max_org_starting_rev
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
--dbms_output.put_line('rev err1 '||xx_common_error_tbl.count);		 
         if (not xxha_inv_common_utilities_pk.staged_chronology_ok(newitmrev.item_rev
                                             ,newitmrev.item_number,newitmrev.revision_no,newitmrev.effective_date,'C'
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
--dbms_output.put_line('rev err2 '||xx_common_error_tbl.count);		 

         ------------------------------------------------------------------------
         -- The following checks are done against master org only since revisions
         -- at the inventory org are kept synchronized with the master org.
         ------------------------------------------------------------------------
         if (not xxha_inv_common_utilities_pk.higher_revision_exists(newitmrev.item_rev,newitmrev.revision_no
                                         ,newitmrev.item_number,newitmrev.inventory_item_id,gr_icSetup.org_id_MST
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
--dbms_output.put_line('rev err31 '||	gc_error_msg||gc_error_logged);		
			populate_common_error(gc_error_msg);
         end if;
--dbms_output.put_line('rev err3 '||xx_common_error_tbl.count);
         if (newitmrev.inventory_item_id is not null) then
            if (xxha_inv_common_utilities_pk.revision_exists(newitmrev.item_rev,newitmrev.revision_no
                                         ,newitmrev.inventory_item_id,gr_icSetup.org_id_MST) ) then
               newitmrev.trx_type := 'UPDATE';
            else
               newitmrev.trx_type := 'CREATE';
            end if;
         else
            newitmrev.trx_type := 'CREATE';
         end if;

      end;  -- item revision validation

      if (gc_error_logged = 'Y') then
         gn_cnt_invalid_rv := gn_cnt_invalid_rv + 1;
         lc_validation_status := 'VE';
         x_validation_status := 'VE';
      else
         gn_cnt_valid_rv := gn_cnt_valid_rv + 1;
         lc_validation_status := 'VS';
      end if;

      update  xxha_item_invorgs_stg
      set     status = lc_validation_status
             ,inventory_item_id = newitmrev.inventory_item_id
             ,trx_type = newitmrev.trx_type
      where   item_number = newitmrev.item_number;
	  update  xxha_item_revisions_stg
      set     status = lc_validation_status
      where   record_id = newitmrev.record_id;

   end loop;

end validate_item_revisions;


-- +=========================================================================
-- |  This procedure validates organization items info staged for conversion.
-- +========================================================================= 
PROCEDURE validate_organization_items (
         x_validation_status  out  varchar2
        ,x_max_starting_revision  out  varchar2
        ) is

   lc_max_starting_revision  varchar2(3);
   lc_validation_status  varchar2(5);

BEGIN
   gc_log_msg := 'Performing Validate_Organization_Items';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   -- scan thru xxha_item_invorgs_stg
   for xorgitm in c_neworgitm (newitm.item_number,newitm.record_id,gc_invorg_only_flag)
   loop
      gn_cnt_read_oi := gn_cnt_read_oi + 1;

      neworgitm := xorgitm;
      neworgitm.inventory_item_id := newitm.inventory_item_id;

      gc_record_identifier := neworgitm.item_number||'/'||neworgitm.inventory_org_code;
      gn_record_number := neworgitm.record_id;
      gc_table_name := gc_table_ORGITM;
      gc_error_code := null;
      gc_error_msg := null;
      gc_comments := null;
      lc_validation_status := null;

      gc_error_logged := 'N';

      begin  -- org items validation
         ----------------------------------
         -- Main
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.inventory_org_ok(neworgitm.item_number,neworgitm.inventory_org_code
                      ,neworgitm.inv_org_id,neworgitm.zero_cost_dff,neworgitm.starting_revision
                      ,neworgitm.org_cos_cc_id,neworgitm.org_sales_cc_id,neworgitm.org_expense_cc_id
                      ,neworgitm.ou_org_id,neworgitm.sob_id,neworgitm.coa_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         -- buffer the highest starting revision for staged organizations for the item
         -- this will be used later when validating staged revisions for the item
         if (neworgitm.starting_revision >= nvl(lc_max_starting_revision,neworgitm.starting_revision) ) then
            lc_max_starting_revision := neworgitm.starting_revision;
         end if;

--         if (not xxha_inv_common_utilities_pk.user_item_type_ok(neworgitm.org_item,neworgitm.user_item_type
  --                    ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
	--		populate_common_error(gc_error_msg);
      --   end if;
		 
         if (not xxha_inv_common_utilities_pk.conversions_ok(neworgitm.org_item,neworgitm.conversions
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (    neworgitm.inventory_item_id is not null
             and neworgitm.inv_org_id is not null) then
            if (xxha_inv_common_utilities_pk.item_at_org(neworgitm.org_item,neworgitm.inventory_item_id,neworgitm.inv_org_id) ) then
               neworgitm.trx_type := 'UPDATE';
            else
               neworgitm.trx_type := 'CREATE';
            end if;
         else
            neworgitm.trx_type := 'CREATE';
         end if;

         ----------------------------------
         -- Costing
         ----------------------------------
		-- dbms_output.put_line('newitm.category_product_line_dff '||newitm.category_product_line_dff||neworgitm.inventory_org_code||' '||gc_invorg_only_flag);
         if (not xxha_inv_common_utilities_pk.account_derivation_ok(neworgitm.org_item,neworgitm.inventory_org_code,neworgitm.coa_id,'Cost Of Sales'
                                                                   ,neworgitm.org_cos_cc_id,newitm.category_product_line_dff
                      ,neworgitm.orgitm_cos_cc_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
             
			-->log_error;
			populate_common_error(gc_error_msg);
			
         end if;
--dbms_output.put_line('newitm.category_product_line_dff1 '||newitm.category_product_line_dff);
         ----------------------------------
         -- Purchasing
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.asg_value_YN_ok(neworgitm.org_item,'Purchased flag',neworgitm.purchased
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.asg_value_YN_ok(neworgitm.org_item,'Taxable flag',neworgitm.taxable
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.purchasing_tax_code_ok(neworgitm.org_item,neworgitm.ou_org_id,neworgitm.purchasing_tax_code
                      ,neworgitm.purchasing_tax_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.default_buyer_name_ok(neworgitm.org_item,neworgitm.default_buyer_name
                      ,neworgitm.buyer_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.account_derivation_ok(neworgitm.org_item,neworgitm.inventory_org_code,neworgitm.coa_id,'Expense'
                                                                   ,neworgitm.org_expense_cc_id,newitm.category_product_line_dff
                      ,neworgitm.orgitm_expense_cc_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			null;
			--dbms_output.put_line(gc_error_msg);
			--populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- General Panning
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.planner_ok(neworgitm.org_item,neworgitm.inv_org_id,neworgitm.planner
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.make_or_buy_ok(neworgitm.org_item,neworgitm.make_or_buy
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.postprocessing_lead_time_ok(neworgitm.item_number,neworgitm.inventory_org_code
                                             ,nvl(neworgitm.make_or_buy,newitm.make_buy_code),newitm.postprocessing_lead_time
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.organization_ok(neworgitm.org_item,'Source',neworgitm.source_org_code
                      ,neworgitm.source_org_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Lead Times
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.asg_range_gr_eq_0(neworgitm.org_item,'Preprocessing Lead Time',neworgitm.preprocessing_lead_time
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.asg_range_gr_eq_0(neworgitm.org_item,'Processing Lead Time',neworgitm.processing_lead_time
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Order Management
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.organization_ok(neworgitm.org_item,'Default Shipping',neworgitm.default_shipping_org_code
                      ,neworgitm.default_shipping_org_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Invoicing
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.tax_code_ok(neworgitm.org_item,neworgitm.ou_org_id,neworgitm.tax_code
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.payment_terms_name_ok(neworgitm.org_item,neworgitm.payment_terms_name
                      ,neworgitm.payment_terms_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.account_derivation_ok(neworgitm.org_item,neworgitm.inventory_org_code,neworgitm.coa_id,'Sales'
                                                                   ,neworgitm.org_sales_cc_id,newitm.category_product_line_dff
                      ,neworgitm.orgitm_sales_cc_id
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

      end;  -- org items validation

      if (gc_error_logged = 'Y') then
         gn_cnt_invalid_oi := gn_cnt_invalid_oi + 1;
         lc_validation_status := 'VE';
         x_validation_status := 'VE';
      else
         gn_cnt_valid_oi := gn_cnt_valid_oi + 1;
         lc_validation_status := 'VS';
      end if;
--populate_common_error('de '||neworgitm.item_number||neworgitm.inventory_org_code||neworgitm.inv_org_id);	  
--dbms_output.put_line('before update ----'||lc_validation_status||' '||neworgitm.inv_org_id||neworgitm.org_sales_cc_id);
      update  xxha_item_invorgs_stg
      set     status = lc_validation_status
             ,inventory_item_id = neworgitm.inventory_item_id
             ,inv_org_id = neworgitm.inv_org_id
             ,zero_cost_dff = neworgitm.zero_cost_dff
             ,starting_revision = neworgitm.starting_revision
             ,org_cos_cc_id = neworgitm.org_cos_cc_id
             ,org_sales_cc_id = neworgitm.org_sales_cc_id
             ,org_expense_cc_id = neworgitm.org_expense_cc_id
             ,orgitm_cos_cc_id = neworgitm.orgitm_cos_cc_id
             ,orgitm_sales_cc_id = neworgitm.orgitm_sales_cc_id
             ,orgitm_expense_cc_id = neworgitm.orgitm_expense_cc_id
             ,ou_org_id = neworgitm.ou_org_id
             ,sob_id = neworgitm.sob_id
             ,coa_id = neworgitm.coa_id
             ,purchasing_tax_id = neworgitm.purchasing_tax_id
             ,buyer_id = neworgitm.buyer_id
             ,source_org_id = neworgitm.source_org_id
             ,default_shipping_org_id = neworgitm.default_shipping_org_id
             ,payment_terms_id = neworgitm.payment_terms_id
             ,trx_type = neworgitm.trx_type
      where   rowid = neworgitm.rowid;
	  
--dbms_output.put_line('before update1----');	  

      x_max_starting_revision := lc_max_starting_revision;

   end loop;

end validate_organization_items;

-- +=========================================================================
-- | Pre Validate Item Revisions
-- +=========================================================================

procedure pre_validate_item_revisions
is
cursor c_pre_val_rev is 
select  rev.*,to_date(substr(staged_effective_date,1,22),'MM/DD/YYYY HH:MI:SS AM') update_effective_date
from xxha_item_revisions_stg rev
where status <> 'PS'
--and item_number = '100418-00'
;
cursor c_item_no_rev
is
select item_number,'-' revision_no,record_id, 'NEW' status,'C' CI_Flag,description
from xxha_items_cleaned_stg
where item_number not in
(select item_number from xxha_item_revisions_stg)
;
cursor c_get_item_id (q_item_number varchar2) is
select inventory_item_id
from mtl_system_items_b
where segment1 = q_item_number
and organization_id = 103
;

cursor c_get_item_rev_rec is
select * 
from xxha_item_revisions_stg
where status <> 'PS'
;
l_rev_record_id number:= 0;
l_inv_item_id number;
begin
--add
/*  for v_item_no_rev in c_item_no_rev loop
   l_rev_record_id := l_rev_record_id + 1;
   insert into xxha_item_revisions_stg
   (record_id,item_record_id,ci_flag,status,item_number,revision_no,effective_date,description)
   values
   (l_rev_record_id,v_item_no_rev.record_id,v_item_no_rev.ci_flag,v_item_no_rev.status,v_item_no_rev.item_number,v_item_no_rev.revision_no,sysdate,v_item_no_rev.description)
   ;
 end loop;
 commit;
 */
 ---add 
 for v_get_item_rev_rec in c_get_item_rev_rec loop
   l_inv_item_id := null;
   for v_get_item_id in c_get_item_id (v_get_item_rev_rec.item_number) loop
     l_inv_item_id := v_get_item_id.inventory_item_id;
   end loop;
   update xxha_item_revisions_stg
   set inventory_item_id = l_inv_item_id
   ,trx_type = 'CREATE'
   where item_number = v_get_item_rev_rec.item_number;
   
 end loop;
 /*
 for v_pre_val_rev in c_pre_val_rev loop
   if v_pre_val_rev.staged_effective_date is not null then
     update xxha_item_revisions_stg
	 set effective_date = v_pre_val_rev.update_effective_date
	 ,effective_date_iface = v_pre_val_rev.update_effective_date
	 where record_id = v_pre_val_rev.record_id
	 ;
   end if;
 end loop;
 */
 select max(record_id) 
 into l_rev_record_id
 from xxha_item_revisions_stg
 ;
 /*
 for v_item_no_rev in c_item_no_rev loop
   l_rev_record_id := l_rev_record_id + 1;
   insert into xxha_item_revisions_stg
   (record_id,item_record_id,ci_flag,status,item_number,revision_no,effective_date,description)
   values
   (l_rev_record_id,v_item_no_rev.record_id,v_item_no_rev.ci_flag,v_item_no_rev.status,v_item_no_rev.item_number,v_item_no_rev.revision_no,sysdate,v_item_no_rev.description)
   ;
 end loop;
*/
Exception
When Others then
populate_common_error(substr(sqlerrm,1,2000));
end;


-- +=========================================================================
-- |  This procedure validates item info staged for conversion.
-- +========================================================================= 
PROCEDURE validate_items
          is

   ln_lot_control_mst  number;
   lc_error_logged  varchar2(1);
   lc_validation_status  varchar2(5);
   lc_validation_status_oi  varchar2(5);
   lc_validation_status_rv  varchar2(5);
   lc_object_status  varchar2(5);
   lc_max_starting_revision  varchar2(3);
   
   cursor c_get_minmax_qty is
   select record_id,item_number,inventory_org_code,minmax_minimum_qty,minmax_maximum_qty 
   from haemo.xxha_item_invorgs_stg
   where nvl(minmax_minimum_qty,1) > nvl(minmax_maximum_qty,1)
   and status <> 'PS'
   ; 
   cursor c_chk_postproc_lead_time is
   select *
   from haemo.xxha_item_invorgs_stg
   where postprocessing_lead_time is not null
   and status <> 'PS'
   ; 
   
   cursor c_get_outside_process is
   select distinct cle.item_number,primary_uom
   from haemo.xxha_item_invorgs_stg inv, xxha_items_cleaned_stg cle
   where nvl(inv.outside_processing_item,'N') = 'Y'   
   and inv.status <> 'PS'
   and cle.item_number = inv.item_number
   ;
   
   l_template_name varchar2 (2000);
   l_make_or_buy number;
   l_outside_process_unit_type varchar2 (2000);
BEGIN
   dbms_output.put_line('Start Validate Items ');
   gc_log_msg := 'Performing Validate_Items';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   gr_icSetup.category_set_id := 1;
   -- scan thru xxha_items_cleaned_stg
   buffer_item_statuses;
   dbms_output.put_line('Start Validate Items2 ');
   for v_get_minMax_qty in c_get_minmax_qty loop
     populate_common_error('MinMax Maximum Qty is greater than Minmax Minimum qty','MINMAX_MIN_QTY_ERROR',v_get_minMax_qty.minmax_minimum_qty||' MinMax Minimum Qty is greater than Minmax Maximum Qty '||v_get_minMax_qty.minmax_maximum_qty,v_get_minMax_qty.record_id,v_get_minMax_qty.item_number||' '||v_get_minMax_qty.inventory_org_code);
   end loop;
   for v_get_outside_process in c_get_outside_process loop
     IF v_get_outside_process.primary_uom = 'Ea' THEN
	   l_outside_process_unit_type := 'ASSEMBLY';
	 ELSE
	    l_outside_process_unit_type := 'RESOURCE';  
	 END IF;
     update xxha_items_cleaned_stg 
	 set outside_processing_item = 'Y'
	 , outside_processing_unit_type = l_outside_process_unit_type
	 where item_number = v_get_outside_process.item_number
	 ;
   end loop;
   
   for v_chk_postproc_lead_time in c_chk_postproc_lead_time loop
     XXHA_INV_COMMON_UTILITIES_PK.GET_TEMPLATE_CODE(v_chk_postproc_lead_time.template_code,l_template_name);
	 
	 select nvl(attribute_value,2) make_or_buy
	 into l_make_or_buy
	 from mtl_item_templates temp,mtl_item_templ_attributes_v attr
	 where temp.template_id = attr.template_id
	 and template_name  = l_template_name 
	 and attribute_name = 'MTL_SYSTEM_ITEMS.PLANNING_MAKE_BUY_CODE'
     ;
	 IF l_make_or_buy = 1 THEN
	   IF to_number(nvl(v_chk_postproc_lead_time.postprocessing_lead_time,0)) != 0 THEN
	     populate_common_error('Post Processing Lead Time cannot be > 0 for Make Items','POPROC_LEAD_TIME_ERR',v_chk_postproc_lead_time.postprocessing_lead_time||' Post Processing Lead Time is greater than 0 for Make Item Template '||v_chk_postproc_lead_time.template_code||' '||l_template_name,v_chk_postproc_lead_time.record_id,v_chk_postproc_lead_time.item_number||' '||v_chk_postproc_lead_time.inventory_org_code);
	   END IF;
	 END IF;
   end loop;
   
   
   for xitm in c_newitm
   loop
      gn_cnt_read_itm := gn_cnt_read_itm + 1;

      newitm := xitm;

      gc_record_identifier := newitm.item_number;
      gn_record_number := newitm.record_id;
      gc_table_name := gc_table_ITM;

      lc_validation_status := null;

      gc_error_logged := 'N';

     begin  -- items validation
         ----------------------------------
         -- Main
         ----------------------------------
         xxha_inv_common_utilities_pk.check_item_at_master(gr_icSetup.org_id_mst,newitm.item_number,newitm.inventory_item_id,ln_lot_control_mst);
         if (not xxha_inv_common_utilities_pk.item_status_ok(newitm.item_number,gt_itemStatuses,newitm.item_status
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            gc_comments := gc_comments||' '||g_item_status_list;
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.uom_ok(newitm.item_number,'Primary', newitm.primary_uom
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.uom_ok(newitm.item_number,'Secondary', newitm.secondary_uom
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.template_ok(newitm.item_number,newitm.template_code,gr_icSetup
                      ,newitm.template_id,newitm.stock_enabled_flag,newitm.mtl_transactions_enabled_flag
                      ,newitm.make_buy_code,newitm.template_lot_control
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.category_ok(newitm.item_number,gr_icSetup.category_set_id
                                                         ,newitm.item_product_line,newitm.item_product_type
                                                         ,newitm.item_product_subtype,newitm.item_platform
                      ,newitm.category_id,newitm.category_product_line_dff
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Inventory
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.revision_control_ok(newitm.item_number,newitm.revision_control
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.lot_expiration_ok(newitm.item_number,newitm.lot_expiration
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.lot_control_ok(newitm.item_number
                                          ,newitm.lot_control,newitm.template_lot_control,ln_lot_control_mst
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.serial_number_control_ok(newitm.item_number,newitm.serial_number_generation
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Purchasing
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.value_YN_ok(newitm.item_number,'Outside Processing Item flag',newitm.outside_processing_item
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.outproc_unit_type_ok(newitm.item_number,newitm.outside_processing_unit_type
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.uom_ok(newitm.item_number,'Issue', newitm.unit_of_issue
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Physical Attributes
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.uom_ok(newitm.item_number,'Weight', newitm.weight_uom
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Weight', newitm.unit_weight
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.uom_ok(newitm.item_number,'Volume', newitm.volume_uom
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Volume', newitm.unit_volume
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.value_YN_ok(newitm.item_number,'Vehicle flag',newitm.vehicle
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.value_YN_ok(newitm.item_number,'Container flag',newitm.container
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.container_type_ok(newitm.item_number,newitm.container_type
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Internal Volume', newitm.internal_volume
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Maximum Load Weight', newitm.maximum_load_weight
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Minimum Fill Percentage', newitm.minimum_fill_percentage
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.uom_ok(newitm.item_number,'Dimension', newitm.dimension_uom
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Length', newitm.length
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Width', newitm.width
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Height', newitm.height
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- General Planning
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.minmax_qty_ok(newitm.item_number,newitm.minmax_minimum_qty,newitm.minmax_maximum_qty
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.source_type_ok(newitm.item_number,newitm.source_type
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.safety_stock_ok(newitm.item_number,newitm.safety_stock
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_0(newitm.item_number,'Safety Stock Bucket Days', newitm.safety_stock_bucket_days
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Safety Stock Percent', newitm.safety_stock_percent
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.forecast_type_ok(newitm.item_number,newitm.forecast_type
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_eq_0(newitm.item_number,'Window Days', newitm.window_days
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- MPS/MRP Planning
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.range_gr_0(newitm.item_number,'Target Inventory Days Supply', newitm.target_inventory_days_supply
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_0(newitm.item_number,'Target Inventory Window', newitm.target_inventory_window
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Lead Times
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.range_gr_0(newitm.item_number,'Postprocessing Lead Time', newitm.postprocessing_lead_time
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.range_gr_0(newitm.item_number,'Fixed Lead Time', newitm.fixed_lead_time
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Order Management
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.value_YN_ok(newitm.item_number,'Pick Components flag',newitm.pick_components
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

         ----------------------------------
         -- Service
         ----------------------------------
         if (not xxha_inv_common_utilities_pk.service_request_code_ok(newitm.item_number,newitm.service_request_code
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.value_YN_ok(newitm.item_number,'Enable Contract Coverage flag',newitm.enable_contract_coverage
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.value_YN_ok(newitm.item_number,'Enable Defect Tracking flag',newitm.enable_defect_tracking
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.value_YN_ok(newitm.item_number,'Enable Service Billing flag',newitm.enable_service_billing
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.billing_type_ok(newitm.item_number,newitm.enable_service_billing,newitm.billing_type
                                                             ,newitm.stock_enabled_flag,newitm.mtl_transactions_enabled_flag
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;
         if (not xxha_inv_common_utilities_pk.recovered_part_disposition_ok(newitm.item_number,newitm.billing_type,newitm.recovered_part_disposition
                      ,gc_error_code,gc_error_msg,gc_comments) ) then
            -->log_error;
			populate_common_error(gc_error_msg);
         end if;

      end;  -- items validation

      lc_error_logged := gc_error_logged;
--dbms_output.put_line('Bef org Item  ' || XX_COMMON_ERROR_TBL.count);
      validate_organization_items(lc_validation_status_oi,lc_max_starting_revision);
--dbms_output.put_line('Bef Item rev '|| XX_COMMON_ERROR_TBL.count||newitm.item_number||neworgitm.inventory_org_code);	  
      validate_item_revisions(lc_validation_status_rv,lc_max_starting_revision);
--dbms_output.put_line('Aft Item rev '|| XX_COMMON_ERROR_TBL.count||newitm.item_number||neworgitm.inventory_org_code);
      if (lc_error_logged = 'Y') then
         gn_cnt_invalid_itm := gn_cnt_invalid_itm + 1;
         lc_validation_status := 'VE';
      else
         gn_cnt_valid_itm := gn_cnt_valid_itm + 1;
         lc_validation_status := 'VS';
      end if;

      if (   lc_validation_status = 'VE'
          or lc_validation_status_oi = 'VE'
          or lc_validation_status_rv = 'VE') then
         lc_object_status := 'VE';
      else
         lc_object_status := 'VALID';
      end if;

      update  xxha_items_cleaned_stg
      set     status = lc_validation_status
             ,object_status = lc_object_status
             ,template_id = newitm.template_id
             ,inventory_item_id = newitm.inventory_item_id
             ,category_id = newitm.category_id
             ,category_product_line_dff = newitm.category_product_line_dff
      where   rowid = newitm.rowid;

   end loop;
   dbms_output.put_line('End Validate Items ' ||XX_COMMON_ERROR_TBL.count);

end validate_items;

-- +=========================================================================
-- | Populate Issue Serial On Hadn Qty
-- +=========================================================================

PROCEDURE issue_ohb_serial
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
IS
  
  cursor c_ohb_ser is
select organization_code,items.segment1 item_number,items.description item_description,primary_uom_code,ser.inventory_item_id,last_transaction_id trx_id,ser.current_organization_id organization_id,'1' transaction_quantity,current_subinventory_code subinventory_code,revision,current_locator_id locator_id, lot_number
,serial_number fr_serial_number,serial_number to_serial_number--,ser.*
,decode(serial_number_control_code,1,'No serial number control',2,'Predefined serial numbers',5,'Dynamic entry at inventory receipt',6,'Dynamic entry at sales order issue') oracle_Serial_Control
from mtl_serial_numbers ser,mtl_parameters param,mtl_system_items items
where ser.current_organization_id = param.organization_id
and items.inventory_item_id = ser.inventory_item_id
and current_status = 3
--and items.segment1 = '06002-110-NA-EW'
--and organization_code = 'BTO'
and items.serial_number_control_code in (5)
and items.organization_id = ser.current_organization_id
and items.lot_control_code = 1 
and items.segment1 in 
(select item_number from xxha_item_invorgs_stg where template_code in ('LCI','CLCI','SCI','CSCI'))
;
  lc_material_transactions_id number;
 l_uom_code varchar2 (2000);
 l_cc_id number; 
BEGIN
 select code_combination_id
 into l_cc_id 
from gl_code_combinations_KFV
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000'
;	   
  FOR v_get_ohb in c_ohb_ser LOOP
  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;
 	 
		 
 /* select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;
*/
l_uom_code := v_get_ohb.primary_uom_code;
--FOR v_get_serial IN c_get_serial(v_get_ohb.create_transaction_id) LOOP
INSERT INTO mtl_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
													  ,to_serial_number
													  ,source_code
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,fnd_global.user_id
                                                     ,SYSDATE
                                                     ,fnd_global.user_id
                                                     ,lc_material_transactions_id
                                                     ,v_get_ohb.fr_serial_number
													 ,v_get_ohb.to_serial_number
													 ,'Ph1 Item Lot OHB Clean Issue'
                                                     );
INSERT INTO xxha_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
													  ,to_serial_number
													  ,source_code
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,fnd_global.user_id
                                                     ,SYSDATE
                                                     ,fnd_global.user_id
                                                     ,lc_material_transactions_id
                                                     ,v_get_ohb.fr_serial_number
													 ,v_get_ohb.to_serial_number
													 ,'Ph1 Item Lot OHB Clean Issue'
                                                     );
--END LOOP;													 													 


IF v_get_ohb.lot_number is not null then
 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,''
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 Item Lot OHB Clean Issue'
                                                       );
													   
													   INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,''
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 Item Lot OHB Clean Issue'
                                                       );

end if;

    insert into XXHA_MTL_TRANSACTIONS_INT_STG
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
													,error_code
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 Item Lot OHB Clean Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
												   ,'ITEM_VS_ISSUE'
                                                  );

  
insert into mtl_transactions_interface
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 Item Lot OHB Clean Issue'--'OHB Lot Control Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
  
  END LOOP;

commit;


  

END;		

-- +=========================================================================
-- | Populate Issue non Serial On Hand
-- +=========================================================================

PROCEDURE issue_ohb_non_serial
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
IS

cursor c_ohb is
select organization_code,items.segment1 item_number,items.description item_description,ohb.inventory_item_id,create_transaction_id,ohb.organization_id,transaction_quantity,subinventory_code,ohb.revision,locator_id,ohb.lot_number 
,expiration_date--,serial_number
from mtl_onhand_quantities ohb,mtl_system_items items,mtl_parameters param
,mtl_lot_numbers lot
--,mtl_serial_numbers ser
where 1=1
and items.inventory_item_id = ohb.inventory_item_id
and items.organization_id = ohb.organization_id
and items.organization_id = param.organization_id
and lot.inventory_item_id(+) = ohb.inventory_item_id
and lot.organization_id(+) = ohb.organization_id
and lot.lot_number(+) = ohb.lot_number
--and ser.last_transaction_id(+) = ohb.create_transaction_id
and (items.lot_control_code = 1)
and items.segment1 in
(select item_number from xxha_item_invorgs_stg where template_code in ('LCI','CLCI'))--('LCI','CLCI','SCI','CSCI'))
;

lc_material_transactions_id number;
 l_uom_code varchar2 (2000);
 l_cc_id number;
BEGIN
select code_combination_id
 into l_cc_id 
from gl_code_combinations_KFV
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000'
;
 FOR v_get_ohb in c_ohb LOOP
  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;
		 
  select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;
		 
--l_uom_code := v_get_ohb.primary_uom_code;

IF v_get_ohb.lot_number is not null then
 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 Item Lot OHB Clean Issue2'
                                                       );
													   
													   INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 Item Lot OHB Clean Issue2'
                                                       );

end if;

    insert into XXHA_MTL_TRANSACTIONS_INT_STG
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
													,error_code
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 Item Lot OHB Clean Issue2'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
												   ,'ITEM_VS_ISSUE'
                                                  );

  
insert into mtl_transactions_interface
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 Item Lot OHB Clean Issue2'--'OHB Lot Control Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
  
  END LOOP;

commit;


END;

-- +=========================================================================
-- | Issue Non Serial For To Be Serial Control Items
-- +=========================================================================

PROCEDURE issue_ohb_non_ser_ser_control
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
IS

cursor c_ohb is
select organization_code,items.segment1 item_number,items.description item_description,ohb.inventory_item_id,create_transaction_id,ohb.organization_id,transaction_quantity,subinventory_code,ohb.revision,locator_id,ohb.lot_number 
,expiration_date--,serial_number
from mtl_onhand_quantities ohb,mtl_system_items items,mtl_parameters param
,mtl_lot_numbers lot
--,mtl_serial_numbers ser
where 1=1
and items.inventory_item_id = ohb.inventory_item_id
and items.organization_id = ohb.organization_id
and items.organization_id = param.organization_id
and lot.inventory_item_id(+) = ohb.inventory_item_id
and lot.organization_id(+) = ohb.organization_id
and lot.lot_number(+) = ohb.lot_number
--and ser.last_transaction_id(+) = ohb.create_transaction_id
and (items.serial_number_control_code <> 5)
and items.segment1 in
(select item_number from xxha_items_cleaned_stg where template_code in ('SCI','CSCI'))--('LCI','CLCI','SCI','CSCI'))
;

lc_material_transactions_id number;
 l_uom_code varchar2 (2000);
 l_cc_id number;
BEGIN
select code_combination_id
 into l_cc_id 
from gl_code_combinations_KFV
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000'
;
 FOR v_get_ohb in c_ohb LOOP
  SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;
		 
  select distinct transaction_uom_code 
  into l_uom_code
  from MTL_ONHAND_QUANTITIES_DETAIL
where inventory_item_id = v_get_ohb.inventory_item_id
and create_transaction_id = v_get_ohb.create_transaction_id;
		 
--l_uom_code := v_get_ohb.primary_uom_code;

IF v_get_ohb.lot_number is not null then
 INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 Item Serial OHB Cln Iss3'
                                                       );
													   
													   INSERT INTO XXHA_MTL_TRANSACTIONS_LOT_STG(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
														,source_code
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,v_get_ohb.lot_number
                                                       ,v_get_ohb.expiration_date
                                                       ,v_get_ohb.transaction_quantity*-1
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
                                                       ,SYSDATE
                                                       ,fnd_global.user_id--gn_user_id
													   ,'Ph1 Item Serial OHB Cln Iss3'
                                                       );

end if;

    insert into XXHA_MTL_TRANSACTIONS_INT_STG
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
													,error_code
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 Item Serial OHB Cln Iss3'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
												   ,'ITEM_VS_ISSUE'
                                                  );

  
insert into mtl_transactions_interface
	(last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    --,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                   ,locator_id
												   -- ,loc_segment1
                                                    --,loc_segment2
                                                    --,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id--gn_user_id
                                                   ,'Ph1 Item Serial OHB Cln Iss3'--'OHB Lot Control Issue'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                  -- ,lr_ohb_processing.itemnumber
                                                   ,v_get_ohb.inventory_item_id
                                                   ,v_get_ohb.revision
                                                   ,v_get_ohb.organization_id
                                                   ,v_get_ohb.subinventory_code
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,v_get_ohb.locator_id
												   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   --,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,v_get_ohb.transaction_quantity*-1
                                                   ,l_uom_code
                                                   ,sysdate
                                                   ,32
                                                   ,l_cc_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );

  
  
  END LOOP;

commit;


END;

-- +=========================================================================
-- | Update Lot Prefix
-- +=========================================================================
Procedure Update_Lot_Prefix
(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
is
cursor c_get_lot_items is
select * 
from xxha_item_invorgs_stg
where template_code like '%LCI%'
;
cursor c_lot_items_upd --(q_item_number varchar2) 
is
select organization_code,items.segment1
from mtl_system_items items,mtl_parameters param
where 1=1--items.segment1 = q_item_number
and lot_control_code = 2
and items.organization_id = param.organization_id
and organization_code not in ('CN1','CN2','CN3')
--and organization_code in ('BTO')--,'BDO','GBX','HMO','PTO')
;
l_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_Inventory_Item_Id   mtl_system_items_b.inventory_item_id%TYPE;
   x_Organization_Id     mtl_system_items_b.organization_id%TYPE;
   x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
begin
--for v_get_lot_items in c_get_lot_items loop
 for v_lot_items_upd in c_lot_items_upd --(v_get_lot_items.item_number) 
 loop
	 l_item_table.delete;
	 x_item_table.delete;
	 gn_record_number := 10000;
	  gc_record_identifier := v_lot_items_upd.segment1||'/'||v_lot_items_upd.organization_code;
	  l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_lot_items_upd.segment1;
   l_item_table(1).Organization_Code           := v_lot_items_upd.organization_code;
   --l_item_table(1).Template_Name               := 'HAE_'||v_lot_items_upd.organization_code||'_LOT_PREFIX';
   l_item_table(1).auto_lot_alpha_prefix           := v_lot_items_upd.organization_code;
   l_item_table(1).start_auto_lot_number           := '100';
	  call_item_api (
                            l_item_table
						   ,x_item_table
						   ,x_message_list
						   ,x_return_status
						   ,x_msg_count 
	                     );
	end loop;					 
	--end loop;			
	log_all_errors;		 
    commit;
    
end;


-- +=========================================================================
-- | Update Serial Numbers
-- +=========================================================================
Procedure Update_Serial_Numbers
(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
is
cursor c_get_serial_items is
select * 
from xxha_item_invorgs_stg
where template_code like '%SCI%'
;
cursor c_serial_items_upd (q_item_number varchar2) is
select organization_code,items.segment1
from mtl_system_items items,mtl_parameters param
where items.segment1 = q_item_number
and items.organization_id = param.organization_id
and organization_code not in ('CN1','CN2','CN3')
--and organization_code in ('BTO','BDO','CHO','GBX','HMO','PTO','MST')
;
l_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_Inventory_Item_Id   mtl_system_items_b.inventory_item_id%TYPE;
   x_Organization_Id     mtl_system_items_b.organization_id%TYPE;
   x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
begin
for v_get_serial_items in c_get_serial_items loop
 for v_serial_items_upd in c_serial_items_upd (v_get_serial_items.item_number) loop
	 l_item_table.delete;
	 x_item_table.delete;
	 gn_record_number := 10000;
	  gc_record_identifier := v_serial_items_upd.segment1||'/'||v_serial_items_upd.organization_code;
	  l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_serial_items_upd.segment1;
   l_item_table(1).Organization_Code           := v_serial_items_upd.organization_code;
   l_item_table(1).Template_Name               := 'HAE_SERIAL_TEMPLATE';
	  call_item_api (
                            l_item_table
						   ,x_item_table
						   ,x_message_list
						   ,x_return_status
						   ,x_msg_count 
	                     );
	end loop;					 
	end loop;			
	log_all_errors;		 
    commit;
    update xxha_items_cleaned_stg
    set status = 'VS';
    update xxha_item_invorgs_stg
    set status = 'VS';
    commit;
end;

-- +=========================================================================
-- | Update US Purchasing Tax
-- +=========================================================================

Procedure Update_US_PUR_Tax
(x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        )
is

cursor c_get_items is
select segment1,organization_code,inventory_item_id
from mtl_system_items items,mtl_parameters param
where items.organization_id = param.organization_id
and organization_code in ('BTO',
'AVO',
'PTO',
'BDO',
'HMO',
'BTS',
'CAO',
'HMS',
'JPC',
'MSO',
'SIO',
'SIO',
'UNO',
'UPO'
);
l_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_Inventory_Item_Id   mtl_system_items_b.inventory_item_id%TYPE;
   x_Organization_Id     mtl_system_items_b.organization_id%TYPE;
   x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
begin
     
	 for v_get_items in c_get_items loop
	 l_item_table.delete;
	 x_item_table.delete;
	 gn_record_number := v_get_items.inventory_item_id;
	  gc_record_identifier := v_get_items.segment1||'/'||v_get_items.organization_code;
	  l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_get_items.segment1;
   l_item_table(1).Organization_Code           := v_get_items.organization_code;
   l_item_table(1).Template_Name               := 'TAX-USA';
	  call_item_api (
                            l_item_table
						   ,x_item_table
						   ,x_message_list
						   ,x_return_status
						   ,x_msg_count 
	                     );
	end loop;		
	log_all_errors;			 
    commit;
end;
-- +=========================================================================
-- | Pre Process Items
-- +=========================================================================
PROCEDURE pre_processing_items
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_debug  in  varchar2
        ,p_purge_data  in  varchar2
        ,p_commit_flag  in  varchar2
        ) 
                  is
	l_commit_flag boolean;			  
BEGIN
gn_request_id := fnd_global.conc_request_id; 
FND_GLOBAL.APPS_INITIALIZE(USER_ID=>fnd_global.USER_ID,RESP_ID=>fnd_global.RESP_ID,RESP_APPL_ID=>fnd_global.RESP_APPL_ID);


  XX_ITEM_SUCCESS_TBL.DELETE;
  l_commit_flag := false;
  dbms_output.put_line(' pre processing items '||XX_COMMON_ERROR_TBL.count);
   -- Concurrent request of validating program
   --gc_attribute4 := gc_conc_name;
   chk_item_exists;
  chk_Lot_OHB;
  pre_validate_item_revisions;
  validate_items;
  log_all_errors;
  commit;
  dbms_output.put_line(' validate items '||XX_COMMON_ERROR_TBL.count);
  --populate_items_inv_asset;
  populate_mst_items;
  
  dbms_output.put_line(' populate mst items '||XX_COMMON_ERROR_TBL.count);
  --update_item_category ;
  --update_po_item_category
  dbms_output.put_line(' update item cat '||XX_COMMON_ERROR_TBL.count);
  dbms_output.put_line(' Start Interface Items '||XX_COMMON_ERROR_TBL.count);
  --interface_items_rev_info;
  --process_item_rev ;
  dbms_output.put_line(' End Interface Items '||XX_COMMON_ERROR_TBL.count);
 -- dbms_output.put_line('fnd_file.log',' Log all errors ');
 --commit;
  IF p_commit_flag = 'Y' AND nvl(gc_error_logged,'N') <> 'Y' THEN
      dbms_output.put_line('Commit: ');
    Commit;
	l_commit_flag := true;
  ELSE
    
	 --dbms_output.put_line('Roll : ');
    
	Rollback;
	
  END IF;
  
  FOR i IN 1..XX_ITEM_SUCCESS_TBL.COUNT LOOP
    IF l_commit_flag then
	  update xxha_item_invorgs_stg
	  set status = 'PS'
	  where item_number = xx_item_success_tbl(i).item_number
	  and inventory_org_code = xx_item_success_tbl(i).inventory_org_code
	  and record_id = xx_item_success_tbl(i).record_id
	  ;
	  update xxha_items_cleaned_stg
	  set status = 'PS'
	  where item_number = xx_item_success_tbl(i).item_number
	  ;
	  xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_request_id--xx_eco_success_tbl(i).record_id
                            ,xx_item_success_tbl(i).item_number||' '||xx_item_success_tbl(i).inventory_org_code
                            ,'S'--gc_error_code
                            ,''--gc_error_msg
                            ,'ITEM SUCCESS'
                            ,'XXHA_ECO_ITEMS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,''--xx_eco_success_tbl(i).eco_name
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );		 
	else
	
	 
	  update xxha_item_invorgs_stg
	  set api_status = xx_item_success_tbl(i).api_status
	  where item_number = xx_item_success_tbl(i).item_number
	  and inventory_org_code = xx_item_success_tbl(i).inventory_org_code
	  and record_id = xx_item_success_tbl(i).record_id
	  ;
	
	end if;
  end loop;	
	FOR i IN 1..XX_ITEM_SUCCESS_TBL.COUNT LOOP
    IF xx_item_success_tbl(i).api_status = 'E' THEN
	
	 
	  update xxha_item_invorgs_stg
	  set api_status = xx_item_success_tbl(i).api_status
	  where item_number = xx_item_success_tbl(i).item_number
	  and inventory_org_code = xx_item_success_tbl(i).inventory_org_code
	  and record_id = xx_item_success_tbl(i).record_id
	  ;
	
	end if;
  
  end loop;
  log_all_errors;
  commit;
  IF GC_ERROR_LOGGED = 'Y' THEN
    xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,'Item Conv P2','Item/Org');	
  END IF;			  
EXCEPTION
WHEN OTHERS THEN
  rollback;
  populate_common_error(substr(sqlerrm,1,2000));
  log_all_errors;
  commit;
  dbms_output.put_line('Main When Others ');

END pre_processing_items;				  
-- +=========================================================================
-- | Upate Staging Table
-- +=========================================================================
PROCEDURE upd_stg_tables
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_stmt1 in varchar2
		,p_table_name  in  varchar2
		,p_stmt2 in varchar2)
is

begin
	-- p_stmt1 := 'update ';
 	-- p_tbl := ' XXHA_TST_TBL';
 	-- p_stmt2 := ' set a = ''EE'' where a = ''AA''';
  	-- dbms_output.put_line('upd0');
 	 if p_table_name  like '%XXHA%' or p_table_name  like '%INTERFACE' THEN
 	 	dbms_output.put_line('upd');
 		execute immediate p_stmt1 || ' '||p_table_name ||'  '||p_stmt2;
 		commit;
 	 end if;
end;		

----Get eco Name

PROCEDURE get_eco_name (p_item_number varchar2
                        ,x_eco_name    OUT Varchar2
						) 
is
 cursor c_get_eco_name (q_item_number varchar2) is
 select charuserfield1 
 from xxha_items_cleaned_stg
 where item_number = q_item_number
 ;
 
BEGIN
  FOR v_get_eco_name in c_get_eco_name (p_item_number) LOOP
    x_eco_name := v_get_eco_name.charuserfield1; 
  ENd LOOP;
END;
---->><-------------------------------------------------------------------------------------------------------------------------

-- +=========================================================================
-- | Process Items
-- +=========================================================================
PROCEDURE processing_items
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_commit_flag  in  varchar2
		,p_validate_flag in varchar2
		,p_convert_items in varchar2
		,p_update_inv_category in varchar2
		,p_update_po_category in varchar2
		,p_process_item_rev in varchar2
		,p_force_commit in varchar2 
        ) 
                  is
	l_commit_flag boolean;			  
	l_eco_name varchar2 (2000);
BEGIN
gn_request_id := fnd_global.conc_request_id; 
FND_GLOBAL.APPS_INITIALIZE(USER_ID=>fnd_global.USER_ID,RESP_ID=>fnd_global.RESP_ID,RESP_APPL_ID=>fnd_global.RESP_APPL_ID);
   IF p_process_item_rev = 'Y' THEN
   	 l_process_revision := 'Y';
   ELSE
    l_process_revision := 'N';  	 
   END IF;			   
   IF p_force_commit = 'Y' THEN  
    l_force_commit := 'Y';
   ELSE 
    l_force_commit := 'N';	
  END IF;
  XX_ITEM_SUCCESS_TBL.DELETE;
  l_commit_flag := false;
  dbms_output.put_line(' pre processing items '||XX_COMMON_ERROR_TBL.count);
   -- Concurrent request of validating program
   --gc_attribute4 := gc_conc_name;
  
  IF  p_validate_flag = 'Y' THEN
   chk_item_exists;
   populate_existing_category ;
   chk_Lot_OHB;
   IF p_process_item_rev = 'Y' THEN
   			   pre_validate_item_revisions;
   END IF;			   
   validate_items;
   log_all_errors;
   commit;
  END IF;
  dbms_output.put_line(' validate items '||XX_COMMON_ERROR_TBL.count);
  IF p_convert_items = 'Y' THEN
    populate_mst_items;
  END IF;
  
  dbms_output.put_line(' populate mst items '||XX_COMMON_ERROR_TBL.count);
  IF p_update_inv_category = 'Y' THEN
   update_item_category ;
  END IF;
  IF p_force_commit = 'Y' THEN  
    commit;
  END IF;
  IF p_update_po_category = 'Y' THEN
    update_po_item_category;
  END IF;
  IF p_force_commit = 'Y' THEN  
    commit;
  END IF;
  dbms_output.put_line(' update item cat '||XX_COMMON_ERROR_TBL.count);
  dbms_output.put_line(' Start Interface Items '||XX_COMMON_ERROR_TBL.count);
  IF p_process_item_rev = 'Y' THEN
    interface_items_rev_info;
    process_item_rev ;
	--commit;
  END IF;	
  dbms_output.put_line(' End Interface Items '||XX_COMMON_ERROR_TBL.count);
 -- dbms_output.put_line('fnd_file.log',' Log all errors ');
  	
  IF p_commit_flag = 'Y' AND nvl(gc_error_logged,'N') <> 'Y' THEN
      dbms_output.put_line('Commit: ');
    Commit;
	l_commit_flag := true;
  ELSE
    
	 --dbms_output.put_line('Roll : ');
    
	Rollback;
	
  END IF;
  IF p_force_commit = 'Y' THEN
    l_commit_flag := true;  
    commit;
  END IF;
  IF p_convert_items = 'Y' THEN 
	  FOR i IN 1..XX_ITEM_SUCCESS_TBL.COUNT LOOP
	    IF l_commit_flag then
		  update xxha_item_invorgs_stg
		  set status = 'PS'
		  where item_number = xx_item_success_tbl(i).item_number
		  and inventory_org_code = xx_item_success_tbl(i).inventory_org_code
		  and record_id = xx_item_success_tbl(i).record_id
		  ;
		  update xxha_items_cleaned_stg
		  set status = 'PS'
		  where item_number = xx_item_success_tbl(i).item_number
		  ;
		  get_eco_name (xx_item_success_tbl(i).item_number
                        ,l_eco_name
						);
		  xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,xx_item_success_tbl(i).record_id
                            ,xx_item_success_tbl(i).item_number||'/'||xx_item_success_tbl(i).inventory_org_code
                            ,'S'--gc_error_code
                            ,''--gc_error_msg
                            ,'ITEM SUCCESS'
                            ,'XXHA_ECO_ITEMS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,l_eco_name
                            ,'N'--gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );				
		else
		
		 
		  update xxha_item_invorgs_stg
		  set api_status = xx_item_success_tbl(i).api_status
		  where item_number = xx_item_success_tbl(i).item_number
		  and inventory_org_code = xx_item_success_tbl(i).inventory_org_code
		  and record_id = xx_item_success_tbl(i).record_id
		  ;
		
		end if;
	  end loop;	
		FOR i IN 1..XX_ITEM_SUCCESS_TBL.COUNT LOOP
	    IF xx_item_success_tbl(i).api_status = 'E' THEN
		
		 
		  update xxha_item_invorgs_stg
		  set api_status = xx_item_success_tbl(i).api_status
		  where item_number = xx_item_success_tbl(i).item_number
		  and inventory_org_code = xx_item_success_tbl(i).inventory_org_code
		  and record_id = xx_item_success_tbl(i).record_id
		  ;
		
		end if;
	  
	  end loop;
  END IF;  
  log_all_errors;
  commit;
  IF GC_ERROR_LOGGED = 'Y' THEN
    xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,'Item Conv P2','Item/Org');	
  END IF;			  
EXCEPTION
WHEN OTHERS THEN
  rollback;
  populate_common_error(substr(sqlerrm,1,2000));
  log_all_errors;
  commit;
  dbms_output.put_line('Main When Others ');

END processing_items;				  


---->><------------------------------------------------------------------------------------------------------------------------


END XXHA_INV_CONV_ITM_P2_API;
/
