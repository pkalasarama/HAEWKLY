create or replace PACKAGE XXHA_TRANSPORT_RATES_PKG AUTHID CURRENT_USER
AS

/****************************************************************************************************************
*
* Package Name : XXHA_TRANSPORT_RATES_PKG
* Description:  This package will use XXHA_TRANSPORT_RATES_V to determine Transportation Charges 
* Notes:
*
* Modified:       Ver      Date            Modification
* -------------   -----    -----------     ----------------------------------------------------------------------
* BMarcoux        1.0      01-MAR-2016     Initial Package Creation
*
****************************************************************************************************************/

-- Global Variable Declaration
g_Date                    DATE;

TYPE Header_Rec_Type
IS
RECORD
(
    P_ORIGIN_CITY         VARCHAR2(240)
  , P_ORIGIN_STATE        VARCHAR2(240)
  , P_ORIGIN_COUNTRY      VARCHAR2(240)
  , P_DESTINATION_CITY    VARCHAR2(240)
  , P_DESTINATION_STATE   VARCHAR2(240)
  , P_DESTINATION_COUNTRY VARCHAR2(240)
  , P_LENGTH_INCHES       NUMBER
  , P_WIDTH_INCHES        NUMBER
  , P_HEIGHT_INCHES       NUMBER
  , P_ACTUAL_WEIGHT_LBS   NUMBER
  , P_QUANTITY_PALLETS    NUMBER
  , P_STD_METRIC          VARCHAR2(240)
  , P_DATE_IN             DATE
  , P_FCL                 VARCHAR2(240)
  , P_LCL                 VARCHAR2(240)
  , P_AIR                 VARCHAR2(240)
);

TYPE Header_Tbl_Type
IS
TABLE OF Header_Rec_Type INDEX BY BINARY_INTEGER;

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_MAIN
PROCEDURE XXHA_TRANS_MAIN (P_SESSION_ID                         IN NUMBER
                         , P_header_tbl                         IN Header_Tbl_Type
                          );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_SKID_PROCESSING
PROCEDURE XXHA_SKID_PROCESSING (P_SESSION_ID                    IN NUMBER
                              , P_header_tbl                    IN Header_Tbl_Type
                              , P_Count                         IN NUMBER
                               );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_FCL
PROCEDURE XXHA_TRANS_FCL (P_SESSION_ID                          IN NUMBER
                        , P_ORIGIN_CITY                         IN VARCHAR2
                        , P_ORIGIN_STATE                        IN VARCHAR2
                        , P_ORIGIN_COUNTRY                      IN VARCHAR2
                        , P_DESTINATION_CITY                    IN VARCHAR2
                        , P_DESTINATION_STATE                   IN VARCHAR2
                        , P_DESTINATION_COUNTRY                 IN VARCHAR2
                        , P_PROVIDER                            IN VARCHAR2
                        , P_SHIPPER_NAME                        IN VARCHAR2
                        , P_COSIGNEE_NAME                       IN VARCHAR2
                        , P_LANE_ID                             IN VARCHAR2
                        , P_LANE_TYPE                           IN VARCHAR2
                        , P_EQUIPMENT                           IN VARCHAR2
                        , P_SERVICE                             IN VARCHAR2
                        , P_ORIGIN_TYPE                         IN VARCHAR2
                        , P_DATE_IN                             IN DATE
                        , P_QTY_PALLETS                         IN NUMBER
                         );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_LCL
PROCEDURE XXHA_TRANS_LCL (P_SESSION_ID                          IN NUMBER
                        , P_ORIGIN_CITY                         IN VARCHAR2
                        , P_ORIGIN_STATE                        IN VARCHAR2
                        , P_ORIGIN_COUNTRY                      IN VARCHAR2
                        , P_DESTINATION_CITY                    IN VARCHAR2
                        , P_DESTINATION_STATE                   IN VARCHAR2
                        , P_DESTINATION_COUNTRY                 IN VARCHAR2
                        , P_PROVIDER                            IN VARCHAR2
                        , P_SHIPPER_NAME                        IN VARCHAR2
                        , P_COSIGNEE_NAME                       IN VARCHAR2
                        , P_LANE_ID                             IN VARCHAR2
                        , P_LANE_TYPE                           IN VARCHAR2
                        , P_EQUIPMENT                           IN VARCHAR2
                        , P_SERVICE                             IN VARCHAR2
                        , P_ORIGIN_TYPE                         IN VARCHAR2
                        , P_LENGTH_INCHES                       IN NUMBER
                        , P_WIDTH_INCHES                        IN NUMBER
                        , P_HEIGHT_INCHES                       IN NUMBER
                        , P_ACTUAL_WEIGHT_LBS                   IN NUMBER
                        , P_QUANTITY_PALLETS                    IN NUMBER
                        , P_STD_METRIC                          IN VARCHAR2
                        , P_DATE_IN                             IN DATE
                         );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_LCL_P
PROCEDURE XXHA_TRANS_LCL_P (P_SESSION_ID                        IN NUMBER
                          , P_ORIGIN_CITY                       IN VARCHAR2
                          , P_ORIGIN_STATE                      IN VARCHAR2
                          , P_ORIGIN_COUNTRY                    IN VARCHAR2
                          , P_DESTINATION_CITY                  IN VARCHAR2
                          , P_DESTINATION_STATE                 IN VARCHAR2
                          , P_DESTINATION_COUNTRY               IN VARCHAR2
                          , P_PROVIDER                          IN VARCHAR2
                          , P_SHIPPER_NAME                      IN VARCHAR2
                          , P_COSIGNEE_NAME                     IN VARCHAR2
                          , P_LANE_ID                           IN VARCHAR2
                          , P_LANE_TYPE                         IN VARCHAR2
                          , P_EQUIPMENT                         IN VARCHAR2
                          , P_SERVICE                           IN VARCHAR2
                          , P_ORIGIN_TYPE                       IN VARCHAR2
                          , P_LENGTH_INCHES                     IN NUMBER
                          , P_WIDTH_INCHES                      IN NUMBER
                          , P_HEIGHT_INCHES                     IN NUMBER
                          , P_ACTUAL_WEIGHT_LBS                 IN NUMBER
                          , P_QUANTITY_PALLETS                  IN NUMBER
                          , P_STD_METRIC                        IN VARCHAR2
                          , P_DATE_IN                           IN DATE
                           );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_AIR
PROCEDURE XXHA_TRANS_AIR (P_SESSION_ID                          IN NUMBER
                        , P_ORIGIN_CITY                         IN VARCHAR2
                        , P_ORIGIN_STATE                        IN VARCHAR2
                        , P_ORIGIN_COUNTRY                      IN VARCHAR2
                        , P_DESTINATION_CITY                    IN VARCHAR2
                        , P_DESTINATION_STATE                   IN VARCHAR2
                        , P_DESTINATION_COUNTRY                 IN VARCHAR2
                        , P_PROVIDER                            IN VARCHAR2
                        , P_SHIPPER_NAME                        IN VARCHAR2
                        , P_COSIGNEE_NAME                       IN VARCHAR2
                        , P_LANE_ID                             IN VARCHAR2
                        , P_LANE_TYPE                           IN VARCHAR2
                        , P_EQUIPMENT                           IN VARCHAR2
                        , P_SERVICE                             IN VARCHAR2
                        , P_ORIGIN_TYPE                         IN VARCHAR2
                        , P_LENGTH_INCHES                       IN NUMBER
                        , P_WIDTH_INCHES                        IN NUMBER
                        , P_HEIGHT_INCHES                       IN NUMBER
                        , P_ACTUAL_WEIGHT_LBS                   IN NUMBER
                        , P_QUANTITY_PALLETS                    IN NUMBER
                        , P_STD_METRIC                          IN VARCHAR2
                        , P_DATE_IN                             IN DATE
                        , P_COUNT                               IN NUMBER
                         );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_TRANS_AIR_P
PROCEDURE XXHA_TRANS_AIR_P (P_SESSION_ID                        IN NUMBER
                          , P_ORIGIN_CITY                       IN VARCHAR2
                          , P_ORIGIN_STATE                      IN VARCHAR2
                          , P_ORIGIN_COUNTRY                    IN VARCHAR2
                          , P_DESTINATION_CITY                  IN VARCHAR2
                          , P_DESTINATION_STATE                 IN VARCHAR2
                          , P_DESTINATION_COUNTRY               IN VARCHAR2
                          , P_PROVIDER                          IN VARCHAR2
                          , P_SHIPPER_NAME                      IN VARCHAR2
                          , P_COSIGNEE_NAME                     IN VARCHAR2
                          , P_LANE_ID                           IN VARCHAR2
                          , P_LANE_TYPE                         IN VARCHAR2
                          , P_EQUIPMENT                         IN VARCHAR2
                          , P_SERVICE                           IN VARCHAR2
                          , P_ORIGIN_TYPE                       IN VARCHAR2
                          , P_LENGTH_INCHES                     IN NUMBER
                          , P_WIDTH_INCHES                      IN NUMBER
                          , P_HEIGHT_INCHES                     IN NUMBER
                          , P_ACTUAL_WEIGHT_LBS                 IN NUMBER
                          , P_QUANTITY_PALLETS                  IN NUMBER
                          , P_STD_METRIC                        IN VARCHAR2
                          , P_DATE_IN                           IN DATE
                          , P_COUNT                             IN NUMBER
                           );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_MULTI_SKID_AIR
PROCEDURE XXHA_MULTI_SKID_AIR (P_SESSION_ID                        IN NUMBER
                             , P_TRANS_MODE                        IN VARCHAR2
                              );

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_MULTI_SKID_LCL
PROCEDURE XXHA_MULTI_SKID_LCL (P_SESSION_ID                        IN NUMBER
                             , P_TRANS_MODE                        IN VARCHAR2
                              );

END XXHA_TRANSPORT_RATES_PKG;