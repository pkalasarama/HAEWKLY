CREATE OR REPLACE PACKAGE XXHA_BT_CONTACT AS 
/*********************************************************************************************
* Package Name : XXHA_BT_CONTACT                                                             *
* Purpose      : This package provides functions to retrieve BillTo Contact Information.     *
*                                                                                            *
* Used By      : XXHA: Sales Order Acknowledgment Report XX                                  *
*              : XXHA: Pick Slip Report XX                                                   *
*                                                                                            *
* PROCEDURES   : XXHA_GET_CONTACT_ID                                                         *
*              : XXHA_GET_CONTACT_NAME                                                       *
*              : XXHA_GET_PHONE_NUMBER                                                       *
*              : XXHA_GET_FAX_NUMBER                                                         *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*   AR_CONTACTS_V            S                                                               *
*   HZ_ORG_CONTACTS          S                                                               *
*   HZ_RELATIONSHIPS         S                                                               *
*   HZ_CONTACT_POINTS        S                                                               *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        09-MAR-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
* 2.0        04-MAY-2012     B. Marcoux           Added processing for retrieving FAX#.      *
*                                                                                            *
*********************************************************************************************/

PROCEDURE XXHA_GET_CONTACT_ID(
                           p_BT_Address_ID      IN  NUMBER
                        ,  p_BT_Customer_ID     IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Data               OUT NUMBER
                          );

PROCEDURE XXHA_GET_CONTACT_NAME(
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Data               OUT VARCHAR2
                          );

PROCEDURE XXHA_GET_PHONE_NUMBER(
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                          );

PROCEDURE XXHA_GET_FAX_NUMBER(
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                          );

END XXHA_BT_CONTACT;
/


CREATE OR REPLACE PACKAGE BODY XXHA_BT_CONTACT AS
/*********************************************************************************************
* Package Name : XXHA_BT_CONTACT                                                             *
* Purpose      : This package provides functions to retrieve BillTo Contact Information.     *
*                                                                                            *
* Used By      : XXHA: Sales Order Acknowledgment Report XX                                  *
*              : XXHA: Pick Slip Report XX                                                   *
*                                                                                            *
* PROCEDURES   : XXHA_GET_CONTACT_ID                                                         *
*              : XXHA_GET_CONTACT_NAME                                                       *
*              : XXHA_GET_PHONE_NUMBER                                                       *
*              : XXHA_GET_FAX_NUMBER                                                         *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*   AR_CONTACTS_V            S                                                               *
*   HZ_ORG_CONTACTS          S                                                               *
*   HZ_RELATIONSHIPS         S                                                               *
*   HZ_CONTACT_POINTS        S                                                               *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        09-MAR-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
* 2.0        04-MAY-2012     B. Marcoux           Added processing for retrieving FAX#.      *
*                                                                                            *
*********************************************************************************************/

--------------------------------------------------------------------------------
-- Retrieve Customer Contact ID
PROCEDURE XXHA_GET_CONTACT_ID
                        (
                           p_BT_Address_ID     IN  NUMBER
                        ,  p_BT_Customer_ID    IN  NUMBER
                        ,  p_Count             IN  NUMBER
                        ,  p_Data              OUT NUMBER
                        )  IS

l_loop_count   NUMBER        := 0;
l_data         NUMBER        := NULL;

   CURSOR contact_cursor IS
   SELECT
        cn.Contact_ID
   FROM
        AR_CONTACTS_V                   cn
   WHERE
        cn.Address_Id                 = p_BT_Address_ID
   AND  cn.Customer_Id                = p_BT_Customer_ID
   AND  cn.Status                     = 'A';

BEGIN

  OPEN  contact_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contact_cursor INTO l_data;
              IF contact_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contact_cursor%NOTFOUND THEN
                 l_data := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;           
        END LOOP;

  CLOSE contact_cursor;

  p_Data := l_data;

END;

--------------------------------------------------------------------------------
-- Retrieve Customer Contact Name
PROCEDURE XXHA_GET_CONTACT_NAME
                        (
                           p_Contact_Id        IN  NUMBER
                        ,  p_Count             IN  NUMBER
                        ,  p_Data              OUT VARCHAR2
                        )  IS

l_loop_count   NUMBER        := 0;
l_data         VARCHAR2(240) := NULL;

   CURSOR contact_cursor IS
   SELECT
        DECODE(cn.First_Name, NULL, cn.Last_Name, cn.First_Name || ' ' || cn.Last_Name)
   FROM
        AR_CONTACTS_V                 cn
   WHERE
        cn.Contact_Id                 = p_Contact_Id;

BEGIN

  OPEN  contact_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contact_cursor INTO l_data;
              IF contact_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contact_cursor%NOTFOUND THEN
                 l_data := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;           
        END LOOP;

  CLOSE contact_cursor;

  p_Data := l_data;

END;

--------------------------------------------------------------------------------
-- Retrieve Customer Contact Phone Numbers
PROCEDURE XXHA_GET_PHONE_NUMBER
                        (
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                        )  IS

l_loop_count            NUMBER                                      := 0;
l_Phone_Country_Code    HZ_CONTACT_POINTS.PHONE_COUNTRY_CODE%TYPE   := NULL;
l_Phone_Area_Code       HZ_CONTACT_POINTS.PHONE_AREA_CODE%TYPE      := NULL;
l_Phone_Number          HZ_CONTACT_POINTS.PHONE_NUMBER%TYPE         := NULL;
l_Phone_Extension       HZ_CONTACT_POINTS.PHONE_EXTENSION%TYPE      := NULL;

   CURSOR contact_cursor IS
   SELECT
        hzp.Phone_Country_Code
   ,    hzp.Phone_Area_Code
   ,    hzp.Phone_Number
   ,    hzp.Phone_Extension
   FROM
        AR_CONTACTS_V                 cn
   ,    HZ_ORG_CONTACTS               hzc
   ,    HZ_RELATIONSHIPS              hzr
   ,    HZ_CONTACT_POINTS             hzp
   WHERE
        cn.Contact_ID               = p_Contact_Id
   AND  cn.Contact_Number           = hzc.Contact_Number
   AND  hzc.Party_Relationship_Id   = hzr.Relationship_Id
   AND  hzr.Directional_Flag        = 'F'
   AND  hzr.Object_Table_Name (+)   = 'HZ_PARTIES' 
   AND  hzr.Subject_Table_Name (+)	= 'HZ_PARTIES' 
   AND  hzr.Party_Id                =  hzp.Owner_Table_Id
   AND  hzp.Owner_Table_Name (+)    = 'HZ_PARTIES'
   AND  hzp.Contact_Point_Type	    = 'PHONE'
   AND  hzp.Phone_Line_Type	        <> 'FAX'
   AND  hzp.Status	              	= 'A'
   ORDER BY
      hzp.primary_flag desc
   ,  hzp.contact_point_id;

BEGIN

  OPEN  contact_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contact_cursor 
            INTO l_Phone_Country_Code
               , l_Phone_Area_Code
               , l_Phone_Number
               , l_Phone_Extension;
              IF contact_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contact_cursor%NOTFOUND THEN
                 l_Phone_Country_Code := NULL;
                 l_Phone_Area_Code    := NULL;
                 l_Phone_Number       := NULL;
                 l_Phone_Extension    := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;
        END LOOP;

  CLOSE contact_cursor;

  p_Phone_Country_Code := l_Phone_Country_Code;
  p_Phone_Area_Code    := l_Phone_Area_Code;
  p_Phone_Number       := l_Phone_Number;
  p_Phone_Extension    := l_Phone_Extension;

END;

--------------------------------------------------------------------------------
-- Retrieve Customer Contact FAX Number
PROCEDURE XXHA_GET_FAX_NUMBER
                        (
                           p_Contact_Id         IN  NUMBER
                        ,  p_Count              IN  NUMBER
                        ,  p_Phone_Country_Code OUT VARCHAR2
                        ,  p_Phone_Area_Code    OUT VARCHAR2
                        ,  p_Phone_Number       OUT VARCHAR2
                        ,  p_Phone_Extension    OUT VARCHAR2
                        )  IS

l_loop_count            NUMBER                                      := 0;
l_Phone_Country_Code    HZ_CONTACT_POINTS.PHONE_COUNTRY_CODE%TYPE   := NULL;
l_Phone_Area_Code       HZ_CONTACT_POINTS.PHONE_AREA_CODE%TYPE      := NULL;
l_Phone_Number          HZ_CONTACT_POINTS.PHONE_NUMBER%TYPE         := NULL;
l_Phone_Extension       HZ_CONTACT_POINTS.PHONE_EXTENSION%TYPE      := NULL;

   CURSOR contact_cursor IS
   SELECT
        hzp.Phone_Country_Code
   ,    hzp.Phone_Area_Code
   ,    hzp.Phone_Number
   ,    hzp.Phone_Extension
   FROM
        AR_CONTACTS_V                 cn
   ,    HZ_ORG_CONTACTS               hzc
   ,    HZ_RELATIONSHIPS              hzr
   ,    HZ_CONTACT_POINTS             hzp
   WHERE
        cn.Contact_ID               = p_Contact_Id
   AND  cn.Contact_Number           = hzc.Contact_Number
   AND  hzc.Party_Relationship_Id   = hzr.Relationship_Id
   AND  hzr.Directional_Flag        = 'F'
   AND  hzr.Object_Table_Name (+)   = 'HZ_PARTIES' 
   AND  hzr.Subject_Table_Name (+)	= 'HZ_PARTIES' 
   AND  hzr.Party_Id                =  hzp.Owner_Table_Id
   AND  hzp.Owner_Table_Name (+)    = 'HZ_PARTIES'
   AND  hzp.Contact_Point_Type	    = 'PHONE'
   AND  hzp.Phone_Line_Type	        = 'FAX'
   AND  hzp.Status	              	= 'A'
   ORDER BY
      hzp.primary_flag desc
   ,  hzp.contact_point_id;

BEGIN

  OPEN  contact_cursor;
        LOOP
        l_loop_count := l_loop_count + 1;
           FETCH contact_cursor 
            INTO l_Phone_Country_Code
               , l_Phone_Area_Code
               , l_Phone_Number
               , l_Phone_Extension;
              IF contact_cursor%ROWCOUNT = p_Count THEN
                 EXIT;
              ELSIF contact_cursor%NOTFOUND THEN
                 l_Phone_Country_Code := NULL;
                 l_Phone_Area_Code    := NULL;
                 l_Phone_Number       := NULL;
                 l_Phone_Extension    := NULL;
                 EXIT;
              ELSIF l_loop_count = p_Count THEN
                 EXIT;
            END IF;
        END LOOP;

  CLOSE contact_cursor;

  p_Phone_Country_Code := l_Phone_Country_Code;
  p_Phone_Area_Code    := l_Phone_Area_Code;
  p_Phone_Number       := l_Phone_Number;
  p_Phone_Extension    := l_Phone_Extension;

END;

END XXHA_BT_CONTACT;
/
