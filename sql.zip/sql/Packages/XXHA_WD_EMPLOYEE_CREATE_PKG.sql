create or replace PACKAGE XXHA_WD_EMPLOYEE_CREATE_PKG AUTHID CURRENT_USER AS 

/************************************************************************************************************************
* Package Name : XXHA_WD_EMPLOYEE_CREATE_PKG                                                                            *
* Purpose      : This Package will process New Employee Records created by Workday.                                     *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*              : XXHA_CHECK_FOR_NON_NUMERIC                                                                             *
*              : XXHA_BACKUP_DATA                                                                                       *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        20-FEB-2018     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

   PROCEDURE XXHA_PROCESS_DATA(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2);

   PROCEDURE XXHA_CHECK_FOR_NON_NUMERIC(
             p_Value_In        IN  VARCHAR2
            ,p_Value_Out       OUT VARCHAR2);

   PROCEDURE XXHA_BACKUP_DATA(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2);

END XXHA_WD_EMPLOYEE_CREATE_PKG;