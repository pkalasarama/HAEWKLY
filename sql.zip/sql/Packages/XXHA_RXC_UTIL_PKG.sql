CREATE OR REPLACE PACKAGE        "XXHA_RXC_UTIL_PKG"
/*****************************************************************************************
* Name/Purpose : XXHA_RXC_UTIL_PKG							 *
* Description  : Creates Custom Package Specification that will trigger Outbound ASN     *
*                for COVINA shipments and Cancel Orders on an 860                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     Nandu Vellal         Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
AS
  v_global_seq NUMBER := 0;

  PROCEDURE DEBUG_LOG(pi_loc IN VARCHAR2);

  PROCEDURE DEBUG_LOG(pi_transaction_type IN VARCHAR2, pi_loc IN VARCHAR2);

  PROCEDURE COMMIT_ORDERS;

  PROCEDURE GET_USER_ID(pi_user_name IN VARCHAR2, po_user_id OUT NUMBER);

  PROCEDURE RAISE_SHIPMENT_EVENT(itemtype in varchar2,itemkey in varchar2,actid in number,funcmode in varchar2, resultout out varchar2);

  PROCEDURE CANCEL_ORDER(p_header_id IN NUMBER, p_resp IN VARCHAR2, p_user IN VARCHAR2, p_reason_code IN VARCHAR2);

END XXHA_RXC_UTIL_PKG;
/


CREATE OR REPLACE PACKAGE BODY        "XXHA_RXC_UTIL_PKG"
/*****************************************************************************************
* Name/Purpose : XXHA_RXC_UTIL_PKG							 *
* Description  : Creates Custom Package Body that will trigger Outbound ASN              *
*                for COVINA shipments and Cancel Orders on an 860                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     Nandu Vellal         Initial Creation                                  *
* 05-FEB-2014     Nandu Vellal         R12 related changes before calling API            *
*                                                                                        *
*****************************************************************************************/
AS
PROCEDURE DEBUG_LOG(pi_loc IN VARCHAR2)
AS
BEGIN
    v_global_seq := v_global_seq + 1;
    INSERT INTO haemo.xxha_edi_log VALUES(v_global_seq, 'GENERIC', pi_loc, SYSDATE, FND_GLOBAL.USER_ID, SYSDATE, FND_GLOBAL.USER_ID);
EXCEPTION
   WHEN OTHERS THEN
      NULL;
END;
PROCEDURE DEBUG_LOG(pi_transaction_type IN VARCHAR2, pi_loc IN VARCHAR2)
AS
BEGIN
    v_global_seq := v_global_seq + 1;
    INSERT INTO haemo.xxha_edi_log VALUES(v_global_seq, pi_transaction_type, pi_loc, SYSDATE, FND_GLOBAL.USER_ID, SYSDATE, FND_GLOBAL.USER_ID);
    DELETE FROM haemo.xxha_edi_log WHERE creation_date < (SYSDATE - 30);
EXCEPTION
   WHEN OTHERS THEN
      NULL;
END;
PROCEDURE COMMIT_ORDERS
AS
BEGIN
    COMMIT;
END;
PROCEDURE GET_USER_ID(pi_user_name IN VARCHAR2, po_user_id OUT NUMBER)
AS
   v_user_id NUMBER;
BEGIN
   SELECT user_id INTO v_user_id FROM FND_USER WHERE user_name = pi_user_name;
   po_user_id := v_user_id;
EXCEPTION
   WHEN OTHERS THEN
      po_user_id := 0;  --sysadmin
END;
PROCEDURE RAISE_SHIPMENT_EVENT(itemtype in varchar2,itemkey in varchar2,actid in number,funcmode in varchar2,resultout out varchar2)
AS
   v_resultout 		VARCHAR2(100) := NULL;
   v_oe_line_id 	NUMBER;
   v_xml_doc		CLOB;
   v_event_key		VARCHAR2(30);
   v_message		VARCHAR2(4000);
   retcode		pls_integer;
   errmsg		varchar2(2000);
   logfile		varchar2(200);
   v_tp_party_site_id	NUMBER;
   v_parameter_list     wf_parameter_list_t := wf_parameter_list_t();
   CURSOR ship_cur(p_line_id IN NUMBER) IS
   SELECT wnd.delivery_id, wnd.asn_status_code, wnd.asn_date_sent, wnd.asn_seq_number, xdl.party_id, xdl.party_site_id, xdl.organization_id
      FROM wsh_new_deliveries wnd, xxha_rxc_edi_delivery_lines_v xdl
     WHERE wnd.delivery_id = xdl.delivery_id
       AND xdl.source_line_id = p_line_id
       AND wnd.asn_status_code IS NULL
       FOR UPDATE OF wnd.asn_status_code;
BEGIN
   v_oe_line_id := TO_NUMBER(itemkey);
   XXHA_RXC_UTIL_PKG.v_global_seq := TO_CHAR(sysdate,'DDMMYYHHMMSS');
   v_tp_party_site_id := NULL;
   --Raise Event only if party_site_id is enabled for EDI 856 Outbound in XML Gateway
   --ecx_debug.pl(0, '856OUT: '||'Raise Event for Itemkey:'||itemkey);
   XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Raise Event for Itemtype:'||itemtype);
   XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Raise Event for Itemkey:'||itemkey);
   XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Raise Event for Activity ID:'||actid);
   XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Raise Event for Function Mode:'||funcmode);
      FOR ship_rec IN ship_cur(v_oe_line_id)
      LOOP
   	   --ecx_debug.pl(0, '856OUT: '||'Delivery ID:'||ship_rec.delivery_id);
   	   --ecx_debug.pl(0, '856OUT: '||'Party Site ID:'||ship_rec.party_site_id);
   	   XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Delivery ID:'||ship_rec.delivery_id);
   	   XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Party Site ID:'||ship_rec.party_site_id);
           --Validate Trading Partner
	   BEGIN
	     SELECT eth.party_site_id
	       INTO v_tp_party_site_id
	       FROM ecx_ext_processes eep, ecx_transactions et, ecx_standards es, ecx_tp_details etd, ecx_tp_headers eth,
	            hr_locations_v hlv
	      WHERE eep.ext_type = 'XXHA'
	        AND eep.ext_subtype = '856OUT'
	        AND et.transaction_type = 'XXHA'
	        AND et.transaction_subtype = '856OUT'
	        AND eep.transaction_id = et.transaction_id
	        AND eep.standard_id = es.standard_id
	        AND es.standard_code = 'XCBL'
	        AND eep.ext_process_id = etd.ext_process_id
	        AND etd.tp_header_id = eth.tp_header_id
	        AND hlv.ece_tp_location_code = etd.source_tp_location_code
	        AND hlv.inventory_organization_id = ship_rec.organization_id
	        AND eth.party_site_id = ship_rec.party_site_id;
	   EXCEPTION
	      WHEN OTHERS THEN
	         v_tp_party_site_id := NULL;
	         XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Trading Partner not defined for Party Site '||ship_rec.party_site_id);
           END;
      IF (v_tp_party_site_id IS NOT NULL)
      THEN
        v_event_key := TO_CHAR(SYSDATE,'DDMMYYYYHHMISS')||TO_CHAR(ship_rec.delivery_id);
        XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Event Key: '||v_event_key);
        IF ( funcmode = 'RUN' ) THEN
           wf_event.AddParameterToList(p_name=>   'ECX_TRANSACTION_TYPE',
                               p_value=>         'XXHA',
                      	       p_parameterlist=> v_parameter_list);
           wf_event.AddParameterToList(p_name=>  'ECX_TRANSACTION_SUBTYPE',
                               p_value=>         '856OUT',
                      	       p_parameterlist=> v_parameter_list);
           wf_event.AddParameterToList(p_name=>  'ECX_PARTY_TYPE',
                               p_value=>         'C',
                      	       p_parameterlist=> v_parameter_list);
           wf_event.AddParameterToList(p_name=>        'ECX_PARTY_ID',
                               p_value=>         ship_rec.party_id,
                      	       p_parameterlist=> v_parameter_list);
           wf_event.AddParameterToList(p_name=>        'ECX_PARTY_SITE_ID',
                               p_value=>         ship_rec.party_site_id,
                      	       p_parameterlist=> v_parameter_list);
           wf_event.AddParameterToList(p_name=>        'ECX_DOCUMENT_ID',
                               p_value=>         ship_rec.delivery_id,
                      	       p_parameterlist=> v_parameter_list);
           wf_event.AddParameterToList(p_name=>        'ECX_MESSAGE_STANDARD',
                                 p_value=>         'XCBL',
                      	         p_parameterlist=> v_parameter_list);
           wf_event.AddParameterToList(p_name=>        'ECX_MAP_CODE',
                                  p_value=>      'XXHA_RxC_856_OUT',
                      	          p_parameterlist=> v_parameter_list);
           --ecx_debug.pl(0, '856OUT: '||'Populated Event Parameters');
           XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Populated Event Parameters');
           v_xml_doc := ECX_STANDARD.generate(p_event_name => 'oracle.apps.xxha.om.shipline.asn',
   				      p_event_key => v_event_key,
   				      p_parameter_list => v_parameter_list);
           --ecx_debug.pl(0, '856OUT: '||'Generated document for Event oracle.apps.xxha.om.shipline.asn');
           XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Generated document for Event oracle.apps.xxha.om.shipline.asn');
           ECX_OUTBOUND.getXML(
   			i_message_standard   => 'XCBL',
   			i_transaction_type   => 'XXHA',
   			i_transaction_subtype  => '856OUT',
   			i_tp_id	 => ship_rec.party_id,
   			i_tp_site_id	=> ship_rec.party_site_id,
   			i_tp_type    => 'Customer',
   			i_document_id	=> ship_rec.delivery_id,
        		i_map_code     => 'XXHA_RxC_856_OUT',
   			i_debug_level	=> 0,
   			i_xmldoc => v_xml_doc,
   			i_message_type   => 'XML',
   			i_ret_code => retcode,
   			i_errbuf => errmsg,
   			i_log_file => logfile);
           --ecx_debug.pl(0, '856OUT: '||'Get XML document for Event oracle.apps.xxha.om.shipline.asn');
           XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Get XML document for Event oracle.apps.xxha.om.shipline.asn');
           wf_event.raise( p_event_name => 'oracle.apps.xxha.om.shipline.asn',
                   p_event_key => v_event_key,
                   p_event_data => v_xml_doc,
                   p_parameters => v_parameter_list);
           --ecx_debug.pl(0, '856OUT: '||'Raised Event oracle.apps.xxha.om.shipline.asn');
           XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Raised Event oracle.apps.xxha.om.shipline.asn');
           v_parameter_list.DELETE;
           resultout := NULL;
        END IF;
        --Update ASN only if it is for a valid XML Gateway TP
        UPDATE wsh_new_deliveries
           SET asn_status_code = 'SENT', asn_date_sent = SYSDATE, asn_seq_number = NVL(ship_rec.asn_seq_number,0)+1
         WHERE CURRENT OF ship_cur;
     END IF;
  END LOOP;
EXCEPTION
   WHEN OTHERS THEN
      --ecx_debug.pl(0,'Did not Raise Event oracle.apps.xxha.om.shipline.asn');
      XXHA_RXC_UTIL_PKG.DEBUG_LOG('856OUT','Did not Raise Event oracle.apps.xxha.om.shipline.asn');
      WF_CORE.CONTEXT ('XXHA_RXC_UTIL_PKG', 'RAISE_SHIPMENT_EVENT',itemtype,itemkey,to_char(actid),funcmode);
END RAISE_SHIPMENT_EVENT;
PROCEDURE CANCEL_ORDER(p_header_id IN NUMBER, p_resp IN VARCHAR2, p_user IN VARCHAR2, p_reason_code IN VARCHAR2)
AS
	 l_header_rec 		OE_ORDER_PUB.Header_Rec_Type;
	 x_header_rec 		OE_ORDER_PUB.Header_Rec_Type;
	 l_line_tbl 		OE_ORDER_PUB.Line_Tbl_Type;
	 x_line_tbl 		OE_ORDER_PUB.Line_Tbl_Type;
	 l_action_request_tbl 	OE_ORDER_PUB.Request_Tbl_Type;
	 l_header_adj_tbl 	OE_ORDER_PUB.Header_Adj_Tbl_Type;
	 l_line_adj_tbl 	OE_ORDER_PUB.line_adj_tbl_Type;
	 l_header_scr_tbl 	OE_ORDER_PUB.Header_Scredit_Tbl_Type;
	 l_line_scredit_tbl 	OE_ORDER_PUB.Line_Scredit_Tbl_Type;
	 l_return_status 	VARCHAR2(1000);
	 l_msg_count 		NUMBER;
	 l_msg_data 		VARCHAR2(1000);
	 p_api_version_number 	NUMBER :=1.0;
	 p_init_msg_list 	VARCHAR2(10) := FND_API.G_FALSE;
	 p_return_values 	VARCHAR2(10) := FND_API.G_FALSE;
	 p_action_commit 	VARCHAR2(10) := FND_API.G_FALSE;
	 x_return_status 	VARCHAR2(1);
	 x_msg_count 		NUMBER;
	 x_msg_data 		VARCHAR2(100);
	 p_action_request_tbl 	OE_ORDER_PUB.Request_Tbl_Type :=  oe_order_pub.G_MISS_REQUEST_TBL;
	 x_header_val_rec 	OE_ORDER_PUB.Header_Val_Rec_Type;
	 x_Header_Adj_tbl 	OE_ORDER_PUB.Header_Adj_Tbl_Type;
	 x_Header_Adj_val_tbl 	OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
	 x_Header_price_Att_tbl OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
	 x_Header_Adj_Att_tbl 	OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
	 x_Header_Adj_Assoc_tbl OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
	 x_Header_Scredit_tbl 	OE_ORDER_PUB.Header_Scredit_Tbl_Type;
	 x_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
	 x_line_val_tbl 	OE_ORDER_PUB.Line_Val_Tbl_Type;
	 x_Line_Adj_tbl 	OE_ORDER_PUB.Line_Adj_Tbl_Type;
	 x_Line_Adj_val_tbl 	OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
	 x_Line_price_Att_tbl 	OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
	 x_Line_Adj_Att_tbl 	OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
	 x_Line_Adj_Assoc_tbl 	OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
	 x_Line_Scredit_tbl 	OE_ORDER_PUB.Line_Scredit_Tbl_Type;
	 x_Line_Scredit_val_tbl OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
	 x_Lot_Serial_tbl 	OE_ORDER_PUB.Lot_Serial_Tbl_Type;
	 x_Lot_Serial_val_tbl 	OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type;
	 x_action_request_tbl 	OE_ORDER_PUB.Request_Tbl_Type;
	 X_DEBUG_FILE 		VARCHAR2(100);
	 l_msg_index_out 	NUMBER(10);
	 v_user_id		NUMBER;
	 v_appl_id		NUMBER;
	 v_resp_id 		NUMBER;
BEGIN
 Dbms_Output.Enable(1000000);
 debug_log('860','BEGIN');
   BEGIN
      SELECT user_id INTO v_user_id FROM fnd_user WHERE user_name = NVL(p_user, 'WEBMETHODS');
   EXCEPTION
      WHEN OTHERS THEN
      	RAISE_APPLICATION_ERROR(-20000, 'Error deriving user id for user '||p_user, TRUE);
   END;

   debug_log('860','User Id: '||v_user_id);
   BEGIN
   	SELECT application_id, responsibility_id INTO v_appl_id, v_resp_id
   	  FROM fnd_responsibility_tl
   	 WHERE responsibility_name = NVL(p_resp, 'US Order Management Super User OC')
   	   AND language = 'US';
   EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20001, 'Error deriving responsibility id for responsibility '||p_resp, TRUE);
   End;


   Debug_Log('860','Resp ID: '||V_Resp_Id);
   Fnd_Global.Apps_Initialize(V_User_Id, V_Resp_Id, V_Appl_Id); -- pass in  user_id,responsibility_id, and application_id
   Mo_Global.Init('ONT');  -- R12 related changes
   --Fnd_Request.Set_Org_Id(Fnd_Global.Org_Id) ;
   MO_GLOBAL.set_policy_context('S',Fnd_Global.Org_Id); -- R12 related changes
 	 Oe_Msg_Pub.Initialize;

   Debug_Log('860','ORG ID: '||Fnd_Global.Org_Id);
   Oe_Debug_Pub.Initialize;
   Oe_Debug_Pub.Debug_On;
 	 X_Debug_File := Oe_Debug_Pub.Set_Debug_Mode('FILE');
 	 Oe_Debug_Pub.Setdebuglevel(1); -- Use 5 for the most debuging output, I warn  you its a lot of data

   Oe_Debug_Pub.Add('Start Debug in File: '||X_Debug_File,1);
   Oe_Debug_Pub.Add('Directory name '||Oe_Debug_Pub.G_Dir,1);
   oe_debug_pub.add('File name '||OE_DEBUG_PUB.G_FILE,1);

   debug_log('860','START OF NEW DEBUG in File: '||X_Debug_File);
	--This is to cancel an order
	-- Initialize the record to missing
	 l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
	 l_header_rec.header_id := p_header_id;
	 L_Header_Rec.Cancelled_Flag := 'Y';
	 l_header_rec.change_reason := p_reason_code;  --haemonetics default
	 L_Header_Rec.Operation := Oe_Globals.G_Opr_Update;

   Oe_Debug_Pub.Add('Operation '||Oe_Globals.G_Opr_Update,1);
   oe_debug_pub.add('Change Reason '||p_reason_code,1);
   Debug_Log('860','Reason Code '||P_Reason_Code);
   debug_log('860','Header ID '||p_header_id);
	-- Call To Process Order API
 	OE_ORDER_PUB.process_order (
  		P_Api_Version_Number => 1.0
      ,p_org_id => fnd_global.org_id
  		,p_init_msg_list => fnd_api.g_false
  		,p_return_values => fnd_api.g_false
  		,p_action_commit => fnd_api.g_false
  		,x_return_status => l_return_status
  		,x_msg_count => l_msg_count
  		,x_msg_data => l_msg_data
  		,p_header_rec => l_header_rec
  		,p_line_tbl => l_line_tbl
  		,p_action_request_tbl => l_action_request_tbl
		-- OUT PARAMETERS
  		,x_header_rec => x_header_rec
  		,x_header_val_rec => x_header_val_rec
  		,x_Header_Adj_tbl => x_Header_Adj_tbl
  		,x_Header_Adj_val_tbl => x_Header_Adj_val_tbl
  		,x_Header_price_Att_tbl => x_Header_price_Att_tbl
  		,x_Header_Adj_Att_tbl => x_Header_Adj_Att_tbl
  		,x_Header_Adj_Assoc_tbl => x_Header_Adj_Assoc_tbl
  		,x_Header_Scredit_tbl => x_Header_Scredit_tbl
  		,x_Header_Scredit_val_tbl => x_Header_Scredit_val_tbl
  		,x_line_tbl => x_line_tbl
  		,x_line_val_tbl => x_line_val_tbl
  		,x_Line_Adj_tbl => x_Line_Adj_tbl
  		,x_Line_Adj_val_tbl => x_Line_Adj_val_tbl
  		,x_Line_price_Att_tbl => x_Line_price_Att_tbl
  		,x_Line_Adj_Att_tbl => x_Line_Adj_Att_tbl
  		,x_Line_Adj_Assoc_tbl => x_Line_Adj_Assoc_tbl
  		,x_Line_Scredit_tbl => x_Line_Scredit_tbl
  		,x_Line_Scredit_val_tbl => x_Line_Scredit_val_tbl
  		,x_Lot_Serial_tbl => x_Lot_Serial_tbl
  		,x_Lot_Serial_val_tbl => x_Lot_Serial_val_tbl
  		,x_action_request_tbl => x_action_request_tbl);
 	FOR i IN 1 .. l_msg_count
 	LOOP
  		Oe_Msg_Pub.get( p_msg_index => i
   				,p_encoded => Fnd_Api.G_FALSE
   				,p_data => l_msg_data
   				,p_msg_index_out => l_msg_index_out
  				);

      Debug_Log('860',L_Msg_Data);
      oe_debug_pub.add('Error Message '||L_Msg_Data,1);
 	END LOOP;
	--Check the return status
 	IF l_return_status = FND_API.G_RET_STS_SUCCESS
 	Then
  		Dbms_Output.Put_Line('Process order Success');
      Debug_Log('860','Order Cancellation Success');
      Oe_Debug_Pub.Add('Order Cancelled',1);
      commit;
 	ELSE
  		Dbms_Output.Put_Line('Failed');
      Oe_Debug_Pub.Add('Order NOT Cancelled',1);
      rollback;
 	END IF;
	--debug output
 	dbms_output.put_line('Debug Output');
 	FOR i in 1..OE_DEBUG_PUB.g_debug_count
 	LOOP
  		dbms_output.put_line(OE_DEBUG_PUB.G_debug_tbl(i));
 	End Loop;
 	--COMMIT;
END CANCEL_ORDER;
End Xxha_Rxc_Util_Pkg;
/
