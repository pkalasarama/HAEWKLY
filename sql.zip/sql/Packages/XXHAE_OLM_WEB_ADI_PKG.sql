CREATE OR REPLACE PACKAGE      xxhae_olm_web_adi_pkg
AS
--
-- ================================================================
-- Description: This package has been created for OLM Web ADI
--
--
-- Revision History:
-- Date        Author                 Change Description
-- ----------- --------------         -------------------------------------
-- 27-JUL-2011 Hmirchandani(KBACE)    Initial Version.
--
-- ================================================================
   FUNCTION get_person_bg_id (cp_person_id NUMBER, cp_effective_date DATE)
      RETURN NUMBER;

--
   PROCEDURE get_person_asg_dtl (
      p_person_id              NUMBER,
      p_effective_date         DATE,
      p_asg_id           OUT   NUMBER
      --,p_org_id           OUT   NUMBER
   );

--
   PROCEDURE enroll_learner_in_class (
      p_employee_name       IN       VARCHAR2,
      p_employee_number     IN       VARCHAR2,
      p_course_name         IN       VARCHAR2,
      p_class_name          IN       VARCHAR2,
      p_enrollment_status   IN       VARCHAR2
   );

--
--
   PROCEDURE course_offering_class_creation (
      p_course_name                IN   VARCHAR2,
      p_course_code                IN   VARCHAR2,
      p_sponsor                    IN   VARCHAR2 DEFAULT 'BG_US',
      p_course_start_date          IN   DATE,
      p_course_end_date            IN   DATE,
      p_course_category            IN   VARCHAR2,
      p_offering_name              IN   VARCHAR2,
      p_offering_learning_object   IN   VARCHAR2,
      p_offering_start_date        IN   DATE,
      p_offering_end_date          IN   DATE,
      p_delivery_mode              IN   VARCHAR2,
      p_language                   IN   VARCHAR2 DEFAULT 'English',
      p_show_toolbar               IN   VARCHAR2 DEFAULT 'Y',
      p_new_window                 IN   VARCHAR2 DEFAULT 'Y',
      p_next                       IN   VARCHAR2 DEFAULT 'N',
      p_exit                       IN   VARCHAR2 DEFAULT 'Y',
      p_outline                    IN   VARCHAR2 DEFAULT 'Y',
      p_previous                   IN   VARCHAR2 DEFAULT 'N',
      p_class_title                IN   VARCHAR2,
      p_status                     IN   VARCHAR2,
      p_class_start_date           IN   DATE,
      p_class_end_date             IN   DATE,
      p_class_start_time           IN   VARCHAR2,
      p_class_end_time             IN   VARCHAR2,
      p_duration                   IN   VARCHAR2,
      p_duration_unit              IN   VARCHAR2,
      p_time_zone                  IN   VARCHAR2,
      p_enrollment_start_date      IN   DATE,
      p_enrollment_end_date        IN   DATE,
      p_minimum_attendees          IN   NUMBER,
      p_maximum_attendees          IN   NUMBER,
      p_restricted                 IN   VARCHAR2 DEFAULT 'Y',
      p_secure                     IN   VARCHAR2
   );
--
END;
/


CREATE OR REPLACE PACKAGE BODY      xxhae_olm_web_adi_pkg
AS
--
-- ================================================================
-- Description: This package has been created for OLM Web ADI
--
--
-- Revision History:
-- Date        Author                 Change Description
-- ----------- --------------         -------------------------------------
-- 27-JUL-2011 Hmirchandani(KBACE)    Initial Version.
--
-- ================================================================
--******************************************************************************
-- Procedure get_person_bg_id
--
-- Description: Get the Business Group Id of person
--******************************************************************************
   FUNCTION get_person_bg_id (cp_person_id NUMBER, cp_effective_date DATE)
      RETURN NUMBER
   IS
--
      l_procedure   VARCHAR2 (40) := 'get_person_bg_id';
--
      ln_retval     NUMBER;
--
   BEGIN
--
      SELECT business_group_id
        INTO ln_retval
        FROM per_all_people_f ppf
       WHERE cp_effective_date BETWEEN ppf.effective_start_date
                                   AND ppf.effective_end_date
         AND ppf.person_id = cp_person_id;

      --
      RETURN ln_retval;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

--
--
--******************************************************************************
-- Procedure get_person_asg_dtl
--
-- Description: Gets the asisgnment details of the person for enrollment
--******************************************************************************
--
   PROCEDURE get_person_asg_dtl (
      p_person_id              NUMBER,
      p_effective_date         DATE,
      p_asg_id           OUT   NUMBER
      --,p_org_id           OUT   NUMBER
   )
   IS
--
      CURSOR c_asg_dtl
      IS
         SELECT asg.assignment_id
               --, asg.organization_id
           FROM per_all_assignments_f asg
          WHERE asg.person_id = p_person_id
            AND p_effective_date BETWEEN asg.effective_start_date
                                     AND asg.effective_end_date
            AND asg.assignment_type = 'E'
            AND asg.primary_flag = 'Y';

--
      l_procedure   VARCHAR2 (40) := 'get_person_asg_dtl';
--
   BEGIN
      --
      OPEN c_asg_dtl;

      FETCH c_asg_dtl
       INTO p_asg_id;
       --, p_org_id;

      CLOSE c_asg_dtl;
   --
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   --
   END get_person_asg_dtl;

--
--
--
--******************************************************************************
-- Procedure enroll_learner_in_class
--
-- Description: Enroll learner in class
--******************************************************************************
   PROCEDURE enroll_learner_in_class (
      p_employee_name       IN       VARCHAR2,
      p_employee_number     IN       VARCHAR2,
      p_course_name         IN       VARCHAR2,
      p_class_name          IN       VARCHAR2,
      p_enrollment_status   IN       VARCHAR2
   )
   IS
--
--
      CURSOR learner_id_cur (cp_employee_number varchar2)
      IS
         SELECT person_id
           FROM per_all_people_f ppf
          WHERE ppf.employee_number = cp_employee_number
            AND TRUNC (SYSDATE) BETWEEN ppf.effective_start_date
                                    AND ppf.effective_end_date;
--
      CURSOR event_id_cur (cp_course_name varchar2, cp_class_name varchar2)
      IS
         SELECT evt.event_id event_id,
                evt.business_group_id business_group_id,
                evt.organization_id organization_id 
           FROM ota_events_vl evt,
                ota_offerings_vl OFF,
                ota_activity_versions_vl course
          WHERE evt.parent_offering_id = OFF.offering_id
            AND course.activity_version_id = OFF.activity_version_id
            AND course.activity_version_id = evt.activity_version_id
            AND evt.title = cp_class_name
            AND course.version_name = cp_course_name;
      --
      CURSOR enroll_status_cur (cp_event_id IN NUMBER, cp_learner_id IN NUMBER)
      IS
         SELECT UPPER (bst.NAME) enrollment_status, tdb.booking_id,
                tdb.object_version_number
           FROM ota_delegate_bookings tdb, ota_booking_status_types_vl bst
          WHERE tdb.booking_status_type_id = bst.booking_status_type_id
            AND tdb.event_id = cp_event_id
            AND tdb.delegate_person_id = cp_learner_id
            AND UPPER (bst.NAME) IN ('ATTENDED', 'ENROLLED');
--
--
      CURSOR get_placed_status_type_id_cur (
         cp_business_group_id        NUMBER,
         cp_name                IN   VARCHAR2
      )
      IS
         SELECT booking_status_type_id
           FROM ota_booking_status_types obst
          WHERE UPPER (NAME) = upper(cp_name)
            AND business_group_id = cp_business_group_id
            AND obst.active_flag = 'Y';

      --
      --
      l_learner_id               NUMBER;
      l_event_id                 NUMBER;
--
      l_enroll_status            ota_booking_status_types_vl.NAME%TYPE;
      l_assignment_id            per_all_assignments_f.assignment_id%TYPE;
      l_org_id                   per_all_assignments_f.organization_id%TYPE;
      l_business_group_id        per_all_assignments_f.business_group_id%TYPE;
      l_object_version_number    NUMBER;
      l_booking_id               NUMBER;
      l_finance_line_id          NUMBER;
      l_booking_status_type_id   NUMBER;
      l_tdb_obj_number           NUMBER;
      l_tfl_number               NUMBER;
      l_step                     number;
   BEGIN
      --
      execute immediate 'alter session set nls_language = ''AMERICAN'' NLS_TERRITORY = ''AMERICA''';
      --
      l_step := 10;
      -- fetch learner id
      l_learner_id := NULL;
      l_event_id := NULL;
      l_enroll_status := NULL;
      l_booking_status_type_id := NULL;
      l_booking_id := NULL;
      l_object_version_number := NULL;
      l_tdb_obj_number := NULL;
      l_finance_line_id := NULL;
      l_tfl_number := NULL;

      l_step := 20;
      --
      if p_employee_name is not null then
        begin
          SELECT person_id
            INTO l_learner_id
            FROM per_all_people_f ppf
           WHERE ppf.full_name = p_employee_name
             AND TRUNC (SYSDATE) BETWEEN ppf.effective_start_date
                                    AND ppf.effective_end_date;
        exception 
          when too_many_rows then
            null;
          when no_data_found then
            null;
        end;
      end if;
      --
      if l_learner_id is null then
        OPEN learner_id_cur (p_employee_number);
        FETCH learner_id_cur
        INTO l_learner_id;

        IF learner_id_cur%NOTFOUND
        THEN
           l_learner_id := NULL;
        END IF;

        CLOSE learner_id_cur;
      end if;
      --
      if l_learner_id is null then
        raise_application_error(-20001,'Unable to find employee');
      end if;
      --
      -- fetch event_id
      l_event_id := NULL;

      l_step := 30;
      --
      OPEN event_id_cur (p_course_name, p_class_name);
      FETCH event_id_cur 
       INTO l_event_id, l_business_group_id, l_org_id;

      IF event_id_cur%NOTFOUND
      THEN
         l_event_id := NULL;
      END IF;

      CLOSE event_id_cur;
      --
      if l_event_id is null then
        raise_application_error(-20001,'Unable to find class and course combination in application');
      end if;
      --
      l_enroll_status := NULL;

      l_step := 40;
      --
      OPEN enroll_status_cur (l_event_id, l_learner_id);

      FETCH enroll_status_cur
       INTO l_enroll_status, l_booking_id, l_tdb_obj_number;

      IF enroll_status_cur%NOTFOUND
      THEN
         l_enroll_status := NULL;
      END IF;

      CLOSE enroll_status_cur;
      --
      l_step := 50;
      --
      --l_business_group_id := get_person_bg_id (l_learner_id, TRUNC (SYSDATE));
      --
      -- fetch learner assignment detail
      get_person_asg_dtl (l_learner_id,
                          TRUNC (SYSDATE),
                          l_assignment_id
                          --,l_org_id
                         );
      l_booking_status_type_id := NULL;

      l_step := 60;
      --
      OPEN get_placed_status_type_id_cur (l_business_group_id,
                                          UPPER (p_enrollment_status)
                                         );

      FETCH get_placed_status_type_id_cur
       INTO l_booking_status_type_id;

      IF get_placed_status_type_id_cur%NOTFOUND
      THEN
         l_booking_status_type_id := NULL;
      END IF;

      CLOSE get_placed_status_type_id_cur;

      -- dbms_output.put_line('l_enrol:'||l_enroll_status||' '||p_enrollment_status);
      l_step := 70;
      --
      IF l_enroll_status = 'ATTENDED'
      THEN
         -- set enrollment status to complete . No need to proceed further.
         raise_application_error(-20001,'The class has been already completed by learner');
      ELSIF l_enroll_status = 'ENROLLED'
      THEN
        l_step := 80;
        --
         IF UPPER (p_enrollment_status) <> l_enroll_status
         THEN
            -- update the existing enrollment
            --
            DBMS_OUTPUT.put_line ('calling update api '||l_assignment_id);
            ota_tdb_api_upd2.update_enrollment
                       (p_booking_id                     => l_booking_id,
                        p_booking_status_type_id         => l_booking_status_type_id,
                        p_delegate_person_id             => l_learner_id,
                        p_contact_id                     => NULL,
                        p_business_group_id              => l_business_group_id,
                        p_event_id                       => l_event_id,
                        --p_date_booking_placed          => TRUNC(SYSDATE),
                        p_internal_booking_flag          => 'Y',
                        p_number_of_places               => 1,
                        p_object_version_number          => l_tdb_obj_number,
                        p_date_status_changed            => TRUNC (SYSDATE),
                        p_tfl_object_version_number      => l_tfl_number,
                        p_finance_line_id                => l_finance_line_id
                       );
         END IF;
      ELSE
         -- no enrollment found. upload record AS IS
         l_step := 90;
         --
         DBMS_OUTPUT.put_line ('calling create api '||l_assignment_id);
         ota_tdb_api_ins2.create_enrollment
                       (p_booking_id                  => l_booking_id,
                        p_booking_status_type_id      => l_booking_status_type_id,
                        p_delegate_person_id          => l_learner_id,
                        p_contact_id                  => NULL,
                        p_business_group_id           => l_business_group_id,
                        p_event_id                    => l_event_id,
                        p_date_booking_placed         => TRUNC (SYSDATE),
                        p_internal_booking_flag       => 'Y',
                        p_number_of_places            => 1,
                        p_object_version_number       => l_object_version_number,
                        p_finance_line_id             => l_finance_line_id,
                        p_enrollment_type             => 'S',
                        p_validate                    => FALSE,
                        p_organization_id             => l_org_id,
                        p_delegate_assignment_id      => l_assignment_id
                       );
      --
      END IF;                                       -- passed in enroll status
      --
      COMMIT;
      --
   EXCEPTION
     when others then 
        raise_application_error(-20001,'Error in step '||l_step||':'||l_booking_status_type_id||':'||l_learner_id||':'||
                                                         l_business_group_id||':'||l_event_id||':'||l_org_id||':'|| 
                                                         l_assignment_id||':'||sqlerrm);
        raise_application_error(-20001,'Error in step '||l_step||': '||sqlerrm);
   END;

--
--
--******************************************************************************
-- Procedure : course_offering_creation
--
-- Description: Creates course and offering
--******************************************************************************
   PROCEDURE course_offering_class_creation (
      p_course_name                IN   VARCHAR2,
      p_course_code                IN   VARCHAR2,
      p_sponsor                    IN   VARCHAR2 DEFAULT 'BG_US',
      p_course_start_date          IN   DATE,
      p_course_end_date            IN   DATE,
      p_course_category            IN   VARCHAR2,
      p_offering_name              IN   VARCHAR2,
      p_offering_learning_object   IN   VARCHAR2,
      p_offering_start_date        IN   DATE,
      p_offering_end_date          IN   DATE,
      p_delivery_mode              IN   VARCHAR2,
      p_language                   IN   VARCHAR2 DEFAULT 'English',
      p_show_toolbar               IN   VARCHAR2 DEFAULT 'Y',
      p_new_window                 IN   VARCHAR2 DEFAULT 'Y',
      p_next                       IN   VARCHAR2 DEFAULT 'N',
      p_exit                       IN   VARCHAR2 DEFAULT 'Y',
      p_outline                    IN   VARCHAR2 DEFAULT 'Y',
      p_previous                   IN   VARCHAR2 DEFAULT 'N',
      p_class_title                IN   VARCHAR2,
      p_status                     IN   VARCHAR2,
      p_class_start_date           IN   DATE,
      p_class_end_date             IN   DATE,
      p_class_start_time           IN   VARCHAR2,
      p_class_end_time             IN   VARCHAR2,
      p_duration                   IN   VARCHAR2,
      p_duration_unit              IN   VARCHAR2,
      p_time_zone                  IN   VARCHAR2,
      p_enrollment_start_date      IN   DATE,
      p_enrollment_end_date        IN   DATE,
      p_minimum_attendees          IN   NUMBER,
      p_maximum_attendees          IN   NUMBER,
      p_restricted                 IN   VARCHAR2 DEFAULT 'Y',
      p_secure                     IN   VARCHAR2
   )
   IS
--
--
      CURSOR bg_cur (cp_name varchar2)
      IS
         SELECT organization_id, business_group_id
           FROM hr_all_organization_units
          WHERE UPPER (NAME) = UPPER (cp_name);
--
      CURSOR course_exists_cur (cp_course_name varchar2)
      IS
         SELECT activity_version_id
           FROM ota_activity_versions
          WHERE UPPER (version_name) = UPPER (cp_course_name);
--
      CURSOR course_cat_cur (cp_bg_id IN NUMBER, cp_course_category varchar2)
      IS
         SELECT activity_id, b.category_usage_id
           FROM ota_activity_definitions a, ota_category_usages b
          WHERE a.category_usage_id = b.category_usage_id
            AND a.business_group_id = cp_bg_id
            AND UPPER (b.CATEGORY) = UPPER (cp_course_category);
--
      CURSOR lang_cur (cp_language varchar2)
      IS
        select lang.language_id, ota_lang.language_code
        from ota_natural_languages_v ota_lang
            ,fnd_languages lang
        WHERE upper(ota_lang.iso_language_3) = upper(lang.iso_language_3(+))
          and nvl(ota_lang.iso_territory,'X') = nvl(lang.iso_territory(+),'X')
          and ota_lang.enabled_flag = 'Y'
          and upper(ota_lang.name) = upper(cp_language);
--
      CURSOR offering_exist_cur (cp_offering_name varchar2, cp_activity_version_id number)
      IS
         SELECT offering_id, delivery_mode_id
           FROM ota_offerings_vl
          WHERE UPPER (NAME) = UPPER (cp_offering_name)
            AND activity_version_id = cp_activity_version_id;
--
      CURSOR learning_object_cur (cp_bg_id IN NUMBER, cp_offering_learning_object varchar2)
      IS
         SELECT learning_object_id
           FROM ota_learning_objects
          WHERE UPPER (NAME) = UPPER (cp_offering_learning_object)
            AND business_group_id = cp_bg_id;
--
      CURSOR delivery_mode_cur (cp_bg_id IN NUMBER, cp_delivery_mode varchar2)
      IS
         SELECT category_usage_id, synchronous_flag
           FROM ota_category_usages
          WHERE business_group_id = cp_bg_id
            AND TYPE = 'DM'
            AND UPPER (CATEGORY) = UPPER (p_delivery_mode);
--
      CURSOR delivery_mode_cur2 (cp_delivery_mode_id number)
      IS
         SELECT synchronous_flag
           FROM ota_category_usages
          WHERE category_usage_id = cp_delivery_mode_id;
--
      CURSOR event_exist_cur (cp_class_title varchar2)
      IS
         SELECT event_id
           FROM ota_events_vl
          WHERE UPPER (title) = UPPER (cp_class_title);
--
      CURSOR timezone_cur (cp_timezone varchar2)
      IS
         SELECT timezone_code
           FROM fnd_timezones_vl
          WHERE UPPER (name) = UPPER (cp_timezone);
--
      l_bg_id                     hr_all_organization_units.business_group_id%TYPE;
      l_org_id                    hr_all_organization_units.organization_id%TYPE;
      l_category_usage_id         ota_category_usages.category_usage_id%TYPE;
      l_synchronous_flag          ota_category_usages.synchronous_flag%TYPE;
      l_activity_id               ota_activity_definitions.activity_id%TYPE;
      l_language_id               fnd_languages_vl.language_id%TYPE;
      l_language_code             fnd_languages_vl.language_code%TYPE;
      l_activity_version_id       ota_activity_versions.activity_version_id%TYPE;
      l_offering_id               ota_offerings_vl.offering_id%TYPE;
      l_learning_object_id        ota_learning_objects.learning_object_id%TYPE;
      l_event_id                  ota_events.event_id%TYPE;
      l_event_type                ota_events.event_type%TYPE;
      l_timezone_code             fnd_timezones_vl.timezone_code%TYPE;
      l_act_ver_obj_number        NUMBER;
      l_offering_version_number   NUMBER;
      l_class_version_number      NUMBER;
      l_delivery_mode_id          NUMBER;
      l_sponsor                   hr_all_organization_units.name%type;
      l_player_toolbar_bitset     ota_offerings.player_toolbar_bitset%type;
--
   BEGIN
      -- fetch business group id
      l_org_id := NULL;
      l_bg_id := NULL;
      l_act_ver_obj_number := NULL;
      --
      if rtrim(ltrim(p_sponsor)) = '' or p_sponsor is null then
        l_sponsor := 'BG_US';
      else 
        l_sponsor := p_sponsor;
      end if;
      --
      l_player_toolbar_bitset := 0;
      --
      if nvl(p_exit,'Y') = 'Y' then
        l_player_toolbar_bitset := l_player_toolbar_bitset + 1;
      end if;
      --
      if nvl(p_previous,'N') = 'Y' then
        l_player_toolbar_bitset := l_player_toolbar_bitset + 2;
      end if;
      --
      if nvl(p_next,'N') = 'Y' then
        l_player_toolbar_bitset := l_player_toolbar_bitset + 4;
      end if;
      --
      if nvl(p_outline,'Y') = 'Y' then
        l_player_toolbar_bitset := l_player_toolbar_bitset + 1024;
      end if;
      --
      if l_player_toolbar_bitset = 0 then
        l_player_toolbar_bitset := null;
      end if;
      --
      OPEN bg_cur(l_sponsor);
      FETCH bg_cur
       INTO l_org_id, l_bg_id;
      CLOSE bg_cur;
      --
      -- fetch category usage id
      l_category_usage_id := NULL;
      l_activity_id := NULL;

      OPEN course_cat_cur (l_bg_id, p_course_category);
      FETCH course_cat_cur
       INTO l_activity_id, l_category_usage_id;

      IF course_cat_cur%NOTFOUND
      THEN
         l_category_usage_id := NULL;
         l_activity_id := NULL;
      END IF;

      CLOSE course_cat_cur;

      --
      -- check if course already exists.
      l_activity_version_id := NULL;

      --
      OPEN course_exists_cur (p_course_name);
      FETCH course_exists_cur
       INTO l_activity_version_id;

      IF course_exists_cur%NOTFOUND
      THEN
         l_activity_version_id := NULL;
      END IF;

      CLOSE course_exists_cur;

      --
      --
       -- FETCH LANGUAGE ID
      l_language_id := NULL;
      --
      execute immediate 'alter session set nls_language = ''AMERICAN'' NLS_TERRITORY = ''AMERICA''';
      --
      OPEN lang_cur (nvl(p_language,'English'));
      FETCH lang_cur
       INTO l_language_id, l_language_code;
      CLOSE lang_cur;
      --
      if l_language_id is null and l_language_code is null then
        raise_application_error(-20001,'Invalid Language'); 
      end if;
      --
      --dbms_output.put_line('activity id:'||l_activity_version_id);
      IF l_activity_version_id IS NOT NULL
      THEN
         -- course already exists
         -- skip;
         NULL;
      ELSE                                       -- create course and offering
                                                 --
         ota_activity_version_api.create_activity_version
            (p_effective_date                 => p_course_start_date,
             p_validate                       => false,
             p_activity_id                    => l_activity_id,
             p_developer_organization_id      => l_org_id,
             p_version_name                   => p_course_name,
             p_version_code                   => p_course_code,
             p_duration                       => p_duration,
             p_duration_units                 => p_duration_unit,
             p_start_date                     => p_course_start_date,
             p_end_date                       => p_course_end_date,
             p_language_id                    => l_language_id,
             p_maximum_attendees              => p_maximum_attendees,
             p_minimum_attendees              => p_minimum_attendees,
             p_budget_currency_code           => 'USD',
             p_expenses_allowed               => 'N',
             p_business_group_id              => l_bg_id,
             p_activity_version_id            => l_activity_version_id,
             p_object_version_number          => l_act_ver_obj_number
            );
         --
         --
         DBMS_OUTPUT.put_line ('course creation successful');
         --
         ota_activity_category_api.create_act_cat_inclusion
            (p_validate                   => FALSE,
             p_effective_date             => p_course_start_date,
             p_activity_version_id        => l_activity_version_id,
             p_activity_category          => NULL,
             p_object_version_number      => l_act_ver_obj_number,
             p_primary_flag               => 'Y',
             p_category_usage_id          => l_category_usage_id
            );
         --
         DBMS_OUTPUT.put_line ('course category creation successful');
      END IF;

       --
      -- CHECK IF OFFERING EXISTS
      l_offering_id := NULL;

      OPEN offering_exist_cur (p_offering_name, l_activity_version_id);
      FETCH offering_exist_cur
       INTO l_offering_id, l_delivery_mode_id;
      CLOSE offering_exist_cur;

      --
      DBMS_OUTPUT.put_line ('Offereing id is '||l_offering_id);
      IF l_offering_id IS NULL and p_offering_name is not null
      THEN
         -- create offering
         l_delivery_mode_id := NULL;
   
         OPEN delivery_mode_cur (l_bg_id, p_delivery_mode);
         FETCH delivery_mode_cur
          INTO l_delivery_mode_id, l_synchronous_flag;
         CLOSE delivery_mode_cur;
         --
         l_learning_object_id := NULL;

         OPEN learning_object_cur (l_bg_id, p_offering_learning_object);
         FETCH learning_object_cur
          INTO l_learning_object_id;
         CLOSE learning_object_cur;
         --
         ota_offering_api.create_offering
            (p_validate                    => false,
             p_effective_date              => p_offering_start_date,
             p_business_group_id           => l_bg_id,
             p_name                        => p_offering_name,
             p_start_date                  => p_offering_start_date,
             p_activity_version_id         => l_activity_version_id,
             p_end_date                    => p_offering_end_date,
             p_language_id                 => l_language_id,
             p_delivery_mode_id            => l_delivery_mode_id,
             p_learning_object_id          => l_learning_object_id,
             p_player_toolbar_flag         => nvl(p_show_toolbar,'Y'),
             p_player_new_window_flag      => nvl(p_new_window,'Y'),
             p_player_toolbar_bitset       => l_player_toolbar_bitset,
             p_maximum_attendees           => p_maximum_attendees,
             p_minimum_attendees           => p_minimum_attendees,
             p_offering_id                 => l_offering_id,
             p_object_version_number       => l_offering_version_number,
             p_language_code               => l_language_code
            );
         --
         DBMS_OUTPUT.put_line ('offering creation successful');
         DBMS_OUTPUT.put_line ('Offereing id is '||l_offering_id);
      END IF;
      --
      l_event_id := NULL;
      open event_exist_cur (p_class_title);
      fetch event_exist_cur into l_event_id;
      close event_exist_cur;
      --
      -- CREATE CLASS
      DBMS_OUTPUT.put_line ('Event id is '||l_event_id);
      if l_event_id is null and p_class_title is not null then
         DBMS_OUTPUT.put_line ('before class creation');
         --
         --
         if l_synchronous_flag is null and l_delivery_mode_id is not null then
            OPEN delivery_mode_cur2 (l_delivery_mode_id);
            FETCH delivery_mode_cur2
             INTO l_synchronous_flag;
            CLOSE delivery_mode_cur2;
         end if;
         --
         if nvl(l_synchronous_flag,'X') = 'N' then
            l_event_type := 'SELFPACED';
         else
            l_event_type := 'SCHEDULED';
         end if;
         --
         l_timezone_code:= NULL;
         OPEN timezone_cur (p_time_zone);
         FETCH timezone_cur
          INTO l_timezone_code;
         CLOSE timezone_cur;
         --
         ota_event_api.create_class
                           (p_effective_date             => p_class_start_date,
                            p_event_id                   => l_event_id,
                            p_activity_version_id        => l_activity_version_id,
                            p_business_group_id          => l_bg_id,
                            p_organization_id            => l_org_id,
                            p_event_type                 => L_evenT_type,
                            p_object_version_number      => l_class_version_number,
                            p_title                      => p_class_title,
                            p_budget_currency_code       => 'USD',
                            p_course_end_date            => p_class_end_date,
                            p_course_end_time            => p_class_end_time,
                            p_course_start_date          => p_class_start_date,
                            p_course_start_time          => p_class_start_time,
                            p_duration                   => p_duration,
                            p_duration_units             => p_duration_unit,
                            p_enrolment_end_date         => p_enrollment_end_date,
                            p_enrolment_start_date       => p_enrollment_start_date,
                            p_language_id                => l_language_id,
                            p_event_status               => 'N',
                            p_price_basis                => 'N',
                            p_maximum_attendees          => p_maximum_attendees,
                            p_minimum_attendees          => p_minimum_attendees,
                            p_book_independent_flag      => 'N',
                            p_public_event_flag          => nvl(p_restricted,'Y'),
                            p_secure_event_flag          => p_secure,
                            p_timezone                   => l_timezone_code,
                            p_parent_offering_id         => l_offering_id
                           -- ,p_event_availability           => 'ALL'
                            );
         DBMS_OUTPUT.put_line ('class creation successful');
        DBMS_OUTPUT.put_line ('Event id is '||l_event_id);
      end if;
   --
   --
   commit;
   --
   END;
   --
END;
/
