CREATE OR REPLACE PACKAGE xxha_3rdparty_owm_pk IS
 PROCEDURE get_3rdparty_owm(errbuf  OUT VARCHAR2,
                                  retcode OUT NUMBER,
				  p_dist IN VARCHAR2,
                                  p_partial_file IN VARCHAR2,
                                  p_report_date IN VARCHAR2); -- added sept27-2007


--	gc_owm_cust_name VARCHAR2(1000):=	'Owens'||' & '||'Minor';
--	gc_car_cust_name VARCHAR2(1000):=	'Cardinal';
	gc_owm_cust_name VARCHAR2(1000):=	'Owens'||' and '||'Minor';
	gc_car_cust_name VARCHAR2(1000):=	'Cardinal Health Medical Services';
	gn_request_id           NUMBER         :=FND_PROFILE.VALUE('CONC_REQUEST_ID');--Variable to hold Request id
gn_record_number        NUMBER;                                               --Variable to hold Record Number
gc_record_identifier    VARCHAR2(2000);                                       --Variable to hold Record Identifier
gc_err_rec_identifier   VARCHAR2(2000);                                       --Variable to hold Error Record Identifier
gc_error_code           VARCHAR2(2000);                                       --Variable to hold Error Code
gc_error_msg            VARCHAR2(2000);                                       --Variable to hold Error Message
gc_comments             VARCHAR2(2000);                                       --Variable to hold Comments
gc_table_name           VARCHAR2(2000) :=' ';                   --Variable to hold Table Name
gc_attribute1           VARCHAR2(2000);                                       --Variable to hold Attribute1
gc_attribute2           VARCHAR2(2000);                                       --Variable to hold Attribute2
gc_attribute3           VARCHAR2(2000);                                       --Variable to hold Attribute3
gc_attribute4           VARCHAR2(2000);                                       --Variable to hold Attribute4
gc_attribute5           VARCHAR2(2000);                                       --Variable to hold Attribute5
gc_status               VARCHAR2(2000);                                       --Variable to hold Status of the Insertion to Common Error Table
gc_con_name             VARCHAR2(240)  :=' ';         --Variable to hold Concurrent Program Name
gc_identifier           VARCHAR2(240)  :=' ';                    --Variable to hold the Identifier for the Error Report
gc_debug_flag           VARCHAR2(1);                                          --Variable to hold the Debug Flag
gc_log_msg              VARCHAR2(4000);                                       --Variable to hold the log Message
gn_record_id            NUMBER;                                               --Variable to hold the Record Id
gc_status_flag          VARCHAR2(150);                                        --Variable to hold the Status Flag
gc_api_status           VARCHAR2(20);                                         --Variable to hold the API Status
gc_car_xref             VARCHAR2(40)  := 'Cross Ref CAR';
gc_owm_xref             VARCHAR2(40)  := 'Cross Ref OAM';




END xxha_3rdparty_owm_pk;

/


CREATE OR REPLACE PACKAGE BODY xxha_3rdparty_owm_pk IS
--|=============================================================================+
--| Name        :   INSERT_ERROR_PRC                                            |
--|                                                                             |
--| Description :   Procedure to call xxha_common_utilities.insert_error_prc    |
--|                                                                             |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN:    gn_request_id                                                      |
--|          gn_record_number                                                   |
--|          gc_err_rec_identifier                                              |
--|          gc_error_code                                                      |
--|          gc_error_msg                                                       |
--|          gc_comments                                                        |
--|          gc_table_name                                                      |
--|          gc_attribute1                                                      |
--|          gc_attribute2                                                      |
--|          gc_attribute3                                                      |
--|          gc_attribute4                                                      |
--|          gc_attribute5                                                      |
--|  OUT:    gc_status                                                          |
--|                                                                             |
--|  Returns :                                                                  |
--|=============================================================================+
PROCEDURE INSERT_ERROR_PRC
IS
BEGIN
   XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(
                                            gn_request_id
                                           ,gn_record_number
                                           ,gc_err_rec_identifier
                                           ,gc_error_code
                                           ,gc_error_msg
                                           ,gc_comments
                                           ,gc_table_name
                                           ,gc_attribute1
                                           ,gc_attribute2
                                           ,gc_attribute3
                                           ,gc_attribute4
                                           ,gc_attribute5
                                           ,gc_status
                                           );
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC. Error is: '||SQLERRM);
END INSERT_ERROR_PRC;
--+=============================================================================+
--| Name        :    GET_3RDPARTY_OWM                                           |
--|                                                                             |
--| Description :   Procedure to validate and generat TM output                 |
--|                                                                             |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN:    errbuf                                                             |
--|          retcode                                                            |
--|  Returns :                                                                  |
--|  History            Author      Date        Change                          |
--|  Rel 1.1            P.Rajack    29-aug-07   Added parameter (partial file)  |
--|                                                                             |
--|                                                                             |
--|                                                                             |
--+=============================================================================+
PROCEDURE get_3rdparty_owm(errbuf  OUT VARCHAR2,
                           retcode OUT NUMBER,
                           p_dist  IN VARCHAR2,
                           p_partial_file IN VARCHAR2,
                           p_report_date IN VARCHAR2)  IS

   temp_char varchar2(10000);
   lc_sign VARCHAR2(1);
   lc_qty VARCHAR2(10);
   lc_val_flag VARCHAR2(1):='N';
   gn_child_request2_id NUMBER:=0;
   lc_logfile VARCHAR2(10000);
   lc_validation_status_code VARCHAR2(10000);
   lc_rollback_flag VARCHAR2(1):='N';
   l_error_count NUMBER;
   l_pricelist  VARCHAR2(240);
   l_agree_type VARCHAR2(10);
   l_unit_price NUMBER;
  l_purchase_price NUMBER;
  l_start_date  DATE;    -- added sept282007
  l_end_date DATE;       -- ADDED SEPT-28-2007
  l_conversion_rate  NUMBER; -- ADDED SEP-28-2007

-- delete xxha_3rdparty_owm; -- delete haemo_car_3rd_party_data;
   --------------------------------------------------------------------------
   -- Main Cursor to get all the rcords from the staging table
   -----------------------------------------------------------

   CURSOR c1 IS
   SELECT d.ITEM ITEM, d.CUSNBR CUSNBR,d.QUANT QUANT,d.record_number,d.record_type,
   decode(d.uom,'CS','Ca',d.uom) uom
   FROM   xxha_3rdparty_owm d
   WHERE  p_dist=gc_owm_cust_name
   AND    status is null                 -- rel 1.1
   UNION ALL
   SELECT  d.ITEM_no ITEM ,d.CUSTOMER_NUMBER CUSNBR,to_char(d.QUANTITY) QUANT,d.record_number,null,
   decode(d.uom_code,'CS','Ca',d.uom_code) uom
   FROM    haemo_car_3rd_party_data d
   WHERE   p_dist=gc_car_cust_name
   AND    status is null                 -- rel 1.1
   ORDER BY RECORD_NUMBER;

   r1 c1%rowtype;

  --------------------------------------------------------------------------
  -- This cursor will fetch the customer name and primary bill to site id for
  -- the cardinal/Owens/Minor.Customr
  ---------------------------------------------------------------------------
  CURSOR C2 IS
  /*SELECT c.customer_name, s.site_use_id     ---11i code modified
  FROM ar_customers_v c, ar_addresses_v a, hz_site_uses_v s
  WHERE s.address_id = a.address_id
  AND a.customer_id = c.customer_id
  AND s.status = 'A'
  AND a.status = 'A'
  AND c.status = 'A'
  AND s.site_use_code = 'BILL_TO'
  AND s.primary_flag = 'Y'
  AND c.customer_name = decode(p_dist, gc_owm_cust_name,gc_owm_cust_name,gc_car_cust_name);*/
  ---R12 Remediated
  SELECT ---C.CUSTOMER_NAME,---11i code modified
       HP.PARTY_NAME CUSTOMER_NAME,---R12 Remediated
       S.SITE_USE_ID
  FROM ---AR_CUSTOMERS_V C,---11i code modified
       HZ_PARTIES  HP,---R12 Remediated
       HZ_CUST_ACCOUNTS HCA,---R12 Remediated
       ---AR_ADDRESSES_V A,---11i code modified
       HZ_PARTY_SITES HPS, ---R12 Remediated
        HZ_LOCATIONS HL ,   ---R12 Remediated
        HZ_CUST_ACCT_SITES_ALL HCASA , ---R12 Remediated
       ---HZ_SITE_USES_V S---11i code modified
       hz_cust_site_uses_all S---R12 Remediated
  WHERE ---S.ADDRESS_ID = A.ADDRESS_ID---11i code modified
       S.CUST_ACCT_SITE_ID = HCASA.CUST_ACCT_SITE_ID---R12 Remediated
  AND  HP.PARTY_ID   = HCA.PARTY_ID---R12 Remediated
  ---AND a.customer_id = c.customer_id---11i code modified
  AND HCASA.CUST_ACCOUNT_ID  = HCA. CUST_ACCOUNT_ID---R12 Remediated
  AND HPS.LOCATION_ID        = HL.LOCATION_ID---R12 Remediated
  AND HPS.PARTY_SITE_ID       = HCASA.PARTY_SITE_ID---R12 Remediated
  AND S.STATUS = 'A'
  ---AND A.STATUS = 'A'---11i code modified
  AND HCASA.STATUS = 'A'---R12 Remediated
  ---AND c.status = 'A'---11i code modified
  AND  HCA.STATUS = 'A'---R12 Remediated
  AND s.site_use_code = 'BILL_TO'
  AND S.PRIMARY_FLAG = 'Y'
---AND C.CUSTOMER_NAME = DECODE(P_DIST, GC_OWM_CUST_NAME,GC_OWM_CUST_NAME,GC_CAR_CUST_NAME);---11i code modified
  AND HP.PARTY_NAME  = DECODE(P_DIST, GC_OWM_CUST_NAME,GC_OWM_CUST_NAME,GC_CAR_CUST_NAME);---R12 Remediated

  r2 c2%rowtype;
  --------------------------------------------------------------------------
  -- This cursor will select the customer name and primary bill to city from
  -- the end customer on the record.
  --------------------------------------------------------------------------
  CURSOR C3 IS
   /*SELECT c.customer_name, a.city    ---11i code modified
   FROM   ar_customers_v c
         ,ar_addresses_v a
         ,hz_site_uses_v s
   WHERE s.address_id = a.address_id
   AND a.customer_id = c.customer_id
   AND s.status = 'A'
   AND a.status = 'A'
   AND c.status = 'A'
   AND s.site_use_code = 'BILL_TO'
   AND s.primary_flag = 'Y'
   AND s.attribute3 = r1.CUSNBR;*/
   ---R12 Remediated
   SELECT ---C.CUSTOMER_NAME, ---11i code modified
       HP.PARTY_NAME CUSTOMER_NAME,---R12 Remediated
       ---A.CITY---11i code modified
       HL.CITY---R12 Remediated
FROM   ---ar_customers_v c---11i code modified
          HZ_PARTIES  HP---R12 Remediated
        , HZ_CUST_ACCOUNTS HCA---R12 Remediated
         ---,ar_addresses_v a ---11i code modified
        ,HZ_PARTY_SITES HPS ---R12 Remediated
        ,HZ_LOCATIONS HL    ---R12 Remediated
        ,HZ_CUST_ACCT_SITES_ALL HCASA  ---R12 Remediated
         ---,HZ_SITE_USES_V S ---11i code modified
        ,hz_cust_site_uses_all S  ---R12 Remediated
   WHERE ---S.ADDRESS_ID = A.ADDRESS_ID
         S.CUST_ACCT_SITE_ID = HCASA.CUST_ACCT_SITE_ID---R12 Remediated
   AND  HP.PARTY_ID   = HCA.PARTY_ID---R12 Remediated
   ---AND a.customer_id = c.customer_id---11i code modified
   AND  HCASA.CUST_ACCOUNT_ID = HCA. CUST_ACCOUNT_ID---R12 Remediated
   AND HPS.LOCATION_ID        = HL.LOCATION_ID---R12 Remediated
  AND HPS.PARTY_SITE_ID       = HCASA.PARTY_SITE_ID---R12 Remediated
   AND S.STATUS = 'A'
   ---AND A.STATUS = 'A'---11i code modified
   AND HCASA.STATUS = 'A'---R12 Remediated
   ---AND c.status = 'A'---11i code modified
   AND  HCA.STATUS = 'A'---R12 Remediated
   AND s.site_use_code = 'BILL_TO'
   AND S.PRIMARY_FLAG = 'Y'
   and s.attribute3 = r1.cusnbr;
r3 c3%rowtype;
---------------------------------------------------------------------------
  -- This cursor will find the cross referenced item for the item in the data
  -- file.
  ---------------------------------------------------------------------------
  CURSOR c4 is
  SELECT i.segment1,i.inventory_item_id
  FROM mtl_system_items i
      ,mtl_parameters p
      ,mtl_cross_references_v c
  WHERE p.organization_id = i.organization_id
  AND c.inventory_item_id = i.inventory_item_id
  AND p.organization_code = 'MST'
  AND c.cross_reference_type = 'Third Party Customer'
  AND c.description = decode(p_dist,gc_owm_cust_name,gc_owm_xref,gc_car_xref)
  AND c.cross_reference = r1.item;
  r4 c4%rowtype;
-- ---------------------------------------------------------------
-- This cursor gets the start and end date of the reporting period
-- --------------------------------------------------------------
CURSOR c5 IS
  SELECT start_date,end_date
  FROM GL_PERIODS_V
  WHERE PERIOD_SET_NAME = 'HAE_GLOBAL_CAL'
  AND PERIOD_NAME = p_report_date;
r5 c5%rowtype;
v_error_message varchar2(150);
  BEGIN
UPDATE xxha_3rdparty_owm
    SET STATUS = NULL
    WHERE STATUS != 'VS';
UPDATE haemo_car_3rd_party_data
    SET STATUS = NULL
    WHERE STATUS != 'VS';
IF p_partial_file = 'N' THEN          -- rel 1.1
IF p_dist<>gc_car_cust_name THEN
	gn_child_request2_id := FND_REQUEST.SUBMIT_REQUEST(
	                                                     Application => 'HAEMO'
		                                            ,Program     => 'XXHA_THRDPTY_LOADER'
		                                            ,description =>  'Owens/Minor Loader'
		                                            ,start_time  =>  TO_CHAR (SYSDATE,'DD-MON-YYYY HH24:MI:SS')
		                                            ,sub_request =>  FALSE
		                                            );
 COMMIT;
	 LOOP
	   BEGIN
	      SELECT FCR.logfile_name,FCR.status_code
	      INTO   lc_logfile, lc_validation_status_code
	      FROM   fnd_concurrent_requests FCR
	      WHERE  FCR.request_id = gn_child_request2_id
-- 	      AND    FCR.phase_code = 'C';
 	      AND    FCR.phase_code in ('C','G');
EXIT WHEN lc_logfile IS NOT NULL;
	  EXCEPTION
	     WHEN NO_DATA_FOUND THEN
	         NULL;
	  END;
	END LOOP;--End of the Loop
   ELSE
        gn_child_request2_id := FND_REQUEST.SUBMIT_REQUEST(
				                         Application => 'HAEMO'
				                         ,Program     => 'XXHA_CAR_LOAD'
				                         ,description =>  'Cardinal Loader'
				                         ,start_time  =>  TO_CHAR (SYSDATE,'DD-MON-YYYY HH24:MI:SS')
				                         ,sub_request =>  FALSE
				                          );

COMMIT;
      LOOP
	BEGIN
	  SELECT FCR.logfile_name,FCR.status_code
	  INTO   lc_logfile, lc_validation_status_code
	  FROM   fnd_concurrent_requests FCR
	  WHERE  FCR.request_id = gn_child_request2_id
	  AND    FCR.phase_code = 'C';
EXIT WHEN lc_logfile IS NOT NULL;
       EXCEPTION
	WHEN NO_DATA_FOUND THEN
	     NULL;
       END;
     END LOOP;--End of the Loop
END IF; --IF p_dist<>gc_car_cust_name THEN
END IF;  -- partial_file parameter rel 1.1

 gc_status_flag:='VS';
 gc_identifier :='Customer Number';
 gc_con_name:='TM';

OPEN c2;
 FETCH c2 into r2;
 IF c2%NOTFOUND THEN
    gc_status_flag      :=  'VE';
    gc_error_code       :=  'SETUP-Err';

    IF p_dist = gc_owm_cust_name then
       gc_error_msg        :=  ' No data found for the Distributor Name: ' ||gc_owm_cust_name;
    ELSE
       gc_error_msg        :=  ' No data found for the Distributor Name: ' ||gc_car_cust_name;
    END IF;
    gc_comments         :=   NULL;
    INSERT_ERROR_PRC;
    CLOSE c2;
    GOTO endproc;
 ELSE
    CLOSE c2;
 END IF;

 OPEN c1;
 LOOP
   FETCH c1 INTO r1;
   gn_record_number     :=  r1.record_number;
   gc_err_rec_identifier:=  r1.CUSNBR;
   lc_rollback_flag := 'N';
   lc_val_flag:='Y';
   EXIT WHEN C1%NOTFOUND;
   v_error_message := 'OK';
   gc_status_flag:='VS';
   IF p_dist<>gc_car_cust_name THEN
IF r1.record_type='3' THEN
lc_rollback_flag:='N';
	  -- fetch the customer name and city from the primary bill to address.
	  OPEN c3;
	  FETCH c3 INTO r3;
	  IF c3%NOTFOUND then
	   gc_status_flag      :=  'VE';
	   lc_rollback_flag   :='Y';
	   gc_error_code       :=  'TM01';
	   gc_error_msg :=  'No data found for the End customer: ' ||r1.CUSNBR||' for the Record number: '||r1.record_number;
             gc_comments         :=   NULL;
	     INSERT_ERROR_PRC;
	     CLOSE c3;
	     GOTO endloop;
         ELSE
	   CLOSE c3;
	 END IF;
-- get start date and end date of reporting period
OPEN c5;
          FETCH c5 into r5;
          IF c5%NOTFOUND then
           gc_status_flag      :=  'VE';
           lc_rollback_flag   :='Y';
           gc_error_code       :=  'TM99';
           gc_error_msg :=  'No start or end date found for reporting period - '||p_report_date;
             gc_comments         :=   NULL;
             INSERT_ERROR_PRC;
             CLOSE c5;
             GOTO endloop;
         ELSE
           CLOSE c5;
         END IF;
ELSE
	--Get the last char of the quantity
	SELECT substr(r1.quant,-1,1)
	INTO lc_sign
	FROM dual;
--Check if the Last Char falls in the below range and translate it to eith Positive/Negative Numbr
	IF lc_sign IN ('A','B','C','D','E','F','G','H','I','{') THEN
	   SELECT  REPLACE(SUBSTR(r1.quant,-2,2),SUBSTR(r1.quant,-1,1),DECODE(SUBSTR(r1.quant,-1,1),'A',1,'B',2,'C',3,'D',4,'E',5,'F',6,'G',7,'H',8,'I',9,'{',0))
	   INTO lc_qty
	   FROM DUAL; --POSITIVE
	ELSE
	   SELECT  '-'||REPLACE(substr(r1.quant,-2,2),SUBSTR(r1.quant,-1,1),decode(SUBSTR(r1.quant,-1,1),'J',1,'K',2,'L',3,'M',4,'N',5,'O',6,'P',7,'Q',8,'R',9,'}',0))
	   INTO lc_qty
	   FROM DUAL; --NEGATIVE
	END IF;

	-- Validate Item  Owen and Minors
	OPEN c4;
	FETCH c4 INTO r4;
	IF c4%NOTFOUND  THEN
	   gc_status_flag      :=  'VE';
           gc_error_code       :=  'TM02';
	   gc_error_msg        :=  'Item cross reference not found for the Item: '||r1.item||' for the Record number: '||r1.record_number;
	   gc_comments         :=   NULL;
	   INSERT_ERROR_PRC;
	   CLOSE c4;
	   GOTO endloop;
	ELSE
IF upper(r1.uom) != 'EA' THEN   -- convert uom logic 28-sep-2007
BEGIN

            SELECT conversion_rate
                        INTO l_conversion_rate
                        FROM mtl_uom_conversions
                        WHERE upper(uom_code) = upper(r1.uom)
                        AND INVENTORY_ITEM_ID = r4.inventory_item_id
                        AND NVL(DISABLE_DATE,SYSDATE) >= SYSDATE;

                        lc_qty := lc_qty * l_conversion_rate;
            EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                       gc_status_flag := 'VE';
                       gc_error_code := 'TM97';
                       gc_error_msg := 'No uom conversion record found for item - '||r4.segment1;
                       INSERT_ERROR_PRC;
            WHEN OTHERS THEN

                       gc_status_flag := 'VE';
                       gc_error_code := 'TM96';
                       gc_error_msg := substr(SQLERRM,1,80);
                       INSERT_ERROR_PRC;
          END;

        ELSE

--              lc_qty := r1.quant;
         null;


       END IF;


	   CLOSE c4;
	END IF;
     END IF; --r1.record_type='3'    -- owen and minors record type 3

   ELSE --p_dist<>gc_car_cust_name THEN     -- it is cardinal

      lc_rollback_flag:='N';
      OPEN c3;
      FETCH c3 INTO r3;
      IF c3%NOTFOUND then
	 gc_status_flag      :=  'VE';
	 gc_error_code       :=  'TM01';
	 gc_error_msg        :=  'No data found for the End customer: ' ||r1.CUSNBR||' for the Record number: '||r1.record_number;
	 gc_comments         :=   NULL;
	 INSERT_ERROR_PRC;
	 CLOSE c3;
	 GOTO endloop;
       ELSE
         CLOSE c3;
       END IF;

OPEN c5;
          FETCH c5 into r5;
          IF c5%NOTFOUND then
           gc_status_flag      :=  'VE';
           lc_rollback_flag   :='Y';
           gc_error_code       :=  'TM98';
           gc_error_msg :=  'No start or end date found for reporting period - '||p_report_date;
             gc_comments         :=   NULL;
             INSERT_ERROR_PRC;
             CLOSE c5;
             GOTO endloop;
         ELSE
           CLOSE c5;
         END IF;

       -- Validate Item  for Cardinal
       OPEN c4;
       FETCH c4 INTO r4;
       IF c4%NOTFOUND  THEN
          gc_status_flag      :=  'VE';
	  gc_error_code       :=  'TM02';
    gc_error_msg   :=  'Item cross reference not found for the Item: '||r1.item||' for the Record number: '||r1.record_number;
	  gc_comments         :=   NULL;
	  INSERT_ERROR_PRC;

	  CLOSE c4;
	  GOTO endloop;
	ELSE

             IF upper(r1.uom) != 'EA' THEN   -- convert uom logic 28-sep-2007

		BEGIN

			SELECT conversion_rate
                        INTO l_conversion_rate
                        FROM mtl_uom_conversions
                        WHERE upper(uom_code) = upper(r1.uom)
                        AND INVENTORY_ITEM_ID = r4.inventory_item_id
                        AND NVL(DISABLE_DATE,SYSDATE) >= SYSDATE;

                        lc_qty := r1.quant * l_conversion_rate;
            EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                       gc_status_flag := 'VE';
                       gc_error_code := 'TM97';
                       gc_error_msg := 'No uom conversion record found for item - '||r4.segment1;
                       INSERT_ERROR_PRC;
            WHEN OTHERS THEN

                       gc_status_flag := 'VE';
                       gc_error_code := 'TM96';
                       gc_error_msg := substr(SQLERRM,1,80);
                       INSERT_ERROR_PRC;
          END;

        ELSE

             lc_qty := r1.quant;


       END IF;

      l_purchase_price := 0;

             BEGIN

                 select c.name
                 into l_pricelist
                 from oe_blanket_lines_v a,
                      oe_blanket_headers_v b,
                      qp_list_headers c
                 where a.sold_to_org_id = b.sold_to_org_id
                 and a.header_id = b.header_id
                 and b.sold_to = r3.customer_name
                 and a.ordered_item =r4.segment1
                 and c.list_header_id = a.price_list_id
                 and b.start_date_active = (select max(start_date_active)
                         from oe_blanket_headers_v
                         where sold_to = r3.customer_name
                         and end_date_active is null);
                l_agree_type := 'Price List';
            EXCEPTION WHEN NO_DATA_FOUND THEN
                l_pricelist := null;
                l_agree_type := null;
            WHEN OTHERS THEN
               l_pricelist := null;
               l_agree_type := null;

            END;


IF l_pricelist is not null THEN

       BEGIN

      SELECT  operand
      into l_unit_price
      from qp_list_lines_v   a,
         qp_secu_list_headers_v b
      where a.product_attr_val_disp = r4.segment1
      and a.list_header_id = b.list_header_id
      and b.name = l_pricelist
      and nvl(a.end_date_active,sysdate) = (select max(nvl(a.end_date_active,sysdate))
                from qp_list_lines_v a,
                qp_secu_list_headers_v b
                where a.list_header_id = b.list_header_id
                and a.product_attr_val_disp = r4.segment1
                and b.name = l_pricelist);

--                 l_purchase_price := r1.quant * l_unit_price;
                 l_purchase_price := lc_qty * l_unit_price;

       EXCEPTION   WHEN NO_DATA_FOUND THEN
                      l_purchase_price := 0;

            WHEN OTHERS THEN
                       l_purchase_price := 0;

        END;

END IF;

CLOSE c4;
	END IF;
    END IF;--p_dist<>gc_car_cust_name THEN
    <<endloop>>

-- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'ROLLBACK FLAG IS - '||lc_rollback_flag);
-- This is Cardinal's output file creation
IF gc_status_flag ='VS' AND lc_rollback_flag='N'    THEN
        IF p_dist =gc_car_cust_name THEN
	   FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Chargeback'||'~'||           -- header
                                              r5.start_date||'~'||             -- header start date of p_report_date
                                              r5.end_date||'~'||      -- header end date of p_report_date
                                               r2.customer_name||'~'||    -- header
                                               r2.site_use_id|| '~'||      -- header
                                               'US Dollar'||'~'||                     -- header
                                               '0'||'~'||                       -- header
                                               r3.customer_name||'~'||
                                               r3.city||'~'||
                                               l_agree_type||'~'||
                                               l_pricelist||'~'||
                                               '0'||'~'||
                                               r5.end_date||'~'||    -- end date of report perioD
                                               lc_qty||'~'||
                                               r4.segment1||'~'||
                                               l_purchase_price);
           UPDATE haemo_car_3rd_party_data
	      SET status='VS'
	    WHERE record_number=r1.record_number;
        ELSE

	   IF r1.record_type = '3' then


/*

      temp_char:='Chargeback' ||'~'||sysdate || '~' ||( sysdate + 30) || '~' ||r2.customer_name || '~' ||r2.site_use_id || '~' ||'US Dollar' ||'~'||'0'||'~'||r3.customer_name || '~' ||r3.city || '~' ||l_agree_type||'~'||l_pricelist||'~'||'0'||'~'||sysdate || '~';
*/

      temp_char:='Chargeback' ||'~'||r5.start_date || '~' ||r5.end_date|| '~' ||r2.customer_name || '~' ||r2.site_use_id || '~' ||'US Dollar' ||'~'||'0'||'~'||r3.customer_name || '~' ||r3.city || '~';

--  ||l_agree_type||'~'||l_pricelist||'~'||'0'||'~'||sysdate || '~';
	       NULL;

	   ELSIF r1.record_type = '4' THEN
                 l_purchase_price := 0;

BEGIN
                select c.name
                 into l_pricelist
                 from oe_blanket_lines_v a,
                      oe_blanket_headers_v b,
                      qp_list_headers c
                 where a.sold_to_org_id = b.sold_to_org_id
                 and a.header_id = b.header_id
                 and b.sold_to = r3.customer_name
                 and a.ordered_item =r4.segment1
                 and c.list_header_id = a.price_list_id
                 and b.start_date_active = (select max(start_date_active)
                         from oe_blanket_headers_v
                         where sold_to = r3.customer_name
                         and end_date_active is null);
                     l_agree_type := 'Price List';
            EXCEPTION WHEN NO_DATA_FOUND THEN
                l_pricelist := null;
                l_agree_type := null;
            WHEN OTHERS THEN
               l_pricelist := null;
               l_agree_type := null;

            END;
IF l_pricelist is not null THEN

       BEGIN
SELECT  operand
      into l_unit_price
      from qp_list_lines_v   a,
         qp_secu_list_headers_v b
      where a.product_attr_val_disp = r4.segment1
      and a.list_header_id = b.list_header_id
      and b.name = l_pricelist
      and nvl(a.end_date_active,sysdate) = (select max(nvl(a.end_date_active,sysdate))
                from qp_list_lines_v a,
                qp_secu_list_headers_v b
                where a.list_header_id = b.list_header_id
                and a.product_attr_val_disp = r4.segment1
                and b.name = l_pricelist);

                l_purchase_price := lc_qty * l_unit_price;

       EXCEPTION   WHEN NO_DATA_FOUND THEN
                      l_purchase_price := 0;

            WHEN OTHERS THEN
                       l_purchase_price := 0;

        END;

END IF;     -- if l_pricelist
-- 	         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,temp_char||lc_qty || '~' ||r4.segment1 ) ;

FND_FILE.PUT_LINE(FND_FILE.OUTPUT,temp_char||l_agree_type||'~'||l_pricelist
                 ||'~'||'0'||'~'||r5.end_date||'~'||lc_qty || '~' ||r4.segment1||'~'||l_purchase_price ) ;
END IF;
	   UPDATE xxha_3rdparty_owm
	   SET status='VS'
	   WHERE record_number=r1.record_number;
        END IF; --IF p_dist =gc_car_cust_name THEN
   ELSE            --FND_FILE.PUT_LINE(FND_FILE.LOG,'ERR IN PACKAGE ');
       IF p_dist<>gc_car_cust_name THEN
	   UPDATE xxha_3rdparty_owm
	   SET status='VE'
	   WHERE record_number=r1.record_number;
        ELSE
           UPDATE haemo_car_3rd_party_data
	    SET status='VE'
	    WHERE record_number=r1.record_number;
        END IF;
   END IF; --IF gc_status_flag ='VS' AND lc_rollback_flag='N'    THEN
END LOOP; --OPEN c1;
CLOSE c1;
--END LOOP; --MAIN  FOR I IN 1..2 LOOP

<<endproc>>
-- IF (gc_status_flag  <>'VS') THEN

BEGIN
SELECT COUNT(*)
      INTO l_error_count
      FROM XXHA_COMMON_ERRORS
      WHERE REQUEST_ID = gn_request_id;
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;
IF  l_error_count > 1 THEN
     xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
	  IF lc_val_flag='N' THEN
         retcode:=2;
	  ELSE
	      retcode:=1;
	  END IF;
    END IF;
-- END IF;
COMMIT;
END get_3rdparty_owm  ;
end xxha_3rdparty_owm_pk;
/
