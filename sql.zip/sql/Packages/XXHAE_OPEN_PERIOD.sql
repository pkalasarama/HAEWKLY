CREATE OR REPLACE package XXHAE_OPEN_PERIOD is

  -- Author  : SKULIKOV
  -- Created : 3/17/2010 3:46:24 AM
  -- Purpose : automatically opens gl period 
  
  -- Public type declarations
  
  -- Public function and procedure declarations
  procedure open_inv_period_for_all_orgs(p_type IN varchar2);
  procedure open_inv_period(p_org_id IN number ,p_type IN varchar2) ;
  procedure open_inv_period_daily(err_buf OUT varchar2,
     retcode OUT number,p_org_id in number);
  procedure open_purchase_period_daily(err_buf  OUT varchar2,
                                  retcode  OUT number,
                                  p_org_id in number);
  procedure open_purchase_period (p_org_id IN number);

end XXHAE_OPEN_PERIOD;
/


CREATE OR REPLACE package body XXHAE_OPEN_PERIOD is

--+=======================================================================+
--|               Data Intensity, Inc.                                    |
--|           22 Crosby Drive, Suite 100    Bedford, MA 01730             |
--+=======================================================================+
--|                                                                       |
--| DESCRIPTION                                                           |
--|     Spec. of XXHAE_OPEN_PERIOD                                        |
--|                                                                       |
--| PROCEDURE LIST                                                        |
--|     open_inv_period_daily                                             |
--|     open_inv_period_monthly                                           |
--|     open_purchase_period_daily                                        |
--|     open_inv_period_for_all_orgs                                      |
--|     open_purchase_period                                              |
--|     open_inv_period                                                   |
--| HISTORY                                                               |
--|   March 2010 skulikov      Created                                    |
--|   June 2010  syazvinskiy   Adjusted all occurencies of sysdate to     |
--|                            trunc(sysdate). Since gl_periods.start_date|
--|                            has 01/15/2010 format                      |
--+======================================================================*/


  -- Private type declarations
  -- Function and procedure implementations
  procedure open_inv_period_daily(err_buf  OUT varchar2,
                                  retcode  OUT number,
                                  p_org_id in number) is
    l_org_count number;
  begin
    select count(organization_id)
      into l_org_count
      from org_organization_definitions
     where organization_id = p_org_id;
    if l_org_count > 0 then
      open_inv_period(p_org_id, 'D');
    end if;
  end;
  procedure open_inv_period_monthly(err_buf  OUT varchar2,
                                    retcode  OUT number,
                                    p_org_id in number) is
    l_org_count number;
  begin
    select count(organization_id)
      into l_org_count
      from org_organization_definitions
     where organization_id = p_org_id
     and INVENTORY_ENABLED_FLAG = 'Y'
     AND NVL(DISABLE_DATE, TRUNC(SYSDATE)+1) > SYSDATE;
    if l_org_count > 0 then
      open_inv_period(p_org_id, 'M');
    end if;
  
  end;
  procedure open_purchase_period_daily(err_buf  OUT varchar2,
                                  retcode  OUT number,
                                  p_org_id in number) is
                                  begin
                                  open_purchase_period(p_org_id);
                                  end;
  procedure open_inv_period_for_all_orgs(p_type IN varchar2) is
  
    l_count  number;
--    l_org_id number;
  
    cursor org_list is
      select distinct organization_id from org_organization_definitions
     where INVENTORY_ENABLED_FLAG = 'Y'
     AND NVL(DISABLE_DATE, TRUNC(SYSDATE)+1) > SYSDATE;
  
  begin
    --open org_list;
    for rec in org_list loop
      --fetch org_list into l_org_id;
      --if org_list%notfound then 
      --close org_list;
      --else
      select count(*)
        into l_count
        from ORG_ACCT_PERIODS_V
       where organization_id = rec.organization_id;
      dbms_output.put_line('Org : ' || to_char(rec.organization_id) ||
                           ' : ' || l_count);
      if l_count > 0 then
        open_inv_period(rec.organization_id, p_type => p_type);
      end if;
    end loop;
    --end if;
  end;
  procedure open_purchase_period(p_org_id IN number) is
    l_period_count number;
--    l_min_date     date;
  begin
    select count(min(start_date))
      into l_period_count
      FROM GL_PERIOD_STATUSES
     WHERE ADJUSTMENT_PERIOD_FLAG = 'N'
       AND ((CLOSING_STATUS) IN
           (SELECT LOOKUP_CODE
               FROM AP_LOOKUP_CODES
              WHERE APPLICATION_ID = '201'
                AND SET_OF_BOOKS_ID =
                    (SELECT SET_OF_BOOKS_ID
                       FROM FINANCIALS_SYSTEM_PARAMS_ALL
                      where org_id = p_org_id)))
       and start_date = TRUNC(SYSDATE) + 1
       and closing_status = 'N'
     group by closing_status; 
    if l_period_count > 0 then
   
    dbms_output.put_line(to_char(l_period_count));
      update GL_PERIOD_STATUSES
         set closing_status = 'O'
       WHERE ADJUSTMENT_PERIOD_FLAG = 'N'
       AND ((CLOSING_STATUS) IN
           (SELECT LOOKUP_CODE
               FROM AP_LOOKUP_CODES
              WHERE APPLICATION_ID = '201'
                AND SET_OF_BOOKS_ID =
                    (SELECT SET_OF_BOOKS_ID
                       FROM FINANCIALS_SYSTEM_PARAMS_ALL
                      where org_id = p_org_id)))
       and start_date = TRUNC(SYSDATE) + 1
       and closing_status = 'N'; 
       COMMIT;
    end if;
  exception
    when others then
      raise;
    
  end;
  procedure open_inv_period(p_org_id IN number, p_type IN varchar2) is
    -- l_str_date varchar2;
--    l_count            number;
    l_accounted_period number;
    l_period_set_name  varchar2(50);
    l_period_name      varchar2(50);
    l_period_number    number;
    l_period_year      number;
    l_start_date       date;
    l_end_date         date;
--    l_org_id           number;
  
    x_prior_period_open         boolean;
    x_duplicate_open_period     boolean;
    x_commit_complete           boolean;
    x_last_scheduled_close_date date;
    x_return_status             varchar2(100);
    x_new_acct_period_id        number;
  
    cursor period_to_open_month(c_org_id number) is
             SELECT accounted_period_type,
             period_set_name,
             period_name,
             period_number,
             period_year,
             start_date,
             end_date
                             FROM ORG_ACCT_PERIODS_V
                            WHERE ((rec_type = 'ORG_PERIOD' and
                                  organization_id = c_org_id) or
                                  (rec_type = 'GL_PERIOD' and
                                  period_set_name = 'HAE_GLOBAL_CAL' and
                                  accounted_period_type = '21' and
                                  (PERIOD_YEAR, PERIOD_NAME) NOT IN
                                  (SELECT PERIOD_YEAR, PERIOD_NAME
                                       FROM ORG_ACCT_PERIODS
                                      WHERE ORGANIZATION_ID = c_org_id) 
                                   and end_date >=  trunc(sysdate)))
                              and status = 'Future'
                              and start_date > trunc(sysdate);
                              
    cursor period_to_open_day(c_org_id number) is
             SELECT accounted_period_type,
             period_set_name,
             period_name,
             period_number,
             period_year,
             start_date,
             end_date
                             FROM ORG_ACCT_PERIODS_V
                            WHERE ((rec_type = 'ORG_PERIOD' and
                                  organization_id = c_org_id) or
                                  (rec_type = 'GL_PERIOD' and
                                  period_set_name = 'HAE_GLOBAL_CAL' and
                                  accounted_period_type = '21' and
                                  (PERIOD_YEAR, PERIOD_NAME) NOT IN
                                  (SELECT PERIOD_YEAR, PERIOD_NAME
                                       FROM ORG_ACCT_PERIODS
                                      WHERE ORGANIZATION_ID = c_org_id) 
                                   and end_date >= trunc(sysdate)))
                              and status = 'Future'
                              and start_date = trunc(sysdate) + 1;
  
  begin
    if p_type = 'M' then
      open period_to_open_month(p_org_id);
      fetch period_to_open_month
        into l_accounted_period, l_period_set_name, l_period_name, l_period_number, l_period_year, l_start_date, l_end_date;
      close period_to_open_month;
    elsif p_type = 'D' then
    
      open period_to_open_day(p_org_id);
      fetch period_to_open_day
        into l_accounted_period, l_period_set_name, l_period_name, l_period_number, l_period_year, l_start_date, l_end_date;
      close period_to_open_day;
    end if;
    if (l_accounted_period is not null) and (l_period_set_name is not null) and
       (l_period_name is not null) and (l_period_number is not null) and
       (l_period_year is not null) then
      dbms_output.put_line('Period account :' ||
                           to_char(l_accounted_period) ||
                           ' Period set name :' || l_period_set_name ||
                           ' Period name :' || l_period_name ||
                           ' Period_number :' || to_char(l_period_number));
      cst_accountingperiod_pub.open_period(p_api_version               => 1.0,
                                           p_org_id                    => p_org_id,
                                           p_user_id                   => -1,
                                           p_login_id                  => -1,
                                           p_acct_period_type          => l_accounted_period,
                                           p_org_period_set_name       => l_period_set_name,
                                           p_open_period_name          => l_period_name,
                                           p_open_period_year          => l_period_year,
                                           p_open_period_num           => l_period_number,
                                           x_last_scheduled_close_date => x_last_scheduled_close_date,
                                           p_period_end_date           => l_end_date,
                                           x_prior_period_open         => x_prior_period_open,
                                           x_new_acct_period_id        => x_new_acct_period_id,
                                           x_duplicate_open_period     => x_duplicate_open_period,
                                           x_commit_complete           => x_commit_complete,
                                           x_return_status             => x_return_status);
      -- Convert false/true/null to 0/1/null 
      /*x_prior_period_open := sys.diutil.bool_to_int(x_prior_period_open);
      x_duplicate_open_period := sys.diutil.bool_to_int(x_duplicate_open_period);
      x_commit_complete := sys.diutil.bool_to_int(x_commit_complete);*/
    
      --COMMIT;
    else
      dbms_output.put_line('NO PERIOD FOUND');
    end if;
  exception
    when others then
      raise;
  end;

end XXHAE_OPEN_PERIOD;
/
