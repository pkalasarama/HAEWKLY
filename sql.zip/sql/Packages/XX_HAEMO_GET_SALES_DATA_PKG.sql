CREATE OR REPLACE PACKAGE XX_HAEMO_GET_SALES_DATA_PKG AUTHID CURRENT_USER AS

/*****************************************************************************************
* Package Name : XX_HAEMO_GET_SALES_DATA_PKG                                             *
* Purpose      : populate Sales Revenue data                                             *
*                in the XX_HAEMO_SALES_REVENUE, XX_HAEMO_SHIPTO_CUST_DETAILS,            *
*                XX_HAEMO_SHIPTO_CUST_DETAILS and XX_HAEMO_ITEM_DETAILS.                 *
*                                                                                        *
*                                                                                        *
* Procedures   :                                                                         *
* ---------------------                                                                  *
*                                                                                        *
* Tables Accessed :                                                                      *
* Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)          *
*                                                                                        *
* XX_HAEMO_SALES_REVENUE         D, I                                                    *
* XX_HAEMO_BILLTO_CUST_DETAILS   D, I                                                    *
* XX_HAEMO_SHIPTO_CUST_DETAILS   D, I                                                    *
* XX_HAEMO_ITEM_DETAILS          D, I                                                    *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* Draft 1A   11-Dec-2007     Rakesh Sawarkar      Initial Creation                       *
* 1.0        15-Jan-2009     IPadela              added an additional parameter to pass  *
*                                                 the current fiscal year. This will be  *
*                                                 used by XX_HAEMO_REF_PLAN_ACTUALS_PKG.Main
*                                                 procedure to refresh the current actuals
*                                                 in the XX_HAEMO_SALES_PLAN_FACT table  *
******************************************************************************************/

-- Procedures used to populate main data
--
PROCEDURE GET_SALES_REVENUE(x_errbuf          OUT VARCHAR2,
                            x_retcode         OUT VARCHAR2,
                            p_curr_fis_year   in number
			   );


END XX_HAEMO_GET_SALES_DATA_PKG;
/


CREATE OR REPLACE PACKAGE BODY      XX_HAEMO_GET_SALES_DATA_PKG AS
/* ***************************************************************************************
*  Procedure Name :   GET_SALES_REVENUE                                                  *
*                                                                                        *
*  GET_SALES_REVENUE :   Populate the XX_HAEMO_SALES_REVENUE data                        *
*                                                                                        *
*  Called From    :   This package will be called from standard concurrent program       *
*                                                                                        *
*  Parameters             Type       Description                                         *
*  x_errbuf               OUT        Standard Error Buffer                               *
*  x_retcode              OUT        Standard Error Code                                 *
*                                                                                        *
*  Tables Accessed                                                                       *
*  -----------------                                                                     *
*  Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)         *
*                                                                                        *
* XX_HAEMO_SALES_REVENUE        D, I                                                     *
* RA_CUSTOMER_TRX_ALL           S                                                        *
* RA_CUSTOMER_TRX_LINES_ALL     S                                                        *
* RA_CUST_TRX_TYPES_ALL         S                                                        *
* RA_CUST_TRX_LINE_GL_DIST_ALL  S                                                        *
* GL_CODE_COMBINATIONS_KFV      S                                                        *
* JTF_RS_SALESREPS              S                                                        *
* HR_OPERATING_UNITS            S                                                        *
* GL_SETS_OF_BOOKS              S                                                        *
*                                                                                        *
*  Change History                                                                        *
*  -----------------                                                                     *
*  Version         Date              Author               Description                    *
*  ---------       ------------     ---------------     ---------------------------      *
*  Draft 1A        11-Dec-2007      Rakesh Sawarkar     Initial Creation                 *
*  1.1             09-Jan-2008      Rakesh Sawarkar     Customer ID join added in the    *
*                                                       Bill to and Ship to query        *
*  1.2             25-Jan-2008      Imran Padela        Put outer joins for Cust Class,  *
*                                                       Cust Type and Cust Category      *
*                                                       lookups for the Bill To and      *
*                                                       Ship To dimension tables.        *
*  1.3             04-Feb-2008      L.Richards          As per Imran, added section to   *
*                                                       populate Sold To dimension table *
*                                                       Also modified to have the        *
*                                                       different site use attributes    *
*                                                       retrieved thru same cursor       *
*                                                       (instead of one cursor per       *
*                                                        SITE_USE_CODE)                  *
*  1.4             18-Mar-2008      L.Richards          As per Imran ... populate new    *
*                                                       column xxxxxx_SITE_NUMBER on     *
*                                                       tables                           *
*                                                         XX_HAEMO_SOLDTO_CUST_DETAILS   *
*                                                         XX_HAEMO_BILLTO_CUST_DETAILS   *
*                                                         XX_HAEMO_SHIPTO_CUST_DETAILS   *
*                                                       and column PURCHASE_ORDER on     *
*                                                         XX_HAEMO_SALES_REVENUE         *
*  1.5             21-Apr-2008      L.Richards          New requirement ... populate new *
*                                                       column AGENT on                  *
*                                                       tables                           *
*                                                         XX_HAEMO_SOLDTO_CUST_DETAILS   *
*                                                         XX_HAEMO_BILLTO_CUST_DETAILS   *
*                                                         XX_HAEMO_SHIPTO_CUST_DETAILS   *
*                                                       from customer site DFF.          *
*                                                       Aside ... also for debugging,    *
*                                                       add/populate columns             *
*                                                              CUST_TRX_LINE_GL_DIST_ID  *
*                                                       For performance, truncate tables *
*                                                       rather than delete               *
* 1.6               06-Jan-2009      I.Padela           changed the logic for setting the*
*                                                       intercompany flag based on the   *
*                                                       bill to cust type instead of the *
*                                                       Invoice type name. This is done  *
*                                                       in the XX_HAEMO_CUSTOMER_TRADE_PKG*
* 1.7               15-Jan-2009      I.Padela           added procedure call to          *
*                                                       XX_HAEMO_REF_PLAN_ACTUALS_PKG.Main
*                                                       to refresh the actual for current*
*                                                       fiscal year in the sales plan fact
*                                                       table.                           *
*                                                       Also added an additional parameter
*                                                       p_curr_fis_year in the           *
*                                                       GET_SALES_REVENUE definition. This
*                                                       parametr is set in the concurrent*
*                                                       program XXHA: Populate Sales Revenue
*                                                       Data call to this procedure.     *
* 1.8               25-Mar-2009      IPadela            Change the item dimension table
*                                                       to capture FY09 costs in the
*                                                       Item_Frozen_Cost column, also
*                                                       capture FY10 cost in New_Frozen_Cost
*                                                       column.
* 1.9               18-May-2008      IPadela            Change the item dimension table
*                                                       to capture FY10 costs in the
*                                                       Item_Frozen_Cost column, also
*                                                       capture FY09 cost in Old_Frozen_Cost
*                                                       column.
* 2.0               01-Apr-2010      IPadela            added a row to item dimension table
*                                                       with item id 0, also added nvl func to
*                                                       the item id field in sales revenue fact
*                                                       table. this is so that we can have an
*                                                       equal join on these table so as to filter
*                                                       the daily sales query by prod line and prod type
* 2.1               14-Apr-2010      IPadela            Change the item dimension table
*                                                       to capture FY11 costs in the
*                                                       Item_Frozen_Cost column, also
*                                                       capture FY10 cost in Old_Frozen_Cost
*                                                       column.
* 2.2               21-Apr-2011      ERossing           Modified CUR_GET_SALES_REVENUE cursor to only
*                                                       retrieve last two years of data. Modified
*                                                       CUR_GET_CUST_SITEUSE_DETLS cursor to not use
*                                                       RA_CUSTOMERS, which will be removed in R12.
* 2.3               22-Mar-2012      ERossing           Modified last-two-years limit to use ADD_MONTHS
*                                                       instead of INTERVAL in calculation to work around
*                                                       leap year bug.
* 2.4               20-Mar-2013      IPadela            modified the join to the sales rep table jtf_rs_salesreps
                                                        to be left joined instead of equal as the the primary sales rep
                                                        can be null sometimes.
  2.5               02-APR-2013      IPadela            added the RxC BillTo and ShipTo reference
                    26-Jun-2014     IMenzies            always get salesrep name from resource table
*********************************************************************************************************/
PROCEDURE GET_SALES_REVENUE (x_errbuf          OUT VARCHAR2,
                             x_retcode         OUT VARCHAR2,
                             p_curr_fis_year   in number
          )

IS

-- Declaring local variables for procedure
--
--
ln_record_count NUMBER := 0;
--IPadela - 01/15/09 added this variable to capture the return code from XX_HAEMO_REF_PLAN_ACTUALS_PKG
p_retcode number := 0;

CURSOR cur_get_sales_revenue
IS
  select   rct.trx_number trx_number
      ,rct.customer_trx_id cust_trx_id
      ,rctl.customer_trx_line_id cust_trx_line_id
      ,rctgl.cust_trx_line_gl_dist_id   -- <Rev 1.5>
      ,rct.bill_to_customer_id bill_to_cust_id
      ,rct.sold_to_customer_id sold_to_customer_id
      ,rct.ship_to_customer_id ship_to_customer_id
      ,rct.exchange_rate_type exchange_rate_type
      ,rct.exchange_rate exchange_rate
      ,rct.exchange_date exchange_date
      ,rct.invoice_currency_code transaction_currency_code
      ,rct.trx_date transaction_date
      ,rctgl.gl_date accounting_date
      ,rctgl.gl_posted_date inv_post_gl_date
      ,res.resource_name sales_person_name
      ,rct.primary_salesrep_id sales_rep_id
      ,rctt.cust_trx_type_id cust_trx_type_id
      ,rctl.line_type line_type
      ,rctt.name transaction_type_name
      ,rctl.line_number line_number
      ,xx_haemo_sales_rev_cnv_uom(rctl.inventory_item_id,rctl.quantity_credited,rctl.uom_code) qty_credited
      ,xx_haemo_sales_rev_cnv_uom(rctl.inventory_item_id,rctl.quantity_invoiced,rctl.uom_code) qty_invoiced
      ,xx_haemo_sales_rev_cnv_uom(rctl.inventory_item_id,rctl.quantity_ordered,rctl.uom_code) qty_ordered
      ,rctl.unit_selling_price selling_price
      --Rev 2.0
      ,nvl(rctl.inventory_item_id,0) item_id
      --end rev 2.0
      ,rctl.sales_order so_number
      ,rctl.sales_order_line so_line
      ,rctl.sales_order_revision so_revision
      ,rctl.sales_order_source so_source
      ,rctl.uom_code uom_code
      ,rctl.gross_unit_selling_price gross_unit_selling_price
      ,rctl.revenue_amount revenue_amount
      ,rctt.type transaction_type
      ,rctl.set_of_books_id set_of_book_id
      ,rctgl.acctd_amount accounted_amt
      ,gcc.segment1 legal_entity
      ,gcc.segment2 product_line
      ,gcc.segment3 business_unit
      ,gcc.segment4 management_unit
      ,gcc.segment5 department
      ,gcc.segment6 natural_account
      ,gcc.segment7 intercompany
      ,hou.name ou_name
      ,rct.interface_header_attribute1 interface_header_attribute1
      ,rctl.interface_line_attribute6 interface_line_attribute6
      ,hou.organization_id organization_id
      ,gsob.currency_code functional_currency_code
        ,rctgl.amount distribution_level_amount
      ,rctgl.percent distribution_level_percent
      ,rct.ship_to_site_use_id ship_to_site_use_id
      ,rct.bill_to_site_use_id bill_to_site_use_id
      /*,(case when upper(rctt.name) like '%INTERNAL%'
                 then 'Y'
                 else 'N'
                 end) intercompany_flag*/
      -- Rev 1.6 IPadela - 01/06/09 changed the logic to use the bill to cust type to decide intercompany
      -- (logic in the XX_HAEMO_CUSTOMER_TRADE_PKG being called at the end of this package)
      , null intercompany_flag
      ,null
      ,rct.purchase_order  --<Rev 1.4>
      ,rct.ct_reference
  from     ra_customer_trx_all rct
          ,ra_customer_trx_lines_all rctl
          ,ra_cust_trx_types_all rctt
          ,ra_cust_trx_line_gl_dist_all rctgl
  --      ,ra_cust_trx_line_salesreps_all rctls
          ,gl_code_combinations_kfv gcc
          ,jtf_rs_salesreps rs
          ,jtf_rs_resource_extns_vl res
          ,HR_OPERATING_UNITS HOU
          ---,gl_sets_of_books gsob  ---11I code modified
          ,GL_LEDGERS gsob           ---R12 Remediated
  where   1=1
  and     rct.complete_flag = 'Y'
  and     rctl.customer_trx_id = rct.customer_trx_id
  and     rctl.org_id = rct.org_id
  and     rctl.line_type in ('LINE','FREIGHT')
  and     rctt.cust_trx_type_id = rct.cust_trx_type_id
  and     rctt.org_id = rct.org_id
  and     rctt.post_to_gl = 'Y'
  and     hou.organization_id = rctt.org_id
  and     rctgl.customer_trx_id = rctl.customer_trx_id
  and     rctgl.customer_trx_line_id = rctl.customer_trx_line_id
  and     rctgl.account_class in ('REV','FREIGHT')
  and     rctgl.account_set_flag = 'N'
  -- Rev 2.4
  and     rs.salesrep_id (+) = rct.primary_salesrep_id
  and     rs.org_id (+) = rct.org_id
  and     rs.resource_id = res.resource_id(+)
  --end rev 2.4
  ---and  gsob.set_of_books_id = rctl.set_of_books_id ---11I code modified
  AND     gsob.LEDGER_ID =  rctl.set_of_books_id      ---R12 Remediated
  and     gcc.code_combination_id = rctgl.code_combination_id
  -- Rev 2.2 ERossing - 4/21/11 modified cursor to only retrieve last six months of data
--  and     rctgl.gl_date>=(sysdate - (interval '24' month));
  -- Rev 2.3 ERossing - 3/22/12 modified calculation to use ADD_MONTHS instead
  and     rctgl.gl_date>=(add_months(sysdate, -24));

-- 04-Feb-2008 : L. Richards
-- Cursor to fetch Customer SiteUse details
-- It can be used for any type of site use by passing in the SITE_USE_CODE (eg. BILL_TO, SHIP_TO, etc)
-- It replaces the individual cursors previously used
CURSOR cur_get_cust_siteuse_detls
          (q_site_use_code  varchar2
          ) IS
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --SELECT   rac.CUSTOMER_ID
  SELECT   ca.CUST_ACCOUNT_ID  CUSTOMER_ID
          ,csu.SITE_USE_ID
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --    ,rac.CUSTOMER_NUMBER
      ,ca.ACCOUNT_NUMBER  CUSTOMER_NUMBER
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --    ,rac.CUSTOMER_NAME
      ,substrb(p.PARTY_NAME,1,50)  CUSTOMER_NAME
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --    ,rac.ATTRIBUTE1  legacy_cus_number
      ,ca.ATTRIBUTE1  legacy_cus_number
      ,arl3.LOOKUP_CODE  customer_type_code
      ,arl3.MEANING  customer_type
      ,arl1.LOOKUP_CODE  customer_class_code
      ,arl1.MEANING  customer_class
      ,arl2.LOOKUP_CODE  customer_category_code
      ,arl2.MEANING  customer_category
      ,loc.ADDRESS1  ADDR1
      ,loc.ADDRESS2  ADDR2
      ,loc.ADDRESS3  ADDR3
      ,loc.ADDRESS4  ADDR4
      ,loc.CITY
      ,loc.COUNTY
      ,loc.STATE
      ,loc.PROVINCE
      ,loc.POSTAL_CODE
      ,loc.COUNTRY
                -- <Rev 1.4 : fetch SITE_NUMBER to populate dimension tables>
                ,ps.party_site_number  site_number
                -- <Rev 1.5 : fetch AGENT to populate dimension tables>
                ,cas.attribute5  agent
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --FROM   RA_CUSTOMERS  rac
  --  ,AR_LOOKUPS  arl1
  --Rev 2.5
  ,csu.attribute5 rxc_site
  --end
  FROM   AR_LOOKUPS arl1
    ,AR_LOOKUPS  arl2
    ,AR_LOOKUPS  arl3
        ,HZ_PARTY_SITES  ps
        ,HZ_LOCATIONS  loc
        ,HZ_CUST_ACCT_SITES_ALL  cas
        ,HZ_CUST_SITE_USES_ALL  csu
        ,HZ_CUST_ACCOUNTS  ca
        ,HZ_PARTIES  p
--Added on 25-Jan-2008 - Imran Padela Put outer joins for Cust Class,
--Cust Type and Cust Category, lookups for the Bill To and Ship To dimension tables.
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --WHERE   arl1.LOOKUP_CODE (+) = rac.CUSTOMER_CLASS_CODE
  WHERE   arl1.LOOKUP_CODE (+) = ca.CUSTOMER_CLASS_CODE
  AND   arl1.LOOKUP_TYPE (+) = 'CUSTOMER CLASS'
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --AND   arl2.LOOKUP_CODE (+) = rac.CUSTOMER_CATEGORY_CODE
  AND   arl2.LOOKUP_CODE (+) = p.CATEGORY_CODE
  AND   arl2.LOOKUP_TYPE (+) = 'CUSTOMER_CATEGORY'
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --AND   arl3.LOOKUP_CODE (+) = rac.CUSTOMER_TYPE
  AND   arl3.LOOKUP_CODE (+) = ca.CUSTOMER_TYPE
  AND   arl3.LOOKUP_TYPE (+) = 'CUSTOMER_TYPE'
  AND   ca.PARTY_ID = p.PARTY_ID
  AND   ca.CUST_ACCOUNT_ID = cas.CUST_ACCOUNT_ID
  AND   ps.LOCATION_ID = loc.LOCATION_ID
  AND   loc.CONTENT_SOURCE_TYPE = 'USER_ENTERED'
  AND   ps.PARTY_SITE_ID   = cas.PARTY_SITE_ID
  AND   cas.CUST_ACCT_SITE_ID = csu.CUST_ACCT_SITE_ID
  AND   csu.SITE_USE_CODE   = q_site_use_code
  -- Rev 2.2 - ERossing - 21-Apr-2011 - Remove RA_CUSTOMERS references from cursor
  --AND   rac.PARTY_ID = p.PARTY_ID
--Added on 9-Jan-08 as per Roberto's comments
  --AND     rac.CUSTOMER_ID = ca.CUST_ACCOUNT_ID;
  ;

CURSOR cur_get_item_detls
IS

  SELECT  I.INVENTORY_ITEM_ID INVENTORY_ITEM_ID,
      I.SEGMENT1 ITEMNUMBER,
      REPLACE(I.DESCRIPTION,'"','""') DESCRIPTION,
      CA.SEGMENT1 PRODUCT_LINE,
      CA.SEGMENT2 PRODUCT_TYPE,
      CA.SEGMENT3 PRODUCT_SUB_TYPE,
      CA.SEGMENT4 PLATFORM,
      DECODE(I.LOT_CONTROL_CODE,1,'No',2,'Yes') LOT_CONTROL,
      DECODE(I.SERIAL_NUMBER_CONTROL_CODE,1, 'No Control',2, 'Predefined',5, 'At Receipt',6,'At Sales Order Issue') SERIAL_CONTROL,
      DECODE(I.REVISION_QTY_CONTROL_CODE,1,'No',2,'Yes') REVISION_CONTROL,
      I.PRIMARY_UNIT_OF_MEASURE PRIMARY_UNIT_OF_MEASURE,
      I.SERVICE_ITEM_FLAG SERVICE_ITEM_FLAG,
      I.INVENTORY_ITEM_FLAG INVENTORY_ITEM_FLAG,
      I.ITEM_TYPE INVENTORY_ITEM_TYPE,
      I.INVENTORY_ITEM_STATUS_CODE ITEM_STATUS,
      -- Rev 1.9
      --CIC.ITEM_COST ITEM_FROZEN_COST,
      cic2.item_cost ITEM_FROZEN_COST,
      --end Rev 1.9
      SOB.CURRENCY_CODE FRZN_COST_CURRENCY
      -- Rev 2.1
      -- <Rev 1.8>
      --, cic2.item_cost NEW_FROZEN_COST
      -- end <Rev 1.8>
      , CIC.ITEM_COST OLD_FROZEN_COST
      --end Rev 2.1
  FROM MTL_SYSTEM_ITEMS_B I
  inner join MTL_ITEM_CATEGORIES IC
  on i.inventory_item_id = ic.inventory_item_id
  and i.organization_id = ic.organization_id
  inner join MTL_CATEGORIES CA
  on ic.category_id = ca.category_id
  and category_set_id = 1
  -- <Rev 2.1>
  left outer join CST_ITEM_COST_TYPE_V cic
  on i.inventory_item_id = cic.inventory_item_id
  and i.organization_id = cic.organization_id
  and cic.cost_type = 'FY10'
  left outer join CST_ITEM_COST_TYPE_V cic2
  on i.inventory_item_id = cic2.inventory_item_id
  and i.organization_id = cic2.organization_id
  and cic2.cost_type = 'Frozen'
  -- end <Rev 2.1>
  inner join org_organization_definitions ood
  ON i.organization_id = ood.organization_id
  INNER JOIN ---gl_sets_of_books sob  ---11i code modified
                gl_ledgers  sob       ---R12 Remediated
  ---on ood.set_of_books_id = sob.set_of_books_id---11i code modified
  on ood.set_of_books_id = sob.ledger_id         ---R12 Remediated
  where i.organization_id = 103
  and i.enabled_flag = 'Y'
  --and i.start_date_active is not null
  and ca.disable_date is null
  --and i.segment1 in ('PLATINUM')
  order by i.segment1;


CURSOR cur_get_management_units
IS
SELECT FLEX_VALUE, DESCRIPTION
FROM FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1010317;

CURSOR cur_get_departments
IS
SELECT FLEX_VALUE, DESCRIPTION
FROM FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1010318;

CURSOR cur_get_business_units
IS
SELECT FLEX_VALUE, DESCRIPTION
FROM FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1010316;

CURSOR cur_get_product_line
IS
SELECT FLEX_VALUE, DESCRIPTION
FROM FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1010315;

CURSOR cur_get_natural_acct
IS
SELECT FLEX_VALUE, DESCRIPTION
FROM FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1010319;

CURSOR cur_get_legal_entity
IS
SELECT FLEX_VALUE, DESCRIPTION
FROM FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1010314;

CURSOR cur_get_inter_company
IS
SELECT FLEX_VALUE, DESCRIPTION
FROM FND_FLEX_VALUES_VL
WHERE FLEX_VALUE_SET_ID = 1010314;

CURSOR cur_get_OU
IS
SELECT ORGANIZATION_ID, NAME
FROM HR_OPERATING_UNITS
ORDER BY ORGANIZATION_ID;



BEGIN
-----------------------
-- Set processing flag
-- Added 4/22/2011 by Eric Rossing to allow report to know when data is being updated
-----------------------

UPDATE XXHA_REPORT_CONTROL SET STATUS='PROCESSING' WHERE REPORT_NAME='DAILY_SALES';
COMMIT;

-----------------------
-- Purging the tables
-----------------------
/*****
  DELETE FROM XX_HAEMO_SALES_REVENUE;

        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_SALES_REVENUE table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_SHIPTO_CUST_DETAILS;

        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_SHIPTO_CUST_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_BILLTO_CUST_DETAILS;

        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_BILLTO_CUST_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_SOLDTO_CUST_DETAILS;

        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_SOLDTO_CUST_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_ITEM_DETAILS;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_ITEM_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_MGMTUNITS;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_MGMTUNITS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_DEPTS;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_DEPTS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_BUSSUNITS;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_BUSSUNITS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_PRODLINE;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_PRODLINE table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_NATACCT;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_NATACCT table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_LEGALENTITY;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_LEGALENTITY table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_INTERCOMPANY;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_INTERCOMPANY table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  DELETE FROM XX_HAEMO_OPUNITS;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Data deleted from XX_HAEMO_OPUNITS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  COMMIT;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Commit executed: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

*****/

  -- Rev 2.2 ERossing - 4/21/11 modified statement to only delete last six months of data
--  execute immediate 'truncate table haemo.XX_HAEMO_SALES_REVENUE';
--        fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_SALES_REVENUE table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));
  DELETE FROM XX_HAEMO_SALES_REVENUE
  -- Rev 2.3 ERossing - 3/22/12 modified calculation to use ADD_MONTHS instead
--  WHERE GL_DATE>=(SYSDATE - (INTERVAL '24' MONTH));
  WHERE GL_DATE>=(ADD_MONTHS(SYSDATE, -24));
        FND_FILE.PUT_LINE(FND_FILE.LOG,'Deleted last 24 months of records from XX_HAEMO_SALES_REVENUE table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));
	COMMIT;

  execute immediate 'truncate table haemo.XX_HAEMO_SHIPTO_CUST_DETAILS';
        fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_SHIPTO_CUST_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_BILLTO_CUST_DETAILS';
        fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_BILLTO_CUST_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_SOLDTO_CUST_DETAILS';
        fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_SOLDTO_CUST_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_ITEM_DETAILS';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_ITEM_DETAILS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_MGMTUNITS';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_MGMTUNITS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_DEPTS';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_DEPTS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_BUSSUNITS';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_BUSSUNITS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_PRODLINE';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_PRODLINE table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_NATACCT';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_NATACCT table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_LEGALENTITY';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_LEGALENTITY table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_INTERCOMPANY';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_INTERCOMPANY table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  execute immediate 'truncate table haemo.XX_HAEMO_OPUNITS';
  fnd_file.put_line(fnd_file.log,'Truncated XX_HAEMO_OPUNITS table: ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


------------------------------------
-- Populate XX_HAEMO_SALES_REVENUE
------------------------------------
    ln_record_count := 0;
    FOR rec_get_sales_revenue IN cur_get_sales_revenue
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_SALES_REVENUE
                 (TRX_NUMBER,
              CUSTOMER_TRX_ID,
        CUSTOMER_TRX_LINE_ID,
        BILL_TO_CUSTOMER_ID,
        SOLD_TO_CUSTOMER_ID,
      SHIP_TO_CUSTOMER_ID,
        EXCHANGE_RATE_TYPE,
        EXCHANGE_RATE,
        EXCHANGE_DATE,
        INVOICE_CURRENCY_CODE,
        TRX_DATE,
        GL_DATE,
        GL_POSTED_DATE,
        SALES_PERSON_NAME,
        PRIMARY_SALESREP_ID,
        CUST_TRX_TYPE_ID,
        LINE_TYPE,
        TRANSACTION_TYPE_NAME,
        LINE_NUMBER,
        QUANTITY_CREDITED,
        QUANTITY_INVOICED,
        QUANTITY_ORDERED,
        UNIT_SELLING_PRICE,
        INVENTORY_ITEM_ID,
        SALES_ORDER,
      SALES_ORDER_LINE,
        SALES_ORDER_REVISION,
        SALES_ORDER_SOURCE,
        UOM_CODE,
        GROSS_UNIT_SELLING_PRICE,
        REVENUE_AMOUNT,
        TRANSACTION_TYPE,
        SET_OF_BOOKS_ID,
        ACCTD_AMOUNT,
        LEGAL_ENTITY,
        PRODUCT_LINE,
        BUSINESS_UNIT,
        MANAGEMENT_UNIT,
        DEPARTMENT,
        NATURAL_ACCOUNT,
        INTERCOMPANY,
        OPERATING_UNIT_NAME,
        INTERFACE_HEADER_ATTRIBUTE1,
        INTERFACE_LINE_ATTRIBUTE6,
        ORGANIZATION_ID,
        FUNCTIONAL_CURRENCY_CODE,
        DISTRIBUTION_LEVEL_AMOUNT,
        DISTRIBUTION_LEVEL_PERCENT,
        SHIP_TO_SITE_USE_ID,
        BILL_TO_SITE_USE_ID,
        INTERCOMPANY_FLAG,
        TRADE_FLAG,
                        SOLD_TO_SITE_USE_ID,
                        ORDER_TYPE,
                        ORDER_LINE_TYPE,
                        END_CUSTOMER_ID,
      LAST_UPDATED_BY,
      CREATION_DATE,
      LAST_UPDATE_LOGIN,
      CREATED_BY,
      LAST_UPDATE_DATE
      ,PURCHASE_ORDER  -- <Rev 1.4>
      ,CUST_TRX_LINE_GL_DIST_ID  -- <Rev 1.5>
      ,CT_REFERENCE
            )
    VALUES
      (
       rec_get_sales_revenue.TRX_Number
              ,rec_get_sales_revenue.CUST_TRX_ID
        ,rec_get_sales_revenue.CUST_TRX_Line_ID
        ,rec_get_sales_revenue.Bill_to_Cust_ID
        ,rec_get_sales_revenue.Sold_to_Customer_ID
        ,rec_get_sales_revenue.Ship_to_customer_ID
        ,rec_get_sales_revenue.Exchange_Rate_Type
        ,rec_get_sales_revenue.Exchange_Rate
        ,rec_get_sales_revenue.Exchange_Date
        ,rec_get_sales_revenue.Transaction_Currency_Code
        ,rec_get_sales_revenue.Transaction_Date
        ,rec_get_sales_revenue.Accounting_Date
        ,rec_get_sales_revenue.INV_Post_GL_Date
        ,rec_get_sales_revenue.Sales_Person_Name
        ,rec_get_sales_revenue.Sales_Rep_ID
        ,rec_get_sales_revenue.Cust_Trx_Type_ID
        ,rec_get_sales_revenue.Line_Type
        ,rec_get_sales_revenue.Transaction_Type_Name
        ,rec_get_sales_revenue.Line_Number
        ,rec_get_sales_revenue.QTY_Credited
        ,rec_get_sales_revenue.QTY_Invoiced
              ,rec_get_sales_revenue.QTY_Ordered
        ,rec_get_sales_revenue.Selling_Price
        ,rec_get_sales_revenue.Item_ID
        ,rec_get_sales_revenue.SO_Number
        ,rec_get_sales_revenue.SO_Line
        ,rec_get_sales_revenue.SO_Revision
        ,rec_get_sales_revenue.SO_Source
        ,rec_get_sales_revenue.UOM_Code
        ,rec_get_sales_revenue.Gross_Unit_Selling_Price
          ,rec_get_sales_revenue.Revenue_Amount
        ,rec_get_sales_revenue.Transaction_Type
        ,rec_get_sales_revenue.Set_of_Book_ID
        ,rec_get_sales_revenue.Accounted_AMT
        ,rec_get_sales_revenue.Legal_Entity
        ,rec_get_sales_revenue.Product_Line
        ,rec_get_sales_revenue.Business_Unit
        ,rec_get_sales_revenue.Management_Unit
        ,rec_get_sales_revenue.Department
        ,rec_get_sales_revenue.Natural_Account
        ,rec_get_sales_revenue.Intercompany
        ,rec_get_sales_revenue.OU_Name
        ,rec_get_sales_revenue.Interface_Header_Attribute1
        ,rec_get_sales_revenue.Interface_Line_Attribute6
        ,rec_get_sales_revenue.Organization_ID
        ,rec_get_sales_revenue.Functional_Currency_Code
          ,rec_get_sales_revenue.Distribution_Level_Amount
        ,rec_get_sales_revenue.Distribution_Level_Percent
        ,rec_get_sales_revenue.Ship_to_Site_Use_ID
        ,rec_get_sales_revenue.Bill_to_Site_Use_ID
        ,rec_get_sales_revenue.Intercompany_Flag
              ,NULL
              ,NULL
              ,NULL
              ,NULL
              ,NULL
      ,FND_GLOBAL.USER_ID
      ,SYSDATE
      ,FND_GLOBAL.LOGIN_ID
      ,FND_GLOBAL.USER_ID
      ,SYSDATE
      ,rec_get_sales_revenue.purchase_order  -- <Rev 1.4>
      ,rec_get_sales_revenue.cust_trx_line_gl_dist_id  -- <Rev 1.5>
      ,rec_get_sales_revenue.ct_reference
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_SALES_REVENUE: ' || SQLERRM);
          END;
    ln_record_count := ln_record_count + 1;
  END LOOP;
  COMMIT;
    FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_SALES_REVENUE '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


----------------------------------------
-- Populate XX_HAEMO_BILLTO_CUST_DETAILS
----------------------------------------


  ln_record_count := 0;

  FOR rec_billto_cust_detls IN cur_get_cust_siteuse_detls ('BILL_TO')
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_BILLTO_CUST_DETAILS
      (
        BILLTO_SITE_NUMBER  -- <Rev 1.4>
       ,BILLTO_AGENT  -- <Rev 1.5>
       ,BILLTO_CUSTOMER_ID
         ,BILLTO_SITE_USE_ID
       ,BILLTO_CUSTOMER_NUMBER
       ,BILLTO_CUSTOMER_NAME
       ,BILLTO_LEGACY_CUS_NUMBER
       ,BILLTO_CUSTOMER_TYPE_CODE
       ,BILLTO_CUSTOMER_TYPE
       ,BILLTO_CUSTOMER_CLASS_CODE
       ,BILLTO_CUSTOMER_CLASS
       ,BILLTO_CUSTOMER_CATEGORY_CODE
       ,BILLTO_CUSTOMER_CATEGORY
       ,BILLTO_ADDR1
       ,BILLTO_ADDR2
       ,BILLTO_ADDR3
       ,BILLTO_ADDR4
       ,BILLTO_CITY
       ,BILLTO_COUNTY
       ,BILLTO_STATE
       ,BILLTO_PROVINCE
       ,BILLTO_POSTAL_CODE
       ,BILLTO_COUNTRY
       ,LAST_UPDATED_BY
       ,CREATION_DATE
       ,LAST_UPDATE_LOGIN
       ,CREATED_BY
       ,last_update_date
       --Rev 2.5
       ,rxc_billto
       --end
      )
    VALUES
      (
         rec_billto_cust_detls.SITE_NUMBER  -- <Rev 1.4>
        ,rec_billto_cust_detls.AGENT  -- <Rev 1.5>
      ,rec_billto_cust_detls.CUSTOMER_ID
            ,rec_billto_cust_detls.SITE_USE_ID
        ,rec_billto_cust_detls.CUSTOMER_NUMBER
        ,rec_billto_cust_detls.CUSTOMER_NAME
        ,rec_billto_cust_detls.LEGACY_CUS_NUMBER
        ,rec_billto_cust_detls.CUSTOMER_TYPE_CODE
        ,rec_billto_cust_detls.CUSTOMER_TYPE
        ,rec_billto_cust_detls.CUSTOMER_CLASS_CODE
        ,rec_billto_cust_detls.CUSTOMER_CLASS
        ,rec_billto_cust_detls.CUSTOMER_CATEGORY_CODE
        ,rec_billto_cust_detls.CUSTOMER_CATEGORY
        ,rec_billto_cust_detls.ADDR1
        ,rec_billto_cust_detls.ADDR2
        ,rec_billto_cust_detls.ADDR3
        ,rec_billto_cust_detls.ADDR4
        ,rec_billto_cust_detls.CITY
        ,rec_billto_cust_detls.COUNTY
        ,rec_billto_cust_detls.STATE
        ,rec_billto_cust_detls.PROVINCE
        ,rec_billto_cust_detls.POSTAL_CODE
        ,rec_billto_cust_detls.COUNTRY
      ,FND_GLOBAL.USER_ID
      ,SYSDATE
      ,FND_GLOBAL.LOGIN_ID
      ,FND_GLOBAL.USER_ID
      ,sysdate
      --Rev 2.5
      ,rec_billto_cust_detls.rxc_site
      --end
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_BILLTO_CUST_DETAILS: ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
        FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_BILLTO_CUST_DETAILS '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));



----------------------------------------
-- Populate XX_HAEMO_SHIPTO_CUST_DETAILS
----------------------------------------

  ln_record_count := 0;

  FOR rec_shipto_cust_detls IN cur_get_cust_siteuse_detls ('SHIP_TO')
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_SHIPTO_CUST_DETAILS
      (
        SHIPTO_SITE_NUMBER  -- <Rev 1.4>
       ,SHIPTO_AGENT  -- <Rev 1.5>
       ,SHIPTO_CUSTOMER_ID
       ,SHIPTO_SITE_USE_ID
       ,SHIPTO_CUSTOMER_NUMBER
       ,SHIPTO_CUSTOMER_NAME
       ,SHIPTO_LEGACY_CUS_NUMBER
       ,SHIPTO_CUSTOMER_TYPE_CODE
         ,SHIPTO_CUSTOMER_TYPE
       ,SHIPTO_CUSTOMER_CLASS_CODE
       ,SHIPTO_CUSTOMER_CLASS
       ,SHIPTO_CUSTOMER_CATEGORY_CODE
       ,SHIPTO_CUSTOMER_CATEGORY
       ,SHIPTO_ADDR1
       ,SHIPTO_ADDR2
       ,SHIPTO_ADDR3
               ,SHIPTO_ADDR4
       ,SHIPTO_CITY
       ,SHIPTO_COUNTY
       ,SHIPTO_STATE
       ,SHIPTO_PROVINCE
       ,SHIPTO_POSTAL_CODE
       ,SHIPTO_COUNTRY
       ,LAST_UPDATED_BY
       ,CREATION_DATE
       ,LAST_UPDATE_LOGIN
       ,CREATED_BY
       ,last_update_date
       --Rev 2.5
       ,rxc_shipto
       --end
      )
    VALUES
      (
         rec_shipto_cust_detls.SITE_NUMBER  -- <Rev 1.4>
        ,rec_shipto_cust_detls.AGENT  -- <Rev 1.5>
      ,rec_shipto_cust_detls.CUSTOMER_ID
            ,rec_shipto_cust_detls.SITE_USE_ID
        ,rec_shipto_cust_detls.CUSTOMER_NUMBER
        ,rec_shipto_cust_detls.CUSTOMER_NAME
        ,rec_shipto_cust_detls.LEGACY_CUS_NUMBER
        ,rec_shipto_cust_detls.CUSTOMER_TYPE_CODE
        ,rec_shipto_cust_detls.CUSTOMER_TYPE
        ,rec_shipto_cust_detls.CUSTOMER_CLASS_CODE
        ,rec_shipto_cust_detls.CUSTOMER_CLASS
        ,rec_shipto_cust_detls.CUSTOMER_CATEGORY_CODE
        ,rec_shipto_cust_detls.CUSTOMER_CATEGORY
        ,rec_shipto_cust_detls.ADDR1
        ,rec_shipto_cust_detls.ADDR2
        ,rec_shipto_cust_detls.ADDR3
        ,rec_shipto_cust_detls.ADDR4
        ,rec_shipto_cust_detls.CITY
        ,rec_shipto_cust_detls.COUNTY
        ,rec_shipto_cust_detls.STATE
        ,rec_shipto_cust_detls.PROVINCE
        ,rec_shipto_cust_detls.POSTAL_CODE
        ,rec_shipto_cust_detls.COUNTRY
      ,FND_GLOBAL.USER_ID
      ,SYSDATE
      ,FND_GLOBAL.LOGIN_ID
      ,FND_GLOBAL.USER_ID
      ,sysdate
      --Rev 2.5
       ,rec_shipto_cust_detls.rxc_site
       --end
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_SHIPTO_CUST_DETAILS: ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
        FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_SHIPTO_CUST_DETAILS '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));



----------------------------------------
-- Populate XX_HAEMO_SOLDTO_CUST_DETAILS
----------------------------------------

  ln_record_count := 0;

  FOR rec_soldto_cust_detls IN cur_get_cust_siteuse_detls ('SOLD_TO')
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_SOLDTO_CUST_DETAILS
      (
        SOLDTO_SITE_NUMBER  -- <Rev 1.4>
       ,SOLDTO_AGENT  -- <Rev 1.5>
       ,SOLDTO_CUSTOMER_ID
       ,SOLDTO_SITE_USE_ID
       ,SOLDTO_CUSTOMER_NUMBER
       ,SOLDTO_CUSTOMER_NAME
       ,SOLDTO_LEGACY_CUS_NUMBER
       ,SOLDTO_CUSTOMER_TYPE_CODE
       ,SOLDTO_CUSTOMER_TYPE
       ,SOLDTO_CUSTOMER_CLASS_CODE
       ,SOLDTO_CUSTOMER_CLASS
       ,SOLDTO_CUSTOMER_CATEGORY_CODE
       ,SOLDTO_CUSTOMER_CATEGORY
       ,SOLDTO_ADDR1
       ,SOLDTO_ADDR2
       ,SOLDTO_ADDR3
       ,SOLDTO_ADDR4
       ,SOLDTO_CITY
       ,SOLDTO_COUNTY
       ,SOLDTO_STATE
       ,SOLDTO_PROVINCE
       ,SOLDTO_POSTAL_CODE
       ,SOLDTO_COUNTRY
       ,LAST_UPDATED_BY
       ,CREATION_DATE
       ,LAST_UPDATE_LOGIN
       ,CREATED_BY
       ,LAST_UPDATE_DATE
      )
    VALUES
      (
         rec_soldto_cust_detls.SITE_NUMBER  -- <Rev 1.4>
        ,rec_soldto_cust_detls.AGENT  -- <Rev 1.5>
      ,rec_soldto_cust_detls.CUSTOMER_ID
            ,rec_soldto_cust_detls.SITE_USE_ID
        ,rec_soldto_cust_detls.CUSTOMER_NUMBER
        ,rec_soldto_cust_detls.CUSTOMER_NAME
        ,rec_soldto_cust_detls.LEGACY_CUS_NUMBER
        ,rec_soldto_cust_detls.CUSTOMER_TYPE_CODE
        ,rec_soldto_cust_detls.CUSTOMER_TYPE
        ,rec_soldto_cust_detls.CUSTOMER_CLASS_CODE
        ,rec_soldto_cust_detls.CUSTOMER_CLASS
        ,rec_soldto_cust_detls.CUSTOMER_CATEGORY_CODE
        ,rec_soldto_cust_detls.CUSTOMER_CATEGORY
        ,rec_soldto_cust_detls.ADDR1
        ,rec_soldto_cust_detls.ADDR2
        ,rec_soldto_cust_detls.ADDR3
        ,rec_soldto_cust_detls.ADDR4
        ,rec_soldto_cust_detls.CITY
        ,rec_soldto_cust_detls.COUNTY
        ,rec_soldto_cust_detls.STATE
        ,rec_soldto_cust_detls.PROVINCE
        ,rec_soldto_cust_detls.POSTAL_CODE
        ,rec_soldto_cust_detls.COUNTRY
      ,FND_GLOBAL.USER_ID
      ,SYSDATE
      ,FND_GLOBAL.LOGIN_ID
      ,FND_GLOBAL.USER_ID
      ,SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_SOLDTO_CUST_DETAILS: ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
        FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_SOLDTO_CUST_DETAILS '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));



------------------------------------
-- Populate XX_HAEMO_ITEM_DETAIL
------------------------------------

  ln_record_count := 0;

  FOR rec_get_item_detls IN cur_get_item_detls
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_ITEM_DETAILS
      (
        INVENTORY_ITEM_ID,
        ITEMNUMBER,
          DESCRIPTION,
          PRODUCT_LINE,
          PRODUCT_TYPE,
          PRODUCT_SUB_TYPE,
          PLATFORM,
          LOT_CONTROL,
          SERIAL_CONTROL,
          REVISION_CONTROL,
          PRIMARY_UNIT_OF_MEASURE,
          SERVICE_ITEM_FLAG,
          INVENTORY_ITEM_FLAG,
          INVENTORY_ITEM_TYPE,
          ITEM_STATUS,
          ITEM_FROZEN_COST,
          FRZN_COST_CURRENCY,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
          --Rev 1.9
          -- <Rev 1.8>
          --, NEW_FROZEN_COST
          -- end <Rev 1.8>
          , OLD_FROZEN_COST
          -- end Rev 1.9
      )
    VALUES
      (
       rec_get_item_detls.INVENTORY_ITEM_ID,
         rec_get_item_detls.ITEMNUMBER,
         rec_get_item_detls.DESCRIPTION,
         rec_get_item_detls.PRODUCT_LINE,
         rec_get_item_detls.PRODUCT_TYPE,
         rec_get_item_detls.PRODUCT_SUB_TYPE,
         rec_get_item_detls.PLATFORM,
         rec_get_item_detls.LOT_CONTROL,
         rec_get_item_detls.SERIAL_CONTROL,
         rec_get_item_detls.REVISION_CONTROL,
         rec_get_item_detls.PRIMARY_UNIT_OF_MEASURE,
         rec_get_item_detls.SERVICE_ITEM_FLAG,
         rec_get_item_detls.INVENTORY_ITEM_FLAG,
         rec_get_item_detls.INVENTORY_ITEM_TYPE,
         rec_get_item_detls.ITEM_STATUS,
         rec_get_item_detls.ITEM_FROZEN_COST,
         rec_get_item_detls.FRZN_COST_CURRENCY,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
       -- Rev 1.9
       -- <Rev 1.8>
       --, rec_get_item_detls.NEW_FROZEN_COST
      -- end <Rev 1.8>
      , rec_get_item_detls.OLD_FROZEN_COST
      --end Rev 1.9
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_ITEM_DETAILS: ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      --Rev 2.0
      insert into XX_HAEMO_ITEM_DETAILS(inventory_item_id,LAST_UPDATED_BY,CREATION_DATE,LAST_UPDATE_LOGIN,CREATED_BY,LAST_UPDATE_DATE)
                                values(0,FND_GLOBAL.USER_ID,SYSDATE,FND_GLOBAL.LOGIN_ID,FND_GLOBAL.USER_ID,SYSDATE);
      --Rev 2.0
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_ITEM_DETAILS '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

------------------------------------
-- Populate XX_HAEMO_MgmtUnits
------------------------------------

  ln_record_count := 0;

  FOR rec_get_management_units IN cur_get_management_units
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_MgmtUnits
      (
        FLEX_VALUE,
        DESCRIPTION,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_get_management_units.FLEX_VALUE,
         rec_get_management_units.DESCRIPTION,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_MgmtUnits ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_MgmtUnits '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

------------------------------------
-- Populate XX_HAEMO_Depts
------------------------------------

  ln_record_count := 0;

  FOR rec_get_departments IN cur_get_departments
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_Depts
      (
        FLEX_VALUE,
        DESCRIPTION,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_get_departments.FLEX_VALUE,
         rec_get_departments.DESCRIPTION,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_Depts ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_Depts '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));



------------------------------------
-- Populate XX_HAEMO_BussUnits
------------------------------------

  ln_record_count := 0;

  FOR rec_get_business_units IN cur_get_business_units
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_BussUnits
      (
        FLEX_VALUE,
        DESCRIPTION,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_get_business_units.FLEX_VALUE,
         rec_get_business_units.DESCRIPTION,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_BussUnits ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_BussUnits '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


------------------------------------
-- Populate XX_HAEMO_ProdLine
------------------------------------

  ln_record_count := 0;

  FOR rec_get_product_line IN cur_get_product_line
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_ProdLine
      (
        FLEX_VALUE,
        DESCRIPTION,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_get_product_line.FLEX_VALUE,
         rec_get_product_line.DESCRIPTION,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_ProdLine ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_ProdLine '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


------------------------------------
-- Populate XX_HAEMO_NatAcct
------------------------------------

  ln_record_count := 0;

  FOR rec_cur_natural_acct IN cur_get_natural_acct
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_NatAcct
      (
        FLEX_VALUE,
        DESCRIPTION,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_cur_natural_acct.FLEX_VALUE,
         rec_cur_natural_acct.DESCRIPTION,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_NatAcct ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_NatAcct '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


------------------------------------
-- Populate XX_HAEMO_LegalEntity
------------------------------------

  ln_record_count := 0;

  FOR rec_get_legal_entity IN cur_get_legal_entity
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_LegalEntity
      (
        FLEX_VALUE,
        DESCRIPTION,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_get_legal_entity.FLEX_VALUE,
         rec_get_legal_entity.DESCRIPTION,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_LegalEntity ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_LegalEntity '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


------------------------------------
-- Populate XX_HAEMO_InterCompany
------------------------------------

  ln_record_count := 0;

  FOR rec_get_inter_company IN cur_get_inter_company
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_InterCompany
      (
        FLEX_VALUE,
        DESCRIPTION,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_get_inter_company.FLEX_VALUE,
         rec_get_inter_company.DESCRIPTION,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_InterCompany ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_InterCompany '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


------------------------------------
-- Populate XX_HAEMO_OPUNITS
------------------------------------

  ln_record_count := 0;

  FOR rec_get_OU IN cur_get_OU
      LOOP
        BEGIN
          INSERT INTO XX_HAEMO_OPUNITS
      (
        ORGANIZATION_ID,
        NAME,
          LAST_UPDATED_BY,
          CREATION_DATE,
          LAST_UPDATE_LOGIN,
          CREATED_BY,
          LAST_UPDATE_DATE
      )
    VALUES
      (
       rec_get_OU.ORGANIZATION_ID,
         rec_get_OU.NAME,
         FND_GLOBAL.USER_ID,
       SYSDATE,
       FND_GLOBAL.LOGIN_ID,
       FND_GLOBAL.USER_ID,
       SYSDATE
      );

      EXCEPTION
                    WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting into XX_HAEMO_OPUNITS ' || SQLERRM);

        END;
        ln_record_count := ln_record_count + 1;
      END LOOP;
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG, ln_record_count || ' - Records Successfully inserted in XX_HAEMO_OPUNITS '|| TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));


-------------------------------------------------------------------
-- Call procedure to populate TradeFlag, SoldToSite, OrderType, OrderLineType and EndCustomer in XX_HAEMO_SALES_REVENUE
-------------------------------------------------------------------

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Calling XX_HAEMO_CUSTOMER_TRADE_PKG.Main procedure to get the Trade Flag : ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  BEGIN
    XX_HAEMO_CUSTOMER_TRADE_PKG.Main(NULL);
  END;

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Trade Flag updated into XX_HAEMO_SALES_REVENUE table : ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

-------------------------------------------------------------------
-- IPadela - 11/12/08 - Call procedure to refresh the actual for current and prior fiscal years in the sales plan fact table
-------------------------------------------------------------------

  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Calling XX_HAEMO_REF_PLAN_ACTUALS_PKG.Main procedure to refresh the actuals for current and prior fiscal years in the sales plan fact table : ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

  BEGIN
    XX_HAEMO_REF_PLAN_ACTUALS_PKG.Main(p_curr_fis_year, p_retcode);
  END;
  if (p_retcode = 0) then
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Actuals for the current and prior fiscal years successfully refreshed in the sales plan fact table : ' || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));
  else
    x_errbuf := 'Failed to refresh current and prior year actuals in the sales plan fact table';
    x_retcode := 4;
  end if;
-----------------------
-- Unset processing flag
-- Added 4/22/2011 by Eric Rossing to allow report to know when data is being updated
-----------------------

  UPDATE XXHA_REPORT_CONTROL SET STATUS='READY' WHERE REPORT_NAME='DAILY_SALES';
  COMMIT;

 EXCEPTION
        WHEN OTHERS THEN
        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Encountered Error.' || SQLERRM || TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS'));

END GET_SALES_REVENUE;

end xx_haemo_get_sales_data_pkg;
/
