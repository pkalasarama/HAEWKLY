CREATE OR REPLACE PACKAGE Haemo_Wm_Proc_Exp_Rep_Imp_Pkg AUTHID CURRENT_USER
-- +=====================================================================================+
-- | Name        : Haemo_Wm_Proc_Exp_Rep_Imp_Pkg                 	                 |
-- | Purpose     : Run Expense Report Import program.    				 |
-- |                                                             	                 |
-- | Description : Procedure to determine calling parameters for 			 |
-- |		   Expense Report Import Concurrent Request					 |
-- |		   Takes in the mandatory and optional parameters required for 		 |
-- |		   Expense Report Import Concurrent Request.					 |
-- |                                                                           		 |
-- |                                            					 |
-- |                                                                           		 |
-- | Comment     :                                                                 |
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who       What                                             		 |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 20120806  1.0  Eric Rossing   Initial version.					 |
-- | 20140212  2.0  Eric Rossing   Modified to use Expense Report Export program used by R12 |
-- +=====================================================================================+
AS
PROCEDURE HAEMO_WM_HANDLE_EXP_REP_IMP(p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
          p_batch_name IN VARCHAR,
          p_organization_id IN VARCHAR,
          p_send_notification_to IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg OUT VARCHAR
			    ) ;

END Haemo_Wm_Proc_Exp_Rep_Imp_Pkg;
/


CREATE OR REPLACE PACKAGE BODY Haemo_Wm_Proc_Exp_Rep_Imp_Pkg
AS
-- +=====================================================================================+
-- | Name        : Haemo_Wm_Proc_Exp_Rep_Imp_Pkg                 	                 |
-- | Purpose     : Run Expense Report Import program.    				 |
-- |                                                             	                 |
-- | Description : Procedure to determine calling parameters for 			 |
-- |		   Expense Report Import Concurrent Request					 |
-- |		   Takes in the mandatory and optional parameters required for 		 |
-- |		   Expense Report Import Concurrent Request.					 |
-- |                                                                           		 |
-- |                                            					 |
-- |                                                                           		 |
-- | Comment     :                                                                 |
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who       What                                             		 |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 20120806  1.0  Eric Rossing   Initial version.					 |
-- | 20140212  2.0  Eric Rossing   Modified to use Expense Report Export program used by R12 |
-- +=====================================================================================+

PROCEDURE HAEMO_WM_HANDLE_EXP_REP_IMP(p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
          p_batch_name IN VARCHAR,
          p_organization_id IN VARCHAR,
          p_send_notification_to IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg OUT VARCHAR
			    )
IS
	v_program  				   VARCHAR2(20):='APXEXPER'; -- XXHA_ECO_CREATE_ECO Program
	v_application		   	   	   VARCHAR2(20):='SQLAP'; -- Application
	v_application_id		           NUMBER;
	v_user_id				   NUMBER;
	v_user_responsibility_id                   NUMBER;
  v_org_id  NUMBER;

--Fixed Parameters
  v_source  VARCHAR2(25):='XpenseXpress';
  v_transfer_dff      VARCHAR2(1):='Y';
  v_gl_date DATE:=NULL;
  v_group VARCHAR2(1):=NULL;
  v_commit_batch_size NUMBER:=99999999;
  v_debug_switch VARCHAR2(1):='N';
  v_transfer_attachments VARCHAR2(1):='Y';
BEGIN

	  -- Fetch Application id for INV Application
	  v_errmsg:='Fetching Application id';

	  SELECT application_id
	  INTO   v_application_id
	  FROM   fnd_application
	  WHERE  application_short_name = v_application;

	  -- Fetch the User Id
	  v_errmsg:='Fetching the User Id';

	  v_user_id:=wm_conc_request_pkg.get_user_id(p_user);

	  -- Fetch the Responsibility Id
	  v_errmsg:='Fetching the Responsibility Id';

	  v_user_responsibility_id:=wm_conc_request_pkg.get_user_responsibility_id(p_user_responsibility);

           -- Initialize environment
    v_errmsg:='Initializing environment';

	  Fnd_Global.apps_initialize(v_user_id,v_user_responsibility_id,v_application_id);
    fnd_request.set_org_id(fnd_global.org_id) ;

          v_errmsg:='Calling Submit Request';

	  -- Call to submit request

	  wm_conc_request_pkg.wm_request_submit(v_application_id,
	  					 v_user_responsibility_id,
	  					 v_user_id,
	  					 v_application,
			  			 v_program,
			  			 v_status,
						 v_request_id,
						 NULL,
			  			 NULL,
			  			 o_message,
						 v_errmsg,
              p_batch_name,
              v_source,
              v_transfer_dff,
              v_gl_date,
              v_group,
              v_commit_batch_size,
              v_debug_switch,
              p_organization_id,
              p_send_notification_to,
              v_transfer_attachments
           			  	     	 );



EXCEPTION
 WHEN OTHERS THEN
 v_errmsg:=v_errmsg||SQLERRM;
 v_status:='FAILED';

END HAEMO_WM_HANDLE_EXP_REP_IMP;

END Haemo_Wm_Proc_Exp_Rep_Imp_Pkg;
/
