CREATE OR REPLACE PACKAGE      XXHA_AP_5DPPAY_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_AP_5DPPAY_PKG
* Purpose      : This procedure generates positive pay output file for the Canadian Operations of 5D
*
*
*
*
*
*
* Tables Accessed:
* ----------------
* Access Type (I - Insert, S - Select, U - Update, D - Delete)
* AP_BANK_ACCOUNTS - Select
* AP_BANK_BRANCHES - Select
* AP_CHECKS        - Select
* AP_CHECK_STOCKS  - Select
* AP_CHECKS_ALL    - Update
*
* Change History:
* ----------------
* Ver        Date            Author               Description
* ------     -----------     -----------------    ---------------
* 1.0        23-Jun-2009     Suresh Ramamoorthy  First version of Positive Pay program exclusively for 5D Canada Mellon Bank
*****************************************************************************************/

PROCEDURE gen_ppay (
                   errbuf               OUT  VARCHAR2
               ,   retcode              OUT  VARCHAR2
	           ,   p_bank_name          IN   varchar2
			   ,   p_bank_acct_number   IN   varchar2
               ,   p_check_start_date   IN   date
			   ,   p_check_end_date     IN   date
               ) ;

END XXHA_AP_5DPPAY_PKG;

/


CREATE OR REPLACE PACKAGE BODY      XXHA_AP_5DPPAY_PKG  AS
/***********************************************************************************************************************************
* Package Name :  XXHA_AP_5DPPAY_PKG
* Purpose      : This procedure generates positive pay output file for the Canadian Operations of 5D
*
*
*
*
*
*
* Tables Accessed:
* ----------------
* Access Type (I - Insert, S - Select, U - Update, D - Delete)
* AP_BANK_ACCOUNTS - Select
* AP_BANK_BRANCHES - Select
* AP_CHECKS        - Select
* AP_CHECK_STOCKS  - Select
* AP_CHECKS_ALL    - Update
*
* Change History:
* ----------------
* Ver        Date            Author               Description
* ------     -----------     -----------------    ---------------
* 1.0        23-Jun-2009     Suresh Ramamoorthy  First version of Positive Pay program exclusively for 5D Canada Mellon Bank
***********************************************************************************************************************************/
PROCEDURE gen_ppay (
                   errbuf              OUT  VARCHAR2
               ,   retcode             OUT  VARCHAR2
			   ,   p_bank_name	       IN   varchar2
               ,   p_bank_acct_number  IN   varchar2
               ,   p_check_start_date  IN   date
			   ,   p_check_end_date    IN   date
               )
IS
cursor cur_bank_account is
/*select DISTINCT abb.BANK_NUM  ---11i code modified
,      aba.BANK_ACCOUNT_NUM
from   ap_bank_accounts aba
,      ap_bank_branches abb
where  aba.bank_branch_id = abb.bank_branch_id
and    abb.bank_name = NVL(p_bank_name,'Mellon Bank')
and    aba.bank_account_num = NVL(p_bank_acct_number,'01-1-01081') ;*/

select distinct abb.branch_number              ---R12 Remediated
,		            aba.bank_account_num
from	---ap_bank_accounts_all aba
         ce_bank_accounts aba
---,		ap_bank_branches abb
,       ce_bank_branches_v abb
where	---aba.bank_branch_id = abb.bank_branch_id
         aba.bank_branch_id = abb.branch_party_id
and    abb.bank_name = nvl(p_bank_name,'Mellon Bank')
and    aba.bank_account_num = NVL(p_bank_acct_number,'01-1-01081') ;
CURSOR cur_check_content(p_org_id IN number, p_bank_num IN VARCHAR2, p_bank_acct_num IN VARCHAR2) IS
/*select
  lpad(ac.check_number,12,0) cheque_serial_number    11i code modified
, lpad(replace(abb.bank_num,' ',''),8,0) bank_transit_number
, lpad(replace(aba.bank_account_num,'-',''),14,0) bank_account_number
, lpad(trim(to_char(ac.amount * 100)),15,'0') cheque_amount
, to_char(ac.check_date,'YYYYMMDD') cheque_issue_date
, rpad(ac.vendor_name,11) cust_reference
, rpad(' ',8) filler
, ac.vendor_name
, ac.address_line1 vendor_address_line1
, decode(ac.status_lookup_code,'ISSUED','NEGOTIABLE',ac.status_lookup_code) status_lookup_code
, ac.currency_code
, ac.check_number
, ac.check_id
, ac.check_stock_id
, ac.amount
from   ap_checks ac
,      ap_check_stocks acs
,      ap_bank_accounts aba
,      ap_bank_branches abb
where 1 = 1
   and ac.status_lookup_code NOT in ('VOIDED','SPOILED','SETUP','OVERFLOW') -- per Andrew Barker of Mellon Bank's e-mail dated 6/25/2009 12:56pm
   and ac.payment_method_lookup_code = 'CHECK'
   and ac.check_stock_id = acs.check_stock_id
   and acs.bank_account_id = aba.bank_account_id
   and aba.bank_branch_id = abb.bank_branch_id
   and abb.bank_num = p_bank_num
   and aba.bank_account_num = p_bank_acct_num
   and ac.org_id = p_org_id
   AND (
        (trunc(ac.check_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
        -- OR
        -- (trunc(ac.void_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
       )
order by 1,2,3 ;*/
---R12 Remediated
select
  lpad(ac.check_number,12,0) cheque_serial_number
---, lpad(replace(abb.bank_num,' ',''),8,0) bank_transit_number
, lpad(replace(abb.branch_number,' ',''),8,0) bank_transit_number
, lpad(replace(aba.bank_account_num,'-',''),14,0) bank_account_number
, lpad(trim(to_char(ac.amount * 100)),15,'0') cheque_amount
, to_char(ac.check_date,'YYYYMMDD') cheque_issue_date
, rpad(ac.vendor_name,11) cust_reference
, rpad(' ',8) filler
, ac.vendor_name
, ac.address_line1 vendor_address_line1
, decode(ac.status_lookup_code,'ISSUED','NEGOTIABLE',ac.status_lookup_code) status_lookup_code
, ac.currency_code
, ac.check_number
, ac.check_id
---, ac.check_stock_id   ---11i code modified
, ac.payment_document_id ---R12 Remediated
, ac.amount
from   ap_checks ac
---,      ap_check_stocks acs---11i code modified
,       ce_payment_documents  acs ---R12 Remediated
---,      ap_bank_accounts aba---11i code modified
,      ce_bank_accounts  aba  ---R12 Remediated
---,      ap_bank_branches abb---11i code modified
,      CE_BANK_BRANCHES_V abb   ---R12 Remediated
where 1 = 1
   and ac.status_lookup_code NOT in ('VOIDED','SPOILED','SETUP','OVERFLOW') -- per Andrew Barker of Mellon Bank's e-mail dated 6/25/2009 12:56pm
   and ac.payment_method_lookup_code = 'CHECK'
   ---and ac.check_stock_id = acs.check_stock_id---11i code modified
   and ac.payment_document_id = acs.payment_document_id ---R12 Remediated
   ---and acs.bank_account_id = aba.bank_account_id---11i code modified
   and acs.internal_bank_account_id = aba.bank_account_id ---R12 Remediated
   ---and aba.bank_branch_id = abb.bank_branch_id---11i code modified
   and aba.bank_branch_id = abb.branch_party_id ---R12 Remediated
   ---and abb.bank_num = p_bank_num11i code modified
   and abb.branch_number = p_bank_num---R12 Remediated
   and aba.bank_account_num = p_bank_acct_num
   and ac.org_id = p_org_id
   AND (
        (trunc(ac.check_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
        -- OR
        -- (trunc(ac.void_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
       )
order by 1,2,3 ;

l_org_id      	   NUMBER;
l_detail_rec  	   varchar2(250);

l_status_lookup_code_val NUMBER := 0;
l_add_issue_count  NUMBER := 0;
l_tot_issue_amount NUMBER := 0;
l_void_issue_count NUMBER := 0;
l_tot_void_amount  NUMBER := 0;
l_tot_record_count NUMBER := 0;

l_user_id          NUMBER := 0;
BEGIN
-- Deriving the organization id and user_id
FND_CLIENT_INFO.SET_ORG_CONTEXT(FND_PROFILE.VALUE('ORG_ID'));
  l_org_id  := FND_PROFILE.VALUE('ORG_ID');
  l_user_id := FND_GLOBAL.user_id ;
FOR c_bank_acct in cur_bank_account
  LOOP
l_void_issue_count := 0;
   l_tot_void_amount  := 0;
   l_add_issue_count  := 0;
   l_tot_issue_amount := 0;
FOR c_details in cur_check_content(l_org_id,c_bank_acct.branch_number,c_bank_acct.bank_account_num)
      LOOP
        l_detail_rec := c_details.cheque_serial_number||c_details.bank_transit_number||c_details.bank_account_number||
                        c_details.cheque_amount||c_details.cheque_issue_date||c_details.cust_reference||c_details.filler;

		-- This update is required as per the standard Oracle report AFTER_REPORT trigger which does the same
        UPDATE ap_checks_all
        SET    positive_pay_status_code = DECODE(status_lookup_code,
			   							  		'NEGOTIABLE','SENT AS NEGOTIABLE',
        		  						   	 	'ISSUED', 'SENT AS NEGOTIABLE',
        										'CLEARED','SENT AS NEGOTIABLE',
        										'CLEARED BUT UNACCOUNTED', 'SENT AS NEGOTIABLE',
											    'RECONCILED','SENT AS NEGOTIABLE',
                          						'RECONCILED UNACCOUNTED','SENT AS NEGOTIABLE',
											    'VOIDED','SENT AS VOIDED',
											    'SPOILED' ,'SENT AS VOIDED',
                          						'SET UP','SENT AS VOIDED',
                          						'OVERFLOW','SENT AS VOIDED')
        ,      last_updated_by  = l_user_id
        ,      last_update_date = sysdate
        WHERE check_id = c_details.check_id
        and   check_number = c_details.check_number
        ---AND   check_stock_id = c_details.check_stock_id ;---11i code modified
        AND   PAYMENT_DOCUMENT_ID = c_details.PAYMENT_DOCUMENT_ID ;---R12 Remediated
l_tot_record_count := l_tot_record_count + 1;
        -- THE FOLLOWING VOID LOGIC IS LEFT ALONE IN CASE MELLON BANK MOVES AWAY FROM MANUAL VOIDS TO HANDLING VOIDS THRU POSITIVE PAY EXTRACT
if c_details.status_lookup_code in ('OVERFLOW','VOIDED','SETUP','SPOILED') then
    	  l_void_issue_count := l_void_issue_count + 1;
		  l_tot_void_amount  := l_tot_void_amount + NVL(c_details.amount,0);
    	else
    	  l_add_issue_count  := l_add_issue_count + 1 ;
		  l_tot_issue_amount := l_tot_issue_amount + NVL(c_details.amount,0);
    	end if;

        fnd_file.put_line(FND_FILE.OUTPUT,l_detail_rec);
END LOOP ;
fnd_file.put_line(FND_FILE.LOG,'DEBUG: l_add_issue_count:'||l_add_issue_count||'; l_tot_issue_amount:'||l_tot_issue_amount||'; l_void_issue_count:'||l_void_issue_count||'; l_tot_void_amount:'||l_tot_void_amount);
END LOOP ;
IF NVL(l_tot_record_count,0) = 0 THEN
     FND_FILE.PUT_LINE( FND_FILE.LOG, 'No File was created because of ' ||to_char(l_tot_record_count) || ' records ');
  END IF;
commit; -- Commit is required for the AP_CHECKS update
-- Outer Block exception
  EXCEPTION
    WHEN OTHERS THEN
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -Unexpected error '||SQLERRM);
       FND_FILE.PUT_LINE(FND_FILE.LOG,' Unexpected error : '||SQLERRM);
IF cur_bank_account%ISOPEN THEN
           CLOSE cur_bank_account;
       END IF;
IF cur_check_content%ISOPEN THEN
           CLOSE cur_check_content;
       END IF;
errbuf :='Unknown Errors occured';
       retcode := -1;
END gen_ppay;
end xxha_ap_5dppay_pkg;
/
