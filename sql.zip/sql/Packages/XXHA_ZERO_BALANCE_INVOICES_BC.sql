CREATE OR REPLACE PACKAGE XXHA_ZERO_BALANCE_INVOICES_BC AUTHID CURRENT_USER AS

/*****************************************************************************************
* Package Name : XXHA_ZERO_BALANCE_INVOICES_BC                                           *
* Purpose      : This package provides functions to retrieve counts for the consolidated *
*                billing records.  This processing checks for zero balance invoices.     *
*                Change Request: ERP102313                                               *
*                                                                                        *
* Procedures   :  p_zero_inv_1                                                           *
*                 p_zero_inv_2                                                           *
*                 p_zero_inv_3                                                           *
*                                                                                        *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*    ar_cons_inv			 	     S                                                           *
*    hz_cust_site_uses			 S                                                           *
*    hz_cust_acct_sites			 S                                                           *
*    hz_party_sites				   S                                                           *
*    hz_locations				     S                                                           *
*    fnd_territories_vl			 S                                                           *
*    hz_cust_accounts			   S                                                           *
*    hz_parties				       S                                                           *
*    ar_cons_inv_trx         S                                                           *
*    ar_payment_schedules    S                                                           *
*    ra_customer_trx_all     S                                                           *
*    ar_cons_inv_trx_lines   S                                                           *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        05-Feb-2009     B. Marcoux           Initial Version                        *
*****************************************************************************************/

/* globals for cache */
gv_count              NUMBER           := NULL;

/* ************************************************************************************ */
PROCEDURE p_zero_inv_1 (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE,
                        p_count            OUT NUMBER) ;                    

FUNCTION f_zero_inv_1  (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE)
RETURN NUMBER;


/* ************************************************************************************ */
PROCEDURE p_zero_inv_2 (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE,
                        p_count            OUT NUMBER) ;                    

FUNCTION f_zero_inv_2  (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE)
RETURN NUMBER;


/* ************************************************************************************ */
PROCEDURE p_zero_inv_3 (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE,
                        p_count            OUT NUMBER) ;                    

FUNCTION f_zero_inv_3  (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE)
RETURN NUMBER;

END XXHA_ZERO_BALANCE_INVOICES_BC;
/


CREATE OR REPLACE PACKAGE BODY XXHA_ZERO_BALANCE_INVOICES_BC AS
/*****************************************************************************************
* Package Name : XXHA_ZERO_BALANCE_INVOICES_BC                                           *
* Purpose      : This package provides functions to retrieve counts for the consolidated *
*                billing records.  This processing checks for zero balance invoices.     *
*                                                                                        *
* Called From  : XXHA_ARXCBI_BC - Consolidated Billing                                   *
*                                                                                        *
* Parameters             Type       Description                                          *
* p_account_number       Nbr                                                             *
* p_cons_inv_id          Nbr                                                             *
* p_date                 Date                                                            *
* p_count                Nbr                                                             *
*                                                                                        *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*    ar_cons_inv			 	     S                                                           *
*    hz_cust_site_uses			 S                                                           *
*    hz_cust_acct_sites			 S                                                           *
*    hz_party_sites				   S                                                           *
*    hz_locations				     S                                                           *
*    fnd_territories_vl			 S                                                           *
*    hz_cust_accounts			   S                                                           *
*    hz_parties				       S                                                           *
*    ar_cons_inv_trx         S                                                           *
*    ar_payment_schedules    S                                                           *
*    ra_customer_trx_all     S                                                           *
*    ar_cons_inv_trx_lines   S                                                           *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        05-Feb-2009     B. Marcoux           Initial Version                        *
* 1.1        26-Sep-2012     sboppana             Initial Version                        *
*****************************************************************************************/

/* ************************************************************************************ */
/* Given account_number, cons_inv_id and date return count of invoices                  */
/* that don't have a zero balance.                                                      */
/* Selection for transaction_types:                                                     */
/*  'INVOICE'                                                                           */
/*  'CREDIT_MEMO'                                                                       */
/*  'XSITE_CMREV'                                                                       */
/*  'XSITE_CMAPP'                                                                       */
/*  'EXCLUDE_CMREV'                                                                     */
/*  'EXCLUDE_CMAPP')                                                                    */
PROCEDURE p_zero_inv_1 (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE,
                        p_count            OUT NUMBER)  AS
BEGIN
SELECT
     nvl(COUNT(*),'0')
INTO
     p_count
from
     ar_cons_inv_all			 	     I
,    hz_cust_site_uses			 SU
,    hz_cust_acct_sites			 A
,    hz_party_sites				   party_site
,    hz_locations				     loc
,    fnd_territories_vl			 T
,    hz_cust_accounts			   C
,    hz_parties				       party
,    ar_cons_inv_trx_all         IT
,    ar_payment_schedules    PS
,    ra_customer_trx_all     rct
,    ar_cons_inv_trx_lines_all   trxl
WHERE
     I.print_status 		        = 'PRINTED'
AND  I.status 			    	      <> 'REJECTED'
AND  C.cust_account_id		      = I.customer_id
AND  C.party_id				          = party.party_id
AND  SU.site_use_id			        = I.site_use_id
AND  A.cust_acct_site_id	      = SU.cust_acct_site_id
AND  A.party_site_id			      = party_site.party_site_id
AND  loc.location_id			      = party_site.location_id
AND  T.territory_code(+)	      = loc.country
/*AND  (select customer_class_code from ra_customers where customer_id = I.customer_id) = 'BB'
 R12 Upgrade Modified on 09/26/2012 by Sboppana, Rolta */
and c.customer_class_code = 'BB'
--and  i.cut_off_date				      = p_date
and (i.cut_off_date				= p_date
or i.billing_date         = p_date
)
AND  C.account_number			      = p_account_number
AND  IT.cons_inv_id				      = p_cons_inv_id
AND  IT.transaction_type			  in ('INVOICE', 'CREDIT_MEMO', 'XSITE_CMREV', 'XSITE_CMAPP', 'EXCLUDE_CMREV', 'EXCLUDE_CMAPP')
AND  PS.payment_schedule_id(+)	= DECODE(IT.transaction_type, 'INVOICE', IT.adj_ps_id, 'CREDIT_MEMO', IT.adj_ps_id, NULL)
AND  IT.trx_number				      = rct.trx_number
AND  IT.org_id				          = rct.org_id
AND  trxl.cons_inv_id			      = p_cons_inv_id
AND  trxl.cons_inv_line_number	= IT.cons_inv_line_number
AND  trxl.unit_selling_price    <> 0
GROUP BY
     C.account_number
ORDER BY
     C.account_number
;
END p_zero_inv_1;
/* ************************************************************************************ */
FUNCTION f_zero_inv_1  (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE)
RETURN NUMBER AS
BEGIN
    p_zero_inv_1(p_account_number, p_cons_inv_id, p_date, gv_count);
    RETURN(gv_count);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
        RETURN '0';
  WHEN OTHERS THEN
        RETURN '0';
END f_zero_inv_1;
/* ************************************************************************************ */
/* Given account_number, cons_inv_id and date return count of invoices                  */
/* that don't have a zero balance.                                                      */
/* Selection for transaction_types:                                                     */
/*  'ADJUSTMENT'                                                                        */
PROCEDURE p_zero_inv_2 (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE,
                        p_count            OUT NUMBER)  AS
BEGIN
SELECT
     nvl(COUNT(*),'0')
INTO
     p_count
from
     ar_cons_inv_all			 	     I
,    hz_cust_site_uses			 SU
,    hz_cust_acct_sites			 A
,    hz_party_sites				   party_site
,    hz_locations				     loc
,    fnd_territories_vl			 T
,    hz_cust_accounts			   C
,    hz_parties				       party
,    ar_cons_inv_trx_all         IT
,    ar_payment_schedules    PS
,    ra_customer_trx_all     rct
,    ar_cons_inv_trx_lines_all   trxl
WHERE
     I.print_status 		        = 'PRINTED'
AND  I.status 			    	      <> 'REJECTED'
AND  C.cust_account_id		      = I.customer_id
AND  C.party_id				          = party.party_id
AND  SU.site_use_id			        = I.site_use_id
AND  A.cust_acct_site_id	      = SU.cust_acct_site_id
AND  A.party_site_id			      = party_site.party_site_id
AND  loc.location_id			      = party_site.location_id
AND  T.territory_code(+)	      = loc.country
/*AND  (select customer_class_code from ra_customers where customer_id = I.customer_id) = 'BB'
 R12 Upgrade Modified on 09/26/2012 by Sboppana, Rolta */
and c.customer_class_code = 'BB'
--AND  I.cut_off_date				      = p_date
and (i.cut_off_date				= p_date
or i.billing_date         = p_date
)
AND  C.account_number			      = p_account_number
AND  IT.cons_inv_id				      = p_cons_inv_id
AND  IT.transaction_type			  = 'ADJUSTMENT'
AND  PS.payment_schedule_id(+)	= DECODE(IT.transaction_type, 'INVOICE', IT.adj_ps_id, 'CREDIT_MEMO', IT.adj_ps_id, NULL)
AND  IT.trx_number				      = rct.trx_number
AND  IT.org_id				          = rct.org_id
AND IT.amount_original          <> 0
GROUP BY
     C.account_number
ORDER BY
     C.account_number
;
END p_zero_inv_2;
/* ************************************************************************************ */
FUNCTION f_zero_inv_2  (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE)
RETURN NUMBER AS
BEGIN
    p_zero_inv_2(p_account_number, p_cons_inv_id, p_date, gv_count);
    RETURN(gv_count);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
        RETURN '0';
  WHEN OTHERS THEN
        RETURN '0';
END f_zero_inv_2;
/* ************************************************************************************ */
/* Given account_number, cons_inv_id and date return count of invoices                  */
/* that don't have a zero balance.                                                      */
/* Selection for transaction_types:                                                     */
/*  'ADJUSTMENT'                                                                        */
/*  'RECEIPT'                                                                           */
/*  'RECEIPT REV'                                                                       */
/*  'XSITE RECREV'                                                                      */
/*  'XSITE RECAPP'                                                                      */
/*  'XCURR RECREV'                                                                      */
/*  'XCURR RECAPP'                                                                      */
/*  'XSITE XCURR RECREV'                                                                */
/*  'XSITE XCURR RECAPP'                                                                */
/*  'EXCLUDE RECREV'                                                                    */
/*  'EXCLUDE RECAPP'                                                                    */
PROCEDURE p_zero_inv_3 (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE,
                        p_count            OUT NUMBER)  AS
BEGIN
SELECT
     nvl(COUNT(*),'0')
INTO
     p_count
from
     ar_cons_inv_all			 	     I
,    hz_cust_site_uses			 SU
,    hz_cust_acct_sites			 A
,    hz_party_sites				   party_site
,    hz_locations				     loc
,    fnd_territories_vl			 T
,    hz_cust_accounts			   C
,    hz_parties				       party
,    ar_cons_inv_trx_all         IT
,    ar_payment_schedules    PS
,    ra_customer_trx_all     rct
,    ar_cons_inv_trx_lines_all   trxl
WHERE
     I.print_status 		        = 'PRINTED'
AND  I.status 			    	      <> 'REJECTED'
AND  C.cust_account_id		      = I.customer_id
AND  C.party_id				          = party.party_id
AND  SU.site_use_id			        = I.site_use_id
AND  A.cust_acct_site_id	      = SU.cust_acct_site_id
AND  A.party_site_id			      = party_site.party_site_id
AND  loc.location_id			      = party_site.location_id
AND  T.territory_code(+)	      = loc.country
/*AND  (select customer_class_code from ra_customers where customer_id = I.customer_id) = 'BB'
 R12 Upgrade Modified on 09/26/2012 by Sboppana, Rolta */
and c.customer_class_code = 'BB'
--AND  I.cut_off_date				      = p_date
and (i.cut_off_date				= p_date
or i.billing_date         = p_date
)
AND  C.account_number			      = p_account_number
AND  IT.cons_inv_id				      = p_cons_inv_id
AND  IT.transaction_type 			  IN ('RECEIPT', 'RECEIPT REV', 'XSITE RECREV', 'XSITE RECAPP'
                           				, 'XCURR RECREV', 'XCURR RECAPP', 'XSITE XCURR RECREV'
                           				, 'XSITE XCURR RECAPP', 'EXCLUDE RECREV', 'EXCLUDE RECAPP')
AND  IT.trx_number				      = rct.trx_number
AND  IT.org_id				          = rct.org_id
AND  trxl.cons_inv_id			      = p_cons_inv_id
AND  trxl.cons_inv_line_number	= IT.cons_inv_line_number
AND  trxl.unit_selling_price    <> 0
GROUP BY
     C.account_number
ORDER BY
     C.account_number
;
END p_zero_inv_3;
/* ************************************************************************************ */
FUNCTION f_zero_inv_3  (p_account_number   IN hz_cust_accounts.account_number%TYPE,
                        p_cons_inv_id      IN ar_cons_inv.cons_inv_id%TYPE,
                        p_date             IN DATE)
RETURN NUMBER AS
BEGIN
    p_zero_inv_3(p_account_number, p_cons_inv_id, p_date, gv_count);
    RETURN(gv_count);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
        RETURN '0';
  WHEN OTHERS THEN
        RETURN '0';
END f_zero_inv_3;
end xxha_zero_balance_invoices_bc;
/
