CREATE OR REPLACE PACKAGE xxha_deferred_revenue_rep_pkg IS

  FUNCTION Current_Month_Billing(p_prj_trx_id number
                                ,p_task_id number
                                ,p_rep_period VARCHAR2
                                ,p_type VARCHAR2) RETURN NUMBER;

  FUNCTION Deff_bal_Prior_Month(p_prj_trx_id NUMBER
                               ,p_task_id NUMBER
                               ,p_rep_period VARCHAR2
                               ,p_type VARCHAR2) RETURN NUMBER;

  FUNCTION Curr_Mon_Deff_Recognition(p_prj_trx_id NUMBER
                                    ,p_task_id NUMBER
                                    ,p_rep_period VARCHAR2
                                    ,p_type VARCHAR2) RETURN NUMBER;

  FUNCTION Deff_bal_cur_Month(p_prj_trx_id NUMBER
                             ,p_task_id NUMBER
                             ,p_rep_period VARCHAR2
                             ,p_type VARCHAR2) RETURN NUMBER;
                             
  FUNCTION Current_Month_Revenue(p_prj_trx_id NUMBER
                                ,p_task_id NUMBER
                                ,p_rep_period VARCHAR2
                                ,p_type VARCHAR2) RETURN NUMBER;                             

  FUNCTION Unbilled_Bal_Prior_Month(p_prj_trx_id NUMBER
                                   ,p_task_id NUMBER
                                   ,p_rep_period VARCHAR2
                                   ,p_type VARCHAR2) RETURN NUMBER;

  FUNCTION CurrMonth_Revenue_Rec_unbilled(p_prj_trx_id NUMBER
                                         ,p_task_id NUMBER
                                         ,p_rep_period VARCHAR2
                                         ,p_type VARCHAR2) RETURN NUMBER;

  FUNCTION Unbilled_Bal_Curr_Mon(p_prj_trx_id NUMBER
                                ,p_task_id NUMBER
                                ,p_rep_period VARCHAR2
                                ,p_type VARCHAR2) RETURN NUMBER;

  FUNCTION Curr_Mon_Bill_Rev(p_prj_trx_id NUMBER
                                ,p_task_id NUMBER
                                ,p_rep_period VARCHAR2
                                ,p_type VARCHAR2) RETURN NUMBER;

  FUNCTION Tot_Rev_Recognized(p_prj_trx_id NUMBER
                                ,p_task_id NUMBER
                                ,p_rep_period VARCHAR2
                                ,p_type VARCHAR2) RETURN NUMBER;
                                
  FUNCTION Tot_Revenue(p_prj_trx_id NUMBER
                      ,p_task_id NUMBER
                      ,p_rep_period VARCHAR2
                      ,p_type VARCHAR2) RETURN NUMBER;
                                
  FUNCTION Tot_Invoice(p_prj_trx_id NUMBER
                      ,p_task_id NUMBER
                      ,p_rep_period VARCHAR2
                      ,p_type VARCHAR2) RETURN NUMBER;
                      
  FUNCTION Tot_Inv_lastmonth(p_prj_trx_id NUMBER
                            ,p_task_id NUMBER
                            ,p_rep_period VARCHAR2
                            ,p_type VARCHAR2) RETURN NUMBER;
                       
  FUNCTION Tot_Rev_lastmonth(p_prj_trx_id NUMBER
                            ,p_task_id NUMBER
                            ,p_rep_period VARCHAR2
                            ,p_type VARCHAR2) RETURN NUMBER;
                      
  FUNCTION Tot_Inv_curmonth(p_prj_trx_id NUMBER
                           ,p_task_id NUMBER
                           ,p_rep_period VARCHAR2
                           ,p_type VARCHAR2) RETURN NUMBER;
                      
                      
  FUNCTION Tot_Rev_curmonth(p_prj_trx_id NUMBER
                           ,p_task_id NUMBER
                           ,p_rep_period VARCHAR2
                           ,p_type VARCHAR2) RETURN NUMBER;                      

END xxha_deferred_revenue_rep_pkg;
/


CREATE OR REPLACE PACKAGE BODY xxha_deferred_revenue_rep_pkg IS
-- +====================================================================================+
-- | Name        : XXHA_DEFERRED_REVENUE_REP_PKG                                        |
-- |                                                                                    |
-- | History                                                                            |
-- | =======                                                                            |
-- | When      Rev  Who               What                                              |
-- | --------  ---  --------          ------------------------------------------------- |
-- | 20081216  1.0  Centium           Initial version.                                  |
-- | 20110524  1.1  Vasil S. Valkov   Removed few ABS calls on few functions, which     |
-- |                                  returned incorrect calculations. See notes below. |
-- | 20111221  1.2  Eric Rossing      Remove unneeded code (SQL queries whose return    |
-- |                                  values are never used and duplicate SQL queries)  |
-- |                                  to improve performance.                           |
-- +====================================================================================+
  FUNCTION Current_Month_Billing(p_prj_trx_id NUMBER
                                ,p_task_id NUMBER
                                ,p_rep_period VARCHAR2
			        ,p_type VARCHAR2) RETURN NUMBER IS
 /*Function returns the Current Month Billing information of the Projects and Service Contracts
   Projects: current month billing information will be displayed from Invoice Review of Projects
   Service Contracts: Current Month billing information will be displayed from the Invoice lines
 */
   ln_amount NUMBER := 0;
  BEGIN
  IF p_type = 'PROJECT' THEN
        SELECT  SUM(invoice_amount)
	INTO    ln_amount
	FROM    xxha_pa_invoice_review_v xpi
	       ,pa_periods_all pa
	WHERE   p_prj_trx_id = xpi.project_id
	AND     (NVL(p_task_id,0)  = NVL(xpi.task_id,0) or p_task_id is null)
	AND     xpi.gl_date between pa.start_date and pa.end_date
	AND     xpi.org_id = PA.org_id
	AND     xpi.invoice_status = 'Accepted in Receivable'
	AND     PA.PERIOD_NAME = p_rep_period;
  ELSIF p_type = 'SERVICE' THEN
        SELECT invd.amount
        INTO   ln_amount
        FROM   ra_customer_trx_all RCT
              ,ra_customer_trx_lines_all RCTL
              ,ra_cust_trx_line_gl_dist_all INVD
              ,gl_period_statuses gps
        WHERE  rct.customer_trx_id = rctl.customer_trx_id
          AND  rctl.customer_trx_line_id = p_prj_trx_id
          AND  RCTL.CUSTOMER_TRX_LINE_ID = INVD.CUSTOMER_TRX_LINE_ID
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--        AND  rctl.set_of_books_id = gps.set_of_books_id
          AND  rctl.set_of_books_id = gps.ledger_id
          AND  invd.gl_date between gps.start_date and gps.end_date
          AND  GPS.application_id = 222
          AND  NVL(REC_OFFSET_FLAG, 'N')  = 'Y'
          AND  invd.account_class = 'UNEARN'
          AND  gps.period_name = p_rep_period;
  END IF; -- P_TYPE = 'PROJECT'
  RETURN NVL(ln_amount, 0);
  EXCEPTION WHEN OTHERS THEN
	    RETURN 0;
  END Current_Month_Billing;
  FUNCTION Deff_bal_Prior_Month(p_prj_trx_id NUMBER
                               ,p_task_id NUMBER
                               ,p_rep_period VARCHAR2
			       ,p_type VARCHAR2) RETURN NUMBER IS

 /*Function returns the Deferred Balance up to prior month of the Period passed in the parameter
   Projects: function returns the  sum(Invoice) from invoice review - Sum(Revenue) from revenue review up to the prior Month
   Service Contracts: function returns the sum(amount) from the receivables invoice distribution for which account class is "UNEARN" up to the prior month
 */
    ln_amount NUMBER;
 -- ETR - added these variables to capture values rather than call the functions multiple times with the same parameters
    ln_tot_inv_lastmonth NUMBER;
    ln_tot_rev_lastmonth NUMBER;
  BEGIN
  IF p_type = 'PROJECT' THEN
      SELECT
      ((SELECT NVL(SUM(INVOICE_AMOUNT), 0)
	from    apps.xxha_pa_invoice_review_v xpi
        where   p_prj_trx_id = xpi.project_id
	and     (NVL(p_task_id,0) = NVL(xpi.task_id,0)  OR (xpi.task_id is null and p_task_id is null))
	AND     xpi.invoice_status = 'Accepted in Receivable'
	and     xpi.gl_date < (SELECT pa1.start_date
	                       FROM   pa_periods_all pa1
			       WHERE  P_REP_PERIOD = PA1.PERIOD_NAME
			       AND    PA1.ORG_ID = XPI.ORG_ID)
             ) -
         (SELECT NVL(SUM(REVENUE_AMOUNT), 0)
          FROM   apps.xxha_pa_revenue_review_v xpr
          WHERE  xpr.project_id = p_prj_trx_id
          AND    (NVL(xpr.task_id, 0)  = NVL(p_task_id, 0) or (xpr.task_id is null and p_task_id is null))
          AND     xpr.transfer_status = 'Accepted'
	  AND     xpr.gl_date < (SELECT pa1.start_date
	                         FROM   pa_periods_all pa1
			         WHERE  p_rep_period = pa1.period_name
				 AND    pa1.org_id = xpr.org_id)
	 )
       ) TOT
	 INTO ln_amount
	 FROM DUAL;
   ln_tot_inv_lastmonth := Tot_Inv_lastmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type);
   ln_tot_rev_lastmonth := Tot_Rev_lastmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type);
	 IF ln_tot_inv_lastmonth > ln_tot_rev_lastmonth
            OR (ln_tot_inv_lastmonth < 0 AND ln_tot_rev_lastmonth = 0) THEN
/* - ETR - replaced below with above - only call each function once, since each does a lookup
   IF Tot_Inv_lastmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type) > Tot_Rev_lastmonth(p_prj_trx_id
                                                           ,p_task_id
                                                           ,p_rep_period
                                                           ,p_type)
            OR (SIGN(Tot_Inv_lastmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type)) = -1 AND Tot_Rev_lastmonth(p_prj_trx_id
                                                           ,p_task_id
                                                           ,p_rep_period
                                                           ,p_type) = 0) THEN */
	    RETURN NVL(ln_amount, 0);
         ELSE
            ln_amount :=0;
            RETURN ln_amount;
	 END IF; --Tot_Invoice - Tot_Revenue
  ELSIF p_type = 'SERVICE' THEN
        SELECT sum(INVD.amount)
        INTO ln_amount
        FROM   ra_customer_trx_all RCT
              ,ra_customer_trx_lines_all RCTL
              ,ra_cust_trx_line_gl_dist_all INVD
               ,gl_period_statuses gps
        WHERE  rct.customer_trx_id = rctl.customer_trx_id
		AND    rctl.customer_trx_line_id = p_prj_trx_id
		and    rctl.customer_trx_line_id = invd.customer_trx_line_id
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--       AND    rctl.set_of_books_id = gps.set_of_books_id
         AND    rctl.set_of_books_id = gps.ledger_id
         AND    invd.gl_date < gps.start_date
 		AND    GPS.application_id = 222
		AND    account_class = 'UNEARN'
 		AND    gps.period_name = p_rep_period;

-- Vasil: 20110526
--		ln_amount := ABS(ln_amount);
			RETURN nvl( ln_amount, 0 );
  END IF; -- P_TYPE = 'PROJECT'
  EXCEPTION WHEN OTHERS THEN
     RETURN 0;
  END Deff_bal_Prior_Month;
  FUNCTION Curr_Mon_Deff_Recognition(p_prj_trx_id NUMBER
                                    ,p_task_id NUMBER
                                    ,p_rep_period VARCHAR2
				    ,p_type VARCHAR2) RETURN NUMBER IS
 /*Function returns the Deferred Balance recognized for the Period passed in the parameter
   Projects: function returns the  sum(Invoice) from invoice review - Sum(Revenue) from revenue review for a period
   Service Contracts: function returns the sum(amount) from the receivables invoice distribution for which account class is "UNEARN" for a period
 */
    ln_amount NUMBER:=0;
--    ln_inv_amount NUMBER:=0; ETR - removed because value is retrieved, but not used
--    ln_inv_prev_amount  NUMBER :=0 ;  ETR - removed because value is retrieved, but not used
    ln_difference NUMBER:=0;
    ln_oks_rev_amount NUMBER:=0;
    ln_rctl_amount NUMBER:=0;
--    ln_inv_tot  NUMBER:=0;  ETR - removed because value is retrieved, but not used
--    ln_rev_amount NUMBER:=0;  ETR - removed because value is retrieved, but not used
--    ln_rev_prev_amount NUMBER:=0;  ETR - removed because value is retrieved, but not used
-- ETR - added these variables to capture values rather than call the functions multiple times with the same parameters
    ln_tot_invoice NUMBER:=0;
    ln_tot_revenue NUMBER:=0;
    ln_tot_rev_curmonth NUMBER:=0;
    ln_tot_inv_curmonth NUMBER:=0;
-- ETR end
  BEGIN
  IF p_type = 'PROJECT' THEN
        SELECT NVL(SUM(xpr.revenue_amount), 0)
	INTO   ln_amount
	FROM   xxha_pa_revenue_review_v xpr
	      ,pa_periods_all pa
        WHERE  xpr.project_id = p_prj_trx_id
	AND    (xpr.task_id = p_task_id or (p_task_id is null and xpr.task_id is null))
	AND     xpr.transfer_status = 'Accepted'
	AND    xpr.gl_date between pa.start_date and pa.end_date
	AND    pa.org_id = xpr.org_id
	AND    pa.period_name = p_rep_period;
/* ETR - comment out selects whose returned values aren't used.
        SELECT  NVL(SUM(XPI.invoice_amount), 0)
	INTO    ln_inv_amount
	FROM    xxha_pa_invoice_review_v xpi
	       ,pa_periods_all pa
	WHERE   p_prj_trx_id = xpi.project_id
	AND     (p_task_id = xpi.task_id or (p_task_id is null and xpi.task_id is null))
	AND     xpi.org_id = pa.org_id
	AND     xpi.invoice_status = 'Accepted in Receivable'
	AND     xpi.gl_date between pa.start_date and pa.end_date
	AND     pa.period_name = p_rep_period;
        SELECT  NVL(SUM(XPI.invoice_amount), 0)
	INTO    ln_inv_prev_amount
	FROM    xxha_pa_invoice_review_v xpi
	       ,pa_periods_all pa
	WHERE   p_prj_trx_id = xpi.project_id
	AND     (p_task_id = xpi.task_id or (p_task_id is null and xpi.task_id is null))
	AND     xpi.invoice_status = 'Accepted in Receivable'
	AND     xpi.org_id = pa.org_id
	AND     xpi.gl_date < pa.start_date
	AND     pa.period_name = p_rep_period;
        SELECT NVL(SUM(Revenue_Amount), 0)
        INTO   ln_rev_prev_amount
        FROM   xxha_pa_revenue_review_v xpr
        WHERE  xpr.project_id = p_prj_trx_id
        AND    (NVL(xpr.task_id, 0)  = NVL(p_task_id, 0) or (xpr.task_id is null and p_task_id is null))
        AND     xpr.transfer_status = 'Accepted'
	AND     xpr.gl_date < (SELECT pa1.start_date
	                       FROM   pa_periods_all pa1
			       WHERE  p_rep_period = pa1.period_name
			       AND    pa1.org_id = xpr.org_id);
      SELECT
      ((SELECT NVL(SUM(Invoice_Amount), 0)
	from    xxha_pa_invoice_review_v xpi
        where   p_prj_trx_id = xpi.project_id
	and     (NVL(p_task_id,0) = NVL(xpi.task_id,0)  OR (xpi.task_id is null and p_task_id is null))
	AND     xpi.invoice_status = 'Accepted in Receivable'
	and     xpi.gl_date < (SELECT pa1.start_date
	                       FROM   pa_periods_all pa1
			       WHERE  p_rep_period = pa1.period_name
			       AND    pa1.org_id = xpi.org_id)
		) -
         (SELECT NVL(SUM(Revenue_Amount), 0)
          FROM   xxha_pa_revenue_review_v xpr
          WHERE  xpr.project_id = p_prj_trx_id
          AND    (NVL(xpr.task_id, 0)  = NVL(p_task_id, 0) or (xpr.task_id is null and p_task_id is null))
          AND     xpr.transfer_status = 'Accepted'
	  AND     xpr.gl_date < (SELECT pa1.start_date
	                         FROM   pa_periods_all pa1
			         WHERE  p_rep_period = pa1.period_name
				 AND    pa1.org_id = xpr.org_id)
	 )
       ) TOT
	 INTO ln_inv_tot
	 FROM DUAL;
   SELECT ((SELECT NVL(SUM(revenue_amount), 0)
            FROM   xxha_pa_revenue_review_v xpr
            WHERE  xpr.project_id = p_prj_trx_id
	    AND    (xpr.task_id = p_task_id or p_task_id is null)
	    AND     xpr.transfer_status = 'Accepted'
	    AND    xpr.gl_date < (SELECT pa1.start_date
	                          FROM   pa_periods_all pa1
			          WHERE  p_rep_period = pa1.period_name
				  AND    pa1.org_id = xpr.org_id
				 )
            ) - (SELECT NVL(SUM(invoice_amount), 0)
                 FROM   xxha_pa_invoice_review_v xpi
          	 WHERE  p_prj_trx_id = xpi.project_id
          	 AND    (p_task_id = xpi.task_id or p_task_id is null)
          	 AND    xpi.invoice_status = 'Accepted in Receivable'
          	 AND    xpi.gl_date < (SELECT pa1.start_date
	                               FROM   pa_periods_all pa1
			               WHERE  p_rep_period = pa1.period_name
				       AND    pa1.org_id = xpi.org_id
				      )
          	)
          )
   INTO ln_rev_amount
   FROM DUAL;
*/
   ln_tot_invoice := Tot_Invoice(p_prj_trx_id
                             ,p_task_id
                             ,p_rep_period
                             ,p_type);
   ln_tot_revenue := Tot_Revenue(p_prj_trx_id
                             ,p_task_id
                             ,p_rep_period
                             ,p_type);
   ln_tot_rev_curmonth := Tot_Rev_curmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type);
   ln_tot_inv_curmonth := Tot_Inv_curmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type);
   IF ln_tot_invoice > ln_tot_revenue
     /*      OR Tot_Inv_curmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type) > ln_tot_rev_curmonth */ THEN
     RETURN NVL(ln_amount, 0);
    ELSIF ln_tot_invoice = ln_tot_revenue
             AND  ln_tot_rev_curmonth >  ln_tot_inv_curmonth    THEN
     ln_amount := ln_tot_rev_curmonth;
     RETURN ln_amount;
    ELSIF ln_tot_revenue > ln_tot_invoice
             AND  Tot_Inv_lastmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type) >  Tot_Rev_lastmonth(p_prj_trx_id
                                                              ,p_task_id
                                                              ,p_rep_period
                                                              ,p_type)    THEN

      ln_amount := ln_tot_inv_curmonth + Deff_bal_Prior_Month(p_prj_trx_id
                                                                  ,p_task_id
                                                                  ,p_rep_period
                                                                  ,p_type);
      RETURN ln_amount;
   ELSE
    RETURN 0;
  END IF;
/* - ETR - replaced below with above - only call each function once, since each does a lookup
   IF Tot_Invoice(p_prj_trx_id
	         ,p_task_id
	         ,p_rep_period
	         ,p_type) > Tot_Revenue(p_prj_trx_id
				       ,p_task_id
				       ,p_rep_period
				       ,p_type )
     /*      OR Tot_Inv_curmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type) > Tot_Rev_curmonth(p_prj_trx_id
                                                           ,p_task_id
                                                           ,p_rep_period
                                                           ,p_type) *//* THEN
     RETURN NVL(ln_amount, 0);
    ELSIF Tot_Invoice(p_prj_trx_id
                       ,p_task_id
                       ,p_rep_period
                       ,p_type) = Tot_Revenue(p_prj_trx_id
                                            ,p_task_id
                                            ,p_rep_period
                                            ,p_type )
             AND  Tot_Rev_curmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type) >  Tot_Inv_curmonth(p_prj_trx_id
                                                              ,p_task_id
                                                              ,p_rep_period
                                                              ,p_type)    THEN
     ln_amount := Tot_Rev_curmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type);
     RETURN ln_amount;
    ELSIF Tot_Revenue(p_prj_trx_id
                       ,p_task_id
                       ,p_rep_period
                       ,p_type) > Tot_Invoice(p_prj_trx_id
                                            ,p_task_id
                                            ,p_rep_period
                                            ,p_type )
             AND  Tot_Inv_lastmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type) >  Tot_Rev_lastmonth(p_prj_trx_id
                                                              ,p_task_id
                                                              ,p_rep_period
                                                              ,p_type)    THEN
      ln_amount := Tot_Inv_curmonth(p_prj_trx_id
                                   ,p_task_id
                                   ,p_rep_period
                                   ,p_type) + Deff_bal_Prior_Month(p_prj_trx_id
                                                                  ,p_task_id
                                                                  ,p_rep_period
                                                                  ,p_type);
      RETURN ln_amount;
   ELSE
    RETURN 0;
   END IF;
*/
  ELSIF p_type = 'SERVICE' THEN
      SELECT NVL(sum(INVD.amount), 1)
	  INTO   ln_difference
      FROM   ra_customer_trx_all RCT
            ,ra_customer_trx_lines_all RCTL
            ,ra_cust_trx_line_gl_dist_all INVD
            ,gl_period_statuses gps
      WHERE  rct.customer_trx_id = rctl.customer_trx_id
  	  AND  rctl.customer_trx_line_id = p_prj_trx_id
	  and  rctl.customer_trx_line_id = invd.customer_trx_line_id
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--      AND  rctl.set_of_books_id = gps.set_of_books_id
      AND  rctl.set_of_books_id = gps.ledger_id
      AND  invd.gl_date between gps.start_date and gps.end_date
      AND  GPS.application_id = 222
      AND  invd.account_class = 'UNEARN'
 	  AND  gps.period_name = p_rep_period;
      SELECT NVL(sum(INVD.amount), 1),
             NVL(SUM(rctl.extended_amount),1)
      INTO   ln_oks_rev_amount,
	     ln_rctl_amount
      FROM   ra_customer_trx_all RCT
            ,ra_customer_trx_lines_all RCTL
            ,ra_cust_trx_line_gl_dist_all INVD
            ,gl_period_statuses gps
      WHERE  rct.customer_trx_id = rctl.customer_trx_id
  	  AND  rctl.customer_trx_line_id = p_prj_trx_id
	  and  rctl.customer_trx_line_id = invd.customer_trx_line_id
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--    AND  rctl.set_of_books_id = gps.set_of_books_id
      AND  rctl.set_of_books_id = gps.ledger_id
      AND  invd.gl_date between gps.start_date and gps.end_date
      AND  GPS.application_id = 222
      AND  invd.account_class = 'REV'
 	  AND  gps.period_name = p_rep_period;
          SELECT RCTL.extended_amount
	  INTO   ln_amount
          FROM   ra_customer_trx_all RCT
                ,ra_customer_trx_lines_all RCTL
          WHERE  rct.customer_trx_id = rctl.customer_trx_id
          AND  rctl.customer_trx_line_id = p_prj_trx_id;
     IF (ln_difference  = 0 AND ln_oks_rev_amount = ln_rctl_amount) THEN
         ln_amount:=0;
         RETURN ln_amount;
      ELSE
         SELECT NVL(sum(INVD.amount), 0)
         INTO   ln_amount
         FROM   ra_customer_trx_all RCT
               ,ra_customer_trx_lines_all RCTL
               ,ra_cust_trx_line_gl_dist_all INVD
               ,gl_period_statuses gps
         WHERE  rct.customer_trx_id = rctl.customer_trx_id
         AND  rctl.customer_trx_line_id = p_prj_trx_id
	 and  rctl.customer_trx_line_id = invd.customer_trx_line_id
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--       AND  rctl.set_of_books_id = gps.set_of_books_id
         AND  rctl.set_of_books_id = gps.ledger_id
         AND  invd.gl_date between gps.start_date and gps.end_date
         AND  GPS.application_id = 222
         AND  invd.account_class = 'UNEARN'
         AND  NVL(INVD.rec_offset_flag, 'N')  = 'N'
         AND  gps.period_name = p_rep_period;
         -- Vasil: 20110524 removed ABS and added nvl
         RETURN nvl( ln_amount, 0 );
      END IF; --ln_difference = 0
  END IF; -- P_TYPE = 'PROJECT'
  EXCEPTION WHEN OTHERS THEN
    RETURN 0;
  END Curr_Mon_Deff_Recognition;
  FUNCTION Deff_bal_cur_Month(p_prj_trx_id NUMBER
                             ,p_task_id NUMBER
                             ,p_rep_period VARCHAR2
		             ,p_type VARCHAR2) RETURN NUMBER IS
 /*Function returns the Deferred Balance as of End of Period passed in the parameter
   Projects: Current Month Billing + Deferred Balance Prior Month - Current Month Deferred Recognization
   Service Contracts: Current Month Billing + Deferred Balance Prior Month - Current Month Deferred Recognization
 */
        ln_amount NUMBER :=0;
	ln_difference NUMBER:=0;
	ln_oks_rev_amount   NUMBER:=0;
	ln_rctl_amount      NUMBER:=0;
	--lv_prev_amount NUMBER:=0; ETR - removed because value is retrieved, but not used
  ln_tot_inv_curmonth NUMBER:=0; -- ETR - added to capture values rather than call the functions multiple times with the same parameters
  BEGIN
   IF p_type = 'PROJECT' THEN
/* ETR - comment out selects whose returned values aren't used.
        SELECT (NVL((SELECT SUM(Invoice_Amount)
	           from    xxha_pa_invoice_review_v xpi
	                  ,pa_periods_all pa
		   where   p_prj_trx_id = xpi.project_id
		   and     (p_task_id = xpi.task_id or (p_task_id is null and xpi.task_id is null))
	            AND    xpi.gl_date between pa.start_date and pa.end_date
	            AND    xpi.invoice_status = 'Accepted in Receivable'
	            AND    pa.org_id = xpi.org_id
	            AND    pa.period_name = p_rep_period
                    ),0) -
               NVL((SELECT SUM(Revenue_Amount)
	 	    FROM   xxha_pa_revenue_review_v xpr,
	 	    	   pa_periods_all pa
		    WHERE  xpr.project_id = p_prj_trx_id
	 	    AND    (xpr.task_id  = p_task_id or (p_task_id is null and xpr.task_id is null))
	 	    AND     xpr.transfer_status = 'Accepted'
	            AND    xpr.gl_date between pa.start_date and pa.end_date
	            AND    pa.org_id = xpr.org_id
	            AND    pa.period_name = p_rep_period
                 ),0)
              ) TOT
         INTO ln_difference
	 FROM DUAL;
         SELECT
          ((SELECT NVL(SUM(Invoice_Amount), 0)
   	    from    xxha_pa_invoice_review_v xpi
            where   p_prj_trx_id = xpi.project_id
	    and     (NVL(p_task_id,0) = NVL(xpi.task_id,0)  OR (xpi.task_id is null and p_task_id is null))
	    AND     xpi.invoice_status = 'Accepted in Receivable'
	    and     xpi.gl_date <= (SELECT pa1.end_date
	                           FROM   pa_periods_all pa1
			           WHERE  p_rep_period = pa1.period_name
			           AND    pa1.org_id = xpi.org_id)
		                   ) -
            (SELECT NVL(SUM(Revenue_Amount), 0)
             FROM   xxha_pa_revenue_review_v xpr
             WHERE  xpr.project_id = p_prj_trx_id
             AND    (NVL(xpr.task_id, 0)  = NVL(p_task_id, 0) or (xpr.task_id is null and p_task_id is null))
             AND     xpr.transfer_status = 'Accepted'
	     AND     xpr.gl_date <= (SELECT pa1.end_date
	                            FROM   pa_periods_all pa1
			            WHERE  p_rep_period = pa1.period_name
				    AND    pa1.org_id = xpr.org_id)
	 )
       ) TOT
	 INTO lv_prev_amount
	 FROM DUAL;
*/
   ln_tot_inv_curmonth := Tot_Inv_curmonth(p_prj_trx_id
                                ,p_task_id
                                ,p_rep_period
                                ,p_type);
     IF Tot_Invoice(p_prj_trx_id
                   ,p_task_id
                   ,p_rep_period
                   ,p_type) > Tot_Revenue(p_prj_trx_id
                                         ,p_task_id
                                         ,p_rep_period
                                         ,p_type )
/*
         or (Tot_Inv_curmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type) > Tot_Rev_curmonth(p_prj_trx_id
*/
           or (ln_tot_inv_curmonth > Tot_Rev_curmonth(p_prj_trx_id
                                                           ,p_task_id
                                                           ,p_rep_period
                                                           ,p_type)
              and Tot_Inv_lastmonth(p_prj_trx_id
                                   ,p_task_id
                                   ,p_rep_period
                                   ,p_type) > Tot_Rev_lastmonth(p_prj_trx_id
                                                           ,p_task_id
                                                           ,p_rep_period
                                                           ,p_type)) THEN
       ln_amount :=  Deff_bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period,'PROJECT')
                     - Unbilled_Bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT')
                     + Current_Month_Billing(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT')
                     - Tot_Rev_curmonth(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT');
/*       ln_amount:=   (xxha_deferred_revenue_rep_pkg.Current_Month_Billing(p_prj_trx_id, p_task_id, p_rep_period,'PROJECT') +
	                   xxha_deferred_revenue_rep_pkg.Deff_bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT')) -
	                    xxha_deferred_revenue_rep_pkg.Curr_Mon_Deff_Recognition(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT');*/
       RETURN ln_amount;
     ELSIF ln_tot_inv_curmonth <0 THEN
/* - ETR - replaced below with above - only call each function once, since each does a lookup
     ELSIF SIGN(Tot_Inv_curmonth(p_prj_trx_id
                                ,p_task_id
                                ,p_rep_period
                                ,p_type)) = -1 THEN
*/
/*       ln_amount:=   (xxha_deferred_revenue_rep_pkg.Current_Month_Billing(p_prj_trx_id, p_task_id, p_rep_period,'PROJECT') +
	                   xxha_deferred_revenue_rep_pkg.Deff_bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT')) -
	                    xxha_deferred_revenue_rep_pkg.Curr_Mon_Deff_Recognition(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT');*/

       ln_amount :=  Deff_bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period,'PROJECT')
                     - Unbilled_Bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT')
                     + Current_Month_Billing(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT')
                     - Tot_Rev_curmonth(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT');
       RETURN ln_amount;
/*     ELSIF Tot_Revenue(p_prj_trx_id
                   ,p_task_id
                   ,p_rep_period
                   ,p_type) > Tot_Invoice(p_prj_trx_id
                                         ,p_task_id
                                         ,p_rep_period
                                         ,p_type )
           AND Tot_Inv_lastmonth(p_prj_trx_id
                              ,p_task_id
                              ,p_rep_period
                              ,p_type) > Tot_Rev_lastmonth(p_prj_trx_id
                                                           ,p_task_id
                                                           ,p_rep_period
                                                           ,p_type) THEN
       ln_amount:=   (xxha_deferred_revenue_rep_pkg.Current_Month_Billing(p_prj_trx_id, p_task_id, p_rep_period,'PROJECT') +
	                   xxha_deferred_revenue_rep_pkg.Deff_bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT')) -
	                    xxha_deferred_revenue_rep_pkg.Curr_Mon_Deff_Recognition(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT');

       RETURN ln_amount; */
      ELSE
     	ln_amount :=0;
     	RETURN ln_amount;
      END IF;   --  tot_inv - tot_rev
   ELSIF p_type = 'SERVICE' THEN
      SELECT NVL(sum(INVD.amount), 1)
      INTO   ln_difference
      FROM   ra_customer_trx_all RCT
            ,ra_customer_trx_lines_all RCTL
            ,ra_cust_trx_line_gl_dist_all INVD
            ,gl_period_statuses gps
      WHERE  rct.customer_trx_id = rctl.customer_trx_id
  	  AND  rctl.customer_trx_line_id = p_prj_trx_id
	  AND  RCTL.CUSTOMER_TRX_LINE_ID = INVD.CUSTOMER_TRX_LINE_ID
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--    AND  rctl.set_of_books_id = gps.set_of_books_id
      AND  rctl.set_of_books_id = gps.ledger_id
      AND  invd.gl_date between gps.start_date and gps.end_date
      AND  GPS.application_id = 222
      AND  invd.account_class = 'UNEARN'
 	  AND  gps.period_name = p_rep_period;
      SELECT NVL(sum(INVD.amount), 1),
             NVL(SUM(rctl.extended_amount),1)
      INTO   ln_oks_rev_amount,
	     ln_rctl_amount
      FROM   ra_customer_trx_all RCT
            ,ra_customer_trx_lines_all RCTL
            ,ra_cust_trx_line_gl_dist_all INVD
            ,gl_period_statuses gps
      WHERE  rct.customer_trx_id = rctl.customer_trx_id
  	  AND  rctl.customer_trx_line_id = p_prj_trx_id
	  AND  RCTL.CUSTOMER_TRX_LINE_ID = INVD.CUSTOMER_TRX_LINE_ID
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--      AND  rctl.set_of_books_id = gps.set_of_books_id
      AND  rctl.set_of_books_id = gps.ledger_id
      AND  invd.gl_date between gps.start_date and gps.end_date
      AND  GPS.application_id = 222
      AND  invd.account_class = 'REV'
 	  AND  gps.period_name = p_rep_period;
          SELECT RCTL.extended_amount
	  INTO   ln_amount
          FROM   ra_customer_trx_all RCT
                ,ra_customer_trx_lines_all RCTL
          WHERE  rct.customer_trx_id = rctl.customer_trx_id
          AND  rctl.customer_trx_line_id = p_prj_trx_id;
      IF (ln_difference  = 0 AND ln_oks_rev_amount = ln_rctl_amount) THEN
         ln_amount:=0;
         RETURN ln_amount;
      ELSE
         ln_amount:=   (xxha_deferred_revenue_rep_pkg.Current_Month_Billing(p_prj_trx_id, p_task_id, p_rep_period,'SERVICE') +
	              xxha_deferred_revenue_rep_pkg.Deff_bal_Prior_Month(p_prj_trx_id, p_task_id, p_rep_period, 'SERVICE')) +			-- change by VV
	               xxha_deferred_revenue_rep_pkg.Curr_Mon_Deff_Recognition(p_prj_trx_id, p_task_id, p_rep_period, 'SERVICE');
         -- Vasil: 20110524 removed ABS and added nvl
         RETURN nvl( ln_amount, 0 );
      END IF; --ln_difference = 0
   END IF;  -- P_TYPE = 'PROJECT'
  EXCEPTION WHEN OTHERS THEN
    RETURN 0;
  END  Deff_bal_cur_Month;
  FUNCTION Current_Month_Revenue(p_prj_trx_id NUMBER
                                ,p_task_id NUMBER
                                ,p_rep_period VARCHAR2
                                ,p_type VARCHAR2) RETURN NUMBER  IS
  BEGIN
      RETURN  Tot_Rev_curmonth(p_prj_trx_id
                                ,p_task_id
                                ,p_rep_period
                                ,p_type);
  EXCEPTION WHEN OTHERS THEN
      RETURN 0;
  END Current_Month_Revenue;
  FUNCTION Unbilled_Bal_Prior_Month(p_prj_trx_id NUMBER
                                   ,p_task_id NUMBER
                                   ,p_rep_period VARCHAR2
                                   ,p_type VARCHAR2) RETURN NUMBER IS
 /*Function returns the Unbilled Balance as of Begenning of the Period passed in the parameter
   Projects: If Revenue is more than Bill then this function returns Revenue Recognized as of beginning of the period - Billed as of beginning of the period
   Service Contracts: This Scenario will never occur for the service contract*/
   ln_amount NUMBER:=0;
   ln_tot_inv_lastmonth NUMBER:=0; -- ETR - added to capture values rather than call the functions multiple times with the same parameters
  BEGIN
   SELECT ((SELECT NVL(SUM(revenue_amount), 0)
            FROM   xxha_pa_revenue_review_v xpr
	              ,pa_periods_all pa
            WHERE  xpr.project_id = p_prj_trx_id
	    AND    (xpr.task_id  = p_task_id or p_task_id is null)
	    AND     xpr.transfer_status = 'Accepted'
	    and    xpr.org_id = pa.org_id
	    AND    xpr.gl_date < pa.start_date
	    AND    pa.period_name = p_rep_period
	   ) - (SELECT NVL(SUM(invoice_amount), 0)
	         FROM   xxha_pa_invoice_review_v xpi
		       ,pa_periods_all pa
          	 WHERE  p_prj_trx_id = xpi.project_id
          	 AND    (p_task_id = xpi.task_id or p_task_id is null)
          	 AND     xpi.invoice_status = 'Accepted in Receivable'
          	 and    xpi.org_id = pa.org_id
          	 AND    xpi.gl_date < pa.start_date
          	 AND    pa.period_name = p_rep_period
	       )
	 )
   INTO ln_amount
   FROM DUAL;
   ln_tot_inv_lastmonth := Tot_Inv_lastmonth(p_prj_trx_id
                                             ,p_task_id
                                             ,p_rep_period
                                             ,p_type);
   IF Tot_Rev_lastmonth(p_prj_trx_id
                 ,p_task_id
                 ,p_rep_period
                 ,p_type ) > ln_tot_inv_lastmonth
       AND  ln_tot_inv_lastmonth >= 0 THEN
/* - ETR - replaced below with above - only call each function once, since each does a lookup
   IF Tot_Rev_lastmonth(p_prj_trx_id
                 ,p_task_id
                 ,p_rep_period
                 ,p_type ) > Tot_Inv_lastmonth(p_prj_trx_id
                                             ,p_task_id
                                             ,p_rep_period
                                             ,p_type)
       AND  SIGN(Tot_Inv_lastmonth(p_prj_trx_id
                             ,p_task_id
                             ,p_rep_period
                             ,p_type)) IN (1, 0) THEN
*/
      RETURN NVL(ln_amount, 1);
   ELSE
      ln_amount := 0;
      RETURN ln_amount;
   END IF;
  EXCEPTION WHEN OTHERS THEN
  RETURN 0;
  END Unbilled_Bal_Prior_Month;
  FUNCTION CurrMonth_Revenue_Rec_unbilled(p_prj_trx_id NUMBER
                                         ,p_task_id NUMBER
                                         ,p_rep_period VARCHAR2
				         ,p_type VARCHAR2) RETURN NUMBER IS
 /*Function returns the Unbilled Balance for the Period passed in the parameter
   Projects: If Revenue is more than Bill then this function returns Revenue Recognized for the period - Billed for the period.
   Service Contracts: This Scenario will never occur for the service contract
 */
   ln_amount  NUMBER :=0;
   --ln_currev_min_curinv NUMBER := 0;  ETR - removed because value is retrieved, but not used
   --ln_lastrev_min_lastinv  NUMBER :=0;  ETR - removed because value is retrieved, but not used
   ln_prev_amount NUMBER :=0;
   ln_rev_amount  NUMBER :=0;
   ln_inv_amount NUMBER := 0;
   ln_totrev_amount  NUMBER := 0;
   ln_currinv_amount NUMBER :=0;
 -- ETR - added these variables to capture values rather than call the functions multiple times with the same parameters
   ln_tot_revenue NUMBER := 0;
   ln_tot_invoice NUMBER := 0;
   ln_tot_rev_lastmonth NUMBER := 0;
   ln_tot_inv_lastmonth NUMBER := 0;
  BEGIN
  IF p_type = 'PROJECT' THEN
/*  ETR - comment out selects whose returned values aren't used.
   SELECT Tot_Rev_curmonth(p_prj_trx_id
                          ,p_task_id
                          ,p_rep_period
                          ,p_type ) - Tot_Inv_curmonth(p_prj_trx_id
                                                      ,p_task_id
                                                      ,p_rep_period
                                                      ,p_type )
   INTO ln_currev_min_curinv
   FROM DUAL;
   SELECT Tot_Rev_lastmonth(p_prj_trx_id
                           ,p_task_id
                           ,p_rep_period
                           ,p_type ) - Tot_Inv_lastmonth(p_prj_trx_id
                                                        ,p_task_id
                                                        ,p_rep_period
                                                        ,p_type )
   INTO ln_lastrev_min_lastinv   --ln_prev_amount
   FROM DUAL;
*/
   ln_tot_revenue := Tot_Revenue(p_prj_trx_id
                       ,p_task_id
                       ,p_rep_period
                       ,p_type );
   ln_tot_invoice := Tot_Invoice(p_prj_trx_id
                                              ,p_task_id
                                              ,p_rep_period
                                              ,p_type);
   ln_tot_rev_lastmonth := Tot_Rev_lastmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type);
   ln_tot_inv_lastmonth := Tot_Inv_lastmonth(p_prj_trx_id
                                                              ,p_task_id
                                                              ,p_rep_period
                                                              ,p_type);
	 IF ln_tot_revenue > ln_tot_invoice AND
            ln_tot_rev_lastmonth >=  ln_tot_inv_lastmonth THEN
/* - ETR - replaced below with above - only call each function once, since each does a lookup
	 IF Tot_Revenue(p_prj_trx_id
                       ,p_task_id
                       ,p_rep_period
                       ,p_type ) > Tot_Invoice(p_prj_trx_id
                                              ,p_task_id
                                              ,p_rep_period
                                              ,p_type) AND
            Tot_Rev_lastmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type) >=  Tot_Inv_lastmonth(p_prj_trx_id
                                                              ,p_task_id
                                                              ,p_rep_period
                                                              ,p_type) THEN
*/
--           RETURN NVL(ln_currev_min_curinv, 0);
--             RETURN 1;
            ln_amount :=  Tot_Rev_curmonth(p_prj_trx_id
                                          ,p_task_id
                                          ,p_rep_period
                                          ,p_type ) ;

            RETURN ln_amount;
    ELSIF ln_tot_revenue > ln_tot_invoice
             AND  ln_tot_inv_lastmonth >  ln_tot_rev_lastmonth    THEN
/* - ETR - replaced below with above - only call each function once, since each does a lookup
    ELSIF Tot_Revenue(p_prj_trx_id
                       ,p_task_id
                       ,p_rep_period
                       ,p_type) > Tot_Invoice(p_prj_trx_id
                                            ,p_task_id
                                            ,p_rep_period
                                            ,p_type )
             AND  Tot_Inv_lastmonth(p_prj_trx_id
                                  ,p_task_id
                                  ,p_rep_period
                                  ,p_type) >  Tot_Rev_lastmonth(p_prj_trx_id
                                                              ,p_task_id
                                                              ,p_rep_period
                                                              ,p_type)    THEN*/
            ln_amount :=  Tot_Rev_curmonth(p_prj_trx_id
                                     ,p_task_id
                                     ,p_rep_period
                                     ,p_type) - Curr_Mon_Deff_Recognition(p_prj_trx_id
								         ,p_task_id
								         ,p_rep_period
								         ,p_type );
            RETURN ln_amount;
         ELSE
            ln_amount := 0;
            RETURN ln_amount;
         END IF;
  END IF; -- P_TYPE = 'PROJECT'
  EXCEPTION WHEN OTHERS THEN
   RETURN 0;
  END CurrMonth_Revenue_Rec_unbilled;
  FUNCTION Unbilled_Bal_Curr_Mon(p_prj_trx_id NUMBER
                                ,p_task_id NUMBER
                                ,p_rep_period VARCHAR2
                                ,p_type VARCHAR2) RETURN NUMBER is
 /*Function returns the Unbilled Balance as of end of the Period passed in the parameter
   Projects: If Revenue is more than Bill then this function returns Revenue Recognized as of end of the period - Billed as of end of the period.
   Service Contracts: This Scenario will never occur for the service contract
 */
   ln_amount NUMBER := 0;
--   lv_prev_amount NUMBER :=0; ETR - removed because value is retrieved, but not used
--   ln_difference NUMBER :=0; ETR - removed because value is retrieved, but not used
--   ln_prevrev_amount NUMBER :=0; ETR - removed because value is retrieved, but not used
--   ln_rev_amount  NUMBER:=0; ETR - removed because value is retrieved, but not used
--   ln_inv_amount  NUMBER :=0; ETR - removed because value is retrieved, but not used
--   ln_currinv_amount  NUMBER :=0; ETR - removed because value is retrieved, but not used
--   ln_totrev_amount   NUMBER :=0; ETR - removed because value is retrieved, but not used
-- ETR - added these variables to capture values rather than call the functions multiple times with the same parameters
   ln_tot_revenue NUMBER :=0;
   ln_tot_invoice NUMBER :=0;
  BEGIN
/*
        SELECT (NVL((SELECT SUM(Invoice_Amount)
	           from    xxha_pa_invoice_review_v xpi
	                  ,pa_periods_all pa
		   where   p_prj_trx_id = xpi.project_id
		   and     (p_task_id = xpi.task_id or (p_task_id is null and xpi.task_id is null))
	            AND    xpi.gl_date between pa.start_date and pa.end_date
	            AND     xpi.invoice_status = 'Accepted in Receivable'
	            AND    pa.org_id = xpi.org_id
	            AND    pa.period_name = p_rep_period
                    ),0) -
               NVL((SELECT SUM(Revenue_Amount)
	 	    FROM   xxha_pa_revenue_review_v xpr,
	 	    	   pa_periods_all pa
		    WHERE  xpr.project_id = p_prj_trx_id
	 	    AND    (xpr.task_id  = p_task_id or (p_task_id is null and xpr.task_id is null))
	 	    AND     xpr.transfer_status = 'Accepted'
	            AND    xpr.gl_date between pa.start_date and pa.end_date
	            AND    pa.org_id = xpr.org_id
	            AND    pa.period_name = p_rep_period
                 ),0)
              ) TOT
         INTO ln_difference
	 FROM DUAL;
         SELECT
          ((SELECT NVL(SUM(Invoice_Amount), 0)
   	    from    xxha_pa_invoice_review_v xpi
            where   p_prj_trx_id = xpi.project_id
	    and     (NVL(p_task_id,0) = NVL(xpi.task_id,0)  OR (xpi.task_id is null and p_task_id is null))
	    AND     xpi.invoice_status = 'Accepted in Receivable'
	    and     xpi.gl_date < (SELECT pa1.end_date
	                           FROM   pa_periods_all pa1
			           WHERE  p_rep_period = pa1.period_name
			           AND    pa1.org_id = xpi.org_id)
		                   ) -
            (SELECT NVL(SUM(Revenue_Amount), 0)
             FROM   xxha_pa_revenue_review_v xpr
             WHERE  xpr.project_id = p_prj_trx_id
             AND    (NVL(xpr.task_id, 0)  = NVL(p_task_id, 0) or (xpr.task_id is null and p_task_id is null))
             AND     xpr.transfer_status = 'Accepted'
	     AND     xpr.gl_date < (SELECT pa1.end_date
	                            FROM   pa_periods_all pa1
			            WHERE  p_rep_period = pa1.period_name
				    AND    pa1.org_id = xpr.org_id)
	 )
       ) TOT
	 INTO lv_prev_amount
	 FROM DUAL;
   SELECT ((SELECT NVL(SUM(revenue_amount), 0)
            FROM   xxha_pa_revenue_review_v xpr
	              ,pa_periods_all pa
            WHERE  xpr.project_id = p_prj_trx_id
	    AND    (xpr.task_id  = p_task_id or p_task_id is null)
	    AND     xpr.transfer_status = 'Accepted'
	    and    xpr.org_id = pa.org_id
	    AND    xpr.gl_date < pa.start_date
	    AND    pa.period_name = p_rep_period
	   ) - (SELECT NVL(SUM(invoice_amount), 0)
	         FROM   xxha_pa_invoice_review_v xpi
		       ,pa_periods_all pa
          	 WHERE  p_prj_trx_id = xpi.project_id
          	 AND    (p_task_id = xpi.task_id or p_task_id is null)
          	 AND     xpi.invoice_status = 'Accepted in Receivable'
          	 and    xpi.org_id = pa.org_id
          	 AND    xpi.gl_date < pa.start_date
          	 AND    pa.period_name = p_rep_period
	       )
	 )
   INTO ln_prevrev_amount
   FROM DUAL;
*/
   ln_tot_revenue := Tot_Revenue(p_prj_trx_id
		 ,p_task_id
		 ,p_rep_period
		 ,p_type );
   ln_tot_invoice := Tot_Invoice(p_prj_trx_id
	                                 ,p_task_id
	                                 ,p_rep_period
	                                 ,p_type);
   IF ln_tot_revenue  > ln_tot_invoice
       AND Current_Month_Billing(p_prj_trx_id
		                     ,p_task_id
		                     ,p_rep_period
		                     ,p_type ) >= 0 THEN
     ln_amount := ln_tot_revenue  - ln_tot_invoice;
   END IF;
/*  - ETR - replaced below with above - only call each function once, since each does a lookup
   IF Tot_Revenue(p_prj_trx_id
		 ,p_task_id
		 ,p_rep_period
		 ,p_type )  > Tot_Invoice(p_prj_trx_id
	                                 ,p_task_id
	                                 ,p_rep_period
	                                 ,p_type)
       AND SIGN(Current_Month_Billing(p_prj_trx_id
		                     ,p_task_id
		                     ,p_rep_period
		                     ,p_type )) IN (1,0) THEN
     ln_amount := Tot_Revenue(p_prj_trx_id
		 ,p_task_id
		 ,p_rep_period
		 ,p_type )  - Tot_Invoice(p_prj_trx_id
	                                 ,p_task_id
	                                 ,p_rep_period
	                                 ,p_type);
   END IF;
*/
   RETURN NVL(ln_amount,0);
  EXCEPTION WHEN OTHERS THEN
   RETURN 0;
  END Unbilled_Bal_Curr_Mon;
  FUNCTION Curr_Mon_Bill_Rev(p_prj_trx_id NUMBER
                            ,p_task_id NUMBER
                            ,p_rep_period VARCHAR2
		            ,p_type VARCHAR2) RETURN NUMBER as
 /*Function returns the Current Month's Billing which is fully recognized as revenue
   Projects: If Current months Revenue is equal to the current month's Bill then this function returns bill amount from invoice review of the period passed
   Service Contracts: If current months revenue is equal to the current month;s bill then the function returns bill amount from invoice lines of period passed
 */
   ln_difference NUMBER := 0;
   ln_amount     NUMBER := 0;
   ln_rctl_amount NUMBER:=0;
   ln_oks_rev_amount NUMBER;
  BEGIN
  IF p_type = 'PROJECT' THEN
      SELECT
      (NVL((SELECT SUM(Invoice_Amount)
	    FROM    xxha_pa_invoice_review_v xpi
		       ,pa_periods_all pa
	    WHERE   p_prj_trx_id = xpi.project_id
            AND     (p_task_id = xpi.task_id or p_task_id is null)
	    AND     xpi.org_id = pa.org_id
	    AND     xpi.gl_date between pa.start_date and pa.end_date
	    AND     xpi.invoice_status = 'Accepted in Receivable'
	    AND     pa.period_name = (SELECT PA1.period_name
	                              FROM   pa_periods_all pa1
		                      WHERE  p_rep_period = pa1.period_name
			              AND    pa1.org_id = xpi.org_id
			             )
	   ),0)
       - NVL((SELECT SUM(Revenue_Amount)
	     FROM   xxha_pa_revenue_review_v xpr
	           ,pa_periods_all pa
	     WHERE  xpr.project_id = p_prj_trx_id
	     AND    (xpr.task_id  = p_task_id or p_task_id is null)
	     AND     xpr.transfer_status = 'Accepted'
	     AND    xpr.org_id = pa.org_id
	     AND     xpr.gl_date between pa.start_date and  pa.end_date
	     AND     pa.period_name = (SELECT PA1.period_name
	                               FROM   pa_periods_all pa1
		                       WHERE  p_rep_period = pa1.period_name
			               AND    pa1.org_id = xpr.org_id
			              )
	    ),0)
	) TOT
      INTO ln_difference
      FROM DUAL;
      IF NVL(ln_difference, 0) = 0 THEN
	 SELECT NVL(SUM(Invoice_Amount), 0)
	 INTO   ln_amount
         FROM   xxha_pa_invoice_review_v xpi
	       ,pa_periods_all pa
	 WHERE  p_prj_trx_id = xpi.project_id
	 AND   (p_task_id = xpi.task_id or p_task_id is null)
	 AND    xpi.org_id = pa.org_id
	 AND    xpi.gl_date between pa.start_date and pa.end_date		-- Version 2.0
	 AND     xpi.invoice_status = 'Accepted in Receivable'
	 AND    pa.period_name = (SELECT PA1.PERIOD_NAME
	                          FROM   pa_periods_all pa1
                                  WHERE  p_rep_period = pa1.period_name
                                  AND    pa1.org_id = xpi.org_id
                                 );

      ELSE
	 ln_amount := 0;
      END IF;  --ln_difference = 0
         RETURN ln_amount;
  ELSIF p_type = 'SERVICE' THEN
      SELECT NVL(sum(INVD.amount), 1)
	  INTO   ln_difference
      FROM   ra_customer_trx_all RCT
            ,ra_customer_trx_lines_all RCTL
            ,ra_cust_trx_line_gl_dist_all INVD
            ,gl_period_statuses gps
      WHERE  rct.customer_trx_id = rctl.customer_trx_id
  	  AND  rctl.customer_trx_line_id = p_prj_trx_id
	  AND  RCTL.CUSTOMER_TRX_LINE_ID = INVD.CUSTOMER_TRX_LINE_ID
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
 --     AND  rctl.set_of_books_id = gps.set_of_books_id
         AND  rctl.set_of_books_id = gps.ledger_id
      AND  invd.gl_date between gps.start_date and gps.end_date
      AND  GPS.application_id = 222
      AND  invd.account_class = 'UNEARN'
 	  AND  gps.period_name = p_rep_period;
      SELECT NVL(sum(INVD.amount), 1),
             SUM(rctl.extended_amount)
	  INTO   ln_oks_rev_amount,
	     ln_rctl_amount
      FROM   ra_customer_trx_all RCT
            ,ra_customer_trx_lines_all RCTL
            ,ra_cust_trx_line_gl_dist_all INVD
            ,gl_period_statuses gps
      WHERE  rct.customer_trx_id = rctl.customer_trx_id
  	  AND  rctl.customer_trx_line_id = p_prj_trx_id
	  AND  RCTL.CUSTOMER_TRX_LINE_ID = INVD.CUSTOMER_TRX_LINE_ID
/* R12 Upgrade Modified on 09/26/2012 by Venkatesh Sarangam, Rolta */
--    AND  rctl.set_of_books_id = gps.set_of_books_id
     AND  rctl.set_of_books_id = gps.ledger_id
      AND  invd.gl_date between gps.start_date and gps.end_date
      AND  GPS.application_id = 222
      AND  invd.account_class = 'REV'
 	  AND  gps.period_name = p_rep_period;
          SELECT RCTL.extended_amount
	  INTO   ln_amount
          FROM   ra_customer_trx_all RCT
                ,ra_customer_trx_lines_all RCTL
          WHERE  rct.customer_trx_id = rctl.customer_trx_id
          AND  rctl.customer_trx_line_id = p_prj_trx_id;
      IF (ln_difference  = 0 AND ln_oks_rev_amount = ln_rctl_amount) THEN
          -- Vasil: 20110524 removed ABS and added nvl
          RETURN nvl( ln_amount, 0 );
      ELSE
          RETURN 0;
     END IF; --ln_difference = 0
  END IF; -- P_TYPE = 'PROJECT OR SERVICE'
  EXCEPTION WHEN OTHERS THEN
	  RETURN 0;
  END Curr_Mon_Bill_Rev;
  FUNCTION Tot_Rev_Recognized(p_prj_trx_id NUMBER
                             ,p_task_id NUMBER
                             ,p_rep_period VARCHAR2
                             ,p_type VARCHAR2) RETURN NUMBER as
 /*Function returns the Total Revenue Recognized Current Month
   Projects: Current Month Deferred REcognization + Current Month Revenue Recognized + current Month Bill direct to revenue
   Service Contracts: Current Month Deferred REcognization + current Month Bill direct to revenue
 */
	ln_amount NUMBER := 0;
  BEGIN
    IF p_type = 'PROJECT' THEN
	   ln_amount := Curr_Mon_Deff_Recognition(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT') +
	                CurrMonth_Revenue_Rec_unbilled(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT') +
	                 Curr_Mon_Bill_Rev(p_prj_trx_id, p_task_id, p_rep_period, 'PROJECT');
     ELSIF p_type = 'SERVICE' THEN
	  ln_amount := xxha_deferred_revenue_rep_pkg.Curr_Mon_Deff_Recognition(p_prj_trx_id, NULL, p_rep_period, 'SERVICE') +
	                xxha_deferred_revenue_rep_pkg.Curr_Mon_Bill_Rev(p_prj_trx_id, NULL, p_rep_period, 'SERVICE');
	END IF;
	RETURN ln_amount;
  EXCEPTION WHEN OTHERS THEN
    RETURN 0;
  END Tot_Rev_Recognized;
  FUNCTION Tot_Revenue(p_prj_trx_id NUMBER
                      ,p_task_id NUMBER
                      ,p_rep_period VARCHAR2
                      ,p_type VARCHAR2) RETURN NUMBER AS
   ln_rev_amount NUMBER :=0;
  BEGIN
	   SELECT NVL(SUM(revenue_amount), 0)
	   INTO   ln_rev_amount
	   FROM   xxha_pa_revenue_review_v xpr
		 ,pa_periods_all pa
	   WHERE  xpr.project_id = p_prj_trx_id
	   AND    (xpr.task_id  = p_task_id or p_task_id is null)
	   AND     xpr.transfer_status = 'Accepted'
	   and    xpr.org_id = pa.org_id
	   AND    xpr.gl_date <= pa.end_date
	   AND    pa.period_name = p_rep_period;
   RETURN ln_rev_amount;
  EXCEPTION WHEN OTHERS THEN
   RETURN 0;
  END Tot_Revenue;
  FUNCTION Tot_Invoice(p_prj_trx_id NUMBER
                      ,p_task_id NUMBER
                      ,p_rep_period VARCHAR2
                      ,p_type VARCHAR2) RETURN NUMBER AS
   ln_inv_amount NUMBER:=0;
  BEGIN
   SELECT NVL(SUM(invoice_amount), 0)
   INTO   ln_inv_amount
   FROM   xxha_pa_invoice_review_v xpi
         ,pa_periods_all pa
   WHERE  p_prj_trx_id = xpi.project_id
   AND    (p_task_id = xpi.task_id or p_task_id is null)
   AND     xpi.invoice_status = 'Accepted in Receivable'
   and    xpi.org_id = pa.org_id
   AND    xpi.gl_date <= pa.end_date
   AND    pa.period_name = p_rep_period;
   RETURN ln_inv_amount;
  EXCEPTION WHEN OTHERS THEN
   RETURN 0;
  END Tot_Invoice;
  FUNCTION Tot_Inv_lastmonth(p_prj_trx_id NUMBER
                            ,p_task_id NUMBER
                            ,p_rep_period VARCHAR2
                            ,p_type VARCHAR2) RETURN NUMBER AS

   ln_inv_prev_amount NUMBER:=0;
  BEGIN
   SELECT  NVL(SUM(XPI.invoice_amount), 0)
   INTO    ln_inv_prev_amount
   FROM    xxha_pa_invoice_review_v xpi
          ,pa_periods_all pa
   WHERE   p_prj_trx_id = xpi.project_id
   AND     (p_task_id = xpi.task_id or (p_task_id is null and xpi.task_id is null))
   AND     xpi.invoice_status = 'Accepted in Receivable'
   AND     xpi.org_id = pa.org_id
   AND     xpi.gl_date < pa.start_date
   AND     pa.period_name = p_rep_period;
   RETURN ln_inv_prev_amount;
  EXCEPTION WHEN OTHERS THEN
   RETURN 0;
  END Tot_Inv_lastmonth;
  FUNCTION Tot_Rev_lastmonth(p_prj_trx_id NUMBER
                            ,p_task_id NUMBER
                            ,p_rep_period VARCHAR2
                            ,p_type VARCHAR2) RETURN NUMBER AS

   ln_rev_prev_amount NUMBER :=0;
  BEGIN
   SELECT NVL(SUM(revenue_amount), 0)
   INTO   ln_rev_prev_amount
   FROM   xxha_pa_revenue_review_v xpr
         ,pa_periods_all pa
   WHERE  xpr.project_id = p_prj_trx_id
   AND    (xpr.task_id  = p_task_id or p_task_id is null)
   AND     xpr.transfer_status = 'Accepted'
   and    xpr.org_id = pa.org_id
   AND    xpr.gl_date < pa.start_date
   AND    pa.period_name = p_rep_period;
   RETURN ln_rev_prev_amount;
  EXCEPTION WHEN OTHERS THEN
   RETURN 0;
  END Tot_Rev_lastmonth;
  FUNCTION Tot_Inv_curmonth(p_prj_trx_id NUMBER
                           ,p_task_id NUMBER
                           ,p_rep_period VARCHAR2
                           ,p_type VARCHAR2) RETURN NUMBER AS
   ln_inv_cur_amount NUMBER:=0;
  BEGIN
   SELECT  NVL(SUM(XPI.invoice_amount), 0)
   INTO    ln_inv_cur_amount
   FROM    xxha_pa_invoice_review_v xpi
          ,pa_periods_all pa
   WHERE   p_prj_trx_id = xpi.project_id
   AND     (p_task_id = xpi.task_id or (p_task_id is null and xpi.task_id is null))
   AND     xpi.invoice_status = 'Accepted in Receivable'
   AND     xpi.org_id = pa.org_id
   AND     xpi.gl_date between pa.start_date and pa.end_date
   AND     pa.period_name = p_rep_period;
   RETURN ln_inv_cur_amount;
  EXCEPTION WHEN OTHERS THEN
  RETURN 0;
  END Tot_Inv_curmonth;
  FUNCTION Tot_Rev_curmonth(p_prj_trx_id NUMBER
                           ,p_task_id NUMBER
                           ,p_rep_period VARCHAR2
                           ,p_type VARCHAR2) RETURN NUMBER AS

   ln_rev_cur_amount NUMBER :=0;
  BEGIN
   SELECT NVL(SUM(revenue_amount), 0)
   INTO   ln_rev_cur_amount
   FROM   xxha_pa_revenue_review_v xpr
         ,pa_periods_all pa
   WHERE  xpr.project_id = p_prj_trx_id
   AND    (xpr.task_id  = p_task_id or p_task_id is null)

   and    xpr.org_id = pa.org_id
   AND    xpr.gl_date between pa.start_date and pa.end_date
   AND    pa.period_name = p_rep_period;
   RETURN ln_rev_cur_amount;
  EXCEPTION WHEN OTHERS THEN
   RETURN 0;
  END Tot_Rev_curmonth;
END xxha_deferred_revenue_rep_pkg;
/
