CREATE OR REPLACE PACKAGE HAEMO_WM_UPD_ITEM_STS_HLER_PKG AUTHID CURRENT_USER 
-- +=====================================================================================+
-- | Name        : HAEMO_WM_UPD_ITEM_STS_HLER_PKG                 	         |
-- | Purpose     : Support the Interface of ECO into EBS.    				 |
-- |                                                             	                 |
-- | Description : Procedure to determine calling parameters for 			 |
-- |		   Updating Item Status Concurrent Request				 |
-- |		   Takes in the mandatory and optional parameters required for 		 |
-- |		   Updating Item Status Concurrent Request.				 |
-- |                                                                           		 |
-- |                                            					 |
-- |                                                                           		 |
-- | Comment     : This package is called to execute EGO_ITEM_PUB.Process_Items function.|
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who       What                                             		 |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 20100426  1.0  Vasil S. Valkov   Initial version.					 |
-- +=====================================================================================+
AS
PROCEDURE HAEMO_WM_HANDLE_UPD_ITEM_STS(p_item_number IN VARCHAR,
			    v_status OUT VARCHAR, v_message OUT VARCHAR
			    );

END Haemo_Wm_Upd_Item_Sts_Hler_Pkg;
/


CREATE OR REPLACE PACKAGE BODY HAEMO_WM_UPD_ITEM_STS_HLER_PKG 
AS
-- +=====================================================================================+
-- | Name        : HAEMO_WM_UPD_ITEM_STS_HLER_PKG                 	         |
-- | Purpose     : Support the Interface of ECO into EBS.    				 |
-- |                                                             	                 |
-- | Description : Procedure to determine calling parameters for 			 |
-- |		   Updating Item Status Concurrent Request				 |
-- |		   Takes in the mandatory and optional parameters required for 		 |
-- |		   Updating Item Status Concurrent Request.				 |
-- |                                                                           		 |
-- |                                            					 |
-- |                                                                           		 |
-- | Comment     : This package is called to execute EGO_ITEM_PUB.Process_Items function.|
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who       What                                             		 |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 20100426  1.0  Vasil S. Valkov   Initial version.					 |
-- +=====================================================================================+

PROCEDURE HAEMO_WM_HANDLE_UPD_ITEM_STS(p_item_number IN VARCHAR,
			    v_status OUT VARCHAR, v_message OUT VARCHAR
			    )
IS

l_item_table          EGO_Item_PUB.Item_Tbl_Type;
x_item_table          EGO_Item_PUB.Item_Tbl_Type;
x_return_status       VARCHAR2(10);
x_msg_count           NUMBER(10);
x_msg_data	      VARCHAR2(4000);
x_msg_index_out	      NUMBER;

cursor c_orgs is
select ood.organization_code 
from mtl_system_items_b msi,
     org_organization_definitions ood
where msi.organization_id = ood.organization_id
and msi.segment1 = p_item_number;

BEGIN

FND_GLOBAL.APPS_INITIALIZE(USER_ID=>1706,RESP_ID=>20634,RESP_APPL_ID=>401);

for orgs in c_orgs loop
	  --FIRST Item definition
	     l_item_table(1).Transaction_Type            := 'UPDATE'; 
	     l_item_table(1).Segment1                    := p_item_number;--'01945AB1-00';
	     l_item_table(1).Organization_Code           := orgs.organization_code;--'ATV';
	     l_item_table(1).Inventory_Item_Status_Code  := 'Active';
	  
	  ---*****note this will also update the customer_order_enabled_flag and internal_order_enabled_flag to Y
	  
	  
	     EGO_ITEM_PUB.Process_Items(
	            p_api_version           => 1.0
	           ,p_init_msg_list         => FND_API.g_TRUE
	           ,p_commit                => FND_API.g_TRUE
	           ,p_Item_Tbl              => l_item_table
	           ,x_Item_Tbl              => x_item_table
	           ,x_return_status         => x_return_status
         	   ,x_msg_count             => x_msg_count);
         	   
	     IF x_msg_count > 0
	           THEN
	              FOR v_index IN 1 .. x_msg_count
	              LOOP
	                 fnd_msg_pub.get (p_msg_index => v_index, p_encoded => 'F', p_data => x_msg_data, p_msg_index_out => x_msg_index_out);
	                 v_message := SUBSTR (x_msg_data, 1, 200);
	              END LOOP;
	           END IF;

end loop;
commit;

v_status := x_return_status;

EXCEPTION
 WHEN OTHERS THEN
 v_status:='E';

END HAEMO_WM_HANDLE_UPD_ITEM_STS;

END HAEMO_WM_UPD_ITEM_STS_HLER_PKG;
/
