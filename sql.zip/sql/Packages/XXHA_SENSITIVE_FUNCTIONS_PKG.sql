CREATE OR REPLACE PACKAGE XXHA_SENSITIVE_FUNCTIONS_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_SENSITIVE_FUNCTIONS_PKG                                            *
* Purpose      : This package creates Data and reports for Sesitive Functions reporting  *
*                It is called from several concurrent Requests                           *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        19-Jul-2010     Dave Lund            Initial Creation                       *
*                                                                                        *
*****************************************************************************************/

PROCEDURE XXHAE_FND_FIND_APP_FUNC 
                       (p_func_area varchar2
                      , p_func_name varchar2
                      , p_user_func_name varchar2
                      , p_desc varchar2);

PROCEDURE XXHAE_run_FIND_APP_FUNC
                       (x_errbuf  out  varchar2
                      , x_retcode  out  varchar2);

PROCEDURE XXHA_SENS_FUNC_BY_USER_RPT
                       (x_err_buf  out  varchar2
                      , x_ret_code  out  varchar2);
                                     
PROCEDURE XXHA_SENS_FUNC_BY_RESP_RPT
                       (x_err_buf  out  varchar2
                      , x_ret_code  out  varchar2);

END XXHA_SENSITIVE_FUNCTIONS_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_SENSITIVE_FUNCTIONS_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_SENSITIVE_FUNCTIONS_PKG                                            *
* Purpose      : This package creates Data and reports for Sesitive Functions reporting  *
*                It is called from several concurrent Requests                           *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        19-Jul-2010     Dave Lund            Initial Creation                       *
* 1.1        23-Jul-2010     Dave Lund            Added contracts sensitive functions    *
*                                                                                        *
*****************************************************************************************/

PROCEDURE XXHAE_RUN_FIND_APP_FUNC
(x_errbuf  out  varchar2
,x_retcode  out  varchar2)
 as
/*****************************************************************************************
* Procedure Name : XXHAE_RUN_FIND_APP_FUNC                                               *
* Purpose      : This procedure calls the procedure to populate the data for each        *
*                function identified as sensitive                                        *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author            Description                               *
* ------     -----------     ----------------- ---------------                           *
* 1.0        19-Jul-2010     Dave Lund         Initial Creation                          *
* 1.1        23-Jul-2010     Dave Lund         Added contracts sensitive functions       *
* 1.2        24-Aug-2011     Dave Lund         Removed functions no longer considered    *
*                                              sensitive                                 *
* 1.3        11-Jan-2012     Dave Lund         Added customer quick and summary funcs    *
* 1.4        31-MAY-2013     Dave Lund         Removed item where used and indented BOM  *
*                                                                                        *
*****************************************************************************************/
begin
--
delete from XXHAE_SENSITIVE_FUNC;
--
XXHAE_FND_FIND_APP_FUNC('General Ledger','FND_FNDFFMSV','Flexfield Values','Create/modify/delete content of the COA (account names / numbers)');
XXHAE_FND_FIND_APP_FUNC('General Ledger','GLXOCPER','Open and Close Periods','Open / close period');
XXHAE_FND_FIND_APP_FUNC('General Ledger','FND_FNDFFMIS','Key Flexfield Segments','Create/modify/delete structure of the COA (e.g., flexfield segments, sets of books)');
XXHAE_FND_FIND_APP_FUNC('General Ledger','GLXRTDLY','Daily Rates','Create/modify/delete Daily and Period Rates (exchange rates)');
XXHAE_FND_FIND_APP_FUNC('General Ledger','GLXRTPER','Period Rates','Create/modify/delete Daily and Period Rates (exchange rates)');
XXHAE_FND_FIND_APP_FUNC('General Ledger','GLXJEPST','Post Journals','Post journal entries');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDAXS_R','Row Set','Define Row Set');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDAXS_C','Column Set','Define Column Set');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDCON','Define Content Set','Define Content Set');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDORD','Define Row Order','Define Row Order');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDREP','Define Financial Report','Define Financial Report');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDRST','Define Financial Report Set','Define Financial Report Set');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDCOS','Define Display Set','Define Display Set');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXGDCOG','Define Display Group','Define Display Group');
XXHAE_FND_FIND_APP_FUNC('General Ledger','RGXAUCP','Autocopy Report component','Autocopy Report component');
commit;
--
XXHAE_FND_FIND_APP_FUNC('Fixed Assets','FAXDPRUN','Run Depreciation','Open / close period');
XXHAE_FND_FIND_APP_FUNC('Fixed Assets','FAXSSPMA','Post Mass Additions','Initiate Mass Additions Concurrent (run/modify depreciation)');
XXHAE_FND_FIND_APP_FUNC('Fixed Assets','FAXASSET','Asset Workbench','Create/modify/delete fixed assets');
XXHAE_FND_FIND_APP_FUNC('Fixed Assets','FAXASSET','Asset Workbench','Change useful lives and depreciation methods');
XXHAE_FND_FIND_APP_FUNC('Fixed Assets','FAXSUCAT','Asset Categories','Change useful lives and depreciation methods');
commit;
--
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTGMP','Cost Periods','Open / close period');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVIDITM','Master Items','Create/modify/delete inventory items (Master Org)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVIDITM_ORG','Organization Items','Create/modify/delete inventory items (Inventory Org)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_CSTFITCT','Item Costs','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_CSTFEACU','Average Cost Update','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_UPDATE','Launch Cost Update','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_CSTFQSCU','View Standard Cost Update','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_PURGE_COSTHIS','Purge Standard Cost History','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_CSTFQSCH','View Standard Cost History','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_COPY_COST','Copy Cost Information','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_MASSEDIT_COST','Mass Edit Cost Information','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_MASSEDIT_ACCOUNT','Mass Edit Item Accounts','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_PURGE_COST','Purge Cost Information','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_CSTIMP','Import Cost Information','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_CSTPLIMP','Import Cost from Price List','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_SETCOSTCNTRLS','Set Cost Controls','Create/modify/delete standard costs (Item Cost)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVIDITM','Master Items','Create/modify/delete item attributes including safety stock levels');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVIDITM_ORG','Organization Items','Create/modify/delete item attributes including safety stock levels');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTMTX_MISC','Miscellaneous Transaction','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_FNDRSRUN_TXN_PURGE','Purge Transactions','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVSDSUB','Subinventories','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','RCV_RCVRCERC','Receipts','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','RCV_RCVTXERE','Returns','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','RCV_RCVSHESH','Manage Shipments','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','RCV_RCVTXECO','Corrections','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTMTX_MISC','Miscellaneous Transaction','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTVPTX','Transaction Interface','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTMTX_VMIXFER','Planning Transfer','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVATCEN','Cycle Count Counts','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVAMCAP','Cycle Count Adjustments','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVADPPI','Physical Inventories','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVADPAP','Physical Inventory Adjustments','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
XXHAE_FND_FIND_APP_FUNC('Inventory','WIP_WIPTXCMP','Completion Transactions','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--the following functions are no longer considered sensitive and are being removed from the reporting DL 8/24/11
--XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVPTRPR','Replenishment Counts','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','WSHFSTRX','Shipping Transactions Form','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','WIP_WIPTXSFM','Move Transactions','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','WIP_WIPTXMAT','WIP Material Transactions','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTMTX_CONSXFER','Consigned Transactions','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTOMAI','Move Orders','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTOTRX','Transact Move Orders','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTMTX_BORROW_PAYBACK','Borrow Payback Transactions','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTMTX_SUBINV','Subinventory Transfer','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVTTMTX_INTERORG','Interorganization Transfer','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');
--XXHAE_FND_FIND_APP_FUNC('Inventory','RCV_RCVTXERT','Receiving Transactions','Create/modify/delete inventory balances in the perpetual/subledger (includes shipping transactions, receiving transactions, completion transactions, misc. issues, misc. receipts, account aliases, cycle count and physical inventory)');

--Standard Cost updates are done through a concurrent program. this query extracts the data and puts it in the table
--DL added 7/23
  insert into XXHAE_SENSITIVE_FUNC
    (USER_FUNCTION_NAME
    , RESP_APPLICATION_ID
    , RESPONSIBILITY_ID
    , FUNCTIONAL_AREA
    , description
    , refresh_date)
    select v.conc_prog_name
    , r.application_id
    , r.responsibility_id
    , 'Inventory'
    , 'Create/modify/delete standard cost rates (labor, overhead and dept rates)'
    , sysdate
    from XXHA_REQUEST_ACCESS_BY_RESP_V v, fnd_responsibility_tl r
    where v.executable_name in ('CMCICU','CMCCCU','XXHAMAKEITEMCST')
    and r.responsibility_name = v.responsibility_name
    and r.language = 'US';
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_CSTFITCT','Item Costs','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_CSTQICCG','Item Costs History','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','CST_FNDRSRUN_ROLLUP','Launch Cost Rollup','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','INV_INVSDOIO','Organization Parameters','Modify Uplift Calculation');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFDBOM','Bills of Material','Create/modify/delete BOM');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFQBCP','Bills of Material Comparison','Create/modify/delete BOM');
-- functions are qurey only and do not need to be monitored DL 5/31/13
--XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFQBIN','Indented Bills of Materials','Create/modify/delete BOM');
--XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFQWIN','Item WhereUsed','Create/modify/delete BOM');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFDMCO','Mass Change Orders','Create/modify/delete BOM');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_FNDRSRUN_BOM_IMPORT','Requests: Import Bills and Routings','Create/modify/delete BOM');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BILL_FNDATDOC','Bill Documents','Create/modify/delete BOM');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_FNDRSRUN_CREATECOMMONBILLS','Create Common Bills','Create/modify/delete BOM');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFDRTG','Routings','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFDRSO','Standard Operations','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFDODP','Departments','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFDORS','Resources','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFQWRS','Resource WhereUsed','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_FNDRSRUN_LEADTIME','Requests: Compute Lead times','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_FNDRSRUN_BOM_IMPORT','Requests: Import Bills and Routings','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_OPERATION_FNDATDOC','Operation Documents','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFRSSO','Setup Standard Operation','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
XXHAE_FND_FIND_APP_FUNC('Inventory','BOM_BOMFDSTP','Setup Types','Create/modify/delete standard cost rates (labor, overhead and dept rates)');
--
commit;
-- DL added 1/11/12
XXHAE_FND_FIND_APP_FUNC('Order Management','AR_ARXCUDCI_GATEWAY','Customers Summary','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','AR_ARXCUDCI_QUICK','Customers Quick','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','HZ_ARXCUDCI_GATEWAY','Customers: Summary','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','HZ_ARXCUDCI_QUICK','Customers: Quick Form','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','AR_ARXCUDCI_GATEWAY','Customers Summary','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','HZ_ARXCUDCW_QUICK','Customers:  Quick','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','AR_ARXCUDCI_GATEWAY','Customers Summary','Create/modify/delete customers');
--
XXHAE_FND_FIND_APP_FUNC('Order Management','HZ_ARXCUDCI_STD','Customers: Standard Form','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','AR_ARXCUDCI_STD','Customers Standard','Create/modify/delete customers');
XXHAE_FND_FIND_APP_FUNC('Order Management','QP_QPXPRLST','Enter Price Lists','Create/modify/delete price lists (includes transfer prices)');
XXHAE_FND_FIND_APP_FUNC('Order Management','QP_QPXPRCPL','Duplicate Price List','Create/modify/delete price lists (includes transfer prices)');
XXHAE_FND_FIND_APP_FUNC('Order Management','QP_QPXPRMPL','Adjust Prices in Price Lists','Create/modify/delete price lists (includes transfer prices)');
XXHAE_FND_FIND_APP_FUNC('Order Management','QP_QPXPRAII','Attach Items to Price Lists','Create/modify/delete price lists (includes transfer prices)');
XXHAE_FND_FIND_APP_FUNC('Order Management','HZ_ARXCUDCI_STD','Customers: Standard Form','Create/modify/delete pricing associations (price lists to customers)');
XXHAE_FND_FIND_APP_FUNC('Order Management','AR_ARXCUDCI_STD','Customers Standard','Create/modify/delete pricing associations (price lists to customers)');
XXHAE_FND_FIND_APP_FUNC('Order Management','ONT_FNDLVMLU','Order Management QuickCodes','Create/modify/delete shipping terms');
XXHAE_FND_FIND_APP_FUNC('Order Management','AR_RAXSUTRM','Define Payment Terms','Create/modify/delete payment terms');
XXHAE_FND_FIND_APP_FUNC('Order Management','ONT_OEXOEORD','Sales Orders','Create/modify/delete orders');
--credit hold releases are done through a form in OE. this query extracts the data and puts it in the table
  insert into XXHAE_SENSITIVE_FUNC
    (USER_FUNCTION_NAME
    , RESP_APPLICATION_ID
    , RESPONSIBILITY_ID
    , FUNCTIONAL_AREA
    , description
    , refresh_date)
  select 'Release credit hold'
    , application_id
    , responsibility_id
    , 'Order Management'
    , 'Release credit hold'
    , sysdate
  from OE_HOLD_AUTHORIZATIONS
  where hold_id = 1 --credit check
  and sysdate between nvl(start_date_active,sysdate) and nvl(end_date_active,sysdate)
  and authorized_action_code = 'REMOVE';
--
commit;
--
XXHAE_FND_FIND_APP_FUNC('Accounts Receivables','AR_ARXSUMPS','Open/Close Accounting Periods','Open / close period');
XXHAE_FND_FIND_APP_FUNC('Accounts Receivables','AR_ARXCWMAI_MAI','Customer Accounts','Adjust accounts receivable balances in the subledger');
XXHAE_FND_FIND_APP_FUNC('Accounts Receivables','AR_ARXTWMAI_HEADER','Transactions','Create/modify/delete invoices');
XXHAE_FND_FIND_APP_FUNC('Accounts Receivables','AR_ARXTWMAI_HEADER','Transactions','Create/modify/delete manual AR invoices');
XXHAE_FND_FIND_APP_FUNC('Accounts Receivables','AR_ARXTWMAI_HEADER','Transactions','Create/modify/delete invoice date (or otherwise adjust the aging)');
XXHAE_FND_FIND_APP_FUNC('Accounts Receivables','AR_ARXRWMAI_HEADER','Receipt','Cash applications');
commit;
--
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXSUMPS','AP Accounting Periods','Open / close period');
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXVDMVD','Suppliers','Create/modify/delete supplier payment details (e.g., bank information)');
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXVDDUP','Merge Suppliers','Create/modify/delete supplier payment details (e.g., bank information)');
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXINWKB_HOLDS','Invoice Holds','Release invoice holds');
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXSUMMT','Tolerances','Modify invoice matching tolerances');
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXPAWKB_BATCH','Payment Batches','Manual disbursement (i.e., not from a matched invoice)');
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXPBSET','Payment Batch Sets','Manual disbursement (i.e., not from a matched invoice)');
XXHAE_FND_FIND_APP_FUNC('Accounts Payables','AP_APXPAWKB','Payments','Manual disbursement (i.e., not from a matched invoice)');
commit;
--
XXHAE_FND_FIND_APP_FUNC('Purchasing','PON_PO_SUMMARY','Purchase Order Summary','Create/modify purchase orders');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOVPO','Purchase Order Summary','Create/modify purchase orders');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOEPO','Purchase Orders','Create/modify purchase orders');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PON_PO_SUMMARY','Purchase Order Summary','Approve/Create/modify blanket purchase agreements');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOVPO','Purchase Order Summary','Approve/Create/modify blanket purchase agreements');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOEPO','Purchase Orders','Approve/Create/modify blanket purchase agreements');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PON_PO_SUMMARY','Purchase Order Summary','Approve/Create/modify contract purchase agreements');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOVPO','Purchase Order Summary','Approve/Create/modify contract purchase agreements');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOEPO','Purchase Orders','Approve/Create/modify contract purchase agreements');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PON_PO_SUMMARY','Purchase Order Summary','Modify receiving tolerances');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOVPO','Purchase Order Summary','Modify receiving tolerances');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOEPO','Purchase Orders','Modify receiving tolerances');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PON_PO_SUMMARY','Purchase Order Summary','Close a Purchase Order');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOVPO','Purchase Order Summary','Close a Purchase Order');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXPOEPO','Purchase Orders','Close a Purchase Order');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PONINQREQSUM_REQSUMMARY','Requisition Summary','Create/modify requisitions');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXRQVRQ','Requisition Summary','Create/modify requisitions');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXRQERQ','Requisitions','Create/modify requisitions');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXSTDPC','Approval Assignments','Assign Approval Group to the Job-codes');
XXHAE_FND_FIND_APP_FUNC('Purchasing','PO_POXSTDCG','Approval Groups','Assign Amount Limits to the approval group');
commit;
--
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSDJT_EI','Job form','Add/Modify job codes');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-275','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-400','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-400-EI','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-403','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-403-EI','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-404','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-404-ZA-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-405','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-406','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-407','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-407-EI','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-408','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-409','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-410','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-411','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-412','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-AE-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-AU-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-BE-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-CA-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-DE-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-DK-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-ES-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-FI-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-FR-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-GHR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-HU-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-HXTOTM','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-IE-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-IT-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-JP-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-JP-HR-PERSON','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-JP-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-JP-HRMS-PERSON','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-JP-PAY','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-JP-PAY-PERSON','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-JP-SHRMS-PERSON','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-KW-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-NL-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-NO-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-NZ-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-PL-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-PL-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-PL-PAY','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-PL-SHRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-PTU','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-RU-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-SA-HR','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-SE-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-SG-HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG-SSP','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG_CA_HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG_CA_SHRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG_CA_PAY','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSHRG_KR_HRMS','Combined People/Assignment form','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PERWSEMA','Enter Assignment','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PQHWSCET10','Mass Employee Assignment Update','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PQHWSCET11','Mass Employee Assignment Update','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PQHWSCET3','Mass Employee Assignment Update','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PQHWSCET6','Mass Employee Assignment Update','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PQHWSCET7','Mass Employee Assignment Update','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PQHWSCET8','Mass Employee Assignment Update','Change employee job code assignments');
XXHAE_FND_FIND_APP_FUNC('Human Resources','PQHWSCET9','Mass Employee Assignment Update','Change employee job code assignments');
commit;
--
--DL added 7/23
XXHAE_FND_FIND_APP_FUNC('Contracts','OKC_TERMS_TEMPLATE_SEARCH','OKC Terms Templates Search Page','Create/modify/delete whether clause is mandatory');
XXHAE_FND_FIND_APP_FUNC('Contracts','OKC_ART_SEARCH','OKC Search Clause Page','Create/modify/delete whether clause is text protected');
XXHAE_FND_FIND_APP_FUNC('Contracts','OKC_ART_SEARCH','OKC Search Clause Page','Create/modify/delete the alternate clauses associated with a clause');
XXHAE_FND_FIND_APP_FUNC('Contracts','OKC_ART_SEARCH','OKC Search Clause Page','Create/modify/delete the text of a clause');
XXHAE_FND_FIND_APP_FUNC('Contracts','ONT_OEXOEBSO','Blanket Sales Agreements','Create/modify/delete the designation of a clause as Standard or Non-standard');
XXHAE_FND_FIND_APP_FUNC('Contracts','XXHA_BSAAPPRLST','XXHA BSA Approval List','Create/modify/delete the table of non-standard contract term approvers');
XXHAE_FND_FIND_APP_FUNC('Contracts','XXHA_NONSTDCLST','XXHA Non Std Clause Titles List','Create/modify/delete the table of non-standard contract term approvers');
XXHAE_FND_FIND_APP_FUNC('Contracts','XXHA_PRDLBDIVMAP','XXHA Product Line to BDIV Mapping','Create/modify/delete the table of non-standard contract term approvers');
commit;
--
end XXHAE_RUN_FIND_APP_FUNC;

/****************************************************************************************/

PROCEDURE XXHAE_FND_FIND_APP_FUNC(p_func_area varchar2
                                , p_func_name varchar2
                                , p_user_func_name varchar2
                                , p_desc varchar2) AS
/*****************************************************************************************
* Procedure Name : XXHAE_FND_FIND_APP_FUNC                                               *
* Purpose      : This procedure populates sensitive data table                           *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        19-Jul-2010     Dave Lund            Initial Creation                       *
*                                                                                        *
*****************************************************************************************/
CURSOR responsibility_list IS
select distinct r.responsibility_name
, r.application_id appid
, r.responsibility_id respid
from apps.fnd_responsibility_vl r
where 1=1
and r.responsibility_name in
       (SELECT FRT.RESPONSIBILITY_NAME
        FROM apps.FND_RESPONSIBILITY_VL FRT,
        apps.FND_MENUS FM
        WHERE exists
         (select to_number(substr (pm, -5))
              from (
                     Select Sys_Connect_by_Path(nvl(FME.prompt,'xxxx'),'~') pp
                             ,Sys_Connect_by_Path(FME.menu_id,'~') pm
                      From apps.FND_MENU_ENTRIES_vl FME
                      Connect by prior FME.MENU_ID = FME.SUB_MENU_ID
                      Start with fme.function_id in (select function_id
                                                     from apps.fnd_form_functions_vl
                                                     where function_name = p_func_name)
                    )
              where pp not like '%xxxx%'
              and FRT.MENU_ID = to_number(substr (pm, -5))
             )
      and not exists
        (select to_number(substr (pm, -5))
              from (
                     Select Sys_Connect_by_Path(nvl(FME2.prompt,'xxxx'),'~') pp
                             ,Sys_Connect_by_Path(FME2.menu_id,'~') pm
                      From apps.FND_MENU_ENTRIES_vl FME2
                      Connect by prior FME2.MENU_ID = FME2.SUB_MENU_ID
                      Start with fme2.function_id in (select function_id
                                                     from apps.fnd_form_functions_vl
                                                     where function_name = p_func_name)
                    ) me
            , apps.FND_RESP_FUNCTIONS FRF
              where me.pp not like '%xxxx%'
              and frf.responsibility_id = frt.responsibility_id
              and frf.rule_type = 'M'
              and frf.action_id = to_number(substr (pm, -5))
     )
        AND FRT.END_DATE IS NULL
       AND FRT.RESPONSIBILITY_ID = FRT.RESPONSIBILITY_ID
       AND FRT.MENU_ID = FM.MENU_ID
       AND FRT.RESPONSIBILITY_ID
              not in ( select FRF.responsibility_ID
                       from apps.FND_RESP_FUNCTIONS FRF
                         Where frf.rule_type = 'F'
                         and FRF.action_id in  (select function_id
                                                  from apps.fnd_form_functions_vl
                                                  where function_name = p_func_name)
                     )
       )
;
--
BEGIN
--
FOR resp_list IN responsibility_list
LOOP
--
    insert into XXHAE_SENSITIVE_FUNC
    (USER_FUNCTION_NAME
    ,RESP_APPLICATION_ID
    ,RESPONSIBILITY_ID
    ,FUNCTIONAL_AREA
    ,description
    ,refresh_date)
    values
    (p_user_func_name
    ,resp_list.appid
    ,resp_list.respid
    ,p_func_area
    ,p_desc
    ,sysdate);

  commit;

END LOOP;

END XXHAE_FND_FIND_APP_FUNC;

/****************************************************************************************/

PROCEDURE XXHA_SENS_FUNC_BY_RESP_RPT(x_err_buf  out  varchar2
                                     ,x_ret_code  out  varchar2) AS
/*****************************************************************************************
* Procedure Name : XXHA_SENS_FUNC_BY_RESP_RPT                                            *
* Purpose      : This procedure produces csv file output for sensitive functions by      *
*                responsibility                                                          *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        19-Jul-2010     Dave Lund            Initial Creation                       *
*                                                                                        *
*****************************************************************************************/

cursor c_resp is
select upper('"RESPONSIBILITY NAME","functional area","secure function","description","refresh date","from database"') data from dual
union all
select distinct '"'||t.RESPONSIBILITY_NAME||'","'||sf.functional_area||'","'||sf.user_function_name||'","'||sf.description||'","'||to_char(sf.refresh_date,'DD-MON-YYYY HH24:MI:SS')||'","'||db.name||'"'
from fnd_responsibility_tl t, XXHAE_SENSITIVE_FUNC sf, v$database db
where t.language = 'US'
and t.responsibility_id = sf.responsibility_id
and t.application_id = sf.resp_application_id;
begin
for resp in c_resp loop
  FND_FILE.PUT_LINE(FND_FILE.output,resp.data);
end loop;
end XXHA_SENS_FUNC_BY_RESP_RPT;

/****************************************************************************************/

PROCEDURE XXHA_SENS_FUNC_BY_USER_RPT(x_err_buf  out  varchar2
                                     ,x_ret_code  out  varchar2) AS

/*****************************************************************************************
* Procedure Name : XXHA_SENS_FUNC_BY_USERS_RPT                                           *
* Purpose      : This procedure produces csv file output for sensitive functions by      *
*                user                                                                    *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        19-Jul-2010     Dave Lund            Initial Creation                       *
* 1.1        29-Mar-2010     Dave Lund            Added job title and process family     *
*                                                                                        *
*****************************************************************************************/

cursor c_user is 
select upper('"user name","employee name","first name","last name","job","job title","process family","RESPONSIBILITY NAME","functional area","secure function","description","refresh date","from database"') data
from dual
union all 
SELECT DISTINCT '"'||u.user_name||'","'||pep.FULL_NAME||'","'||pep.first_name||'","'||pep.last_name||'","'||
j.name||'","'||jd.segment1||'","'||jd.segment3||'","'||t.RESPONSIBILITY_NAME||'","'||sf.functional_area||'","'||sf.user_function_name||'","'||sf.description||'","'||
to_char(sf.refresh_date,'DD-MON-YYYY HH24:MI:SS')||'","'||db.name||'"'
FROM FND_USER_RESP_GROUPS r, fnd_user u, PER_ALL_PEOPLE_F pep
, per_all_assignments_f asg, per_jobs j, per_job_definitions jd
, fnd_responsibility_tl t, XXHAE_SENSITIVE_FUNC sf
, v$database db
where r.RESPONSIBILITY_ID = t.RESPONSIBILITY_ID
and r.USER_ID = u.USER_ID
and u.EMPLOYEE_ID = pep.person_id
and sysdate between u.START_DATE and nvl(u.end_date,sysdate)
and sysdate between pep.effective_start_date and pep.effective_end_date
and pep.person_id = asg.person_id
and asg.primary_flag = 'Y'
and sysdate between asg.effective_start_date and asg.effective_end_date
AND asg.job_id = j.job_id(+)
and j.job_definition_id = jd.job_definition_id(+)
and trunc(sysdate) between r.start_date and nvl(r.end_date,trunc(sysdate))
and t.language = 'US'
and t.responsibility_id = sf.responsibility_id
and t.application_id = sf.resp_application_id;

begin
for user in c_user loop
  FND_FILE.PUT_LINE(FND_FILE.output,user.data);
end loop;
end XXHA_SENS_FUNC_BY_USER_RPT;

end XXHA_SENSITIVE_FUNCTIONS_PKG;
/
