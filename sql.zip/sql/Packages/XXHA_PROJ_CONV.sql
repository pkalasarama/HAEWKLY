CREATE OR REPLACE PACKAGE XXHA_PROJ_CONV IS
/*****************************************************************************************
* Package Name : XXHA_PROJ_CONV
* File Name: XXHAE_PROJ_CONV.sql
* Execute as APPS Schema
*
* Purpose      : This Package is created to convert SR Projects
*
* Change History
*
* Ver        Date            Author               Description
* ------     -----------     -----------------    ---------------
* 1.0        02-01-2011      Shekar Vemuri         Initial Creation
*
*****************************************************************************************/
-- Notes:
-- 1) OU 102   gv_org_id = 102 hardcoded
-- 2) Need to setup Product Code "CONVERSION"   setup/Activity Management Gateway/  PM_PRODUCT_CODE  --- CONVERSION
-- 3) v_template_project_name :=  TMP - HSS SR (US)
-- 4) g_project_user_name
-- 5) g_project_resp_name
--
--
--  Sequence of setuus/Programs:
--  1) package xxha_proj_conv
--  2) setup conc program
--  3) import table HAEMO.XXHA_CUSTOMERS_TEMP
--  4) Projects DATA
--  5) BSA Header for Conversion
--  6) SR  Class code for project
-----------------------------------------


g_request_id  NUMBER       := FND_GLOBAL.conc_request_id;
g_user_id     NUMBER       := FND_GLOBAL.USER_ID;
g_user_name   FND_USER.USER_NAME%TYPE   := fnd_profile.value('USERNAME');
g_data_base   VARCHAR2(15) := UPPER(sys_context('USERENV','DB_NAME')); -- also V$database can be used
g_date_time   VARCHAR2(25) := to_char(sysdate, 'MM-DD-YY-HH12-MI-SS-AM');
g_number      NUMBER  := 0;
g_char        VARCHAR2(32767);
g_date        DATE;
g_error_exists VARCHAR2(1);

--  SETUP INFO  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--g_org_id      NUMBER        := fnd_profile.value('ORG_ID'); -- do not use Client_Info
g_org_id         NUMBER := 102;
--g_utl_dir     VARCHAR2(100):= fnd_profile.value('UTL_FILE_DIR');
g_project_user_name  Varchar2(40)   := 'HAEOPER';                      -- 'SYSADMIN'; --
g_project_resp_name  VARCHAR2(100) := 'US Project Billing Superuser';  -- 'US Project Billing Super User';
g_product_code       VARCHAR2(20)  := 'CONVERSION';
-- TEMPLATE
--  END SETUP INFO  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

g_skip         EXCEPTION;
g_l_skip       EXCEPTION;
g_no_handle    EXCEPTION;
g_rec_counter  NUMBER  := 0;
g_counter      NUMBER  := 0;

g_return_status        VARCHAR2(2000);
g_msg_count            NUMBER;
g_msg_data             VARCHAR2(2000);

g_err_msg             VARCHAR2(1000);
g_return_code         NUMBER;

x               NUMBER;

procedure error_log(    p_prog_name    in  VARCHAR2
                    ,   p_key_value    in  VARCHAR2 --
                    ,   p_error_code   in  VARCHAR2   --
                    ,   p_error_msg    in  VARCHAR2
                    ,   p_column_name  in  VARCHAR
                    ,   p_column_value in  VARCHAR2
                    ,   p_return_code  out number
                   );

PROCEDURE project
            ( errbuf               IN OUT VARCHAR2
            , retcode              IN OUT NUMBER
            , p_prog_name          IN VARCHAR2
            , p_template_project   IN VARCHAR2
            , p_mode               IN  VARCHAR2 := 'VIEW_ONLY'
            , p_proj_conv_id_start IN NUMBER
            , p_proj_conv_id_end   IN NUMBER
            );

PROCEDURE budget
           -- ( errbuf  IN  VARCHAR2
           -- , retcode IN  NUMBER
           (    p_mode                 IN  VARCHAR2 := 'VIEW_ONLY'
           ,    p_proj_conv_id_start   IN NUMBER
           ,    p_proj_conv_id_end     IN NUMBER
           );

PROCEDURE baseline_budget
            ( p_mode IN VARCHAR2 := 'VIEW_ONLY'
            );

PROCEDURE update_project
            ( p_mode IN VARCHAR2 := 'VIEW_ONLY'
            );

PROCEDURE txn_control
            ( p_mode IN VARCHAR2 := 'VIEW_ONLY'
            );

end XXHA_PROJ_CONV;
/


CREATE OR REPLACE PACKAGE BODY XXHA_PROJ_CONV IS

procedure error_log(    p_prog_name    in  VARCHAR2
                    ,   p_key_value    in  VARCHAR2 --
                    ,   p_error_code   in  VARCHAR2   --
                    ,   p_error_msg    in  VARCHAR2
                    ,   p_column_name  in  VARCHAR
                    ,   p_column_value in  VARCHAR2
                    ,   p_return_code  out number
                   ) is

begin

p_return_code := 1;

insert into HAEMO.XXHA_COMMON_ERRORS
( REQUEST_ID        ,
  RECORD_NUMBER     ,
  RECORD_IDENTIFIER ,
  ERROR_CODE        ,
  ERROR_MSG         ,
  COMMENTS          ,
  TABLE_NAME        ,
  ATTRIBUTE1        ,
  ATTRIBUTE2        ,
  ATTRIBUTE3        ,
  ATTRIBUTE4        ,
  ATTRIBUTE5        ,
  CREATED_BY        ,
  CREATION_DATE     ,
  LAST_UPDATED_BY   ,
  LAST_UPDATE_LOGIN ,
  LAST_UPDATE_DATE
) values (
  g_request_id       , -- REQUEST_ID
  NULL                , -- RECORD_NUMBER
  p_key_value         , -- RECORD_IDENTIFIER
  substr(p_ERROR_CODE, 1, 20),
  p_error_msg                ,
  NULL                , -- comments
  p_prog_name         , -- table name --
  p_column_name      , --ATTRIBUTE1  -- colmn name
  substr(p_column_value,1,150),  --ATTRIBUTE2-- column value
  NULL              ,  -- ATTRIBUTE3        ,
  NULL              ,   -- ATTRIBUTE4        ,
  NULL              ,   -- ATTRIBUTE5        ,
  g_user_id        , --CREATED_BY
  SYSDATE           , --CREATION_DATE
  -1                , --LAST_UPDATED_BY
  -1                , --LAST_UPDATE_LOGIN
  SYSDATE            --LAST_UPDATE_DATE
  );

if SQL%FOUND
then
  p_return_code := 1;

else
  p_return_code := -1;
end if;

exception
when others
then
  p_return_code := -1;
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: in error log proc, SQLERRM: ' || SQLERRM);
end error_log;

PROCEDURE project
            ( errbuf      IN  OUT VARCHAR2
            , retcode     IN  OUT NUMBER
            , p_prog_name IN  VARCHAR2
            , p_template_project IN VARCHAR2
            , p_mode      IN  VARCHAR2 := 'VIEW_ONLY'
            , p_proj_conv_id_start IN NUMBER
            , p_proj_conv_id_end   IN NUMBER
            ) is

   v_api_version_number Number  := 1.0;
   v_project_status     Varchar2(50)  := 'UNAPPROVED'; -- Need to create as approved
   v_template_project_name VARCHAR2(30) :=  p_template_project; -- 'SR  Project TEMPLATE'  ;      --- 'T, SR';  -- 'SR  Project TEMPLATE';

   v_user_id	        Number	:= 0;
   v_resp_id            Number	:= 0;

   v_kmg_error_location Varchar2(200) := 'Completed default person id assignment.';

   v_msg_count          number				:= 0;
   v_msg_data		    Varchar2(2000)		:= NULL;
   v_return_status      varchar2(1)         := 'T';
	 v_task_count		Number := 0;
	 v_workflow_status	Varchar2(1) := 'N';
	 v_op_validate_flag	Varchar2(1) := 'N';
	 task_cnt			Number := 0;
	 class_cnt		    Number := 0;
	 cust_cnt			Number := 0;

  -- Variables needed for API standard parameters
  l_api_version_number				NUMBER := 1.0;
  l_commit							VARCHAR2(1) := 'T';
  l_return_status					VARCHAR2(1);
  l_init_msg_list					VARCHAR2(1) := 'T';
  l_msg_count						NUMBER;
  l_msg_index_out					NUMBER;
  l_msg_data						VARCHAR2(2000);
  l_data							VARCHAR2(2000);
  l_workflow_started				VARCHAR2(1) := 'N';
  l_pm_product_code					VARCHAR2(10);
  --l_project_status					Varchar2(20) := 'UNAPPROVED'; -- ?
  l_user_id							NUMBER;
  l_responsibility_id				NUMBER;

-- Predefined Composit data types
  l_project_in					PA_PROJECT_PUB.PROJECT_IN_REC_TYPE;
  l_project_out					PA_PROJECT_PUB.PROJECT_OUT_REC_TYPE;
  l_key_members					PA_PROJECT_PUB.PROJECT_ROLE_TBL_TYPE;
  d_l_key_members					PA_PROJECT_PUB.PROJECT_ROLE_TBL_TYPE;
  l_class_categories		PA_PROJECT_PUB.CLASS_CATEGORY_TBL_TYPE;
  d_l_class_categories		PA_PROJECT_PUB.CLASS_CATEGORY_TBL_TYPE;
  l_customer_in					PA_PROJECT_PUB.CUSTOMER_TBL_TYPE;
  d_l_customer_in					PA_PROJECT_PUB.CUSTOMER_TBL_TYPE;
  l_customer_in_rec			PA_PROJECT_PUB.CUSTOMER_IN_REC_TYPE;
  l_tasks_in_rec				PA_PROJECT_PUB.TASK_IN_REC_TYPE;
  l_tasks_in						PA_PROJECT_PUB.TASK_IN_TBL_TYPE;
  d_l_tasks_in						PA_PROJECT_PUB.TASK_IN_TBL_TYPE;
  l_tasks_out_rec				PA_PROJECT_PUB.TASK_OUT_REC_TYPE;
  l_tasks_out						PA_PROJECT_PUB.TASK_OUT_TBL_TYPE;
  d_l_tasks_out						PA_PROJECT_PUB.TASK_OUT_TBL_TYPE;

  l_person_id			NUMBER;
  l_project_role_type   VARCHAR2(20);

  API_ERROR			EXCEPTION;

  --v_acquisition_date DATE := to_date('01/01/2009', 'mm/dd/yyyy');

  a				NUMBER;
  m				NUMBER;

  v_task_number_ctr NUMBER;
  v_bsa_header_id   OE_BLANKET_HEADERS_ALL.HEADER_ID%TYPE;

BEGIN -- Proc

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'p_prog_name: ' || p_prog_name);
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'p_template_project: ' || p_template_project);
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'p_mode: ' || p_mode );

  if p_prog_name = 'BUDGET'
  then
      budget(   p_mode
            ,   p_proj_conv_id_start
            ,   p_proj_conv_id_end
            );
      --
      RETURN;

  elsif p_prog_name = 'BASELINE_BUDGET'
  then
      baseline_budget(p_mode);
      --
      RETURN;

  elsif p_prog_name = 'UPDATE_PROJECT'
  then
      update_project(p_mode);
      --
      RETURN;

  elsif p_prog_name = 'TXN_CONTROL'
  then
      txn_control(p_mode);
      --
      RETURN;

  end if;


  if p_mode = 'COMMIT'
  then
    l_commit := 'T';
  elsif p_mode = 'VIEW_ONLY'
  then
    l_commit := 'F';
  end if;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Program Begins');

  ---
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_id: ' || g_user_id );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_name: ' || g_user_name );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_data_base: ' || g_data_base);

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_date_time: ' || g_date_time);


  g_rec_counter := 0;

  -----------
  --
  -----------
  Begin
     fnd_client_info.set_org_context(to_char(g_org_id));
  End;


  ---
  -- Derive Task Number
  ---
  begin

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Check if PM_PRODUCT_CODE is setup');

  select NVL(MAX(1), 0)
  into   g_number
  from   FND_LOOKUP_VALUES_VL
  where  LOOKUP_TYPE = 'PM_PRODUCT_CODE'
  and    UPPER(lookup_code) = 'CONVERSION'
  ;

  if g_number = 0
  then
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err :  INITIAL SETUPS');
    retcode := 2;
    RETURN;
  end if;


  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Check the setup of BSA Header for Conversion');

  select header_id
  into   v_bsa_header_id
  from   OE_BLANKET_HEADERS_ALL
  where  UPPER(sales_document_name) = 'CONVERSION'
  and    org_id = g_org_id
  and rownum < 2

  ;
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'v_bsa_header_id: ' || v_bsa_header_id);

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'begin: Derive Existing Task#');

  select  MAX(to_number(pt.TASK_NUMBER))
  into    g_number
  from    pa_tasks pt
  ,       pa_projects_all pp
  where   pt.project_id = pp.project_id
  and     pp.project_type = 'SR Project Type'
  and     pt.task_number not between 'A' and 'Z'
  ;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'MAX Task Number  g_number: ' || g_number);

  if g_number <= 10000
  then
    v_task_number_ctr := 10001;

  elsif  g_number is NULL
  then
    v_task_number_ctr := 10001;

  else
    v_task_number_ctr := g_number;

  end if;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Derived Initial Task Number v_task_number_ctr: ' || v_task_number_ctr );

  ---
  -- Check budget setup
  ---
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Check BUDGET TYPE CODE SETUP' );

  select count(*)
  into   g_number
  from   PA_BUDGET_TYPES
  where  budget_type_code IN ('SR Approved Revenue Budget', 'SR Approved Cost Budget')
  ;

  if g_number < 2
  then
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err :  INITIAL SETUPS');
    retcode := 2;
    RETURN;
  end if;

  exception
  when others
  then
    ROLLBACK;
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err :  INITIAL SETUPS');
    retcode := 2;
    RETURN;

  end;


 -- GET GLOBAL VALUES
 select user_id, responsibility_id
    into l_user_id, l_responsibility_id
    from pa_user_resp_v
    where user_name = g_project_user_name --- 'SVEMURI'
    and UPPER(responsibility_name) = UPPER(g_project_resp_name) -- need to get from Apps
   ;

 -- SET GLOBAL VALUES
  pa_interface_utils_pub.set_global_info(
	p_api_version_number	=> 1.0,
	p_responsibility_id	=> l_responsibility_id,
	p_user_id		=> l_user_id,
	p_msg_count		=> l_msg_count,
	p_msg_data		=> l_msg_data,
	p_return_status		=> l_return_status);

  if l_return_status != 'S'
  then
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: *Set Global Info* failed..');
       for i in 1..l_msg_count loop
         pa_interface_utils_pub.get_messages(
         		p_msg_data		=> l_msg_data,
         		p_msg_index		=> i,
         		p_encoded		=> 'F',
         		p_data 			=> l_data,
         		p_msg_count		=> l_msg_count,
         		p_msg_index_out		=>l_msg_index_out);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'L Data      : '||l_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'SQL Error   : '||SQLERRM);
       end loop;
    raise API_ERROR;
  end if;
 -- PRODUCT RELATED DATA

  l_pm_product_code := g_product_code;		-- CONVERSION -- can be user defined 10074

 --  l_project_status_code := 'UNAPPROVED';
 -- PRODUCT DATA (PROJECT_IN_REC_TYPE)

  Begin
     fnd_client_info.set_org_context(to_char(g_org_id));
  End;

  -------------
  --
  -------------
  FOR c_proj_rec IN (
  select
        PROJECT_CONV_ID
  ,     PROJECT_TYPE
  ,     PROBLEMID
  ,     STATUS_ID
  ,     STATUS
  ,     BUGTITLE
  ,     TYPE
  ,     'SR'                    PRODUCT_LINE
  ,     PROJECT_GROUP
  ,     decode(PROJECT_MANAGER, 'Angela Macsenti', 'Edward Simler', PROJECT_MANAGER) PROJECT_MANAGER
  ,     decode(PROJECT_MANAGER, 'Angela Macsenti', 'Y', 'N') PM_angela
  ,     OWNER
  ,     START_DATE
  ,     CUSTOMER
  ,     CONTACT_NAME
  ,     CONTACT_INFO
  ,     ESTIMATE
  ,     ESTIMATE_COST
  ,     TASK_TYPE
  ,     HOURS
  ,     PROJECT_NUMBER
  ,     CUSTOMER_NAME
  from  HAEMO.XXHA_PROJECTS_CONV
  where (project_number, project_conv_id)
                in  (select pc2.project_number, min(pc2.project_conv_id)
                     from   HAEMO.xxha_projects_conv pc2
                     group by pc2.project_number
                    )
  --and project_number IN ('Oklahoma Blood Institute - ESG')
  --and rownum < 20
  and   PROJECT_CONV_ID BETWEEN p_proj_conv_id_start and p_proj_conv_id_end
  and   NOT EXISTS (select 1
                    from   pa_projects_all pp
                    where  pp.NAME = project_number
                   )
  order by  project_number  asc
  ,         project_conv_id asc
  )
  LOOP -- Project Loop

    ------------------------
    g_error_exists := 'N';
    ------------------------
    l_key_members       :=   d_l_key_members;
    l_class_categories  :=   d_l_class_categories;
    l_customer_in       :=   d_l_customer_in;
    l_tasks_in          :=   d_l_tasks_in;
    l_tasks_out         :=   d_l_tasks_out;

    begin --- Project

    -- Record Count

    g_rec_counter := g_rec_counter + 1; -- Used also for header id


    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Record>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ' || g_rec_counter);

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Project Number: ' || c_proj_rec.project_number);

    ---
    -- Created from Project ID
    ---
    begin

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'v_template_project_name: ' || v_template_project_name);

      select  project_id, CARRYING_OUT_ORGANIZATION_ID
      into    l_project_in.created_from_project_id, l_project_in.carrying_out_organization_id
      from    pa_projects_all
      where   name = v_template_project_name
      ;

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'l_project_in.created_from_project_id: ' ||l_project_in.created_from_project_id);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'l_project_in.carrying_out_organization_id: ' ||l_project_in.carrying_out_organization_id);

    exception
    when others
    then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: TEMPLATE NOT FOUND     SQLERRM: ' || SQLERRM );
      RAISE g_no_handle;

    end;

    -- l_project_in.created_from_project_id   := 901; -- ? proj_data.created_from_project_id;  -- Project id from template 14070
    -- l_project_in.pa_project_number         := c_proj_rec.project_number;  -- Auto Number
    l_project_in.project_name              := c_proj_rec.project_number; --
    l_project_in.pm_project_reference      := c_proj_rec.PROJECT_CONV_ID || '-' ||  substr(c_proj_rec.project_number, 1, 20); --
    l_project_in.description               := c_proj_rec.customer || ' - ' || c_proj_rec.project_group; --
    l_project_in.project_status_code       := v_project_status;
    -- l_project_in.carrying_out_organization_id := 1804; --  proj_data.carrying_organization_id;    -- can default from template
    l_project_in.start_date                := to_date('01/01/2005', 'mm/dd/yyyy');  --proj_data.start_date;-- can override default from template
    --l_project_in.completion_date           := to_date('01/15/2011', 'mm/dd/yyyy'); --proj_data.completion_date; -- can override default from template
    ---
    ----l_project_in.customer_id   -- city of hope  -- hca.cust_account_id
    ---
    begin
    l_project_in.customer_id := NULL;
    g_char := NULL;

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Get Customer# From HAEMO.XXHA_CUSTOMERS_TEMP');
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'c_proj_rec.customer: ' || c_proj_rec.customer);

    select  CUSTOMER_NUMBER
    into    g_char
    from    HAEMO.XXHA_CUSTOMERS_TEMP
    where   LEGACY_CUSTOMER_NAME = c_proj_rec.customer
    and     trim(customer_number) is not null
    ;

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'customer_number g_char: ' || g_char);

    exception
    when others
    then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'war: could not derive customer# from HAEMO.XXHA_CUSTOMERS_TEMP');
      /*
      g_error_exists := 'Y';
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err:  could not derive customer# from HAEMO.XXHA_CUSTOMERS_TEMP');
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'SQLERRM: ' || SQLERRM );

      error_log ( p_prog_name    => 'PROJECT_CONV', p_key_value => c_proj_rec.PROJECT_CONV_ID, p_return_code => g_return_code
                , p_error_code   => 'GET_CUST_NUMBER' , p_error_msg => SQLERRM
                , p_column_name  =>  'PROJECT_NUMBER, CUSTOMER'
                , p_column_value =>  c_proj_rec.project_number || ', ' || c_proj_rec.customer
                );  if g_return_code = -1 then RAISE g_no_handle; end if;
      */
    end;

    ---
    --
    ---
    begin
    l_project_in.customer_id := NULL;

    if g_char is not null
    then

      select  hca.cust_account_id
      into    l_project_in.customer_id
      from    hz_cust_accounts_all hca
      where   hca.ACCOUNT_NUMBER = g_char
      -- and     hca.org_id   =  g_org_id  ?? there is no data in org_id
      ;

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_project_in.customer_id: ' || l_project_in.customer_id);

      --- 3/3/11  if bill and ship does not exists the put the null

      select NVL(MAX(1), 0)
      into   g_number
      from   dual
      where exists (            select 1
                                from  hz_cust_acct_sites_all cas
                                ,     hz_cust_site_uses_all  casu
                                where  cas.CUST_ACCOUNT_ID = l_project_in.customer_id
                                and    cas.status = 'A'
                                and    cas.CUST_ACCT_SITE_ID = casu.CUST_ACCT_SITE_ID
                                and    casu.site_use_code = 'BILL_TO'
                                and    casu.status = 'A'
                                and    casu.primary_flag = 'Y'
                    )
      and exists  (            select 1
                                from  hz_cust_acct_sites_all cas
                                ,     hz_cust_site_uses_all  casu
                                where  cas.CUST_ACCOUNT_ID = l_project_in.customer_id
                                and    cas.status = 'A'
                                and    cas.CUST_ACCT_SITE_ID = casu.CUST_ACCT_SITE_ID
                                and    casu.site_use_code = 'SHIP_TO'
                                and    casu.status = 'A'
                                and    casu.primary_flag = 'Y'
                    ) ;

      if g_number = 0
      then

        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'war:  Customer does not have bill to and  ship to');
        l_project_in.customer_id := NULL;

      end if;


      ---

    end if;

    exception
    when others
    then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Cust is NULL');
      --g_error_exists := 'Y';
      ---FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: could not derive cust_account_id from hz_cust_accounts_all table' );
      --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'SQLERRM: ' || SQLERRM );

      --error_log ( p_prog_name    => 'PROJECT_CONV', p_key_value => c_proj_rec.PROJECT_CONV_ID, p_return_code => g_return_code
      --          , p_error_code   => 'CUST_NUMBER_DERIVATION' , p_error_msg => SQLERRM
      --          , p_column_name  =>  'PROJECT_NUMBER, CUSTOMER_NUMBER'
       --         , p_column_value =>  c_proj_rec.project_number || ', ' || g_char
        --        );  if g_return_code = -1 then RAISE g_no_handle; end if;
    end;

    l_project_in.attribute_category        := 'N';
    l_project_in.attribute1                := to_char(v_bsa_header_id);
    l_project_in.attribute2                := NULL;
    l_project_in.attribute3                := NULL;
    l_project_in.attribute4                := NULL;
    l_project_in.attribute5                := NULL;
    l_project_in.attribute6                := NULL;
    l_project_in.attribute7                := NULL;
    l_project_in.attribute8                := NULL;
    l_project_in.attribute9                := NULL;
    l_project_in.attribute10               := NULL;
    l_project_in.long_name                 := c_proj_rec.customer || ' - ' || c_proj_rec.project_group; --
    l_project_in.actual_start_date         := '';
    l_project_in.actual_finish_date        := '';
    l_project_in.early_start_date          := '';
    l_project_in.early_finish_date         := '';
    l_project_in.late_start_date           := '';
    l_project_in.late_finish_date          := '';
    l_project_in.public_sector_flag        := 'N';
    l_project_in.project_currency_code     := 'USD'; ---?
    l_project_in.allow_cross_charge_flag   := 'N';
    l_project_in.invproc_currency_type     := 'PROJFUNC_CURRENCY';
    l_project_in.revproc_currency_code     := 'USD';
    l_project_in.project_bil_rate_date_code := 'PA_INVOICE_DATE';
    l_project_in.project_bil_rate_type      := 'Corporate';
    l_project_in.projfunc_currency_code     := 'USD';
    l_project_in.projfunc_bil_rate_date_code := 'PA_INVOICE_DATE';
    l_project_in.projfunc_bil_rate_type      := 'Corporate';
    l_project_in.funding_rate_date_code      := 'PA_INVOICE_DATE';
    l_project_in.funding_rate_type           := 'Corporate';
    l_project_in.projfunc_cost_rate_type     := 'Corporate';
    l_project_in.inv_by_bill_trans_curr_flag := 'N';
    l_project_in.multi_currency_billing_flag := 'Y';
    l_project_in.split_cost_from_workplan_flag := 'Y';
    l_project_in.split_cost_from_bill_flag     := 'N';
    l_project_in.assign_precedes_task          := 'N';
    l_project_in.retn_accounting_flag          := 'Y';
    l_project_in.start_adv_action_set_flag     := 'Y';
    l_project_in.revaluate_funding_flag        := 'N';
    l_project_in.include_gains_losses_flag     := 'N';
    l_project_in.asset_allocation_method       := 'N';
    l_project_in.capital_event_processing      := 'N';
    l_project_in.cint_eligible_flag            := 'Y';
    l_project_in.sys_program_flag              := 'N';
    l_project_in.enable_top_task_customer_flag := 'N';
    l_project_in.enable_top_task_inv_mth_flag  := 'N';
    l_project_in.projfunc_attr_for_ar_flag     := 'N';
    l_project_in.allow_multi_program_rollup    := 'N';
    l_project_in.process_mode                  := 'ONLINE';
    --  l_project_in.project_rate_type := 'Corporate';
    --  l_project_in.cc_process_labor_flag := 'N';
    --  l_project_in.cc_process_nl_flag := 'N';
    --  l_project_in.cost_job_group_id := 21;
    --  l_project_in.work_type_id            := 1003;
    --  l_project_in.calendar_id             := 2;
    --  l_project_in.location_id             := 1;
    --  l_project_in.competence_match_wt      := 100;
    --  l_project_in.availability_match_wt    := 100;
    --  l_project_in.job_level_match_wt        := 100;
    --  l_project_in.enable_automated_search   := 'N';
    --  l_project_in.search_min_availability   := 100;
    --  l_project_in.search_org_hier_id        := 64;
    --  l_project_in.search_starting_org_id    := 181;
    --  l_project_in.min_cand_score_reqd_for_nom := 100;
    l_project_in.baseline_funding_flag  := 'N'; -- need this otherwise *You cannot create an approved revenue
    --                                          -- budget version because The Baseline Funding Without Budget feature is enabled for this project.

    --  l_project_in.security_level                := 1;
    --  l_project_in.adv_action_set_id             := 1;


    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Validate Product Line or Class Code');
    class_cnt := 1;
    ---
    -- Project class category
    ---
    --for class_data in get_classCat(proj_Data.project_number) LOOP

    l_class_categories(class_cnt).class_category := 'Product Line';

    ---
    --
    ---
    begin
        select pcc.CLASS_CODE
        into   l_class_categories(class_cnt).class_code
        from   pa_class_codes pcc  -- pa_class_categories_lov_v  from manual
        where  pcc.class_category = 'Product Line'
        and    UPPER(pcc.class_code) = UPPER(c_proj_rec.product_line)
        and    TRUNC(SYSDATE) BETWEEN pcc.start_date_active AND NVL(pcc.end_date_active, TRUNC(SYSDATE))
        ;

        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_class_categories(class_cnt).class_code: '|| l_class_categories(class_cnt).class_code );

    exception
      when others
      then
        g_error_exists := 'Y';
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err :  Need to setup Dummy SR Product Line Class Code');
        retcode := 2;
        RETURN;
    end;


    /*
    --- Customer LOOP +++++++++++++++
    cust_cnt := 1;
    --- FOR c_cust_data in get_customer(proj_Data.project_number) LOOP
            --l_customer_in_rec.PROJECT_CONTACT_TYPE_CODE                := c_cust_data.PROJECT_CONTACT_TYPE_CODE;
            --l_customer_in_rec.CONTACT_ID                                            := c_cust_data.CONTACT_ID;
            l_customer_in_rec.customer_id                                            := c_cust_data.CUSTOMER_ID;
            l_customer_in_rec.bill_to_customer_id                            := c_cust_data.bill_to_customer_id;
            l_customer_in_rec.ship_to_customer_id                            := c_cust_data.ship_to_customer_id;
            l_customer_in_rec.bill_to_address_id                            := c_cust_data.bill_to_address_id;
            l_customer_in_rec.ship_to_address_id                            := c_cust_data.ship_to_address_id;
            --l_customer_in_rec.customer_bill_split                            := c_cust_data.customer_bill_split;
            ---l_customer_in_rec.inv_currency_code                                := c_cust_data.inv_currency_code;
            --l_customer_in_rec.project_relationship_code                := c_cust_data.project_relationship_code;
            --l_customer_in_rec.bill_another_project_flag                := c_cust_data.bill_another_project_flag;
            --l_customer_in_rec.inv_rate_type                                        := c_cust_data.inv_rate_type;
            ---l_customer_in_rec.allow_inv_user_rate_type_flag        := c_cust_data.allow_inv_user_rate_type_flag;
            ---l_customer_in_rec.enable_top_task_cust_flag				:= c_cust_data.enable_top_task_cust_flag;

    l_customer_in(cust_cnt) := l_customer_in_rec;
        */

    -- END LOOP;


    --TASKS DATA
    --Set the number of tasks for every level (there are 4 levels)

    -- This is just a set of looping structures to create the tasks and sub-tasks
    -- If it is difficult to understand, then feel free to create them individually.
    a := 0;

	task_cnt := 0;            --    PA_PROJECT_PUB.TASK_IN_REC_TYPE

    For c_task_rec IN (select   PROJECT_CONV_ID
                       ,        PROBLEMID
                       ,        STATUS
                       ,        BUGTITLE
                       ,        owner
                       ,        START_DATE
                       ,        CUSTOMER
                       ,        CONTACT_NAME
                       ,        project_number
                       from     HAEMO.XXHA_PROJECTS_CONV
                       where   (problemid, project_conv_id) in (select pc2.PROBLEMID, min(pc2.project_conv_id)
                                                                from   HAEMO.xxha_projects_conv pc2
                                                                group by pc2.PROBLEMID
                                                               )
                       and      project_number = c_proj_rec.project_number
                       and      NOT EXISTS (select 1
                                            from   pa_tasks pt
                                            ,      pa_projects_all pp
                                            where  pt.task_name = PROBLEMID
                                            and    pp.project_id = pt.project_id
                                            and    pp.name = c_proj_rec.project_number
                                           )
                      )
    Loop

      task_cnt := task_cnt + 1;
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Task cnt ....................: ' || task_cnt);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'PROBLEMID: ' || c_task_rec.PROBLEMID);


      v_task_number_ctr := v_task_number_ctr + 1;

      l_tasks_in_rec.pa_task_number             := to_char(v_task_number_ctr);
      l_tasks_in_rec.pm_task_reference 			:= c_task_rec.PROBLEMID;
      l_tasks_in_rec.task_name 				 	:= c_task_rec.PROBLEMID;  --  c_task.task_name;
      l_tasks_in_rec.long_task_name 		    := c_task_rec.BUGTITLE;--  -- Bug Title

      -- ? need to crate mapping table
      l_tasks_in_rec.work_type_id                 := 1004;  -- ?? maintenance   -> maps to status field, need to create mapping table

      /* Task manager not required   brad's email 2/18
      ---
      --
      ---
      begin
      l_tasks_in_rec.task_manager_person_id := NULL;
      g_char := NULL;
      g_date := NULL;
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'c_proj_rec.owner: ' || c_proj_rec.owner);

      select  person_id, full_name, effective_start_date
      into    l_tasks_in_rec.task_manager_person_id, g_char, g_date
      from    per_all_people_f
      where   UPPER(first_name || ' ' || middle_names || ' ' || last_name) like  replace(UPPER(c_task_rec.owner), ' ', '%') || '%'
      and     TRUNC(SYSDATE) between TRUNC(effective_start_date) and TRUNC(effective_end_date)
      ;

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Derived PersonID: ' || l_tasks_in_rec.task_manager_person_id);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Derived Full Name: ' || g_char);
      --l_tasks_in_rec.task_manager_person_id := 3714;  -- lisa  -- actually lisa eichler --

      update HAEMO.XXHA_PROJECTS_CONV
      set    task_manager_id = l_tasks_in_rec.task_manager_person_id
      where  project_number = c_proj_rec.project_number
      and    owner = c_task_rec.owner
      ;

      exception
      when others
      then
        --l_tasks_in_rec.task_manager_person_id := 3714;  -- lisa  -- actually lisa eichler -- need to be reomoved later
        g_error_exists := 'Y';
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: Cound not Deriv Task Mgr from Owner: ');
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'SQLERRM: ' || SQLERRM );

        error_log (  p_prog_name    => 'PROJECT_CONV', p_key_value => c_proj_rec.PROJECT_CONV_ID, p_return_code => g_return_code
                  ,  p_error_code   =>'OWNER/TASK_MGR', p_error_msg => SQLERRM
                  ,  p_column_name  =>  'PROJECT_NUMBER, TASK_NUMBER, OWNER'
                  ,  p_column_value =>  c_proj_rec.project_number || ', ' || c_task_rec.PROBLEMID || ', ' || c_task_rec.owner
                 );  if g_return_code = -1 then RAISE g_no_handle; end if;

      end; */

      l_tasks_in_rec.task_manager_person_id := NULL;
      l_tasks_in_rec.task_description	    := c_task_rec.PROBLEMID; -- NR
        -- l_tasks_in_rec.pm_parent_task_reference 	:= c_task.parent_task_number; -- NR

      if to_date(c_task_rec.START_DATE, 'mm/dd/yyyy') < to_date('01/01/2005', 'mm/dd/yyyy')
      then
        l_tasks_in_rec.task_start_date 	        := to_date('01/01/2005', 'mm/dd/yyyy');
      else
        l_tasks_in_rec.task_start_date 	        := to_date(c_task_rec.START_DATE, 'mm/dd/yyyy');-- GREATEST(g_date, v_acquisition_date);

      end if;

      l_tasks_in_rec.task_completion_date 		:= to_date('12/31/2020', 'mm/dd/yyyy');  -- NR
      l_tasks_in_rec.actual_start_date 			:= '';
      l_tasks_in_rec.actual_finish_date 	    := '';
      l_tasks_in_rec.early_start_date 			:= '';
      l_tasks_in_rec.early_finish_date 			:= '';
      l_tasks_in_rec.late_start_date 			:= '';
      l_tasks_in_rec.late_finish_date 			:= '';
      l_tasks_in_rec.billable_flag              := 'Y';
      l_tasks_in_rec.chargeable_flag            := 'Y';
      l_tasks_in_rec.limit_to_txn_controls_flag := 'N';
      l_tasks_in_rec.cc_process_labor_flag		:= 'N';
      l_tasks_in_rec.receive_project_invoice_flag := 'N';
      --    l_tasks_in_rec.allow_cross_charge_flag      := c_task.allow_cross_charge_flag;
      l_tasks_in_rec.attribute1 :=   l_class_categories(class_cnt).class_code;
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_tasks_in_rec.attribute1: ' || l_tasks_in_rec.attribute1);
      ---
      --  Service Type Code
      ---
      begin

        select count(*)
        into   g_number
        from   FND_LOOKUP_VALUES_VL
        where  lookup_type = 'SERVICE TYPE'
        and   lookup_code  IN ('TECHNICAL SERVICES', 'EDUCATION & TRAINING', 'IMPLEMENTATIONS & CONSULTING')
        ;

        if g_number < 3
        then
          ROLLBACK;
          FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: SERVICE TYPE: TECHNICAL SERVICES, EDUCATION & TRAINING is not setup');
          retcode := 2;
          RETURN;
        end if;

        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Project Group: ' || c_proj_rec.project_group);

        if c_proj_rec.project_group = 'TSG'
        then
          l_tasks_in_rec.service_type_code := 'TECHNICAL SERVICES';

        elsif c_proj_rec.project_group = 'ESG'
        then
          l_tasks_in_rec.service_type_code := 'EDUCATION & TRAINING';

        elsif c_proj_rec.project_group = 'PSG'
        then
          l_tasks_in_rec.service_type_code := 'IMPLEMENTATIONS & CONSULTING';
        end if;

        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_tasks_in_rec.service_type_code: ' || l_tasks_in_rec.service_type_code);

      exception
      when others
      then
        ROLLBACK;
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: SERVICE TYPE: TECHNICAL SERVICES, EDUCATION & TRAINING is not setup');
        retcode := 2;
        RETURN;

      end;


      --    l_tasks_in_rec.cost_ind_rate_sch_id         := 6;
      --    l_tasks_in_rec.project_rate_type            := 'Corporate';
      --    l_tasks_in_rec.cc_process_labor_flag			  := 'N';
      --    l_tasks_in_rec.taskfunc_cost_rate_type			:= 'Corporate';
      --    l_tasks_in_rec.retirement_cost_flag         := 'N';
      --	l_tasks_in_rec.cint_eligible_flag           := 'Y';
      --	l_tasks_in_rec.gen_etc_source_code          := 'FINANCIAL_PLAN';

      l_tasks_in(task_cnt) := l_tasks_in_rec;

	end loop; -- for Tasks

    if task_cnt = 0 then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err:   No Tasks, Go to API ERROR');
      raise API_ERROR;
     --raise e_skip;
    END IF;

     ----------------------------
     -- Initiate Environment
     ----------------------------
     --g_project_user_name          := 'SVEMURI';
     -- v_api_version_number := 1.0;
     -- v_project_status     := 'UNAPPROVED';

     v_kmg_error_location := 'Setting up user environment';
     -- Retrieve the user_id and resp_id for AMGUSER
     Select MAX(USER_ID), MAX(RESPONSIBILITY_ID)
         into  v_user_id, v_resp_id
          from  apps.PA_USER_RESP_V
          where USER_NAME = g_project_user_name
          and responsibility_name = g_project_resp_name -- 'Project Billing Super User' -- ??
     ;

     v_kmg_error_location := 'Completed default person id assignment.';
     FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Calling api for user_id = '||v_user_id||' Resp_id = '||v_resp_id);

     apps.pa_interface_utils_pub.Set_Global_Info
         (p_api_version_number  => v_api_version_number,
          p_responsibility_id   => v_resp_id,
          p_user_id	            => v_user_id,
          p_msg_count           => v_msg_count,
          p_msg_data            => v_msg_data,
          p_return_status       => v_return_status);

     -- Error Handling for any AMG Procedure Call
     IF v_return_status != 'S' THEN
 	    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Set Global Info FAILED...');
 	    RAISE API_ERROR;
     ELSE
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Set Global Info Completed Successfully');
     END IF;
     -------------------------------------

    --INIT_CREATE_PROJECT
    pa_project_pub.init_project;

    ---*********************
    --l_person_id := 34;  -- value from template
    --l_project_role_type := 'PROJECT MANAGER';


    begin
    l_key_members(1).person_id := NULL; --:= 16126;
    g_date := NULL;
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'c_proj_rec.project_manager: ' || c_proj_rec.project_manager);

    select  person_id, full_name, effective_start_date
    into    l_key_members(1).person_id, g_char, g_date
    from    per_all_people_f
    where   UPPER(first_name || ' ' || last_name) like  replace(UPPER(c_proj_rec.project_manager), ' ', '%') || '%'
    and     TRUNC(SYSDATE) between TRUNC(effective_start_date) and TRUNC(effective_end_date)
    ;

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_key_members(1).person_id: ' || l_key_members(1).person_id);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Derived Full Name: ' || g_char);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Derived PM Stard Date : ' || g_date);
      --l_tasks_in_rec.task_manager_person_id := 3714;  -- lisa  -- actually lisa eichler --


    exception
      when others
      then
        --l_tasks_in_rec.task_manager_person_id := 3714;  -- lisa  -- actually lisa eichler -- need to be reomoved later
        g_error_exists := 'Y';
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: Could not Derive PM: ');
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'SQLERRM: ' || SQLERRM );

        error_log (  p_prog_name    => 'PROJECT_CONV', p_key_value => c_proj_rec.PROJECT_CONV_ID, p_return_code => g_return_code
                  ,  p_error_code   =>'PROJ_MGR', p_error_msg => SQLERRM
                  ,  p_column_name  =>  'PROJECT_NUMBER, PROJECT_MGR'
                  ,  p_column_value =>  c_proj_rec.project_number || ', ' || c_proj_rec.project_manager
                 );  if g_return_code = -1 then RAISE g_no_handle; end if;

    end;

   -- already fetched above  --  l_key_members(1).person_id 					:= 16126;
    l_key_members(1).project_role_type 	:= 'PROJECT MANAGER'; -- 'Project Manager'; --initcap('PROJECT MANAGER');
    l_key_members(1).start_date	        := to_date('01/01/2005', 'mm/dd/yyyy');

    g_number := 1;
    -- Angela
    if c_proj_rec.PM_Angela = 'Y'
    then

      l_key_members(1).end_date	        := to_date('07/31/2008', 'mm/dd/yyyy');

      g_number := g_number + 1;

      l_key_members(g_number).person_id             := 16163; -- Angela Macsenti
      l_key_members(g_number).project_role_type 	:= 'PROJECT MANAGER'; -- 'Project Manager'; --initcap('PROJECT MANAGER');
      l_key_members(g_number).start_date	        := to_date('08/01/2008', 'mm/dd/yyyy');

    end if; --

    -- Sales Admin
    g_number := g_number + 1;

    l_key_members(g_number).person_id 		    := 16073;
    l_key_members(g_number).project_role_type 	:= '1001';	-- Sales Admin 	-- Lisa Callahan
    l_key_members(g_number).start_date	     	:= to_date('01/01/2005', 'mm/dd/yyyy');

    --Project Accountant  Patricia Eaton
    g_number := g_number + 1;
    l_key_members(g_number).person_id 		    := 16146;
    l_key_members(g_number).project_role_type 	:= '1000'; -- Project Accountant
    l_key_members(g_number).start_date	     	:= to_date('01/01/2005', 'mm/dd/yyyy');
    l_key_members(g_number).end_date	     	:= to_date('05/31/2009', 'mm/dd/yyyy');

    g_number := g_number + 1; -- Genevieve Parado
    l_key_members(g_number).person_id 		    := 16104;
    l_key_members(g_number).project_role_type 	:= '1000'; -- Project Accountant
    l_key_members(g_number).start_date	     	:= to_date('06/01/2009', 'mm/dd/yyyy');

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'***g_error_exists***: ' || g_error_exists );

    if p_mode = 'VIEW_ONLY'
    then
      raise g_skip;
    end if;

    if g_error_exists = 'Y'
    then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: error exist skip creating project using API' );
      raise g_skip;
    else
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'BEFORE_CREATE_PROJECT' );
      --raise g_skip;
    end if;


    --CREATE_PROJECT
    pa_project_pub.create_project(
	  p_api_version_number	=> l_api_version_number,
	  p_init_msg_list 			=> l_init_msg_list,
	  p_msg_count 					=> l_msg_count,
	  p_msg_data 						=> l_msg_data,
	  p_return_status 			=> l_return_status,
	  p_workflow_started 		=> l_workflow_started,
	  p_pm_product_code 		=> l_pm_product_code,
	  p_project_in 					=> l_project_in,
	  p_project_out 				=> l_project_out,
	  p_key_members 				=> l_key_members,
	  p_class_categories 		=> l_class_categories,
      --	p_customer_in					=> l_customer,
	  p_tasks_in 						=> l_tasks_in,
	  p_commit 							=> l_commit,
	  p_tasks_out 					=> l_tasks_out
    );

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'After calling pa_project_pub.create_project api l_return_status: '||l_return_status);
    -- Check for errors
    if l_return_status != 'S'
    then
       for i in 1..l_msg_count loop
         pa_interface_utils_pub.get_messages(
         		p_msg_data		=> l_msg_data,
         		p_msg_index		=> i,
         		p_encoded		=> 'F',
         		p_data 			=> l_data,
         		p_msg_count		=> l_msg_count,
         		p_msg_index_out		=>l_msg_index_out);
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' L Data       = '||substr(l_data,1,25));
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' L Data       = '||substr(l_data,26,55));
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' L Data       = '||substr(l_data,56,75));
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' L Data       = '||substr(l_data,76,105));
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' SQL Error = '||'.'||l_msg_count||'.'||SQLERRM);
         error_log (  p_prog_name    => 'PROJECT_CONV', p_key_value => c_proj_rec.PROJECT_CONV_ID, p_return_code => g_return_code
                  ,  p_error_code   =>'CREATE_PROJECT_API_FAILED', p_error_msg => SQLERRM
                  ,  p_column_name  =>  'PROJECT_NUMBER, MESSAGE'
                  ,  p_column_value =>  c_proj_rec.project_number || ', ' || l_data
                 );  if g_return_code = -1 then RAISE g_no_handle; end if;
       end loop;

      raise API_ERROR;

    Else
     FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'pa_project_pub.create_project ...   Loaded Successfully...');

     FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'New Project Id: ' || l_project_out.pa_project_id);
     FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'New Project Number: ' || l_project_out.pa_project_number);

     ----
     -- Update XXHA_COMMON_ERRORS table
     ----
     UPDATE HAEMO.XXHA_Projects_Conv
     set    project_id = l_project_out.pa_project_id
     where  project_number = c_proj_rec.project_number
     ;

     --
     --
     --
     --g_number := NULL;
     --g_number := l_tasks_in.first;
     --While g_number IS NOT NULL LOOP
     For i in l_tasks_out.first..l_tasks_out.last
     Loop
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'i: ' || i );
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Task Return Status: ' || l_tasks_out(i).return_status );
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Task ID ..........: ' || l_tasks_out(i).pa_task_id );

       UPDATE HAEMO.XXHA_Projects_Conv
       set    task_id = l_tasks_out(i).pa_task_id
       where  project_id = l_project_out.pa_project_id
       and    problemid  = (select task_name from pa_tasks where task_id = l_tasks_out(i).pa_task_id)
       ;

       -- g_number := l_tasks_in.next(g_number);
     End Loop;



     pa_project_pub.clear_project;
     FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'After clear project...');
     commit;

    end if;


      pa_project_pub.init_project;


    EXCEPTION

    when API_ERROR then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: in API ERROR');

    when g_skip then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'skip: ');

    end; -- end project

pa_project_pub.clear_project;
FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'After clear project...');
commit;

pa_project_pub.init_project;

END LOOP;  -- Project Loop


-- ++++++++++++++++++++++++++++
if p_mode = 'VIEW_ONLY'
then

  ROLLBACK;

elsif p_mode = 'COMMIT'
then

  COMMIT;

end if;

-- ++++++++++++++++++++++++++++

EXCEPTION

WHEN OTHERS
THEN
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: OTHERS error message: ' || SQLERRM);
  ROLLBACK;

  retcode := 2;

END PROJECT;

--++++++++++++++++++
PROCEDURE BUDGET
            --( errbuf  IN  VARCHAR2
            --, retcode IN  NUMBER
           (    p_mode                 IN  VARCHAR2 := 'VIEW_ONLY'
           ,    p_proj_conv_id_start   IN NUMBER
           ,    p_proj_conv_id_end     IN NUMBER
           ) is

   v_api_version_number Number  := 1.0;

-- variables needed for API standard parameters
l_api_version_number NUMBER := 1.0;
l_commit             VARCHAR2(1):= 'T';  -- Need to be changed to T for COMMIT
l_return_status      VARCHAR2(1);
l_init_msg_list     VARCHAR2(1) := 'T';
l_msg_count         NUMBER;
l_msg_data          VARCHAR2(2000);
l_data              VARCHAR2(2000);
l_msg_entity        VARCHAR2(100);
l_msg_entity_index  NUMBER;
l_msg_index         NUMBER;
l_msg_index_out     NUMBER;
l_encoded           VARCHAR2(1);
l_user_id			NUMBER;
l_responsibility_id	NUMBER;
i NUMBER;
a NUMBER;
-- variables needed for Oracle Projects�specific parameters
l_pm_product_code       VARCHAR2(10) := 'CONVERSION';
l_pa_project_id         NUMBER;
l_pm_project_reference  VARCHAR2(25);
l_budget_type_code      VARCHAR2(30);
l_version_name          VARCHAR2(30);
l_change_reason_code    VARCHAR2(30);
l_description           VARCHAR2(255);
l_entry_method_code     VARCHAR2(30);
l_resource_list_name    VARCHAR2(60);
l_resource_list_id      NUMBER;

l_budget_lines_in       pa_budget_pub.budget_line_in_tbl_type;
d_l_budget_lines_in       pa_budget_pub.budget_line_in_tbl_type;
l_budget_lines_in_rec   pa_budget_pub.budget_line_in_rec_type;
l_cost_budget_lines_in       pa_budget_pub.budget_line_in_tbl_type;
d_l_cost_budget_lines_in       pa_budget_pub.budget_line_in_tbl_type;
l_cost_budget_lines_in_rec   pa_budget_pub.budget_line_in_rec_type;
l_budget_lines_out      pa_budget_pub.budget_line_out_tbl_type;
d_l_budget_lines_out      pa_budget_pub.budget_line_out_tbl_type;
l_line_index            NUMBER;
l_line_return_status    VARCHAR2(1);
API_ERROR               EXCEPTION;
-- Oracle Projects APIs, Client Extensions, and Open Interfaces Reference
BEGIN

  if p_mode = 'COMMIT'
  then
    l_commit := 'T';
  elsif p_mode = 'VIEW_ONLY'
  then
    l_commit := 'F';
  end if;

  l_budget_lines_in.delete;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'p_mode: ' || p_mode );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_id: ' || g_user_id );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_name: ' || g_user_name );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_org_id: ' || g_org_id );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_data_base: ' || g_data_base);

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_date_time: ' || g_date_time);


  g_rec_counter := 0;
  --------------
  Begin
     fnd_client_info.set_org_context(to_char(g_org_id));
  End;

  -- GET GLOBAL VALUES
  select user_id, responsibility_id
    into l_user_id, l_responsibility_id
    from pa_user_resp_v
  where user_name = g_project_user_name
  and UPPER(responsibility_name) = UPPER(g_project_resp_name) -- need to get from Apps 		-- need to get from Apps
  ;

  -- SET GLOBAL VALUES
  pa_interface_utils_pub.set_global_info(
	p_api_version_number	=> 1.0,
	p_responsibility_id	=> l_responsibility_id,
	p_user_id		=> l_user_id,
	p_msg_count		=> l_msg_count,
	p_msg_data		=> l_msg_data,
	p_return_status		=> l_return_status);

  if l_return_status != 'S'
  then
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: *Set Global Info* failed..');
       for i in 1..l_msg_count loop
         pa_interface_utils_pub.get_messages(
         		p_msg_data		=> l_msg_data,
         		p_msg_index		=> i,
         		p_encoded		=> 'F',
         		p_data 			=> l_data,
         		p_msg_count		=> l_msg_count,
         		p_msg_index_out		=>l_msg_index_out);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'L Data      : '||l_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'SQL Error   : '||SQLERRM);
       end loop;
    raise API_ERROR;
  end if;

  --------------
  -- Nandu --  Estimate cost > Rev Budget

  -- PRODUCT RELATED DATA
  l_pm_product_code := g_product_code;

  -- BUDGET DATA

  g_rec_counter := 0;

  FOR c_bud_rec IN (select  distinct pc.project_id
                    from   HAEMO.XXHA_PROJECTS_CONV pc
                    where  pc.project_id is not null
                    and    pc.PROJECT_CONV_ID BETWEEN p_proj_conv_id_start and p_proj_conv_id_end
                    and    exists (select 1
                                   from   pa_projects_all pp
                                   where  pp.project_id = pc.project_id
                                  )
                    and (   NOT EXISTS (select 1
                                       from   PA_BUDGET_VERSIONS_DRAFT_V db
                                       where  db.project_id = pc.project_id
                                       and    db.budget_type_code = 'SR Approved Revenue Budget'
                                      )
                         or NOT EXISTS (select 1
                                       from   PA_BUDGET_VERSIONS_DRAFT_V db
                                       where  db.project_id = pc.project_id
                                       and    db.budget_type_code = 'SR Approved Cost Budget'
                                      )
                        )
                    and pc.estimate_cost is NOT NULL
                    and pc.ESTIMATE is NOT NULL
                    -- and rownum < 2 -->>>>>>>
                    --and pc.project_id = 350  -- >>>>>>>>>>>
                    order by pc.project_id asc
                   )
  LOOP  -- Budget Loop

  ------------------------
  g_error_exists := 'N';
  ------------------------
  l_budget_lines_in := d_l_budget_lines_in;
  l_cost_budget_lines_in := d_l_cost_budget_lines_in;
  l_budget_lines_out     := d_l_budget_lines_out;


  g_rec_counter := g_rec_counter + 1;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Record>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ' || g_rec_counter);
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Project Id: ' || c_bud_rec.project_id);

  begin -- Budet

    l_pa_project_id   := c_bud_rec.project_id;
    l_pm_project_reference := c_bud_rec.project_id;  --'shek-budget23'; -- project name
    l_change_reason_code := NULL; --  'ESTIMATING ERROR';
    l_description := 'Description 1.0';
    l_version_name := 'Version 1.0';
    l_entry_method_code :=  'HSS Top Task Level';  -- 'Task Level Baseline';-- '
    l_resource_list_id := 1000; -- none
    -- BUDGET LINES DATA

    -- a := 1;
    i := 0;

    FOR c_task_rec IN (select pc.task_id
                       , (select pt.START_DATE from pa_tasks pt where pt.task_id = pc.task_id) start_date
                       , (select pt.COMPLETION_DATE from pa_tasks pt where pt.task_id = pc.task_id) COMPLETION_date
                       ,      pc.PROBLEMID
                       ,      pc.ESTIMATE      cost_budget_hrs
                       ,      pc.ESTIMATE_COST revenue_budget_amt
                       from   HAEMO.XXHA_PROJECTS_CONV pc
                       where   (pc.problemid, pc.project_conv_id) in (select pc2.PROBLEMID, min(pc2.project_conv_id)
                                                                      from   HAEMO.xxha_projects_conv pc2
                                                                      where  pc2.project_id = c_bud_rec.project_id
                                                                      group by pc2.PROBLEMID
                                                                     )
                       and    pc.ESTIMATE is NOT NULL
                       and    pc.estimate_cost is NOT NULL
                       order by pc.task_id asc
                       )
    Loop
      i := i+1;

      --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'DBMS_SQL.LAST_ROW_COUNT: ' || DBMS_SQL.LAST_ROW_COUNT );

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'.......................Task Id: ' || c_task_rec.task_id);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Task Name: ' || c_task_rec.PROBLEMID);
      --if i = 1
      --THEN
      l_budget_lines_in_rec.pa_task_id := c_task_rec.task_id;   --82002;
      --l_budget_lines_in_rec.resource_list_member_id := 2003;   -- check this one-- Contract Labor

      --end if;
      ---------------------------

      --l_budget_lines_in_rec.pm_task_reference     := --       VARCHAR2(30)
      --l_budget_lines_in_rec.resource_alias               VARCHAR2(80)
      --l_budget_lines_in_rec.resource_list_member_id      NUMBER
      l_budget_lines_in_rec.budget_start_date   := c_task_rec.start_date; --to_date('01/01/2005', 'mm/dd/yyyy');
      l_budget_lines_in_rec.budget_end_date     := c_task_rec.COMPLETION_date;
      -- l_budget_lines_in_rec.period_name   := 'Dec-11';
      -- l_budget_lines_in_rec.description                  VARCHAR2(255)
      --l_budget_lines_in_rec.raw_cost := NULL;  ---
      --l_budget_lines_in_rec.burdened_cost                NUMBER
      l_budget_lines_in_rec.revenue  := c_task_rec.revenue_budget_amt;
      l_budget_lines_in_rec.quantity := c_task_rec.cost_budget_hrs;
      ---l_budget_lines_in_rec.pm_product_code              VARCHAR2(30)
      ---l_budget_lines_in_rec.pm_budget_line_reference

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_budget_lines_in_rec.revenue: ' || l_budget_lines_in_rec.revenue);

      ---------------------------
      l_cost_budget_lines_in_rec.pa_task_id := c_task_rec.task_id;
      --l_cost_budget_lines_in_rec.period_name   := 'Dec-11';
      l_cost_budget_lines_in_rec.budget_start_date   := c_task_rec.start_date;
      l_cost_budget_lines_in_rec.budget_end_date     := to_date('12/31/2020', 'mm/dd/yyyy');
      l_cost_budget_lines_in_rec.quantity := c_task_rec.cost_budget_hrs;
      --l_cost_budget_lines_in_rec.raw_cost := c_task_rec.cost_budget_hrs * 85;

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_cost_budget_lines_in_rec.quantity: ' || l_cost_budget_lines_in_rec.quantity);

      l_budget_lines_in(i) := l_budget_lines_in_rec;
      l_cost_budget_lines_in(i) := l_cost_budget_lines_in_rec;

    end loop; -- task

    ---
    -- REVENUE  BUDGET     --  INIT_BUDGET
    ---
    begin

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Process  REVENUE BUDGET');

      l_budget_type_code := 'SR Approved Revenue Budget';   ---   'AR'; -- Approve Cost Budget -- �AR�;
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_budget_type_code: ' || l_budget_type_code);

      select NVL(MAX(1), 0)
      into   g_number
      from   PA_BUDGET_VERSIONS_DRAFT_V db
      where  db.project_id = c_bud_rec.project_id
      and    db.budget_type_code = l_budget_type_code
      ;

      if g_number = 1
      then
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'skip: SR Approved Revenue Budget already exists for this project');
        raise g_l_skip;
      end if;


      if g_error_exists = 'Y'
      then
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: error exist skip creating budget using API' );
        raise g_skip;
      else
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'BEFORE_CREATE_REVENUE_BUDGET' );
        --raise g_skip;
      end if;

      pa_budget_pub.init_budget;

      pa_budget_pub.create_draft_budget
      (  p_api_version_number   => l_api_version_number
        ,p_msg_count            => l_msg_count
        ,p_msg_data             => l_msg_data
        ,p_return_status        => l_return_status
        ,p_pm_product_code      => l_pm_product_code
        ,p_pa_project_id        => l_pa_project_id
        ,p_pm_project_reference => l_pm_project_reference
        ,p_budget_type_code     => l_budget_type_code
        ,p_change_reason_code   => l_change_reason_code
        ,p_budget_version_name  => l_version_name
        ,p_description          => l_description
        ,p_entry_method_code    => l_entry_method_code
        ,p_resource_list_name   => l_resource_list_name
        ,p_resource_list_id     => l_resource_list_id
        ,p_budget_lines_in      => l_budget_lines_in
        ,p_budget_lines_out     => l_budget_lines_out
      );

      IF l_return_status != 'S'
      THEN
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: *Create Draft Budget* API failed..');

         for i in 1..l_msg_count loop
           pa_interface_utils_pub.get_messages(
                 p_msg_data        => l_msg_data,
                 p_msg_index        => i,
                 p_encoded        => 'F',
                 p_data             => l_data,
                 p_msg_count        => l_msg_count,
                 p_msg_index_out        =>l_msg_index_out);

           FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);

         end loop;

        else

          FND_FILE.PUT_LINE( FND_FILE.OUTPUT, '$Create Draft Budget$ Created Successfully...........');

      END IF;

      -- CLEAR_BUDGET
      pa_budget_pub.clear_budget;

      IF l_return_status != 'S'
      THEN
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: *Clear Budget* API failed..');
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: Raising API_ERROR');
        RAISE API_ERROR;

      END IF;

    exception
    when g_l_skip
    then

      NULL;

    end;--- Revenue budget end

    -------------------------------------
    -- COST  BUDGET     --  INIT_BUDGET
    -------------------------------------
    begin

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Process  COST BUDGET');

      l_budget_type_code := 'SR Approved Cost Budget';   ---   'AR'; -- Approve Cost Budget -- �AR�;
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'l_budget_type_code: ' || l_budget_type_code);

      select NVL(MAX(1), 0)
      into   g_number
      from   PA_BUDGET_VERSIONS_DRAFT_V db
      where  db.project_id = c_bud_rec.project_id
      and    db.budget_type_code = l_budget_type_code
      ;

      if g_number = 1
      then
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'skip: SR Approved Cost Budget already exists for this project');
        raise g_l_skip;
      end if;

      if g_error_exists = 'Y'
      then
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: error exist skip creating Cost budget using API' );
        raise g_skip;
      else
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'BEFORE_CREATE_COST_BUDGET' );
         --raise g_skip;
      end if;

      pa_budget_pub.init_budget;

      pa_budget_pub.create_draft_budget
      (  p_api_version_number   => l_api_version_number
        ,p_msg_count            => l_msg_count
        ,p_msg_data             => l_msg_data
        ,p_return_status        => l_return_status
        ,p_pm_product_code      => l_pm_product_code
        ,p_pa_project_id        => l_pa_project_id
        ,p_pm_project_reference => l_pm_project_reference
        ,p_budget_type_code     => l_budget_type_code
        ,p_change_reason_code   => l_change_reason_code
        ,p_budget_version_name  => l_version_name
        ,p_description          => l_description
        ,p_entry_method_code    => l_entry_method_code
        ,p_resource_list_name   => l_resource_list_name
        ,p_resource_list_id     => l_resource_list_id
        ,p_budget_lines_in      => l_cost_budget_lines_in -- l_budget_lines_in
        ,p_budget_lines_out     => l_budget_lines_out
      );

      IF l_return_status != 'S'
      THEN
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: *Create Draft Budget* API failed..');

         for i in 1..l_msg_count loop
           pa_interface_utils_pub.get_messages(
                 p_msg_data        => l_msg_data,
                 p_msg_index        => i,
                 p_encoded        => 'F',
                 p_data             => l_data,
                 p_msg_count        => l_msg_count,
                 p_msg_index_out        =>l_msg_index_out);

           FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);

         end loop;

        else

          FND_FILE.PUT_LINE( FND_FILE.OUTPUT, '$Create Draft Budget$ Created Successfully...........');

      END IF;

      -- CLEAR_BUDGET
      pa_budget_pub.clear_budget;

      IF l_return_status != 'S'
      THEN
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: *Clear Budget* API failed..');
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: Raising API_ERROR');
        RAISE API_ERROR;

      END IF;

    exception
    when g_l_skip
    then
      NULL;

    end;--- Cost budget end


  EXCEPTION
  WHEN API_ERROR
  THEN
    for i in 1..l_msg_count
    loop
    pa_interface_utils_pub.get_messages (
        p_msg_data => l_msg_data
    ,   p_data => l_data
    ,   p_msg_count => l_msg_count
    ,   p_msg_index_out => l_msg_index_out
    );

         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' SQL Error = '||'.'||l_msg_count||'.'||SQLERRM);


    end loop;

  when g_skip
  then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'skip: ');

  end;  -- Budget

  END LOOP; -- Budget Loop

--
-- ++++++++++++++++++++++++++++
if p_mode = 'VIEW_ONLY'
then
  ROLLBACK;

elsif p_mode = 'COMMIT'
then
  COMMIT;

end if;

-- ++++++++++++++++++++++++++++

EXCEPTION

WHEN OTHERS
THEN

  for i in 1..l_msg_count
  loop

  pa_interface_utils_pub.get_messages
    (   p_msg_data => l_msg_data
    ,   p_data => l_data
    ,   p_msg_count => l_msg_count
    ,   p_msg_index_out => l_msg_index_out
    );
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' SQL Error = '||'.'||l_msg_count||'.'||SQLERRM);


    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: OTHERS '||SQLERRM);

  end loop;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: OTHERS error message: ' || SQLERRM);
  ROLLBACK;

  RAISE g_no_handle;

END BUDGET;

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PROCEDURE baseline_budget
            ( p_mode IN VARCHAR2 := 'VIEW_ONLY'
            )
          is
-- Name: basleline_budget.sql
--
-- Description:
--
--
-- Setup:
-- There are a few setup steps that need to be made before running this script.
-- 1. There must be an active Project with a draft budget approved to baseline
--    the budget for.

   v_api_version_number Number  := 1.0;

-- variables needed for API standard parameters
   l_api_version_number         NUMBER          := 1.0;
   l_commit                     VARCHAR2(1)     := 'T';
   l_return_status              VARCHAR2(1);
   l_init_msg_list              VARCHAR2(1)     := 'T';
   l_msg_count                  NUMBER;
   l_msg_data                   VARCHAR2(2000);
   l_data                       VARCHAR2(2000);
   l_msg_index                  NUMBER;
   l_msg_index_out              NUMBER;
   l_encoded                    VARCHAR2(1);

-- variables needed for Oracle Project specific parameters
  l_pm_product_code             VARCHAR2(10);
  l_pa_project_id               NUMBER;
  l_pm_project_reference        VARCHAR2(25);
  l_workflow_started		VARCHAR2(1);
  l_budget_type_code            VARCHAR2(30);
  l_user_id                     NUMBER;
  l_responsibility_id           NUMBER;

  API_ERROR                     EXCEPTION;

BEGIN

  if p_mode = 'COMMIT'
  then
    l_commit := 'T';
  elsif p_mode = 'VIEW_ONLY'
  then
    l_commit := 'F';
  end if;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Program Begins');

  ---
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'p_mode: ' || p_mode );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_id: ' || g_user_id );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_name: ' || g_user_name );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_id: ' || g_org_id );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_data_base: ' || g_data_base);

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_date_time: ' || g_date_time);


  -----------
  --
  -----------
  Begin
     fnd_client_info.set_org_context(to_char(g_org_id));
  End;

  -- PRODUCT RELATED DATA
  l_pm_product_code     := g_product_code; --  'CONVERSION';


  -- GET GLOBAL VALUES
  select user_id, responsibility_id
    into l_user_id, l_responsibility_id
    from pa_user_resp_v
  where user_name = g_project_user_name
  and UPPER(responsibility_name) = UPPER(g_project_resp_name) -- need to get from Apps         -- need to get from Apps
  ;

  -- SET GLOBAL VALUES
  pa_interface_utils_pub.set_global_info(
    p_api_version_number    => 1.0,
    p_responsibility_id    => l_responsibility_id,
    p_user_id        => l_user_id,
    p_msg_count        => l_msg_count,
    p_msg_data        => l_msg_data,
    p_return_status        => l_return_status);

  if l_return_status != 'S'
  then
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: *Set Global Info* failed..');
       for i in 1..l_msg_count loop
         pa_interface_utils_pub.get_messages(
                 p_msg_data        => l_msg_data,
                 p_msg_index        => i,
                 p_encoded        => 'F',
                 p_data             => l_data,
                 p_msg_count        => l_msg_count,
                 p_msg_index_out        =>l_msg_index_out);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'L Data      : '||l_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'SQL Error   : '||SQLERRM);
       end loop;

    RAISE g_no_handle;
    raise API_ERROR;

  else

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, '*Set Global Info* Successful......');

  end if;

  g_rec_counter := 0;

  For c_base_rec IN (select pc.project_conv_id
                     ,      pc.project_id
                     ,      pbv.BUDGET_VERSION_ID
                     ,      pbv.BUDGET_TYPE_CODE
                     from   HAEMO.XXHA_PROJECTS_CONV pc
                     ,      PA_BUDGET_VERSIONS_DRAFT_V pbv
                     where (pc.project_id, pc.project_conv_id) in  (select pc2.project_id, min(pc2.project_conv_id)
                                                                    from   HAEMO.xxha_projects_conv pc2
                                                                    group by pc2.project_id
                                                                   )
                     and    pc.project_id = pbv.project_id
                     and    (pc.project_id, pbv.budget_version_id) in (select pbv2.project_id, max(pbv2.budget_version_id)
                                                                       from   PA_BUDGET_VERSIONS_DRAFT_V pbv2
                                                                       where  pbv2.BUDGET_TYPE_CODE =  'SR Approved Revenue Budget'
                                                                       group by pbv2.project_id
                                                                       UNION
                                                                       select pbv2.project_id, max(pbv2.budget_version_id)
                                                                       from   PA_BUDGET_VERSIONS_DRAFT_V pbv2
                                                                       where  pbv2.BUDGET_TYPE_CODE =  'SR Approved Cost Budget'
                                                                       group by pbv2.project_id
                                                                      )
                     and NOT EXISTS (select 1
                                     from   PA_BUDGET_VERSIONS_BASELINED_V  bb
                                     where  bb.project_id = pbv.project_id
                                     and    bb.budget_version_id = pbv.budget_version_id
                                     and    bb.budget_type_code =  pbv.BUDGET_TYPE_CODE
                                     and    bb.budget_status_code = 'B'
                                     and    current_flag = 'Y'
                                    )
                     order by pc.project_id
                    )
  Loop

    g_rec_counter := g_rec_counter + 1;

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Record>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ' || g_rec_counter);
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Project Id: ' || c_base_rec.project_id);
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'c_base_rec.BUDGET_TYPE_CODE: ' || c_base_rec.BUDGET_TYPE_CODE);

    Begin
      -- Budget_Status_code = S    Budget_status_m = Submitted
      -- BUDGET DATA
      l_pa_project_id       := c_base_rec.project_id; --Set for the project
      l_pm_project_reference:= 'AMG TEST PROJECT';   --Set for the project
      l_budget_type_code    := c_base_rec.BUDGET_TYPE_CODE;  --'AC';

      -- BASELINE BUDGET
      pa_budget_pub.baseline_budget(
	    p_api_version_number    => l_api_version_number
	    , p_commit			    => l_commit
	    , p_init_msg_list		=> l_init_msg_list
	    , p_msg_count			=> l_msg_count
	    , p_msg_data			=> l_msg_data
	    , p_return_status		=> l_return_status
	    , p_workflow_started	=> l_workflow_started
	    , p_pm_product_code		=> l_pm_product_code
	    , p_pa_project_id		=> l_pa_project_id
	    , p_pm_project_reference=> l_pm_project_reference
	    , p_budget_type_code	=> l_budget_type_code
	  );

      IF l_return_status != 'S'
      THEN
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: *Create BaseLine Budget* API failed..');

         for i in 1..l_msg_count loop
           pa_interface_utils_pub.get_messages(
                 p_msg_data        => l_msg_data,
                 p_msg_index        => i,
                 p_encoded        => 'F',
                 p_data             => l_data,
                 p_msg_count        => l_msg_count,
                 p_msg_index_out        =>l_msg_index_out);

           FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);

         end loop;

      else

        FND_FILE.PUT_LINE( FND_FILE.OUTPUT, '$Create BaseLine Budget$ Created Successfully...........');

      END IF;

    Exception
    WHEN API_ERROR
    THEN
      for i in 1..l_msg_count
      loop
        pa_interface_utils_pub.get_messages (
            p_msg_data => l_msg_data
        ,   p_data => l_data
        ,   p_msg_count => l_msg_count
        ,   p_msg_index_out => l_msg_index_out
        );

        --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
        FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);
        --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' SQL Error = '||'.'||l_msg_count||'.'||SQLERRM);


      end loop;

    when g_skip
    then
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'skip: ');

    End;

  End Loop;

--
-- ++++++++++++++++++++++++++++
if p_mode = 'VIEW_ONLY'
then
  ROLLBACK;

elsif p_mode = 'COMMIT'
then
  COMMIT;

end if;

-- ++++++++++++++++++++++++++++

-- HANDLE EXCEPTIONS
EXCEPTION
WHEN OTHERS
THEN

  for i in 1..l_msg_count
  loop

  pa_interface_utils_pub.get_messages
    (   p_msg_data => l_msg_data
    ,   p_data => l_data
    ,   p_msg_count => l_msg_count
    ,   p_msg_index_out => l_msg_index_out
    );
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Message Data: '||l_msg_data);
         FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Error l_data: ' || i || ': ' ||l_data);
         --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' SQL Error = '||'.'||l_msg_count||'.'||SQLERRM);


    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: OTHERS '||SQLERRM);

  end loop;

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: OTHERS error message: ' || SQLERRM);
  ROLLBACK;
  RAISE g_no_handle;

End BASELINE_BUDGET;  -----
--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PROCEDURE update_project
            ( p_mode IN VARCHAR2 := 'VIEW_ONLY'
            ) is
BEGIN
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Program update_project Begins');

  ---
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'p_mode: ' || p_mode );

  UPDATE pa_projects_all pp
  set    pp.project_status_code         = 'APPROVED'
  ,      pp.last_update_date            = SYSDATE
  ,      pp.LIMIT_TO_TXN_CONTROLS_FLAG  = 'Y'
  where  pp.project_id IN (select distinct pc.project_id
                           from   HAEMO.XXHA_PROJECTS_CONV pc
                           where  pc.project_id is not null
                          )
  and    pp.project_status_code = 'UNAPPROVED'
  ;

  if SQL%FOUND
  then
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, '******* No of Projects updated with status Approved: ' || SQL%ROWCOUNT);

  else
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'war: Did not find any record to update: ' || SQL%ROWCOUNT);

  end if;


  update pa_tasks pt
  set    pt.attribute1 = (select decode(replace(UPPER(pc.product_line), ' ', ''),
                                                                'SAFETRACE',      'Safetrace',
                                                                'SAFETRACETX',    'Safetrace Tx',
                                                                'ELDORADODONOR',  'El Dorado Donor',
                                                                'DONORDOC',       'El Dorado Donor Doc', pc.product_line
                                       )
                          from   HAEMO.xxha_projects_conv pc
                          where  pc.task_id = pt.task_id
                          and    pc.project_conv_id = (select min(pc2.project_conv_id)
                                                       from   HAEMO.xxha_projects_conv pc2
                                                       where  pc2.task_id = pc.task_id
                                                      )
                         )
  ,     last_update_date  = SYSDATE
  where pt.project_id in (select distinct xpc.project_id
                          from   HAEMO.xxha_projects_conv xpc
                          where  xpc.project_id is not null
                          --and    xpc.project_id > 2721
                         );

  if SQL%FOUND
  then
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, '******* No of Tasks updated with Attribute1 for Product Line: ' || SQL%ROWCOUNT);

  else
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'war: Did not find any record to update: ' || SQL%ROWCOUNT);

  end if;

--
-- ++++++++++++++++++++++++++++
if p_mode = 'VIEW_ONLY'
then
  ROLLBACK;

elsif p_mode = 'COMMIT'
then
  COMMIT;

end if;

-- ++++++++++++++++++++++++++++

EXCEPTION
when others
then
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: OTHERS error message: ' || SQLERRM);
  ROLLBACK;

END UPDATE_PROJECT;
--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PROCEDURE txn_control
            ( p_mode IN VARCHAR2 := 'VIEW_ONLY'
            ) is

v_exp_cat       PA_TRANSACTION_CONTROLS.EXPENDITURE_CATEGORY%TYPE;
v_exp_type      PA_TRANSACTION_CONTROLS.EXPENDITURE_TYPE%TYPE;
v_billable_ind  PA_TRANSACTION_CONTROLS.BILLABLE_INDICATOR%TYPE;

BEGIN

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'p_mode: ' || p_mode );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_id: ' || g_user_id );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_user_name: ' || g_user_name );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_org_id: ' || g_org_id );

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_data_base: ' || g_data_base);

  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'g_date_time: ' || g_date_time);

  --
  -- one time check
  --
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Check if Exp Category and Type is setup in system');

  select COUNT(*)
  into   g_number
  from   PA_EXPENDITURE_CATEGORIES
  where  EXPENDITURE_CATEGORY IN ('Labor', 'Material', 'Travel Expenses', 'Non-Billable Travel')
  and    TRUNC(SYSDATE) BETWEEN  START_DATE_ACTIVE and NVL(END_DATE_ACTIVE, TRUNC(SYSDATE) )
  ;

  if g_number < 4
  then
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: Fatal no categories setup');
    RAISE g_no_handle;

  end if;

  select COUNT(*)
  into   g_number
  from   PA_EXPENDITURE_TYPES_DESC_V
  where  EXPENDITURE_TYPE IN ('LABOR', 'Admin Labor')
  and    TRUNC(SYSDATE) BETWEEN  START_DATE_ACTIVE and NVL(END_DATE_ACTIVE, TRUNC(SYSDATE) )
  ;

  if g_number < 2
  then
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: Fatal no Categorie Type setup');
    RAISE g_no_handle;

  end if;

  ---
  --
  ---
  g_rec_counter := 0;

  FOR c_txn_rec IN (select distinct pp.project_id
                    --,       pt.task_id
                    --,       pc.task_type
                    ,       pp.start_date
                    from    pa_tasks pt
                    ,       pa_projects_all pp
                    where   pt.project_id = pp.project_id
                    and     EXISTS ( select 1
                                     from   HAEMO.XXHA_PROJECTS_CONV pc
                                     where  pc.project_id = pt.project_id
                                     -- and    pc.task_id = pt.project_id
                                   )
                    and     NOT EXISTS (select 1
                                        from   PA_TRANSACTION_CONTROLS tc
                                        where  tc.project_id = pt.project_id
                                        and    tc.task_id = pt.task_id
                                       )
                    order by pp.project_id --, pt.task_id, pc.task_type
                   )
  LOOP

    v_exp_cat  := NULL;
    v_exp_type := NULL;
    v_billable_ind := NULL;

    g_rec_counter := g_rec_counter +1;

    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Record>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ' || g_rec_counter);
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Project Id: ' || c_txn_rec.project_id);
    --FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'Task Id: ' || c_txn_rec.task_id);

    ---
    --
    ---
    -- x := 1;

    For i in 1..5
    Loop

      if i = 1
      then
        v_exp_cat  := 'Labor';
        v_exp_type := 'LABOR';
        v_billable_ind := 'T';

      elsif i = 2
      then
        v_exp_cat  := 'Labor';
        v_exp_type := 'Admin Labor';
        v_billable_ind := 'N';

      elsif i = 3
      then
        v_exp_cat  := 'Material';
        v_exp_type := NULL;
        v_billable_ind := 'T';

      elsif i = 4
      then
        v_exp_cat  := 'Travel Expenses';
        v_exp_type := NULL;
        v_billable_ind := 'T';

      elsif i = 5
      then
        v_exp_cat  := 'Non-Billable Travel';
        v_exp_type := NULL;
        v_billable_ind := 'N';

      end if;

      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'i: ' ||i);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'v_exp_cat: ' ||v_exp_cat);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'v_exp_type: ' ||v_exp_type);
      FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'v_billable_ind: ' ||v_billable_ind);

      ---
      --
      ---
      begin

        if i in (1,2)
        then
          select NVL(MAX(1), 0)
          into   g_number
          from   PA_TRANSACTION_CONTROLS
          where  project_id = c_txn_rec.project_id
          and    expenditure_category = v_exp_cat
          and    expenditure_type = v_exp_type
          and    start_date_active = c_txn_rec.start_date
          ;

          if g_number = 1
          then
            FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'skip: Transaction Control already exists for this project');
            raise g_skip;
          end if;

        elsif i in (3,4,5)
        then
          select NVL(MAX(1), 0)
          into   g_number
          from   PA_TRANSACTION_CONTROLS
          where  project_id = c_txn_rec.project_id
          and    expenditure_category = v_exp_cat
          and    expenditure_type is null
          and    start_date_active = c_txn_rec.start_date
          ;

          if g_number = 1
          then
            FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'skip: Transaction Control already exists for this project');
            raise g_skip;
          end if;

        end if;

        INSERT INTO PA_TRANSACTION_CONTROLS
        (   PROJECT_ID
        , START_DATE_ACTIVE
        , CHARGEABLE_FLAG
        , BILLABLE_INDICATOR
        , CREATION_DATE
        , CREATED_BY
        , LAST_UPDATE_DATE
        , LAST_UPDATED_BY
        , LAST_UPDATE_LOGIN
        , TASK_ID
        , PERSON_ID
        , EXPENDITURE_CATEGORY
        , EXPENDITURE_TYPE
        , NON_LABOR_RESOURCE
        , END_DATE_ACTIVE
        , SCHEDULED_EXP_ONLY
        , EMPLOYEES_ONLY_FLAG
        , WORKPLAN_RES_ONLY_FLAG
        ) values
        (   c_txn_rec.project_id  -- PROJECT_ID
        , c_txn_rec.start_date  -- START_DATE_ACTIVE
        , 'Y'                   -- CHARGEABLE_FLAG
        , v_billable_ind        -- BILLABLE_INDICATOR  T- Task Level   N-
        , SYSDATE               -- CREATION_DATE
        , g_user_id            -- CREATED_BY
        , SYSDATE               -- LAST_UPDATE_DATE
        , g_user_id            -- LAST_UPDATED_BY
        , g_user_id            -- LAST_UPDATE_LOGIN
        , NULL -- c_txn_rec.TASK_ID     -- TASK_ID
        , NULL                  -- PERSON_ID
        , v_exp_cat             -- EXPENDITURE_CATEGORY
        , v_exp_type            -- EXPENDITURE_TYPE
        , NULL                  -- NON_LABOR_RESOURCE
        , NULL                  -- END_DATE_ACTIVE
        , 'N'                   -- SCHEDULED_EXP_ONLY
        , NULL                  -- EMPLOYEES_ONLY_FLAG
        , 'N'                   -- WORKPLAN_RES_ONLY_FLAG
        );

        if SQL%FOUND
        then
          FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'**************** Record Successfully Created in PA txn Controls');

        else

          FND_FILE.PUT_LINE( FND_FILE.OUTPUT,'err: Could not create Record in PA txn Controls');

        end if;

      exception

      when g_skip
      then
        NULL;

      end;

    End Loop; -- loop for insert

  END LOOP;

-- ++++++++++++++++++++++++++++
if p_mode = 'VIEW_ONLY'
then
  ROLLBACK;

elsif p_mode = 'COMMIT'
then
  COMMIT;

end if;

-- ++++++++++++++++++++++++++++

EXCEPTION

when others
then
  FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'err: OTHERS error message: ' || SQLERRM);
  ROLLBACK;

END TXN_CONTROL;

END XXHA_PROJ_CONV;  -- End Package Body
/
