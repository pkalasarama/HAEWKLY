CREATE OR REPLACE PACKAGE      xxha_gl_wf_pkg AUTHID CURRENT_USER
AS
/**********************************************************************************************************************************
*
* Package:      xxha_gl_wf_pkg
* Description:   Custom GL Approval workflow code, for multi-org approvals
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    27-Aug-2014  Initial Creation
*
**********************************************************************************************************************************/
   PROCEDURE verify_authority (
      itemtype   IN              VARCHAR2,
      itemkey    IN              VARCHAR2,
      actid      IN              NUMBER,
      funcmode   IN              VARCHAR2,
      RESULT     OUT NOCOPY      VARCHAR2
   );

   PROCEDURE find_approver (
      item_type   IN              VARCHAR2,
      item_key    IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      RESULT      OUT NOCOPY      VARCHAR2
   );
END;
/


CREATE OR REPLACE PACKAGE BODY      xxha_gl_wf_pkg
AS
/**********************************************************************************************************************************
*
* Package:      xxha_gl_wf_pkg
* Description:   Custom GL Approval workflow code, for multi-org approvals
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    27-Aug-2014  Initial Creation
*
**********************************************************************************************************************************/
   PROCEDURE verify_authority (
      itemtype   IN              VARCHAR2,
      itemkey    IN              VARCHAR2,
      actid      IN              NUMBER,
      funcmode   IN              VARCHAR2,
      RESULT     OUT NOCOPY      VARCHAR2
   )
   IS
      v_test   NUMBER;
   BEGIN
      IF (funcmode = 'RUN')
      THEN
         SELECT COUNT (*)
           INTO v_test
           FROM xxha_gl_approvers
          WHERE approve_flag = 'N' AND wf_item_key = itemkey;

         IF v_test = 0
         THEN
            RESULT := 'COMPLETE:PASS';
         ELSE
            RESULT := 'COMPLETE:FAIL';
         END IF;
      ELSIF (funcmode = 'CANCEL')
      THEN
         NULL;
      END IF;
   END verify_authority;

   PROCEDURE setpersonas (
      manager_id   IN   NUMBER,
      item_type    IN   VARCHAR2,
      item_key     IN   VARCHAR2
   )
   IS
      l_manager_name           VARCHAR2 (240);
      l_manager_display_name   VARCHAR2 (240);
   BEGIN
      wf_directory.getusername ('PER',
                                manager_id,
                                l_manager_name,
                                l_manager_display_name
                               );
      wf_engine.setitemattrnumber (item_type,
                                   item_key,
                                   'APPROVER_ID',
                                   manager_id
                                  );
      wf_engine.setitemattrtext (item_type,
                                 item_key,
                                 'APPROVER_NAME',
                                 l_manager_name
                                );
      wf_engine.setitemattrtext (item_type,
                                 item_key,
                                 'APPROVER_DISPLAY_NAME',
                                 l_manager_display_name
                                );
   END setpersonas;

   PROCEDURE find_approver (
      item_type   IN              VARCHAR2,
      item_key    IN              VARCHAR2,
      actid       IN              NUMBER,
      funcmode    IN              VARCHAR2,
      RESULT      OUT NOCOPY      VARCHAR2
   )
   IS
      CURSOR approvers
      IS
         SELECT   person_id
             FROM xxha_gl_approvers
            WHERE wf_item_key = item_key AND approve_flag = 'N'
         ORDER BY appr_level asc;

      v_approver        approvers%ROWTYPE;
      l_error_message   VARCHAR2 (255);

      CURSOR get_ledgers (p_batch_id IN NUMBER)
      IS
         SELECT DISTINCT ledger_id
                    FROM gl_je_headers jeh
                   WHERE jeh.je_batch_id = p_batch_id
                     AND jeh.currency_code <> 'STAT'
                GROUP BY ledger_id
                order by ledger_id asc;
   BEGIN
      IF (funcmode = 'RUN')
      THEN
         OPEN approvers;

         FETCH approvers
          INTO v_approver;

         CLOSE approvers;

         IF v_approver.person_id IS NOT NULL
         THEN
            UPDATE xxha_gl_approvers
               SET approve_flag = 'Y'
             WHERE wf_item_key = item_key AND person_id = v_approver.person_id;

            setpersonas (v_approver.person_id, item_type, item_key);
            RESULT := 'COMPLETE:Y';
         ELSE
            fnd_message.set_name ('SQLGL', 'GL_WF_CANNOT_FIND_APPROVER');
            l_error_message := fnd_message.get;
            wf_engine.setitemattrtext (item_type,
                                       item_key,
                                       'ERROR_MESSAGE',
                                       l_error_message
                                      );
            RESULT := 'COMPLETE:N';
         END IF;
      ELSIF (funcmode = 'CANCEL')
      THEN
         NULL;
      END IF;
   END find_approver;
END;
/
