CREATE OR REPLACE package XXHA_QD_GET_QUALITY_DATA_PKG
-- +====================================================================================+
-- | Name        : XXHA_QD_GET_QUALITY_DATA_PKG                                         |
-- | Purpose     : Runs insert-select statements to populate HAEMO schema               |
-- |               tables (XXHA_QD_DISP_SALES_DATA, XXHA_QD_QUALITY_DATA,               |
-- |               		XXHA_QD_QUALITY_NOTE_DATA)                                      |
-- |               for the Quality Data and Service Contracts Hyperion reports.         |
-- |                                                                                    |
-- | Tables Accessed :                                                                  |
-- | Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)      |
-- |                                                                                    |
-- | XXHA_QD_DISP_SALES_DATA         D, I                                               |
-- | XXHA_QD_QUALITY_DATA            D, I                                               |
-- | XXHA_QD_QUALITY_NOTE_DATA       D, I                                               |
-- |                                                                                    |
-- | History                                                                            |
-- | =======                                                                            |
-- | When      Rev  Who               What                                              |
-- | --------  ---  --------          ------------------------------------------------- |
-- | 20081216  1.0  Vasil S. Valkov   Initial version                                   |
-- | 20090608  1.1  Vasil S. Valkov   Added SEVERITY field to XXHA_QD_QUALITY_DATA      |
-- | 20091204  1.2  Vasil S. Valkov   Added cursors for populating a second quality     |
-- |                                  data table that contains Note fields.             |
-- |                                  The table is XXHA_QD_QUALITY_NOTE_DATA.           |
-- |                                  There were also changes to the existing 	        |
-- |                                  quality cursors to avoid duplicates in the        |
-- |                                  financial data - labor, materials, expenses.      |
-- | 20100308  1.3  Vasil S. Valkov   Changed the calculation of Responsed Time         |
-- |                                  field to use INCIDENT_OCCURRED_DATE instead       |
-- |                                  of INCIDENT_DATE.                                 |
-- | 20100825  1.4  Vasil S. Valkov   Added Closed_Date field to                        |
-- | 								  XXHA_QD_QUALITY_NOTE_DATA.                        |
-- | 20101117  1.5  Vasil S. Valkov	  Added Account_Number to both Quality tables.      |
-- | 20110308  1.6  Vasil S. Valkov	  Added fields to XXHA_QD_QUALITY_NOTE_DATA table.  |
-- | 20110526  1.7  Vasil S. Valkov   Added fields to XXHA_QD_QUALITY_NOTE_DATA table.  |
-- | 20110801  1.8  Vasil S. Valkov   Added MATERIAL_USED_QUANTITY field to both        |
-- |                                  quality tables.                                   |
-- | 20111129  1.9  Vasil S. Valkov   In both queries for Depot Repair, replaced        |
-- |                                  'cs_sr_owners_v' with 'jtf_rs_all_resources_vl'   |
-- |                                  for correct retrieving of incident_owner.         |
-- | 20140304  2.0  Ian Menzies       Total rework of package for R12 and performance   |
-- +====================================================================================+
AS




PROCEDURE GET_QUALITY_DATA
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
         );



end XXHA_QD_GET_QUALITY_DATA_PKG;
/


CREATE OR REPLACE PACKAGE BODY      XXHA_QD_GET_QUALITY_DATA_PKG
-- +====================================================================================+
-- | Name        : XXHA_QD_GET_QUALITY_DATA_PKG                                         |
-- | Purpose     : Runs insert-select statements to populate HAEMO schema               |
-- |               tables (XXHA_QD_DISP_SALES_DATA, XXHA_QD_QUALITY_DATA,               |
-- |                 XXHA_QD_QUALITY_NOTE_DATA)                                      |
-- |               for the Quality Data and Service Contracts Hyperion reports.         |
-- |                                                                                    |
-- | Tables Accessed :                                                                  |
-- | Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)      |
-- |                                                                                    |
-- | XXHA_QD_DISP_SALES_DATA         D, I                                               |
-- | XXHA_QD_QUALITY_DATA            D, I                                               |
-- | XXHA_QD_QUALITY_NOTE_DATA       D, I                                               |
-- |                                                                                    |
-- | History                                                                            |
-- | =======                                                                            |
-- | When      Rev  Who               What                                              |
-- | --------  ---  --------          ------------------------------------------------- |
-- | 20081216  1.0  Vasil S. Valkov   Initial version                                   |
-- | 20090608  1.1  Vasil S. Valkov   Added SEVERITY field to XXHA_QD_QUALITY_DATA      |
-- | 20091204  1.2  Vasil S. Valkov   Added cursors for populating a second quality     |
-- |                                  data table that contains Note fields.             |
-- |                                  The table is XXHA_QD_QUALITY_NOTE_DATA.           |
-- |                                  There were also changes to the existing          |
-- |                                  quality cursors to avoid duplicates in the        |
-- |                                  financial data - labor, materials, expenses.      |
-- | 20100308  1.3  Vasil S. Valkov   Changed the calculation of Responsed Time         |
-- |                                  field to use INCIDENT_OCCURRED_DATE instead       |
-- |                                  of INCIDENT_DATE.                                 |
-- | 20100825  1.4  Vasil S. Valkov   Added Closed_Date field to                        |
-- |           XXHA_QD_QUALITY_NOTE_DATA.                        |
-- | 20101117  1.5  Vasil S. Valkov   Added Account_Number to both Quality tables.      |
-- | 20110308  1.6  Vasil S. Valkov   Added fields to XXHA_QD_QUALITY_NOTE_DATA table.  |
-- | 20110526  1.7  Vasil S. Valkov   Added fields to XXHA_QD_QUALITY_NOTE_DATA table.  |
-- | 20110801  1.8  Vasil S. Valkov   Added MATERIAL_USED_QUANTITY field to both        |
-- |                                  quality tables.                                   |
-- | 20111129  1.9  Vasil S. Valkov   In both queries for Depot Repair, replaced        |
-- |                                  'cs_sr_owners_v' with 'jtf_rs_all_resources_vl'   |
-- |                                  for correct retrieving of incident_owner.         |
-- |20140304  2.0  Ian Menzies       Total rework of package for R12 and performance    |
-- +====================================================================================+
AS
   PROCEDURE GET_QUALITY_DATA (x_errbuf OUT VARCHAR2, x_retcode OUT VARCHAR2)
   IS
      ln_record_count   NUMBER := 0;
   BEGIN
      EXECUTE IMMEDIATE
         ('alter session set "_optimizer_cost_based_transformation"=off');

      EXECUTE IMMEDIATE 'truncate table haemo.XXHA_QD_DISP_SALES_SUMMARY';

      EXECUTE IMMEDIATE 'truncate table haemo.XXHA_QD_QUALITY_DATA_TASKS';

      EXECUTE IMMEDIATE 'truncate table haemo.XXHA_QD_QUALITY_NOTE_DATA';

      ln_record_count := 0;

      BEGIN
         INSERT INTO HAEMO.XXHA_QD_DISP_SALES_SUMMARY (NET_QUANTITY,
                                              ITEMNUMBER,
                                              DESCRIPTION,
                                              PRODUCT_SUB_TYPE,
                                              PRODUCT_TYPE,
                                              LEGAL_ENTITY_SEGMENT,
                                              LEGAL_ENTITY_DESC,
                                              MGMT_UNIT_SEGMENT,
                                              MGMT_UNIT_DESC,
                                              NAT_ACCT_SEGMENT,
                                              NATURAL_ACCT_DESC,
                                              GL_PROD_LINE_SEGMENT,
                                              GL_PROD_LINE_DESC,
                                              BUSS_UNIT_SEGMENT,
                                              BUSINESS_UNIT_DESC,
                                              DEPT_SEGMENT,
                                              DEPT_DESC,
                                              FISCAL_YEAR,
                                              FIS_QUARTER,
                                              FISCAL_MONTH,
                                              PERIOD_NUM,
                                              FISCAL_CODE,
                                              PERIOD_NAME,
                                              PERIOD_START_DATE,
                                              PERIOD_END_DATE,
                                              SHIPTO_COUNTRY,
                                              DISTRIBUTION_LEVEL_PERCENT,
                                              INTERCOMPANY_FLAG,
                                              TRADE_FLAG)
     SELECT SUM (
                 (NVL (quantity_invoiced, 0) + NVL (quantity_credited, 0))
               * al1.distribution_level_percent/100)
               net_quantity,
            al2.itemnumber itemnumber,
            al2.description description,
            al2.product_sub_type product_sub_type,
            al2.product_type product_type,
            al3.flex_value legal_entity_segment,
            al3.description legal_entity_desc,
            al4.flex_value mgmt_unit_segment,
            al4.description mgmt_unit_desc,
            al5.flex_value nat_acct_segment,
            al5.description natural_acct_desc,
            al6.flex_value gl_prod_line_segment,
            al6.description gl_prod_line_desc,
            al7.flex_value buss_unit_segment,
            al7.description business_unit_desc,
            al15.flex_value dept_segment,
            al15.description dept_desc,
            al8.period_year fiscal_year,
            (DECODE (al8.quarter_num,
                     1, 'FQ1',
                     2, 'FQ2',
                     3, 'FQ3',
                     4, 'FQ4'))
               fis_quarter,
            (DECODE (al8.entered_period_name,
                     'Apr', 'FM01(Apr)',
                     'May', 'FM02(May)',
                     'Jun', 'FM03(Jun)',
                     'Jul', 'FM04(Jul)',
                     'Aug', 'FM05(Aug)',
                     'Sep', 'FM06(Sep)',
                     'Oct', 'FM07(Oct)',
                     'Nov', 'FM08(Nov)',
                     'Dec', 'FM09(Dec)',
                     'Jan', 'FM10(Jan)',
                     'Feb', 'FM11(Feb)',
                     'Mar', 'FM12(Mar)'))
               fiscal_month,
            al8.period_num,
            al8.period_year * 100 + al8.period_num fiscal_code,
            al8.period_name period_name,
            al8.start_date period_start_date,
            al8.end_date period_end_date,
            --al13.billto_country billto_country,
            --al13.billto_customer_name billto_customer_name,
            --al13.billto_customer_number billto_customer_number,
            al12.shipto_country shipto_country,
            --al12.shipto_customer_name shipto_customer_name,
            --al12.shipto_customer_number shipto_customer_number,
            --al1.distribution_level_percent
            100 distribution_level_percent,
            al1.intercompany_flag intercompany_flag,
            al1.trade_flag trade_flag
       FROM apps.xx_haemo_sales_revenue al1,
            apps.xx_haemo_item_details al2,
            apps.xx_haemo_legalentity al3,
            apps.xx_haemo_mgmtunits al4,
            apps.xx_haemo_natacct al5,
            apps.xx_haemo_prodline al6,
            apps.xx_haemo_bussunits al7,
            apps.gl_periods al8,
            apps.xx_haemo_shipto_cust_details al12,
            --apps.xx_haemo_billto_cust_details al13,
            apps.xx_haemo_depts al15,
            apps.jtf_rs_salesreps al18,
            apps.gl_code_combinations_kfv al19,
            apps.xx_haemo_bussunits al20,
            apps.xx_haemo_mgmtunits al21
      WHERE     (    al1.inventory_item_id = al2.inventory_item_id
                 AND al1.ship_to_site_use_id = al12.shipto_site_use_id(+)
                 --AND al1.bill_to_site_use_id = al13.billto_site_use_id(+)
                 AND al1.current_salesrep_id = al18.salesrep_id(+)
                 AND al18.gl_id_rev = al19.code_combination_id(+)
                 AND al19.segment3 = al20.flex_value(+)
                 AND al19.segment4 = al21.flex_value(+)
                 AND al1.organization_id = al18.org_id(+)
                 AND al1.legal_entity = al3.flex_value
                 AND al1.management_unit = al4.flex_value
                 AND al1.natural_account = al5.flex_value
                 AND al1.product_line = al6.flex_value
                 AND al1.business_unit = al7.flex_value
                 AND al1.trx_date >= al8.start_date
                 AND TRUNC (al1.trx_date) <= al8.end_date
                 AND al1.department = al15.flex_value)
            AND ( (    al8.period_set_name = 'HAE_GLOBAL_CAL'
                   AND al8.period_type = '21'
                   AND al1.intercompany_flag <> 'Y'
                   AND AL1.TRADE_FLAG <> 'N'
                   AND AL2.inventory_item_id <> 0
                   AND AL19.SEGMENT4 NOT IN ('2120', '2125')))
   GROUP BY al2.itemnumber,
            al2.description,
            al2.product_sub_type,
            al2.product_type,
            al3.flex_value,
            al3.description,
            al4.flex_value,
            al4.description,
            al5.flex_value,
            al5.description,
            al6.flex_value,
            al6.description,
            al7.flex_value,
            al7.description,
            al15.flex_value,
            al15.description,
            al8.period_year,
            al8.quarter_num,
            al8.entered_period_name,
            al8.period_num,
            al8.period_name,
            al8.start_date,
            al8.end_date,
            --al13.billto_country,
            --al13.billto_customer_name,
            --al13.billto_customer_number,
            al12.shipto_country,
            --al12.shipto_customer_name,
            --al12.shipto_customer_number,
            al1.intercompany_flag,
            al1.trade_flag;


         ln_record_count := SQL%ROWCOUNT;
      EXCEPTION
         WHEN OTHERS
         THEN
            FND_FILE.PUT_LINE (
               FND_FILE.LOG,
                  'Unexpected error occured while inserting into XXHA_QD_DISP_SALES_SUMMARY: '
               || SQLERRM);
      END;

      COMMIT;
      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            ln_record_count
         || ' - Records Successfully inserted in XXHA_QD_DISP_SALES_SUMMARY '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));

      ln_record_count := 0;

      BEGIN
         INSERT INTO HAEMO.XXHA_QD_QUALITY_DATA_TASKS (
                        INCIDENT_ID,
                        INCIDENT_NUMBER,
                        INCIDENT_DATE,
                        DATE_CLOSED,
                        ORG_ID,
                        INCIDENT_OWNER,
                        INCIDENT_COUNTRY_CODE,
                        ADDRESS1,
                        CITY,
                        STATE,
                        ZIP_CODE,
                        INSTANCE_SERIAL_NUMBER,
                        INSTANCE_PRODUCT_NAME,
                        INSTANCE_ITEM_PRODUCT_DESCR,
                        INSTALL_DATE,
                        SEVERITY,
                        INCIDENT_PROBLEM_CODE,
                        INCIDENT_PROBLEM_DESC,
                        INCIDENT_RESOLUTION_CODE,
                        INCIDENT_RESOLUTION_DESC,
                        INCIDENT_TYPE,
                        INCIDENT_STATUS_ID,
                        INCIDENT_STATUS_MEANING,
                        LOGGED_BY,
                        LAST_UPDATE_DATE,
                        INCIDENT_CONTEXT,
                        PROBLEM_SUMMARY,
                        TOTAL_SUBMITTED,
                        PIR_NEED,
                        PROCESS_PHASE,
                        DEATH,
                        INJURY,
                        APPENDIX_A,
                        CONTRACT_NUMBER,
                        ACCOUNT_NUMBER,
                        CONTACT_PARTY_NAME,
                        PRIMARY_PHONE_AREA_CODE,
                        PRIMARY_PHONE_NUMBER,
                        EMAIL_ADDRESS,
                        URL,
                        TASK_ID,
                        TASK_NUMBER,
                        TASK_NAME,
                        TASK_PLANNED_START_DATE,
                        TASK_ACTUAL_START_DATE,
                        TASK_ACTUAL_END_DATE,
                        RESPONSE_TIME_IN_HRS,
                        TASK_OWNER,
                        TASK_STATUS,
                        TASK_PRIORITY,
                        REPAIR_STATUS_MEANING,
                        DEBRIEF_HEADER_ID,
                        DEBRIEF_ASSIGNEE_RESOURCE,
                        DEBRIEF_ASSIGNEE_COUNTRY)
            SELECT cia.incident_id,
                   cia.incident_number,
                   cia.incident_date,
                   cia.close_date date_closed,
                   cia.org_id,
                   cio_r.resource_name incident_owner,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_country
                      ELSE
                         hl.country
                   END
                      incident_country_code,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_address
                      ELSE
                         hl.address1
                   END
                      address1,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_city
                      ELSE
                         hl.city
                   END
                      city,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_state
                      ELSE
                         hl.state
                   END
                      state,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_postal_code
                      ELSE
                         hl.postal_code
                   END
                      zip_code,
                   cii.serial_number instance_serial_number,
                   msi_inc.segment1 instance_product_name,
                   msi_inc.description instance_item_product_descr,
                   cii.install_date,
                   cisv.name severity,
                   cl_pc.lookup_code incident_problem_code,
                   cl_pc.description incident_problem_desc,
                   cl_rc.lookup_code incident_resolution_code,
                   cl_rc.description incident_resolution_desc,
                   cit.name incident_type,
                   cia.incident_status_id,
                   cis.name incident_status_meaning,
                   fu.user_name logged_by,
                   cia.last_update_date,
                   cia.incident_context,
                   cia_tl.summary problem_summary,
                   ts.total_submitted,
                   cia.incident_context pir_need,
                   cia.incident_attribute_2 process_phase,
                   cia.incident_attribute_3 death,
                   cia.incident_attribute_4 injury,
                   cia.incident_attribute_5 appendix_a,
                   cia.contract_number,
                   hca.account_number,
                   hp.party_name contact_party_name,
                   hp.primary_phone_area_code,
                   hp.primary_phone_number,
                   hp.email_address,
                   hp.url,
                   cdt.task_id,
                   cdt.task_number,
                   cdt.task_name,
                   cdt.planned_start_date task_planned_start_date,
                   cdt.actual_start_date task_actual_start_date,
                   cdt.actual_end_date task_actual_end_date,
                   (  (  (cdt.actual_start_date - cia.incident_occurred_date)
                       * 24)
                    - (  xx_haemo_get_wkendday_count_us (
                            cia.incident_occurred_date,
                            cdt.actual_start_date)
                       * 24))
                      response_time_in_hrs,
                   cdt.owner_name task_owner,
                   cdt.task_status,
                   cdt.task_priority_name task_priority,
                   cdt.repair_status_meaning,
                   cdt.debrief_header_id,
                   cdtda_r.resource_name debrief_assignee_resource,
                   da_hp.country debrief_assignee_country
              FROM apps.cs_incidents_all_b cia,
                   apps.cs_incidents_all_tl cia_tl,
                   apps.cs_hz_sr_contact_points chscp,
                   (SELECT jtv.source_object_id incident_id,
                           jta.resource_id,
                           csf_util_pvt.get_object_name (jtv.owner_type_code,
                                                         jtv.owner_id)
                              owner_name,
                           jtv.owner_id,
                           jtv.owner_type_code,
                           jtv.task_number,
                           jtv.task_name,
                           jtv.task_id,
                           jts1.name task_status,
                           jts1.task_status_id,
                           jtp.task_priority_id,
                           jtp.name task_priority_name,
                           jtv.planned_start_date,
                           jtv.planned_end_date,
                           jtv.actual_start_date,
                           jtv.actual_end_date,
                           cdh.debrief_number,
                           cdh.debrief_header_id,
                           cdh.debrief_date,
                           'n/a' repair_status_meaning
                      FROM jtf_tasks_vl jtv,
                           jtf_task_assignments jta,
                           jtf_task_statuses_vl jts1,
                           jtf_task_priorities_vl jtp,
                           csf_debrief_headers cdh
                     WHERE     1 = 1
                           AND jtv.task_id = jta.task_id(+)
                           AND jta.assignee_role(+) = 'ASSIGNEE'
                           AND jta.task_assignment_id =
                                  cdh.task_assignment_id(+)
                           AND jtv.task_priority_id = jtp.task_priority_id(+)
                           AND jtv.task_status_id = jts1.task_status_id
                           AND jtv.source_object_type_code = 'SR'
                    UNION ALL
                    SELECT cr.incident_id,
                           jta.resource_id,
                           csf_util_pvt.get_object_name (jtv.owner_type_code,
                                                         jtv.owner_id)
                              owner_name,
                           jtv.owner_id,
                           jtv.owner_type_code,
                           jtv.task_number,
                           jtv.task_name,
                           jtv.task_id,
                           jts1.name task_status,
                           jts1.task_status_id,
                           jtp.task_priority_id,
                           jtp.name task_priority_name,
                           jtv.planned_start_date,
                           jtv.planned_end_date,
                           jtv.actual_start_date,
                           jtv.actual_end_date,
                           cdh.debrief_number,
                           cdh.debrief_header_id,
                           cdh.debrief_date,
                           cl_r_stat.meaning repair_status_meaning
                      FROM csd_repairs cr,
                           jtf_tasks_vl jtv,
                           jtf_task_assignments jta,
                           jtf_task_statuses_vl jts1,
                           jtf_task_priorities_vl jtp,
                           csf_debrief_headers cdh,
                           apps.cs_lookups cl_r_stat
                     WHERE     1 = 1
                           AND cr.repair_line_id = jtv.source_object_id
                           AND jtv.task_id = jta.task_id
                           AND jta.assignee_role = 'ASSIGNEE'
                           AND jta.task_assignment_id =
                                  cdh.task_assignment_id(+)
                           AND jtv.task_priority_id = jtp.task_priority_id(+)
                           AND jtv.task_status_id = jts1.task_status_id
                           AND cr.status = cl_r_stat.lookup_code(+)
                           AND cl_r_stat.lookup_type(+) =
                                  'CSZ_SRCH_STATUS_FLAG_CODE'
                           AND jtv.source_object_type_code = 'DR'
                           AND jts1.name IN ('Closed', 'Completed')) cdt,
                   apps.csi_item_instances cii,
                   apps.hz_parties hp,
                   apps.hz_party_sites hps,
                   apps.hz_locations hl,
                   apps.hz_cust_accounts hca,
                   apps.fnd_user fu,
                   apps.jtf_rs_all_resources_vl cio_r,
                   apps.jtf_rs_all_resources_vl cdtda_r,
                   apps.hz_parties da_hp,
                   apps.mtl_system_items_b msi_inc,
                   apps.cs_incident_severities_vl cisv,
                   apps.cs_lookups cl_pc,
                   apps.cs_lookups cl_rc,
                   apps.cs_incident_statuses_vl cis,
                   apps.cs_incident_types_vl cit,
                   (  SELECT incident_id, SUM (total_submitted) total_submitted
                        FROM apps.cs_charge_details_v
                    GROUP BY incident_id) ts
             WHERE     1 = 1
                   AND cia.incident_id = cia_tl.incident_id
                   AND cia_tl.language = USERENV ('LANG')
                   AND cia.incident_id = cdt.incident_id(+)
                   AND cia.incident_id = chscp.incident_id(+)
                   AND chscp.primary_flag(+) = 'Y'
                   AND cia.customer_product_id = cii.instance_id(+)
                   AND cia.incident_location_id = hps.party_site_id(+)
                   AND hps.location_id = hl.location_id(+)
                   AND cia.account_id = hca.cust_account_id(+)
                   AND chscp.party_id = hp.party_id(+)
                   AND cia.incident_owner_id = cio_r.resource_id(+)
                   AND cdt.resource_id = cdtda_r.resource_id(+)
                   AND cdtda_r.person_party_id = da_hp.party_id(+)
                   AND cia.inventory_item_id = msi_inc.inventory_item_id(+)
                   AND msi_inc.organization_id(+) = 103
                   AND cia.incident_severity_id = cisv.incident_severity_id
                   AND cia.problem_code = cl_pc.lookup_code(+)
                   AND cl_pc.lookup_type(+) = 'REQUEST_PROBLEM_CODE'
                   AND cia.resolution_code = cl_rc.lookup_code(+)
                   AND cl_rc.lookup_type(+) = 'REQUEST_RESOLUTION_CODE'
                   AND cia.created_by = fu.user_id
                   AND cia.incident_status_id = cis.incident_status_id
                   AND cia.incident_type_id = cit.incident_type_id
                   AND cia.incident_id = ts.incident_id(+)
                   AND cia.incident_status_id NOT IN (100, 1224);

         ln_record_count := SQL%ROWCOUNT;
      EXCEPTION
         WHEN OTHERS
         THEN
            FND_FILE.PUT_LINE (
               FND_FILE.LOG,
                  'Unexpected error occured while inserting into XXHA_QD_QUALITY_DATA_TASKS: '
               || SQLERRM);
      END;

      COMMIT;
      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            ln_record_count
         || ' - Records Successfully inserted in XXHA_QD_QUALITY_DATA_TASKS '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));
      ln_record_count := 0;

      BEGIN
         INSERT INTO HAEMO.XXHA_QD_QUALITY_NOTE_DATA (
                        INCIDENT_ID,
                        INCIDENT_NUMBER,
                        INCIDENT_DATE,
                        DATE_CLOSED,
                        ORG_ID,
                        INCIDENT_OWNER,
                        INCIDENT_COUNTRY_CODE,
                        ADDRESS1,
                        CITY,
                        STATE,
                        ZIP_CODE,
                        INSTANCE_SERIAL_NUMBER,
                        INSTANCE_PRODUCT_NAME,
                        INSTANCE_ITEM_PRODUCT_DESCR,
                        INSTALL_DATE,
                        SEVERITY,
                        INCIDENT_PROBLEM_CODE,
                        INCIDENT_PROBLEM_DESC,
                        INCIDENT_RESOLUTION_CODE,
                        INCIDENT_RESOLUTION_DESC,
                        INCIDENT_TYPE,
                        INCIDENT_STATUS_ID,
                        INCIDENT_STATUS_MEANING,
                        LOGGED_BY,
                        LAST_UPDATE_DATE,
                        INCIDENT_CONTEXT,
                        PROBLEM_SUMMARY,
                        TOTAL_SUBMITTED,
                        PIR_NEED,
                        PROCESS_PHASE,
                        DEATH,
                        INJURY,
                        APPENDIX_A,
                        CONTRACT_NUMBER,
                        ACCOUNT_NUMBER,
                        CONTACT_PARTY_NAME,
                        PRIMARY_PHONE_AREA_CODE,
                        PRIMARY_PHONE_NUMBER,
                        EMAIL_ADDRESS,
                        URL,
                        TASK_ID,
                        TASK_NUMBER,
                        TASK_NAME,
                        TASK_PLANNED_START_DATE,
                        TASK_ACTUAL_START_DATE,
                        TASK_ACTUAL_END_DATE,
                        RESPONSE_TIME_IN_HRS,
                        TASK_OWNER,
                        TASK_STATUS,
                        TASK_PRIORITY,
                        REPAIR_STATUS_MEANING,
                        DEBRIEF_HEADER_ID,
                        DEBRIEF_ASSIGNEE_RESOURCE,
                        DEBRIEF_ASSIGNEE_COUNTRY,
                        NOTE,
                        NOTE_TYPE_MEANING,
                        DEBRIEF_LINE_ID,
                        DEBRIEF_LINE_NUMBER,
                        DEBRIF_SERIAL_NUMBER,
                        BILLING_CATEGORY,
                        MATERIAL_USED,
                        MATERIAL_USED_DESCRIPTION,
                        MATERIAL_USED_QUANTITY,
                        MATERIAL_USED_MST_COST,
                        LABOR_HOURS,
                        LABOR_ITEM,
                        LABOR_ITEM_DESCRIPTION,
                        EXPENSE_ITEM,
                        EXPENSE_ITEM_DESCRIPTION,
                        EXPENSE_ITEM_AMOUNT,
                        EXPENSES_CURRENCY_CODE,
                        ROW_SORT)
            SELECT qdt.incident_id,
                   qdt.incident_number,
                   qdt.incident_date,
                   qdt.date_closed,
                   qdt.org_id,
                   qdt.incident_owner,
                   qdt.incident_country_code,
                   qdt.address1,
                   qdt.city,
                   qdt.state,
                   qdt.zip_code,
                   qdt.instance_serial_number,
                   qdt.instance_product_name,
                   qdt.instance_item_product_descr,
                   qdt.install_date,
                   qdt.severity,
                   qdt.incident_problem_code,
                   qdt.incident_problem_desc,
                   qdt.incident_resolution_code,
                   qdt.incident_resolution_desc,
                   qdt.incident_type,
                   qdt.incident_status_id,
                   qdt.incident_status_meaning,
                   qdt.logged_by,
                   qdt.last_update_date,
                   qdt.incident_context,
                   qdt.problem_summary,
                   qdt.total_submitted,
                   qdt.pir_need,
                   qdt.process_phase,
                   qdt.death,
                   qdt.injury,
                   qdt.appendix_a,
                   qdt.contract_number,
                   qdt.account_number,
                   qdt.contact_party_name,
                   qdt.primary_phone_area_code,
                   qdt.primary_phone_number,
                   qdt.email_address,
                   qdt.url,
                   qdt.task_id,
                   qdt.task_number,
                   qdt.task_name,
                   qdt.task_planned_start_date,
                   qdt.task_actual_start_date,
                   qdt.task_actual_end_date,
                   qdt.response_time_in_hrs,
                   qdt.task_owner,
                   qdt.task_status,
                   qdt.task_priority,
                   qdt.repair_status_meaning,
                   qdt.debrief_header_id,
                   qdt.debrief_assignee_resource,
                   qdt.debrief_assignee_country,
                   NULL note,
                   NULL note_type_meaning,
                   cdl.debrief_line_id,
                   cdl.debrief_line_number,
                   cdl.item_serial_number debrif_serial_number,
                   cbt.billing_category,
                   CASE
                      WHEN cbt.billing_category = 'M' THEN msi_bt.segment1
                   END
                      material_used,
                   CASE
                      WHEN cbt.billing_category = 'M' THEN msi_bt.description
                   END
                      material_used_description,
                   CASE WHEN cbt.billing_category = 'M' THEN cdl.quantity END
                      material_used_quantity,
                   CASE
                      WHEN cbt.billing_category = 'M' THEN mst_cst.item_cost
                   END
                      material_used_mst_cost,
                   CASE WHEN cbt.billing_category = 'L' THEN cdl.quantity END
                      labor_hours,
                   CASE
                      WHEN cbt.billing_category = 'L' THEN msi_bt.segment1
                   END
                      labor_item,
                   CASE
                      WHEN cbt.billing_category = 'L' THEN msi_bt.description
                   END
                      labor_item_description,
                   CASE
                      WHEN cbt.billing_category = 'E' THEN msi_bt.segment1
                   END
                      expense_item,
                   CASE
                      WHEN cbt.billing_category = 'E' THEN msi_bt.description
                   END
                      expense_item_description,
                   CASE
                      WHEN cbt.billing_category = 'E' THEN cdl.expense_amount
                   END
                      expense_item_amount,
                   CASE
                      WHEN cbt.billing_category = 'E' THEN cdl.currency_code
                   END
                      expenses_currency_code,
                   ROW_NUMBER ()
                   OVER (PARTITION BY qdt.incident_id
                         ORDER BY qdt.task_number, cdl.debrief_line_number)
                      row_sort
              FROM haemo.xxha_qd_quality_data_tasks qdt,
                   apps.csf_debrief_lines cdl,
                   apps.mtl_system_items_b msi_bt,
                   apps.cst_item_costs mst_cst,
                   apps.cs_billing_type_categories cbt
             WHERE     1 = 1
                   AND qdt.debrief_header_id = cdl.debrief_header_id(+)
                   AND cdl.inventory_item_id = msi_bt.inventory_item_id(+)
                   AND msi_bt.organization_id(+) = 103
                   AND msi_bt.inventory_item_id =
                          mst_cst.inventory_item_id(+)
                   AND msi_bt.organization_id = mst_cst.organization_id(+)
                   AND mst_cst.cost_type_id(+) = 1
                   AND msi_bt.material_billable_flag = cbt.billing_type(+)
            UNION ALL
            SELECT qdt.incident_id,
                   qdt.incident_number,
                   qdt.incident_date,
                   qdt.date_closed,
                   qdt.org_id,
                   qdt.incident_owner,
                   qdt.incident_country_code,
                   qdt.address1,
                   qdt.city,
                   qdt.state,
                   qdt.zip_code,
                   qdt.instance_serial_number,
                   qdt.instance_product_name,
                   qdt.instance_item_product_descr,
                   qdt.install_date,
                   qdt.severity,
                   qdt.incident_problem_code,
                   qdt.incident_problem_desc,
                   qdt.incident_resolution_code,
                   qdt.incident_resolution_desc,
                   qdt.incident_type,
                   qdt.incident_status_id,
                   qdt.incident_status_meaning,
                   qdt.logged_by,
                   qdt.last_update_date,
                   qdt.incident_context,
                   qdt.problem_summary,
                   qdt.total_submitted,
                   qdt.pir_need,
                   qdt.process_phase,
                   qdt.death,
                   qdt.injury,
                   qdt.appendix_a,
                   qdt.contract_number,
                   qdt.account_number,
                   qdt.contact_party_name,
                   qdt.primary_phone_area_code,
                   qdt.primary_phone_number,
                   qdt.email_address,
                   qdt.url,
                   qdt.task_id,
                   qdt.task_number,
                   qdt.task_name,
                   qdt.task_planned_start_date,
                   qdt.task_actual_start_date,
                   qdt.task_actual_end_date,
                   qdt.response_time_in_hrs,
                   qdt.task_owner,
                   qdt.task_status,
                   qdt.task_priority,
                   qdt.repair_status_meaning,
                   qdt.debrief_header_id,
                   qdt.debrief_assignee_resource,
                   qdt.debrief_assignee_country,
                   csn.note,
                   csn.note_type_meaning,
                   NULL debrief_line_id,
                   NULL debrief_line_number,
                   NULL debrif_serial_number,
                   NULL billing_category,
                   NULL material_used,
                   NULL material_used_description,
                   NULL material_used_quantity,
                   NULL material_used_mst_cost,
                   NULL labor_hours,
                   NULL labor_item,
                   NULL labor_item_description,
                   NULL expense_item,
                   NULL expense_item_description,
                   NULL expense_item_amount,
                   NULL expenses_currency_code,
                     1
                   - ROW_NUMBER ()
                     OVER (
                        PARTITION BY qdt.incident_id
                        ORDER BY
                           qdt.task_number DESC, csn.note_type_meaning DESC)
                      row_sort
              FROM haemo.xxha_qd_quality_data_tasks qdt,
                   apps.cs_sr_all_notes_v csn
             WHERE 1 = 1 AND qdt.incident_id = csn.incident_id;

         ln_record_count := SQL%ROWCOUNT;
      EXCEPTION
         WHEN OTHERS
         THEN
            FND_FILE.PUT_LINE (
               FND_FILE.LOG,
                  'Unexpected error occured while inserting into XXHA_QD_QUALITY_NOTE_DATA: '
               || SQLERRM);
      END;

      COMMIT;
      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            ln_record_count
         || ' - Records Successfully inserted in XXHA_QD_QUALITY_NOTE_DATA '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));
   --FND_FILE.PUT_LINE (FND_FILE.LOG,'Refreshing materialized views');

   --DBMS_SNAPSHOT.REFRESH ('APPS.MPBF_MV, APPS.XXHA_QD_QUALITY_DATA_MV, APPS.XXHA_QD_RESOLUTIONS_DATA_MV, APPS.XXHA_QD_SHIPMENT_DATA_MV');

   --FND_FILE.PUT_LINE (FND_FILE.LOG,'Materialized views refreshed: '|| TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));
   END;
END xxha_qd_get_quality_data_pkg;
/
