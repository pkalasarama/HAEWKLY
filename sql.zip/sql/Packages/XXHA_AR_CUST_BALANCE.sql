CREATE OR REPLACE PACKAGE XXHA_AR_CUST_BALANCE AUTHID CURRENT_USER AS

/*****************************************************************************************
* Package Name : XXHA_AR_CUST_BALANCE                                                    *
*                                                                                        *
* Purpose      : This package provides functions to retrieve counts for records in the   *
*                table 'XXHA_AR_CUSTOMER_BALANCE_ITF'.  This package will be used by the *
*                XML Report 'XXHA: Customer Open Balance Letter US' and                  *
*                'XXHA: Customer Open Balance Letter HK'.                                *
*                                                                                        *
* Procedures   :  P_Total                                                                *
*                 P_Owed                                                                 *
*                                                                                        *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*    XXHA_AR_CUSTOMER_BALANCE_ITF     S                                                  *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    -------------------------------------  *
* 1.0        01-JUN-2011     B. Marcoux           Initial Version                        *
*                                                                                        *
*****************************************************************************************/

/* globals for cache */
gv_dollars              NUMBER           := NULL;


/* ********************************************************************************************************************* */
/* Retrieves Total Balance for all invoices associated with customer                                                     */
PROCEDURE P_Total (P_REQUEST_ID        IN  XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                   P_ORG_LOCATION_ID   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                   P_CUSTOMER_NUMBER   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                   P_BILLTO_NUMBER     IN  XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                   P_TRX_CURRENCY_CODE IN  XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE,
                   P_DOLLARS           OUT XXHA_AR_CUSTOMER_BALANCE_ITF.TRANS_AMOUNT_REMAINING%TYPE) ;

FUNCTION F_Total  (P_REQUEST_ID        IN  XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                   P_ORG_LOCATION_ID   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                   P_CUSTOMER_NUMBER   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                   P_BILLTO_NUMBER     IN  XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                   P_TRX_CURRENCY_CODE IN  XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE)
RETURN NUMBER;


/* ********************************************************************************************************************* */
/* Retrieves Total Balance for all invoices associated with customer that are more than xxx days overdue                 */
PROCEDURE P_Owed  (P_REQUEST_ID        IN  XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                   P_ORG_LOCATION_ID   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                   P_CUSTOMER_NUMBER   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                   P_BILLTO_NUMBER     IN  XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                   P_TRX_CURRENCY_CODE IN  XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE,
                   P_DAYS              IN  XXHA_AR_CUSTOMER_BALANCE_ITF.DAYS_LATE%TYPE,
                   P_DOLLARS           OUT XXHA_AR_CUSTOMER_BALANCE_ITF.TRANS_AMOUNT_REMAINING%TYPE) ;

FUNCTION F_Owed   (P_REQUEST_ID        IN  XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                   P_ORG_LOCATION_ID   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                   P_CUSTOMER_NUMBER   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                   P_BILLTO_NUMBER     IN  XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                   P_TRX_CURRENCY_CODE IN  XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE,
                   P_DAYS              IN  XXHA_AR_CUSTOMER_BALANCE_ITF.DAYS_LATE%TYPE)
RETURN NUMBER;


END XXHA_AR_CUST_BALANCE;

/


CREATE OR REPLACE PACKAGE BODY XXHA_AR_CUST_BALANCE AS

/*****************************************************************************************
* Package Name : XXHA_AR_CUST_BALANCE                                                    *
*                                                                                        *
* Purpose      : This package provides functions to retrieve counts for records in the   *
*                table 'XXHA_AR_CUSTOMER_BALANCE_ITF'.  This package will be used by the *
*                XML Report 'XXHA: Customer Open Balance Letter US' and                  *
*                'XXHA: Customer Open Balance Letter HK'.                                *
*                                                                                        *
* Procedures   :  P_Total                                                                *
*                 P_Owed                                                                 *
*                                                                                        *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*    XXHA_AR_CUSTOMER_BALANCE_ITF     S                                                  *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    -------------------------------------  *
* 1.0        01-JUN-2011     B. Marcoux           Initial Version                        *
*                                                                                        *
*****************************************************************************************/

PROCEDURE P_Total (P_REQUEST_ID        IN  XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                   P_ORG_LOCATION_ID   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                   P_CUSTOMER_NUMBER   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                   P_BILLTO_NUMBER     IN  XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                   P_TRX_CURRENCY_CODE IN  XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE,
                   P_DOLLARS           OUT XXHA_AR_CUSTOMER_BALANCE_ITF.TRANS_AMOUNT_REMAINING%TYPE)  AS

BEGIN

SELECT

SUM(trans_amount_remaining + on_account_credit_amount)

INTO
    P_Dollars

FROM
    XXHA_AR_CUSTOMER_BALANCE_ITF   AR

WHERE
    ar.Request_ID        = P_REQUEST_ID
AND ar.Org_Location_ID   = P_ORG_LOCATION_ID
AND ar.Customer_Number   = P_CUSTOMER_NUMBER
AND ar.BillTo_Number     = P_BILLTO_NUMBER
AND ar.TRX_Currency_Code = P_TRX_CURRENCY_CODE
;

END P_Total;

FUNCTION F_Total (P_REQUEST_ID        IN XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                  P_ORG_LOCATION_ID   IN XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                  P_CUSTOMER_NUMBER   IN XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                  P_BILLTO_NUMBER     IN XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                  P_TRX_CURRENCY_CODE IN XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE)
RETURN NUMBER AS
BEGIN

    P_Total(P_REQUEST_ID, P_ORG_LOCATION_ID, P_CUSTOMER_NUMBER, P_BILLTO_NUMBER, P_TRX_CURRENCY_CODE, gv_dollars);

    RETURN(gv_dollars);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Total;

/* ********************************************************************************************************************* */
PROCEDURE P_Owed  (P_REQUEST_ID        IN  XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                   P_ORG_LOCATION_ID   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                   P_CUSTOMER_NUMBER   IN  XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                   P_BILLTO_NUMBER     IN  XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                   P_TRX_CURRENCY_CODE IN  XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE,
                   P_DAYS              IN  XXHA_AR_CUSTOMER_BALANCE_ITF.DAYS_LATE%TYPE,
                   P_DOLLARS           OUT XXHA_AR_CUSTOMER_BALANCE_ITF.TRANS_AMOUNT_REMAINING%TYPE)  AS

BEGIN

SELECT

SUM(trans_amount_remaining + on_account_credit_amount)

INTO
    P_DOLLARS

FROM
    XXHA_AR_CUSTOMER_BALANCE_ITF   AR

WHERE
    ar.Request_ID        =  P_REQUEST_ID
AND ar.Org_Location_ID   =  P_ORG_LOCATION_ID
AND ar.Customer_Number   =  P_CUSTOMER_NUMBER
AND ar.BillTo_Number     =  P_BILLTO_NUMBER
AND ar.TRX_Currency_Code =  P_TRX_CURRENCY_CODE
AND ar.Days_Late         >= P_DAYS
;

END P_Owed;

FUNCTION F_Owed  (P_REQUEST_ID        IN XXHA_AR_CUSTOMER_BALANCE_ITF.REQUEST_ID%TYPE,
                  P_ORG_LOCATION_ID   IN XXHA_AR_CUSTOMER_BALANCE_ITF.ORG_LOCATION_ID%TYPE,
                  P_CUSTOMER_NUMBER   IN XXHA_AR_CUSTOMER_BALANCE_ITF.CUSTOMER_NUMBER%TYPE,
                  P_BILLTO_NUMBER     IN XXHA_AR_CUSTOMER_BALANCE_ITF.BILLTO_NUMBER%TYPE,
                  P_TRX_CURRENCY_CODE IN XXHA_AR_CUSTOMER_BALANCE_ITF.TRX_CURRENCY_CODE%TYPE,
                  P_DAYS              IN XXHA_AR_CUSTOMER_BALANCE_ITF.DAYS_LATE%TYPE)
RETURN NUMBER AS
BEGIN

    P_Owed(P_REQUEST_ID, P_ORG_LOCATION_ID, P_CUSTOMER_NUMBER, P_BILLTO_NUMBER, P_TRX_CURRENCY_CODE, P_DAYS, gv_dollars);

    RETURN(gv_dollars);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Owed;


END XXHA_AR_CUST_BALANCE;

/
