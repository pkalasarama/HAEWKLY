CREATE OR REPLACE PACKAGE      XXHA_GL_JOURNAL_IMPORT_PK
-- +===================================================================+
-- |                       Oracle NAIO (India)                         |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- | Name             :  XXHA_GL_JOURNAL_IMPORT_PK                     |
-- | Description      :  Package Specification consisting of a Main    |
-- |                     Procedure,Validation Procedure to move the    |
-- |                     data from the Legacy System to Oracle General |
-- |                     Ledger base Tables                            |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  11-11-2006  Narendra.S        Initial draft version      |
-- |1.0       29-11-2006  Narendra.S        After Review               |
-- |                                                                   |
-- +===================================================================+
AS


-------------------------------------------------------------------------
--The Global Variables
-------------------------------------------------------------------------
gc_attribute1               xxha_common_errors.attribute1%TYPE;                                                      --Attribute1 insert in common error table
gc_attribute2               xxha_common_errors.attribute2%TYPE;                                                      --Attribute2 insert in common error table
gc_attribute3               xxha_common_errors.attribute3%TYPE;                                                      --Attribute3 insert in common error table
gc_attribute4               xxha_common_errors.attribute4%TYPE;                                                      --Attribute4 insert in common error table
gc_attribute5               xxha_common_errors.attribute5%TYPE;                                                      --Attribute5 insert in common error table
gc_conc_name                fnd_concurrent_programs.concurrent_program_name%TYPE :='XXHA_GL_JOURNAL_INTERFACE';      --Concurrent program name to delete the records from common error table
gc_comments                 xxha_common_errors.comments%TYPE;                                                        --Comments   insert in common error table
gc_error_code               xxha_common_errors.error_code%TYPE;                                                      --Error_code insert in common error table
gc_error_msg                xxha_common_errors.error_msg%TYPE;                                                       --Error_msg  insert in common error table
gc_log_message              VARCHAR2(2000);                                                                          --Variable to hold Log Messages
gc_record_identifier        xxha_common_errors.record_identifier%TYPE;                                               --Record identifier of staging table
gc_status                   VARCHAR2(2);                                                                             --Variable to get the Status of the Error Table insertion procedure
gc_table_name               xxha_common_errors.table_name%TYPE        :='XXHA_GL_JOURNALS_INT';                      --Variable to get Staging Table Name
gn_login_id                 fnd_logins.login_id%type := FND_GLOBAL.LOGIN_ID;                                         --Login name for running conversion program
gn_request_id               fnd_concurrent_requests.request_id%TYPE      := FND_GLOBAL.CONC_REQUEST_ID;              --Request Id of the Main Concurrent Program
gn_child_request1_id        fnd_concurrent_requests.request_id%TYPE      := FND_GLOBAL.CONC_REQUEST_ID;              --Variable to hold the request id of the Loader Concurrent Program
gn_child_request2_id        fnd_concurrent_requests.request_id%TYPE      := FND_GLOBAL.CONC_REQUEST_ID;              --Variable to hold the request id of the Validations Concurrent Program
gc_file_name                VARCHAR2(100);                                                                           --Variable to hold the file name
gn_record_number            xxha_gl_journals_int.rec_num%TYPE:=NULL;                                                 --Record_number of staging table
gn_user_id                  fnd_user.user_id%TYPE            := FND_GLOBAL.USER_ID;                                  --User name for running Interface program
gn_application_id           fnd_application.application_id%TYPE;                                                     --Variable to hold the Application Id
gn_sob_id                   gl_sets_of_books.set_of_books_id%TYPE        := FND_PROFILE.VALUE('GL_SET_OF_BKS_ID');   --Variable to hold the Set Of Books Id
gn_chart_of_accounts_id     gl_sets_of_books.chart_of_accounts_id%TYPE;                                              --Variable to hold the Chart Of Accounts Id
gn_ccid                     gl_code_combinations.code_combination_id%TYPE;                                           --Variable to hold the Code combination Id
gn_no_of_batches            NUMBER := 0;                                                                             --Variable to hold the No. Of Batches in the staging table
gn_batch_count              NUMBER := 0;                                                                             --Variable to hold the batch count
gn_invalid_batches          NUMBER := 0;                                                                             --Variable to hold the number of invalid batches


--Procedure to update the group_id and file_name columns in the XXHA_GL_JOURNALS_INT table
--This procedure will call from Loader Concurrent program
PROCEDURE UPDATE_STAGING_TABLE(
                               p_file_name  IN  VARCHAR2
                              ,p_request_id IN  NUMBER
                              );

--Procedure to Sumbit the loader and validations concurrent programs.
PROCEDURE ADPTOGL_JOURNALS_MAIN(
                                x_err_buf           OUT VARCHAR2
                               ,x_ret_code          OUT VARCHAR2
                               ,p_directory         IN  VARCHAR2
                               ,p_arc_directory     IN  VARCHAR2
                               ,p_debug_flag        IN  VARCHAR2
                               ,p_purge_flag        IN  VARCHAR2
                               );

--Procedure to Validate and process ADP to GL Journal records
PROCEDURE VALIDATE_ADPTOGL_JOURNALS(
                                    x_err_buf    OUT VARCHAR2
                                   ,x_ret_code   OUT VARCHAR2
                                   ,p_debug_flag IN  VARCHAR2
                                   ,p_purge_flag IN  VARCHAR2
                                   );


END XXHA_GL_JOURNAL_IMPORT_PK;    --End of the XXHA_GL_JOURNAL_IMPORT_PK Specification

/


CREATE OR REPLACE PACKAGE BODY      XXHA_GL_JOURNAL_IMPORT_PK
-- +===================================================================+
-- |                       Oracle NAIO (India)                         |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- | Name             :  XXHA_GL_JOURNAL_IMPORT_PK                     |
-- | Description      :  Package Body consisting of a Main Procedure,  |
-- |                     Validation Procedure and a Move procedure     |
-- |                     to move the data from the Legacy System to    |
-- |                     Oracle Inventory base Tables                  |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  11-11-2006  Narendra.S        Initial draft version      |
-- |1.0       29-11-2006  Narendra.S        After Review               |
-- |                                                                   |
-- +===================================================================+
AS
-- +==============================================================================+
-- | Name       : INSERT_ERROR                                                    |
-- |                                                                              |
-- | Description: The Local Procedure which inserts the errors into the           |
-- |              error table                                                     |
-- |                                                                              |
-- | Call From  : VALIDATE_ADPTOGL_JOURNALS,MOVE_ADPTOGL_JOURNALS and             |
-- |              VALIDATE_SETUP                                                  |
-- | PARAMETERS:                                                                  |
-- |   IN: None                                                                   |
-- |  OUT: None                                                                   |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PRIVATE                                                               |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE INSERT_ERROR
IS
BEGIN
   XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(
                                              gn_child_request2_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                             );
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in the local procedure INSERT_ERROR. Error is: ' ||SQLERRM);
END INSERT_ERROR;     --End of the INSERT_ERROR procedure
-- +==============================================================================+
-- | Name       : UPDATE_PROCESSING_STATUS                                        |
-- |                                                                              |
-- | Description: The Local Procedure which updates the Staging table             |
-- |              processing status whenever there is an error                    |
-- |                                                                              |
-- | Call From  : MOVE_ADPTOGL_JOURNALS                                           |
-- | PARAMETERS:                                                                  |
-- |   IN: p_rec_num                                                              |
-- |       p_rec_status                                                           |
-- |  OUT:                                                                        |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PRIVATE                                                               |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE UPDATE_PROCESSING_STATUS(
                                   p_recnum     NUMBER
                                  ,p_rec_status VARCHAR2
                                  )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   IF ( p_rec_status = 'PE' ) THEN
       UPDATE xxha_gl_journals_int XGJI
       SET    XGJI.process_flag='PE'
       WHERE  XGJI.rec_num=p_recnum;
   END IF;
COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in the local procedure UPDATE_PROCESSING_STATUS  Error is: ' ||SQLERRM);
END UPDATE_PROCESSING_STATUS; --End of the UPDATE_PROCESSING_STATUS procedure
-- +==============================================================================+
-- | Name: VALIDATE_SETUP                                                         |
-- |                                                                              |
-- | DESCRIPTION: The Local Procedure which validates the Applications Setup      |
-- |                                                                              |
-- | Call From  : VALIDATE_ADPTOGL_JOURNALS                                       |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_debug_flag                                                           |
-- |  OUT: p_derivation_status                                                    |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PRIVATE                                                               |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE VALIDATE_SETUP(
                         p_debug_flag        IN  VARCHAR2
                        ,p_derivation_status OUT VARCHAR2
                        )
IS
BEGIN
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'Start Of Derivations');
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
-------------------------------------------------------------------------
      --Deriving the Application Id
      -------------------------------------------------------------------------
      p_derivation_status:='P';
      BEGIN
         SELECT FA.application_id
         INTO   gn_application_id
         FROM   fnd_application FA
         WHERE  FA.application_short_name ='SQLGL';
gc_log_message := 'The derivation of Application Id is successful';
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Failed to derive the Application ID for the Application Short Name: SQLGL';
         gc_comments   := 'Please contact the System Administrator';
         INSERT_ERROR;
         p_derivation_status:='F';
         gc_log_message:='SETUP-Error - Failed to derive the Application ID for the Application Short Name: SQLGL';
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
      WHEN OTHERS THEN
         gc_error_code := SQLCODE;
         gc_error_msg  := SQLERRM;
         gc_comments   := 'Please contact the System Administrator';
         INSERT_ERROR;
         p_derivation_status:='F';
         gc_log_message:= SQLERRM;
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
      END; -- end of deriving the Application Id
-------------------------------------------------------------------------
      --Deriving the Chart Of Accounts Id
      -------------------------------------------------------------------------
      BEGIN
         SELECT GSOB.chart_of_accounts_id
         into   gn_chart_of_accounts_id
         from   ---gl_sets_of_books GSOB---11i code modified
                   gl_ledgers   gsob    ---R12 Remediated
         where  ---GSOB.set_of_books_id = gn_sob_id;---11i code modified
                   gsob.ledger_id   = gn_sob_id;---R12 Remediated
          gc_log_message := 'The derivation of Chart Of Accounts Id is successful';
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Failed to derive the Chart Of Accounts for the SOB associated with the Login';
         gc_comments   := 'Please check the GL: Set Of Books Profile Option';
         INSERT_ERROR;
         p_derivation_status:='F';
         gc_log_message:='SETUP-Error - Failed to derive the Chart Of Accounts for the SOB associated with the Login';
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
      WHEN OTHERS THEN
         gc_error_code := SQLCODE;
         gc_error_msg  := SQLERRM;
         gc_comments   := 'Please check the Set Of Books associated with the responsibility';
         INSERT_ERROR;
         p_derivation_status:='F';
         gc_log_message:= SQLERRM;
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
      END; -- end of Deriving the Chart Of Accounts Id
XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'End Of Derivations');

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in the local procedure VALIDATE_SETUP. Error is: ' ||SQLERRM);
END VALIDATE_SETUP;     --End of VALIDATE_SETUP Procedure
-- +==============================================================================+
-- | Name       : MOVE_ADPTOGL_JOURNALS                                           |
-- |                                                                              |
-- | Description: Procedure to insert the valid records into the interface table  |
-- |                                                                              |
-- | Call From  : VALIDATE_ADPTOGL_JOURNALS                                       |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_debug_flag                                                           |
-- |       p_group_id                                                             |
-- |  OUT: x_ret_code                                                             |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PRIVATE                                                               |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE MOVE_ADPTOGL_JOURNALS(
                                p_debug_flag IN  VARCHAR2
                               ,p_group_id   IN  NUMBER
                               ,x_ret_code   OUT VARCHAR2
                               )
IS
--The Local Variables
lc_rec_status                  VARCHAR2(3);    --Variable to hold the Record Status
ln_invalid_processing_rec      NUMBER := 0;    --Variable to hold the Total No.of invalid processing Records
ln_total_processing_rec        NUMBER := 0;    --Variable to hold the Total No.of processing Records
ln_valid_processing_rec        NUMBER := 0;    --Variable to hold the Total No.of valid processing Records

--The Cursor on the Staging Table XXHA_GL_JOURNALS_INT
CURSOR lcu_journals_processing(group_id NUMBER)
IS
SELECT *
FROM   xxha_gl_journals_int XGJI
WHERE  XGJI.process_flag='VS'
AND    XGJI.group_id=group_id;
BEGIN
XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'Start Of processing the records into the interface table');
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
FOR lr_journals IN lcu_journals_processing(p_group_id)
      LOOP
-------------------------------------------------------------------------
         --Inserting the valid records into the Interface Table GL_INTERFACE
         -------------------------------------------------------------------------
         gc_record_identifier := lr_journals.file_name;
         gn_record_number     := lr_journals.rec_num;
         lc_rec_status        := 'PS';
BEGIN
gc_log_message := 'Processing the record '||lr_journals.rec_num||' into GL_INTERFACE table';
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
INSERT INTO gl_interface(
                                     status
                                    ---,set_of_books_id---11i code modified
                                    ,ledger_id         ---R12 Remediated
                                    ,accounting_date
                                    ,currency_code
                                    ,date_created
                                    ,created_by
                                    ,actual_flag
                                    ,user_je_category_name
                                    ,user_je_source_name
                                    ,entered_dr
                                    ,entered_cr
                                    ,code_combination_id
                                    ,group_id
                                    ,reference1
                                   )
                                   VALUES
                                   (
                                    lr_journals.status
                                   ,lr_journals.set_of_books_id
                                   ,lr_journals.accounting_date
                                   ,lr_journals.currency_code
                                   ,SYSDATE
                                   ,gn_user_id
                                   ,lr_journals.actual_flag
                                   ,lr_journals.user_je_category_name
                                   ,lr_journals.user_je_source_name
                                   ,lr_journals.entered_dr
                                   ,lr_journals.entered_cr
                                   ,lr_journals.code_combination_id
                                   ,lr_journals.group_id
                                   ,lr_journals.file_name
                                   );
         EXCEPTION
         WHEN OTHERS THEN
            gc_error_code := SQLCODE;
            gc_error_msg  := SQLERRM;
            gc_comments   := 'Please Check the data for the file '||gc_file_name;
            INSERT_ERROR;
            lc_rec_status:='PE';
            UPDATE_PROCESSING_STATUS(gn_record_number,lc_rec_status);
         END;
END LOOP;-- End of the processing Loop
--Counting the total processing records
   SELECT COUNT(*)
   INTO   ln_total_processing_rec
   FROM   xxha_gl_journals_int
   WHERE  group_id=p_group_id;
--Counting the total invalid processing records
   SELECT COUNT(*)
   INTO   ln_invalid_processing_rec
   FROM   xxha_gl_journals_int
   WHERE  process_flag = 'PE'
   AND    group_id=p_group_id;
gc_log_message := 'If there are invalid processing records it rollbacks the data and sets the concurrent program status to warning';
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
IF ( ln_invalid_processing_rec > 0 ) THEN
      ROLLBACK;
      gn_invalid_batches := gn_invalid_batches + 1;
      --Updating the control table xxha_control column process_flag status
      UPDATE xxha_control XC
      SET    XC.status_flag='PE'
      WHERE  XC.interface_id=p_group_id;
   ELSE
      --Updating the control table xxha_control column process_flag status
      UPDATE xxha_control XC
      SET    XC.status_flag='PS'
      WHERE  XC.interface_id=p_group_id;
   END IF; --End of ln_invalid_processing_rec > 0
--Updating the status of staging table
   UPDATE xxha_gl_journals_int XGJI
   SET    XGJI.process_flag ='PS'
   WHERE  XGJI.process_flag <> 'PE'
   AND    group_id=p_group_id;
--Counting the total valid processing records
   SELECT COUNT(*)
   INTO   ln_valid_processing_rec
   FROM   xxha_gl_journals_int
   WHERE  process_flag = 'PS'
   AND    group_id=p_group_id;
 COMMIT;
XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'End Of processing the records into the interface table');
-------------------------------------------------------------------------
   --Summary Of Data Processing Process
   -------------------------------------------------------------------------
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of '||gc_file_name||' Records Processed');
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records                                            :'||ln_total_processing_rec);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'The Total Records Processed to interface table           :'||ln_valid_processing_rec);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'The Total Records failed to process to interface table   :'||ln_invalid_processing_rec);
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_GL_JOURNAL_IMPORT_PK.MOVE_ADPTOGL_JOURNALS: ' || SQLERRM);
END MOVE_ADPTOGL_JOURNALS;    --End Of the MOVE_ADPTOGL_JOURNALS Procedure
-- +==============================================================================+
-- | Name       : UPDATE_STAGING_TABLE                                            |
-- |                                                                              |
-- | Description: Procedure to submit loader and validations programs             |
-- |                                                                              |
-- | Call From  : Loader Concurrent Program                                       |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_file_name                                                            |
-- |       p_request_id                                                           |
-- |  OUT:                                                                        |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PUBLIC                                                                |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE UPDATE_STAGING_TABLE(
                               p_file_name  IN  VARCHAR2
                              ,p_request_id IN  NUMBER
                              )
IS
--local variables
ln_group_id                gl_interface.group_id%TYPE := 0;          --Variable to hold the GroupId value
ln_record_count            NUMBER := 0;                              --Variable to hold the No. of Records for a Batch
BEGIN
   SELECT XC.interface_id
   INTO   ln_group_id
   FROM   xxha_control XC
   WHERE  XC.file_name   = p_file_name
   AND    XC.status_flag = 'N';
UPDATE xxha_gl_journals_int XGJI
   SET    XGJI.group_id  = ln_group_id
         ,XGJI.file_name = UPPER(p_file_name)
   WHERE  XGJI.group_id IS NULL;
COMMIT;
SELECT COUNT(*)
   INTO   ln_record_count
   FROM   xxha_gl_journals_int
   WHERE  group_id=ln_group_id;
UPDATE xxha_control XC
   SET    XC.record_count = ln_record_count
         ,XC.request_id   = p_request_id
   WHERE  XC.interface_id=ln_group_id;
COMMIT;
EXCEPTION
WHEN OTHERS THEN
   UPDATE xxha_control XC1
   SET    XC1.status_flag = 'Loader Error'
         ,XC1.charfld1 = 'There may be file mismatch'
         ,XC1.charfld2 = 'The O/S filename and Control Record filename'
   WHERE  XC1.interface_id = (SELECT MAX(XC2.interface_id)
                              FROM   xxha_control XC2);
   COMMIT;
END UPDATE_STAGING_TABLE;  -- End of UPDATE_STAGING_TABLE procedure
-- +==============================================================================+
-- | Name       : ADPTOGL_JOURNALS_MAIN                                           |
-- |                                                                              |
-- | Description: Procedure to submit loader and validations programs             |
-- |                                                                              |
-- | Call From  : Main Concurrent Program                                         |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_directory                                                            |
-- |       p_arc_directory                                                        |
-- |       p_debug_flag                                                           |
-- |       p_purge_flag                                                           |
-- |  OUT: x_err_buf                                                              |
-- |       x_ret_code                                                             |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PUBLIC                                                                |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE ADPTOGL_JOURNALS_MAIN(
                                x_err_buf           OUT VARCHAR2
                               ,x_ret_code          OUT VARCHAR2
                               ,p_directory         IN  VARCHAR2
                               ,p_arc_directory     IN  VARCHAR2
                               ,p_debug_flag        IN  VARCHAR2
                               ,p_purge_flag        IN  VARCHAR2
                               )
IS
--The Local variables
ln_loaded_rec_count        NUMBER := 0;                     --Variable to hold the no of records loaded from loader program
lc_loader_status_code      VARCHAR2(10);                    --Variable to hold the Loader program status code
lc_validation_status_code  VARCHAR2(10);                    --Variable to hold the Validation program status code
lc_phase_code              VARCHAR2(10);                    --Variable to hold the phase code of a concurrent program
lc_logfile                 VARCHAR2(100);                   --Variable to hold the log file name

BEGIN
gc_log_message := 'Submitting........ the "XXHA: GL Haemonetics ADP to GL Loader"';
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
--Submitting the Loader Concurrent Program
   gn_child_request1_id := FND_REQUEST.SUBMIT_REQUEST(
                                                      Application => 'HAEMO'
                                                     ,Program     => 'XXHAGLJOURNALSLOAD'
                                                     ,description =>  'Loader Program'
                                                     ,start_time  =>  TO_CHAR (SYSDATE,'DD-MON-YYYY HH24:MI:SS')
                                                     ,sub_request =>  FALSE
                                                     ,Argument1   =>  p_directory
                                                     ,Argument2   =>  p_arc_directory
                                                     );
   COMMIT;
LOOP
      BEGIN
         SELECT FCR.logfile_name
               ,FCR.status_code
               ,FCR.phase_code
         INTO   lc_logfile
               ,lc_loader_status_code
               ,lc_phase_code
         FROM   fnd_concurrent_requests FCR
         WHERE  FCR.request_id = gn_child_request1_id
         AND    FCR.phase_code = 'C';
EXIT WHEN lc_logfile IS NOT NULL;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         NULL;
      END;
   END LOOP;--End of the Loop
COMMIT;
SELECT COUNT(*)
   INTO   ln_loaded_rec_count
   FROM   xxha_gl_journals_int;
IF ( lc_phase_code = 'C' AND ln_loaded_rec_count > 0 ) THEN
gc_log_message := 'Submitting........ the "XXHA: GL Haemonetics ADP to GL Interface"';
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
--Submitting the Validations Concurrent Program
      gn_child_request2_id := FND_REQUEST.SUBMIT_REQUEST(
                                                         Application => 'HAEMO'
                                                        ,Program     => 'XXHA_GL_JOURNAL_INTERFACE'
                                                        ,description =>  'Validations Program'
                                                        ,start_time  =>  TO_CHAR (SYSDATE,'DD-MON-YYYY HH24:MI:SS')
                                                        ,sub_request =>  FALSE
                                                        ,Argument1   =>  p_debug_flag
                                                        ,Argument2   =>  p_purge_flag
                                                       );

      COMMIT;
      LOOP
         BEGIN
           SELECT FCR.logfile_name,FCR.status_code
           INTO   lc_logfile, lc_validation_status_code
           FROM   fnd_concurrent_requests FCR
           WHERE  FCR.request_id = gn_child_request2_id
           AND    FCR.phase_code = 'C';
 EXIT WHEN lc_logfile IS NOT NULL;
         EXCEPTION
         WHEN NO_DATA_FOUND THEN
            NULL;
         END;
      END LOOP;--End of the Loop
COMMIT;
IF ( lc_loader_status_code = 'E' OR lc_validation_status_code = 'E' ) THEN
         x_ret_code := 2;        --Setting the Concurrent program status to Error
      ELSIF ( lc_loader_status_code = 'C' AND lc_validation_status_code = 'G' ) THEN
         x_ret_code := 1;        --Setting the Concurrent program status to Warning
      ELSIF ( lc_loader_status_code = 'C' AND lc_validation_status_code = 'C' ) THEN
         x_ret_code := 0;        --Setting the Concurrent program status to Normal
      END IF;
   ELSE
      x_ret_code := 2;
   END IF;   --End of lc_phase_code = 'C' AND ln_loaded_rec_count > 0
END ADPTOGL_JOURNALS_MAIN;   --End Of the ADPTOGL_JOURNALS_MAIN Procedure
-- +==============================================================================+
-- | Name       : VALIDATE_ADPTOGL_JOURNALS                                       |
-- |                                                                              |
-- | Description: Procedure to perform validations on staging table               |
-- |                                                                              |
-- | Call From  : Validations Concurrent Program                                  |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_debug_flag                                                           |
-- |       p_purge_flag                                                           |
-- |  OUT: x_err_buf                                                              |
-- |       x_ret_code                                                             |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PUBLIC                                                                |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE VALIDATE_ADPTOGL_JOURNALS(
                                    x_err_buf    OUT VARCHAR2
                                   ,x_ret_code   OUT VARCHAR2
                                   ,p_debug_flag IN  VARCHAR2
                                   ,p_purge_flag IN  VARCHAR2
                                   )
IS
--The Local Variables
---ln_set_of_books_id     gl_sets_of_books.set_of_books_id%TYPE;    --Variable to hold the Set Of Books Id---11icode modified
ln_set_of_books_id        gl_ledgers.ledger_id%TYPE;    --Variable to hold the Ledger_id (Set Of Books Id)---R12 Remediated
lc_cal_open_flag          gl_period_statuses.closing_status%TYPE;   --Variable to hold the Closing Status of the Accounting Calendar
lc_currency_code          fnd_currencies.currency_code%type;        --Variable to hold the Currency Code
---lc_sob_currency       gl_sets_of_books.currency_code%TYPE;      --Variable to hold the SOB Currency Code---11icodemodified
lc_sob_currency                 gl_ledgers.currency_code%TYPE;      --Variable to hold the SOB Currency Code---R12 Remediated
ln_currency_precision           fnd_currencies.precision%TYPE;            --Variable to hold the Currency Precision
ln_dr_precision                 fnd_currencies.precision%TYPE;            --Variable to hold the Debit Amount Precision
ln_cr_precision                 fnd_currencies.precision%TYPE;            --Variable to hold the Credit Amount Precision
ln_dr_precision_pos             NUMBER := 0;                              --Variable to hold the Debit Amount Precision Position
ln_cr_precision_pos             NUMBER := 0;                              --Variable to hold the Credit Amount Precision Position
lc_journal_category             gl_je_categories.je_category_name%TYPE;   --Variable to hold the Journal Category
lc_journal_source               gl_je_sources.je_source_name%TYPE;        --Variable to hold the Journal Source
lc_flex_value                   fnd_flex_values.flex_value%TYPE;          --Variable to hold the Accounting segment value
lc_seg_value                    fnd_flex_values.flex_value%TYPE;          --Variable to hold the Staging table Accounting segment value
lc_seg_values_exists            VARCHAR2(1) := 'N';                       --Variable to hold the Accounting segment values exist flag
lc_concat_segments              VARCHAR2(1000);                           --Variable to hold the Inventory Distribution Code combination
ln_debit                        gl_je_lines.entered_dr%TYPE;              --Variable to hold the Entered Debit
ln_credit                       gl_je_lines.entered_cr%TYPE;              --Variable to hold the Entered Credit
ln_enterd_dr_sum                NUMBER := 0;                              --Variable to hold the Entered Debit Total
ln_enterd_cr_sum                NUMBER := 0;                              --Variable to hold the Entered Credit Total
ln_batch_dr_total               NUMBER := 0;                              --Variable to hold the Batch Debit Total
ln_batch_cr_total               NUMBER := 0;                              --Variable to hold the Batch Credit Total
lc_batch_validation_flag        VARCHAR2(2);                              --Variable to hold the Batch validation status
lc_batch_validation_flag1       VARCHAR2(2);                              --Variable to hold the Batch validation status for Scenario1
lc_batch_validation_flag2       VARCHAR2(2);                              --Variable to hold the Batch validation status for Scenario2
lc_batch_validation_flag3       VARCHAR2(2);                              --Variable to hold the Batch validation status for Scenario3
lc_batch_validation_flag4       VARCHAR2(2);                              --Variable to hold the Batch validation status for Scenario3
ln_group_id                     gl_interface.group_id%TYPE;               --Variable to hold the Interface Group Id
lc_validation_status            VARCHAR2(3);                              --Variable to hold the Validation Status
lc_derivation_status            VARCHAR2(3);                              --Variable to hold the Derivation Status
ln_total_rec                    NUMBER := 0;                              --Variable to hold the Total No. Of Records in the Staging Table
ln_valid_rec                    NUMBER := 0;                              --Variable to hold the Total No. Of Valid Records in the Staging Table
ln_invalid_rec                  NUMBER := 0;                              --Variable to hold the Total No. Of Invalid Records in the Staging Table
lc_debug_flag                   VARCHAR2(2);                              --Variable to hold the debug flag
ln_no_of_distinct_rows          NUMBER := 0;                              --Variable to hold the number of distinct rows from the validate once cursor
lc_validate_once_flag           VARCHAR2(1);                              --Variable to hold the validate once block success flag
----------------------------------------------
--Cursor to get records from the Control Table
----------------------------------------------
CURSOR lcu_journals_control
IS
SELECT *
FROM   xxha_control XC
WHERE  XC.status_flag = 'N';
----------------------------------------------
--Cursor to get records from the Staging Table
----------------------------------------------
CURSOR lcu_journals_validate_once(p_group_id NUMBER)
IS
SELECT DISTINCT XGJI.Set_of_books_name
               ,XGJI.Currency_code
               ,XGJI.User_je_category_name
               ,XGJI.User_je_source_name
FROM   xxha_gl_journals_int XGJI
WHERE  XGJI.group_id = p_group_id;
----------------------------------------------
--Cursor to get records from the Staging Table
----------------------------------------------
--The Cursor on the Staging Table XXHA_GL_JOURNALS_INT
CURSOR lcu_journals_validate(p_group_id NUMBER)
IS
SELECT *
FROM   xxha_gl_journals_int XGJI
WHERE  XGJI.group_id = p_group_id;
--The Cursor for Value Set Values validation
CURSOR lcu_vs
IS
SELECT   FFVS.flex_value_set_name
FROM     fnd_id_flex_segments FIFS
        ,fnd_flex_value_sets FFVS
WHERE    FIFS.flex_value_set_id = FFVS.flex_value_set_id
AND      FIFS.id_flex_code='GL#'
AND      FIFS.id_flex_num=gn_chart_of_accounts_id
AND      FIFS.application_id=gn_application_id
ORDER BY FIFS.application_column_name;
BEGIN
--Purging the Error Table Data
   gc_log_message := 'Purging the Error Table data';
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
IF ( p_purge_flag = 'Y' ) THEN
         XXHA_COMMON_UTILITIES_PKG.DELETE_ERROR_PRC(gc_conc_name);
      END IF;
COMMIT;
gc_log_message := 'Calling the VALIDATE_SETUP Procedure';
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
   lc_debug_flag := p_debug_flag;
--Calling the VALIDATE_SETUP Procedure
   VALIDATE_SETUP(lc_debug_flag,lc_derivation_status);
-------------------------------------------------------------------------
   --The Validations on the Staging Table
   -------------------------------------------------------------------------
   gc_log_message := 'If validation of SetUp fails then the this Interface Program ends with warning else it is going to perform validations';
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
IF ( lc_derivation_status = 'F' ) THEN
      x_ret_code:=2;              --Setting the Concurrent Program status to Completed with Error
      XXHA_COMMON_UTILITIES_PKG.LAUNCH_ERROR_REPORT_PRC(gn_child_request2_id,'ADP to GL Interface','BatchName');
   ELSE
BEGIN
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'                                                           ');
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'Start Of Validations On Staging Table XXHA_GL_JOURNALS_INT');
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
SELECT COUNT(*)
         INTO   gn_no_of_batches
         FROM   xxha_control
         WHERE  status_flag='N';
FOR lr_journals_control IN lcu_journals_control                    --Start of Control Loop
         LOOP
 gc_record_identifier:= lr_journals_control.file_name;
            lc_validation_status:='VS';
gc_log_message := '***********Batch Debit Toal and Batch Credit Total validation for the file******* '||lr_journals_control.file_name;
            XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
SELECT SUM(XGJI.entered_dr)
                  ,SUM(XGJI.entered_cr)
            INTO   ln_enterd_dr_sum
                  ,ln_enterd_cr_sum
            FROM   xxha_gl_journals_int XGJI
            WHERE  XGJI.group_id=lr_journals_control.interface_id;

            ln_batch_dr_total := lr_journals_control.control_total1;
            ln_batch_cr_total := lr_journals_control.control_total2;
-------------------------------------------------------------------------
            --Validating the Batch Debit Toal and Batch Credit Total - Scenario 1
            -------------------------------------------------------------------------
            BEGIN

               IF ( ln_batch_dr_total = ln_batch_cr_total ) THEN
                  lc_batch_validation_flag1:='Y';
                  gc_log_message := 'The Batch Totals validation is successful for Scenario 1';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               ELSE
                  gc_error_code := 'DataFile-Error';
                  gc_error_msg  := 'Total Debit and Credit Amounts in the trailer record of the data file do not match';
                  gc_comments   := 'Please check the Control Record in the file '||lr_journals_control.file_name;
                  INSERT_ERROR;
                  lc_batch_validation_flag1:='N';
                  gc_log_message:= 'DataFile-Error - Total Debit and Credit Amounts in the trailer record of the data file do not match';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               END IF;
            EXCEPTION
            WHEN OTHERS THEN
               gc_error_code := SQLCODE;
               gc_error_msg  := SQLERRM;
               gc_comments   := 'Please check the data in the Control Record of the file '||lr_journals_control.file_name;
               INSERT_ERROR;
               lc_batch_validation_flag1:='N';
               gc_log_message:= SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
            END; -- End of Validating the Batch Debit Toal and Batch Credit Total - Scenario 1
-------------------------------------------------------------------------
            --Validating the Batch Debit Toal and Batch Credit Total - Scenario 2
            -------------------------------------------------------------------------
            BEGIN
               IF ( ln_enterd_dr_sum = ln_enterd_cr_sum ) THEN
                  lc_batch_validation_flag2:='Y';
                  gc_log_message := 'The Batch Totals validation is successful for Scenario 2';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               ELSE
                  gc_error_code := 'DataFile-Error';
                  gc_error_msg  := 'The total of Debit and Credit amounts for all the records in the file do not match';
                  gc_comments   := 'Check the Debit and Credit amounts in the records of the file '||lr_journals_control.file_name;
                  INSERT_ERROR;
                  lc_batch_validation_flag2:='N';
                  gc_log_message:= 'DataFile-Error - The total of Debit and Credit amounts for all the records in the file do not match';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               END IF;
            EXCEPTION
            WHEN OTHERS THEN
               gc_error_code := SQLCODE;
               gc_error_msg  := SQLERRM;
               gc_comments   := 'Check the Debit and Credit amounts in the records of the file '||lr_journals_control.file_name;
               INSERT_ERROR;
               lc_batch_validation_flag2:='N';
               gc_log_message:= SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
            END;  -- End of Validating the Batch Debit Toal and Batch Credit Total - Scenario 2
-------------------------------------------------------------------------
            --Validating the Batch Debit Toal and Batch Credit Total - Scenario 3
            -------------------------------------------------------------------------
            BEGIN
               IF ( ln_enterd_dr_sum = ln_batch_dr_total ) THEN
                  lc_batch_validation_flag3:='Y';
                  gc_log_message := 'The Batch Totals validation is successful for Scenario 3';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               ELSE
                  gc_error_code := 'DataFile-Error';
                  gc_error_msg  := 'The total of Debit amount does not match the value in the Trailer record';
                  gc_comments   := 'Please check the data in the file '||lr_journals_control.file_name;
                  INSERT_ERROR;
                  lc_batch_validation_flag3:='N';
                  gc_log_message:= 'DataFile-Error - The total of Debit amount does not match the value in the Trailer record';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               END IF;--ln_enterd_dr_sum = ln_batch_dr_total

               IF ( ln_enterd_cr_sum = ln_batch_cr_total) THEN
                  lc_batch_validation_flag4:='Y';
                  gc_log_message := 'The Batch Totals validation is successful for Scenario 3';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               ELSE
                  gc_error_code := 'DataFile-Error';
                  gc_error_msg  := 'The total of Credit amount does not match the value in the Trailer record';
                  gc_comments   := 'Please check the data in the file '||lr_journals_control.file_name;
                  INSERT_ERROR;
                  lc_batch_validation_flag4:='N';
                  gc_log_message:= 'DataFile-Error - The total of Credit amount does not match the value in the Trailer record';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
               END IF; --ln_enterd_cr_sum = ln_batch_cr_total
            EXCEPTION
            WHEN OTHERS THEN
               gc_error_code := SQLCODE;
               gc_error_msg  := SQLERRM;
               gc_comments   := 'Please check the data in the file '||lr_journals_control.file_name;
               INSERT_ERROR;
               lc_batch_validation_flag:='N';
               gc_log_message:= SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
            END;  -- End of Validating the Batch Debit Toal and Batch Credit Total - Scenario 3

            --Setting the Batch Validation flag
            IF ( lc_batch_validation_flag1='N' OR lc_batch_validation_flag2='N' OR lc_batch_validation_flag3='N' OR lc_batch_validation_flag4='N' ) THEN
                 lc_batch_validation_flag:='N';
            ELSE
                 lc_batch_validation_flag:='Y';
            END IF;
gc_log_message := '***********End of Batch Debit Toal and Batch Credit Total validation for the file******* '||lr_journals_control.file_name;
            XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

gc_log_message := 'Starting.....validations for Set of Book,Accounting Date,Currency,Journal Category,Journal Source,Account Code Combination,Debit and Credit Amount';
            XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
-------------------------------------------------------------------------
            --Checking the Validate Once Cursor
            -------------------------------------------------------------------------
            BEGIN
               FOR lr_journals IN lcu_journals_validate_once(lr_journals_control.interface_id)
               LOOP
                  ln_no_of_distinct_rows := ln_no_of_distinct_rows + 1;
               END LOOP;
IF ( ln_no_of_distinct_rows > 1 ) THEN
                  gc_error_code := 'DataFile-Error';
                  gc_error_msg  := 'There is more than one value for one of the following in the File: Set of Book/Currency/Category/Source';
                  gc_comments   := 'All the records should belong to the same Set of Book, Currency, Catgory and Source';
                  INSERT_ERROR;
                  lc_validate_once_flag := 'N';
               END IF;
            EXCEPTION
            WHEN OTHERS THEN
               gc_error_code := SQLCODE;
               gc_error_msg  := SQLERRM;
               gc_comments   := 'All the records should belong to the same Set of Book, Currency, Catgory and Source, Please check the data in the file';
               INSERT_ERROR;
               lc_validation_status:= 'VE';
               lc_validate_once_flag := 'N';
               gc_log_message:= SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
            END;

--If no of distinct rows in validate once cursor is 1 then only it perform validations like Set of Book,Accounting Date,Currency,Category,Source
               IF ( lc_batch_validation_flag = 'Y' AND ln_no_of_distinct_rows = 1 ) THEN

                  FOR lr_journals IN lcu_journals_validate_once(lr_journals_control.interface_id)
                  LOOP
gc_log_message := '**********************Start of Validate Once of the file '||lr_journals_control.file_name||'*********************';
                     XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
 -------------------------------------------------------------------------
                     --Validating the Set of Books
                     -------------------------------------------------------------------------
                     begin
                        select   ---GSOB.set_of_books_id ---11i code modified
                                 gsob.ledger_id          ---R12 Remediated
                                ,GSOB.currency_code
                        INTO     ln_set_of_books_id
                                ,lc_sob_currency
                        from     ---gl_sets_of_books GSOB  ---11i code modified
                                    gl_ledgers  GSOB       ---R12 Remediated
                        where    gsob.name = lr_journals.set_of_books_name
                        ---AND      GSOB.set_of_books_id = gn_sob_id; ---11i code modified     --gn_sob_id holds the Login Responsibility's Set Of Book Id
                           AND      gsob.ledger_id   = gn_sob_id; ---R12 Remediated            --gn_sob_id holds the Login Responsibility's Set Of Book Id
                     EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        gc_error_code := 'JIE01';
                        gc_error_msg  := 'Invalid Set of Book: '||lr_journals.set_of_books_name;
                        gc_comments   := 'Please check the Set of Book';
                        INSERT_ERROR;
                        lc_validation_status:= 'VE';
                        gc_log_message      := 'JIE01-Unable to derive the Set of Books Id for '||lr_journals.set_of_books_name;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := SQLERRM;
                        INSERT_ERROR;
                        lc_validation_status:= 'VE';
                        gc_log_message      := SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;
-------------------------------------------------------------------------
                     --Validating the Currency Code
                     -------------------------------------------------------------------------
                     BEGIN
                        SELECT FC.currency_code
                              ,FC.precision
                        INTO   lc_currency_code
                              ,ln_currency_precision
                        FROM   fnd_currencies FC
                        WHERE  FC.currency_code = lr_journals.currency_code
                        AND    FC.currency_code = lc_sob_currency
                        AND    FC.enabled_flag = 'Y'
                        AND    FC.end_date_active IS NULL;
                     EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        gc_error_code := 'JIE02';
                        gc_error_msg  := 'Invalid Currency: '||lr_journals.currency_code;
                        gc_comments   := 'Please define or enable the currency';
                        INSERT_ERROR;
                        lc_validation_status:= 'VE';
                        gc_log_message      := 'JIE02-Invalid Currency '||lr_journals.currency_code;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := SQLERRM;
                        INSERT_ERROR;
                        lc_validation_status:= 'VE';
                        gc_log_message      := SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;
-------------------------------------------------------------------------
                     --Validating the Journal Category
                     -------------------------------------------------------------------------
                     BEGIN
                        SELECT GJC.user_je_category_name
                        INTO   lc_journal_category
                        FROM   gl_je_categories GJC
                        WHERE  GJC.user_je_category_name = lr_journals.user_je_category_name
                        AND    GJC.language =  USERENV('LANG');
                     EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        gc_error_code := 'JIE03';
                        gc_error_msg  := 'Invalid Journal Category: '||lr_journals.user_je_category_name;
                        gc_comments   := 'Please define the Journal Category';
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := 'JIE03-Invalid Journal Category '||lr_journals.user_je_category_name;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := SQLERRM;
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;
-------------------------------------------------------------------------
                     --Validating the Journal Source
                     -------------------------------------------------------------------------
                     BEGIN
                        SELECT GJS.user_je_source_name
                        INTO   lc_journal_source
                        FROM   gl_je_sources GJS
                        WHERE  GJS.user_je_source_name = lr_journals.user_je_source_name
                        AND    GJS.language =  USERENV('LANG');
                     EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        gc_error_code := 'JIE04';
                        gc_error_msg  := 'Invalid Journal Source: '||lr_journals.user_je_source_name;
                        gc_comments   := 'Please define the Journal Source';
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := 'JIE04-Invalid Journal Source '||lr_journals.user_je_source_name;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := SQLERRM;
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;
 --Setting the Validate Once flag
                        IF ( lc_validation_status = 'VE') THEN
                        lc_validate_once_flag := 'N';
                        ELSE
                        lc_validate_once_flag := 'Y';
                        END IF;
gc_log_message := '**********************End of Validate Once of the file '||lr_journals_control.file_name||'*********************';
                     XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

                  END LOOP; -- End of the Validate Once cursor loop

               ELSE
                  --if batch validation fails or if there are more than one distinct no. of rows then update the status flag of the control table to 'VE'
                  UPDATE xxha_control XC
                  SET    XC.status_flag='VE'
                  WHERE  XC.interface_id=lr_journals_control.interface_id;
               END IF; --End of lc_batch_validation_flag = 'Y' AND ln_no_of_distinct_rows = 1
IF ( lc_batch_validation_flag = 'Y' AND lc_validate_once_flag = 'Y' ) THEN
FOR lr_journals IN lcu_journals_validate(lr_journals_control.interface_id)
                  LOOP
gc_log_message := 'Starting..... validations for the record '||lr_journals.rec_num;
                     XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
gn_record_number    := lr_journals.rec_num;
                     --gc_record_identifier:= lr_journals.file_name;
-------------------------------------------------------------------------
                     --Validating the Accounting Date
                     -------------------------------------------------------------------------
                     BEGIN
                        SELECT GPS.closing_status
                        INTO   lc_cal_open_flag
                        FROM   gl_periods GP, gl_period_statuses GPS
                        WHERE  GP.period_set_name = 'HAE_GLOBAL_CAL'
                        AND    GP.period_name= GPS.PERIOD_NAME
                        AND    lr_journals.accounting_date BETWEEN GPS.start_date AND GPS.end_date
                        AND    GPS.closing_status = 'O'
                        and    gps.application_id = gn_application_id
                       --- AND    GPS.set_of_books_id= ln_set_of_books_id;---11i code modified
                        AND     gps.ledger_id = ln_set_of_books_id;---R12 Remediated
                     EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        gc_error_code := 'JIE05';
                        gc_error_msg  := 'The Accounting Date: '||lr_journals.accounting_date||' does not fall in an Open Accounting Period';
                        gc_comments   := 'Please open the Accounting period';
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := 'JIE05-The Accounting Date '||lr_journals.accounting_date||' does not fall in an Open Accounting Period';
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := SQLERRM;
                        INSERT_ERROR;
                        lc_validation_status:= 'VE';
                        gc_log_message      := SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;
-------------------------------------------------------------------------
                     --Validating the Account Code Combination Segment values
                     -------------------------------------------------------------------------
                     DECLARE
                        ln_segment_no                   NUMBER := 1;                --variable to hold the segment number
                        ln_valid_segment_count          NUMBER := 0;                --variable to hold the valid segment count
                     BEGIN

                        FOR lr_vs IN lcu_vs
                        LOOP
                           BEGIN
                              SELECT DECODE(ln_segment_no ,1,lr_journals.segment1,
                                                     2,lr_journals.segment2,
                                                     3,lr_journals.segment3,
                                                     4,lr_journals.segment4,
                                                     5,lr_journals.segment5,
                                                     6,lr_journals.segment6,
                                                     7,lr_journals.segment7,
                                                     8,lr_journals.segment8,
                                                     9,lr_journals.segment9)
                              INTO lc_seg_value
                              FROM DUAL;

                              SELECT  FFVV.flex_value
                              INTO    lc_flex_value
                              FROM    fnd_flex_values_vl FFVV
                                     ,fnd_flex_value_sets FFVS
                              WHERE   FFVS.flex_value_set_name = lr_vs.flex_value_set_name
                              AND     FFVV.flex_value_set_id =  FFVS.flex_value_set_id
                              AND     FFVV.flex_value = lc_seg_value
                              AND     FFVV.enabled_flag = 'Y'
                              AND     SYSDATE BETWEEN NVL (FFVV.start_date_active, SYSDATE) AND NVL (FFVV.end_date_active, SYSDATE);


                              ln_valid_segment_count := ln_valid_segment_count + 1;
                           EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                              gc_error_code := 'JIE06';
                              gc_error_msg  := 'Invalid value: '||lc_seg_value||' for the segment: '||ln_segment_no||' against the Value Set '||lr_vs.flex_value_set_name;
                              gc_comments   := 'Please check the values in the value set';
                              INSERT_ERROR;
                              lc_validation_status := 'VE';
                              gc_log_message       := 'Invalid value: '||lc_seg_value||' for the segment: '||ln_segment_no||' against the Value Set '||lr_vs.flex_value_set_name;
                              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                           WHEN OTHERS THEN
                              gc_error_code       := SQLCODE;
                              gc_error_msg        := SQLERRM;
                              INSERT_ERROR;
                              lc_validation_status := 'VE';
                              gc_log_message       := SQLERRM;
                              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                           END;
ln_segment_no  := ln_segment_no  + 1;
IF ( ln_valid_segment_count = 9 ) THEN
                           lc_seg_values_exists := 'Y';
                           ELSE
                           lc_seg_values_exists := 'N';
                           END IF;
 END LOOP;          --end of value sets loop
                     EXCEPTION
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := SQLERRM;
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;
-------------------------------------------------------------------------
                     --Validating the Account Code Combination
                     -------------------------------------------------------------------------
                     IF ( lc_seg_values_exists = 'Y' ) THEN
                        BEGIN
lc_concat_segments := lr_journals.segment1||'.'||lr_journals.segment2||'.'||lr_journals.segment3||'.'||lr_journals.segment4||'.'||
                                                 lr_journals.segment5||'.'||lr_journals.segment6||'.'||lr_journals.segment7||'.'||lr_journals.segment8||'.'||
                                                 lr_journals.segment9;

                           gn_ccid := FND_FLEX_EXT.GET_CCID(
                                                            'SQLGL'
                                                            ,'GL#'
                                                            ,gn_chart_of_accounts_id
                                                            ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
                                                            ,lc_concat_segments
                                                           );
lc_seg_values_exists := 'N';
IF gn_ccid = 0 THEN
                                 gc_error_code := 'JIE07';
                                 gc_error_msg  := 'Invalid Account Code Combination '||lc_concat_segments;
                                 gc_comments   := 'Please check the Account Code Combination';
                                 INSERT_ERROR;
                                 lc_validation_status := 'VE';
                                 gc_log_message       := 'JIE07-Invalid Account Code Combination '||lc_concat_segments;
                                 XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                              END IF;
EXCEPTION
                        WHEN OTHERS THEN
                           gc_error_code       := SQLCODE;
                           gc_error_msg        := SQLERRM;
                           INSERT_ERROR;
                           lc_validation_status := 'VE';
                           gc_log_message       := SQLERRM;
                           XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                        END;
                     ELSE
                        gn_ccid := 0;
                     END IF; --End of lc_seg_values_exists = 'Y'
-------------------------------------------------------------------------
                     --Validating the Debit Amount and Credit Amount
                     -------------------------------------------------------------------------
                     DECLARE
                      lc_dr_null  VARCHAR2(10);
                      lc_cr_null  VARCHAR2(10);
                     BEGIN
                        SELECT DECODE(lr_journals.entered_dr,0,NULL,NULL,NULL,lr_journals.entered_dr)
                              ,DECODE(lr_journals.entered_cr,0,NULL,NULL,NULL,lr_journals.entered_cr)
                        INTO   lc_dr_null
                              ,lc_cr_null
                        FROM   dual;
IF ( lc_dr_null IS NOT NULL AND lc_cr_null IS NOT NULL ) THEN
                           gc_error_code := 'JIE08';
                           gc_error_msg  := 'Both the Entered Debit and Entered Credit amounts cannot be specified';
                           gc_comments   := 'Only one value should be provided in a given line';
                           INSERT_ERROR;
                           lc_validation_status := 'VE';
                           gc_log_message       := 'JIE08-Both the Entered Debit and Entered Credit amounts cannot be specified';
                           XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                        END IF;

                        IF ( lc_dr_null IS NULL AND lc_cr_null IS NULL ) THEN
                           gc_error_code := 'JIE09';
                           gc_error_msg  := 'Both the Entered Debit and Entered Credit amounts have not been specified';
                           gc_comments   := 'One of the values should be provided in a given line';
                           INSERT_ERROR;
                           lc_validation_status := 'VE';
                           gc_log_message       := 'JIE09-Both the Entered Debit and Entered Credit are NULL';
                           XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                        END IF;
                     EXCEPTION
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := SQLERRM;
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;
-------------------------------------------------------------------------
                     --Validating the Debit Amount and Credit Amount precision
                     -------------------------------------------------------------------------
                     IF ( lr_journals.entered_dr IS NOT NULL OR lr_journals.entered_cr IS NOT NULL ) THEN
                        BEGIN
                           SELECT INSTR(TO_CHAR(lr_journals.entered_dr),'.')
                                 ,INSTR(TO_CHAR(lr_journals.entered_cr),'.')
                           INTO   ln_dr_precision_pos
                                 ,ln_cr_precision_pos
                           FROM   xxha_gl_journals_int XGJI
                           WHERE  XGJI.group_id = lr_journals.group_id
                           AND    XGJI.rec_num = lr_journals.rec_num;
 IF ( ln_dr_precision_pos <> 0 OR ln_cr_precision_pos <> 0 ) THEN
                              SELECT LENGTH(SUBSTR(TO_CHAR(lr_journals.entered_dr),ln_dr_precision_pos))
                                    ,LENGTH(SUBSTR(TO_CHAR(lr_journals.entered_cr),ln_cr_precision_pos))
                              INTO   ln_dr_precision
                                    ,ln_cr_precision
                              FROM   xxha_gl_journals_int XGJI
                              WHERE  XGJI.group_id = lr_journals.group_id
                              AND    XGJI.rec_num = lr_journals.rec_num;
 ln_dr_precision := ln_dr_precision - 1;
                              ln_cr_precision := ln_cr_precision - 1;
IF ( ln_dr_precision > ln_currency_precision ) THEN
                                 gc_error_code := 'JIE10';
                                 gc_error_msg  := 'The Entered Debit amount precision exceeds the precision in the currency setup';
                                 gc_comments   := 'The Currency Precision is: '||ln_currency_precision;
                                 INSERT_ERROR;
                                 lc_validation_status := 'VE';
                                 gc_log_message       := 'JIE10-Either the Entered Debit or Entered Credit Currency Precision is not valid';
                                 XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                              END IF; --End of ln_dr_precision <> ln_currency_precision

                              IF ( ln_cr_precision > ln_currency_precision ) THEN
                                 gc_error_code := 'JIE11';
                                 gc_error_msg  := 'The Entered Credit amount precision exceeds the precision in the currency setup';
                                 gc_comments   := 'The Currency Precision is: '||ln_currency_precision;
                                 INSERT_ERROR;
                                 lc_validation_status := 'VE';
                                 gc_log_message       := 'JIE11-The Entered Credit amount precision exceeds the precision in the currency setup';
                                 XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                              END IF; --End of ln_cr_precision <> ln_currency_precision )
                           END IF; --End of ln_dr_precision_pos <> 0 OR ln_cr_precision_pos <> 0
                        END;
                     END IF; --End of lr_journals.entered_dr IS NOT NULL OR lr_journals.entered_cr IS NOT NULL

                     gc_log_message := 'End of validations for the record '||lr_journals.rec_num;
                     XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
 -------------------------------------------------------------------------
                     --END OF VALIDATIONS
                     -------------------------------------------------------------------------
 ----------------------------------------------------------------------------
                     --Updating the validation status and some derivated ids in the staging table
                     -----------------------------------------------------------------------------
                     BEGIN
                        IF ( lc_validation_status = 'VE' ) THEN
                           UPDATE xxha_gl_journals_int XGJI
                           SET    XGJI.process_flag    = 'VE'
                                 ,XGJI.set_of_books_id = ln_set_of_books_id
                                 ,XGJI.code_combination_id = gn_ccid
                                 ,XGJI.oracleintfld8 = gn_child_request2_id
                           WHERE  XGJI.rec_num=lr_journals.rec_num;
                        ELSE
                           UPDATE xxha_gl_journals_int XGJI
                           SET    XGJI.process_flag    = 'VS'
                                 ,XGJI.set_of_books_id = ln_set_of_books_id
                                 ,XGJI.code_combination_id=gn_ccid
                                 ,XGJI.oracleintfld8 = gn_child_request2_id
                           WHERE  XGJI.rec_num=lr_journals.rec_num;
                        END IF;
                     EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                        gc_log_message:='There is no data found to not update the validation status(process_flag) and some other derived id s';
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     WHEN OTHERS THEN
                        gc_log_message:='There is other reason to not update the validation status(process_flag) and some other derived id s'||SQLERRM;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                     END;

                     lc_validation_status:=NULL;

                  END LOOP;             -- End of the validations Loop

               ELSE
                  --if batch validation fails or if there are more than one distinct no. of rows then update the status flag of the control table to 'VE'
                  UPDATE xxha_control XC
                  SET    XC.status_flag='VE'
                  WHERE  XC.interface_id=lr_journals_control.interface_id;

               END IF;  --End of lc_batch_validation_flag = 'Y' AND lc_validate_once_flag = 'Y'

XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'End Of Validations On the Staging Table XXHA_GL_JOURNALS_INT');
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'                                                                              ');
COMMIT;
-------------------------------------------------------------------------
           --If there is invalid records in the staging table call the
           --error report other wise call the MOVE_ADPTOGL_JOURNALS which
           --moves all the valid records into the Interface Tables
           -------------------------------------------------------------------------
           BEGIN
              -- Counting total records from the staging table
              IF ( lc_batch_validation_flag <> 'Y' OR lc_validate_once_flag <> 'Y' ) THEN
                  ln_total_rec:=0;
              ELSE
                  SELECT COUNT(*)
                  INTO   ln_total_rec
                  FROM   xxha_gl_journals_int
                  WHERE  group_id=lr_journals_control.interface_id;
              END IF;
-- Counting total valid records from the staging table
              SELECT COUNT(*)
              INTO   ln_valid_rec
              FROM   xxha_gl_journals_int
              WHERE  process_flag = 'VS'
              AND    group_id=lr_journals_control.interface_id;
-- Counting total invalid records from the staging table
              SELECT COUNT(*)
              INTO   ln_invalid_rec
              FROM   xxha_gl_journals_int
              WHERE  process_flag = 'VE'
              AND    group_id=lr_journals_control.interface_id;
-------------------------------------------------------------------------
              --Summary Of Data Validation Process
              -------------------------------------------------------------------------
              FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of '||lr_journals_control.file_name||' Records Validated ');
              FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                          :    ' ||ln_total_rec);
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation                  :    ' ||ln_valid_rec);
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored out                        :    ' ||ln_invalid_rec);
              FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
gc_log_message := 'If there are Invalid Records it sets the Concurrent Program status to Warning Otherwise it moves the records into the Interface Tables';
              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
gc_file_name := lr_journals_control.file_name;
IF ( ln_invalid_rec > 0 OR ln_valid_rec = 0 ) THEN
gn_invalid_batches := gn_invalid_batches + 1;
UPDATE xxha_control XC
                SET    XC.status_flag='VE'
                WHERE  XC.interface_id=lr_journals_control.interface_id;
FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('+',90,'+'));
 ELSE
                XXHA_GL_JOURNAL_IMPORT_PK.MOVE_ADPTOGL_JOURNALS(p_debug_flag,lr_journals_control.interface_id,x_ret_code);
                FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('+',90,'+'));
              END IF;
gn_batch_count := gn_batch_count + 1;
EXCEPTION
            WHEN NO_DATA_FOUND THEN
               gc_log_message:='There is no data found to determine whether it needs to run error report or execute MOVE_ADPTOGL_JOURNALS';
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
            WHEN OTHERS THEN
               gc_log_message:='There is other reason not to determine whether it needs to run error report or execute MOVE_ADPTOGL_JOURNALS';
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;
--Resetting all the variables
           ln_total_rec := 0;
           ln_valid_rec := 0;
           ln_invalid_rec := 0;
           gn_record_number := NULL;
           ln_no_of_distinct_rows := 0;
           lc_batch_validation_flag := NULL;
           lc_validate_once_flag := NULL;

         END LOOP;    --End of the  Control Loop

         IF ( gn_no_of_batches = gn_batch_count ) THEN
            IF ( gn_invalid_batches <> 0 ) THEN
               x_ret_code:=1;              --Setting the Concurrent Program status to Completed with Warning
               XXHA_COMMON_UTILITIES_PKG.LAUNCH_ERROR_REPORT_PRC(gn_child_request2_id,'ADP to GL Interface','BatchName');
               COMMIT;
            END IF;
         END IF;
END; --End of Validations Block
END IF; --End of lc_derivation_status = 'F'
END VALIDATE_ADPTOGL_JOURNALS; --End of the VALIDATE_ADPTOGL_JOURNALS Procedure
end xxha_gl_journal_import_pk; --End of the XXHA_GL_JOURNAL_IMPORT_PK Body
/
