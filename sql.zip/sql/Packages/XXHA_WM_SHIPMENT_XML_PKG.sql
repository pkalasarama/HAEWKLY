CREATE OR REPLACE PACKAGE "XXHA_WM_SHIPMENT_XML_PKG"
AS
  /*******************************************************************************************************
  * Object Name: XXHA_WM_SHIPMENT_XML_PKG
  * Object Type: PACKAGE BODY
  *
  * Description: This Package will be used in shipshipment process
  *
  * Modification Log:
  * Developer          Date              Version   Description
  *-----------------   ------------      -------   --------------------------------------
  * Apps Associates    16-JAN-2015        v1.0     Initial object creation.
  * Apps Associates    09-OCT-2015        v1.1     Modified XXHA_WMS_SUP_PREC_FUNC to get Y for internations irrespective of overpack/ non-overpack. And N for other cases
  *               Added variable L_SUP_PREC_FLAG to capture function value and use it at different cases in order toa void redundant logic and improve performance
  *
  *******************************************************************************************************/
  PROCEDURE XXHA_WM_SHIPMENT_XML(
      p_delivery_id NUMBER);
  FUNCTION XXHA_WMS_SUP_PREC_FUNC(
      p_delivery_id NUMBER)
    RETURN VARCHAR2;
END XXHA_WM_SHIPMENT_XML_PKG;
/
CREATE OR REPLACE PACKAGE BODY "APPS"."XXHA_WM_SHIPMENT_XML_PKG"
  /*******************************************************************************************************
  * Object Name: XXHA_WM_SHIPMENT_XML_PKG
  * Object Type: PACKAGE BODY
  *
  * Description: This Package will be used in shipshipment process
  *
  * Modification Log:
  * Developer          Date              Version   Description
  *-----------------   ------------      -------   --------------------------------------
  * Apps Associates    16-JAN-2015        v1.0     Initial object creation.
  * Apps Associates    24-SEP-2015        v1.1     Modify server brs-wmpoc01 with brs-methods97
  * Apps Associates    09-OCT-2015        v1.2     Modified XXHA_WMS_SUP_PREC_FUNC to get Y for internations irrespective of overpack/ non-overpack. And N for other cases
  *               Added variable L_SUP_PREC_FLAG to capture function value and use it at different cases in order toa void redundant logic and improve performance
  * Apps Associates    13-NOV-2015        v1.3     Modify server wmtmp01.haemo.net with brs-methods97  
  *
  *******************************************************************************************************/
AS
  FUNCTION XXHA_WMS_SUP_PREC_FUNC(
      p_delivery_id NUMBER)
    RETURN VARCHAR2
  AS
    l_status VARCHAR2(100);
    l_count  NUMBER;
  BEGIN
    BEGIN
      --v1.2 modified below sql code to get ship method from new deliveries and return value irrespective of overpack or not.
      SELECT COUNT(wnd.delivery_id)
      INTO l_count
      FROM apps.wsh_new_deliveries wnd,
        apps.fnd_lookup_values flv,
        apps.mtl_parameters mp
      WHERE 1                  =1
      AND wnd.delivery_id      = p_delivery_id
      AND wnd.organization_id  = mp.organization_id
      AND wnd.ship_method_code = flv.description
      AND flv.lookup_type      = 'XXHA_WMS_SUPPRESS_PRECISION'
      AND flv.enabled_flag     = 'Y'
      AND flv.language         = userenv('LANG')
      AND lookup_code          = mp.organization_code
        ||':'
        ||wnd.ship_method_code ;
    EXCEPTION
    WHEN no_data_found THEN
      l_status:='N';
    END;
    IF l_count = 1 THEN
      l_status:='Y';
      RETURN l_status;
    ELSE
      l_status:='N';
    END IF;
    RETURN l_status;
  END XXHA_WMS_SUP_PREC_FUNC;
  PROCEDURE XXHA_WM_SHIPMENT_XML(
      p_delivery_id NUMBER)
  AS
    p_rec_wm_trackChange wm_trackchanges%ROWTYPE;
    c_transaction_type VARCHAR2(100) :='SHIPSHIPMENT';
    l_err              VARCHAR2(100);
    reqlength          NUMBER;
    eob                BOOLEAN := false;
    l_http_request UTL_HTTP.req;
    l_http_response UTL_HTTP.resp;
    request_env       VARCHAR2 (32767);
    request_env1      VARCHAR2 (32767);
    eof               BOOLEAN;
    l_key_str         NUMBER := 0;
    l_err_count       NUMBER;
    l_count           NUMBER;
    l_text            VARCHAR2(32767);
    l_request_context VARCHAR2(10)  := 'POST';
    p_server          VARCHAR2(300) := 'brs-wmtmp01.haemo.net'; --v1.2 only for testing in ZRC need to uncomment
    --p_server              VARCHAR2(300) := 'brs-wmpoc01.haemo.net'; --v1.2 only for testing in ZRC need to comment
    l_server              VARCHAR2(1000); --brs-wmpoc01.haemo.net
    l_response            VARCHAR2(32767);
    L_EXCEPTION           VARCHAR2(3000);
    ln_request_id         NUMBER;
    l_user_id             NUMBER         := to_number(fnd_profile.value('USER_ID')); --to_number(fnd_profile.value('USER_ID'));
    l_resp_id             NUMBER         := NULL;
    l_resp_appl_id        NUMBER         := NULL;
    l_responsibility_name VARCHAR2 (255) := 'US Order Management Super User OC';
    l_doc_printer         VARCHAR2(50);
    l_lookup_code         VARCHAR2(250);
    L_SUP_PREC_FLAG       VARCHAR2(10); --v1.2
  BEGIN
    BEGIN
      --v1.2
      BEGIN
        SELECT XXHA_WMS_SUP_PREC_FUNC(p_delivery_id) INTO L_SUP_PREC_FLAG FROM DUAL;
      EXCEPTION
      WHEN OTHERS THEN
        dbms_output.put_line('Function returned with exception:'||SQLERRM);
        L_SUP_PREC_FLAG := 'N';
      END;
      dbms_output.put_line('Function returned status: '||L_SUP_PREC_FLAG);--v1.2
      IF L_SUP_PREC_FLAG = 'N' THEN                                       --v1.2
        --IF XXHA_WMS_SUP_PREC_FUNC(p_delivery_id) = 'N' THEN --v1.2
        dbms_output.put_line('Entered IF condition for: '||p_delivery_id);
        p_rec_wm_trackChange.transaction_type   := c_transaction_type;
        p_rec_wm_trackChange.date_created       := SYSDATE;
        p_rec_wm_trackChange.processed_flag     := 'N';
        p_rec_wm_trackChange.transaction_id     :=p_delivery_id;
        p_rec_wm_trackChange.comments           :='ORDER DELIVERY INSERT FOR '|| p_delivery_id;
        p_rec_wm_trackChange.transaction_status := 1;
        -- Call Procedure to Insert into wm_track_changes
        wm_track_changes_pkg.web_transaction(p_rec_wm_trackChange);
        COMMIT;
      ELSE
        BEGIN
          SELECT wdd.attribute4,
            flv.lookup_code
          INTO l_doc_printer,
            l_lookup_code
          FROM wsh_carrier_services_v wcs,
            wsh_delivery_details wdd ,
            wsh_delivery_assignments wda,
            wsh_new_deliveries wnd,
            wsh_lookups wl,
            org_organization_definitions ood,
            fnd_lookup_values_vl flv
          WHERE wcs.carrier_id       = wdd.carrier_id
          AND wdd.delivery_detail_id = wda.delivery_detail_id
          AND wda.delivery_id        = wnd.delivery_id
          AND wdd.organization_id    = ood.organization_id
          AND wda.delivery_id        = p_delivery_id
          AND wdd.mode_of_transport  = wl.lookup_code
          AND wl.lookup_type(+)      = 'XXHA_WSH_BOL_MODE_OF_TRANSPORT'
          AND flv.lookup_type        = 'XXHA_WMS_SHIPPING_DOCS'
          AND flv.tag                = DECODE(upper(wdd.mode_of_transport),'PARCEL',wdd.mode_of_transport,'NP')
          AND flv.description        = ood.organization_code
          AND wl.enabled_flag        = 'Y'
          AND flv.enabled_flag       = 'Y'
          AND wdd.attribute4        IS NOT NULL
          AND rownum                 = 1
          GROUP BY wdd.attribute4,
            flv.lookup_code ;
          BEGIN
            SELECT frt.application_id,
              frt.responsibility_id
            INTO l_resp_appl_id,
              l_resp_id
            FROM fnd_responsibility_tl frt
            WHERE frt.LANGUAGE          = 'US'
            AND frt.responsibility_name = l_responsibility_name;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_resp_appl_id := '';
            l_resp_id      := '';
          END;
          dbms_output.put_line('Responsibility id: '||l_resp_id);
          dbms_output.put_line('User id: '||l_user_id);
          fnd_global.apps_initialize (user_id => l_user_id, resp_id => l_resp_id, resp_appl_id => l_resp_appl_id );
          dbms_output.put_line('In calling Shipping docs package for: '||p_delivery_id);
          ln_request_id := fnd_request.submit_request ( 'HAEMO' -- Application
          , l_lookup_code                                       -- Program
          , NULL                                                -- Description
          , NULL                                                -- Start Time
          , FALSE                                               -- Sub Request
          , p_delivery_id                                       -- Delivery ID
          , l_doc_printer                                       -- Shipping docs printer
          );
          COMMIT;
          IF ln_request_id = 0 THEN
            DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
          END IF;
        END;
      END IF;
    END;
    IF L_SUP_PREC_FLAG = 'N' THEN --v1.2 Added condition to submit web method only when ship method is not FedEx Int'l
      --Calling Web Service
      BEGIN
        dbms_output.put_line('Entered Web Service call procedure');
        request_env  := '<?xml version="1.0" encoding="utf-8"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">                                    
<SOAP-ENV:Header xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"/>                                    
<soapenv:Body>                  
<tns:generateShipShipment xmlns:tns="http://brs-wmtmp01.haemo.net/ERPShipment.service:PrecisionInterface">                                    
<deliveryID>$STRING1</deliveryID>                                    
</tns:generateShipShipment>                                    
</soapenv:Body>                                    
</soapenv:Envelope>';
        request_env1 := REPLACE (request_env, '$STRING1', p_delivery_id);
        dbms_output.put_line('p_delivery_id:'||p_delivery_id);
        l_server       := 'http://'||p_server||':5555/ws/ERPShipment.service.PrecisionInterface/ERPShipment_service_PrecisionInterface_Port';
        l_http_request := UTL_HTTP.begin_request ('http://brs-wmtmp01.haemo.net:5555/ws/ERPShipment.service.PrecisionInterface/ERPShipment_service_PrecisionInterface_Port', l_request_context, UTL_HTTP.HTTP_VERSION_1_1);
        UTL_HTTP.set_header (l_http_request, 'Content-Type', 'text/xml; charset=utf-8');
        UTL_HTTP.set_header (l_http_request, 'Content-Length', LENGTH (request_env1));
        UTL_HTTP.set_header (l_http_request, 'SOAPAction', '"ERPShipment_service_PrecisionInterface_Binder_generateShipShipment"' );
        UTL_HTTP.write_text (l_http_request, request_env1);
        l_http_response := UTL_HTTP.get_response (l_http_request);
        -- Copy the response into the CLOB.
        UTL_HTTP.read_text(l_http_response, l_text, 32767);
        IF l_text IS NOT NULL AND LENGTH(l_text)>0 THEN
          dbms_output.put_line ('HTTP Response Text: ' || l_text);
          BEGIN
            SELECT SUBSTR(l_text, (instr(l_text, '<status>')+8), (instr(l_text, '</status>') - (instr(l_text, '<status>')+8)))
            INTO l_response
            FROM dual;
            dbms_output.put_line ('Web Service status(result): ' || l_response);
          EXCEPTION
          WHEN OTHERS THEN
            dbms_output.put_line('Exception occured:'||SQLERRM);
            L_EXCEPTION := SQLCODE || sqlerrm;
          END;
        END IF;
        utl_http.end_response(l_http_response);
      EXCEPTION
      WHEN UTL_HTTP.END_OF_BODY THEN
        UTL_HTTP.END_RESPONSE(l_http_response);
        L_EXCEPTION := SQLCODE || sqlerrm;
      WHEN UTL_HTTP.TOO_MANY_REQUESTS THEN
        --UTL_HTTP.END_RESPONSE(l_http_response);
        --UTL_HTTP.DESTROY_REQUEST_CONTEXT(l_request_context);
        dbms_output.put_line('UTL_HTTP.TOO_MANY_REQUESTS Error occured in calling Shipshipment Web service: too many requests: '||SQLERRM);
        L_EXCEPTION := SQLCODE || sqlerrm;
      WHEN OTHERS THEN
        --UTL_HTTP.end_response(l_http_response);
        --UTL_HTTP.DESTROY_REQUEST_CONTEXT(l_request_context);
        dbms_output.put_line('Error occured in calling Shipshipment Web Service: '||SQLERRM);
        L_EXCEPTION := SQLCODE || sqlerrm;
        -- END send request - get response
      END;
    END IF; --v1.2
  EXCEPTION
  WHEN UTL_HTTP.END_OF_BODY THEN
    L_EXCEPTION := SQLCODE || sqlerrm;
  WHEN UTL_HTTP.TOO_MANY_REQUESTS THEN
    dbms_output.put_line('UTL_HTTP.TOO_MANY_REQUESTS : '||SQLERRM);
    L_EXCEPTION := SQLCODE || sqlerrm;
  WHEN OTHERS THEN
    L_EXCEPTION := SQLCODE || sqlerrm;
  END;
END XXHA_WM_SHIPMENT_XML_PKG;
/