CREATE OR REPLACE PACKAGE xxha_oe_bsa_ame_approval_pkg
AS
   FUNCTION approver_list (
      p_transactionid                     NUMBER
   )
      RETURN xxha_apprlist_type PIPELINED;
END;

/


CREATE OR REPLACE PACKAGE BODY      xxha_oe_bsa_ame_approval_pkg
--+======================================================================================================+
--| Name        :    xxha_oe_bsa_ame_approval_pkg                                                        |
--|                                                                                                      |
--| Description :   Package to generate approver list for BSA workflow                                   |
--|                                                                                                      |
--|                                                                                                      |
--|  History            Author      Date        Change                                                   |
--|  Rel 1.0            KBace       01-MAY-2010 Created                                                  |
--|  Rel 1.1            D. Lund     24-JUN-2010 Bug fix to reset the variable l_nonstd_req_undef         |
--|                                               so that it does not go to the undefined section        |
--|                                               unless needed                                          |
--|  Rel 1.2            D. Lund     29-JUN-2010 Changed logic to leverage the non-standard workflow as   |
--|                                               defined by the listed clause titles in the existing    |
--|                                               approval matrix for certain blanket types              |
--|  Rel 1.3            D. Lund     30-JUN-2010 Changed logic to leverage the non-standard workflow as   |
--|                                               defined by the listed clause titles in the existing    |
--|                                               approval matrix when the authoring party is CUSTOMER   |
--|  Rel 1.4            D. Lund     21-JUL-2010 Exclude the undefined approvals for product lines MS / SV|
--|  Rel 1.5            IPadela     25-OCT-2010 Added 3 more payment terms as std terms for Italy OU     |
--|  Rel 1.6            IPadela     08-Dec-2010 modified the std pay term for GB to 30 Net in place of 60|
--|  Rel 1.7            D. Lund     17-MAR-2011 Added new logic for HSS related BSAs                     |
--|  Rel 1.8            IPadela     28-Nov-2011 added payment term 30 Net as std pay term for CH as per  |
--|                                             WO 28836 Incident 93213
--+======================================================================================================+
AS
   FUNCTION approver_list (p_transactionid NUMBER)
      RETURN xxha_apprlist_type PIPELINED
   IS
      CURSOR std_nonstd_cl_cnt (c_yes_no VARCHAR2)
      IS
--         SELECT COUNT (*)
--           FROM okc_k_articles_b b, okc_articles_v a
--          WHERE b.sav_sae_id = a.article_id
--            AND document_type = 'B'
--            AND document_id = p_transactionid
--            AND standard_yn = c_yes_no;
    select sum(cnt) from
        (SELECT COUNT (*) cnt
           FROM okc_k_articles_b b, okc_articles_v a
          WHERE b.sav_sae_id = a.article_id
            AND document_type = 'B'
            AND document_id = p_transactionid
            AND standard_yn = c_yes_no
          union all
          -- added 6/29/10 DL - to drive nonstd for certain blanket order types
          select 1 from oe_blanket_headers_all bh, oe_transaction_types_tl tt
          where bh.header_id = p_transactionid
          and bh.order_type_id = tt.transaction_type_id
          and tt.language = 'US'
          and tt.name in ('English - Military (US)',
                          'English ? Cust Defined (US)',
                          'English - Military (CA)',
                          'English ? Cust Defined (CA)',
                          'German ? Cust Defined (AT)',
                          'Dutch ? Cust Defined (BE)',
                          'Dutch ? Tender (BE)',
                          'French ? Cust Defined (BE)',
                          'French ? Tender (BE)',
                          'German ? Cust Defined (CH)',
                          'French ? Cust Defined (CH)',
                          'Italian ? Cust Defined (CH)',
                          'Czech ? Tender (CZ)',
                          'Czech ? Cust Defined (CZ)',
                          'German ? Cust Defined (DE)',
                          'French ? Tender (FR)',
                          'French ? Cust Defined (FR)',
                          'English ? Tender (GB)',
                          'English ? Cust Defined (GB)',
                          'Italian ? Tender (IT)',
                          'Italian ? Cust Defined (IT)',
                          'Dutch ? Tender (NL)',
                          'Dutch ? Cust Defined (NL)',
                          'English ? Tender (SE)',
                          'English ? Cust Defined (SE)')
          union all
          -- added 6/29/10 DL - to drive nonstd for customer contract source
          select 1 from okc_template_usages usg
          where usg.document_id = p_transactionid
          and usg.authoring_party_code = 'CUSTOMER_ORG'
          and usg.document_type = 'B');


      CURSOR payment_term
      IS
         SELECT b.NAME
           FROM oe_blanket_headers_all a, ra_terms b
          WHERE a.header_id = p_transactionid
                AND a.payment_term_id = b.term_id;

      CURSOR std_approvers (c_org_id NUMBER)
      IS
         SELECT   papf.person_id, bsa.approver_ranking ranking
             FROM xxha_oe_bsa_approval_lst bsa, per_all_people_f papf
            WHERE UPPER (bsa.clause_type) = 'STANDARD_BSA'
              --AND   bsa.approver_first_name = papf.first_name
              --AND   bsa.approver_last_name = papf.last_name
              AND TO_CHAR (bsa.employee_number) = papf.employee_number
              AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                      AND papf.effective_end_date
              AND bsa.org_id = c_org_id
         ORDER BY bsa.approver_ranking;

      CURSOR nonstd_pt_approvers (c_org_id NUMBER, c_bdiv VARCHAR2)
      IS
         SELECT   papf.person_id, bsa.approver_ranking ranking
             FROM xxha_oe_bsa_approval_lst bsa, per_all_people_f papf
            WHERE UPPER (bsa.clause_type) = 'BSA_PAY_TERMS'
              --AND   bsa.approver_first_name = papf.first_name
              --AND   bsa.approver_last_name = papf.last_name
              AND TO_CHAR (bsa.employee_number) = papf.employee_number
              AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                      AND papf.effective_end_date
              AND bsa.org_id = c_org_id
              /*AND NVL (bsa.bdiv, 'X') =
                             DECODE (c_bdiv
                                    ,'ALL', NVL (bsa.bdiv, 'X')
                                    ,c_bdiv
                                    )*/
              AND UPPER (bsa.bdiv) = UPPER (c_bdiv)
         ORDER BY bsa.approver_ranking;

      CURSOR nonstd_cl_type_appr (
         c_org_id        NUMBER,
         c_bdiv          VARCHAR2,
         c_clause_type   VARCHAR2
      )
      IS
         SELECT   papf.person_id, bsa.approver_ranking ranking
             FROM xxha_oe_bsa_approval_lst bsa, per_all_people_f papf
            WHERE UPPER (bsa.clause_type) = UPPER (c_clause_type)
              --AND   bsa.approver_first_name = papf.first_name
              --AND   bsa.approver_last_name = papf.last_name
              AND TO_CHAR (bsa.employee_number) = papf.employee_number
              AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                      AND papf.effective_end_date
              AND bsa.org_id = c_org_id
              /*AND NVL (bsa.bdiv, 'X') =
                             DECODE (c_bdiv
                                    ,'ALL', NVL (bsa.bdiv, 'X')
                                    ,c_bdiv
                                    )*/
              AND UPPER (bsa.bdiv) = UPPER (c_bdiv)
         ORDER BY bsa.approver_ranking;

      CURSOR nonstd_cl_title_appr (
         c_org_id         NUMBER,
         c_bdiv           VARCHAR2,
         c_clause_title   VARCHAR2
      )
      IS
         SELECT   papf.person_id, bsa.approver_ranking ranking
             FROM xxha_oe_nonstd_cltitle_lst bsa, per_all_people_f papf
            WHERE UPPER (bsa.clause_title) = UPPER (c_clause_title)
              --AND   bsa.approver_first_name = papf.first_name
              --AND   bsa.approver_last_name = papf.last_name
              AND TO_CHAR (bsa.employee_number) = papf.employee_number
              AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                      AND papf.effective_end_date
              AND bsa.org_id = c_org_id
              /*AND NVL (bsa.bdiv, 'X') =
                             DECODE (c_bdiv
                                    ,'ALL', NVL (bsa.bdiv, 'X')
                                    ,c_bdiv
                                    )*/
              AND UPPER (bsa.bdiv) = UPPER (c_bdiv)
         ORDER BY bsa.approver_ranking;

      CURSOR nonstd_undefined_appr (c_org_id NUMBER)
      IS
         SELECT   papf.person_id, bsa.approver_ranking ranking
             FROM xxha_oe_nonstd_cltitle_lst bsa, per_all_people_f papf
            WHERE UPPER (bsa.clause_title) = 'UNDEFINED'
--     AND   bsa.approver_first_name = papf.first_name
--     AND   bsa.approver_last_name = papf.last_name
              AND TO_CHAR (bsa.employee_number) = papf.employee_number
              AND TRUNC (SYSDATE) BETWEEN papf.effective_start_date
                                      AND papf.effective_end_date
              AND bsa.org_id = c_org_id
         -- and   bsa.bdiv = c_bdiv
         ORDER BY bsa.approver_ranking;

      CURSOR bdivs
      IS
         SELECT DISTINCT bdiv.bdiv
                    FROM oe_blanket_lines_all obla,
                         mtl_item_categories mic,
                         mtl_categories mc,
                         mtl_category_sets mcs,
                         xxha_oe_prdline_bdiv_mapping bdiv,
                         mtl_parameters mp
                   WHERE obla.header_id = p_transactionid
                     AND obla.inventory_item_id = mic.inventory_item_id
                     AND mp.organization_code = 'MST'
                     AND mic.organization_id = mp.organization_id
                     AND UPPER (mcs.category_set_name) = 'INVENTORY'
                     AND mcs.category_set_id = mic.category_set_id
                     AND mic.category_id = mc.category_id
                     AND bdiv.product_line = mc.segment1;

      CURSOR nstd_cl_types
      IS
        select distinct clause_type from 
         (SELECT DISTINCT fl.meaning clause_type
                    FROM okc_k_articles_b b, okc_articles_v a, fnd_lookups fl
                   WHERE b.sav_sae_id = a.article_id
                     AND document_type = 'B'
                     AND document_id = p_transactionid
                     AND standard_yn = 'N'
                     AND a.article_type = fl.lookup_code(+)
                     AND NVL (lookup_type, 'OKC_SUBJECT') = 'OKC_SUBJECT'
         union all
         -- added 6/29/10 DL - to drive Customer defined clause type for certain blanket order types
         select 'CUSTOMER DEFINED TERMS' clause_type
         from oe_blanket_headers_all bh, oe_transaction_types_tl tt
         where bh.header_id = p_transactionid
         and bh.order_type_id = tt.transaction_type_id
         and tt.language = 'US'
         and tt.name in ('English - Military (US)',
                          'English ? Cust Defined (US)',
                          'English - Military (CA)',
                          'English ? Cust Defined (CA)',
                          'German ? Cust Defined (AT)',
                          'Dutch ? Cust Defined (BE)',
                          'Dutch ? Tender (BE)',
                          'French ? Cust Defined (BE)',
                          'French ? Tender (BE)',
                          'German ? Cust Defined (CH)',
                          'French ? Cust Defined (CH)',
                          'Italian ? Cust Defined (CH)',
                          'Czech ? Tender (CZ)',
                          'Czech ? Cust Defined (CZ)',
                          'German ? Cust Defined (DE)',
                          'French ? Tender (FR)',
                          'French ? Cust Defined (FR)',
                          'English ? Tender (GB)',
                          'English ? Cust Defined (GB)',
                          'Italian ? Tender (IT)',
                          'Italian ? Cust Defined (IT)',
                          'Dutch ? Tender (NL)',
                          'Dutch ? Cust Defined (NL)',
                          'English ? Tender (SE)',
                          'English ? Cust Defined (SE)')
          union all
          -- added 6/29/10 DL - to drive nonstd for customer contract source
          select 'CUSTOMER DEFINED TERMS' clause_type
          from okc_template_usages usg
          where usg.document_id = p_transactionid
          and usg.authoring_party_code = 'CUSTOMER_ORG'
          and usg.document_type = 'B')
;

      --Modified by Vijay to get the Clause Type from Fnd Lookup
      CURSOR nstd_cl_titles (c_clause_type VARCHAR2)
      IS
        select distinct clause_title from
         (SELECT DISTINCT a.article_title clause_title
                    FROM okc_k_articles_b b, okc_articles_v a, fnd_lookups fl
                   WHERE b.sav_sae_id = a.article_id
                     AND document_type = 'B'
                     AND document_id = p_transactionid
                     AND fl.meaning = c_clause_type
                     --AND article_type = c_clause_type
                     AND standard_yn = 'N'
                     AND a.article_type = fl.lookup_code(+)
                     AND NVL (lookup_type, 'OKC_SUBJECT') = 'OKC_SUBJECT'
        union all
        -- added 6/29/10 DL - to drive Customer defined clause title for certain blanket order types
        SELECT decode(tt.name,'English - Military (US)','English - Cust Defined [Non-Standard]',
                      'English ? Cust Defined (US)','English - Cust Defined [Non-Standard]',
                      'English - Military (CA)','English - Cust Defined [Non-Standard]',
                      'English ? Cust Defined (CA)','English - Cust Defined [Non-Standard]',
                      'German ? Cust Defined (AT)','German - Cust Defined [Non-Standard]',
                      'Dutch ? Cust Defined (BE)','Dutch - Cust Defined [Non-Standard]',
                      'Dutch ? Tender (BE)','Dutch - Cust Defined [Non-Standard]',
                      'French ? Cust Defined (BE)','French - Cust Defined [Non-Standard]',
                      'French ? Tender (BE)','French - Cust Defined [Non-Standard]',
                      'German ? Cust Defined (CH)','German - Cust Defined [Non-Standard]',
                      'French ? Cust Defined (CH)','French - Cust Defined [Non-Standard]',
                      'Italian ? Cust Defined (CH)','Italian - Cust Defined [Non-Standard]',
                      'Czech ? Tender (CZ)	','Czech - Cust Defined [Non-Standard]',
                      'Czech ? Cust Defined (CZ)','Czech - Cust Defined [Non-Standard]',
                      'German ? Cust Defined (DE)','German - Cust Defined [Non-Standard]',
                      'French ? Tender (FR)','French - Cust Defined [Non-Standard]',
                      'French ? Cust Defined (FR)','French - Cust Defined [Non-Standard]',
                      'English ? Tender (GB)','English - Cust Defined [Non-Standard]',
                      'English ? Cust Defined (GB)','English - Cust Defined [Non-Standard]',
                      'Italian ? Tender (IT)','Italian - Cust Defined [Non-Standard]',
                      'Italian ? Cust Defined (IT)','Italian - Cust Defined [Non-Standard]',
                      'Dutch ? Tender (NL)','Dutch - Cust Defined [Non-Standard]',
                      'Dutch ? Cust Defined (NL)','Dutch - Cust Defined [Non-Standard]',
                      'English ? Tender (SE)','English - Cust Defined [Non-Standard]',
                      'English ? Cust Defined (SE)','English - Cust Defined [Non-Standard]') clause_title
          from oe_blanket_headers_all bh, oe_transaction_types_tl tt
          where bh.header_id = p_transactionid
          and bh.order_type_id = tt.transaction_type_id
          and tt.language = 'US'
          and tt.name in ('English - Military (US)',
                          'English ? Cust Defined (US)',
                          'English - Military (CA)',
                          'English ? Cust Defined (CA)',
                          'German ? Cust Defined (AT)',
                          'Dutch ? Cust Defined (BE)',
                          'Dutch ? Tender (BE)',
                          'French ? Cust Defined (BE)',
                          'French ? Tender (BE)',
                          'German ? Cust Defined (CH)',
                          'French ? Cust Defined (CH)',
                          'Italian ? Cust Defined (CH)',
                          'Czech ? Tender (CZ)',
                          'Czech ? Cust Defined (CZ)',
                          'German ? Cust Defined (DE)',
                          'French ? Tender (FR)',
                          'French ? Cust Defined (FR)',
                          'English ? Tender (GB)',
                          'English ? Cust Defined (GB)',
                          'Italian ? Tender (IT)',
                          'Italian ? Cust Defined (IT)',
                          'Dutch ? Tender (NL)',
                          'Dutch ? Cust Defined (NL)',
                          'English ? Tender (SE)',
                          'English ? Cust Defined (SE)')
        union all
        -- added 6/29/10 DL - to drive nonstd for customer contract source
        select clauses.clause_title
        from okc_template_usages usg , oe_blanket_headers_all bsa
          , ( select 'English - Cust Defined [Non-Standard]' clause_title, 102 org_id from dual
              union all select 'English - Cust Defined [Non-Standard]' clause_title, 234 org_id from dual
              union all select 'German - Cust Defined [Non-Standard]' clause_title, 237 org_id from dual
              union all select 'Dutch - Cust Defined [Non-Standard]' clause_title, 157 org_id from dual
              union all select 'French - Cust Defined [Non-Standard]' clause_title, 157 org_id from dual
              union all select 'German - Cust Defined [Non-Standard]' clause_title, 158 org_id from dual
              union all select 'French - Cust Defined [Non-Standard]' clause_title, 158 org_id from dual
              union all select 'Italian - Cust Defined [Non-Standard]' clause_title, 158 org_id from dual
              union all select 'Czech - Cust Defined [Non-Standard]' clause_title, 136 org_id from dual
              union all select 'German - Cust Defined [Non-Standard]' clause_title, 155 org_id from dual
              union all select 'French - Cust Defined [Non-Standard]' clause_title, 130 org_id from dual
              union all select 'English - Cust Defined [Non-Standard]' clause_title, 162 org_id from dual
              union all select 'Italian - Cust Defined [Non-Standard]' clause_title, 132 org_id from dual
              union all select 'Dutch - Cust Defined [Non-Standard]' clause_title, 159 org_id from dual
              union all select 'English - Cust Defined [Non-Standard]' clause_title, 134 org_id from dual) clauses
        where usg.document_id = bsa.header_id
        and usg.authoring_party_code = 'CUSTOMER_ORG'
        and usg.document_type = 'B'
        and bsa.header_id = p_transactionid
        and bsa.org_id = clauses.org_id)
;

      --Modified by Vijay to get the Clause Type from Fnd Lookup;

      -- This cursor fetches Y or N to say whether the payment term is standard or not for
      -- the specific OU.
      CURSOR pt_std_nonstd (c_org_id NUMBER, c_term_name VARCHAR2)
      IS
         SELECT MAX (stds)
           FROM (SELECT 'STD' stds
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS FRANCE S.A.R.L. FR OU'
                    AND UPPER (c_term_name) = '60 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS ITALIA S.R.L. IT OU'
                    AND UPPER (c_term_name) = '90 NET'
                -- Rev 1.5
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS ITALIA S.R.L. IT OU'
                    AND UPPER (c_term_name) = 'RIBA 30 GG.'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS ITALIA S.R.L. IT OU'
                    AND UPPER (c_term_name) = 'RIBA 60 GG.'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS ITALIA S.R.L. IT OU'
                    AND UPPER (c_term_name) = 'RIBA 90 GG.'
                --end Rev 1.5
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS SCANDINAVIA AB SE OU'
                    AND UPPER (c_term_name) = '30 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS CZ, SPOL. S.R.O. CZ OU'
                    AND UPPER (c_term_name) = '60 NET'
                 UNION
                 -- Rev 1.6
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS LTD. GB OU'
                    AND UPPER (c_term_name) = '30 NET'
                -- end Rev 1.6
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS CANADA LTD. CA OU'
                    AND UPPER (c_term_name) = '30 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS AUSTRIA AT OU'
                    AND UPPER (c_term_name) = '2% 14, 30 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS AUSTRIA AT OU'
                    AND UPPER (c_term_name) = '30 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS GMBH DE OU'
                    AND UPPER (c_term_name) = '2% 14, 30 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS GMBH DE OU'
                    AND UPPER (c_term_name) = '30 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS SA-NV BE OU'
                    AND UPPER (c_term_name) = '60 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS (UK) LTD. ST OU'
                    AND UPPER (c_term_name) = '60 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS CORP US OU'
                    AND UPPER (c_term_name) = '30 NET'
                 UNION
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS BV NL OU'
                    AND UPPER (c_term_name) = '30 NET'
                 UNION
                 -- Rel 1.8 IPadela added this to make 30 Net standard payment term for Switzerland
                 SELECT 'STD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS S.A. CH OU'
                    AND UPPER (c_term_name) = '30 NET'
                 UNION
                 SELECT 'NONSTD'
                   FROM hr_operating_units
                  WHERE organization_id = c_org_id
                    AND UPPER (NAME) = 'HAEMONETICS S.A. CH OU'
                    AND c_term_name IS NULL
                 UNION
                 SELECT 'NONSTD'
                   FROM DUAL);

     cursor c_blanket_amt is
        select sum(nvl(blanket_min_amount,0))
        from oe_blanket_headers_ext e
        , oe_blanket_headers_all h
        where h.order_number = e.order_number 
        and h.header_id = p_transactionid;


      l_which                 NUMBER;
      l_org_id                NUMBER;
      l_payment_term          VARCHAR2 (240);
      l_approver_type         VARCHAR2 (10);
      l_non_std_cl_cnt        NUMBER;
      l_cnt                   NUMBER            := 0;
      l_bdiv_cnt              NUMBER            := 0;
      l_bdiv                  VARCHAR2 (240);
      lt_unsorted             xxha_oe_bsa_apprs := xxha_oe_bsa_apprs ();
      lt_sorted               xxha_oe_bsa_apprs;
      l_table_index           NUMBER            := 0;
      l_temp_check            NUMBER;
      l_nonstd_req_undef      VARCHAR2 (1);
      l_nonstd_undef_cnt      NUMBER            := 0;
      l_nonstd_pt_cnt         NUMBER            := 0;
      l_nonstd_undef_pt_cnt   NUMBER            := 0;
      l_nonstd_pt_req_undef   VARCHAR2 (1);
      l_blanket_type          varchar2(200)     := NULL;
      l_clause_title          varchar2(200)     := NULL;
      l_blanket_amount        number            := 0;
   BEGIN
      SELECT org_id
        INTO l_org_id
        FROM oe_blanket_headers_all
       WHERE header_id = p_transactionid;

      SELECT TT.NAME
      INTO l_blanket_type
      from oe_blanket_headers_all bh, oe_transaction_types_tl tt
      where bh.header_id = p_transactionid
      and bh.order_type_id = tt.transaction_type_id
      and tt.language = 'US';

  if l_blanket_type in ('HSS US','HSS CA') then 
      OPEN c_blanket_amt;

      FETCH c_blanket_amt
       INTO l_blanket_amount;

      CLOSE c_blanket_amt;

      if nvl(l_blanket_amount,0) <= 50000 
        then l_clause_title := 'HSS Under 50K';
        else l_clause_title := 'HSS Over 50K';
      end if;

                     FOR nscta IN nonstd_cl_title_appr (l_org_id,
                                                        'HSS',
                                                        l_clause_title
                                                       )
                     LOOP
                        DBMS_OUTPUT.put_line
                                      (   'HSS Clause Title Approver:'
                                       || nscta.person_id
                                      );
                        lt_unsorted.EXTEND;
                        l_table_index := l_table_index + 1;
                        lt_unsorted (l_table_index) :=
                           xxha_oe_bsa_appr_obj (nscta.person_id,
                                                 nscta.ranking
                                                );
                        l_nonstd_undef_cnt := l_nonstd_undef_cnt + 1;
                     /*DBMS_OUTPUT.put_line (   'VJ_l_nonstd_undef_cnt LOOP '
                                           || l_nonstd_undef_cnt
                                          );*/
                     END LOOP;

else
      -- gets the payment term name.
      OPEN payment_term;

      FETCH payment_term
       INTO l_payment_term;

      CLOSE payment_term;

      DBMS_OUTPUT.put_line ('l_payment_term:' || l_payment_term);

      /*IF    (l_payment_term IS NULL)
         OR (UPPER (l_payment_term) = '30 NET')
      THEN
         l_approver_type := 'STD';
      ELSE
         l_approver_type := 'NONSTD';
         l_which := 1;
      END IF;*/
      IF l_payment_term IS NOT NULL
      THEN
         -- check whether payment term is standard or not
         OPEN pt_std_nonstd (l_org_id, l_payment_term);

         FETCH pt_std_nonstd
          INTO l_approver_type;

         CLOSE pt_std_nonstd;
      ELSE
         l_approver_type := 'NONSTD';
      END IF;

      IF l_approver_type = 'NONSTD'
      THEN
         l_which := 1;
      END IF;

      DBMS_OUTPUT.put_line ('Payment Term Type:' || l_approver_type);

      -- check if there is/are any non-standard clauses.
      OPEN std_nonstd_cl_cnt ('N');

      FETCH std_nonstd_cl_cnt
       INTO l_non_std_cl_cnt;

      CLOSE std_nonstd_cl_cnt;

      IF l_non_std_cl_cnt > 0
      THEN
         l_approver_type := 'NONSTD';

         IF l_which = 1
         THEN
            l_which := 2;
         ELSE
            l_which := 3;
         END IF;
      END IF;

      DBMS_OUTPUT.put_line ('non_std_clause_cnt:' || l_non_std_cl_cnt);
      DBMS_OUTPUT.put_line ('l_which:' || l_which);
      DBMS_OUTPUT.put_line ('l_approver_type:' || l_approver_type);

      IF l_approver_type = 'STD'
      THEN
         DBMS_OUTPUT.put_line
                ('************Fetching Standard Approvers*******************');

         -- fetch the standard approvers
         FOR appr IN std_approvers (l_org_id)
         LOOP
            DBMS_OUTPUT.put_line ('Standard Approver:' || appr.person_id);
            l_table_index := l_table_index + 1;
            lt_unsorted.EXTEND;
            lt_unsorted (l_table_index) :=
                          xxha_oe_bsa_appr_obj (appr.person_id, appr.ranking);
         END LOOP;

         DBMS_OUTPUT.put_line ('6');    -- standard approvers logic ends here.
      ELSE                        --- non standard approvers logic starts here
         IF l_which <> 3
         THEN
            DBMS_OUTPUT.put_line
               ('************Fetching NON Standard Approvers****************');
            DBMS_OUTPUT.put_line ('**Payment Terms OU Approvers');

            -- Get non-standard payment term approvers
            FOR nspt IN nonstd_pt_approvers (l_org_id, 'ALL')
            LOOP
               DBMS_OUTPUT.put_line (   'Non-Standard Payment Approver:'
                                     || nspt.person_id
                                    );
               lt_unsorted.EXTEND;
               l_table_index := l_table_index + 1;
               lt_unsorted (l_table_index) :=
                           xxha_oe_bsa_appr_obj (nspt.person_id, nspt.ranking);
               l_nonstd_pt_cnt := l_nonstd_pt_cnt + 1;
            END LOOP;

            IF l_nonstd_pt_cnt =
                  0
                --If Non standard payment term Approvers not found at OU level
            THEN
               --DBMS_OUTPUT.put_line ('l_nonstd_pt_cnt  ' || l_nonstd_pt_cnt);
               DBMS_OUTPUT.put_line
                  ('Non standard payment term Approvers not found at OU level'
                  );
               l_nonstd_pt_req_undef := 'Y';
            END IF;
         ELSE
            l_nonstd_pt_cnt := 1;
DBMS_OUTPUT.put_line ('here now');
-- to make sure it does not fetch undefined approvers.
         END IF;

         FOR bdiv IN bdivs
         LOOP
            l_bdiv_cnt := l_bdiv_cnt + 1;
            l_bdiv := bdiv.bdiv;

            IF l_which <> 3
            THEN
               DBMS_OUTPUT.put_line
                      (   '****Fetching Non-Standard Payment BDIV Approvers:'
                       || bdiv.bdiv
                      );
               DBMS_OUTPUT.put_line ('**Payment Terms OU/BDIV Approvers');
               l_nonstd_undef_pt_cnt := 0;

               FOR nspt IN nonstd_pt_approvers (l_org_id, l_bdiv)
               LOOP
                  DBMS_OUTPUT.put_line (   'Non-Standard Payment BDVI:'
                                        || l_bdiv
                                        || 'Approver:'
                                        || nspt.person_id
                                       );
                  lt_unsorted.EXTEND;
                  l_table_index := l_table_index + 1;
                  lt_unsorted (l_table_index) :=
                           xxha_oe_bsa_appr_obj (nspt.person_id, nspt.ranking);
                  l_nonstd_undef_pt_cnt := l_nonstd_undef_pt_cnt + 1;
               --Added by Vijay 04/27/10
               END LOOP;

               IF l_nonstd_undef_pt_cnt =
                     0
    --If non Standard Payment term approvers not found business devision level
               THEN
                  /*DBMS_OUTPUT.put_line (   'l_nonstd_undef_pt_cnt '
                                        || l_nonstd_undef_pt_cnt
                                       );*/
                  l_nonstd_pt_req_undef := 'Y';
               END IF;
            END IF;
         END LOOP;

         /*DBMS_OUTPUT.put_line ('VJ_l_bdiv_cnt ' || l_bdiv_cnt);
         DBMS_OUTPUT.put_line (   'l_nonstd_undef_pt_cnt '
                               || l_nonstd_undef_pt_cnt
                              );*/
         IF l_bdiv_cnt = 0 OR NVL (l_nonstd_pt_req_undef, 'N') = 'Y'
         THEN
            DBMS_OUTPUT.put_line
               ('**Undefined Approvers, If none of BSA line has got BDIV or if no non-std payment approvers'
               );
            DBMS_OUTPUT.put_line ('****Fetching Undefined Approvers --level1');

            -- if no bdiv found then fetch undefined approvers
            FOR nua IN nonstd_undefined_appr (l_org_id)
            LOOP
               DBMS_OUTPUT.put_line ('Undefined Approvers:' || nua.person_id);
               lt_unsorted.EXTEND;
               l_table_index := l_table_index + 1;
               lt_unsorted (l_table_index) :=
                            xxha_oe_bsa_appr_obj (nua.person_id, nua.ranking);
            END LOOP;
/*--Commented by Vijay 04/27/10
            IF l_bdiv_cnt = 0 THEN
               RETURN;
            END IF;*/
         END IF;

         IF l_which IN (2, 3)
         THEN
            DBMS_OUTPUT.put_line
                          ('**Fetching Non-Std Clause Types/Titles approvers');

            FOR nscty IN nstd_cl_types
            LOOP
               l_cnt := 0;
               DBMS_OUTPUT.put_line (   '****Non-Std Clause Type:'
                                     || nscty.clause_type
                                    );

               -- OU level approvers
               FOR nsctya IN nonstd_cl_type_appr (l_org_id,
                                                        'ALL',
                                                  nscty.clause_type
                                                 )
               LOOP
                  DBMS_OUTPUT.put_line (   'Non-Std Clause Type OU approver:'
                                        || nsctya.person_id
                                       );
                  lt_unsorted.EXTEND;
                  l_table_index := l_table_index + 1;
                  lt_unsorted (l_table_index) :=
                       xxha_oe_bsa_appr_obj (nsctya.person_id, nsctya.ranking);
                  l_cnt := l_cnt + 1;
               END LOOP;

               IF l_cnt = 0
               THEN
                  DBMS_OUTPUT.put_line
                     ('******Non Std Type level approvers not found, Search for Title level approvers.....'
                     );

                  -- If no approvers for Clause type, get OU level approvers for Clause Title
                  FOR nsct IN nstd_cl_titles (nscty.clause_type)
                  LOOP
                     DBMS_OUTPUT.put_line (   '********Non-Std Clause Title:'
                                           || nsct.clause_title
                                          );
                     l_nonstd_undef_cnt := 0;

                     FOR nscta IN nonstd_cl_title_appr (l_org_id,
                                                        'ALL',
                                                        nsct.clause_title
                                                       )
                     LOOP
                        DBMS_OUTPUT.put_line
                                      (   'Non-Std Clause Title OU Approver:'
                                       || nscta.person_id
                                      );
                        lt_unsorted.EXTEND;
                        l_table_index := l_table_index + 1;
                        lt_unsorted (l_table_index) :=
                           xxha_oe_bsa_appr_obj (nscta.person_id,
                                                 nscta.ranking
                                                );
                        l_nonstd_undef_cnt := l_nonstd_undef_cnt + 1;
                     /*DBMS_OUTPUT.put_line (   'VJ_l_nonstd_undef_cnt LOOP '
                                           || l_nonstd_undef_cnt
                                          );*/
                     END LOOP;
                  END LOOP;

                  IF NVL (l_nonstd_undef_cnt, 0) = 0
                  THEN
                     --IF NVL(l_nonstd_undef_cnt,0) = 0 AND NVL(l_nonstd_req_undef,'N') = 'N' THEN --Commented by Vijay 04/27/10
                     DBMS_OUTPUT.put_line
                        ('OU Level Approvers Not Found for the Clause Title ');
                     /*DBMS_OUTPUT.put_line (   'VJ_l_nonstd_req_undef IF1 '
                                           || l_nonstd_req_undef
                                          );
                     DBMS_OUTPUT.put_line (   'VJ_l_nonstd_undef_cnt IF1 '
                                           || l_nonstd_undef_cnt
                                          );*/
                     l_nonstd_req_undef := 'Y';
                  END IF;
               END IF;

               DBMS_OUTPUT.put_line ('****Non Std Clause Type BDIV approvers');

               -- BDIV approvers
               FOR bdiv IN bdivs
               LOOP
                  DBMS_OUTPUT.put_line
                             (   '******Non Standard BDIV Clause Type, BDIV:'
                              || bdiv.bdiv
                             );
                  l_bdiv := bdiv.bdiv;
                  l_cnt := 0;

                  FOR nsctya IN nonstd_cl_type_appr (l_org_id,
                                                     l_bdiv,
                                                     nscty.clause_type
                                                    )
                  LOOP
                     DBMS_OUTPUT.put_line
                                 (   'Non Stadard BDIV Clause Type Approver:'
                                  || nsctya.person_id
                                 );
                     lt_unsorted.EXTEND;
                     l_table_index := l_table_index + 1;
                     lt_unsorted (l_table_index) :=
                        xxha_oe_bsa_appr_obj (nsctya.person_id,
                                              nsctya.ranking);
                     l_cnt := l_cnt + 1;
                     l_nonstd_req_undef := 'N'; --DL added line 6/24/10
                  END LOOP;

                  IF l_cnt = 0
                  THEN
                     DBMS_OUTPUT.put_line
                        ('********Non Std Clause Type BDIV approvers not found. Search for Title approvers...'
                        );

                     -- If no clause type BDIV level approvers, get BDIV cluase title approvers.
                     FOR nsct IN nstd_cl_titles (nscty.clause_type)
                     LOOP
                        DBMS_OUTPUT.put_line
                              (   '**********Non Standard BDIV clause Title:'
                               || nsct.clause_title
                              );
                        l_bdiv := bdiv.bdiv;
                        l_nonstd_undef_cnt := 0;

                        FOR nscta IN nonstd_cl_title_appr (l_org_id,
                                                           l_bdiv,
                                                           nsct.clause_title
                                                          )
                        LOOP
                           DBMS_OUTPUT.put_line
                               (   'Non Standard BDIV Clause Title Approver:'
                                || nscta.person_id
                               );
                           lt_unsorted.EXTEND;
                           l_table_index := l_table_index + 1;
                           lt_unsorted (l_table_index) :=
                              xxha_oe_bsa_appr_obj (nscta.person_id,
                                                    nscta.ranking
                                                   );
                           l_nonstd_undef_cnt := l_nonstd_undef_cnt + 1;
                        END LOOP;
                     END LOOP;

                     --IF NVL(l_nonstd_undef_cnt,0) = 0 AND NVL(l_nonstd_req_undef,'N') = 'N' THEN
                     IF NVL (l_nonstd_undef_cnt, 0) = 0
                     THEN
                        /*DBMS_OUTPUT.put_line (   'VJ_l_nonstd_req_undef '
                                              || l_nonstd_req_undef
                                             );*/
                        DBMS_OUTPUT.put_line
                           ('BDIV Level Approvers Not Found for the Clause Title '
                           );
                        l_nonstd_req_undef := 'Y';
                     else ---DL added else clause 6/24/10
                        l_nonstd_req_undef := 'N';
                     END IF;
                  END IF;
               END LOOP;
            END LOOP;

            l_cnt := 0;

            SELECT COUNT (*)
              INTO l_cnt
              FROM oe_blanket_lines_all obla
             WHERE obla.header_id = p_transactionid
               AND NOT EXISTS (
                      SELECT 1
                        FROM mtl_item_categories mic,
                             mtl_categories mc,
                             mtl_category_sets mcs,
                             xxha_oe_prdline_bdiv_mapping bdiv,
                             mtl_parameters mp
                       WHERE obla.inventory_item_id = mic.inventory_item_id
                         AND mp.organization_code = 'MST'
                         AND mic.organization_id = mp.organization_id
                         AND UPPER (mcs.category_set_name) = 'INVENTORY'
                         AND mcs.category_set_id = mic.category_set_id
                         AND mic.category_id = mc.category_id
                         AND bdiv.product_line = mc.segment1)
               --exclude the undefined approvals for certain product lines DL 7/20/10
               AND NOT EXISTS (
                      SELECT 1
                        FROM mtl_item_categories mic,
                             mtl_categories mc,
                             mtl_category_sets mcs,
                             mtl_parameters mp
                       WHERE obla.inventory_item_id = mic.inventory_item_id
                         AND mp.organization_code = 'MST'
                         AND mic.organization_id = mp.organization_id
                         AND UPPER (mcs.category_set_name) = 'INVENTORY'
                         AND mcs.category_set_id = mic.category_set_id
                         AND mic.category_id = mc.category_id
                         AND mc.segment1 in ('MS','SV'));
                  

            --DBMS_OUTPUT.put_line ('count is: '||to_char(l_cnt));
            IF l_cnt <> 0
                         -- if there is any BSA line for which BDIV can not be determined.
               OR l_nonstd_req_undef = 'Y'
            -- If there is any Non Std Clause Type/Title having no approvers.
            THEN
               /*DBMS_OUTPUT.put_line ('VJ_l_cnt ' || l_cnt);
               DBMS_OUTPUT.put_line (   'VJ_l_nonstd_req_undef '
                                     || l_nonstd_req_undef
                                    );*/
               --know if any BSA line did not mapped to BDIV.
               DBMS_OUTPUT.put_line ('Undefind approvers --level2');

               FOR nua IN nonstd_undefined_appr (l_org_id)
               LOOP
                  DBMS_OUTPUT.put_line ('Undefined approver:' || nua.person_id
                                       );
                  lt_unsorted.EXTEND;
                  l_table_index := l_table_index + 1;
                  lt_unsorted (l_table_index) :=
                             xxha_oe_bsa_appr_obj (nua.person_id, nua.ranking);
               END LOOP;
            END IF;
         END IF;
      END IF;
    end if;

      -- sorting the approvers based on approver ranking after all have been derived.
      IF lt_unsorted.COUNT <> 0
      THEN
         SELECT CAST
                   (MULTISET (SELECT   xxha_oe_bsa_appr_obj (person_id,
                                                             ranking
                                                            )
                                  FROM TABLE (lt_unsorted)
                              ORDER BY ranking, person_id
                             ) AS xxha_oe_bsa_apprs
                   )
           INTO lt_sorted
           FROM DUAL;

         DBMS_OUTPUT.put_line (LPAD ('Person_id', 10) || LPAD ('Ranking', 10));
         DBMS_OUTPUT.put_line (LPAD ('---------', 10) || LPAD ('-------', 10));
         l_temp_check := NULL;

         FOR i IN lt_sorted.FIRST .. lt_sorted.COUNT
         LOOP
            -- Elemenating Duplicates
            IF    (l_temp_check IS NULL)
               OR (l_temp_check <> lt_sorted (i).person_id)
            THEN
               DBMS_OUTPUT.put_line (   LPAD (lt_sorted (i).person_id, 10)
                                     || LPAD (lt_sorted (i).ranking, 10)
                                    );
               l_temp_check := lt_sorted (i).person_id;
               PIPE ROW (lt_sorted (i).person_id);
            END IF;
         END LOOP;
      END IF;
   END approver_list;
END xxha_oe_bsa_ame_approval_pkg;
/
