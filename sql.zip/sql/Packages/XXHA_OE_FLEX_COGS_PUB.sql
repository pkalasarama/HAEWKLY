CREATE OR REPLACE PACKAGE XXHA_OE_FLEX_COGS_PUB AS
/*************************************

Modification History:
  2011-06-27  Eric Rossing  Added function GET_SALESREP_ID to replace function in OE_FLEX_COGS_PUB
**************************************/

--
-- PUBLIC FUNCTIONS
--

PROCEDURE Get_Order_Line_Type
(       itemtype    IN VARCHAR2,
	itemkey     IN VARCHAR2,
	actid       IN NUMBER,
	funcmode    IN VARCHAR2,
result OUT NOCOPY VARCHAR2);

-- 2011-06-27 - Eric Rossing
-- Name
--  GET_SALESREP_ID
-- Purpose
-- Derives the salesrep's ID
-- Arguments
--    Internal Name for the WF Item Type
--    WF Item Key
--    ID Number of thw WF activity
--    Result
-- This is a copy of the function from OE_FLEX_COGS_PUB, modified to try to
-- get the SalesRep ID from the order line before the line sales credit
PROCEDURE GET_SALESREP_ID(ITEMTYPE  IN VARCHAR2,
	    	   ITEMKEY     IN VARCHAR2,
		   ACTID       IN NUMBER,
		   FUNCMODE    IN VARCHAR2,
RESULT OUT NOCOPY VARCHAR2);

END XXHA_OE_FLEX_COGS_PUB;

/


CREATE OR REPLACE PACKAGE BODY XXHA_OE_FLEX_COGS_PUB AS
-- +=====================================================================+
-- |                   Oracle USA Inc.                                   |
-- |                   Braintree, USA                                    |
-- +=====================================================================+
-- |                                                                     |
-- | $Id$                                                                |
-- | FILENAME                                                            |
-- |                                                                     |
-- |  XXHA_WFCOGS_EXT_PKG.pkb                                            |
-- |                                                                     |
-- | PACKAGE NAME                                                        |
-- |                                                                     |
-- |  XXHA_OE_FLEX_COGS_PUB                                              |
-- |                                                                     |
-- |Description      :  Script to Create the Package Body for Haemonetics|
-- |                    COGS Account Generation Process.                 |
-- |                                                                     |
-- |                                                                     |
-- |Change History:                                                      |
-- |---------------                                                      |
-- |Version  Date        Author         Remarks                          |
-- +-------  ----------- -------------- ---------------------------------+
-- |Draft 1A 27-Nov-2006 Ajit.P              Initial Version.
-- |Draft 1B 04-Dec-2006 Ajit.P              Reviewed
-- |1.0      05-Dec-2006 Ajit.P              Baselined after review and test
-- |1.1      12-Dec-2006 Ajit.P              After Alex tested
-- |2.0      19-Dec-2007 L.Richards          Modify Get_Order_Line_Type - if
-- |                                         line is of type Internal Order
-- |                                         fetch the Intercompany COGS
-- |                                         Segment Value from profile
-- |3.0      19-May-2009 Suresh Ramamoorthy  Derived 7th Intercompany segment from Bill-To site Revenue account for Internal Sales Order created from IRQs
-- |4.0      01-Jul-2009 Suresh Ramamoorthy  Modified Get_Order_Line_Type - if
-- |                                         line is of type "Mfg"
-- |                                         fetch the Intercompany COGS
-- |                                         Segment Value from the Profile: "HAE: Mfg COGS Account"
-- |5.0      27-Jun-2011 Eric Rossing        Modified to add GET_SALESREP_ID from
-- |                                         OE_FLEX_COGS_PUB package. This copy
-- |                                         is edited to try to retrieve the
-- |                                         Salesrep ID from the order line
-- |                                         before checking the sales credits.
-- +=====================================================================+


--
-- PUBLIC FUNCTIONS
--

/*===========================================================================+
 | Name:  Get_Order_Line_Type                                              |
 | Purpose: Determines whether an Order Line Type is :                      |
 |    Equipment Placement:          Like Equipment Placement                |
 |    Internal Sales Order:         Like Internal Sales Order               |
 |    Others:                       Any other line type                     |
 +===========================================================================*/

PROCEDURE Get_Order_Line_Type

-- Arguments
--    Internal Name for the WF Item Type
--    WF Item Key
--    ID Number of thw WF activity
--    Result
(
	itemtype    IN VARCHAR2,
	itemkey     IN VARCHAR2,
	actid       IN NUMBER,
	funcmode    IN VARCHAR2,
	result      OUT NOCOPY VARCHAR2)

IS

    l_order_line_type_id            NUMBER;
    l_order_line_id                 NUMBER;
    l_order_line_type	            VARCHAR2(50);
    lc_segment2                     VARCHAR2(25); -- Product Line Segment
    lc_segment6                     VARCHAR2(25); -- Account Segment
    lc_segment7                     VARCHAR2(25); -- Intercompany Legal Entity Segment#7
    fb_error_msg                    VARCHAR2(240) DEFAULT NULL;
    l_debug_level CONSTANT          NUMBER := oe_debug_pub.g_debug_level;
BEGIN
        -- ***************************************************
        -- Start Haemonetics COGS Account Generation Extension
        -- ***************************************************
        OE_STANDARD_WF.Set_Msg_Context(actid);

	IF l_debug_level > 0 THEN
           oe_debug_pub.add('Entering XXHA_OE_FLEX_COGS_PUB.Get_Order_Line_Type',1);
        END IF;
	IF 	(FUNCMODE = 'RUN') THEN

       	l_order_line_id:= wf_engine.GetItemAttrNumber(itemtype,itemkey,'LINE_ID');

        IF l_debug_level > 0 THEN
	       oe_debug_pub.add('Input Paramerers : ',2);
	       oe_debug_pub.add('Order Line ID :'|| to_char(l_order_line_id),2);
        END IF;

       	IF (l_order_line_id IS NOT NULL) THEN

             BEGIN

               SELECT line_type_id
               INTO   l_order_line_type_id
               FROM   oe_order_lines_all
               WHERE  line_id = l_order_line_id;

             EXCEPTION
               WHEN NO_DATA_FOUND THEN
                 wf_engine.setItemAttrText(itemtype,itemkey,'ERROR_MESSAGE','No line type id found in oe_order_lines_all');
                 result :=  'COMPLETE:FAILURE';
                 RETURN;

             END;
         	wf_engine.setItemAttrNumber(itemtype,itemkey,'ORDER_TYPE_ID',l_order_line_type_id);

             IF l_debug_level > 0 THEN
               oe_debug_pub.add('Output : ',2);
               oe_debug_pub.add('Order Type Id :'|| l_order_line_type_id,2);
             END IF;

       	ELSE
             result :=  'COMPLETE:FAILURE';
             RETURN;
       	END IF; -- l_order_line_id


       	IF (l_order_line_type_id IS NOT NULL) THEN

          BEGIN

            SELECT name
            INTO   l_order_line_type
            FROM   oe_transaction_types
            WHERE  transaction_type_id = l_order_line_type_id
            AND    transaction_type_code = 'LINE';

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              wf_engine.setItemAttrText(itemtype,itemkey,'ERROR_MESSAGE','No line type code found in oe_transaction_types');
              result :=  'COMPLETE:FAILURE';
              RETURN;

          END;
         	wf_engine.setItemAttrText(itemtype,itemkey,'ORDER_LINE_TYPE_CODE',l_order_line_type);

          IF l_debug_level > 0 THEN
               oe_debug_pub.add('Output : ',2);
               oe_debug_pub.add('Order Line Type :'|| l_order_line_type,2);
          END IF;

       	ELSE
         	result :=  'COMPLETE:FAILURE';
	    	RETURN;
       	END IF; -- l_order_line_type

/********************************************
-- Check If Order Line Type IS LIKE one of the 3 types:
--   1.  Equipment Placement
--   2.  Internal Order Line
--   3.  Others
--
-- Since Base Language is US English as verified from oe_transaction_types_tl
-- Eg. LIKE 'FR Internal Order Line'
-- Eg. LIKE 'FR Equipment Placement'
-- ******************************************/

        -- IF Order Line Type IS LIKE '%Equipment Placement' Then


       IF l_order_line_type LIKE '%Equipment Placement' THEN

            -- Get the profile option values for both segment

            -- SEGMENT2
            -- HAE: Equipment Placement COGS Product Line Segment
            -- HAE_EQUIPMENT_PLACEMENT_COGS_PRODUCT_LINE
            -- 000
            --
            -- SEGMENT6
            -- HAE: Equipment Placement COGS Account Segment
            -- HAE_EQUIPMENT_PLACEMENT_COGS_ACCOUNT
            -- 151910
            --

	    lc_segment2 := FND_PROFILE.VALUE('HAE_EQUIPMENT_PLACEMENT_COGS_PRODUCT_LINE');
	    lc_segment6 := FND_PROFILE.VALUE('HAE_EQUIPMENT_PLACEMENT_COGS_ACCOUNT');

            IF lc_segment2 IS NULL THEN

                 lc_segment2 := '000';   -- Alex 30-Nov-06 Defaulting value 000 is better option than Erroring out
                 --wf_engine.setItemAttrText(itemtype,itemkey,'ERROR_MESSAGE','Custom Profile Option NOT defined for HAE: Equipment Placement COGS Product Line Segment');
                 --result :=  'COMPLETE:FAILURE';
                 --RETURN;
            END IF;

            IF lc_segment6 IS NULL THEN

                 lc_segment2 := '151910'; -- Alex 30-Nov-06 Defaulting value 151910 is better option than Erroring out
                 --wf_engine.setItemAttrText(itemtype,itemkey,'ERROR_MESSAGE','Custom Profile Option NOT defined for HAE: Equipment Placement COGS Account Segment');
                 --result :=  'COMPLETE:FAILURE';
                 --RETURN;
            END IF;

            IF l_debug_level > 0 THEN
               oe_debug_pub.add('HAE: Equipment Placement COGS Product Line Segment'|| lc_segment2,2);
               oe_debug_pub.add('HAE: Equipment Placement COGS Account Segment'|| lc_segment6,2);
            END IF;

            -- Set the profile value to the Workflow Attributes for both profiles

         	wf_engine.setItemAttrText(itemtype,itemkey,'HAE_COGS_PRODUCT_LINE',lc_segment2);
         	wf_engine.setItemAttrText(itemtype,itemkey,'HAE_COGS_ACCOUNT',lc_segment6);

        	result := 'COMPLETE:EQUIPMENT PLACEMENT';


       -- Start of code added by Suresh Ramamoorthy on 01-JUL-2009; refer to Rev 4.0
       -- For Contract Manufacturing derive the COGS account from a custom profile

       ELSIF l_order_line_type LIKE '%Mfg%' THEN

	    lc_segment6 := FND_PROFILE.VALUE('HAE_CONTRACT_MFG_COGS_ACCOUNT');
		    oe_debug_pub.add('HAE:Contract Mfg COGS Account Segment right from profile: '|| lc_segment6,2);
            IF lc_segment6 IS NULL THEN
               lc_segment6 := '500020'; -- Better to default that have WF error out
            END IF;

            IF l_debug_level > 0 THEN
               oe_debug_pub.add('HAE: Contract Mfg COGS Account Segment after handling IS NULL check: '|| lc_segment6,2);
            END IF;

            -- Set the profile value to the Workflow Attributes for both profiles
            wf_engine.setItemAttrText(itemtype,itemkey,'HAE_MFG_COGS_ACCOUNT',lc_segment6);
            result := 'COMPLETE:CONTRACT MFG';
       -- End of code added by Suresh Ramamoorthy on 01-JUL-2009; refer to Rev 4.0


       -- IF Order Line Type IS LIKE '%Internal Order Line Then
	   ELSIF l_order_line_type LIKE '%Internal Order Line' THEN

            -- <Rev 2.0 : For Internal Order Line, fetch the Intercompany COGS segment value from profile

            -- SEGMENT6
            -- HAE: Equipment Placement COGS Account Segment
            -- HAE_INTERCOMPANY_COGS_ACCOUNT
            -- Default to 460400 is not found
            --

	    lc_segment6 := FND_PROFILE.VALUE('HAE_INTERCOMPANY_COGS_ACCOUNT');

            IF lc_segment6 IS NULL THEN
               lc_segment6 := '460400'; -- Better to default that have WF error out
            END IF;

            IF l_debug_level > 0 THEN
               oe_debug_pub.add('HAE: Intercompany COGS Account Segment'|| lc_segment6,2);
            END IF;

            -- Set the profile value to the Workflow Attributes for both profiles
            wf_engine.setItemAttrText(itemtype,itemkey,'HAE_INTERCO_COGS_ACCOUNT',lc_segment6);

            -- Rev 2.0>

        -- Start of code added by Suresh Ramamoorthy on 19-MAY-2009; refer to Rev 3.0
        begin
          select gcc.segment7
          into   lc_segment7
          from   gl_code_combinations gcc
          ,      hz_cust_site_uses_all bill_su
          ,      oe_order_lines_all oola
          where  bill_su.site_use_id = oola.invoice_to_org_id
          and    bill_su.site_use_code = 'BILL_TO'
          and    gcc.code_combination_id = bill_su.gl_id_rev
          and    oola.line_id = l_order_line_id;

          if l_debug_level > 0 THEN
	       oe_debug_pub.add('HAE: Intercompany Legal Entity Segment7'|| lc_segment7,2);
	      end if;

        exception
          when no_data_found then
            null;
          when others then
            null;
        end;
        -- Set the profile value to the Workflow Attributes for both profiles
        wf_engine.setItemAttrText(itemtype,itemkey,'HAE_INTERCO_COGS_LE',lc_segment7);
       -- End of code added by Suresh Ramamoorthy on 19-MAY-2009; refer to Rev 3.0
        result := 'COMPLETE:INTERNAL ORDER LINE';

       ELSE

                result := 'COMPLETE:OTHERS';

       END IF;


            IF l_debug_level > 0 THEN
               oe_debug_pub.add('Order Line Type :'|| l_order_line_type,2);
            END IF;

     	RETURN;

     ELSIF (funcmode = 'CANCEL') THEN
         result :=  wf_engine.eng_completed;
         RETURN;
     ELSE
         result := '';
         RETURN;
     END IF;
     -- ***************************************************
     -- End Haemonetics COGS Account Generation Extension
     -- ***************************************************

EXCEPTION
   WHEN OTHERS THEN
        wf_core.context('XXHA_OE_FLEX_COGS_PUB','Get_Order_Line_Type',
                        itemtype,itemkey,TO_CHAR(actid),funcmode);
                result :=  'COMPLETE:FAILURE';
                -- start data fix project
                OE_STANDARD_WF.Add_Error_Activity_Msg(p_actid => actid,
                                          p_itemtype => itemtype,
                                          p_itemkey => itemkey);
                OE_STANDARD_WF.Save_Messages;
                OE_STANDARD_WF.Clear_Msg_Context;
                -- end data fix project
		RAISE;
END Get_Order_Line_Type;

-- 2011-06-27 Eric Rossing
/*===========================================================================+
 | Name: GET_SALESREP_ID                                                     |
 | Purpose: Derives the salesrep's ID                                        |
 +===========================================================================*/
-- This is a copy of the function from OE_FLEX_COGS_PUB, modified to try to
-- get the SalesRep ID from the order line before the line sales credit

PROCEDURE Get_Salesrep_Id
(
	itemtype  	IN VARCHAR2,
	itemkey     IN VARCHAR2,
	actid       IN NUMBER,
	funcmode    IN VARCHAR2,
	result      OUT NOCOPY VARCHAR2)

IS
	l_salesrep_id			VARCHAR2(240) DEFAULT NULL;
	l_order_line_id			NUMBER;
	l_header_id			     NUMBER;
	fb_error_msg			VARCHAR2(240) DEFAULT NULL;
	l_error_msg				VARCHAR2(240) DEFAULT NULL;
        l_debug_level CONSTANT          NUMBER := oe_debug_pub.g_debug_level;
BEGIN
        -- start data fix project
        OE_STANDARD_WF.Set_Msg_Context(actid);
        -- end data fix project
        IF l_debug_level > 0 THEN
           oe_debug_pub.add('Entering OE_FLEX_COGS_PUB.GET_SALESREP_ID',2);
        END IF;
	IF 	(FUNCMODE = 'RUN') THEN
       	l_order_line_id:= wf_engine.GetItemAttrNumber(itemtype,itemkey,'LINE_ID');
       	l_header_id:= wf_engine.GetItemAttrNumber(itemtype,itemkey,'HEADER_ID');

        IF l_debug_level > 0 THEN
            oe_debug_pub.add('Input Paramerers : ',2);
	    oe_debug_pub.add('Order Line ID :'|| to_char(l_order_line_id),2);
	    oe_debug_pub.add('Order Header ID :'|| to_char(l_header_id),2);
        END IF;
       	l_salesrep_id := NULL;

       	IF 	(l_order_line_id IS NOT NULL) THEN
-- 2011-06-27 Eric Rossing - add block to check order line for salesrep ID before
--                           checking sales credits
          BEGIN
            SELECT    SALESREP_ID
            INTO      l_salesrep_id
            FROM      OE_ORDER_LINES_ALL
            WHERE     LINE_ID = L_ORDER_LINE_ID
            AND       SALESREP_ID = (
                SELECT MIN(SALESREP_ID)
                FROM OE_ORDER_LINES_ALL OL
                WHERE OL.LINE_ID = L_ORDER_LINE_ID
                )
            AND ROWNUM = 1;
          EXCEPTION
              WHEN NO_DATA_FOUND THEN
                  IF l_debug_level > 0 THEN
                      oe_debug_pub.add('Sales rep not found on order line',2);
                  END IF;
         	BEGIN
	       		SELECT    SALESREP_ID
	       		INTO      l_salesrep_id
	       		FROM      OE_SALES_CREDITS
	       		WHERE     LINE_ID = L_ORDER_LINE_ID
	       		AND       SALESREP_ID = (
							   	SELECT MIN(SALESREP_ID)
					   			FROM OE_SALES_CREDITS SC ,
						   		OE_SALES_CREDIT_TYPES SCT
					   			WHERE SC.LINE_ID = L_ORDER_LINE_ID
								AND   SC.SALES_CREDIT_TYPE_ID = SCT.SALES_CREDIT_TYPE_ID
					   			AND SCT.QUOTA_FLAG = 'Y'
					   			AND SC.PERCENT = (
						  		SELECT MAX(PERCENT)
						  		FROM OE_SALES_CREDITS SC, --Bug4091119 start
								OE_SALES_CREDIT_TYPES SCT
						  		WHERE SC.LINE_ID = L_ORDER_LINE_ID
								AND   SC.SALES_CREDIT_TYPE_ID = SCT.SALES_CREDIT_TYPE_ID
								AND   SCT.QUOTA_FLAG = 'Y' --Bug4091119 end
                           		                   )
                           				)
            	AND ROWNUM = 1;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN
	                IF l_debug_level > 0 THEN
                           oe_debug_pub.add('Sales rep not found at line level',2);
                        END IF;
				BEGIN
			  	     SELECT    SALESREP_ID
	       		     INTO      l_salesrep_id
	       		     FROM      OE_SALES_CREDITS
	       		     WHERE     HEADER_ID = l_header_id
					AND       LINE_ID IS NULL
	       		     AND       SALESREP_ID = (
							   	SELECT MIN(SALESREP_ID)
					   			FROM OE_SALES_CREDITS SC ,
						   		OE_SALES_CREDIT_TYPES SCT
					   			WHERE SC.HEADER_ID = L_HEADER_ID
					               AND   SC.LINE_ID IS NULL
								AND   SC.SALES_CREDIT_TYPE_ID = SCT.SALES_CREDIT_TYPE_ID
					   			AND SCT.QUOTA_FLAG = 'Y'
					   			AND SC.PERCENT = (
						  		SELECT MAX(PERCENT)
						  		FROM OE_SALES_CREDITS SC, --Bug4091119 start
								OE_SALES_CREDIT_TYPES SCT
						  		WHERE SC.HEADER_ID = L_HEADER_ID
								AND   SC.LINE_ID IS NULL
								AND   SC.SALES_CREDIT_TYPE_ID = SCT.SALES_CREDIT_TYPE_ID
								AND   SCT.QUOTA_FLAG = 'Y' --Bug4091119 end
                           		                   )
                           				)
            	          AND ROWNUM = 1;

				EXCEPTION

				     WHEN NO_DATA_FOUND THEN
					FND_MESSAGE.SET_NAME('ONT','OE_COGS_SALESREP_NOT_FOUND');
					FND_MESSAGE.SET_TOKEN('LINEID',l_order_line_id);
					fb_error_msg := FND_MESSAGE.GET_ENCODED;
					FND_MESSAGE.SET_ENCODED(fb_error_msg);
					l_error_msg := FND_MESSAGE.GET;
         				wf_engine.setItemAttrText(itemtype,itemkey,'ERROR_MESSAGE',l_error_msg);
         				result :=  'COMPLETE:FAILURE';
         				RETURN;
                    END;
         	END;
          END; -- of new block to try order line first (added 2011-06-27 by Eric Rossing)
         	wf_engine.setItemAttrNumber(itemtype,itemkey,'SALESREP_ID',TO_NUMBER(l_salesrep_id));
         	result := 'COMPLETE:SUCCESS';
       	ELSE
         	result :=  'COMPLETE:FAILURE';
	    	RETURN;
       	END IF;
	    IF l_debug_level > 0 THEN
               oe_debug_pub.add('Output : ',2);
	       oe_debug_pub.add('Salesrep ID :'|| l_salesrep_id,2);
            END IF;
 	RETURN;
	ELSIF (funcmode = 'CANCEL') THEN
        result :=  wf_engine.eng_completed;
        RETURN;
    ELSE
        result := '';
        RETURN;
     END IF;
EXCEPTION
	WHEN OTHERS THEN
		wf_core.context('XXHA_OE_FLEX_COGS_PUB','GET_SALESREP_ID',
		itemtype,itemkey,TO_CHAR(actid),funcmode);
		result :=  'COMPLETE:FAILURE';
                -- start data fix project
                OE_STANDARD_WF.Add_Error_Activity_Msg(p_actid => actid,
                                          p_itemtype => itemtype,
                                          p_itemkey => itemkey);
                OE_STANDARD_WF.Save_Messages;
                OE_STANDARD_WF.Clear_Msg_Context;
                -- end data fix project
		RAISE;
END Get_Salesrep_Id;


END XXHA_OE_FLEX_COGS_PUB;

/
