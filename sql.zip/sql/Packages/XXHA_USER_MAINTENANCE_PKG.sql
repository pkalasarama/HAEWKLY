create or replace PACKAGE "XXHA_USER_MAINTENANCE_PKG"
AS
  --$Header$
  /*******************************************************************************************
  *Program Name: HAE_User_Maintenance_pkg
  *
  *Description: This package automates manual steps done during the off-boarding (termination) process
  *       a) end date user's login account
  *
  *Created By: David Lund
  *Date:   JAN-24-2011
  *
  *Modification Log:
  *Developer            Date                 Description
  *-----------------    ------------------   ------------------------------------------------
  * David Lund          Jan-24-2011          Created this Package
  * David Lund          Oct-24-2011          Added auto_assign and assign_ess procedures
  * David Lund          Nov-21-2011          changed auto_assign to remove the europe restriction
  * David Lund          Feb-02-2012          Added procedure populate_def_po_acct
  * Manuel Fernandes    Jul-10-2012          changed auto_assign to remove end date if assignment exists
  * Venkatesh Sarangam  Apr-05-2013          Added procedure assign_mss
  * David Lund          May-01-2013          Changed auto_assign MSS to remove end date if assignment exists
  * Bruce Marcoux       Jun-28-2013          Added procedure revoke_ess
  * Manuel Fernandes    Dec-03-2013          Added "assign_responsibility('HAE_CWK_MAINTENANCE');" in auto_assign
  * Manuel Fernandes    May-14-2014          Added procedure end_responsibility_assignments
  *                                          End Date all responsibilty assignments for terminated
  *                                          Users terminated date is 14 days prior to to-date
  *                                          Added "assign_responsibility('HAE_CWK_MAINTENANCE');" in auto_assign
  * Divya Kantem        Jun-30-2015          Fixed the Start date in "assign_responsibility" (Incident #INC0055908)
  * Apps Associates     Apr-01-2015          Added Procedure 'XXHA_UNASSIGN_ROLE' for Removing roles associated with Oracle Installed Base responsibility
  * Preethi Revalli     Apr-23-2015          Added procedure xxha_endate_subinv for end dating the subinventories of terminated users
  * Preethi Revalli     Apr-30-2015          Added procedure xxha_endate_buyer for end dating the buyer setup for terminated users
  * Krishna Murthy      Aug-10-2015          Added procedure xxha_del_user_apprgroup for deleting terminated user from approver group
  * Divya Kantem        Aug-25-2015          Fixed the issue with end dating buyers for the persons which are not supposed to
  * Krishna Murthy      Aug-10-2015          Added procedure xxha_del_user_apprgroup for deleting terminated user from approver group
  * Krishna Murthy      Aug-21-2015          Added procedure xxha_Endate_SaleRep for End Dating Sales Representative
  * Divya Kantem        Aug-21-2015          Added procedure xxha_enduser_apsp to end date user in APSP instance
  * Bruce Marcoux       Apr-20-2018          Modified package for Workday Processing
  *                                          - Assign Manager Self Service Responsibility if not already assigned (PROCEDURE assign_mss) � Comment out code
  *                                          - Remove Employee Self Service Responsibility for non-employees (CWK) (PROCEDURE REVOKE_ESS) � Comment out code
  *
  *******************************************************************************************/
  --
  PROCEDURE Main(
      errbuf OUT VARCHAR2 ,
      retcode OUT NUMBER ,
      p_person_id NUMBER ,
      p_user_name VARCHAR2);
  --
  --*******************************************************************
  --
  PROCEDURE end_date_user(
      p_username IN VARCHAR2);
  --
  --*******************************************************************
  --
  PROCEDURE Cancel_termed_enrollees;
  --*******************************************************************
  --
  PROCEDURE Auto_assign(
      errbuf OUT VARCHAR2 ,
      retcode OUT NUMBER);
  --****************************************************************
  PROCEDURE ASSIGN_ESS;
  --****************************************************************
  PROCEDURE ASSIGN_MSS;
  --****************************************************************
  PROCEDURE populate_def_po_acct;
  --****************************************************************
  PROCEDURE REVOKE_ESS;
  --****************************************************************
  PROCEDURE XXHA_UNASSIGN_ROLE(
      P_USERNAME VARCHAR2);
  --*******************************************************************
  PROCEDURE xxha_endate_subinv(
      p_user_name IN VARCHAR2);
  --*******************************************************************
  PROCEDURE xxha_endate_buyer(
      p_user_name IN VARCHAR2);
  --*******************************************************************
  PROCEDURE xxha_del_user_apprgroup(
      p_user_name IN VARCHAR2);
  --*******************************************************************
  PROCEDURE xxha_Endate_SaleRep(
      p_source_name IN VARCHAR2);
  --*******************************************************************
  PROCEDURE xxha_enduser_apsp(
      p_user_name IN VARCHAR2);
  --*******************************************************************
END XXHA_USER_MAINTENANCE_PKG ;