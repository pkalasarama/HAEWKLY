CREATE OR REPLACE PACKAGE xxha_EDI_validation
/*****************************************************************************************
* Name/Purpose : xxha_EDI_validation
* Description  : creates                                                                 *
*                package body xxha_EDI_validation                                        *
*                Validate EDI Data Part of RXC EDIT Process                              *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
AS
Validating_Header Boolean := False;
Procedure Payment_Term_From_Modifier(
  P_Modifier_Name Varchar2, P_Bill_To_Edi_Code Varchar2,
  X_Payment_Term_Id out Number, X_Payment_Terms out Varchar2,
  X_Error_Message Out Varchar2,
  X_Status Out Varchar2);
Procedure Reprocess_856_Out
(Err_Buf Out Varchar2, Ret_Code Out Number, P_Order_Source_Id Number, P_Header_Id Number, P_Line_Id Number);
procedure process_inbound_asn(p_delivery_num varchar2,
                         p_transaction_type_name varchar2,
                         p_user_name varchar2,
                         p_responsibility_name varchar2,
                         x_error_message out varchar2,
                         x_status out varchar2);
procedure submit_order(p_order_source_id number, p_orig_sys_document_ref varchar2, p_request_id out number);
procedure reprocess_inbound_order(err_buf out varchar2, ret_code out number, message_id varchar2);
procedure edi_xref_conversion(p_xref_category_code varchar2,
                         p_xref_standard_code varchar2,
                         x_xref_std_value in out varchar2,
                         x_xref_int_value in out varchar2,
                         x_error_message out varchar2,
                         x_status out varchar2);
procedure set_header_info(
                      p_org_id number,
                      p_orig_sys_document_ref varchar2,
                      p_warehouse_id number,
                      p_error_flag varchar2,
                      x_error_message out varchar2,
                      x_status out varchar2);
procedure get_order_source_id(
                       p_order_source_name varchar2,
                       x_order_source_id out number,
                       x_error_message out varchar2,
                       x_status out varchar2);
procedure validate_line( p_price_list_id in number default null, p_bill_to_location_code in varchar2 default null, p_ship_to_location_code in varchar2 default null, p_item_number in varchar2 default null,
                        p_price_list_name in varchar2 default null,
                        p_warehouse_code in varchar2 default null,
                        p_org_id in number default null,
                        p_order_source_id in number,
                        p_order_number in number default null,
                        p_order_line_number in number default null,
                        x_price_list_id out number,
                        x_inventory_item_id out number,
                        x_sold_to_org_id out number,
                        x_bill_to_site_use_id out number,
                        x_ship_to_site_use_id out number,
                        x_warehouse_id out number,
                        x_header_id out number,
                        x_line_id out number,
                        x_line_item_id out number,
                        x_orig_sys_document_ref out varchar2,
                        x_orig_sys_line_ref out varchar2,
                        x_request_date out date,
                        x_promise_date out date,
                        x_schedule_ship_date out date,
                        x_unit_selling_price out number,
                        x_unit_list_price out number,
                        x_ordered_quantity out number,
                        x_cancelled_quantity out number,
                        x_shipped_quantity out number,
                        x_open_quantity out number,
                        x_error_message out varchar2,
                        x_status out varchar2);
procedure validate_header(
                        p_price_list_id in number default null,
                        p_bill_to_location_code in varchar2 default null,
                        p_price_list_name in varchar2 default null,
                        p_org_id in number default null,
                        p_order_source_id in number,
                        p_order_number in number default null,
                        x_price_list_id out number,
                        x_sold_to_org_id out number,
                        x_bill_to_site_use_id out number,
                        x_header_id out number,
                        x_orig_sys_document_ref out varchar2,
                        x_error_message out varchar2,
                        x_status out varchar2);
END xxha_EDI_validation;
/


CREATE OR REPLACE PACKAGE BODY xxha_EDI_validation
/*****************************************************************************************
* Name/Purpose : xxha_EDI_validation
* Description  : creates                                                                 *
*                package body xxha_EDI_validation                                        *
*                Validate EDI Data Part of RXC EDIT Process                              *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     Manuel Fernandes     Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
AS
G_Pkg_Name                    Constant Varchar2(30) := 'XXHA_EDI_VALIDATION';
Procedure Payment_Term_From_Modifier(
  P_Modifier_Name Varchar2, P_Bill_To_Edi_Code Varchar2,
  X_Payment_Term_Id out Number, X_Payment_Terms out Varchar2,
  X_Error_Message Out Varchar2,
  X_Status Out Varchar2) is
cursor c1 is
  select qms.substitution_value payment_terms, qms.substitution_val payment_terms_id
  From Qp_Modifier_Summary_V Qms, Qp_List_Headers_All Qlh, Qp_Qualifiers_V Qq
  where qlh.name = P_Modifier_Name --'US RxC Term Substitution'
  and   qlh.list_type_code = 'PRO'
  and   qlh.source_system_code = 'QP'
  and   qlh.active_flag = 'Y'
  and   qlh.pte_code = 'ORDFUL'
  and   trunc(sysdate) >= nvl(qlh.start_date_active, trunc(sysdate))
  and   trunc(sysdate) <= nvl(qlh.end_date_active, trunc(sysdate))
  and   qms.list_header_id = qlh.list_header_id
  and   qms.substitution_context = 'TERMS'
  and   trunc(sysdate) >= nvl(qms.start_date_active, trunc(sysdate))
  and   trunc(sysdate) <= nvl(qms.end_date_active, trunc(sysdate))
  and   qms.sub_segment_name = 'PAYMENT_TERMS'
  and   qq.list_line_id = qms.list_line_id
  and   trunc(sysdate) >= nvl(qq.start_date_active, trunc(sysdate))
  and   trunc(sysdate) <= nvl(qq.end_date_active, trunc(sysdate))
  and   qq.qualifier_context = 'CUSTOMER'
  --and   qq.qualifier_attribute = 'QUALIFIER_ATTRIBUTE14'
  and exists (
    select 1
    from QP_PRC_CONTEXTS_V qpc, qp_segments_v qs
    where qpc.prc_context_code = 'CUSTOMER'
    and   qpc.prc_context_id = qs.prc_context_id
    and   qs.segment_code = 'BILL_TO'
    and   qs.segment_mapping_column = qq.qualifier_attribute
    and   qpc.prc_context_code = qq.qualifier_context
    )
  and exists
  (
     /* select c.customer_id, su.status site_status, a.status address_status, su.site_use_id, c.status customer_status, a.ece_tp_location_code, a.*
      --into x_sold_to_org_id, v_site_status, v_address_status, x_bill_to_site_use_id, v_customer_status
      from ra_site_uses_all su, ra_addresses_all a, ra_customers c
      where a.address_id = su.address_id
      And   A.Customer_Id = C.Customer_Id
      and   a.ece_tp_location_code = P_Bill_To_Edi_Code --'21574'
      and   su.site_use_code = 'BILL_TO'
      And   To_Char(Su.Site_Use_Id) = Qq.Qualifier_Attr_Value*/
    select hcc.cust_account_id customer_id, hcu.status site_status, hca.status address_status, hcu.site_use_id, hcc.status customer_status, hca.ece_tp_location_code
       From hz_cust_accounts hcc,  Hz_Cust_Acct_Sites_All Hca, Hz_Cust_Site_Uses_All Hcu
      Where Hcu.Cust_Acct_Site_Id = Hca.Cust_Acct_Site_Id
      And   Hcc.Cust_Account_Id = Hca.Cust_Account_Id
      And   Hca.Ece_Tp_Location_Code = P_Bill_To_Edi_Code    --'21574'
      And   Hcu.Site_Use_Code = 'BILL_TO'
      And   to_char(hcu.site_use_id) = Qq.Qualifier_Attr_Value
  )
  Order By Qq.Qualifier_Precedence
  ;
Begin
  X_Status := 'F';
  For I In C1 Loop
    X_Payment_Term_Id := I.Payment_Terms_Id;
    X_Payment_Terms := I.Payment_Terms;
    X_Status := 'S';
    exit;
  End Loop;
  If X_Status = 'F' Then
    X_Error_Message := 'Payment terms not found';
  End If;
  return;
End;
procedure reprocess_856_out
(err_buf out varchar2, ret_code out number, p_order_source_id number, p_header_id number, p_line_id number)
is
v_instance_id number;
begin
  select max(instance_id) instance_id into v_instance_id
  from WF_PROCESS_ACTIVITIES wpa1 where wpa1.activity_name = 'XXHA_SHIP_LINE_RAISE_EVT' and wpa1.activity_item_type = 'OEOL'
  and process_version =  (select max(process_version) from WF_PROCESS_ACTIVITIES wpa2 where wpa2.activity_name = wpa1.activity_name and wpa2.activity_item_type = wpa2.activity_item_type);
  if v_instance_id is not null then
    UPDATE wsh_new_deliveries wnd
         SET wnd.asn_status_code = NULL
    WHERE wnd.delivery_id in ( select  xdl.delivery_id from xxha_rxc_edi_delivery_lines_v xdl where xdl.source_line_id = p_line_id);
    xxha_rxc_util_pkg.raise_shipment_event('OEOL', to_char(p_line_id), v_instance_id, 'RUN', err_buf);
  else
    err_buf := 'XXHA_SHIP_LINE_RAISE_EVT process not defined';
    ret_code := 1;
  end if;
End;
procedure process_inbound_asn(p_delivery_num varchar2,
                         p_transaction_type_name varchar2,
                         p_user_name varchar2,
                         p_responsibility_name varchar2,
                         x_error_message out varchar2,
                         x_status out varchar2)
is
v_request_id number;
v_user_id number;
v_resp_id number;
v_resp_appl_id number;
v_transaction_type_id number;
x_req_phase varchar2(255);
x_req_status varchar2(255);
x_req_dev_phase varchar2(255);
x_req_dev_status varchar2(255);
x_req_message varchar2(2000);
v_boolean boolean;
begin
  begin
    select user_id into v_user_id from fnd_user where user_name = p_user_name and trunc(sysdate) between nvl(start_date,trunc(sysdate)) and nvl(end_date,trunc(sysdate));
  exception when no_data_found then
    x_error_message := x_error_message || '*USER_NOT_FOUND_OR_END_DATED';
    x_status := 'F';
  end;
  begin
    select application_id, responsibility_id into v_resp_appl_id, v_resp_id from fnd_responsibility_vl where responsibility_name = p_responsibility_name and trunc(sysdate) between nvl(start_date,trunc(sysdate)) and nvl(end_date,trunc(sysdate));
  exception when no_data_found then
    x_error_message := x_error_message || '*RESPONSIBILITY_NOT_FOUND_OR_END_DATED';
    x_status := 'F';
  end;
  begin
    select transaction_type_id into v_transaction_type_id from oe_transaction_types_tl where name like 'RxC Standard' and language = 'US';
  exception when no_data_found then
    x_error_message := x_error_message || '*ORDER_TYPE_NOT_FOUND';
    x_status := 'F';
  end;
  if p_delivery_num is null then
    x_error_message := x_error_message || '*DELIERY_NUM_NOT_PROVIDED';
    x_status := 'F';
  end if;
  if x_status = 'F' then
    return;
  end if;
  FND_GLOBAL.APPS_INITIALIZE(USER_ID=>v_user_id,RESP_ID=>v_resp_id,RESP_APPL_ID=>v_resp_appl_id);
  v_request_id := FND_REQUEST.SUBMIT_REQUEST('HAEMO'
                                           , 'XXHARXP856'
                                           , 'XXHA: Process RXP Inbound 856ASN'
                                           , SYSDATE
                                           , FALSE
                                           ,p_delivery_num
                                           ,p_transaction_type_name
                                           ,v_user_id
                                           ,v_resp_appl_id
                                           ,v_resp_id
  );
  dbms_output.put_line(to_char(v_request_id));
  dbms_output.put_line(to_char(v_user_id));
  dbms_output.put_line(to_char(v_resp_appl_id));
  dbms_output.put_line(to_char(v_resp_id));
  commit;
  if v_request_id > 0 then
    v_boolean := FND_CONCURRENT.wait_for_request(request_id => v_request_id,
                phase => x_req_phase,
                status => x_req_status,
                dev_phase  => x_req_dev_phase,
                dev_status => x_req_dev_status,
                message    => x_req_message);
    if x_req_dev_status = 'ERROR' then
      x_status := 'S';
      return;
    end if;
  else
      x_status := 'F';
      x_error_message := x_error_message || '*CONCURRENT_JOB_INITIATE_FAILED';
      return;
  end if;
end;
procedure submit_order(p_order_source_id number, p_orig_sys_document_ref varchar2, p_request_id out number)
is
v_request_id number;
begin
  v_request_id := FND_REQUEST.SUBMIT_REQUEST('ONT'
                                           , 'OEOIMP'
                                           , 'XXHA: Inbound Order Import'
                                           , SYSDATE
                                           , FALSE
                                           ,to_char(p_order_source_id)
                                           ,p_orig_sys_document_ref
                                           ,null
                                           ,'N'
                                           ,1
                                           ,1
                                           ,null
                                           ,null
                                           ,null
                                           ,null
                                           ,null
                                           ,null
                                           ,'N'
  );
end;
procedure reprocess_inbound_order(err_buf out varchar2, ret_code out number, message_id varchar2)
is
i_trigger_id number;
i_retcode pls_integer;
i_errbuf varchar2(50);
begin
  ecx_inbound_trig.reprocess(message_id,10,i_trigger_id,i_retcode,i_errbuf);
  ret_code := i_retcode;
  err_buf  := i_errbuf;
end;
procedure edi_xref_conversion(p_xref_category_code varchar2,
                         p_xref_standard_code varchar2,
                         x_xref_std_value in out varchar2,
                         x_xref_int_value  in out varchar2,
                         x_error_message out varchar2,
                         x_status out varchar2)
is
begin
  if p_xref_category_code is null then
    x_error_message := x_error_message || '*xref_category_code NOT PROVIDED';
  end if;
  if p_xref_standard_code is null then
    x_error_message := x_error_message || '*xref_standard_code NOT PROVIDED';
  end if;
  if x_xref_std_value is null and x_xref_int_value is null then
    x_error_message := x_error_message || '*standard_value or extrnal_value MUST BE PROVIDED';
  end if;
  if x_error_message is not null then
    x_status := 'F';
    return;
  end if;
  begin
    select xs.xref_std_value, xs.xref_int_value into x_xref_std_value, x_xref_int_value
    from ecx_xref_hdr_b xh, ecx_xref_standards_b xs
    where xh.xref_category_code = p_xref_category_code
    and   xref_standard_code = p_xref_standard_code
    and   xh.xref_category_id = xs.xref_category_id
    and   (x_xref_std_value is null or xs.xref_std_value = x_xref_std_value)
    and   (x_xref_int_value is null or xs.xref_int_value = x_xref_int_value);
    x_status := 'S';
  exception
    when no_data_found then
      x_error_message := x_error_message || '*NO MATCHING RECORD FOUND';
      x_status := 'F';
    when too_many_rows then
      x_error_message := x_error_message || '*MORE THAN 1 MATCH FOUND';
      x_status := 'F';
    WHEN OTHERS THEN
    IF OE_MSG_PUB.Check_Msg_Level (OE_MSG_PUB.G_MSG_LVL_UNEXP_ERROR) THEN
      OE_MSG_PUB.Add_Exc_Msg( G_PKG_NAME, 'XXHA_EDI_VALIDATE' ) ;
    END IF ;
    x_status := 'F';
    RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
  end;
  return;
end;
procedure set_header_info(
                      p_org_id number,
                      p_orig_sys_document_ref varchar2,
                      p_warehouse_id number,
                      p_error_flag varchar2,
                      x_error_message out varchar2,
                      x_status out varchar2)
IS
begin
  if p_org_id is null or p_orig_sys_document_ref is null then
    x_status := 'F';
    x_error_message := '*NO_HEADER_RECORD_INFO_PROVIDED';
    ecx_debug.pl(0, x_status ||' '||x_error_message);
    return;
  end if;
  update oe_headers_iface_all
  set error_flag = 'Y'
  where org_id = p_org_id
  and   orig_sys_document_ref = p_orig_sys_document_ref
  and   p_error_flag = 'Y'
  ;
  update oe_headers_iface_all
  set ship_from_org_id = p_warehouse_id
  where org_id = p_org_id
  and   orig_sys_document_ref = p_orig_sys_document_ref
  and   p_warehouse_id is not null
  ;
  x_status := 'S';
  ecx_debug.pl(0, x_status ||' '||x_error_message);
  return;
EXCEPTION
  WHEN OTHERS THEN
    IF OE_MSG_PUB.Check_Msg_Level (OE_MSG_PUB.G_MSG_LVL_UNEXP_ERROR) THEN
      OE_MSG_PUB.Add_Exc_Msg( G_PKG_NAME, 'XXHA_EDI_VALIDATE' ) ;
    END IF ;
    x_status := 'F';
    ecx_debug.pl(0, x_status ||' '||x_error_message);
    RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
end;
procedure get_order_source_id(
                       p_order_source_name varchar2,
                       x_order_source_id out number,
                       x_error_message out varchar2,
                       x_status out varchar2)
IS
begin
  fnd_file.put_line(fnd_file.log,'p_order_source_name =>'||p_order_source_name);
  x_order_source_id := null;
  x_error_message := null;
  x_status := null;
  select order_source_id into x_order_source_id from oe_order_sources where name = p_order_source_name;
  x_status := 'S';
  fnd_file.put_line(fnd_file.log,'order_source_id =>'||to_char(x_order_source_id));
  ecx_debug.pl(0, x_status ||' '||x_error_message);
  exception when no_data_found then
    x_error_message := substr(x_error_message ||'*ORDER_SOURCE_NOT_FOUND',1,1000);
    x_status := 'F';
    ecx_debug.pl(0, x_status ||' '||x_error_message);
end;
procedure validate_line(
                        p_price_list_id in number default null,
                        p_bill_to_location_code in varchar2 default null, p_ship_to_location_code in varchar2 default null, p_item_number in varchar2 default null,
                        p_price_list_name in varchar2 default null,
                        p_warehouse_code in varchar2 default null,
                        p_org_id in number default null,
                        p_order_source_id in number,
                        p_order_number in number default null,
                        p_order_line_number in number default null,
                        x_price_list_id out number,
                        x_inventory_item_id out number,
                        x_sold_to_org_id out number,
                        x_bill_to_site_use_id out number,
                        x_ship_to_site_use_id out number,
                        x_warehouse_id out number,
                        x_header_id out number,
                        x_line_id out number,
                        x_line_item_id out number,
                        x_orig_sys_document_ref out varchar2,
                        x_orig_sys_line_ref out varchar2,
                        x_request_date out date,
                        x_promise_date out date,
                        x_schedule_ship_date out date,
                        x_unit_selling_price out number,
                        x_unit_list_price out number,
                        x_ordered_quantity out number,
                        x_cancelled_quantity out number,
                        x_shipped_quantity out number,
                        x_open_quantity out number,
                        x_error_message out varchar2,
                        x_status out varchar2)
IS
v_return boolean;
v_price_list_valid boolean;
v_price_name_id_matched boolean;
v_item_valid boolean;
v_dummy number;
v_site_status varchar2(10);
v_address_status varchar2(10);
v_customer_status varchar2(10);
BEGIN
  fnd_file.put_line(fnd_file.log,'p_price_list_id =>'||to_char(p_price_list_id));
  fnd_file.put_line(fnd_file.log,'p_bill_to_location_code =>'||p_bill_to_location_code);
  fnd_file.put_line(fnd_file.log,'p_ship_to_location_code =>'||p_ship_to_location_code);
  fnd_file.put_line(fnd_file.log,'p_item_number =>'||p_item_number);
  fnd_file.put_line(fnd_file.log,'p_price_list_name =>'||p_price_list_name);
  fnd_file.put_line(fnd_file.log,'p_warehouse_code =>'||p_warehouse_code);
  fnd_file.put_line(fnd_file.log,'p_org_id =>'||to_char(p_org_id));
  fnd_file.put_line(fnd_file.log,'p_order_source_id =>'||to_char(p_order_source_id));
  fnd_file.put_line(fnd_file.log,'p_order_number =>'||to_char(p_order_number));
  fnd_file.put_line(fnd_file.log,'p_order_line_number =>'||to_char(p_order_line_number));
  x_error_message := null;
  v_return := true;
  v_price_list_valid := false;
  v_price_name_id_matched := true;
  -- check price list if price_list ID is given it will validate that else will proceed to price_list_name
  if p_price_list_id is null and p_price_list_name is null then
    if validating_header then
      x_error_message := substr(x_error_message ||'*PRICE_LIST_REQUIRED',1,1000);
      v_return := false;
    end if;
    validating_header := false;
  else -- price list info is required
    validating_header := false;
    if p_price_list_id is not null and p_price_list_name is not null then
      begin
        select a.price_list_id - b.price_list_id into v_dummy
        from oe_price_lists a, oe_price_lists b
        where a.price_list_id = p_price_list_id
        and   b.name = p_price_list_name;
        if v_dummy != 0 then
          v_price_name_id_matched := false;
          v_return := false;
        end if;
      exception when no_data_found then
        x_error_message := substr(x_error_message ||'*PRICE_LIST_NAME_OR_ID_NOT_FOUND',1,1000);
        v_price_name_id_matched := false;
        v_return := false;
      end;
    end if;
    if v_price_name_id_matched then
    -- will be true if id and name sent is same
      begin
         select price_list_id into x_price_list_id
         from oe_price_lists where trunc(sysdate) >= start_date_active
         and trunc(sysdate) <= nvl(end_date_active,trunc(sysdate))
         and (
              (p_price_list_id is not null and price_list_id = p_price_list_id)
              or
              (p_price_list_id is null and p_price_list_name is not null and name = p_price_list_name)
            );
        v_price_list_valid := true;
      exception when no_data_found then
        x_error_message := substr(x_error_message ||'*PRICELIST_NOT_FOUND_OR_EXPIRED',1,1000);
        v_return := false;
      end;
    end if;
  end if;
  -- validate Item
  v_item_valid := false;
  if p_item_number is not null then
    begin
      select inventory_item_id into x_inventory_item_id from mtl_system_items_b where segment1 = p_item_number and organization_id = fnd_profile.value('SO_ORGANIZATION_ID');
      v_item_valid := true;
    exception when no_data_found then
        x_error_message := substr(x_error_message ||'*ITEM_NOT_FOUND',1,1000);
        v_return := false;
     end;
  end if;
  if v_price_list_valid and v_item_valid and v_price_name_id_matched then
    -- check item/pricelist
    select count(1) into v_dummy from oe_price_list_lines where price_list_id = x_price_list_id and inventory_item_id = x_inventory_item_id
    and trunc(sysdate) >= start_date_active
    and trunc(sysdate) <= nvl(end_date_active, trunc(sysdate));
    if v_dummy = 0 then
      x_error_message := substr(x_error_message ||'*ITEM_NOT_IN_PRICE_LIST',1,1000);
      v_return := false;
    end if;
  end if;
  if p_bill_to_location_code is not null then
    Begin
    /*  select c.customer_id, su.status site_status, a.status address_status, su.site_use_id, c.status customer_status
      into x_sold_to_org_id, v_site_status, v_address_status, x_bill_to_site_use_id, v_customer_status
      from ra_site_uses_all su, ra_addresses_all a, ra_customers c
      where a.address_id = su.address_id
      and   a.customer_id = c.customer_id
      and   a.ece_tp_location_code = p_bill_to_location_code
      and   su.site_use_code = 'BILL_TO';*/
    Select Hcc.Cust_Account_Id , Hcu.Status , Hca.Status , Hcu.Site_Use_Id, Hcc.Status
    into x_sold_to_org_id, v_site_status, v_address_status, x_bill_to_site_use_id, v_customer_status
      From hz_cust_accounts hcc,  Hz_Cust_Acct_Sites_All Hca, Hz_Cust_Site_Uses_All Hcu
      Where Hcu.Cust_Acct_Site_Id = Hca.Cust_Acct_Site_Id
      And   Hcc.Cust_Account_Id = Hca.Cust_Account_Id
      And   Hca.Ece_Tp_Location_Code = p_bill_to_location_code   --'21574'
      And   Hcu.Site_Use_Code = 'BILL_TO';

      if not (v_address_status = 'A' and v_site_status = 'A' and v_customer_status = 'A') then
        select substr(x_error_message
          || decode(v_address_status,'A','','*BILL_TO_ADDR_INACTIVE')
          || decode(v_site_status,'A','','*BILL_TO_SITE_INACTIVE')
          || decode(v_customer_status,'A','','*BILL_TO_CUSTOMER_INACTIVE'),1,1000)
          into x_error_message  from dual;
        v_return := false;
      end if;
    exception when no_data_found then
      x_error_message := substr(x_error_message ||'*BILL_TO_LOCATION_CODE_NOT_FOUND',1,1000);
      v_return := false;
    end;
  end if;
  if p_ship_to_location_code is not null then
    Begin
    /*  select c.customer_id, su.status site_status, a.status address_status, su.site_use_id, c.status customer_status
      into x_sold_to_org_id, v_site_status, v_address_status, x_ship_to_site_use_id, v_customer_status
      from ra_site_uses_all su, ra_addresses_all a, ra_customers c
      where a.address_id = su.address_id
      and   a.customer_id = c.customer_id
      and   a.ece_tp_location_code = p_ship_to_location_code
      and   su.site_use_code = 'SHIP_TO'; */
   Select Hcc.Cust_Account_Id , Hcu.Status , Hca.Status , Hcu.Site_Use_Id, Hcc.Status
    into x_sold_to_org_id, v_site_status, v_address_status, x_ship_to_site_use_id, v_customer_status
      From hz_cust_accounts hcc,  Hz_Cust_Acct_Sites_All Hca, Hz_Cust_Site_Uses_All Hcu
      Where Hcu.Cust_Acct_Site_Id = Hca.Cust_Acct_Site_Id
      And   Hcc.Cust_Account_Id = Hca.Cust_Account_Id
      And   Hca.Ece_Tp_Location_Code = p_ship_to_location_code   --'21574'
      And   Hcu.Site_Use_Code = 'SHIP_TO';

      if not (v_address_status = 'A' and v_site_status = 'A' and v_customer_status = 'A') then
        select substr(x_error_message
          || decode(v_address_status,'A','','*SHIP_TO_ADDR_INACTIVE')
          || decode(v_site_status,'A','','*SHIP_TO_SITE_INACTIVE')
          || decode(v_customer_status,'A','','*SHIP_TO_CUSTOMER_INACTIVE'),1,1000)
          into x_error_message from dual;
        v_return := false;
      end if;
    exception when no_data_found then
      x_error_message := substr(x_error_message ||'*SHIP_TO_LOCATION_CODE_NOT_FOUND',1,1000);
      v_return := false;
    end;
  end if;
  if p_warehouse_code is not null then
    begin
      select organization_id into x_warehouse_id from mtl_parameters where organization_code  = p_warehouse_code;
    exception when no_data_found then
      x_error_message := substr(x_error_message ||'*WAREHOUSE_CODE_NOT_FOUND',1,1000);
      v_return := false;
    end;
    if x_warehouse_id is not null and x_inventory_item_id is not null then
    begin
      select 1 into v_dummy from mtl_system_items_b where inventory_item_id = x_inventory_item_id and organization_id = x_warehouse_id;
    exception when no_data_found then
      x_error_message := substr(x_error_message ||'*WAREHOUSE_ITEM_NOT_ENABLED',1,1000);
      v_return := false;
    end;
    end if;
  end if;
  if p_order_number is not null then
    if p_org_id is null or p_order_source_id is null then
      x_error_message := substr(x_error_message ||'*ORG_ID_OR_ORDER_SOURCE_NOT_PASSED',1,1000);
      v_return := false;
    else
      begin
        select orig_sys_document_ref, header_id into x_orig_sys_document_ref, x_header_id
        from oe_order_headers_all where order_source_id = p_order_source_id and order_number = p_order_number and org_id = p_org_id;
      exception when no_data_found then
        x_error_message := substr(x_error_message ||'*ORDER_NOT_FOUND',1,1000);
        v_return := false;
      end;
    end if;
    if x_header_id is not null and p_order_line_number is not null then
      declare
      cursor c1 is
        select orig_sys_line_ref, line_id,
        request_date, promise_date, schedule_ship_date, inventory_item_id,
        unit_selling_price, unit_list_price, ordered_quantity, cancelled_quantity, shipped_quantity,
        (ordered_quantity - nvl(shipped_quantity,0) - nvl(cancelled_quantity,0)) open_quantity
        from oe_order_lines_all
        where header_id = x_header_id and org_id = p_org_id and line_number = p_order_line_number
        order by line_number, shipment_number;
      begin
        open c1;
        loop
          fetch c1 into
            x_orig_sys_line_ref, x_line_id,
            x_request_date, x_promise_date, x_schedule_ship_date, x_line_item_id,
            x_unit_selling_price, x_unit_list_price, x_ordered_quantity, x_cancelled_quantity, x_shipped_quantity,
            x_open_quantity;
          if c1%notfound then
            x_orig_sys_line_ref := null; x_line_id := null; x_request_date := null; x_promise_date := null; x_schedule_ship_date := null; x_line_item_id := null; x_unit_selling_price := null; x_unit_list_price := null; x_ordered_quantity := null; x_cancelled_quantity := null; x_shipped_quantity := null; x_open_quantity := null;
            /* not to be used as line number is given but 860 can send new line
            if x_line_id is not null then
              x_error_message := substr(x_error_message ||'*NO_OPEN_ORDER_LINE_NOT_FOUND',1,1000);
            else
              x_error_message := substr(x_error_message ||'*ORDER_LINE_DOES_NOT_EXISTS',1,1000);
            end if;
            close c1;
            x_orig_sys_line_ref := null; x_line_id := null; x_request_date := null; x_promise_date := null; x_schedule_ship_date := null; x_line_item_id := null; x_unit_selling_price := null; x_unit_list_price := null; x_ordered_quantity := null; x_cancelled_quantity := null; x_shipped_quantity := null; x_open_quantity := null;
            v_return := false;
            */
            exit;
          elsif x_open_quantity > 0 then
            close c1;
            exit;
          end if;
        end loop;
      end;
    end if;
  end if;
  if v_return then
    x_status := 'S';
  else
    x_status := 'F';
  end if;
  fnd_file.put_line(fnd_file.log,'x_price_list_id '||to_char(x_price_list_id));
  fnd_file.put_line(fnd_file.log,'x_inventory_item_id '||to_char(x_inventory_item_id));
  fnd_file.put_line(fnd_file.log,'x_sold_to_org_id '||to_char(x_sold_to_org_id));
  fnd_file.put_line(fnd_file.log,'x_bill_to_site_use_id '||to_char(x_bill_to_site_use_id));
  fnd_file.put_line(fnd_file.log,'x_ship_to_site_use_id '||to_char(x_ship_to_site_use_id));
  fnd_file.put_line(fnd_file.log,'x_warehouse_id '||to_char(x_warehouse_id));
  fnd_file.put_line(fnd_file.log,'x_header_id '||to_char(x_header_id));
  fnd_file.put_line(fnd_file.log,'x_line_id '||to_char(x_line_id));
  fnd_file.put_line(fnd_file.log,'x_line_item_id '||to_char(x_line_item_id));
  fnd_file.put_line(fnd_file.log,'x_orig_sys_document_ref '||x_orig_sys_document_ref);
  fnd_file.put_line(fnd_file.log,'x_orig_sys_line_ref '||x_orig_sys_line_ref);
  fnd_file.put_line(fnd_file.log,'x_request_date '||to_char(x_request_date));
  fnd_file.put_line(fnd_file.log,'x_promise_date '||to_char(x_promise_date));
  fnd_file.put_line(fnd_file.log,'x_schedule_ship_date '||to_char(x_schedule_ship_date));
  fnd_file.put_line(fnd_file.log,'x_unit_selling_price '||to_char(x_unit_selling_price));
  fnd_file.put_line(fnd_file.log,'x_unit_list_price '||to_char(x_unit_list_price));
  fnd_file.put_line(fnd_file.log,'x_ordered_quantity '||to_char(x_ordered_quantity));
  fnd_file.put_line(fnd_file.log,'x_cancelled_quantity '||to_char(x_cancelled_quantity));
  fnd_file.put_line(fnd_file.log,'x_shipped_quantity '||to_char(x_shipped_quantity));
  fnd_file.put_line(fnd_file.log,'x_open_quantity '||to_char(x_open_quantity));
  ecx_debug.pl(0, x_status ||' '||x_error_message);
EXCEPTION
  WHEN OTHERS THEN
    IF OE_MSG_PUB.Check_Msg_Level (OE_MSG_PUB.G_MSG_LVL_UNEXP_ERROR) THEN
      OE_MSG_PUB.Add_Exc_Msg( G_PKG_NAME, 'XXHA_EDI_VALIDATE' ) ;
    END IF ;
    x_status := 'F';
    ecx_debug.pl(0, x_status ||' '||x_error_message);
    RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
END validate_line;
procedure validate_header(
                        p_price_list_id in number default null,
                        p_bill_to_location_code in varchar2 default null,
                        p_price_list_name in varchar2 default null,
                        p_org_id in number default null,
                        p_order_source_id in number,
                        p_order_number in number default null,
                        x_price_list_id out number,
                        x_sold_to_org_id out number,
                        x_bill_to_site_use_id out number,
                        x_header_id out number,
                        x_orig_sys_document_ref out varchar2,
                        x_error_message out varchar2,
                        x_status out varchar2)
IS
v_return boolean;
v_price_list_valid boolean;
v_item_valid boolean;
v_dummy number;
v_site_status varchar2(10);
v_address_status varchar2(10);
x_inventory_item_id number;
x_ship_to_site_use_id number;
x_warehouse_id number;
x_line_id number;
x_line_item_id number;
x_orig_sys_line_ref varchar2(255);
x_request_date date;
x_promise_date date;
x_schedule_ship_date date;
x_unit_selling_price number;
x_unit_list_price number;
x_ordered_quantity number;
x_cancelled_quantity number;
x_shipped_quantity number;
x_open_quantity number;
begin
  validating_header := true;
  fnd_file.put_line(fnd_file.log,'p_price_list_id =>'||to_char(p_price_list_id));
  fnd_file.put_line(fnd_file.log,'p_bill_to_location_code =>'||p_bill_to_location_code);
  fnd_file.put_line(fnd_file.log,'p_price_list_name =>'||p_price_list_name);
  validate_line(
           p_price_list_id => p_price_list_id,
           p_bill_to_location_code => p_bill_to_location_code,
           p_ship_to_location_code => null,
           p_item_number => null,
           p_price_list_name => p_price_list_name,
           p_warehouse_code => null,
            p_org_id => p_org_id,
            p_order_source_id => p_order_source_id,
            p_order_number => p_order_number,
            p_order_line_number => null,
                        x_price_list_id => x_price_list_id,
                        x_inventory_item_id => x_inventory_item_id,
                        x_sold_to_org_id => x_sold_to_org_id,
                        x_bill_to_site_use_id => x_bill_to_site_use_id,
                        x_ship_to_site_use_id => x_ship_to_site_use_id,
                        x_warehouse_id => x_warehouse_id,
                        x_header_id => x_header_id,
                        x_line_id => x_line_id,
                        x_line_item_id => x_line_item_id,
                        x_orig_sys_document_ref => x_orig_sys_document_ref,
                        x_orig_sys_line_ref => x_orig_sys_line_ref,
                        x_request_date => x_request_date,
                        x_promise_date => x_promise_date,
                        x_schedule_ship_date => x_schedule_ship_date,
                        x_unit_selling_price => x_unit_selling_price,
                        x_unit_list_price => x_unit_list_price,
                        x_ordered_quantity => x_ordered_quantity,
                        x_cancelled_quantity => x_cancelled_quantity,
                        x_shipped_quantity => x_shipped_quantity,
                        x_open_quantity => x_open_quantity,
                        x_status => x_status,
           x_error_message => x_error_message);
END validate_header ;
END xxha_EDI_validation;
/
