create or replace PACKAGE BODY XXHA_DPS_VENDOR_PK AS

/*********************************************************************************************
* Package Name : XXHA_DPS_VENDOR_PK                                                          *
* Purpose      : This package provides functions to retrieve Contact, Title, Phone, Fax      *
*                 and Email Address.                                                         *
*                                                                                            *
* Used By      : View XXHA_DPS_VENDOR_V                                                      *
*                                                                                            *
* PROCEDURE    : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        04-MAY-2016     B. Marcoux           Initial Package Creation                   *
*                                                                                            *
*********************************************************************************************/

FUNCTION PROCESS_DATA (
                        p_party_site_id        IN  NUMBER
                      , p_Index                IN  NUMBER  
                      ) RETURN VARCHAR2 IS

l_org_party_site_id                    ap_supplier_contacts.org_party_site_id%TYPE;
l_vendor_contact_id                    ap_supplier_contacts.vendor_contact_id%TYPE;
l_per_party_id                         ap_supplier_contacts.per_party_id%TYPE;
l_relationship_id                      ap_supplier_contacts.relationship_id%TYPE;
l_rel_party_id                         ap_supplier_contacts.rel_party_id%TYPE;
l_party_site_id                        ap_supplier_contacts.party_site_id%TYPE;
l_org_contact_id                       ap_supplier_contacts.org_contact_id%TYPE;

l_PERSON_NAME                          VARCHAR(2500):= NULL;
l_PERSON_TITLE                         VARCHAR(2500):= NULL;
l_PHONE                                VARCHAR(2500):= NULL;
l_FAX                                  VARCHAR(2500):= NULL;
l_EMAIL                                VARCHAR(2500):= NULL;
l_DATA                                 VARCHAR(2500):= NULL;
l_Data_Found                           VARCHAR(01)  := NULL;

-- Retrieve Contact
CURSOR cur_1 (p_org_party_site_id ap_supplier_contacts.org_party_site_id%TYPE)
IS
SELECT
    apsc.org_party_site_id
 ,  apsc.vendor_contact_id
 ,  apsc.per_party_id
 ,  apsc.relationship_id
 ,  apsc.rel_party_id
 ,  apsc.party_site_id
 ,  apsc.org_contact_id

FROM 
    ap_suppliers              asp
 ,  ap_supplier_sites_all     ass
 ,  ap_supplier_contacts      apsc
 ,  hz_parties                person
 ,  hz_parties                pty_rel
 ,  HZ_RELATIONSHIPS          hzr

WHERE
    asp.vendor_id           = ass.vendor_id
AND ass.party_site_id       = apsc.org_party_site_id
AND apsc.org_party_site_id  = p_org_party_site_id
AND apsc.per_party_id       = person.party_id
AND apsc.rel_party_id       = pty_rel.party_id
AND pty_rel.party_id        = hzr.party_id
AND HZR.OBJECT_TABLE_NAME   = 'HZ_PARTIES'
AND HZR.RELATIONSHIP_CODE   = 'CONTACT'
AND TRUNC(SYSDATE)          <= NVL(TRUNC(HZR.END_DATE), TRUNC(SYSDATE+1))
ORDER BY
    apsc.creation_date DESC
;

-- Retrieve Name
CURSOR cur_Name (p_per_party_id ap_supplier_contacts.per_party_id%TYPE)
IS
SELECT
    (pty.person_first_name || ' ' || pty.person_last_name)
FROM
    hz_parties     pty
WHERE
    pty.party_id = p_per_party_id
AND pty.status   = 'A'
;

-- Retrieve Title
CURSOR cur_Title (p_ORG_CONTACT_ID ap_supplier_contacts.ORG_CONTACT_ID%TYPE)
IS
SELECT
    ORG_CONT.job_title
FROM
    hz_org_contacts            org_cont
WHERE
    ORG_CONT.ORG_CONTACT_ID  = p_ORG_CONTACT_ID
AND NVL(ORG_CONT.Status,'A') = 'A'
;

-- Retrieve Phone
CURSOR cur_Phone (p_org_party_site_id ap_supplier_contacts.org_party_site_id%TYPE, p_rel_party_id ap_supplier_contacts.rel_party_id%TYPE)
IS
SELECT
    (PTY_REL.PRIMARY_PHONE_AREA_CODE || ' ' || pty_rel.primary_phone_number || ' ' || PTY_REL.PRIMARY_PHONE_EXTENSION)
FROM
    ap_supplier_contacts      apsc
 ,  hz_parties                pty_rel
WHERE
    apsc.rel_party_id       = pty_rel.party_id
AND apsc.org_party_site_id  = p_org_party_site_id
AND PTY_REL.PARTY_ID        = p_rel_party_id
;

-- Retrieve Fax
CURSOR cur_Fax (p_rel_party_id ap_supplier_contacts.rel_party_id%TYPE)
IS
SELECT
    (hcpp.PHONE_AREA_CODE || ' ' || hcpp.PHONE_NUMBER || ' ' || hcpp.Phone_extension)
FROM
    hz_contact_points         hcpp
WHERE
    hcpp.owner_table_ID     = p_rel_party_id
AND hcpp.owner_table_name   = 'HZ_PARTIES'
AND hcpp.status             = 'A'
AND hcpp.contact_point_type = 'PHONE'
AND hcpp.PHONE_LINE_TYPE    = 'FAX'
;

-- Retrieve EMail
CURSOR cur_EMail (p_org_party_site_id ap_supplier_contacts.org_party_site_id%TYPE, p_rel_party_id ap_supplier_contacts.rel_party_id%TYPE)
IS
SELECT
    pty_rel.email_Address
FROM
    ap_supplier_contacts      apsc
 ,  hz_parties                pty_rel
WHERE
    apsc.rel_party_id       = pty_rel.party_id
AND apsc.org_party_site_id  = p_org_party_site_id
AND PTY_REL.PARTY_ID        = p_rel_party_id
;

BEGIN

   l_Data_Found := 'Y';

   -- Determine if contact exists (We are retrieving the first record we come across based upon apsc.creation_date DESCENDING)
   OPEN cur_1(p_party_site_id);
   FETCH cur_1 INTO l_org_party_site_id, l_vendor_contact_id, l_per_party_id, l_relationship_id, l_rel_party_id, l_party_site_id, l_org_contact_id;
   IF cur_1%NOTFOUND THEN
      l_Data_Found := 'N';
      CLOSE cur_1;
   END IF;

   -- Retrieve Name
   IF (l_Data_Found = 'Y' AND p_Index = 1) THEN
      OPEN cur_Name(l_per_party_id);
      FETCH cur_Name INTO l_PERSON_NAME;
      l_DATA := (l_PERSON_NAME);
      CLOSE cur_Name;
   END IF;

   -- Retrieve Title
   IF (l_Data_Found = 'Y' AND p_Index = 2) THEN
      OPEN cur_Title(l_ORG_CONTACT_ID);
      FETCH cur_Title INTO l_PERSON_TITLE;
      l_DATA := (l_PERSON_TITLE);
      CLOSE cur_Title;
   END IF;

   -- Retrieve Phone
   IF (l_Data_Found = 'Y' AND p_Index = 3) THEN
      OPEN cur_Phone(p_party_site_id, l_rel_party_id);
      FETCH cur_Phone INTO l_PHONE;
      l_DATA := LTRIM(RTRIM(TRANSLATE((l_PHONE), chr(1)||chr(2)||chr(3)||chr(4)||chr(5)||chr(6)||chr(7)||chr(8)||chr(9)||chr(11)||chr(12)||chr(13)||chr(14)||chr(15)||chr(16)||chr(17)||chr(18)||chr(19)||chr(20)||chr(21)||chr(22)||chr(23)||chr(24)||chr(25)||chr(26)||chr(27)||chr(28)||chr(29)||chr(30)||chr(31)||chr(127), ' ')));
      CLOSE cur_Phone;
   END IF;

   -- Retrieve Fax
   IF (l_Data_Found = 'Y' AND p_Index = 4) THEN
      OPEN cur_Fax(l_rel_party_id);
      FETCH cur_Fax INTO l_FAX;
      l_DATA := LTRIM(RTRIM(TRANSLATE((l_FAX), chr(1)||chr(2)||chr(3)||chr(4)||chr(5)||chr(6)||chr(7)||chr(8)||chr(9)||chr(11)||chr(12)||chr(13)||chr(14)||chr(15)||chr(16)||chr(17)||chr(18)||chr(19)||chr(20)||chr(21)||chr(22)||chr(23)||chr(24)||chr(25)||chr(26)||chr(27)||chr(28)||chr(29)||chr(30)||chr(31)||chr(127), ' ')));
      CLOSE cur_Fax;
   END IF;
 
   -- Retrieve EMail
   IF (l_Data_Found = 'Y' AND p_Index = 5) THEN
      OPEN cur_EMail(p_party_site_id, l_rel_party_id);
      FETCH cur_EMail INTO l_EMAIL;
      l_DATA := (l_EMAIL);
      CLOSE cur_EMail;
   END IF;

   RETURN l_DATA;

END PROCESS_DATA;

END XXHA_DPS_VENDOR_PK;