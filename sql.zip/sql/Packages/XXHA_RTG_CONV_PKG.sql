CREATE OR REPLACE package      XXHA_RTG_CONV_PKG
as
-- +=============================================================================+
-- | Name             :  XXHA_RTG_CONV_BLL_PK
-- | Description      :  This package supports the processing of BOM routings and
-- |                     bills information staged for conversion.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-09-10  Palash Kundu     Initial release
-- +=============================================================================+

-- +=====================
-- | Global variables
-- +=====================

   -----------------------------------
   -- Common Errors placeholders
   -----------------------------------
   gn_request_id            xxha_common_errors.request_id%type := fnd_global.conc_request_id;  --Request ID of running concurrent program
   gn_record_number         xxha_common_errors.record_number%type;       --Record number of staged record
   gc_record_identifier     xxha_common_errors.record_identifier%type;   --Record identifier of staged record
   gc_error_code            xxha_common_errors.error_code%type;          --Error Code for detected error
   gc_error_msg             xxha_common_errors.error_msg%type;           --Description of error
   gc_comments              xxha_common_errors.comments%type;            --Comment related to error
   gc_table_name            xxha_common_errors.table_name%type;          --Staging table name
   gc_attribute1            xxha_common_errors.attribute1%type;          --Attribute1
   gc_attribute2            xxha_common_errors.attribute2%type;          --Attribute2
   gc_attribute3            xxha_common_errors.attribute3%type;          --Attribute3
   gc_attribute4            xxha_common_errors.attribute4%type;          --Attribute4 stores the concurrent program name
   gc_attribute5            xxha_common_errors.attribute5%type;          --Attribute5 stores the validated (eg. ROUTING, OPERATION, RESOURCE, BILL, INVCOMP, SUBCOMP)
  gc_error_logged  varchar2(1);
  gc_assembly_item_number varchar2 (2000);
   -----------------------------------
   -- Constants
   -----------------------------------
   gc_table_RTG             xxha_common_errors.table_name%type := 'XXHA_BOM_ROUTING_OPS_STG';  --Staging table for routings
   gc_table_RTGOP           xxha_common_errors.table_name%type := 'XXHA_BOM_ROUTING_OPS_STG';  --Staging table for routing operations
   gc_table_OPRES           xxha_common_errors.table_name%type := 'XXHA_BOM_OP_RESOURCES_STG'; --Staging table for operation resources
   gc_table_BILL            xxha_common_errors.table_name%type := 'XXHA_BOM_INV_COMPS_STG';    --Staging table for bills
   gc_table_INVCOMP         xxha_common_errors.table_name%type := 'XXHA_BOM_INV_COMPS_STG';    --Staging table for bill components
   gc_table_SUBCOMP         xxha_common_errors.table_name%type := 'XXHA_BOM_SUB_COMPS_STG';    --Staging table for substitute components
   gc_conc_name_BILL        xxha_common_errors.attribute4%type := 'XXHA_BOM_BILLS_CONV';       --CP name for Bills conversion
   gc_conc_name_RTG         xxha_common_errors.attribute4%type := 'XXHA_BOM_RTGS_CONV';        --CP name for Routings conversion
   gc_valtype_RTG           xxha_common_errors.attribute5%type := 'ROUTING';                   --Validation type for routings
   gc_valtype_RTGOP         xxha_common_errors.attribute5%type := 'OPERATION';                 --Validation type for routing operations
   gc_valtype_OPRES         xxha_common_errors.attribute5%type := 'RESOURCE';                  --Validation type for operation resources
   gc_valtype_BILL          xxha_common_errors.attribute5%type := 'BILL';                      --Validation type for bills
   gc_valtype_INVCOMP       xxha_common_errors.attribute5%type := 'INVCOMP';                   --Validation type for bill components
   gc_valtype_SUBCOMP       xxha_common_errors.attribute5%type := 'SUBCOMP';                   --Validation type for substitute components
   gc_org_code_MST          mtl_parameters.organization_code%type := 'MST';                   --Master Organization Code
   gn_org_id_MST            mtl_parameters.organization_id%type := 103;                     --Master Organization Id
   gc_language_code         fnd_languages.language_code%type := 'US';                    --Language_code

   -----------------------------------
   -- Other placeholder variables
   -----------------------------------
   gc_org_code              mtl_parameters.organization_code%type;        --Current Org being processed
   gc_debug_flag            VARCHAR2(1);                                  --Debug_flag for display debug
   gc_conc_name             xxha_common_errors.attribute4%type;           --CP name placeholder to delete the records from common error table
   gn_user_id               fnd_user.user_id%type := FND_GLOBAL.USER_ID;  --User name for running conversion program
   gc_log_msg               VARCHAR2(1000);                               --Log_msg to display msgs
   gc_error_report          VARCHAR2(1) := 'N';                           --Error_report launch if its <>'N'
   --gc_program_name          VARCHAR2(50) := 'Item Conversion';          --Program Name In parameter for launch_error_prc procedure
   --gc_rec_identifier        VARCHAR2(50) := 'Item Number';              --Record identifier In parameter for launch_error_prc procedure
   --gc_starting_revision     mtl_parameters.starting_revision%type;      --Variable to get staring revision against the Inventory Orgs

   gc_now                   date;
   gc_status                VARCHAR2(2);                              --Variable to get status flag of data insertion in common error table
   gc_transaction_type      mtl_system_items_interface.transaction_type%type := 'CREATE';   --Default transaction_type
   gc_process_flag          mtl_system_items_interface.process_flag%type := '1';            --Default process_flag

-- +==============================================================================+
-- | Name       : process_bill_info
-- |
-- | Description: Procedure to process staged Bill info in preparation for
-- |              importing.  It drives the following actions:
-- |               . Validate staged records
-- |               . Update staged records with internal IDs matching user-friendly values
-- |               . Call launch program for reporting errors (if any)
-- |               . Populate interface tables if no errors found
-- |
-- | PARAMETERS:
-- |   IN: p_org_code
-- |       p_debug_flag
-- |       p_purge_flag
-- |  OUT: x_err_buf
-- |       x_ret_code
-- |
-- | SCOPE: PUBLIC
-- |
-- +==============================================================================+

---------------------------------------------------------------------------------------------------------
/*
PROCEDURE populate_rtg_header
		  					 	(l_org_code					VARCHAR2
								,l_error_message_list       in out Error_handler.error_tbl_type
								,l_chk_eror					out BOOLEAN
								);

PROCEDURE populate_rtg_op_seq
		  					 	(l_operation_tbl            IN OUT Bom_Rtg_Pub.Operation_Tbl_Type
								,l_org_code					VARCHAR2
								,l_assembly_item_number     VARCHAR2
								,l_routing_sequence_id      VARCHAR2
								,l_error_message_list       in out Error_handler.error_tbl_type
								,l_op_resource_tbl          OUT  Bom_Rtg_Pub.Op_Resource_Tbl_Type
								,l_chk_eror					out BOOLEAN
								);
PROCEDURE  populate_rtg_resource
		  					 	(l_op_resource_tbl          IN OUT Bom_Rtg_Pub.Op_Resource_Tbl_Type
								,l_org_code					VARCHAR2
								,l_assembly_item_number     VARCHAR2
								,l_operation_sequence_id      VARCHAR2
								,l_error_message_list       in out Error_handler.error_tbl_type
								,l_chk_eror					out BOOLEAN
								);

PROCEDURE CALL_RTG_API
	 		   				   	 (l_rtg_header_rec           Bom_Rtg_Pub.Rtg_Header_Rec_Type
  								 ,l_rtg_revision_tbl         Bom_Rtg_Pub.Rtg_Revision_Tbl_Type
								 ,l_operation_tbl            Bom_Rtg_Pub.Operation_Tbl_Type
								 ,l_op_resource_tbl          Bom_Rtg_Pub.Op_Resource_Tbl_Type
								 ,l_sub_resource_tbl         Bom_Rtg_Pub.Sub_Resource_Tbl_Type
								 ,l_op_network_tbl           Bom_Rtg_Pub.Op_Network_Tbl_Type
								 ,l_error_message_list       in out Error_handler.error_tbl_type
								 ,l_x_rtg_header_rec         out Bom_Rtg_Pub.Rtg_Header_Rec_Type
								 ,l_x_rtg_revision_tbl       out Bom_Rtg_Pub.Rtg_Revision_Tbl_Type
								 ,l_x_operation_tbl          out Bom_Rtg_Pub.Operation_Tbl_Type
								 ,l_x_op_resource_tbl        out Bom_Rtg_Pub.Op_Resource_Tbl_Type
								 ,l_x_sub_resource_tbl       out Bom_Rtg_Pub.Sub_Resource_Tbl_Type
								 ,l_x_op_network_tbl         out Bom_Rtg_Pub.Op_Network_Tbl_Type
								 ,l_x_return_status          out VARCHAR2
  								 ,l_x_msg_count              out NUMBER);*/
PROCEDURE convert_rtg (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
      --  ,p_org_code  in  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
		,p_commit      in   varchar2
		,p_force_commit      in   varchar2
        );
---------------------------------------------------------------------------------------------------------


END XXHA_RTG_CONV_PKG;  -- package spec

/


CREATE OR REPLACE package body      XXHA_RTG_CONV_PKG
as
-- +=============================================================================+
-- | Name             :  XXHA_BOM_CONV_BLL_PK
-- | Description      :  This package supports the processing of BOM routings and
-- |                     bills information staged for conversion.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-09-09  Palash Kundu     Initial release
-- +=============================================================================+

  -- Cursor for errored records
  /*cursor c_err (
           q_request_id  xxha_common_errors.request_id%type
          ,q_table_name  xxha_common_errors.table_name%type
          ,q_conc_name  xxha_common_errors.attribute4%type
          ,q_validation_type  xxha_common_errors.attribute5%type
          ) is
    select  ce.error_code
           ,ce.error_msg
           ,count(1)  cnt
    from    xxha_common_errors  ce
    where   ce.request_id = q_request_id
    and     ce.table_name = q_table_name
    and     ce.attribute4 = q_conc_name
    and     ce.attribute5 = q_validation_type
    group by ce.error_code
            ,ce.error_msg
    order by 1;
*/


---------------------------------------------------------------------------
---Error Handling
---------------------------------------------------------------------------


    TYPE XX_COMMON_ERROR_Tbl_Type IS TABLE OF XXHA_COMMON_ERRORS%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_COMMON_ERROR_TBL		XX_COMMON_ERROR_Tbl_Type;
	TYPE XX_RTG_STG_Tbl_Type IS TABLE OF XXHA_BOM_ROUTING_OPS_STG%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_RTG_STG_TBL		XX_RTG_STG_Tbl_Type;
	TYPE XX_RTG_SUCCESS_STG_Tbl_Type IS TABLE OF XXHA_BOM_ROUTING_OPS_STG%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_RTG_SUCCESS_STG_TBL		XX_RTG_SUCCESS_STG_Tbl_Type;

procedure populate_common_error(error_msg varchar2,error_code varchar2,error_comments varchar2,record_number number,record_identifier varchar2) is
  l_error_counter number;
begin
gc_error_logged := 'Y';
dbms_output.put_line(' popu err large '||substr(error_msg,1,2000));
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := substr(error_code,1,20);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_comments,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;

end populate_common_error;

procedure populate_rtg_success_stg_tbl(assembly_item_number varchar2) is
  l_rtg_succ_counter number;
begin
   l_rtg_succ_counter :=XX_RTG_SUCCESS_STG_TBL.count;
			 XX_RTG_SUCCESS_STG_TBL(l_rtg_succ_counter+1).assembly_item_number := assembly_item_number;

end populate_rtg_success_stg_tbl;

procedure populate_rtg_stg_tbl(assembly_item_number varchar2) is
  l_rtg_counter number;
begin
   l_rtg_counter :=XX_RTG_STG_TBL.count;
			 XX_RTG_STG_TBL(l_rtg_counter+1).assembly_item_number := assembly_item_number;

end populate_rtg_stg_tbl;


procedure log_error
          is
begin
   gc_error_logged := 'Y';
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,gc_comments
                            ,gc_table_name
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
	dbms_output.put_line('error '||gc_error_code||gc_error_msg||gc_comments);
exception
   when others then
      populate_common_error(substr(sqlerrm,1,2000),'log error','When Others Log Error',gn_record_number,gc_record_identifier);
	  fnd_file.put_line(fnd_file.log,'Error in XXHA_BOM_CONV_PKG.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
end log_error;





procedure log_all_errors IS
l_error_occured boolean := FALSE;
BEGIN
  dbms_output.put_line('All Error '||xx_common_error_tbl.count);
  FOR i IN 1..XX_COMMON_ERROR_TBL.COUNT LOOP
     l_error_occured := TRUE;
     gn_request_id :=  XX_COMMON_ERROR_TBL(i).request_id;
     gn_record_number := XX_COMMON_ERROR_TBL(i).record_number;
     gc_record_identifier := XX_COMMON_ERROR_TBL(i).record_identifier ;
     gc_error_code := XX_COMMON_ERROR_TBL(i).error_code;
     gc_error_msg := XX_COMMON_ERROR_TBL(i).error_msg;
     gc_comments  :=  XX_COMMON_ERROR_TBL(i).comments;
     gc_table_name :=  XX_COMMON_ERROR_TBL(i).table_name;
     gc_attribute1 :=  XX_COMMON_ERROR_TBL(i).attribute1;
     gc_attribute2 :=  XX_COMMON_ERROR_TBL(i).attribute2;
     gc_attribute3:=  XX_COMMON_ERROR_TBL(i).attribute3;
     gc_attribute4 :=  XX_COMMON_ERROR_TBL(i).attribute4;
     gc_attribute5 :=  XX_COMMON_ERROR_TBL(i).attribute5;

	 log_error;

	 gn_request_id :=  null;
     gn_record_number := null;
     gc_record_identifier := null;
     gc_error_code := null;
     gc_error_msg := null;
     gc_comments  :=  null;
     gc_table_name :=  null;
     gc_attribute1 :=  null;
     gc_attribute2 :=  null;
     gc_attribute3:=  null;
     gc_attribute4 :=  null;
     gc_attribute5 :=  null;


  ENd LOOP;
  IF NOT l_error_occured THEN
    xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,'No Error Occured'
                            ,'XXHA_BOM_INV_COMPS_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
    gc_error_logged := 'N';
	dbms_output.put_line('No err ');
   ELSE
    FOR i IN 1..XX_RTG_STG_TBL.COUNT LOOP
	  IF XX_RTG_STG_TBL(i).assembly_item_number IS NOT NULL THEN
	    update xxha_bom_routing_ops_stg
	    set rt_status = 'VE'
		, op_status = 'VE'
		where assembly_item_number = XX_RTG_STG_TBL(i).assembly_item_number
		and rt_status <> 'VE';
		update xxha_bom_op_resources_stg
	    set status = 'VE'
		where assembly_item_number = XX_RTG_STG_TBL(i).assembly_item_number
		and status <> 'VE';
	  END IF;
	END LOOP;
  END IF;

END log_all_errors;


procedure chk_bom_departments is

cursor c_upd_dept is
select distinct  ops.organization_id ,department_code
from XXHA_BOM_ROUTING_OPS_STG ops,mtl_parameters param
where param.organization_code = ops.organization_code
;
cursor c_get_dept (q_organization_id number,q_department_code varchar2) is
select department_code
from bom_departments
where organization_id = q_organization_id
and upper(department_code) = upper(q_department_code)
;
begin
for v_upd_dept in c_upd_dept loop
  for v_get_dept in c_get_dept (v_upd_dept.organization_id,v_upd_dept.department_code) loop
    update XXHA_BOM_ROUTING_OPS_STG
	set department_code = v_get_dept.department_code
	where organization_id = v_upd_dept.organization_id
	and department_code = v_upd_dept.department_code
	;
  end loop;

end loop;


end;

-----------------------------------------------------------------------------
----CALL_RTG_API
-----------------------------------------------------------------------------

 PROCEDURE CALL_RTG_API
	 		   				   	 (l_rtg_header_rec           Bom_Rtg_Pub.Rtg_Header_Rec_Type
  								 ,l_rtg_revision_tbl         Bom_Rtg_Pub.Rtg_Revision_Tbl_Type
								 ,l_operation_tbl            Bom_Rtg_Pub.Operation_Tbl_Type
								 ,l_op_resource_tbl          Bom_Rtg_Pub.Op_Resource_Tbl_Type
								 ,l_sub_resource_tbl         Bom_Rtg_Pub.Sub_Resource_Tbl_Type
								 ,l_op_network_tbl           Bom_Rtg_Pub.Op_Network_Tbl_Type
								 ,l_error_message_list       in out Error_handler.error_tbl_type
								 ,l_x_rtg_header_rec         out Bom_Rtg_Pub.Rtg_Header_Rec_Type
								 ,l_x_rtg_revision_tbl       out Bom_Rtg_Pub.Rtg_Revision_Tbl_Type
								 ,l_x_operation_tbl          out Bom_Rtg_Pub.Operation_Tbl_Type
								 ,l_x_op_resource_tbl        out Bom_Rtg_Pub.Op_Resource_Tbl_Type
								 ,l_x_sub_resource_tbl       out Bom_Rtg_Pub.Sub_Resource_Tbl_Type
								 ,l_x_op_network_tbl         out Bom_Rtg_Pub.Op_Network_Tbl_Type
								 ,l_x_return_status          out VARCHAR2
  								 ,l_x_msg_count              out NUMBER) IS


  BEGIN
      dbms_output.put_line('CALL RTG API PKG ');
      Error_Handler.Initialize;
	  l_error_message_list.delete;

      dbms_output.put_line('CALL RTG API '||l_op_resource_tbl(1).operation_sequence_number||' a '||l_operation_tbl(1).operation_sequence_number);
	  IF nvl(gc_assembly_item_number,'N')<>l_rtg_header_rec.assembly_item_name THEN
		      Bom_Rtg_Pub.Process_Rtg
		         ( p_bo_identifier          => 'RTG'
		         , p_api_version_number     => 1.0
		         , p_init_msg_list          => FALSE
		         , p_rtg_header_rec         => l_rtg_header_rec
		         , p_rtg_revision_tbl       => l_rtg_revision_tbl
		         , p_operation_tbl          => l_operation_tbl
		         , p_op_resource_tbl        => l_op_resource_tbl
		         , p_sub_resource_tbl       => l_sub_resource_tbl
		         , p_op_network_tbl         => l_op_network_tbl
		         , x_rtg_header_rec         => l_x_rtg_header_rec
		         , x_rtg_revision_tbl       => l_x_rtg_revision_tbl
		         , x_operation_tbl          => l_x_operation_tbl
		         , x_op_resource_tbl        => l_x_op_resource_tbl
		         , x_sub_resource_tbl       => l_x_sub_resource_tbl
		         , x_op_network_tbl         => l_x_op_network_tbl
		         , x_return_status          => l_x_return_status
		         , x_msg_count              => l_x_msg_count
		         , p_debug                  => 'N'
		         , p_output_dir             => ''
		         , p_debug_filename         => ''
		         );
		      dbms_output.put_line('CALL RTG API END ');
		      dbms_output.put_line('Return Status = '||l_x_return_status);
		      dbms_output.put_line('Message Count = '||l_x_msg_count);

		      /**** Error messages ****/

		      Error_Handler.Get_message_list(l_error_message_list);

		      if l_x_return_status <> 'S'
		      then
		         --  Error Processing
				 populate_rtg_stg_tbl(l_rtg_header_rec.assembly_item_name);
		         for i in 1..l_error_message_list.COUNT LOOP
				   populate_common_error(l_rtg_header_rec.transaction_type||','||l_operation_tbl(1).transaction_type||','||l_op_resource_tbl(1).transaction_type||','||l_operation_tbl(1).start_effective_date||l_operation_tbl(1).new_start_effective_date||l_error_message_list(i).message_text,l_x_return_status,'RTG_API_ERROR',gn_record_number,gc_record_identifier);
		           dbms_output.put_line('Entity Id    : '||l_error_message_list(i).entity_id);
		           dbms_output.put_line('Index        : '||l_error_message_list(i).entity_index);
		           dbms_output.put_line('Message Type : '||l_error_message_list(i).message_type);
		           dbms_output.put_line('Mesg         : '||SUBSTR(l_error_message_list(i).message_text,1,250));
		           dbms_output.put_line('-------------------------------------------------------------------');
		         end loop;
		         --  The business object APIs do not issue commits or rollbacks. It is the responsibility of
		         --  the calling code to issue them. This ensures that parts of the transactions are not left
		         --  in the database. If an error occurs, the whole transaction is rolled back.
		       --  rollback;
				 dbms_output.put_line('Call API Error ');
		      else
			     populate_rtg_success_stg_tbl(l_rtg_header_rec.assembly_item_name);
		         dbms_output.put_line('Call API Sucess ');
		      end if;
      END IF;
  EXCEPTION

	When Others then
	    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others call rtg api',gn_record_number,gc_record_identifier);
	  dbms_output.put_line (substr(sqlerrm,1,250));

  END call_rtg_api;


-----------------------------------------------------------------------------
----Populate RTG RESOURCES
-----------------------------------------------------------------------------

PROCEDURE populate_rtg_resource
		  					 	(l_op_resource_tbl          IN OUT Bom_Rtg_Pub.Op_Resource_Tbl_Type
								,l_org_code					VARCHAR2
								,l_assembly_item_number     VARCHAR2
								,l_operation_sequence_id      VARCHAR2
								,l_error_message_list       in out Error_handler.error_tbl_type
								,l_chk_eror					out BOOLEAN
								)
	IS
	cursor c_rtg_resource (
           q_org_code  varchar2
		   ,q_assembly_item_number varchar2
          ) is
    select  rtg_resource.*
           ,rtg_resource.rowid
    from    xxha_bom_op_resources_stg  rtg_resource
    where   rtg_resource.status <> 'PS'
    and     rtg_resource.organization_code = q_org_code
	and     rtg_resource.assembly_item_number = q_assembly_item_number
	;
	l_resource_tbl_counter   NUMBER;
	x_out_resource_id   NUMBER;
	x_err_msg  varchar2(1000);
	x_out_rtg_resource_found  boolean;
	x_err_cd varchar2(1000);
BEGIN
  dbms_output.put_line('Start Populate Rtg Resource ');
  l_resource_tbl_counter := 0;
  FOR v_rtg_resource IN c_rtg_resource (l_org_code,l_assembly_item_number) LOOP
   -- gc_record_identifier := gc_record_identifier||'RES'||v_rtg_resource.resource_code;
    l_resource_tbl_counter := l_resource_tbl_counter + 1;
	  x_out_rtg_resource_found  := FALSE;
	  dbms_output.put_line('Before Res Found ');
	  XXHA_BOM_COMMON_UTILITIES_PK.rtg_resource_found (
												         l_operation_sequence_id
												        ,v_rtg_resource.Resource_Seq_Num
												        ,x_out_resource_id
												        ,x_err_cd
												        ,x_err_msg
														,x_out_rtg_resource_found
												        );
	dbms_output.put_line('After Res Found ');

	  l_op_resource_tbl(l_resource_tbl_counter).Assembly_Item_Name           := v_rtg_resource.assembly_item_number;
      l_op_resource_tbl(l_resource_tbl_counter).Organization_Code            := v_rtg_resource.organization_code;
	  l_op_resource_tbl(l_resource_tbl_counter).Alternate_Routing_Code           := v_rtg_resource.alternate_rtg_designator;
	  l_op_resource_tbl(l_resource_tbl_counter).Operation_Sequence_Number    := v_rtg_resource.Operation_Seq_Num;
	  l_op_resource_tbl(l_resource_tbl_counter).Resource_Sequence_Number     := v_rtg_resource.Resource_Seq_Num;
	  l_op_resource_tbl(l_resource_tbl_counter).Assigned_Units     := v_rtg_resource.Assigned_Units;
      IF x_out_rtg_resource_found THEN
	    l_op_resource_tbl(l_resource_tbl_counter).Transaction_Type             := 'UPDATE';
	  ELSE
	    l_op_resource_tbl(l_resource_tbl_counter).Transaction_Type             := 'CREATE';
		l_op_resource_tbl(l_resource_tbl_counter).op_Start_Effective_Date             := sysdate;
	  END IF;
	  dbms_output.put_line('Res Trx Type '||l_op_resource_tbl(l_resource_tbl_counter).Transaction_Type);
      l_op_resource_tbl(l_resource_tbl_counter).Resource_Code                := v_rtg_resource.Resource_Code;
      l_op_resource_tbl(l_resource_tbl_counter).Usage_Rate_Or_Amount := v_rtg_resource.usage_rate_or_amount;
      l_op_resource_tbl(l_resource_tbl_counter).Schedule_Flag                := v_rtg_resource.schedule_flag;

      dbms_output.put_line('After Res Found '||l_op_resource_tbl(1).assembly_item_name);

  END LOOP;
Exception
	When Others then
	    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others populate rtg resource',gn_record_number,gc_record_identifier);
END populate_rtg_resource;



-----------------------------------------------------------------------------
----Populate RTG OP SEQUENCE
-----------------------------------------------------------------------------

PROCEDURE populate_rtg_op_seq
		  					 	(l_operation_tbl            IN OUT Bom_Rtg_Pub.Operation_Tbl_Type
								,l_org_code					VARCHAR2
								,l_assembly_item_number     VARCHAR2
								,l_routing_sequence_id      VARCHAR2
								,l_error_message_list       in out Error_handler.error_tbl_type
								,l_op_resource_tbl          OUT  Bom_Rtg_Pub.Op_Resource_Tbl_Type
								,l_chk_eror					out BOOLEAN
								)
	IS
	cursor c_rtg_ops (
           q_org_code  varchar2
		   ,q_assembly_item_number varchar2
          ) is
    select  rtg_ops.*
           ,rtg_ops.rowid
    from    xxha_bom_routing_ops_stg  rtg_ops
    where   rtg_ops.rt_status <> 'PS'
    --and     rtg_ops.op_status <> 'PS'
	and     assembly_item_number = q_assembly_item_number
    and     rtg_ops.organization_code = q_org_code;
    l_ops_tbl_counter         NUMBER;
	x_operation_sequence_id    NUMBER;
	x_out_rtg_ops_exists       BOOLEAN;
	x_out_op_effectivity_date  DATE;
BEGIN
  dbms_output.put_line('populate rtg op seq ');
  l_ops_tbl_counter := 0;

  l_op_resource_tbl := Bom_Rtg_Pub.G_MISS_OP_RESOURCE_TBL;

 FOR v_rtg_ops in c_rtg_ops (l_org_code,l_assembly_item_number) LOOP
     -- gc_record_identifier := gc_record_identifier||'OPS'||v_rtg_ops.operation_seq_num;
      x_operation_sequence_id := NULL;
      IF l_routing_sequence_id IS NOT NULL THEN

	    XXHA_BOM_COMMON_UTILITIES_PK.routing_op_exists (l_routing_sequence_id
        										 ,v_rtg_ops.operation_type
        										 ,v_rtg_ops.operation_seq_num
        										 ,nvl(v_rtg_ops.effectivity_date,sysdate)
        										 ,x_operation_sequence_id
												 ,x_out_op_effectivity_date
        										 ,x_out_rtg_ops_exists);
	  ELSE
	    x_out_rtg_ops_exists := FALSE;
	  END IF;
	  dbms_output.put_line('RTG OPS Populate '||v_rtg_ops.organization_code||v_rtg_ops.operation_seq_num);
  	  l_ops_tbl_counter := l_ops_tbl_counter + 1;
	  l_operation_tbl(l_ops_tbl_counter).Assembly_Item_Name             := l_assembly_item_number;
      l_operation_tbl(l_ops_tbl_counter).Organization_Code              := l_org_code;
      l_operation_tbl(l_ops_tbl_counter).Operation_Sequence_Number      := v_rtg_ops.operation_seq_num;
	  dbms_output.put_line('Before populate rtg res '||l_operation_tbl(l_ops_tbl_counter).Operation_Sequence_Number);
	  l_operation_tbl(l_ops_tbl_counter).Standard_Operation_code      := v_rtg_ops.operation_code;
      l_operation_tbl(l_ops_tbl_counter).Operation_Type                 := 1;
      l_operation_tbl(l_ops_tbl_counter).Department_Code                := v_rtg_ops.department_code;
	  l_operation_tbl(l_ops_tbl_counter).Operation_Description          := v_rtg_ops.operation_description;
	  l_operation_tbl(l_ops_tbl_counter).Option_Dependent_Flag          := v_rtg_ops.option_dependent_flag;
	  l_operation_tbl(l_ops_tbl_counter).Op_Lead_Time_Percent           := v_rtg_ops.operation_lead_time_percent;
	  l_operation_tbl(l_ops_tbl_counter).Count_Point_Type               := v_rtg_ops.count_point_type;
      IF x_out_rtg_ops_exists THEN
       l_operation_tbl(l_ops_tbl_counter).Transaction_Type               := 'UPDATE';
	   l_operation_tbl(l_ops_tbl_counter).Start_Effective_Date           := nvl(to_date(to_char(x_out_op_effectivity_date, 'DD-MON-YYYY HH:MI:SS PM'),'DD-MON-YYYY HH:MI:SS PM'),sysdate);
	   l_operation_tbl(l_ops_tbl_counter).disable_Date                   := sysdate;
	   l_operation_tbl(l_ops_tbl_counter).New_Start_Effective_Date           := sysdate+1;--nvl(v_rtg_ops.effectivity_date,sysdate);
	  ELSE
	   l_operation_tbl(l_ops_tbl_counter).Transaction_Type               := 'CREATE';
	   l_operation_tbl(l_ops_tbl_counter).Start_Effective_Date           := nvl(v_rtg_ops.effectivity_date,sysdate);
	  END IF;
	  l_operation_tbl(l_ops_tbl_counter).backflush_flag                 := v_rtg_ops.backflush_flag;
	  l_operation_tbl(l_ops_tbl_counter).minimum_transfer_quantity      := v_rtg_ops.minimum_transfer_quantity;
	  l_operation_tbl(l_ops_tbl_counter).cumulative_yield               := v_rtg_ops.cumulative_yield;


	  dbms_output.put_line('Before populate rtg res '||l_operation_tbl(l_ops_tbl_counter).Operation_Sequence_Number||l_org_code||l_assembly_item_number);
	  populate_rtg_resource
		  					 	(l_op_resource_tbl
								,l_org_code
								,l_assembly_item_number
								,x_operation_sequence_id
								,l_error_message_list
								,l_chk_eror
								);
  END LOOP;
Exception
	When Others then
	    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others populate rtg op seq',gn_record_number,gc_record_identifier);
END populate_rtg_op_seq;



 -----------------------------------------------------------------------------
----Populate RTG Header
-----------------------------------------------------------------------------

PROCEDURE populate_rtg_header
		  					 	(--l_org_code					VARCHAR2
								--,
								l_error_message_list       in out Error_handler.error_tbl_type
								,l_chk_eror					out BOOLEAN
								)
	IS
	cursor c_rtg_hdr --(
         ---  q_org_code  varchar2
          --)
		  is
    select  distinct
            rtg_hdr.organization_code
           ,rtg_hdr.assembly_item_number
           ,rtg_hdr.alternate_rtg_designator
           ,rtg_hdr.completion_subinventory
           ,rtg_hdr.routing_comment
           ,rtg_hdr.location_name
           ,rtg_hdr.routing_trx_type
		   --,rtg_hdr.record_id
    from    xxha_bom_routing_ops_stg  rtg_hdr
    where   rtg_hdr.rt_status <> 'PS'
--	and assembly_item_number = '00208-MT'
	--and organization_code = 'BDO'
    --and     rtg_hdr.organization_code = q_org_code
	;


	l_rtg_header_rec           Bom_Rtg_Pub.Rtg_Header_Rec_Type := Bom_Rtg_Pub.G_MISS_RTG_HEADER_REC;
  	v_org_code                 VARCHAR2(1000);
  	v_out_item_id  			 NUMBER;
  	v_err_cd    				 VARCHAR2(1000);
  	v_err_msg    				 VARCHAR2(1000);
  	v_out_item_at_org  			 BOOLEAN;
	x_out_rtg_found              BOOLEAN;
	x_routing_sequence_id        NUMBER;
	l_trx_type                   VARCHAR2(1000);
	l_operation_tbl             Bom_Rtg_Pub.Operation_Tbl_Type         := Bom_Rtg_Pub.G_MISS_OPERATION_TBL;
	l_op_resource_tbl           Bom_Rtg_Pub.Op_Resource_Tbl_Type:= Bom_Rtg_Pub.G_MISS_OP_RESOURCE_TBL;
	l_rtg_revision_tbl          Bom_Rtg_Pub.Rtg_Revision_Tbl_Type:= Bom_Rtg_Pub.G_MISS_RTG_REVISION_TBL;
	l_sub_resource_tbl          Bom_Rtg_Pub.Sub_Resource_Tbl_Type:= Bom_Rtg_Pub.G_MISS_SUB_RESOURCE_TBL;
	l_op_network_tbl            Bom_Rtg_Pub.Op_Network_Tbl_Type := Bom_Rtg_Pub.G_MISS_OP_NETWORK_TBL;
	l_x_rtg_header_rec         Bom_Rtg_Pub.Rtg_Header_Rec_Type        := Bom_Rtg_Pub.G_MISS_RTG_HEADER_REC;
  l_x_rtg_revision_tbl       Bom_Rtg_Pub.Rtg_Revision_Tbl_Type      := Bom_Rtg_Pub.G_MISS_RTG_REVISION_TBL;
  l_x_operation_tbl          Bom_Rtg_Pub.Operation_Tbl_Type         := Bom_Rtg_Pub.G_MISS_OPERATION_TBL;
  l_x_op_resource_tbl        Bom_Rtg_Pub.Op_Resource_Tbl_Type       := Bom_Rtg_Pub.G_MISS_OP_RESOURCE_TBL;
  l_x_sub_resource_tbl       Bom_Rtg_Pub.Sub_Resource_Tbl_Type      := Bom_Rtg_Pub.G_MISS_SUB_RESOURCE_TBL;
  l_x_op_network_tbl         Bom_Rtg_Pub.Op_Network_Tbl_Type        := Bom_Rtg_Pub.G_MISS_OP_NETWORK_TBL;

	l_x_return_status           VARCHAR2(1000);
  	l_x_msg_count               NUMBER;

BEGIN
    dbms_output.put_line('Populate RTG Header '	);

	   FOR v_rtg_hdr in c_rtg_hdr  LOOP
   	   	   dbms_output.put_line('RTG ASSY '||v_rtg_hdr.assembly_item_number);
	   	   --gn_record_number := v_rtg_hdr.assembly_item_number;
	       gc_record_identifier := v_rtg_hdr.assembly_item_number||'/'||v_rtg_hdr.organization_code;
		   l_rtg_header_rec                      := Bom_Rtg_Pub.G_MISS_RTG_HEADER_REC;
		   l_operation_tbl                       := Bom_Rtg_Pub.G_MISS_OPERATION_TBL;
		   XXHA_BOM_COMMON_UTILITIES_PK.CHK_ITEM_AT_ORG (
											         v_rtg_hdr.organization_code
											        ,v_rtg_hdr.assembly_item_number
											        ,v_out_item_id
													,v_err_cd
													,v_err_msg
													,v_out_item_at_org
													) ;
		   XXHA_BOM_COMMON_UTILITIES_PK.rtg_header_found ( v_rtg_hdr.organization_code
								          				   	,v_rtg_hdr.assembly_item_number
								        					,v_rtg_hdr.alternate_rtg_designator
								        					,x_routing_sequence_id
															,x_out_rtg_found
								        					);
		   IF x_out_rtg_found then
			  l_trx_type := 'UPDATE';
			ELSE
			  l_trx_type := 'CREATE';
			END IF;
			dbms_output.put_line('Rtg Hdr Trx Type '||l_trx_type);
			IF v_out_item_at_org  THEN --Item at Org
			  l_rtg_header_rec.Assembly_Item_Name               := v_rtg_hdr.assembly_item_number;
              l_rtg_header_rec.Organization_Code                := v_rtg_hdr.organization_code;
              l_rtg_header_rec.Eng_Routing_Flag                 := 2;
			  l_rtg_header_rec.alternate_routing_code           := v_rtg_hdr.alternate_rtg_designator;
			  l_rtg_header_rec.routing_comment                  := v_rtg_hdr.routing_comment;
			  l_rtg_header_rec.completion_subinventory          := v_rtg_hdr.completion_subinventory;
			  l_rtg_header_rec.completion_location_name         := v_rtg_hdr.location_name;
			  l_rtg_header_rec.transaction_type                 := l_trx_type;
			  l_rtg_header_rec.return_status                    := NULL;
			  l_operation_tbl.delete;
			  l_op_resource_tbl.delete;
			  populate_rtg_op_seq
		  					 	(l_operation_tbl
								,v_rtg_hdr.organization_code
								,v_rtg_hdr.assembly_item_number
								,x_routing_sequence_id
								,l_error_message_list
								,l_op_resource_tbl
								,l_chk_eror
								);
			dbms_output.put_line('Before RTG API '||l_op_resource_tbl.count);

			 -- l_error_message_list.delete;
			   CALL_RTG_API	   	 (l_rtg_header_rec
  								 ,l_rtg_revision_tbl
								 ,l_operation_tbl
								 ,l_op_resource_tbl
								 ,l_sub_resource_tbl
								 ,l_op_network_tbl
								 ,l_error_message_list
								 ,l_x_rtg_header_rec
								 ,l_x_rtg_revision_tbl
								 ,l_x_operation_tbl
								 ,l_x_op_resource_tbl
								 ,l_x_sub_resource_tbl
								 ,l_x_op_network_tbl
								 ,l_x_return_status
  								 ,l_x_msg_count
								 );

			ELSE
              populate_rtg_stg_tbl(v_rtg_hdr.assembly_item_number);
			  populate_common_error(substr(sqlerrm,1,2000),'Rtg Header Chk Item' ,'Item Do Not Exist',gn_record_number,gc_record_identifier);
			  gc_assembly_item_number:= v_rtg_hdr.assembly_item_number;
			END IF;
		END LOOP;

Exception
	When Others then
	    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others populate rtg hdr',gn_record_number,gc_record_identifier);
END populate_rtg_header;


PROCEDURE pre_process_rtg  IS
cursor c_rtg is
select * from xxha_bom_op_resources_stg
where resource_code <> 'STERILIZE'
and status <> 'PS'
;
l_record_id number;
l_resource_code varchar2 (2000);
l_resource_seq_num varchar2 (2000);
l_assigned_units varchar2 (2000);
BEGIN
delete from xxha_bom_op_resources_stg where resource_code like 'P-%' and status <> 'PS';
commit;
update xxha_bom_op_resources_stg
set schedule_flag = 2
where resource_code not like 'P-%'
and status <> 'PS';
commit;
select max(record_id)
into l_record_id
from xxha_bom_op_resources_stg
;
for v_rtg in c_rtg loop
  gn_record_number := v_rtg.record_id;
  gc_record_identifier := v_rtg.assembly_item_number;
  l_record_id := l_record_id +1;
  l_resource_code := substr('P-'||v_rtg.resource_code,1,10);
  l_resource_seq_num := to_number(v_rtg.resource_seq_num) + 5;

  select distinct capacity_units
  into l_assigned_units
  from bom_departments dept,bom_resources res,bom_department_resources dept_res,mtl_parameters param
  where dept.organization_id = res.organization_id
  and dept.department_id = dept_res.department_id
  and res.resource_id = dept_res.resource_id
  and dept.organization_id = param.organization_id
  and res.organization_id = param.organization_id
  and organization_code = v_rtg.organization_code--'BDO'
  --and department_code = --'BOWLS'
  and resource_code = l_resource_code--'P-BOWLS'
  ;
  insert into xxha_bom_op_resources_stg
    (record_id,ops_record_id,organization_code,assembly_item_number,operation_seq_num,resource_seq_num,resource_code,basis_type,usage_rate_or_amount,assigned_units,schedule_flag,standard_rate_flag,autocharge_type,status)
  values
    (l_record_id,v_rtg.ops_record_id,v_rtg.organization_code,v_rtg.assembly_item_number,v_rtg.operation_seq_num,l_resource_seq_num,l_resource_code,v_rtg.basis_type,v_rtg.usage_rate_or_amount,l_assigned_units,'1','2','1',v_rtg.status)
  ;

end loop;
commit;
exception
when others then
populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Pre proc',gn_record_number,gc_record_identifier);
END;

-----------------------------------------------------------------------------
----CONVERT RTG
-----------------------------------------------------------------------------

PROCEDURE convert_rtg (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        --,p_org_code  in  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
		,p_commit      in   varchar2
		,p_force_commit      in   varchar2
        ) IS
	l_error_message_list       Error_handler.error_tbl_type;
	l_chk_eror					BOOLEAN;
BEGIN
  --gn_request_id := fnd_global.conc_request_id;
  --FND_GLOBAL.APPS_INITIALIZE(USER_ID=>fnd_global.USER_ID,RESP_ID=>fnd_global.RESP_ID,RESP_APPL_ID=>fnd_global.RESP_APPL_ID);
    pre_process_rtg ;
     dbms_output.put_line('convert_rtg');
	 populate_rtg_header
		  					 	(--p_org_code
								--,
								l_error_message_list
								,l_chk_eror
								);
     IF p_force_commit = 'Y' THEN
	   commit;
	 ENd IF;
	 IF p_commit = 'Y' AND (nvl(gc_error_logged,'N') <> 'Y' OR p_force_commit = 'Y') THEN
	   FOR i IN 1..XX_RTG_SUCCESS_STG_TBL.COUNT LOOP
	      IF XX_RTG_SUCCESS_STG_TBL(i).assembly_item_number IS NOT NULL THEN
	        update xxha_bom_routing_ops_stg
	        set rt_status = 'PS'
			, op_status = 'PS'
		    where assembly_item_number = XX_RTG_SUCCESS_STG_TBL(i).assembly_item_number
		    and rt_status <> 'PS';
			update xxha_bom_op_resources_stg
	        set status = 'PS'
		    where assembly_item_number = XX_RTG_SUCCESS_STG_TBL(i).assembly_item_number
		    and status <> 'PS';
	      END IF;
	    END LOOP;
		Commit;
	   dbms_output.put_line('Commit');
	 ELSE
	   Rollback;
	   FOR i IN 1..XX_RTG_SUCCESS_STG_TBL.COUNT LOOP
	      IF XX_RTG_SUCCESS_STG_TBL(i).assembly_item_number IS NOT NULL THEN
	       update xxha_bom_routing_ops_stg
	        set rt_status = 'VS'
			,op_status = 'VS'
		    where assembly_item_number = XX_RTG_SUCCESS_STG_TBL(i).assembly_item_number
		    and rt_status <> 'VS';
			update xxha_bom_op_resources_stg
	        set status = 'VS'
		    where assembly_item_number = XX_RTG_SUCCESS_STG_TBL(i).assembly_item_number
		    and status <> 'VS';
	      END IF;
	    END LOOP;
	   dbms_output.put_line('Roll');

	 END IF;
     log_all_errors;
	 commit;
Exception

When Others Then
  populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others Convert Rtg',gn_record_number,gc_record_identifier);
  Rollback;
  log_all_errors;
  commit;


END convert_rtg;



END XXHA_RTG_CONV_PKG;  -- package body

/
