CREATE OR REPLACE PACKAGE
  XXHA_OM_PRICE_LIST_CONV_PK AUTHID CURRENT_USER
AS
-- +============================================================================+
-- |                        Oracle NAIO (India)                        		    |
-- |                         Bangalore, India                          		    |
-- +============================================================================+
-- |                                                                   		    |
-- | $Id$                                                              		    |
-- |                                                                   		    |
-- |Description  Package to convert Price list from legacy to oracle   		    |
-- |             base table                                            		    |
-- |                                                                   		    |
-- |                                                                   		    |
-- |Change Record:                                                     		    |
-- |===============                                                    		    |
-- |Version   Date        Author           Remarks                     		    |
-- |=======   ==========  =============    ============================		    |
-- |DRAFT 1A 03-Oct-2006  Subramanya S.N    Initial draft version      		    |
-- |1.0      02-Nov-2006  Subramanya S.N    After Review               		    |
-- |1.1      15-Nov-2006  Subramanya S.N    Update  Value for global   		    |
-- |                                        variable gc_arithmatic_oprt1 	    |
-- |                                        to 'UNIT_PRICE'      		        |
-- |1.2      01-Dec-2006 Subramanya S.N     Added global var for Operating unit |
-- |3.00     04-FEB-2014  BMarcoux         Modifications required for R12.      |
-- +============================================================================+

   --GlobalVariables
   gc_request_id            xxha_common_errors.request_id%TYPE:= fnd_global.conc_request_id;
   gc_program_name          VARCHAR2(1000):='Price List Conversion';
   gc_record_identify       xxha_common_errors.record_identifier%TYPE:='Price List';                   --Record identifier of staging table
   gc_record_number         xxha_common_errors.record_number%TYPE;                                     --Record_number of staging table
   gc_record_identifier     xxha_common_errors.record_identifier%TYPE;                                 --Record identifier of staging table
   gc_error_code            xxha_common_errors.error_code%TYPE;                                        --Error_code insert in common error table
   gc_error_msg             xxha_common_errors.error_msg%TYPE;                                         --Error_msg  insert in common error table
   gc_comments              xxha_common_errors.comments%TYPE;                                          --Comments   insert in common error table
   gc_attribute1            xxha_common_errors.attribute1%TYPE;                                        --Attribute1 insert in common error table
   gc_attribute2            xxha_common_errors.attribute2%TYPE;                                        --Attribute2 insert in common error table
   gc_attribute3            xxha_common_errors.attribute3%TYPE;                                        --Attribute3 insert in common error table
   gc_attribute4            xxha_common_errors.attribute4%TYPE;                                        --Attribute4 insert in common error table
   gc_attribute5            xxha_common_errors.attribute5%TYPE;                                        --Attribute5 insert in common error table
   gc_status                VARCHAR2(2);                                                               -- Variable to get status falg of data insertion in common error table
   gc_list_type_code        fnd_lookup_values.lookup_code%TYPE:='PRL';
   gc_line_type_code        fnd_lookup_values.lookup_code%TYPE:='PLL';
   gc_prc_context_code      qp_prc_contexts_b.prc_context_code%TYPE:='ITEM';
   gc_prc_attribute         qp_segments_b.segment_mapping_column%TYPE:='PRICING_ATTRIBUTE1';
   gc_con_prg_shot_name     fnd_concurrent_programs.concurrent_program_name%TYPE:='XXHA_PRICE_LIST_CONV';
   gc_table_name            xxha_common_errors.TABLE_NAME%TYPE:='USBPCS_PRICELIST_CLEANED';
   --Start of changes V1.1
   gc_arithmatic_oprt1      fnd_lookup_values.lookup_code%TYPE:='UNIT_PRICE';
   --End of changes V1.1
   gc_arithmatic_oprt2      fnd_lookup_values.lookup_code%TYPE:='AMT';
   gc_debug_flag            VARCHAR2(1);
   gc_log_msg               VARCHAR2(3000);
   --Start of changes V1.2
   gc_operating_unit_name  hr_operating_units.NAME%TYPE;
   --End of changes V1.2




   --Procedure to validate records
   PROCEDURE validate_price_lists (x_errbuf        OUT VARCHAR2
                                  ,x_retcode       OUT VARCHAR2
                                  ,p_debug        IN VARCHAR2
                                  ,p_purge_data    IN  VARCHAR2
                                  );

   --Procedure to import pricelist records
   PROCEDURE process_price_lists (x_retcode       OUT VARCHAR2
                                 );



   --Procedure to import secondary pricelist records
   PROCEDURE PROCESS_SECONDARY_PRICE_LISTS(  x_errbuf       OUT VARCHAR2
                                 	    ,x_retcode      OUT VARCHAR2
                                            ,p_debug         IN VARCHAR2
                                 );









END XXHA_OM_PRICE_LIST_CONV_PK;
/


CREATE OR REPLACE PACKAGE BODY
   XXHA_OM_PRICE_LIST_CONV_PK
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |                                                                   |
-- |Name         :XXHA_OM_PRICE_LIST_CONV_PK                           |
-- |                                                                   |
-- |Description  :Package to convert Price list from legasys to oracle |
-- |              base table                                           |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A 03-Oct-2006  Subramanya S.N    Initial draft version      |
-- |1.0      02-Nov-2006  Subramanya S.N    After Review               |
-- |1.1      09-Nov-2006  Subramanya S.N    Commented Arithmatic Opertr|
-- |                                        Logic and used             |
-- |                                        UNIT_PRICE as operator     |
-- |1.2      01-Dec-2006 Subramanya S.N     Added logic to validate    |
-- |                                        and process on Operatin unit
-- |                                        specific.                  |
-- |                                        Added statistic for        |
-- |                                        for error records both in  |
-- |                                        val and process procedure  |
-- |1.3      18-Jan-2007 Subramanya S.N     Added following logic      |
-- |                                        Populate Pricelist header  |
-- |                                        start/end date by taking min
-- |                                        /max of lines              |
-- |                                                                   |
-- |                                        If condurmon is null then  |
-- |                                        set enddate to null.       |
-- |                                                                   |
-- |                                        If Min of Startdate  or MAX|
-- |                                        enddate is NULL then error |
-- |                                        out                        |
-- |                                                                   |
-- |                                        Logic to errorout the price
-- |                                        list If stedte is null for US
-- |1.4    12-Feb-2007 Subramanya S.N       Modified Err Msg
-- |                                       Added logic to update the procelist
-- |                                       if already exist in oracle
-- |1.5    26-Feb-2007 Subbu               Re-initialise of Local variable for item number
-- |1.6    09-Mar-2007 Subbu               Modified the API..add parameter
-- |                                       to pass   PRIMARY_UOM_FLAG
-- |
-- |                                       Added logic to check for
-- |                                       contracttype IC,SA for pricelist
-- |                                       header enddate
-- |1.7   14-Mar-2007 Subbu	               Added TO_DATE function to MIN/MAX pricelistlist dates
-- |                                       Added operating unit condition for UPDATE statment
-- |1.8   04-Apr-2007 Subbu                Populate pricelistname to description
-- |1.9   16-Apr-2007 Subbu                Added new procedure to process Secondary pricelist
-- |1.10  20-aug-2007 Patrick              Modified rounding factor to use currency code
-- |3.00  04-FEB-2014 BMarcoux             Modifications required for R12.      |
-- +===================================================================+
AS

-- +===================================================================+
-- | Name        :  UPDATE_RECORD_STATUS_SEC                           |
-- | Description :  Procedure to update  the status of processd        |
-- |                records  for secondary pricelist                   |
-- | Parameters  :  p_pricelist_name                                   |
-- |                p_status_flag                                      |
-- |                                                                   |
-- | Returns     :  NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE UPDATE_RECORD_STATUS_SEC(
                               p_pricelist_name        IN      VARCHAR2
                               ,p_identifier           IN       NUMBER
                              ,p_status_flag           IN      VARCHAR2
                              )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  USBPCS_PriceList_Cleaned HC
   SET     HC.oraclecharfld1  =   p_status_flag
   WHERE   HC.pricelistname   =   p_pricelist_name
   --Start of Changes V1.7
    AND oraclegenuse2=gc_operating_unit_name
    and ORACLEIDENTIFIER=p_identifier;
  --End of Changes V1.7
   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in xxha_om_price_list_conv_pk.update_record_status: ' || SQLERRM);
   RAISE;
end UPDATE_RECORD_STATUS_SEC;

-- +===================================================================+
-- | Name        :  UPDATE_RECORD_STATUS                               |
-- | Description :  Procedure to update  the status of processd        |
-- |                records                                            |
-- | Parameters  :  p_pricelist_name                                   |
-- |                p_status_flag                                      |
-- |                                                                   |
-- | Returns     :  NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE UPDATE_RECORD_STATUS(
                               p_pricelist_name        IN      VARCHAR2
                              ,p_status_flag           IN      VARCHAR2
                              )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  USBPCS_PriceList_Cleaned HC
   SET     HC.oraclecharfld1  =   p_status_flag
   WHERE   HC.pricelistname   =   p_pricelist_name
   --Start of Changes V1.7
    AND oraclegenuse2=gc_operating_unit_name;
  --End of Changes V1.7
   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in xxha_om_price_list_conv_pk.update_record_status: ' || SQLERRM);
   RAISE;
END UPDATE_RECORD_STATUS;

-- +===================================================================+
-- | Name       :   INSERT_ERROR_MSG                                   |
-- | Description:   Procedure to call xxsc_common_utilities            |
-- |                to insert errors into error table                  |
-- |                records                                            |
-- | Parameters :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- | Returns    :   NONE                                               |
-- |                ;                                                  |
-- |                                                                   |
-- +===================================================================+
PROCEDURE INSERT_ERROR_MSG
IS
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gc_request_id
                                             ,gc_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                            );

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in xxha_common_utilities_pkg.INSERT_ERROR_MSG. Error is: ' ||SQLERRM);
END INSERT_ERROR_MSG;

-- +===================================================================+
-- | Name       :   CHK_PRICE_LIST_SETUP                               |
-- |                                                                   |
-- | Description:   Function to check setup`s for price list           |
-- |                                                                   |
-- |                                                                   |
-- | Parameters :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- | Returns    :   Returns Y/N                                        |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
FUNCTION chk_price_list_setup RETURN VARCHAR2
IS
   lc_listtype_flag    VARCHAR2(1):='N';
   lc_linetype_flag    VARCHAR2(1):='N';
   lc_ptd_cntx_flag    VARCHAR2(1):='N';
   lc_arth_oprt1_exist VARCHAR2(1):='N';
   lc_arth_oprt2_exist VARCHAR2(1):='N';
   ln_prc_context_id  qp_prc_contexts_b.prc_context_id%TYPE;


   ----------------------------------------------------
   --Cursor to check if list type code has been defined
   ----------------------------------------------------
   CURSOR  lcu_chk_list_type_code
   IS
   SELECT  'Y'
   FROM    qp_lookups QL
   WHERE   QL.lookup_code= gc_list_type_code
   AND     SYSDATE BETWEEN NVL(QL.start_date_active,SYSDATE) AND NVL(QL.end_date_active,SYSDATE+1)
   AND     QL.enabled_flag='Y'
   AND     QL.lookup_type='LIST_TYPE_CODE';

   ---------------------------------------------------------
   --Cursor to check if list line type code has been defined
   ---------------------------------------------------------
   CURSOR  lcu_chk_line_type_code
   IS
   SELECT  'Y'
   FROM    qp_lookups QL
   WHERE   QL.lookup_code= gc_line_type_code
   AND     SYSDATE BETWEEN NVL(QL.start_date_active,SYSDATE) AND NVL(QL.end_date_active,SYSDATE+1)
   AND     QL.enabled_flag='Y'
   AND     QL.lookup_type='LIST_LINE_TYPE_CODE';


   ---------------------------------------------------------
   --Cursor to check if product attribute context is defined
   ---------------------------------------------------------
   CURSOR lcu_chk_prodt_attbte_cntx
   IS
   SELECT prc_context_id
   FROM   qp_prc_contexts_b QPCB
   WHERE  QPCB.prc_context_code=gc_prc_context_code;

   -------------------------------------------------
   --Cursor to check if product attribute is defined
   -------------------------------------------------
   CURSOR lcu_chk_prodt_attbte(p_prc_context_id NUMBER)
   IS
   SELECT 'Y'
   FROM    qp_segments_b QSB
   WHERE   QSB.prc_context_id=p_prc_context_id
   AND     QSB.segment_mapping_column=gc_prc_attribute
   AND     QSB.segment_code='INVENTORY_ITEM_ID';

   --------------------------------------------------------
   --Cursor to check if Arithmatic operators '%' is defined
   --------------------------------------------------------

   CURSOR lcu_chk_arth_oprt(p_arithmatic_oprt VARCHAR2)
   IS
   SELECT 'Y'
   FROM    qp_lookups QL
   WHERE   QL.lookup_code= p_arithmatic_oprt
   AND     SYSDATE BETWEEN NVL(QL.start_date_active,SYSDATE) AND NVL(QL.end_date_active,SYSDATE+1)
   AND     QL.enabled_flag='Y'
   AND     QL.lookup_type='ARITHMETIC_OPERATOR';


BEGIN
   -----------------------------------
   --Check if LIST_TYPE_CODE is defined
   -----------------------------------
   OPEN  lcu_chk_list_type_code;
   FETCH lcu_chk_list_type_code INTO lc_listtype_flag;
     IF lcu_chk_list_type_code%NOTFOUND THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='LIST_TYPE_CODE: '||gc_list_type_code||' is Invalid';
        gc_comments   :='Please define the value in the LIST_TYPE_CODE Lookup';
        INSERT_ERROR_MSG;
        lc_listtype_flag:='N';
     END IF;
   CLOSE lcu_chk_list_type_code;
   gc_log_msg:='Flag returned by the LIST_TYPE_CODE cursor: '||lc_listtype_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ----------------------------------------
   --Check if LIST_LINE_TYPE_CODE is defined
   -----------------------------------------
   OPEN  lcu_chk_line_type_code;
   FETCH lcu_chk_line_type_code INTO lc_linetype_flag;
      IF lcu_chk_line_type_code%NOTFOUND THEN
         --Log error
         gc_error_code   :='SETUP-Error';
         gc_error_msg    :='LIST_LINE_TYPE_CODE: '||gc_line_type_code||' is Invalid';
         gc_comments     :='Please define the value in the LIST_LINE_TYPE_CODE Lookup';
         INSERT_ERROR_MSG;
         lc_linetype_flag:='N';
      END IF;
   CLOSE lcu_chk_line_type_code;
   gc_log_msg:='Flag returned by the LIST_LINE_TYPE_CODE cursor: '||lc_linetype_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --------------------------------------------------
   --Check if product_attribute_context(ITEM) is Defined
   --------------------------------------------------
   OPEN  lcu_chk_prodt_attbte_cntx;
   FETCH lcu_chk_prodt_attbte_cntx INTO  ln_prc_context_id;
      IF lcu_chk_prodt_attbte_cntx%NOTFOUND THEN
         --Log err
         gc_error_code:='SETUP-Error';
         gc_error_msg :='Product Attribute context: '||gc_prc_context_code||' is Invalid';
         gc_comments  :='Please define the Product Attribute context';
         INSERT_ERROR_MSG;
         lc_ptd_cntx_flag:='N';
      ELSE
         -- Check if product_attribute(PRICING_ATTRIBUTE1) is defined
         OPEN  lcu_chk_prodt_attbte(ln_prc_context_id);
         FETCH lcu_chk_prodt_attbte INTO lc_ptd_cntx_flag;
            IF lcu_chk_prodt_attbte%NOTFOUND THEN
               --Log error
               gc_error_code       :='SETUP-Error';
               gc_error_msg        :='Product Attribute: '||gc_prc_attribute||' is Invalid for the Context: '||gc_prc_context_code;
               gc_comments         :='Please define the Product Attribute';
               INSERT_ERROR_MSG;
               lc_ptd_cntx_flag:='N';
            END IF;
         CLOSE lcu_chk_prodt_attbte;
      END IF;
   CLOSE lcu_chk_prodt_attbte_cntx;
   gc_log_msg:='Flag returned by the PRODUCT_ATTRIBUTE_CONTEXT cursor :'||lc_ptd_cntx_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --Start of changes V1.1
   -----------------------------------------------
   --Check if Arithmatic operators(UNIT_PRICE) is defined
   -----------------------------------------------
   OPEN  lcu_chk_arth_oprt(gc_arithmatic_oprt1);
   FETCH lcu_chk_arth_oprt INTO lc_arth_oprt1_exist;
      IF lcu_chk_arth_oprt%NOTFOUND THEN
         --Log error
         gc_error_code       :='SETUP-Error';
         gc_error_msg        :='ARITHMATIC_OPERATOR: '||gc_arithmatic_oprt1||' is Invalid';
         gc_comments         :='Please define the value in the ARITHMATIC_OPERATOR Lookup';
         INSERT_ERROR_MSG;
         lc_arth_oprt1_exist:='N';
      END IF;
   CLOSE lcu_chk_arth_oprt;
   gc_log_msg:='Flag returned by the ARITHMATIC OPERATORS cursor for % :'||lc_arth_oprt1_exist;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


   --------------------------------------------------
   --Check if Arithmatic operators('AMT') is defined
   --------------------------------------------------

 /*  OPEN  lcu_chk_arth_oprt(gc_arithmatic_oprt2);
   FETCH lcu_chk_arth_oprt INTO lc_arth_oprt2_exist;
      IF lcu_chk_arth_oprt%NOTFOUND THEN
         gc_error_code       :='SETUP-Error';
         gc_error_msg        :='Arithmatic Operator: '||gc_arithmatic_oprt2||' is Invalid';
         gc_comments         :='Please define the value in the ARITHMATIC_OPERATOR Lookup';
         INSERT_ERROR_MSG;
         lc_arth_oprt2_exist:='N';
      END IF;
   CLOSE lcu_chk_arth_oprt;
   gc_log_msg:='Flag returned by the ARITHMATIC OPERATORS cursor for AMT :'||lc_arth_oprt2_exist;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);*/
    --End of changes V1.1

   ---------------------------------------------------------------
   --If any of the above setup`s are missing, eror out the program
   ---------------------------------------------------------------
   IF (lc_listtype_flag    <>'Y' OR
       lc_linetype_flag    <>'Y' OR
       lc_ptd_cntx_flag    <>'Y' OR
       lc_arth_oprt1_exist <>'Y' ) THEN
       --Start of changes V1.1
       --lc_arth_oprt2_exist <>'Y')
       --End of changes V1.1
       RETURN 'N';
   ELSE
      RETURN 'Y';
   END IF;

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error encountered while checking Setup in the function CHK_PRICE_LIST_SETUP  '||SQLERRM);
   RAISE;
END CHK_PRICE_LIST_SETUP;

-- +===================================================================+
-- | Name          : VALIDATE_PRICE_LISTS                              |
-- | Description   : Procedure to validate and import the price list   |
-- |                 records                                           |
-- |                                                                   |
-- | Parameters    : x_errbuf   OUT                                    |
-- |                 x_errbuf   OUT                                    |
-- |                 p_debug    IN                                     |
-- | Returns       : NONE;                                             |
-- |                                                                   |
-- +===================================================================+
PROCEDURE VALIDATE_PRICE_LISTS (
                              x_errbuf       OUT VARCHAR2
                             ,x_retcode      OUT VARCHAR2
                             ,p_debug         IN VARCHAR2
                             ,p_purge_data    IN VARCHAR2
                             )
IS
   --Local Valribles
   lc_setup_err_flag        VARCHAR2(1):='N';
   lc_item_err_flag         VARCHAR2(1):='N';
   lc_procelist_err_flag    VARCHAR2(1):='N';
   lc_currency_err_flag     VARCHAR2(1):='N';
   lc_date_err_flag         VARCHAR2(1):='N';
   lc_date_err1_flag        VARCHAR2(1):='N';
   lc_date_err2_flag        VARCHAR2(1):='N';
   lc_selprice_err_flag     VARCHAR2(1):='N';
   lc_mast_prc_err_flag     VARCHAR2(1):='N';
   lc_mast_err_flag         VARCHAR2(1):='N';
   lc_pricelist_err_flag    VARCHAR2(1):='N';
   lc_arth_oprt_err_flag    VARCHAR2(1):='N';
   lc_item_date_err_flag    VARCHAR2(1):='N';
   lc_arithmatic_operator   VARCHAR2(100);
   lc_setup_exist           VARCHAR2(1);
   lc_retcode               VARCHAR2(1);
   ld_item_strt_dte         DATE;
   ld_item_end_dte          DATE;
   ld_itm_strt_dte_old      DATE;
   ld_itm_end_dte_old       DATE;
   ln_rec_fetched           NUMBER:=0;
   ln_rec_validated         NUMBER:=0;
   ln_rec_errored           NUMBER:=0;
   ln_commit_point          NUMBER:=0;
   ld_start_date            DATE;
   ld_end_date              DATE;
   lc_pricename             usbpcs_pricelist_cleaned.pricelistname%TYPE:='+9+0+';
   lc_item_number           usbpcs_pricelist_cleaned.itemnumber%TYPE:='+9+0+';
   ln_inventory_item_id     mtl_system_items_b.inventory_item_id%TYPE;
   lc_uom                   mtl_system_items_b.primary_uom_code%TYPE;
   EX_INVALID_STDATE_FORMAT EXCEPTION;
   EX_START_DATE_NULL       EXCEPTION;
   EX_INVALID_ENDATE_FORMAT EXCEPTION;
   lc_countrycode           VARCHAR2(10);

   ---------------------------------------------------------
   --Cursot to get all the price list from the staging table
   ---------------------------------------------------------
   CURSOR  lcu_get_price_list
   IS
   SELECT   *
   FROM     usbpcs_pricelist_cleaned UPC
   --Start of changes V1.2
   WHERE    UPC.OracleGenUse2=gc_operating_unit_name
   AND      UPC.oraclecharfld1 IS NULL
   --End of changes V1.2
   ORDER BY UPC.pricelistname
           ,UPC.itemnumber
           ,UPC.startdate
           ,UPC.endingdate;

   --------------------------------------------------
   --Cursor to check if price list is already defined
   --------------------------------------------------
   CURSOR lcu_chk_price_list(p_price_list VARCHAR2)
   IS
   SELECT 'N'
   FROM   qp_list_headers_tl QLHT
   WHERE  QLHT.name=p_price_list;

   ---------------------------------------------------
   --Cursor to get INVENTORY_ITEM_ID and UOM for items
   ---------------------------------------------------
   CURSOR lcu_chk_item(p_item VARCHAR2)
   IS
   SELECT 'N'
          ,inventory_item_id
          ,primary_uom_code
   FROM    mtl_system_items_b MSIB
          ,mtl_parameters     MP
   WHERE   MP.organization_id  =MP.master_organization_id
   AND     MSIB.organization_id=MP.organization_id
   AND     MSIB.segment1       =p_item;

   ----------------------------------------------
   --Cursor to check if valid currency code exist
   ----------------------------------------------
   CURSOR lcu_chk_currency(p_currency VARCHAR2)
   IS
   SELECT 'N'
   FROM   fnd_currencies FC
   WHERE  SYSDATE BETWEEN NVL(FC.start_date_active, SYSDATE) AND NVL(FC.end_date_active, SYSDATE)
   AND    FC.currency_code = UPPER(p_currency)
   AND    FC.enabled_flag = 'Y';

   ---------------------------------------
   --Cursor to get total count of records
   ---------------------------------------
   CURSOR lcu_get_rec_count
   IS
   SELECT COUNT(1)
   FROM   usbpcs_pricelist_cleaned UPC
   --Start of changes V1.2
   WHERE  UPC.OracleGenUse2=gc_operating_unit_name;
   --End of changes V1.2


   ------------------------------------------------
   --Cursor to get total count of records Validated
   ------------------------------------------------
   CURSOR lcu_get_rec_val_count
   IS
   SELECT COUNT(1)
   FROM   usbpcs_pricelist_cleaned UPC
   WHERE  UPC.oraclecharfld1='VS'
   --Start of changes V1.2
   AND    UPC.OracleGenUse2=gc_operating_unit_name;
   --End of changes V1.2

   ------------------------------------------------
   --Cursor to get total count of records Errored
   ------------------------------------------------
   CURSOR lcu_get_rec_err_count
   IS
   SELECT COUNT(1)
   FROM   usbpcs_pricelist_cleaned UPC
   WHERE  UPC.oraclecharfld1='VE'
   --Start of changes V1.2
   AND    UPC.OracleGenUse2=gc_operating_unit_name;
   --End of changes V1.2



BEGIN
  --Start of changes V1.2
   --------------------------------------------
   -- Selecting the current operating unit name
   --------------------------------------------
   BEGIN
      SELECT  HOU.name
      INTO    gc_operating_unit_name
      FROM    hr_operating_units  HOU
      WHERE   HOU.organization_id   =  FND_PROFILE.VALUE('ORG_ID');
   EXCEPTION
   WHEN    NO_DATA_FOUND   THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Operating Unit Does not Exist in the Application');
      x_retcode := 2;
      RETURN;

   WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Unexpected error encountered when trying to ger Operating Unit '||SQLERRM);
   x_retcode := 2;
   RETURN;
   END;
   --End of changes V1.2


  --Start of changes V1.3
  --------------------------------------------
  -- Selecting the current operating unit name
  --------------------------------------------
  BEGIN

      SELECT HL.country
      INTO lc_countrycode
      FROM hr_organization_units HOU
          ,hr_locations HL
      WHERE HOU.location_id=HL.location_id
      AND   HOU.name=gc_operating_unit_name;
  EXCEPTION
  WHEN    NO_DATA_FOUND   THEN
     FND_FILE.PUT_LINE(FND_FILE.LOG,'Operating Unit Does not Exist in the Application');
     x_retcode := 2;
     RETURN;

  WHEN OTHERS THEN
  FND_FILE.PUT_LINE(FND_FILE.LOG,'Unexpected error encountered when trying to ger Operating Unit '||SQLERRM);
  x_retcode := 2;
  RETURN;
  END;
  --End of changes V1.3

   gc_log_msg:='Start of Price List Validation';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --Assign the depug parameter to the global variable
   gc_debug_flag:=p_debug;

   gc_record_number    :=NULL;
   gc_record_identifier:=NULL;

   ----------------------------------------
   -- Purge the record from the error table
   ----------------------------------------
   IF (NVL(p_purge_data,'N') = 'Y') THEN
      xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>gc_con_prg_shot_name);
   END IF;

   ----------------
   --Validate setup
   ----------------
   --Call the function "CHK_PRICE_LIST_SETUP" to check if Setup`s exist
   lc_setup_exist:=chk_price_list_setup;

   gc_log_msg:='Status returned by the Setup function CHK_PRICE_LIST_SETUP :'||lc_setup_exist;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --If setup`s exist then validate the records from the staging table ,else error out the program
   IF (lc_setup_exist='Y') THEN
      FOR lcu_get_price_list_rec IN lcu_get_price_list
      LOOP
         --Re Initialise the variables
         lc_item_err_flag       :='N';
         lc_currency_err_flag   :='N';
         lc_date_err_flag       :='N';
         lc_date_err1_flag      :='N';
         lc_date_err2_flag      :='N';
         lc_selprice_err_flag   :='N';
         lc_arth_oprt_err_flag  :='N';

         --Count for records fetched
         --ln_rec_fetched         :=ln_rec_fetched+1;


         gc_record_number       :=lcu_get_price_list_rec.oracleidentifier;
         gc_record_identifier   :=lcu_get_price_list_rec.pricelistname||' - Item number: '||lcu_get_price_list_rec.itemnumber;

         ------------------------------------------
         -- Price list validation
         ------------------------------------------
         --Check if Pricelist has been already defined
         IF (lcu_get_price_list_rec.pricelistname IS NOT NULL) THEN
            --Start od changes V1.4
            NULL;

           IF (lc_pricename <>lcu_get_price_list_rec.pricelistname) THEN
               --lc_mast_prc_err_flag:='N';
              -- lc_pricelist_err_flag  :='N';
              --Start of changes 1.5
              lc_pricename:=lcu_get_price_list_rec.pricelistname;
              lc_item_number :='-77-';
               --End of changes 1.5
              /*
              lc_pricename:=lcu_get_price_list_rec.pricelistname;
               lc_item_number :='-77-';
               OPEN  lcu_chk_price_list(lcu_get_price_list_rec.pricelistname);
               FETCH lcu_chk_price_list INTO lc_pricelist_err_flag;
                  IF lcu_chk_price_list%FOUND THEN
                     --Log error message
                     gc_error_code       :='PL01';
                     gc_error_msg        :='Price List Name: '||lcu_get_price_list_rec.pricelistname||' already exists in Oracle';
                     gc_comments         :='Please use a different Price List Name';
                     INSERT_ERROR_MSG;
                     lc_pricelist_err_flag:='Y';
                  END IF;
               CLOSE lcu_chk_price_list;
               */
            END IF;

             --End od changes V1.4
         ELSE
            --Log error message
            gc_error_code       :='PL01';
            gc_error_msg        :='Field pricelistname cannot be NULL in the staging table';
            gc_comments         :='Please provide the Price List Name';
            INSERT_ERROR_MSG;
            lc_pricelist_err_flag:='Y';
         END IF;
         gc_log_msg:='Flag returned by the Price list validation cursor :'||lc_pricelist_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         --If pricelist doesnt exist then check for other validations
         IF (lc_pricelist_err_flag <>'Y') THEN
            ----------------------------
            -- Start/End date validation
            ---------------------------
            BEGIN
               ld_start_date:=NULL;
               ld_end_date  :=NULL;
               IF (lcu_get_price_list_rec.startdate IS NOT NULL AND
                  lcu_get_price_list_rec.endingdate IS NOT NULL) THEN

                  ld_start_date:=TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD');
                  ld_end_date  :=TO_DATE(lcu_get_price_list_rec.endingdate,'YYYY-MM-DD');

                  --Check if start is greatet then enddate
                  IF (ld_start_date > ld_end_date) THEN
                     --Log error
                     gc_error_code       :='PL02';
                     gc_error_msg        :='Start date: '||lcu_get_price_list_rec.startdate||' is greater than End date: '||lcu_get_price_list_rec.endingdate||' for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                     gc_comments         :='Start date cannot be greater then Enddate';
                     INSERT_ERROR_MSG;
                     lc_date_err_flag:='Y';
                  END IF;
               ELSE --lcu_get_price_list_rec.startdate IS NOT NULL AND

                  --Check if Startdate is NULL
                  IF (NVL(lcu_get_price_list_rec.startdate,0) = 0) THEN

                      --Start of changes V1.3
                      IF lc_countrycode ='US' THEN
                         RAISE EX_START_DATE_NULL;
                      END IF;
                      --End of changes V1.3

                  ELSE
                     --Check If it is able to convert date format
                     BEGIN
                        ld_start_date:=TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD');
                     EXCEPTION
                     WHEN OTHERS THEN
                        RAISE EX_INVALID_STDATE_FORMAT;
                     END;
                  END IF;

                  --Derive the contractdurationmonths if the enddate is null.
                  IF (NVL(lcu_get_price_list_rec.endingdate,0) = 0) THEN
                      -- Add the contractdurationmonths to startdate to get endate active
                      --ld_end_date:=ADD_MONTHS(TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD'), NVL(lcu_get_price_list_rec.contractdurationmonths,0));
                      --Start of changes V1.3
                      IF NVL(lcu_get_price_list_rec.contractdurationmonths,0)=0 THEN
                         ld_end_date:=Null;
                      ELSE
                         ld_end_date:=ADD_MONTHS(TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD'),  lcu_get_price_list_rec.contractdurationmonths );

                      END IF;

                       --End of changes V1.3
                      --END IF;
                  ELSE
                      --IF value exist,convert it to date format
                      BEGIN
                        ld_end_date:=TO_DATE(lcu_get_price_list_rec.endingdate,'YYYY-MM-DD');
                      EXCEPTION
                      WHEN OTHERS THEN
                         RAISE EX_INVALID_ENDATE_FORMAT;
                      END;
                  END IF;
                   ---Check if start is greatet then enddate
                  IF (ld_start_date > ld_end_date) THEN
                     gc_error_code       :='PL03';
                     gc_error_msg        :='Start date: '||lcu_get_price_list_rec.startdate||' is greater than End date: '||ld_end_date||' for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the pricelist: '||lcu_get_price_list_rec.pricelistname;
                     gc_comments         :='Start date cannot be greater then Enddate';
                     INSERT_ERROR_MSG;
                     lc_date_err_flag:='Y';
                  END IF;
               END IF; --Main If condition

            EXCEPTION
            WHEN EX_START_DATE_NULL THEN
               gc_error_code       :='PL04';
               gc_error_msg        :='Field startdate cannot be NULL in the staging table for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the pricelist: '||lcu_get_price_list_rec.pricelistname;
               gc_comments         :='Please provide the startdate';
               INSERT_ERROR_MSG;
               lc_date_err_flag:='Y';
            WHEN EX_INVALID_STDATE_FORMAT THEN
               gc_error_code       :='PL05';
               gc_error_msg        :='Invalid startdate for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the pricelist: '||lcu_get_price_list_rec.pricelistname;
               gc_comments         :='Please provide the date in YYYYMMDD format for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the pricelist: '||lcu_get_price_list_rec.pricelistname;
               INSERT_ERROR_MSG;
               lc_date_err_flag:='Y';
            WHEN EX_INVALID_ENDATE_FORMAT THEN
               gc_error_code       :='PL06';
               gc_error_msg        :='Invalid endingdate for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the pricelist: '||lcu_get_price_list_rec.pricelistname;
               gc_comments         :='Please provide the date in YYYYMMDD format';
               INSERT_ERROR_MSG;
               lc_date_err_flag:='Y';
            WHEN OTHERS THEN
               gc_error_code       :='PL07';
               gc_error_msg        :='Unexpected error encountered during date validation for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
               gc_comments         :=SQLERRM||' Please ensure that Start/Endingdate fileds are having valid date in the format YYYYMMDD ';
               INSERT_ERROR_MSG;
               lc_date_err_flag:='Y';
            END ;--main validation
            gc_log_msg:='Flag returned by the START/END DATE validation  :'||lc_date_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            -------------------------------------------
            -- Item validation
            -------------------------------------------
            BEGIN
               IF (lcu_get_price_list_rec.itemnumber IS NOT NULL) THEN
                  IF (lc_item_number <> trim(lcu_get_price_list_rec.itemnumber)) THEN
                     --lc_item_err_flag     :='N';
                     ln_inventory_item_id   :=NULL;
                     lc_uom                 :=NULL;
                     ld_item_strt_dte       :=NULL;
                     ld_item_end_dte        :=NULL;
                     ld_itm_strt_dte_old    :=NULL;
                     ld_itm_end_dte_old     :=NULL;
                     lc_item_date_err_flag  :='N';

                     lc_item_number:=lcu_get_price_list_rec.itemnumber;
                     --Store the start/end date of the current record in
                     --local variable  to check for overlpping if the pricelist has same items
                     IF (lc_date_err_flag <>'Y') THEN
                        ld_item_strt_dte:=ld_start_date; --TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD');
                        ld_item_end_dte :=ld_end_date;
                     ELSE
                        lc_item_date_err_flag:='Y';
                     END IF;

                     --Check if the Item exist in oracle and get the item id and UOM
                     OPEN  lcu_chk_item(trim(lcu_get_price_list_rec.itemnumber));
                     FETCH lcu_chk_item INTO lc_item_err_flag,ln_inventory_item_id,lc_uom;
                        IF lcu_chk_item%NOTFOUND THEN
                            --Log error message
                            gc_error_code       :='PL08';
                            gc_error_msg        :='Invalid Item: '||lcu_get_price_list_rec.itemnumber||' for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                            gc_comments         :='Please check this item in Master Inventory Organization';
                            INSERT_ERROR_MSG;
                            lc_item_err_flag:='Y';
                        END IF;
                     CLOSE lcu_chk_item;
                  ELSE --IF lc_item_number <> trim(lcu_get_price_list_rec.itemnumber) THEN
                     --Check if the records having same Item,UOM etc are having overlappng dates
                     --Store the start/end date of the previous recods
                     IF (lc_date_err_flag ='N' AND lc_item_date_err_flag='N') THEN
                        ld_itm_strt_dte_old:=ld_item_strt_dte;
                        ld_itm_end_dte_old :=ld_item_end_dte;

                        --Store the start/end date of the current  recods
                        ld_item_strt_dte:=ld_start_date;
                        ld_item_end_dte :=ld_end_date;

                        --*********************** --Start of changes V1.3
                        IF ld_item_strt_dte IS NOT NULL AND ld_itm_end_dte_old IS NOT NULL THEN
                           --Check if the date are overlapping
                           IF (ld_item_strt_dte <= NVL(ld_itm_end_dte_old,ld_item_strt_dte)) THEN --added by subbu V1.3
                              --ld_strt_dte>ld_end_dte  THEN
                              --Log error msg
                              gc_error_code       :='PL09-1';
                              gc_error_msg        :='The price list line effective dates overlap with startdate: '||ld_item_strt_dte||' and enddate: '||ld_itm_end_dte_old||' for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                              gc_comments         :='Two lines with same item,UOM and pricing attributes cannot have overlapping effective dates';
                              INSERT_ERROR_MSG;
                              lc_item_err_flag:='Y';
                           END IF;
                        --***********************
                        ELSIF ld_item_strt_dte IS NOT NULL AND ld_itm_end_dte_old IS  NULL THEN
                            --Log error msg
                            gc_error_code       :='PL09-2';
                            -- gc_error_msg        :='The price list line effective dates overlap with startdate : '||ld_item_strt_dte||' and enddate: '||ld_itm_end_dte_old||' for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                            gc_error_msg	 :='Pricelist end date of the previous record is holding null for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                            gc_comments         :='Two lines with same item,UOM and pricing attributes cannot have overlapping effective dates';
                            INSERT_ERROR_MSG;
                            lc_item_err_flag:='Y';
                        --***********************
                        ELSIF ld_item_strt_dte IS   NULL AND ld_itm_end_dte_old IS NOT NULL THEN
                            --Log error msg
                            gc_error_code       :='PL09-3';
                            --gc_error_msg        :='The price list line effective dates overlap with startdate : '||ld_item_strt_dte||' and enddate: '||ld_itm_end_dte_old||' for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                            gc_error_msg	 :='Pricelist Start date is holding null for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                            gc_comments         :='Two lines with same item,UOM and pricing attributes cannot have overlapping effective dates';
                            INSERT_ERROR_MSG;
                            lc_item_err_flag:='Y';
                        ELSE
                             --Log error msg
                             gc_error_code       :='PL09-4';
                             --gc_error_msg        :='The price list line effective dates overlap with startdate : '||ld_item_strt_dte||' and enddate: '||ld_itm_end_dte_old||' for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                             gc_error_msg	 :='Pricelist Start date and end date(End date of previous record)is holding null for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                             gc_comments         :='Two lines with same item,UOM and pricing attributes cannot have overlapping effective dates';
                             INSERT_ERROR_MSG;
                             lc_item_err_flag:='Y';


                        END IF;			  --End of changes V1.3
                        --***********************






                     ELSE --IF lc_date_err_flag ='N' AND lc_item_date_err_flag='N' THEN
                        lc_item_date_err_flag:='Y';
                     END IF;
                  END IF; --lc_item_number <> lcu_get_price_list_rec.itemnumber
               ELSE --IF lcu_get_price_list_rec.itemnumber IS NOT NULL
                  --Log error message
                  gc_error_code       :='PL10';
                  gc_error_msg        :='Field Itemnumber cannot be NULL in the staging table for the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                  gc_comments         :='Please provide a valid Item number';
                  INSERT_ERROR_MSG;
                  lc_item_err_flag:='Y';
               END IF; --IF item is null
            EXCEPTION
            WHEN OTHERS THEN
               --Log error message
               gc_error_code       :='PL10';
               gc_error_msg        :='Unexpected error encountered during item validation for the item: '||lcu_get_price_list_rec.itemnumber||' attached to the Pricelist: '||lcu_get_price_list_rec.pricelistname;
               gc_comments         :=SQLERRM||' Please ensure that Start/Endingdate fileds are having valid date format values ';
               INSERT_ERROR_MSG;
               lc_item_err_flag:='Y';
            END;
            gc_log_msg:='Flag returned by the Item validation cursor  :'||lc_item_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            -------------------------------------------
            --Currency code validation
            -------------------------------------------
            --Check if valid currency code exist
            OPEN lcu_chk_currency(lcu_get_price_list_rec.currencycode);
            FETCH lcu_chk_currency INTO lc_currency_err_flag;
               IF lcu_chk_currency%NOTFOUND THEN
                  --Log error message
                  gc_error_code       :='PL11';
                  gc_error_msg        :='Currency code: '||lcu_get_price_list_rec.currencycode||' does not exist or is Invalid for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the Pricelist: '||lcu_get_price_list_rec.pricelistname;
                  gc_comments         :='Please define this currency code';
                  INSERT_ERROR_MSG;
                  lc_currency_err_flag:='Y';
               END IF;
            CLOSE lcu_chk_currency;
            gc_log_msg:='Flag returned by the Currency code validation cursor: '||lc_currency_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            ----------------------------
            -- Validate Selling price
            ----------------------------
            --Check if sellprice is Valid
            IF (lcu_get_price_list_rec.sellprice is NULL OR
               lcu_get_price_list_rec.sellprice <0) THEN
               --Log errors
               gc_error_code       :='PL12';
               gc_error_msg        :='Invalid Selling price: '||lcu_get_price_list_rec.sellprice||' for the Item: '||lcu_get_price_list_rec.itemnumber||' attached to the Pricelist: '||lcu_get_price_list_rec.pricelistname;
               gc_comments         :='Please provide a positive number for selling price';
               INSERT_ERROR_MSG;
               lc_selprice_err_flag:='Y';
            END IF;
            gc_log_msg:='Flag returned by the Selling price validation :'||lc_selprice_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            ------------------------------------------
            -- Validate and derive Arithmatic Operator
            ------------------------------------------
             --Start of changes V1.1
            /*IF (NVL(lcu_get_price_list_rec.pricetype1234,0) IN (1,2)) THEN
               lc_arithmatic_operator:=gc_arithmatic_oprt1;
            ELSIF (lcu_get_price_list_rec.pricetype1234 IN (3,4)) THEN
               lc_arithmatic_operator:=gc_arithmatic_oprt2;
            ELSE
               gc_error_code       :='PL13';
               gc_error_msg        :='Invalid value in the field Pricetype1234: '||lcu_get_price_list_rec.pricetype1234;
               gc_comments         :='Field Pricetype1234 should be in range 1 - 4';
               INSERT_ERROR_MSG;
               lc_arth_oprt_err_flag:='Y';
            END IF;*/
            --End of changes V1.1
            --gc_log_msg:='Flag returned by the Arithmatic oprt validation: '||lc_arth_oprt_err_flag;
            -- xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         END IF; -- IF lc_pricelist_err_flag <>'Y' THEN


         -- If  there exist any errors in the above validations then update the status of the records
         IF (lc_item_err_flag        <>'N'  OR
             lc_pricelist_err_flag   <>'N'  OR
             lc_currency_err_flag    <>'N'  OR
             lc_date_err_flag        <>'N'  OR
             lc_selprice_err_flag    <>'N' )THEN
             --Start of changes V1.1
             --lc_arth_oprt_err_flag   <>'N') THEN
             --End of changes V1.1

            lc_mast_prc_err_flag:='Y';
            lc_mast_err_flag    :='Y';

            --If any errors in the above validation then update the status of the record to VE
            UPDATE usbpcs_pricelist_cleaned
            SET    oraclecharfld1='VE'
                  ,oracleintfld8   =gc_request_id
            WHERE  oracleidentifier=lcu_get_price_list_rec.oracleidentifier
            --Start of Changes V1.7
            AND    oraclegenuse2=gc_operating_unit_name;
            --End of Changes V1.7
         ELSE
           --If NO errors in the above validation then update the status of the record to VS
           UPDATE usbpcs_pricelist_cleaned
           SET    oraclecharfld1='VS'
                 ,oraclecharfld2=lc_uom
                 ,oraclecharfld3=gc_arithmatic_oprt1
                 ,oraclecharfld4=ld_start_date
                 ,oraclecharfld5=ld_end_date
                 ,oracleintfld8   =gc_request_id
                 ,oracleintfld2   =ln_inventory_item_id
           WHERE  oracleidentifier=lcu_get_price_list_rec.oracleidentifier
           --Start of Changes V1.7
           AND oraclegenuse2=gc_operating_unit_name;
           --End of Changes V1.7

         END IF;

      END LOOP; --End of main loop
   ELSE
      lc_mast_err_flag:='Y';
   END IF; -- IF lc_setup_exist='Y'
   COMMIT;

   --Get the total no of records
   OPEN  lcu_get_rec_count;
   FETCH lcu_get_rec_count INTO ln_rec_fetched;
   CLOSE lcu_get_rec_count;

   --Get total no of records Validated
   OPEN lcu_get_rec_val_count;
   FETCH lcu_get_rec_val_count INTO ln_rec_validated;
   CLOSE lcu_get_rec_val_count;


    --Get total no of records Errored
    OPEN lcu_get_rec_err_count;
    FETCH lcu_get_rec_err_count INTO ln_rec_errored;
    CLOSE lcu_get_rec_err_count;

    --Summary information of Records Validated
    --===============================================
    fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
    fnd_file.put_line(fnd_file.log,'Summary information of Records Validated ');
    fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
    fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
    fnd_file.put_line(fnd_file.log,'Total Records Validated             :    ' ||ln_rec_validated);
    fnd_file.put_line(fnd_file.log,'Total Records Errored               :    ' ||ln_rec_errored );

   IF (lc_mast_err_flag='Y') THEN      --If any kind of errors (setup or validation)
      xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);

      IF (lc_setup_exist <>'Y') THEN   --If setup`s are missing then error out the program
         x_retcode:=2;
         RETURN;
      ELSE                           --If validation error then set the status of the prog to warning

         --Summary information of Records Validated
         --===============================================
       /*  fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
         fnd_file.put_line(fnd_file.log,'Summary information of Records Validated ');
         fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
         fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
         fnd_file.put_line(fnd_file.log,'Total Records Validated             :    ' ||ln_rec_validated);
         fnd_file.put_line(fnd_file.log,'Total Records Errored               :    ' ||(ln_rec_fetched - ln_rec_validated));*/
         x_retcode:=1;
         RETURN;
      END IF ;
   ELSE --If no errors the call the process procedure


      process_price_lists (x_retcode =>lc_retcode
                           );
      IF (lc_retcode=1 OR lc_retcode=2) THEN
         xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);
         x_retcode:=lc_retcode;
         RETURN;
      END IF;
   END IF;--(lc_mast_err_flag='Y') THEN
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in xxha_om_price_list_conv_pk.validate_price_lists. Error is: ' ||SQLERRM);
   x_errbuf:=SQLERRM;
   x_retcode:=2;
   ROLLBACK;
END VALIDATE_PRICE_LISTS ;

-- +===================================================================+
-- | Name            : PROCESS_PRICE_LISTS                             |
-- | Description     : Procedure to import the price list into base    |
-- |                   tables                                          |
-- |                                                                   |
-- |                                                                   |
-- | Parameters      : NONE                                            |
-- |                                                                   |
-- |                                                                   |
-- | Returns         : NONE                                            |
-- |                                                                   |
-- +===================================================================+

PROCEDURE PROCESS_PRICE_LISTS (
                               x_retcode  OUT VARCHAR2
                              )
IS
   lc_price_list_rec              QP_Price_List_PUB.Price_List_Rec_Type             :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_REC;
   lc_price_list_val_rec          QP_Price_List_PUB.Price_List_Val_Rec_Type         :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_VAL_REC;
   lc_price_list_line_tbl         QP_Price_List_PUB.Price_List_Line_Tbl_Type        :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_TBL;
   lc_price_list_line_val_tbl     QP_Price_List_PUB.Price_List_Line_Val_Tbl_Type    :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
   lc_qualifiers_tbl              Qp_Qualifier_Rules_Pub.Qualifiers_Tbl_Type        :=  Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_TBL;
   lc_qualifiers_val_tbl          Qp_Qualifier_Rules_Pub.Qualifiers_Val_Tbl_Type    :=  Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_VAL_TBL;
   lc_pricing_attr_tbl            QP_Price_List_PUB.Pricing_Attr_Tbl_Type           :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_TBL;
   lc_pricing_attr_val_tbl        QP_Price_List_PUB.Pricing_Attr_Val_Tbl_Type       :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_VAL_TBL;

-- R12 Mods
   XLC_PRICE_LIST_REC             QP_PRICE_LIST_PUB.PRICE_LIST_REC_TYPE             :=  QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_REC;
   XLC_PRICE_LIST_VAL_REC         QP_PRICE_LIST_PUB.PRICE_LIST_VAL_REC_TYPE         :=  QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_VAL_REC;
   XLC_PRICE_LIST_LINE_TBL        QP_PRICE_LIST_PUB.PRICE_LIST_LINE_TBL_TYPE        :=  QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_TBL;
   XLC_PRICE_LIST_LINE_VAL_TBL    QP_PRICE_LIST_PUB.PRICE_LIST_LINE_VAL_TBL_TYPE    :=  QP_PRICE_LIST_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
   XLC_QUALIFIERS_TBL             QP_QUALIFIER_RULES_PUB.QUALIFIERS_TBL_TYPE        :=  QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_TBL;
   XLC_QUALIFIERS_VAL_TBL         QP_QUALIFIER_RULES_PUB.QUALIFIERS_VAL_TBL_TYPE    :=  QP_QUALIFIER_RULES_PUB.G_MISS_QUALIFIERS_VAL_TBL;
   XLC_PRICING_ATTR_TBL           QP_PRICE_LIST_PUB.PRICING_ATTR_TBL_TYPE           :=  QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_TBL;
   XLC_PRICING_ATTR_VAL_TBL       QP_PRICE_LIST_PUB.PRICING_ATTR_VAL_TBL_TYPE       :=  QP_PRICE_LIST_PUB.G_MISS_PRICING_ATTR_VAL_TBL;

   lc_pricelistname               usbpcs_pricelist_cleaned.pricelistname%TYPE       :='+=9=+';
   lc_sta_dte_act                 usbpcs_pricelist_cleaned.oraclecharfld4%TYPE ;
   lc_end_dte_act                 usbpcs_pricelist_cleaned.oraclecharfld5%TYPE ;
   ld_end_date_active             DATE;
   lc_data                        VARCHAR2(2000);
   ln_count                       NUMBER  ;
   lc_status                      VARCHAR2(1000);
   ln_loop_cnt                    NUMBER := 0;
   ln_dummy_cnt                   NUMBER := 0;
   ln_api_version_number          NUMBER:=1;
   ln_rec_fetched                 NUMBER:=0;
   ln_rec_processed               NUMBER:=0;
   ln_rec_errored                 NUMBER:=0;
   ln_commit_point                NUMBER:=0;
   ln_line_index                  NUMBER:=0;
   lc_api_err_flag                VARCHAR2(1):='N';
   lc_max_err_flag                VARCHAR2(1):='N';
   lc_api_mst_err_flag            VARCHAR2(1):='N';
   ln_price_lines_cnt             NUMBER:=0;
   ln_tot_price_lines             NUMBER:=0;
   lc_debug_file                  VARCHAR2(200);
   ln_list_header_id              NUMBER;
   ln_item_id                     NUMBER:=9999999;
   lc_item_porcess_mode           VARCHAR2(1);
   ln_list_line_id                NUMBER;
   ln_pricing_attribute_id        NUMBER;

   --Cursot to get all the price list from the staging table
   CURSOR lcu_get_price_list
   IS
   SELECT *
   FROM   usbpcs_pricelist_cleaned UPC
   --Start of changes V1.2
   WHERE  UPC.OracleGenUse2=gc_operating_unit_name
   AND UPC.oraclecharfld1 ='VS'
   --and itemnumber='TEST2'
   --End of changes V1.2
   ORDER  BY UPC.pricelistname,itemnumber;

   --Cursor to get the count of lines for the pricelist
   CURSOR lcu_get_prc_lines_cnt (p_pricelist VARCHAR2)
   IS               --Start of changes V1.3,1.7
   SELECT count(1),MIN(to_date(oraclecharfld4,'DD-MON-RRRR')),MAX(to_date(oraclecharfld5,'DD-MON-RRRR'))
                   --End of changes V1.3,1.7
   FROM   usbpcs_pricelist_cleaned UPC
   WHERE  UPC.pricelistname=p_pricelist;

   --Cursor to get total count of records
   CURSOR lcu_get_rec_count
   IS
   SELECT  count(1)
   FROM    usbpcs_pricelist_cleaned UPC
   --Start of changes V1.2
   WHERE   UPC.OracleGenUse2=gc_operating_unit_name;
   --End of changes V1.2;

   --Cursor to get total count of records processed
   CURSOR lcu_get_rec_prc_count
   IS
   SELECT count(1)
   FROM   usbpcs_pricelist_cleaned UPC
   WHERE  UPC.oraclecharfld1='PS'
    --Start of changes V1.2
   AND    UPC.OracleGenUse2=gc_operating_unit_name;
    --End of changes V1.2

  --Cursor to get total count of records errored
  CURSOR lcu_get_rec_err_count
  IS
  SELECT count(1)
  FROM   usbpcs_pricelist_cleaned UPC
  WHERE  UPC.oraclecharfld1='PE'
  AND    UPC.OracleGenUse2=gc_operating_unit_name;





   --------------------------------------------------
   --Cursor to check if price list is already defined
   --------------------------------------------------
   CURSOR lcu_chk_price_list(p_price_list VARCHAR2)
   IS
   SELECT list_header_id
   FROM   qp_list_headers_tl QLHT
   WHERE  QLHT.name=p_price_list;




   CURSOR lcu_chk_price_list_lines(p_header_id NUMBER,p_item_id NUMBER)
   IS
   SELECT    A.list_line_id,b.pricing_attribute_id
   FROM    qp_list_lines A
         , qp_pricing_attributes B
   WHERE A.list_line_id=B.list_line_id
   AND A.list_header_id=p_header_id
   AND product_attr_value=p_item_id
   AND NVL(TRUNC(start_date_active),SYSDATE) IN (
				      SELECT     NVL( MAX(TRUNC( START_DATE_ACTIVE)),SYSDATE)
				      FROM    qp_list_lines A
					    , qp_pricing_attributes B
				      WHERE A.list_line_id=B.list_line_id
				      AND A.list_header_id=p_header_id
				      AND product_attr_value=p_item_id );



BEGIN
   gc_log_msg:='*************START OF PROCESS PROCEDURE*************';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   FOR lcu_get_price_list_rec IN lcu_get_price_list
   LOOP
      gc_record_number       :=lcu_get_price_list_rec.oracleidentifier;
      gc_record_identifier   :='Price List name :'||lcu_get_price_list_rec.pricelistname||' - Item number :'||lcu_get_price_list_rec.itemnumber;

      --Re Initialise variables
      lc_api_err_flag:='N';
      --lc_max_err_flag:='N';
      --Start od changes V1.4
      -------------------------------
      --Check if the Price list exist
      -------------------------------
      	OPEN  lcu_chk_price_list(lcu_get_price_list_rec.pricelistname);
      	FETCH lcu_chk_price_list INTO ln_list_header_id;
      	   ---------------------------------------------------- IF PRICELIST  FOUND IN ORACLE-----------------------------------------------------------------


      	   IF lcu_chk_price_list%FOUND THEN

      	   lc_price_list_rec                 :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_REC;
	   lc_price_list_line_tbl            :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_TBL;
	   lc_pricing_attr_tbl               :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_TBL;

      	      -----------------------------------
      	      --Check if line with the item exist
      	      -----------------------------------
      	          ln_list_line_id:=NULL;
      	          ln_pricing_attribute_id:=NULL;

      	          OPEN lcu_chk_price_list_lines(ln_list_header_id,lcu_get_price_list_rec.oracleintfld2);
      	          FETCH lcu_chk_price_list_lines INTO ln_list_line_id ,ln_pricing_attribute_id;
      	             IF lcu_chk_price_list_lines%NOTFOUND THEN
      	                lc_item_porcess_mode:='C'; --Create Lines
      	             ELSE
      	                lc_item_porcess_mode:='U'; --Update Lines
      	             END IF;
      	   	  CLOSE lcu_chk_price_list_lines;
      	           ----------------------------------------
      	   	   -- Update Price list headers information
      	   	   ----------------------------------------
      	   	   lc_price_list_rec.list_header_id     := ln_list_header_id;
      	   	   --lc_price_list_rec.created_by         := fnd_global.user_id;
      	   	   --lc_price_list_rec.creation_date      := SYSDATE;
      	   	   --lc_price_list_rec.currency_code      := lcu_get_price_list_rec.currencycode;
      	   	   --lc_price_list_rec.last_updated_by    := fnd_global.user_id;
      	   	   -- lc_price_list_rec.last_update_date   := SYSDATE;
      	   	   -- lc_price_list_rec.last_update_login  := fnd_global.user_id;
      	   	   -- lc_price_list_rec.List_type_code     := gc_list_type_code;
      	   	   -- lc_price_list_rec.rounding_factor    := -2;
      	   	   lc_price_list_rec.operation          := QP_GLOBALS.G_OPR_UPDATE;
      	   	   lc_price_list_rec.name               := lcu_get_price_list_rec.pricelistname;


      	   	   ln_line_index:=1;
      	   	   --fnd_file.put_line(fnd_file.log,'***MODE ***               :    ' ||lc_item_porcess_mode);
      	   	  -- fnd_file.put_line(fnd_file.log,'***ln_line_index ***               :    ' ||ln_line_index);
      	   	   IF  lc_item_porcess_mode='C' THEN


      	   	      --lc_price_list_rec.version_no         :=1;
      	   	       ------------------------------------
      	   	       --Assign price list Line information
      	   	       ------------------------------------
      	   	       lc_price_list_line_tbl(ln_line_index).list_header_id            := ln_list_header_id;
      	   	       lc_price_list_line_tbl(ln_line_index).Arithmetic_operator       := lcu_get_price_list_rec.oraclecharfld3;
      	   	       lc_price_list_line_tbl(ln_line_index).created_by                := fnd_global.user_id;
      	   	       lc_price_list_line_tbl(ln_line_index).creation_date             := SYSDATE;
      	   	       lc_price_list_line_tbl(ln_line_index).last_updated_by           := fnd_global.user_id;
      	   	       lc_price_list_line_tbl(ln_line_index).last_update_date          := SYSDATE;
      	   	       lc_price_list_line_tbl(ln_line_index).last_update_login         := fnd_global.user_id;
      	   	       lc_price_list_line_tbl(ln_line_index).list_line_id              := FND_API.G_MISS_NUM;
      	   	       lc_price_list_line_tbl(ln_line_index).list_line_type_code       := gc_line_type_code;
      	   	       lc_price_list_line_tbl(ln_line_index).operation                 := QP_GLOBALS.G_OPR_CREATE;
      	   	       lc_price_list_line_tbl(ln_line_index).product_precedence        := 220;
      	   	       lc_price_list_line_tbl(ln_line_index).start_date_active         := lcu_get_price_list_rec.oraclecharfld4; --TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD');
      	   	       lc_price_list_line_tbl(ln_line_index).Operand                   := lcu_get_price_list_rec.SellPrice;
      	   	       lc_price_list_line_tbl(ln_line_index).end_date_active           := lcu_get_price_list_rec.oraclecharfld5; --ld_end_date_active;


      	   	       ------------------------------------
      	   	       --Assign price attribute information
      	   	       ------------------------------------
      	   	       lc_pricing_attr_tbl(ln_line_index).list_header_id            := ln_list_header_id;
      	   	       lc_pricing_attr_tbl(ln_line_index).attribute_grouping_no      := 1;
      	   	       lc_pricing_attr_tbl(ln_line_index).created_by                 := fnd_global.user_id;
      	   	       lc_pricing_attr_tbl(ln_line_index).creation_date              := SYSDATE;
      	   	       lc_pricing_attr_tbl(ln_line_index).excluder_flag              := 'N';
      	   	       lc_pricing_attr_tbl(ln_line_index).last_updated_by            := fnd_global.user_id;
      	   	       lc_pricing_attr_tbl(ln_line_index).last_update_date           := SYSDATE;
      	   	       lc_pricing_attr_tbl(ln_line_index).last_update_login          := fnd_global.user_id;
      	   	       lc_pricing_attr_tbl(ln_line_index).List_line_id               := FND_API.G_MISS_NUM;
      	   	       lc_pricing_attr_tbl(ln_line_index).pricing_attribute_id       := FND_API.G_MISS_NUM;
      	   	       lc_pricing_attr_tbl(ln_line_index).product_attribute          := gc_prc_attribute;
      	   	       lc_pricing_attr_tbl(ln_line_index).product_attribute_context  := gc_prc_context_code;
      	   	       lc_pricing_attr_tbl(ln_line_index).product_attr_value         := lcu_get_price_list_rec.oracleintfld2;
      	   	       lc_pricing_attr_tbl(ln_line_index).product_uom_code           := lcu_get_price_list_rec.oraclecharfld2;
      	   	       lc_pricing_attr_tbl(ln_line_index).price_list_line_index      := ln_line_index;
      	   	       lc_pricing_attr_tbl(ln_line_index).operation                  := Qp_Globals.G_OPR_CREATE;











      	   	  ELSE --UPDATE THE RECORDS
      	   	       --lc_price_list_rec.version_no         :=1;
      	   	       ------------------------------------
      	   	       --Assign price list Line information
      	   	       ------------------------------------
      	   	       lc_price_list_line_tbl(ln_line_index).Arithmetic_operator       := lcu_get_price_list_rec.oraclecharfld3;
      	   	       lc_price_list_line_tbl(ln_line_index).created_by                := fnd_global.user_id;
      	   	       lc_price_list_line_tbl(ln_line_index).creation_date             := SYSDATE;
      	   	       lc_price_list_line_tbl(ln_line_index).last_updated_by           := fnd_global.user_id;
      	   	       lc_price_list_line_tbl(ln_line_index).last_update_date          := SYSDATE;
      	   	       lc_price_list_line_tbl(ln_line_index).last_update_login         := fnd_global.user_id;
      	   	       lc_price_list_line_tbl(ln_line_index).list_line_id              := ln_list_line_id; --FND_API.G_MISS_NUM;
      	   	       lc_price_list_line_tbl(ln_line_index).list_line_type_code       := gc_line_type_code;
      	   	       lc_price_list_line_tbl(ln_line_index).operation                 := QP_GLOBALS.G_OPR_UPDATE;
      	   	       lc_price_list_line_tbl(ln_line_index).product_precedence        := 220;
      	   	       lc_price_list_line_tbl(ln_line_index).start_date_active         := lcu_get_price_list_rec.oraclecharfld4; --TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD');
      	   	       lc_price_list_line_tbl(ln_line_index).Operand                   := lcu_get_price_list_rec.SellPrice;
      	   	       lc_price_list_line_tbl(ln_line_index).end_date_active           := lcu_get_price_list_rec.oraclecharfld5; --ld_end_date_active;


      	   	       ------------------------------------
      	   	       --Assign price attribute information
      	   	       ------------------------------------
      	   	       lc_pricing_attr_tbl(ln_line_index).attribute_grouping_no      := 1;
      	   	       lc_pricing_attr_tbl(ln_line_index).created_by                 := fnd_global.user_id;
      	   	       lc_pricing_attr_tbl(ln_line_index).creation_date              := SYSDATE;
      	   	       lc_pricing_attr_tbl(ln_line_index).excluder_flag              := 'N';
      	   	       lc_pricing_attr_tbl(ln_line_index).last_updated_by            := fnd_global.user_id;
      	   	       lc_pricing_attr_tbl(ln_line_index).last_update_date           := SYSDATE;
      	   	       lc_pricing_attr_tbl(ln_line_index).last_update_login          := fnd_global.user_id;
      	   	       lc_pricing_attr_tbl(ln_line_index).List_line_id               := ln_list_line_id; --FND_API.G_MISS_NUM;
      	   	       lc_pricing_attr_tbl(ln_line_index).pricing_attribute_id       := ln_pricing_attribute_id; --FND_API.G_MISS_NUM;
      	   	       lc_pricing_attr_tbl(ln_line_index).product_attribute          := gc_prc_attribute;
      	   	       lc_pricing_attr_tbl(ln_line_index).product_attribute_context  := gc_prc_context_code;
      	   	       --lc_pricing_attr_tbl(ln_line_index).product_attr_value         := lcu_get_price_list_rec.oracleintfld2;
      	   	      -- lc_pricing_attr_tbl(ln_line_index).product_uom_code           := lcu_get_price_list_rec.oraclecharfld2;
      	   	       lc_pricing_attr_tbl(ln_line_index).price_list_line_index      := ln_line_index;
      	   	       lc_pricing_attr_tbl(ln_line_index).operation                  := Qp_Globals.G_OPR_UPDATE;


      	   	   END IF; --End if of lc_item_porcess_mode='C

      	   	   -- fnd_file.put_line(fnd_file.log,'item id                :    ' ||lcu_get_price_list_rec.oracleintfld2);

      	   	   BEGIN
      	   	           --Call the standard API
      	   	           fnd_msg_pub.initialize;
      	   	           lc_debug_file := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
      	   	           oe_debug_pub.initialize;
      	   	           oe_debug_pub.setdebuglevel(5);
      	   	           Oe_Msg_Pub.initialize;

/*      	   	           QP_Price_List_PUB.Process_Price_List
      	   	                                               ( p_api_version_number            => 1.0
      	   	                                                ,p_init_msg_list                 => FND_API.G_FALSE
      	   	                                                ,p_return_values                 => FND_API.G_FALSE
      	   	                                                ,p_commit                        => FND_API.G_FALSE
      	   	                                                ,x_return_status                 => lc_status
      	   	                                                ,x_msg_count                     => ln_count
      	   	                                                ,x_msg_data                      => lc_data
      	   	                                                ,p_price_list_rec                => lc_price_list_rec
      	   	                                                ,p_price_list_val_rec            => lc_price_list_val_rec
      	   	                                                ,p_price_list_line_tbl           => lc_price_list_line_tbl
      	   	                                                ,p_price_list_line_val_tbl       => lc_price_list_line_val_tbl
      	   	                                                ,p_qualifiers_tbl                => lc_qualifiers_tbl
      	   	                                                ,p_qualifiers_val_tbl            => lc_qualifiers_val_tbl
      	   	                                                ,p_pricing_attr_tbl              => lc_pricing_attr_tbl
      	   	                                                ,p_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
      	   	                                                ,x_price_list_rec                => lc_price_list_rec
      	   	                                                ,x_price_list_val_rec            => lc_price_list_val_rec
      	   	                                                ,x_price_list_line_tbl           => lc_price_list_line_tbl
      	   	                                                ,x_price_list_line_val_tbl       => lc_price_list_line_val_tbl
      	   	                                                ,x_qualifiers_tbl                => lc_qualifiers_tbl
      	   	                                                ,x_qualifiers_val_tbl            => lc_qualifiers_val_tbl
      	   	                                                ,x_pricing_attr_tbl              => lc_pricing_attr_tbl
      	   	                                                ,x_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
      	   	                                               );
*/

-- R12 Mods
      	   	           QP_Price_List_PUB.Process_Price_List(
      	   	                                                p_api_version_number      => 1.0
      	   	                                              , p_init_msg_list           => FND_API.G_FALSE
      	   	                                              , p_return_values           => FND_API.G_FALSE
      	   	                                              , p_commit                  => FND_API.G_FALSE
      	   	                                              , x_return_status           => lc_status
      	   	                                              , x_msg_count               => ln_count
      	   	                                              , x_msg_data                => lc_data
      	   	                                              , p_price_list_rec          => lc_price_list_rec
      	   	                                              , p_price_list_val_rec      => lc_price_list_val_rec
      	   	                                              , p_price_list_line_tbl     => lc_price_list_line_tbl
      	   	                                              , p_price_list_line_val_tbl => lc_price_list_line_val_tbl
      	   	                                              , p_qualifiers_tbl          => lc_qualifiers_tbl
      	   	                                              , p_qualifiers_val_tbl      => lc_qualifiers_val_tbl
      	   	                                              , p_pricing_attr_tbl        => lc_pricing_attr_tbl
      	   	                                              , p_pricing_attr_val_tbl    => lc_pricing_attr_val_tbl
      	   	                                              , x_price_list_rec          => XLC_price_list_rec
      	   	                                              , x_price_list_val_rec      => XLC_price_list_val_rec
      	   	                                              , x_price_list_line_tbl     => XLC_price_list_line_tbl
      	   	                                              , x_price_list_line_val_tbl => XLC_price_list_line_val_tbl
      	   	                                              , x_qualifiers_tbl          => XLC_qualifiers_tbl
      	   	                                              , x_qualifiers_val_tbl      => XLC_qualifiers_val_tbl
      	   	                                              , x_pricing_attr_tbl        => XLC_pricing_attr_tbl
      	   	                                              , X_PRICING_ATTR_VAL_TBL    => XLC_PRICING_ATTR_VAL_TBL
                                                             );

      	   	           gc_log_msg:='Status returned by the API :'||lc_status;
      	   	           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      	   	           IF (lc_status <> FND_API.G_RET_STS_SUCCESS) THEN
      	   	          --   fnd_file.put_line(fnd_file.log,'***ERRMITMM ***               :    ' ||lcu_get_price_list_rec.oracleintfld2);
      	   	              lc_api_err_flag:='Y';
      	   	              lc_api_mst_err_flag:='Y';
      	   	              RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
      	   	           END IF;
      	   	        EXCEPTION
      	   	        WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
      	   	           FOR I IN 1 .. ln_count
      	   	           LOOP
      	   	              lc_data := oe_msg_pub.get( p_msg_index => 1
      	   	                                        ,p_encoded   => 'F'
      	   	                                       );
      	   	           END LOOP;
      	   	           --Log error
      	   	           gc_error_code       :='API';
      	   	           gc_error_msg        :=lc_data;
      	   	           gc_comments         :=NULL;
      	   	           INSERT_ERROR_MSG;
      	   	        WHEN OTHERS THEN
      	   	           --Log error
      	   	           FND_FILE.PUT_LINE(FND_FILE.LOG,'Unexpected error encountered when calling the API '||SQLERRM);
      	   	           RAISE;
      	   	        END;
      	   	        --Any error by API,update the status of the reocrds
      	   	        IF (lc_api_err_flag<>'N') OR (lc_max_err_flag <>'N') THEN
      	   	            lc_max_err_flag:='N';
      	   	           --Call the update procedure for updae the rrecord status which will run as a Autonomous transaction
      	   	           update_record_status(p_pricelist_name => lcu_get_price_list_rec.pricelistname
      	   	                               ,p_status_flag    =>'PE'
      	   	                               );
      	   	        ELSE
      	   	           update_record_status(p_pricelist_name => lcu_get_price_list_rec.pricelistname
      	   	                               ,p_status_flag    =>'PS'
      	   	                               );

      	   	        END IF;
      	   	 -- END IF; --IF  lc_item_porcess_mode='C' THEN



      	   --End od changes V1.4
      	   ELSE ---------------------------------------------------- IF PRICELIST NOT FOUND IN ORACLE-----------------------------------------------------------------

	      IF (lc_pricelistname<>lcu_get_price_list_rec.pricelistname) THEN
		 lc_pricelistname:= lcu_get_price_list_rec.pricelistname;
		 ln_line_index:=0;
		 lc_price_list_rec                 :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_REC;
		 lc_price_list_line_tbl            :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_TBL;
		 lc_pricing_attr_tbl               :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_TBL;

		 -----------------------------------------
		 --Get the count of line for the pricelist
		 --Get MIN of start date and MAX of End date
		 -----------------------------------------
		 OPEN lcu_get_prc_lines_cnt(lcu_get_price_list_rec.pricelistname);
								     --Start of changes V1.3
		 FETCH lcu_get_prc_lines_cnt INTO ln_tot_price_lines,lc_sta_dte_act,lc_end_dte_act;
								     --End of changes   V1.3
		 CLOSE lcu_get_prc_lines_cnt;

		 --Start of changes V1.3
		 --Start of changes V1.6
		 -- IF lc_sta_dte_act IS NULL OR  lc_end_dte_act IS NULL THEN
		    IF lc_sta_dte_act IS NULL THEN
		 ---End of changes V1.6
		     lc_max_err_flag:='Y';
		     lc_api_mst_err_flag:='Y';
		     gc_error_code       :='API';
		     gc_error_msg        :='MIN of Startdate is holding null for the Pricelistname'||lcu_get_price_list_rec.pricelistname;
		     gc_comments         :=NULL;
		     INSERT_ERROR_MSG;

		 END IF	;

		 --Start of changes V1.6
		 IF lcu_get_price_list_rec.contracttype IN ('SA','IC') THEN
		    lc_end_dte_act:=NULL;
		 ELSE
		    IF lc_end_dte_act IS NULL THEN
		       lc_max_err_flag:='Y';
		       lc_api_mst_err_flag:='Y';
		       gc_error_code       :='API';
		       gc_error_msg        :='MAX of Enddate is holding null for the Pricelistname'||lcu_get_price_list_rec.pricelistname;
		       gc_comments         :=NULL;
		       INSERT_ERROR_MSG;
		    END IF;
		 END IF;
		  ---End of changes V1.6






		 ----------------------------------------
		 -- Assign Price list headers information
		 ----------------------------------------
		 lc_price_list_rec.list_header_id     := FND_API.G_MISS_NUM;
		 lc_price_list_rec.created_by         := fnd_global.user_id;
		 lc_price_list_rec.creation_date      := SYSDATE;
		 lc_price_list_rec.currency_code      := lcu_get_price_list_rec.currencycode;
		 lc_price_list_rec.last_updated_by    := fnd_global.user_id;
		 lc_price_list_rec.last_update_date   := SYSDATE;
		 lc_price_list_rec.last_update_login  := fnd_global.user_id;
		 lc_price_list_rec.List_type_code     := gc_list_type_code;
-- 		 lc_price_list_rec.rounding_factor    := -2;                -- jul-20-07 pr
		 lc_price_list_rec.operation          := QP_GLOBALS.G_OPR_CREATE;
		 lc_price_list_rec.name               := lcu_get_price_list_rec.pricelistname;
		 --Start of changes V1.8
		 lc_price_list_rec.description        := lcu_get_price_list_rec.pricelistname;
		 --End of changes V1.8
		 lc_price_list_rec.version_no         :=1;
							 --Start of changes V1.3
		 lc_price_list_rec.start_date_active  := lc_sta_dte_act ; --NULL;
		 lc_price_list_rec.end_date_active    := lc_end_dte_act ; --NULL;
							 --End of changes   V1.3


                ------------------------------------------------------
                -- Japan setups require rounding to be zero
                -- Modified jul-20-07
                -- Modified Aug 20-07
                -- used currencycode to determine rounding factor
                ------------------------------------------------------

--                   IF gc_operating_unit_name = 'Haemonetics Japan K.K. JP OU'
                  IF lcu_get_price_list_rec.currencycode = 'JPY'    -- aug-20-07
                  THEN
 		   lc_price_list_rec.rounding_factor    := 0;     -- jul-20-07 pr
                  ELSE
 		   lc_price_list_rec.rounding_factor    := -2;   -- jul-20-07 pr
                  END IF;




	      END IF; --IF lc_pricelistname<>lcu_get_price_list_rec.pricel

	      --Index increment for lines
	      ln_line_index:=ln_line_index+1;

	      ------------------------------------
	      --Assign price list Line information
	      ------------------------------------
	      lc_price_list_line_tbl(ln_line_index).Arithmetic_operator       := lcu_get_price_list_rec.oraclecharfld3;
	      lc_price_list_line_tbl(ln_line_index).created_by                := fnd_global.user_id;
	      lc_price_list_line_tbl(ln_line_index).creation_date             := SYSDATE;
	      lc_price_list_line_tbl(ln_line_index).last_updated_by           := fnd_global.user_id;
	      lc_price_list_line_tbl(ln_line_index).last_update_date          := SYSDATE;
	      lc_price_list_line_tbl(ln_line_index).last_update_login         := fnd_global.user_id;
	      lc_price_list_line_tbl(ln_line_index).list_line_id              := FND_API.G_MISS_NUM;
	      lc_price_list_line_tbl(ln_line_index).list_line_type_code       := gc_line_type_code;
	      lc_price_list_line_tbl(ln_line_index).operation                 := QP_GLOBALS.G_OPR_CREATE;
	      lc_price_list_line_tbl(ln_line_index).product_precedence        := 220;
	      lc_price_list_line_tbl(ln_line_index).start_date_active         := lcu_get_price_list_rec.oraclecharfld4; --TO_DATE(lcu_get_price_list_rec.startdate,'YYYY-MM-DD');
	      lc_price_list_line_tbl(ln_line_index).Operand                   := lcu_get_price_list_rec.SellPrice;
	      lc_price_list_line_tbl(ln_line_index).end_date_active           := lcu_get_price_list_rec.oraclecharfld5; --ld_end_date_active;
	      --Start of Changes V1.6
	      lc_price_list_line_tbl(ln_line_index).primary_uom_flag           := 'Y'; --lcu_get_price_list_rec.oraclecharfld5; --ld_end_date_active;
	      --End of Changes V1.6


	      ------------------------------------
	      --Assign price attribute information
	      ------------------------------------
	      lc_pricing_attr_tbl(ln_line_index).attribute_grouping_no      := 1;
	      lc_pricing_attr_tbl(ln_line_index).created_by                 := fnd_global.user_id;
	      lc_pricing_attr_tbl(ln_line_index).creation_date              := SYSDATE;
	      lc_pricing_attr_tbl(ln_line_index).excluder_flag              := 'N';
	      lc_pricing_attr_tbl(ln_line_index).last_updated_by            := fnd_global.user_id;
	      lc_pricing_attr_tbl(ln_line_index).last_update_date           := SYSDATE;
	      lc_pricing_attr_tbl(ln_line_index).last_update_login          := fnd_global.user_id;
	      lc_pricing_attr_tbl(ln_line_index).List_line_id               := FND_API.G_MISS_NUM;
	      lc_pricing_attr_tbl(ln_line_index).pricing_attribute_id       := FND_API.G_MISS_NUM;
	      lc_pricing_attr_tbl(ln_line_index).product_attribute          := gc_prc_attribute;
	      lc_pricing_attr_tbl(ln_line_index).product_attribute_context  := gc_prc_context_code;
	      lc_pricing_attr_tbl(ln_line_index).product_attr_value         := lcu_get_price_list_rec.oracleintfld2;
	      lc_pricing_attr_tbl(ln_line_index).product_uom_code           := lcu_get_price_list_rec.oraclecharfld2;
	      lc_pricing_attr_tbl(ln_line_index).price_list_line_index      := ln_line_index;
	      lc_pricing_attr_tbl(ln_line_index).operation                  := Qp_Globals.G_OPR_CREATE;

	      --If the line increment count matched witht the no of lines
	      --attached to the current price list then call the API
	      IF (ln_tot_price_lines = ln_line_index) THEN
		 ln_tot_price_lines:=0;
		 --ln_price_lines_cnt:=0;
		 BEGIN
		    --Call the standard API
		    fnd_msg_pub.initialize;
		    lc_debug_file := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
		    oe_debug_pub.initialize;
		    oe_debug_pub.setdebuglevel(5);
		    Oe_Msg_Pub.initialize;

/*		    QP_Price_List_PUB.Process_Price_List
							( p_api_version_number            => 1.0
							 ,p_init_msg_list                 => FND_API.G_FALSE
							 ,p_return_values                 => FND_API.G_FALSE
							 ,p_commit                        => FND_API.G_FALSE
							 ,x_return_status                 => lc_status
							 ,x_msg_count                     => ln_count
							 ,x_msg_data                      => lc_data
							 ,p_price_list_rec                => lc_price_list_rec
							 ,p_price_list_val_rec            => lc_price_list_val_rec
							 ,p_price_list_line_tbl           => lc_price_list_line_tbl
							 ,p_price_list_line_val_tbl       => lc_price_list_line_val_tbl
							 ,p_qualifiers_tbl                => lc_qualifiers_tbl
							 ,p_qualifiers_val_tbl            => lc_qualifiers_val_tbl
							 ,p_pricing_attr_tbl              => lc_pricing_attr_tbl
							 ,p_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
							 ,x_price_list_rec                => lc_price_list_rec
							 ,x_price_list_val_rec            => lc_price_list_val_rec
							 ,x_price_list_line_tbl           => lc_price_list_line_tbl
							 ,x_price_list_line_val_tbl       => lc_price_list_line_val_tbl
							 ,x_qualifiers_tbl                => lc_qualifiers_tbl
							 ,x_qualifiers_val_tbl            => lc_qualifiers_val_tbl
							 ,x_pricing_attr_tbl              => lc_pricing_attr_tbl
							 ,x_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
							);
*/

-- R12 Mods
		    QP_Price_List_PUB.Process_Price_List(
		      p_api_version_number      => 1.0
		    , p_init_msg_list           => FND_API.G_FALSE
		    , p_return_values           => FND_API.G_FALSE
		    , p_commit                  => FND_API.G_FALSE
		    , x_return_status           => lc_status
		    , x_msg_count               => ln_count
		    , x_msg_data                => lc_data
		    , p_price_list_rec          => lc_price_list_rec
		    , p_price_list_val_rec      => lc_price_list_val_rec
		    , p_price_list_line_tbl     => lc_price_list_line_tbl
		    , p_price_list_line_val_tbl => lc_price_list_line_val_tbl
		    , p_qualifiers_tbl          => lc_qualifiers_tbl
		    , p_qualifiers_val_tbl      => lc_qualifiers_val_tbl
		    , p_pricing_attr_tbl        => lc_pricing_attr_tbl
		    , p_pricing_attr_val_tbl    => lc_pricing_attr_val_tbl
		    , x_price_list_rec          => XLC_price_list_rec
		    , x_price_list_val_rec      => XLC_price_list_val_rec
		    , x_price_list_line_tbl     => XLC_price_list_line_tbl
		    , x_price_list_line_val_tbl => XLC_price_list_line_val_tbl
		    , x_qualifiers_tbl          => XLC_qualifiers_tbl
		    , x_qualifiers_val_tbl      => XLC_qualifiers_val_tbl
		    , x_pricing_attr_tbl        => XLC_pricing_attr_tbl
		    , X_PRICING_ATTR_VAL_TBL    => XLC_PRICING_ATTR_VAL_TBL
		    );

		    gc_log_msg:='Status returned by the API :'||lc_status;
		    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
		    IF (lc_status <> FND_API.G_RET_STS_SUCCESS) THEN
		       lc_api_err_flag:='Y';
		       lc_api_mst_err_flag:='Y';
		       RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
		    END IF;
		 EXCEPTION
		 WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
		    FOR I IN 1 .. ln_count
		    LOOP
		       lc_data := oe_msg_pub.get( p_msg_index => 1
						 ,p_encoded   => 'F'
						);
		    END LOOP;
		    --Log error
		    gc_error_code       :='API';
		    gc_error_msg        :=lc_data;
		    gc_comments         :=NULL;
		    INSERT_ERROR_MSG;
		 WHEN OTHERS THEN
		    --Log error
		    FND_FILE.PUT_LINE(FND_FILE.LOG,'Unexpected error encountered when calling the API '||SQLERRM);
		    RAISE;
		 END;
		 --Any error by API,update the status of the reocrds
		 IF (lc_api_err_flag<>'N') OR (lc_max_err_flag <>'N') THEN
		     lc_max_err_flag:='N';
		    --Call the update procedure for updae the rrecord status which will run as a Autonomous transaction
		    update_record_status(p_pricelist_name => lcu_get_price_list_rec.pricelistname
					,p_status_flag    =>'PE'
					);
		 ELSE
		    update_record_status(p_pricelist_name => lcu_get_price_list_rec.pricelistname
					,p_status_flag    =>'PS'
					);

		 END IF;
		 --Commit after every 100 records
		 /*IF ln_commit_point=100 THEN
		 ln_commit_point:=0;
		 COMMIT;
		 END IF;*/
	      END IF; -- ln_tot_price_lines = ln_price_lines_cnt
	   END IF; -- lcu_chk_price_list%FOUND THEN
	CLOSE lcu_chk_price_list ; --
   END LOOP;-- End of main loop
   --COMMIT;

   --Get the total no of records
   OPEN  lcu_get_rec_count;
   FETCH lcu_get_rec_count INTO ln_rec_fetched;
   CLOSE lcu_get_rec_count;

   --Get total no of records processed
   OPEN  lcu_get_rec_prc_count;
   FETCH lcu_get_rec_prc_count INTO ln_rec_processed;
   CLOSE lcu_get_rec_prc_count;


   --Get total no of records errored
   OPEN  lcu_get_rec_err_count;
   FETCH lcu_get_rec_err_count INTO ln_rec_errored;
   CLOSE lcu_get_rec_err_count;


   --Summary information of Records Processed
   --===============================================
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Summary information of Records processed ');
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
   fnd_file.put_line(fnd_file.log,'Total Records Processed             :    ' ||ln_rec_processed);
   fnd_file.put_line(fnd_file.log,'Total Records Errored/Warning       :    ' ||ln_rec_errored);

   --Call the error report if any errors
   IF (lc_api_mst_err_flag <>'N') THEN
      --xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);
      x_retcode:=1;
      ROLLBACK;
   ELSE
     COMMIT;
   END IF;

EXCEPTION
WHEN OTHERS THEN
   ROLLBACK;
   gc_error_code       :='API';
   gc_error_msg        :='Unexpected error encountered in procedure process_price_lists '||SQLERRM;
   gc_comments         :=NULL;
   INSERT_ERROR_MSG;
   x_retcode:=2;
END PROCESS_PRICE_LISTS;

--Start of changes V1.9
-- +===================================================================+
-- | Name            : PROCESS_SECONDARY_PRICE_LISTS                   |
-- | Description     : Procedure to import Secondary price list into   |
-- |                   oracle base  tables                             |
-- |                                                                   |
-- |                                                                   |
-- | Parameters      : NONE                                            |
-- |                                                                   |
-- |                                                                   |
-- | Returns         : NONE                                            |
-- |                                                                   |
-- +===================================================================+
PROCEDURE PROCESS_SECONDARY_PRICE_LISTS (
                                            x_errbuf       OUT VARCHAR2
                                 	    ,x_retcode      OUT VARCHAR2
                                             ,p_debug         IN VARCHAR2
                                          )
IS
   lc_price_list_rec              QP_Price_List_PUB.Price_List_Rec_Type             :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_REC;
   lc_price_list_val_rec          QP_Price_List_PUB.Price_List_Val_Rec_Type         :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_VAL_REC;
   lc_price_list_line_tbl         QP_Price_List_PUB.Price_List_Line_Tbl_Type        :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_TBL;
   lc_price_list_line_val_tbl     QP_Price_List_PUB.Price_List_Line_Val_Tbl_Type    :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_LINE_VAL_TBL;
   lc_qualifiers_tbl              Qp_Qualifier_Rules_Pub.Qualifiers_Tbl_Type        :=  Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_TBL;
   lc_qualifiers_val_tbl          Qp_Qualifier_Rules_Pub.Qualifiers_Val_Tbl_Type    :=  Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_VAL_TBL;
   lc_pricing_attr_tbl            QP_Price_List_PUB.Pricing_Attr_Tbl_Type           :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_TBL;
   lc_pricing_attr_val_tbl        QP_Price_List_PUB.Pricing_Attr_Val_Tbl_Type       :=  QP_Price_List_PUB.G_MISS_PRICING_ATTR_VAL_TBL;
   lc_pricelistname               usbpcs_pricelist_cleaned.pricelistname%TYPE       :='+=9=+';
   lc_sta_dte_act                 usbpcs_pricelist_cleaned.oraclecharfld4%TYPE ;
   lc_end_dte_act                 usbpcs_pricelist_cleaned.oraclecharfld5%TYPE ;
   ld_end_date_active             DATE;
   lc_data                        VARCHAR2(2000);
   ln_count                       NUMBER  ;
   lc_status                      VARCHAR2(1000);
   ln_loop_cnt                    NUMBER := 0;
   ln_dummy_cnt                   NUMBER := 0;
   ln_api_version_number          NUMBER:=1;
   ln_rec_fetched                 NUMBER:=0;
   ln_rec_processed               NUMBER:=0;
   ln_rec_errored                 NUMBER:=0;
   ln_commit_point                NUMBER:=0;
   ln_line_index                  NUMBER:=0;
   lc_api_err_flag                VARCHAR2(1):='N';
   lc_max_err_flag                VARCHAR2(1):='N';
   lc_api_mst_err_flag            VARCHAR2(1):='N';
   ln_price_lines_cnt             NUMBER:=0;
   ln_tot_price_lines             NUMBER:=0;
   lc_debug_file                  VARCHAR2(200);
   ln_list_header_id              NUMBER;
   ln_item_id                     NUMBER:=9999999;
   lc_item_porcess_mode           VARCHAR2(1);
   ln_list_line_id                NUMBER;
   ln_pricing_attribute_id        NUMBER;
   ln_pri_list_header_id          NUMBER;
   ln_sec_list_header_id          NUMBER;
   lc_primary_prc_name            VARCHAR2(100):='=9=9=';
   lc_pri_currency_code           VARCHAR2(100);
   lc_sec_currency_code           VARCHAR2(100);


   --------------------------------------------------------
   --Cursot to get all the price list from the staging table
   --------------------------------------------------------
   CURSOR lcu_get_price_list
   IS
   SELECT *
   FROM   usbpcs_pricelist_cleaned UPC
   WHERE  UPC.OracleGenUse2=gc_operating_unit_name
   AND UPC.oraclecharfld1 ='PS'
   AND UPC.charuserfld1 is NOT NULL
   ORDER  BY UPC.pricelistname,itemnumber;

   --------------------------------------------------------
   --Cursor to get the all the secondary pricelist
   -- attached to the main pricelist from the staging table
   --------------------------------------------------------
   CURSOR lcu_get_sec_prc_lst (p_pricelist VARCHAR2)
   IS
   SELECT *
   FROM   usbpcs_pricelist_cleaned UPC
   WHERE  UPC.pricelistname=p_pricelist
   AND UPC.charuserfld1 is NOT NULL;
   --AND oracleidentifier=12360;

   --------------------------------------
   --Cursor to get total count of records
   --------------------------------------
   CURSOR lcu_get_rec_count
   IS
   SELECT  count(1)
   FROM    usbpcs_pricelist_cleaned UPC
   WHERE   UPC.OracleGenUse2=gc_operating_unit_name
   AND UPC.charuserfld1 is NOT NULL;


   ------------------------------------------------
   --Cursor to get total count of records processed
   ------------------------------------------------
   CURSOR lcu_get_rec_prc_count
   IS
   SELECT count(1)
   FROM   usbpcs_pricelist_cleaned UPC
   WHERE  UPC.oraclecharfld1='PS1'
   AND    UPC.OracleGenUse2=gc_operating_unit_name;

  -----------------------------------------------
  --Cursor to get total count of records errored
  -----------------------------------------------
  CURSOR lcu_get_rec_err_count
  IS
  SELECT count(1)
  FROM   usbpcs_pricelist_cleaned UPC
  WHERE  UPC.oraclecharfld1='PE1'
  AND    UPC.OracleGenUse2=gc_operating_unit_name;

  -------------------------------------
  --Cursor to check if price list exist
  -------------------------------------
  CURSOR lcu_chk_price_list(p_price_list VARCHAR2)
  IS
  SELECT list_header_id,currency_code
  FROM   qp_list_headers QLHT
  WHERE  QLHT.name=p_price_list;





BEGIN
   gc_debug_flag:=p_debug;
   gc_log_msg:='*************START OF PROCEDURE*************';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   gc_program_name :='Secondary Price List Conversion';

   --------------------------------------------
   -- Selecting the current operating unit name
   --------------------------------------------
   BEGIN
      SELECT  HOU.name
      INTO    gc_operating_unit_name
      FROM    hr_operating_units  HOU
      WHERE   HOU.organization_id   =  FND_PROFILE.VALUE('ORG_ID');
   EXCEPTION
   WHEN    NO_DATA_FOUND   THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Operating Unit Does not Exist in the Application');
      x_retcode := 2;
      RETURN;

   WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Unexpected error encountered when trying to ger Operating Unit '||SQLERRM);
   x_retcode := 2;
   RETURN;
   END;


   ----------------------------------------
   --Get all the Primary pricelisr records
   -----------------------------------------
   FOR lcu_get_price_list_rec IN lcu_get_price_list
   LOOP

      gc_log_msg:='INSIDE MAIN LOOP :';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      gc_record_number       :=lcu_get_price_list_rec.oracleidentifier;
      gc_record_identifier   :='Price List name :'||lcu_get_price_list_rec.pricelistname;

      --Re Initialise variables

      lc_api_err_flag                   :='N';
       lc_price_list_rec                 :=  QP_Price_List_PUB.G_MISS_PRICE_LIST_REC;
       lc_qualifiers_tbl                 :=  Qp_Qualifier_Rules_Pub.G_MISS_QUALIFIERS_TBL;
      ln_line_index                     :=0;
      ln_pri_list_header_id             :=NULL;
      lc_pri_currency_code              :=NULL;

     IF lc_primary_prc_name<>lcu_get_price_list_rec.pricelistname THEN
           lc_primary_prc_name :=lcu_get_price_list_rec.pricelistname;
      ---------------------------------------
      --Check if the Primary Price list exist
      ---------------------------------------
      	OPEN  lcu_chk_price_list(lcu_get_price_list_rec.pricelistname);
      	FETCH lcu_chk_price_list INTO ln_pri_list_header_id,lc_pri_currency_code;
      	   IF lcu_chk_price_list%NOTFOUND THEN
      	      lc_api_err_flag:='Y';
	      lc_api_mst_err_flag:='Y';
      	      gc_error_code       :='SPL01';
	      gc_error_msg        :='Primary pricelist :'||lcu_get_price_list_rec.pricelistname||' not found in Oracle base table';
	      gc_comments         :=NULL;
	      INSERT_ERROR_MSG;
	   END IF;
      	CLOSE lcu_chk_price_list;

      	gc_log_msg:='ln_pri_list_header_id :'||ln_pri_list_header_id;
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


      	---------------------------------------------------------------------------------------
      	--Get all the secondary pricelist attached to the primary price from the staging table
      	---------------------------------------------------------------------------------------
       IF lc_api_err_flag <>'Y' THEN
      	  FOR lcu_get_sec_prc_rec IN lcu_get_sec_prc_lst(lcu_get_price_list_rec.pricelistname)
      	  LOOP


      	   gc_record_number       :=lcu_get_sec_prc_rec.oracleidentifier;
           --gc_record_identifier   :='Secondary Price List name :'||lcu_get_sec_prc_rec.charuserfld1;
      	   gc_log_msg:=' **********************oracleidentifier ********************** :'||lcu_get_sec_prc_rec.oracleidentifier;
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      	   gc_log_msg:='INSIDE SECOND LOOP-Secondary prcname   :'||lcu_get_sec_prc_rec.charuserfld1;
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


           IF lcu_get_sec_prc_rec.charuserfld1 IS NOT NULL THEN

            gc_log_msg:='INSIDE SECOND LOOP :';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      	   ----------------------------------
      	   --Record count for holding records
      	   ----------------------------------
      	   ln_line_index:=0;
      	    ln_line_index:=ln_line_index+1;
      	   ----------------------------------
      	   --ReiInitialise of local variables
      	   ----------------------------------
      	    ln_sec_list_header_id   :=NULL;
             lc_api_err_flag:='N';



      	 ---------------------------------------
      	 --Check if the Secondary Price list exist
      	 ---------------------------------------
      	 lc_sec_currency_code              :=NULL;
      	 OPEN  lcu_chk_price_list(lcu_get_sec_prc_rec.charuserfld1);
      	 FETCH lcu_chk_price_list INTO ln_sec_list_header_id,lc_sec_currency_code;
      	    IF lcu_chk_price_list%NOTFOUND THEN
      	       lc_api_err_flag:='Y';
      	       lc_api_mst_err_flag:='Y';
      	       gc_error_code       :='SPL02';
      	       gc_error_msg        :='Secondary pricelist :'||lcu_get_sec_prc_rec.charuserfld1||' not found in Oracle base table';
      	       gc_comments         :=NULL;
      	       INSERT_ERROR_MSG;
      	     END IF;
      	  CLOSE lcu_chk_price_list;


      	 -----------------------------------------------------------------------------------
      	 --Check if the currency code of secondaty pricelist is same as of primary pricelist
      	 ----------------------------------------------------------------------------------
      	 IF lc_sec_currency_code <>lc_pri_currency_code THEN
      	    lc_api_err_flag:='Y';
      	    lc_api_mst_err_flag:='Y';
      	    gc_error_code       :='SPL03';
      	    gc_error_msg        :='Currency code :'||lc_pri_currency_code||' of the primary pricelist :'||lcu_get_price_list_rec.pricelistname||' does not match with the currency code :'||lc_sec_currency_code||' attached to the Secondary pricelist '||lcu_get_sec_prc_rec.charuserfld1;
      	    gc_comments         :=NULL;
      	    INSERT_ERROR_MSG;
      	 END IF;

      	  gc_log_msg:='ln_sec_list_header_id :'||ln_sec_list_header_id;
          xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          IF lc_api_err_flag <>'Y' THEN
      	  	--------------------
      	  	--Assign the records
      	  	--------------------
          	gc_log_msg:=' Before Assign the records :'||lc_status;
          	xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      	  	lc_qualifiers_tbl(ln_line_index).qualifier_id           :=fnd_api.g_miss_num;
	  	lc_qualifiers_tbl(ln_line_index).operation               :=qp_globals.g_opr_create;
	  	lc_qualifiers_tbl(ln_line_index).comparison_operator_code:='=';
	  	lc_qualifiers_tbl(ln_line_index).qualifier_attr_value_to :=lcu_get_sec_prc_rec.pricelistname; --'I/Co Between US and GB 520 GBP Price List';
	  	lc_qualifiers_tbl(ln_line_index).qualifier_attribute     :='QUALIFIER_ATTRIBUTE4';
	  	lc_qualifiers_tbl(ln_line_index).qualifier_attr_value    :=ln_pri_list_header_id;
	  	lc_qualifiers_tbl(ln_line_index).qualifier_context       :='MODLIST';
	  	lc_qualifiers_tbl(ln_line_index).qualifier_grouping_no   :=-1;
          	lc_qualifiers_tbl(ln_line_index).list_header_id          :=ln_sec_list_header_id;
          	lc_qualifiers_tbl(ln_line_index).qualifier_precedence    :=NVL(lcu_get_sec_prc_rec.intuserfld2,10);

      	  	gc_log_msg:='After Assign the records :';
          	xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      	  	BEGIN
      	  	    --Call the standard API
      	  	 	fnd_msg_pub.initialize;
      	  	 	lc_debug_file := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
      	  	 	oe_debug_pub.initialize;
      	  	 	oe_debug_pub.setdebuglevel(5);
      	  	 	Oe_Msg_Pub.initialize;
          	      gc_log_msg:='Before API Call :'||lc_status;
          	      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      	  	 	QP_Price_List_PUB.Process_Price_List
      	  	 	                                               ( p_api_version_number            => 1.0
      	  	 	                                                ,p_init_msg_list                 => FND_API.G_FALSE
      	  	 	                                                ,p_return_values                 => FND_API.G_FALSE
      	  	 	                                                ,p_commit                        => FND_API.G_FALSE
      	  	 	                                                ,x_return_status                 => lc_status
      	  	 	                                                ,x_msg_count                     => ln_count
      	  	 	                                                ,x_msg_data                      => lc_data
      	  	 	                                                ,p_price_list_rec                => lc_price_list_rec
      	  	 	                                                ,p_price_list_val_rec            => lc_price_list_val_rec
      	  	 	                                                ,p_price_list_line_tbl           => lc_price_list_line_tbl
      	  	 	                                                ,p_price_list_line_val_tbl       => lc_price_list_line_val_tbl
      	  	 	                                                ,p_qualifiers_tbl                => lc_qualifiers_tbl
      	  	 	                                                ,p_qualifiers_val_tbl            => lc_qualifiers_val_tbl
      	  	 	                                                ,p_pricing_attr_tbl              => lc_pricing_attr_tbl
      	  	 	                                                ,p_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
      	  	 	                                                ,x_price_list_rec                => lc_price_list_rec
      	  	 	                                                ,x_price_list_val_rec            => lc_price_list_val_rec
      	  	 	                                                ,x_price_list_line_tbl           => lc_price_list_line_tbl
      	  	 	                                                ,x_price_list_line_val_tbl       => lc_price_list_line_val_tbl
      	  	 	                                                ,x_qualifiers_tbl                => lc_qualifiers_tbl
      	  	 	                                                ,x_qualifiers_val_tbl            => lc_qualifiers_val_tbl
      	  	 	                                                ,x_pricing_attr_tbl              => lc_pricing_attr_tbl
      	  	 	                                                ,x_pricing_attr_val_tbl          => lc_pricing_attr_val_tbl
      	  	 	                                               );

      	  	 	           gc_log_msg:='Status returned by the API :'||lc_status;
      	  	 	           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      	  	 	           IF (lc_status <> FND_API.G_RET_STS_SUCCESS) THEN
          	                    gc_log_msg:='INSIDE ERROR  :'||lc_status;
          	                    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      	  	 	              lc_api_err_flag:='Y';
      	  	 	              lc_api_mst_err_flag:='Y';
      	  	 	              RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
      	  	 	           END IF;
      	  	 	        EXCEPTION
      	  	 	        WHEN FND_API.G_EXC_UNEXPECTED_ERROR THEN
      	  	 	           FOR I IN 1 .. ln_count
      	  	 	           LOOP
      	  	 	              lc_data := oe_msg_pub.get( p_msg_index => 1
      	  	 	                                        ,p_encoded   => 'F'
      	  	 	                                       );
      	  	 	           END LOOP;
      	  	 	           --Log error
          	                 gc_log_msg:='  ERROR MSG :'||lc_data;
          	                 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      	  	 	           gc_error_code       :='API';
      	  	 	           gc_error_msg        :=lc_data;
      	  	 	           gc_comments         :=NULL;
      	  	 	           INSERT_ERROR_MSG;
      	  	WHEN OTHERS THEN
      	  	     --Log error
      	  	 	FND_FILE.PUT_LINE(FND_FILE.LOG,'Unexpected error encountered when calling the API '||SQLERRM);
      	  	 	RAISE;
      	  	END;
      	   END IF; --IF lc_api_err_flag<>'Y'
      	   --Any error by API,update the status of the reocrds
      	   IF (lc_api_err_flag<>'N') OR (lc_max_err_flag <>'N') THEN
      	      lc_max_err_flag:='N';
      	      --Call the update procedure for updae the record status which will run as a Autonomous transaction for secondary pricelis records
      	      update_record_status_sec(p_pricelist_name => lcu_get_sec_prc_rec.pricelistname
                                  ,p_identifier =>lcu_get_sec_prc_rec.oracleidentifier
      	   	                 ,p_status_flag    =>'PE1'
      	   	                 );
      	   ELSE
      	   	update_record_status_sec(p_pricelist_name => lcu_get_sec_prc_rec.pricelistname
                                        ,p_identifier =>lcu_get_sec_prc_rec.oracleidentifier
      	   	                    ,p_status_flag    =>'PS1'
      	   	                   );

      	   END IF;
         END IF; -- IF lcu_get_sec_prc_rec.charuserfld1 IS NOT NULL THEN
        END LOOP; --End of secondary pricelist cursor
      ELSE

           IF (lc_api_err_flag<>'N') OR (lc_max_err_flag <>'N') THEN
      	      lc_max_err_flag:='N';
      	      --Call the update procedure for updae the rrecord status which will run as a Autonomous transaction for primary pricelis records
      	      update_record_status(p_pricelist_name => lcu_get_price_list_rec.pricelistname
                                 -- ,p_identifier =>lcu_get_price_list_rec.oracleidentifier
      	   	                 ,p_status_flag    =>'PE1'
      	   	                 );
      	   ELSE
      	   	update_record_status(p_pricelist_name => lcu_get_price_list_rec.pricelistname
                                     --   ,p_identifier =>lcu_get_price_list_rec.oracleidentifier
      	   	                    ,p_status_flag    =>'PS1'
      	   	                   );

      	   END IF;
          END IF ;--  IF lc_api_err_flag <>'Y' THEN
      END IF; --IF lc_primary_prc_name<>lcu_get_price_list_rec.pricelistname THE
   END LOOP;-- End primary pricelist cursor


   --Get the total no of records
   OPEN  lcu_get_rec_count;
   FETCH lcu_get_rec_count INTO ln_rec_fetched;
   CLOSE lcu_get_rec_count;

   --Get total no of records processed
   OPEN  lcu_get_rec_prc_count;
   FETCH lcu_get_rec_prc_count INTO ln_rec_processed;
   CLOSE lcu_get_rec_prc_count;


   --Get total no of records errored
   OPEN  lcu_get_rec_err_count;
   FETCH lcu_get_rec_err_count INTO ln_rec_errored;
   CLOSE lcu_get_rec_err_count;


   --Summary information of Records Processed
   --===============================================
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Summary information of Records processed ');
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
   fnd_file.put_line(fnd_file.log,'Total Records Processed             :    ' ||ln_rec_processed);
   fnd_file.put_line(fnd_file.log,'Total Records Errored/Warning       :    ' ||ln_rec_errored);

   --Call the error report if any errors
   gc_log_msg:='  lc_api_mst_err_flag :'||lc_api_mst_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   IF (lc_api_mst_err_flag <>'N') THEN

      x_retcode:=1;
      --ROLLBACK;
      COMMIT;

       xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);
   ELSE
     COMMIT;
   END IF;

EXCEPTION
WHEN OTHERS THEN
   ROLLBACK;
   gc_error_code       :='API';
   gc_error_msg        :='Unexpected error encountered in procedure process_secondary_price_lists '||SQLERRM;
   gc_comments         :=NULL;
   INSERT_ERROR_MSG;
   x_retcode:=2;
END PROCESS_SECONDARY_PRICE_LISTS;
--End of changes V1.9
END XXHA_OM_PRICE_LIST_CONV_PK;
/
