--------------------------------------------------------
--  File created - Monday-October-09-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package XXHA_CSD_SYNC_STATUSES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "APPS"."XXHA_CSD_SYNC_STATUSES" AUTHID CURRENT_USER as

procedure debug(p_message IN varchar2);


PROCEDURE main(   errbuf                  OUT NOCOPY VARCHAR2,
                  retcode                 OUT NOCOPY NUMBER);

end;

/
