CREATE OR REPLACE PACKAGE BODY XXHA_BOM_EXTRACT_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_BOM_EXTRACT_PKG                                                                                   *
* Purpose      : This package provides a process load the table, 'APPS.XXHA_BOM_EXPLOSION_TEMP' for the BOM Extract.    *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*                XXHA_LOAD_BOM                                                                                          * 
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        04-FEB-2016     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

PROCEDURE XXHA_PROCESS_DATA(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2) AS

BEGIN

DECLARE

   TRUNCATE_TABLE_BOM_EXPLOSION          VARCHAR2(500);
   l_count                               NUMBER;

   BEGIN

      FND_FILE.PUT_LINE(FND_FILE.LOG,'Program Start Date and Time: ' || TO_CHAR (SYSDATE, 'DD-MON-RR HH:MI:SS') );
      FND_FILE.PUT_LINE(FND_FILE.LOG,' ');

      -- TRUNCATE TABLE APPS.xxha_bom_explosion_temp
      TRUNCATE_TABLE_BOM_EXPLOSION := 'TRUNCATE TABLE APPS.XXHA_BOM_EXPLOSION_TEMP';
      EXECUTE IMMEDIATE TRUNCATE_TABLE_BOM_EXPLOSION;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'TRUNCATE TABLE APPS.XXHA_BOM_EXPLOSION_TEMP: Completed');
      FND_FILE.PUT_LINE(FND_FILE.LOG,' ');

      -- Process BOM Data
      XXHA_LOAD_BOM(
          errbuf
         ,errcode);

      IF errcode = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG, errbuf);
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Load into APPS.XXHA_BOM_EXPLOSION_TEMP: Completed');
         FND_FILE.PUT_LINE(FND_FILE.LOG,' ');
      END IF;

      SELECT COUNT(*) INTO l_count FROM APPS.XXHA_BOM_EXPLOSION_TEMP;

      FND_FILE.PUT_LINE(FND_FILE.LOG,'Program completion Date and Time: ' || TO_CHAR (SYSDATE, 'DD-MON-RR HH:MI:SS') );
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Number of records processed:      ' || l_count );

   END;

END XXHA_PROCESS_DATA;

PROCEDURE XXHA_LOAD_BOM(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2) AS

   no_updates EXCEPTION;

   v_err_msg                        VARCHAR2 (1000);
   v_err_code                       NUMBER;
   p_grp_id                         NUMBER;
   v_sucess                         NUMBER;
   v_count                          NUMBER := 0;
   v_list                           NUMBER;
   v_org_id                         org_organization_definitions.organization_id%TYPE;
   truncate_temp                    VARCHAR2 (1000);

   CURSOR c_orgs
   IS 
   SELECT organization_id,
          organization_code org_code
     FROM mtl_parameters;

   CURSOR c_boms (p_org_id NUMBER)
   IS
   SELECT bom.assembly_item_id item_id,
          bom.organization_id,
          bom.bill_sequence_id
     FROM mtl_system_items msi,
          bom_bill_of_materials bom
    WHERE bom.assembly_item_id         = msi.inventory_item_id
      AND bom.organization_id          = msi.organization_id
      AND bom.organization_id          = p_org_id
      AND bom.alternate_bom_designator IS NULL;
  
   x_sql   VARCHAR2 (500);
   x_seq   NUMBER;
   x_count NUMBER := 0;

BEGIN

   FOR v_org IN c_orgs
   LOOP

      v_org_id    := v_org.organization_id;

      FOR v_items IN c_boms (v_org_id)
      LOOP
         v_sucess := 0;
         SELECT bom_lists_s.NEXTVAL INTO v_list FROM DUAL;
         INSERT INTO bom_lists(
                sequence_id, 
                assembly_item_id, 
                alternate_designator)
         SELECT DISTINCT 
                v_list,
                assembly_item_id,
                alternate_bom_designator
           FROM bom_bill_of_materials       bboms,
                mtl_system_items_b          msis
          WHERE bboms.organization_id     = v_org_id
            AND bboms.assembly_item_id    = v_items.item_id
            AND msis.inventory_item_id    = bboms.assembly_item_id
            AND msis.organization_id      = bboms.organization_id
            AND msis.bom_enabled_flag     = 'Y';

         p_grp_id := 0;

         SELECT bom_explosion_temp_s.NEXTVAL INTO p_grp_id FROM DUAL;

         SELECT bom_explosion_temp_session_s.NEXTVAL INTO x_seq FROM DUAL;

         BEGIN

            -- Call API
            bompexpl.explosion_report(
            verify_flag                           => 2,
            org_id                                => v_org_id,
            order_by                              => 1,
            list_id                               => v_list,
            grp_id                                => p_grp_id,
            session_id                            => x_seq,
            levels_to_explode                     => 20,
            bom_or_eng                            => 1,
            impl_flag                             => 1,
            plan_factor_flag                      => 2,
            incl_lt_flag                          => 2,
            explode_option                        => 3,
            module                                => 2,
            cst_type_id                           => 0,
            std_comp_flag                         => 2,
            expl_qty                              => 1,
            report_option                         => 0,
            req_id                                => 0,
            cst_rlp_id                            => 0,
            lock_flag                             => 1,
            rollup_option                         => 0,
            alt_rtg_desg                          => '',
            alt_desg                              => '',
            rev_date                              => TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS'),
            err_msg                               => v_err_msg,
            ERROR_CODE                            => v_err_code
            );

            IF v_err_msg IS NOT NULL THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'Group Id = ' || p_grp_id || ' ; Error_Message = ' || v_err_msg || '--' || v_err_code );
               errbuf  := 'Error in XXHA_BOM_EXTRACT_PKG.XXHA_LOAD_BOM: ' || SQLERRM;
               errcode := 1;
            ELSE
               BEGIN
               -- Delete from list table
               DELETE FROM bom_lists WHERE sequence_id = v_list;
               -- For Reporting view purpose
               INSERT INTO apps.XXHA_bom_explosion_temp
               SELECT * FROM bom_explosion_temp WHERE TOP_ALTERNATE_DESIGNATOR IS NULL;
               DELETE FROM bom_explosion_temp WHERE GROUP_ID = p_grp_id;

               v_count := v_count + 1;

               COMMIT;

               EXCEPTION
                    WHEN OTHERS THEN
                         NULL;
               END;

            END IF;

         END;

      END LOOP; -- FOR v_items IN c_boms

   END LOOP; -- FOR v_org IN c_orgs

   EXCEPTION
        WHEN no_updates THEN
             FND_FILE.PUT_LINE(FND_FILE.LOG,'Program failed.' );

END XXHA_LOAD_BOM;

END XXHA_BOM_EXTRACT_PKG;