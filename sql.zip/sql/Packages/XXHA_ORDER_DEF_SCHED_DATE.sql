CREATE OR REPLACE PACKAGE xxha_order_def_sched_date
/*****************************************************************************************
* Name/Purpose : xxha_order_def_sched_date                                               *
* Description  : creates                                                                 *
*                package xxha_order_def_sched_date                                       *
*                Defaulting Rule API for Schedule Ship Date                              *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     David Lund           Initial Creation                                  *
*                                                                                        *
*****************************************************************************************/
AS
--
FUNCTION xxha_get_scheduled_ship_date( p_database_object_name IN VARCHAR2,
                                      p_attribute_code       IN VARCHAR2 )
RETURN DATE ;
END xxha_order_def_sched_date;
/


CREATE OR REPLACE PACKAGE BODY xxha_order_def_sched_date
/*****************************************************************************************
* Name/Purpose : xxha_order_def_sched_date                                               *
* Description  : creates                                                                 *
*                package body xxha_order_def_sched_date                                  *
*                Defaulting Rule API for Schedule Ship Date                              *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 01-FEB-2013     David Lund           Initial Creation (proof of concept)               *
* 10-OCT-2013     Manuel Fernandes     Added business logic                              *
* 21-MAY-2014     Manuel Fernandes     Added USE Org exact requirements as PTO           *
*****************************************************************************************/
AS
G_PKG_NAME                    CONSTANT VARCHAR2(30) := 'XXHA_ORDER_DEF_SCHED_DATE';
--
FUNCTION xxha_get_scheduled_ship_date( p_database_object_name IN VARCHAR2,
                                      p_attribute_code       IN VARCHAR2 )
RETURN date
IS
    l_scheduled_ship_date DATE;
    l_warehouse_code varchar2(50);
    l_ord_type_attribute1 varchar2(150);
    v_use_date date;
-- 
Begin
--
  --v_use_date := ONT_LINE_DEF_HDLR.g_record.request_date;
  v_use_date := sysdate;
  l_scheduled_ship_date := null;
  begin
    select organization_code into l_warehouse_code 
    from mtl_parameters 
    --where organization_id = ONT_HEADER_DEF_HDLR.g_record.ship_from_org_id;
    where organization_id = ONT_LINE_DEF_HDLR.g_record.ship_from_org_id;
  exception
  when no_data_found then
    l_warehouse_code := null;
    --insert into haemo.zz_debug(x) values(l_warehouse_code || ','||to_char(v_use_date,'HH24:MI:SS')||','||to_char(ONT_HEADER_DEF_HDLR.g_record.order_type_id));
    --return sysdate+10;
    return null;
  end;
  l_ord_type_attribute1 := null;
  begin
    select attribute1 into l_ord_type_attribute1
    from oe_transaction_types_all where transaction_type_id = ONT_HEADER_DEF_HDLR.g_record.order_type_id;
  exception
  when no_data_found then
    l_ord_type_attribute1 := null;
    --return sysdate+20;
    --insert into haemo.zz_debug(x) values(l_warehouse_code || ','||to_char(v_use_date,'HH24:MI:SS')||','||to_char(ONT_HEADER_DEF_HDLR.g_record.order_type_id));
    return null;
  end;
  --create table haemo.zz_debug(x varchar2(4000))
  --insert into haemo.zz_debug(x) values(l_warehouse_code || ','||to_char(v_use_date,'HH24:MI:SS')||','||to_char(ONT_HEADER_DEF_HDLR.g_record.order_type_id));
  --select to_number(to_char(sysdate+.2,'HH24')) from dual
  if l_warehouse_code in ('AVO', 'PTO', 'SLO', 'BDO', 'MSO', 'CAO', 'COV', 'PRR', 'USE')
    and ONT_HEADER_DEF_HDLR.g_record.order_type_id != 2353 --RxC Standard	
    and l_ord_type_attribute1 = 'Std'
  then
    --l_scheduled_ship_date := v_use_date;
    --if trunc(ONT_LINE_DEF_HDLR.g_record.request_date) = trunc(sysdate) and to_number(to_char(ONT_LINE_DEF_HDLR.g_record.request_date,'HH24')) >= 15 then
    if to_number(to_char(ONT_LINE_DEF_HDLR.g_record.request_date,'HH24')) >= 15 then
      --l_scheduled_ship_date := ONT_LINE_DEF_HDLR.g_record.request_date+1;
      --insert into haemo.zz_debug(x) values('date = '||l_warehouse_code || ','||to_char(v_use_date,'HH24:MI:SS')||','||to_char(ONT_HEADER_DEF_HDLR.g_record.order_type_id));
      l_scheduled_ship_date := xxha_get_next_working_day(ONT_HEADER_DEF_HDLR.g_record.ship_from_org_id, v_use_date, +1, true, 1, 20);
      --insert into haemo.zz_debug(x) values('date = '||l_warehouse_code || ','||to_char(v_use_date,'HH24:MI:SS')||',' || ','||to_char(l_scheduled_ship_date,'DD-MON-YYYY HH24:MI:SS') ||','||to_char(ONT_HEADER_DEF_HDLR.g_record.order_type_id));
      return l_scheduled_ship_date;
    else
      l_scheduled_ship_date := v_use_date;
      return l_scheduled_ship_date;
    end if;
  end if;
  if l_warehouse_code in ('HMO') 
    and l_ord_type_attribute1 = 'Std' then
    l_scheduled_ship_date := xxha_get_next_working_day(ONT_HEADER_DEF_HDLR.g_record.ship_from_org_id, v_use_date, +2, true, 1, 20);
    return l_scheduled_ship_date;
  end if;
  if l_warehouse_code in ('EDC', 'CZO', 'AVO', 'ASC', 'BTO', 'BTS', 'COV', 'FRO', 'FRS', 'FRV', 'HMO', 'PTO', 'PRR', 'SLO', 'GBX', 'GSO', 'UNO', 'USE')
    and l_ord_type_attribute1 = 'Dist' then --5.5 days = 132 hours
    l_scheduled_ship_date := xxha_get_next_working_day(ONT_HEADER_DEF_HDLR.g_record.ship_from_org_id, v_use_date + .5, +5, true, 1, 20);
    return l_scheduled_ship_date;
  end if;
  if l_warehouse_code in ('EDC', 'CHO', 'FRS', 'ILO', 'FRO', 'GSO','CZO', 'FRV')
    and l_ord_type_attribute1 = 'Std' then -- 2.5 days = 60 hrs
    l_scheduled_ship_date := xxha_get_next_working_day(ONT_HEADER_DEF_HDLR.g_record.ship_from_org_id, v_use_date +.5, +2, true, 1, 20);
    return l_scheduled_ship_date;
  end if;
  --insert into haemo.zz_debug(x) values('date null= '||l_warehouse_code || ','||to_char(v_use_date,'DD-MON-YYYY HH24:MI:SS')||',' || ','||to_char(l_scheduled_ship_date,'HH24:MI:SS') ||','||to_char(ONT_HEADER_DEF_HDLR.g_record.order_type_id));
  return l_scheduled_ship_date;
EXCEPTION
  WHEN OTHERS THEN
    IF OE_MSG_PUB.Check_Msg_Level (OE_MSG_PUB.G_MSG_LVL_UNEXP_ERROR) THEN
      OE_MSG_PUB.Add_Exc_Msg( G_PKG_NAME, 'XXHA_GET_SCHEDULED_SHIP_DATE' ) ;
    END IF ;
    RAISE FND_API.G_EXC_UNEXPECTED_ERROR;
END xxha_get_scheduled_ship_date;
--create table haemo.zz_debug (x varchar2(1000));
--select * from haemo.zz_debug
--delete from haemo.zz_debug where x like '%AVO%'--
END xxha_order_def_sched_date ;
/
