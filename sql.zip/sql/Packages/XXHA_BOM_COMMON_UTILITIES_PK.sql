CREATE OR REPLACE package XXHA_BOM_COMMON_UTILITIES_PK
as
-- +=============================================================================+
-- | Name             :  XXHA_BOM_COMMON_UTILITIES_PK
-- | Description      :  This package supports the processing of BOM routings and
-- |                     bills information staged for conversion or interfacing.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-07-09  L.Richards     Initial release
-- +=============================================================================+

-- +=========================================================================
-- | Check for organization
-- +=========================================================================
function organization_ok (
         p_organization_code  in  varchar2
        ,x_organization_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;

-- +=========================================================================
-- | Check for item at master organization
-- +=========================================================================
function item_at_master (
         p_organization_id_mst  in  number
        ,p_item_number  in  varchar2
        ,x_inventory_item_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for item at an organization
-- +=========================================================================
function item_at_org (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_item_number  in  varchar2
        ,p_inventory_item_id  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;

-- +=========================================================================
-- | Check for item at an organization
-- +=========================================================================
procedure chk_item_at_org (
         p_in_organization_code  in  varchar2
        ,p_in_item_number  in  varchar2
        ,x_out_item_id out number
		,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
	, x_out_error_chk out boolean
        ) ;



-- +=========================================================================
-- | Check for item revision
-- +=========================================================================
function item_revision_exists (
         p_organization_id  in  number
        ,p_inventory_item_id  in  number
        ,p_revision  in  varchar2
        ,x_revision_id  out  number
        ) return boolean;


-- +=========================================================================
-- | Check for bill
-- +=========================================================================
function bill_found (
         p_organization_id  in  number
        ,p_assembly_item_id  in  number
        ,p_alternate_bom_designator  in  varchar2
        ,x_bill_sequence_id  out  number
        ) return boolean;

PROCEDURE bill_found (
         p_in_organization_code  in  varchar2
        ,p_in_assembly_item_id  in  number
        ,p_alternate_bom_designator  in  varchar2
        ,x_bill_sequence_id  out  number
		,x_out_bill_found out boolean
        ) ;

PROCEDURE bill_comp_found (
         p_in_organization_code  in  varchar2
        ,p_in_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
		,p_in_comp_item_id  in  varchar2
        ,x_effectivity_date   out date
		,x_out_bill_found out boolean
        ) ;

PROCEDURE rtg_header_found (p_org_code IN  VARCHAR2
          				   	,p_assembly_item_number  IN  varchar2
        					,p_alternate_rtg_designator  IN  varchar2
        					,x_routing_sequence_id  OUT  number
							,x_rtg_found OUT boolean
        					) ;

PROCEDURE routing_op_exists (
         p_routing_sequence_id  in  number
        ,p_operation_type  in  number
        ,p_operation_seq_num  in  number
        ,p_effectivity_date  in  date
        ,x_operation_sequence_id  out  number
		,x_out_op_effectivity_date out date
        ,x_out_rtg_ops_exists out boolean) ;
-- +=========================================================================
-- | Check for consistency in bill header info
-- +=========================================================================
function bill_hdr_consistent (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_revision  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check that operation seq/component item has been staged one time only
-- +=========================================================================
function opcomp_staged_once (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,p_operation_seq_num  in  number
        ,p_component_item_number  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check that item seq has been staged one time only
-- +=========================================================================
function itemseq_staged_once (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,p_item_num  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for duplicate substitute components (Inventory Components)
-- | Ref: PR38
-- +=========================================================================
function duplicate_subcomp_found (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,p_item_num  in  number
        ,p_subcomp_item_1  in  varchar2
        ,p_subcomp_item_2  in  varchar2
        ,p_subcomp_item_3  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for routing
-- +=========================================================================
function routing_found (
         p_organization_id  in  number
        ,p_assembly_item_id  in  number
        ,p_alternate_rtg_designator  in  varchar2
        ,x_routing_sequence_id  out  number
        ) return boolean;


-- +=========================================================================
-- | Check for routing operation existence
-- +=========================================================================
function routing_operation_exists (
         p_routing_sequence_id  in  number
        ,p_operation_type  in  number
        ,p_operation_seq_num  in  number
        ,p_effectivity_date  in  date
        ,x_operation_sequence_id  out  number
        ) return boolean;


-- +=========================================================================
-- | Check for department
-- +=========================================================================
function department_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_department_code  in  varchar2
        ,x_department_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for resource
-- +=========================================================================
function resource_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_resource_code  in  varchar2
        ,x_resource_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


PROCEDURE rtg_resource_found (
         p_in_operation_sequence_id  in  number
        ,p_in_resource_seq_num  in out  varchar2
        ,x_resource_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
		,x_out_rtg_resource_found out boolean
        ) ;

-- +=========================================================================
-- | Check for department resource
-- +=========================================================================
function department_resource_found (
         p_department_code  in  varchar2
        ,p_department_id  in  number
        ,p_resource_code  out  varchar2
        ,p_resource_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for standard operation
-- +=========================================================================
function standard_operation_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_operation_code  in  varchar2
        ,p_operation_type  in  number
        ,x_standard_operation_id  out  number
        ,x_stdop_department_id  out  number
        ,x_stdop_department_code  out  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for standard operation at department
-- +=========================================================================
function stdop_at_department_ok (
         p_operation_code  in  varchar2
        ,p_operation_department_id  in  number
        ,p_department_code  in  varchar2
        ,p_department_id  in number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for activity
-- +=========================================================================
function activity_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_activity  in  varchar2
        ,x_activity_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for subinventory
-- +=========================================================================
function subinventory_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_subinventory_code  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check for subinventory location
-- +=========================================================================
function stock_locator_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_subinventory_code  in  varchar2
        ,p_location  in  varchar2
        ,x_locator_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check Yield (Routing Operation)
-- | Ref: PR11
-- +=========================================================================
function yield_in_range (
         p_yield  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check attribute for between range
-- | Ref: PR13, PR27, PR28
-- +=========================================================================
function between_range (
         p_attr  in  varchar2
        ,p_value  in  number
        ,p_lo  in  number
        ,p_hi  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check attribute for > 0
-- | Ref: PR26
-- +=========================================================================
function greater_than_0 (
         p_attr  in  varchar2
        ,p_value  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check attribute for > 1
-- | Ref: PR34
-- +=========================================================================
function greater_than_1 (
         p_attr  in  varchar2
        ,p_value  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check attribute for value 1 or 2
-- | Ref: PR14
-- +=========================================================================
function Y_or_N (
         p_attr  in  varchar2
        ,p_value  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check operation type is 1, 2 or 3
-- | Ref: PR15
-- +=========================================================================
function operation_type_ok(
         p_operation_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check Autocharge Type (Operation Resources)
-- | Ref: PR29
-- +=========================================================================
function autocharge_type_ok (
         p_autocharge_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check WIP Supply Type (Inventory Component)
-- | Ref: PR32
-- +=========================================================================
function wip_supply_type_ok (
         p_wip_supply_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check Enforce Integer Requirement (Inventory Component)
-- | Ref: PR33
-- +=========================================================================
function enforce_integer_ok (
         p_enforce_integer  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check Autocharge Type (Operation Resources)
-- | Ref: PR35
-- +=========================================================================
function schedule_flag_ok (
         p_schedule_flag  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check Basis Type (Operation Resources)
-- | Ref: PR36
-- +=========================================================================
function basis_type_ok (
         p_basis_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check SO Basis (Inventory Components)
-- | Ref: PR37
-- +=========================================================================
function so_basis_ok (
         p_so_basis  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;


-- +=========================================================================
-- | Check Maximum Quantity allowed on an order (Inventory Components)
-- | Ref: PR31
-- +=========================================================================
function max_qty_ok (
         p_high_quantity  in  number
        ,p_component_quantity  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean;

procedure chk_rtg_ops_seq
                         (p_assembly_item_number IN VARCHAR2
						  ,p_organization_code IN VARCHAR2
						  ,x_ops_seq_num OUT VARCHAR2
						 );
END XXHA_BOM_COMMON_UTILITIES_PK;

/


CREATE OR REPLACE package body XXHA_BOM_COMMON_UTILITIES_PK
as
-- +=============================================================================+
-- | Name             :  XXHA_BOM_COMMON_UTILITIES_PK
-- | Description      :  This package supports the processing of BOM routings and
-- |                     bills information staged for conversion or interfacing.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-07-09  L.Richards     Initial release
-- +=============================================================================+

-- +=========================================================================
-- | Check for organization
-- +=========================================================================
function organization_ok (
         p_organization_code  in  varchar2
        ,x_organization_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
begin
   select  organization_id
   into    x_organization_id
   from    mtl_parameters
   where   organization_code = p_organization_code;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-010';
      x_err_msg := 'Organization code '||p_organization_code||' not found.';
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'Organization Code: '||SQLERRM;
      return(false);
end organization_ok;


-- +=========================================================================
-- | Check for item at master organization
-- +=========================================================================
function item_at_master (
         p_organization_id_mst  in  number
        ,p_item_number  in  varchar2
        ,x_inventory_item_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
begin
   select  inventory_item_id
   into    x_inventory_item_id
   from    mtl_system_items_b
   where   organization_id = p_organization_id_mst
   and     segment1 = p_item_number;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-020';
      x_err_msg := 'Item '||p_item_number||' not found in master inventory.';
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'MST Inventory: '||SQLERRM;
      return(false);
end item_at_master;


-- +=========================================================================
-- | Check for item at an organization
-- +=========================================================================
function item_at_org (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_item_number  in  varchar2
        ,p_inventory_item_id  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_found_flag  varchar2(1);
begin
   select  'Y'
   into    l_found_flag
   from    mtl_system_items_b
   where   organization_id = p_organization_id
   and     inventory_item_id = p_inventory_item_id;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-030';
      x_err_msg := 'Item '||p_item_number||' not found for org '||p_organization_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'ORG Inventory: '||SQLERRM;
      return(false);
end item_at_org;

-- +=========================================================================
-- | Check for item at an organization
-- +=========================================================================
procedure chk_item_at_org (
         p_in_organization_code  in  varchar2
        ,p_in_item_number  in  varchar2
        ,x_out_item_id out number
		,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
		, x_out_error_chk out boolean
        )  is

begin
   x_out_error_chk := true;
   select  inventory_item_id
   into    x_out_item_id
   from    mtl_system_items_b items, mtl_parameters param
   where     items.organization_id = param.organization_id
   and       organization_code = p_in_organization_code
   and     segment1 = p_in_item_number;


exception
   when no_data_found then
      x_err_cd := 'BOM-030';
      x_err_msg := 'Item '||p_in_item_number||' not found for org '||p_in_organization_code;
      x_out_error_chk := false;
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'ORG Inventory: '||SQLERRM;
      x_out_error_chk := false;
end chk_item_at_org;




-- +=========================================================================
-- | Check for item revision
-- +=========================================================================
function item_revision_exists (
         p_organization_id  in  number
        ,p_inventory_item_id  in  number
        ,p_revision  in  varchar2
        ,x_revision_id  out  number
        ) return boolean is
begin
   if (p_revision is null) then
      return(false);
   end if;

   select  revision_id
   into    x_revision_id
   from    mtl_item_revisions_b
   where   inventory_item_id = p_inventory_item_id
   and     organization_id = p_organization_id
   and     nvl(revision,'~!@') = nvl(p_revision,'~!@');

   return(true);
exception
   when others then
      return(false);
end item_revision_exists;


-- +=========================================================================
-- | Check for bill
-- +=========================================================================
function bill_found (
         p_organization_id  in  number
        ,p_assembly_item_id  in  number
        ,p_alternate_bom_designator  in  varchar2
        ,x_bill_sequence_id  out  number
        ) return boolean is
begin
   select  bill_sequence_id
   into    x_bill_sequence_id
   from    bom_bill_of_materials_v
   where   assembly_item_id = p_assembly_item_id
   and     organization_id = p_organization_id
   and     nvl(alternate_bom_designator,'~!@') = nvl(p_alternate_bom_designator,'~!@');

   return(true);
exception
   when others then
      return(false);
end bill_found;

-- +=========================================================================
-- | Check for bill Proc
-- +=========================================================================
PROCEDURE bill_found (
         p_in_organization_code  in  varchar2
        ,p_in_assembly_item_id  in  number
        ,p_alternate_bom_designator  in  varchar2
        ,x_bill_sequence_id  out  number
		,x_out_bill_found out boolean
        ) is
begin
   x_out_bill_found := TRUE;
   select  bill_sequence_id
   into    x_bill_sequence_id
   from    bom_bill_of_materials bom,mtl_parameters param
   where   assembly_item_id = p_in_assembly_item_id
   and     organization_code = p_in_organization_code
   and     bom.organization_id = param.organization_id
   and     nvl(alternate_bom_designator,'~!@') = nvl(p_alternate_bom_designator,'~!@');


exception

   when others then
      x_out_bill_found := FALSE;
end bill_found;

-- +=========================================================================
-- | Check for bill comp Proc
-- +=========================================================================
PROCEDURE bill_comp_found (
         p_in_organization_code  in  varchar2
        ,p_in_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
		,p_in_comp_item_id  in  varchar2
        ,x_effectivity_date   out date
		,x_out_bill_found out boolean
        ) is
begin
   x_out_bill_found := TRUE;

   select comp.effectivity_date
   into   x_effectivity_date
   from bom_bill_of_materials bom,BOM_INVENTORY_COMPONENTS comp, mtl_system_items items,mtl_parameters param
   where component_item_id = p_in_comp_item_id
   and bom.bill_sequence_id = comp.bill_sequence_id
   and     nvl(alternate_bom_designator,'~!@') = nvl(p_alternate_bom_designator,'~!@')
   and items.inventory_item_id = assembly_item_id
   and items.segment1 = p_in_assembly_item_number
   and items.organization_id = param.organization_id
   and bom.organization_id = param.organization_id
   and organization_code = p_in_organization_code;


exception
   when others then
      x_out_bill_found := FALSE;

end bill_comp_found;

-- +=========================================================================
-- | Check for consistency in bill header info
-- +=========================================================================
function bill_hdr_consistent (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_revision  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_diff_count  number;
   l_result  boolean := true;
begin
   select  count(1)
   into    l_diff_count
   from    xxha_bom_inv_comps_stg  x
          ,xxha_bom_inv_comps_stg  y
   where   x.organization_code = p_organization_code
   and     x.assembly_item_number = p_assembly_item_number
   and     nvl(x.alternate_bom_designator,'~!@') = nvl(p_alternate_bom_designator,'~!@')
   and     nvl(x.revision,'~!@') = nvl(p_revision,'~!@')
   and     y.organization_code = x.organization_code
   and     y.assembly_item_number = x.assembly_item_number
   and     nvl(y.alternate_bom_designator,'~!@') = nvl(x.alternate_bom_designator,'~!@')
   and     nvl(y.revision,'~!@') = nvl(x.revision,'~!@')
   and (   nvl(x.specific_assembly_comment,'~!@') <> nvl(y.specific_assembly_comment,'~!@')
       );

   if (l_diff_count > 0) then
      x_err_cd := 'BOM-410';
      x_err_msg := 'Routing header attributes are inconsistent';
      l_result := false;
   end if;

   return(l_result);
end bill_hdr_consistent;


-- +=========================================================================
-- | Check that operation seq/component item has been staged one time only
-- +=========================================================================
function opcomp_staged_once (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,p_operation_seq_num  in  number
        ,p_component_item_number  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_stg_count  number;
   l_altdsg  varchar2(20);
   l_result  boolean := true;
begin
   select  count(1)
   into    l_stg_count
   from    xxha_bom_inv_comps_stg  x
   where   x.organization_code = p_organization_code
   and     x.assembly_item_number = p_assembly_item_number
   and     nvl(x.alternate_bom_designator,'~!@') = nvl(p_alternate_bom_designator,'~!@')
   and     x.operation_seq_num = p_operation_seq_num
   and     x.component_item_number = p_component_item_number;

   if (l_stg_count > 1) then
      if (p_alternate_bom_designator is not null) then
         l_altdsg := '~'||p_alternate_bom_designator;
      end if;
      x_err_cd := 'BOM-450';
      x_err_msg := 'OPSeq/Component '||p_operation_seq_num||'/'||p_component_item_number
                  ||' must be unique for '||p_organization_code||'/'||p_assembly_item_number||l_altdsg;
      l_result := false;
   end if;

   return(l_result);
end opcomp_staged_once;


-- +=========================================================================
-- | Check that item seq has been staged one time only
-- +=========================================================================
function itemseq_staged_once (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,p_item_num  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_stg_count  number;
   l_altdsg  varchar2(20);
   l_result  boolean := true;
begin
   select  count(1)
   into    l_stg_count
   from    xxha_bom_inv_comps_stg  x
   where   x.organization_code = p_organization_code
   and     x.assembly_item_number = p_assembly_item_number
   and     nvl(x.alternate_bom_designator,'~!@') = nvl(p_alternate_bom_designator,'~!@')
   and     x.item_num = p_item_num;

   if (l_stg_count > 1) then
      if (p_alternate_bom_designator is not null) then
         l_altdsg := '~'||p_alternate_bom_designator;
      end if;
      x_err_cd := 'BOM-420';
      x_err_msg := 'Item Seq '||p_item_num||' must be unique for '||p_organization_code||'/'||p_assembly_item_number||l_altdsg;
      l_result := false;
   end if;

   return(l_result);
end itemseq_staged_once;


-- +=========================================================================
-- | Check for duplicate substitute components (Inventory Components)
-- | Ref: PR38
-- +=========================================================================
function duplicate_subcomp_found (
         p_organization_code  in  varchar2
        ,p_assembly_item_number  in  varchar2
        ,p_alternate_bom_designator  in  varchar2
        ,p_item_num  in  number
        ,p_subcomp_item_1  in  varchar2
        ,p_subcomp_item_2  in  varchar2
        ,p_subcomp_item_3  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   lc_altdsg  varchar2(20);
   l_result  boolean := true;
begin
   if (p_alternate_bom_designator is not null) then
      lc_altdsg := '~'||p_alternate_bom_designator;
   end if;

   if (   nvl(p_subcomp_item_1,'~!@1') = nvl(p_subcomp_item_2,'~!@2')
       or nvl(p_subcomp_item_1,'~!@1') = nvl(p_subcomp_item_3,'~!@3')
       or nvl(p_subcomp_item_2,'~!@2') = nvl(p_subcomp_item_3,'~!@3') ) then
      x_err_cd := 'BOM-480';
      x_err_msg := 'Substitutes for component'
                  ||p_organization_code||'/'||p_assembly_item_number||lc_altdsg||'['||p_item_num||']'
                  ||' must be unique';
      l_result := false;
   end if;

   return(l_result);
end duplicate_subcomp_found;


-- +=========================================================================
-- | Check for routing
-- +=========================================================================
function routing_found (
         p_organization_id  in  number
        ,p_assembly_item_id  in  number
        ,p_alternate_rtg_designator  in  varchar2
        ,x_routing_sequence_id  out  number
        ) return boolean is
begin
   select  routing_sequence_id
   into    x_routing_sequence_id
   from    bom_operational_routings
   where   assembly_item_id = p_assembly_item_id
   and     organization_id = p_organization_id
   and     nvl(alternate_routing_designator,'~!@') = nvl(p_alternate_rtg_designator,'~!@');

   return(true);
exception
   when others then
      return(false);
end routing_found;

PROCEDURE rtg_header_found (p_org_code IN  VARCHAR2
          				   	,p_assembly_item_number  IN  varchar2
        					,p_alternate_rtg_designator  IN  varchar2
        					,x_routing_sequence_id  OUT  number
							,x_rtg_found OUT boolean
        					) is
begin
   x_rtg_found := TRUE;
   select  distinct routing_sequence_id
   into    x_routing_sequence_id
   from    bom_operational_routings rtg,mtl_system_items items,mtl_parameters param
   where   assembly_item_id = inventory_item_id
   and     items.organization_id = param.organization_id
   and    items.organization_id = rtg.organization_id
   and     organization_code = p_org_code
   and    items.segment1 = p_assembly_item_number
   and     nvl(alternate_routing_designator,'~!@') = nvl(p_alternate_rtg_designator,'~!@');


exception
   when others then
      x_rtg_found := FALSE;
end rtg_header_found;

-- +=========================================================================
-- | Check for routing operation existence
-- +=========================================================================
function routing_operation_exists (
         p_routing_sequence_id  in  number
        ,p_operation_type  in  number
        ,p_operation_seq_num  in  number
        ,p_effectivity_date  in  date
        ,x_operation_sequence_id  out  number
        ) return boolean is
begin
   if (p_routing_sequence_id is null) then
      return(false);
   end if;
   if (p_operation_seq_num = 1) then
      return(true);
   end if;

   select  operation_sequence_id
   into    x_operation_sequence_id
   from    bom_operation_sequences
   where   routing_sequence_id = p_routing_sequence_id
   and     operation_type = nvl(p_operation_type,operation_type)
   and     operation_seq_num = p_operation_seq_num
   and     p_effectivity_date between effectivity_date
                                  and nvl(disable_date,p_effectivity_date);

   return(true);
exception
   when others then
      return(false);
end routing_operation_exists;

PROCEDURE routing_op_exists (
         p_routing_sequence_id  in  number
        ,p_operation_type  in  number
        ,p_operation_seq_num  in  number
        ,p_effectivity_date  in  date
        ,x_operation_sequence_id  out  number
		,x_out_op_effectivity_date out date
        ,x_out_rtg_ops_exists out boolean)  is
begin


   select  distinct operation_sequence_id,to_date(to_char(effectivity_date, 'DD-MON-YYYY HH:MI:SS PM'),'DD-MON-YYYY HH:MI:SS PM')
   into    x_operation_sequence_id,x_out_op_effectivity_date
   from    bom_operation_sequences
   where   routing_sequence_id = p_routing_sequence_id
   --and     operation_type = nvl(p_operation_type,operation_type)
   and     operation_seq_num = p_operation_seq_num
   --and     p_effectivity_date between effectivity_date
     --                             and nvl(disable_date,p_effectivity_date);
;
   x_out_rtg_ops_exists := TRUE;

exception
   when others then
      x_out_rtg_ops_exists := FALSE;
end routing_op_exists;
-- +=========================================================================
-- | Check for department
-- +=========================================================================
function department_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_department_code  in  varchar2
        ,x_department_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
begin
   if (p_department_code is null) then
      return(true);
   end if;

   select  department_id
   into    x_department_id
   from    bom_departments
   where   organization_id = p_organization_id
   and     department_code = p_department_code;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-040';
      x_err_msg := 'Department '||p_department_code||' not found for org '||p_organization_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'Department: '||SQLERRM;
      return(false);
end department_ok;


-- +=========================================================================
-- | Check for resource
-- +=========================================================================
function resource_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_resource_code  in  varchar2
        ,x_resource_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
begin
   if (p_resource_code is null) then
      return(true);
   end if;

   select  resource_id
   into    x_resource_id
   from    bom_resources
   where   organization_id = p_organization_id
   and     resource_code = p_resource_code;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-050';
      x_err_msg := 'Resource '||p_resource_code||' not found for org '||p_organization_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'Resource: '||SQLERRM;
      return(false);
end resource_ok;


PROCEDURE rtg_resource_found (
         p_in_operation_sequence_id  in  number
        ,p_in_resource_seq_num  in out  varchar2
        ,x_resource_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
		,x_out_rtg_resource_found out boolean
        ) is
BEGIN
   x_out_rtg_resource_found := TRUE;
   select distinct resource_seq_num
   into p_in_resource_seq_num
   from bom_operation_resources
   where operation_sequence_id = p_in_operation_sequence_id
   and resource_seq_num = p_in_resource_seq_num;


exception
   when no_data_found then
     x_out_rtg_resource_found := FALSE;

end rtg_resource_found;


-- +=========================================================================
-- | Check for department resource
-- +=========================================================================
function department_resource_found (
         p_department_code  in  varchar2
        ,p_department_id  in  number
        ,p_resource_code  out  varchar2
        ,p_resource_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_found_flag  varchar2(1);
begin
   if (p_resource_code is null) then
      return(true);
   end if;

   select  'Y'
   into    l_found_flag
   from    bom_department_resources
   where   department_id = p_department_id
   and     resource_id = p_resource_id;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-060';
      x_err_msg := 'Resource '||p_resource_code||' is not assigned to department '||p_department_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'Department Resource: '||SQLERRM;
      return(false);
end department_resource_found;


-- +=========================================================================
-- | Check for standard operation
-- +=========================================================================
function standard_operation_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_operation_code  in  varchar2
        ,p_operation_type  in  number
        ,x_standard_operation_id  out  number
        ,x_stdop_department_id  out  number
        ,x_stdop_department_code  out  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
begin
   if (p_operation_code is null) then
      return(true);
   end if;

   select  so.standard_operation_id
          ,so.department_id
          ,d.department_code
   into    x_standard_operation_id
          ,x_stdop_department_id
          ,x_stdop_department_code
   from    bom_standard_operations  so
          ,bom_departments  d
   where   1=1
   and     so.operation_code = p_operation_code
   and     so.organization_id = p_organization_id
   and     so.operation_type = nvl(p_operation_type,1)
   and     d.department_id = so.department_id;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-070';
      x_err_msg := 'Standard Operation '||p_operation_code||' is not setup for Org '||p_organization_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'Standard Operation: '||SQLERRM;
      return(false);
end standard_operation_ok;


-- +=========================================================================
-- | Check for standard operation at department
-- +=========================================================================
function stdop_at_department_ok (
         p_operation_code  in  varchar2
        ,p_operation_department_id  in  number
        ,p_department_code  in  varchar2
        ,p_department_id  in number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_operation_code is not null  and  p_department_code is not null) then
      if (p_operation_department_id <> p_department_id) then
         x_err_cd := 'BOM-080';
         x_err_msg := 'Std Op '||p_operation_code||' is not defined for department '||p_department_code;
         l_result := false;
      end if;
   end if;

   return(l_result);
end stdop_at_department_ok;


-- +=========================================================================
-- | Check for activity
-- +=========================================================================
function activity_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_activity  in  varchar2
        ,x_activity_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
begin
   select  activity_id
   into    x_activity_id
   from    cst_activities
   where   organization_id = p_organization_id
   and     activity = p_activity;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-090';
      x_err_msg := 'Activity '||p_activity||' is not setup for Org '||p_organization_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'Activity: '||SQLERRM;
      return(false);
end activity_ok;


-- +=========================================================================
-- | Check for subinventory
-- +=========================================================================
function subinventory_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_subinventory_code  in  varchar2
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_found_flag  varchar2(1);
begin
   if (p_subinventory_code is null) then
      return(true);
   end if;

   select  'Y'
   into    l_found_flag
   from    mtl_secondary_inventories
   where   organization_id = p_organization_id
   and     secondary_inventory_name = p_subinventory_code;

   return(true);
exception
   when no_data_found then
      x_err_cd := 'BOM-100';
      x_err_msg := 'SubInventory '||p_subinventory_code||' is not setup for Org '||p_organization_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'SubInventory: '||SQLERRM;
      return(false);
end subinventory_ok;


-- +=========================================================================
-- | Check for subinventory location
-- +=========================================================================
function stock_locator_ok (
         p_organization_code  in  varchar2
        ,p_organization_id  in  number
        ,p_subinventory_code  in  varchar2
        ,p_location  in  varchar2
        ,x_locator_id  out  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_enabled_flag  varchar2(1);
   l_disable_date  date;
   e_subinv  exception;
   e_locator  exception;
begin
   if (p_location is null) then
      return(true);
   end if;

   if (p_subinventory_code is null) then
      raise e_subinv;
   end if;

   select  inventory_location_id
          ,enabled_flag
          ,disable_date
   into    x_locator_id
          ,l_enabled_flag
          ,l_disable_date
   from    mtl_item_locations
   where   organization_id = p_organization_id
   and     subinventory_code = p_subinventory_code
   and     segment1||'.'||segment2||'.'||segment3 = p_location;

   if (l_enabled_flag <> 'Y'  or   nvl(l_disable_date,sysdate) < sysdate) then
      raise e_locator;
   end if;

   return(true);
exception
   when e_subinv then
      x_err_cd := 'BOM-115';
      x_err_msg :=  'Subinventory must be specified for Stock Locator '||p_location;
      return(false);
   when e_locator then
      x_err_cd := 'BOM-120';
      x_err_msg :=  'Stock Locator '||p_location||' is disabed or inactive.';
      return(false);
   when no_data_found then
      x_err_cd := 'BOM-110';
      x_err_msg :=  'Stock Locator '||p_location||' is not defined for '
                  ||p_organization_code||' SubInventory '||p_subinventory_code;
      return(false);
   when others then
      x_err_cd := 'SQL-010';
      x_err_msg := 'Stock Locator: '||SQLERRM;
      return(false);
end stock_locator_ok;


-- +=========================================================================
-- | Check Yield (Routing Operation)
-- | Ref: PR11
-- +=========================================================================
function yield_in_range (
         p_yield  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_yield is not null) then
      if not (p_yield > 0 and p_yield <= 1) then
         x_err_cd := 'BOM-200';
         x_err_msg :=  'Yield must be > 0 and <= 1';
         l_result := false;
      end if;
   end if;

   return(l_result);
end yield_in_range;


-- +=========================================================================
-- | Check attribute for between range
-- | Ref: PR13, PR27, PR28
-- +=========================================================================
function between_range (
         p_attr  in  varchar2
        ,p_value  in  number
        ,p_lo  in  number
        ,p_hi  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_value is not null) then
      if (p_value not between p_lo and p_hi) then
         x_err_cd := 'BOM-210';
         x_err_msg :=  p_attr||' must range from '||p_lo||' to '||p_hi;
         l_result := false;
      end if;
   end if;

   return(l_result);
end between_range;


-- +=========================================================================
-- | Check attribute for > 0
-- | Ref: PR26
-- +=========================================================================
function greater_than_0 (
         p_attr  in  varchar2
        ,p_value  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_value is not null) then
      if (p_value <= 0) then
         x_err_cd := 'BOM-220';
         x_err_msg :=  p_attr||' must be > 0';
         l_result := false;
      end if;
   end if;

   return(l_result);
end greater_than_0;


-- +=========================================================================
-- | Check attribute for > 1
-- | Ref: PR34
-- +=========================================================================
function greater_than_1 (
         p_attr  in  varchar2
        ,p_value  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_value is not null) then
      if (p_value <= 1) then
         x_err_cd := 'BOM-225';
         x_err_msg :=  p_attr||' must be > 1';
         l_result := false;
      end if;
   end if;

   return(l_result);
end greater_than_1;


-- +=========================================================================
-- | Check attribute for value 1 or 2
-- | Ref: PR14
-- +=========================================================================
function Y_or_N (
         p_attr  in  varchar2
        ,p_value  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_value is not null) then
      if (p_value not in (1,2)) then
         x_err_cd := 'BOM-230';
         x_err_msg :=  p_attr||' must be 1 (for Yes) or 2 (for No)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end Y_or_N;


-- +=========================================================================
-- | Check operation type is 1, 2 or 3
-- | Ref: PR15
-- +=========================================================================
function operation_type_ok(
         p_operation_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_operation_type is not null) then
      if (p_operation_type not in (1,2,3)) then
         x_err_cd := 'BOM-240';
         x_err_msg := 'Operation Type must be 1 (Event), 2 (Process) or 3 (Line Operation)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end operation_type_ok;


-- +=========================================================================
-- | Check Autocharge Type (Operation Resources)
-- | Ref: PR29
-- +=========================================================================
function autocharge_type_ok (
         p_autocharge_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_autocharge_type is not null) then
      if (p_autocharge_type not in (1,2,3,4)) then
         x_err_cd := 'BOM-250';
         x_err_msg := 'Autocharge Type must be 1 (WIP move), 2 (Manual), 3 (PO receipt) or 4 (PO move)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end autocharge_type_ok;


-- +=========================================================================
-- | Check WIP Supply Type (Inventory Component)
-- | Ref: PR32
-- +=========================================================================
function wip_supply_type_ok (
         p_wip_supply_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_wip_supply_type is not null) then
      if (p_wip_supply_type not in (1,2,4,5,6)) then
         x_err_cd := 'BOM-260';
         x_err_msg := 'WIP Supply Type must be 1 (Push), 2 (Assembly Pull), 4 (Bulk), 5 (Supplier) or 6 (Phantom)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end wip_supply_type_ok;


-- +=========================================================================
-- | Check Enforce Integer Requirement (Inventory Component)
-- | Ref: PR33
-- +=========================================================================
function enforce_integer_ok (
         p_enforce_integer  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_enforce_integer is not null) then
      if (p_enforce_integer not in (0,1,2)) then
         x_err_cd := 'BOM-270';
         x_err_msg := 'Enforce Integer Flag must be 0 (None), 1 (Up) or 2 (Down)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end enforce_integer_ok;


-- +=========================================================================
-- | Check Autocharge Type (Operation Resources)
-- | Ref: PR35
-- +=========================================================================
function schedule_flag_ok (
         p_schedule_flag  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_schedule_flag is not null) then
      if (p_schedule_flag not in (1,2,3,4)) then
         x_err_cd := 'BOM-255';
         x_err_msg := 'Schedule must be 1 (Yes, 2 (No), 3 (Prior) or 4 (Next)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end schedule_flag_ok;


-- +=========================================================================
-- | Check Basis Type (Operation Resources)
-- | Ref: PR36
-- +=========================================================================
function basis_type_ok (
         p_basis_type  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_basis_type is not null) then
      if (p_basis_type not in (1,2)) then
         x_err_cd := 'BOM-280';
         x_err_msg := 'Basis type must be 1 (Item) or 2 (Lot)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end basis_type_ok;


-- +=========================================================================
-- | Check SO Basis (Inventory Components)
-- | Ref: PR37
-- +=========================================================================
function so_basis_ok (
         p_so_basis  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_so_basis is not null) then
      if (p_so_basis not in (1,2)) then
         x_err_cd := 'BOM-460';
         x_err_msg := 'SO Basis must be 1 (Option Class) or 2 (None)';
         l_result := false;
      end if;
   end if;

   return(l_result);
end so_basis_ok;


-- +=========================================================================
-- | Check Maximum Quantity allowed on an order (Inventory Components)
-- | Ref: PR31
-- +=========================================================================
function max_qty_ok (
         p_high_quantity  in  number
        ,p_component_quantity  in  number
        ,x_err_cd  out  varchar2
        ,x_err_msg  out  varchar2
        ) return boolean is
   l_result  boolean := true;
begin
   if (p_high_quantity is not null) then
      if (p_high_quantity >= p_component_quantity) then
         x_err_cd := 'BOM-470';
         x_err_msg := 'Maximum Qty '||p_high_quantity||' cannot be less than Component Qty '||p_component_quantity;
         l_result := false;
      end if;
   end if;

   return(l_result);
end max_qty_ok;

procedure chk_rtg_ops_seq
                         (p_assembly_item_number IN VARCHAR2
						  ,p_organization_code IN VARCHAR2
						  ,x_ops_seq_num OUT VARCHAR2
						 )
						 IS
 cursor c_rtg_ops_seq (q_org_code varchar2,q_assly_item_number varchar2) is
  select  operation_seq_num
from BOM_OPERATIONAL_ROUTINGS rtg_hdr,bom_operation_sequences rtg_ops,mtl_system_items items,mtl_parameters param
where rtg_hdr.routing_sequence_id = rtg_ops.routing_sequence_id
and items.inventory_item_id = rtg_hdr.assembly_item_id
and items.organization_id = rtg_hdr.organization_id
and items.organization_id = param.organization_id
and param.organization_code = q_org_code
and items.segment1 = q_assly_item_number
;
begin
   x_ops_seq_num := 1;
  for v_rtg_ops_seq in c_rtg_ops_seq (p_organization_code,p_assembly_item_number) loop
    x_ops_seq_num := v_rtg_ops_seq.operation_seq_num;
  end loop;


end;

END XXHA_BOM_COMMON_UTILITIES_PK;

/
