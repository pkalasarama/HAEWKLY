CREATE OR REPLACE PACKAGE XXHA_wm_SHIP_CONF_Handler_Pkg AUTHID CURRENT_USER AS

-- Procedure to determine calling parameters for Order Import Concurrent Request
-- Takes in the mandatory and optional parameters required for Order Import Concurrent Request

PROCEDURE WM_HANDLE_SHIP_CONFIRM( p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg OUT VARCHAR,
			    p_ship_confirm_rule IN VARCHAR2,
			    p_ship_confirm_batch_prefix IN VARCHAR2,
				p_organization IN VARCHAR2
			    );


END XXHA_wm_SHIP_CONF_Handler_Pkg;

/


CREATE OR REPLACE PACKAGE BODY XXHA_wm_SHIP_CONF_Handler_Pkg AS

PROCEDURE WM_HANDLE_SHIP_CONFIRM(p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg OUT VARCHAR,
			    p_ship_confirm_rule IN VARCHAR2,
			    p_ship_confirm_batch_prefix IN VARCHAR2,
				p_organization IN VARCHAR2
			    )
	IS
	v_program  			 VARCHAR2(20):='WSHASCSRS'; -- Order Import
	v_application		 VARCHAR2(20):='WSH'; -- Application
	v_application_id		 NUMBER;
	v_user_id			 NUMBER;
	v_user_responsibility_id NUMBER;
	v_ship_confirm_rule_id NUMBER;
	v_organization_id	 NUMBER;
BEGIN

	  -- Fetch Application id for ONT Application
	  v_errmsg:='Fetching the Application Id';

	  SELECT application_id
	  INTO   v_application_id
	  FROM   fnd_application
	  WHERE  application_short_name = 'ONT';

	  -- Fetch the User Id
	  v_errmsg:='Fetching the User Id';
	  v_user_id:=wm_conc_request_pkg.get_user_id(p_user);

	  -- Fetch the Responsibility Id
	  v_errmsg:='Fetching the Responsibility Id';

        v_user_responsibility_id:= wm_conc_request_pkg.get_user_responsibility_id( p_user_responsibility);
		
		
	  v_errmsg:='Fetching Ship Confirm Rule ID';
	  
	  if p_ship_confirm_rule IS NOT NULL THEN
		SELECT ship_confirm_rule_id
		INTO v_ship_confirm_rule_id
		FROM wsh_ship_confirm_rules
		WHERE name=p_ship_confirm_rule
		AND effective_start_date <= SYSDATE
		AND NVL(effective_end_date, SYSDATE) >= SYSDATE;
	  END IF;
	  
	  v_errmsg:='Fetching Organization ID';
	  
	  if p_organization IS NOT NULL THEN
		SELECT organization_id
		INTO v_organization_id
		FROM org_organization_definitions
		WHERE organization_code=p_organization;
	  END IF;

	  -- Initialize environment

 Fnd_Global.apps_initialize(v_user_id,v_user_responsibility_id,v_application_id);

	  -- Call to submit request
        v_errmsg:='Submitting the Concurrent Request';

	  Wm_Conc_Request_Pkg.wm_request_submit(v_application_id,
	  							v_user_responsibility_id,
	  							v_user_id,
	  							v_application,
			  			     		v_program,
			  			     		v_status,
			  			     		v_request_id,
			  			     		NULL,
			  			     		NULL,
			  			     		o_message,
			  			     		v_errmsg,
           			  	     			v_ship_confirm_rule_id,
										p_ship_confirm_batch_prefix,
           			  	     			v_organization_id,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null,
										null);

EXCEPTION
WHEN OTHERS THEN
 v_errmsg:=v_errmsg||SQLERRM;


END WM_HANDLE_SHIP_CONFIRM;

END XXHA_wm_SHIP_CONF_Handler_Pkg;

/
