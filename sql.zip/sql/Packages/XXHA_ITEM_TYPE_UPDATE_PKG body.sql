create or replace PACKAGE BODY XXHA_ITEM_TYPE_UPDATE_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_ITEM_TYPE_UPDATE_PKG                                                                              *
* Purpose      : This package sets the Item Type for each child org to the Item Type for the MST Org.                   *
*                                                                                                                       *
* Procedures   : XXHA_ITEM_TYPE_UPDATE_TO_MST                                                                           *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        10-JAN-2018     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

--------------------------------------------------------------------------------
-- PROCEDURE XXHA_ITEM_TYPE_UPDATE_TO_MST

PROCEDURE XXHA_ITEM_TYPE_UPDATE_TO_MST(
                                     x_errbuf  OUT VARCHAR2
                                   , x_retcode OUT VARCHAR2
                                        )
AS

   l_item_table                      ego_item_pub.item_tbl_type;
   x_item_table                      ego_item_pub.item_tbl_type;
   x_message_list                    error_handler.error_tbl_type;

   x_return_status                   VARCHAR2 (1);
   x_msg_data                        VARCHAR2 (1000);
   x_msg_count                       NUMBER   (10);

   CURSOR C_ITEM IS
   SELECT
       mp.ORGANIZATION_ID
    ,  mp.organization_code
    ,  msib.segment1
    ,  msib.INVENTORY_ITEM_ID
    ,  msib.item_type
    ,  MSIB_MST.INVENTORY_ITEM_ID          MST_INVENTORY_ITEM_ID
    ,  MSIB_MST.item_type                  MST_item_type
   FROM
       apps.mtl_system_items_b             msib
    ,  apps.mtl_parameters                 mp
    ,  (SELECT 
               msib1.INVENTORY_ITEM_ID
             , msib1.organization_id
             , msib1.item_type
          FROM
               apps.mtl_system_items_b     msib1
             , apps.mtl_parameters         mp1
         WHERE 1=1
           AND msib1.organization_id     = mp1.organization_id
           AND mp1.organization_id       = 103) MSIB_MST
   WHERE 1=1
   AND msib.organization_id              = mp.organization_id
   AND mp.organization_id               <> 103
   AND msib.INVENTORY_ITEM_ID            = MSIB_MST.INVENTORY_ITEM_ID
   AND MSIB_MST.item_type               IS NOT NULL
   AND NVL(msib.item_type,'-XXXX-')     <> MSIB_MST.item_type
   ORDER BY
       mp.organization_code
    ,  msib.segment1;

BEGIN

FOR ITEM IN C_ITEM LOOP

      L_ITEM_TABLE(1).TRANSACTION_TYPE            := 'UPDATE';
      L_ITEM_TABLE(1).INVENTORY_ITEM_ID           := item.INVENTORY_ITEM_ID;
      L_ITEM_TABLE(1).ORGANIZATION_ID             := item.ORGANIZATION_ID;
      L_ITEM_TABLE(1).item_type                   := item.MST_item_type;

      ego_item_pub.process_items(
        p_api_version             => 1.0
      , p_init_msg_list           => fnd_api.g_true
      , p_commit                  => fnd_api.g_true
      , p_item_tbl                => l_item_table
      , x_item_tbl                => x_item_table
      , x_return_status           => x_return_status
      , x_msg_count               => x_msg_count);

      IF x_return_status = fnd_api.g_ret_sts_success THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG, 'Item/Org: ' || item.segment1 || '/' || item.ORGANIZATION_ID || ' - Updated to: ' || item.MST_item_type);
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, 'Item/Org: ' || item.segment1 || '/' || item.ORGANIZATION_ID || ' - Failed ');
         FOR i IN 1 .. x_msg_count
         LOOP
            x_msg_data := oe_msg_pub.get(p_msg_index => i, p_encoded => 'F');
            FND_FILE.PUT_LINE(FND_FILE.LOG, x_msg_data || ' - return_status: ' || x_return_status);
         END LOOP;
      END IF;

END LOOP;

END XXHA_ITEM_TYPE_UPDATE_TO_MST;

END XXHA_ITEM_TYPE_UPDATE_PKG;