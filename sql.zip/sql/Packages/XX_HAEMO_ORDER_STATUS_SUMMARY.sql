CREATE OR REPLACE package xx_haemo_order_status_summary
as
procedure summary_main(errbuf varchar2, retcode varchar2);
end xx_haemo_order_status_summary;
/


CREATE OR REPLACE package body xx_haemo_order_status_summary
as
procedure order_lines_all
as
lp_loop_check number := 1;
lp_ship_date date;
lp_count number;
lp_date_first date;
lp_date_last date;
lp_max_weeks number;
lp_date_temp date;
lp_days number;
cursor c_day_count is
	   select today
	   		  , yesterday 
			  , week_number
	   from   xxha_order_status_summary
	   order by week_number asc;
begin
	 select max(week_number)
	 into   lp_max_weeks
	 from   xxha_order_status_summary;
	 begin
  	 	  select distinct trunc(last_run_date)
  	 	  into   lp_date_temp
  	 	  from   xxha_order_status_summary;
	 exception
	 		  when others then
  	 	  	  	   select distinct trunc(last_run_date)
  	 	  		   into   lp_date_temp
  	 	  		   from   xxha_order_status_summary
  	 	  		   where  last_run_date is not null;
	 end;
	 if trunc(sysdate) = lp_date_temp then
	 	null;
	 elsif trunc(sysdate) > lp_date_temp then
	 	lp_days := trunc(sysdate) - lp_date_temp;
		if lp_days <= 2 and lp_days <> 0 then
		   if lp_days = 1 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday = r_day_count.yesterday
				  		 , yesterday = r_day_count.today
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   elsif lp_days = 2 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday = r_day_count.today
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   end if;
		end if;
	 end if;
	 while lp_loop_check <> 0 loop
	 	   if lp_loop_check = 1 then
		   	     select week_schedule_ship_date 
				 into   lp_ship_date
				 from   xxha_order_status_summary
				 where  week_number = lp_loop_check;
		   	  	 select count(oola.line_id)
				 into   lp_count
	 			 from   oe_order_lines_all oola
	 			 		, oe_order_headers_all ooha
						, wsh_delivery_details wdd
						, wsh_deliverables_v wdv
	 			 where  oola.header_id = ooha.header_id
	 			 		and ooha.flow_status_code in ('BOOKED', 'ENTERED')
						and oola.cancelled_flag <> 'Y'
						and ooha.cancelled_flag <> 'Y'
						and oola.header_id = wdd.source_header_id (+)
						and oola.org_id = wdd.org_id (+)
						and oola.line_id = wdd.source_line_id (+)
						and wdv.delivery_detail_id = wdd.delivery_detail_id
						and wdv.released_status_name <> 'Shipped'
						and oola.schedule_ship_date <= lp_ship_date;
				 update xxha_order_status_summary
				 set    today = lp_count
				 		, last_update_date = sysdate
						, last_updated_by = fnd_global.user_id
						, last_update_login = fnd_global.login_id
				 where  week_number = lp_loop_check;
				 lp_loop_check := lp_loop_check + 1;
		   else
			   select week_schedule_ship_date
			   into   lp_date_first
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check - 1;
			   select week_schedule_ship_date
			   into   lp_date_last
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check;
			   select count(oola.line_id)
			   into   lp_count
	 		   from   oe_order_lines_all oola
	 		   		  , oe_order_headers_all ooha
					  , wsh_delivery_details wdd
					  , wsh_deliverables_v wdv
	 		   where  oola.header_id = ooha.header_id
	 		   		  and ooha.flow_status_code in ('BOOKED', 'ENTERED')
					  and oola.cancelled_flag <> 'Y'
					  and ooha.cancelled_flag <> 'Y'
					  and oola.header_id = wdd.source_header_id (+)
					  and oola.org_id = wdd.org_id (+)
					  and oola.line_id = wdd.source_line_id (+)
					  and wdv.delivery_detail_id = wdd.delivery_detail_id
					  and wdv.released_status_name <> 'Shipped'
					  and oola.schedule_ship_date > lp_date_first
					  and oola.schedule_ship_date <= lp_date_last;
			   update xxha_order_status_summary
			   set    today = lp_count
			   		  , last_update_date = sysdate
					  , last_updated_by = fnd_global.user_id
					  , last_update_login = fnd_global.login_id
			   where  week_number = lp_loop_check;
			   lp_loop_check := lp_loop_check + 1;
			   if lp_loop_check > lp_max_weeks then
			   	  lp_loop_check := 0;
			   end if;			   
		   end if;
     end loop;
	 commit;	 	 
end order_lines_all;
procedure order_lines_bk
as
lp_loop_check number := 1;
lp_ship_date date;
lp_count number;
lp_date_first date;
lp_date_last date;
lp_max_weeks number;
lp_date_temp date;
lp_days number;
cursor c_day_count is
	   select today_bk
	   		  , yesterday_bk 
			  , week_number
	   from   xxha_order_status_summary
	   order by week_number asc;
begin
	 select max(week_number)
	 into   lp_max_weeks
	 from   xxha_order_status_summary;
	 begin
  	 	  select distinct trunc(last_run_date)
  	 	  into   lp_date_temp
  	 	  from   xxha_order_status_summary;
	 exception
	 		  when others then
  	 	  	  	   select distinct trunc(last_run_date)
  	 	  		   into   lp_date_temp
  	 	  		   from   xxha_order_status_summary
  	 	  		   where  last_run_date is not null;
	 end;
	 if trunc(sysdate) = lp_date_temp then
	 	null;
	 elsif trunc(sysdate) > lp_date_temp then
	 	lp_days := trunc(sysdate) - lp_date_temp;
		if lp_days <= 2 and lp_days <> 0 then
		   if lp_days = 1 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_bk = r_day_count.yesterday_bk
				  		 , yesterday_bk = r_day_count.today_bk
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   elsif lp_days = 2 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_bk = r_day_count.today_bk
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   end if;
		end if;
	 end if;
	 while lp_loop_check <> 0 loop
	 	   if lp_loop_check = 1 then
		   	     select week_schedule_ship_date 
				 into   lp_ship_date
				 from   xxha_order_status_summary
				 where  week_number = lp_loop_check;
		   	  	 select count(oola.line_id)
				 into   lp_count
	 			 from   oe_order_lines_all oola
	 			 		, oe_order_headers_all ooha
						, wsh_delivery_details wdd
						, wsh_deliverables_v wdv
	 			 where  oola.header_id = ooha.header_id
	 			 		and ooha.flow_status_code in ('BOOKED', 'ENTERED')
						and oola.cancelled_flag <> 'Y'
						and ooha.cancelled_flag <> 'Y'
						and oola.header_id = wdd.source_header_id (+)
						and oola.org_id = wdd.org_id (+)
						and oola.line_id = wdd.source_line_id (+)
						and wdv.delivery_detail_id = wdd.delivery_detail_id
						and wdv.released_status_name = 'Backordered'
						and oola.schedule_ship_date <= lp_ship_date;
				 update xxha_order_status_summary
				 set    today_bk = lp_count
				 		, last_update_date = sysdate
						, last_updated_by = fnd_global.user_id
						, last_update_login = fnd_global.login_id
				 where  week_number = lp_loop_check;
				 lp_loop_check := lp_loop_check + 1;
		   else
			   select week_schedule_ship_date
			   into   lp_date_first
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check - 1;
			   select week_schedule_ship_date
			   into   lp_date_last
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check;
			   select count(oola.line_id)
			   into   lp_count
	 		   from   oe_order_lines_all oola
	 		   		  , oe_order_headers_all ooha
					  , wsh_delivery_details wdd
					  , wsh_deliverables_v wdv
	 		   where  oola.header_id = ooha.header_id
	 		   		  and ooha.flow_status_code in ('BOOKED', 'ENTERED')
					  and oola.cancelled_flag <> 'Y'
					  and ooha.cancelled_flag <> 'Y'
					  and oola.header_id = wdd.source_header_id (+)
					  and oola.org_id = wdd.org_id (+)
					  and oola.line_id = wdd.source_line_id (+)
					  and wdv.delivery_detail_id = wdd.delivery_detail_id
					  and wdv.released_status_name = 'Backordered'
					  and oola.schedule_ship_date > lp_date_first
					  and oola.schedule_ship_date <= lp_date_last;
			   update xxha_order_status_summary
			   set    today_bk = lp_count
			   		  , last_update_date = sysdate
					  , last_updated_by = fnd_global.user_id
					  , last_update_login = fnd_global.login_id
			   where  week_number = lp_loop_check;
			   lp_loop_check := lp_loop_check + 1;
			   if lp_loop_check > lp_max_weeks then
			   	  lp_loop_check := 0;
			   end if;			   
		   end if;
     end loop;
	 commit;	 	 
end order_lines_bk;
procedure order_lines_rr
as
lp_loop_check number := 1;
lp_ship_date date;
lp_count number;
lp_date_first date;
lp_date_last date;
lp_max_weeks number;
lp_date_temp date;
lp_days number;
cursor c_day_count is
	   select today_rr
	   		  , yesterday_rr 
			  , week_number
	   from   xxha_order_status_summary
	   order by week_number asc;
begin
	 select max(week_number)
	 into   lp_max_weeks
	 from   xxha_order_status_summary;
	 begin
  	 	  select distinct trunc(last_run_date)
  	 	  into   lp_date_temp
  	 	  from   xxha_order_status_summary;
	 exception
	 		  when others then
  	 	  	  	   select distinct trunc(last_run_date)
  	 	  		   into   lp_date_temp
  	 	  		   from   xxha_order_status_summary
  	 	  		   where  last_run_date is not null;
	 end;
	 if trunc(sysdate) = lp_date_temp then
	 	null;
	 elsif trunc(sysdate) > lp_date_temp then
	 	lp_days := trunc(sysdate) - lp_date_temp;
		if lp_days <= 2 and lp_days <> 0 then
		   if lp_days = 1 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_rr = r_day_count.yesterday_rr
				  		 , yesterday_rr = r_day_count.today_rr
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   elsif lp_days = 2 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_rr = r_day_count.today_rr
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   end if;
		end if;
	 end if;
	 while lp_loop_check <> 0 loop
	 	   if lp_loop_check = 1 then
		   	     select week_schedule_ship_date 
				 into   lp_ship_date
				 from   xxha_order_status_summary
				 where  week_number = lp_loop_check;
		   	  	 select count(oola.line_id)
				 into   lp_count
	 			 from   oe_order_lines_all oola
	 			 		, oe_order_headers_all ooha
						, wsh_delivery_details wdd
						, wsh_deliverables_v wdv
	 			 where  oola.header_id = ooha.header_id
	 			 		and ooha.flow_status_code in ('BOOKED', 'ENTERED')
						and oola.cancelled_flag <> 'Y'
						and ooha.cancelled_flag <> 'Y'
						and oola.header_id = wdd.source_header_id (+)
						and oola.org_id = wdd.org_id (+)
						and oola.line_id = wdd.source_line_id (+)
						and wdv.delivery_detail_id = wdd.delivery_detail_id
						and wdv.released_status_name = 'Ready to Release'
						and oola.schedule_ship_date <= lp_ship_date;
				 update xxha_order_status_summary
				 set    today_rr = lp_count
				 		, last_update_date = sysdate
						, last_updated_by = fnd_global.user_id
						, last_update_login = fnd_global.login_id
				 where  week_number = lp_loop_check;
				 lp_loop_check := lp_loop_check + 1;
		   else
			   select week_schedule_ship_date
			   into   lp_date_first
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check - 1;
			   select week_schedule_ship_date
			   into   lp_date_last
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check;
			   select count(oola.line_id)
			   into   lp_count
	 		   from   oe_order_lines_all oola
	 		   		  , oe_order_headers_all ooha
					  , wsh_delivery_details wdd
					  , wsh_deliverables_v wdv
	 		   where  oola.header_id = ooha.header_id
	 		   		  and ooha.flow_status_code in ('BOOKED', 'ENTERED')
					  and oola.cancelled_flag <> 'Y'
					  and ooha.cancelled_flag <> 'Y'
					  and oola.header_id = wdd.source_header_id (+)
					  and oola.org_id = wdd.org_id (+)
					  and oola.line_id = wdd.source_line_id (+)
					  and wdv.delivery_detail_id = wdd.delivery_detail_id
					  and wdv.released_status_name = 'Ready to Release'
					  and oola.schedule_ship_date > lp_date_first
					  and oola.schedule_ship_date <= lp_date_last;
			   update xxha_order_status_summary
			   set    today_rr = lp_count
			   		  , last_update_date = sysdate
					  , last_updated_by = fnd_global.user_id
					  , last_update_login = fnd_global.login_id
			   where  week_number = lp_loop_check;
			   lp_loop_check := lp_loop_check + 1;
			   if lp_loop_check > lp_max_weeks then
			   	  lp_loop_check := 0;
			   end if;			   
		   end if;
     end loop;
	 commit;	 	 
end order_lines_rr;
procedure order_lines_rw
as
lp_loop_check number := 1;
lp_ship_date date;
lp_count number;
lp_date_first date;
lp_date_last date;
lp_max_weeks number;
lp_date_temp date;
lp_days number;
cursor c_day_count is
	   select today_rw
	   		  , yesterday_rw 
			  , week_number
	   from   xxha_order_status_summary
	   order by week_number asc;
begin
	 select max(week_number)
	 into   lp_max_weeks
	 from   xxha_order_status_summary;
	 begin
  	 	  select distinct trunc(last_run_date)
  	 	  into   lp_date_temp
  	 	  from   xxha_order_status_summary;
	 exception
	 		  when others then
  	 	  	  	   select distinct trunc(last_run_date)
  	 	  		   into   lp_date_temp
  	 	  		   from   xxha_order_status_summary
  	 	  		   where  last_run_date is not null;
	 end;
	 if trunc(sysdate) = lp_date_temp then
	 	null;
	 elsif trunc(sysdate) > lp_date_temp then
	 	lp_days := trunc(sysdate) - lp_date_temp;
		if lp_days <= 2 and lp_days <> 0 then
		   if lp_days = 1 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_rw = r_day_count.yesterday_rw
				  		 , yesterday_rw = r_day_count.today_rw
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   elsif lp_days = 2 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_rw = r_day_count.today_rw
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   end if;
		end if;
	 end if;
	 while lp_loop_check <> 0 loop
	 	   if lp_loop_check = 1 then
		   	     select week_schedule_ship_date 
				 into   lp_ship_date
				 from   xxha_order_status_summary
				 where  week_number = lp_loop_check;
		   	  	 select count(oola.line_id)
				 into   lp_count
	 			 from   oe_order_lines_all oola
	 			 		, oe_order_headers_all ooha
						, wsh_delivery_details wdd
						, wsh_deliverables_v wdv
	 			 where  oola.header_id = ooha.header_id
	 			 		and ooha.flow_status_code in ('BOOKED', 'ENTERED')
						and oola.cancelled_flag <> 'Y'
						and ooha.cancelled_flag <> 'Y'
						and oola.header_id = wdd.source_header_id (+)
						and oola.org_id = wdd.org_id (+)
						and oola.line_id = wdd.source_line_id (+)
						and wdv.delivery_detail_id = wdd.delivery_detail_id
						and wdv.released_status_name = 'Released to Warehouse'
						and oola.schedule_ship_date <= lp_ship_date;
				 update xxha_order_status_summary
				 set    today_rw = lp_count
				 		, last_update_date = sysdate
						, last_updated_by = fnd_global.user_id
						, last_update_login = fnd_global.login_id
				 where  week_number = lp_loop_check;
				 lp_loop_check := lp_loop_check + 1;
		   else
			   select week_schedule_ship_date
			   into   lp_date_first
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check - 1;
			   select week_schedule_ship_date
			   into   lp_date_last
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check;
			   select count(oola.line_id)
			   into   lp_count
	 		   from   oe_order_lines_all oola
	 		   		  , oe_order_headers_all ooha
					  , wsh_delivery_details wdd
					  , wsh_deliverables_v wdv
	 		   where  oola.header_id = ooha.header_id
	 		   		  and ooha.flow_status_code in ('BOOKED', 'ENTERED')
					  and oola.cancelled_flag <> 'Y'
					  and ooha.cancelled_flag <> 'Y'
					  and oola.header_id = wdd.source_header_id (+)
					  and oola.org_id = wdd.org_id (+)
					  and oola.line_id = wdd.source_line_id (+)
					  and wdv.delivery_detail_id = wdd.delivery_detail_id
					  and wdv.released_status_name = 'Released to Warehouse'
					  and oola.schedule_ship_date > lp_date_first
					  and oola.schedule_ship_date <= lp_date_last;
			   update xxha_order_status_summary
			   set    today_rw = lp_count
			   		  , last_update_date = sysdate
					  , last_updated_by = fnd_global.user_id
					  , last_update_login = fnd_global.login_id
			   where  week_number = lp_loop_check;
			   lp_loop_check := lp_loop_check + 1;
			   if lp_loop_check > lp_max_weeks then
			   	  lp_loop_check := 0;
			   end if;			   
		   end if;
     end loop;
	 commit;	 	 
end order_lines_rw;
procedure order_lines_pc
as
lp_loop_check number := 1;
lp_ship_date date;
lp_count number;
lp_date_first date;
lp_date_last date;
lp_max_weeks number;
lp_date_temp date;
lp_days number;
cursor c_day_count is
	   select today_pc
	   		  , yesterday_pc 
			  , week_number
	   from   xxha_order_status_summary
	   order by week_number asc;
begin
	 select max(week_number)
	 into   lp_max_weeks
	 from   xxha_order_status_summary;
	 begin
  	 	  select distinct trunc(last_run_date)
  	 	  into   lp_date_temp
  	 	  from   xxha_order_status_summary;
	 exception
	 		  when others then
  	 	  	  	   select distinct trunc(last_run_date)
  	 	  		   into   lp_date_temp
  	 	  		   from   xxha_order_status_summary
  	 	  		   where  last_run_date is not null;
	 end;
	 if trunc(sysdate) = lp_date_temp then
	 	null;
	 elsif trunc(sysdate) > lp_date_temp then
	 	lp_days := trunc(sysdate) - lp_date_temp;
		if lp_days <= 2 and lp_days <> 0 then
		   if lp_days = 1 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_pc = r_day_count.yesterday_pc
				  		 , yesterday_pc = r_day_count.today_pc
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   elsif lp_days = 2 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_pc = r_day_count.today_pc
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   end if;
		end if;
	 end if;
	 while lp_loop_check <> 0 loop
	 	   if lp_loop_check = 1 then
		   	     select week_schedule_ship_date 
				 into   lp_ship_date
				 from   xxha_order_status_summary
				 where  week_number = lp_loop_check;
		   	  	 select count(oola.line_id)
				 into   lp_count
	 			 from   oe_order_lines_all oola
	 			 		, oe_order_headers_all ooha
						, wsh_delivery_details wdd
						, wsh_deliverables_v wdv
	 			 where  oola.header_id = ooha.header_id
	 			 		and ooha.flow_status_code in ('BOOKED', 'ENTERED')
						and oola.cancelled_flag <> 'Y'
						and ooha.cancelled_flag <> 'Y'
						and oola.header_id = wdd.source_header_id (+)
						and oola.org_id = wdd.org_id (+)
						and oola.line_id = wdd.source_line_id (+)
						and wdv.delivery_detail_id = wdd.delivery_detail_id
						and wdv.released_status_name = 'Staged/Pick Confirmed'
						and oola.schedule_ship_date <= lp_ship_date;
				 update xxha_order_status_summary
				 set    today_pc = lp_count
				 		, last_update_date = sysdate
						, last_updated_by = fnd_global.user_id
						, last_update_login = fnd_global.login_id
				 where  week_number = lp_loop_check;
				 lp_loop_check := lp_loop_check + 1;
		   else
			   select week_schedule_ship_date
			   into   lp_date_first
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check - 1;
			   select week_schedule_ship_date
			   into   lp_date_last
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check;
			   select count(oola.line_id)
			   into   lp_count
	 		   from   oe_order_lines_all oola
	 		   		  , oe_order_headers_all ooha
					  , wsh_delivery_details wdd
					  , wsh_deliverables_v wdv
	 		   where  oola.header_id = ooha.header_id
	 		   		  and ooha.flow_status_code in ('BOOKED', 'ENTERED')
					  and oola.cancelled_flag <> 'Y'
					  and ooha.cancelled_flag <> 'Y'
					  and oola.header_id = wdd.source_header_id (+)
					  and oola.org_id = wdd.org_id (+)
					  and oola.line_id = wdd.source_line_id (+)
					  and wdv.delivery_detail_id = wdd.delivery_detail_id
					  and wdv.released_status_name = 'Staged/Pick Confirmed'
					  and oola.schedule_ship_date > lp_date_first
					  and oola.schedule_ship_date <= lp_date_last;
			   update xxha_order_status_summary
			   set    today_pc = lp_count
			   		  , last_update_date = sysdate
					  , last_updated_by = fnd_global.user_id
					  , last_update_login = fnd_global.login_id
			   where  week_number = lp_loop_check;
			   lp_loop_check := lp_loop_check + 1;
			   if lp_loop_check > lp_max_weeks then
			   	  lp_loop_check := 0;
			   end if;			   
		   end if;
     end loop;
	 commit;	 	 
end order_lines_pc;
procedure order_lines_sni
as
lp_loop_check number := 1;
lp_ship_date date;
lp_count number;
lp_date_first date;
lp_date_last date;
lp_max_weeks number;
lp_date_temp date;
lp_days number;
cursor c_day_count is
	   select today_sni
	   		  , yesterday_sni 
			  , week_number
	   from   xxha_order_status_summary
	   order by week_number asc;
begin
	 select max(week_number)
	 into   lp_max_weeks
	 from   xxha_order_status_summary;
	 begin
  	 	  select distinct trunc(last_run_date)
  	 	  into   lp_date_temp
  	 	  from   xxha_order_status_summary;
	 exception
	 		  when others then
  	 	  	  	   select distinct trunc(last_run_date)
  	 	  		   into   lp_date_temp
  	 	  		   from   xxha_order_status_summary
  	 	  		   where  last_run_date is not null;
	 end;
	 if trunc(sysdate) = lp_date_temp then
	 	null;
	 elsif trunc(sysdate) > lp_date_temp then
	 	lp_days := trunc(sysdate) - lp_date_temp;
		if lp_days <= 2 and lp_days <> 0 then
		   if lp_days = 1 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_sni = r_day_count.yesterday_sni
				  		 , yesterday_sni = r_day_count.today_sni
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   elsif lp_days = 2 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_sni = r_day_count.today_sni
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   end if;
		end if;
	 end if;
	 while lp_loop_check <> 0 loop
	 	   if lp_loop_check = 1 then
		   	     select week_schedule_ship_date 
				 into   lp_ship_date
				 from   xxha_order_status_summary
				 where  week_number = lp_loop_check;
		   	  	 select count(oola.line_id)
				 into   lp_count
	 			 from   oe_order_lines_all oola
	 			 		, oe_order_headers_all ooha
						, wsh_delivery_details wdd
						, wsh_deliverables_v wdv
	 			 where  oola.header_id = ooha.header_id
	 			 		and ooha.flow_status_code in ('BOOKED', 'ENTERED')
						and oola.cancelled_flag <> 'Y'
						and ooha.cancelled_flag <> 'Y'
						and oola.header_id = wdd.source_header_id (+)
						and oola.org_id = wdd.org_id (+)
						and oola.line_id = wdd.source_line_id (+)
						and wdv.delivery_detail_id = wdd.delivery_detail_id
						and wdv.released_status_name = 'Shipped'
						and nvl(wdv.inv_interfaced_flag, 'N') <> 'Y'
						and oola.schedule_ship_date <= lp_ship_date;
				 update xxha_order_status_summary
				 set    today_sni = lp_count
				 		, last_update_date = sysdate
						, last_updated_by = fnd_global.user_id
						, last_update_login = fnd_global.login_id
				 where  week_number = lp_loop_check;
				 lp_loop_check := lp_loop_check + 1;
		   else
			   select week_schedule_ship_date
			   into   lp_date_first
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check - 1;
			   select week_schedule_ship_date
			   into   lp_date_last
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check;
			   select count(oola.line_id)
			   into   lp_count
	 		   from   oe_order_lines_all oola
	 		   		  , oe_order_headers_all ooha
					  , wsh_delivery_details wdd
					  , wsh_deliverables_v wdv
	 		   where  oola.header_id = ooha.header_id
	 		   		  and ooha.flow_status_code in ('BOOKED', 'ENTERED')
					  and oola.cancelled_flag <> 'Y'
					  and ooha.cancelled_flag <> 'Y'
					  and oola.header_id = wdd.source_header_id (+)
					  and oola.org_id = wdd.org_id (+)
					  and oola.line_id = wdd.source_line_id (+)
					  and wdv.delivery_detail_id = wdd.delivery_detail_id
					  and wdv.released_status_name = 'Shipped'
					  and nvl(wdv.inv_interfaced_flag, 'N') <> 'Y'
					  and oola.schedule_ship_date > lp_date_first
					  and oola.schedule_ship_date <= lp_date_last;
			   update xxha_order_status_summary
			   set    today_sni = lp_count
			   		  , last_update_date = sysdate
					  , last_updated_by = fnd_global.user_id
					  , last_update_login = fnd_global.login_id
			   where  week_number = lp_loop_check;
			   lp_loop_check := lp_loop_check + 1;
			   if lp_loop_check > lp_max_weeks then
			   	  lp_loop_check := 0;
			   end if;			   
		   end if;
     end loop;
	 commit;	 	 
end order_lines_sni;
procedure order_lines_si
as
lp_loop_check number := 1;
lp_ship_date date;
lp_count number;
lp_date_first date;
lp_date_last date;
lp_max_weeks number;
lp_date_temp date;
lp_days number;
cursor c_day_count is
	   select today_i
	   		  , yesterday_i 
			  , week_number
	   from   xxha_order_status_summary
	   order by week_number asc;
begin
	 select max(week_number)
	 into   lp_max_weeks
	 from   xxha_order_status_summary;
	 begin
  	 	  select distinct trunc(last_run_date)
  	 	  into   lp_date_temp
  	 	  from   xxha_order_status_summary;
	 exception
	 		  when others then
  	 	  	  	   select distinct trunc(last_run_date)
  	 	  		   into   lp_date_temp
  	 	  		   from   xxha_order_status_summary
  	 	  		   where  last_run_date is not null;
	 end;
	 if trunc(sysdate) = lp_date_temp then
	 	null;
	 elsif trunc(sysdate) > lp_date_temp then
	 	lp_days := trunc(sysdate) - lp_date_temp;
		if lp_days <= 2 and lp_days <> 0 then
		   if lp_days = 1 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_i = r_day_count.yesterday_i
				  		 , yesterday_i = r_day_count.today_i
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   elsif lp_days = 2 then
		   	  for r_day_count in c_day_count loop
			  	  update xxha_order_status_summary
				  set    day_before_yesterday_i = r_day_count.today_i
						 , last_update_date = sysdate
						 , last_updated_by = fnd_global.user_id
						 , last_update_login = fnd_global.login_id
				  where  week_number = r_day_count.week_number;
			  end loop;
		   end if;
		end if;
	 end if;
	 while lp_loop_check <> 0 loop
	 	   if lp_loop_check = 1 then
		   	     select week_schedule_ship_date 
				 into   lp_ship_date
				 from   xxha_order_status_summary
				 where  week_number = lp_loop_check;
				 select count(oola.line_id)
				 into   lp_count
	 			 from   oe_order_lines_all oola
	 			 		, oe_order_headers_all ooha
						, wsh_delivery_details wdd
						, wsh_deliverables_v wdv
	 			 where  oola.header_id = ooha.header_id
	 			 		and ooha.flow_status_code in ('BOOKED', 'ENTERED')
						and oola.cancelled_flag <> 'Y'
						and ooha.cancelled_flag <> 'Y'
						and oola.header_id = wdd.source_header_id (+)
						and oola.org_id = wdd.org_id (+)
						and oola.line_id = wdd.source_line_id (+)
						and wdv.delivery_detail_id = wdd.delivery_detail_id
						and wdv.released_status_name = 'Shipped'
						and nvl(wdv.inv_interfaced_flag, 'N') = 'Y'
						and oola.schedule_ship_date <= lp_ship_date;
				 update xxha_order_status_summary
				 set    today_i = lp_count
				 		, last_update_date = sysdate
						, last_updated_by = fnd_global.user_id
						, last_update_login = fnd_global.login_id
				 where  week_number = lp_loop_check;
				 lp_loop_check := lp_loop_check + 1;
		   else
			   select week_schedule_ship_date
			   into   lp_date_first
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check - 1;
			   select week_schedule_ship_date
			   into   lp_date_last
			   from   xxha_order_status_summary
			   where  week_number = lp_loop_check;
			   select count(oola.line_id)
			   into   lp_count
	 		   from   oe_order_lines_all oola
	 		   		  , oe_order_headers_all ooha
					  , wsh_delivery_details wdd
					  , wsh_deliverables_v wdv
	 		   where  oola.header_id = ooha.header_id
	 		   		  and ooha.flow_status_code in ('BOOKED', 'ENTERED')
					  and oola.cancelled_flag <> 'Y'
					  and ooha.cancelled_flag <> 'Y'
					  and oola.header_id = wdd.source_header_id (+)
					  and oola.org_id = wdd.org_id (+)
					  and oola.line_id = wdd.source_line_id (+)
					  and wdv.delivery_detail_id = wdd.delivery_detail_id
					  and wdv.released_status_name = 'Shipped'
					  and nvl(wdv.inv_interfaced_flag, 'N') = 'Y'
					  and oola.schedule_ship_date > lp_date_first
					  and oola.schedule_ship_date <= lp_date_last;
			   update xxha_order_status_summary
			   set    today_i = lp_count
			   		  , last_update_date = sysdate
					  , last_updated_by = fnd_global.user_id
					  , last_update_login = fnd_global.login_id
			   where  week_number = lp_loop_check;
			   lp_loop_check := lp_loop_check + 1;
			   if lp_loop_check > lp_max_weeks then
			   	  lp_loop_check := 0;
			   end if;			   
		   end if;
     end loop;
	 commit;	 	 
end order_lines_si;
procedure org_order_lines_all
is
cursor c_org_id 
is
  select distinct organization_id
  from   xxha_order_status_summary_org;
lp_count number;
lp_check number;
lp_date_difference number;
lp_last_run_date_org date;
begin
	 begin
	 	  select distinct last_run_date
	 	  into   lp_last_run_date_org
	 	  from   xxha_order_status_summary_org;
	 exception
	 		  when others then
			  	   lp_last_run_date_org := null;
	 end;
	 if lp_last_run_date_org is null then
	 	lp_check := 1;
     else
	 	 lp_check := 0;
     end if;
	 if lp_last_run_date_org < trunc(sysdate) then
	 	lp_date_difference := trunc(sysdate) - lp_last_run_date_org;
		if lp_date_difference <= 2 then
		   if lp_date_difference = 2 then
		   	  update xxha_order_status_summary_org
			  set    day_before_yesterday_oo = today_oo;
		   elsif lp_date_difference = 1 then
		   	  update xxha_order_status_summary_org
			  set    day_before_yesterday_oo = yesterday_oo
			  		 , yesterday_oo = today_oo;
		   end if;
		end if;
      end if;
	  if lp_check = 1 or lp_check = 0 then	  	
		for r_org_id in c_org_id loop
			select count(oola.line_id)
			into   lp_count
			from   oe_order_lines_all oola
	 	   	   	   , oe_order_headers_all ooha
		   	   	   , wsh_delivery_details wdd
		   	   	   , wsh_deliverables_v wdv
			where  oola.header_id = ooha.header_id
	 	   	   	   and ooha.flow_status_code in ('BOOKED', 'ENTERED')
		   	   	   and oola.cancelled_flag <> 'Y'
		   	   	   and ooha.cancelled_flag <> 'Y'
		   	   	   and oola.header_id = wdd.source_header_id (+)
		   	   	   and oola.org_id = wdd.org_id (+)
		   	   	   and oola.line_id = wdd.source_line_id (+)
		   	   	   and wdv.delivery_detail_id = wdd.delivery_detail_id
		   	   	   and wdv.released_status_name <> 'Shipped'
		   	   	   and trunc(oola.schedule_ship_date) < trunc(sysdate)
			   	   and oola.ship_from_org_id = r_org_id.organization_id;
		    update xxha_order_status_summary_org
			set    today_oo = lp_count
			   	   , last_updated_by = fnd_global.user_id
			   	   , last_update_date = sysdate
			   	   , last_update_login = fnd_global.login_id
			where  organization_id = r_org_id.organization_id;
	 	end loop;
      end if;
end org_order_lines_all;
procedure org_order_lines_bk
is
cursor c_org_id 
is
  select distinct organization_id
  from   xxha_order_status_summary_org;
lp_count number;
lp_check number;
lp_date_difference number;
lp_last_run_date_org date;
begin
	 begin
	 	  select distinct last_run_date
	 	  into   lp_last_run_date_org
	 	  from   xxha_order_status_summary_org;
	 exception
	 		  when others then
			  	   lp_last_run_date_org := null;
	 end;
	 if lp_last_run_date_org is null then
	 	lp_check := 1;
     else
	 	 lp_check := 0;
     end if;
	 if lp_last_run_date_org < trunc(sysdate) then
	 	lp_date_difference := trunc(sysdate) - lp_last_run_date_org;
		if lp_date_difference <= 2 then
		   if lp_date_difference = 2 then
		   	  update xxha_order_status_summary_org
			  set    day_before_yesterday_bk = today_bk;
		   elsif lp_date_difference = 1 then
		   	  update xxha_order_status_summary_org
			  set    day_before_yesterday_bk = yesterday_bk
			  		 , yesterday_bk = today_bk;
		   end if;
		end if;
      end if;
	  if lp_check = 1 or lp_check = 0 then	  	
		for r_org_id in c_org_id loop
			select count(oola.line_id)
			into   lp_count
			from   oe_order_lines_all oola
	 	   	   	   , oe_order_headers_all ooha
		   	   	   , wsh_delivery_details wdd
		   	   	   , wsh_deliverables_v wdv
			where  oola.header_id = ooha.header_id
	 	   	   	   and ooha.flow_status_code in ('BOOKED', 'ENTERED')
		   	   	   and oola.cancelled_flag <> 'Y'
		   	   	   and ooha.cancelled_flag <> 'Y'
		   	   	   and oola.header_id = wdd.source_header_id (+)
		   	   	   and oola.org_id = wdd.org_id (+)
		   	   	   and oola.line_id = wdd.source_line_id (+)
		   	   	   and wdv.delivery_detail_id = wdd.delivery_detail_id
		   	   	   and wdv.released_status_name = 'Backordered'
		   	   	   and trunc(oola.schedule_ship_date) < trunc(sysdate)
			   	   and oola.ship_from_org_id = r_org_id.organization_id;
		    update xxha_order_status_summary_org
			set    today_bk = lp_count
			   	   , last_updated_by = fnd_global.user_id
			   	   , last_update_date = sysdate
			   	   , last_update_login = fnd_global.login_id
			where  organization_id = r_org_id.organization_id;
	 	end loop;
      end if;
end org_order_lines_bk;
procedure org_order_lines_pc
is
cursor c_org_id 
is
  select distinct organization_id
  from   xxha_order_status_summary_org;
lp_count number;
lp_check number;
lp_date_difference number;
lp_last_run_date_org date;
begin
	 begin
	 	  select distinct last_run_date
	 	  into   lp_last_run_date_org
	 	  from   xxha_order_status_summary_org;
	 exception
	 		  when others then
			  	   lp_last_run_date_org := null;
	 end;
	 if lp_last_run_date_org is null then
	 	lp_check := 1;
     else
	 	 lp_check := 0;
     end if;
	 if lp_last_run_date_org < trunc(sysdate) then
	 	lp_date_difference := trunc(sysdate) - lp_last_run_date_org;
		if lp_date_difference <= 2 then
		   if lp_date_difference = 2 then
		   	  update xxha_order_status_summary_org
			  set    day_before_yesterday_pc = today_pc;
		   elsif lp_date_difference = 1 then
		   	  update xxha_order_status_summary_org
			  set    day_before_yesterday_pc = yesterday_pc
			  		 , yesterday_pc = today_pc;
		   end if;
		end if;
      end if;
	  if lp_check = 1 or lp_check = 0 then	  	
		for r_org_id in c_org_id loop
			select count(oola.line_id)
			into   lp_count
			from   oe_order_lines_all oola
	 	   	   	   , oe_order_headers_all ooha
		   	   	   , wsh_delivery_details wdd
		   	   	   , wsh_deliverables_v wdv
			where  oola.header_id = ooha.header_id
	 	   	   	   and ooha.flow_status_code in ('BOOKED', 'ENTERED')
		   	   	   and oola.cancelled_flag <> 'Y'
		   	   	   and ooha.cancelled_flag <> 'Y'
		   	   	   and oola.header_id = wdd.source_header_id (+)
		   	   	   and oola.org_id = wdd.org_id (+)
		   	   	   and oola.line_id = wdd.source_line_id (+)
		   	   	   and wdv.delivery_detail_id = wdd.delivery_detail_id
		   	   	   and wdv.released_status_name = 'Staged/Pick Confirmed'
		   	   	   and trunc(oola.schedule_ship_date) < trunc(sysdate)
			   	   and oola.ship_from_org_id = r_org_id.organization_id;
		    update xxha_order_status_summary_org
			set    today_pc = lp_count
			   	   , last_updated_by = fnd_global.user_id
			   	   , last_update_date = sysdate
			   	   , last_update_login = fnd_global.login_id
			where  organization_id = r_org_id.organization_id;
	 	end loop;
      end if;
end org_order_lines_pc;
procedure ou_order_lines_stat
is
lp_order_header_cnt number;
lp_order_line_cnt number;
cursor c_ou_list
is
   select organization_name
   		  , organization_id
   from   xxha_order_status_summary_ou;
begin
	 for r_ou_list in c_ou_list loop
	 	 select count(distinct ooha.header_id)
		 		, count(distinct oola.line_id)
 	 	 into   lp_order_header_cnt
 		 		, lp_order_line_cnt
	 	 from   oe_order_lines_all oola
		 		, oe_order_headers_all ooha
		 where  oola.header_id = ooha.header_id
		 		and ooha.org_id = r_ou_list.organization_id
				and ooha.ordered_date <= sysdate;
		 update xxha_order_status_summary_ou
		 set    total_orders = lp_order_header_cnt
		 		, total_lines = lp_order_line_cnt
				, last_updated_by = fnd_global.user_id
				, last_update_date = sysdate
				, last_update_login = fnd_global.login_id
		 where  organization_id = r_ou_list.organization_id;
	 end loop;
end ou_order_lines_stat;
procedure ou_avg_stats
is
lp_start_date date;
lp_holidays number;
lp_total_days number;
lp_working_days number;
lp_total_orders number;
lp_total_lines number;
cursor c_ou_list
is
   select organization_name
   		  , organization_id
   from   xxha_order_status_summary_ou; 
begin
	 for r_ou_list in c_ou_list loop
	 	 select min(trunc(ordered_date))
	     into   lp_start_date
	     from   oe_order_headers_all
		 where  org_id = r_ou_list.organization_id;
		 select count(*)
		 into   lp_holidays
		 from   bom_calendar_dates
		 where  calendar_date >= lp_start_date
		 		and calendar_date <= trunc(sysdate)
				and seq_num is null;
		 select count(*)
		 into   lp_total_days
		 from   bom_calendar_dates
		 where  calendar_date >= lp_start_date
		 		and calendar_date <= trunc(sysdate);
		 lp_working_days := lp_total_days - lp_holidays;
		 update xxha_order_status_summary_ou
		 set    week_days = lp_working_days
				, last_updated_by = fnd_global.user_id
				, last_update_date = sysdate
				, last_update_login = fnd_global.login_id		 
		 where  organization_id = r_ou_list.organization_id;
		 select total_orders
		 		, total_lines
		 into   lp_total_orders
		 		, lp_total_lines
	     from   xxha_order_status_summary_ou
		 where  organization_id = r_ou_list.organization_id;
		 if lp_total_orders <> 0 and lp_working_days <> 0 then
		 	update xxha_order_status_summary_ou
		 	set    avg_order_pd = round((lp_total_orders/lp_working_days), 2)
				   , last_updated_by = fnd_global.user_id
				   , last_update_date = sysdate
				   , last_update_login = fnd_global.login_id
		 	where  organization_id = r_ou_list.organization_id;
		 else
		 	update xxha_order_status_summary_ou
		 	set    avg_order_pd = 0			
				   , last_updated_by = fnd_global.user_id
				   , last_update_date = sysdate
				   , last_update_login = fnd_global.login_id
		 	where  organization_id = r_ou_list.organization_id;
		 end if;
		 if lp_total_orders <> 0 and lp_total_lines <> 0 then
		 	update xxha_order_status_summary_ou
		 	set    avg_lines_po = round((lp_total_lines/lp_total_orders), 2)
				   , last_updated_by = fnd_global.user_id
				   , last_update_date = sysdate
				   , last_update_login = fnd_global.login_id
		 	where  organization_id = r_ou_list.organization_id;
		 else 	
		 	update xxha_order_status_summary_ou
		 	set    avg_lines_po = 0
				   , last_updated_by = fnd_global.user_id
				   , last_update_date = sysdate
				   , last_update_login = fnd_global.login_id
		 	where  organization_id = r_ou_list.organization_id;
		 end if;
	 end loop;
end ou_avg_stats;
procedure summary_main(errbuf varchar2, retcode varchar2)
as
lp_schedule_ship_date_first date;
lp_sch_ship_date_last date;
lp_loop_check number := 1;
lp_date_temp date;
lp_date_check date;
lp_sch_ship_date_first_org date;
lp_sch_ship_date_last_org date;
lp_loop_check_org number := 1;
lp_date_temp_org date;
lp_date_check_org date;
lp_last_run_date date;
lp_last_run_date_org date;
lp_last_run_date_ou date;
cursor c_org_names
is
  select distinct organization_code
  		 , organization_name
		 , organization_id
  from   org_organization_definitions;
cursor c_org_dif
is 
   select distinct organization_code
   		  , organization_name
		  , organization_id
   from   org_organization_definitions ood
   where  not exists 
		  (select distinct organization_code
		   		  , organization_name
				  , organization_id
		   from   xxha_order_status_summary_org xxha
		   where  ood.organization_id = xxha.organization_id);
cursor c_ou_details
is
  select name
  		 , organization_id
  from   hr_operating_units;
begin
	 begin
	 	  select distinct trunc(last_run_date)
	 	  into   lp_last_run_date
	 	  from   xxha_order_status_summary;
	 exception
	 	  when others then
			   lp_last_run_date := null;
	 end;
	 if lp_last_run_date < trunc(sysdate) or lp_last_run_date is null then
	 	select decode((next_day(min(schedule_ship_date), 'FRIDAY') - min(schedule_ship_date)), 7, min(schedule_ship_date)
 											   			   						      	  	 , next_day(min(schedule_ship_date), 'FRIDAY'))
     	into   lp_schedule_ship_date_first
 	 	from   oe_order_lines_all
 	 	where  schedule_ship_date is not null;
	 	select decode((next_day(max(schedule_ship_date), 'FRIDAY') - max(schedule_ship_date)), 7, max(schedule_ship_date)
	 											   			   						         , next_day(max(schedule_ship_date), 'FRIDAY'))
	    into   lp_sch_ship_date_last
  	 	from   oe_order_lines_all
  	 	where  schedule_ship_date is not null;
	 	begin
	 	  	 select max(week_schedule_ship_date)
		  		 	, max(week_number)
 	 	     into   lp_date_check
 		  		 	, lp_loop_check
	 	     from   xxha_order_status_summary;
	    exception
	 	  	 when others then
		  	   lp_date_check := null;
	 	end;
	 	if lp_date_check is not null and lp_loop_check is not null and lp_sch_ship_date_last > lp_date_check then		
		   while lp_date_check <= lp_sch_ship_date_last loop
			  	 insert into xxha_order_status_summary
			  		 	  	 (week_schedule_ship_date
						   	  , week_number
						   	  , creation_date
						   	  , created_by
						   	  , last_update_date
						   	  , last_updated_by
						   	  , last_update_login)
			     values (lp_date_check + 7
			    	  	 , lp_loop_check + 1
					  	 , sysdate, fnd_global.user_id, sysdate, fnd_global.user_id, fnd_global.login_id);
		 	     lp_date_check := lp_date_check + 7;
		 	  	 lp_loop_check := lp_loop_check + 1;
		   end loop;
	    elsif lp_date_check is null and lp_loop_check is null then
	 		  lp_loop_check := 1;
	 		  while lp_loop_check <> 0 loop
	 	   	  		insert into xxha_order_status_summary
			  		 	   (week_schedule_ship_date
						   	, week_number
						   	, creation_date
						   	, created_by
						   	, last_update_date
						   	, last_updated_by
						   	, last_update_login)
	 	   	        values (trunc(lp_schedule_ship_date_first)
		   		   	  	    , lp_loop_check
				   	  	    , sysdate, fnd_global.user_id, sysdate, fnd_global.user_id, fnd_global.login_id);
		   	  	    lp_loop_check := lp_loop_check + 1;
		   	  		select lp_schedule_ship_date_first + 7
		   	  		into   lp_date_temp
		   	  		from   dual;
		   	  		lp_schedule_ship_date_first := lp_date_temp;		  
		   	  		if lp_schedule_ship_date_first > lp_sch_ship_date_last then
		   	  	 	   lp_loop_check := 0;
		   	  		end if;
	 	      end loop;
        end if;
	    xx_haemo_order_status_summary.order_lines_all;
		xx_haemo_order_status_summary.order_lines_bk;
		xx_haemo_order_status_summary.order_lines_rr;
		xx_haemo_order_status_summary.order_lines_rw;
		xx_haemo_order_status_summary.order_lines_pc;
		xx_haemo_order_status_summary.order_lines_sni;
		xx_haemo_order_status_summary.order_lines_si;
	 else
	 	 dbms_output.put_line('This process (Order Lines Summary for all Organizations) has already been run once, it is scheduled to run again');
	 end if;
	 update xxha_order_status_summary
	 set    last_run_date = trunc(sysdate)
			, last_updated_by = fnd_global.user_id
			, last_update_date = sysdate
			, last_update_login = fnd_global.login_id;
	 commit;
	 begin
	 	 select trunc(last_run_date)
	 	 into   lp_last_run_date_org
	 	 from   xxha_order_status_summary_org;
	 exception
	 	 when others then
		 	  lp_last_run_date_org := null;
	 end;
	 if lp_last_run_date is null then
	 	for r_org_names in c_org_names loop
	 		insert into xxha_order_status_summary_org
		 			 (organization_code
					  , organization_name
					  , creation_date
					  , created_by
					  , last_update_date
					  , last_updated_by
					  , last_update_login
					  , organization_id
					 )
		 	values (r_org_names.organization_code
		 		 , r_org_names.organization_name
				 , sysdate
				 , fnd_global.user_id
				 , sysdate
				 , fnd_global.user_id
				 , fnd_global.login_id
				 , r_org_names.organization_id
				);
	 	end loop;
	 else
	 	 dbms_output.put_line('All Organizations have been loaded, there are no more to load');
	 end if;
	 xx_haemo_order_status_summary.org_order_lines_all;
	 xx_haemo_order_status_summary.org_order_lines_bk;
	 xx_haemo_order_status_summary.org_order_lines_pc;
	 update xxha_order_status_summary_org
	 set    last_run_date = trunc(sysdate)
			, last_updated_by = fnd_global.user_id
			, last_update_date = sysdate
			, last_update_login = fnd_global.login_id;
	 commit;
	 begin
	 	  select distinct trunc(last_run_date)
	 	  into   lp_last_run_date_ou
	 	  from   xxha_order_status_summary_ou;
	 exception
	 		  when others then
			  	   lp_last_run_date_ou := null;
	 end;	
	 for r_ou_details in c_ou_details loop
	     if lp_last_run_date_ou is null then
	 	 	insert into xxha_order_status_summary_ou
		 			 (organization_name
					  , organization_id
					  , creation_date
					  , created_by
					  , last_update_date
					  , last_updated_by
					  , last_update_login
					 )
		 	values (r_ou_details.name
		 		 , r_ou_details.organization_id
				 , sysdate
				 , fnd_global.user_id
				 , sysdate
				 , fnd_global.user_id
				 , fnd_global.login_id
				);
		 end if;
	 end loop;
	 xx_haemo_order_status_summary.ou_order_lines_stat;
	 xx_haemo_order_status_summary.ou_avg_stats;
	 update xxha_order_status_summary_ou
	 set    last_run_date = trunc(sysdate)
		    , last_updated_by = fnd_global.user_id
			, last_update_date = sysdate
			, last_update_login = fnd_global.login_id;
	 commit;				
end summary_main;
end xx_haemo_order_status_summary;
/
