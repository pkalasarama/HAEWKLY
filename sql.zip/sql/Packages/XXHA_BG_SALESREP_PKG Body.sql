create or replace PACKAGE BODY        "XXHA_BG_SALESREP_PKG" IS
/*******************************************************************************************************
* Object Name: XXHA_BG_SALESREP_PKG
* Object Type: PACKAGE BODY
*
* Description: This package used in custom form XXHA_BG_SALESREP to created Coe Use Record employee based on last name and location.
*
* Modification Log:
* Developer          Date          Version       Description
*-----------------   ------------- -----------   ------------------------------------------------
* Apps Associates    18-NOV-2015   1.0           Initial object creation.
* Vijay Medikonda    09-JUN-2016   2.0           Updated code for BG_NL
* Bruce Marcoux      30-APR-2018   3.0           Updated code for BG_HK
*
*******************************************************************************************************/
 PROCEDURE XXHA_BG_SALESREP(
    p_last_name     VARCHAR2,
    p_location_code VARCHAR2,
	P_employee_number out varchar2 )
   IS
  l_employee_number per_people_f.employee_number%TYPE;
  L_PERSON_ID per_people_f.person_id%TYPE;
  L_ASSIGNMENT_ID per_assignments_f.assignment_id%TYPE;
  l_object_ver_number per_people_f.object_version_number%TYPE;
  l_asg_ovn per_people_f.object_version_number%TYPE;
  l_per_effective_start_date per_people_v.effective_start_date%TYPE;
  l_per_effective_end_date per_people_v.effective_end_date%TYPE;
  l_full_name per_people_f.full_name%TYPE;
  l_per_comment_id per_people_f.comment_id%TYPE;
  l_assignment_sequence per_people_assignments_view.assignment_sequence%TYPE;
  l_assignment_number per_people_assignments_view.assignment_number%TYPE;
  l_name_combination_warning BOOLEAN;
  l_assign_payroll_warning   BOOLEAN;
  l_orig_hire_warning        BOOLEAN;
  l_error_msg                VARCHAR2(4000);
  l_context2                 NUMBER;
  l_OBJECT_VERSION_NUMBER per_all_assignments_f.OBJECT_VERSION_NUMBER%TYPE;
  L_per_information7      per_all_people_f.per_information7%type; 
  L_per_information18     per_all_people_f.per_information18%type; 
  L_per_information1     per_all_people_f.per_information1%type; 
  l_correspondence_language            varchar2(50);  
  l_per_information8      per_all_people_f.per_information8%type; 
  l_per_information4      per_all_people_f.per_information4%type; 
  l_per_information5      per_all_people_f.per_information5%type; 
  l_per_information6      per_all_people_f.per_information6%type;   -- V3.0
  l_national_identifier      per_all_people_f.national_identifier%type; 
  
  -- Out Variables for Update Employee Assgment Criteria
  ln_object_number   NUMBER :=1 ;
  ln_people_group_id NUMBER :=1;
  ln_special_ceiling_step_id PER_ALL_ASSIGNMENTS_F.SPECIAL_CEILING_STEP_ID%TYPE;
  lc_group_name VARCHAR2(30);
  ld_effective_start_date PER_ALL_ASSIGNMENTS_F.EFFECTIVE_START_DATE%TYPE;
  ld_effective_end_date PER_ALL_ASSIGNMENTS_F.EFFECTIVE_END_DATE%TYPE;
  lb_org_now_no_manager_warning BOOLEAN;
  lb_other_manager_warning      BOOLEAN;
  lb_spp_delete_warning         BOOLEAN;
  lc_entries_changed_warning    VARCHAR2(30);
  lb_tax_district_changed_warn  BOOLEAN;
  l_business_group_name Per_Business_Groups.name%type;
  l_business_group_id Per_Business_Groups.business_group_id%type;
  l_location_name Hr_Locations_All.location_code%type;
  l_location_id Hr_Locations_All.location_id%type;
  l_organization_name hr_all_organization_units.name%type;
  l_organization_id hr_all_organization_units.organization_id%type;
  l_user_person_type per_person_types.user_person_type%type;
  l_person_type_id per_person_types.person_type_id%type;
  l_last_name per_all_people_f.last_name%type;
    l_first_name per_all_people_f.first_name%type;

BEGIN
  --fnd_message.debug('Start of creating COE Use Record');
BEGIN
	
select distinct null business_group_name,  haou.business_group_id, hr.location_code location_name, hr.location_id, haou.name organization_name, 
   haou.business_group_id organization_id, TYPE.user_person_type, type.person_type_id
   ,p_last_name
  INTO l_business_group_name,
      l_business_group_id ,
      l_location_name ,
      l_location_id ,
      l_organization_name ,
      l_organization_id ,
      l_user_person_type ,
      l_person_type_id ,
      l_last_name
  from hr_locations hr,HR_ALL_ORGANIZATION_UNITS haou,
      PER_PERSON_TYPES TYPE
  WHERE 1=1 
   AND LOCATION_CODE = P_LOCATION_CODE 
   AND HR.ATTRIBUTE6=HAOU.NAME 
   and haou.organization_id = haou.business_group_id -- added to return only single record for each org.
   AND haou.business_group_id  = type.business_group_id
   AND TYPE.user_person_type = 'COE Use Record'
   AND TYPE.ACTIVE_FLAG      = 'Y'
   AND rownum =1;
   
  exception when others then 
	 null;
	 dbms_output.put_line('Error in getting org bg loc details:'||SQLERRM);
	 --fnd_message.debug('Error in getting org bg loc details:'||SQLERRM);
  END;
  
  BEGIN
  
   IF l_organization_name = 'BG_IN' THEN  --SECTION
	L_per_information7 := 'NRI';
   ELSIF l_organization_name = 'BG_HK' THEN    -- V3.0
	L_per_Information6 := l_last_name;         -- V3.0
   ELSIF l_organization_name = 'BG_JP' THEN 
	L_per_information18 := l_last_name;
   ELSIF l_organization_name = 'BG_BE' THEN 
	l_correspondence_language := 'F';
   ELSIF l_organization_name = 'BG_CN' THEN 
	
	begin --hokou type for CN
      select lookup_code into l_per_information4
	  from fnd_lookup_values 
	  where lookup_type like 'CN_HUKOU_TYPE' and meaning = 'Other'  AND language = 'US';
	exception when others then
	dbms_output.put_line('Error in retrieving hokou type. Defaulted to ID 9'||SQLERRM);
	l_per_information4 := 9;
	end;

	begin --hokou loction for CN
      select lookup_code into l_per_information5
	  from fnd_lookup_values 
	  where lookup_type like 'CN_HUKOU_LOCN' and meaning = 'Other'  AND language = 'US';
	exception when others then
	dbms_output.put_line('Error in retrieving hokou location. Defaulted to ID 990000'||SQLERRM);
	l_per_information5 := 990000;
	end;	
	
	l_per_information8 := 'N';
	l_national_identifier := l_last_name; --national identifier, currently defaulting same as last_name.
  elsif l_organization_name = 'BG_NL'
  then
   l_per_information1 := '.';                                         -- (Initials)
          l_per_information4 := 'FORMAT8';                                   -- 'Surname Prefix Firstname' (Further Name - Full Name Format)
  	l_national_identifier := l_last_name;
    l_first_name:=l_last_name;
   END IF;

      DBMS_OUTPUT.PUT_LINE('BGID:'||l_business_group_id||'l_last_name:'||l_last_name||'l_person_type_id:'||l_person_type_id
					  ||'L_per_information7:'||L_per_information7||'L_per_information18:'||L_per_information18
					  ||'l_correspondence_language:'||l_correspondence_language
					  ||'L_per_information8:'||L_per_information8
					  ||'L_per_information4:'||L_per_information4
					  ||'L_per_information5:'||L_per_information5
					  ||'L_per_information6:'||L_per_information6       -- V3.0
					  ||'l_national_identifier:'||l_national_identifier);

    HR_EMPLOYEE_API.CREATE_EMPLOYEE ( P_VALIDATE => FALSE, 
									  P_HIRE_DATE => sysdate, 
									  P_BUSINESS_GROUP_ID => l_business_group_id, 
									  P_LAST_NAME => l_last_name, 
									  p_first_name=>l_first_name,
									  p_person_type_id => l_person_type_id, 
									  p_sex => 'F',
									  p_per_information7  => L_per_information7, 
									  p_per_information1  => L_per_information1,
									  p_per_information18 => L_per_information18,
									  p_correspondence_language => l_correspondence_language,
									  p_per_information8 => L_per_information8,
									  p_per_information4 => L_per_information4,
									  p_per_information5 => L_per_information5,
									  p_per_information6 => L_per_information6,       -- V3.0
									  p_national_identifier => l_national_identifier,
    ---------------Out Variables-----------------------
									  p_employee_number => L_employee_number, 
									  P_PERSON_ID => L_PERSON_ID, 
									  P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, 
									  P_PER_OBJECT_VERSION_NUMBER => L_OBJECT_VER_NUMBER , 
									  P_ASG_OBJECT_VERSION_NUMBER => L_ASG_OVN, 
									  P_PER_EFFECTIVE_START_DATE => L_PER_EFFECTIVE_START_DATE , 
									  P_PER_EFFECTIVE_END_DATE => L_PER_EFFECTIVE_END_DATE, 
									  P_FULL_NAME => L_FULL_NAME , 
									  P_PER_COMMENT_ID => L_PER_COMMENT_ID , 
									  P_ASSIGNMENT_SEQUENCE => L_ASSIGNMENT_SEQUENCE, 
									  P_ASSIGNMENT_NUMBER => L_ASSIGNMENT_NUMBER , 
									  P_NAME_COMBINATION_WARNING => L_NAME_COMBINATION_WARNING, 
									  P_ASSIGN_PAYROLL_WARNING => L_ASSIGN_PAYROLL_WARNING , 
									  p_orig_hire_warning => l_orig_hire_warning );

    --fnd_message.debug('Completed creating COE Use Record.'|| 'L_employee_number: '||L_employee_number|| ',L_PERSON_ID: ' ||L_PERSON_ID|| ',L_ASSIGNMENT_ID: ' ||L_ASSIGNMENT_ID ||',L_OBJECT_VER_NUMBER: '||L_OBJECT_VER_NUMBER);
  EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line('Excep in getting org bg loc details:'||SQLERRM);
    --fnd_message.debug('Exception occured :'||SQLERRM);
  END;
  
  
  IF (L_ASSIGNMENT_ID > 0 AND L_ASSIGNMENT_ID IS NOT NULL) THEN
    BEGIN
      SELECT object_version_number
      INTO l_object_version_number
      FROM per_all_assignments_f
      WHERE assignment_id = L_ASSIGNMENT_ID
      AND TRUNC(sysdate) BETWEEN TRUNC(effective_start_date) AND TRUNC(effective_end_date);
      hr_assignment_api.update_emp_asg_criteria (P_VALIDATE => FALSE, 
												 p_effective_date => SYSDATE, 
												 p_datetrack_update_mode => 'CORRECTION', 
												 p_assignment_id => L_ASSIGNMENT_ID, 
												 P_OBJECT_VERSION_NUMBER => l_object_version_number , 
												 p_location_id => l_location_id, 
												 p_organization_id => l_organization_id,
      ---------------Out Variables-----------------------
												 p_people_group_id => ln_people_group_id, 
												 p_special_ceiling_step_id => ln_special_ceiling_step_id, 
												 p_group_name => lc_group_name, 
												 p_effective_start_date => ld_effective_start_date, 
												 p_effective_end_date => ld_effective_end_date, 
												 p_org_now_no_manager_warning => lb_org_now_no_manager_warning, 
												 p_other_manager_warning => lb_other_manager_warning, 
												 p_spp_delete_warning => lb_spp_delete_warning, 
												 p_entries_changed_warning => lc_entries_changed_warning, 
												 p_tax_district_changed_warning => lb_tax_district_changed_warn );
      --COMMIT;
      --fnd_message.debug('Completed updating assignment with location: '||l_location_name);
	  dbms_output.put_line('Completed updating assignment with location: '||l_location_name);
    EXCEPTION
    WHEN OTHERS THEN
	dbms_output.put_line('Exception occured in assign update API:'||SQLERRM);
     -- fnd_message.debug('Exception occured in assign update API:'||SQLERRM);
    END;
  END IF; 
  
  P_employee_number  := L_employee_number;
  dbms_output.put_line('HAE COE Use Record Employee created with employee number: '||P_employee_number);
  --fnd_message.debug('HAE COE Use Record Employee created with employee number: '||:XXHA_BG_SALESREP_TAB.employee_number);
  --fnd_message.debug('Procedure execution is completed.');
EXCEPTION
WHEN OTHERS THEN
dbms_output.put_line('Exception occured in Procedure:'||SQLERRM);
 -- fnd_message.debug('Exception occured in Procedure:'||SQLERRM);
END;

END;