CREATE OR REPLACE package XXHA_UPDATE_ASL_ATTRIBUTES
-- +===========================================================================+
-- | Name        : XXHA_UPDATE_ASL_ATTRIBUTES                                    	   |
-- | Purpose     : Support the update of ASl Attributes in ASL in EBS.	       |
-- |                                                                           |
-- | Comment     : This package updates the ASL Attributes    |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20090323  1.0  Palash Kundu       Initial version                         |
-- | 20090323  1.1  Palash Kundu       Added Blanket Number                    |
-- +===========================================================================+
AS

PROCEDURE UPDATE_ASL_ATTRIBUTES
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_blanket_number  in  varchar2
		,p_scheduler_id in number
		,p_bucket_pattern_id number
        );




end XXHA_UPDATE_ASL_ATTRIBUTES;

/


CREATE OR REPLACE package body      XXHA_UPDATE_ASL_ATTRIBUTES
as
-- +===========================================================================+
-- | Name        : XXHA_UPDATE_ASL_ATTRIBUTES                                    	   |
-- | Purpose     : Support the update of ASl Attributes in ASL in EBS.	       |
-- |                                                                           |
-- | Comment     : This package updates the ASL Attributes    |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20090323  1.0  Palash Kundu       Initial version                         |
-- | 20090323  1.1  Palash Kundu       Added Blanket Number                    |
-- +===========================================================================+
PROCEDURE UPDATE_ASL_ATTRIBUTES
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ,p_blanket_number  in  varchar2
		,p_scheduler_id in number
		,p_bucket_pattern_id number
        ) IS
--Get PO Header ID
cursor c_get_blanket (q_blanket_number varchar2,q_org_id number) is
select po_header_id from po_headers_all
where type_lookup_code = 'BLANKET'
and segment1 = q_blanket_number
and org_id = q_org_id
;
---Get ASL Id
cursor c_get_asl (q_doc_hdr_id number) is
select asl_id from po_asl_documents
where document_type_code = 'BLANKET'
and document_header_id = q_doc_hdr_id;

/*cursor c_get_asl_id (q_asl_id number,q_item_number varchar2) is
select asl_id from PO_ASL_ATTRIBUTES asl,mtl_system_items items
where asl.item_id = items.inventory_item_id
and items.organization_id = 103
and items.segment1 = q_item_number
and asl_id = q_asl_id;
*/
l_bucket_pattern_id number;
l_scheduler_id number;
l_sucess varchar2 (2000);
BEGIN
--Get Bucket Pattern Id
  select bucket_pattern_id
  into l_bucket_pattern_id
   from chv_bucket_patterns
   where bucket_pattern_name = 'DISPBUCK';
   l_bucket_pattern_id := p_bucket_pattern_id;
   select employee_id
   into l_scheduler_id
    from fnd_user
	where user_id = fnd_global.USER_ID;
	l_scheduler_id := p_scheduler_id;
 for v_get_blanket in c_get_blanket (p_blanket_number,fnd_global.ORG_ID) loop
     for v_get_asl in c_get_asl (v_get_blanket.po_header_id) loop
	   --for v_get_asl_id in c_get_asl_id (v_get_asl.asl_id,p_item_number) loop
	     update po_asl_attributes
		 set plan_schedule_type = 'MATERIAL_RELEASE'
		 ,enable_autoschedule_flag = 'Y'
		 ,enable_plan_schedule_flag = 'Y'
		 ,plan_bucket_pattern_id = l_bucket_pattern_id
		 ,scheduler_id = l_scheduler_id
		 where asl_id = v_get_asl.asl_id
		 ;
		 l_sucess := 'Y';
	   --end loop;
	 end loop;
 end loop;
 commit;
  IF l_sucess = 'Y' THEN
   FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'For Blanket Number '|| p_blanket_number||' update was sucessful.');
  ELSE
   FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'For Blanket Number '|| p_blanket_number||' update was errored out. Please check blanket number and item number');
 END IF;
END;
END XXHA_UPDATE_ASL_ATTRIBUTES;

/
