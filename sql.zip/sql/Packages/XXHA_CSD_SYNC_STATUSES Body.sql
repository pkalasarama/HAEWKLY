--------------------------------------------------------
--  File created - Monday-October-09-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body XXHA_CSD_SYNC_STATUSES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "APPS"."XXHA_CSD_SYNC_STATUSES" as
/* $Header: XXHA_CSD_SYNC_STATUSES 120.1.1 2015/06/12 */

/******************************************************************************
   PURPOSE: resolve as many inconsistencies between depot repair logistics
            line statuses and their corresponding order line status im Order
            Management. Not all can be solved (due to missing data in OM),
            not all are a problem (e.g. when shipped quantity is not the
            full expected quantity yet) and some depend on other errors (mostly
            IB transaction errors that need to be resolved before the logistics
            line status can be refreshed

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   120.1.0        10-May-15      jgraaf        Created this package for SR 3-9606623931
   120.1.1        12-Jun-15      jgraaf        fixed bug for case 6 - not updating l_rcv_trx_count when trx are found
******************************************************************************/


procedure debug(p_message IN varchar2)
   is
 begin
      fnd_log_repository.string_unchecked_internal(1,'XXHA_CSD_SYNC_STATUSES.main',p_message);
      fnd_file.put_line(fnd_file.log,p_message);

 end debug;
 
 
PROCEDURE main
  ( errbuf                  OUT NOCOPY VARCHAR2,
    retcode                 OUT NOCOPY NUMBER) 
    
    IS
 l_user_id          NUMBER;
  l_resp_id          NUMBER;
  l_appl_id          NUMBER;
  l_prod_txn_id      NUMBER;
  l_action_type      VARCHAR2(10);
  l_order_line_id    NUMBER;
  l_sql_stmt VARCHAR2(1000);


 TYPE csd_prod_txn_rec_type IS RECORD (
      PRODUCT_TRANSACTION_ID NUMBER
      ,ESTIMATE_DETAIL_ID NUMBER
      ,ORDER_HEADER_ID NUMBER
      ,ORDER_LINE_ID NUMBER
     );

 TYPE csd_prod_txn_tab IS TABLE OF csd_prod_txn_rec_type index by binary_integer;

  csd_prod_txn_rec csd_prod_txn_rec_type;
  csd_prod_txn_table csd_prod_txn_tab;

--****************************************
--Phase 1 Step 1: --Cursor to fetch all the records where the order header and the order line are null
--****************************************
  CURSOR C_RO_NO_ORD_HD_LINE
  IS
   select
   A.product_transaction_id
   ,A.ESTIMATE_DETAIL_ID
   ,B.ORDER_HEADER_ID
   ,B.ORDER_LINE_ID
   from
   csd_product_transactions A
   ,cs_estimate_details B
   where
   A.estimate_detail_id = B.estimate_detail_id
   and A.ORDER_HEADER_ID is null
   and A.ORDER_LINE_ID is null
   and A.PROD_TXN_STATUS = 'BOOKED'
   and A.ACTION_TYPE in ('RMA','SHIP')
   order by A.creation_date desc;

  l_C_RO_NO_ORD_HD_LINE C_RO_NO_ORD_HD_LINE%ROWTYPE;


--****************************************
--pase 1 step 2: --Cursor to fetch all the records where the order line are null
--****************************************
  CURSOR C_RO_NO_ORD_LINE
  IS
   select
   A.product_transaction_id
   ,A.ESTIMATE_DETAIL_ID
   ,B.ORDER_HEADER_ID
   ,B.ORDER_LINE_ID
   from
   csd_product_transactions A
   ,cs_estimate_details B
   where
   A.estimate_detail_id = B.estimate_detail_id
   and A.ORDER_HEADER_ID is not null
   and A.ORDER_LINE_ID is null
   and A.PROD_TXN_STATUS = 'BOOKED'
   and A.ACTION_TYPE in ('RMA','SHIP')
   order by A.creation_date desc;

  l_C_RO_NO_ORD_LINE C_RO_NO_ORD_LINE%ROWTYPE;

--****************************************
--Stage 2: --Cursor to fetch all the records where the order id's exist but status is out of synch with OM
--****************************************

cursor invalid_status_cur is
  select * from (
    SELECT  cr.repair_number, ooh.order_number, ooh.header_id, lin.line_number ,
         cpt.action_type, cpt.PROD_TXN_STATUS ro_line_status, SUBSTR (lin.flow_status_code, 1, 22) oe_line_st,
         cr.creation_date ro_created, cpt.creation_date logistic_created, lin.creation_date orderline_created,
         cr.repair_line_id, cpt.product_transaction_id, ced.order_line_id , ced.order_header_id
    FROM oe_order_lines_all lin,
        oe_transaction_types_all typ,
        mtl_system_items_b itm,
        mtl_parameters par,
        oe_sets st1,
        oe_sets st2,
        oe_sets st3,
        csd_product_transactions cpt,
        cs_estimate_details ced,
       csd_repairs cr,
       oe_order_headers_all ooh,
        cs_incidents_all_b cia,
       cs_incident_statuses_b cis
   WHERE lin.header_id = ooh.header_id
   and   ced.estimate_detail_id = cpt.estimate_detail_id
   and ced.order_line_id      = lin.line_id
  and ced.order_header_id      = lin.header_id
  and ced.order_header_id      = ooh.header_id
/*   AND  lin.line_id in ( Select line_id
                       from oe_order_lines_all oel1
                      start with oel1.line_id = ced.order_line_id
                   connect by prior oel1.line_id = oel1.split_from_line_id
                    and oel1.shipped_quantity is not null)*/
   and cr.repair_line_id = cpt.repair_line_id
   AND NVL (0, 0) IN
           (0,
            lin.line_id,
            lin.top_model_line_id,
            lin.ato_line_id,
            lin.link_to_line_id,
            lin.service_reference_line_id
           )
   AND lin.line_type_id = typ.transaction_type_id
   AND lin.ship_from_org_id = par.organization_id(+)
   AND lin.ship_from_org_id = itm.organization_id(+)
   AND lin.inventory_item_id = itm.inventory_item_id(+)
   AND lin.arrival_set_id = st1.set_id(+)
   AND lin.ship_set_id = st2.set_id(+)
   AND lin.line_set_id = st3.set_id(+)
   AND cr.status <>  'C'
   and cr.incident_id = cia.incident_id
   and cis.incident_status_id = cia.incident_status_id
   and nvl(cis.close_flag, 'N') = 'N'
    )
  where (action_type = 'RMA' and ro_line_status = 'BOOKED' and oe_line_st = 'CLOSED')
  or (action_type = 'RMA' and ro_line_status = 'BOOKED' and oe_line_st = 'RETURNED')
  or (action_type = 'RMA' and ro_line_status = 'ENTERED' and oe_line_st = 'AWAITING_RETURN')
  or (action_type = 'RMA' and ro_line_status = 'ENTERED' and oe_line_st = 'AWAITING_RETURN_DISPOS')
  or (action_type = 'RMA' and ro_line_status = 'ENTERED' and oe_line_st = 'CANCELLED')
  or (action_type = 'RMA' and ro_line_status = 'ENTERED' and oe_line_st = 'CLOSED')
  or (action_type = 'RMA' and ro_line_status = 'SUBMITTED' and oe_line_st = 'AWAITING_RETURN')
  or (action_type = 'RMA' and ro_line_status = 'SUBMITTED' and oe_line_st = 'AWAITING_RETURN_DISPOS')
  or (action_type = 'RMA' and ro_line_status = 'RECEIVED' and oe_line_st = 'AWAITING_RETURN')
  or (action_type = 'RMA' and ro_line_status = 'RECEIVED' and oe_line_st = 'AWAITING_RETURN_DISPOS')
  --or (action_type = 'RMA' and ro_line_status = 'CANCELLED' and oe_line_st <> 'CANCELLED')  -- decided to ignore these
  --or (action_type = 'SHIP' and ro_line_status = 'CANCELLED' and oe_line_st <> 'CANCELLED') -- decided to ignore these
  or (action_type = 'SHIP' and ro_line_status = 'BOOKED' and oe_line_st = 'CLOSED')
  or (action_type = 'SHIP' and ro_line_status = 'BOOKED' and oe_line_st = 'SHIPPED')
  or (action_type = 'SHIP' and ro_line_status = 'ENTERED' and oe_line_st = 'AWAITING_SHIPPING')
  or (action_type = 'SHIP' and ro_line_status = 'ENTERED' and oe_line_st = 'CANCELLED')
  or (action_type = 'SHIP' and ro_line_status = 'ENTERED' and oe_line_st = 'CLOSED')
  or (action_type = 'SHIP' and ro_line_status = 'RELEASED' and oe_line_st = 'CANCELLED')
  or (action_type = 'SHIP' and ro_line_status = 'RELEASED' and oe_line_st = 'CLOSED')
  or (action_type = 'SHIP' and ro_line_status = 'SUBMITTED' and oe_line_st = 'AWAITING_SHIPPING')
  or (action_type = 'SHIP' and ro_line_status = 'SUBMITTED' and oe_line_st = 'BOOKED')
  or (action_type = 'SHIP' and ro_line_status = 'SUBMITTED' and oe_line_st = 'CLOSED')
  or (action_type = 'SHIP' and ro_line_status = 'SUBMITTED' and oe_line_st = 'PRODUCTION_OPEN')
  or (action_type = 'SHIP' and ro_line_status = 'SUBMITTED' and oe_line_st = 'AWAITING_SHIPPING')
  or (action_type = 'SHIP' and ro_line_status = 'SUBMITTED' and oe_line_st = 'SUPPLY_ELIGIBLE')
 order by 5,6,7;

 l_errbuf varchar2(2000);
 l_retcode varchar2(1);

 l_delivery_detail_id number;
 l_case_handled varchar2(1);

/*  cursor case2_cur (p_line_id in number) is  -- to check if shipping data exists
     select  dd.delivery_detail_id
     from  oe_order_lines_all oel,
           wsh_delivery_details dd
     where 1=1
     AND  oel.line_id in ( Select line_id
                           from oe_order_lines_all oel1
                           start with oel1.line_id = p_line_id
                           connect by prior oel1.line_id = oel1.split_from_line_id
                                      and oel1.shipped_quantity is not null
                                      and oel1.header_id = oel.header_id)
     AND  dd.source_header_id    = oel.header_id
     AND  dd.source_line_id(+)     = oel.line_id
     AND  dd.released_status     in ('C','I');
*/
-- replaced cursor in v8 as it was taking a long time to run in the original query
 cursor case2_cur (p_line_id in number) is  -- to check if shipping data exists
  select  /*+ FIRST_ROWS */  dd.delivery_detail_id, dd.shipped_quantity, ced.quantity_required
     from  oe_order_lines_all oel,
           wsh_delivery_details dd,
           (Select line_id
            from oe_order_lines_all oel1
            start with oel1.line_id = p_line_id
            connect by prior oel1.line_id = oel1.split_from_line_id
            and oel1.shipped_quantity is not null) split,
            cs_estimate_details ced
     where 1=1
     and oel.line_id = split.line_id
     AND  dd.source_header_id    = oel.header_id
     AND  dd.source_line_id(+)     = oel.line_id
     AND  dd.released_status     in ('C','I')
     and ced.order_line_id =  p_line_id;

   l_shipped_quantity number := 0;
   l_logistics_quantity number := 0;

 cursor status_after_refresh (p_product_transaction_id in number) is
     select PROD_TXN_STATUS
     from csd_product_transactions
     where product_transaction_id = p_product_transaction_id;

   l_new_ro_line_status varchar2(60);


 cursor case_2_check_history (p_repair_line_id in number,p_delivery_detail_id in number) is
   select 'Y'
          from csd_repair_history crh
         where crh.repair_line_id = p_repair_line_id
          and  crh.paramn1        = p_delivery_detail_id
          and  event_code         = 'PS';

 l_history_row_exists varchar2(1) := 'N';

 cursor case6_search_rcv_transactions (p_product_transaction_id in number) is
   SELECT rcvt.transaction_id, rcvt.transaction_type, rcvt.quantity
   FROM csd_repairs cra,
        csd_product_transactions cpt,
        cs_estimate_details ced,
        oe_order_headers_all oeh,
        rcv_transactions rcvt,
        oe_order_lines_all oel
   WHERE cra.repair_line_id = cpt.repair_line_id
   and   cpt.product_transaction_id = p_product_transaction_id
   AND   cra.repair_line_id     = cpt.repair_line_id
   AND   ced.estimate_detail_id = cpt.estimate_detail_id
   AND   cpt.action_type    in ('RMA', 'RMA_THIRD_PTY')
   AND   oeh.header_id          = ced.order_header_id
   AND   oel.header_id          = oeh.header_id
   AND oel.line_id in ( Select line_id
                           from oe_order_lines_all oel1
                           start with oel1.line_id = ced.order_line_id
                       connect by prior oel1.line_id = oel1.split_from_line_id
                       and oel1.shipped_quantity is not null
                       and oel1.header_id = oeh.header_id)
   AND   rcvt.oe_order_line_id  = oel.line_id;

   l_rcv_trx_count number;

   l_skip_refresh varchar2(1) := 'N';

 cursor case6_check_received_qty  (p_product_transaction_id in number) is
   select nvl(cpt.quantity_received,0), nvl(abs(ced.quantity_required),0) quantity_required
   from csd_product_transactions cpt,
        csd_repairs cr,
        cs_estimate_details ced
   where cr.repair_line_id = cpt.repair_line_id
   and cpt.estimate_detail_id = ced.estimate_detail_id
   and cpt.product_transaction_id = p_product_transaction_id
   and cpt.action_type = 'RMA';

   l_quantity_received number;
   l_quantity_expected number;
   
  
BEGIN

  debug('start - version1');

  retcode := 0;  -- success
  /*
  SELECT user_id
  INTO l_user_id
  FROM fnd_user
  WHERE user_name = upper('&username');

  SELECT responsibility_id, application_id
  INTO l_resp_id, l_appl_id
  FROM fnd_responsibility_tl
  WHERE upper(responsibility_name) = upper('&responsibility')
  and language=userenv('LANG');

  fnd_global.apps_initialize(user_id => l_user_id, resp_id => l_resp_id,  resp_appl_id => l_appl_id);
    --EXAMPLE fnd_global.apps_initialize(user_id => 1318, resp_id => 52284, resp_appl_id => 512);

  */
  --Start Case 1: find and correct submitted csd product_transactions with no order header_id or line_id
  --Step1: Get the CSD Product Transaction details for which the order_header_id and order_line_id are null from cs_estimate_details
  --Step2: Loop through the cursor and for each record update the order_header_id and the order_line_id in the csd_product_transactions table.

  debug('*********STAGE1 Step 1: Populate missing order header data - Start ******');
  OPEN C_RO_NO_ORD_HD_LINE;
  LOOP --loop1
    FETCH C_RO_NO_ORD_HD_LINE
       BULK COLLECT INTO csd_prod_txn_table LIMIT 1000;
    EXIT WHEN csd_prod_txn_table.COUNT = 0;

    FOR i IN 1 .. csd_prod_txn_table.COUNT
    LOOP  -- loop2
       csd_prod_txn_rec := csd_prod_txn_table(i);

       l_sql_stmt := 'update CSD_PRODUCT_TRANSACTIONS SET ORDER_HEADER_ID = ' || csd_prod_txn_rec.ORDER_HEADER_ID
                     || ', ORDER_LINE_ID = ' || csd_prod_txn_rec.ORDER_LINE_ID
                     || ' WHERE PRODUCT_TRANSACTION_ID = '|| csd_prod_txn_rec.product_transaction_id
                     || ' and ESTIMATE_DETAIL_ID=' || csd_prod_txn_rec.ESTIMATE_DETAIL_ID;


       BEGIN
          EXECUTE IMMEDIATE l_sql_stmt;

          EXCEPTION
             when others then
             debug('Case 1: SQL statement failed= '||l_sql_stmt);
             debug('  with error = '||sqlerrm);
       END;

    End LOOP; -- loop2

    COMMIT; --Do a commit after every limit 1000 or <1000 records, which ever comes first.

  END LOOP;  -- loop1

  CLOSE C_RO_NO_ORD_HD_LINE;
  debug('*******STAGE1 Step 1: Ends*****');

  --Step2: Get the CSD Product Transaction details for which just the order_line_id are null from cs_estimate_details
  --Step2: Loop through the cursor and for each record update the order_line_id in the csd_product_transactions table.

  debug('*********STAGE 1 Step2: populate missing order line id - Start ******');

  OPEN C_RO_NO_ORD_LINE;
  LOOP -- loop3
   FETCH C_RO_NO_ORD_LINE
      BULK COLLECT INTO csd_prod_txn_table LIMIT 1000;
   EXIT WHEN csd_prod_txn_table.COUNT = 0;

   FOR i IN 1 .. csd_prod_txn_table.COUNT
   LOOP -- loop4
       csd_prod_txn_rec := csd_prod_txn_table(i);
       l_sql_stmt := 'update CSD_PRODUCT_TRANSACTIONS SET ORDER_LINE_ID = ' || csd_prod_txn_rec.ORDER_LINE_ID
                  || ' WHERE PRODUCT_TRANSACTION_ID = '|| csd_prod_txn_rec.product_transaction_id
                  || ' and ESTIMATE_DETAIL_ID=' || csd_prod_txn_rec.ESTIMATE_DETAIL_ID;

      BEGIN
         EXECUTE IMMEDIATE l_sql_stmt;

         EXCEPTION
            when others then
            debug('Step 2: SQL statement failed= '||l_sql_stmt);
            debug('  with error = '||sqlerrm);

      END;

   End Loop; -- loop4
  END LOOP; -- loop3

  CLOSE C_RO_NO_ORD_LINE;
  debug('*******STAGE 1 Step 2: Ends*****');

  ---------------------------------------------------------------------------------------------
  -- now all product transactions have been updated to the correct order header_id and line_id
  -- so now we loop through all of those which potentially have a status synch problem
  ---------------------------------------------------------------------------------------------

  debug('*********STAGE 2: - identify and fix rows with statuses out of synch - START ******');


  for i in invalid_status_cur loop -- loop5

    l_skip_refresh := 'N';
    l_case_handled :='N';
    debug('-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-');

    debug(' processing '||i.action_type
                                              ||' line for RO '  ||i.repair_number
                                              ||' in '||i.ro_line_status
                                              ||' status with orderline (id '||i.order_line_id||') in ' ||i.oe_line_st
                                              ||' status');

    -- case 1: line is in ENTERED status while order is submitted.
    -- fix: change the status to SUBMITTED - the standard refresh API will take care of the rest

    if i.ro_line_status = 'ENTERED'
    then
      debug(  ' case 1');

      update csd_product_transactions
       set prod_txn_status = 'SUBMITTED', interface_to_om_flag = 'Y'
       where PRODUCT_TRANSACTION_ID  = i.product_transaction_id;

       debug(' updated status to SUBMITTED - refresh should do the rest');
       
       l_case_handled :='Y';
 
    end if;


    -- case 3 - cancelled order but not cancelled logistics line (return or ship)
    -- we will just cancel the logistics line
    if i.ro_line_status in ('BOOKED', 'RELEASED', 'SUBMITTED', 'AWAITING_RETURN')
      and i.oe_line_st in ('CANCELLED')
    then
       debug(  ' case 3 - cancelled orderline');
       l_case_handled :='Y';

       update csd_product_transactions
       set prod_txn_status = 'CANCELLED', interface_to_om_flag = 'Y',
           book_sales_order_flag='Y', release_sales_order_flag = 'N',
           ship_sales_order_flag='N'
       where PRODUCT_TRANSACTION_ID  = i.product_transaction_id;
       
       
    end if; -- case 3

    -- case 4
    -- RMA line in submitted status while order is awaiting return already
    -- this case is not handled in csd_update_programs_pvt.rma_rcv_update as it does not
    -- find any return line. Just setting it to Booked
    if i.ro_line_status = 'SUBMITTED'
      and i.oe_line_st in ('AWAITING_RETURN', 'AWAITING_RETURN_DISPOS')
    then
       debug(  ' case 4 - rma line booked but not received - making logistics booked too');
       l_case_handled :='Y';

         update csd_product_transactions
         set prod_txn_status = 'BOOKED', interface_to_om_flag = 'Y',
           book_sales_order_flag='Y', release_sales_order_flag = 'N',
           ship_sales_order_flag='N'
       where PRODUCT_TRANSACTION_ID  = i.product_transaction_id;
       

    end if; -- case 4

    -- case 2: ship line is BOOKED, RELEASED or SUBMITTED but orderline is SHIPPED or CLOSED
    -- mostly this seems to happen when shipping data (WSH) does not exist

    if i.action_type = 'SHIP'
       and i.ro_line_status in ('BOOKED', 'RELEASED', 'SUBMITTED')
       and i.oe_line_st in ('SHIPPED', 'CLOSED')
    then
       debug(  ' case 2');
       l_case_handled :='Y';

       l_delivery_detail_id := -12; -- dummy value
       l_shipped_quantity := 0;
       l_logistics_quantity := 0;

       OPEN case2_cur (i.order_line_id);
       FETCH case2_cur into l_delivery_detail_id, l_shipped_quantity, l_logistics_quantity;

       if case2_cur%notfound or l_delivery_detail_id = -12 then
          debug(
                                                        ' no shipping data exists - setting status to SHIPPED without details');
          update csd_product_transactions
          set prod_txn_status = 'SHIPPED', interface_to_om_flag = 'N'
          where PRODUCT_TRANSACTION_ID  = i.product_transaction_id;

          l_skip_refresh := 'Y'; -- skipping refresh because direct update is done - refresh would not pick it up
       else

        debug(' shipping data found: ');
        debug('   delivery_detail_id: '|| l_delivery_detail_id||'  shipped_quantity: '|| l_shipped_quantity||'  logistics quantity: '|| l_logistics_quantity);

          if l_shipped_quantity > l_logistics_quantity then
                update csd_product_transactions
                set prod_txn_status = 'SHIPPED', interface_to_om_flag = 'N'
                where PRODUCT_TRANSACTION_ID  = i.product_transaction_id;

                debug(' quantity shipped is larger than required quantity - setting status to SHIPPED');

                l_skip_refresh := 'Y'; -- skipping refresh because direct update is done - refresh would not pick it up
   

          elsif l_shipped_quantity < l_logistics_quantity then
               debug(' quantity shipped is smaller than required quantity - so not fully SHIPPED yet');
                l_skip_refresh := 'Y'; -- skipping refresh because no refresh is to be expected (save time by not even trying)
          else
               debug(' quantity shipped is the same as required quantity');

               l_history_row_exists := 'N';
               OPEN case_2_check_history (i.repair_line_id ,l_delivery_detail_id );
               fetch case_2_check_history into l_history_row_exists;

               if l_history_row_exists = 'Y' then
                 debug(' history exists already - setting to SHIPPED ');

                 update csd_product_transactions
                 set prod_txn_status = 'SHIPPED', interface_to_om_flag = 'N'
                 where PRODUCT_TRANSACTION_ID  = i.product_transaction_id;

                 l_skip_refresh := 'Y'; -- skipping refresh because direct update is done - refresh would not pick it up
               else
                 debug(' history does not exist yet - check for IB error');

               end if;

               close case_2_check_history;

          end if;

       end if;
       CLOSE case2_cur;

    end if; --- case 2

   -- case 6: RMA line in BOOKED status while order is closed. Found this can occur for cases when:
   --   6.1 no receiving transactions are found in the system -> what to do??
   --   6.2 there are receiving transactions, but the received quantity > required quantity; the code cannot handle that.
   --   6.3 ?

   if i.action_type = 'RMA'
       and i.ro_line_status in ('BOOKED')
       and i.oe_line_st in ('CLOSED','RETURNED')
   then
         debug(  ' case 6 ');
       l_case_handled :='Y';


      open case6_check_received_qty(i.product_transaction_id);
      fetch case6_check_received_qty into l_quantity_received, l_quantity_expected;

      if l_quantity_received >= l_quantity_expected then
         --- case 6.2

         debug(' l_quantity_received ('||l_quantity_received||') - is greater than required quantity ('||l_quantity_expected||') so setting status to RECEIVED');

         update csd_product_transactions
         set PROD_TXN_STATUS = 'RECEIVED'
         where product_transaction_id = i.product_transaction_id;

         l_skip_refresh := 'Y'; -- skipping refresh because direct update is done and refresh cannot handle overreceipt

      else
         -- case 6.1

         debug('recorded received quantity ('||l_quantity_received||') not greater than required quantity ('||l_quantity_expected||'); searching for receiving transactions');
         -- see if we can find any receiving transactions:
          l_rcv_trx_count :=0;
          for rcv_trx in case6_search_rcv_transactions (i.product_transaction_id) loop
             debug(' found '||rcv_trx.transaction_type || ' receiving transaction ID '||rcv_trx.transaction_id||' quantity ' || rcv_trx.quantity);
             l_rcv_trx_count := l_rcv_trx_count +1;
          end loop;
          if   l_rcv_trx_count = 0 then
            debug('no receiving transactions found - setting this return logistics line to received anyway');

             update csd_product_transactions
             set PROD_TXN_STATUS = 'RECEIVED'
             where product_transaction_id = i.product_transaction_id;

            l_skip_refresh := 'Y'; -- skipping refresh because direct update is done - refresh would not pick it up

          end if;
      end if;

     close case6_check_received_qty;

   end if; -- case 6

  -- case 7 ;ship line in Submitted status while the orderline is actually at least booked; logistics line can be Booked then too.

  if i.action_type = 'SHIP'
       and i.ro_line_status in ( 'SUBMITTED')
       and i.oe_line_st in ('AWAITING_RELEASE', 'AWAITING_SHIPPING','BOOKED','PRODUCTION_OPEN','SUPPLY_ELIGIBLE', 'CLOSED')
    then
       debug(  ' case 7 - changing status to BOOKED ');
         l_case_handled :='Y';

         update csd_product_transactions
         set prod_txn_status = 'BOOKED', interface_to_om_flag = 'Y',
           book_sales_order_flag='Y', release_sales_order_flag = 'N',
           ship_sales_order_flag='N'
       where PRODUCT_TRANSACTION_ID  = i.product_transaction_id;

  end if; -- case 7

  -- case 8 return  line is received while the RMA line is still open
  -- re-using the cursors from case 6 to check for receiving transactions
  -- if there are no receipts - or not enough - the logistics line should be BOOKED

  if i.action_type = 'RMA'
       and i.ro_line_status in ('RECEIVED')
       and i.oe_line_st in ('AWAITING_RETURN', 'AWAITING_RETURN_DISPOS')
   then
       debug(  ' case 8 ');
       l_case_handled :='Y';

       open case6_check_received_qty(i.product_transaction_id);
       fetch case6_check_received_qty into l_quantity_received, l_quantity_expected;


      if l_quantity_received >= l_quantity_expected then

         debug(' l_quantity_received ('||l_quantity_received||') - is equal to or greater than required quantity ('||l_quantity_expected||') ');


      else

         debug('recorded received quantity ('||l_quantity_received||') not greater than required quantity ('||l_quantity_expected||'); searching for receiving transactions');

         -- see if we can find any receiving transactions:

          l_rcv_trx_count :=0;

          for rcv_trx in case6_search_rcv_transactions (i.product_transaction_id) loop
             debug(' found '||rcv_trx.transaction_type || ' receiving transaction ID '||rcv_trx.transaction_id||' quantity ' || rcv_trx.quantity);
          end loop;
          if   l_rcv_trx_count = 0 then
            debug('no receiving transactions found ');

          end if;

      end if;

       close case6_check_received_qty ;
  end if;


  if l_skip_refresh = 'N'
    then
      if i.action_type = 'RMA' then
            CSD_UPDATE_PROGRAMS_PVT.RECEIPTS_UPDATE_CONC_PROG (errbuf         => l_errbuf,
                                                               retcode             => l_retcode,
                                                               p_order_type        => NULL,
                                                               p_order_header_id   => NULL,
                                                               p_repair_line_id    => i.repair_line_id,
                                                               p_past_num_of_days  => NULL);

       elsif i.action_type = 'SHIP' then
            CSD_UPDATE_PROGRAMS_PVT.SHIP_UPDATE_CONC_PROG (errbuf             => l_errbuf,
                                                           retcode             => l_retcode,
                                                           p_order_type        => NULL,
                                                           p_order_header_id   => NULL,
                                                           p_repair_line_id    => i.repair_line_id,
                                                           p_past_num_of_days  => NULL);
       end if;
    end if;

     -- checking result of the refresh:
     if l_retcode <> '0' then
         debug(' update failed ('||l_retcode||'): '||substr(l_errbuf,1,230));
     else
         l_new_ro_line_status := null;
         open status_after_refresh(i.product_transaction_id);
         fetch status_after_refresh into l_new_ro_line_status;
         debug(' update success; new logistics line status: '||l_new_ro_line_status);
         close status_after_refresh;

         if i.ro_line_status = l_new_ro_line_status then
           debug('status did NOT change - further investigation might be required');
         end if;
     end if;




    if  l_case_handled ='N' then
            debug('this case is not handled by the script yet');
    end if;

  end loop; -- loop5

  debug('end');
  commit;

  exception
    when others then
         debug('Error Encountered: '||sqlerrm);
         retcode := 2;
         errbuf := sqlerrm;

 END MAIN;

End XXHA_CSD_SYNC_STATUSES;

/
