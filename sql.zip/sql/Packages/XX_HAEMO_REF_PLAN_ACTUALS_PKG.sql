CREATE OR REPLACE PACKAGE XX_HAEMO_REF_PLAN_ACTUALS_PKG AS

 -- +===========================================================================+
-- | Name        : XX_HAEMO_REFRESH_PLAN_ACTUALS_PKG                           |
-- | Purpose     : Refresh the sales plan fact table with current year and     |
-- |               prior year actuals.                                         |
-- | Description : Refresh the sales plan fact table with current year and     |
-- |               prior year actuals.                                         |
-- | Comment     :                                                             |
-- |                                                                           |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 11/11/08  1.0  IPadela       Initial version                              |
-- +===========================================================================+

--procedure used to refresh the current and prior year actuals

PROCEDURE main(
          p_Curr_Fis_Year in number,
          Ret_Code out number
	);
END XX_HAEMO_REF_PLAN_ACTUALS_PKG;
/


CREATE OR REPLACE PACKAGE BODY      XX_HAEMO_REF_PLAN_ACTUALS_PKG AS
/* *************************************************************************************************************************
*  Procedure Name :   main
*
*  main           :   Refresh the sales plan table with current and prior year actuals
*
*  Called From    :   This package will be called from XX_HAEMO_SALES_REVENUE_PKG
*
*  Parameters             Type       Description
*  p_Curr_Fis_Year        IN         current fiscal year

*  Tables Accessed
*  -----------------
*  Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)
*
* XX_HAEMO_SALES_PLAN_FACT            D, I
* XX_HAEMO_SALES_REVENUE              S
* xx_haemo_billto_cust_details        S
* xx_haemo_item_details               S
* gl_daily_rates                      S
* gl_periods                          S
* GL_CODE_COMBINATIONS_KFV            S
* JTF_RS_SALESREPS                    S
* xx_haemo_mgmtunits                  S
*
*  Change History
*  -----------------
*  Version         Date              Author               Description
*  ---------       ------------     ---------------     ---------------------------
*  1.0            11-Nov-2008       IPadela             Initial Creation
*  2.0            28-May-2009       IPadela             Added the dimensions for Fis week,
*                                                       Buss Unit and Ship To country as
                                                        per the req for FY10 plans and
                                                        global markets president's dashboard
* 3.0             19-Jan-2010       IPadela             Added units and item number
* 4.0             08-Sep-2010       IPadela             added logic to filter out non sales
                                                        accts data for current actuals and prior year
                                                        actuals
* 5.0             07-Sep-2012       IPadela             added inventory_item_id so as to retreive the
                                                        pre Pall cost and calculate the margin.
***********************************************************************************************************************************/
  PROCEDURE main(
          p_Curr_Fis_Year in number,
          Ret_Code out number
	) is
      exp_RetCode exception;
  BEGIN
    -- delete current year actuals from XX_HAEMO_SALES_PLAN_FACT
    begin
      Delete from XX_HAEMO_SALES_PLAN_FACT where plan_id = -1 and fiscal_year = p_Curr_Fis_Year;
      EXCEPTION
      WHEN OTHERS THEN
        rollback;
        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while deleting current fiscal year actuals from XX_HAEMO_SALES_PLAN_FACT: ' || SQLERRM);
        raise exp_RetCode;
    end;
    commit;
    -- delete prior year actuals from XX_HAEMO_SALES_PLAN_FACT
    begin
      Delete from XX_HAEMO_SALES_PLAN_FACT where plan_id = -2 and fiscal_year = p_Curr_Fis_Year - 1;
      EXCEPTION
      WHEN OTHERS THEN
        rollback;
        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while deleting prior year actuals from XX_HAEMO_SALES_PLAN_FACT: ' || SQLERRM);
        raise exp_RetCode;
    end;
    commit;

    -- insert current year actuals into XX_HAEMO_SALES_PLAN_FACT
    begin
      INSERT into haemo.XX_HAEMO_SALES_PLAN_FACT (plan_id, current_sales_rep, item_prod_line, item_prod_type, fiscal_year,
      fiscal_quarter, fiscal_month, fis_month_no, fiscal_week, mgmtunit_segment, management_unit, bussunit_segment, buss_unit, cyr_act_revenue, cyr_act_margin,
      billto_customer_number, shipto_country, created_by, creation_date, cyr_act_units, itemnumber, inv_item_id)
      select -1, S.current_salesrep_name, I.product_line as item_prod_line, I.product_type as item_prod_type, P.period_year as fiscal_year
      , P.quarter_num as fiscal_quarter, P.entered_period_name as fiscal_month, P.period_num, W.long_name as fiscal_week
      , M.flex_value, M.description as management_unit, B.flex_value, B.description as buss_unit,
      (S.Distribution_Level_Amount * R.conversion_rate) as sales_revenue_amt, -- SALES_REVENUE_AMOUNT is Distribution_Level_Amount * Trans_US1_Rate
      ( (S.Distribution_Level_Amount * R.conversion_rate) - -- MARGIN is (Sales_Revenue_Amount - Cogs_in_MST_USD)
      (
      case when I.item_frozen_cost is null then 0
      else
      (((S.Distribution_Level_Percent * (NVL(S.quantity_invoiced, 0) + NVL(S.quantity_credited, 0))) / 100) * I.item_frozen_cost) -- This is COGS_in_MST_USD = Units * Item_Frozen_Cost, Units = Distribution_Level_Percent * Net_Quantity, Net_Quantity = NVL(quantity_invoiced,0) + NVL(quantity_credited,0)
      end ) ) as margin,
      C.billto_customer_number as billto_customer_number,
      ST.shipto_country,
      FND_GLOBAL.USER_ID, sysdate,
      S.Distribution_Level_Percent * (NVL(S.quantity_invoiced, 0) + NVL(S.quantity_credited, 0)) / 100 as Units,
      I.itemnumber as Item_Number,
      I.inventory_item_id
      from xx_haemo_sales_revenue S
      left outer join xx_haemo_billto_cust_details C on S.bill_to_site_use_id=C.billto_site_use_id
      left outer join xx_haemo_item_details I on S.inventory_item_id=I.inventory_item_id
      left outer join gl_daily_rates R on S.invoice_currency_code=R.from_currency and R.conversion_date='29-MAR-08' and R.conversion_type='1000' and R.to_currency='US1'
      inner join gl_periods P on S.gl_date>=P.start_date and S.gl_date<=P.end_date + interval '1' day - interval '1' second and P.period_set_name='HAE_GLOBAL_CAL' and P.period_type='21'
      -- Rev 2.0
      inner join xx_haemo_fis_week W ON S.Gl_Date >= W.Begin_Date AND S.Gl_Date < W.End_Date
      --end Rev 2.0
      left outer join jtf_rs_salesreps srep
      on s.current_salesrep_id = srep.salesrep_id
      and s.organization_id = srep.org_id
      left outer join GL_CODE_COMBINATIONS_KFV gcc
      on srep.gl_id_rev = gcc.code_combination_id
      left outer join xx_haemo_mgmtunits M
      on gcc.segment4 = M.flex_value
      --Rev 2.0
      left outer join xx_haemo_bussunits B
      on gcc.segment3 = B.flex_value
      left outer join xx_haemo_shipto_cust_details ST on S.ship_to_site_use_id = ST.shipto_site_use_id
      --end Rev 2.0
      Where P.period_year = p_Curr_Fis_Year
      and c.BILLTO_CUSTOMER_TYPE = 'External'
      --Rev 4.0
      and Substr(S.natural_account, 1, 2 ) in ('40','41','44');
      --end Rev 4.0
      EXCEPTION
        WHEN OTHERS THEN
          rollback;
          FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting current year actuals into XX_HAEMO_SALES_PLAN_FACT: ' || SQLERRM);
          raise exp_RetCode;
      end;
      commit;
      Ret_Code := 0;

    -- insert prior year actuals into XX_HAEMO_SALES_PLAN_FACT
    begin
      INSERT into haemo.XX_HAEMO_SALES_PLAN_FACT (plan_id, current_sales_rep, item_prod_line, item_prod_type, fiscal_year,
      fiscal_quarter, fiscal_month, fis_month_no, fiscal_week, mgmtunit_segment, management_unit, bussunit_segment, buss_unit, pyr_act_revenue, pyr_act_margin,
      billto_customer_number, shipto_country, created_by, creation_date, pyr_act_units, itemnumber, inv_item_id)
      select -2, S.current_salesrep_name, I.product_line as item_prod_line, I.product_type as item_prod_type, P.period_year as fiscal_year,
      P.quarter_num as fiscal_quarter, P.entered_period_name as fiscal_month, P.period_num, W.long_name as fiscal_week,
      M.flex_value, M.description as management_unit, B.flex_value, B.description as buss_unit,
      (S.Distribution_Level_Amount * R.conversion_rate) as sales_revenue_amt, -- SALES_REVENUE_AMOUNT is Distribution_Level_Amount * Trans_US1_Rate
      ( (S.Distribution_Level_Amount * R.conversion_rate) - -- MARGIN is (Sales_Revenue_Amount - Cogs_in_MST_USD)
      (
      case when I.item_frozen_cost is null then 0
      else
      (((S.Distribution_Level_Percent * (NVL(S.quantity_invoiced, 0) + NVL(S.quantity_credited, 0))) / 100) * I.item_frozen_cost) -- This is COGS_in_MST_USD = Units * Item_Frozen_Cost, Units = Distribution_Level_Percent * Net_Quantity, Net_Quantity = NVL(quantity_invoiced,0) + NVL(quantity_credited,0)
      end ) ) as margin,
      C.billto_customer_number as billto_customer_number,
      ST.shipto_country,
      FND_GLOBAL.USER_ID, sysdate,
      S.Distribution_Level_Percent * (NVL(S.quantity_invoiced, 0) + NVL(S.quantity_credited, 0)) / 100 as Units,
      I.itemnumber as Item_Number,
      I.inventory_item_id
      from xx_haemo_sales_revenue S
      left outer join xx_haemo_billto_cust_details C on S.bill_to_site_use_id=C.billto_site_use_id
      left outer join xx_haemo_item_details I on S.inventory_item_id=I.inventory_item_id
      left outer join gl_daily_rates R on S.invoice_currency_code=R.from_currency and R.conversion_date='29-MAR-08' and R.conversion_type='1000' and R.to_currency='US1'
      inner join gl_periods P on S.gl_date>=P.start_date and S.gl_date<=P.end_date + interval '1' day - interval '1' second and P.period_set_name='HAE_GLOBAL_CAL' and P.period_type='21'
      --Rev 2.0
      inner join xx_haemo_fis_week W ON S.Gl_Date >= W.Begin_Date AND S.Gl_Date < W.End_Date
      --end Rev 2.0
      left outer join jtf_rs_salesreps srep
      on s.current_salesrep_id = srep.salesrep_id
      and s.organization_id = srep.org_id
      left outer join GL_CODE_COMBINATIONS_KFV gcc
      on srep.gl_id_rev = gcc.code_combination_id
      left outer join xx_haemo_mgmtunits M
      on gcc.segment4 = M.flex_value
      --Rev 2.0
      left outer join xx_haemo_bussunits B
      on gcc.segment3 = B.flex_value
      left outer join xx_haemo_shipto_cust_details ST on S.ship_to_site_use_id = ST.shipto_site_use_id
      --end Rev 2.0
      Where P.period_year = p_Curr_Fis_Year - 1
      and c.BILLTO_CUSTOMER_TYPE = 'External'
      --Rev 4.0
      and Substr(S.natural_account, 1, 2 ) in ('40','41','44');
      --end Rev 4.0
      EXCEPTION
        WHEN OTHERS THEN
          rollback;
          FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error occured while inserting prior year actuals into XX_HAEMO_SALES_PLAN_FACT: ' || SQLERRM);
          raise exp_RetCode;
      end;
      commit;
      Ret_Code := 0;

    EXCEPTION
        WHEN exp_RetCode THEN
          Ret_Code := 1;
  END main;

END XX_HAEMO_REF_PLAN_ACTUALS_PKG;
/
