create or replace PACKAGE        "XXHA_BG_SALESREP_PKG" IS
  /*******************************************************************************************************
* Object Name: XXHA_BG_SALESREP_PKG
* Object Type: PACKAGE SPECIFICATION
*
* Description: This package used in custom form XXHA_BG_SALESREP to created Coe Use Record employee based on last name and location.
*
* Modification Log:
* Developer          Date          Version       Description
*-----------------   ------------- -----------   ------------------------------------------------
* Apps Associates    18-NOV-2015   1.0           Initial object creation.
* Vijay Medikonda    09-JUN-2016   2.0           Updated code for BG_NL
* Bruce Marcoux      30-APR-2018   3.0           Updated code for BG_HK
*
*******************************************************************************************************/

  PROCEDURE XXHA_BG_SALESREP(   p_last_name  IN VARCHAR2,
								p_location_code IN VARCHAR2,
								P_employee_number out varchar2 
							);
END;