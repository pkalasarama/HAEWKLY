create or replace PACKAGE BODY XXHA_JAPAN_AR_PKG AS

/*****************************************************************************************
* Package Name : XXHA_JAPAN_AR_PKG                                                       *
* Purpose      : This package will process the data in the table                         *
*               'HAEMO.XXHA_JAPAN_AR_ZENGIN_TBL'.                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        17-DEC-2014     Bruce Marcoux        Initial Creation                       *
*                                                                                        *
*****************************************************************************************/

------------------------------------------------------------------------------------------
-- XXHA_MAIN_FUNC

PROCEDURE XXHA_MAIN_FUNC(
                  x_errbuf                        OUT VARCHAR2
                , x_retcode                       OUT VARCHAR2
                , p_remit_bank_account_id         IN  NUMBER
                , p_rcpt_method_id                IN  NUMBER) AS

   -- Customer w/mapping
   lc_CUSTOMER_NUMBER                  HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NUMBER%TYPE;
   lc_CUSTOMER_NAME                    HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME%TYPE;
   lc_CUSTOMER_NAME_BANKING            HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE;
   lc_CUSTOMER_PRIORITY                HAEMO.XXHA_JAPAN_AR_PAYER_TBL.PRIORITY%TYPE;
   lc_CUSTOMER_JRC                     HAEMO.XXHA_JAPAN_AR_PAYER_TBL.JRC%TYPE;
   lc_CUSTOMER_PARTY_NAME              HZ_PARTIES.PARTY_NAME%TYPE;
   lc_CUSTOMER_ACCOUNT_NUMBER          HZ_CUST_ACCOUNTS.ACCOUNT_NUMBER%TYPE;    
   lc_CUSTOMER_CUST_ACCOUNT_ID         HZ_CUST_ACCOUNTS.CUST_ACCOUNT_ID%TYPE;

   -- Customer w/mapping 
   lcx_CUSTOMER_NAME_BANKING           HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE;
   lcx_CUSTOMER_ACCOUNT_NUMBER         HZ_CUST_ACCOUNTS.ACCOUNT_NUMBER%TYPE;    
   lcx_CUSTOMER_CUST_ACCOUNT_ID        HZ_CUST_ACCOUNTS.CUST_ACCOUNT_ID%TYPE;

   -- MULTCUST
   lc_MULTCUST_NAME                    HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME%TYPE;
   lc_MULTCUST_COUNT                   NUMBER                                   := 0;

   -- CBI/CBIA Record
   lc_CBIA_ACCOUNT_NUMBER              HZ_CUST_ACCOUNTS.ACCOUNT_NUMBER%TYPE;    
   lc_CBIA_CUST_ACCOUNT_ID             HZ_CUST_ACCOUNTS.CUST_ACCOUNT_ID%TYPE;
   lc_CBIA_CONS_INV_ID                 ar_cons_inv_trx_all.cons_inv_id%TYPE;
   lc_CBIA_AMOUNT_DUE_REMAINING        ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIA_CUSTOMER_PRIORITY           HAEMO.XXHA_JAPAN_AR_PAYER_TBL.PRIORITY%TYPE;

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                VARCHAR2 (1);
   lc_api_msg_data                     VARCHAR2 (1000);
   lc_api_msg_count                    NUMBER   (10);
   lc_api_count                        NUMBER                                   := 0;
   lc_api_cash_receipt_id              NUMBER                                   := 0;

   -- Variables for Receipt Numbers
   lc_receipt_number_no_cust           NUMBER                                   := 0;
   lc_receipt_number_no_CBI            NUMBER                                   := 0;

   -- Variables for determining single/multi matching CBI data
   lc_single_matching_CBI_found        VARCHAR2 (1);
   lc_multi_matching_CBI_found         VARCHAR2 (1);

   -- Misc
   lc_Headings_Done                    VARCHAR2 (1)                             := 'N';
   lc_error                            VARCHAR2 (250)                           := NULL;
   lc_alert                            VARCHAR2 (100)                           := NULL;

   -- Cursor to retrieve data from HAEMO.XXHA_JAPAN_ZENGIN_TBL
   CURSOR ZENGIN
   IS
   SELECT
       z.CUSTOMER_NAME                                                          "CUSTOMER_NAME"
     , SUBSTR(z.DATE2,1,2) + 1988 || SUBSTR(z.DATE2,3,4)                        "DATE_YYYYMMDD"
     , TO_DATE(SUBSTR(z.DATE2,1,2) + 1988 || SUBSTR(z.DATE2,3,4), 'YYYY/MM/DD') "DATE_DDMONYY"
     , z.DATE2                                                                  "DATE2"
     , z.TOTAL_RECEIPT_AMOUNT                                                   "TOTAL_RECEIPT_AMOUNT"
   FROM
       HAEMO.XXHA_JAPAN_AR_ZENGIN_TBL z;

   -- Cursor to retrieve Customers w/mapping data
   CURSOR CUSTINFO (p_CUSTOMER_NAME_BANKING HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE)
   IS
   SELECT
       hae.CUSTOMER_NUMBER          "CUSTOMER_NUMBER"
     , hae.CUSTOMER_NAME            "CUSTOMER_NAME"
     , hae.CUSTOMER_NAME_BANKING    "CUSTOMER_NAME_BANKING"
     , NVL(hae.PRIORITY,0)          "PRIORITY"
     , NVL(UPPER(hae.JRC),'NO')     "JRC"
     , party.PARTY_NAME             "PARTY_NAME"
     , CUST.ACCOUNT_NUMBER          "ACCOUNT_NUMBER"
     , CUST.CUST_ACCOUNT_ID         "CUST_ACCOUNT_ID"
   FROM
       hz_parties                    party
     , hz_cust_accounts              cust
     , HAEMO.XXHA_JAPAN_AR_PAYER_TBL hae
   WHERE
       hae.CUSTOMER_NAME_BANKING   = p_CUSTOMER_NAME_BANKING
   AND hae.CUSTOMER_NUMBER         = CUST.ACCOUNT_NUMBER
   AND cust.Party_Id               = party.Party_Id
   ORDER BY
       hae.CUSTOMER_NAME_BANKING
     , NVL(hae.PRIORITY,0)
     , hae.CUSTOMER_NUMBER;

   -- Cursor to determine Multiple Customers
   CURSOR MULTCUST (p_CUSTOMER_NAME_BANKING HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE)
   IS
   SELECT
       hae.CUSTOMER_NAME_BANKING    "CUSTOMER_NAME_BANKING"
     , COUNT(*)                     "COUNT"
   FROM 
       HAEMO.XXHA_JAPAN_AR_PAYER_TBL hae
   WHERE  
       hae.CUSTOMER_NAME_BANKING   = p_CUSTOMER_NAME_BANKING
   GROUP BY hae.CUSTOMER_NAME_BANKING
   ORDER BY hae.CUSTOMER_NAME_BANKING;

   -- Cursor to retrieve CBI
   CURSOR CBI (p_CUST_ACCOUNT_ID hz_cust_accounts.CUST_ACCOUNT_ID%TYPE)
   IS
   SELECT
       CBI.ACCOUNT_NUMBER
     , CBI.CUST_ACCOUNT_ID
     , CBI.CONS_INV_ID
     , CBI.AMOUNT_DUE_REMAINING
   FROM
       XXHA_JAPAN_AR_V               CBI
   WHERE  
       CBI.CUST_ACCOUNT_ID         = p_CUST_ACCOUNT_ID
   ORDER BY
       CBI.CONS_INV_ID;

   -- Cursor to retrieve CBI with Amount Due Remaining
   CURSOR CBIA (p_CUST_ACCOUNT_ID hz_cust_accounts.CUST_ACCOUNT_ID%TYPE, p_AMOUNT_DUE_REMAINING ar_payment_schedules_all.AMOUNT_DUE_REMAINING%TYPE)
   IS
   SELECT
       CBIA.ACCOUNT_NUMBER
     , CBIA.CUST_ACCOUNT_ID
     , CBIA.CONS_INV_ID
     , CBIA.AMOUNT_DUE_REMAINING
   FROM
       XXHA_JAPAN_AR_V               CBIA
   WHERE  
       CBIA.CUST_ACCOUNT_ID        = p_CUST_ACCOUNT_ID
   AND CBIA.AMOUNT_DUE_REMAINING   = p_AMOUNT_DUE_REMAINING
   ORDER BY
       CBIA.CONS_INV_ID;

   -- Cursor to retrieve Customers w/CBI data
   CURSOR CUSTCBI (p_CUSTOMER_NAME_BANKING HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE)
   IS
   SELECT
       hae.CUSTOMER_NUMBER          "CUSTOMER_NUMBER"
     , CUST.CUST_ACCOUNT_ID         "CUST_ACCOUNT_ID"
     , CBI.CONS_INV_ID              "CBI_CONS_INV_ID"
     , CBI.AMOUNT_DUE_REMAINING     "CBI_AMOUNT_DUE_REMAINING"
     , NVL(hae.PRIORITY,0)          "PRIORITY"
   FROM
       hz_parties                    party
     , hz_cust_accounts              cust
     , HAEMO.XXHA_JAPAN_AR_PAYER_TBL hae
     , XXHA_JAPAN_AR_V               CBI
   WHERE
       hae.CUSTOMER_NAME_BANKING   = p_CUSTOMER_NAME_BANKING
   AND hae.CUSTOMER_NUMBER         = CUST.ACCOUNT_NUMBER
   AND cust.Party_Id               = party.Party_Id
   AND CUST.CUST_ACCOUNT_ID        = CBI.CUST_ACCOUNT_ID
   ORDER BY
       hae.CUSTOMER_NAME_BANKING
     , NVL(hae.PRIORITY,0)
     , CBI.CONS_INV_ID;

BEGIN

   -- Set the applications context
   mo_global.init('AR');
   mo_global.set_policy_context('S','156'); --156 is JP OU

   FND_GLOBAL.APPS_INITIALIZE(FND_GLOBAL.USER_ID, 50672, 222);

   -- Set Global Varaiables to parameter values
   g_remit_bank_account_id      := p_remit_bank_account_id;
   g_rcpt_method_id             := p_rcpt_method_id;

   -- Initialize variables to 1
   lc_receipt_number_no_cust    := 1;
   lc_receipt_number_no_CBI     := 1;

   -- Loop through the data in HAEMO.XXHA_JAPAN_ZENGIN_TBL
   FOR ZENGIN_Rec IN ZENGIN
   LOOP

      -- Produce Header for Output (only once)
      IF lc_Headings_Done = 'N' THEN
         FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Receipt Method,Receipt Date,Receipt Number,Net Receipt Amount,Billing Number,Customer Number,Customer Name,Bank Charges,Alert,Informational');
         lc_Headings_Done := 'Y';
      END IF;

      -- Check if Customer Exists
      OPEN CUSTINFO(ZENGIN_Rec.CUSTOMER_NAME);
      FETCH CUSTINFO INTO lc_CUSTOMER_NUMBER, lc_CUSTOMER_NAME, lc_CUSTOMER_NAME_BANKING, lc_CUSTOMER_PRIORITY, lc_CUSTOMER_JRC, lc_CUSTOMER_PARTY_NAME, lc_CUSTOMER_ACCOUNT_NUMBER, lc_CUSTOMER_CUST_ACCOUNT_ID;

      -- Initialize lc_api_return_status to NULL
      lc_api_return_status      := NULL;

      -- If Customer was not found, Create 'BLIND Receipt without Customer'
      IF CUSTINFO%NOTFOUND THEN
         AR_RECEIPT_API_PUB.CREATE_CASH
         (
           p_api_version                 => 1.0
         , p_init_msg_list               => FND_API.G_TRUE
         , p_commit                      => FND_API.G_TRUE
         , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
         , x_return_status               => lc_api_return_status
         , x_msg_count                   => lc_api_msg_count
         , x_msg_data                    => lc_api_msg_data
         , p_currency_code               => 'JPY'
         , p_amount                      => ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT     -- RECEIPT AMOUNT
         , p_factor_discount_amount      => 0                                   -- BANK CHARGE
         , p_receipt_number              => (ZENGIN_Rec.DATE_YYYYMMDD || '-' || TO_CHAR(lc_receipt_number_no_cust))
         , p_receipt_date                => ZENGIN_Rec.DATE_DDMONYY
         , p_gl_date                     => ZENGIN_Rec.DATE_DDMONYY
         , p_customer_number             => NULL
         , p_receipt_method_id           => g_rcpt_method_id                    -- Receipt Method of EFT with Bank Account# ending in 0100
         , p_remittance_bank_account_id  => g_remit_bank_account_id
         , p_comments                    => ('BLIND Receipt without Customer: ' || ZENGIN_Rec.CUSTOMER_NAME)
         , p_cr_id                       => lc_api_cash_receipt_id
         );

         -- Write to output only if API Completed Successfully
         IF lc_api_return_status = 'S' THEN
            lc_error := ('BLIND Receipt without Customer: ' || ZENGIN_Rec.CUSTOMER_NAME);
            lc_alert := NULL;
            XXHA_WRITE_OUTPUT(NULL, NULL, ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT, 0, ZENGIN_Rec.DATE_YYYYMMDD, ZENGIN_Rec.DATE_DDMONYY, lc_receipt_number_no_cust, lc_api_cash_receipt_id, lc_alert, lc_error);
            lc_error := NULL;
         END IF;

         -- Add 1 to lc_receipt_number_no_cust
         lc_receipt_number_no_cust   := (lc_receipt_number_no_cust + 1);

         -- If successful, was there a message sent back?
         IF lc_api_return_status = 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Successful: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         ELSIF lc_api_return_status != 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Error: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         END IF;
      END IF; -- CUSTINFO%NOTFOUND

      -- If Customer was found
      IF CUSTINFO%FOUND THEN

         -- Determine if maps to Multiple Customers
         OPEN MULTCUST(ZENGIN_Rec.CUSTOMER_NAME);
         FETCH MULTCUST INTO lc_MULTCUST_NAME, lc_MULTCUST_COUNT;
         CLOSE MULTCUST;

         -- Reset Matching CBI Found flags
         lc_single_matching_CBI_found := 'N';
         lc_multi_matching_CBI_found  := 'N';

         -- Processing for Non-JRC Customers
         IF lc_CUSTOMER_JRC = 'NO' THEN
            -- If multiple Customers don't exist then determine if the Customer has a CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT
            IF lc_MULTCUST_COUNT = 1 THEN
               OPEN CBIA(lc_CUSTOMER_CUST_ACCOUNT_ID, ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT);
               FETCH CBIA INTO lc_CBIA_ACCOUNT_NUMBER, lc_CBIA_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_CBIA_AMOUNT_DUE_REMAINING;
               IF CBIA%FOUND THEN
                  lc_single_matching_CBI_found := 'Y';
               END IF;
               -- If no records found where CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT, see if any open CBI's exist
               IF CBIA%NOTFOUND THEN
                  OPEN CBI(lc_CUSTOMER_CUST_ACCOUNT_ID);
                  FETCH CBI INTO lc_CBIA_ACCOUNT_NUMBER, lc_CBIA_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_CBIA_AMOUNT_DUE_REMAINING;
                  IF CBI%FOUND THEN
                     lc_single_matching_CBI_found := 'Y';
                  END IF;
                  CLOSE CBI;
               END IF;
               CLOSE CBIA;
            END IF;

            -- If multiple Customers do exist then we need to determine if any of the multiple Customers have a CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT
            IF lc_MULTCUST_COUNT > 1 THEN
               -- Store values in order to restore if no matching record found
               lcx_CUSTOMER_NAME_BANKING     := lc_CUSTOMER_NAME_BANKING;
               lcx_CUSTOMER_ACCOUNT_NUMBER   := lc_CUSTOMER_ACCOUNT_NUMBER;
               lcx_CUSTOMER_CUST_ACCOUNT_ID  := lc_CUSTOMER_CUST_ACCOUNT_ID;
               XXHA_FIND_MATCH_CBI_AMT_NONJRC(lc_CUSTOMER_NAME_BANKING, ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT, lc_CBIA_AMOUNT_DUE_REMAINING, lc_CUSTOMER_ACCOUNT_NUMBER, lc_CUSTOMER_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_multi_matching_CBI_found);

               -- If we didn't find any of the multiple Customers having a CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT, see if there are any CBI's for the Customers
               IF lc_multi_matching_CBI_found = 'N' THEN
                  -- Restore values
                  lc_CUSTOMER_NAME_BANKING     := lcx_CUSTOMER_NAME_BANKING;
                  lc_CUSTOMER_ACCOUNT_NUMBER   := lcx_CUSTOMER_ACCOUNT_NUMBER;
                  lc_CUSTOMER_CUST_ACCOUNT_ID  := lcx_CUSTOMER_CUST_ACCOUNT_ID;
                  OPEN CUSTCBI(ZENGIN_Rec.CUSTOMER_NAME);
                  FETCH CUSTCBI INTO lc_CUSTOMER_ACCOUNT_NUMBER, lc_CBIA_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_CBIA_AMOUNT_DUE_REMAINING, lc_CBIA_CUSTOMER_PRIORITY;
                  IF CUSTCBI%FOUND THEN
                     lc_multi_matching_CBI_found := 'Y';
                  END IF;
                  CLOSE CUSTCBI;
               END IF;
            END IF;

         END IF; -- Processing for Non-JRC Customers

         -- Processing for JRC Customers
         IF lc_CUSTOMER_JRC = 'YES' THEN
            -- If multiple Customers don't exist then determine if the Customer has a CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT
            IF lc_MULTCUST_COUNT = 1 THEN
               OPEN CBIA(lc_CUSTOMER_CUST_ACCOUNT_ID, ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT);
               FETCH CBIA INTO lc_CBIA_ACCOUNT_NUMBER, lc_CBIA_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_CBIA_AMOUNT_DUE_REMAINING;
               IF CBIA%FOUND THEN
                  lc_single_matching_CBI_found := 'Y';
               END IF;
               -- If no records found where CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT, see if any open CBI's exist
               IF CBIA%NOTFOUND THEN
                  OPEN CBI(lc_CUSTOMER_CUST_ACCOUNT_ID);
                  FETCH CBI INTO lc_CBIA_ACCOUNT_NUMBER, lc_CBIA_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_CBIA_AMOUNT_DUE_REMAINING;
                  IF CBI%FOUND THEN
                     lc_single_matching_CBI_found := 'Y';
                  END IF;
                  CLOSE CBI;
               END IF;
               CLOSE CBIA;
            END IF;

            -- If multiple Customers do exist then we need to determine if any of the multiple Customers have a CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT
            IF lc_MULTCUST_COUNT > 1 THEN
               -- Store values in order to restore if no matching record found
               lcx_CUSTOMER_NAME_BANKING     := lc_CUSTOMER_NAME_BANKING;
               lcx_CUSTOMER_ACCOUNT_NUMBER   := lc_CUSTOMER_ACCOUNT_NUMBER;
               lcx_CUSTOMER_CUST_ACCOUNT_ID  := lc_CUSTOMER_CUST_ACCOUNT_ID;
               XXHA_FIND_MATCH_CBI_AMT_JRC(lc_CUSTOMER_NAME_BANKING, ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT, lc_CBIA_AMOUNT_DUE_REMAINING, lc_CUSTOMER_ACCOUNT_NUMBER, lc_CUSTOMER_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_multi_matching_CBI_found);

               -- If we didn't find any of the multiple Customers having a CBI AMOUNT_DUE_REMAINING = TOTAL_RECEIPT_AMOUNT, see if there are any CBI's for the Customers
               IF lc_multi_matching_CBI_found = 'N' THEN
                  -- Restore values
                  lc_CUSTOMER_NAME_BANKING     := lcx_CUSTOMER_NAME_BANKING;
                  lc_CUSTOMER_ACCOUNT_NUMBER   := lcx_CUSTOMER_ACCOUNT_NUMBER;
                  lc_CUSTOMER_CUST_ACCOUNT_ID  := lcx_CUSTOMER_CUST_ACCOUNT_ID;
                  OPEN CUSTCBI(ZENGIN_Rec.CUSTOMER_NAME);
                  FETCH CUSTCBI INTO lc_CUSTOMER_ACCOUNT_NUMBER, lc_CBIA_CUST_ACCOUNT_ID, lc_CBIA_CONS_INV_ID, lc_CBIA_AMOUNT_DUE_REMAINING, lc_CBIA_CUSTOMER_PRIORITY;
                  IF CUSTCBI%FOUND THEN
                     lc_multi_matching_CBI_found := 'Y';
                  END IF;
                  CLOSE CUSTCBI;
               END IF;
            END IF;

         END IF; -- Processing for JRC Customers

         -- If outstanding CBI's for a Customer or Customers exist then call procedure to determine processing
         IF (lc_single_matching_CBI_found = 'Y' OR lc_multi_matching_CBI_found = 'Y') THEN
            XXHA_DETERMINE_CBI_PROCESS(lc_CBIA_CONS_INV_ID, lc_CUSTOMER_ACCOUNT_NUMBER, lc_CUSTOMER_CUST_ACCOUNT_ID, lc_CUSTOMER_NAME_BANKING, lc_MULTCUST_COUNT, ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT, lc_CBIA_AMOUNT_DUE_REMAINING, lc_CUSTOMER_JRC, ZENGIN_Rec.DATE_YYYYMMDD, ZENGIN_Rec.DATE_DDMONYY, lc_CBIA_CUSTOMER_PRIORITY);
         ELSE
            -- If outstanding CBI's don't exist for a Customer or Customers then create 'BLIND Receipt for CUSTOMER'
            AR_RECEIPT_API_PUB.CREATE_CASH
            (
              p_api_version                 => 1.0
            , p_init_msg_list               => FND_API.G_TRUE
            , p_commit                      => FND_API.G_TRUE
            , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
            , x_return_status               => lc_api_return_status
            , x_msg_count                   => lc_api_msg_count
            , x_msg_data                    => lc_api_msg_data
            , p_currency_code               => 'JPY'
            , p_amount                      => ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT  -- RECEIPT AMOUNT
            , p_factor_discount_amount      => 0                                -- BANK CHARGE
            , p_receipt_number              => (ZENGIN_Rec.DATE_YYYYMMDD || '-' || lc_CUSTOMER_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number_no_CBI))
            , p_receipt_date                => ZENGIN_Rec.DATE_DDMONYY
            , p_gl_date                     => ZENGIN_Rec.DATE_DDMONYY
            , p_customer_number             => lc_CUSTOMER_ACCOUNT_NUMBER
            , p_remittance_bank_account_id  => g_remit_bank_account_id
            , p_receipt_method_id           => g_rcpt_method_id                 -- Receipt Method of EFT with Bank Account# ending in 0100
            , p_comments                    => ('BLIND Receipt for Customer: ' || lc_CUSTOMER_ACCOUNT_NUMBER)
            , p_cr_id                       => lc_api_cash_receipt_id
            );

            -- Write to output only if API Completed Successfully
            IF lc_api_return_status = 'S' THEN
               lc_error := ('Outstanding CBI''s do not exist for Customer: ' || lc_CUSTOMER_ACCOUNT_NUMBER);
               lc_alert := NULL;
               XXHA_WRITE_OUTPUT(lc_CBIA_CONS_INV_ID, lc_CUSTOMER_ACCOUNT_NUMBER, ZENGIN_Rec.TOTAL_RECEIPT_AMOUNT, 0, ZENGIN_Rec.DATE_YYYYMMDD, ZENGIN_Rec.DATE_DDMONYY, lc_receipt_number_no_CBI, lc_api_cash_receipt_id, lc_alert, lc_error);
               lc_error := NULL;
            END IF;

            -- Add 1 to lc_receipt_number_no_CBI
            lc_receipt_number_no_CBI    := (lc_receipt_number_no_CBI + 1);

            -- If successful, was there a message sent back?
            IF lc_api_return_status = 'S' THEN
               IF NVL(lc_api_msg_count,0) = 1 THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Successful: ' ||lc_api_msg_data);
               ELSIF NVL(lc_api_msg_count,0) > 1 THEN
                  LOOP
                     lc_api_count    := lc_api_count + 1;
                     lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                     IF lc_api_msg_data IS NULL THEN
                        EXIT;
                     END IF;
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Error: '  || lc_api_count ||'. '||lc_api_msg_data);
                  END LOOP;
               END IF;
            ELSIF lc_api_return_status != 'S' THEN
               IF NVL(lc_api_msg_count,0) = 1 THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Error: ' ||lc_api_msg_data);
               ELSIF NVL(lc_api_msg_count,0) > 1 THEN
                  LOOP
                     lc_api_count    := lc_api_count + 1;
                     lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                     IF lc_api_msg_data IS NULL THEN
                        EXIT;
                     END IF;
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_MAIN_FUNC Error: '  || lc_api_count ||'. '||lc_api_msg_data);
                  END LOOP;
               END IF;
            END IF;

         END IF; -- IF (lc_single_matching_CBI_found = 'Y' OR lc_multi_matching_CBI_found = 'Y') THEN

      END IF; -- CUSTINFO%FOUND

      CLOSE CUSTINFO;

   END LOOP; -- Loop through ZENGIN records

END XXHA_MAIN_FUNC;

------------------------------------------------------------------------------------------
-- XXHA_DETERMINE_CBI_PROCESS

PROCEDURE XXHA_DETERMINE_CBI_PROCESS(p_CBI_CONS_INV_ID            NUMBER
                                   , p_CBI_ACCOUNT_NUMBER         NUMBER
                                   , p_CUSTOMER_CUST_ACCOUNT_ID   NUMBER
                                   , p_CUSTOMER_NAME_BANKING      VARCHAR2
                                   , p_MULTCUST_COUNT             NUMBER
                                   , p_TOTAL_RECEIPT_AMOUNT       NUMBER
                                   , p_CBI_AMOUNT_DUE_REMAINING   NUMBER
                                   , p_CUSTOMER_JRC               VARCHAR2
                                   , p_DATE_YYYYMMDD              NUMBER
                                   , p_DATE_DDMONYY               DATE
                                   , p_CBIA_CUSTOMER_PRIORITY     NUMBER) AS

BEGIN

   -- Procssing for JRC = 'NO'
   IF p_CUSTOMER_JRC = 'NO' THEN

      -- If does not map to Multiple Customers
      IF p_MULTCUST_COUNT = 1 THEN
         IF p_TOTAL_RECEIPT_AMOUNT < p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P1(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT = p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P2(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT > p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P3(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
      END IF;

      -- If maps to Multiple Customers
      IF p_MULTCUST_COUNT > 1 THEN
         IF p_TOTAL_RECEIPT_AMOUNT < p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P4(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT = p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P5(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT > p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P6(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
      END IF;
   END IF;

   -- Procssing for JRC = 'YES'
   IF p_CUSTOMER_JRC = 'YES' THEN

      -- If does not map to Multiple Customers
      IF p_MULTCUST_COUNT = 1 THEN
         IF p_TOTAL_RECEIPT_AMOUNT < p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P7(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT = p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P8(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT > p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P9(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
      END IF;

      -- If maps to Multiple Customers
      IF p_MULTCUST_COUNT > 1 THEN
         IF p_TOTAL_RECEIPT_AMOUNT < p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P10(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT = p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P11(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY);
         END IF;
         IF p_TOTAL_RECEIPT_AMOUNT > p_CBI_AMOUNT_DUE_REMAINING THEN
            XXHA_CBI_P12(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_CUSTOMER_CUST_ACCOUNT_ID, p_CUSTOMER_NAME_BANKING, p_MULTCUST_COUNT, p_TOTAL_RECEIPT_AMOUNT, p_CBI_AMOUNT_DUE_REMAINING, p_CUSTOMER_JRC, p_DATE_YYYYMMDD, p_DATE_DDMONYY, p_CBIA_CUSTOMER_PRIORITY);
         END IF;
      END IF;
   END IF;

END XXHA_DETERMINE_CBI_PROCESS;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P1
-- Processing where: 
--   JRC = 'NO'
--   Multiple Customers don't exist
--   TOTAL_RECEIPT_AMOUNT < CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P1(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;
   
BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P1');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Allocate Amount of CBI against the Receipt
   -- Difference between CBI Amount and Receipt Amount, populate in 'Bank Charges' Field
   -- Call API to Create Receipt
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                                  -- RECEIPT AMOUNT
   , p_factor_discount_amount      => (p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT)   -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || p_CBI_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => p_CBI_ACCOUNT_NUMBER
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('Receipt for Customer/CBI: ' || p_CBI_ACCOUNT_NUMBER || '/' || p_CBI_CONS_INV_ID)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := NULL;
      IF ((p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT) > 1000) THEN
          lc_alert :=  'YES';
      ELSE
          lc_alert :=  NULL;
      END IF;
      XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_TOTAL_RECEIPT_AMOUNT, (p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT), p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P1 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P1 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P1 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P1 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P1;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P2
-- Processing where: 
--   JRC = 'NO'
--   Multiple Customers don't exist
--   TOTAL_RECEIPT_AMOUNT = CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P2(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P2');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Allocate TOTAL_RECEIPT_AMOUNT against the CBI
   -- Call API to Create Receipt
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                    -- RECEIPT AMOUNT
   , p_factor_discount_amount      => 0                                         -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || p_CBI_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => p_CBI_ACCOUNT_NUMBER
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('Receipt for Customer/CBI: ' || p_CBI_ACCOUNT_NUMBER || '/' || p_CBI_CONS_INV_ID)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := NULL;
      lc_alert := NULL;
      XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P2 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P2 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P2 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P2 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P2;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P3
-- Processing where: 
--   JRC = 'NO'
--   Multiple Customers don't exist
--   TOTAL_RECEIPT_AMOUNT > CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P3(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- CBIB Record
   lc_CBIB_ACCOUNT_NUMBER                         hz_cust_accounts.ACCOUNT_NUMBER%TYPE;    
   lc_CBIB_CUST_ACCOUNT_ID                        hz_cust_accounts.CUST_ACCOUNT_ID%TYPE;
   lc_CBIB_CONS_INV_ID                            ar_cons_inv_trx_all.cons_inv_id%TYPE;
   lc_CBIB_AMOUNT_DUE_REMAINING                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_TOTAL_RECEIPT_AMOUNT                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_FOUND                                  VARCHAR2 (1);

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

   -- Cursor to retrieve CBI
   CURSOR CBIB (p_CUSTOMER_CUST_ACCOUNT_ID hz_cust_accounts.CUST_ACCOUNT_ID%TYPE)
   IS
   SELECT
       CBIB.ACCOUNT_NUMBER
     , CBIB.CUST_ACCOUNT_ID
     , CBIB.CONS_INV_ID
     , CBIB.AMOUNT_DUE_REMAINING
   FROM
       XXHA_JAPAN_AR_V              CBIB
   WHERE  
       CBIB.CUST_ACCOUNT_ID       = p_CUSTOMER_CUST_ACCOUNT_ID
   ORDER BY
       CBIB.CONS_INV_ID;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P3');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Set lc_CBIB_TOTAL_RECEIPT_AMOUNT to p_TOTAL_RECEIPT_AMOUNT
   lc_CBIB_TOTAL_RECEIPT_AMOUNT := p_TOTAL_RECEIPT_AMOUNT;

   -- Retrieve outstanding CBI's for Customer
   OPEN CBIB(p_CUSTOMER_CUST_ACCOUNT_ID);
   LOOP
      FETCH CBIB INTO lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_CUST_ACCOUNT_ID, lc_CBIB_CONS_INV_ID, lc_CBIB_AMOUNT_DUE_REMAINING;

      -- Exit when no more CBIB recs or if CBIB_TOTAL_RECEIPT_AMOUNT < CBIB_AMOUNT_DUE_REMAINING
      EXIT WHEN CBIB%NOTFOUND OR (lc_CBIB_TOTAL_RECEIPT_AMOUNT < lc_CBIB_AMOUNT_DUE_REMAINING);

      -- Allocate lc_CBIB_AMOUNT_DUE_REMAINING against the Receipt
      -- Call API to Create Receipt
      AR_RECEIPT_API_PUB.CREATE_CASH
      (
        p_api_version                 => 1.0
      , p_init_msg_list               => FND_API.G_TRUE
      , p_commit                      => FND_API.G_TRUE
      , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
      , x_return_status               => lc_api_return_status
      , x_msg_count                   => lc_api_msg_count
      , x_msg_data                    => lc_api_msg_data
      , p_currency_code               => 'JPY'
      , p_amount                      => lc_CBIB_AMOUNT_DUE_REMAINING           -- RECEIPT AMOUNT
      , p_factor_discount_amount      => 0                                      -- BANK CHARGE
      , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
      , p_receipt_date                => p_DATE_DDMONYY
      , p_gl_date                     => p_DATE_DDMONYY
      , p_customer_number             => lc_CBIB_ACCOUNT_NUMBER
      , p_remittance_bank_account_id  => g_remit_bank_account_id
      , p_receipt_method_id           => g_rcpt_method_id                       -- Receipt Method of EFT with Bank Account# ending in 0100
      , p_comments                    => ('Receipt for Customer/CBI: ' || lc_CBIB_ACCOUNT_NUMBER || '/' || lc_CBIB_CONS_INV_ID)
      , p_cr_id                       => lc_api_cash_receipt_id
      );

      -- Write to output only if API Completed Successfully
      IF lc_api_return_status = 'S' THEN
         lc_error := NULL;
         lc_alert := NULL;
         XXHA_WRITE_OUTPUT(lc_CBIB_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, lc_CBIB_AMOUNT_DUE_REMAINING, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
      END IF;

      -- Add 1 to lc_receipt_number
      lc_receipt_number := (lc_receipt_number + 1);

      -- If successful, was there a message sent back?
      IF lc_api_return_status = 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Successful: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      ELSIF lc_api_return_status != 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      END IF;

      -- Subtract CBIB_AMOUNT_DUE_REMAINING from CBIB_TOTAL_RECEIPT_AMOUNT
      lc_CBIB_TOTAL_RECEIPT_AMOUNT := (lc_CBIB_TOTAL_RECEIPT_AMOUNT - lc_CBIB_AMOUNT_DUE_REMAINING);

   END LOOP; -- Loop through outstanding CBI's for Customer

   -- If we have remaining dollars and oustanding CBIB's
   IF lc_CBIB_TOTAL_RECEIPT_AMOUNT > 0 AND CBIB%FOUND THEN

      -- Allocate Amount of CBI against the Receipt
      -- Difference between CBI Amount and Receipt Amount, populate in 'Bank Charges' Field
      -- Call API to Create Receipt
      AR_RECEIPT_API_PUB.CREATE_CASH
      (
        p_api_version                 => 1.0
      , p_init_msg_list               => FND_API.G_TRUE
      , p_commit                      => FND_API.G_TRUE
      , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
      , x_return_status               => lc_api_return_status
      , x_msg_count                   => lc_api_msg_count
      , x_msg_data                    => lc_api_msg_data
      , p_currency_code               => 'JPY'
      , p_amount                      => lc_CBIB_TOTAL_RECEIPT_AMOUNT                                     -- RECEIPT AMOUNT
      , p_factor_discount_amount      => (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT)    -- BANK CHARGE
      , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
      , p_receipt_date                => p_DATE_DDMONYY
      , p_gl_date                     => p_DATE_DDMONYY
      , p_customer_number             => lc_CBIB_ACCOUNT_NUMBER
      , p_remittance_bank_account_id  => g_remit_bank_account_id
      , p_receipt_method_id           => g_rcpt_method_id                       -- Receipt Method of EFT with Bank Account# ending in 0100
      , p_comments                    => ('Receipt for Customer/CBI: ' || lc_CBIB_ACCOUNT_NUMBER || '/' || lc_CBIB_CONS_INV_ID)
      , p_cr_id                       => lc_api_cash_receipt_id
      );

      -- Write to output only if API Completed Successfully
      IF lc_api_return_status = 'S' THEN
         lc_error := NULL;
         IF (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT) > 1000 THEN
            lc_alert := 'YES';
         ELSE
            lc_alert := NULL;
         END IF;
         XXHA_WRITE_OUTPUT(lc_CBIB_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, lc_CBIB_TOTAL_RECEIPT_AMOUNT, (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT), p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
      END IF;

      -- Add 1 to lc_receipt_number
      lc_receipt_number := (lc_receipt_number + 1);

      -- If successful, was there a message sent back?
      IF lc_api_return_status = 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Successful: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      ELSIF lc_api_return_status != 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      END IF;
   END IF;

   -- If we have remaining dollars and no more oustanding CBIB's
   IF lc_CBIB_TOTAL_RECEIPT_AMOUNT > 0 AND CBIB%NOTFOUND THEN
      -- Create 'Receipt for CUSTOMER'
      IF CBIB%NOTFOUND THEN
         AR_RECEIPT_API_PUB.CREATE_CASH
         (
           p_api_version                 => 1.0
         , p_init_msg_list               => FND_API.G_TRUE
         , p_commit                      => FND_API.G_TRUE
         , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
         , x_return_status               => lc_api_return_status
         , x_msg_count                   => lc_api_msg_count
         , x_msg_data                    => lc_api_msg_data
         , p_currency_code               => 'JPY'
         , p_amount                      => lc_CBIB_TOTAL_RECEIPT_AMOUNT        -- RECEIPT AMOUNT
         , p_factor_discount_amount      => 0                                   -- BANK CHARGE
         , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
         , p_receipt_date                => p_DATE_DDMONYY      
         , p_gl_date                     => p_DATE_DDMONYY      
         , p_customer_number             => lc_CBIB_ACCOUNT_NUMBER
         , p_remittance_bank_account_id  => g_remit_bank_account_id
         , p_receipt_method_id           => g_rcpt_method_id                    -- Receipt Method of EFT with Bank Account# ending in 0100
         , p_comments                    => ('Receipt for Customer: ' || lc_CBIB_ACCOUNT_NUMBER)
         , p_cr_id                       => lc_api_cash_receipt_id
         );

         -- Write to output only if API Completed Successfully
         IF lc_api_return_status = 'S' THEN
            lc_error := ('No more outstanding CBI''s exist for Customer: ' || lc_CBIB_ACCOUNT_NUMBER);
            lc_alert := NULL;
            XXHA_WRITE_OUTPUT(NULL, lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
         END IF;

         -- Add 1 to lc_receipt_number
         lc_receipt_number := (lc_receipt_number + 1);

         -- If successful, was there a message sent back?
         IF lc_api_return_status = 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Successful: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         ELSIF lc_api_return_status != 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P3 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         END IF;
      END IF;
   END IF;

   CLOSE CBIB;

END XXHA_CBI_P3;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P4
-- Processing where: 
--   JRC = 'NO'
--   Multiple Customers do exist
--   TOTAL_RECEIPT_AMOUNT < CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P4(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P4');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Allocate Amount of CBI against the Receipt
   -- Difference between CBI Amount and Receipt Amount, populate in 'Bank Charges' Field
   -- Call API to Create Receipt
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                                    -- RECEIPT AMOUNT
   , p_factor_discount_amount      => (p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT)     -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || p_CBI_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => p_CBI_ACCOUNT_NUMBER
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('Receipt for Customer/CBI: ' || p_CBI_ACCOUNT_NUMBER || '/' || p_CBI_CONS_INV_ID)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := NULL;
      IF (p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT) > 1000 THEN
         lc_alert := 'YES';
      ELSE
         lc_alert := NULL;
      END IF;
      XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_TOTAL_RECEIPT_AMOUNT, (p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT), p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P4 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P4 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P4 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P4 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P4;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P5
-- Processing where: 
--   JRC = 'NO'
--   Multiple Customers do exist
--   TOTAL_RECEIPT_AMOUNT = CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P5(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P5');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Allocate TOTAL_RECEIPT_AMOUNT against the CBI
   -- Call API to Create Receipt
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                    -- RECEIPT AMOUNT
   , p_factor_discount_amount      => 0                                         -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || p_CBI_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => p_CBI_ACCOUNT_NUMBER
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('Receipt for Customer/CBI: ' || p_CBI_ACCOUNT_NUMBER || '/' || p_CBI_CONS_INV_ID)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := NULL;
      lc_alert := NULL;
      XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P5 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P5 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P5 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P5 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P5;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P6
-- Processing where: 
--   JRC = 'NO'
--   Multiple Customers do exist
--   TOTAL_RECEIPT_AMOUNT > CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P6(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- CBIB Record
   lc_CBIB_ACCOUNT_NUMBER                         hz_cust_accounts.ACCOUNT_NUMBER%TYPE;    
   lc_CBIB_CUST_ACCOUNT_ID                        hz_cust_accounts.CUST_ACCOUNT_ID%TYPE;
   lc_CBIB_CONS_INV_ID                            ar_cons_inv_trx_all.cons_inv_id%TYPE;
   lc_CBIB_AMOUNT_DUE_REMAINING                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_TOTAL_RECEIPT_AMOUNT                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_FOUND                                  VARCHAR2 (1);

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

   -- Cursor to retrieve Customers w/CBI data
   CURSOR CUSTCBIB (p_CUSTOMER_NAME_BANKING HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE)
   IS
   SELECT
       hae.CUSTOMER_NUMBER          "CUSTOMER_NUMBER"
     , CUST.CUST_ACCOUNT_ID         "CUST_ACCOUNT_ID"
     , CBI.CONS_INV_ID              "CBI_CONS_INV_ID"
     , CBI.AMOUNT_DUE_REMAINING     "CBI_AMOUNT_DUE_REMAINING"
   FROM
       hz_parties                    party
     , hz_cust_accounts              cust
     , HAEMO.XXHA_JAPAN_AR_PAYER_TBL hae
     , XXHA_JAPAN_AR_V               CBI
   WHERE
       hae.CUSTOMER_NAME_BANKING   = p_CUSTOMER_NAME_BANKING
   AND hae.CUSTOMER_NUMBER         = CUST.ACCOUNT_NUMBER
   AND cust.Party_Id               = party.Party_Id
   AND CUST.CUST_ACCOUNT_ID        = CBI.CUST_ACCOUNT_ID
   ORDER BY
       hae.CUSTOMER_NAME_BANKING
     , NVL(hae.PRIORITY,0)
     , CBI.CONS_INV_ID;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P6');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Set lc_CBIB_TOTAL_RECEIPT_AMOUNT to p_TOTAL_RECEIPT_AMOUNT
   lc_CBIB_TOTAL_RECEIPT_AMOUNT := p_TOTAL_RECEIPT_AMOUNT;

   -- Retrieve outstanding CBI's for CUSTOMER_NAME_BANKING
   OPEN CUSTCBIB(p_CUSTOMER_NAME_BANKING);
   LOOP
      FETCH CUSTCBIB INTO lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_CUST_ACCOUNT_ID, lc_CBIB_CONS_INV_ID, lc_CBIB_AMOUNT_DUE_REMAINING;

      -- Exit when no more CBIB recs or if CBIB_TOTAL_RECEIPT_AMOUNT < CBIB_AMOUNT_DUE_REMAINING
      EXIT WHEN CUSTCBIB%NOTFOUND OR (lc_CBIB_TOTAL_RECEIPT_AMOUNT < lc_CBIB_AMOUNT_DUE_REMAINING);

      -- Allocate lc_CBIB_AMOUNT_DUE_REMAINING against the Receipt
      -- Call API to Create Receipt
      AR_RECEIPT_API_PUB.CREATE_CASH
      (
        p_api_version                 => 1.0
      , p_init_msg_list               => FND_API.G_TRUE
      , p_commit                      => FND_API.G_TRUE
      , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
      , x_return_status               => lc_api_return_status
      , x_msg_count                   => lc_api_msg_count
      , x_msg_data                    => lc_api_msg_data
      , p_currency_code               => 'JPY'
      , p_amount                      => lc_CBIB_AMOUNT_DUE_REMAINING           -- RECEIPT AMOUNT
      , p_factor_discount_amount      => 0                                      -- BANK CHARGE
      , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
      , p_receipt_date                => p_DATE_DDMONYY
      , p_gl_date                     => p_DATE_DDMONYY
      , p_customer_number             => lc_CBIB_ACCOUNT_NUMBER
      , p_remittance_bank_account_id  => g_remit_bank_account_id
      , p_receipt_method_id           => g_rcpt_method_id                       -- Receipt Method of EFT with Bank Account# ending in 0100
      , p_comments                    => ('Receipt for Customer/CBI: ' || lc_CBIB_ACCOUNT_NUMBER || '/' || lc_CBIB_CONS_INV_ID)
      , p_cr_id                       => lc_api_cash_receipt_id
      );

      -- Write to output only if API Completed Successfully
      IF lc_api_return_status = 'S' THEN
         lc_error := NULL;
         lc_alert := NULL;
         XXHA_WRITE_OUTPUT(lc_CBIB_CONS_INV_ID, lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_AMOUNT_DUE_REMAINING, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
      END IF;

      -- Add 1 to lc_receipt_number
      lc_receipt_number := (lc_receipt_number + 1);

      -- If successful, was there a message sent back?
      IF lc_api_return_status = 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Successful: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      ELSIF lc_api_return_status != 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      END IF;

      -- Subtract CBIB_AMOUNT_DUE_REMAINING from CBIB_TOTAL_RECEIPT_AMOUNT
      lc_CBIB_TOTAL_RECEIPT_AMOUNT := (lc_CBIB_TOTAL_RECEIPT_AMOUNT - lc_CBIB_AMOUNT_DUE_REMAINING);

   END LOOP; -- Loop through outstanding CBI's for Customer

   -- If we have remaining dollars and oustanding CBIB's
   IF lc_CBIB_TOTAL_RECEIPT_AMOUNT > 0 AND CUSTCBIB%FOUND THEN

      -- Allocate Amount of CBI against the Receipt
      -- Difference between CBI Amount and Receipt Amount, populate in 'Bank Charges' Field
      -- Call API to Create Receipt
      AR_RECEIPT_API_PUB.CREATE_CASH
      (
        p_api_version                 => 1.0
      , p_init_msg_list               => FND_API.G_TRUE
      , p_commit                      => FND_API.G_TRUE
      , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
      , x_return_status               => lc_api_return_status
      , x_msg_count                   => lc_api_msg_count
      , x_msg_data                    => lc_api_msg_data
      , p_currency_code               => 'JPY'
      , p_amount                      => lc_CBIB_TOTAL_RECEIPT_AMOUNT                                    -- RECEIPT AMOUNT
      , p_factor_discount_amount      => (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT)   -- BANK CHARGE
      , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
      , p_receipt_date                => p_DATE_DDMONYY
      , p_gl_date                     => p_DATE_DDMONYY
      , p_customer_number             => p_CBI_ACCOUNT_NUMBER
      , p_remittance_bank_account_id  => g_remit_bank_account_id
      , p_receipt_method_id           => g_rcpt_method_id                       -- Receipt Method of EFT with Bank Account# ending in 0100
      , p_comments                    => ('Receipt for Customer/CBI: ' || lc_CBIB_ACCOUNT_NUMBER || '/' || lc_CBIB_CONS_INV_ID)
      , p_cr_id                       => lc_api_cash_receipt_id
      );

      -- Write to output only if API Completed Successfully
      IF lc_api_return_status = 'S' THEN
         lc_error := NULL;
         IF (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT) > 1000 THEN
            lc_alert := 'YES';
         ELSE
            lc_alert := NULL;
         END IF;
         XXHA_WRITE_OUTPUT(lc_CBIB_CONS_INV_ID, lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_TOTAL_RECEIPT_AMOUNT, (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT), p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
      END IF;

      -- Add 1 to lc_receipt_number
      lc_receipt_number := (lc_receipt_number + 1);

      -- If successful, was there a message sent back?
      IF lc_api_return_status = 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Successful: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      ELSIF lc_api_return_status != 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      END IF;
   END IF;

   -- If we have remaining dollars and no more oustanding CBIB's
   IF lc_CBIB_TOTAL_RECEIPT_AMOUNT > 0 AND CUSTCBIB%NOTFOUND THEN
      -- Create 'BLIND Receipt without CUSTOMER'
      IF CUSTCBIB%NOTFOUND THEN
         AR_RECEIPT_API_PUB.CREATE_CASH
         (
           p_api_version                 => 1.0
         , p_init_msg_list               => FND_API.G_TRUE
         , p_commit                      => FND_API.G_TRUE
         , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
         , x_return_status               => lc_api_return_status
         , x_msg_count                   => lc_api_msg_count
         , x_msg_data                    => lc_api_msg_data
         , p_currency_code               => 'JPY'
         , p_amount                      => lc_CBIB_TOTAL_RECEIPT_AMOUNT        -- RECEIPT AMOUNT
         , p_factor_discount_amount      => 0                                   -- BANK CHARGE
         , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || TO_CHAR(lc_receipt_number))
         , p_receipt_date                => p_DATE_DDMONYY      
         , p_gl_date                     => p_DATE_DDMONYY      
         , p_customer_number             => NULL
         , p_remittance_bank_account_id  => g_remit_bank_account_id
         , p_receipt_method_id           => g_rcpt_method_id                    -- Receipt Method of EFT with Bank Account# ending in 0100
         , p_comments                    => ('BLIND Receipt without Customer: ' || p_CUSTOMER_NAME_BANKING)
         , p_cr_id                       => lc_api_cash_receipt_id
         );

         -- Write to output only if API Completed Successfully
         IF lc_api_return_status = 'S' THEN
            lc_error := ('BLIND Receipt without Customer: ' || p_CUSTOMER_NAME_BANKING);
            lc_alert := NULL;
            XXHA_WRITE_OUTPUT(NULL, NULL, lc_CBIB_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
         END IF;

         -- Add 1 to lc_receipt_number
         lc_receipt_number := (lc_receipt_number + 1);

         -- If successful, was there a message sent back?
         IF lc_api_return_status = 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Successful: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         ELSIF lc_api_return_status != 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P6 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         END IF;
      END IF;
   END IF;

   CLOSE CUSTCBIB;

END XXHA_CBI_P6;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P7
-- Processing where: 
--   JRC = 'YES'
--   Multiple Customers don't exist
--   TOTAL_RECEIPT_AMOUNT < CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P7(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P7');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Allocate Amount of CBI against the Receipt
   -- Difference between CBI Amount and Receipt Amount, populate in 'Bank Charges' Field
   -- Call API to Create Receipt
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                                     -- RECEIPT AMOUNT
   , p_factor_discount_amount      => (p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT)      -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || p_CBI_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => p_CBI_ACCOUNT_NUMBER
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('Receipt for Customer/CBI: ' || p_CBI_ACCOUNT_NUMBER || '/' || p_CBI_CONS_INV_ID)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := NULL;
      lc_alert := 'YES';
      XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_TOTAL_RECEIPT_AMOUNT, (p_CBI_AMOUNT_DUE_REMAINING - p_TOTAL_RECEIPT_AMOUNT), p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P7 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P7 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P7 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P7 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P7;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P8
-- Processing where: 
--   JRC = 'YES'
--   Multiple Customers don't exist
--   TOTAL_RECEIPT_AMOUNT = CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P8(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P8');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Allocate TOTAL_RECEIPT_AMOUNT against the CBI
   -- Call API to Create Receipt
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                    -- RECEIPT AMOUNT
   , p_factor_discount_amount      => 0                                         -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || p_CBI_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => p_CBI_ACCOUNT_NUMBER
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('Receipt for Customer/CBI: ' || p_CBI_ACCOUNT_NUMBER || '/' || p_CBI_CONS_INV_ID)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := NULL;
      lc_alert := NULL;
      XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P8 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P8 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P8 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P8 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P8;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P9
-- Processing where: 
--   JRC = 'YES'
--   Multiple Customers don't exist
--   TOTAL_RECEIPT_AMOUNT > CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P9(p_CBI_CONS_INV_ID           NUMBER
                    , p_CBI_ACCOUNT_NUMBER        NUMBER
                    , p_CUSTOMER_CUST_ACCOUNT_ID  NUMBER
                    , p_CUSTOMER_NAME_BANKING     VARCHAR2
                    , p_MULTCUST_COUNT            NUMBER
                    , p_TOTAL_RECEIPT_AMOUNT      NUMBER
                    , p_CBI_AMOUNT_DUE_REMAINING  NUMBER
                    , p_CUSTOMER_JRC              VARCHAR2
                    , p_DATE_YYYYMMDD             NUMBER
                    , p_DATE_DDMONYY              DATE) AS

   -- CBIB Record
   lc_CBIB_ACCOUNT_NUMBER                         hz_cust_accounts.ACCOUNT_NUMBER%TYPE;    
   lc_CBIB_CUST_ACCOUNT_ID                        hz_cust_accounts.CUST_ACCOUNT_ID%TYPE;
   lc_CBIB_CONS_INV_ID                            ar_cons_inv_trx_all.cons_inv_id%TYPE;
   lc_CBIB_AMOUNT_DUE_REMAINING                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_TOTAL_RECEIPT_AMOUNT                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_FOUND                                  VARCHAR2 (1);

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

   -- Cursor to retrieve CBI
   CURSOR CBIB (p_CUSTOMER_CUST_ACCOUNT_ID hz_cust_accounts.CUST_ACCOUNT_ID%TYPE)
   IS
   SELECT
       CBIB.ACCOUNT_NUMBER
     , CBIB.CUST_ACCOUNT_ID
     , CBIB.CONS_INV_ID
     , CBIB.AMOUNT_DUE_REMAINING
   FROM
       XXHA_JAPAN_AR_V              CBIB
   WHERE  
       CBIB.CUST_ACCOUNT_ID       = p_CUSTOMER_CUST_ACCOUNT_ID
   ORDER BY
       CBIB.CONS_INV_ID;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P9');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Set lc_CBIB_TOTAL_RECEIPT_AMOUNT to p_TOTAL_RECEIPT_AMOUNT
   lc_CBIB_TOTAL_RECEIPT_AMOUNT := p_TOTAL_RECEIPT_AMOUNT;

   -- Retrieve outstanding CBI's for Customer
   OPEN CBIB(p_CUSTOMER_CUST_ACCOUNT_ID);
   LOOP
      FETCH CBIB INTO lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_CUST_ACCOUNT_ID, lc_CBIB_CONS_INV_ID, lc_CBIB_AMOUNT_DUE_REMAINING;

      -- Exit when no more CBIB recs or if CBIB_TOTAL_RECEIPT_AMOUNT < CBIB_AMOUNT_DUE_REMAINING
      EXIT WHEN CBIB%NOTFOUND OR (lc_CBIB_TOTAL_RECEIPT_AMOUNT < lc_CBIB_AMOUNT_DUE_REMAINING);

      -- Allocate lc_CBIB_AMOUNT_DUE_REMAINING against the Receipt
      -- Call API to Create Receipt
      AR_RECEIPT_API_PUB.CREATE_CASH
      (
        p_api_version                 => 1.0
      , p_init_msg_list               => FND_API.G_TRUE
      , p_commit                      => FND_API.G_TRUE
      , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
      , x_return_status               => lc_api_return_status
      , x_msg_count                   => lc_api_msg_count
      , x_msg_data                    => lc_api_msg_data
      , p_currency_code               => 'JPY'
      , p_amount                      => lc_CBIB_AMOUNT_DUE_REMAINING           -- RECEIPT AMOUNT
      , p_factor_discount_amount      => 0                                      -- BANK CHARGE
      , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
      , p_receipt_date                => p_DATE_DDMONYY
      , p_gl_date                     => p_DATE_DDMONYY
      , p_customer_number             => lc_CBIB_ACCOUNT_NUMBER
      , p_remittance_bank_account_id  => g_remit_bank_account_id
      , p_receipt_method_id           => g_rcpt_method_id                       -- Receipt Method of EFT with Bank Account# ending in 0100
      , p_comments                    => ('Receipt for Customer/CBI: ' || lc_CBIB_ACCOUNT_NUMBER || '/' || lc_CBIB_CONS_INV_ID)
      , p_cr_id                       => lc_api_cash_receipt_id
      );

      -- Write to output only if API Completed Successfully
      IF lc_api_return_status = 'S' THEN
         lc_error := NULL;
         lc_alert := NULL;
         XXHA_WRITE_OUTPUT(lc_CBIB_CONS_INV_ID, lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_AMOUNT_DUE_REMAINING, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
      END IF;

      -- Add 1 to lc_receipt_number
      lc_receipt_number := (lc_receipt_number + 1);

      -- If successful, was there a message sent back?
      IF lc_api_return_status = 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Successful: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      ELSIF lc_api_return_status != 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      END IF;

      -- Subtract CBIB_AMOUNT_DUE_REMAINING from CBIB_TOTAL_RECEIPT_AMOUNT
      lc_CBIB_TOTAL_RECEIPT_AMOUNT := (lc_CBIB_TOTAL_RECEIPT_AMOUNT - lc_CBIB_AMOUNT_DUE_REMAINING);

   END LOOP; -- Loop through outstanding CBI's for Customer

   -- If we have remaining dollars and oustanding CBIB's
   IF lc_CBIB_TOTAL_RECEIPT_AMOUNT > 0 AND CBIB%FOUND THEN

      -- Allocate Amount of CBI against the Receipt
      -- Difference between CBI Amount and Receipt Amount, populate in 'Bank Charges' Field
      -- Call API to Create Receipt
      AR_RECEIPT_API_PUB.CREATE_CASH
      (
        p_api_version                 => 1.0
      , p_init_msg_list               => FND_API.G_TRUE
      , p_commit                      => FND_API.G_TRUE
      , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
      , x_return_status               => lc_api_return_status
      , x_msg_count                   => lc_api_msg_count
      , x_msg_data                    => lc_api_msg_data
      , p_currency_code               => 'JPY'
      , p_amount                      => lc_CBIB_TOTAL_RECEIPT_AMOUNT                                     -- RECEIPT AMOUNT
      , p_factor_discount_amount      => (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT)    -- BANK CHARGE
      , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
      , p_receipt_date                => p_DATE_DDMONYY
      , p_gl_date                     => p_DATE_DDMONYY
      , p_customer_number             => lc_CBIB_ACCOUNT_NUMBER
      , p_remittance_bank_account_id  => g_remit_bank_account_id
      , p_receipt_method_id           => g_rcpt_method_id                       -- Receipt Method of EFT with Bank Account# ending in 0100
      , p_comments                    => ('Receipt for Customer/CBI: ' || lc_CBIB_ACCOUNT_NUMBER || '/' || lc_CBIB_CONS_INV_ID)
      , p_cr_id                       => lc_api_cash_receipt_id
      );

      -- Write to output only if API Completed Successfully
      IF lc_api_return_status = 'S' THEN
         lc_error := NULL;
         IF (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT) > 1000 THEN
            lc_alert := 'YES';
         ELSE
            lc_alert := NULL;
         END IF;
         XXHA_WRITE_OUTPUT(lc_CBIB_CONS_INV_ID, lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_TOTAL_RECEIPT_AMOUNT, (lc_CBIB_AMOUNT_DUE_REMAINING - lc_CBIB_TOTAL_RECEIPT_AMOUNT), p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
      END IF;

      -- Add 1 to lc_receipt_number
      lc_receipt_number := (lc_receipt_number + 1);

      -- If successful, was there a message sent back?
      IF lc_api_return_status = 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Successful: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      ELSIF lc_api_return_status != 'S' THEN
         IF NVL(lc_api_msg_count,0) = 1 THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: ' ||lc_api_msg_data);
         ELSIF NVL(lc_api_msg_count,0) > 1 THEN
            LOOP
               lc_api_count    := lc_api_count + 1;
               lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
               IF lc_api_msg_data IS NULL THEN
                  EXIT;
               END IF;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
            END LOOP;
         END IF;
      END IF;
   END IF;

   -- If we have remaining dollars and no more oustanding CBIB's
   IF lc_CBIB_TOTAL_RECEIPT_AMOUNT > 0 AND CBIB%NOTFOUND THEN
      -- Create 'Receipt for CUSTOMER'
      IF CBIB%NOTFOUND THEN
         AR_RECEIPT_API_PUB.CREATE_CASH
         (
           p_api_version                 => 1.0
         , p_init_msg_list               => FND_API.G_TRUE
         , p_commit                      => FND_API.G_TRUE
         , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
         , x_return_status               => lc_api_return_status
         , x_msg_count                   => lc_api_msg_count
         , x_msg_data                    => lc_api_msg_data
         , p_currency_code               => 'JPY'
         , p_amount                      => lc_CBIB_TOTAL_RECEIPT_AMOUNT        -- RECEIPT AMOUNT
         , p_factor_discount_amount      => 0                                   -- BANK CHARGE
         , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || lc_CBIB_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
         , p_receipt_date                => p_DATE_DDMONYY      
         , p_gl_date                     => p_DATE_DDMONYY      
         , p_customer_number             => lc_CBIB_ACCOUNT_NUMBER
         , p_remittance_bank_account_id  => g_remit_bank_account_id
         , p_receipt_method_id           => g_rcpt_method_id                    -- Receipt Method of EFT with Bank Account# ending in 0100
         , p_comments                    => ('Receipt for Customer: ' || lc_CBIB_ACCOUNT_NUMBER)
         , p_cr_id                       => lc_api_cash_receipt_id
         );

         -- Write to output only if API Completed Successfully
         IF lc_api_return_status = 'S' THEN
            lc_error := ('No more outstanding CBI''s exist for Customer: ' || lc_CBIB_ACCOUNT_NUMBER);
            lc_alert := NULL;
            XXHA_WRITE_OUTPUT(NULL, lc_CBIB_ACCOUNT_NUMBER, lc_CBIB_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
         END IF;

         -- Add 1 to lc_receipt_number
         lc_receipt_number := (lc_receipt_number + 1);

         -- If successful, was there a message sent back?
         IF lc_api_return_status = 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Successful: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         ELSIF lc_api_return_status != 'S' THEN
            IF NVL(lc_api_msg_count,0) = 1 THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: ' ||lc_api_msg_data);
            ELSIF NVL(lc_api_msg_count,0) > 1 THEN
               LOOP
                  lc_api_count    := lc_api_count + 1;
                  lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                  IF lc_api_msg_data IS NULL THEN
                     EXIT;
                  END IF;
               FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P9 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
               END LOOP;
            END IF;
         END IF;
      END IF;
   END IF;

   CLOSE CBIB;

END XXHA_CBI_P9;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P10
-- Processing where: 
--   JRC = 'YES'
--   Multiple Customers do exist
--   TOTAL_RECEIPT_AMOUNT < CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P10(p_CBI_CONS_INV_ID          NUMBER
                     , p_CBI_ACCOUNT_NUMBER       NUMBER
                     , p_CUSTOMER_CUST_ACCOUNT_ID NUMBER
                     , p_CUSTOMER_NAME_BANKING    VARCHAR2
                     , p_MULTCUST_COUNT           NUMBER
                     , p_TOTAL_RECEIPT_AMOUNT     NUMBER
                     , p_CBI_AMOUNT_DUE_REMAINING NUMBER
                     , p_CUSTOMER_JRC             VARCHAR2
                     , p_DATE_YYYYMMDD            NUMBER
                     , p_DATE_DDMONYY             DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P10');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- If no matching CBI Amount to Receipt Amount, Create 'BLIND Receipt without Customer'
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                    -- RECEIPT AMOUNT
   , p_factor_discount_amount      => 0                                         -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => NULL
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('BLIND Receipt without Customer: ' || p_CUSTOMER_NAME_BANKING)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := ('BLIND Receipt without Customer: ' || p_CUSTOMER_NAME_BANKING);
      lc_alert := NULL;
      XXHA_WRITE_OUTPUT(NULL, NULL, p_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P10 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P10 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P10 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P10 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P10;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P11
-- Processing where: 
--   JRC = 'YES'
--   Multiple Customers do exist
--   TOTAL_RECEIPT_AMOUNT = CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P11(p_CBI_CONS_INV_ID          NUMBER
                     , p_CBI_ACCOUNT_NUMBER       NUMBER
                     , p_CUSTOMER_CUST_ACCOUNT_ID NUMBER
                     , p_CUSTOMER_NAME_BANKING    VARCHAR2
                     , p_MULTCUST_COUNT           NUMBER
                     , p_TOTAL_RECEIPT_AMOUNT     NUMBER
                     , p_CBI_AMOUNT_DUE_REMAINING NUMBER
                     , p_CUSTOMER_JRC             VARCHAR2
                     , p_DATE_YYYYMMDD            NUMBER
                     , p_DATE_DDMONYY             DATE) AS

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P11');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- Allocate TOTAL_RECEIPT_AMOUNT against the CBI
   -- Call API to Create Receipt
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                    -- RECEIPT AMOUNT
   , p_factor_discount_amount      => 0                                         -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || p_CBI_ACCOUNT_NUMBER || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => p_CBI_ACCOUNT_NUMBER
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('Receipt for Customer/CBI: ' || p_CBI_ACCOUNT_NUMBER || '/' || p_CBI_CONS_INV_ID)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := NULL;
      lc_alert := NULL;
      XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID, p_CBI_ACCOUNT_NUMBER, p_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P11 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P11 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P11 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P11 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P11;

------------------------------------------------------------------------------------------
-- XXHA_CBI_P12
-- Processing where: 
--   JRC = 'YES'
--   Multiple Customers do exist
--   TOTAL_RECEIPT_AMOUNT > CBI_AMOUNT_DUE_REMAINING

PROCEDURE XXHA_CBI_P12(p_CBI_CONS_INV_ID          NUMBER
                     , p_CBI_ACCOUNT_NUMBER       NUMBER
                     , p_CUSTOMER_CUST_ACCOUNT_ID NUMBER
                     , p_CUSTOMER_NAME_BANKING    VARCHAR2
                     , p_MULTCUST_COUNT           NUMBER
                     , p_TOTAL_RECEIPT_AMOUNT     NUMBER
                     , p_CBI_AMOUNT_DUE_REMAINING NUMBER
                     , p_CUSTOMER_JRC             VARCHAR2
                     , p_DATE_YYYYMMDD            NUMBER
                     , p_DATE_DDMONYY             DATE
                     , p_CBIA_CUSTOMER_PRIORITY   NUMBER) AS

   -- CBIB Record
   lc_CBIB_ACCOUNT_NUMBER                         hz_cust_accounts.ACCOUNT_NUMBER%TYPE;    
   lc_CBIB_CUST_ACCOUNT_ID                        hz_cust_accounts.CUST_ACCOUNT_ID%TYPE;
   lc_CBIB_CONS_INV_ID                            ar_cons_inv_trx_all.cons_inv_id%TYPE;
   lc_CBIB_AMOUNT_DUE_REMAINING                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_TOTAL_RECEIPT_AMOUNT                   ar_payment_schedules_all.amount_due_remaining%TYPE;
   lc_CBIB_CUSTOMER_PRIORITY                      HAEMO.XXHA_JAPAN_AR_PAYER_TBL.PRIORITY%TYPE;
   lc_CBIB_FOUND                                  VARCHAR2 (1);

   -- AR_RECEIPT_API_PUB
   lc_api_return_status                           VARCHAR2 (1);
   lc_api_msg_data                                VARCHAR2 (1000);
   lc_api_msg_count                               NUMBER   (10);
   lc_api_count                                   NUMBER                        := 0;
   lc_api_cash_receipt_id                         NUMBER;
   lc_receipt_number                              NUMBER                        := 0;

   lc_error                                       VARCHAR2 (250)                := NULL;
   lc_alert                                       VARCHAR2 (100)                := NULL;


BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_CBI_P12');

   -- Initialize values to 1
   lc_receipt_number    := 1;

   -- If no matching CBI Amount to Receipt Amount, Create 'BLIND Receipt without Customer'
   AR_RECEIPT_API_PUB.CREATE_CASH
   (
     p_api_version                 => 1.0
   , p_init_msg_list               => FND_API.G_TRUE
   , p_commit                      => FND_API.G_TRUE
   , p_validation_level            => FND_API.G_VALID_LEVEL_FULL
   , x_return_status               => lc_api_return_status
   , x_msg_count                   => lc_api_msg_count
   , x_msg_data                    => lc_api_msg_data
   , p_currency_code               => 'JPY'
   , p_amount                      => p_TOTAL_RECEIPT_AMOUNT                    -- RECEIPT AMOUNT
   , p_factor_discount_amount      => 0                                         -- BANK CHARGE
   , p_receipt_number              => (p_DATE_YYYYMMDD || '-' || TO_CHAR(lc_receipt_number))
   , p_receipt_date                => p_DATE_DDMONYY
   , p_gl_date                     => p_DATE_DDMONYY
   , p_customer_number             => NULL
   , p_remittance_bank_account_id  => g_remit_bank_account_id
   , p_receipt_method_id           => g_rcpt_method_id                          -- Receipt Method of EFT with Bank Account# ending in 0100
   , p_comments                    => ('BLIND Receipt without Customer: ' || p_CUSTOMER_NAME_BANKING)
   , p_cr_id                       => lc_api_cash_receipt_id
   );

   -- Write to output only if API Completed Successfully
   IF lc_api_return_status = 'S' THEN
      lc_error := ('BLIND Receipt without Customer: ' || p_CUSTOMER_NAME_BANKING);
      lc_alert := NULL;
      XXHA_WRITE_OUTPUT(NULL, NULL, p_TOTAL_RECEIPT_AMOUNT, 0, p_DATE_YYYYMMDD, p_DATE_DDMONYY, lc_receipt_number, lc_api_cash_receipt_id, lc_alert, lc_error);
   END IF;

   -- Add 1 to lc_receipt_number
   lc_receipt_number := (lc_receipt_number + 1);

   -- If successful, was there a message sent back?
   IF lc_api_return_status = 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P12 Successful: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P12 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   ELSIF lc_api_return_status != 'S' THEN
      IF NVL(lc_api_msg_count,0) = 1 THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P12 Error: ' ||lc_api_msg_data);
      ELSIF NVL(lc_api_msg_count,0) > 1 THEN
         LOOP
            lc_api_count    := lc_api_count + 1;
            lc_api_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
            IF lc_api_msg_data IS NULL THEN
               EXIT;
            END IF;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_JAPAN_AR_PKG.XXHA_CBI_P12 Error: '  || lc_api_count ||'. '||lc_api_msg_data);
         END LOOP;
      END IF;
   END IF;

END XXHA_CBI_P12;

------------------------------------------------------------------------------------------
-- XXHA_WRITE_OUTPUT

PROCEDURE XXHA_WRITE_OUTPUT(p_CBI_CONS_INV_ID     NUMBER
                          , p_CUSTOMER_NUMBER     NUMBER
                          , p_RECEIPT_AMOUNT      NUMBER
                          , p_BANK_CHARGE         NUMBER
                          , p_DATE_YYYYMMDD       NUMBER
                          , p_DATE_DDMONYY        DATE
                          , p_NUMBER              NUMBER
                          , p_CASH_RECEIPT_ID     NUMBER
                          , p_ALERT               VARCHAR2
                          , p_ERROR               VARCHAR2) AS

   lc_Bank_Name                                   CE_BANK_BRANCHES_V.BANK_NAME%TYPE;
   lc_Branch_Name                                 CE_BANK_BRANCHES_V.BANK_BRANCH_NAME%TYPE;
   lc_Account_Number                              CE_BANK_ACCOUNTS.BANK_ACCOUNT_NUM%TYPE;
   lc_Cons_Billing_Number                         ar_cons_inv_all.Cons_Billing_Number%TYPE;
   lc_Name                                        ar_receipt_methods.name%TYPE;
   lc_PARTY_NAME                                  hz_parties.PARTY_NAME%TYPE;
   lc_Account_Number_Mask                         VARCHAR2 (100)                := NULL;

   -- Cursor to retrieve Consolidated Billing Number
   CURSOR RCPTNUM
   IS
   SELECT
       arc.Cons_Billing_Number
   FROM
       ar_cons_inv_all    arc
   WHERE
       arc.CONS_INV_ID  = p_CBI_CONS_INV_ID;

   -- Cursor to retrieve Receipt Method Name
   CURSOR CASHRECPT
   IS
   SELECT
       arr.name
   FROM
       AR_CASH_RECEIPTS_All     arca
     , ar_receipt_methods       arr
   WHERE
       arca.cash_receipt_ID   = p_CASH_RECEIPT_ID
   AND arca.receipt_method_id = arr.receipt_method_id;

   -- Cursor to retrieve Bank/Branch/Account Number Information
   CURSOR BANKBRANCH
   IS
   SELECT
       CBA.BANK_ACCOUNT_NUM
     , BB.BANK_NAME
     , BB.BANK_BRANCH_NAME
   FROM
       CE_BANK_ACCT_USES            BA
     , CE_BANK_ACCOUNTS             CBA
     , CE_BANK_BRANCHES_V           BB
   WHERE 
       CBA.BANK_BRANCH_ID         = BB.BRANCH_PARTY_ID
   AND BA.BANK_ACCOUNT_ID         = CBA.BANK_ACCOUNT_ID 
   AND CBA.ACCOUNT_CLASSIFICATION = 'INTERNAL'
   AND BA.BANK_ACCT_USE_ID        = g_remit_bank_account_id;

   -- Cursor to retrieve Customer Name
   CURSOR CUSTOMER
   IS
   SELECT
       PARTY.PARTY_NAME
   FROM
       hz_parties                   party
     , hz_cust_accounts             cust
   WHERE
       CUST.ACCOUNT_NUMBER        = p_CUSTOMER_NUMBER
   AND cust.Party_Id              = party.Party_Id;

BEGIN 

   OPEN RCPTNUM;
   FETCH RCPTNUM INTO lc_Cons_Billing_Number;
   CLOSE RCPTNUM;

   OPEN CASHRECPT;
   FETCH CASHRECPT INTO lc_Name;
   CLOSE CASHRECPT;

   OPEN BANKBRANCH;
   FETCH BANKBRANCH INTO lc_Account_Number, lc_Bank_Name, lc_Branch_Name;
   CLOSE BANKBRANCH;

   OPEN CUSTOMER;
   FETCH CUSTOMER INTO lc_PARTY_NAME;
   CLOSE CUSTOMER;

   -- Only display the last four digits of the Account Number
   lc_Account_Number_Mask := '***' || SUBSTR(lc_Account_Number,(LENGTH(lc_Account_Number) - 3), LENGTH(lc_Account_Number));

   -- Write data out
   FND_FILE.PUT_LINE(FND_FILE.OUTPUT,(lc_Name || ' / ' ||
                                      lc_Bank_Name || ' / ' ||
                                      lc_Branch_Name || ' / ' ||
                                      lc_Account_Number_Mask || ',' ||
                                      p_DATE_DDMONYY || ',' ||
                                      p_DATE_YYYYMMDD || '-' || 
                                      p_CUSTOMER_NUMBER || '-' || 
                                      p_NUMBER || ',' ||
                                      p_RECEIPT_AMOUNT || ',' ||
                                      lc_Cons_Billing_Number || ',' ||
                                      p_CUSTOMER_NUMBER || ',' ||
                                      lc_PARTY_NAME || ',' ||
                                      p_BANK_CHARGE || ',' ||
                                      p_ALERT || ',' ||
                                      p_ERROR
                                      ));

END XXHA_WRITE_OUTPUT;

------------------------------------------------------------------------------------------
-- XXHA_FIND_MATCH_CBI_AMT_JRC

PROCEDURE XXHA_FIND_MATCH_CBI_AMT_JRC(p_CUSTOMER_NAME_BANKING     IN  VARCHAR2
                                    , p_TOTAL_RECEIPT_AMOUNT      IN  NUMBER
                                    , p_CBI_AMOUNT_DUE_REMAINING  OUT NUMBER
                                    , p_CUSTOMER_NUMBER           OUT NUMBER
                                    , p_CUSTOMER_CUST_ACCOUNT_ID  OUT NUMBER
                                    , p_CBI_CONS_INV_ID           OUT NUMBER
                                    , p_multi_matching_CBI_found  OUT VARCHAR2) AS

   -- Cursor to retrieve Customers w/CBI data
   CURSOR CUSTCBI_MATCH (p_CUSTOMER_NAME_BANKING HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE, p_TOTAL_RECEIPT_AMOUNT ar_payment_schedules_all.AMOUNT_DUE_REMAINING%TYPE)
   IS
   SELECT
       hae.CUSTOMER_NUMBER          "CUSTOMER_NUMBER"
     , CUST.CUST_ACCOUNT_ID         "CUST_ACCOUNT_ID"
     , CBI.CONS_INV_ID              "CBI_CONS_INV_ID"
     , CBI.AMOUNT_DUE_REMAINING     "CBI_AMOUNT_DUE_REMAINING"
   FROM
       hz_parties                    party
     , hz_cust_accounts              cust
     , HAEMO.XXHA_JAPAN_AR_PAYER_TBL hae
     , XXHA_JAPAN_AR_V               CBI
   WHERE
       hae.CUSTOMER_NAME_BANKING   = p_CUSTOMER_NAME_BANKING
   AND hae.CUSTOMER_NUMBER         = CUST.ACCOUNT_NUMBER
   AND cust.Party_Id               = party.Party_Id
   AND CUST.CUST_ACCOUNT_ID        = CBI.CUST_ACCOUNT_ID
   AND CBI.AMOUNT_DUE_REMAINING    = p_TOTAL_RECEIPT_AMOUNT
   ORDER BY
       hae.CUSTOMER_NAME_BANKING
     , NVL(hae.PRIORITY,0)
     , hae.CUSTOMER_NUMBER;

   -- Data
   l_CUSTOMER_NUMBER               hz_cust_accounts.ACCOUNT_NUMBER%TYPE;    
   l_CUSTOMER_CUST_ACCOUNT_ID      hz_cust_accounts.CUST_ACCOUNT_ID%TYPE;
   l_CBI_CONS_INV_ID               ar_cons_inv_trx_all.cons_inv_id%TYPE;
   l_CBI_AMOUNT_DUE_REMAINING      ar_payment_schedules_all.amount_due_remaining%TYPE;
   l_multi_matching_CBI_found      VARCHAR2 (1);

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_FIND_MATCH_CBI_AMT_JRC');

   -- Reset flags
   l_CUSTOMER_NUMBER               := NULL;
   l_CUSTOMER_CUST_ACCOUNT_ID      := NULL;
   l_CBI_CONS_INV_ID               := NULL;
   l_CBI_AMOUNT_DUE_REMAINING      := NULL;
   l_multi_matching_CBI_found      := 'N';

   -- Loop through Customers to find a matching CBI Amount.  There could be multiples where p_TOTAL_RECEIPT_AMOUNT = CBI.AMOUNT_DUE_REMAINING
   OPEN CUSTCBI_MATCH(p_CUSTOMER_NAME_BANKING, p_TOTAL_RECEIPT_AMOUNT);
   LOOP
       FETCH CUSTCBI_MATCH INTO l_CUSTOMER_NUMBER, l_CUSTOMER_CUST_ACCOUNT_ID, l_CBI_CONS_INV_ID, l_CBI_AMOUNT_DUE_REMAINING;
       IF CUSTCBI_MATCH%FOUND THEN
          l_multi_matching_CBI_found   := 'Y';
          EXIT;
       END IF;
       IF CUSTCBI_MATCH%NOTFOUND THEN
          l_multi_matching_CBI_found   := 'N';
          EXIT;
       END IF;
   END LOOP;

   -- Set return values
   IF l_multi_matching_CBI_found = 'Y' THEN
      p_multi_matching_CBI_found   := l_multi_matching_CBI_found;
      p_CBI_AMOUNT_DUE_REMAINING   := l_CBI_AMOUNT_DUE_REMAINING;
      p_CUSTOMER_NUMBER            := l_CUSTOMER_NUMBER;
      p_CUSTOMER_CUST_ACCOUNT_ID   := l_CUSTOMER_CUST_ACCOUNT_ID;
      p_CBI_CONS_INV_ID            := l_CBI_CONS_INV_ID;
   ELSE
      p_multi_matching_CBI_found   := l_multi_matching_CBI_found;
      p_CBI_AMOUNT_DUE_REMAINING   := NULL;
      p_CUSTOMER_NUMBER            := NULL;
      p_CUSTOMER_CUST_ACCOUNT_ID   := NULL;
      p_CBI_CONS_INV_ID            := NULL;
   END IF;

END XXHA_FIND_MATCH_CBI_AMT_JRC;

------------------------------------------------------------------------------------------
-- XXHA_FIND_MATCH_CBI_AMT_NONJRC

PROCEDURE XXHA_FIND_MATCH_CBI_AMT_NONJRC(p_CUSTOMER_NAME_BANKING     IN  VARCHAR2
                                       , p_TOTAL_RECEIPT_AMOUNT      IN  NUMBER
                                       , p_CBI_AMOUNT_DUE_REMAINING  OUT NUMBER
                                       , p_CUSTOMER_NUMBER           OUT NUMBER
                                       , p_CUSTOMER_CUST_ACCOUNT_ID  OUT NUMBER
                                       , p_CBI_CONS_INV_ID           OUT NUMBER
                                       , p_multi_matching_CBI_found  OUT VARCHAR2) AS

   -- Cursor to retrieve Customers w/CBI data
   CURSOR CUSTCBI_MATCH (p_CUSTOMER_NAME_BANKING HAEMO.XXHA_JAPAN_AR_PAYER_TBL.CUSTOMER_NAME_BANKING%TYPE)
   IS
   SELECT
       hae.CUSTOMER_NUMBER          "CUSTOMER_NUMBER"
     , CUST.CUST_ACCOUNT_ID         "CUST_ACCOUNT_ID"
     , CBI.CONS_INV_ID              "CBI_CONS_INV_ID"
     , CBI.AMOUNT_DUE_REMAINING     "CBI_AMOUNT_DUE_REMAINING"
   FROM
       hz_parties                    party
     , hz_cust_accounts              cust
     , HAEMO.XXHA_JAPAN_AR_PAYER_TBL hae
     , XXHA_JAPAN_AR_V               CBI
   WHERE
       hae.CUSTOMER_NAME_BANKING   = p_CUSTOMER_NAME_BANKING
   AND hae.CUSTOMER_NUMBER         = CUST.ACCOUNT_NUMBER
   AND cust.Party_Id               = party.Party_Id
   AND CUST.CUST_ACCOUNT_ID        = CBI.CUST_ACCOUNT_ID
   ORDER BY
       hae.CUSTOMER_NAME_BANKING
     , NVL(hae.PRIORITY,0)
     , CBI.CONS_INV_ID;

   -- Data
   l_CUSTOMER_NUMBER               hz_cust_accounts.ACCOUNT_NUMBER%TYPE;    
   l_CUSTOMER_CUST_ACCOUNT_ID      hz_cust_accounts.CUST_ACCOUNT_ID%TYPE;
   l_CBI_CONS_INV_ID               ar_cons_inv_trx_all.cons_inv_id%TYPE;
   l_CBI_AMOUNT_DUE_REMAINING      ar_payment_schedules_all.amount_due_remaining%TYPE;
   l_multi_matching_CBI_found      VARCHAR2 (1);

BEGIN

   FND_FILE.PUT_LINE(FND_FILE.LOG,'XXHA_FIND_MATCH_CBI_AMT_NONJRC');

   -- Reset flags
   l_CUSTOMER_NUMBER               := NULL;
   l_CUSTOMER_CUST_ACCOUNT_ID      := NULL;
   l_CBI_CONS_INV_ID               := NULL;
   l_CBI_AMOUNT_DUE_REMAINING      := NULL;
   l_multi_matching_CBI_found      := 'N';

   -- Check first CBI record for match, if none exists, then process as normal
   OPEN CUSTCBI_MATCH(p_CUSTOMER_NAME_BANKING);
   FETCH CUSTCBI_MATCH INTO l_CUSTOMER_NUMBER, l_CUSTOMER_CUST_ACCOUNT_ID, l_CBI_CONS_INV_ID, l_CBI_AMOUNT_DUE_REMAINING;
   IF l_CBI_AMOUNT_DUE_REMAINING = p_TOTAL_RECEIPT_AMOUNT THEN
      l_multi_matching_CBI_found   := 'Y';
   END IF;

   -- Set return values
   IF l_multi_matching_CBI_found = 'Y' THEN
      p_multi_matching_CBI_found   := l_multi_matching_CBI_found;
      p_CBI_AMOUNT_DUE_REMAINING   := l_CBI_AMOUNT_DUE_REMAINING;
      p_CUSTOMER_NUMBER            := l_CUSTOMER_NUMBER;
      p_CUSTOMER_CUST_ACCOUNT_ID   := l_CUSTOMER_CUST_ACCOUNT_ID;
      p_CBI_CONS_INV_ID            := l_CBI_CONS_INV_ID;
   ELSE
      p_multi_matching_CBI_found   := l_multi_matching_CBI_found;
      p_CBI_AMOUNT_DUE_REMAINING   := NULL;
      p_CUSTOMER_NUMBER            := NULL;
      p_CUSTOMER_CUST_ACCOUNT_ID   := NULL;
      p_CBI_CONS_INV_ID            := NULL;
   END IF;

END XXHA_FIND_MATCH_CBI_AMT_NONJRC;

END XXHA_JAPAN_AR_PKG;