CREATE OR REPLACE PACKAGE
   XXHA_INV_ITEM_CONV_PK
-- +===================================================================+
-- |                       Oracle NAIO (India)                         |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- | Name             : XXHA_INV_ITEM_CONV_PK                          |
-- | Description      : This is the package for validating the items   |
-- |                    records and importing the valid items from     |
-- |                    staging tables to interface table.             |
-- |                                                                   |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  20-Sep-06  Rahul Raut       Initial draft version        |
-- |1.0       18-Oct-06  Rahul Raut       After Review                 |
-- |1.1       15-Dec-06  Rahul Raut       Removed declaration of       |
-- |                                      procedure INSERT_ERROR_PRC   |
-- |                                      Added global variable for Set|
-- |                                      Process Id for Master and    |
-- |                                      Child inventory orgs         |
-- |1.2                                   Added parameter              |
-- |                                      p_org_assigments_flag        |
-- |                                      under VALIDATE_ITEM_DATA prc |
-- +===================================================================+
AS
      -- Global Variables Declaration

      gn_record_number         xxha_common_errors.record_number%TYPE;                                          --Record_number of staging table
      gc_record_identifier     xxha_common_errors.record_identifier%TYPE;                                      --Record identifier of staging table
      gc_error_code            xxha_common_errors.error_code%TYPE;                                             --Error_code insert in common error table
      gc_error_msg             xxha_common_errors.error_msg%TYPE;                                              --Error_msg  insert in common error table
      gc_comments              xxha_common_errors.comments%TYPE;                                               --Comments   insert in common error table
      gc_attribute1            xxha_common_errors.attribute1%TYPE;                                             --Attribute1 insert in common error table
      gc_attribute2            xxha_common_errors.attribute2%TYPE;                                             --Attribute2 insert in common error table
      gc_attribute3            xxha_common_errors.attribute3%TYPE;                                             --Attribute3 insert in common error table
      gc_attribute4            xxha_common_errors.attribute4%TYPE;                                             --Attribute4 insert in common error table
      gc_attribute5            xxha_common_errors.attribute5%TYPE;                                             --Attribute5 insert in common error table
      gc_table_name            xxha_common_errors.table_name%TYPE;                                             --Variable to get Staging Table Name
      gc_status                VARCHAR2(2);                                                                    --Variable to get status flag of data insertion in common error table
      gc_conc_name             fnd_concurrent_programs.concurrent_program_name%TYPE :='XXHA_ITEM_CONV';        --Concurrent program name to delete the records from common error table
      gn_user_id               fnd_user.user_id%TYPE                                :=FND_GLOBAL.USER_ID;      --User name for running conversion program
      gc_material_sub_element  bom_resources.resource_code%TYPE                     :='Material';              --Material Sub Element
      gc_debug_flag            VARCHAR2(1);                                                                    --Debug_flag for display debug
      gc_category_set_name     mtl_category_sets_tl.category_set_name%TYPE          :='Inventory'   ;          --Default Category Set name
      gc_transaction_type      mtl_system_items_interface.transaction_type%TYPE     :='CREATE';                --Default transaction_type
      gc_process_flag          mtl_system_items_interface.process_flag%TYPE         :='1';                     --Default process_flag
      gc_master_org            mtl_parameters.organization_code%TYPE                :='MST';                   --Master Organization Name
      gc_template_d            mtl_item_templates.template_name%TYPE                :='Disposable Finished Goods'; --Template Name for Template Identifier D
      gc_template_s            mtl_item_templates.template_name%TYPE                :='Parts - Non returnable';--Template Name for Template Identifier S
      gc_template_n            mtl_item_templates.template_name%TYPE                :='Non-Inventory';         --Template Name for Template Identifier E
      gc_template_e            mtl_item_templates.template_name%TYPE                :='Equipment Finished Goods';--Template Name for Template Identifier N
      gc_template_r            mtl_item_templates.template_name%TYPE                :='Parts - Returnable';    --Template Name for Template Identifier R
      gc_language_code         fnd_languages.language_code%TYPE                     :='US';                    --Language_code
      gc_log_msg               VARCHAR2(1000);                                                                 --Log_msg to display msgs
      gc_error_report          VARCHAR2(1)                                          := 'N';                    --Error_report launch if its <>'N'
      gn_request_id            xxha_common_errors.request_id%TYPE                   := fnd_global.conc_request_id;--Request Id of running concurrent Program
      gc_program_name          VARCHAR2(50)                                         :='Item Conversion';       --Program Name In parameter for launch_error_prc procedure
      gc_rec_identifier        VARCHAR2(50)                                         :='Item Number';           --Record identifier In parameter for launch_error_prc procedure
      gc_auto_lot_alpha_prefix mtl_system_items_interface.auto_lot_alpha_prefix%TYPE:='1';                     --Variable for auto_lot_alpha_prefix
      gc_start_auto_lot_number mtl_system_items_interface.start_auto_lot_number%TYPE:='1';                     --Variable for start_auto_lot_number
      gc_starting_revision     mtl_parameters.starting_revision%TYPE;                                          --Variable to get staring revision against the Inventory Orgs

      --Start of changes V1.1
      gc_set_proc_id_mst       mtl_system_items_interface.set_process_id%TYPE       :=1;                       --Variable to get set process id for Master Inventory Org
      gc_set_proc_id_child     mtl_system_items_interface.set_process_id%TYPE       :=2;                       --Variable to get set process id for Child Inventory Orgs
      --End of changes V1.1
      --Start of Changes V1.2
       gc_org_assigments_flag   VARCHAR2(10);
      --End of Changes V1.2

     --------------------------------------------------
      --Procedure to validate and process items records
      --------------------------------------------------
      PROCEDURE VALIDATE_ITEM_DATA(
                                  errbuf        OUT VARCHAR2
                                 ,retcode       OUT VARCHAR2
                                 ,p_debug       IN  VARCHAR2
                                 ,p_purge_data  IN  VARCHAR2
                                 --Start of Changes V1.2
                                 ,p_org_assigments_flag IN  VARCHAR2
                                 --End of Changes V1.2
                                 );
      ------------------------------------------------------------
      --Procedure to insert validated records into Interface table
      ------------------------------------------------------------
      PROCEDURE MOVE_ITEM_DATA(
                               p_debug         IN VARCHAR2
                              ,x_process_flag  OUT VARCHAR2
                              ) ;
END XXHA_INV_ITEM_CONV_PK  ;

/


CREATE OR REPLACE PACKAGE BODY
   XXHA_INV_ITEM_CONV_PK
-- +===================================================================+
-- |                       Oracle NAIO (India)                         |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- | Name             : XXHA_INV_ITEM_CONV_PK                          |
-- | Description      : This is the package for validating the items   |
-- |                    records and importing the valid items from     |
-- |                    staging tables to interface table.             |
-- |                                                                   |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  20-Sep-06  Rahul Raut       Initial draft version        |
-- |1.0       18-Oct-06  Rahul Raut       After review                 |
-- |1.1       02-Nov-06  Rahul Raut       Commented asset_creation_code|
-- |                                      logic                        |
-- |                                      Changed the comments for     |
-- |                                      cursor lcu_val_att_set       |
-- |                                      Defaulted the Item Desc to   |
-- |                                      Item No if its null          |
-- |1.2      08-Dec-06   Rahul Raut       Added Cursor                 |
-- |                                      lcu_val_template_name to     |
-- |                                      validate distinct Template   |
-- |                                      Name                         |
-- |                                      Added Cursor lcu_get_sob_id  |
-- |                                      to check SOB against         |
-- |                                      profile value                |
-- |                                      Changed the oraclecharfld1=VS|
-- |                                      condition to NOT NULL for    |
-- |                                      checking duplication         |
-- |                                      Added equals to condition to |
-- |                                      check Effective date         |
-- |                                      against item start date      |
-- |1.3     12-Dec-06    Rahul Raut       Added  following procedures  |
-- |                                      UPDATE_ITEM_RECORD_STATUS    |
-- |                                      UPDATE_INV_RECORD_STATUS and |
-- |                                      UPDATE_REV_RECORD_STATUS     |
-- |                                      to update status flag in     |
-- |                                      MOVE_ITEM_DATA Procedure     |
-- |                                      Added Validation to check    |
-- |                                      duplicate effectivity date   |
-- |                                      against the item number      |
-- |                                      Added Rollback and Commit    |
-- |                                      In MOVE_ITEM_DATA Procedure  |
-- |                                      Added ln_set_process_id      |
-- |                                      variable to get set process  |
-- |                                      id for Master and Child      |
-- |                                      inventory Organization       |
-- |                                                                   |
-- |1.4     07-Feb-07   Subbu             Added error flag             |
-- |                                      'lc_inv_error_exists' under  |
-- |                                      exception block for 	       |
-- |                                      sales_Account Validation     |
-- |                                      of Inv Orgs cursor           |
-- |1.5   12-Feb-07   Subbu               Modified Err messages        |
-- |                                      Added one more parameter to the
-- |                                      Validate procedure for ristrict
-- |                                      master records and validate and
-- |                                      assign for Inv Org records
-- |
-- |                                      Changed the Derivation value for
-- |                                      material cost from field
-- |                                      FROZENSTDCOST to INVORG_ITEMCOST
-- |
-- |
-- |                                     Commented logic for expense a/c
-- |                                     that gets the account and added
-- |                                     logic to get CCID instead
-- |                                     Modified the Org Assign logic
-- |1.6   27-Feb-07   Subbu              Modified the Serial/Lot control
-- |                                     Logic
-- +===================================================================+
-- +===================================================================+
-- |                       Haemonetics                                 |
-- |                         Braintree                                 |
-- +===================================================================+
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author        Remarks                        |
-- |1.7   24-Oct-07       IPadela       Modified the Serial control    |
-- |                                    validation logic to include the|
-- |                                    value 6 - At Sales Order Issue |
-- |                                    as acceptable value            |
-- |                                    Also mapped the value in       |
-- |                                    SellingUOM field in Staging    |
-- |                                    table to primary_UOM_code field|
-- |                                    in the interface table. Hence  |
-- |                                    UOM will now not default from  |
-- |                                    template but has to be set as  |
-- |                                    per the staging table          |
-- +===================================================================+
AS

PROCEDURE INSERT_ERROR_PRC
-- +===================================================================+
-- | Name            : INSERT_ERROR_PRC                                |
-- | Description     : Procedure to call                               |
-- |                   xxha_common_utilities.insert_error_prc          |
-- |                   For inserting error records into                |
-- |                   common error table                              |
-- | Call From       : The procedure is called from VALIDATE_ITEM_DATA |
-- |                   and MOVE_ITEM_DATA procedure                    |
-- | Parameters      :                                                 |
-- |   IN: None                                                        |
-- |  OUT: None                                                        |
-- |                                                                   |
-- | Returns         :                                                 |
-- +===================================================================+
IS
   BEGIN
      gc_error_report:='Y';
      xxha_common_utilities_pkg.insert_error_prc(
                                                 gn_request_id
                                                ,gn_record_number
                                                ,gc_record_identifier
                                                ,gc_error_code
                                                ,gc_error_msg
                                                ,gc_comments
                                                ,gc_table_name
                                                ,gc_attribute1
                                                ,gc_attribute2
                                                ,gc_attribute3
                                                ,gc_attribute4
                                                ,gc_attribute5
                                                ,gc_status
                                                );

   EXCEPTION
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_INV_ITEM_CONV_PK.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
END INSERT_ERROR_PRC;

--Start of changes V1.3
-- +=======================================================================+
-- | Name        :  UPDATE_ITEM_RECORD_STATUS                              |
-- | Description :  Procedure to update  the status of processed           |
-- |                records in USBPCS_ITEM_CLEANED table                   |
-- | Call From   :  Procedure is called from MOVE_ITEM_DATA procedure      |
-- |                                                                       |
-- | Parameters  :  p_request_id                                           |
-- |                p_status_flag                                          |
-- |                p_itemnbr                                              |
-- | Returns     :  None                                                   |
-- +=======================================================================+
PROCEDURE UPDATE_ITEM_RECORD_STATUS (
                                     p_status_flag   IN   VARCHAR2
                                    ,p_request_id    IN   NUMBER
                                    ,p_itemnbr       IN   VARCHAR2
                                    )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  usbpcs_item_cleaned UIC
   SET     UIC.oraclecharfld1  =   p_status_flag
          ,UIC.oracleintfld8   =   p_request_id
   WHERE   UIC.itemnumber      =   p_itemnbr;

   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_INV_ITEM_CONV_PK.UPDATE_ITEM_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_ITEM_RECORD_STATUS;
--End of changes V1.3

--Start of changes V1.3
-- +=======================================================================+
-- | Name        :  UPDATE_INV_RECORD_STATUS                               |
-- | Description :  Procedure to update  the status of processed           |
-- |                records in USBPCS_ITEM_INVORG table                    |
-- |                                                                       |
-- | Call From   :  Procedure is called from MOVE_ITEM_DATA procedure      |
-- | Parameters  :  p_request_id                                           |
-- |                p_status_flag                                          |
-- |                p_itemnbr                                              |
-- |                p_invorg
-- | Returns     :  None                                                   |
-- +=======================================================================+
PROCEDURE UPDATE_INV_RECORD_STATUS (
                                     p_status_flag   IN   VARCHAR2
                                    ,p_request_id    IN   NUMBER
                                    ,p_itemnbr       IN   VARCHAR2
                                    ,p_invorg        IN   VARCHAR2
                                    )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  usbpcs_item_invorg UII
   SET     UII.oraclecharfld1  =   p_status_flag
          ,UII.oracleintfld8   =   p_request_id
   WHERE   UII.itemnbr         =   p_itemnbr
   AND     UII.invorg          =   p_invorg;

   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_INV_ITEM_CONV_PK.UPDATE_INV_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_INV_RECORD_STATUS;
--End of changes V1.3

--Start of changes V1.3
-- +=======================================================================+
-- | Name        :  UPDATE_REV_RECORD_STATUS                               |
-- | Description :  Procedure to update  the status of processed           |
-- |                records in USBPCS_REVISION table                       |
-- |                                                                       |
-- | Call From   :  Procedure is called from MOVE_ITEM_DATA procedure      |
-- | Parameters  :  p_request_id                                           |
-- |                p_status_flag                                          |
-- |                p_itemnbr                                              |
-- |                p_revision                                             |
-- | Returns     :  None                                                   |
-- +=======================================================================+
PROCEDURE UPDATE_REV_RECORD_STATUS (
                                     p_status_flag   IN   VARCHAR2
                                    ,p_request_id    IN   NUMBER
                                    ,p_itemnbr       IN   VARCHAR2
                                    ,p_revision      IN   VARCHAR2
                                    )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  usbpcs_revision UR
   SET     UR.oraclecharfld1  =   p_status_flag
          ,UR.oracleintfld8   =   p_request_id
   WHERE   UR.itemnbr         =   p_itemnbr
   AND     UR.revisionnbr     =   p_revision;

   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_INV_ITEM_CONV_PK.UPDATE_REV_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_REV_RECORD_STATUS;
--End of changes V1.3


PROCEDURE CHECK_ITEM_SETUP (
                           x_setup_err_flag OUT VARCHAR2
                           )
-- +===================================================================+
-- | Name            : CHECK_ITEM_SETUP                                |
-- | Description     : Procedure to validate all the setup             |
-- |                   required prior of running Items Conversion      |
-- |                                                                   |
-- | Call From       :  Procedure is called from VALIDATE_ITEM_DATA    |
-- |                    procedure                                      |
-- | Parameters      :                                                 |
-- |   IN: None                                                        |
-- |  OUT: None                                                        |
-- |                                                                   |
-- | Returns : x_setup_err_flag                                        |
-- +===================================================================+
IS

   -- Local Variables Declaration
   lc_err_flag       VARCHAR2(1):='N';                         -- Error_flag for checking the setup
   lc_mst_err_flag   VARCHAR2(1):='N';                         -- Master Error_flag for checking the setup
   ln_rec_count      NUMBER :=0;                               -- Variable to fetch value of COUNT(*)
   lc_temp_value     VARCHAR2(1);                              -- Variable to hold value of Cursor

   --Cursor to validate Language Code
   CURSOR lcu_val_lang_code(
                           p_lang_code VARCHAR2
                           )
   IS
   SELECT 'N'
   FROM   fnd_languages FL
   WHERE  FL.language_code = p_lang_code;

   --Cursor to validate Category Set Name
   CURSOR lcu_val_category_set(
                              p_category_set_name VARCHAR2
                              )
   IS
   SELECT 'N'
   FROM   mtl_category_sets_tl MCST
   WHERE  MCST.category_set_name = p_category_set_name
   AND    MCST.language          = gc_language_code;

   -- Start of changes V1.1
   --Cursor to fetch distinct Inventory Organizations.
   --The Attribute6 of each Organization will be validated in the cursor lcu_val_attribute
   --The Material Sub Element will be validated for each organization in the cursor lcu_val_material
   --End of changes V1.1

   CURSOR lcu_val_att_set
   IS
   SELECT DISTINCT(UII.invorg)
   FROM   usbpcs_item_invorg UII
   WHERE  UII.invorg IS NOT NULL ;

   --Cursor to validate DFF(attribute6) for material cost
   CURSOR lcu_val_attribute(
                           p_organization_code VARCHAR2
                           )
   IS
   SELECT 'N'
   FROM   mtl_parameters MP
   WHERE  MP.attribute6 IS NULL
   AND    MP.organization_code = p_organization_code;

   --Cursor to validate material sub element set up
   CURSOR lcu_val_material(
                           p_organization_code VARCHAR2
                           )
   IS
   SELECT 'N'
   FROM   bom_resources  BR
         ,mtl_parameters MP
   WHERE  MP.organization_id     =BR.organization_id
   AND    BR.resource_code       =gc_material_sub_element
   AND    MP.organization_code   =p_organization_code
   AND    BR.disable_date        >= TRUNC(SYSDATE);


   --Cursor to validate template_name specified is not against organization -- INV_ORG_TEMPLATE_ERROR
   CURSOR lcu_val_template_org
   IS
   SELECT 'N'
   FROM    mtl_item_templates MIT
          ,mtl_parameters MP
          ,usbpcs_item_cleaned ITEM
          ,usbpcs_item_invorg INV
   WHERE   MIT.context_organization_id IS NOT NULL
   AND     INV.invorg         = MP.organization_code
   AND     MP.organization_id <> MIT.context_organization_id
   AND     INV.itemnbr        =ITEM.itemnumber
   AND     MIT.template_name  = DECODE ( item.oracletemplateid
                                       ,'D', gc_template_d
                                       ,'S', gc_template_s
                                       ,'N', gc_template_n
                                       ,'E', gc_template_e
                                       ,'R', gc_template_r
                                       );

   --Cursor to validate  Master Org Set Up
   CURSOR lcu_val_master_org
   IS
   SELECT 'N'
   FROM    mtl_parameters MP
   WHERE   MP.organization_code     = gc_master_org
   AND     MP.master_organization_id=MP.organization_id ;

   -- Start of changes V1.2
   -- Changes made to validate distinct Template Name
   --Cursor to check Template Name set up
   CURSOR lcu_val_template_name (
                                 p_template_name VARCHAR2
                                )
   IS
   SELECT 'N'
   FROM   mtl_item_templates MIT
   WHERE  MIT.template_name =p_template_name;

   --End of changes V1.2

   --Start of changes V1.2
   --Added Setup to check SOB check against profile value

   --Cursor to check set of books id set up
   CURSOR lcu_get_sob_id (
                          p_sob_id NUMBER
                         )
   IS
   SELECT 'N'
   FROM   gl_sets_of_books GSOB
   WHERE  GSOB.set_of_books_id = p_sob_id;

   --End of changes V1.2

BEGIN
   lc_err_flag :='N';
   ------------------------------
   --Validate Language Code
   ------------------------------
   OPEN  lcu_val_lang_code(gc_language_code);
   FETCH lcu_val_lang_code INTO lc_temp_value;
      IF lcu_val_lang_code%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code :='SETUP-Error';
         gc_error_msg  := gc_language_code||' has not been set up as valid language code';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_lang_code ;
   gc_log_msg:='Flag returned by the Language Code validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ------------------------------
   --Validate Category Set Name
   ------------------------------
   OPEN  lcu_val_category_set(gc_category_set_name);
   FETCH lcu_val_category_set INTO lc_temp_value;
      IF lcu_val_category_set%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code :='SETUP-Error';
         gc_error_msg  := gc_category_set_name||' has not been set up as valid Category Set';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_category_set ;
   gc_log_msg:='Flag returned by the Category Set Name validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ------------------------------
   --Validate Master Org Set Up
   ------------------------------
   BEGIN
      OPEN  lcu_val_master_org;
      FETCH lcu_val_master_org INTO lc_temp_value;
         IF lcu_val_master_org%NOTFOUND THEN
            lc_err_flag   :='Y';
            gc_error_code := 'SETUP-Error';
            gc_error_msg  := 'Master org  '||gc_master_org||' has not been set up in the system';
            INSERT_ERROR_PRC;
         END IF;
      CLOSE lcu_val_master_org;
   EXCEPTION
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Validating Master Organization Set Up ' ||SQLERRM);
   END;
   gc_log_msg:='Flag returned by the Master Org Set Up '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   -- Start of changes V1.2
   ------------------------------
   --Validate Template Name Setup
   ------------------------------
   OPEN  lcu_val_template_name(gc_template_d );
   FETCH lcu_val_template_name  INTO lc_temp_value;
      IF lcu_val_template_name%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Template Name: '||gc_template_d||' has not been set up in the system';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_template_name;
   gc_log_msg:='Flag returned by the Template Name '||gc_template_d||'  Setup '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   OPEN  lcu_val_template_name(gc_template_s);
   FETCH lcu_val_template_name  INTO lc_temp_value;
      IF lcu_val_template_name%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Template Name: '||gc_template_s||' has not been set up in the system';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_template_name;
   gc_log_msg:='Flag returned by the Template Name '||gc_template_s||'  Setup '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   OPEN  lcu_val_template_name(gc_template_n);
   FETCH lcu_val_template_name  INTO lc_temp_value;
      IF lcu_val_template_name%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Template Name: '||gc_template_n||' has not been set up in the system';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_template_name;
   gc_log_msg:='Flag returned by the Template Name '||gc_template_n||'  Setup '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   OPEN  lcu_val_template_name(gc_template_e);
   FETCH lcu_val_template_name  INTO lc_temp_value;
      IF lcu_val_template_name%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Template Name: '||gc_template_e||' has not been set up in the system';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_template_name;
   gc_log_msg:='Flag returned by the Template Name '||gc_template_e||'  Setup '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   OPEN  lcu_val_template_name(gc_template_r);
   FETCH lcu_val_template_name  INTO lc_temp_value;
      IF lcu_val_template_name%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Template Name: '||gc_template_r||' has not been set up in the system';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_template_name;
   gc_log_msg:='Flag returned by the Template Name '||gc_template_r||'  Setup '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   -- End of changes V1.2

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ------------------------------------------------------
   --Validate set up of DFF(attribute6) for material cost
   -------------------------------------------------------
   FOR val_att_set_rec IN lcu_val_att_set
   LOOP
      OPEN  lcu_val_attribute(val_att_set_rec.invorg);
      FETCH lcu_val_attribute INTO lc_temp_value;
         IF lcu_val_attribute%FOUND THEN
            lc_err_flag   :='Y';
            gc_error_code := 'SETUP-Error';
            gc_error_msg  := 'Attribute6 has not been set up for the organization '||val_att_set_rec.invorg;
            INSERT_ERROR_PRC;
         END IF;
      CLOSE lcu_val_attribute;
      gc_log_msg:='Flag returned by the DFF(attribute6) for material cost Setup for the organization '||val_att_set_rec.invorg||' is '||lc_err_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      IF lc_err_flag ='Y' THEN
         lc_mst_err_flag:='Y';
         lc_err_flag:='N';
      END IF;

      --------------------------------------------------------------------------
         --Validation of Material Sub Element for each Inventory Organization
      --------------------------------------------------------------------------
      OPEN  lcu_val_material(val_att_set_rec.invorg);
      FETCH lcu_val_material INTO lc_temp_value;
         IF lcu_val_material%FOUND THEN
            lc_err_flag   :='Y';
            gc_error_code := 'SETUP-Error';
            gc_error_msg  :='The '||gc_material_sub_element||' Sub Element has not been set for the Organization '||val_att_set_rec.invorg;
            INSERT_ERROR_PRC;
         END IF;
      CLOSE lcu_val_material;
      gc_log_msg:='Flag returned by the Material Sub Element set up for Inventory Organization '||val_att_set_rec.invorg||' is '||lc_err_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   END LOOP;

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   --------------------------------------------------------------
   --Validate template_name specified is not against organization
   --------------------------------------------------------------
   OPEN  lcu_val_template_org;
   FETCH lcu_val_template_org INTO lc_temp_value;
      IF lcu_val_template_org%FOUND THEN
         lc_err_flag   :='Y';
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='An Organization specific template is being used by an item that needs to be imported into another organization';
        INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_val_template_org ;
   gc_log_msg:='Flag returned by the template_name validation against the Inventory organization '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   --Start of changes V1.2
   --------------------------------------------------------------
   --Validate Set Of Books Id Set Up against User Name
   --------------------------------------------------------------
   OPEN  lcu_get_sob_id(FND_PROFILE.VALUE('GL_SET_OF_BKS_ID'));
   FETCH lcu_get_sob_id  INTO lc_temp_value;
      IF lcu_get_sob_id%NOTFOUND THEN
         lc_err_flag   :='Y';
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='Set Of Books Id is not fetched for the User Login';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_get_sob_id;
   gc_log_msg:='Flag returned by the Set Of Books Id Setup '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   -- End of changes V1.2

   IF lc_err_flag ='Y' THEN
      lc_mst_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   IF  lc_mst_err_flag <>'N' THEN
      x_setup_err_flag:='Y';
   ELSE
      x_setup_err_flag:='N';
   END IF;

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_INV_ITEM_CONV_PK.CHECK_ITEM_SETUP_PRC ' ||SQLERRM);
   RAISE;
END CHECK_ITEM_SETUP;

PROCEDURE VALIDATE_ITEM_DATA (
                              errbuf       OUT VARCHAR2
                             ,retcode      OUT VARCHAR2
                             ,p_debug      IN  VARCHAR2
                             ,p_purge_data IN  VARCHAR2
                             ,p_org_assigments_flag IN  VARCHAR2
                             )
 -- +===================================================================+
 -- | Name            : VALIDATE_ITEM_DATA                              |
 -- | Description     : Procedure to validate and process Items,        |
 -- |                   Categories.Revisions Records From Staging tables|
 -- |                   To Oracle Inventory interface Tables            |
 -- |                                                                   |
 -- |Call From        : This procedure is registered as Concurrent      |
 -- |                   Program executable file name                    |
 -- |Parameters       :                                                 |
 -- |                                                                   |
 -- | IN              : p_debug,p_purge_data                            |
 -- | OUT             : errbuf,errbuf                                   |
 -- |                                                                   |
 -- | Returns         :                                                 |
 -- +===================================================================+
IS
   -- Local Variable Declaration
   lc_error_exists          VARCHAR2(1):='N';                                       -- Error Exists Flag in Item cleaned tabled
   lc_rev_error_exists      VARCHAR2(1):='N';                                       -- Error Exists Flag in Inventory table
   lc_inv_error_exists      VARCHAR2(1):='N';                                       -- Error Exists Flag in Revision table
   lc_setup_err_flag        VARCHAR2(1):='N';                                       -- Variable to take Setup procedure Out parameter
   ln_item_rec_fetched      NUMBER:=0;                                              -- Variable to fetch total records from "usbpcs_item_cleaned" table.
   ln_inv_rec_fetched       NUMBER:=0;                                              -- Variable to fetch total records from "usbpcs_item_invorg" table.
   ln_rev_rec_fetched       NUMBER:=0;                                              -- Variable to fetch total records from "usbpcs_revision" table.
   lc_item_miss_flag        VARCHAR2(1):='N';                                       -- Item existance in staging table chking flag
   lc_item_exist_flag       VARCHAR2(1):='N';                                       -- Item existance Flag variable
   ln_rev_rejected_recs     NUMBER:=0;                                              -- Variable to fetch errored records from "usbpcs_revision" table.
   ln_item_rejected_recs    NUMBER:=0;                                              -- Variable to fetch errored records from "usbpcs_item_cleaned" table.
   ln_inv_rejected_recs     NUMBER:=0;                                              -- Variable to fetch errored records from "usbpcs_item_invorg" table.
   lc_insert_interface_flag VARCHAR2(1):='Y';                                       -- Variable to call interface insertion process
   lc_org_exist_flag        VARCHAR2(1):='N';                                       -- Variable to check existance of inventory org in Oracle
   lc_inv_exist_flag        VARCHAR2(1):='N';                                       -- Variable to check existance of item numbee in staging tables
   lc_process_flag          VARCHAR2(1):='N';                                       -- Variable return by the MOVE_ITEM_DATA_PRC procedure
   lc_cat_combn_flag        VARCHAR(2):='N';                                        -- Variable to check valid Item category segment combinations
   lc_temp_flag             VARCHAR2(1);                                            -- Variable for temporary storage of value
   ln_rec_count             NUMBER:=0;                                              -- Variable to fetch value of COUNT(*)
   lc_item_num              VARCHAR2(50):= '-9999--';                               -- Dummy Variable to check the item number
   lc_err_flag              VARCHAR2(1):='N';                                       -- Variable for Error_flag for checking validation
   ln_org_id                mtl_system_items_interface.organization_id%TYPE;        -- Variable to get Organization_id
   ln_expense_act           mtl_system_items_interface.expense_account%TYPE;        -- Variable to get expense account
   ln_sales_ccid            mtl_system_items_interface.sales_account%TYPE;          -- Variable to get expense account
   ln_cost_sales_ccid       mtl_system_items_interface.cost_of_sales_account%TYPE;  -- Variable to get cost of sales ccid
   ln_ccid                  gl_code_combinations.code_combination_id%TYPE;          -- Variable to get ccid
   lc_attribute1            mtl_categories_b.attribute1%TYPE;                       -- Variable to get new ccid
   lc_concat_segments       gl_code_combinations_kfv.concatenated_segments%TYPE;    -- Variable to get DFF(Attribute1) value
   ln_coa_id                gl_sets_of_books.chart_of_accounts_id%TYPE;             -- Variable to get chart of accounts id
   ln_template_id           mtl_system_items_interface.template_id%TYPE;            -- Variable to get template id for the template identifier
   ln_category_id           mtl_categories_b.category_id%TYPE;                      -- Variable to get category id against the concatenated segments
   ln_category_set_id       mtl_category_sets_vl.category_set_id%TYPE;              -- Variable to get category set id againsnt category name
   lc_dum   VARCHAR2(1);

   ----------------------------------------------------------------------------------------------
   -- Cursor to fetch all New Items records from staging table usbpcs_item_cleaned
   ----------------------------------------------------------------------------------------------
   CURSOR lcu_item
   IS
   SELECT *
   FROM   usbpcs_item_cleaned UIC
   --WHERE  UIC.oraclecharfld1 IS NULL;
   WHERE NVL(UIC.oraclecharfld1,'-9-') =DECODE(p_org_assigments_flag,'YES','PS1','-9-'); --subbu_feb23

   -----------------------------------------------------------------------------------------------
   -- Cursor to fetch all New  Inventory Org records  from staging table usbpcs_item_invorg
   ----------------------------------------------------------------------------------------------
   CURSOR lcu_item_inv (
                        p_item_no VARCHAR2
                       )
   IS
   SELECT *
   FROM   usbpcs_item_invorg UII
   WHERE  UII.itemnbr = p_item_no
   --V1.5  Start of Changes
   AND    UII.invorg <> DECODE(p_org_assigments_flag,'YES','MST','-9-')
   --V1.5  End of Changes
   AND    UII.oraclecharfld1 IS NULL;

   -----------------------------------------------------------------------------------------------
   -- Cursor to fetch all New Item Revisions records  from staging table usbpcs_revision
   ----------------------------------------------------------------------------------------------
   CURSOR lcu_item_rev (
                        p_item_no VARCHAR2
                       )
   IS
   SELECT *
   FROM   usbpcs_revision UR
   WHERE  UR.itemnbr= p_item_no
   --AND    UR.oraclecharfld1 IS NULL;
   AND  NVL(UR.oraclecharfld1,'-9-') =DECODE(p_org_assigments_flag,'YES','PS1','-9-'); --subbu_feb23


   --Cursor to check item existance in Oracle Base table
   CURSOR lcu_val_item_exist(
                             p_segment1 VARCHAR2
                            ,p_org_id NUMBER
                            )
   IS
   SELECT 'N'
   FROM    mtl_system_items_b MSIB
   WHERE   MSIB.segment1         =p_segment1
   AND     MSIB.organization_id  =p_org_id;


   --Cursor to check item existance in Oracle Interface table
   CURSOR lcu_val_item_exist_int(
                                 p_segment1 VARCHAR2
                               , p_org_id NUMBER
                                )
   IS
   SELECT 'N'
   FROM    mtl_system_items_interface MSII
   WHERE   MSII.segment1         =p_segment1
   AND     MSII.organization_id  =p_org_id
   AND     MSII.process_flag     =gc_process_flag;

    -- Start of changes V1.2
    -- Changes the oraclecharfld1 =VS condition to NOT NULL
   --Cursor to check duplication of Item and Revision Number
   CURSOR lcu_val_item_rev_comb(
                                p_segment1 VARCHAR2
                               ,p_revision VARCHAR2
                               )
   IS
   SELECT 'N'
   FROM    usbpcs_revision UR
   WHERE   UR.itemnbr      =p_segment1
   AND     UR.revisionnbr  =p_revision
   AND     UR.oraclecharfld1 IS NOT NULL;

   -- End of changes V1.2


   --Cursor to check order of revision number and effectivity date
   CURSOR lcu_val_item_rev_order(
                                 p_segment1 VARCHAR2
                                ,p_revision VARCHAR2
                                )
   IS
   SELECT 'N'
   FROM    usbpcs_revision UR1
          ,usbpcs_revision UR2
   WHERE   UR1.itemnbr     = UR2.itemnbr
   AND     UR1.itemnbr     = p_segment1
   AND     UR1.revisionnbr =p_revision
   AND     (
            (UR1.revisionnbr < UR2.revisionnbr)
             AND (
                  (TRUNC(UR1.effdate)     = TRUNC(SYSDATE)
                   AND TRUNC(UR2.effdate) = TRUNC(SYSDATE)
                   AND UR1.effdate        = UR2.effdate
                  )
                  OR(UR1.effdate          >= UR2.effdate)
                 )
          );

   -- Start of changes V1.2
   -- Changes the oraclecharfld1 =VS condition to NOT NULL
   --Cursor to check item number duplication against the organization
   CURSOR lcu_val_dupl_item(
                            p_segment1 VARCHAR2
                           ,p_org VARCHAR2
                           )
   IS
   SELECT 'N'
   FROM    usbpcs_item_invorg UII
   WHERE   UII.itemnbr  = p_segment1
   AND     UII.invorg   = p_org
   AND     UII.oraclecharfld1 IS NOT NULL;

   --End of changes V1.2


   --Cursor to check inventory details for the item number
   CURSOR lcu_val_inv_item_detail(
                                 p_segment1 VARCHAR2
                                 )
   IS
   SELECT 'N'
   FROM    usbpcs_item_invorg UII
   WHERE   UII.itemnbr =p_segment1;

   --Cursor to check Master inventory details for the item number
   CURSOR lcu_val_item_mst(
                           p_segment1 VARCHAR2
                          ,p_org      VARCHAR2
                          )
   IS
   SELECT 'N'
   FROM    usbpcs_item_invorg UII
   WHERE   UII.itemnbr  =p_segment1
   AND     UII.invorg   =p_org;

   --Cursor to check valid category set/category Segment combination
   CURSOR lcu_val_cat_valid_comb(
                                 p_set_id NUMBER
                                ,p_cat_id NUMBER
                                )
   IS
   SELECT   'N'
   FROM     mtl_category_set_valid_cats MCSVC
   WHERE    MCSVC.category_set_id   = p_set_id
   AND      MCSVC.category_id       = p_cat_id;

   --Cursor to check valid EXPENSE ACCOUNF GROM GL_CODE_COMBINATIONS TABLE
   CURSOR lcu_val_expense_act(
                              p_expense_act NUMBER
                             ,p_coa_id      NUMBER
                             )
   IS
   SELECT 'N'
   FROM    gl_code_combinations GCC
   WHERE   GCC.code_combination_id              = p_expense_act
   AND     GCC.chart_of_accounts_id             = p_coa_id
   AND     NVL(GCC.start_date_active,SYSDATE)   <= SYSDATE
   AND     NVL(GCC.end_date_active,SYSDATE)     >= SYSDATE;

   --Start of changes V1.3
   --Cursor to check effectivity date against the Item for duplication
   CURSOR lcu_val_effdate (
                            p_itemnr   VARCHAR2
                           ,p_effdate  DATE
                          )
   IS
   SELECT   DISTINCT('N')
   FROM     usbpcs_revision REV
   WHERE    REV.itemnbr =p_itemnr
   AND      REV. effdate=p_effdate
   AND      REV.oraclecharfld1 IS NOT NULL;
   --End of changes V1.3








BEGIN
   gn_request_id               := FND_GLOBAL.CONC_REQUEST_ID;         -- Request Id of validating data
   lc_error_exists             :='N';                                 -- Error_exits flag initialise
   gc_debug_flag               := p_debug;                            -- Debug Flag
   gc_log_msg                  :='Start of VALIDATE_ITEM_DATA_PRC...';-- Indicator to show start of Validation Procedure
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   lc_insert_interface_flag    := 'Y';                                -- Reinitialise interface insert flag

   ------------------------------------------------------------------------
   --If Purge Data flag set to Y then all Error records for Item Conversion
   --will get deleted from XXHA_COMMON_ERRORS table
   --which were generated due to earlier run of Item Conversion
   ------------------------------------------------------------------------
    --V1.5  Start of Changes
      IF p_org_assigments_flag ='YES' THEN
         gc_org_assigments_flag :='Y';
     ELSE
        gc_org_assigments_flag :='N';
     END IF;
      --V1.5  End of Changes



      ------------------------------------------------------
      --Update the the records which got procssed previously  to PS1
      -----------------------------------------------------SUBBU_FEB23
    BEGIN
      UPDATE usbpcs_item_cleaned
         SET ORACLECHARFLD1='PS1'
       WHERE oraclecharfld1='PS';

      UPDATE usbpcs_item_invorg
          SET ORACLECHARFLD1='PS1'
       WHERE oraclecharfld1='PS';


       UPDATE usbpcs_revision
          SET ORACLECHARFLD1='PS1'
       WHERE oraclecharfld1='PS';

       COMMIT;
    EXCEPTION
      WHEN OTHERs THEN
        NULL;
    END;




















   IF p_purge_data = 'Y' THEN
      xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>gc_conc_name);
   END IF;
   -- Calling setup procedure out parameter
   CHECK_ITEM_SETUP(x_setup_err_flag=>lc_setup_err_flag);

   --IF any setup are missing then error out the concurrent program else
   --start validating  the records from the staging tables

   IF lc_setup_err_flag <>'Y' THEN   -- start validating records

      --------------------------------------------------
      --Fetch charts of account id for the User Login
      --------------------------------------------------

      BEGIN
         SELECT chart_of_accounts_id
         INTO   ln_coa_id
         FROM   gl_sets_of_books
         WHERE  set_of_books_id = FND_PROFILE.VALUE('GL_SET_OF_BKS_ID');
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         lc_error_exists     :='Y';
         gc_error_code       :='ITEM-01';
         gc_error_msg        :='Chart of accounts id is not found against the Set Of Books Id '||FND_PROFILE.VALUE('GL_SET_OF_BKS_ID');
         gc_comments         :='Please check set of books set up for the user login';
         INSERT_ERROR_PRC ;
      WHEN OTHERS THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in fetching chart of accounts id is: ' ||SQLERRM);
      END;
      gc_log_msg:='Flag returned while deriving the charts of account id: '||lc_error_exists;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


   --*****************************************************************************
   -- Opening the cursor to fetch Items records from "usbpcs_item_cleaned" table
   --****************************************************************************
      FOR lr_item_rec IN lcu_item
      LOOP
         gc_record_identifier := NVL( lr_item_rec.itemnumber,'NULL')||' Item Description : '||NVL( lr_item_rec.ItemDescription,'NULL');
         gn_record_number     := lr_item_rec.oracleidentifier;
         ln_item_rec_fetched  := ln_item_rec_fetched + 1 ;                     -- Increment record fetched for usbpcs_item_cleaned table
         lc_error_exists      := 'N';                                          -- Reinitialise error_exists flag
         lc_item_miss_flag    := 'N';                                          -- Reinitialise Item exist checking flag
         ln_cost_sales_ccid   := NULL;                                         -- Reinitialise ccid fetching variable
         ln_sales_ccid        := NULL;                                         -- Reinitialise sales account ccod variable
         ln_ccid              := NULL;                                         -- Reinitialise new ccid fetching variable
         lc_attribute1        := NULL;                                         -- Reinitialise DFF (attr1) fetching variable
         lc_concat_segments   := NULL;                                         -- Reinitialise concatenated segments variable
         ln_template_id       := NULL;                                         -- Reinitialise template id variable
         ln_category_id       := NULL;                                         -- Reinitialise category id variable
         ln_category_set_id   := NULL;                                         -- Reinitialise category set id variable
         lc_cat_combn_flag    := 'N';                                          -- Reinitialise category cominations existanace flag
         lc_temp_flag         := NULL;                                         -- Reinitialise temporary flag variable
         gc_log_msg           :='USBPCS_ITEM_CLEANED-'||gc_record_identifier;  -- Log msg to get record identifier for every record
         gc_table_name        := 'USBPCS_ITEM_CLEANED';                        -- Staging table name insertion in common error table
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          ---------------------------------------------------------
            -- Validation of Item Number for Null
          ---------------------------------------------------------
         IF lr_item_rec.itemnumber IS NULL THEN
            lc_item_miss_flag   := 'Y';
            lc_error_exists     := 'Y';
            gc_error_code       :='ITEM-02';
            gc_error_msg        :='Item Number has not been provided';
            gc_comments         :='Please provide Item Number as part of usbpcs_item_cleaned table';
            INSERT_ERROR_PRC ;
         END IF ;
         gc_log_msg:='Flag returned by the Item Number validation for null as part of usbpcs_item_cleaned table'||lc_error_exists;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -- Start of changes V1.1
    /*    ---------------------------------------------------------
            -- Validation of Item Description for Null
          ---------------------------------------------------------
         IF lr_item_rec.itemdescription IS NULL THEN
            lc_error_exists     := 'Y';
            gc_error_code       :='ITEM-03';
            gc_error_msg        :='Item Description has not been provided';
            gc_comments         :='Please provide the Item Description';
            INSERT_ERROR_PRC ;
         END IF ;
         gc_log_msg:='Flag returned by the Item Description validation for null as part of usbpcs_item_cleaned table'||lc_error_exists;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg); */

         -- End of changes V1.1

          ---------------------------------------------------------
            -- Validation of revision_qty_control_code
          ---------------------------------------------------------
         IF lr_item_rec.revisioncontrol IS NOT NULL THEN
            IF lr_item_rec.revisioncontrol <>'2' THEN
               lc_error_exists     := 'Y';
               gc_error_code       :='ITEM-05';
               gc_error_msg        :='Invalid Revision Control Code: ' ||lr_item_rec.revisioncontrol||' for the Item Number: '||lr_item_rec.itemnumber;
               gc_comments         :='Revision Control Code must be either NULL or 2';
               INSERT_ERROR_PRC ;
            END IF ;
         END IF;
         gc_log_msg:='Flag returned by the validation of revision_qty_control_code '||lc_error_exists;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          ---------------------------------------------------------
            -- Validation of LOT_CONTROL_CODE
            -- 1 = No Control
            -- 2 = Full Control
          ---------------------------------------------------------
         IF lr_item_rec.lotcontrol IS NOT NULL THEN
           --Start of Changes 1.6
           --IF lr_item_rec.lotcontrol <>'2' THEN
           IF lr_item_rec.lotcontrol NOT IN ('1','2') THEN
           --End of Changes 1.6
               lc_error_exists     := 'Y';
               gc_error_code       :='ITEM-06';
               gc_error_msg        :='Invalid Lot Control Code: ' ||lr_item_rec.lotcontrol||' for the Item Number: '||lr_item_rec.itemnumber;
               gc_comments         :='Lot Control Code must be either NULL. 1 or 2';
               INSERT_ERROR_PRC ;
            END IF ;
         END IF;
         gc_log_msg:='Flag returned by the validation of Lot Control Code '||lc_error_exists;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          ---------------------------------------------------------
            -- Validation of SERIAL_NUMBER_CONTROL_CODE
            -- 1 = Not Serial Controlled
	    -- 5 = At Receipt
            -- 6 = At Sales Order Issue
          ---------------------------------------------------------
         IF lr_item_rec.serialcontrol IS NOT NULL THEN
            --Start of Changes 1.6
            --IF lr_item_rec.serialcontrol <>'5' THEN
            --IPadela - 10/24/07 added 6 as acceptable value of serial controlled field, as part of rectifying bug in NAIO/Oracle Consulting 
            -- code in not allowing a valid value, cause problems post conversions.
            IF lr_item_rec.serialcontrol NOT IN ('1','5','6') THEN
            --End of Changes 1.6
               lc_error_exists     := 'Y';
               gc_error_code       :='ITEM-07';
               gc_error_msg        :='Invalid Serial Control Code: ' ||lr_item_rec.serialcontrol||' for the Item Number: '||lr_item_rec.itemnumber;
               gc_comments         :='Serial Control Code must be either NULL, 1, 5 or 6 ';
               INSERT_ERROR_PRC ;
            END IF ;
         END IF;
         gc_log_msg:='Flag returned by the validation of Serial Control Code '||lc_error_exists;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          ---------------------------------------------------------
            -- Validation of Template Identifier for valid value
          ---------------------------------------------------------
         IF lr_item_rec.oracletemplateid
            NOT IN ('S','R','E','N','D') THEN
            lc_error_exists     := 'Y';
            gc_error_code       :='ITEM-08';
            gc_error_msg        :='Invalid Template Identifier: '||lr_item_rec.oracletemplateid||' for the Item Number: '||lr_item_rec.itemnumber;
            gc_comments         :='Template Identifier must be S/R/E/N/D';
            INSERT_ERROR_PRC ;
         ELSE

         ---------------------------------------------------------
         -- Derive template id for valid Template Identifier
         ---------------------------------------------------------

            BEGIN
               SELECT   MIT.template_id
               INTO     ln_template_id
               FROM     mtl_item_templates MIT
               WHERE    MIT.template_name IN
                                             DECODE ( lr_item_rec.oracletemplateid
                                                    ,'D', gc_template_d
                                                    ,'S', gc_template_s
                                                    ,'N', gc_template_n
                                                    ,'E', gc_template_e
                                                    ,'R', gc_template_r
                                                    );
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
               lc_error_exists     := 'Y';
               gc_error_code       :='ITEM-09';
               gc_error_msg        :='Template Id is not derived for Template Identifier: '||lr_item_rec.oracletemplateid||' for the Item Number: '||lr_item_rec.itemnumber;
               gc_comments         :='Please check the Template Identifier';
               INSERT_ERROR_PRC ;

            WHEN OTHERS THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Template Id'||SQLERRM);
            END;
         END IF;
         gc_log_msg:='Flag returned by the Template Identifier validation for valid value '||lc_error_exists;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          ---------------------------------------------------------------------------------
            -- Validation of Source Type for valid value (1-Inventory ,2-Supplier,3-Sub Inventory)
          ---------------------------------------------------------------------------------
         IF lr_item_rec.sourcetype IS NOT NULL THEN
            IF lr_item_rec.sourcetype NOT IN ( '1','2','3') THEN
               lc_error_exists     := 'Y';
               gc_error_code       :='ITEM-10';
               gc_error_msg        :='Invalid Source Type: '||lr_item_rec.sourcetype||' for the Item Number: '||lr_item_rec.itemnumber;
               gc_comments         :='Source Type must be either NULL or 1/2/3';
               INSERT_ERROR_PRC ;
            END IF ;
         END IF;
         gc_log_msg:='Flag returned by the validation of Source Type for valid value '||lc_error_exists;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          -----------------------------------------------------------------------
            -- Validation of Item No for existance in usbpcs_item_invorg table
          ----------------------------------------------------------------------
          --V1.5 Start of changes
          IF p_org_assigments_flag ='NO' THEN
            OPEN  lcu_val_inv_item_detail(lr_item_rec.itemnumber);
            FETCH lcu_val_inv_item_detail INTO lc_temp_flag;
               IF lcu_val_inv_item_detail%NOTFOUND THEN
                  lc_error_exists     := 'Y';
                  gc_error_code       :='ITEM-11';
                  gc_error_msg        :='Inventory Organization Details has not been provided for the Item Number: '||lr_item_rec.itemnumber;
                  gc_comments         :='Please provide the Inventory Organization Details';
                  INSERT_ERROR_PRC ;
               END IF;
            CLOSE lcu_val_inv_item_detail;
            gc_log_msg:='Flag returned by the Item No validation for existance in usbpcs_item_invorg table as part of usbpcs_item_cleaned table'||lc_error_exists;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         END IF;
         --V1.5 End of changes

          -----------------------------------------------------------------------
          -- Validation and derivation of category_id and Attribute 1
          ----------------------------------------------------------------------
         BEGIN
            SELECT mcb.category_id
                  ,mcs.category_set_id
                  ,mcb.attribute1
            INTO   ln_category_id
                  ,ln_category_set_id
                  ,lc_attribute1
            FROM   mtl_categories_b mcb
                  ,mtl_category_sets_vl mcs
            WHERE  mcb.structure_id       = mcs.structure_id
            AND    mcs.category_set_name  = gc_category_set_name
            AND    mcb.segment1           = lr_item_rec.ItemCat1
            AND    mcb.segment2           = lr_item_rec.ItemCat2
            AND    mcb.segment3           = lr_item_rec.ItemCat3
            AND    mcb.segment4           = lr_item_rec.ItemCat4
            AND    NVL (mcb.disable_date, SYSDATE) >= SYSDATE;
         EXCEPTION
         WHEN NO_DATA_FOUND THEN
            lc_cat_combn_flag   := 'Y';
            lc_error_exists     := 'Y';
            gc_error_code       :='ITEM-12';
            gc_error_msg        :='Item Number: '||lr_item_rec.itemnumber||' has Invalid Item category: ' ||lr_item_rec.ItemCat1||','||lr_item_rec.ItemCat2||','||lr_item_rec.ItemCat3||','||lr_item_rec.ItemCat4||' for the Category Set: '||gc_category_set_name ;
            gc_comments         :='Please check the Item Category Code Combination';
            INSERT_ERROR_PRC ;
         WHEN OTHERS THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in deriving caregory_id and category_set_id for  Item Number '||lr_item_rec.itemnumber||' is: ' ||SQLERRM);
         END;
         gc_log_msg:='Flag returned by the derivation of category_id and category_set_id is'||SQLERRM;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          -----------------------------------------------------------------------
          -- Validation of valid combination of category set/category segments
          ----------------------------------------------------------------------

         IF lc_cat_combn_flag <>'Y' THEN
            OPEN  lcu_val_cat_valid_comb(ln_category_set_id,ln_category_id);
            FETCH lcu_val_cat_valid_comb INTO lc_temp_flag;
               IF lcu_val_cat_valid_comb%NOTFOUND THEN
                  lc_error_exists     := 'Y';
                  gc_error_code       :='ITEM-13';
                  gc_error_msg        :='Item Number: '||lr_item_rec.itemnumber||' has Invalid combination of the Category Set: ' ||gc_category_set_name ||' and Category Code: '||lr_item_rec.ItemCat1||','||lr_item_rec.ItemCat2||','||lr_item_rec.ItemCat3||','||lr_item_rec.ItemCat4;
                  gc_comments         :='Category set used in this item category assignment enforces a list of valid categories and the selected category is not on the list';
                  INSERT_ERROR_PRC ;
               END IF;
            CLOSE lcu_val_cat_valid_comb;
         END IF;

         gc_log_msg:='Flag returned by the validation of valid combination of category set/category segments is'||SQLERRM;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          -----------------------------------------------------------------------
          -- Validation of Item No For Master Organization
          ----------------------------------------------------------------------
          --V1.5 Start of changes
         IF p_org_assigments_flag ='NO' THEN
		 OPEN  lcu_val_item_mst(lr_item_rec.itemnumber,gc_master_org);
		 FETCH lcu_val_item_mst INTO lc_temp_flag;
		    IF lcu_val_item_mst%NOTFOUND THEN
		       lc_error_exists     := 'Y';
		       gc_error_code       :='ITEM-25';
		       gc_error_msg        :='Item Number: '||lr_item_rec.itemnumber||' has not been assigned to the Master Inventory organization: '||gc_master_org;
		       gc_comments         :='Please provide the record for the Master Inventory organization in the usbpcs_item_invorg table';
		      INSERT_ERROR_PRC ;
		    END IF;
		 CLOSE lcu_val_item_mst;
		 gc_log_msg:='Flag returned by the Item No validation For Master Organization in usbpcs_item_cleaned table'||lc_error_exists;
		 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         END IF;
	 --V1.5 End of changes

      --*****************************************************************************
      -- Opening the cursor to fetch Items records from usbpcs_item_invorg table
      --*****************************************************************************
         FOR lr_item_inv_rec IN lcu_item_inv (lr_item_rec.itemnumber)
         LOOP
            gc_record_identifier := NVL(lr_item_inv_rec.itemnbr,'NULL')||' Inventory Org: '||NVL(lr_item_inv_rec.InvOrg,'NULL');
            gn_record_number     := lr_item_inv_rec.oracleidentifier;
            ln_inv_rec_fetched   := ln_inv_rec_fetched + 1 ;                       -- Increment record fetched for usbpcs_item_invorg table
            lc_inv_error_exists  := 'N';                                          -- Reinitialise error_exists flag
            lc_item_exist_flag   := 'N';                                          -- Reinitialise item_exists_flag
            lc_item_miss_flag    := 'N';                                          -- Reinitialise Item exist checking flag
            ln_rec_count         :=  0;                                           -- Reinitialise the COUNT(*) variable
            ln_org_id            := NULL;                                         -- Reinitialise the Organization Id variable
            lc_org_exist_flag    := 'N';                                          -- Reinitialise the Organization code exists  variable
            ln_expense_act       := NULL;                                         -- Reinitialise expense account variable
            lc_temp_flag         := NULL;                                         -- Reinitialise temporary flag variable
            gc_log_msg           :='USBPCS_ITEM_INVORG-'||gc_record_identifier;   -- Log message with record identifier
            gc_table_name        :='USBPCS_ITEM_INVORG';                          -- Staging table name insertion in common error table
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

             ---------------------------------------------------------
               -- Validation of Inventory Org for Not Null
             ---------------------------------------------------------
            IF lr_item_inv_rec.InvOrg IS NULL THEN
               lc_inv_error_exists := 'Y';
               gc_error_code       :='ITEM-21';
               gc_error_msg        :='Inventory Organization field (INVORG) is NULL for the Item Number: '||lr_item_rec.itemnumber;
               gc_comments         :='Please provide the Inventory Organization';
               INSERT_ERROR_PRC ;
            ELSE
            -----------------------------------------------------
            -- Validation of Inventory Org for valid value
            -----------------------------------------------------
               BEGIN
                  SELECT   mp.organization_id
                          ,mp.expense_account
                  INTO     ln_org_id
                          ,ln_expense_act
                  FROM     mtl_parameters mp
                          ,org_organization_definitions ood
                  WHERE    mp.master_organization_id  = ood.organization_id
                  AND      mp.organization_code       = lr_item_inv_rec.invorg;
               EXCEPTION
               WHEN NO_DATA_FOUND THEN
                     lc_org_exist_flag   := 'Y';
                     lc_inv_error_exists := 'Y';
                     gc_error_code       :='ITEM-22';
                     --gc_error_msg        :='Invalid Inventory Organization: '||lr_item_inv_rec.invorg;
                     gc_error_msg        :='Inventory Organization: '||lr_item_inv_rec.invorg||' does not exist in Oracle';
                     gc_comments         :='Please provide a valid Inventory Organization';
                     INSERT_ERROR_PRC ;
               WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'While deriving Inventory Organization Id for Inventory Organization: '||lr_item_inv_rec.invorg ||' found an error '||SQLERRM);
               END;
            END IF ;
            gc_log_msg:='Flag returned by the Inventory Org validation for valid value as part of usbpcs_item_invorg table'||lc_inv_error_exists;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            --1275
            ----------------------------------------
            --Check if the item exist in the master org --SUBBU_FEB23
            ----------------------------------------
            IF p_org_assigments_flag ='YES' THEN

             BEGIN

		    SELECT 'N'
		    into lc_dum
		     FROM  mtl_system_items_b a
			  ,mtl_parameters b
		     WHERE a.organization_id =b.master_organization_id
		     AND   b.master_organization_id=b.organization_id
		     AND    a.segment1= lr_item_rec.itemnumber;

            EXCEPTION
		 WHEN NO_DATA_FOUND THEN
		       lc_org_exist_flag   := 'Y';
		       lc_inv_error_exists := 'Y';
		       gc_error_code       :='ITEM-22';
		        gc_error_msg        :='Item :'||lr_item_rec.itemnumber||' has  not been assigned to Item Maste Org';
		       --gc_error_msg        :='Inventory Organization: '||lr_item_inv_rec.invorg||' does not exist in Oracle';
		       gc_comments         :='Please define this Item  in Master Org';
		       INSERT_ERROR_PRC ;
		 WHEN OTHERS THEN
		    FND_FILE.PUT_LINE(FND_FILE.LOG,'Err while validation item in Master Org'||SQLERRM);
		 END;
            END IF ;












            ----------------------------------------------------------------------------------------------------
            -- Validation of derived expense account for expiry in GL Code Combinations(INV_IOI_EXEPENSE_ACCOUNT)
            ----------------------------------------------------------------------------------------------------
           --Start of Changes V1.5
           /*
           IF ln_expense_act IS NOT NULL  THEN
               OPEN  lcu_val_expense_act(ln_expense_act,ln_coa_id);
               FETCH lcu_val_expense_act INTO lc_temp_flag;
                  IF lcu_val_expense_act%NOTFOUND THEN
                     lc_inv_error_exists := 'Y';
                     gc_error_code       :='ITEM-24';
                     --gc_error_msg        :='Invalid Expense Account: '||ln_expense_act;
                     gc_error_msg        :='No records fetched for the Expense Account: '||ln_expense_act||' derived from the Inventory Org: '||lr_item_inv_rec.invorg||' for the Item Number: '||lr_item_rec.itemnumber;
                     gc_comments         :='Please check the Account Code Combination';
                     INSERT_ERROR_PRC ;
                  END IF;
               CLOSE lcu_val_expense_act;
            END IF;
            */
            --End of Changes V1.5
            gc_log_msg:='Flag returned by the expense account validation for expiry in GL Code Combinations'||lc_inv_error_exists;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            -----------------------------------------------------------------------
               -- Validation of Item No for existance in Oracle Base table
            ----------------------------------------------------------------------
            OPEN  lcu_val_item_exist(lr_item_rec.itemnumber,ln_org_id);
            FETCH lcu_val_item_exist INTO lc_temp_flag;
               IF lcu_val_item_exist%FOUND THEN
                  lc_inv_error_exists := 'Y';
                  gc_error_code       :='ITEM-26';
                  gc_error_msg        :='A record for this Item: '||lr_item_rec.itemnumber||' has already been defined to the Inventory Org: '||lr_item_inv_rec.invorg||' in Oracle Inventory';
                  gc_comments         :='Please check the staging tables and Items Definition Form';
                  INSERT_ERROR_PRC ;
               END IF;
            CLOSE lcu_val_item_exist;
            gc_log_msg:='Flag returned by the Item No validation for existance in Oracle Base table'||lc_inv_error_exists ;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

             -----------------------------------------------------------------------
               -- Validation of Item No for existance in Interface table
             ----------------------------------------------------------------------
            OPEN  lcu_val_item_exist_int(lr_item_rec.itemnumber,ln_org_id);
            FETCH lcu_val_item_exist_int INTO lc_temp_flag;
               IF lcu_val_item_exist_int%FOUND THEN
                  lc_inv_error_exists := 'Y';
                  gc_error_code       :='ITEM-27';
                  gc_error_msg        :='A record for this Item: '||lr_item_rec.itemnumber||' and Inventory Org: '||lr_item_inv_rec.invorg||' already exists in the interface table';
                  --gc_error_msg        :='A record for this Item Inventory Org combination already exists in the interface table';
                  gc_comments         :='Please check the interface/staging tables';
                  INSERT_ERROR_PRC ;
                 END IF;
            CLOSE lcu_val_item_exist_int;
            gc_log_msg:='Flag returned by the Item No validation for existance in Interface table'||lc_inv_error_exists ;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ---------------------------------------------------------
               -- Validation of Item Number for duplication
               ---------------------------------------------------------
            OPEN  lcu_val_dupl_item(lr_item_rec.itemnumber,lr_item_inv_rec.InvOrg);
            FETCH lcu_val_dupl_item INTO lc_temp_flag;
               IF lcu_val_dupl_item%FOUND THEN
                  lc_inv_error_exists := 'Y';
                  gc_error_code       :='ITEM-28';
                  gc_error_msg        :='A record for this Item: '||lr_item_rec.itemnumber||' and Inventory Org: '||lr_item_inv_rec.invorg||' already exists in staging table';
                  gc_comments         :='Please check the staging table';
                  INSERT_ERROR_PRC ;
                END IF;
            CLOSE lcu_val_dupl_item;
            gc_log_msg:='Flag returned by the Item Number validation for duplication as part of usbpcs_item_cleaned table'||lc_inv_error_exists;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            ------------------------------------------------
            -- Validation and derivation of sales_account
            ------------------------------------------------
            IF lc_org_exist_flag <> 'Y' AND lc_cat_combn_flag <>'Y' THEN

               ----------------------------------------
               -- Derive the new concatenated segments
               -----------------------------------------
               BEGIN
                  SELECT segment1      ||'.'||
                         lc_attribute1 ||'.'||
                         segment3      ||'.'||
                         segment4      ||'.'||
                         segment5      ||'.'||
                         segment6      ||'.'||
                         segment7      ||'.'||
                         segment8      ||'.'||
                         segment9
                  INTO   lc_concat_segments
                  FROM   gl_code_combinations glc
                        ,mtl_parameters mp
                  WHERE  mp.sales_account    = glc.code_combination_id
                  AND    mp.organization_id  = ln_org_id ;
               EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  --Start of Changes V1.4
                    lc_error_exists     := 'Y';
                    lc_inv_error_exists := 'Y';
                  --End of Changes V1.4

                  gc_error_code       :='ITEM-29';
                  gc_error_msg        :='Concatenated Segments for Sales Account for the Oraganization: '||lr_item_inv_rec.InvOrg||' is not found in Oracle for the Item Number: '||lr_item_rec.itemnumber;
                  gc_comments         :='Please check concatenated segments against the organization';
                  INSERT_ERROR_PRC ;


               WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in deriving concatenated segments for the organization '||lr_item_inv_rec.InvOrg||' is: ' ||SQLERRM);
               END;
               gc_log_msg:='Flag returned by the derivation of new concatenated segments for sales_account'||lc_error_exists;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               -------------------------------------
               -- Derivation of ccid
               --------------------------------------
               IF lc_concat_segments IS NOT NULL THEN
                  BEGIN
                     ln_ccid:= FND_FLEX_EXT.GET_CCID(
                                                      'SQLGL'
                                                     ,'GL#'
                                                     ,ln_coa_id
                                                     ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
                                                     ,lc_concat_segments
                                                    );

                     IF ln_ccid = 0 THEN

                        --Start of Changes V1.4
                          lc_error_exists     := 'Y';
                          lc_inv_error_exists := 'Y';
                        --End of Changes V1.4


                        gc_error_code       :='ITEM-30';
                        gc_error_msg        :='No Records (CCID) found for the Sales Account: '||lc_concat_segments||' derived from the Oraganization: '||lr_item_inv_rec.InvOrg||' for the Item: '||lr_item_rec.itemnumber;
                        gc_comments         :='Please check the code combination';
                        INSERT_ERROR_PRC ;
                     ELSE
                        ln_sales_ccid := ln_ccid;
                     END IF;
                  EXCEPTION
                  WHEN OTHERS THEN
                     FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in generating CCID for '||lc_concat_segments || 'is : ' ||SQLERRM);
                  END;
               END IF;
               gc_log_msg:='Flag returned by the CCID validation and derivation for sales_account'||lc_error_exists;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ln_ccid           :=0;
               lc_concat_segments := NULL;
            -----------------------------------------------------------------------
            -- Validation and derivation of  cost_of_sales_account
            ----------------------------------------------------------------------
             ----------------------------------------
              -- Derive the new concatenated segments
             -----------------------------------------
               BEGIN
                  SELECT segment1      ||'.'||
                         lc_attribute1 ||'.'||
                         segment3      ||'.'||
                         segment4      ||'.'||
                         segment5      ||'.'||
                         segment6      ||'.'||
                         segment7      ||'.'||
                         segment8      ||'.'||
                         segment9
                  INTO   lc_concat_segments
                  FROM   gl_code_combinations glc
                        ,mtl_parameters mp
                  WHERE  mp.cost_of_sales_account  = glc.code_combination_id
                  AND    mp.organization_id        = ln_org_id ;
               EXCEPTION
               WHEN NO_DATA_FOUND THEN

                   --Start of Changes V1.4
                     lc_error_exists     := 'Y';
                     lc_inv_error_exists := 'Y';
                   --End of Changes V1.4





                  gc_error_code       :='ITEM-31';
                  gc_error_msg        :='Concatenated Segments for Cost of Sales Account for the Oraganization: '||lr_item_inv_rec.InvOrg||' is not found in Oracle for the Item Number: '||lr_item_rec.itemnumber;
                  gc_comments         :='Please check concatenated segments against the organization';
                  INSERT_ERROR_PRC ;

               WHEN OTHERS THEN
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in deriving concatenated segments for the organization '||lr_item_inv_rec.InvOrg||' is: ' ||SQLERRM);
               END;
               gc_log_msg:='Flag returned by the derivation of new concatenated segments for cost_of_sales_account'||lc_error_exists;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               IF lc_concat_segments IS NOT NULL  THEN
               -------------------------------------
               -- Derivation of ccid
               --------------------------------------
                  BEGIN
                     ln_ccid:= FND_FLEX_EXT.GET_CCID(
                                                      'SQLGL'
                                                     ,'GL#'
                                                     ,ln_coa_id
                                                     ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
                                                     ,lc_concat_segments
                                                    );

                     IF ln_ccid = 0 THEN
                        --Start of Changes V1.4
                        lc_error_exists     := 'Y';
                        lc_inv_error_exists := 'Y';
                        --End of Changes V1.4






                        gc_error_code       :='ITEM-32';
                        gc_error_msg        :='No Records (CCID) found for the Cost Of Sales Account: '||lc_concat_segments||' derived from the Oraganization: '||lr_item_inv_rec.InvOrg||' for the Item Number: '||lr_item_rec.itemnumber;
                        gc_comments         :='Please check the code combination';
                        INSERT_ERROR_PRC ;
                     ELSE
                        ln_cost_sales_ccid := ln_ccid;
                     END IF;
                  EXCEPTION
                  WHEN OTHERS THEN
                     FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in generating CCID for '||lc_concat_segments || 'is : ' ||SQLERRM);
                  END;
               END IF;
               gc_log_msg:='Flag returned by the CCID validation and derivation for cost_of_sales_account'||lc_error_exists;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            --END IF;

	    --Start of Changes V1.5
	    ln_ccid           :=0;
	    lc_concat_segments := NULL;
	    ln_expense_act     := NULL;
	    -----------------------------------------------------------------------
	    -- Validation and derivation of  Expense Account
	    ----------------------------------------------------------------------
	     ----------------------------------------
	      -- Derive the new concatenated segments
	     -----------------------------------------
	       BEGIN
	          SELECT segment1      ||'.'||
	                 lc_attribute1 ||'.'||
	                 segment3      ||'.'||
	                 segment4      ||'.'||
	                 segment5      ||'.'||
	                 segment6      ||'.'||
	                 segment7      ||'.'||
	                 segment8      ||'.'||
	                 segment9
	          INTO   lc_concat_segments
	          FROM   gl_code_combinations glc
	                ,mtl_parameters mp
	          WHERE  mp.expense_account  = glc.code_combination_id
	          AND    mp.organization_id        = ln_org_id ;
	       EXCEPTION
	       WHEN NO_DATA_FOUND THEN

	           --Start of Changes V1.4
	             lc_error_exists     := 'Y';
	             lc_inv_error_exists := 'Y';
	           --End of Changes V1.4

	          gc_error_code       :='ITEM-31';
	          gc_error_msg        :='Concatenated Segments for Expense Account for the Oraganization: '||lr_item_inv_rec.InvOrg||' is not found in Oracle for the Item Number: '||lr_item_rec.itemnumber;
	          gc_comments         :='Please check concatenated segments against the organization';
	          INSERT_ERROR_PRC ;

	       WHEN OTHERS THEN
	          FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in deriving concatenated segments for the organization '||lr_item_inv_rec.InvOrg||' is: ' ||SQLERRM);
	       END;
	       gc_log_msg:='Flag returned by the derivation of new concatenated segments for Expense Account'||lc_error_exists;
	       xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

	       IF lc_concat_segments IS NOT NULL  THEN
	       -------------------------------------
	       -- Derivation of ccid
	       --------------------------------------
	          BEGIN
	             ln_ccid:= FND_FLEX_EXT.GET_CCID(
	                                              'SQLGL'
	                                             ,'GL#'
	                                             ,ln_coa_id
	                                             ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
	                                             ,lc_concat_segments
	                                            );

	             IF ln_ccid = 0 THEN
	                --Start of Changes V1.4
	                lc_error_exists     := 'Y';
	                lc_inv_error_exists := 'Y';
	                --End of Changes V1.4
	                gc_error_code       :='ITEM-32';
	                gc_error_msg        :='No Records (CCID) found for the Expense Account: '||lc_concat_segments||' derived from the Oraganization: '||lr_item_inv_rec.InvOrg||' for the Item Number: '||lr_item_rec.itemnumber;
	                gc_comments         :='Please check the code combination';
	                INSERT_ERROR_PRC ;
	             ELSE
	                ln_expense_act := ln_ccid;
	             END IF;
	          EXCEPTION
	          WHEN OTHERS THEN
	             FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in generating CCID for '||lc_concat_segments || 'is : ' ||SQLERRM);
	          END;
	       END IF;
	       gc_log_msg:='Flag returned by the CCID validation and derivation for Expense Account'||lc_error_exists;
	       xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
	    END IF;
	    --End of Changes V1.5
















            ----------------------
            -- Status Flag Update
            ----------------------

            IF lc_inv_error_exists = 'Y' THEN
               UPDATE usbpcs_item_invorg
               SET    oraclecharfld1 = 'VE'
                     ,oracleintfld8 = gn_request_id --Request_id
               WHERE  oracleidentifier = lr_item_inv_rec.oracleidentifier
               AND itemnbr=lr_item_inv_rec.itemnbr; --SUBBU_FEB23;
            ELSE
               UPDATE usbpcs_item_invorg
               SET    oraclecharfld1 = 'VS'
                     ,oracleintfld2 = ln_org_id             --Inventory Org Id
                     ,oracleintfld5 = ln_sales_ccid         --Sales Account
                     ,oracleintfld6 = ln_cost_sales_ccid    --Cost_of_sates_account
                     ,oracleintfld7 = ln_expense_act        --Expense_account
                     ,oracleintfld8 = gn_request_id         --Request_id
               WHERE  oracleidentifier = lr_item_inv_rec.oracleidentifier
               and itemnbr=lr_item_inv_rec.itemnbr; --SUBBU_FEB23
            END IF;
         END LOOP; -- End loop for usbpcs_item_invorg table
         COMMIT;

      --*****************************************************************************
      -- Opening the cursor to fetch Items records from usbpcs_revision table
      --*****************************************************************************
         FOR lr_item_rev_rec IN lcu_item_rev (lr_item_rec.itemnumber)
         LOOP
            gc_record_identifier := NVL(lr_item_rev_rec.itemnbr,'NULL')||' Revision Number: '||NVL(lr_item_rev_rec.revisionnbr,'NULL');
            gn_record_number     := lr_item_rev_rec.oracleidentifier;
            ln_rev_rec_fetched   := ln_rev_rec_fetched + 1 ;                       -- Increment record fetched for usbpcs_revision table
            lc_rev_error_exists  := 'N';                                          -- Reinitialise error_exists flag
            lc_item_exist_flag   := 'N';                                          -- Reinitialise item_exists_flag
            lc_item_miss_flag    := 'N';                                          -- Reinitialise Item exist checking flag
            lc_inv_exist_flag    := 'N';                                          -- Reinitialise inv item exist flag
            lc_temp_flag         := NULL ;                                        -- Reinitialise temporary variable
            gc_log_msg           := 'USBPCS_REVISION-'||gc_record_identifier;     -- Log messgae with record identifier
            gc_table_name        := 'USBPCS_REVISION';                            -- Staging table name insertion in common error table
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

             ----------------------------------------------
               --Validation of Revision Nbr for Not Null
             ----------------------------------------------
            IF lr_item_rev_rec.revisionnbr IS NULL THEN
               lc_rev_error_exists := 'Y';
               gc_error_code       :='ITEM-41';
               --gc_error_msg        :='Revision Number has not been provided';
               gc_error_msg        :='Field Revision Number (revisionnbr) is NULL for the Item Number: '||lr_item_rec.itemnumber;
               gc_comments         :='Please provide Revision Number';
               INSERT_ERROR_PRC ;
            ELSE
            ---------------------------------------------------------------------------------
               --Validation of Item No and revision Number combination for Duplication
            --------------------------------------------------------------------------------

            IF p_org_assigments_flag ='NO' THEN
               OPEN  lcu_val_item_rev_comb(lr_item_rev_rec.itemnbr,lr_item_rev_rec.revisionnbr);
               FETCH lcu_val_item_rev_comb INTO lc_temp_flag;
                  IF lcu_val_item_rev_comb%FOUND THEN
                     lc_rev_error_exists := 'Y';
                     gc_error_code       :='ITEM-42';
                     gc_error_msg        :='Item Number: '||lr_item_rev_rec.itemnbr||' and  Revision Number: '||lr_item_rev_rec.revisionnbr||' combination already exists in the staging table';
                     gc_comments         :='Please check the the staging table';
                    INSERT_ERROR_PRC ;
                  END IF;
               CLOSE lcu_val_item_rev_comb;
               gc_log_msg:='Flag returned by the Item No and revision Number combination for Duplication '||lc_rev_error_exists;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            END IF;
          END IF;--SUBBU_FEB23

            ----------------------------------------------------------------------------
            -- Validation For Effective date and revision Number for chronological order
            -----------------------------------------------------------------------------
            IF lr_item_rev_rec.effdate IS NOT NULL THEN

               OPEN  lcu_val_item_rev_order(lr_item_rev_rec.itemnbr,lr_item_rev_rec.revisionnbr);
               FETCH lcu_val_item_rev_order INTO lc_temp_flag;
                  IF lcu_val_item_rev_order%FOUND THEN
                     lc_rev_error_exists := 'Y';
                     gc_error_code       :='ITEM-43';
                     gc_error_msg        :='The order of Revision: '||lr_item_rev_rec.revisionnbr||' for the Item: '||lr_item_rev_rec.itemnbr||' should be chronologically ordered by the Revision Number and Effective Date';
                     gc_comments         :='Please provide the Revision Number and Effective Date';
                    INSERT_ERROR_PRC ;
                  END IF;
               CLOSE lcu_val_item_rev_order;
            END IF;
            gc_log_msg:='Flag returned by the Validation of Revision Nbr and effective date for chronological order '||lc_rev_error_exists;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            ------------------------------------------------------
            -- Validation For Effective date for not null
            ------------------------------------------------------
            IF lr_item_rev_rec.revisionnbr IS NOT NULL THEN
               IF lr_item_rev_rec.effdate IS NULL THEN
                  lc_rev_error_exists := 'Y';
                  gc_error_code       :='ITEM-44';
                  gc_error_msg        :='Effectivity Date is not provided';
                  gc_comments         :='Please provide the Effectivity Date';
                  INSERT_ERROR_PRC ;
               ELSE
                   -- Start of changes V1.2
                   --Added equals to condition to check Effective date against item start date
                  ------------------------------------------------------
                  -- Validation Of Effective date against item start date
                  ------------------------------------------------------
                  IF NVL(lr_item_rec.itemstartdate,SYSDATE) >= lr_item_rev_rec.effdate THEN
                     lc_rev_error_exists := 'Y';
                     gc_error_code       :='ITEM-45';
                     gc_error_msg        :='Effectivity Date '||lr_item_rev_rec.effdate ||' is either earlier than or equal to Start Date '||lr_item_rec.itemstartdate||' for the Item '||lr_item_rev_rec.itemnbr;
                     gc_comments         :='Effectivity date should be after the Item Start Date';
                     INSERT_ERROR_PRC ;
                  END IF;
               END IF;
            END IF;
            gc_log_msg:='Flag returned by the Validation of effective date and Item Start Date '||lc_rev_error_exists;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            -- End of changes V1.2

            --Start of changes V1.3
            ------------------------------------------------------------
            --Validation to check for Revision Number against the Item
            --can not have same effectivity date
            ------------------------------------------------------------
            IF p_org_assigments_flag ='NO' THEN
		    OPEN  lcu_val_effdate(lr_item_rev_rec.itemnbr,lr_item_rev_rec.effdate);
		    FETCH lcu_val_effdate INTO lc_temp_flag;
		       IF lcu_val_effdate%FOUND THEN
			  lc_rev_error_exists := 'Y';
			  gc_error_code       :='ITEM-46';
			  gc_error_msg        :='The Revision Effectivity Date has been duplicated for the Item Number: '||lr_item_rev_rec.itemnbr;
			  gc_comments         :='Please provide unique Revision Effectivity Date against the Item Number';
			  INSERT_ERROR_PRC ;
		       END IF;
		    CLOSE lcu_val_effdate;
		    gc_log_msg:='Flag returned by the Validation of effective date for duplication against the Item Number '||lc_rev_error_exists;
		    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            --End of changes V1.3
           END IF; --SUBBU_23


            ----------------------
            -- Status Flag Update
            ----------------------

            IF lc_rev_error_exists  = 'Y' THEN
               UPDATE usbpcs_revision
               SET    oraclecharfld1 = 'VE'
                     ,oracleintfld8 = gn_request_id  --Request_id
               WHERE  oracleidentifier = lr_item_rev_rec.oracleidentifier;
            ELSE
               UPDATE usbpcs_revision
               SET    oraclecharfld1 = 'VS'
                     ,oracleintfld8 = gn_request_id
               WHERE  oracleidentifier = lr_item_rev_rec.oracleidentifier;
            END IF;
         END LOOP; -- End loop for validation of usbpcs_revision table

         -----------------------
         -- Status Flag Update
         -----------------------
         IF lc_error_exists = 'Y' THEN
            UPDATE usbpcs_item_cleaned
            SET    oraclecharfld1   = 'VE'
                  ,oracleintfld8    = gn_request_id  --Request_id
            WHERE  oracleidentifier = lr_item_rec.oracleidentifier;
         ELSE
            UPDATE usbpcs_item_cleaned
            SET    oraclecharfld1     = 'VS'
                  ,oracleintfld2      = ln_category_id     --category_id
                  ,oracleintfld3      = ln_category_set_id --category_set_id
                  ,oracleintfld4      = ln_template_id     --template_id
                  ,oracleintfld8      = gn_request_id      --Request_id
            WHERE  oracleidentifier   = lr_item_rec.oracleidentifier;
         END IF;
      END LOOP; -- End loop for validation of usbpcs_item_cleaned table
      COMMIT;

      ------------------------------------------------------
      --Count the number of records get failed in validation
      ------------------------------------------------------
      BEGIN
         SELECT COUNT (*)
         INTO ln_item_rejected_recs
         FROM  usbpcs_item_cleaned
         WHERE oraclecharfld1='VE';

         SELECT COUNT (*)
         INTO ln_inv_rejected_recs
         FROM  usbpcs_item_invorg
         WHERE oraclecharfld1='VE';

         SELECT COUNT (*)
         INTO ln_rev_rejected_recs
         FROM  usbpcs_revision
         WHERE oraclecharfld1='VE';
      END;

      ----------------------------------------
      -- Summary Of Data Validation Process
      ----------------------------------------

      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_ITEM_CLEANED Records Validated ');
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                             :  ' ||ln_item_rec_fetched);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation                     :  ' ||(ln_item_rec_fetched - ln_item_rejected_recs));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored out                           :  ' ||ln_item_rejected_recs);
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_ITEM_INVORG Records Validated ');
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                             :  ' || ln_inv_rec_fetched);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation                     :  ' ||( ln_inv_rec_fetched - ln_inv_rejected_recs));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored out                           :  ' ||ln_inv_rejected_recs);
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_REVISION Records Validated ');
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                             :  ' || ln_rev_rec_fetched);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation                     :  ' ||(ln_rev_rec_fetched - ln_rev_rejected_recs));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored out                           :  ' ||ln_rev_rejected_recs);
      ------------------------------------------------------
      -- If set up is not done then errored out the program
      -- and stop further processing of records .
      ------------------------------------------------------
      ----------------------------------------------------------------------------------
      -- If any single record failed in validation then complete the program with warning
      -- and stop further processing of records .
      -----------------------------------------------------------------------------------
      IF ln_item_rejected_recs > 0 OR ln_inv_rejected_recs > 0 OR ln_rev_rejected_recs > 0 THEN
         retcode := 1; -- complete the request with warning
         lc_insert_interface_flag := 'N';
         xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
      END IF;

      --------------------------------------------------------------------------
      -- If all records validate successfully inert records in interface tables
      ---------------------------------------------------------------------------
      IF lc_insert_interface_flag <> 'N' THEN
         --************************************************************************
         --Calling Data Insertion Procedure to insert records into interface tables
         --*************************************************************************
         MOVE_ITEM_DATA(p_debug =>p_debug,x_process_flag=>lc_process_flag);
      END IF;
      ----------------------------------------------------------------------------------
      -- If all records successfully processed to interface table from staging table then
      -- submit the Import item program  .
      -----------------------------------------------------------------------------------

      IF lc_process_flag = 'Y' THEN
         retcode := 1; -- complete the request with warning
         xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
      END IF;
   ELSE
      retcode :=2;
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
   END IF ; -- End of Setup procedure
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in xxha_item_conv_pk.VALIDATE_ITEM_DATA: ' || SQLERRM);
END VALIDATE_ITEM_DATA;

PROCEDURE MOVE_ITEM_DATA (
                          p_debug         IN VARCHAR2
                         ,x_process_flag  OUT VARCHAR2
                         )
-- +===================================================================+
-- | Name            : MOVE_ITEM_DATA                                  |
-- | Description     : Procedure to process validated Items,Categories |
-- |                   ,Revisions Records From Staging tables          |
-- |                   To Oracle Inventory interface Tables            |
-- |                                                                   |
-- | Call From       :  Procedure is called from VALIDATE_ITEM_DATA    |
-- |                    procedure                                      |
-- | Parameters :                                                      |
-- |   IN: p_debug                                                     |
-- |  OUT: x_process_fla                                               |
-- |                                                                   |
-- | Returns :                                                         |
-- +===================================================================+
AS
   -- Local Variable Declaration
   lc_error_exists          VARCHAR2(1):='N';                               -- Error Exists Flag
   lc_setup_err_flag        VARCHAR2(1):='N';                               -- Variable to take Setup procedure Out parameter
   ln_inv_rec_fetched       NUMBER:=0;                                      -- Variable to fetch total records from "usbpcs_item_invorg" table.
   ln_rev_rec_fetched       NUMBER:=0;                                      -- Variable to fetch total records from "usbpcs_revision" table.
   lc_item_miss_flag        VARCHAR2(1):='N';                               -- Item existance in staging table chking flag
   ln_org_id                mtl_system_items_interface.organization_id%TYPE;-- Variable to get Organization_id
   lc_item_exist_flag       VARCHAR2(1):='N';                               -- Item existance Flag variable
   ln_rev_reject_recs       NUMBER:=0;                                      -- Variable to fetch errored records from "usbpcs_revision" table.
   ln_item_reject_recs      NUMBER:=0;                                      -- Variable to fetch errored records from "usbpcs_item_cleaned" table.
   ln_inv_reject_recs       NUMBER:=0;                                      -- Variable to fetch errored records from "usbpcs_item_invorg" table.
   ln_rev_process_recs      NUMBER:=0;                                      -- Variable to fetch processed records from "usbpcs_revision" table.
   ln_item_process_recs     NUMBER:=0;                                      -- Variable to fetch processed records from "usbpcs_item_cleaned" table.
   ln_inv_process_recs      NUMBER:=0;                                      -- Variable to fetch processed records from "usbpcs_item_invorg" table.
   lc_insert_interface_flag VARCHAR2(1):='N';                               -- Variable to call interface insertion process
   lc_attribute6            mtl_parameters.attribute6%TYPE;                 -- Variable to check valid value of DFF for material cost
   ln_material_cost         mtl_system_items_interface.material_cost%TYPE;  -- Variable to get material cost value
   ln_rec_count             NUMBER:=0;                                      -- Variable to get value of COUNT(*)
   ln_total_item_recs       NUMBER:=0;                                      -- Variable to get total item records for Insertion
   ln_total_inv_recs        NUMBER:=0;                                      -- Variable to get total item inventory orgs records for Insertion
   ln_total_rev_recs        NUMBER:=0;                                      -- Variable to get total item revisions  records for Insertion
   lc_revisioncontrol       VARCHAR2(50):=NULL;                             -- Variable to get revision control value
   lc_lotcontrol            VARCHAR2(50):=NULL;                             -- Variable to get lot control value
   lc_serialcontrol         VARCHAR2(50):=NULL;                             -- Variable to get serial control value
   lc_starting_revision     VARCHAR2(3);                                    -- Variable to get starting_revision value
   lc_item_num              VARCHAR2(50):='-9999--';                        -- Dummy variable for itemnbr
   ld_effdate               DATE;                                           -- Variable to get effectivity date against the revision nbr
   lc_revisionnbr           VARCHAR2(3);                                    -- Variable to get revision nbr against the item number
   lc_inv_org               VARCHAR2(50):='-999--';                         -- Dummy variable for inventory organization
   lc_start_auto_lot_num    VARCHAR2(30);                                   -- Variable to get start_auto_lot_number value
   lc_auto_lot_alpha_prefix VARCHAR2(30);                                   -- Variable to get auto_lot_alpha_prefix value
   lc_asset_creation_code   VARCHAR2(30);                                   -- Variable to get asset_creation_code value
   lc_err_flag              VARCHAR2(1):='N';                               -- Variable for Error_flag for checking validation
   lc_asset_flag            VARCHAR2(1):='N';                               -- Variable for asset flag
   lc_rollback_flag         VARCHAR2(1):='N';                               -- Variable to check rollback and commit
   lc_temp_flag             VARCHAR2(1);                                    -- Variable to hold temporary value
   ln_set_process_id        mtl_system_items_interface.set_process_id%TYPE; -- Variable to get set process id value for inventory organization
   ---------------------------------------------------------------------------------------
   -- Cursor to fetch all Items, Categories and Inventory Orgs records having status 'VS'
   -- from staging tables usbpcs_item_cleaned and usbpcs_item_invorg
   --------------------------------------------------------------------------------------

   CURSOR lcu_item
   IS
   SELECT ITEM.itemdescription
         ,ITEM.itemnumber
         ,ITEM.ucccode,item.temprhreq
         ,ITEM.sourcetype
         ,ITEM.oracletemplateid
         ,ITEM.oracleintfld4               -- TEMPLATE_ID
         --Start of changes V1.5
         --,ITEM.frozenstdcost
         ,INV.invorg_itemcost
         --End of changes V1.5
         ,INV.invorg
         ,INV.oracleintfld2 invorgid       -- inv org id
         ,ITEM.oracleintfld3               --  category_set_id
         ,ITEM.oracleintfld2               -- category_id
         ,INV.oracleintfld6                -- Cost_of_sales
         ,INV.oracleintfld7                -- Expense_account
         ,INV.oracleintfld5                -- Sales_account
         ,ITEM.sterilization
         ,ITEM.revisioncontrol
         ,ITEM.lotcontrol
         ,ITEM.serialcontrol
         ,ITEM.itemstartdate
         --IPadela 10/24/07 added getting sellinguom field so as to assign it to primary_uom_code, 
         --was using default value from the template
         ,ITEM.sellinguom
   FROM usbpcs_item_cleaned  ITEM
         ,usbpcs_item_invorg INV
   WHERE ITEM.itemnumber=INV.itemnbr
   AND ITEM.oraclecharfld1='VS'
   and INV .oraclecharfld1='VS' --SUBBU_FEB23
    --V1.5  Start of Changes
      AND    INV.invorg <> DECODE(gc_org_assigments_flag,'Y','MST','-9-')
   --V1.5  End of Changes

   ORDER BY ITEM.itemnumber
           ,INV.invorg
           ,INV.oracleintfld2 ;

   ---------------------------------------------------------------------------------------
   -- Cursor to fetch all Items, Revisions and Inventory Orgs records having status 'VS'
   -- from staging tables usbpcs_item_invorg and usbpcs_revision
   --------------------------------------------------------------------------------------
   CURSOR lcu_item_rev
   IS
   SELECT    REV.itemnbr
            ,REV.revisionnbr
            ,REV.chgnotice
            ,REV.effdate
            ,REV.description
            ,INV.invorg
            ,INV.oracleintfld2 invorgid        -- inv org id
            ,ITEM.itemstartdate
   FROM      usbpcs_revision REV
            ,usbpcs_item_invorg INV
            ,usbpcs_item_cleaned  ITEM
   WHERE    REV.itemnbr       =INV.itemnbr
   AND      INV.itemnbr       =ITEM.itemnumber
   AND      REV.itemnbr       =ITEM.itemnumber
   AND      REV.oraclecharfld1='VS'
   AND      INV.oraclecharfld1='PS'  --SUBBU_FEB23
   and     ITEM. oraclecharfld1='PS'  --SUBBU_FEB23
    --V1.5  Start of Changes
         AND    INV.invorg <> DECODE(gc_org_assigments_flag,'Y','MST','-9-')
    --V1.5  End of Changes
   GROUP BY REV.itemnbr
           ,INV.oracleintfld2
           ,REV.revisionnbr
           ,REV.chgnotice
           ,REV.effdate
           ,REV.description
           ,INV.invorg
           ,ITEM.itemstartdate
   ORDER BY invorgid
           ,REV.itemnbr
           ,REV.revisionnbr
           ,REV.effdate;

   --Cursor to check starting revision against the item number
   CURSOR lcu_val_start_rev_c(
                              p_rev VARCHAR2
                             ,p_item VARCHAR2,p_org NUMBER
                             )
   IS
   SELECT 'N'
   FROM    usbpcs_revision REV
          ,usbpcs_item_invorg INV
   WHERE   REV.revisionnbr    =p_rev
   AND     REV.itemnbr        =p_item
   AND     REV.itemnbr        =INV.itemnbr
   AND     INV.oracleintfld2  =p_org;

   -- Start of changes V1.1
  /* --Cursor to check asset_creation_code value for the template
   CURSOR lcu_asset_creation_c(
                              p_template NUMBER
                              )
   IS
   SELECT attribute_value
   FROM   mtl_item_templ_attributes
   WHERE  attribute_name   ='MTL_SYSTEM_ITEMS.ASSET_CREATION_CODE'
   AND    template_id      =p_template; */
   -- End of changes V1.1

BEGIN
   gn_request_id               := fnd_global.conc_request_id;         -- Request Id of processing data
   lc_error_exists             :='N';                                 -- Error_exits flag initialise
   gc_debug_flag               := p_debug;                            -- Debug Flag
   gc_log_msg                  :='Start of MOVE_ITEM_DATA...';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --*********************************************************************************
   -- Opening the cursor to fetch valid Items and inventory records records
   --********************************************************************************
   FOR lr_item_rec IN lcu_item
   LOOP
      gc_record_identifier     := lr_item_rec.itemnumber||' Item Description :'||lr_item_rec.ItemDescription || ' Inventory Org ' ||lr_item_rec.invorg;
      lc_error_exists          := 'N';                                          -- Reinitialise error_exists flag
      lc_attribute6            := NULL;                                         -- Reinitialise attribute6 value
      ln_material_cost         := NULL;                                         -- Reinitialise material_cost value
      lc_revisioncontrol       := NULL;                                         -- Reinitialise revision control value
      lc_lotcontrol            := NULL;                                         -- Reinitialise serial control value
      lc_serialcontrol         := NULL;                                         -- Reinitialise error_exists flag
      lc_start_auto_lot_num    := NULL;                                         -- Reinitialise the start_auto_lot_number value
      lc_auto_lot_alpha_prefix := NULL;                                         -- Reinitialise the auto_lot_alpha_prefix value
      lc_asset_creation_code   := NULL;                                         -- Reinitialise the asset_creation_code variable
      lc_asset_flag            := NULL;                                         -- Reinitialise the asset flag
      ln_set_process_id        := NULL;
      gc_log_msg               :='usbpcs_item_cleaned-'||gc_record_identifier ;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


     -------------------------------------------------------------------------------------
     -- Determining value of attribute6 field (dff at organization classification level )
     --------------------------------------------------------------------------------------
      BEGIN
         SELECT MP.attribute6
         INTO   lc_attribute6
         FROM   mtl_parameters MP
         WHERE  MP.organization_id =lr_item_rec.invorgid ;

         IF lc_attribute6 ='Y' THEN
            ln_material_cost :=0;
         ELSE
            --Start of Changes V1.5
            --ln_material_cost :=lr_item_rec.frozenstdcost;
              ln_material_cost :=lr_item_rec.invorg_itemcost;
            --End of Changes V1.5
         END IF;
      EXCEPTION
      WHEN OTHERS THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Error while determining Material Cost for the Item ');
      END ;

      -- Assigning the revision control code value if its not null
      IF lr_item_rec.revisioncontrol IS NOT NULL THEN
         lc_revisioncontrol :=lr_item_rec.revisioncontrol;
      END IF;

      -- Assigning the lot control code value if its not null
      IF lr_item_rec.lotcontrol IS NOT NULL THEN
         lc_lotcontrol            :=lr_item_rec.lotcontrol;
         lc_start_auto_lot_num    := gc_auto_lot_alpha_prefix;
         lc_auto_lot_alpha_prefix := gc_start_auto_lot_number;
      END IF;

      -- Assigning the serial control code value if its not null
      IF lr_item_rec.serialcontrol IS NOT NULL THEN
         lc_serialcontrol :=lr_item_rec.serialcontrol;
      END IF;

      -- Start of changes V1.1
   /* -- If for the template name asset_creation_code is 'Y' then
      -- Assigning the asset_creation_code to 1 else set to null
      OPEN  lcu_asset_creation_c(lr_item_rec.oracleintfld4);
      FETCH lcu_asset_creation_c INTO lc_asset_flag;
         IF lc_asset_flag ='Y' THEN
            lc_asset_creation_code := '1';
         ELSE
            lc_asset_creation_code := NULL;
         END IF;
      CLOSE lcu_asset_creation_c;  */
     -- End of changes V1.1

      --Start of changes V1.3
      -- Assigning the set_process_id to the Mater and Child inventory organization
      IF lr_item_rec.invorg = gc_master_org THEN
         ln_set_process_id  := gc_set_proc_id_mst; -- For Master Org
      ELSE
         ln_set_process_id  := gc_set_proc_id_child;  -- For Child Org
      END IF;
      --End of changes V1.3
      --************************************************
      -- insert records in mtl_system_items_interface
      --************************************************
      BEGIN
         INSERT INTO mtl_system_items_interface (
                                                 organization_id
                                                ,last_update_date
                                                ,last_updated_by
                                                ,creation_date
                                                ,created_by
                                                ,last_update_login
                                                ,description
                                                ,segment1
                                                ,start_date_active
                                                ,attribute1
                                                ,attribute2
                                                ,attribute3
                                                ,source_type
                                                ,expense_account
                                                ,cost_of_sales_account
                                                ,sales_account
                                                ,process_flag
                                                ,template_id
                                                ,auto_lot_alpha_prefix
                                                ,start_auto_lot_number
                                                ,revision_qty_control_code
                                                ,lot_control_code
                                                ,serial_number_control_code
                                                ,asset_creation_code
                                                ,transaction_type
                                                ,material_cost
                                                ,material_sub_elem
                                                ,container_item_flag
                                                ,vehicle_item_flag
                                                ,set_process_id
                                                ,primary_uom_code
                                                )
                                       VALUES
                                                (
                                                 lr_item_rec.invorgid
                                                ,SYSDATE
                                                ,FND_GLOBAL.USER_ID
                                                ,SYSDATE
                                                ,FND_GLOBAL.USER_ID
                                                ,FND_GLOBAL.USER_ID
                                                -- Start of changes V1.1
                                                ,NVL(lr_item_rec.itemdescription,lr_item_rec.itemnumber)
                                                -- End of changes V1.1
                                                ,lr_item_rec.itemnumber
                                                ,NVL(lr_item_rec.itemstartdate,SYSDATE)
                                                ,lr_item_rec.sterilization
                                                ,lr_item_rec.ucccode
                                                ,lr_item_rec.temprhreq
                                                ,lr_item_rec.sourcetype
                                                ,lr_item_rec.oracleintfld7
                                                ,lr_item_rec.oracleintfld6
                                                ,lr_item_rec.oracleintfld5
                                                ,gc_process_flag
                                                ,lr_item_rec.oracleintfld4
                                                ,lc_start_auto_lot_num
                                                ,lc_auto_lot_alpha_prefix
                                                ,lc_revisioncontrol
                                                ,lc_lotcontrol
                                                ,lc_serialcontrol
                                                ,lc_asset_creation_code
                                                ,gc_transaction_type
                                                ,ln_material_cost
                                                ,gc_material_sub_element
                                                ,'N'
                                                ,'N'
                                                ,ln_set_process_id
                                                --IPadela 10/24/07 use the previously fetched value for UOM from the staging table to populate the primary_uom_code field
                                                ,lr_item_rec.sellinguom
                                                );
      EXCEPTION
      WHEN OTHERS THEN
         lc_error_exists     := 'Y';
         gc_error_code       :='ITEM-50';
         gc_error_msg        :='Item Number '||lr_item_rec.itemnumber ||' and Inv Org '||lr_item_rec.invorg||' record is failed to insert into MTL_SYSTEM_ITEMS_INTERFACE table due to error '||SQLERRM;
         gc_comments         :='Please check the provided data';
         INSERT_ERROR_PRC ;
      END;

      -- IF Inventory org is equal to Master Org then create categories for the Items

      --*****************************************************************
      -- insert master inventory records in mtl_item_categories_interface
      --******************************************************************
      IF lr_item_rec.invorg = gc_master_org THEN
         BEGIN
            INSERT INTO mtl_item_categories_interface (
                                                       category_set_id
                                                      ,category_id
                                                      ,last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,last_update_login
                                                      ,organization_id
                                                      ,process_flag
                                                      ,item_number
                                                      ,transaction_type
                                                      ,set_process_id
                                                      )
                                                VALUES(
                                                        lr_item_rec.oracleintfld3
                                                       ,lr_item_rec.oracleintfld2
                                                       ,SYSDATE
                                                       ,FND_GLOBAL.user_id
                                                       ,SYSDATE
                                                       ,FND_GLOBAL.user_id
                                                       ,FND_GLOBAL.user_id
                                                       ,lr_item_rec.invorgid
                                                       ,gc_process_flag
                                                       ,lr_item_rec.itemnumber
                                                       ,gc_transaction_type
                                                       ,ln_set_process_id
                                                       );
         EXCEPTION
         WHEN OTHERS THEN
            lc_error_exists     := 'Y';
            gc_error_code       :='ITEM-51';
            gc_error_msg        :='Item Number '||lr_item_rec.itemnumber ||' and Inv Org '||lr_item_rec.invorg||' record is failed to insert into MTL_ITEM_CATEGORIES_INTERFACE table due to error '||SQLERRM;
            gc_comments         :='Please check the provided data';
            INSERT_ERROR_PRC ;
         END;
      END IF;
      -----------------------------------------
      -- Update oraclecharfld1 in Staging Tables
      ------------------------------------------
      IF lc_error_exists   = 'Y' THEN

        --Start of changes V1.3

         lc_rollback_flag  :='Y';

         ---------------------------------------------------------
         --Call the update procedure for update the record status
         --which will run as a Autonomous transaction
         ---------------------------------------------------------
         update_item_record_status (
                                     p_status_flag   =>'PE'
                                    ,p_request_id    =>gn_request_id
                                    ,p_itemnbr       =>lr_item_rec.itemnumber
                                    );

         update_inv_record_status  (
                                     p_status_flag   =>'PE'
                                    ,p_request_id    =>gn_request_id
                                    ,p_itemnbr       =>lr_item_rec.itemnumber
                                    ,p_invorg        =>lr_item_rec.invorg
                                    );
      ELSE
         update_item_record_status (
                                     p_status_flag   =>'PS'
                                    ,p_request_id    =>gn_request_id
                                    ,p_itemnbr       =>lr_item_rec.itemnumber
                                    );

         update_inv_record_status  (
                                     p_status_flag   =>'PS'
                                    ,p_request_id    =>gn_request_id
                                    ,p_itemnbr       =>lr_item_rec.itemnumber
                                    ,p_invorg        =>lr_item_rec.invorg
                                    );
        --End of changes V1.3


      END IF;
   END LOOP;
   gc_log_msg:='Flag returned by the Data Insertion in mtl_system_items_interface and mtl_item_categories_interface table'||lc_error_exists;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



   --*********************************************************************
   -- Opening the cursor to fetch valid Items and Items Revisions records
   --*********************************************************************
   FOR lr_item_rev_rec IN lcu_item_rev
   LOOP
      gc_record_identifier := lr_item_rev_rec.itemnbr||' Revision Number :'||lr_item_rev_rec.revisionnbr || ' Inventory Org ' ||lr_item_rev_rec.invorg;
      lc_error_exists      := 'N';                                          -- Reinitialise error_exists flag
      lc_starting_revision := NULL;                                         -- Reinitialise the starting_revision variable
      lc_revisionnbr       := NULL;                                         -- Reinitialise the revision variable
      ld_effdate           := NULL;                                         -- Reinitialise the effectivity_date variable
      lc_temp_flag         := NULL;
      ln_set_process_id    := NULL;
      gc_log_msg           :='usbpcs_item_cleaned-'||gc_record_identifier ;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      --Start of changes V1.3
      -- Assigning the set_process_id to the Mater and Child inventory organization
      IF lr_item_rev_rec.invorg = gc_master_org THEN
         ln_set_process_id  := gc_set_proc_id_mst; -- For Master Org
      ELSE
         ln_set_process_id  := gc_set_proc_id_child;  -- For Child Org
      END IF;
      --End of changes V1.3

      ----------------------------------------------------------
      -- Fetch Start_revision For the organization set in Oracle
      ----------------------------------------------------------
      BEGIN
         SELECT DISTINCT(MP.starting_revision)
         INTO   lc_starting_revision
         FROM   mtl_parameters MP
         WHERE  MP.organization_id =lr_item_rev_rec.invorgid;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'No starting revision has been set for the inventory organization'||lr_item_rev_rec.invorg );
         lc_starting_revision :=NULL;
      WHEN OTHERS THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'error while fetching starting_revision for the organization '||lr_item_rev_rec.invorg );
      END;


      IF lr_item_rev_rec.itemnbr   = lc_item_num AND
         lr_item_rev_rec.invorg    = lc_inv_org THEN
         lc_revisionnbr           := lr_item_rev_rec.revisionnbr;
         ld_effdate               := lr_item_rev_rec.effdate;
      ELSE
         OPEN  lcu_val_start_rev_c(lc_starting_revision,lr_item_rev_rec.itemnbr,lr_item_rev_rec.invorgid);
         FETCH lcu_val_start_rev_c INTO lc_temp_flag;
            IF lcu_val_start_rev_c%NOTFOUND THEN
               lc_revisionnbr  := lc_starting_revision;
               ld_effdate      := lr_item_rev_rec.itemstartdate;


               --**************************************************************************
               -- Inserting Default Revisions records into mtl_item_revisions_interface table
               --****************************************************************************
               BEGIN
                  INSERT INTO mtl_item_revisions_interface  (
                                                             organization_id
                                                            ,revision
                                                            ,last_update_date
                                                            ,last_updated_by
                                                            ,creation_date
                                                            ,created_by
                                                            ,last_update_login
                                                         -- ,change_notice
                                                            ,effectivity_date
                                                         --,description
                                                            ,item_number
                                                            ,process_flag
                                                            ,transaction_type
                                                            ,set_process_id
                                                            )
                                                      VALUES(
                                                              lr_item_rev_rec.invorgid
                                                             ,lc_revisionnbr
                                                             ,SYSDATE
                                                             ,FND_GLOBAL.USER_ID
                                                             ,SYSDATE
                                                             ,FND_GLOBAL.USER_ID
                                                             ,FND_GLOBAL.USER_ID
                                                           --,lr_item_rev_rec.chgnotice
                                                             ,ld_effdate
                                                           --,lr_item_rev_rec.description
                                                             ,lr_item_rev_rec.itemnbr
                                                             ,gc_process_flag
                                                             ,gc_transaction_type
                                                             ,ln_set_process_id
                                                            );

               EXCEPTION
               WHEN OTHERS THEN
                  lc_error_exists     := 'Y';
                  gc_error_code       :='ITEM-52';
                  gc_error_msg        :='Item Number '||lr_item_rev_rec.itemnbr ||' and Revision Number '||lr_item_rev_rec.revisionnbr||' record is failed to insert into MTL_ITEM_REVISIONS_INTERFACE  table due to error '||SQLERRM;
                  gc_comments         :='Please check the provided data';
                  INSERT_ERROR_PRC ;
               END;
               lc_item_num           :=lr_item_rev_rec.itemnbr;
               lc_inv_org            :=lr_item_rev_rec.invorg;
            END IF;
         CLOSE lcu_val_start_rev_c;

         lc_revisionnbr        := lr_item_rev_rec.revisionnbr;
         ld_effdate            := lr_item_rev_rec.effdate;
      END IF;

      --**************************************************************************
      -- Inserting  Revisions records into mtl_item_revisions_interface table
      --****************************************************************************
      BEGIN
         INSERT INTO mtl_item_revisions_interface  (
                                                    organization_id
                                                   ,revision
                                                   ,last_update_date
                                                   ,last_updated_by
                                                   ,creation_date
                                                   ,created_by
                                                   ,last_update_login
                                                   ,change_notice
                                                   ,effectivity_date
                                                   ,description
                                                   ,item_number
                                                   ,process_flag
                                                   ,transaction_type
                                                   ,set_process_id
                                                   )
                                             VALUES(
                                                     lr_item_rev_rec.invorgid
                                                    ,lc_revisionnbr
                                                    ,SYSDATE
                                                    ,FND_GLOBAL.USER_ID
                                                    ,SYSDATE
                                                    ,FND_GLOBAL.USER_ID
                                                    ,FND_GLOBAL.USER_ID
                                                    ,lr_item_rev_rec.chgnotice
                                                    ,ld_effdate
                                                    ,lr_item_rev_rec.description
                                                    ,lr_item_rev_rec.itemnbr
                                                    ,gc_process_flag
                                                    ,gc_transaction_type
                                                    ,ln_set_process_id
                                                   );

      EXCEPTION
      WHEN OTHERS THEN
         lc_error_exists     := 'Y';
         gc_error_code       :='ITEM-53';
         gc_error_msg        :='Item Number '||lr_item_rev_rec.itemnbr ||' and Revision Number '||lr_item_rev_rec.revisionnbr||' record is failed to insert into MTL_ITEM_REVISIONS_INTERFACE  table due to error '||SQLERRM;
         gc_comments         :='Please check the provided data';
         INSERT_ERROR_PRC ;
      END;

      -----------------------------------------
      -- Update ststus_flag in Staging Tables
      ------------------------------------------
      IF lc_error_exists   = 'Y' THEN

         --Start of changes V1.3

         lc_rollback_flag  :='Y';
         ---------------------------------------------------------
         --Call the update procedure for update the record status
         --which will run as a Autonomous transaction
         ---------------------------------------------------------
         update_rev_record_status (
                                     p_status_flag   =>'PE'
                                    ,p_request_id    =>gn_request_id
                                    ,p_itemnbr       =>lr_item_rev_rec.itemnbr
                                    ,p_revision      =>lr_item_rev_rec.revisionnbr
                                  );
      ELSE
         update_rev_record_status (
                                     p_status_flag   =>'PS'
                                    ,p_request_id    =>gn_request_id
                                    ,p_itemnbr       =>lr_item_rev_rec.itemnbr
                                    ,p_revision      =>lr_item_rev_rec.revisionnbr
                                  );
        --End of changes V1.3

      END IF;

   END LOOP;
   gc_log_msg:='Flag returned by the Data Insertion in mtl_item_revisions_interface table'||lc_error_exists;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --Start of changes V1.3
   -----------------------------------------------------------------
   -- If all records inserted successfully
   -- then issue commit else rollback whole data insertion process
   -----------------------------------------------------------------

   IF (lc_rollback_flag ='Y') THEN
      ROLLBACK;
   ELSE
      COMMIT;   -- COMMIT for all insertion
   END IF;

   --End of changes V1.3
   --------------------------------------------------------------------------
   --Count the total number of records for data insertion in interface tables
   -------------------------------------------------------------------------

   BEGIN
      SELECT COUNT (*)
      INTO   ln_total_item_recs
      FROM   usbpcs_item_cleaned ;

      SELECT COUNT (*)
      INTO   ln_total_inv_recs
      FROM   usbpcs_item_invorg ;

      SELECT COUNT (*)
      INTO   ln_total_rev_recs
      FROM   usbpcs_revision ;

   END;

   -------------------------------------------------------------
   --Count the number of records get failed in data Insertion
   -------------------------------------------------------------
   BEGIN
      SELECT COUNT (*)
      INTO   ln_item_reject_recs
      FROM   usbpcs_item_cleaned
      WHERE  oraclecharfld1='PE';

      SELECT COUNT (*)
      INTO   ln_inv_reject_recs
      FROM   usbpcs_item_invorg
      WHERE  oraclecharfld1='PE' ;

      SELECT COUNT (*)
      INTO   ln_rev_reject_recs
      FROM   usbpcs_revision
      WHERE  oraclecharfld1='PE' ;
   END;

   -------------------------------------------------------------
   --Count the number of records get processed in data Insertion
   -------------------------------------------------------------
   BEGIN
      SELECT COUNT (*)
      INTO   ln_item_process_recs
      FROM   usbpcs_item_cleaned
      WHERE  oraclecharfld1='PS';

      SELECT COUNT (*)
      INTO   ln_inv_process_recs
      FROM   usbpcs_item_invorg
      WHERE  oraclecharfld1='PS' ;

      SELECT COUNT (*)
      INTO   ln_rev_process_recs
      FROM   usbpcs_revision
      WHERE  oraclecharfld1='PS' ;
   END;

   IF gc_org_assigments_flag='Y' THEN

      ln_item_process_recs:=ln_total_item_recs;
      ln_total_inv_recs:=ln_inv_process_recs;
      ln_rev_process_recs:=ln_total_rev_recs;

   END IF;



   ----------------------------------------
   -- Summary Of Data Validation Process
   ----------------------------------------

   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_ITEM_CLEANED Records Processed ');
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records                                       :  ' ||ln_total_item_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Processed to interface tables         :  ' ||ln_item_process_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records failed to process to interface tables :  ' ||ln_item_reject_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_ITEM_INVORG Records Processed  ');
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records                                       :  ' ||ln_total_inv_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Processed to interface tables         :  ' ||ln_inv_process_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records failed to process to interface tables :  ' ||ln_inv_reject_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_REVISION Records Processed  ');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records                                       :  ' || ln_total_rev_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Processed to interface tables         :  ' ||ln_rev_process_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records failed to process to interface tables :  ' ||ln_rev_reject_recs);
   ----------------------------------------------------------------------------------
   -- If any single record failed in data insertion process then complete the program with warning
   -- and stop further processing of records .
   -----------------------------------------------------------------------------------
   IF ln_item_reject_recs > 0 OR ln_inv_reject_recs > 0 OR ln_rev_reject_recs > 0 THEN
     x_process_flag := 'Y';
   END IF;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in xxha_item_conv_pk.MOVE_ITEM_DATA: ' || SQLERRM);

END MOVE_ITEM_DATA;

END XXHA_INV_ITEM_CONV_PK ;
/
