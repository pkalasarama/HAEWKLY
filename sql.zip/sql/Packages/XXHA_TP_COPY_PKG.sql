CREATE OR REPLACE PACKAGE XXHA_TP_COPY_PKG AS

/***********************************************************************************************
* Package Name : XXHA_TP_COPY_PKG                                                              *
*                                                                                              *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to copy a Trading Partner Customer setup to a new Trading       *
*                   Partner.                                                                   *
*                                                                                              *
* Procedures   : p_load_data                                                                   *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
* HZ_CUST_ACCT_SITES_ALL           S                                                           *
* HZ_CUST_SITE_USES_ALL            S                                                           *
* HZ_PARTY_SITES                   S                                                           *
* HZ_LOCATIONS                     S                                                           *
* HZ_PARTIES                       S                                                           *
* HZ_CUST_ACCOUNTS                 S                                                           *
* ECX_TP_DETAILS                   S                                                           *
* ECX_TP_HEADERS                   S                                                           *
* ECX_MAPPINGS                     S                                                           *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        18-MAR-2013     B. Marcoux           Initial Version                              *
*                                                                                              *
***********************************************************************************************/

/* ****************************************************************************************** */
/* This procedure will Create the Trading Partner Header and Details                          */
PROCEDURE p_load_data  (
                        errbuf             OUT  VARCHAR2
                      , retcode            OUT  NUMBER
                      , p_tp_copy_from     IN   ECX_TP_HEADERS.TP_HEADER_ID%TYPE
                      , p_party_site_id    IN   HZ_PARTY_SITES.PARTY_SITE_ID%TYPE
                      , p_password         IN   ECX_TP_DETAILS_V.PASSWORD%TYPE
					  ) ;
END XXHA_TP_COPY_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_TP_COPY_PKG AS

/***********************************************************************************************
* Package Name : XXHA_TP_COPY_PKG                                                              *
*                                                                                              *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to copy a Trading Partner Customer setup to a new Trading       *
*                   Partner.                                                                   *
*                                                                                              *
* Procedures   : p_load_data                                                                   *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
* HZ_CUST_ACCT_SITES_ALL           S                                                           *
* HZ_CUST_SITE_USES_ALL            S                                                           *
* HZ_PARTY_SITES                   S                                                           *
* HZ_LOCATIONS                     S                                                           *
* HZ_PARTIES                       S                                                           *
* HZ_CUST_ACCOUNTS                 S                                                           *
* ECX_TP_DETAILS                   S                                                           *
* ECX_TP_HEADERS                   S                                                           *
* ECX_MAPPINGS                     S                                                           *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        18-MAR-2013     B. Marcoux           Initial Version                              *
*                                                                                              *
***********************************************************************************************/

/* ****************************************************************************************** */
/* This procedure will Create the Trading Partner Header and Details                          */
  PROCEDURE p_load_data (
                        errbuf             OUT  VARCHAR2
                      , retcode            OUT  NUMBER
                      , p_tp_copy_from     IN   ECX_TP_HEADERS.TP_HEADER_ID%TYPE
                      , p_party_site_id    IN   HZ_PARTY_SITES.PARTY_SITE_ID%TYPE
                      , p_password         IN   ECX_TP_DETAILS_V.PASSWORD%TYPE
                        ) IS

   V_RETURN_STATUS                   INTEGER;
   V_MSG                             VARCHAR2(2000);
   GC_STATUS                         VARCHAR2(02);
   LC_STATUS                         VARCHAR2(1000);

   XX_COMPANY_ADMIN_EMAIL            ECX_TP_HEADERS.COMPANY_ADMIN_EMAIL%TYPE;
   XX_CREATED_BY                     ECX_TP_HEADERS.CREATED_BY%TYPE;
   XX_CREATION_DATE                  ECX_TP_HEADERS.CREATION_DATE%TYPE;
   XX_LAST_UPDATED_BY                ECX_TP_HEADERS.LAST_UPDATED_BY%TYPE;
   XX_LAST_UPDATE_DATE               ECX_TP_HEADERS.LAST_UPDATE_DATE%TYPE;
   XX_TP_HEADER_ID                   ECX_TP_HEADERS.TP_HEADER_ID%TYPE;
   XX_RETURN_STATUS                  VARCHAR2(2500);
   XX_MSG                            VARCHAR2(2500);

   V_TP_HEADER_ID                    ECX_TP_HEADERS.TP_HEADER_ID%TYPE;
   V_TP_DETAIL_ID                    ECX_TP_DETAILS.TP_DETAIL_ID%TYPE;
   LN_TP_HEADER_ID                   ECX_TP_HEADERS.TP_HEADER_ID%TYPE;
   LN_TP_DETAIL_ID                   ECX_TP_DETAILS.TP_DETAIL_ID%TYPE;
   LN_PS_PARTY_SITE_ID               HZ_PARTY_SITES.PARTY_SITE_ID%TYPE;
   LN_PS_PARTY_ID                    HZ_PARTY_SITES.PARTY_ID%TYPE;
   LN_ECE_TP_LOCATION_CODE           HZ_CUST_ACCT_SITES_ALL.ECE_TP_LOCATION_CODE%TYPE;

   GC_REQUEST_ID                     XXHA_COMMON_ERRORS.REQUEST_ID%TYPE         := FND_GLOBAL.CONC_REQUEST_ID;
   GC_RECORD_IDENTIFIER              XXHA_COMMON_ERRORS.RECORD_IDENTIFIER%TYPE;
   GC_RECORD_NUMBER                  XXHA_COMMON_ERRORS.RECORD_NUMBER%TYPE;
   GC_ERROR_CODE                     XXHA_COMMON_ERRORS.ERROR_CODE%TYPE;
   GC_ERROR_MSG                      XXHA_COMMON_ERRORS.ERROR_MSG%TYPE;
   GC_COMMENTS                       XXHA_COMMON_ERRORS.COMMENTS%TYPE;
   GC_ATTRIBUTE1                     XXHA_COMMON_ERRORS.ATTRIBUTE1%TYPE;
   GC_ATTRIBUTE2                     XXHA_COMMON_ERRORS.ATTRIBUTE2%TYPE;
   GC_ATTRIBUTE3                     XXHA_COMMON_ERRORS.ATTRIBUTE3%TYPE;
   GC_ATTRIBUTE4                     XXHA_COMMON_ERRORS.ATTRIBUTE4%TYPE;
   GC_ATTRIBUTE5                     XXHA_COMMON_ERRORS.ATTRIBUTE5%TYPE;
   GC_TABLE_NAME                     XXHA_COMMON_ERRORS.TABLE_NAME%TYPE         := 'XXHA_TP_COPY';

   CURSOR C_TP_HEADER(P_HEADER_ID NUMBER) IS
   SELECT
       HDR.COMPANY_ADMIN_EMAIL
   FROM
       ECX_TP_HEADERS             HDR
   ,   HZ_CUST_ACCT_SITES_ALL     CAS
   ,   HZ_CUST_SITE_USES_ALL      SU
   ,   HZ_PARTY_SITES             PS
   ,   HZ_LOCATIONS               LOC
   ,   HZ_PARTIES                 PARTY
   ,   HZ_CUST_ACCOUNTS           CUST
   WHERE
       HDR.TP_HEADER_ID         = P_HEADER_ID
   AND HDR.PARTY_SITE_ID        = CAS.PARTY_SITE_ID
   AND CAS.CUST_ACCT_SITE_ID    = SU.CUST_ACCT_SITE_ID
   AND CAS.PARTY_SITE_ID        = PS.PARTY_SITE_ID
   AND PS.LOCATION_ID           = LOC.LOCATION_ID
   AND CAS.CUST_ACCOUNT_ID      = CUST.CUST_ACCOUNT_ID
   AND CUST.PARTY_ID            = PARTY.PARTY_ID;

   CURSOR C_TP_DETAIL(P_HEADER_ID NUMBER) IS
   SELECT
       DTL.TP_DETAIL_ID
   ,   DTL.MAP_ID
   ,   MP.MAP_CODE
   ,   DTL.EXT_PROCESS_ID
   ,   DTL.CONNECTION_TYPE
   ,   DTL.HUB_USER_ID
   ,   DTL.PROTOCOL_TYPE
   ,   DTL.PROTOCOL_ADDRESS
   ,   DTL.USERNAME
   ,   DTL.PASSWORD
   ,   DTL.ROUTING_ID
   ,   DTL.SOURCE_TP_LOCATION_CODE
   ,   DTL.EXTERNAL_TP_LOCATION_CODE
   ,   DTL.CONFIRMATION
   FROM
       ECX_TP_DETAILS             DTL
   ,   ECX_TP_HEADERS             HDR
   ,   ECX_MAPPINGS               MP
   WHERE
       HDR.TP_HEADER_ID         = P_HEADER_ID
   AND HDR.TP_HEADER_ID         = DTL.TP_HEADER_ID
   AND DTL.MAP_ID               = MP.MAP_ID;

BEGIN

   FND_GLOBAL.APPS_INITIALIZE(FND_GLOBAL.USER_ID, FND_GLOBAL.RESP_ID, FND_GLOBAL.RESP_APPL_ID);

   SELECT DISTINCT
       PS.PARTY_ID
   ,   PS.PARTY_SITE_ID
   ,   CAS.ECE_TP_LOCATION_CODE
   INTO
       LN_PS_PARTY_ID
   ,   LN_PS_PARTY_SITE_ID
   ,   LN_ECE_TP_LOCATION_CODE
   FROM
       HZ_CUST_ACCT_SITES_ALL     CAS
   ,   HZ_CUST_SITE_USES_ALL      SU
   ,   HZ_PARTY_SITES             PS
   ,   HZ_LOCATIONS               LOC
   ,   HZ_PARTIES                 PARTY
   ,   HZ_CUST_ACCOUNTS           CUST
   WHERE
       CAS.CUST_ACCT_SITE_ID    = SU.CUST_ACCT_SITE_ID
   AND CAS.PARTY_SITE_ID        = PS.PARTY_SITE_ID
   AND PS.LOCATION_ID           = LOC.LOCATION_ID
   AND CAS.CUST_ACCOUNT_ID      = CUST.CUST_ACCOUNT_ID
   AND CAS.ECE_TP_LOCATION_CODE IS NOT NULL
   AND CUST.PARTY_ID            = PARTY.PARTY_ID
   AND PS.PARTY_SITE_ID         = p_party_site_id;

   BEGIN

   FOR HEADER_REC IN C_TP_HEADER(p_tp_copy_from)

   LOOP

   -- Check to see if TP Header exists for the entered Site
   ECX_TP_API.RETRIEVE_TRADING_PARTNER
       (P_PARTY_TYPE              => 'C'
       ,P_PARTY_ID                => LN_PS_PARTY_ID
       ,P_PARTY_SITE_ID           => LN_PS_PARTY_SITE_ID
       ,X_COMPANY_ADMIN_EMAIL     => XX_COMPANY_ADMIN_EMAIL
       ,X_CREATED_BY              => XX_CREATED_BY
       ,X_CREATION_DATE           => XX_CREATION_DATE
       ,X_LAST_UPDATED_BY         => XX_LAST_UPDATED_BY
       ,X_LAST_UPDATE_DATE        => XX_LAST_UPDATE_DATE
       ,X_RETURN_STATUS           => V_RETURN_STATUS
       ,X_MSG                     => V_MSG
       ,X_TP_HEADER_ID            => XX_TP_HEADER_ID);
       GC_RECORD_NUMBER           := 1;
       GC_RECORD_IDENTIFIER       := XX_TP_HEADER_ID;
       GC_ERROR_CODE              := 'TP1';
       GC_ERROR_MSG               := V_RETURN_STATUS;
       GC_COMMENTS                := V_MSG;
       XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

   -- Does it already exist?
   IF XX_TP_HEADER_ID = -1 THEN

       -- Create TP Header
       ECX_TP_API.CREATE_TRADING_PARTNER
           (P_PARTY_TYPE             => 'C'
           ,P_PARTY_ID               => LN_PS_PARTY_ID
           ,P_PARTY_SITE_ID          => LN_PS_PARTY_SITE_ID
           ,P_COMPANY_ADMIN_EMAIL    => HEADER_REC.COMPANY_ADMIN_EMAIL
           ,X_RETURN_STATUS          => V_RETURN_STATUS
           ,X_MSG                    => V_MSG
           ,X_TP_HEADER_ID           => V_TP_HEADER_ID);
           GC_RECORD_NUMBER          := 1;
           GC_RECORD_IDENTIFIER      := V_TP_HEADER_ID;
           GC_ERROR_CODE             := 'TP1';
           GC_ERROR_MSG              := V_RETURN_STATUS;
           GC_COMMENTS               := V_MSG;
           XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

           FOR DETAIL_REC IN C_TP_DETAIL(p_tp_copy_from)

           LOOP

             -- Create TP Detail
             IF DETAIL_REC.PROTOCOL_ADDRESS IS NOT NULL THEN
                ECX_TP_API.CREATE_TP_DETAIL
               (P_TP_HEADER_ID                => V_TP_HEADER_ID                     --IN   pls_integer,
               ,P_EXT_PROCESS_ID              => DETAIL_REC.EXT_PROCESS_ID          --IN   pls_integer,
               ,P_MAP_CODE                    => DETAIL_REC.MAP_CODE                --IN   VARCHAR2,
               ,P_CONNECTION_TYPE             => DETAIL_REC.CONNECTION_TYPE         --IN   VARCHAR2,
               ,P_HUB_USER_ID                 => DETAIL_REC.HUB_USER_ID             --IN   pls_integer,
               ,P_PROTOCOL_TYPE               => DETAIL_REC.PROTOCOL_TYPE           --IN   VARCHAR2,
               ,P_PROTOCOL_ADDRESS            => DETAIL_REC.PROTOCOL_ADDRESS        --IN   VARCHAR2,
               ,P_USERNAME                    => DETAIL_REC.USERNAME                --IN   VARCHAR2,
               ,P_PASSWORD                    => p_password                         --IN   VARCHAR2  default null,
               ,P_ROUTING_ID                  => DETAIL_REC.ROUTING_ID              --IN   pls_integer,
               ,P_SOURCE_TP_LOCATION_CODE     => DETAIL_REC.SOURCE_TP_LOCATION_CODE --IN   VARCHAR2  default null,
               ,P_EXTERNAL_TP_LOCATION_CODE   => LN_ECE_TP_LOCATION_CODE            --IN   VARCHAR2,
               ,P_CONFIRMATION                => DETAIL_REC.CONFIRMATION            --IN   pls_integer
               ,X_RETURN_STATUS               => V_RETURN_STATUS
               ,X_MSG                         => V_MSG
               ,X_TP_DETAIL_ID                => V_TP_DETAIL_ID);
               GC_RECORD_NUMBER               := 2;
               GC_RECORD_IDENTIFIER           := V_TP_DETAIL_ID;
               GC_ERROR_CODE                  := 'TP2';
               GC_ERROR_MSG                   := V_RETURN_STATUS;
               GC_COMMENTS                    := V_MSG;
               XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);
             END IF;

             -- Create TP Detail
             IF DETAIL_REC.PROTOCOL_ADDRESS IS NULL THEN
                ECX_TP_API.CREATE_TP_DETAIL
               (P_TP_HEADER_ID                => V_TP_HEADER_ID                     --IN   pls_integer,
               ,P_EXT_PROCESS_ID              => DETAIL_REC.EXT_PROCESS_ID          --IN   pls_integer, (was 321)
               ,P_MAP_CODE                    => DETAIL_REC.MAP_CODE                --IN   VARCHAR2,
               ,P_CONNECTION_TYPE             => DETAIL_REC.CONNECTION_TYPE         --IN   VARCHAR2,
               ,P_HUB_USER_ID                 => DETAIL_REC.HUB_USER_ID             --IN   pls_integer,
               ,P_PROTOCOL_TYPE               => DETAIL_REC.PROTOCOL_TYPE           --IN   VARCHAR2,
               ,P_PROTOCOL_ADDRESS            => DETAIL_REC.PROTOCOL_ADDRESS        --IN   VARCHAR2,
               ,P_USERNAME                    => DETAIL_REC.USERNAME                --IN   VARCHAR2,
               ,P_PASSWORD                    => NULL                               --IN   VARCHAR2,
               ,P_ROUTING_ID                  => DETAIL_REC.ROUTING_ID              --IN   pls_integer,
               ,P_SOURCE_TP_LOCATION_CODE     => LN_ECE_TP_LOCATION_CODE            --IN   VARCHAR2  default null,
               ,P_EXTERNAL_TP_LOCATION_CODE   => NULL                               --IN   VARCHAR2,
               ,P_CONFIRMATION                => DETAIL_REC.CONFIRMATION            --IN   pls_integer
               ,X_RETURN_STATUS               => V_RETURN_STATUS
               ,X_MSG                         => V_MSG
               ,X_TP_DETAIL_ID                => V_TP_DETAIL_ID);
               GC_RECORD_NUMBER               := 2;
               GC_RECORD_IDENTIFIER           := V_TP_DETAIL_ID;
               GC_ERROR_CODE                  := 'TP2';
               GC_ERROR_MSG                   := V_RETURN_STATUS;
               GC_COMMENTS                    := V_MSG;
               XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);
             END IF;

           END LOOP;

   END IF;

   END LOOP;

   END;

END;

END XXHA_TP_COPY_PKG;
/
