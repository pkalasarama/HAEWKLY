create or replace PACKAGE BODY XXHA_WD_EMPLOYEE_CREATE_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_WD_EMPLOYEE_CREATE_PKG                                                                            *
* Purpose      : This Package will process New Employee Records created by Workday.                                     *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*              : XXHA_CHECK_FOR_NON_NUMERIC                                                                             *
*              : XXHA_BACKUP_DATA                                                                                       *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        20-FEB-2018     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

--------------------------------------------------------------------------------
PROCEDURE XXHA_PROCESS_DATA(
          errbuf            OUT VARCHAR2
         ,errcode           OUT VARCHAR2) AS

BEGIN

DECLARE

   l_WD_RECORD_ID                           HAEMO.XXHA_WD_EMPLOYEE_CREATE.WD_RECORD_ID%TYPE;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CREATE.STATUS_MESSAGE%TYPE := NULL;
   l_errcode                                VARCHAR2(2000);
   l_ERROR_MSG                              VARCHAR2(2000);
   l_EXCEPTION                              EXCEPTION;
   l_Count                                  NUMBER;

   l_Value_In                               VARCHAR2(20);
   l_Value_Out                              VARCHAR2(20);
   l_location_Id_Num                        HR_LOCATIONS_V.location_id%TYPE;

   l_ATTRIBUTE_ORACLE1                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE1%TYPE;
   l_ATTRIBUTE_ORACLE2                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE2%TYPE;
   l_ATTRIBUTE_WD1                          HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD1%TYPE;
   l_ATTRIBUTE_WD2                          HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD2%TYPE;

   l_business_group_id                      per_business_groups.business_group_id%TYPE;
   l_business_group                         per_business_groups.name%TYPE;
   l_organization_country                   HR_LOCATIONS_V.country%TYPE;
   l_location_id                            HR_LOCATIONS_V.location_id%TYPE;
   l_person_type_id                         per_person_types.person_type_id%TYPE;
   l_assignment_category_code               PER_ASSIGNMENTS_X.Employment_Category%TYPE;
   l_sup_person_id                          per_people_X.Person_id%TYPE;
   l_sup_full_name                          per_people_X.full_name%TYPE;

   lc_BUSINESS_GROUP                        per_business_groups.name%TYPE;
   lc_BUSINESS_GROUP_ID                     per_business_groups.business_group_id%TYPE;
   lc_LOCATION                              HR_LOCATIONS_V.location_code%TYPE;
   lc_LOCATION_ID                           HR_LOCATIONS_V.location_id%TYPE;
   lc_SEX                                   PER_PEOPLE_X.SEX%TYPE;
   lc_DATE_OF_BIRTH                         PER_PEOPLE_X.DATE_OF_BIRTH%TYPE;
   lc_ORGANIZATION_ID                       PER_ASSIGNMENTS_X.ORGANIZATION_ID%TYPE;
   lc_ORGANIZATION_NAME                     HR_ALL_ORGANIZATION_UNITS.name%TYPE;
   lc_ORGANIZATION_COUNTRY                  HR_LOCATIONS_V.country%TYPE;
   lc_JOB_ID                                PER_ASSIGNMENTS_X.JOB_ID%TYPE;
   lc_JOB_FAMILY                            per_jobs.Job_Information9%TYPE;
   lc_JOB_NAME                              per_jobs.name%TYPE;
   lc_JOB_DEFINITION_ID                     per_jobs.job_definition_id%TYPE;
   lc_JOB_GRADE_ID                          PER_ASSIGNMENTS_X.GRADE_ID%TYPE;
   lc_JOB_GRADE                             per_grades.name%TYPE;
   lc_PAYROLL_ID                            PER_ASSIGNMENTS_X.PAYROLL_ID%TYPE;
   lc_PAYROLL_NAME                          pay_all_payrolls_f.payroll_name%TYPE;
   lc_SET_OF_BOOKS_ID                       PER_ASSIGNMENTS_X.Set_of_Books_ID%TYPE;
   lc_LEDGER                                gl_ledgers.name%TYPE;
   lc_PAY_BASIS_ID                          PER_ASSIGNMENTS_X.PAY_BASIS_ID%TYPE;
   lc_SALARY_PAY_BASIS                      per_pay_bases.name%TYPE;
   lc_HOURLY_SALARIED_CODE                  PER_ASSIGNMENTS_X.Hourly_Salaried_Code%TYPE;
   lc_HOURLY_SALARIED_MEANING               VARCHAR2(240);
   lc_SOFT_CODING_KEYFLEX_ID                PER_ASSIGNMENTS_X.Soft_Coding_Keyflex_Id%TYPE;
   lc_SOFT_CODING_KEYFLEX_MEANING           VARCHAR2(240);
   lc_CODE_COMBINATION_ID                   GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   lc_EXPENSE_ACCOUNT                       VARCHAR2(240);
   lc_NATIONALITY                           PER_PEOPLE_X.NATIONALITY%TYPE;
   lc_CORRESPONDENCE_LANGUAGE               PER_PEOPLE_X.CORRESPONDENCE_LANGUAGE%TYPE;
   lc_ATTRIBUTE_CATEGORY                    PER_PEOPLE_X.ATTRIBUTE_CATEGORY%TYPE;
   lc_PER_INFORMATION_CATEGORY              PER_PEOPLE_X.PER_INFORMATION_CATEGORY%TYPE;
   lc_PER_INFORMATION1                      PER_PEOPLE_X.PER_INFORMATION1%TYPE;
   lc_PER_INFORMATION2                      PER_PEOPLE_X.PER_INFORMATION2%TYPE;
   lc_PER_INFORMATION3                      PER_PEOPLE_X.PER_INFORMATION3%TYPE;
   lc_PER_INFORMATION4                      PER_PEOPLE_X.PER_INFORMATION4%TYPE;
   lc_PER_INFORMATION5                      PER_PEOPLE_X.PER_INFORMATION5%TYPE;
   lc_PER_INFORMATION6                      PER_PEOPLE_X.PER_INFORMATION6%TYPE;
   lc_PER_INFORMATION7                      PER_PEOPLE_X.PER_INFORMATION7%TYPE;
   lc_PER_INFORMATION8                      PER_PEOPLE_X.PER_INFORMATION8%TYPE;
   lc_PER_INFORMATION9                      PER_PEOPLE_X.PER_INFORMATION9%TYPE;
   lc_PER_INFORMATION10                     PER_PEOPLE_X.PER_INFORMATION10%TYPE;
   lc_PER_INFORMATION18                     PER_PEOPLE_X.PER_INFORMATION18%TYPE;
   lc_PER_INFORMATION19                     PER_PEOPLE_X.PER_INFORMATION19%TYPE;
   lc_ASS_ATTRIBUTE_CATEGORY                PER_ASSIGNMENTS_X.ASS_ATTRIBUTE_CATEGORY%TYPE;
   lc_ASS_ATTRIBUTE1                        PER_ASSIGNMENTS_X.ASS_ATTRIBUTE1%TYPE;
   lc_ASS_ATTRIBUTE7                        PER_ASSIGNMENTS_X.ASS_ATTRIBUTE7%TYPE;
   lc_ASS_ATTRIBUTE8                        PER_ASSIGNMENTS_X.ASS_ATTRIBUTE8%TYPE;
   lc_EMPLOYEE_CATEGORY                     PER_ASSIGNMENTS_X.Employment_Category%TYPE;
   lc_SEGMENT8                              VARCHAR2(240);
   lc_ESTABLISHMENT_ID                      NUMBER;
   lc_Status                                HAEMO.XXHA_WD_EMPLOYEE_CREATE.STATUS%TYPE;
   lc_haemo_email_required                  VARCHAR2(05);
   lc_NATIONAL_IDENTIFIER                   PER_PEOPLE_X.NATIONAL_IDENTIFIER%TYPE;

   l_error_message                          VARCHAR (4000);
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CREATE.STATUS%TYPE;

   -- hr_employee_api.create_us_employee/hr_employee_api.create_employee
   -- OUTPUT
   l_employee_number                        per_people_X.employee_number%TYPE;
   l_person_id                              per_people_X.Person_id%TYPE;
   l_assignment_id                          PER_ASSIGNMENTS_X.assignment_id%TYPE;
   l_per_object_version_number              PER_PEOPLE_X.object_version_number%TYPE;
   l_asg_object_version_number              PER_ASSIGNMENTS_X.object_version_number%TYPE;
   l_per_effective_start_date               PER_PEOPLE_X.effective_start_date%TYPE;
   l_per_effective_end_date                 PER_PEOPLE_X.effective_end_date%TYPE;
   l_full_name                              PER_PEOPLE_X.full_name%TYPE;
   l_per_comment_id                         NUMBER;
   l_assignment_sequence                    NUMBER;
   l_assignment_number                      VARCHAR2(30);
   l_name_combination_warning               BOOLEAN;
   l_assign_payroll_warning                 BOOLEAN;
   l_orig_hire_warning                      BOOLEAN;

   -- hr_assignment_api.update_emp_asg
   -- INPUT
   l_asg_effective_start_date               PER_ASSIGNMENTS_X.effective_start_date%TYPE   := NULL;
   l_assignment_ovn                         PER_ASSIGNMENTS_X.object_version_number%TYPE  := NULL;
   l_ass_attribute_category                 PER_ASSIGNMENTS_X.ASS_ATTRIBUTE_CATEGORY%TYPE := NULL;
   l_ass_attribute1                         PER_ASSIGNMENTS_X.ASS_ATTRIBUTE1%TYPE         := NULL;
   l_ass_attribute7                         PER_ASSIGNMENTS_X.ASS_ATTRIBUTE7%TYPE         := NULL;
   l_ass_attribute8                         PER_ASSIGNMENTS_X.ASS_ATTRIBUTE8%TYPE         := NULL;
   l_segment1                               VARCHAR2(60)                                  := NULL;
   l_segment2                               VARCHAR2(60)                                  := NULL;
   l_segment3                               VARCHAR2(60)                                  := NULL;
   l_segment4                               VARCHAR2(60)                                  := NULL;
   l_segment8                               VARCHAR2(60)                                  := NULL;
   l_segment20                              VARCHAR2(60)                                  := NULL;
   l_segment21                              VARCHAR2(60)                                  := NULL;
   l_concatenated_segments                  VARCHAR2 (1000);                                        -- out nocopy varchar2                   
   l_SOFT_CODING_KEYFLEX_ID                 PER_ASSIGNMENTS_X.Soft_Coding_Keyflex_Id%TYPE;          -- in out nocopy number
   -- OUTPUT
   l_comment_id                             NUMBER;
   l_effective_start_date                   DATE;
   l_effective_end_date                     DATE;
   l_no_managers_warning                    BOOLEAN;
   l_other_manager_warning                  BOOLEAN;
   l_employee_category                      VARCHAR2 (100);
   l_hourly_salaried_warning                BOOLEAN;
   l_cagr_concatenated_segments             VARCHAR2 (1000);
   l_cagr_grade_def_id                      NUMBER;

   -- hr_assignment_api.update_emp_asg_criteria
   -- OUTPUT
   io_people_group_id                       NUMBER;                             --  in out nocopy number
   io_special_ceiling_step_id               NUMBER;                             --  in out nocopy number
   io_soft_coding_keyflex_id                NUMBER;                             --  in out nocopy number
   o_group_name                             VARCHAR2 (255);                     --  out nocopy varchar2
   o_effective_start_date                   DATE;                               --  out nocopy date
   o_effective_end_date                     DATE;                               --  out nocopy date
   o_org_now_no_manager_warning             BOOLEAN;                            --  out nocopy boolean
   o_other_manager_warning                  BOOLEAN;                            --  out nocopy boolean
   o_spp_delete_warning                     BOOLEAN;                            --  out nocopy boolean
   o_entries_changed_warning                VARCHAR2 (1000);                    --  out nocopy varchar2
   o_tax_district_changed_warning           BOOLEAN;                            --  out nocopy boolean
   o_concatenated_segments                  VARCHAR2 (100);
   o_gsp_post_process_warning               VARCHAR2 (100);

   -- fnd_user_pkg.createuser
   -- INPUT
   ln_user_name                             FND_USER.USER_NAME%TYPE;
   ln_user_password                         FND_USER.ENCRYPTED_USER_PASSWORD%TYPE;
   ln_user_start_date                       FND_USER.START_DATE%TYPE;
   ln_user_end_date                         FND_USER.END_DATE%TYPE;
   ln_password_date                         FND_USER.PASSWORD_DATE%TYPE;
   ln_password_lifespan_days                FND_USER.PASSWORD_LIFESPAN_DAYS%TYPE;
   ln_person_id                             FND_USER.EMPLOYEE_ID%TYPE;
   ln_email_address                         FND_USER.EMAIL_ADDRESS%TYPE;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE
CURSOR cur_0100 (p_Status HAEMO.XXHA_WD_EMPLOYEE_CREATE.STATUS%TYPE)
IS
SELECT
    PERSON_ID
  , USER_NAME
  , EMPLOYEE_NUMBER
  , FIRST_NAME
  , LAST_NAME
  , KNOWN_AS
  , PERSON_TYPE_WD
  , PERSON_TYPE
  , PERSON_TYPE_ID
  , TIME_TYPE_WD
  , ASSIGNMENT_CATEGORY
  , ASSIGNMENT_CATEGORY_CODE
  , EMAIL_ADDRESS
  , SUP_PERSON_ID
  , SUP_FULL_NAME
  , START_DATE
  , START_DATE_CHAR
  , LOCATION_ID                                 
  , LOCATION
  , PHONE_WORK
  , PHONE_MOBILE
  , BUSINESS_GROUP_ID
  , BUSINESS_GROUP
  , ORGANIZATION_COUNTRY
--
  , CREATION_DATE
  , STATUS
  , STATUS_MESSAGE
  , PROCESS_TO_WD_STATUS
  , PROCESS_TO_WD_DATE
  , WD_RECORD_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CREATE
WHERE
    NVL(STATUS,'XXX')              = NVL(p_Status,'XXX')
AND NVL(PROCESS_TO_WD_STATUS,'N')  NOT IN ('Y','C')                             -- Don't want to select if Ready to Process to WD ('Y') or has been Processed to WD ('C')
ORDER BY
    WD_RECORD_ID
;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP
CURSOR cur_0110 (c_ATTRIBUTE_CATEGORY HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_CATEGORY%TYPE,
                 c_ATTRIBUTE_WD1 HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD1%TYPE, 
                 c_ATTRIBUTE_WD2 HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD2%TYPE)
IS
SELECT
    maps.ATTRIBUTE_ORACLE1
  , maps.ATTRIBUTE_ORACLE2
FROM
    HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP maps
WHERE
    maps.ATTRIBUTE_CATEGORY        = c_ATTRIBUTE_CATEGORY
AND maps.ATTRIBUTE_WD1             = NVL(c_ATTRIBUTE_WD1,'XXX')
AND NVL(maps.ATTRIBUTE_WD2,'XXX')  = NVL(c_ATTRIBUTE_WD2,'XXX')
;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_MAPPPING using location_id
CURSOR cur_0200 (c_LOCATION apps.HR_LOCATIONS_V.LOCATION_ID%TYPE)
IS
SELECT
    BUSINESS_GROUP
  , BUSINESS_GROUP_ID
  , ORGANIZATION_COUNTRY
  , LOCATION_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_MAPPPING
WHERE
    LOCATION_ID = c_LOCATION
;

-- Retrieve Person Type
CURSOR cur_0300 (c_USER_PERSON_TYPE APPS.PER_PERSON_TYPES.USER_PERSON_TYPE%TYPE, c_business_group_id per_business_groups.business_group_id%TYPE)
IS
SELECT
    PT.PERSON_TYPE_ID
FROM
    APPS.PER_PERSON_TYPES  PT
WHERE
    PT.USER_PERSON_TYPE  = c_USER_PERSON_TYPE
AND pt.BUSINESS_GROUP_ID = c_business_group_id
;

-- Retrieve Supervisor Full Name
CURSOR cur_0400 (c_PERSON_ID APPS.PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    PPX.FULL_NAME
FROM
    APPS.PER_PEOPLE_X  PPX
WHERE
    PPX.PERSON_ID    = c_PERSON_ID 
;

-- Retrieve Employee
CURSOR cur_0410 (c_EMPLOYEE_NUMBER APPS.PER_PEOPLE_X.EMPLOYEE_NUMBER%TYPE)
IS
SELECT
    PPX.FULL_NAME
FROM
    APPS.PER_PEOPLE_X     PPX
WHERE
    PPX.EMPLOYEE_NUMBER = c_EMPLOYEE_NUMBER
;

-- Retrieve assignment category code
CURSOR cur_0420 (c_lookup_Code APPS.hr_lookups.lookup_Code%TYPE)
IS
SELECT
     hrl.MEANING 
FROM
     APPS.hr_lookups     hrl 
WHERE
    hrl.lookup_type(+) = 'EMP_CAT'
AND hrl.Enabled_Flag   = 'Y' 
AND TRUNC(SYSDATE)     BETWEEN NVL(TRUNC(hrl.START_DATE_ACTIVE), TRUNC(SYSDATE)-1) AND NVL(TRUNC(hrl.END_DATE_ACTIVE), TRUNC(SYSDATE)+1)
AND hrl.lookup_Code    = c_lookup_Code
;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_MAPPPING using Location_ID
CURSOR cur_0500 (c_LOCATION_id apps.HR_LOCATIONS_V.location_id%TYPE)
IS
SELECT
    map.BUSINESS_GROUP
  , map.BUSINESS_GROUP_ID
  , map.LOCATION
  , map.LOCATION_ID
  , map.SEX
  , map.DATE_OF_BIRTH
  , map.ORGANIZATION_ID
  , map.ORGANIZATION_NAME
  , map.ORGANIZATION_COUNTRY
  , map.JOB_ID
  , map.JOB_FAMILY
  , map.JOB_NAME
  , map.JOB_DEFINITION_ID
  , map.JOB_GRADE_ID
  , map.JOB_GRADE
  , map.PAYROLL_ID
  , map.PAYROLL_NAME
  , map.SET_OF_BOOKS_ID
  , map.LEDGER
  , map.PAY_BASIS_ID
  , map.SALARY_PAY_BASIS
  , map.HOURLY_SALARIED_CODE
  , map.HOURLY_SALARIED_MEANING
  , map.SOFT_CODING_KEYFLEX_ID
  , map.SOFT_CODING_KEYFLEX_MEANING
  , map.CODE_COMBINATION_ID
  , map.EXPENSE_ACCOUNT
  , map.NATIONALITY
  , map.CORRESPONDENCE_LANGUAGE
  , map.ATTRIBUTE_CATEGORY
  , map.PER_INFORMATION_CATEGORY
  , map.PER_INFORMATION1
  , map.PER_INFORMATION2
  , map.PER_INFORMATION3
  , map.PER_INFORMATION4
  , map.PER_INFORMATION5
  , map.PER_INFORMATION6
  , map.PER_INFORMATION7
  , map.PER_INFORMATION8
  , map.PER_INFORMATION9
  , map.PER_INFORMATION10
  , map.PER_INFORMATION18
  , map.PER_INFORMATION19
  , map.ASS_ATTRIBUTE_CATEGORY
  , map.ASS_ATTRIBUTE1
  , map.ASS_ATTRIBUTE7
  , map.ASS_ATTRIBUTE8
  , map.EMPLOYEE_CATEGORY
  , map.SEGMENT8
  , map.ESTABLISHMENT_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_MAPPPING MAP
WHERE
    MAP.LOCATION_ID               = c_LOCATION_id
;

-- Retrieve assignment data for Person_ID
CURSOR cur_0600 (c_person_id per_assignments_f.person_id%TYPE, c_start_date per_assignments_f.effective_Start_Date%TYPE)
IS
SELECT 
    paf.assignment_id
  , paf.object_version_number
  , paf.effective_start_date
  , paf.business_group_id
FROM 
    per_assignments_f                 paf
WHERE 
    paf.person_id                   = c_person_id
AND TRUNC(paf.effective_Start_Date) = c_start_date
;  

-- Retrieve object_version_number for assignment_id
CURSOR cur_0700 (c_assignment_id per_all_assignments_f.assignment_id%TYPE)
IS
SELECT 
    asg.object_version_number
FROM
    per_all_assignments_f asg
WHERE
    asg.assignment_id   = l_assignment_id
;

BEGIN

--------------------------------------------------------------------------------
-- Ensure WD_RECORD_ID must contain a value and must be unique in the mapping table
--------------------------------------------------------------------------------

   -- Initialize Values
   l_Count   := 0;
   l_errcode := NULL;

   -- WD_RECORD_ID must contain a value
   BEGIN
      SELECT COUNT(*)
        INTO l_Count
        FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE
       WHERE WD_RECORD_ID IS NULL;
   EXCEPTION
        WHEN NO_DATA_FOUND THEN
             l_Count := 0;
   END;

   BEGIN
      IF NVL(l_Count,0) > 0 THEN
         l_errcode := 'WD_RECORD_ID in table ''HAEMO.XXHA_WD_EMPLOYEE_CREATE'' is null - Abnormal End';
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_errcode);
         RAISE l_EXCEPTION;
      END IF;
   EXCEPTION
        WHEN OTHERS THEN
             errcode := l_errcode;
             RETURN;
   END;

   -- Initialize Values
   l_errcode      := NULL;
   l_Count        := 0;
   l_WD_RECORD_ID := 0;

   -- WD_RECORD_ID must be unique
   BEGIN
      SELECT DISTINCT WD_RECORD_ID, COUNT(*)
        INTO l_WD_RECORD_ID, l_Count
        FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE
       GROUP BY
             WD_RECORD_ID
      HAVING COUNT(*) > 1;
   EXCEPTION
        WHEN NO_DATA_FOUND THEN
             l_Count := 0;
   END;

   BEGIN
      IF NVL(l_Count,0) > 0 THEN
         l_errcode := 'WD_RECORD_ID in table ''HAEMO.XXHA_WD_EMPLOYEE_CREATE'' must be unique - Abnormal End';
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_errcode);
         RAISE l_EXCEPTION;
      END IF;
   EXCEPTION
        WHEN OTHERS THEN
             errcode := l_errcode;
             RETURN;
   END;

--------------------------------------------------------------------------------
-- Check for Non-Numeric Values
--------------------------------------------------------------------------------

   -- Initialize Value
   lc_Status := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE
   FOR dta0100 IN cur_0100 (lc_Status)
   LOOP

      -- Initialize Value
      l_Value_Out := NULL;

      -- Check Location value for non-numeric values
      XXHA_CHECK_FOR_NON_NUMERIC(dta0100.LOCATION, l_Value_Out);

      -- Check to see if valid or not
      IF l_Value_Out = 'Invalid' THEN
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Location contains non-numeric value: ' || dta0100.LOCATION || ' / ')
              , XXHA.STATUS = 'FAIL'
          WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
      END IF;

   COMMIT;

   END LOOP;

--------------------------------------------------------------------------------
-- Translate values from Workday to Oracle
--------------------------------------------------------------------------------

   -- Convert Date provided by Workday to Oracle format
   UPDATE haemo.XXHA_WD_EMPLOYEE_CREATE xxha
      SET xxha.START_DATE = TO_DATE(xxha.START_DATE_CHAR,'YYYY-MM-DD');
   COMMIT;

   -- Initialize Value
   lc_Status := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE
   FOR dta0100 IN cur_0100 (lc_Status)
   LOOP

      -- Translate PERSON_TYPE_WD/TIME_TYPE_WD to PERSON_TYPE/ASSIGNMENT_CATEGORY
      l_ATTRIBUTE_ORACLE1 := NULL;
      l_ATTRIBUTE_ORACLE2 := NULL;
      BEGIN
           OPEN cur_0110('PERSON_ASSIGNMENT', dta0100.PERSON_TYPE_WD, dta0100.TIME_TYPE_WD);
          FETCH cur_0110 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
             IF cur_0110%NOTFOUND THEN
                l_STATUS_MESSAGE := NULL;
                SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
                UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Person Type (Worker Type)/Time Type: ' || dta0100.PERSON_TYPE_WD || '/' || dta0100.TIME_TYPE_WD || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ')
                  , XXHA.STATUS = 'FAIL'
                WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
             END IF;
             IF cur_0110%FOUND THEN
                UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                SET XXHA.PERSON_TYPE         = l_ATTRIBUTE_ORACLE1
                  , XXHA.ASSIGNMENT_CATEGORY = l_ATTRIBUTE_ORACLE2
                WHERE XXHA.WD_RECORD_ID      = dta0100.WD_RECORD_ID;
             END IF;
          CLOSE cur_0110;
      END;

      -- Translate Workday value in LOCATION to Oracle Value
      l_ATTRIBUTE_ORACLE1 := NULL;
      l_ATTRIBUTE_ORACLE2 := NULL;
      BEGIN
           OPEN cur_0110('LOCATION', dta0100.LOCATION, NULL);
          FETCH cur_0110 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
             IF cur_0110%NOTFOUND THEN
                l_STATUS_MESSAGE := NULL;
                SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
                UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Location: ' || dta0100.LOCATION || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ')
                  , XXHA.STATUS = 'FAIL'
                WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
             END IF;
             IF cur_0110%FOUND THEN
                UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                SET XXHA.LOCATION_ID    = TO_NUMBER(l_ATTRIBUTE_ORACLE1)
                WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
             END IF;
          CLOSE cur_0110;
      END;

   COMMIT;

   END LOOP;

--------------------------------------------------------------------------------
-- Edit the data
--------------------------------------------------------------------------------

   -- Initialize Value
   lc_Status := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE
   FOR dta0100 IN cur_0100 (lc_Status)
   LOOP

      -- Initialize Values
      l_BUSINESS_GROUP       := NULL;
      l_BUSINESS_GROUP_ID    := NULL;
      l_ORGANIZATION_COUNTRY := NULL;
      l_LOCATION_ID          := NULL;

      -- Derive Business Group, Country and Location from Oracle using location
      BEGIN
           OPEN cur_0200(dta0100.LOCATION_ID);
          FETCH cur_0200 INTO l_BUSINESS_GROUP, l_BUSINESS_GROUP_ID, l_ORGANIZATION_COUNTRY, l_LOCATION_ID;
             IF cur_0200%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
            SET XXHA.BUSINESS_GROUP       = l_BUSINESS_GROUP
              , XXHA.BUSINESS_GROUP_ID    = l_BUSINESS_GROUP_ID
              , XXHA.ORGANIZATION_COUNTRY = l_ORGANIZATION_COUNTRY
              --, XXHA.LOCATION_ID          = l_LOCATION_ID
          WHERE XXHA.WD_RECORD_ID         = dta0100.WD_RECORD_ID;
            END IF;
          CLOSE cur_0200;
      END;

      -- Derive Person Type from Oracle
      l_person_type_id := NULL;
      BEGIN
           OPEN cur_0300(dta0100.PERSON_TYPE, l_BUSINESS_GROUP_ID);
          FETCH cur_0300 INTO l_person_type_id;
             IF cur_0300%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
            SET XXHA.PERSON_TYPE_ID = l_person_type_id
          WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
            END IF;
          CLOSE cur_0300;
      END;

      -- Derive Assignment Category Code from Oracle
      l_assignment_category_code := NULL;
      BEGIN
           OPEN cur_0420(dta0100.ASSIGNMENT_CATEGORY);
          FETCH cur_0420 INTO l_assignment_category_code;
             IF cur_0420%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
            SET XXHA.ASSIGNMENT_CATEGORY_CODE = l_assignment_category_code
          WHERE XXHA.WD_RECORD_ID             = dta0100.WD_RECORD_ID;
            END IF;
          CLOSE cur_0420;
      END;

      -- Derive Manager Name from Oracle
      l_sup_full_name := NULL;
      BEGIN
           OPEN cur_0400(dta0100.SUP_PERSON_ID);
          FETCH cur_0400 INTO l_sup_full_name;
             IF cur_0400%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
            SET XXHA.SUP_FULL_NAME = l_sup_full_name
          WHERE XXHA.WD_RECORD_ID  = dta0100.WD_RECORD_ID;
            END IF;
          CLOSE cur_0400;
      END;

   COMMIT;

   END LOOP;

--------------------------------------------------------------------------------
-- Flag records in error
--------------------------------------------------------------------------------

   lc_Status := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE
   FOR dta0100 IN cur_0100 (lc_Status)
   LOOP

      -- Initialize Values
      l_ERROR_MSG := NULL;

      -- Ensure Employee Number does not already exist in Oracle
      l_sup_full_name := NULL;
      BEGIN
           OPEN cur_0410(dta0100.EMPLOYEE_NUMBER);
          FETCH cur_0410 INTO l_sup_full_name;
             IF cur_0410%FOUND THEN
                l_ERROR_MSG := l_ERROR_MSG || ('Employee Number: ' || dta0100.EMPLOYEE_NUMBER || ' - Already exists in Oracle ' || ' / ');
            END IF;
          CLOSE cur_0410;
      END;

      -- Check First Name
      IF dta0100.FIRST_NAME IS NULL THEN
         l_ERROR_MSG := l_ERROR_MSG || ('First Name cannot be NULL.' || ' / ');
      END IF;

      -- Check Last Name
      IF dta0100.LAST_NAME IS NULL THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Last Name cannot be NULL.' || ' / ');
      END IF;

      -- Check Start_Date
      IF dta0100.START_DATE IS NULL THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Start Date cannot be NULL.' || ' / ');
      END IF;

      -- Check Business Group, Country and Location for NULL Values
      IF (dta0100.BUSINESS_GROUP IS NULL) OR (dta0100.BUSINESS_GROUP_ID IS NULL) OR (dta0100.ORGANIZATION_COUNTRY IS NULL) OR (dta0100.LOCATION_ID IS NULL) THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Invalid Location: ' || dta0100.Location || ' / ');
      END IF;

      -- Check Person Type
      IF (dta0100.PERSON_TYPE_ID IS NULL) THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Invalid Person Type: ' || dta0100.PERSON_TYPE || ' / ');
      END IF;

      -- Check Assignment Category
      IF (dta0100.ASSIGNMENT_CATEGORY_CODE IS NULL) THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Invalid Asignment Category: ' || dta0100.ASSIGNMENT_CATEGORY || ' / ');
      END IF;

      -- Check Supervisor
      IF (dta0100.SUP_FULL_NAME IS NULL) THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Invalid Supervisor ID: ' || dta0100.SUP_PERSON_ID || ' / ');
      END IF;

      -- Ensure that Supervisor is an Employee
      IF SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE), dta0100.SUP_PERSON_ID)),1,8) NOT IN ('EMPLOYEE','HAE CONT') THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Supervisor: ' || dta0100.SUP_FULL_NAME || ' needs to be an employee.  Oracle Person Type: ' || (HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE), dta0100.SUP_PERSON_ID)) || '.' || ' / ');
      END IF;

      -- Check Location exists in XXHA_WD_EMPLOYEE_MAPPPING (Mapping table)
      BEGIN
           OPEN cur_0500(dta0100.LOCATION_ID);
          FETCH cur_0500 INTO   lc_BUSINESS_GROUP, lc_BUSINESS_GROUP_ID, lc_LOCATION, lc_LOCATION_ID, lc_SEX, lc_DATE_OF_BIRTH, lc_ORGANIZATION_ID, lc_ORGANIZATION_NAME
                              , lc_ORGANIZATION_COUNTRY, lc_JOB_ID, lc_JOB_FAMILY, lc_JOB_NAME, lc_JOB_DEFINITION_ID,lc_JOB_GRADE_ID, lc_JOB_GRADE
                              , lc_PAYROLL_ID, lc_PAYROLL_NAME, lc_SET_OF_BOOKS_ID, lc_LEDGER
                              , lc_PAY_BASIS_ID, lc_SALARY_PAY_BASIS, lc_HOURLY_SALARIED_CODE, lc_HOURLY_SALARIED_MEANING, lc_SOFT_CODING_KEYFLEX_ID, lc_SOFT_CODING_KEYFLEX_MEANING
                              , lc_CODE_COMBINATION_ID, lc_EXPENSE_ACCOUNT, lc_NATIONALITY, lc_CORRESPONDENCE_LANGUAGE, lc_ATTRIBUTE_CATEGORY, lc_PER_INFORMATION_CATEGORY
                              , lc_PER_INFORMATION1, lc_PER_INFORMATION2, lc_PER_INFORMATION3, lc_PER_INFORMATION4, lc_PER_INFORMATION5, lc_PER_INFORMATION6, lc_PER_INFORMATION7
                              , lc_PER_INFORMATION8, lc_PER_INFORMATION9, lc_PER_INFORMATION10,lc_PER_INFORMATION18, lc_PER_INFORMATION19
                              , lc_ASS_ATTRIBUTE_CATEGORY, lc_ASS_ATTRIBUTE1, lc_ASS_ATTRIBUTE7, lc_ASS_ATTRIBUTE8, lc_EMPLOYEE_CATEGORY, lc_SEGMENT8, lc_ESTABLISHMENT_ID;
             IF cur_0500%NOTFOUND THEN
                l_ERROR_MSG := l_ERROR_MSG || ('Location does not exist in Mapping Table (XXHA_WD_EMPLOYEE_MAPPPING): ' || dta0100.LOCATION);
             END IF;
          CLOSE cur_0500;
      END;

      -- Perform update to HAEMO.XXHA_WD_EMPLOYEE_CREATE if Errors were discovered
      IF l_ERROR_MSG IS NOT NULL THEN
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_ERROR_MSG || ' / ')
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
         COMMIT;
      END IF;

   END LOOP;

   COMMIT;

   -- SET XXHA.STATUS for Errors
   UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
      SET XXHA.STATUS = 'FAIL'
    WHERE LENGTH(XXHA.STATUS_MESSAGE) > 0;

   -- SET XXHA.STATUS for No Errors
   UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
      SET XXHA.STATUS = 'PASS'
    WHERE XXHA.STATUS_MESSAGE IS NULL;

--------------------------------------------------------------------------------
-- Create Employee Records but only for those records that passed the edits
--------------------------------------------------------------------------------

   lc_Status := 'PASS';

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE
   FOR dta0100 IN cur_0100 (lc_Status)
   LOOP

      -- Initialize Values
      lc_BUSINESS_GROUP                     := NULL;
      lc_BUSINESS_GROUP_ID                  := NULL;
      lc_LOCATION                           := NULL;
      lc_LOCATION_ID                        := NULL;
      lc_SEX                                := NULL;
      lc_DATE_OF_BIRTH                      := NULL;
      lc_ORGANIZATION_ID                    := NULL;
      lc_ORGANIZATION_NAME                  := NULL;
      lc_ORGANIZATION_COUNTRY               := NULL;
      lc_JOB_ID                             := NULL;
      lc_JOB_FAMILY                         := NULL;
      lc_JOB_NAME                           := NULL;
      lc_JOB_DEFINITION_ID                  := NULL;
      lc_JOB_GRADE_ID                       := NULL;
      lc_JOB_GRADE                          := NULL;
      lc_PAYROLL_ID                         := NULL;
      lc_PAYROLL_NAME                       := NULL;
      lc_SET_OF_BOOKS_ID                    := NULL;
      lc_LEDGER                             := NULL;
      lc_PAY_BASIS_ID                       := NULL;
      lc_SALARY_PAY_BASIS                   := NULL;
      lc_HOURLY_SALARIED_CODE               := NULL;
      lc_HOURLY_SALARIED_MEANING            := NULL;
      lc_SOFT_CODING_KEYFLEX_ID             := NULL;
      lc_SOFT_CODING_KEYFLEX_MEANING        := NULL;
      lc_NATIONALITY                        := NULL;
      lc_CORRESPONDENCE_LANGUAGE            := NULL;
      lc_ATTRIBUTE_CATEGORY                 := NULL;
      lc_PER_INFORMATION_CATEGORY           := NULL;
      lc_PER_INFORMATION1                   := NULL;
      lc_PER_INFORMATION2                   := NULL;
      lc_PER_INFORMATION3                   := NULL;
      lc_PER_INFORMATION4                   := NULL;
      lc_PER_INFORMATION5                   := NULL;
      lc_PER_INFORMATION6                   := NULL;
      lc_PER_INFORMATION7                   := NULL;
      lc_PER_INFORMATION8                   := NULL;
      lc_PER_INFORMATION9                   := NULL;
      lc_PER_INFORMATION10                  := NULL;
      lc_PER_INFORMATION18                  := NULL;
      lc_PER_INFORMATION19                  := NULL;
      lc_ASS_ATTRIBUTE_CATEGORY             := NULL;
      lc_ASS_ATTRIBUTE1                     := NULL;
      lc_ASS_ATTRIBUTE7                     := NULL;
      lc_ASS_ATTRIBUTE8                     := NULL;
      lc_EMPLOYEE_CATEGORY                  := NULL;
      lc_SEGMENT8                           := NULL;
      lc_ESTABLISHMENT_ID                   := NULL;
      l_Status                              := NULL;

      -- Retrieve Defaults from XXHA_WD_EMPLOYEE_MAPPPING (Mapping table)
      BEGIN
           OPEN cur_0500(dta0100.LOCATION);
          FETCH cur_0500 INTO   lc_BUSINESS_GROUP, lc_BUSINESS_GROUP_ID, lc_LOCATION, lc_LOCATION_ID, lc_SEX, lc_DATE_OF_BIRTH, lc_ORGANIZATION_ID, lc_ORGANIZATION_NAME
                              , lc_ORGANIZATION_COUNTRY, lc_JOB_ID, lc_JOB_FAMILY, lc_JOB_NAME, lc_JOB_DEFINITION_ID, lc_JOB_GRADE_ID, lc_JOB_GRADE
                              , lc_PAYROLL_ID, lc_PAYROLL_NAME, lc_SET_OF_BOOKS_ID, lc_LEDGER
                              , lc_PAY_BASIS_ID, lc_SALARY_PAY_BASIS, lc_HOURLY_SALARIED_CODE, lc_HOURLY_SALARIED_MEANING, lc_SOFT_CODING_KEYFLEX_ID, lc_SOFT_CODING_KEYFLEX_MEANING
                              , lc_CODE_COMBINATION_ID, lc_EXPENSE_ACCOUNT, lc_NATIONALITY, lc_CORRESPONDENCE_LANGUAGE, lc_ATTRIBUTE_CATEGORY, lc_PER_INFORMATION_CATEGORY
                              , lc_PER_INFORMATION1, lc_PER_INFORMATION2, lc_PER_INFORMATION3, lc_PER_INFORMATION4, lc_PER_INFORMATION5, lc_PER_INFORMATION6, lc_PER_INFORMATION7
                              , lc_PER_INFORMATION8, lc_PER_INFORMATION9, lc_PER_INFORMATION10,lc_PER_INFORMATION18, lc_PER_INFORMATION19
                              , lc_ASS_ATTRIBUTE_CATEGORY, lc_ASS_ATTRIBUTE1, lc_ASS_ATTRIBUTE7, lc_ASS_ATTRIBUTE8, lc_EMPLOYEE_CATEGORY, lc_SEGMENT8, lc_ESTABLISHMENT_ID;
          CLOSE cur_0500;
      END;

      -- Determine if Haemo Email is required
      IF dta0100.EMAIL_ADDRESS IS NULL THEN 
         lc_haemo_email_required := 'YES';
      ELSE
         lc_haemo_email_required := 'NO';
      END IF;

      -- Build National Identifier from Employee Number - National Identifier must be unique in Oracle
      lc_NATIONAL_IDENTIFIER := SUBSTR(LPAD(dta0100.EMPLOYEE_NUMBER , 9, '0'),1,3) || '-' || SUBSTR(LPAD(dta0100.EMPLOYEE_NUMBER , 9, '0'),4,2) || '-' || SUBSTR(LPAD(dta0100.EMPLOYEE_NUMBER , 9, '0'),6,4);

      -- IF PERSON_TYPE = 'HAE Contingent Worker' and ASSIGNMENT_CATEGORY is 'Consultant','Ext Support Supplier-Fractional' or 'External Support Supplier'
      -- lc_JOB_ID, lc_JOB_FAMILY, lc_JOB_NAME and lc_JOB_DEFINITION_ID are not set to NULL as they are Req'd for 'Consultant','External Support Supplier Staff','Ext Support Supplier-Fractional' and 'Temporary Worker'
      IF dta0100.PERSON_TYPE = 'HAE Contingent Worker' THEN
         IF dta0100.ASSIGNMENT_CATEGORY IN ('Consultant','Ext Support Supplier-Fractional','External Support Supplier') THEN
            lc_DATE_OF_BIRTH            := NULL;
            lc_JOB_GRADE_ID             := NULL;
            lc_JOB_GRADE                := NULL;
            lc_PAYROLL_ID               := NULL;
            lc_PAYROLL_NAME             := NULL;
            lc_SET_OF_BOOKS_ID          := NULL;
            lc_LEDGER                   := NULL;
            lc_PAY_BASIS_ID             := NULL;
            lc_SALARY_PAY_BASIS         := NULL;
            lc_HOURLY_SALARIED_CODE     := NULL;
            lc_HOURLY_SALARIED_MEANING  := NULL;
            lc_CODE_COMBINATION_ID      := NULL;
            lc_EXPENSE_ACCOUNT          := NULL;
         END IF;
      END IF;

      -- IF PERSON_TYPE = 'HAE Contingent Worker' and ASSIGNMENT_CATEGORY is 'Temporary Worker'
      -- lc_JOB_ID, lc_JOB_FAMILY, lc_JOB_NAME, lc_JOB_DEFINITION_ID, lc_SET_OF_BOOKS_ID, lc_LEDGER, lc_HOURLY_SALARIED_CODE, lc_HOURLY_SALARIED_MEANING, lc_CODE_COMBINATION_ID and lc_EXPENSE_ACCOUNT 
      -- are not set to NULL as they are Req'd for 'Temporary Worker'
      IF dta0100.PERSON_TYPE = 'HAE Contingent Worker' THEN
         IF dta0100.ASSIGNMENT_CATEGORY = 'Temporary Worker' THEN
            lc_DATE_OF_BIRTH            := NULL;
            lc_JOB_GRADE_ID             := NULL;
            lc_JOB_GRADE                := NULL;
            lc_PAYROLL_ID               := NULL;
            lc_PAYROLL_NAME             := NULL;
            lc_PAY_BASIS_ID             := NULL;
            lc_SALARY_PAY_BASIS         := NULL;
         END IF;
      END IF;

      -- National Identifier cannot be NULL for China, Netherlands or Sweden but other BG's allow for it
      IF dta0100.PERSON_TYPE = 'HAE Contingent Worker' THEN
         IF dta0100.ASSIGNMENT_CATEGORY = 'Temporary Worker' THEN
            IF dta0100.BUSINESS_GROUP NOT IN ('BG_CN','BG_NL','BG_SE') THEN
               lc_NATIONAL_IDENTIFIER := NULL;
            END IF;
         END IF;
      END IF;

      -- US Employees
      IF lc_organization_country = 'US' THEN

         BEGIN

            -- Initialize Value 
            l_error_message := NULL;
            l_person_id     := NULL;

            hr_employee_api.create_us_employee
            ( 
               p_validate                   => FALSE
             , p_hire_date                  => dta0100.START_DATE
             , p_business_group_id          => lc_BUSINESS_GROUP_ID
             , p_last_name                  => dta0100.LAST_NAME
             , p_first_name                 => dta0100.FIRST_NAME
             , p_sex                        => lc_SEX
             , p_person_type_id             => dta0100.PERSON_TYPE_ID
             , p_date_of_birth              => lc_DATE_OF_BIRTH
             , p_employee_number            => dta0100.EMPLOYEE_NUMBER
             , p_known_as                   => dta0100.KNOWN_AS
             , p_middle_names               => NULL
             , p_ss_number                  => lc_NATIONAL_IDENTIFIER           -- Does not allow for duplicates! SS# is 9 digits
             , p_vets100A                   => NULL
             , p_attribute15                => NULL
             , p_ethnic_origin              => NULL
             , p_attribute13                => lc_haemo_email_required
             , p_attribute17                => dta0100.EMAIL_ADDRESS
             -- Output data elements
             , p_person_id                  => l_person_id
             , p_assignment_id              => l_assignment_id
             , p_per_object_version_number  => l_per_object_version_number
             , p_asg_object_version_number  => l_asg_object_version_number
             , p_per_effective_start_date   => l_per_effective_start_date
             , p_per_effective_end_date     => l_per_effective_end_date
             , p_full_name                  => l_full_name
             , p_per_comment_id             => l_per_comment_id
             , p_assignment_sequence        => l_assignment_sequence
             , p_assignment_number          => l_assignment_number
             , p_name_combination_warning   => l_name_combination_warning
             , p_assign_payroll_warning     => l_assign_payroll_warning
             , p_orig_hire_warning          => l_orig_hire_warning
            );
         EXCEPTION
              WHEN OTHERS THEN
                   l_error_message := 'API Error: hr_employee_api.create_us_employee: ' || SQLERRM;
              ROLLBACK;
         END;

         -- Check for errors
         IF l_person_id IS NOT NULL THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_error_message);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_error_message || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;

         -- Update Person_ID in HAEMO.XXHA_WD_EMPLOYEE_CREATE
         IF l_person_id IS NOT NULL THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
               SET XXHA.PERSON_ID    = l_person_id
             WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;

      END IF; -- IF lc_organization_country = 'US' 

      -- Non-US Employees
      IF lc_organization_country <> 'US' THEN

         BEGIN

            -- Initialize Value 
            l_error_message := NULL;
            l_person_id     := NULL;

            hr_employee_api.create_employee
            ( 
               p_hire_date                  => dta0100.START_DATE
             , p_employee_number            => dta0100.EMPLOYEE_NUMBER
             , p_business_group_id          => lc_BUSINESS_GROUP_ID
             , p_last_name                  => dta0100.LAST_NAME
             , p_first_name                 => dta0100.FIRST_NAME
             , p_middle_names               => NULL
             , p_sex                        => lc_SEX
             , p_national_identifier        => lc_NATIONAL_IDENTIFIER           -- Does not allow for duplicates! SS# is 9 digits
             , p_date_of_birth              => lc_DATE_OF_BIRTH
             , p_known_as                   => dta0100.KNOWN_AS
             , p_person_type_id             => dta0100.PERSON_TYPE_ID
             , p_attribute15                => NULL
             , p_attribute_category         => lc_ATTRIBUTE_CATEGORY            -- req'd for TW, SE, MY, CH, BE
             , p_attribute13                => lc_haemo_email_required
             , p_attribute17                => dta0100.EMAIL_ADDRESS
             , p_nationality                => lc_NATIONALITY                   -- req'd for TW, SE, NL, MY, MX, IT
             , p_correspondence_language    => lc_CORRESPONDENCE_LANGUAGE       -- req'd for FR, DE, CN, BE
             , p_per_Information_Category   => lc_PER_INFORMATION_CATEGORY      -- req'd for SE, NL, MX, KR, JP, IT, IN, HK, GB, FR, DE, CZ, CN
             , p_per_Information1           => lc_PER_INFORMATION1              -- req'd for NL
             , p_per_Information4           => lc_PER_INFORMATION4              -- req'd for NL (Name formatting 'FORMAT8'), CN (HUKOU_TYPE)
             , p_per_Information5           => lc_PER_INFORMATION5              -- req'd for CN (Hukou Location)
             , p_per_Information6           => lc_PER_INFORMATION6              -- req'd for IN (Ex-Serviceman), HK (Hong Kong Name)
             , p_per_Information7           => lc_PER_INFORMATION7              -- req'd for IN (Residential Status (RO = Resident and ordinarily resident in India))
             , p_per_Information8           => lc_PER_INFORMATION8              -- req'd for CN (EXPATRIATE_INDICATOR)
             , p_per_Information18          => lc_PER_INFORMATION18             -- req'd for JP (Kanji_Last)
             , p_per_Information19          => lc_PER_INFORMATION19             -- req'd for JP (Kanji_First)
             -- Output data elements
             , p_person_id                  => l_person_id
             , p_assignment_id              => l_assignment_id
             , p_per_object_version_number  => l_per_object_version_number
             , p_asg_object_version_number  => l_asg_object_version_number
             , p_per_effective_start_date   => l_per_effective_start_date
             , p_per_effective_end_date     => l_per_effective_end_date
             , p_full_name                  => l_full_name
             , p_per_comment_id             => l_per_comment_id
             , p_assignment_sequence        => l_assignment_sequence
             , p_assignment_number          => l_assignment_number
             , p_name_combination_warning   => l_name_combination_warning
             , p_assign_payroll_warning     => l_assign_payroll_warning
             , p_orig_hire_warning          => l_orig_hire_warning
            );
         EXCEPTION
              WHEN OTHERS THEN
                   l_error_message := 'API Error: hr_employee_api.create_employee: ' || SQLERRM;
              ROLLBACK;
         END;

         -- Check for errors
         IF l_person_id IS NOT NULL THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_error_message);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE|| (l_error_message || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;

         -- Update Person_ID in HAEMO.XXHA_WD_EMPLOYEE_CREATE
         IF l_person_id IS NOT NULL THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
               SET XXHA.PERSON_ID    = l_person_id
             WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;

      END IF; -- IF lc_organization_country <> 'US' 

      -- Continue on but only API hr_employee_api.create_us_employee/hr_employee_api.create_employee did not fail
      IF l_person_id IS NOT NULL THEN

         -- Inialize Values
         l_assignment_id            := NULL;
         l_assignment_ovn           := NULL;
         l_asg_effective_start_date := NULL;
         l_business_group_id        := NULL;

         -- Retrieve Assignment Information
         BEGIN
              OPEN cur_0600(l_person_id, dta0100.START_DATE);
             FETCH cur_0600 INTO l_assignment_id, l_assignment_ovn, l_asg_effective_start_date, l_business_group_id;
                IF cur_0600%NOTFOUND THEN
                   l_STATUS_MESSAGE := NULL;
                   SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
                   UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                   SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Error finding assignment information for person id: ' || l_person_id || ' / ')
                     , XXHA.STATUS         = 'FAIL'        
                   WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
                   COMMIT;
               END IF;
             CLOSE cur_0600;
         END;

         -- Continue on but only if l_assignment_ovn was returned
         IF l_assignment_ovn IS NOT NULL THEN

            -- Initialize Values
            l_segment1                      := '';
            l_segment2                      := '';
            l_segment3                      := '';
            l_segment4                      := '';
            l_segment20                     := '';
            l_segment21                     := '';
            l_concatenated_segments         := NULL;
            l_soft_coding_keyflex_id        := NULL;
            l_comment_id                    := NULL;
            l_effective_start_date          := NULL;
            l_effective_end_date            := NULL;
            l_no_managers_warning           := FALSE;
            l_other_manager_warning         := FALSE;

            BEGIN

               -- Inialize Values
               l_Status        := NULL;
               l_error_message := NULL;

               -- Update Supervisor, GL Code, Set of Books, Hourly/Salaried, SOFT_CODING_KEYFLEX_ID and Employee Category
               hr_assignment_api.update_emp_asg
               ( 
                  p_validate                     => FALSE
                , p_effective_date               => l_asg_effective_start_date
                , p_datetrack_update_mode        => 'CORRECTION'
                , p_assignment_id                => l_assignment_id
                , p_object_version_number        => l_assignment_ovn
                , p_supervisor_id                => dta0100.SUP_PERSON_ID
                , p_default_code_comb_id         => lc_CODE_COMBINATION_ID
                , p_set_of_books_id              => lc_SET_OF_BOOKS_ID
                , p_hourly_salaried_code         => lc_HOURLY_SALARIED_CODE
                , p_ass_attribute_category       => lc_ASS_ATTRIBUTE_CATEGORY
                , p_ass_attribute1               => lc_ASS_ATTRIBUTE1
                , p_ass_attribute7               => lc_ASS_ATTRIBUTE7
                , p_ass_attribute8               => lc_ASS_ATTRIBUTE8
                , p_segment1                     => l_segment1
                , p_segment2                     => l_segment2
                , p_segment3                     => l_segment3
                , p_segment4                     => l_segment4
                , p_segment8                     => lc_SEGMENT8
                , p_segment20                    => l_segment20
                , p_segment21                    => l_segment21
                , p_concatenated_segments        => l_concatenated_segments
                , p_soft_coding_keyflex_id       => lc_SOFT_CODING_KEYFLEX_ID
                , p_comment_id                   => l_comment_id
                , p_effective_start_date         => l_effective_start_date
                , p_effective_end_date           => l_effective_end_date
                , p_no_managers_warning          => l_no_managers_warning
                , p_other_manager_warning        => l_other_manager_warning
                , p_employee_category            => lc_EMPLOYEE_CATEGORY
                , p_hourly_salaried_warning      => l_hourly_salaried_warning
                , p_cagr_concatenated_segments   => l_cagr_concatenated_segments
                , p_cagr_grade_def_id            => l_cagr_grade_def_id
               );
            EXCEPTION
                 WHEN OTHERS THEN
                      l_error_message := 'API Error: hr_assignment_api.update_emp_asg: ' || SQLERRM;
                      l_Status        := 'FAIL';
                 ROLLBACK;
            END;

            -- Check for errors
            IF NVL(l_Status,'PASS') = 'PASS' THEN
               COMMIT;
            ELSE
               FND_FILE.PUT_LINE(FND_FILE.LOG, l_error_message);
               l_STATUS_MESSAGE := NULL;
               SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                  SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_error_message || ' / ')
                    , XXHA.STATUS         = 'FAIL'
                WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
            END IF;

            -- Continue on but only if API hr_assignment_api.update_emp_asg did not fail
            IF l_person_id IS NOT NULL THEN

               -- Initialize Values
               io_people_group_id                := NULL;
               io_special_ceiling_step_id        := NULL;
               o_group_name                      := NULL;
               o_effective_start_date            := NULL;
               o_effective_end_date              := NULL;
               o_org_now_no_manager_warning      := FALSE;
               o_other_manager_warning           := FALSE;
               o_spp_delete_warning              := FALSE;
               o_entries_changed_warning         := NULL;
               o_tax_district_changed_warning    := FALSE;
               o_concatenated_segments           := NULL;
               o_gsp_post_process_warning        := NULL;
               io_soft_coding_keyflex_id         := NULL;
               l_asg_object_version_number       := NULL;

               -- Retrieve object_version_number for assignment_id
               BEGIN
                    OPEN cur_0700(l_assignment_id);
                   FETCH cur_0700 INTO l_asg_object_version_number;
                      IF cur_0700%NOTFOUND THEN
                         l_STATUS_MESSAGE := NULL;
                         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
                         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                         SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Error retrieving asg.object_version_number: ' || l_asg_object_version_number || ' / ')
                           , XXHA.STATUS         = 'FAIL'        
                         WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
                         COMMIT;
                     END IF;
                   CLOSE cur_0700;
               END;

               -- Continue on but only if l_asg_object_version_number was retrieved
               IF l_asg_object_version_number IS NOT NULL THEN

                  BEGIN

                     -- Inialize Values
                     l_Status        := NULL;
                     l_error_message := NULL;

                     -- Update JOB_GRADE_ID, JOB_ID, PAYROLL_ID, LOCATION_ID, ORGANIZATION_ID, PAY_BASIS_ID, ASSIGNMENT_LOOKUP_CODE,
                     -- ESTABLISHMENT_ID and SOFT_CODING_KEYFLEX_ID
                     hr_assignment_api.update_emp_asg_criteria
                     (
                        p_effective_date                =>  dta0100.START_DATE
                      , p_validate                      =>  FALSE
                      , p_datetrack_update_mode         =>  'CORRECTION'
                      , p_object_version_number         =>  l_asg_object_version_number
                      , p_assignment_id                 =>  l_assignment_id
                      , p_grade_id                      =>  lc_JOB_GRADE_ID
                      , p_job_id                        =>  lc_JOB_ID
                      , p_payroll_id                    =>  lc_PAYROLL_ID
                      , p_location_id                   =>  dta0100.LOCATION_ID
                      , p_organization_id               =>  lc_ORGANIZATION_ID
                      , p_pay_basis_id                  =>  lc_PAY_BASIS_ID
                      , p_employment_category           =>  dta0100.ASSIGNMENT_CATEGORY
                      , p_establishment_id              =>  lc_ESTABLISHMENT_ID
                      , p_people_group_id               =>  io_people_group_id
                      , p_soft_coding_keyflex_id        =>  lc_SOFT_CODING_KEYFLEX_ID
                      , p_special_ceiling_step_id       =>  io_special_ceiling_step_id
                      , p_group_name                    =>  o_group_name
                      , p_effective_start_date          =>  o_effective_start_date
                      , p_effective_end_date            =>  o_effective_end_date
                      , p_org_now_no_manager_warning    =>  o_org_now_no_manager_warning
                      , p_other_manager_warning         =>  o_other_manager_warning
                      , p_spp_delete_warning            =>  o_spp_delete_warning
                      , p_entries_changed_warning       =>  o_entries_changed_warning
                      , p_tax_district_changed_warning  =>  o_tax_district_changed_warning
                      , p_concatenated_segments         =>  o_concatenated_segments
                      , p_gsp_post_process_warning      =>  o_gsp_post_process_warning
                     );
                  EXCEPTION
                       WHEN OTHERS THEN
                            l_error_message := 'API Error: hr_assignment_api.update_emp_asg_criteria: ' || SQLERRM;
                            l_Status        := 'FAIL';
                       ROLLBACK;
                  END;

                  -- Determine if data error encountered
                  IF (o_org_now_no_manager_warning  = TRUE 
                  OR o_other_manager_warning        = TRUE
                  OR o_spp_delete_warning           = TRUE 
                  OR o_entries_changed_warning      <> 'N'
                  OR o_tax_district_changed_warning = TRUE 
                  OR o_gsp_post_process_warning     IS NOT NULL) THEN
                     l_error_message := 'API Error: hr_assignment_api.update_emp_asg_criteria: ' || SQLERRM;
                     l_Status        := 'FAIL';
                     ROLLBACK;
                  END IF;

                  -- Check for errors
                  IF NVL(l_Status,'PASS') = 'PASS' THEN
                     COMMIT;
                  ELSE
                     FND_FILE.PUT_LINE(FND_FILE.LOG, l_error_message);
                     l_STATUS_MESSAGE := NULL;
                     SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
                     UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
                        SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_error_message || ' / ')
                          , XXHA.STATUS         = 'FAIL'
                      WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
                  END IF;

               END IF; -- IF NVL(XXHA.STATUS, 'PASS') = 'FAIL'

            END IF; -- IF NVL(XXHA.STATUS, 'PASS') = 'FAIL'

         END IF; -- Continue on but only if l_assignment_ovn was returned

      COMMIT;

      END IF; -- IF l_person_id IS NOT NULL 

   END LOOP;

--------------------------------------------------------------------------------
-- Final processing
--------------------------------------------------------------------------------

   lc_Status := 'FAIL';

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE for only those records that failed edits/processing
   FOR dta0100 IN cur_0100 (lc_Status)
   LOOP

      -- Remove last ' / ' at end of STATUS_MESSAGE if populated and set PROCESS_TO_WD_STATUS to 'N'
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
         SET XXHA.STATUS_MESSAGE = SUBSTR(XXHA.STATUS_MESSAGE,1,(LENGTH(XXHA.STATUS_MESSAGE)-3))
           , XXHA.PROCESS_TO_WD_STATUS = 'N'
       WHERE LENGTH(XXHA.STATUS_MESSAGE) > 0
         AND XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;

   END LOOP;

   COMMIT;

   lc_Status := 'PASS';

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CREATE for only those records that passed edits/processing
   FOR dta0100 IN cur_0100 (lc_Status)
   LOOP

      -- Update PROCESS_TO_WD_STATUS
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
         SET XXHA.PROCESS_TO_WD_STATUS = 'Y'
       WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;

   END LOOP;

   COMMIT;

   -- Backup Processed Data
   XXHA_BACKUP_DATA(errbuf, errcode);

END;

END XXHA_PROCESS_DATA;


--------------------------------------------------------------------------------
PROCEDURE XXHA_BACKUP_DATA(
          errbuf                            OUT VARCHAR2
         ,errcode                           OUT VARCHAR2) AS

BEGIN

DECLARE              

   BEGIN

      -- Backup Data
      INSERT INTO HAEMO.XXHA_WD_EMPLOYEE_CREATE_BKP
      (
       PERSON_ID,USER_NAME,EMPLOYEE_NUMBER,FIRST_NAME,LAST_NAME,KNOWN_AS,PERSON_TYPE_WD,PERSON_TYPE,PERSON_TYPE_ID,TIME_TYPE_WD,ASSIGNMENT_CATEGORY,ASSIGNMENT_CATEGORY_CODE
      ,EMAIL_ADDRESS,SUP_PERSON_ID,SUP_FULL_NAME,START_DATE,START_DATE_CHAR,LOCATION_ID,LOCATION,PHONE_WORK,PHONE_MOBILE,BUSINESS_GROUP_ID,BUSINESS_GROUP
      ,ORGANIZATION_COUNTRY,CREATION_DATE,STATUS,STATUS_MESSAGE,PROCESS_TO_WD_STATUS,PROCESS_TO_WD_DATE,WD_RECORD_ID
      ) 
      SELECT
       PERSON_ID,USER_NAME,EMPLOYEE_NUMBER,FIRST_NAME,LAST_NAME,KNOWN_AS,PERSON_TYPE_WD,PERSON_TYPE,PERSON_TYPE_ID,TIME_TYPE_WD,ASSIGNMENT_CATEGORY,ASSIGNMENT_CATEGORY_CODE
      ,EMAIL_ADDRESS,SUP_PERSON_ID,SUP_FULL_NAME,START_DATE,START_DATE_CHAR,LOCATION_ID,LOCATION,PHONE_WORK,PHONE_MOBILE,BUSINESS_GROUP_ID,BUSINESS_GROUP
      ,ORGANIZATION_COUNTRY,CREATION_DATE,STATUS,STATUS_MESSAGE,PROCESS_TO_WD_STATUS,PROCESS_TO_WD_DATE,WD_RECORD_ID
      FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE
      -- Select records that were Processed by WebMethods ('C') or had an Error ('N')
      WHERE NVL(PROCESS_TO_WD_STATUS,'Z') IN ('N','C');
      COMMIT;

      -- Delete records that were Processed by WebMethods ('C') or had an Error ('N')
      DELETE FROM HAEMO.XXHA_WD_EMPLOYEE_CREATE XXHA
      WHERE NVL(PROCESS_TO_WD_STATUS,'Z') IN ('N','C');
      COMMIT;

   END;

END XXHA_BACKUP_DATA;


--------------------------------------------------------------------------------
PROCEDURE XXHA_CHECK_FOR_NON_NUMERIC(
          p_Value_In        IN  VARCHAR2
         ,p_Value_Out       OUT VARCHAR2) AS

BEGIN

DECLARE

   l_Value_In                               VARCHAR2(20) := NULL;                  

   BEGIN

      l_Value_In := LENGTH(TRIM(TRANSLATE(p_Value_In, ' 0123456789', ' ')));

      IF LENGTH(l_Value_In) <> LENGTH(p_Value_In) THEN
         p_Value_Out := 'Invalid';
      ELSE
         p_Value_Out := 'Valid';
      END IF;

   END;

END XXHA_CHECK_FOR_NON_NUMERIC;

END XXHA_WD_EMPLOYEE_CREATE_PKG;