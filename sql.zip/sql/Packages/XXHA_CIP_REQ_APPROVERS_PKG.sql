CREATE OR REPLACE PACKAGE XXHA_CIP_REQ_APPROVERS_PKG as
/*===========================================================================
  PACKAGE NAME:        XXHA_POWF_REQ_APPROVERS_PKG

  DESCRIPTION:        Package to add to the Requisition Approval List.

  CLIENT/SERVER:      SERVER

  LIBRARY NAME        NONE

  OWNER:              Amit Patel

  HISTORY:            09-March-09      Initial Creation


  ===========================================================================*/


PROCEDURE Add_Category_Approvers (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2);

PROCEDURE Add_Approver         (p_approval_list_header_id    IN     NUMBER
                                ,p_cip_approver_id           IN     NUMBER
                                ,p_sequence_num              IN     NUMBER
                                ,p_approver_type             IN     VARCHAR2
                                ,p_comments                  IN     VARCHAR2
                                ,resultout                   OUT    NUMBER);

PROCEDURE Delete_Approval_List_Lines  (
                                 p_approval_list_header_id    IN     NUMBER
                                ,p_sequence_num               IN     NUMBER
                                ,resultout                    OUT    NUMBER);

FUNCTION Approver_Is_Active     (p_approver_id              IN NUMBER)
                                RETURN BOOLEAN;

PROCEDURE cip_approval_require_check (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2);

PROCEDURE cip_enabled_check (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2);

PROCEDURE cip_category_check (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2);

PROCEDURE update_cip_status (x_errbuf          OUT VARCHAR2,
                             x_retcode         OUT VARCHAR2,
                             p_requisition_header_id IN NUMBER,
                             p_status          IN VARCHAR2);

PROCEDURE cip_supplier_check (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2);

END XXHA_CIP_REQ_APPROVERS_PKG;

/


CREATE OR REPLACE PACKAGE BODY XXHA_CIP_REQ_APPROVERS_PKG as

/*===========================================================================
  PACKAGE NAME:        XXHA_CIP_REQ_APPROVERS_PKG

  DESCRIPTION:        Package to add to the Requisition Approval List.

  CLIENT/SERVER:      SERVER

  LIBRARY NAME        NONE

  OWNER:              Amit Patel

  HISTORY:            09-March-09      Initial Creation
                      20-Aug-2009      Modified to make changes so that the CIP process is complete
            2011-06-27  Eric Rossing   Remove CIP Approver from CIP_PURC approval list

  ===========================================================================*/

/********START declaring cursor for Category based approvers ******************/


CURSOR c_CategoryReqLines(p_requisition_header_id NUMBER,
                          p_org_id NUMBER)
IS
SELECT   Distinct  mcat.category_id,
                   mcat.segment1
    from           mtl_categories_b            mcat,
                   po_requisition_lines_all    prl
    where          prl.category_id = mcat.category_id
    AND            prl.requisition_header_id =  p_requisition_header_id
    AND            prl.org_id = p_org_id;


CURSOR c_CategoryRange( p_org_id NUMBER, p_category_id NUMBER)
IS
SELECT      cr_a.attribute1 v_cip_responsibility_id,       ----  CIP Responsibility
            cr_a.attribute2 v_fyi_responsibility_id        ----  FYI Approver Responsibility
FROM        po_control_groups_all ag_a,
            po_control_rules      cr_a,
            mtl_categories_b      mcb
WHERE        cr_a.control_group_id = ag_a.control_group_id
AND          ag_a.enabled_flag = 'Y'
AND          ag_a.org_id = p_org_id
AND          cr_a.object_code = 'ITEM_CATEGORY_RANGE'
AND          cr_a.rule_type_code = 'INCLUDE'
AND          cr_a.attribute1 is not null
AND          TRUNC(NVL(cr_a.inactive_date,SYSDATE)) >= TRUNC(SYSDATE)
AND          mcb.segment1 BETWEEN cr_a.segment1_low AND cr_a.segment1_high
AND          mcb.category_id  = p_category_id;


/********END declaring cursor for CATEGORY based approvers ******************/


PROCEDURE Add_Category_Approvers (
                 itemtype    IN     VARCHAR2
                ,itemkey     IN     VARCHAR2
                ,actid       IN     NUMBER
                ,funcmode    IN     VARCHAR2
                ,resultout   OUT    VARCHAR2)

IS

  x_count                       NUMBER :=0;

  -- CIP Approver and FYI Approver variable

  v_cip_approver_id             NUMBER;
  v_fyi_approver_id             NUMBER;
  v_fyi_approver_name           VARCHAR2(200);
  v_cip_responsibility_id       NUMBER;
  v_fyi_responsibility_id       NUMBER;
  v_supervisor_id               NUMBER;

  v_sequence_num                NUMBER;
  v_is_Approver_listed          NUMBER;
  v_requisition_header_id       NUMBER;
  v_approval_list_header_id     NUMBER;
  v_org_id                      NUMBER;
  v_count                       NUMBER;
  x_progress                    VARCHAR2(1000);


  v_category_id                 NUMBER;
  v_segment1                    VARCHAR2(30);

  v_comments                    VARCHAR2(100);
  v_add_approver_result         NUMBER;
  v_preparer_id                 NUMBER;
  v_approver_type               VARCHAR2(20);
  v_delete_lines_result         NUMBER;


BEGIN
    IF (funcmode != wf_engine.eng_run)
    THEN
        resultout := wf_engine.eng_null;
        return;
    END IF;

    v_requisition_header_id := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                          ,itemkey  => itemkey
                                                          ,aname    => 'DOCUMENT_ID');

    v_approval_list_header_id := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                            ,itemkey  => itemkey
                                                            ,aname    => 'APPROVAL_LIST_HEADER_ID');

    v_org_id  := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                    ,itemkey  => itemkey
                                                    ,aname    => 'ORG_ID');

    v_preparer_id     := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                    ,itemkey  => itemkey
                                                    ,aname    => 'PREPARER_ID');

    -- Get Latest Approval List Header ID --
    SELECT MAX(approval_list_header_id)
    INTO   v_approval_list_header_id
    FROM   po_approval_list_headers
    WHERE  document_id = v_requisition_header_id
    AND    latest_revision = 'Y';

    OPEN c_CategoryReqLines(v_requisition_header_id, v_org_id);
    LOOP
    FETCH c_CategoryReqLines INTO      v_category_id,
                                       v_segment1;

      EXIT WHEN c_CategoryReqLines%NOTFOUND;

    x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:01 Category Cursor opened ';
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

     IF  v_segment1 = 'CIP_BUDG' THEN

        v_comments   := 'Fixed Asset Admin';

        OPEN c_CategoryRange(v_org_id, v_category_id);

        LOOP
            FETCH c_CategoryRange
             INTO v_cip_responsibility_id,
                  v_fyi_responsibility_id;

            EXIT WHEN c_CategoryRange%NOTFOUND;

            --Set Workflow Attribute

                BEGIN
                        x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:02 Get CIP FYI Approver';
                        PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                   select   user_name
                     INTO   v_fyi_approver_name
                     from   wf_user_roles
                    where   role_orig_system_id = v_fyi_responsibility_id
                      AND   user_orig_system = 'PER'
                      AND   parent_orig_system = 'FND_RESP'
                      AND   NVL(expiration_date, TRUNC(SYSDATE)) >= TRUNC(SYSDATE);

                    Wf_engine.SetItemAttrText(itemtype => itemtype
                                             ,itemkey  => itemkey
                                             ,aname    => 'XXHA_CIP_FYI_APPROVER_NAME'
                                             ,avalue    => v_fyi_approver_name);
                EXCEPTION
                        WHEN OTHERS THEN

                       x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers: No CIP FYI Approver';
                       PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                       resultout := wf_engine.eng_completed || ':' || 'FAILURE';
                       RAISE;

                END;

                --- Get Fixed Asset Admin Approver

                   BEGIN
                               x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:03 Get Fixed Admin Approver';
                               PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                 select   user_orig_system_id
                                   INTO   v_cip_approver_id
                                   from   wf_user_roles
                                  where   role_orig_system_id = v_cip_responsibility_id
                                    AND   user_orig_system = 'PER'
                                    AND   parent_orig_system = 'FND_RESP'
                                    AND   NVL(expiration_date, TRUNC(SYSDATE)) >= TRUNC(SYSDATE);

                   EXCEPTION

                             WHEN OTHERS THEN

                             x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers: No Fixed Admin Approver';
                             PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                             resultout := wf_engine.eng_completed || ':' || 'FAILURE';
                             RAISE;
                   END;

            IF  TRUE THEN

            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:03 Find Fixed Asset Admin Approver';
            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


                 SELECT     count(approver_id)
                   INTO     v_is_Approver_listed
                   FROM     po_approval_list_lines
                  WHERE     approval_list_header_id = v_approval_list_header_id;


                IF (v_is_Approver_listed = 0) THEN
                    x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers 04: Preparer can approve the requisition';
                    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:05 Begin to Add Supervisors and CIP Approvers to List';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                            v_approver_type := 'SYSTEM';

                             SELECT   NVL(MAX(sequence_num),0)
                               INTO   v_sequence_num
                               FROM   po_approval_list_lines
                              WHERE   approval_list_header_id = v_approval_list_header_id
                                AND   status is null;

                            IF v_sequence_num = 0 THEN

                             -- Build approval list if there is no system generated approval list, get supervisor id of preparer

                                    BEGIN
                                             select supervisor_id
                                               INTO v_supervisor_id
                                               from per_all_assignments_f
                                              where person_id = (SELECT person_id
                                                                   FROM per_all_people_f
                                                                  WHERE person_type_id IN
                                                                (SELECT person_type_id
                                                                   FROM per_person_types
                                                                  WHERE system_person_type = 'EMP')
                                                                    AND TRUNC(SYSDATE) BETWEEN effective_start_date
                                                                                           AND NVL(effective_end_date, SYSDATE+1)
                                                                    AND person_id = v_preparer_id)
                                                AND TRUNC(SYSDATE) BETWEEN effective_start_date
                                                                       AND NVL(effective_end_date, SYSDATE+1);
                                    EXCEPTION

                                            WHEN OTHERS THEN

                                            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers: No Supervisor Assigned to Preparer ';
                                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                            resultout := wf_engine.eng_completed || ':' || 'FAILURE';
                                            RAISE;
                                    END;

                                    FOR v_count IN 1..2 LOOP

                                            IF   v_count = 1 THEN

                                               IF v_supervisor_id IS NOT NULL THEN

                                                    Add_approver(v_approval_list_header_id,
                                                                 v_supervisor_id,
                                                                 v_sequence_num + 1,
                                                                 v_approver_type,
                                                                 NULL,
                                                                 v_add_approver_result);
                                               END IF;

                                             ELSE

                                                 IF v_cip_approver_id IS NOT NULL THEN

                                                        Add_approver(v_approval_list_header_id,
                                                                     v_cip_approver_id,
                                                                     v_sequence_num + 1,
                                                                     v_approver_type,
                                                                     v_comments,
                                                                     v_add_approver_result);
                                                 END IF;

                                            END IF;

                                            v_sequence_num := v_sequence_num + 1;

                                    END LOOP;
                            END IF;

                ELSE

                    BEGIN

                            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:05 Begin to Add Approvers to Current Approval List';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                            v_approver_type := 'SYSTEM';
                                                SELECT   NVL(MAX(sequence_num),0)
                                                  INTO   v_sequence_num
                                                  FROM   po_approval_list_lines
                                                 WHERE   approval_list_header_id = v_approval_list_header_id
                                                   AND   status is null;

                         --------- Start Addition at End of List-------------

                         IF v_cip_approver_id IS NOT NULL THEN

                              Add_approver(v_approval_list_header_id,
                                           v_cip_approver_id,
                                           v_sequence_num + 1,
                                           v_approver_type,
                                           v_comments,
                                           v_add_approver_result);

                        END IF;

                    END ;

                END IF;

            END if;

        END LOOP;

        CLOSE c_CategoryRange;

     ELSIF  v_segment1 = 'CIP_PURC' THEN

        v_comments   := 'CER Approval';

        OPEN c_CategoryRange(v_org_id, v_category_id);

        LOOP
            FETCH c_CategoryRange
             INTO v_cip_responsibility_id,
                  v_fyi_responsibility_id;

               EXIT WHEN c_CategoryRange%NOTFOUND;

               --- Get CIP Approver
-- 2011-06-27 - Eric Rossing - Remove CIP Approver from CIP_PURC approval list by 
--     setting the variable to NULL instead of retrieving anything. The rest of
--     the code will see the NULL value and not add that approver.
--                   BEGIN
--                              x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:03 Get CIP Approver';
--                               PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);
--
--                                 select   user_orig_system_id
--                                   INTO   v_cip_approver_id
--                                   from   wf_user_roles
--                                  where   role_orig_system_id = v_cip_responsibility_id
--                                    AND   user_orig_system = 'PER'
--                                    AND   parent_orig_system = 'FND_RESP'
--                                    AND   NVL(expiration_date, TRUNC(SYSDATE)) >= TRUNC(SYSDATE);
--
--                   EXCEPTION
--                           WHEN OTHERS THEN
--
--                             x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers: No CIP Approver';
--                             PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);
--
--                             resultout := wf_engine.eng_completed || ':' || 'FAILURE';
--                             RAISE;
--                   END;
            v_cip_approver_id := NULL;
-- end of 2011-06-27 change

            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:04 CIP Approver Found';
            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                 SELECT     count(approver_id)
                   INTO     v_is_Approver_listed
                   FROM     po_approval_list_lines
                  WHERE     approval_list_header_id = v_approval_list_header_id;

                 -- NO approver or only one approver, add CIP approver

                IF (v_is_Approver_listed <= 1) THEN
                    x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers 04: Preparer can approve the requisition';
                    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                    BEGIN
                            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:05 Begin to Add Approvers to List';
                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                            v_approver_type := 'SYSTEM';

                                                SELECT   NVL(MAX(sequence_num),0)
                                                  INTO   v_sequence_num
                                                  FROM   po_approval_list_lines
                                                 WHERE   approval_list_header_id = v_approval_list_header_id
                                                   AND   status is null;

                            IF v_sequence_num = 0 THEN

                             -- Build approval list if there is no system generated approval list, get supervisor id of preparer

                                    BEGIN

                                            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers: Get Supervisor of Preparer ';
                                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                             select supervisor_id
                                               INTO v_supervisor_id
                                               from per_all_assignments_f
                                              where person_id = (SELECT person_id
                                                                   FROM per_all_people_f
                                                                  WHERE person_type_id IN
                                                                (SELECT person_type_id
                                                                   FROM per_person_types
                                                                  WHERE system_person_type = 'EMP')
                                                                    AND TRUNC(SYSDATE) BETWEEN effective_start_date
                                                                                           AND NVL(effective_end_date, SYSDATE+1)
                                                                    AND person_id = v_preparer_id)
                                                AND TRUNC(SYSDATE) BETWEEN effective_start_date
                                                                       AND NVL(effective_end_date, SYSDATE+1);
                                    EXCEPTION

                                            WHEN OTHERS THEN

                                            x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers: No Supervisor Assigned to Preparer ';
                                            PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                                            resultout := wf_engine.eng_completed || ':' || 'FAILURE';
                                            RAISE;
                                    END;

                                    FOR v_count IN 1..2 LOOP

                                            IF   v_count = 1 THEN

                                               IF v_supervisor_id IS NOT NULL THEN

                                                    Add_approver(v_approval_list_header_id,
                                                                 v_supervisor_id,
                                                                 v_sequence_num + 1,
                                                                 v_approver_type,
                                                                 NULL,
                                                                 v_add_approver_result);
                                               END IF;

                                             ELSE

                                                 IF v_cip_approver_id IS NOT NULL THEN

                                                        Add_approver(v_approval_list_header_id,
                                                                     v_cip_approver_id,
                                                                     v_sequence_num + 1,
                                                                     v_approver_type,
                                                                     v_comments,
                                                                     v_add_approver_result);

                                                 END IF;

                                            END IF;

                                            v_sequence_num := v_sequence_num + 1;

                                    END LOOP;
                            ELSE

                            -- Just add CIP approver to approval list after supervisor

                                        IF v_cip_approver_id IS NOT NULL THEN

                                          Add_approver(v_approval_list_header_id,
                                                       v_cip_approver_id,
                                                       v_sequence_num + 1,
                                                       v_approver_type,
                                                       v_comments,
                                                       v_add_approver_result);

                                        END IF;
                            END IF;
                    END;

                ELSE
                   --  Delete approver above all the approver above approval level 1 and add CIP Approver

                       v_sequence_num := 2;

                        v_approver_type := 'SYSTEM';

                        delete_approval_list_lines(v_approval_list_header_id,
                                                   v_sequence_num,
                                                   v_delete_lines_result);

                        IF v_cip_approver_id IS NOT NULL THEN

select max(sequence_num)+1 into v_sequence_num from apps.po_approval_list_lines where approval_list_header_id = v_approval_list_header_id;

                              Add_approver(v_approval_list_header_id,
                                           v_cip_approver_id,
                                           v_sequence_num,
                                           v_approver_type,
                                           v_comments,
                                           v_add_approver_result);
                        END IF;

                END if;

         END LOOP;

        CLOSE c_CategoryRange;

     END IF;

  END LOOP;
    CLOSE c_CategoryReqLines;

                x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:Closed Cursor ';
                PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                resultout := wf_engine.eng_completed || ':' || 'SUCCESS';

EXCEPTION
    WHEN others THEN

      x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Category_Approvers:Unknown Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      IF c_CategoryRange%ISOPEN THEN
         close c_CategoryRange;
      END IF;

      IF c_CategoryReqLines%ISOPEN THEN
         close c_CategoryReqLines;
        END IF;

      Wf_Core.Context('XXHA_CIP_REQ_APPROVERS', 'Add_Category_Approvers',
                        itemtype, itemkey, x_progress);
      RAISE;

END Add_Category_Approvers;

   /***************************************************************************************/
PROCEDURE Add_Approver (     p_approval_list_header_id     IN  NUMBER
                             ,p_cip_approver_id            IN  NUMBER
                             ,p_sequence_num               IN  NUMBER
                             ,p_approver_type              IN  VARCHAR2
                             ,p_comments                   IN  VARCHAR2
                             ,resultout                    OUT NUMBER)

IS

    v_user_id                    NUMBER     := Fnd_Global.user_id;
    v_login_id                   NUMBER    := Fnd_Global.login_id;

    x_progress                    VARCHAR2(1000);
    --
    --
    PRAGMA AUTONOMOUS_TRANSACTION;
    --
    --
BEGIN
    --
    --
    INSERT INTO po_approval_list_lines (
         approval_list_header_id
        ,approval_list_line_id
        ,next_element_id
        ,approver_id
        ,sequence_num
        ,notification_id
        ,notification_role
        ,responder_id
        ,forward_to_id
        ,mandatory_flag
        ,requires_reapproval_flag
        ,approver_type
        ,status
        ,response_date
        ,comments
        ,created_by
        ,creation_date
        ,last_update_login
        ,last_updated_by
        ,last_update_date
        )
    VALUES
    (    p_approval_list_header_id
        ,po_approval_list_lines_s.NEXTVAL
        ,NULL
        ,p_cip_approver_id
        ,p_sequence_num
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,'Y'
        ,'N'
        ,p_approver_type -- 'SYSTEM'
/*        Changed to variable in the case that a custom approver at the
        Beginning of the List modifies the requisition:  This action
        will cause the list to rebuild based on the first 'SYSTEM' approver
        which was resulting in an incorrect list
*/
        ,NULL
        ,NULL
        ,p_comments
        ,v_user_id
        ,SYSDATE
        ,v_login_id
        ,v_user_id
        ,SYSDATE
        );

    resultout := 0;

    COMMIT;
    RETURN;
    --
    --
EXCEPTION
    WHEN OTHERS THEN
		      x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Approvers: While Inserting Approver'||SUBSTR(SQLERRM, 1, 200);
      		--PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

    			resultout := -1;

      		--Wf_Core.Context('XXHA_CIP_REQ_APPROVERS', 'Add Approver',
              --  				itemtype, itemkey, x_progress);
    			RAISE;
END ADD_APPROVER;

   /***************************************************************************************/

----------------------------------------------------------------------------------
--  DELETE_APPROVAL_LIST_LINES call to delete the approver above supervisor   --
----------------------------------------------------------------------------------

PROCEDURE Delete_Approval_List_Lines ( p_approval_list_header_id    IN    NUMBER
                                      ,p_sequence_num               IN     NUMBER
                                      ,resultout                    OUT    NUMBER)

IS

    x_progress                    VARCHAR2(1000);

    PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN

            DELETE  po_approval_list_lines
             WHERE  approval_list_header_id = p_approval_list_header_id
               AND  sequence_num >= p_sequence_num
               AND  approver_type = 'SYSTEM';

            resultout := 0;

    COMMIT;
    RETURN;

EXCEPTION
    WHEN OTHERS THEN
    			x_progress := 'XXHA_CIP_REQ_APPROVERS.Add_Approvers: While Deleting Approver'||SUBSTR(SQLERRM, 1, 200);
      	--	PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

    			resultout := -1;

      	--	Wf_Core.Context('XXHA_CIP_REQ_APPROVERS', 'Add Approver',
          --      				itemtype, itemkey, x_progress);
    			RAISE;
END Delete_Approval_List_Lines;

   /***************************************************************************************/

FUNCTION Approver_Is_Active (p_approver_id      IN NUMBER)
                               RETURN BOOLEAN IS

  l_flag VARCHAR2(1);

BEGIN

SELECT 'Y'
  INTO l_flag
  FROM per_all_people_f
 WHERE person_type_id IN
        (SELECT person_type_id
          FROM per_person_types
         WHERE system_person_type = 'EMP')
   AND trunc(sysdate) BETWEEN effective_start_date AND nvl(effective_end_date, sysdate+1)
   AND person_id = p_approver_id;

IF l_flag = 'Y' THEN
  RETURN TRUE;
END IF;

EXCEPTION
  WHEN OTHERS THEN
    RETURN FALSE;

END Approver_Is_Active;

/***************************************************************************************/

PROCEDURE cip_approval_require_check (itemtype    IN     VARCHAR2
                                     ,itemkey     IN     VARCHAR2
                                     ,actid       IN     NUMBER
                                     ,funcmode    IN     VARCHAR2
                                     ,resultout   OUT    VARCHAR2)
IS


  v_requisition_header_id        NUMBER;
  v_preparer_id                  NUMBER;
  v_approval_list_header_id      NUMBER;
  v_org_id                       NUMBER;

  v_cip_approval_req            VARCHAR2(5);
  v_cip_cer_number              VARCHAR2(100);

  v_category_id                 NUMBER;
  v_segment1                    VARCHAR2(30);

   x_progress                   VARCHAR2(1000);

BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

   v_requisition_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                             itemkey  => itemkey,
                                                             aname    => 'DOCUMENT_ID');

   v_approval_list_header_id := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                             itemkey  => itemkey,
                                                             aname    => 'APPROVAL_LIST_HEADER_ID');

    v_preparer_id               := Wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                               ,itemkey  => itemkey
                                                               ,aname    => 'PREPARER_ID');

     v_org_id                   := wf_engine.GetItemAttrNumber(
                                                            itemtype => itemtype
                                                            ,itemkey  => itemkey
                                                            ,aname    => 'ORG_ID');


           Select   attribute1
             INTO   v_cip_cer_number
             FROM   po_requisition_headers_all
            WHERE   requisition_header_id = v_requisition_header_id
              AND   org_id = v_org_id;


    OPEN c_CategoryReqLines(v_requisition_header_id, v_org_id);
    LOOP
    FETCH c_CategoryReqLines INTO      v_category_id,
                                       v_segment1;

      EXIT WHEN c_CategoryReqLines%NOTFOUND;


    x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_approval_required:01 Category Cursor opened ';
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


             IF  v_segment1 = 'CIP_PURC' or (v_segment1 =  'CIP_BUDG' and v_cip_cer_number IS NOT NULL) THEN

                  v_cip_approval_req := 'Y';


                  Wf_engine.SetItemAttrText(itemtype => itemtype
                                           ,itemkey  => itemkey
                                           ,aname    => 'XXHA_CIP_APPROVAL_REQ_CHECK'
                                           ,avalue    => v_cip_approval_req);

                    x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_approval_required:02 Passed Required Approval Validation';
                        PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                        IF    v_segment1 =  'CIP_BUDG' THEN

                            Wf_engine.SetItemAttrText(itemtype => itemtype
                                           ,itemkey  => itemkey
                                           ,aname    => 'XXHA_CIP_BUDG_CATEGORY_FLAG'
                                           ,avalue    => 'Y');
                        END IF;

              END IF;

      END LOOP;

      CLOSE c_CategoryReqLines;

        IF      v_cip_approval_req = 'Y' THEN

                resultout := wf_engine.eng_completed || ':' || 'Y';

       ELSE
                resultout := wf_engine.eng_completed || ':' || 'N';

       END IF;


EXCEPTION
    WHEN others THEN

      x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_approval_required Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_CIP_REQ_APPROVERS', 'CIP Approval Required Check',
                itemtype, itemkey, x_progress);
         RAISE;

END cip_approval_require_check;

/***************************************************************************************/
PROCEDURE cip_enabled_check (itemtype    IN     VARCHAR2
                            ,itemkey     IN     VARCHAR2
                            ,actid       IN     NUMBER
                            ,funcmode    IN     VARCHAR2
                            ,resultout   OUT    VARCHAR2)
IS


  v_requisition_header_id        NUMBER;
  v_preparer_id                  NUMBER;
  v_approval_list_header_id      NUMBER;
  v_org_id                       NUMBER;

  v_cip_enabled_flag             VARCHAR2(5);

   x_progress                    VARCHAR2(1000);

BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

    v_requisition_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                             itemkey  => itemkey,
                                                             aname    => 'DOCUMENT_ID');

    v_approval_list_header_id := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                             itemkey  => itemkey,
                                                             aname    => 'APPROVAL_LIST_HEADER_ID');

    v_preparer_id               := Wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                               ,itemkey  => itemkey
                                                               ,aname    => 'PREPARER_ID');

     v_org_id                   := wf_engine.GetItemAttrNumber(
                                                            itemtype => itemtype
                                                            ,itemkey  => itemkey
                                                            ,aname    => 'ORG_ID');

   x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_approval_required:01 CIP Enabled Check';
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


       v_cip_enabled_flag := FND_PROFILE.VALUE('HAE_CIP_ENABLED');


        IF      NVL(v_cip_enabled_flag, 'N') = 'Y' THEN

                resultout := wf_engine.eng_completed || ':' || 'Y';

       ELSE
                resultout := wf_engine.eng_completed || ':' || 'N';

       END IF;


EXCEPTION
    WHEN others THEN

      x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_enabled_check Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_CIP_REQ_APPROVERS', 'CIP Enabled Check',
                itemtype, itemkey, x_progress);
      RAISE;

END cip_enabled_check;
   /***************************************************************************************/
PROCEDURE cip_supplier_check (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2)
IS

  v_po_header_id               NUMBER;
  v_po_line_id                 NUMBER;
  v_buyer_id                   NUMBER;

  v_org_id                     NUMBER;

  v_vendor_id                  NUMBER;
  v_vendor_site_id             NUMBER;
  v_contract_exists_cnt        NUMBER;

  x_progress                  VARCHAR2(1000);

  v_cip_approval_req         VARCHAR2(1) := 'Y';


BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

    v_po_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'DOCUMENT_ID');

     v_org_id  := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                             ,itemkey  => itemkey
                                             ,aname    => 'ORG_ID');

       x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_supplier_check:01 Supplier Contract Check ';
        PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

        select      vendor_id,
                    vendor_site_id
          INTO      v_vendor_id
                   ,v_vendor_site_id
          FROM      po_headers_all
         where      po_header_id = v_po_header_id
           AND      org_id = v_org_id;


      select    COUNT(*)
        INTO    v_contract_exists_cnt
        from    po_headers_all ph
       where    ph.type_lookup_code = 'CONTRACT'
         and   ph.vendor_id = v_vendor_id
         and   ph.vendor_site_id = v_vendor_site_id
         AND   ph.authorization_status  = 'APPROVED'
         AND   TRUNC(SYSDATE) BETWEEN NVL(ph.start_date, TRUNC(SYSDATE)) AND NVL(ph.end_date, TRUNC(SYSDATE) + 1);


          IF  v_contract_exists_cnt > 0  THEN

                 resultout := wf_engine.eng_completed || ':' || 'Y';

             ELSE
                 resultout := wf_engine.eng_completed || ':' || 'N';

          END IF;


EXCEPTION
    WHEN OTHERS THEN

      x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_supplier_check Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_CIP_REQ_APPROVERS', 'CIP Supplier Check',
                       itemtype, itemkey,x_progress);
         RAISE;

END cip_supplier_Check;

/*********************************************************************************/
PROCEDURE cip_category_check (itemtype    IN     VARCHAR2
                             ,itemkey     IN     VARCHAR2
                             ,actid       IN     NUMBER
                             ,funcmode    IN     VARCHAR2
                             ,resultout   OUT    VARCHAR2)
IS

  v_po_header_id                 NUMBER;
  v_preparer_id                  NUMBER;

  v_org_id                       NUMBER;

  v_cip_approval_req            VARCHAR2(5);
  v_cip_cer_number              VARCHAR2(100);

  v_category_id                 NUMBER;
  v_segment1                    VARCHAR2(30);

   x_progress                   VARCHAR2(1000);


    CURSOR c_CategoryPOLines(p_po_header_id NUMBER,
                            p_org_id NUMBER)
    IS
    SELECT  Distinct    mcat.category_id,
                        mcat.segment1
                  from  mtl_categories_b            mcat,
                        po_lines_all                pl
                where   pl.category_id   = mcat.category_id
                  AND   pl.po_header_id  = p_po_header_id
                  AND   pl.org_id        = p_org_id;

BEGIN

    IF (funcmode != Wf_Engine.eng_run)
    THEN
        --  Do nothing in cancel or timeout mode
        resultout := Wf_Engine.eng_null;
        --
        RETURN;
    END IF;

    v_po_header_id   := Wf_Engine.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'DOCUMENT_ID');

     v_org_id        := wf_engine.GetItemAttrNumber(itemtype => itemtype
                                                   ,itemkey  => itemkey
                                                   ,aname    => 'ORG_ID');


   OPEN c_CategoryPOLines(v_po_header_id, v_org_id);
    LOOP
    FETCH c_CategoryPOLines INTO      v_category_id,
                                       v_segment1;

      EXIT WHEN c_CategoryPOLines%NOTFOUND;

    x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_approval_required:01 Category Check ';
    PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

             IF  v_segment1 = 'CIP_PURC' or v_segment1 =  'CIP_BUDG'  THEN

                   v_cip_approval_req  := 'Y';

                  Wf_engine.SetItemAttrText(itemtype => itemtype
                                           ,itemkey  => itemkey
                                           ,aname    => 'XXHA_CIP_APPROVAL_REQ_CHECK'
                                           ,avalue    => v_cip_approval_req);

                    x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_approval_required:02 Passed Required Approval Validation';
                        PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

                        IF    v_segment1 =  'CIP_BUDG' THEN

                            Wf_engine.SetItemAttrText(itemtype => itemtype
                                           ,itemkey  => itemkey
                                           ,aname    => 'XXHA_CIP_BUDG_CATEGORY_FLAG'
                                           ,avalue    => 'Y');

                        END IF;

              END IF;

      END LOOP;

      CLOSE c_CategoryPOLines;


        IF      v_cip_approval_req = 'Y' THEN

                resultout := wf_engine.eng_completed || ':' || 'Y';

       ELSE
                resultout := wf_engine.eng_completed || ':' || 'N';

       END IF;


EXCEPTION
    WHEN others THEN

      x_progress := 'XXHA_CIP_REQ_APPROVERS.cip_approval_required Exception ';
      PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);

      Wf_Core.Context('XXHA_CIP_REQ_APPROVERS', 'CIP Approval Required Check',
                        itemtype, itemkey,x_progress);
         RAISE;

END cip_category_check;
/***************************************************************************************/

PROCEDURE update_cip_status (x_errbuf          OUT VARCHAR2,
                             x_retcode         OUT VARCHAR2,
                             p_requisition_header_id IN NUMBER,
                             p_status          IN VARCHAR2
                            ) IS

BEGIN

        update  po_requisition_headers_all
           SET  attribute2 = upper(p_status)
         where  requisition_header_id = p_requisition_header_id;

END update_cip_status;

/***************************************************************************************/

END XXHA_CIP_REQ_APPROVERS_PKG;
/
