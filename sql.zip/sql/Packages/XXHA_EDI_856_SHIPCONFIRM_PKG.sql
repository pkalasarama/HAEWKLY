CREATE OR REPLACE PACKAGE        "XXHA_EDI_856_SHIPCONFIRM_PKG"
IS
/*-- VERSION : 1.1
-- CREATED BY : Manik Bahl
-- PURPOSE : This Pl/sql Package Is Used To Ship confirm deliveries.
-- CALLED FROM : XML GATEWAY
-- CHANGE HISTORY:
-- *************************************************************************
-- SFRANCIS   3/18/13     -- added procedures for auto create deliveries
                            procedure to pick release (create a batch and release a batch)
                            releasing the batch will be in concurrent mode.
                            added procedure for a concurrent program to wait for completion
--
--
-- ***********************************************************************/
function reserve_qty (p_org_id in number
                    ,p_inv_item_id in number
                    ,p_demand_source_header_id in number
                    ,p_demand_source_line_id in number
                    ,p_reservation_uom_code in varchar2
                    ,p_lot_number in varchar2
                    ) RETURN number;

PROCEDURE PICKCONFIRM (p_move_order_number IN VARCHAR2, x_return_status in out varchar2);

PROCEDURE SHIPCONFIRM (p_delivery_ID        IN NUMBER,
                                       p_ship_method_code   IN VARCHAR2
                                       , x_return_status in out varchar2);

PROCEDURE MAIN(errbuf out varchar2
              ,retcode out varchar2
              ,P_DELIVERY_NUM IN VARCHAR2
              ,P_TXN_TYPE_NAME IN VARCHAR2
              ,P_USER_ID IN NUMBER
              ,P_RESP_APPL_ID IN NUMBER
              ,P_RESP_ID IN NUMBER
              );

PROCEDURE MAIN_TEST;

PROCEDURE AutoCreateDeliveries (P_DELIVERY_NUM IN VARCHAR2
                                ,x_delivery_id IN OUT NUMBER);

PROCEDURE pickRelease (p_delivery_id in number);

PROCEDURE waitForConcRequest (p_request_id IN NUMBER
                             ,p_calling_procedure IN VARCHAR2 DEFAULT NULL
                              ,x_message OUT varchar2
                              ,x_phase out varchar2
                              ,x_status out varchar2
                              ,x_dev_phase out varchar2
                              ,x_dev_status out varchar2
                              ,x_return_status out varchar2 -- values are S or E
                              );

PROCEDURE check_rx_del_num (p_delivery_num in varchar2
                           ,x_return_status out varchar2 -- values are S and F
                           ,x_return_msg out varchar2
                           );

PROCEDURE XXHALOCKORDER (p_order_header_id in number
                                          ,x_return_status in out varchar2) ;
END XXHA_EDI_856_SHIPCONFIRM_PKG;

/


CREATE OR REPLACE PACKAGE BODY      XXHA_EDI_856_SHIPCONFIRM_PKG
IS
   -- VERSION : 1.0
   -- CREATED BY : Manik Bahl
   -- PURPOSE : This Pl/sql Package Is Used To Ship confirm deliveries.
   -- CALLED FROM :XML GATEWAY
   -- CHANGE HISTORY:
   -- ***********************************************************************
   ------Global Variable------------
   g_delivery_num          VARCHAR2 (200) DEFAULT NULL ;
   g_transaction_type_id   NUMBER;
   g_txn_name             VARCHAR2(100);
   g_subinv               varchar2(10);
   g_freight_line_id  number default 0;
  g_emergency_line_id number default 0;
  g_order_number oe_order_headers_all.order_number%TYPE;



procedure print_log (p_text in varchar2) is
begin

  if fnd_global.conc_request_id > 0 then
    fnd_file.put_line(fnd_file.log, to_char(sysdate, 'DD-MON-YYYY HH24:MI:SS')||'   '||p_text);
  else
    dbms_output.put_line (to_char(sysdate, 'DD-MON-YYYY HH24:MI:SS')||'   '||p_text);
   end if;
end print_log;

procedure print_output (p_text in varchar2) is
begin
  if fnd_global.conc_request_id > 0 then
    fnd_file.put_line(fnd_file.output, p_text);
  else
    dbms_output.put_line (p_text);
   end if;
end print_output;

-------------

-- procedure to set error records
--------------

PROCEDURE set_error_status (p_delivery_num in varchar2) as
begin

                   UPDATE   xxha_edi_856_delivery
                      SET   STATUS = 'ERROR'
                    WHERE   delivery_num = p_delivery_num ;

                   UPDATE   xxha_edi_856_delivery_details
                      SET   STATUS = 'ERROR'
                    WHERE   delivery_num =p_delivery_num ;

                    commit;
end;
--------------------------

--- procedure to validate incoming deliveries.
-- called before proceeding from main procedure

-----------------------



procedure validate_del(p_delivery_num varchar2
                    , p_order_type varchar2
                    , p_subinventory_code varchar2
                    , x_status out varchar2
                    , x_error_message out varchar2) is
  --p_delivery_num varchar2(100) := '200086300';
  --p_order_type varchar2(100) := 'RxC Standard';
  --p_subinventory_code varchar2(100) := g_subinv;
  --x_status varchar2(1);
  --x_error_message varchar2(2000);

  cursor d1(x_delivery_num varchar2) is
  select count(1) delivery_counts from xxha_edi_856_delivery xxedi where delivery_num = x_delivery_num;

  cursor c1(x_delivery_num varchar2) is
  select * from xxha_edi_856_delivery xxedi where delivery_num = x_delivery_num;
  --
  cursor c_o1(x_order_number number, x_order_type varchar2) is
  select h.header_id, h.cancelled_flag, h.open_flag, h.booked_flag, t.transaction_type_id, h.org_id
  from oe_order_headers_all h, oe_transaction_types t
  where h.order_number = to_number(x_order_number)
  and   h.order_type_id = t.transaction_type_id(+)
  and   t.name (+) = x_order_type
  ;

  cursor dlineSum(x_delivery_num varchar2) is
  select line_num, nvl(sum(decode(nvl(lot_qty,0),0,item_qty,lot_qty)),0) asn_quantity
  from xxha_edi_856_delivery_details where delivery_num = x_delivery_num
  group by line_num
  ;

  cursor olineOpenSum(x_header_id number, x_line_num varchar2) is
  --select  nvl(sum(l.ordered_quantity - nvl(l.cancelled_quantity,0) - nvl(l.shipped_quantity,0)),0) open_quantity
  -- order changes happen after booking. so there will be a cancelled quantity. the new open qty on the line
  -- will be reflected as ordered qty.
  -- when a partial shipment of a line occurs, the line gets split. every line when it is shipped is shipped in full
  -- hence no need to look at the shipped qty to determine the open qty
  select  nvl(sum(l.ordered_quantity) ,0) open_quantity
  from oe_order_lines l
  where l.header_id = x_header_id
  and   l.line_number = to_number(x_line_num)
  and   l.booked_flag = 'Y' and nvl(l.cancelled_flag,'N') = 'N' and l.open_flag = 'Y'
  ;

  cursor dlineLotSum(x_delivery_num varchar2) is
  select xd.line_num, xd.item_num, xd.lot_number
  , nvl(sum(decode(nvl(xd.lot_qty,0),0,xd.item_qty,xd.lot_qty)),0) quantity
  , sum(xd.lot_qty) lot_quantity, count(1) line_count
  from xxha_edi_856_delivery_details xd
  where xd.delivery_num = x_delivery_num
  group by line_num, item_num, xd.lot_number
  ;

  cursor cAvailable(x_item varchar2, x_subinventory_code varchar2, x_ship_from_org_id number, x_lot_number varchar2) is
  select nvl(sum(transaction_quantity),0) QUANTITY_ON_HAND
  from mtl_onhand_quantities moh, mtl_system_items_vl msi
  where moh.organization_id = msi.organization_id
  and   moh.inventory_item_id = msi.inventory_item_id
  and   msi.segment1 = x_item --'430-40'
  and   moh.subinventory_code = x_subinventory_code --'FG'
  and   msi.organization_id = x_ship_from_org_id --2540
  and   (x_lot_number is null or moh.lot_number = x_lot_number )
  ;
  order_rec c_o1%rowtype;
  v_ship_lines_found boolean;
  v_order_line_found boolean;
  v_some_lines_failed boolean;
  v_ship_from_org_id number;
  v_lot_found boolean;

begin
  for d in d1(p_delivery_num) loop
    if d.delivery_counts = 0 then
       x_status := 'F';
       x_error_message := x_error_message || '*DELIVERY_RECORD_NOT_FOUND';
    end if;

    if d.delivery_counts > 1 then
       x_status := 'F';
       x_error_message := x_error_message || '*DUPLICATE_DELIVERY_RECORDS_FOUND';
    end if;
  end loop;

  if x_status = 'F' then
    return;
  end if;

 ----------------------- -- check the delivery
  for d in c1(p_delivery_num) loop
      if d.order_number is null then
        x_error_message := x_error_message || '*ORDER_NUMBER_NOT_AVAILABLE_ON_DELIVERY_RECORD';
        x_status := 'F';
        exit;
      end if;

        ----- order check
        open c_o1(d.order_number, p_order_type);
        fetch c_o1 into order_rec;
        if c_o1%notfound then
          x_status := 'F';
          x_error_message := x_error_message || '*ORDER_NUMBER_NOT_FOUND_IN_EBS';
          close c_o1;
          return;
        end if;
        close c_o1;

    ---------- lines checks
    -- matching OpenOrderQty To ASNQty
    v_ship_lines_found := false;
        for xi in dlineSum(d.delivery_num) loop
              v_ship_lines_found := true;
              --check if line exists in in order line
              v_order_line_found := false;

                  for ol in olineOpenSum(order_rec.header_id, xi.line_num) loop
                    v_order_line_found := true;
                      if ol.open_quantity < xi.asn_quantity then
                        x_status := 'F';
                        x_error_message := x_error_message || '*ASN_QUANTITY_EXCEEDS_OPEN_ORDER_QUANTITY. Line Num '||xi.line_num;
                      end if;
                  end loop;

            if x_status = 'F' then
               return;
            end if;
              ---------
              if not v_order_line_found then
                x_status := 'F';
                x_error_message := x_error_message || '*ASN_LINE_NOT_FOUND_OR_NOT_AVAILABLE_TO_SHIP';
              end if;
    end loop;

    ------
    if not v_ship_lines_found then
      x_status := 'F';
      x_error_message := x_error_message || '*XML_DELIVERY_LINES_NOT_RECEIVED';
      return;
    end if;

    ----------- check each lot quantity availability
    for l in dlineLotSum(d.delivery_num) loop
      -- find ship_from_org_id
          select ship_from_org_id into v_ship_from_org_id from oe_order_lines where header_id = order_rec.header_id and line_number = to_number(l.line_num) and rownum = 1;
          v_lot_found := false;

          for lq in cAvailable(l.item_num, p_subinventory_code, v_ship_from_org_id, l.lot_number) loop
                v_lot_found := true;

                if lq.quantity_on_hand = 0 then
                      x_status := 'F';
                      x_error_message := x_error_message || '*NO_QUANTITY_ON_HAND';
                else
                    if lq.quantity_on_hand < l.quantity then
                      x_status := 'F';
                      x_error_message := x_error_message || '*QUANTITY_ON_HAND_SHORT';
                    end if;

                end if;
          end loop;

            if x_status = 'F' then
               return;
            end if;

            if not v_lot_found then
              x_status := 'F';
              x_error_message := x_error_message || '*LOT_NOT_AVAILABLE_ON_HAND';
              exit;
            end if;
    end loop;
    --------------
      if x_status = 'F' then
        return;
      end if;

  end loop;

      if x_status = 'F' then
        return;
      end if;

  x_status := 'S';

end validate_del;

------------------

  -- function to find out the total reservation quantity

-------------------
function reserve_qty (p_org_id in number
                    ,p_inv_item_id in number
                    ,p_demand_source_header_id in number
                    ,p_demand_source_line_id in number
                    ,p_reservation_uom_code in varchar2
                    ,p_lot_number in varchar2
                    ) RETURN number as
l_qty number:=-1;

begin

        select nvl( sum(reservation_quantity), 0) into l_qty
         from mtl_reservations
         where organization_id  = p_org_id
         and inventory_item_id = p_inv_item_id
        -- and demand_source_type_id  =2 -- sales orders
         and demand_source_header_id = nvl( p_demand_source_header_id, demand_source_header_id)
         and demand_source_line_id = nvl(p_demand_source_line_id, demand_source_line_id)
         and upper(reservation_uom_code) = upper(p_reservation_uom_code)
         and lot_number = nvl(p_lot_number, lot_number)
         ;
         return l_qty;

exception when others then
print_log ('error in deriving reservation qty '||sqlerrm);
return l_qty;

end    reserve_qty;
   ---------------------------------------------------------------------------
   --Procedure to create emergency and freight items-----------
   ----------------------------------------------------------------------------
PROCEDURE EMERGENCY_FRT_ITEM (p_delivery_num   IN VARCHAR2,
                                          p_frt_item       IN VARCHAR2,
                                          p_frt_amt        IN VARCHAR2,
                                          p_order_header_id in number
                                          ,x_line_id in out number)
   IS
      v_api_version_number           NUMBER := 1;
      v_return_status                VARCHAR2 (2000) DEFAULT NULL ;
      v_msg_count                    NUMBER DEFAULT 0 ;
      v_msg_data                     VARCHAR2 (2000) DEFAULT NULL ;
      -- IN Variables --
      v_header_rec                   oe_order_pub.header_rec_type;
      v_line_tbl                     oe_order_pub.line_tbl_type;
      v_action_request_tbl           oe_order_pub.request_tbl_type;
      v_line_adj_tbl                 oe_order_pub.line_adj_tbl_type;
      -- OUT Variables --
      v_header_rec_out               oe_order_pub.header_rec_type;
      v_header_val_rec_out           oe_order_pub.header_val_rec_type;
      v_header_adj_tbl_out           oe_order_pub.header_adj_tbl_type;
      v_header_adj_val_tbl_out       oe_order_pub.header_adj_val_tbl_type;
      v_header_price_att_tbl_out     oe_order_pub.header_price_att_tbl_type;
      v_header_adj_att_tbl_out       oe_order_pub.header_adj_att_tbl_type;
      v_header_adj_assoc_tbl_out     oe_order_pub.header_adj_assoc_tbl_type;
      v_header_scredit_tbl_out       oe_order_pub.header_scredit_tbl_type;
      v_header_scredit_val_tbl_out   oe_order_pub.header_scredit_val_tbl_type;
      v_line_tbl_out                 oe_order_pub.line_tbl_type;
      v_line_val_tbl_out             oe_order_pub.line_val_tbl_type;
      v_line_adj_tbl_out             oe_order_pub.line_adj_tbl_type;
      v_line_adj_val_tbl_out         oe_order_pub.line_adj_val_tbl_type;
      v_line_price_att_tbl_out       oe_order_pub.line_price_att_tbl_type;
      v_line_adj_att_tbl_out         oe_order_pub.line_adj_att_tbl_type;
      v_line_adj_assoc_tbl_out       oe_order_pub.line_adj_assoc_tbl_type;
      v_line_scredit_tbl_out         oe_order_pub.line_scredit_tbl_type;
      v_line_scredit_val_tbl_out     oe_order_pub.line_scredit_val_tbl_type;
      v_lot_serial_tbl_out           oe_order_pub.lot_serial_tbl_type;
      v_lot_serial_val_tbl_out       oe_order_pub.lot_serial_val_tbl_type;
      v_action_request_tbl_out       oe_order_pub.request_tbl_type;
      v_msg_index                    NUMBER;
      v_data                         VARCHAR2 (2000);
      v_loop_count                   NUMBER;
      v_debug_file                   VARCHAR2 (200);
      b_return_status                VARCHAR2 (200);
      b_msg_count                    NUMBER DEFAULT 0 ;
      b_msg_data                     VARCHAR2 (2000);
      x_header_id                    NUMBER;
      x_inventory_item_id            NUMBER;
      x_organization_id              NUMBER;
      x_sql_err_flag                 NUMBER DEFAULT 0 ;
      x_err_msg                      VARCHAR2 (4000) DEFAULT NULL ;
      x_lockorder_return_status     varchar2(1);

      l_payment_term_id number default null;
      l_payment_terms varchar2(150) default null;
      lx_error_message varchar2(2000);
      lx_pay_term_status varchar2(10);
      l_invoice_to_org_id number;
      /* R12 Upgrade Modified on 02/12/2014 by Venkatesh Sarangam , Rolta  */
      --l_ece_tp_loc_code ra_addresses_all.ece_tp_location_code%TYPE;
      l_ece_tp_loc_code hz_cust_acct_sites_all.ece_tp_location_code%TYPE;

BEGIN
    print_log ('Inside procedure EMERGENCY_FRT_ITEM'||chr(10));

      BEGIN
         SELECT   DISTINCT oh.header_id, ol.ship_from_org_id, oh.invoice_to_org_id
           INTO   x_header_id, x_organization_id, l_invoice_to_org_id
           FROM   oe_order_headers_all oh,
                  oe_order_lines_all ol,
                  wsh_delivery_details wdd,
                  xxha_edi_856_delivery xxedi,
                  xxha_edi_856_delivery_details xxedidet,
                  mtl_system_items_b msi
          WHERE       wdd.source_header_id = oh.header_id
                  AND wdd.source_line_id = ol.line_id
                  AND oh.header_id = ol.header_id
                  AND NVL (ol.open_flag, 'N') = 'Y'
                  AND released_status NOT IN ('Y', 'C')
                  AND NVL (oh.open_flag, 'N') = 'Y'
                  AND oh.booked_flag = 'Y'
                  AND NVL (ol.cancelled_flag, 'N') <> 'Y'
                  AND ol.flow_status_code = 'AWAITING_SHIPPING'
                  AND xxedi.order_number = oh.order_number
                  AND xxedidet.line_num = ol.customer_line_number
                  AND xxedi.delivery_num = xxedidet.delivery_num
                  AND xxedi.delivery_num = p_delivery_num
                  AND xxedidet.delivery_num = p_delivery_num
                  AND msi.inventory_item_id = ol.inventory_item_id
                  AND msi.organization_id = ol.ship_from_org_id
                  AND nvl(xxedi.status, 'XX') !='PROCESSED' -- 'NEW'
                  AND nvl( xxedidet.status, 'XX') !='PROCESSED' --'NEW'
                  AND oh.order_type_id = g_transaction_type_id;
      EXCEPTION
         WHEN OTHERS
         THEN
            x_sql_err_flag := 1;
            ROLLBACK;
            x_err_msg :=
               x_err_msg
               || 'Error in deriving header id information for freight and emergency items:'
               || '||';
               print_log (x_err_msg);
      END;

      BEGIN
         SELECT   inventory_item_id
           INTO   x_inventory_item_id
           FROM   mtl_system_items_b
          WHERE   segment1 = p_frt_item AND ROWNUM = 1;
      EXCEPTION
         WHEN OTHERS
         THEN
            x_sql_err_flag := 1;
            ROLLBACK;
            x_err_msg :=
               x_err_msg
               || 'Error in deriving inventory_item_id information for freight and emergency items:'
               || '||';
               print_log (x_err_msg);
      END;

      -- begin code to get payment term id for line (if there is a payment term substitution modifier for the bill to
      begin
      /* R12 Upgrade Modified on 02/12/2014 by Venkatesh Sarangam , Rolta  */
              /* select
            --   c.customer_id, su.status site_status, a.status address_status, su.site_use_id, c.status customer_status,
               a.ece_tp_location_code --, c.*
              into l_ece_tp_loc_code
              from ra_site_uses_all su, ra_addresses_all a, ra_customers c
              where a.address_id = su.address_id
              And   A.Customer_Id = C.Customer_Id
           --   and   a.ece_tp_location_code = '21577'--P_Bill_To_Edi_Code --'21574'
              and   su.site_use_code = 'BILL_TO'
              and su.site_use_id = l_invoice_to_org_id --130330
            --  and   to_char(su.site_use_id) = qq.qualifier_attr_value
            ;*/
            select
                 hcas.ece_tp_location_code
                 into l_ece_tp_loc_code
            from
                 hz_parties hp,
                 hz_cust_accounts hca,
                 hz_party_sites hps,
                 hz_locations hl,
                 hz_cust_acct_sites_all hcas,
                 hz_cust_site_uses_all hcsu
            where hp.party_id=hca.party_id
              and hca.cust_account_id = hcas.cust_account_id
              and hps.location_id=hl.location_id
              and hps.party_site_id=hcas.party_site_id
              and hcas.cust_acct_site_id = hcsu.cust_acct_site_id
              and hcsu.site_use_code = 'BILL_TO'
              and hcsu.site_use_id = l_invoice_to_org_id
;
      Exception when others then
        print_log ('error, error in deriving ece_tp_location_code. sql error is  '||sqlerrm);
      end;
        -- call to get payment terms id in case there is a payment term substitution
                Xxha_edi_validation.Payment_Term_From_Modifier(
            P_Modifier_Name => 'US RxC Term Substitution'
            , P_Bill_To_Edi_Code =>l_ece_tp_loc_code -- '21577'
            ,X_Payment_Term_Id => l_payment_term_id
            , X_Payment_Terms=> l_payment_terms
            ,X_Error_Message => lx_error_message
            ,X_Status => lx_pay_term_status);
          -- end code to get payment term id for line (if there is a payment term substitution modifier for the bill to



      v_action_request_tbl (1) := oe_order_pub.g_miss_request_rec;

      -- Line Record --
      v_line_tbl (1) := oe_order_pub.g_miss_line_rec;
      v_line_tbl (1).operation := oe_globals.g_opr_create;
      v_line_tbl (1).header_id := x_header_id;
      -- Existing order header id
      v_line_tbl (1).inventory_item_id := x_inventory_item_id;
      v_line_tbl (1).ordered_quantity := 1;
      v_line_tbl (1).unit_selling_price := p_frt_amt;
      --  v_line_tbl (1).original_list_price := p_frt_amt;
      v_line_tbl (1).ship_from_org_id := x_organization_id;
      v_line_tbl (1).calculate_price_flag := 'N';
      if l_payment_term_id is not null then
      v_line_tbl (1).payment_term_id := l_payment_term_id;
      end if;

      print_log ('Starting of API');

      -- Calling the API to add a new line to an existing Order --
       oe_msg_pub.initialize;
        XXHALOCKORDER (p_order_header_id, x_lockorder_return_status); -- lock the order
      OE_ORDER_PUB.PROCESS_ORDER (
         p_api_version_number       => v_api_version_number,
         p_header_rec               => v_header_rec,
         p_line_tbl                 => v_line_tbl,
         p_action_request_tbl       => v_action_request_tbl,
         p_line_adj_tbl             => v_line_adj_tbl,
         -- OUT variables,
         x_header_rec               => v_header_rec_out,
         x_header_val_rec           => v_header_val_rec_out,
         x_header_adj_tbl           => v_header_adj_tbl_out,
         x_header_adj_val_tbl       => v_header_adj_val_tbl_out,
         x_header_price_att_tbl     => v_header_price_att_tbl_out,
         x_header_adj_att_tbl       => v_header_adj_att_tbl_out,
         x_header_adj_assoc_tbl     => v_header_adj_assoc_tbl_out,
         x_header_scredit_tbl       => v_header_scredit_tbl_out,
         x_header_scredit_val_tbl   => v_header_scredit_val_tbl_out,
         x_line_tbl                 => v_line_tbl_out,
         x_line_val_tbl             => v_line_val_tbl_out,
         x_line_adj_tbl             => v_line_adj_tbl_out,
         x_line_adj_val_tbl         => v_line_adj_val_tbl_out,
         x_line_price_att_tbl       => v_line_price_att_tbl_out,
         x_line_adj_att_tbl         => v_line_adj_att_tbl_out,
         x_line_adj_assoc_tbl       => v_line_adj_assoc_tbl_out,
         x_line_scredit_tbl         => v_line_scredit_tbl_out,
         x_line_scredit_val_tbl     => v_line_scredit_val_tbl_out,
         x_lot_serial_tbl           => v_lot_serial_tbl_out,
         x_lot_serial_val_tbl       => v_lot_serial_val_tbl_out,
         x_action_request_tbl       => v_action_request_tbl_out,
         x_return_status            => v_return_status,
         x_msg_count                => v_msg_count,
         x_msg_data                 => v_msg_data
      );

      x_line_id:= v_line_tbl_out (1).line_id;



      IF v_return_status = fnd_api.g_ret_sts_success
      THEN
         print_log ('Line Addition to Existing Order Success ');
      ELSE
         print_log (
            'Line Addition to Existing Order failed:' || v_msg_data
         );

         FOR i IN 1 .. v_msg_count
         LOOP
            -- x_sql_err_flag := 1;
            v_msg_data := oe_msg_pub.get (p_msg_index => i, p_encoded => 'F');
            print_log (i || ') ' || v_msg_data);
         END LOOP;

         x_sql_err_flag := 1;
         ROLLBACK;
         x_err_msg := x_err_msg || v_msg_data;
      END IF;
      print_log ('API msg data '||x_err_msg);
      print_log ('API return status '||v_return_status);

      IF x_sql_err_flag = 1
      THEN
         INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                          ERROR_MESSAGE,
                                          CREATION_DATE,
                                          CREATED_BY,
                                          LAST_UPDATE_DATE,
                                          LAST_UPDATED_BY)
           VALUES   (g_delivery_num,
                     x_err_msg,
                     SYSDATE,
                     fnd_global.user_id,
                     SYSDATE,
                     fnd_global.user_id);

         UPDATE   xxha_edi_856_delivery
            SET   STATUS = 'ERROR'
          WHERE   delivery_num = g_delivery_num;

         UPDATE   xxha_edi_856_delivery_details
            SET   STATUS = 'ERROR'
          WHERE   delivery_num = g_delivery_num;
      END IF;

      COMMIT;
        print_log ('End of  of Emergency Freight Item procedure'||chr(10));
END EMERGENCY_FRT_ITEM;

   --Procedure to split lines  -----------
   ----------------------------------------------------------------------------
PROCEDURE SPLIT_LINE (p_delivery_num IN VARCHAR2, p_order_header_id in number)
   IS
      ----------------------------------------
      -----------Declare local variables-----
      -----------------------------------------
      l_header_rec               OE_ORDER_PUB.Header_Rec_Type;
      l_line_tbl                 OE_ORDER_PUB.Line_Tbl_Type;
      l_action_request_tbl       OE_ORDER_PUB.Request_Tbl_Type;
      l_header_adj_tbl           OE_ORDER_PUB.Header_Adj_Tbl_Type;
      l_line_adj_tbl             OE_ORDER_PUB.line_adj_tbl_Type;
      l_header_scr_tbl           OE_ORDER_PUB.Header_Scredit_Tbl_Type;
      l_line_scredit_tbl         OE_ORDER_PUB.Line_Scredit_Tbl_Type;
      l_request_rec              OE_ORDER_PUB.Request_Rec_Type;
      l_return_status            VARCHAR2 (1000);
      l_msg_count                NUMBER;
      l_msg_data                 VARCHAR2 (1000);
      p_api_version_number       NUMBER := 1.0;
      p_init_msg_list            VARCHAR2 (10) := FND_API.G_FALSE;
      p_return_values            VARCHAR2 (10) := FND_API.G_FALSE;
      p_action_commit            VARCHAR2 (10) := FND_API.G_FALSE;
      x_return_status            VARCHAR2 (1);
      x_msg_count                NUMBER;
      x_msg_data                 VARCHAR2 (100);
      p_header_rec OE_ORDER_PUB.Header_Rec_Type            := OE_ORDER_PUB.G_MISS_HEADER_REC ;
      p_old_header_rec OE_ORDER_PUB.Header_Rec_Type            := OE_ORDER_PUB.G_MISS_HEADER_REC ;
      p_header_val_rec OE_ORDER_PUB.Header_Val_Rec_Type            := OE_ORDER_PUB.G_MISS_HEADER_VAL_REC ;
      p_old_header_val_rec OE_ORDER_PUB.Header_Val_Rec_Type            := OE_ORDER_PUB.G_MISS_HEADER_VAL_REC ;
      p_Header_Adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL ;
      p_old_Header_Adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL ;
      p_Header_Adj_val_tbl OE_ORDER_PUB.Header_Adj_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_VAL_TBL ;
      p_old_Header_Adj_val_tbl OE_ORDER_PUB.Header_Adj_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_VAL_TBL ;
      p_Header_price_Att_tbl OE_ORDER_PUB.Header_Price_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_PRICE_ATT_TBL ;
      p_old_Header_Price_Att_tbl OE_ORDER_PUB.Header_Price_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_PRICE_ATT_TBL ;
      p_Header_Adj_Att_tbl OE_ORDER_PUB.Header_Adj_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ATT_TBL ;
      p_old_Header_Adj_Att_tbl OE_ORDER_PUB.Header_Adj_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ATT_TBL ;
      p_Header_Adj_Assoc_tbl OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ASSOC_TBL ;
      p_old_Header_Adj_Assoc_tbl OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ASSOC_TBL ;
      p_Header_Scredit_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL ;
      p_old_Header_Scredit_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL ;
      p_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_VAL_TBL ;
      p_old_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_VAL_TBL ;
      p_line_tbl OE_ORDER_PUB.Line_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_TBL ;
      p_old_line_tbl OE_ORDER_PUB.Line_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_TBL ;
      p_line_val_tbl OE_ORDER_PUB.Line_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_VAL_TBL ;
      p_old_line_val_tbl OE_ORDER_PUB.Line_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_VAL_TBL ;
      p_Line_Adj_tbl OE_ORDER_PUB.Line_Adj_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL ;
      p_old_Line_Adj_tbl OE_ORDER_PUB.Line_Adj_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL ;
      p_Line_Adj_val_tbl OE_ORDER_PUB.Line_Adj_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_VAL_TBL ;
      p_old_Line_Adj_val_tbl OE_ORDER_PUB.Line_Adj_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_VAL_TBL ;
      p_Line_price_Att_tbl OE_ORDER_PUB.Line_Price_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_TBL ;
      p_old_Line_Price_Att_tbl OE_ORDER_PUB.Line_Price_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_TBL ;
      p_Line_Adj_Att_tbl OE_ORDER_PUB.Line_Adj_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_ATT_TBL ;
      p_old_Line_Adj_Att_tbl OE_ORDER_PUB.Line_Adj_Att_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_ATT_TBL ;
      p_Line_Adj_Assoc_tbl OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_ASSOC_TBL ;
      p_old_Line_Adj_Assoc_tbl OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_ADJ_ASSOC_TBL ;
      p_Line_Scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL ;
      p_old_Line_Scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL ;
      p_Line_Scredit_val_tbl OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_VAL_TBL ;
      p_old_Line_Scredit_val_tbl OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_VAL_TBL ;
      p_Lot_Serial_tbl OE_ORDER_PUB.Lot_Serial_Tbl_Type            := OE_ORDER_PUB.G_MISS_LOT_SERIAL_TBL ;
      p_old_Lot_Serial_tbl OE_ORDER_PUB.Lot_Serial_Tbl_Type            := OE_ORDER_PUB.G_MISS_LOT_SERIAL_TBL ;
      p_Lot_Serial_val_tbl OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LOT_SERIAL_VAL_TBL ;
      p_old_Lot_Serial_val_tbl OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type            := OE_ORDER_PUB.G_MISS_LOT_SERIAL_VAL_TBL ;
      p_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type            := OE_ORDER_PUB.G_MISS_REQUEST_TBL ;

      x_header_rec               OE_ORDER_PUB.Header_Rec_Type;
      x_line_tbl                 OE_ORDER_PUB.Line_Tbl_Type;
      x_header_val_rec           OE_ORDER_PUB.Header_Val_Rec_Type;
      x_Header_Adj_tbl           OE_ORDER_PUB.Header_Adj_Tbl_Type;
      x_Header_Adj_val_tbl       OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
      x_Header_price_Att_tbl     OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
      x_Header_Adj_Att_tbl       OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
      x_Header_Adj_Assoc_tbl     OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
      x_Header_Scredit_tbl       OE_ORDER_PUB.Header_Scredit_Tbl_Type;
      x_Header_Scredit_val_tbl   OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
      x_line_val_tbl             OE_ORDER_PUB.Line_Val_Tbl_Type;
      x_Line_Adj_tbl             OE_ORDER_PUB.Line_Adj_Tbl_Type;
      x_Line_Adj_val_tbl         OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
      x_Line_price_Att_tbl       OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
      x_Line_Adj_Att_tbl         OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
      x_Line_Adj_Assoc_tbl       OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
      x_Line_Scredit_tbl         OE_ORDER_PUB.Line_Scredit_Tbl_Type;
      x_Line_Scredit_val_tbl     OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
      x_Lot_Serial_tbl           OE_ORDER_PUB.Lot_Serial_Tbl_Type;
      x_Lot_Serial_val_tbl       OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type;
      x_action_request_tbl       OE_ORDER_PUB.Request_Tbl_Type;
      X_DEBUG_FILE               VARCHAR2 (100);
      l_line_tbl_index           NUMBER;
      x_ship_set_id              NUMBER;
      l_msg_index_out            NUMBER (10);
      x_user_id                  NUMBER;
      x_sql_err_flag             NUMBER DEFAULT 0 ;
      x_err_msg                  varchar2 (4000) DEFAULT NULL ;
      x_api_msg                  varchar2(4000):=null;
       x_lockorder_return_status     varchar2(1);

      ----------------------------------------------------------
      -----------Declare cursor for prcoessing records-----
      ---------------------------------------------------------

      CURSOR c_ord_details_nf
      IS
         SELECT   oh.order_number,
                  oh.header_id,
                  ol.line_id,
                  ol.customer_line_number,
                  ol.ordered_quantity,
                  msi.inventory_item_id,
                  msi.primary_uom_code,
                  msi.organization_id,
                  wddi.delivery_detail_id,
                  NULL delivery_num,
                  NULL line_num,
                  NULL item_num,
                  NULL item_qty,
                  NULL item_uom,
                  NULL lot_line_num,
                  NULL lot_number,
                  NULL lot_qty
           FROM   oe_order_headers_all oh,
                  oe_order_lines_all ol,
                  wsh_delivery_details wddi,
                  mtl_system_items_b msi
          WHERE       wddi.source_header_id = oh.header_id
                  AND wddi.source_line_id = ol.line_id
                  AND oh.header_id = ol.header_id
                  AND msi.inventory_item_id = ol.inventory_item_id
                  AND msi.organization_id = ol.ship_from_org_id
                  AND msi.segment1 NOT IN ('FREIGHT', 'EMERGENCY')
                  AND oh.order_type_id = g_transaction_type_id
                  AND order_number =
                        (SELECT   order_number
                           FROM   xxha_edi_856_delivery
                          WHERE   delivery_num = p_delivery_num
                                  AND nvl(status,'XX') != 'PROCESSED'--'NEW'

                                  )
                  AND NOT EXISTS
                        (SELECT   1
                           FROM   oe_order_headers_all oho,
                                  oe_order_lines_all olo,
                                  wsh_delivery_details wdd,
                                  xxha_edi_856_delivery xxedi,
                                  xxha_edi_856_delivery_details xxedidet,
                                  mtl_system_items_b msi
                          WHERE       wdd.source_header_id = oho.header_id
                                  AND wdd.source_line_id = olo.line_id
                                  AND oho.header_id = olo.header_id
                                  AND xxedi.order_number = oho.order_number
                                  AND xxedidet.line_num =    olo.customer_line_number
                                  AND xxedi.delivery_num = p_delivery_num
                                  AND xxedidet.delivery_num = p_delivery_num
                                  --  AND ol.ship_set_id IS NOT NULL
                                  --AND ol.split_from_line_id IS NULL
                                  AND msi.inventory_item_id =   olo.inventory_item_id
                                  AND msi.organization_id =        olo.ship_from_org_id
                                  AND oh.header_id = oho.header_id
                                  AND ol.line_id = olo.line_id
                                  AND wdd.delivery_detail_id =  wddi.delivery_detail_id
                                  AND nvl(xxedi.status, 'XX') !='PROCESSED' -- 'NEW'
                                   AND nvl( xxedidet.status, 'XX') !='PROCESSED' --'NEW'
                                  AND oho.order_type_id =  g_transaction_type_id
                            );

      CURSOR c_ord_details
      IS
         SELECT   oh.order_number,
                  oh.header_id,
                  ol.line_id,
                  ol.customer_line_number,
                  ol.ordered_quantity,
                  msi.inventory_item_id,
                  msi.primary_uom_code,
                  msi.organization_id,
                  wdd.delivery_detail_id,
                  xxedi.delivery_num,
                  xxedidet.line_num,
                  xxedidet.item_num,
                  xxedidet.item_qty,
                  xxedidet.item_uom,
                  xxedidet.lot_line_num,
                  xxedidet.lot_number,
                  xxedidet.lot_qty
           FROM   oe_order_headers_all oh,
                  oe_order_lines_all ol,
                  wsh_delivery_details wdd,
                  xxha_edi_856_delivery xxedi,
                  xxha_edi_856_delivery_details xxedidet,
                  mtl_system_items_b msi
          WHERE       wdd.source_header_id = oh.header_id
                  AND wdd.source_line_id = ol.line_id
                  AND oh.header_id = ol.header_id
                  AND NVL (ol.open_flag, 'N') = 'Y'
                  AND released_status NOT IN ('Y', 'C')
                  AND NVL (oh.open_flag, 'N') = 'Y'
                  AND oh.booked_flag = 'Y'
                  AND NVL (ol.cancelled_flag, 'N') <> 'Y'
                  AND ol.flow_status_code = 'AWAITING_SHIPPING'
                  AND xxedi.order_number = oh.order_number
                  AND xxedidet.line_num = ol.customer_line_number
                  AND xxedi.delivery_num = p_delivery_num
                  AND xxedidet.delivery_num = p_delivery_num
                  --AND ol.ship_set_id IS NOT NULL
                  AND ol.split_from_line_id IS NULL
                  AND msi.inventory_item_id = ol.inventory_item_id
                  AND msi.organization_id = ol.ship_from_org_id
                  AND nvl(xxedi.status, 'XX') !='PROCESSED' -- 'NEW'
                  AND nvl( xxedidet.status, 'XX') !='PROCESSED' --'NEW'
                  AND oh.order_type_id = g_transaction_type_id;

      CURSOR c_ord_details_ship
      IS
         SELECT   oh.order_number,
                  oh.header_id,
                  ol.line_id,
                  ol.customer_line_number,
                  ol.ordered_quantity,
                  ol.split_from_line_id,
                  msi.inventory_item_id,
                  msi.primary_uom_code,
                  msi.organization_id,
                  wdd.delivery_detail_id,
                  xxedi.delivery_num,
                  xxedidet.line_num,
                  xxedidet.item_num,
                  xxedidet.item_qty,
                  xxedidet.item_uom,
                  xxedidet.lot_line_num,
                  xxedidet.lot_number,
                  xxedidet.lot_qty
           FROM   oe_order_headers_all oh,
                  oe_order_lines_all ol,
                  wsh_delivery_details wdd,
                  xxha_edi_856_delivery xxedi,
                  xxha_edi_856_delivery_details xxedidet,
                  mtl_system_items_b msi
          WHERE       wdd.source_header_id = oh.header_id
                  AND wdd.source_line_id = ol.line_id
                  AND oh.header_id = ol.header_id
                  AND NVL (ol.open_flag, 'N') = 'Y'
                  AND released_status NOT IN ('Y', 'C')
                  AND NVL (oh.open_flag, 'N') = 'Y'
                  AND oh.booked_flag = 'Y'
                  AND NVL (ol.cancelled_flag, 'N') <> 'Y'
                  AND ol.flow_status_code = 'AWAITING_SHIPPING'
                  AND xxedi.order_number = oh.order_number
                  AND xxedidet.line_num = ol.customer_line_number
                  AND xxedi.delivery_num = xxedidet.delivery_num
                  AND xxedi.delivery_num = p_delivery_num
                  AND xxedidet.delivery_num = p_delivery_num
                  -- AND ol.ship_set_id IS NULL
                  AND ol.split_from_line_id IS NOT NULL
                  AND msi.inventory_item_id = ol.inventory_item_id
                  AND msi.organization_id = ol.ship_from_org_id
                  AND nvl(xxedi.status, 'XX') !='PROCESSED' -- 'NEW'
                  AND nvl( xxedidet.status, 'XX') !='PROCESSED' --'NEW'
                  AND oh.order_type_id = g_transaction_type_id
                  AND ol.split_from_line_id IN
                           (SELECT   line_id
                              FROM   oe_order_lines_all
                             WHERE   header_id = oh.header_id
                                     AND flow_status_code = 'CLOSED');
   BEGIN
  print_log ('Beginning of SPLIT_LINE procedure'||chr(10));

      FOR rec_ord_details_nf IN c_ord_details_nf
      LOOP
         l_line_tbl_index := 1;
         -- Changed attributes
         l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
         l_header_rec.header_id := rec_ord_details_nf.header_id;
         -- header_id of the order
         l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;
         l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
         l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_UPDATE;
         -- l_line_tbl (l_line_tbl_index).split_by := x_user_id;    -- user_id
         --  l_line_tbl (l_line_tbl_index).split_action_code := 'SPLIT';
         l_line_tbl (l_line_tbl_index).header_id :=            rec_ord_details_nf.header_id;
         -- header_id of the order
         l_line_tbl (l_line_tbl_index).line_id := rec_ord_details_nf.line_id;
         -- line_id of the order line
         --l_line_tbl (l_line_tbl_index).ordered_quantity :=
         -- rec_ord_details_nf.ordered_quantity;
         -- new ordered quantity
         l_line_tbl (l_line_tbl_index).ship_set := NULL;
         l_line_tbl (l_line_tbl_index).ship_set_id := NULL;

         -- l_line_tbl (l_line_tbl_index).schedule_ship_date := NULL;

         -- CALL TO PROCESS ORDER
         oe_msg_pub.initialize;
         XXHALOCKORDER (p_order_header_id, x_lockorder_return_status); -- lock the order
         OE_ORDER_PUB.process_order (
            p_api_version_number       => 1.0,
            p_init_msg_list            => fnd_api.g_false,
            p_return_values            => fnd_api.g_false,
            p_action_commit            => fnd_api.g_false,
            x_return_status            => l_return_status,
            x_msg_count                => l_msg_count,
            x_msg_data                 => l_msg_data,
            p_header_rec               => l_header_rec,
            p_line_tbl                 => l_line_tbl,
            p_action_request_tbl       => l_action_request_tbl, -- OUT PARAMETERS
            x_header_rec               => x_header_rec,
            x_header_val_rec           => x_header_val_rec,
            x_Header_Adj_tbl           => x_Header_Adj_tbl,
            x_Header_Adj_val_tbl       => x_Header_Adj_val_tbl,
            x_Header_price_Att_tbl     => x_Header_price_Att_tbl,
            x_Header_Adj_Att_tbl       => x_Header_Adj_Att_tbl,
            x_Header_Adj_Assoc_tbl     => x_Header_Adj_Assoc_tbl,
            x_Header_Scredit_tbl       => x_Header_Scredit_tbl,
            x_Header_Scredit_val_tbl   => x_Header_Scredit_val_tbl,
            x_line_tbl                 => x_line_tbl,
            x_line_val_tbl             => x_line_val_tbl,
            x_Line_Adj_tbl             => x_Line_Adj_tbl,
            x_Line_Adj_val_tbl         => x_Line_Adj_val_tbl,
            x_Line_price_Att_tbl       => x_Line_price_Att_tbl,
            x_Line_Adj_Att_tbl         => x_Line_Adj_Att_tbl,
            x_Line_Adj_Assoc_tbl       => x_Line_Adj_Assoc_tbl,
            x_Line_Scredit_tbl         => x_Line_Scredit_tbl,
            x_Line_Scredit_val_tbl     => x_Line_Scredit_val_tbl,
            x_Lot_Serial_tbl           => x_Lot_Serial_tbl,
            x_Lot_Serial_val_tbl       => x_Lot_Serial_val_tbl,
            x_action_request_tbl       => x_action_request_tbl
         );

         --  COMMIT;

         -- Retrieve messages
         FOR i IN 1 .. l_msg_count
         LOOP
            Oe_Msg_Pub.get (p_msg_index       => i,
                            p_encoded         => Fnd_Api.G_FALSE,
                            p_data            => l_msg_data,
                            p_msg_index_out   => l_msg_index_out);
         -- print_log('message is: ' || l_msg_data);
         -- print_log('message index is: ' || l_msg_index_out);
         x_api_msg := x_api_msg  || chr(10)||l_msg_count || ' : '||l_msg_data;
         END LOOP;
        print_log ('API error message is '||l_msg_data);
        print_log ('API error message is '||x_api_msg);
        print_log ('API return status '||l_return_status);

         -- Check the return status
         IF l_return_status = FND_API.G_RET_STS_SUCCESS
         THEN
            print_log ('Line Quantity Update Sucessful');
         ELSE
            ROLLBACK;
            x_sql_err_flag := 1;
            x_err_msg := x_err_msg || l_msg_data;
         END IF;
      /* IF x_sql_err_flag = 1
                                                                                                                                                                                  THEN
          INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                           ERROR_MESSAGE,
                                           CREATION_DATE,
                                           CREATED_BY,
                                           LAST_UPDATE_DATE,
                                           LAST_UPDATED_BY)
            VALUES   (g_delivery_num,
                      x_err_msg,
                      SYSDATE,
                      fnd_global.user_id,
                      SYSDATE,
                      fnd_global.user_id);
          UPDATE   xxha_edi_856_delivery
             SET   STATUS = 'ERROR'
           WHERE   delivery_num = g_delivery_num;
          UPDATE   xxha_edi_856_delivery_details
             SET   STATUS = 'ERROR'
           WHERE   delivery_num = g_delivery_num;
          COMMIT;
       END IF;*/
      --   END IF;

      END LOOP;

      --This is to UPDATE order line

      FOR rec_ord_details IN c_ord_details
      LOOP
         BEGIN
            SELECT   MAX (set_id)
              INTO   x_ship_set_id
              FROM   oe_sets
             WHERE   header_id = rec_ord_details.header_id;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg :=
                  x_err_msg || 'Error in deriving SHIP SET ID:' || '||';
         END;

         -- x_ship_set_id := g_delivery_num;

         IF rec_ord_details.item_qty < rec_ord_details.ordered_quantity
         THEN
            l_line_tbl_index := 1;
            -- Changed attributes
            l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
            l_header_rec.header_id := rec_ord_details.header_id;
            -- header_id of the order
            l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;
            l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
            l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_UPDATE;
            l_line_tbl (l_line_tbl_index).split_by := x_user_id;    -- user_id
            l_line_tbl (l_line_tbl_index).split_action_code := 'SPLIT';
            l_line_tbl (l_line_tbl_index).header_id :=               rec_ord_details.header_id;
            -- header_id of the order
            l_line_tbl (l_line_tbl_index).line_id := rec_ord_details.line_id;
            -- line_id of the order line
            l_line_tbl (l_line_tbl_index).ordered_quantity := rec_ord_details.item_qty;
          --  l_line_tbl (l_line_tbl_index).ship_set_id := x_ship_set_id;
            -- new ordered quantity
            l_line_tbl (l_line_tbl_index).change_reason :=  'Related PO changes';                     -- change reason code
            l_line_tbl_index := 2;
            l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
            l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_CREATE;
            l_line_tbl (l_line_tbl_index).split_by := x_user_id;    -- user_id
            l_line_tbl (l_line_tbl_index).split_action_code := 'SPLIT';
            l_line_tbl (l_line_tbl_index).split_from_line_id :=               rec_ord_details.line_id;
            -- line_id of  original line
            l_line_tbl (l_line_tbl_index).inventory_item_id :=               rec_ord_details.inventory_item_id;         -- inventory item id
            l_line_tbl (l_line_tbl_index).ordered_quantity :=               rec_ord_details.ordered_quantity - rec_ord_details.item_qty;
            -- ordered quantity
            -- CALL TO PROCESS ORDER
            --print_log ('Before 1. Line '||to_char(l_line_tbl (1).line_id)||' qty '||to_char(l_line_tbl (1).ordered_quantity));
            --print_log ('Before 2. qty '||to_char(l_line_tbl (2).line_id)||' qty '||to_char(l_line_tbl (2).ordered_quantity));

            oe_msg_pub.initialize;
            XXHALOCKORDER (p_order_header_id ,x_lockorder_return_status); -- lock the order
            OE_ORDER_PUB.process_order (
               p_api_version_number       => 1.0,
               p_init_msg_list            => fnd_api.g_false,
               p_return_values            => fnd_api.g_false,
               p_action_commit            => fnd_api.g_false,
               x_return_status            => l_return_status,
               x_msg_count                => l_msg_count,
               x_msg_data                 => l_msg_data,
               p_header_rec               => l_header_rec,
               p_line_tbl                 => l_line_tbl,
               p_action_request_tbl       => l_action_request_tbl,
               -- OUT PARAMETERS
               x_header_rec               => x_header_rec,
               x_header_val_rec           => x_header_val_rec,
               x_Header_Adj_tbl           => x_Header_Adj_tbl,
               x_Header_Adj_val_tbl       => x_Header_Adj_val_tbl,
               x_Header_price_Att_tbl     => x_Header_price_Att_tbl,
               x_Header_Adj_Att_tbl       => x_Header_Adj_Att_tbl,
               x_Header_Adj_Assoc_tbl     => x_Header_Adj_Assoc_tbl,
               x_Header_Scredit_tbl       => x_Header_Scredit_tbl,
               x_Header_Scredit_val_tbl   => x_Header_Scredit_val_tbl,
               x_line_tbl                 => x_line_tbl,
               x_line_val_tbl             => x_line_val_tbl,
               x_Line_Adj_tbl             => x_Line_Adj_tbl,
               x_Line_Adj_val_tbl         => x_Line_Adj_val_tbl,
               x_Line_price_Att_tbl       => x_Line_price_Att_tbl,
               x_Line_Adj_Att_tbl         => x_Line_Adj_Att_tbl,
               x_Line_Adj_Assoc_tbl       => x_Line_Adj_Assoc_tbl,
               x_Line_Scredit_tbl         => x_Line_Scredit_tbl,
               x_Line_Scredit_val_tbl     => x_Line_Scredit_val_tbl,
               x_Lot_Serial_tbl           => x_Lot_Serial_tbl,
               x_Lot_Serial_val_tbl       => x_Lot_Serial_val_tbl,
               x_action_request_tbl       => x_action_request_tbl
            );

            -- Retrieve messages
            FOR i IN 1 .. l_msg_count
            LOOP
               Oe_Msg_Pub.get (p_msg_index       => i,
                               p_encoded         => Fnd_Api.G_FALSE,
                               p_data            => l_msg_data,
                               p_msg_index_out   => l_msg_index_out);
            -- print_log('message is: ' || l_msg_data);
            -- print_log('message index is: ' || l_msg_index_out);
            x_api_msg := x_api_msg  || chr(10)||l_msg_count || ' : '||l_msg_data;
            END LOOP;

              print_log ('API error message is '||l_msg_data);
              print_log ('API error message is '||x_api_msg);
              print_log ('API return status '||l_return_status);

            --print_log ('After 1. Line '||to_char(l_line_tbl (1).line_id)||' qty '||to_char(l_line_tbl (1).ordered_quantity));
            --print_log ('After 2. qty '||to_char(l_line_tbl (2).line_id)||' qty '||to_char(l_line_tbl (2).ordered_quantity));

            -- Check the return status
            IF l_return_status = FND_API.G_RET_STS_SUCCESS
            THEN
               print_log ('Line Quantity Update Sucessful');
            ELSE
               ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg := x_err_msg || l_msg_data;
            END IF;
        /* Added by Manny for debug */
        /* removed debug
        declare
        cursor mc1 is select * from oe_order_lines_all where header_id = p_order_header_id;
        begin
        for ii in mc1 loop
          print_log ('1. Line Id'||to_char(ii.line_id)||'splitFrom'||to_char(ii.split_from_line_id)||'Line #'||to_char(ii.line_number)||'.'||to_char(ii.shipment_number)||'Qty'||to_char(ii.ordered_quantity));
        end loop;
        end;
        */
        /* Debug complete */
         /* IF x_sql_err_flag = 1
                                                                                                                                                                                                                                              THEN
             INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                              ERROR_MESSAGE,
                                              CREATION_DATE,
                                              CREATED_BY,
                                              LAST_UPDATE_DATE,
                                              LAST_UPDATED_BY)
               VALUES   (g_delivery_num,
                         x_err_msg,
                         SYSDATE,
                         fnd_global.user_id,
                         SYSDATE,
                         fnd_global.user_id);
             UPDATE   xxha_edi_856_delivery
                SET   STATUS = 'ERROR'
              WHERE   delivery_num = g_delivery_num;
             UPDATE   xxha_edi_856_delivery_details
                SET   STATUS = 'ERROR'
              WHERE   delivery_num = g_delivery_num;
             COMMIT;*/
         END IF;
    /*-- commented out by SF 3/19/13 as ship sets may not be used anymore
         BEGIN
            SELECT   MAX (set_id)
              INTO   x_ship_set_id
              FROM   oe_sets
             WHERE   header_id = rec_ord_details.header_id;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg :=
                  x_err_msg || 'Error in deriving SHIP SET ID:' || '||';
         END;
        */
         IF rec_ord_details.item_qty = rec_ord_details.ordered_quantity
         THEN
            l_line_tbl_index := 1;
            -- Changed attributes
            l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
            l_header_rec.header_id := rec_ord_details.header_id;
            -- header_id of the order
            l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;
            l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
            l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_UPDATE;
            -- l_line_tbl (l_line_tbl_index).split_by := x_user_id;    -- user_id
            --  l_line_tbl (l_line_tbl_index).split_action_code := 'SPLIT';
            l_line_tbl (l_line_tbl_index).header_id :=               rec_ord_details.header_id;
            -- header_id of the order
            l_line_tbl (l_line_tbl_index).line_id := rec_ord_details.line_id;
            -- line_id of the order line
            l_line_tbl (l_line_tbl_index).ordered_quantity :=               rec_ord_details.item_qty;
            -- new ordered quantity
          --  l_line_tbl (l_line_tbl_index).ship_set_id := x_ship_set_id;

            -- CALL TO PROCESS ORDER
            oe_msg_pub.initialize;
            XXHALOCKORDER (p_order_header_id, x_lockorder_return_status); -- lock the order
            OE_ORDER_PUB.process_order (
               p_api_version_number       => 1.0,
               p_init_msg_list            => fnd_api.g_false,
               p_return_values            => fnd_api.g_false,
               p_action_commit            => fnd_api.g_false,
               x_return_status            => l_return_status,
               x_msg_count                => l_msg_count,
               x_msg_data                 => l_msg_data,
               p_header_rec               => l_header_rec,
               p_line_tbl                 => l_line_tbl,
               p_action_request_tbl       => l_action_request_tbl, -- OUT PARAMETERS
               x_header_rec               => x_header_rec,
               x_header_val_rec           => x_header_val_rec,
               x_Header_Adj_tbl           => x_Header_Adj_tbl,
               x_Header_Adj_val_tbl       => x_Header_Adj_val_tbl,
               x_Header_price_Att_tbl     => x_Header_price_Att_tbl,
               x_Header_Adj_Att_tbl       => x_Header_Adj_Att_tbl,
               x_Header_Adj_Assoc_tbl     => x_Header_Adj_Assoc_tbl,
               x_Header_Scredit_tbl       => x_Header_Scredit_tbl,
               x_Header_Scredit_val_tbl   => x_Header_Scredit_val_tbl,
               x_line_tbl                 => x_line_tbl,
               x_line_val_tbl             => x_line_val_tbl,
               x_Line_Adj_tbl             => x_Line_Adj_tbl,
               x_Line_Adj_val_tbl         => x_Line_Adj_val_tbl,
               x_Line_price_Att_tbl       => x_Line_price_Att_tbl,
               x_Line_Adj_Att_tbl         => x_Line_Adj_Att_tbl,
               x_Line_Adj_Assoc_tbl       => x_Line_Adj_Assoc_tbl,
               x_Line_Scredit_tbl         => x_Line_Scredit_tbl,
               x_Line_Scredit_val_tbl     => x_Line_Scredit_val_tbl,
               x_Lot_Serial_tbl           => x_Lot_Serial_tbl,
               x_Lot_Serial_val_tbl       => x_Lot_Serial_val_tbl,
               x_action_request_tbl       => x_action_request_tbl
            );


            -- Retrieve messages
            FOR i IN 1 .. l_msg_count
            LOOP
               Oe_Msg_Pub.get (p_msg_index       => i,
                               p_encoded         => Fnd_Api.G_FALSE,
                               p_data            => l_msg_data,
                               p_msg_index_out   => l_msg_index_out);
            -- print_log('message is: ' || l_msg_data);
            -- print_log('message index is: ' || l_msg_index_out);
             x_api_msg := x_api_msg  || chr(10)||l_msg_count || ' : '||l_msg_data;
            END LOOP;

                    print_log ('API error message is '||l_msg_data);
        print_log ('API error message is '||x_api_msg);
        print_log ('API return status '||l_return_status);


            -- Check the return status
            IF l_return_status = FND_API.G_RET_STS_SUCCESS
            THEN
               print_log ('Line Quantity Update Sucessful');
            ELSE
               ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg := x_err_msg || l_msg_data;
            END IF;


         /* IF x_sql_err_flag = 1
                                                                                                                                                                                                                                              THEN
             INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                              ERROR_MESSAGE,
                                              CREATION_DATE,
                                              CREATED_BY,
                                              LAST_UPDATE_DATE,
                                              LAST_UPDATED_BY)
               VALUES   (g_delivery_num,
                         x_err_msg,
                         SYSDATE,
                         fnd_global.user_id,
                         SYSDATE,
                         fnd_global.user_id);
             UPDATE   xxha_edi_856_delivery
                SET   STATUS = 'ERROR'
              WHERE   delivery_num = g_delivery_num;
             UPDATE   xxha_edi_856_delivery_details
                SET   STATUS = 'ERROR'
              WHERE   delivery_num = g_delivery_num;
             COMMIT;
          END IF;*/
         END IF;
      END LOOP;

      --This is to UPDATE order line

      FOR rec_ord_details_ship IN c_ord_details_ship
      LOOP

         IF rec_ord_details_ship.item_qty <
               rec_ord_details_ship.ordered_quantity
         THEN
         /* -- commented out by SF 3/19/13 as ship set may is not used
            BEGIN
               SELECT   ship_set_id
                 INTO   x_ship_set_id
                 FROM   oe_order_lines_all
                WHERE   line_id = rec_ord_details_ship.split_from_line_id;
            EXCEPTION
               WHEN OTHERS
               THEN
                  x_sql_err_flag := 1;
                  x_err_msg :=
                     x_err_msg || 'Error in deriving SHIP SET ID:' || '||';
            END;
         */
            l_line_tbl_index := 1;
            -- Changed attributes
            l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
            l_header_rec.header_id := rec_ord_details_ship.header_id;
            -- header_id of the order
            l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;
            l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
            l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_UPDATE;
            l_line_tbl (l_line_tbl_index).split_by := x_user_id;    -- user_id
            l_line_tbl (l_line_tbl_index).split_action_code := 'SPLIT';
            l_line_tbl (l_line_tbl_index).header_id :=               rec_ord_details_ship.header_id;
            -- header_id of the order
            l_line_tbl (l_line_tbl_index).line_id :=               rec_ord_details_ship.line_id;
            -- line_id of the order line
            l_line_tbl (l_line_tbl_index).ordered_quantity :=               rec_ord_details_ship.item_qty;
            -- new ordered quantity
          --  l_line_tbl (l_line_tbl_index).ship_set_id := x_ship_set_id;
            --  l_line_tbl (l_line_tbl_index).ship_set := g_delivery_num;
            l_line_tbl (l_line_tbl_index).change_reason :=               'Related PO changes';
            l_line_tbl_index := 2;
            l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
            l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_CREATE;
            l_line_tbl (l_line_tbl_index).split_by := x_user_id;    -- user_id
            l_line_tbl (l_line_tbl_index).split_action_code := 'SPLIT';
            l_line_tbl (l_line_tbl_index).split_from_line_id :=               rec_ord_details_ship.line_id;
            -- line_id of  original line
            l_line_tbl (l_line_tbl_index).inventory_item_id :=               rec_ord_details_ship.inventory_item_id;    -- inventory item id
            l_line_tbl (l_line_tbl_index).ordered_quantity :=               rec_ord_details_ship.ordered_quantity
               - rec_ord_details_ship.item_qty;            -- ordered quantity

            -- CALL TO PROCESS ORDER
            oe_msg_pub.initialize;
            XXHALOCKORDER (p_order_header_id, x_lockorder_return_status); -- lock the order
            OE_ORDER_PUB.process_order (
               p_api_version_number       => 1.0,
               p_init_msg_list            => fnd_api.g_false,
               p_return_values            => fnd_api.g_false,
               p_action_commit            => fnd_api.g_false,
               x_return_status            => l_return_status,
               x_msg_count                => l_msg_count,
               x_msg_data                 => l_msg_data,
               p_header_rec               => l_header_rec,
               p_line_tbl                 => l_line_tbl,
               p_action_request_tbl       => l_action_request_tbl,
               -- OUT PARAMETERS
               x_header_rec               => x_header_rec,
               x_header_val_rec           => x_header_val_rec,
               x_Header_Adj_tbl           => x_Header_Adj_tbl,
               x_Header_Adj_val_tbl       => x_Header_Adj_val_tbl,
               x_Header_price_Att_tbl     => x_Header_price_Att_tbl,
               x_Header_Adj_Att_tbl       => x_Header_Adj_Att_tbl,
               x_Header_Adj_Assoc_tbl     => x_Header_Adj_Assoc_tbl,
               x_Header_Scredit_tbl       => x_Header_Scredit_tbl,
               x_Header_Scredit_val_tbl   => x_Header_Scredit_val_tbl,
               x_line_tbl                 => x_line_tbl,
               x_line_val_tbl             => x_line_val_tbl,
               x_Line_Adj_tbl             => x_Line_Adj_tbl,
               x_Line_Adj_val_tbl         => x_Line_Adj_val_tbl,
               x_Line_price_Att_tbl       => x_Line_price_Att_tbl,
               x_Line_Adj_Att_tbl         => x_Line_Adj_Att_tbl,
               x_Line_Adj_Assoc_tbl       => x_Line_Adj_Assoc_tbl,
               x_Line_Scredit_tbl         => x_Line_Scredit_tbl,
               x_Line_Scredit_val_tbl     => x_Line_Scredit_val_tbl,
               x_Lot_Serial_tbl           => x_Lot_Serial_tbl,
               x_Lot_Serial_val_tbl       => x_Lot_Serial_val_tbl,
               x_action_request_tbl       => x_action_request_tbl
            );

            -- Retrieve messages
            FOR i IN 1 .. l_msg_count
            LOOP
               Oe_Msg_Pub.get (p_msg_index       => i,
                               p_encoded         => Fnd_Api.G_FALSE,
                               p_data            => l_msg_data,
                               p_msg_index_out   => l_msg_index_out);
            -- print_log('message is: ' || l_msg_data);
            -- print_log('message index is: ' || l_msg_index_out);
                 x_api_msg := x_api_msg  || chr(10)||l_msg_count || ' : '||l_msg_data;
            END LOOP;

              print_log ('API error message is '||l_msg_data);
              print_log ('API error message is '||x_api_msg);
              print_log ('API return status '||l_return_status);

            -- Check the return status

            IF l_return_status = FND_API.G_RET_STS_SUCCESS
            THEN
               print_log ('Line Quantity Update Sucessful');
            ELSE
               ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg := x_err_msg || l_msg_data;
            END IF;
         /*IF x_sql_err_flag = 1
                                                                                                                                                                                                                                             THEN
            INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                             ERROR_MESSAGE,
                                             CREATION_DATE,
                                             CREATED_BY,
                                             LAST_UPDATE_DATE,
                                             LAST_UPDATED_BY)
              VALUES   (g_delivery_num,
                        x_err_msg,
                        SYSDATE,
                        fnd_global.user_id,
                        SYSDATE,
                        fnd_global.user_id);
            UPDATE   xxha_edi_856_delivery
               SET   STATUS = 'ERROR'
             WHERE   delivery_num = g_delivery_num;
            UPDATE   xxha_edi_856_delivery_details
               SET   STATUS = 'ERROR'
             WHERE   delivery_num = g_delivery_num;
            COMMIT;
         END IF;*/
         END IF;

         IF rec_ord_details_ship.item_qty =
               rec_ord_details_ship.ordered_quantity
         THEN
         /* commented out by SF 3/19/13 as ship set is not used
            BEGIN
               SELECT   ship_set_id
                 INTO   x_ship_set_id
                 FROM   oe_order_lines_all
                WHERE   line_id = rec_ord_details_ship.split_from_line_id;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  x_sql_err_flag := 1;
                  x_err_msg :=
                     x_err_msg || 'Error in deriving SHIP SET ID:' || '||';
            END;
          */
            l_line_tbl_index := 1;
            -- Changed attributes
            l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
            l_header_rec.header_id := rec_ord_details_ship.header_id;
            -- header_id of the order
            l_header_rec.operation := OE_GLOBALS.G_OPR_UPDATE;
            l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
            l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_UPDATE;
            -- l_line_tbl (l_line_tbl_index).split_by := x_user_id;    -- user_id
            --  l_line_tbl (l_line_tbl_index).split_action_code := 'SPLIT';
            l_line_tbl (l_line_tbl_index).header_id :=               rec_ord_details_ship.header_id;
            -- header_id of the order
            l_line_tbl (l_line_tbl_index).line_id :=               rec_ord_details_ship.line_id;
            -- line_id of the order line
            l_line_tbl (l_line_tbl_index).ordered_quantity :=               rec_ord_details_ship.item_qty;
            -- new ordered quantity
          --  l_line_tbl (l_line_tbl_index).ship_set_id := x_ship_set_id;
            -- l_line_tbl (l_line_tbl_index).ship_set := g_delivery_num;

            -- CALL TO PROCESS ORDER
            oe_msg_pub.initialize;
            XXHALOCKORDER (p_order_header_id, x_lockorder_return_status); -- lock the order
            OE_ORDER_PUB.process_order (
               p_api_version_number       => 1.0,
               p_init_msg_list            => fnd_api.g_false,
               p_return_values            => fnd_api.g_false,
               p_action_commit            => fnd_api.g_false,
               x_return_status            => l_return_status,
               x_msg_count                => l_msg_count,
               x_msg_data                 => l_msg_data,
               p_header_rec               => l_header_rec,
               p_line_tbl                 => l_line_tbl,
               p_action_request_tbl       => l_action_request_tbl -- OUT PARAMETERS
                                                                 ,
               x_header_rec               => x_header_rec,
               x_header_val_rec           => x_header_val_rec,
               x_Header_Adj_tbl           => x_Header_Adj_tbl,
               x_Header_Adj_val_tbl       => x_Header_Adj_val_tbl,
               x_Header_price_Att_tbl     => x_Header_price_Att_tbl,
               x_Header_Adj_Att_tbl       => x_Header_Adj_Att_tbl,
               x_Header_Adj_Assoc_tbl     => x_Header_Adj_Assoc_tbl,
               x_Header_Scredit_tbl       => x_Header_Scredit_tbl,
               x_Header_Scredit_val_tbl   => x_Header_Scredit_val_tbl,
               x_line_tbl                 => x_line_tbl,
               x_line_val_tbl             => x_line_val_tbl,
               x_Line_Adj_tbl             => x_Line_Adj_tbl,
               x_Line_Adj_val_tbl         => x_Line_Adj_val_tbl,
               x_Line_price_Att_tbl       => x_Line_price_Att_tbl,
               x_Line_Adj_Att_tbl         => x_Line_Adj_Att_tbl,
               x_Line_Adj_Assoc_tbl       => x_Line_Adj_Assoc_tbl,
               x_Line_Scredit_tbl         => x_Line_Scredit_tbl,
               x_Line_Scredit_val_tbl     => x_Line_Scredit_val_tbl,
               x_Lot_Serial_tbl           => x_Lot_Serial_tbl,
               x_Lot_Serial_val_tbl       => x_Lot_Serial_val_tbl,
               x_action_request_tbl       => x_action_request_tbl
            );


            -- Retrieve messages
            FOR i IN 1 .. l_msg_count
            LOOP
               Oe_Msg_Pub.get (p_msg_index       => i,
                               p_encoded         => Fnd_Api.G_FALSE,
                               p_data            => l_msg_data,
                               p_msg_index_out   => l_msg_index_out);
            -- print_log('message is: ' || l_msg_data);
            -- print_log('message index is: ' || l_msg_index_out);
               x_api_msg := x_api_msg  || chr(10)||l_msg_count || ' : '||l_msg_data;
            END LOOP;

              print_log ('API error message is '||l_msg_data);
              print_log ('API error message is '||x_api_msg);
              print_log ('API return status '||l_return_status);

            -- Check the return status

            IF l_return_status = FND_API.G_RET_STS_SUCCESS
            THEN
               print_log ('Line Quantity Update Sucessful');
            ELSE
               ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg := x_err_msg || l_msg_data;
            END IF;
         /* IF x_sql_err_flag = 1
                                                                                                             THEN
             INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                              ERROR_MESSAGE,
                                              CREATION_DATE,
                                              CREATED_BY,
                                              LAST_UPDATE_DATE,
                                              LAST_UPDATED_BY)
               VALUES   (g_delivery_num,
                         x_err_msg,
                         SYSDATE,
                         fnd_global.user_id,
                         SYSDATE,
                         fnd_global.user_id);
             UPDATE   xxha_edi_856_delivery
                SET   STATUS = 'ERROR'
              WHERE   delivery_num = g_delivery_num;
             UPDATE   xxha_edi_856_delivery_details
                SET   STATUS = 'ERROR'
              WHERE   delivery_num = g_delivery_num;
             COMMIT;
          END IF;*/
         END IF;
      END LOOP;

      COMMIT;
       print_log ('End of Procedure SPLIT_LINE '||chr(10));
END SPLIT_LINE;

   --Procedure to create hard reservations for the Lot Numbers -----------
   ----------------------------------------------------------------------------

PROCEDURE RESERVE_INVENTORY_API (p_inv_org_id in number
                                  ,p_inv_item_id in number
                                  ,p_source_header_id in number
                                  ,p_source_line_id in number
                                  ,p_primary_uom_code in varchar2
                                  ,p_reserve_qty in number
                                  ,p_lot_number in varchar2
                                  ,p_locator_id in number
                                  ,p_revision in varchar2
                                  ,p_subinv_code in varchar2
                                ,x_return_status in out varchar2) AS

      p_rsv                inv_reservation_global.mtl_reservation_rec_type;
      p_dummy_sn           inv_reservation_global.serial_number_tbl_type;
      x_msg_count          NUMBER DEFAULT 0 ;
      x_msg_data           VARCHAR2 (1000) DEFAULT NULL ;
      x_rsv_id             NUMBER;
      x_dummy_sn           inv_reservation_global.serial_number_tbl_type;
      x_status             VARCHAR2 (1);
      x_qty                NUMBER;
      x_user_id            NUMBER;
      x_resp_id            NUMBER;
      x_appl_id            NUMBER;
      x_lot_number         VARCHAR2 (150) DEFAULT NULL ;
      x_lot_qty            VARCHAR2 (150) DEFAULT NULL ;
      x_order_number       VARCHAR2 (150) DEFAULT NULL ;
      x_line_lot_number    VARCHAR2 (150) DEFAULT NULL ;
      x_location_id        NUMBER;
      x_source_header_id   NUMBER;
      x_revision           VARCHAR2 (150) DEFAULT NULL ;
      x_sub_code           VARCHAR2 (150) DEFAULT NULL ;
      x_sql_err_flag       NUMBER DEFAULT 0 ;
      x_err_msg            VARCHAR2 (2000) DEFAULT NULL ;
      x_total_qty          NUMBER DEFAULT 0 ;
      z_qty                NUMBER DEFAULT 0 ;
      x_rem_qty            NUMBER DEFAULT 0 ;
      x_message_list      Error_handler.Error_Tbl_Type;
      msg_index           number;
      l_process_msg       varchar2(4000);
      l_reserved_qty      number;
BEGIN
                       x_return_status:= 'S';
                       p_rsv.requirement_date := SYSDATE ;
                        --Clarify with Judy
                        p_rsv.organization_id :=        p_inv_org_id;
                        p_rsv.inventory_item_id :=p_inv_item_id ;
                        p_rsv.demand_source_type_id :=        inv_reservation_global.g_source_type_oe;
                        -- which is 2
                        p_rsv.demand_source_name := NULL;
                        p_rsv.demand_source_header_id := p_source_header_id;                        --mtl_sales_orders.sales_order_id
                        p_rsv.demand_source_line_id := p_source_line_id;                        -- oe_order_lines.line_id
                        p_rsv.primary_uom_code :=            p_primary_uom_code ;
                        p_rsv.attribute_category := NULL;
                        p_rsv.attribute1 := NULL;
                        p_rsv.attribute2 := NULL;
                        p_rsv.attribute3 := NULL;
                        p_rsv.attribute4 := NULL;
                        p_rsv.attribute5 := NULL;
                        p_rsv.attribute6 := NULL;
                        p_rsv.attribute7 := NULL;
                        p_rsv.attribute8 := NULL;
                        p_rsv.attribute9 := NULL;
                        p_rsv.attribute10 := NULL;
                        p_rsv.attribute11 := NULL;
                        p_rsv.attribute12 := NULL;
                        p_rsv.attribute13 := NULL;
                        p_rsv.attribute14 := NULL;
                        p_rsv.attribute15 := NULL;
                        p_rsv.ship_ready_flag := NULL;
                        p_rsv.demand_source_delivery := NULL;
                        p_rsv.lot_number_id := NULL;
                        p_rsv.pick_slip_number := NULL;
                        p_rsv.lpn_id := NULL;                         -- p_rsv.primary_uom_id := NULL;
                        p_rsv.reservation_uom_code :=    p_primary_uom_code ;
                        p_rsv.reservation_quantity :=p_reserve_qty;
                        p_rsv.primary_reservation_quantity :=p_reserve_qty;
                        p_rsv.lot_number := p_lot_number;                         --lot number
                        p_rsv.locator_id := p_locator_id;        --locator_id
                        p_rsv.supply_source_type_id :=                           inv_reservation_global.g_source_type_inv;
                        p_rsv.supply_source_name := NULL;
                        p_rsv.supply_source_LINE_ID := NULL;
                        p_rsv.supply_source_header_ID := NULL;
                        p_rsv.supply_source_line_detail := NULL;
                        p_rsv.autodetail_group_id := NULL;
                        p_rsv.external_source_code := NULL;
                        p_rsv.external_source_line_id := NULL;
                        p_rsv.reservation_uom_id := NULL;
                        P_RSV.subinventory_id := NULL;
                        p_rsv.revision := p_revision;
                        p_rsv.subinventory_code := p_subinv_code;
                        p_rsv.primary_uom_id := NULL;

                         fnd_msg_pub.initialize();
                         INV_QUANTITY_TREE_PVT.CLEAR_QUANTITY_CACHE; -- clear quantity tree cache
                        inv_reservation_pub.create_reservation (
                           p_api_version_number   => 1.0,
                           x_return_status        => x_status,
                           x_msg_count            => x_msg_count,
                           x_msg_data             => x_msg_data,
                           p_rsv_rec              => p_rsv,
                           p_serial_number        => p_dummy_sn,
                           x_serial_number        => x_dummy_sn,
                           x_quantity_reserved    => x_qty,
                           x_reservation_id       => x_rsv_id
                        );

                        print_log (                           'Return status (call 1)   = ' || x_status                        );
                        print_log (                           'msg count        = ' || TO_CHAR (x_msg_count)                        );

                        print_log (                           'Quantity reserved = ' || TO_CHAR (x_qty)                        );
                        print_log (                           'Reservation id   = ' || TO_CHAR (x_rsv_id)                        );
                          if x_status <> fnd_api.g_ret_sts_success then

                            x_return_status:= 'F';

                          else
                            if x_return_status <> 'F' then
                              x_return_status:= 'S';
                            end if;
                          end if;
                     --     print_log ('x_retrn_status '||x_return_status);



                        IF x_msg_count >= 1
                        THEN
                           --  ROLLBACK;
                           x_err_msg :=null;
                           FOR I IN 1 .. x_msg_count
                           LOOP
                              x_msg_data :=
                                 FND_MSG_PUB.GET (FND_MSG_PUB.G_NEXT,
                                                  FND_API.G_FALSE);
                                        x_err_msg := x_err_msg ||chr(10)|| x_msg_data;
                           END LOOP;

                           --ROLLBACK;
                       ELSE
                          print_log ('error message '||x_msg_data);
                        END IF;
                        print_log ('API error message is '||x_err_msg);


END RESERVE_INVENTORY_API;

-------------------------
-- procedure to delete all inventory reservations against a sales order line
----------------

PROCEDURE     DELETE_INV_RESERVATION (p_delivery_num in varchar2
                                      ) AS

l_reservation_id number default 0;

      CURSOR c_ord_details
      IS
         SELECT   distinct
                  ol.line_id,
                  msi.inventory_item_id,
                  msi.organization_id
           FROM   oe_order_headers_all oh,
                  oe_order_lines_all ol,
                  wsh_delivery_details wdd,
                  xxha_edi_856_delivery xxedi,
                  xxha_edi_856_delivery_details xxedidet,
                  mtl_system_items_b msi
          WHERE       wdd.source_header_id = oh.header_id
                  AND wdd.source_line_id = ol.line_id
                  AND oh.header_id = ol.header_id
                  AND NVL (ol.open_flag, 'N') = 'Y'
                  AND released_status NOT IN ('Y', 'C')
                  AND NVL (oh.open_flag, 'N') = 'Y'
                  AND oh.booked_flag = 'Y'
                  AND NVL (ol.cancelled_flag, 'N') <> 'Y'
                  AND ol.flow_status_code = 'AWAITING_SHIPPING'
                  AND xxedi.order_number = oh.order_number
                  AND xxedi.delivery_num = xxedidet.delivery_num
                  AND xxedidet.line_num = ol.customer_line_number
                  AND xxedi.delivery_num = p_delivery_num
                  AND xxedidet.delivery_num = p_delivery_num
                  AND msi.inventory_item_id = ol.inventory_item_id
                  AND msi.organization_id = ol.ship_from_org_id
                  AND nvl(xxedi.status, 'XX') !='PROCESSED' -- 'NEW'
                  AND nvl( xxedidet.status, 'XX') !='PROCESSED' --'NEW'
                  and ol.ordered_quantity = to_number(xxedidet.item_qty) -- this will match the order line with qty also. will select the correct line in case of line split
                  AND oh.order_type_id = g_transaction_type_id;


  x_return_status varchar2(1);
        p_rsv                inv_reservation_global.mtl_reservation_rec_type;
      p_dummy_sn           inv_reservation_global.serial_number_tbl_type;
      x_msg_count          NUMBER DEFAULT 0 ;
      x_msg_data           VARCHAR2 (1000) DEFAULT NULL ;
      x_rsv_id             NUMBER;
      x_dummy_sn           inv_reservation_global.serial_number_tbl_type;
      x_err_msg         varchar2(4000);
      p_primary_relieved_quantity number;
      x_primary_remain_qty number;
      x_relieved_qty  number;
      x_source_header_id number;

BEGIN


           -----------------------------------------------------------------------------------------------------
            --- get the sales_order_id from mtl_sales_orders table which will be passed as one of the input params-
            ---------------------------------------------------------------------------------------------------------
         BEGIN
            SELECT   sales_order_id
              INTO   x_source_header_id
              FROM   mtl_sales_orders
             WHERE   SEGMENT1 = g_order_number
                     AND segment2 = g_txn_name;
         EXCEPTION
            WHEN OTHERS
            THEN null;
         END;

    for cur_lines in c_ord_details loop

        begin
          select reservation_id into l_reservation_id
            from mtl_reservations
            where demand_source_type_id = 2
            and organization_id = cur_lines.organization_id
            and inventory_item_id =cur_lines.inventory_item_id
            and demand_source_header_id =x_source_header_id
            and demand_source_line_id  =cur_lines.line_id
            ;
                p_rsv.reservation_id:= l_reservation_id;

                      print_log(chr(10));
                   print_log ('Deleting Reservation id '||l_reservation_id ||' for order line id '||cur_lines.line_id);

                         fnd_msg_pub.initialize();

                         inv_reservation_pub.delete_reservation
                                    (
                                       p_api_version_number       => 1.0
                                     , p_init_msg_lst             =>  fnd_api.g_false
                                     , x_return_status            => x_return_status
                                     , x_msg_count                => x_msg_count
                                     , x_msg_data                 => x_msg_data
                                     , p_rsv_rec=> p_rsv
                                     , p_serial_number=> p_dummy_sn
                                     );
                                     /*
                                    inv_reservation_pub.relieve_reservation
                                          (
                                             p_api_version_number        => 1.0
                                           , p_init_msg_lst              => fnd_api.g_true
                                          , x_return_status            => x_return_status
                                          , x_msg_count                => x_msg_count
                                          , x_msg_data                 => x_msg_data
                                           , p_rsv_rec=> p_rsv
                                           , p_primary_relieved_quantity => p_primary_relieved_quantity
                                           , p_relieve_all             =>  fnd_api.g_true
                                           , p_original_serial_number=> p_dummy_sn
                                           , p_validation_flag           =>  fnd_api.g_true
                                           , x_primary_relieved_quantity => x_relieved_qty
                                           , x_primary_remain_quantity  => x_primary_remain_qty
                                           );
                                    */
                                    print_log ('return status (delete reservation) '|| x_return_status);
                                    print_log ('return msg count (delete reservation) '|| x_msg_count);


                       IF x_msg_count > 1
                        THEN
                           --  ROLLBACK;
                           x_err_msg :=null;
                           FOR I IN 1 .. x_msg_count
                           LOOP
                              x_msg_data :=
                                 FND_MSG_PUB.GET (FND_MSG_PUB.G_NEXT,
                                                  FND_API.G_FALSE);
                                        x_err_msg := x_err_msg ||chr(10)|| x_msg_data;
                           END LOOP;
                        ELSE
                        print_log ('return msg data  (delete reservation) '|| x_msg_data);

                        END IF;
                       print_log ('API error message (delete reservation) is '||x_err_msg||chr(10));


        exception when others then null;
        end;
  end loop;


END      DELETE_INV_RESERVATION ;


PROCEDURE RESERVE_INVENTORY (p_delivery_num IN VARCHAR2
                            ,x_return_status in out varchar2)
   IS
      ----------------------------------------
      -----------Declare local variables-----
      -----------------------------------------
      p_rsv                inv_reservation_global.mtl_reservation_rec_type;
      p_dummy_sn           inv_reservation_global.serial_number_tbl_type;
      x_msg_count          NUMBER DEFAULT 0 ;
      x_msg_data           VARCHAR2 (1000) DEFAULT NULL ;
      x_rsv_id             NUMBER;
      x_dummy_sn           inv_reservation_global.serial_number_tbl_type;
      x_status             VARCHAR2 (1);
      x_qty                NUMBER;
      x_user_id            NUMBER;
      x_resp_id            NUMBER;
      x_appl_id            NUMBER;
      x_lot_number         VARCHAR2 (150) DEFAULT NULL ;
      x_lot_qty            VARCHAR2 (150) DEFAULT NULL ;
      x_order_number       VARCHAR2 (150) DEFAULT NULL ;
      x_line_lot_number    VARCHAR2 (150) DEFAULT NULL ;
      x_location_id        NUMBER;
      x_source_header_id   NUMBER;
      x_revision           VARCHAR2 (150) DEFAULT NULL ;
      x_sub_code           VARCHAR2 (150) DEFAULT NULL ;
      x_sql_err_flag       NUMBER DEFAULT 0 ;
      x_err_msg            VARCHAR2 (2000) DEFAULT NULL ;
      x_total_qty          NUMBER DEFAULT 0 ;
      z_qty                NUMBER DEFAULT 0 ;
      x_rem_qty            NUMBER DEFAULT 0 ;
      x_qty_api_call      NUMBER DEFAULT 0;
      x_message_list      Error_handler.Error_Tbl_Type;
      msg_index           number;
      l_process_msg       varchar2(4000);
      l_reserved_qty      number;
      xl_return_status    varchar2(1):=null;
      l_previous_line_id    number;
      l_loop_cntr           number:=0;

      ----------------------------------------------------------
      -----------Declare cursor for prcoessing records-----
      ---------------------------------------------------------
      CURSOR c_ord_details
      IS
         SELECT   oh.order_number,
                  oh.header_id,
                  ol.line_id,
                  ol.customer_line_number,
                  ol.ordered_quantity,
                  msi.inventory_item_id,
                  msi.primary_uom_code,
                  msi.organization_id,
                  wdd.delivery_detail_id,
                  xxedi.delivery_num,
                  xxedidet.line_num,
                  xxedidet.item_num,
                  xxedidet.item_qty,
                  xxedidet.item_uom,
                  xxedidet.lot_line_num,
                  xxedidet.lot_number,
                  xxedidet.lot_qty, msi.segment1 item_number, ol.line_number
           FROM   oe_order_headers_all oh,
                  oe_order_lines_all ol,
                  wsh_delivery_details wdd,
                  xxha_edi_856_delivery xxedi,
                  xxha_edi_856_delivery_details xxedidet,
                  mtl_system_items_b msi
          WHERE       wdd.source_header_id = oh.header_id
                  AND wdd.source_line_id = ol.line_id
                  AND oh.header_id = ol.header_id
                  AND NVL (ol.open_flag, 'N') = 'Y'
                  AND released_status NOT IN ('Y', 'C')
                  AND NVL (oh.open_flag, 'N') = 'Y'
                  AND oh.booked_flag = 'Y'
                  AND NVL (ol.cancelled_flag, 'N') <> 'Y'
                  AND ol.flow_status_code = 'AWAITING_SHIPPING'
                  AND xxedi.order_number = oh.order_number
                  AND xxedi.delivery_num = xxedidet.delivery_num
                  AND xxedidet.line_num = ol.customer_line_number
                  AND xxedi.delivery_num = p_delivery_num
                  AND xxedidet.delivery_num = p_delivery_num
                  AND msi.inventory_item_id = ol.inventory_item_id
                  AND msi.organization_id = ol.ship_from_org_id
                  AND nvl(xxedi.status, 'XX') !='PROCESSED' -- 'NEW'
                  AND nvl( xxedidet.status, 'XX') !='PROCESSED' --'NEW'
                  and ol.ordered_quantity = to_number(xxedidet.item_qty) -- this will match the order line with qty also. will select the correct line in case of line split
                  AND oh.order_type_id = g_transaction_type_id;
   BEGIN
    print_log ('Begin to reserve inventory '||chr(10));
    x_return_status:= 'S';


            --------------------------
            ----Delete Inventory Reservation for all matching order lines. Delete any sales order reservation
            -- against this particular order line
            -- need to do this before we open the lines cursor. otherwise it will delete reservations when the same
            -- line is shipped from multiple lots

                DELETE_INV_RESERVATION (p_delivery_num => p_delivery_num
                                      );
            -----------------


      FOR rec_ord_details IN c_ord_details
      LOOP

        print_log ('order header id '|| rec_ord_details.header_id || ' order line id '||rec_ord_details.line_id||
        ' order line # '||rec_ord_details.line_number||' cust po line # '||rec_ord_details.customer_line_number
        || ' lot number '|| rec_ord_details.lot_number ||' lot qty '||rec_ord_details.lot_qty
        ||' order qty ' || rec_ord_details.ordered_quantity||chr(10));
        -- get the existing material reservations for this order and order line

                    l_reserved_qty :=    reserve_qty (p_org_id => rec_ord_details.organization_id
                                            ,p_inv_item_id => rec_ord_details.inventory_item_id
                                            ,p_demand_source_header_id => rec_ord_details.header_id
                                            ,p_demand_source_line_id => rec_ord_details.line_id
                                            ,p_reservation_uom_code => rec_ord_details.item_uom
                                            ,p_lot_number => rec_ord_details.lot_number
                                            ) ;
              print_log (' Total Reserved qty '||l_reserved_qty  ||' for lot '|| rec_ord_details.lot_number
              ||' for item '|| rec_ord_details.item_number || ' for order header id '||rec_ord_details.header_id
              ||' for order line id '|| rec_ord_details.line_id || ' for reservation item uom '||rec_ord_details.item_uom);

        -- get the existing material reservations for this org item across orders for a specific lot number

                    l_reserved_qty :=    reserve_qty (p_org_id => rec_ord_details.organization_id
                                            ,p_inv_item_id => rec_ord_details.inventory_item_id
                                            ,p_demand_source_header_id => null
                                            ,p_demand_source_line_id =>  null
                                            ,p_reservation_uom_code => rec_ord_details.item_uom
                                            ,p_lot_number => rec_ord_details.lot_number
                                            ) ;

              print_log (' Total Reserved qty '||l_reserved_qty  ||' for lot '|| rec_ord_details.lot_number
              ||' for item '|| rec_ord_details.item_number || ' for all order lines  with reservation item uom  '||rec_ord_details.item_uom||' for lot number '||rec_ord_details.lot_number||chr(10));
        -- get the existing material reservations for this org item across orders for all lot numbers

                    l_reserved_qty :=    reserve_qty (p_org_id => rec_ord_details.organization_id
                                            ,p_inv_item_id => rec_ord_details.inventory_item_id
                                            ,p_demand_source_header_id => null
                                            ,p_demand_source_line_id =>  null
                                            ,p_reservation_uom_code => rec_ord_details.item_uom
                                            ,p_lot_number => null
                                            ) ;

              print_log (' Total Reserved qty '||l_reserved_qty  ||' for lot '|| rec_ord_details.lot_number
              ||' for item '|| rec_ord_details.item_number || ' for all order lines in all lot numbers with reservation item uom '||rec_ord_details.item_uom||chr(10));

         BEGIN
            -----------------------------------------------------------------------------------------------------
            --- get the sales_order_id from mtl_sales_orders table which will be passed as one of the input params-
            ---------------------------------------------------------------------------------------------------------
            SELECT   sales_order_id, segment1
              INTO   x_source_header_id, x_order_number
              FROM   mtl_sales_orders
             WHERE   SEGMENT1 =
                        (SELECT   TO_CHAR (oh.order_number)
                           FROM   OE_ORDER_HEADERS_ALL oh
                          WHERE   oh.order_number =                                     rec_ord_details.order_number
                                  AND oh.order_type_id =                                        g_transaction_type_id)
                     AND segment2 = g_txn_name;
         EXCEPTION
            WHEN OTHERS
            THEN
               -- ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg :=
                  x_err_msg
                  || 'Error in deriving Sales Order information from MTL_SALES_ORDERS during reservation:'
                  || '||';
         END;

         BEGIN
            SELECT   SUM (primary_transaction_quantity)
              INTO   x_total_qty
              FROM   mtl_onhand_quantities_detail
             WHERE   inventory_item_id = rec_ord_details.inventory_item_id
                     AND organization_id = rec_ord_details.organization_id
                     AND lot_number = rec_ord_details.lot_number
                     AND subinventory_code = g_subinv;

            IF x_total_qty = 0
            THEN
               x_sql_err_flag := 1;
               x_err_msg :=
                  x_err_msg
                  || 'Error in deriving total onhand qty for Lot Number during reservation:'
                  || '||';
            END IF;
         END;



         BEGIN
            ------------------------------------------------------
            --- Derive Locator information for the given Lot----------
            ----------------------------------------------------
            SELECT   locator_id, revision, subinventory_code
              INTO   x_location_id, x_revision, x_sub_code
              FROM   (  SELECT   locator_id, revision, subinventory_code
                          FROM   mtl_onhand_quantities_detail
                         WHERE   inventory_item_id =                                     rec_ord_details.inventory_item_id
                                 AND organization_id =                                       rec_ord_details.organization_id
                                 AND lot_number = rec_ord_details.lot_number
                                 AND primary_transaction_quantity >=                                        rec_ord_details.lot_qty
                                 AND subinventory_code = g_subinv
                      ORDER BY   primary_transaction_quantity DESC)
             WHERE   ROWNUM = 1;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               IF x_total_qty > rec_ord_details.lot_qty
               THEN
                  FOR i
                  IN (  SELECT   primary_transaction_quantity,
                                 locator_id,
                                 revision,
                                 subinventory_code
                          FROM   mtl_onhand_quantities_detail
                         WHERE   inventory_item_id =
                                    rec_ord_details.inventory_item_id
                                 AND organization_id =
                                       rec_ord_details.organization_id
                                 AND lot_number = rec_ord_details.lot_number
                                 AND subinventory_code = g_subinv
                      ORDER BY   primary_transaction_quantity DESC)
                  LOOP
                     x_qty := x_qty + i.primary_transaction_quantity;
                     x_rem_qty := rec_ord_details.lot_qty - x_qty;

                     IF x_qty < rec_ord_details.lot_qty
                     THEN
                          x_qty_api_call:= x_qty;

                          print_log ('Inside IF x_qty < rec_ord_details.lot_qty . quantity send to reserve api is '||x_qty_api_call);


                          RESERVE_INVENTORY_API (p_inv_org_id => rec_ord_details.organization_id
                                      ,p_inv_item_id => rec_ord_details.inventory_item_id
                                      ,p_source_header_id => x_source_header_id
                                      ,p_source_line_id => rec_ord_details.line_id
                                      ,p_primary_uom_code => rec_ord_details.primary_uom_code
                                      ,p_reserve_qty => x_qty
                                      ,p_lot_number => rec_ord_details.lot_number
                                      ,p_locator_id =>  x_location_id
                                      ,p_revision => x_revision
                                      ,p_subinv_code => x_sub_code
                                    ,x_return_status =>  xl_return_status);


                               if xl_return_status <> fnd_api.g_ret_sts_success then

                                x_return_status:= 'F';

                              else
                                if x_return_status <> 'F' then
                                  x_return_status:= 'S';
                                end if;
                              end if;
                              print_log ('x_return_status for calling program '||x_return_status);


                     END IF;

                     IF x_rem_qty < i.primary_transaction_quantity
                     THEN

                         x_qty_api_call:=x_rem_qty;

                          print_log ('Inside IF x_rem_qty < i.primary_transaction_quantity. quantity send to reserve api is '||x_qty_api_call);

                          RESERVE_INVENTORY_API (p_inv_org_id => rec_ord_details.organization_id
                                      ,p_inv_item_id => rec_ord_details.inventory_item_id
                                      ,p_source_header_id => x_source_header_id
                                      ,p_source_line_id => rec_ord_details.line_id
                                      ,p_primary_uom_code => rec_ord_details.primary_uom_code
                                      ,p_reserve_qty => x_rem_qty
                                      ,p_lot_number => rec_ord_details.lot_number
                                      ,p_locator_id =>  x_location_id
                                      ,p_revision => x_revision
                                      ,p_subinv_code => x_sub_code
                                    ,x_return_status =>  xl_return_status);


                               if xl_return_status <> fnd_api.g_ret_sts_success then

                                x_return_status:= 'F';

                              else
                                if x_return_status <> 'F' then
                                  x_return_status:= 'S';
                                end if;
                              end if;
                              print_log ('x_return_status for calling program '||x_return_status);



                     END IF;

                     IF x_qty + x_rem_qty = rec_ord_details.lot_qty
                     THEN
                        EXIT;
                     END IF;

                  END LOOP;

               END IF;

            WHEN OTHERS
            THEN
               ROLLBACK;
               x_sql_err_flag := 1;
               x_err_msg :=
                  x_err_msg
                  || 'Error in deriving locator information during reservation:'
                  || '||';
         END;
         ---END OF EXCEPTION BLOCK

                         x_qty_api_call:=rec_ord_details.lot_qty;

                          print_log ('Inside loqt qty sufficient to satisfy order line. quantity send to reserve api is '||x_qty_api_call);

                          RESERVE_INVENTORY_API (p_inv_org_id => rec_ord_details.organization_id
                                      ,p_inv_item_id => rec_ord_details.inventory_item_id
                                      ,p_source_header_id => x_source_header_id
                                      ,p_source_line_id => rec_ord_details.line_id
                                      ,p_primary_uom_code => rec_ord_details.primary_uom_code
                                      ,p_reserve_qty => rec_ord_details.lot_qty
                                      ,p_lot_number => rec_ord_details.lot_number
                                      ,p_locator_id =>  x_location_id
                                      ,p_revision => x_revision
                                      ,p_subinv_code => x_sub_code
                                    ,x_return_status =>  xl_return_status);


                               if xl_return_status <> fnd_api.g_ret_sts_success then

                                x_return_status:= 'F';

                              else
                                if x_return_status <> 'F' then
                                  x_return_status:= 'S';
                                end if;
                              end if;
                              print_log ('x_return_status for calling program '||x_return_status);






        l_previous_line_id:= rec_ord_details.line_id;

      END LOOP;
               COMMIT;
      print_log ('end procedure reserve inventory '||chr(10));
END RESERVE_INVENTORY;

PROCEDURE PICKCONFIRM (p_move_order_number IN VARCHAR2, x_return_status in out varchar2)
   IS
      l_api_version            NUMBER := 1.0;
      l_init_msg_list          VARCHAR2 (2) := fnd_api.g_false;
      l_commit                 VARCHAR2 (2) := fnd_api.g_false;
   --   x_return_status          VARCHAR2 (2);
      x_msg_count              NUMBER DEFAULT 0 ;
      x_msg_data               VARCHAR2 (1000) DEFAULT NULL ;
      l_move_order_type        NUMBER := 1;
      l_transaction_mode       NUMBER := 1;
      l_trolin_tbl             inv_move_order_pub.trolin_tbl_type;
      l_mold_tbl               inv_mo_line_detail_util.g_mmtt_tbl_type;
      x_mmtt_tbl               inv_mo_line_detail_util.g_mmtt_tbl_type;
      x_trolin_tbl             inv_move_order_pub.trolin_tbl_type;
      l_transaction_date       DATE := SYSDATE;
      l_user_id                NUMBER;
      l_resp_id                NUMBER;
      l_appl_id                NUMBER;
      x_transaction_temp_id    NUMBER;
      x_number_of_rows         NUMBER;
      x_transfer_to_location   NUMBER;
      x_expiration_date        DATE;
      x_sql_err_flag           NUMBER DEFAULT 0 ;
      x_err_msg                VARCHAR2 (4000) DEFAULT NULL ;

      CURSOR c_mo_details
      IS
         SELECT   mtrh.header_id,
                  mtrh.request_number,
                  mtrh.move_order_type,
                  mtrh.organization_id,
                  mtrl.line_id,
                  mtrl.line_number,
                  mtrl.inventory_item_id,
                  mtrl.lot_number,
                  mtrl.quantity,
                  revision,
                  mtrl.from_locator_id,
                  (SELECT   DISTINCT operating_unit
                     FROM   org_organization_definitions
                    WHERE   organization_id = mtrh.organization_id)
                     org_id
           FROM   mtl_txn_request_headers mtrh, mtl_txn_request_lines mtrl
          WHERE   mtrh.header_id = mtrl.header_id
                  AND mtrh.request_number = p_move_order_number;
   -------------------------------------------------------------------------------------------------------------
BEGIN
    print_log ('Beginning of procedure PICKCONFIRM'||chr(10));

      FOR i IN c_mo_details
      LOOP
         l_trolin_tbl (1).line_id := i.line_id;

         -- call API to create move order header
         SELECT   COUNT ( * )
           INTO   x_number_of_rows
           FROM   mtl_txn_request_lines
          WHERE   header_id = i.header_id;

         print_log (            'Calling INV_REPLENISH_DETAIL_PUB to Allocate Mover Order '         );
         -- Allocate each line of the Move Order
         fnd_msg_pub.initialize();
         inv_replenish_detail_pub.line_details_pub (
            p_line_id                 => i.line_id,
            x_number_of_rows          => x_number_of_rows,
            x_detailed_qty            => i.quantity,
            x_return_status           => x_return_status,
            x_msg_count               => x_msg_count,
            x_msg_data                => x_msg_data,
            x_revision                => i.revision,
            x_locator_id              => i.from_locator_id,
            x_transfer_to_location    => x_transfer_to_location,
            x_lot_number              => i.lot_number,
            x_expiration_date         => x_expiration_date,
            x_transaction_temp_id     => x_transaction_temp_id,
            p_transaction_header_id   => NULL,
            p_transaction_mode        => NULL,
            p_move_order_type         => i.move_order_type,
            p_serial_flag             => fnd_api.g_false,
            p_plan_tasks              => FALSE,
            p_auto_pick_confirm       => FALSE,
            p_commit                  => FALSE
         );
         print_log (            '=========================================================='         );
         print_log ('api return status '||x_return_status);
     --    print_log ('api message data '||x_msg_data);
         print_log ('api msg count '||x_msg_count);

         IF (x_return_status <> fnd_api.g_ret_sts_success)
         THEN
            x_sql_err_flag := 1;
            ROLLBACK;
         --   x_err_msg := x_err_msg || x_msg_data;
          --  print_log (x_msg_data);
          EXIT;
         END IF;

         IF (x_return_status = fnd_api.g_ret_sts_success)
         THEN
            print_log (               'ALLOCATE API SUCCESSFUL WITH - Trx temp ID: '            );
            print_log ('Transaction temp id '||x_transaction_temp_id);
         END IF;

         IF x_transaction_temp_id is null then
            x_return_status:= 'E';
            EXIT;
        END IF;

    IF x_msg_count >= 1
           THEN
             --  ROLLBACK;
              x_err_msg:=null;
              FOR I IN 1 .. x_msg_count
              LOOP
                 x_msg_data :=
                    FND_MSG_PUB.GET (FND_MSG_PUB.G_NEXT, FND_API.G_FALSE);
                      x_err_msg := x_err_msg || chr(10)||I||' : '||x_msg_data;
              END LOOP;


    END IF;
           print_log ('API msg data         = ' || x_err_msg);
         print_log (            '=========================================================='         );

         IF x_transaction_temp_id IS NOT NULL OR x_transaction_temp_id <> 0
         THEN
            print_log (               '======================================================='            );
            print_log (               'Calling INV_Pick_Wave_Pick_Confirm_PUB.Pick_Confirm API'            );

            fnd_msg_pub.initialize();
            inv_pick_wave_pick_confirm_pub.pick_confirm (
               p_api_version_number   => l_api_version,
               p_init_msg_list        => l_init_msg_list,
               p_commit               => l_commit,
               x_return_status        => x_return_status,
               x_msg_count            => x_msg_count,
               x_msg_data             => x_msg_data,
               p_move_order_type      => i.move_order_type,
               p_transaction_mode     => l_transaction_mode,
               p_trolin_tbl           => l_trolin_tbl,
               p_mold_tbl             => l_mold_tbl,
               x_mmtt_tbl             => x_mmtt_tbl,
               x_trolin_tbl           => x_trolin_tbl,
               p_transaction_date     => l_transaction_date
            );

            print_log (               '======================================================='            );
         print_log ('api return status '||x_return_status);
      --   print_log ('api message data '||x_msg_data);
         print_log ('api msg count '||x_msg_count);

                IF x_msg_count >= 1
                       THEN
                         --  ROLLBACK;
                          x_err_msg:=null;
                          FOR I IN 1 .. x_msg_count
                          LOOP
                             x_msg_data :=
                                FND_MSG_PUB.GET (FND_MSG_PUB.G_NEXT, FND_API.G_FALSE);
                                  x_err_msg := x_err_msg || chr(10)||I||' : '||x_msg_data;
                          END LOOP;


                END IF;
                print_log ('API msg data         = ' || x_err_msg);

                        IF (x_return_status <> fnd_api.g_ret_sts_success)
                        THEN
                           print_log (x_msg_data);
                           x_sql_err_flag := 1;
                            ROLLBACK;
                        -- x_err_msg := x_err_msg || x_msg_data;
                        END IF;

            print_log (               '======================================================='            );

         ELSE
            print_log ('PICK CONFIRM API WAS NOT CALLED because MTL Transaction temp id did not return a value');

         END IF;
      END LOOP;

      /*   IF x_sql_err_flag = 1
                                             THEN
            INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                             ERROR_MESSAGE,
                                             CREATION_DATE,
                                             CREATED_BY,
                                             LAST_UPDATE_DATE,
                                             LAST_UPDATED_BY)
              VALUES   (g_delivery_num,
                        x_err_msg,
                        SYSDATE,
                        fnd_global.user_id,
                        SYSDATE,
                        fnd_global.user_id);
            UPDATE   xxha_edi_856_delivery
               SET   STATUS = 'ERROR'
             WHERE   delivery_num = g_delivery_num;
            UPDATE   xxha_edi_856_delivery_details
               SET   STATUS = 'ERROR'
             WHERE   delivery_num = g_delivery_num;
         END IF;*/

      COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
         print_log ('Exception Occured in procedure PICKCONFIRM :');
         print_log (SQLCODE || ':' || SQLERRM);
         print_log (
            '======================================================='
         );
END PICKCONFIRM;

PROCEDURE SHIPCONFIRM                 (p_delivery_ID        IN NUMBER,
                                       p_ship_method_code   IN VARCHAR2
                                       ,x_return_status in out varchar2)
   IS
      p_api_version_number     NUMBER;
      init_msg_list            VARCHAR2 (30):= fnd_api.g_false;
      x_msg_count              NUMBER;
      x_msg_details            VARCHAR2 (32000);
      x_msg_summary            VARCHAR2 (32000);
      p_validation_level       NUMBER;
      p_commit                 VARCHAR2 (30);
     -- x_return_status          VARCHAR2 (15);
      source_code              VARCHAR2 (15);
      changed_attributes       wsh_delivery_details_pub.changedattributetabtype;
      p_action_code            VARCHAR2 (15);
      p_delivery_name          VARCHAR2 (30);
      p_asg_trip_id            NUMBER;
      p_asg_trip_name          VARCHAR2 (30);
      p_asg_pickup_stop_id     NUMBER;
      p_asg_pickup_loc_id      NUMBER;
      p_asg_pickup_loc_code    VARCHAR2 (30);
      p_asg_pickup_arr_date    DATE;
      p_asg_pickup_dep_date    DATE;
      p_asg_dropoff_stop_id    NUMBER;
      p_asg_dropoff_loc_id     NUMBER;
      p_asg_dropoff_loc_code   VARCHAR2 (30);
      p_asg_dropoff_arr_date   DATE;
      p_asg_dropoff_dep_date   DATE;
      p_sc_action_flag         VARCHAR2 (10);
      p_sc_close_trip_flag     VARCHAR2 (10);
      p_defer_iface            VARCHAR2 (10);
      p_sc_create_bol_flag     VARCHAR2 (10);
      p_sc_stage_del_flag      VARCHAR2 (10);
      p_sc_trip_ship_method    VARCHAR2 (30);
      p_sc_actual_dep_date     VARCHAR2 (30);
      p_sc_report_set_id       NUMBER;
      p_sc_report_set_name     VARCHAR2 (60);
      p_wv_override_flag       VARCHAR2 (10);
      x_trip_id                VARCHAR2 (30);
      x_trip_name              VARCHAR2 (30);
      p_msg_data               VARCHAR2 (32000);
      fail_api EXCEPTION;
      v_delivery_name          VARCHAR2 (100);             --  delivery number
      v_action                 VARCHAR2 (100);
      -- Pass 'B' to backorder the unspecified quantity
      p_ship_conf_status       VARCHAR2 (200);
      x_msg_data               VARCHAR2 (1000) DEFAULT NULL ;
      x_sql_err_flag           NUMBER DEFAULT 0 ;
      x_err_msg                VARCHAR2 (4000) DEFAULT NULL ;
            msg_index           number;
      l_process_msg       varchar2(4000);
      l_msg_index_out   number;

BEGIN
    print_log ('Beginnning of Procedure SHIP CONFIRM'||chr(10));
      x_return_status := wsh_util_core.g_ret_sts_success;
      p_action_code := 'CONFIRM';
      -- p_delivery_name := '6006328';
      -- p_delivery_ID := 6006328;
      p_sc_action_flag := 'S';
      p_sc_close_trip_flag := 'Y';
      -- Trip stop concurrent program will be submitted automatically
      p_defer_iface := 'N';
      p_sc_stage_del_flag := 'Y';

       fnd_msg_pub.initialize();
       oe_msg_pub.initialize;

      wsh_deliveries_pub.delivery_action (
         p_api_version_number        => 1.0,
         p_init_msg_list             => fnd_api.g_false,
         x_return_status             => x_return_status,
         x_msg_count                 => x_msg_count,
         x_msg_data                  => p_msg_data,
         p_action_code               => p_action_code,
         p_delivery_id               => p_delivery_id,
         p_delivery_name             => p_delivery_id,
         p_asg_trip_id               => p_asg_trip_id,
         p_asg_trip_name             => p_asg_trip_name,
         p_asg_pickup_stop_id        => p_asg_pickup_stop_id,
         p_asg_pickup_loc_id         => p_asg_pickup_loc_id,
         p_asg_pickup_loc_code       => p_asg_pickup_loc_code,
         p_asg_pickup_arr_date       => p_asg_pickup_arr_date,
         p_asg_pickup_dep_date       => p_asg_pickup_dep_date,
         p_asg_dropoff_stop_id       => p_asg_dropoff_stop_id,
         p_asg_dropoff_loc_id        => p_asg_dropoff_loc_id,
         p_asg_dropoff_loc_code      => p_asg_dropoff_loc_code,
         p_asg_dropoff_arr_date      => p_asg_dropoff_arr_date,
         p_asg_dropoff_dep_date      => p_asg_dropoff_dep_date,
         p_sc_action_flag            => p_sc_action_flag,
         p_sc_close_trip_flag        => p_sc_close_trip_flag,
         p_sc_create_bol_flag        => p_sc_create_bol_flag,
         p_sc_stage_del_flag         => p_sc_stage_del_flag,
         p_sc_trip_ship_method       => p_ship_method_code,
         p_sc_actual_dep_date        => p_sc_actual_dep_date,
         p_sc_report_set_id          => p_sc_report_set_id,
         p_sc_report_set_name        => p_sc_report_set_name,
         p_sc_defer_interface_flag   => p_defer_iface,
         p_wv_override_flag          => p_wv_override_flag,
         x_trip_id                   => x_trip_id,
         x_trip_name                 => x_trip_name
      );

  print_log ('======================================');
  print_log ('Return status from Ship confirm API  '||x_return_status ||' - for delivery id '||p_delivery_id);
    print_log ('message count '||x_msg_count);
  --  print_log (' mesasge_data '||p_msg_data);

      IF (x_return_status <> wsh_util_core.g_ret_sts_success)
      THEN
         wsh_util_core.get_messages ('Y',
                                     x_msg_summary,
                                     x_msg_details,
                                     x_msg_count);

         IF x_msg_count > 1
         THEN
            x_msg_data := x_msg_summary || x_msg_details;
         ELSE
            x_msg_data := x_msg_summary;
         END IF;

         p_ship_conf_status := 'E';
      ELSE
         p_ship_conf_status := 'S';
      END IF;

                 -- Retrieve messages
                FOR i IN 1 .. x_msg_count LOOP
                Oe_Msg_Pub.get( p_msg_index => i ,p_encoded => Fnd_Api.G_FALSE
                ,p_data => p_msg_data
                ,p_msg_index_out => l_msg_index_out);


                  --  if length (l_msg) <=4000 then
                        l_process_msg := l_process_msg ||chr(10)||l_msg_index_out||'-'|| p_msg_data;

                  --  end if;

               -- fnd_file.put_line (fnd_file.LOG,'API message is: ' || p_msg_data);
                --fnd_file.put_line (fnd_file.LOG,'API message index is: ' || l_msg_index_out);
                END LOOP;

                print_log ('API error message from oe debug '||l_process_msg);

          msg_index:=null;
           IF (x_msg_count > 0)
            THEN
               BEGIN
                  msg_index := x_msg_count;

                  FOR i IN 1 .. x_msg_count
                  LOOP
                     fnd_msg_pub.get (p_msg_index       => FND_MSG_PUB.G_LAST,
                                      p_encoded         => 'F',
                                      p_data            => l_process_msg,
                                      p_msg_index_out   => msg_index);
                  --modified_output(lb_debug,'FND_MSG_PUB i= '|| i || ' **** ');
                  --modified_output(lb_debug,'FND_MSG_PUB Message is ' || substrb(err_mesg,1,200) || ' **** ');
                  print_log ('l_process_msg from Fnd Debug : '||i||' : '||l_process_msg);
                  END LOOP;
               END;
            END IF;


      COMMIT;
   /*  IF x_sql_err_flag = 1
                             THEN
        INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                         ERROR_MESSAGE,
                                         CREATION_DATE,
                                         CREATED_BY,
                                         LAST_UPDATE_DATE,
                                         LAST_UPDATED_BY)
          VALUES   (g_delivery_num,
                    x_err_msg,
                    SYSDATE,
                    fnd_global.user_id,
                    SYSDATE,
                    fnd_global.user_id);
        UPDATE   xxha_edi_856_delivery
           SET   STATUS = 'ERROR'
         WHERE   delivery_num = g_delivery_num;
        UPDATE   xxha_edi_856_delivery_details
           SET   STATUS = 'ERROR'
         WHERE   delivery_num = g_delivery_num;
     END IF;
     COMMIT;*/
END SHIPCONFIRM;

   --------------------------------------------------
   ---Main Procedure---------------------------------
   ------------------------------------------------------
/*
declare
x_error_message varchar2(2000);
x_status varchar2(1);
begin
xxha_edi_validation.process_inbound_asn(p_delivery_num =>'299987300' ,
                         p_transaction_type_name => 'RxC Standard',
                         p_user_name =>'WEBMETHODS',
                         p_responsibility_name => 'US Order Management Super User OC',
                         x_error_message => x_error_message,
                         x_status => x_status);
        dbms_output.put_line ('x_error_message is '||x_error_message);
        dbms_output.put_line ('x_status is '||x_status);
end;
*/
PROCEDURE MAIN (errbuf out varchar2
              ,retcode out varchar2
              ,P_DELIVERY_NUM IN VARCHAR2
              ,P_TXN_TYPE_NAME IN VARCHAR2
              ,P_USER_ID IN NUMBER
              ,P_RESP_APPL_ID IN NUMBER
              ,P_RESP_ID IN NUMBER
              )
   IS
      x_delivery_id          NUMBER;
      x_user_id              NUMBER;
      x_resp_id              NUMBER;
      x_appl_id              NUMBER;
      x_ship_method_code     VARCHAR2 (200) DEFAULT NULL ;
      x_delivery_detail_id   number;
      x_move_order_number    VARCHAR2 (50) DEFAULT NULL ;
      x_sql_err_flag         NUMBER DEFAULT 0 ;
      x_cnt_delivery_det     NUMBER DEFAULT 0 ;
      x_cnt                  NUMBER DEFAULT 0 ;
      x_cnt_exist            NUMBER DEFAULT 0 ;
      x_total_qty            NUMBER DEFAULT 0 ;
      x_err_msg              VARCHAR2 (2000) DEFAULT NULL ;
      x_val_status          VARCHAR2(1):=null;
      x_reserve_status      varchar2(1):=null;
      exp_mtl_reserve       exception ;
      exp_pick_confirm      exception;
      exp_ship_confirm      exception ;
      exp_autocreatedel     exception;
      exp_emergency_line    exception;
      exp_freight_line      exception;
      l_order_header_id     number;


      CURSOR c_ord_details
      IS
         SELECT   oh.order_number,
                  oh.header_id,
                  ol.line_id,
                  ol.customer_line_number,
                  ol.ordered_quantity, ol.ordered_item,
                  msi.inventory_item_id,
                  msi.primary_uom_code,
                  msi.organization_id,
                  wdd.delivery_detail_id,
                  xxedi.delivery_num,
                  xxedidet.line_num,
                  xxedidet.item_num,
                  xxedidet.item_qty,
                  xxedidet.item_uom,
                  xxedidet.lot_line_num,
                  xxedidet.lot_number,
                  xxedidet.lot_qty
           FROM   oe_order_headers_all oh,
                  oe_order_lines_all ol,
                  wsh_delivery_details wdd,
                  xxha_edi_856_delivery xxedi,
                  xxha_edi_856_delivery_details xxedidet,
                  mtl_system_items_b msi
          WHERE       wdd.source_header_id = oh.header_id
                  AND wdd.source_line_id = ol.line_id
                  AND oh.header_id = ol.header_id
                  AND NVL (ol.open_flag, 'N') = 'Y'
                  AND released_status NOT IN ('Y', 'C')
                  AND NVL (oh.open_flag, 'N') = 'Y'
                  AND oh.booked_flag = 'Y'
                  AND NVL (ol.cancelled_flag, 'N') <> 'Y'
                  AND ol.flow_status_code = 'AWAITING_SHIPPING'
                  AND xxedi.order_number = oh.order_number
                  AND xxedidet.line_num = ol.customer_line_number
                  AND xxedi.delivery_num = xxedidet.delivery_num
                  AND xxedi.delivery_num = p_delivery_num
                  AND xxedidet.delivery_num = p_delivery_num
                  AND msi.inventory_item_id = ol.inventory_item_id
                  AND msi.organization_id = ol.ship_from_org_id
                  AND nvl(xxedi.status, 'XX') !='PROCESSED' -- 'NEW'
                  AND nvl( xxedidet.status, 'XX') !='PROCESSED' --'NEW'
                  AND oh.order_type_id = g_transaction_type_id;

      CURSOR curmain
      IS
         SELECT   xxedi.delivery_num,
                  status,
                  scac_code,
                  emerg_item,
                  emerg_amt,
                  frt_item,
                  frt_amt
                  ,order_number
           FROM   xxha_edi_856_delivery xxedi
          WHERE   nvl(xxedi.status, 'XX') !='PROCESSED' --'NEW'
          AND delivery_num = p_delivery_num;
BEGIN
      x_err_msg := NULL;
      x_sql_err_flag := 0;
      g_delivery_num := p_delivery_num;
      g_txn_name:=P_TXN_TYPE_NAME;
       g_subinv := 'FG';
     --  g_delivery_num := '200091900';

  print_log ('Beginning of the procedure to process Rx Cross Road Delivery Number '||g_delivery_num||chr(10));

-------
      BEGIN
         SELECT   transaction_type_id
           INTO   g_transaction_type_id
           FROM   OE_TRANSACTION_TYPES_TL
          WHERE   NAME = g_txn_name AND LANGUAGE = 'US';
      EXCEPTION
         WHEN OTHERS
         THEN
            x_sql_err_flag := 1;
            x_err_msg :=
               x_err_msg || 'Order Type  '||g_txn_name||'  is not Set up' || '||';
               print_log (x_err_msg);
      END;
 print_log ('OE Transaction Type is '|| g_txn_name ||' txn type id is '||g_transaction_type_id||chr(10));
-------
/*
      SELECT   user_id
        INTO   x_user_id
        FROM   fnd_user
       WHERE   user_name = 'WEBMETHODS';

      SELECT   responsibility_id, application_id
        INTO   x_resp_id, x_appl_id
        FROM   fnd_responsibility_vl
       WHERE   responsibility_name = 'US Order Management Super User OC';
*/
      ----Intialize APPS--------
      if fnd_global.user_id is null then
        fnd_global.apps_initialize (P_user_id, P_RESP_APPL_ID, P_RESP_ID);
      end if;
--------

    X_CNT_EXIST:=0;
    -- checking whether there are any open orders that exist for the Rx Crossroad delivery number

    FOR rec_ord_details IN c_ord_details LOOP
      X_CNT_EXIST:=X_CNT_EXIST+1;

    END LOOP;

    print_log (' eligible number of EBS order lines for this Rx CrossRoads delivery '||x_cnt_exist);

      IF X_CNT_EXIST = 0
      THEN
         x_sql_err_flag := 1;
         x_err_msg :=
            x_err_msg
            || 'Order Number or Line Number does not exist or can not be processed';
            print_log (x_err_msg);

      END IF;

-----------
      FOR rec_ord_details IN c_ord_details
      LOOP
         BEGIN
            SELECT   primary_transaction_quantity
              INTO   x_total_qty
              FROM   mtl_onhand_quantities_detail
             WHERE   inventory_item_id = rec_ord_details.inventory_item_id
                     AND organization_id = rec_ord_details.organization_id
                     AND lot_number = rec_ord_details.lot_number
                     AND subinventory_code = g_subinv
                     AND ROWNUM = 1;
         EXCEPTION
            WHEN OTHERS
            THEN
               x_sql_err_flag := 1;
               x_err_msg := 'Error in deriving Total Onhand qty for Lot Number '|| rec_ord_details.lot_number ||'  during reservation:'
                  || sqlerrm;
                  print_log ('error for item  '||rec_ord_details.ordered_item|| ' for line number '||rec_ord_details.customer_line_number|| '  error is '||x_err_msg);
         END;
      END LOOP;
        --  print_log (' SQL err flag after inventory procedure '||x_sql_err_flag);

       validate_del(p_delivery_num => g_delivery_num
                          , p_order_type=>  g_txn_name
                          , p_subinventory_code => g_subinv
                          , x_status => x_val_status
                          , x_error_message =>  x_err_msg );

                 if    x_val_status = 'S' then
                  print_log ('successfully validated delivery using validate_del procedure '||chr(10));
                 else
                  print_log ('error in validating delivery. error message is '|| x_err_msg||chr(10) );
                  x_sql_err_flag := 1;
                 end if;

---------------

      IF x_sql_err_flag = 1
      THEN
                 INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                                  ERROR_MESSAGE,
                                                  CREATION_DATE,
                                                  CREATED_BY,
                                                  LAST_UPDATE_DATE,
                                                  LAST_UPDATED_BY)
                   VALUES   (g_delivery_num,
                             x_err_msg,
                             SYSDATE,
                             fnd_global.user_id,
                             SYSDATE,
                             fnd_global.user_id);

                     UPDATE   xxha_edi_856_delivery
                        SET   STATUS = 'ERROR'
                      WHERE   delivery_num = g_delivery_num;

                     UPDATE   xxha_edi_856_delivery_details
                        SET   STATUS = 'ERROR'
                      WHERE   delivery_num = g_delivery_num;
              retcode:='2';
                 COMMIT;
      ELSE
         FOR recmain IN curmain
         LOOP
      --    print_log ('NOT EXECUTING THE MAIN SECTION OF PROGRAM. UNCOMMENT AND CHANGE BEFORE MANUALLY SUBMITTING THE CONC PROGRAM '||chr(10));

          --------- derive order header id
          g_order_number:= recmain.order_number;

            begin
               select header_id into l_order_header_id from oe_order_headers_all
              where order_number  = recmain.order_number
              and order_type_id = g_transaction_type_id;
                print_log ('order header id is '||l_order_header_id||chr(10));
              exception when others then
                print_log ('error in deriving header_id for order number '||recmain.order_number||' sql error is '||sqlerrm);
            end;


            print_log (' Oracle order number is '||recmain.order_number||chr(10));
              -- create emergency item
                  IF recmain.emerg_item IS NOT NULL
                  THEN
                  print_log ('adding freight item'||chr(10));
                     EMERGENCY_FRT_ITEM (recmain.delivery_num,
                                                  'EMERGENCY',
                                                  recmain.emerg_amt, l_order_header_id, g_emergency_line_id);
                                             print_log ('Emergency item added . Order line id for emergecy item is '||g_emergency_line_id);
                                             if g_emergency_line_id is null then
                                              raise exp_emergency_line;
                                              end if;
                  END IF;



               -- create freight item
                IF recmain.frt_item IS NOT NULL
                THEN
                  print_log ('adding freight item'||chr(10));
                   EMERGENCY_FRT_ITEM (recmain.delivery_num,
                                                'FREIGHT',
                                                recmain.frt_amt, l_order_header_id, g_freight_line_id);
                                                print_log ('Freight item added . Order line id for freight item is '||g_freight_line_id);
                                                if g_freight_line_id is null then
                                                  raise exp_freight_line;
                                                end if;

                END IF;

                -- split line if needed
                SPLIT_LINE (recmain.delivery_num, l_order_header_id);

                -- resever inventory

                RESERVE_INVENTORY (recmain.delivery_num,x_reserve_status);

                print_log ('return status from reserve_inventory procedure '|| x_reserve_status||chr(10));
                if x_reserve_status != fnd_api.g_ret_sts_success then
                  raise exp_mtl_reserve;
                  null;
                end if;

               -- raise exp_mtl_reserve;

            -- auto create deliveries

              AutoCreateDeliveries (P_DELIVERY_NUM => recmain.delivery_num
                                ,x_delivery_id => x_delivery_id);

                  if x_delivery_id is null then
                    raise exp_autocreatedel;
                end if;

          -- pick release
            pickRelease (p_delivery_id => x_delivery_id);
            print_log ('delivery id '||x_delivery_id||chr(10));

             --raise exp_mtl_reserve;
                BEGIN
                   SELECT   wdd.delivery_detail_id
                     INTO   x_delivery_detail_id
                     FROM   wsh_delivery_assignments wda,
                            wsh_delivery_details wdd
                    WHERE       wda.delivery_detail_id = wdd.delivery_detail_id
                            AND delivery_id = x_delivery_id
                            AND wdd.released_status = 'S'
                            AND ROWNUM = 1;
                EXCEPTION
                   WHEN OTHERS
                   THEN
                      ROLLBACK;
                      x_sql_err_flag := 1;
                      x_err_msg :=
                         x_err_msg
                         || 'Error in deriving delivery detail id from delivery assignments:'
                         || '||';
                END;
                BEGIN
                   SELECT   DISTINCT request_number
                     INTO   x_move_order_number
                     FROM   mtl_txn_request_HEADERS A, mtl_txn_request_lines B
                    WHERE   A.HEADER_ID = B.HEADER_ID
                            AND b.LINE_ID IN
                                     (SELECT   MOVE_ORDER_LINE_ID
                                        FROM   WSH_DELIVERY_DETAILS
                                       WHERE   DELIVERY_DETAIL_ID =
                                                  x_delivery_detail_id);
                EXCEPTION
                   WHEN OTHERS
                   THEN
                      ROLLBACK;
                      x_sql_err_flag := 1;
                      x_err_msg :=
                            x_err_msg
                         || 'Error in deriving move order number'
                         || '||';
                END;
                -- pick confirm
                IF x_sql_err_flag = 0
                THEN
                print_log ('move order number is '||x_move_order_number ||chr(10));
                   PICKCONFIRM (x_move_order_number,x_reserve_status);
                                   if x_reserve_status != fnd_api.g_ret_sts_success then
                                      raise exp_pick_confirm;
                                      null;
                                  end if;
                END IF;

                BEGIN
                   SELECT   ship_method_code
                     INTO   x_ship_method_code
                     FROM   wsh_carrier_services_v
                    WHERE   attribute1 = recmain.scac_code;
                EXCEPTION
                   WHEN OTHERS
                   THEN
                      ROLLBACK;
                      x_sql_err_flag := 1;
                      x_err_msg :=
                         x_err_msg
                         || 'Error in deriving Carrier Information for Ship Confirm:'
                         || '||';
                END;
              -- raise exp_mtl_reserve;
                -- ship confirm
                SHIPCONFIRM (x_delivery_id, x_ship_method_code,x_reserve_status);
                                if x_reserve_status != fnd_api.g_ret_sts_success then
                                    if x_reserve_status != 'W' then  -- ship confirm API has a tendency to give warnings and successfully ship confirm
                                      raise exp_ship_confirm;
                                     end if;
                                  end if;

                IF x_sql_err_flag = 1
                THEN
                   INSERT INTO XXHA_EDI_856_ERRORS (DELIVERY_ID,
                                                    ERROR_MESSAGE,
                                                    CREATION_DATE,
                                                    CREATED_BY,
                                                    LAST_UPDATE_DATE,
                                                    LAST_UPDATED_BY)
                     VALUES   (g_delivery_num,
                               x_err_msg,
                               SYSDATE,
                               fnd_global.user_id,
                               SYSDATE,
                               fnd_global.user_id);
                      set_error_status (p_delivery_num => g_delivery_num);

                END IF;

                UPDATE   xxha_edi_856_delivery
                   SET   STATUS = 'PROCESSED'
                 WHERE   delivery_num = recmain.delivery_num
                -- AND STATUS = 'NEW'
                 ;

                UPDATE   xxha_edi_856_delivery_details
                   SET   STATUS = 'PROCESSED'
                 WHERE   delivery_num = recmain.delivery_num
                 --AND STATUS = 'NEW'
                 ;

                COMMIT;


         END LOOP;
      END IF; -- IF x_sql_err_flag = 1
  Exception

        when exp_emergency_line then
        print_log ('failed to create emergency line ');
        rollback;
        set_error_status (p_delivery_num => g_delivery_num);
        retcode:= '2';

        when exp_freight_line then
        print_log ('failed to create freight line ');
        rollback;
        set_error_status (p_delivery_num => g_delivery_num);
        retcode:= '2';

        when exp_mtl_reserve then
        print_log ('failed to reserve inventory ');
        rollback;
        set_error_status (p_delivery_num => g_delivery_num);
        retcode:= '2';

       when exp_autocreatedel then
        print_log ('failed to autocreate deliveries ');
        rollback;
        set_error_status (p_delivery_num => g_delivery_num);
        retcode:= '2';

       when exp_pick_confirm then
        print_log ('allocate move order or pick confirm failed ');
        rollback;
        set_error_status (p_delivery_num => g_delivery_num);
        retcode:= '2';

        when exp_ship_confirm then
        print_log ('failed to ship confirm ');
        rollback;
        set_error_status (p_delivery_num => g_delivery_num);
        retcode:= '2';

        when others then
        print_log ('error in main procedure '||sqlerrm);
        set_error_status (p_delivery_num => g_delivery_num);
          retcode:= '2';


END MAIN;


/*
procedure used for testing individual procedures during development cycle
*/

-- script to create sample data
/*
declare
old_delivery_num varchar2(20):='290190000';
new_order_num varchar2(20):='2904900';

begin
insert into xxha_edi_856_delivery_details
select * from xxha_edi_856_delivery_details
where delivery_num = old_delivery_num ;

insert into  xxha_edi_856_delivery
select * from  xxha_edi_856_delivery
where delivery_num = old_delivery_num ;

commit;

update xxha_edi_856_delivery
set delivery_num = new_order_num||'00'
, order_number = new_order_num
where delivery_num = old_delivery_num
and rownum = 1;


update  xxha_edi_856_delivery_details
set delivery_num = new_order_num||'00'
where delivery_num = old_delivery_num
and rownum = 1;

commit;

end;
*/


PROCEDURE MAIN_TEST IS
 l_user_id NUMBER;
  l_resp_id NUMBER;
  l_appl_id NUMBER;
  x_return_status varchar2(1);
BEGIN

-- Initializing the Applications

    SELECT user_id
    INTO l_user_id
    FROM fnd_user
    WHERE user_name = 'WEBMETHODS';

    SELECT responsibility_id, application_id
    INTO l_resp_id, l_appl_id
    FROM fnd_responsibility_vl
    WHERE responsibility_name = 'US Order Management Super User OC';

fnd_global.apps_initialize (l_user_id, l_resp_id, l_appl_id);

 --AutoCreateDeliveries;
--pickRelease (6052328);
--XXHA_EDI_856_PICKCONFIRM (p_move_order_number => '7542627');
--SHIPCONFIRM (p_delivery_ID        => 6052328,   p_ship_method_code  => '000001_FDEG_P_GNDUS', x_return_status);

END MAIN_TEST;


PROCEDURE AutoCreateDeliveries  (P_DELIVERY_NUM IN VARCHAR2
                                ,x_delivery_id IN OUT NUMBER) IS
  x_return_status VARCHAR2 (2);
  x_msg_count NUMBER;
  x_msg_data VARCHAR2 (4000);
  p_api_version_number NUMBER := 1.0;
  init_msg_list VARCHAR2 (200);
  x_msg_details VARCHAR2 (3000);
  x_msg_summary VARCHAR2 (3000);
  p_line_rows wsh_util_core.id_tab_type;
  p_line_rows_cp wsh_util_core.id_tab_type;
  x_del_rows wsh_util_core.id_tab_type;
  l_ship_method_code VARCHAR2 (100);
  l NUMBER;
  l_commit VARCHAR2 (30);
  p_delivery_id NUMBER;
  p_delivery_name VARCHAR2 (30);
  x_trip_id VARCHAR2 (30);
  x_trip_name VARCHAR2 (30);
  exep_api EXCEPTION;
  l_picked_flag VARCHAR2 (10);
  l_return_status VARCHAR2 (1000);
  l_msg_count NUMBER;
  l_msg_data VARCHAR2 (1000);

  l_new_del_id NUMBER;
  x_err_msg varchar2(4000):=null;


CURSOR c_ord_details
IS
    select line_number, min(delivery_detail_id) delivery_detail_id
    from (
              SELECT oha.order_number sales_order, oha.org_id, ola.line_number,
              ola.shipment_number, ola.flow_status_code,
              wdd.delivery_detail_id, wdd.inv_interfaced_flag,
              wdd.oe_interfaced_flag, wdd.released_status, wdd.source_header_id, wdd.source_line_id
              FROM apps.oe_order_headers_all oha,
              apps.oe_order_lines_all ola,
              apps.wsh_delivery_details wdd,
                             xxha_edi_856_delivery xxedi,
                           xxha_edi_856_delivery_details xxedidet
              WHERE oha.header_id = ola.header_id
              AND oha.org_id = ola.org_id
              AND oha.header_id = wdd.source_header_id
              AND ola.line_id = wdd.source_line_id
              AND oha.booked_flag = 'Y'
              AND NVL (ola.cancelled_flag, 'N') <> 'Y'
              --AND wdd.released_status in ('R','B')
              AND ola.flow_status_code = 'AWAITING_SHIPPING'
              AND wdd.source_code = 'OE'
            --  AND oha.order_number = '523'
             AND xxedi.order_number = oha.order_number
                           AND xxedidet.line_num = ola.customer_line_number
                           and xxedidet.item_qty = ola.ordered_quantity
                           AND xxedi.delivery_num = xxedidet.delivery_num
                           AND xxedi.delivery_num = p_delivery_num
                           AND xxedidet.delivery_num = p_delivery_num
                           and ola.ordered_quantity = to_number(xxedidet.item_qty) -- this will match the order line with qty also. will select the correct line in case of line split
             UNION  -- to pick any emergency item or freight item added by thi rx cross road delivery and in awaiting shipping status
             SELECT oha.order_number sales_order, oha.org_id, ola.line_number,
              ola.shipment_number, ola.flow_status_code,
              wdd.delivery_detail_id, wdd.inv_interfaced_flag,
              wdd.oe_interfaced_flag, wdd.released_status, wdd.source_header_id, wdd.source_line_id
              FROM apps.oe_order_headers_all oha,
              apps.oe_order_lines_all ola,
              apps.wsh_delivery_details wdd
               WHERE oha.header_id = ola.header_id
              AND oha.org_id = ola.org_id
              AND oha.header_id = wdd.source_header_id
              AND ola.line_id = wdd.source_line_id
              AND oha.booked_flag = 'Y'
              AND NVL (ola.cancelled_flag, 'N') <> 'Y'
              --AND wdd.released_status in ('R','B')
              AND ola.flow_status_code = 'AWAITING_SHIPPING'
               and wdd.source_code = 'OE'
               and wdd.source_line_id in (g_emergency_line_id, g_freight_line_id)
      )
      GROUP BY line_number
  ;


BEGIN



x_return_status := wsh_util_core.g_ret_sts_success;
l := 0;

    FOR rec_det IN c_ord_details LOOP

          --Mandatory initialization for R12
          --mo_global.set_policy_context ('S', i.org_id);
          --mo_global.init ('ONT');

          l := l + 1;

          p_line_rows (l) := rec_det.delivery_detail_id;

    END LOOP;

    p_line_rows_cp :=p_line_rows;

-- API Call for Auto Create Deliveries

print_log('Calling WSH_DELIVERY_DETAILS_PUB to Perform AutoCreate Delivery'||chr(10));
print_log('====================================================');

    fnd_msg_pub.initialize();

    wsh_delivery_details_pub.autocreate_deliveries
    (p_api_version_number => 1.0,
    p_init_msg_list => apps.fnd_api.g_false,
    p_commit => l_commit,
    x_return_status => x_return_status,
    x_msg_count => x_msg_count,
    x_msg_data => x_msg_data,
    p_line_rows => p_line_rows,
    x_del_rows => x_del_rows
    );

         print_log ('api return status '||x_return_status);
       --  print_log ('api message data '||x_msg_data);
         print_log ('api msg count '||x_msg_count);

    IF x_msg_count > 1
           THEN
             x_err_msg :=null;

              FOR I IN 1 .. x_msg_count
              LOOP
                 x_msg_data :=
                    FND_MSG_PUB.GET (FND_MSG_PUB.G_NEXT, FND_API.G_FALSE);
                     x_err_msg := x_err_msg || chr(10)||I||' : '||x_msg_data;
              END LOOP;
   ELSE
      x_err_msg:= x_msg_data;
    END IF;
           print_log ('API msg data         = ' || x_err_msg);

    IF (x_return_status <> wsh_util_core.g_ret_sts_success) THEN

        print_log ('Failed to Auto create delivery for Sales Order');
        raise_application_error
            (-20000
             , 'Auto create delivery failed');


    ELSE

        print_log('Auto Create Delivery Action has successfully completed for SO');
        print_log ('=============================================');
        COMMIT;

        for i in 1..p_line_rows_cp.COUNT LOOP

            select delivery_id INTO l_new_del_id
            from WSH_DELIVERY_ASSIGNMENTS
            where delivery_detail_id = p_line_rows_cp(i);

            print_log ('Delivery id '||l_new_del_id);

        END LOOP;

        x_delivery_id := l_new_del_id;

        update wsh_new_deliveries
        set attribute2 = P_DELIVERY_NUM
        where delivery_id = x_delivery_id;

    END IF ;

Exception WHEN exep_api then
  null;

END AutoCreateDeliveries;


PROCEDURE pickRelease (p_delivery_id in number) as
 x_return_status VARCHAR2 (2);
  x_msg_count NUMBER;
  x_msg_data VARCHAR2 (4000);
  p_api_version_number NUMBER := 1.0;
  init_msg_list VARCHAR2 (200):=FND_API.G_FALSE;
  x_msg_details VARCHAR2 (3000);
  x_msg_summary VARCHAR2 (3000);
   exep_api EXCEPTION;
  x_batch_id number;
  l_commit VARCHAR2(30):=FND_API.G_FALSE;
  l_batch_rec WSH_PICKING_BATCHES_PUB.Batch_Info_Rec;
  x_request_id number;
  x_err_msg varchar2(4000):=null;

   l_message                     VARCHAR2(4000);
   l_phase                       VARCHAR2(30);
   l_status                      VARCHAR2(30);
   l_dev_phase                   VARCHAR2(30);
   l_dev_status                  VARCHAR2(30);
   l_conc_req_status             VARCHAR2(1);

BEGIN

l_batch_rec.delivery_id:=p_delivery_id;
print_log ('Beginnin PickRelease. Creating pick release batch'||chr(10));
-- create batch
  fnd_msg_pub.initialize();
  WSH_PICKING_BATCHES_PUB.Create_Batch (
        ----- Standard parameters
          p_api_version       => p_api_version_number,
          p_init_msg_list      => init_msg_list,
          p_commit             => l_commit,
          x_return_status     => x_return_status,
          x_msg_count          => x_msg_count,
          x_msg_data           => x_msg_data,
         ---- Program specific paramters.
          p_rule_id            => NULL,
     	 p_rule_name          =>  NULL,
          p_batch_rec          => l_batch_rec,
          p_batch_prefix       =>  NULL,
          x_batch_id           => x_batch_id

  );

         print_log ('api return status '||x_return_status);
    --     print_log ('api message data '||x_msg_data);
         print_log ('api msg count '||x_msg_count);

    IF x_msg_count >= 1
           THEN
              x_err_msg :=null;

              FOR I IN 1 .. x_msg_count
              LOOP
                 x_msg_data :=
                    FND_MSG_PUB.GET (FND_MSG_PUB.G_NEXT, FND_API.G_FALSE);
                     x_err_msg := x_err_msg || chr(10)||I||' : '||x_msg_data;
              END LOOP;
    ELSE
      x_err_msg:= x_msg_data;
    END IF;
           print_log ('API msg data         = ' || x_err_msg);

    IF (x_return_status <> wsh_util_core.g_ret_sts_success) THEN

        print_log ('Failed to create batch id for delivery '||l_batch_rec.delivery_id);
        RAISE exep_api;

    ELSE

      print_log (' success in creating picking batch . batch id is '||x_batch_id);

                      ------ Release batch previously created
                      x_return_status:=null;
                      x_msg_count:=null;
                      x_msg_data:=null;
                      print_log('releasing batch'||chr(10));

                      fnd_msg_pub.initialize();

                       WSH_PICKING_BATCHES_PUB.Release_Batch (
                            -- Standard parameters
                            p_api_version       => p_api_version_number,
                            p_init_msg_list      => init_msg_list,
                            p_commit             => l_commit,
                            x_return_status     => x_return_status,
                            x_msg_count          => x_msg_count,
                            x_msg_data           => x_msg_data,
                            -- program specific paramters.
                             p_batch_id          => x_batch_id,
                            p_batch_name        =>  NULL,
                             p_log_level         => NULL,
                          p_release_mode      =>  'CONCURRENT',
                           x_request_id        => x_request_id
                           ) ;
                           print_log ('api return status '||x_return_status);
                        --   print_log ('api message data '||x_msg_data);
                           print_log ('api msg count '||x_msg_count);

                      IF x_msg_count >= 1
                             THEN
                                x_err_msg :=null;

                                FOR I IN 1 .. x_msg_count
                                LOOP
                                   x_msg_data :=
                                      FND_MSG_PUB.GET (FND_MSG_PUB.G_NEXT, FND_API.G_FALSE);
                                      x_err_msg := x_err_msg || chr(10)||I||' : '||x_msg_data;
                                END LOOP;
                      ELSE
                          x_err_msg:= x_msg_data;
                     END IF;
                            print_log ('API msg data         = ' || x_err_msg);


                      IF (x_return_status <> wsh_util_core.g_ret_sts_success) THEN

                          print_log ('Failed to release batch  for batch id  '); -- add batch id
                          RAISE exep_api;

                      ELSE

                        print_log (' success in releasing batch id  '||x_batch_id||' concurrent request id is '||x_request_id);

                        -- wait for request to finish
                         waitForConcRequest (p_request_id => x_request_id
                             ,p_calling_procedure => 'pickRelease'
                              ,x_message => l_message
                              ,x_phase => l_phase
                              ,x_status => l_status
                              ,x_dev_phase => l_dev_phase
                              ,x_dev_status => l_dev_status
                              ,x_return_status => l_conc_req_status  -- values are S or E
                              ) ;
                      END IF;     -- checking return status for release pick batch

    END IF;-- checking return status for creating pick batch


Exception WHEN exep_api then
  null;
END pickRelease;

/*
generic procedure to wait for a concurrent request to finish
*/

PROCEDURE waitForConcRequest (p_request_id IN NUMBER
                             ,p_calling_procedure IN VARCHAR2 DEFAULT NULL
                              ,x_message OUT varchar2
                              ,x_phase out varchar2
                              ,x_status out varchar2
                              ,x_dev_phase out varchar2
                              ,x_dev_status out varchar2
                              ,x_return_status out varchar2 -- values are S or E
                              ) AS
   l_message                     VARCHAR2(4000);
   l_wait_for_request            BOOLEAN;
   l_phase                       VARCHAR2(30);
   l_status                      VARCHAR2(30);
   l_dev_phase                   VARCHAR2(30);
   l_dev_status                  VARCHAR2(30);
BEGIN
print_log ( 'Calling procedure to wait for concurrent request id '||p_request_id ||' is '||p_calling_procedure);


            l_wait_for_request := fnd_concurrent.wait_for_request(p_request_id
                                                                 ,5
                                                                 ,99999
                                                                 ,l_phase
                                                                 ,l_status
                                                                 ,l_dev_phase
                                                                 ,l_dev_status
                                                                 ,l_message
                                                                 );


            IF  NOT ((l_dev_phase = 'COMPLETE') AND (l_dev_status = 'NORMAL')) THEN
               print_log ('Concurrent Request id '||p_request_id||' finished with errors');
               x_return_status := 'E';
            ELSE
               print_log ('Concurrent Request id '||p_request_id||' finished successfully');
               x_return_status := 'S';
          END IF;

END waitForConcRequest;

/*
procedure to check if a delivery number already exists in the custom table before inserting a new one
called from XML gateway
*/
PROCEDURE check_rx_del_num (p_delivery_num in varchar2
                           ,x_return_status out varchar2 -- values are S and F
                           ,x_return_msg out varchar2
                           ) AS
     l_cnt number:=0;
BEGIN

  select count(1) into l_cnt
  from  xxha_edi_856_delivery
  where delivery_num = p_delivery_num
  and nvl(status , 'XX') = 'PROCESSED'
  ;
  -- check if record exists in the staging table for a delivery in PROCESSED status
  -- if record exists in processed status then error and return (exit from the procedure).
    IF l_cnt > 0 then
      x_return_status := 'F';
      x_return_msg:=' Delivery '||p_delivery_num ||' has records in table xxha_edi_856_delivery  in PROCESSED status. Do not send records again for this delivery ' ;
      RETURN;
    end if;

    -- delete records from stagin table and error table if the delivery number already exists
    -- in a status other than PROCESSED. this will allow for new records to be written without
    -- creating dulicates.
    delete from xxha_edi_856_delivery
    where delivery_num = p_delivery_num
    and nvl(status , 'XX') != 'PROCESSED';

    delete from xxha_edi_856_delivery_details
    where delivery_num = p_delivery_num
    and nvl(status , 'XX') != 'PROCESSED';

    delete from XXHA_EDI_856_ERRORS
    where delivery_id  = p_delivery_num;

      x_return_msg:= 'S';

        commit;

Exception when others then
   x_return_status := 'F';
      x_return_msg:=' Error in procedure check_rx_del_num.SQL error is '||sqlerrm;
END check_rx_del_num;

/*
procedure to lock an order. called before process order API
*/
PROCEDURE XXHALOCKORDER (p_order_header_id in number
                                          ,x_return_status in out varchar2) AS
l_api_version_number number:=1.0;
lx_return_status varchar2(1);
lx_msg_count number;
lx_msg_data varchar2(4000);

------- out variables of get order which becomes the in variables of lock order
p_header_rec oe_order_pub.Header_Rec_Type;
p_header_val_rec oe_order_pub.Header_Val_Rec_Type;
p_Header_Adj_tbl              oe_order_pub.Header_Adj_Tbl_Type;
p_Header_Adj_val_tbl            oe_order_pub.Header_Adj_Val_Tbl_Type;
p_Header_price_Att_tbl          oe_order_pub.Header_Price_Att_Tbl_Type;
p_Header_Adj_Att_tbl            oe_order_pub.Header_Adj_Att_Tbl_Type;
p_Header_Adj_Assoc_tbl            oe_order_pub.Header_Adj_Assoc_Tbl_Type;
p_Header_Scredit_tbl            oe_order_pub.Header_Scredit_Tbl_Type;
p_Header_Scredit_val_tbl        oe_order_pub.Header_Scredit_Val_Tbl_Type;
p_Header_Payment_tbl            oe_order_pub.Header_Payment_Tbl_Type;
p_Header_Payment_val_tbl        oe_order_pub.Header_Payment_Val_Tbl_Type;
p_line_tbl                      oe_order_pub.Line_Tbl_Type;
p_line_val_tbl                  oe_order_pub.Line_Val_Tbl_Type;
p_Line_Adj_tbl                  oe_order_pub.Line_Adj_Tbl_Type;
p_Line_Adj_val_tbl              oe_order_pub.Line_Adj_Val_Tbl_Type;
p_Line_price_Att_tbl            oe_order_pub.Line_Price_Att_Tbl_Type;
p_Line_Adj_Att_tbl              oe_order_pub.Line_Adj_Att_Tbl_Type;
p_Line_Adj_Assoc_tbl              oe_order_pub.Line_Adj_Assoc_Tbl_Type;
p_Line_Scredit_tbl              oe_order_pub.Line_Scredit_Tbl_Type;
p_Line_Scredit_val_tbl          oe_order_pub.Line_Scredit_Val_Tbl_Type;
p_Line_Payment_tbl              oe_order_pub.Line_Payment_Tbl_Type;
p_Line_Payment_val_tbl          oe_order_pub.Line_Payment_Val_Tbl_Type;
p_Lot_Serial_tbl                oe_order_pub.Lot_Serial_Tbl_Type;
p_Lot_Serial_val_tbl            oe_order_pub.Lot_Serial_Val_Tbl_Type;

---------- out variables of lock order

x_header_rec oe_order_pub.Header_Rec_Type;
x_header_val_rec oe_order_pub.Header_Val_Rec_Type;
x_Header_Adj_tbl              oe_order_pub.Header_Adj_Tbl_Type;
x_Header_Adj_val_tbl            oe_order_pub.Header_Adj_Val_Tbl_Type;
x_Header_price_Att_tbl          oe_order_pub.Header_Price_Att_Tbl_Type;
x_Header_Adj_Att_tbl            oe_order_pub.Header_Adj_Att_Tbl_Type;
x_Header_Adj_Assoc_tbl            oe_order_pub.Header_Adj_Assoc_Tbl_Type;
x_Header_Scredit_tbl            oe_order_pub.Header_Scredit_Tbl_Type;
x_Header_Scredit_val_tbl        oe_order_pub.Header_Scredit_Val_Tbl_Type;
x_Header_Payment_tbl            oe_order_pub.Header_Payment_Tbl_Type;
x_Header_Payment_val_tbl        oe_order_pub.Header_Payment_Val_Tbl_Type;
x_line_tbl                      oe_order_pub.Line_Tbl_Type;
x_line_val_tbl                  oe_order_pub.Line_Val_Tbl_Type;
x_Line_Adj_tbl                  oe_order_pub.Line_Adj_Tbl_Type;
x_Line_Adj_val_tbl              oe_order_pub.Line_Adj_Val_Tbl_Type;
x_Line_price_Att_tbl            oe_order_pub.Line_Price_Att_Tbl_Type;
x_Line_Adj_Att_tbl              oe_order_pub.Line_Adj_Att_Tbl_Type;
x_Line_Adj_Assoc_tbl              oe_order_pub.Line_Adj_Assoc_Tbl_Type;
x_Line_Scredit_tbl              oe_order_pub.Line_Scredit_Tbl_Type;
x_Line_Scredit_val_tbl          oe_order_pub.Line_Scredit_Val_Tbl_Type;
x_Line_Payment_tbl              oe_order_pub.Line_Payment_Tbl_Type;
x_Line_Payment_val_tbl          oe_order_pub.Line_Payment_Val_Tbl_Type;
x_Lot_Serial_tbl                oe_order_pub.Lot_Serial_Tbl_Type;
x_Lot_Serial_val_tbl            oe_order_pub.Lot_Serial_Val_Tbl_Type;
BEGIN
  NULL;


                   OE_ORDER_PUB.Get_Order
                    (   p_api_version_number            => l_api_version_number
                    ,   p_init_msg_list                 =>  FND_API.G_FALSE
                    ,   p_return_values                 =>  FND_API.G_FALSE
                    ,   x_return_status                 => lx_return_status
                    ,   x_msg_count                     => lx_msg_count
                    ,   x_msg_data                      => lx_msg_data
                    ,   p_header_id                     => p_order_header_id
                    ,   p_header                        =>     FND_API.G_MISS_CHAR
                    ,   x_header_rec                    => p_header_rec
                    ,   x_header_val_rec                => p_header_val_rec
                    ,   x_Header_Adj_tbl                => p_Header_Adj_tbl
                    ,   x_Header_Adj_val_tbl            => p_Header_Adj_val_tbl
                    ,   x_Header_price_Att_tbl          => p_Header_price_Att_tbl
                    ,   x_Header_Adj_Att_tbl            => p_Header_Adj_Att_tbl
                    ,   x_Header_Adj_Assoc_tbl            => p_Header_Adj_Assoc_tbl
                    ,   x_Header_Scredit_tbl            =>  p_Header_Scredit_tbl
                    ,   x_Header_Scredit_val_tbl        =>  p_Header_Scredit_val_tbl
                    ,   x_Header_Payment_tbl            => p_Header_Payment_tbl
                    ,   x_Header_Payment_val_tbl        => p_Header_Payment_val_tbl
                    ,   x_line_tbl                      => p_line_tbl
                    ,   x_line_val_tbl                  =>  p_line_val_tbl
                    ,   x_Line_Adj_tbl                  => p_Line_Adj_tbl
                    ,   x_Line_Adj_val_tbl              => p_Line_Adj_val_tbl
                    ,   x_Line_price_Att_tbl            => p_Line_price_Att_tbl
                    ,   x_Line_Adj_Att_tbl              => p_Line_Adj_Att_tbl
                    ,   x_Line_Adj_Assoc_tbl              => p_Line_Adj_Assoc_tbl
                    ,   x_Line_Scredit_tbl              => p_Line_Scredit_tbl
                    ,   x_Line_Scredit_val_tbl          => p_Line_Scredit_val_tbl
                    ,   x_Line_Payment_tbl              => p_Line_Payment_tbl
                    ,   x_Line_Payment_val_tbl          => p_Line_Payment_val_tbl
                    ,   x_Lot_Serial_tbl                => p_Lot_Serial_tbl
                    ,   x_Lot_Serial_val_tbl            => p_Lot_Serial_val_tbl
                    );

          if lx_return_status <> fnd_api.g_ret_sts_success then
           print_log ('error in getting information from oe_order_pub.get_order '||chr(10));

          end if;

            OE_ORDER_PUB.Lock_Order
              (   p_api_version_number            => l_api_version_number
              ,   p_init_msg_list                 => FND_API.G_FALSE
              ,   p_return_values                 => FND_API.G_FALSE
                    ,   x_return_status                 => lx_return_status
                    ,   x_msg_count                     => lx_msg_count
                    ,   x_msg_data                      => lx_msg_data
              ,   p_header_rec                    =>  p_header_rec
              ,   p_header_val_rec                 => p_header_val_rec
              ,   p_Header_Adj_tbl                => p_Header_Adj_tbl
              ,   p_Header_Adj_val_tbl            => p_Header_Adj_val_tbl
              ,   p_Header_price_Att_tbl          => p_Header_price_Att_tbl
              ,   p_Header_Adj_Att_tbl            => p_Header_Adj_Att_tbl
              ,   p_Header_Adj_Assoc_tbl           => p_Header_Adj_Assoc_tbl
              ,   p_Header_Scredit_tbl           => p_Header_Scredit_tbl
              ,   p_Header_Scredit_val_tbl       => p_Header_Scredit_val_tbl
              ,   p_Header_Payment_tbl            =>    p_Header_Payment_tbl
              ,   p_Header_Payment_val_tbl       => p_Header_Payment_val_tbl
              ,   p_line_tbl                     =>  p_line_tbl
              ,   p_line_val_tbl                  =>  p_line_val_tbl
              ,   p_Line_Adj_tbl                  => p_Line_Adj_tbl
              ,   p_Line_Adj_val_tbl              => p_Line_Adj_val_tbl
              ,   p_Line_price_Att_tbl           => p_Line_price_Att_tbl
              ,   p_Line_Adj_Att_tbl              => p_Line_Adj_Att_tbl
              ,   p_Line_Adj_Assoc_tbl              => p_Line_Adj_Assoc_tbl
              ,   p_Line_Scredit_tbl             => p_Line_Scredit_tbl
              ,   p_Line_Scredit_val_tbl          => p_Line_Scredit_val_tbl
              ,   p_Line_Payment_tbl             => p_Line_Payment_tbl
              ,   p_Line_Payment_val_tbl          => p_Line_Payment_val_tbl
              ,   p_Lot_Serial_tbl                =>  p_Lot_Serial_tbl
              ,   p_Lot_Serial_val_tbl            => p_Lot_Serial_val_tbl
              ,   x_header_rec                    =>  x_header_rec
              ,   x_header_val_rec                =>x_header_val_rec
              ,   x_Header_Adj_tbl                => x_Header_Adj_tbl
              ,   x_Header_Adj_val_tbl           => x_Header_Adj_val_tbl
              ,   x_Header_price_Att_tbl         => x_Header_price_Att_tbl
              ,   x_Header_Adj_Att_tbl           => x_Header_Adj_Att_tbl
              ,   x_Header_Adj_Assoc_tbl           => x_Header_Adj_Assoc_tbl
              ,   x_Header_Scredit_tbl            => x_Header_Scredit_tbl
              ,   x_Header_Scredit_val_tbl        => x_Header_Scredit_val_tbl
              ,   x_Header_Payment_tbl            =>  x_Header_Payment_tbl
              ,   x_Header_Payment_val_tbl        => x_Header_Payment_val_tbl
              ,   x_line_tbl                      => x_line_tbl
              ,   x_line_val_tbl                  => x_line_val_tbl
              ,   x_Line_Adj_tbl                  => x_Line_Adj_tbl
              ,   x_Line_Adj_val_tbl              => x_Line_Adj_val_tbl
              ,   x_Line_price_Att_tbl            => x_Line_price_Att_tbl
              ,   x_Line_Adj_Att_tbl              =>  x_Line_Adj_Att_tbl
              ,   x_Line_Adj_Assoc_tbl              => x_Line_Adj_Assoc_tbl
              ,   x_Line_Scredit_tbl              =>  x_Line_Scredit_tbl
              ,   x_Line_Scredit_val_tbl          => x_Line_Scredit_val_tbl
              ,   x_Line_Payment_tbl             => x_Line_Payment_tbl
              ,   x_Line_Payment_val_tbl          => x_Line_Payment_val_tbl
              ,   x_Lot_Serial_tbl                =>  x_Lot_Serial_tbl
              ,   x_Lot_Serial_val_tbl           => x_Lot_Serial_val_tbl
              );

          if lx_return_status <> fnd_api.g_ret_sts_success then

            print_log ('error in getting information from oe_order_pub.loc_order. Order not locked '||chr(10));
          end if;

          x_return_status := lx_return_status;

END XXHALOCKORDER;
END XXHA_EDI_856_SHIPCONFIRM_PKG;
/
