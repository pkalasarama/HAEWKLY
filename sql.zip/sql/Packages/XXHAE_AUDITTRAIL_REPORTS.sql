CREATE OR REPLACE package XXHAE_AUDITTRAIL_REPORTS is

  procedure AP_BANK_AUDIT_SINGLE_TABLE(errbuf  OUT VARCHAR2,
                          retcode OUT NUMBER,
                          p_type  in varchar2,
                          p_table_name in varchar2,
                          P_days_before in number,
                          p_creation_date varchar2);
procedure AP_BANK_AUDIT_SUMMARY_TABLE(errbuf  OUT VARCHAR2,
                          retcode OUT NUMBER,

                          P_days_before in number);
end XXHAE_AUDITTRAIL_REPORTS;
/


CREATE OR REPLACE package body XXHAE_AUDITTRAIL_REPORTS is
  procedure AP_BANK_AUDIT_SINGLE_TABLE(errbuf  OUT VARCHAR2,
                          retcode OUT NUMBER,
                          p_type  in varchar2,
                          p_table_name in varchar2,
                          P_days_before in number,
                          p_creation_date varchar2) is
      v_xmldoc           CLOB;
    v_buffer           VARCHAR2(32000);
    v_amount           NUMBER := 10;
    v_offset           NUMBER := 1;
    v_sql_text         DBMS_XMLGEN.ctxHandle;
    v_start_pos number := 0;
    v_index number := 0;
    v_string varchar2(32767);
    v_read_length number := 480;
    V_SQL CLOB;
    V_TXT_SQL varchar2(1000);
    l_additional_where_claus varchar2(1000);
    l_additional_from_claus varchar2(1000);
    l_additional_columns varchar2(1000);
    l_order_by_claus varchar2(1000);
    l_type varchar2(200);
    l_creation_date varchar2(100) := '';
    l_creation_date_value varchar2(30);
  BEGIN
  if p_type  in ('U','I') then
  l_type:='tbl1.audit_transaction_type ='''||p_type||'''';
  else
  l_type:='tbl1.audit_transaction_type in (''I'',''U'')';
  end if;
  if p_creation_date is not null then
  l_creation_date := 'and trunc(tbl1.creation_date) = trunc(to_date('''||p_creation_date||''',''yyyy/mm/dd HH24:MI:SS''))';
  l_creation_date_value := to_char(p_creation_date);
fnd_file.put_line(FND_FILE.LOG,p_creation_date);
  else
  l_creation_date := 'and 1=1';
  l_creation_date_value := to_char(sysdate);
  end if;
  /* if p_table_name in ('AP_BANK_BRANCHES','AP_BANK_ACCOUNTS_ALL','AP_BANK_ACCOUNT_USES_ALL') then
  l_additional_from_claus:=',fnd_user fu1,fnd_user fu2';
  l_additional_where_claus:=l_type||' and tbl1.last_updated_by = fu1.user_id and tbl1.created_by = fu2.user_id and tbl1.audit_timestamp>(sysdate-'||to_char(p_days_before)||') '||l_creation_date;
  l_additional_columns:=',fu1.user_name Updated_User,fu2.user_name Created_User';
  l_order_by_claus:=' order by audit_timestamp';
   end if;
*/
  /*if p_table_name='AP_BANK_ACCOUNT_USES_V' then
  V_SQL:='select sysdate ReportDate ,sysdate-'||to_char(p_days_before)||' DateFrom , ''AP_BANK_ACCOUNT_USES_V'' Audittable,
cursor(SELECT * FROM XXHAE_Trail_Audit_Report tbl1 where tbl1.AUDIT_TIMESTAMP>sysdate-'||to_char(p_days_before)||'
and '||l_type||' '||l_creation_date||'
order by tbl1.AUDIT_TIMESTAMP desc) audit_rows from dual';*/
if p_table_name = 'AP_BANK_ACCOUNT_USES_V' then
  V_SQL:='select sysdate ReportDate ,sysdate-'||to_char(p_days_before)||' DateFrom , ''AP_BANK_ACCOUNT_USES_V'' Audittable,'''||p_type||''' audit_type ,'''||l_creation_date_value||''' creation_date,
cursor(SELECT * FROM (select * from XXHA_BANK_AUDIT_REPORT_DET_V where AUDIT_TIMESTAMP_t>sysdate-'||to_char(p_days_before)||'
union
select * from XXHA_BANK_AUDIT_REPORT_HIS_V where rank = 1 and AUDIT_TIMESTAMP_t>sysdate-'||to_char(p_days_before)||') tbl1 where
'||l_type||' '||l_creation_date||'
order by tbl1.bank_branch_id,tbl1.bank_account_id,tbl1.bank_account_uses_id, tbl1.is_first desc,tbl1.AUDIT_TIMESTAMP) audit_rows from dual';
else
V_SQL:='select sysdate ReportDate ,sysdate-'||to_char(p_days_before)||' DateFrom ,'''||p_table_name||''' Audittable,'''||p_type||''' audit_type ,'''||l_creation_date_value||''' creation_date,
cursor(SELECT * FROM (select * from XXHA_BANK_AUDIT_REPORT_DET_V where AUDIT_TIMESTAMP_t>sysdate-'||to_char(p_days_before)||'
union
select * from XXHA_BANK_AUDIT_REPORT_HIS_V where rank = 1) tbl1 where
'||l_type||' '||l_creation_date||' and tbl1.basetable = '''||p_table_name||'''
order by tbl1.bank_branch_id,tbl1.bank_account_id,tbl1.bank_account_uses_id,tbl1.is_first desc, tbl1.AUDIT_TIMESTAMP) audit_rows from dual';
end if;
  /*else
   V_SQL:='select '''||p_table_name||''' as Audittable,'''||p_type||''' audit_type, SYSDATE ReportDate,
   cursor(select tbl1.*'||l_additional_columns||'
   from '||p_table_name||'_AC1 tbl1'||l_additional_from_claus||'
   where '
   ||l_additional_where_claus||
   l_order_by_claus||') audit_rows from dual';
   end if;*/

dbms_output.put_line(V_SQL);

   v_sql_text:=dbms_xmlgen.newContext(V_SQL);

    v_xmldoc := dbms_xmlgen.getxml(v_sql_text);
    v_amount := dbms_lob.getlength(v_xmldoc);

    if v_amount > 1 then
          while v_start_pos <=  v_amount
          loop
           v_index := v_index + 1;
           v_string := '';
           v_string :=  dbms_lob.substr(v_xmldoc,v_read_length,v_start_pos+1);
           v_start_pos  := v_start_pos+v_read_length;
           fnd_file.put(FND_FILE.OUTPUT, v_string);
          end loop;

    else
      SELECT dbms_xmlgen.newContext('SELECT '' No data found'' DATA FROM dual')
        INTO v_sql_text
        FROM DUAL;
      v_xmldoc := dbms_xmlgen.getxml(v_sql_text);
      v_amount := dbms_lob.getlength(v_xmldoc);
      dbms_lob.read(v_xmldoc, v_amount, v_offset, v_buffer);
      fnd_file.put(FND_FILE.OUTPUT, v_buffer);
    end if;

  end;
 procedure AP_BANK_AUDIT_SUMMARY_TABLE(errbuf  OUT VARCHAR2,
                          retcode OUT NUMBER,

                          P_days_before in number) is
      v_xmldoc           CLOB;
    v_buffer           VARCHAR2(32000);
    v_amount           NUMBER := 10;
    v_offset           NUMBER := 1;
    v_sql_text         DBMS_XMLGEN.ctxHandle;
    v_start_pos number := 0;
    v_index number := 0;
    v_string varchar2(32767);
    v_read_length number := 480;
    V_SQL CLOB;
    BEGIN

V_SQL:='select sysdate DateTo ,sysdate-'||to_char(p_days_before)||' DateFrom ,
cursor(SELECT * FROM XXHAE_Trail_Audit_Report t where t.AUDIT_TIMESTAMP>sysdate-'||to_char(p_days_before)||'
order by t.AUDIT_TIMESTAMP desc) audit_rows from dual';

   v_sql_text:=dbms_xmlgen.newContext(V_SQL);

    v_xmldoc := dbms_xmlgen.getxml(v_sql_text);
    v_amount := dbms_lob.getlength(v_xmldoc);

    if v_amount > 1 then
          while v_start_pos <=  v_amount
          loop
           v_index := v_index + 1;
           v_string := '';
           v_string :=  dbms_lob.substr(v_xmldoc,v_read_length,v_start_pos+1);
           v_start_pos  := v_start_pos+v_read_length;
           fnd_file.put(FND_FILE.OUTPUT, v_string);
          end loop;

    else
      SELECT dbms_xmlgen.newContext('SELECT '' No data found'' DATA FROM dual')
        INTO v_sql_text
        FROM DUAL;
      v_xmldoc := dbms_xmlgen.getxml(v_sql_text);
      v_amount := dbms_lob.getlength(v_xmldoc);
      dbms_lob.read(v_xmldoc, v_amount, v_offset, v_buffer);
      fnd_file.put(FND_FILE.OUTPUT, v_buffer);
    end if;

  end;

end XXHAE_AUDITTRAIL_REPORTS;
/
