CREATE OR REPLACE package XXHA_INV_SV_ITEM_REV_FIX
as
Procedure process_revisions
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        );

end XXHA_INV_SV_ITEM_REV_FIX;

/


CREATE OR REPLACE package body      XXHA_INV_SV_ITEM_REV_FIX
as



Procedure pre_process_revisions
          is
cursor c_get_item_rev_rec is
select * from xxha_sv_item_revisions_stg
where status <>  'PS'
;

cursor c_pre_val_rev is
select  rev.*,to_date(substr(staged_effective_date,1,22),'MM/DD/YYYY HH:MI:SS AM') update_effective_date
from xxha_sv_item_revisions_stg rev
where status <> 'PS'
--and item_number = '100418-00'
;

cursor c_get_item_id (q_item_number varchar2) is
select inventory_item_id
from mtl_system_items_b
where segment1 = q_item_number
and organization_id = 103
;
 l_inv_item_id  number;

begin


for v_get_item_rev_rec in c_get_item_rev_rec loop
   l_inv_item_id := null;
   for v_get_item_id in c_get_item_id (v_get_item_rev_rec.item_number) loop
     l_inv_item_id := v_get_item_id.inventory_item_id;
   end loop;
   update xxha_sv_item_revisions_stg
   set inventory_item_id = l_inv_item_id
   ,trx_type = 'CREATE'
   where record_id = v_get_item_rev_rec.record_id;

 end loop;
 commit;
 for v_pre_val_rev in c_pre_val_rev loop
   if v_pre_val_rev.staged_effective_date is not null then
     update xxha_sv_item_revisions_stg
	 set effective_date = v_pre_val_rev.update_effective_date
	 ,effective_date_iface = v_pre_val_rev.update_effective_date
	 where record_id = v_pre_val_rev.record_id
	 ;
   end if;
 end loop;
 commit;
end;

procedure load_item_revisions_intf
         is
   cursor c_get_rev is
   select * from xxha_sv_item_revisions_int_stg
   where transaction_type= 'CREATE'
   ;
begin
  for v_get_rev in c_get_rev loop
   insert into mtl_item_revisions_interface (
          inventory_item_id
         ,item_number
         ,organization_id
         ,organization_code
         ,revision
         ,effectivity_date
         ,description
         ,last_update_date
         ,last_updated_by
         ,creation_date
         ,created_by
         ,transaction_type
         ,process_flag
         ,set_process_id
		 ,implementation_date
		 )
   values (
          v_get_rev.inventory_item_id
         ,v_get_rev.item_number
         ,v_get_rev.organization_id
         ,v_get_rev.organization_code
         ,v_get_rev.revision
         ,v_get_rev.effectivity_date
         ,v_get_rev.description
         ,sysdate
         ,fnd_global.user_id
         ,sysdate
         ,fnd_global.user_id
         ,v_get_rev.transaction_type
         ,'1'
         ,v_get_rev.set_process_id
		 ,v_get_rev.effectivity_date
         );
	end loop;

end load_item_revisions_intf;

procedure load_item_revisions_stg_intf
         is
   cursor c_get_item_rev is
   select * from xxha_sv_item_revisions_stg
   where status <> 'PS';

   cursor c_get_item_org_id (q_item_number varchar2) is
   select items.organization_id,param.organization_code
   from mtl_system_items items,mtl_parameters param
   where items.segment1 = q_item_number
   and items.organization_id = param.organization_id
   ;
begin
  for v_get_item_rev in c_get_item_rev loop
      for v_get_item_org_id in c_get_item_org_id (v_get_item_rev.item_number) loop
   insert into xxha_sv_item_revisions_int_stg (
          inventory_item_id
         ,item_number
         ,organization_id
         ,organization_code
         ,revision
         ,effectivity_date
         ,description
         ,last_update_date
         ,last_updated_by
         ,creation_date
         ,created_by
         ,transaction_type
         ,process_flag
         ,set_process_id
		 ,implementation_date
		 )
   values (
          v_get_item_rev.inventory_item_id
         ,v_get_item_rev.item_number
         ,v_get_item_org_id.organization_id
         ,v_get_item_org_id.organization_code
         ,v_get_item_rev.revision_no
         ,v_get_item_rev.effective_date
         ,v_get_item_rev.description
         ,sysdate
         ,fnd_global.user_id
         ,sysdate
         ,fnd_global.user_id
         ,'CREATE'
         ,'1'
         ,'2000000'
		 ,v_get_item_rev.effective_date
         );
    end loop;
	update xxha_sv_item_revisions_stg
	set status = 'PS'
	where item_number = v_get_item_rev.item_number
	and revision_no = v_get_item_rev.revision_no;
  end loop;
end load_item_revisions_stg_intf;

procedure post_process_revisions
is

cursor c_get_int_rev is
select * from xxha_sv_item_revisions_int_stg;

cursor c_chk_rev (q_organization_id number,q_inventory_item_id number,q_revision varchar2) is
select revision_id
from mtl_item_revisions_b
where organization_id = q_organization_id
and inventory_item_id = q_inventory_item_id
and revision = q_revision
;
begin
  for v_get_int_rev in c_get_int_rev loop
    for v_chk_rev in c_chk_rev (v_get_int_rev.organization_id,v_get_int_rev.inventory_item_id,v_get_int_rev.revision) loop
	  update xxha_sv_item_revisions_int_stg
	  set transaction_type = 'UPDATE'
	  where organization_id = v_get_int_rev.organization_id
	  and inventory_item_id = v_get_int_rev.inventory_item_id
	  and revision = v_get_int_rev.revision
	  ;
	  commit;
    end loop;
  end loop;

end;

Procedure process_revisions
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
        ) is

begin
pre_process_revisions;
commit;
load_item_revisions_stg_intf;
commit;
post_process_revisions;
commit;
load_item_revisions_intf;
commit;
end;

END XXHA_INV_SV_ITEM_REV_FIX;

/
