CREATE OR REPLACE PACKAGE XXHA_CN_PAYMENTS IS  
--
-- Eric Rossing 
-- 30-SEP-3011
-- Connect as APPS Schema    
-- For HCSG  
--
-- 
-- Main Query 
-- build payments" program is run  AP_INV_SELECTION_CRITERIA_ALL  ap_selected_invoices_all 
-- 	 							   p_check_stocks_all;  ap_checks_all will contain payments records 
-- supplier bank a/c:  Bank acct\supplier assignments    AP_BANK_ACCOUNT_USES_V 
--
-- ++ Business Rules ++
-- 
-- ++ setups ++ 
-- Payment job execution is linked to Bank a/c and  and a/c is ~ Currency ;
-- a/c Document need to be setup in payment format and patment method (check / electronic)
-- payment format prog needs to be setup in each bank a/c currency to be visible in bank a/c/ document setup.
-- if there are 12 bank a/c in 12 different currencies. For each a/c a (check and electronic ) documents need to be setup.
-- You can only run Payment batch for either Check or Electronic 
--
-- ===================================================== 
-- Change Log
-- 2011-09-30	Eric Rossing	Initial release for TW, HK, CN
-- 2012-03-08	Eric Rossing	Combine Supplier Bank Name and Supplier Bank Branch Name and put combination in SECPTY field 37. Use field 38 for overflow if combined name is > 11 characters
-- 2012-03-14	Eric Rossing	Use Bank Account Name instead of Supplier Name for the SECPTY field 3
-- ===================================================== 

--vRequestId    NUMBER       := FND_GLOBAL.conc_request_id;
--vUserId       NUMBER       := HAE_UTIL.user_id;  
--vDataBase     VARCHAR2(15) := UPPER(sys_context('USERENV','DB_NAME')); -- also V$database can be used
--vDateTime     VARCHAR2(25) := to_char(sysdate, 'MM-DD-YY-HH12-MI-SS-AM');
v_org_id	  NUMBER 	   := HAE_UTIL.v_org_id;
--v_user_id	  NUMBER	   := HAE_UTIL.v_user_id;

eNoHandle     EXCEPTION;   

vRecCounter   NUMBER := 0; 
         	 
--v_set_of_books_id      hr_operating_units.set_of_books_id%TYPE  := HAE_UTIL.set_of_books_id('Haemonetics S.A. CH OU');
                                            
PROCEDURE payments_ifile
            (   errbuf       OUT   VARCHAR2
              , retcode      OUT   NUMBER   
              , P_PAYMENT_BATCH IN VARCHAR2       
           );              		

end XXHA_CN_PAYMENTS; 
/


CREATE OR REPLACE PACKAGE BODY XXHA_CN_PAYMENTS IS
-- =====================================================
-- Change Log
-- 2010-07-16	Eric Rossing	Initial release for CN
-- 2012-03-08	Eric Rossing	Combine Supplier Bank Name and Supplier Bank Branch Name and put combination in SECPTY field 37. Use field 38 for overflow if combined name is > 11 characters
-- 2012-03-14	Eric Rossing	Use Bank Account Name instead of Supplier Name for the SECPTY field 3
-- =====================================================
PROCEDURE put_csv_field(p_output_csv_field IN VARCHAR2, p_last_field IN BOOLEAN := FALSE) is
BEGIN

	IF (p_last_field) THEN
		FND_FILE.PUT_LINE(FND_FILE.OUTPUT, p_output_csv_field || CHR(13));
	ELSE
		FND_FILE.PUT(FND_FILE.OUTPUT, p_output_csv_field || ',');
	END IF;
EXCEPTION

	WHEN OTHERS
	THEN
	FND_FILE.PUT_LINE(FND_FILE.LOG, 'err Other Errors in put_csv_field Proc: ' || SQLERRM );
		RAISE eNoHandle;
	END put_csv_field;
PROCEDURE put_empty_fields(p_field_count IN NUMBER) is
	i NUMBER;
BEGIN
FOR i in 1..p_field_count LOOP
		put_csv_field('');
	END LOOP;
EXCEPTION
WHEN OTHERS
	THEN
FND_FILE.PUT_LINE(FND_FILE.LOG, 'err Other Errors in put_empty_fields Proc: ' || SQLERRM );
		RAISE eNoHandle;

END put_empty_fields;
PROCEDURE split_name(p_name IN VARCHAR2
					,p_en_field_size IN NUMBER
					,p_cn_field_size IN NUMBER
					,p_fields OUT XXHA_SPLIT_FIELDS
					,p_field_count OUT NUMBER
					) is
	v_field_size NUMBER;
	v_pos NUMBER := 1;
BEGIN
 p_field_count := 0;

  p_fields := XXHA_SPLIT_FIELDS('','','','');

	IF ASCII(SUBSTR(p_name,1,1)) > 255 THEN
		v_field_size := p_cn_field_size;
	ELSE
		v_field_size := p_en_field_size;
	END IF;

	WHILE v_pos <= LENGTH(p_name) AND p_field_count < 4 LOOP
		p_field_count := p_field_count + 1;
		p_fields(p_field_count) := SUBSTR(p_name, v_pos, v_field_size);
		v_pos := v_pos + v_field_size;
	END LOOP;

END split_name;
PROCEDURE payments_ifile
            (   errbuf       OUT   VARCHAR2
              , retcode      OUT   NUMBER
              ,	P_PAYMENT_BATCH IN VARCHAR2
            )   is

--
v_date_time	 VARCHAR2(100);
v_hae_location_id 	 HR_LOCATIONS.location_id%TYPE;
v_hae_corp_name		 HR_LOCATIONS.address_line_1%TYPE;
--v_hae_address_line_2 HR_LOCATIONS.address_line_2%TYPE;
--v_hae_address_line_3 HR_LOCATIONS.address_line_3%TYPE;
--v_hae_TOWN_OR_CITY   HR_LOCATIONS.TOWN_OR_CITY%TYPE;
v_hae_COUNTRY		 HR_LOCATIONS.COUNTRY%TYPE;
--v_hae_postal_code	 HR_LOCATIONS.postal_code%TYPE;
v_hsbc_connect_customer_id VARCHAR2(11) := 'ABC66269001';
v_hsbcnet_customer_id VARCHAR2(18) := 'HKHBAPGHK500395348';
v_domestic_payment_flag BOOLEAN;
v_split_fields XXHA_SPLIT_FIELDS;
v_split_field_count NUMBER;
v_payment_count NUMBER;
BEGIN
FND_FILE.PUT_LINE(FND_FILE.LOG, 'Program:  *Haemonetics iFile Payments CSV File');
	FND_FILE.PUT_LINE(FND_FILE.LOG, 'Start Date Time: ' || to_char(sysdate, 'DD-MON-YYYY:HH24:MM:SS'));
	FND_FILE.PUT_LINE(FND_FILE.LOG, 'Start Parameters: ');
	FND_FILE.PUT_LINE(FND_FILE.LOG, 'End Parameters: ');
	FND_FILE.PUT_LINE(FND_FILE.LOG, 'Current Org ID: ' || v_org_id);
-- Get Hae Info
	-- Fnd_File.PUT_LINE(Fnd_File.LOG,'Bf Get Hae corp Info');
	----
	begin
 select hl.location_id
		,	   hl.address_line_1 hae_corp_name
--		,	   hl.address_line_2 hae_Adress_line2
--		,	   NVL(hl.address_line_3, 'NA') hae_address_line3  -- value required (atleast 1 character) if XML elemented listed
--		,	   hl.TOWN_OR_CITY	 hae_TOWN_OR_CITY
		,	   hl.COUNTRY		 hae_COUNTRY
--		,	   hl.postal_code    hae_postal_code
--		,	   hou.name
		INTO
			   v_hae_location_id
		,	   v_hae_corp_name
--		,	   v_hae_address_line_2
--		,	   v_hae_address_line_3
--		,	   v_hae_TOWN_OR_CITY
		,	   v_hae_COUNTRY
--		,	   v_hae_postal_code
--		,	   v_ou_name
		from   hr_operating_units hou
		, 	   hr_all_organization_units haou
		,	   hr_locations hl
		where  hou.organization_id = v_org_id
		and    hou.organization_id = haou.organization_id
		and	   haou.location_id = hl.location_id
		;

		-- Fnd_File.PUT_LINE(Fnd_File.LOG,'Get Hae corp Info  Successful');

		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'v_hae_location_id: ' || v_hae_location_id);
		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'v_hae_corp_name: ' || v_hae_corp_name);
		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'v_hae_COUNTRY: ' || v_hae_COUNTRY);
		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'p_payment_batch: ' || p_payment_batch);

	exception

		when others
		then
			FND_FILE.PUT_LINE ( FND_FILE.LOG, 'err: OTHERS error message in Get Hae Info: ' || SQLERRM );
			ROLLBACK;
			RAISE eNoHandle;
	end; ------------

	---
	-- Head Rec Cursor
	-- FND_FILE.PUT_LINE ( FND_FILE.LOG, 'Start Head Rec Cursor' );
	---

	for C_HEAD_REC in (
/* R12 Upgrade Modified on 10/23/2012 by Ramgopal, Rolta */
	/*select aiscv.checkrun_name
	,	   aiscv.invoice_count
	,	   aiscv.negot_payment_count
	,	   aiscv.overall_payment_count
	,	   aiscv.payment_total
	,	   aiscv.invoice_batch_name
	from   AP_INV_SELECTION_CRITERIA_V aiscv
	where  checkrun_name = P_PAYMENT_BATCH -- 'HRB3'
	and	   aiscv.status in ('FORMATTING','BUILT')*/
select iba.payment_process_request_name checkrun_name,
count(iba.payment_id)  negot_payment_count,
count(aia.invoice_id) invoice_count,
sum(iba.payment_amount) payment_total,
aba.BATCH_NAME invoice_batch_name
from iby_payments_all iba
     ,iby_docs_payable_all idpa
     ,ap_invoices_all aia
     ,ap_invoice_payments_all aipa
     ,AP_BATCHES_ALL aba
where 1=1
      AND iba.payment_process_request_name = p_payment_batch
      and iba.payment_id = idpa.payment_id
      and to_number (idpa.calling_app_doc_unique_ref2) = aia.invoice_id
      and aia.invoice_id = aipa.invoice_id
      and aipa.reversal_flag is null
      and AIA.BATCH_ID = ABA.BATCH_ID
group by PAYMENT_PROCESS_REQUEST_NAME,ABA.BATCH_NAME
	order by iba.creation_date desc
					  )
	LOOP
-- FND_FILE.PUT_LINE ( FND_FILE.LOG, 'Head Rec Cursor - In the Loop' );
	 -- File Header
-- Field 1 - record type
put_csv_field('IFH');
-- Field 2 - file format
		put_csv_field('IFILE');

		-- Field 3 - file type
		put_csv_field('CSV');

		-- Field 4 - HSBC Connect Customer ID
		put_csv_field(v_hsbc_connect_customer_id);

		-- Field 5 - HSBCnet Customer ID
		put_csv_field(v_hsbcnet_customer_id);

		-- Field 6 - file serial #
		select to_char(SYSDATE, 'YYYYMMDDHH24MISS')
		into	 v_date_time
		from   dual
		;
	  put_csv_field(v_date_time);

		-- Field 7 - file creation date
		select to_char(SYSDATE, 'YYYY/MM/DD')
		into	 v_date_time
		from   dual
		;

		put_csv_field(v_date_time);

		-- Field 8 - file creation time
		select to_char(SYSDATE, 'HH24:MI:SS')
		into	 v_date_time
		from   dual
		;

		put_csv_field(v_date_time);

		-- Field 9 - Authorization Type
		put_csv_field('P');

		-- Field 10 - File version
		put_csv_field('1.0');

		-- Field 11 - record count (more subtle ways haven't worked, so just run count of records in payment query)
		select COUNT(1) into V_PAYMENT_COUNT from (
/* R12 Upgrade Modified on 10/23/2012 by Ramgopal, Rolta */
			/*SELECT     distinct
					   aisc.CHECKRUN_NAME  		 			-- ==================================== Banks
			,	   	   aisc.payment_method_lookup_code payment_method -- EFT CHECK
			,	   	   aisc.bank_account_id     	   hae_bank_account_id
			,	   	   aisc.bank_account_name   	   hae_bank_account_name
			--,	   	   'NORM' 					       transfer_priority      -- NORM or HIGH
			,	   	   aisc.CHECK_DATE 	           	   payment_date
			,		   abb_hae.bank_num				   hae_bank_num
			,		   abb_hae.bank_branch_type		   hae_bank_branch_type
			,		   CASE WHEN abb_hae.bank_branch_type = 'ABA' then abb_hae.bank_num else null end		hae_bank_aba_num
			,		   abb_hae.BANK_NAME			   hae_bank_name
			,		   abb_hae.bank_branch_name		   hae_bank_branch_name
			,		   abb_hae.COUNTRY				   hae_bank_acct_country
			,		   abb_hae.eft_swift_code 		   hae_bank_BIC
			,		   aba_hae.bank_account_num    	   hae_bank_account_num
			,		   aba_hae.iban_number			   hae_bank_acct_IBAN_num
			,		   aba_hae.CURRENCY_CODE	       hae_bank_acct_curr_code
			,		   asic.vendor_num    		 supp_number  -- ================================== Supp
			,		   asic.selected_check_id	 selected_check_id
			,		   asic.vendor_name   		 supp_name
			,		   asic.VENDOR_SITE_CODE 	 supp_site_code
			,		   asic.CUSTOMER_NUM
			,		   asic.address_line1 		 supp_address_line1
			,		   asic.address_line2 		 supp_address_line2
			,		   asic.city			 	 supp_city
			,		   NVL(asic.STATE, asic.province) supp_state
			,		   asic.zip   		 		 supp_zip
			,		   asic.province 			 supp_PROVINCE
			,		   asic.COUNTRY 		 	 supp_country
			,		   ftv.territory_short_name  supp_COUNTRY_NAME
											  -- =================================================Inv
			,		   asic.check_id		  -- ==================================================Payments
			,		   asic.CHECK_NUMBER  	  	   CHECK_NUM--
			,		   aisc.currency_code  	  	   payment_currency_code -- from  Payment Batch
			,		   asic.CHECK_AMOUNT      	   PAYMENT_AMOUNT
			,		   asic.OK_TO_PAY_FLAG
			,		   asic.void_flag
			,		   'NORM'					   payment_priority
			,		   abb.bank_num				 supp_bank_num	-- ================================ Supp  Banks
			,		   abb.bank_branch_type		 supp_bank_branch_type
			,		   CASE WHEN abb.bank_branch_type = 'ABA' then abb.bank_num else null end		supp_bank_aba_num
			,		   abb.BANK_NAME			 supp_bank_name
			,		   abb.bank_branch_name		 supp_bank_branch_name
			,		   abb.eft_swift_code 		 supp_bank_BIC
			,		   aba.bank_account_num    	 supp_bank_acct_num
			,		   asic.external_bank_account_id	supp_bank_acct_id
			,		   aba.iban_number			 supp_bank_acct_IBAN_num
			,		   aba.CURRENCY_CODE	     supp_bank_acct_curr_code
			,		   abb.COUNTRY				 supp_bank_acct_country
			,		   ftv_b.territory_short_name supp_bank_acct_country_desc
			,	   	   vsi.jgzz_site_info2 	  	   supp_remit_type             -- BANK_ACCOUNT_TYPE
			,		   asic.country				   supp_site_country
			,		   pvs.pay_group_lookup_code supp_pay_group
			,		   pvs.email_address		 supp_email
			,		   pvs.remittance_email		 supp_remittance_email
			from 	   AP_INV_SELECTION_CRITERIA_ALL aisc
			,	   	   ap_bank_accounts_all aba_hae
			,	   	   ap_bank_branches abb_hae  ------
			,	 	   ap_selected_invoice_checks_all asic
			,		   fnd_territories_vl ftv
			,	 	   ap_bank_accounts_all aba
			,	 	   ap_bank_branches abb
			,		   fnd_territories_vl ftv_b
			,		   jg_zz_vend_site_info vsi		--
			,		   po_vendor_sites_all pvs
			where      aisc.checkrun_name  = P_PAYMENT_BATCH -- 'HRB3'   -- P_PAYMENT_BATCH
			and	   	   aisc.bank_account_id = aba_hae.bank_account_id
			and	   	   aba_hae.org_id = v_org_id
			and	   	   aba_hae.BANK_BRANCH_ID = abb_hae.bank_branch_id -- +++
			and 	   aisc.checkrun_name = asic.checkrun_name
			and	   	   aisc.org_id = v_org_id
			and    	   aisc.status in ('FORMATTING','BUILT')
			and	   	   asic.org_id = v_org_id
			and    	   asic.ok_to_pay_flag = 'Y' -- Very Important
			AND  	   asic.country = ftv.TERRITORY_CODE  (+)
			and    	   asic.external_bank_account_id = aba.bank_account_id (+)
			and	   	   aba.org_id (+) = v_org_id
			and    	   aba.bank_branch_id = abb.bank_branch_id (+)
			and		   abb.country = ftv_b.TERRITORY_CODE  (+)
			--    	   and aisc.vendor_pay_group = P_REP_PAY_TYPE
			and   	   ASIC.VENDOR_SITE_ID   = VSI.VENDOR_SITE_ID(+) -- +++++++++++++++++++++++
			and		   asic.vendor_site_id   = pvs.vendor_sitE_id(+)*/

     /* SELECT     distinct
					   aisc.CHECKRUN_NAME  		 			-- ==================================== Banks
			,	   	   aca.payment_method_lookup_code payment_method -- EFT CHECK
			,	   	   aba_hae.bank_account_id     	   hae_bank_account_id
			,	   	   aba_hae.bank_account_name   	   hae_bank_account_name
			--,	   	   'NORM' 					       transfer_priority      -- NORM or HIGH
			,	   	   aisc.CHECK_DATE 	           	   payment_date
			,		   abb_hae.branch_number				   hae_bank_num
			,		   ABB_HAE.BANK_BRANCH_TYPE		   HAE_BANK_BRANCH_TYPE
			,		   CASE WHEN abb_hae.bank_branch_type = 'ABA' then abb_hae.branch_number else null end		hae_bank_aba_num
			,		   abb_hae.BANK_NAME			   hae_bank_name
			,		   abb_hae.bank_branch_name		   hae_bank_branch_name
			,		   abb_hae.COUNTRY				   hae_bank_acct_country
			,		   abb_hae.eft_swift_code 		   hae_bank_BIC
			,		   aba_hae.bank_account_num    	   hae_bank_account_num
			,		   aba_hae.iban_number			   hae_bank_acct_IBAN_num
			,		   aba_hae.CURRENCY_CODE	       hae_bank_acct_curr_code
			,		   asic.vendor_num    		 supp_number  -- ================================== Supp
			,		   asic.selected_check_id	 selected_check_id
			,		   asic.vendor_name   		 supp_name
			,		   asic.VENDOR_SITE_CODE 	 supp_site_code
			,		   asic.CUSTOMER_NUM
			,		   asic.address_line1 		 supp_address_line1
			,		   asic.address_line2 		 supp_address_line2
			,		   asic.city			 	 supp_city
			,		   NVL(asic.STATE, asic.province) supp_state
			,		   asic.zip   		 		 supp_zip
			,		   asic.province 			 supp_PROVINCE
			,		   asic.COUNTRY 		 	 supp_country
			,		   ftv.territory_short_name  supp_COUNTRY_NAME
											  -- =================================================Inv
			,		   asic.check_id		  -- ==================================================Payments
			,		   asic.CHECK_NUMBER  	  	   CHECK_NUM--
			,		   aisc.currency_code  	  	   payment_currency_code -- from  Payment Batch
			,		   asic.CHECK_AMOUNT      	   PAYMENT_AMOUNT
			,		   asic.OK_TO_PAY_FLAG
			,		   asic.void_flag
			,		   'NORM'					   payment_priority
			,		   iebb.branch_number				 supp_bank_num	-- ================================ Supp  Banks
			,		   iebb.bank_branch_type		 supp_bank_branch_type
			,		   CASE WHEN iebb.bank_branch_type = 'ABA' then iebb.branch_number else null end		supp_bank_aba_num
			,		   iebv.bank_name			 supp_bank_name
			,		   iebb.bank_branch_name		 supp_bank_branch_name
			,		   iebb.eft_swift_code 		 supp_bank_BIC
			,		   ieb.bank_account_num    	 supp_bank_acct_num
			,		   asic.external_bank_account_id	supp_bank_acct_id
			,		   ieb.iban			 supp_bank_acct_IBAN_num
			,		   ieb.currency_code	     supp_bank_acct_curr_code
			,		   iebv.home_country				 supp_bank_acct_country
			,		   ftv_b.territory_short_name supp_bank_acct_country_desc
			,	   	   vsi.jgzz_site_info2 	  	   supp_remit_type             -- BANK_ACCOUNT_TYPE
			,		   asic.country				   supp_site_country
			,		   pvs.pay_group_lookup_code supp_pay_group
			,		   pvs.email_address		 supp_email
			,		   pvs.remittance_email		 supp_remittance_email
			from 	   AP_INV_SELECTION_CRITERIA_ALL AISC
      ,        AP_CHECKS_ALL ACA
      ,        ce_bank_acct_uses_all cbau
			,	   	   CE_BANK_ACCOUNTS ABA_HAE
			,	   	   CE_BANK_BRANCHES_V abb_hae  ------
			,	 	   ap_selected_invoice_checks_all asic
			,		   FND_TERRITORIES_VL FTV
			,      IBY_EXTERNAL_PAYEES_ALL IEP
      ,      IBY_PMT_INSTR_USES_ALL IPI
      ,      IBY_EXT_BANK_ACCOUNTS IEB
      ,      IBY_EXT_BANKS_V IEBV
      ,      iby_ext_bank_branches_v iebb
			,		   fnd_territories_vl ftv_b
			,		   JG_ZZ_VEND_SITE_INFO VSI		--
			,		   AP_SUPPLIER_SITES_ALL PVS
			where     AISC.CHECKRUN_NAME  = P_PAYMENT_BATCH -- 'HRB3'   -- P_PAYMENT_BATCH
      and     AISC.CHECKRUN_NAME = ACA.CHECKRUN_NAME
      and     ACA.CE_BANK_ACCT_USE_ID = CBAU.BANK_ACCT_USE_ID
      and     CBAU.BANK_ACCOUNT_ID = ABA_HAE.BANK_ACCOUNT_ID
      and     ABA_HAE.BANK_BRANCH_ID = ABB_HAE.BRANCH_PARTY_ID
			and 	   AISC.CHECKRUN_NAME = ASIC.CHECKRUN_NAME
			and	   	   aisc.org_id = v_org_id
			and    	   AISC.STATUS in ('FORMATTING','BUILT')
			and	   	   asic.org_id = v_org_id
			and    	   asic.ok_to_pay_flag = 'Y' -- Very Important
			AND  	   asic.country = ftv.TERRITORY_CODE  (+)
			and    	   ASIC.EXTERNAL_BANK_ACCOUNT_ID = ieb.ext_bank_account_id (+)
      and    IEP.EXT_PAYEE_ID = IPI.EXT_PMT_PARTY_ID
      and    IPI.INSTRUMENT_ID = IEB.EXT_BANK_ACCOUNT_ID
      and    IEB.BRANCH_ID = IEBB.BRANCH_PARTY_ID
      and    IEBV.BANK_PARTY_ID=IEBB.BANK_PARTY_ID
      and    iebb.bank_party_id   = ieb.bank_id
			and		   iebb.country = ftv_b.TERRITORY_CODE  (+)
			--    	   and aisc.vendor_pay_group = P_REP_PAY_TYPE
			and   	   ASIC.VENDOR_SITE_ID   = VSI.VENDOR_SITE_ID(+) -- +++++++++++++++++++++++
			and		   ASIC.VENDOR_SITE_ID   = PVS.VENDOR_SITE_ID(+)
      and    iep.supplier_site_id=pvs.vendor_site_id*/
      select     distinct
					    nvl(iba.payment_process_request_name, ipsr.call_app_pay_service_req_code) CHECKRUN_NAME  		 			-- ==================================== Banks
			,	   	   iba.payment_method_code payment_method -- EFT CHECK
			,	   	   iba.internal_bank_account_id     	   hae_bank_account_id
			,	   	   iba.int_bank_account_name   	   hae_bank_account_name
			--,	   	   'NORM' 					       transfer_priority      -- NORM or HIGH
			,	   	   iba.payment_date
			,		   abb_hae.branch_number				   hae_bank_num
			,		   abb_hae.bank_branch_type		   hae_bank_branch_type
			,		   CASE WHEN abb_hae.bank_branch_type = 'ABA' then abb_hae.branch_number else null end		hae_bank_aba_num
			,		   iba.int_bank_name			   hae_bank_name
			,		   iba.int_bank_branch_name		   hae_bank_branch_name
			,		   abb_hae.COUNTRY				   hae_bank_acct_country
			,		   iba.int_eft_swift_code 		   hae_bank_BIC
			,		   iba.int_bank_account_number    	   hae_bank_account_num
			,		   iba.int_bank_account_iban			   hae_bank_acct_IBAN_num
			,		   aba_hae.CURRENCY_CODE	       hae_bank_acct_curr_code
			,		   IBA.PAYEE_SUPPLIER_NUMBER    		 SUPP_NUMBER  -- ================================== Supp
			--,		   asic.selected_check_id	 selected_check_id
			,		   aps.vendor_name   		 supp_name
			,		   iba.payee_supplier_site_name 	 supp_site_code
			,		   aps.CUSTOMER_NUM
			,		   IBA.PAYEE_ADDRESS1 		 SUPP_ADDRESS_LINE1
			,		   iba.payee_address2 		 supp_address_line2
			,		   iba.payee_city			 	 supp_city
			,		   nvl(iba.payee_state, iba.payee_province) supp_state
			,		   iba.payee_postal_code   		 		 supp_zip
			,		   iba.payee_province 			 supp_PROVINCE
			,		   iba.payee_country 		 	 supp_country
			,		   ftv.territory_short_name  supp_COUNTRY_NAME
											  -- =================================================Inv
			--,		   asic.check_id		  -- ==================================================Payments
			,		   iba.paper_document_number  	  	   CHECK_NUM--
			,		   IBA.PAYMENT_CURRENCY_CODE -- from  Payment Batch
			,		   IBA.PAYMENT_AMOUNT
			--,		   asic.OK_TO_PAY_FLAG
			--,		   asic.void_flag
			,		   'NORM'					   payment_priority
			,		   iebb.branch_number				 supp_bank_num	-- ================================ Supp  Banks
			,		   IEBB.BANK_BRANCH_TYPE		 SUPP_BANK_BRANCH_TYPE
			,		   CASE WHEN iebb.bank_branch_type = 'ABA' then iebb.branch_number else null end		supp_bank_aba_num
			,		   iba.ext_bank_name			 supp_bank_name
			,		   iba.ext_bank_branch_name		 supp_bank_branch_name
			,		   iba.ext_eft_swift_code 		 supp_bank_BIC
			,		   iba.ext_bank_account_number    	 supp_bank_acct_num
			,		   iba.external_bank_account_id	supp_bank_acct_id
			,		   IBA.EXT_BANK_ACCOUNT_IBAN_NUMBER			 SUPP_BANK_ACCT_IBAN_NUM
			,		   ieb.CURRENCY_CODE	     supp_bank_acct_curr_code
			,		   iebv.home_country				 supp_bank_acct_country
			,		   ftv_b.territory_short_name supp_bank_acct_country_desc
			,	   	   vsi.jgzz_site_info2 	  	   supp_remit_type             -- BANK_ACCOUNT_TYPE
			,		   iba.payee_country				   supp_site_country
			,		   ASS.PAY_GROUP_LOOKUP_CODE SUPP_PAY_GROUP
			,		   ASS.EMAIL_ADDRESS		 SUPP_EMAIL
			,		   ass.remittance_email		 supp_remittance_email
			from 	   ce_bank_accounts aba_hae,
 	   	 ce_bank_branches_v abb_hae,
        iby_payments_all iba,
        iby_docs_payable_all idpa,
        iby_pay_service_requests ipsr,
        ap_checks_all aca1,
        fnd_territories_vl ftv,
        fnd_territories_vl ftv_b,
        jg_zz_vend_site_info vsi,
        ap_supplier_sites_all ass,
        ap_suppliers aps,
        iby_ext_bank_accounts ieb,
        iby_ext_bank_branches_v iebb,
        iby_ext_banks_v iebv
			where      1=1--aisc.checkrun_name like '3'
 --and   aisc.checkrun_name  = p_payment_batch -- 'HRB3'   -- P_PAYMENT_BATCH
 and   iba.payment_process_request_name  = p_payment_batch -- 'HRB3'   -- P_PAYMENT_BATCH
 --and	   aisc.org_id = v_org_id
 and	   iba.org_id = v_org_id
 and	  aba_hae.bank_branch_id = abb_hae.branch_party_id
 and   aba_hae.bank_account_id = iba.internal_bank_account_id
 --and   aisc.checkrun_name = iba.payment_process_request_name
 and   iba.payment_id = idpa.payment_id
 and   to_number (idpa.calling_app_doc_unique_ref1) = aca1.checkrun_id
 and ipsr.payment_service_request_id = idpa.payment_service_request_id
 --and   aisc.status in ('SELECTED')
 and   iba.PAYMENT_STATUS in ('FORMATTED')
 --and   iba.payments_complete_flag = 'Y'
 and   iba.payee_country = ftv.territory_code(+)
 and   iba.payee_country = ftv_b.territory_code(+)
 --and	  iebb.country = ftv_b.territory_code  (+)
 and   iba.external_bank_account_id = ieb.ext_bank_account_id (+)
 and   ieb.branch_id = iebb.branch_party_id
 and   iba.supplier_site_id   = vsi.vendor_site_id(+) -- +++++++++++++++++++++++
 and	  iba.supplier_site_id   = ass.vendor_site_id(+)
 and   ass.vendor_id = aps.vendor_id
 and   IEBV.BANK_PARTY_ID = IEBB.BANK_PARTY_ID
 and   ieb.bank_id = iebv.bank_party_id
			order by
				iba.paper_document_number
		);

		put_csv_field(to_char(1 + v_payment_count * 2));

		-- Field 12 - character encoding (U801 = UTF-8)
		put_csv_field('U801', TRUE);

		FND_FILE.PUT_LINE ( FND_FILE.LOG, '************** H e a d e r  I n f o **************' );

		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'No. of Invoices: ' || c_head_rec.invoice_count );
		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'No. Payments (Negot Payment Count): ' || c_head_rec.negot_payment_count );
		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'Total Payments: ' || c_head_rec.payment_total );

	END LOOP;   --- End Grp Hdr


	FND_FILE.PUT_LINE ( FND_FILE.LOG, 'Before Payment Rec Cursor' );

	for C_PAY_REC in (
/* R12 Upgrade Modified on 10/23/2012 by Ramgopal, Rolta */
	/*SELECT     distinct
			   aisc.CHECKRUN_NAME  		 			-- ==================================== Banks
	,	   	   aisc.payment_method_lookup_code payment_method -- EFT CHECK
	,	   	   aisc.bank_account_id     	   hae_bank_account_id
	,	   	   aisc.bank_account_name   	   hae_bank_account_name
	--,	   	   'NORM' 					       transfer_priority      -- NORM or HIGH
	,	   	   aisc.CHECK_DATE 	           	   payment_date
	,		   abb_hae.bank_num				   hae_bank_num
	,		   abb_hae.bank_branch_type		   hae_bank_branch_type
	,		   CASE WHEN abb_hae.bank_branch_type = 'ABA' then abb_hae.bank_num else null end		hae_bank_aba_num
	,		   abb_hae.BANK_NAME			   hae_bank_name
	,		   abb_hae.bank_branch_name		   hae_bank_branch_name
	,		   abb_hae.COUNTRY				   hae_bank_acct_country
	,		   abb_hae.eft_swift_code 		   hae_bank_BIC
	,		   aba_hae.bank_account_num    	   hae_bank_account_num
	,		   aba_hae.iban_number			   hae_bank_acct_IBAN_num
	,		   aba_hae.CURRENCY_CODE	       hae_bank_acct_curr_code
	,		   asic.vendor_num    		 supp_number  -- ================================== Supp
	,		   asic.selected_check_id	 selected_check_id
	,		   asic.vendor_name   		 supp_name
	,		   asic.VENDOR_SITE_CODE 	 supp_site_code
	,		   asic.CUSTOMER_NUM
	,		   asic.address_line1 		 supp_address_line1
	,		   asic.address_line2 		 supp_address_line2
	,		   asic.city			 	 supp_city
	,		   NVL(asic.STATE, asic.province) supp_state
	,		   asic.zip   		 		 supp_zip
	,		   asic.province 			 supp_PROVINCE
	,		   asic.COUNTRY 		 	 supp_country
	,		   ftv.territory_short_name  supp_COUNTRY_NAME
									  -- =================================================Inv
	,		   asic.check_id		  -- ==================================================Payments
	,		   asic.CHECK_NUMBER  	  	   CHECK_NUM--
	,		   aisc.currency_code  	  	   payment_currency_code -- from  Payment Batch
	,		   asic.CHECK_AMOUNT      	   PAYMENT_AMOUNT
	,		   asic.OK_TO_PAY_FLAG
	,		   asic.void_flag
	,		   'NORM'					   payment_priority
	,		   abb.bank_num				 supp_bank_num	-- ================================ Supp  Banks
	,		   abb.bank_branch_type		 supp_bank_branch_type
	,		   CASE WHEN abb.bank_branch_type = 'ABA' then abb.bank_num else null end		supp_bank_aba_num
	,		   abb.BANK_NAME			 supp_bank_name
	,		   abb.bank_branch_name		 supp_bank_branch_name
	,		   abb.eft_swift_code 		 supp_bank_BIC
	,		   aba.bank_account_num    	 supp_bank_acct_num
	,		   aba.bank_account_name	 supp_bank_account_name -- added 2012-03-14	Eric Rossing	Use Bank Account Name instead of Supplier Name for the SECPTY field 3
	,		   asic.external_bank_account_id	supp_bank_acct_id
	,		   aba.iban_number			 supp_bank_acct_IBAN_num
	,		   aba.CURRENCY_CODE	     supp_bank_acct_curr_code
	,		   abb.COUNTRY				 supp_bank_acct_country
	,		   ftv_b.territory_short_name supp_bank_acct_country_desc
	,	   	   vsi.jgzz_site_info2 	  	   supp_remit_type             -- BANK_ACCOUNT_TYPE
	,		   asic.country				   supp_site_country
	,		   pvs.pay_group_lookup_code supp_pay_group
	,		   pvs.email_address		 supp_email
	,		   pvs.remittance_email		 supp_remittance_email
	from 	   AP_INV_SELECTION_CRITERIA_ALL aisc
	,	   	   ap_bank_accounts_all aba_hae
	,	   	   ap_bank_branches abb_hae  ------
	,	 	   ap_selected_invoice_checks_all asic
	,		   fnd_territories_vl ftv
	,	 	   ap_bank_accounts_all aba
	,	 	   ap_bank_branches abb
	,		   fnd_territories_vl ftv_b
	,		   jg_zz_vend_site_info vsi		--
	,		   po_vendor_sites_all pvs
	where      aisc.checkrun_name  = P_PAYMENT_BATCH -- 'HRB3'   -- P_PAYMENT_BATCH
	and	   	   aisc.bank_account_id = aba_hae.bank_account_id
	and	   	   aba_hae.org_id = v_org_id
	and	   	   aba_hae.BANK_BRANCH_ID = abb_hae.bank_branch_id -- +++
	and 	   aisc.checkrun_name = asic.checkrun_name
	and	   	   aisc.org_id = v_org_id
	and    	   aisc.status in ('FORMATTING','BUILT')
	and	   	   asic.org_id = v_org_id
	and    	   asic.ok_to_pay_flag = 'Y' -- Very Important
	AND  	   asic.country = ftv.TERRITORY_CODE  (+)
	and    	   asic.external_bank_account_id = aba.bank_account_id (+)
	and	   	   aba.org_id (+) = v_org_id
	and    	   aba.bank_branch_id = abb.bank_branch_id (+)
	and		   abb.country = ftv_b.TERRITORY_CODE  (+)
	--    	   and aisc.vendor_pay_group = P_REP_PAY_TYPE
	and   	   asic.vendor_site_id   = vsi.vendor_site_id(+) -- +++++++++++++++++++++++
	and		   asic.vendor_site_id   = pvs.vendor_sitE_id(+)*/
 /* SELECT     distinct
			   aisc.CHECKRUN_NAME  		 			-- ==================================== Banks
	,	   	   aca.payment_method_lookup_code payment_method -- EFT CHECK
	,	   	   aba_hae.bank_account_id     	   hae_bank_account_id
	,	   	   aba_hae.bank_account_name   	   hae_bank_account_name
	--,	   	   'NORM' 					       transfer_priority      -- NORM or HIGH
	,	   	   aisc.CHECK_DATE 	           	   payment_date
	,		   abb_hae.branch_number				   hae_bank_num
	,		   ABB_HAE.BANK_BRANCH_TYPE		   HAE_BANK_BRANCH_TYPE
	,		   CASE WHEN abb_hae.bank_branch_type = 'ABA' then abb_hae.branch_number else null end		hae_bank_aba_num
	,		   abb_hae.BANK_NAME			   hae_bank_name
	,		   abb_hae.bank_branch_name		   hae_bank_branch_name
	,		   abb_hae.COUNTRY				   hae_bank_acct_country
	,		   abb_hae.eft_swift_code 		   hae_bank_BIC
	,		   aba_hae.bank_account_num    	   hae_bank_account_num
	,		   aba_hae.iban_number			   hae_bank_acct_IBAN_num
	,		   aba_hae.CURRENCY_CODE	       hae_bank_acct_curr_code
	,		   asic.vendor_num    		 supp_number  -- ================================== Supp
	,		   asic.selected_check_id	 selected_check_id
	,		   asic.vendor_name   		 supp_name
	,		   asic.VENDOR_SITE_CODE 	 supp_site_code
	,		   asic.CUSTOMER_NUM
	,		   asic.address_line1 		 supp_address_line1
	,		   asic.address_line2 		 supp_address_line2
	,		   asic.city			 	 supp_city
	,		   NVL(asic.STATE, asic.province) supp_state
	,		   asic.zip   		 		 supp_zip
	,		   asic.province 			 supp_PROVINCE
	,		   asic.COUNTRY 		 	 supp_country
	,		   ftv.territory_short_name  supp_COUNTRY_NAME
									  -- =================================================Inv
	,		   asic.check_id		  -- ==================================================Payments
	,		   asic.CHECK_NUMBER  	  	   CHECK_NUM--
	,		   aisc.currency_code  	  	   payment_currency_code -- from  Payment Batch
	,		   asic.CHECK_AMOUNT      	   PAYMENT_AMOUNT
	,		   asic.OK_TO_PAY_FLAG
	,		   asic.void_flag
	,		   'NORM'					   payment_priority
	,		   iebb.branch_number				 supp_bank_num	-- ================================ Supp  Banks
	,		   iebb.bank_branch_type		 supp_bank_branch_type
	,		   CASE WHEN iebb.bank_branch_type = 'ABA' then iebb.branch_number else null end		supp_bank_aba_num
	,		   iebv.bank_name			 supp_bank_name
	,		   iebb.bank_branch_name		 supp_bank_branch_name
	,		   iebb.eft_swift_code 		 supp_bank_BIC
	,		   IEB.BANK_ACCOUNT_NUM    	 SUPP_BANK_ACCT_NUM
	,		   ieb.bank_account_name	 supp_bank_account_name -- added 2012-03-14	Eric Rossing	Use Bank Account Name instead of Supplier Name for the SECPTY field 3
	,		   asic.external_bank_account_id	supp_bank_acct_id
	,		   ieb.iban			 supp_bank_acct_IBAN_num
	,		   ieb.currency_code	     supp_bank_acct_curr_code
	,		   iebv.home_country				 supp_bank_acct_country
	,		   ftv_b.territory_short_name supp_bank_acct_country_desc
	,	   	   vsi.jgzz_site_info2 	  	   supp_remit_type             -- BANK_ACCOUNT_TYPE
	,		   asic.country				   supp_site_country
	,		   pvs.pay_group_lookup_code supp_pay_group
	,		   pvs.email_address		 supp_email
	,		   pvs.remittance_email		 supp_remittance_email
	from 	   AP_INV_SELECTION_CRITERIA_ALL AISC
  ,      AP_CHECKS_ALL ACA
  ,      CE_BANK_ACCT_USES_ALL CBAU
  ,	   	 CE_BANK_ACCOUNTS ABA_HAE
  ,	   	 ce_bank_branches_v abb_hae  ------
	,	 	   ap_selected_invoice_checks_all asic
	,		   fnd_territories_vl ftv
	,      IBY_EXTERNAL_PAYEES_ALL IEP
  ,      IBY_PMT_INSTR_USES_ALL IPI
  ,      IBY_EXT_BANK_ACCOUNTS IEB
  ,      IBY_EXT_BANKS_V IEBV
  ,      iby_ext_bank_branches_v iebb
	,		   fnd_territories_vl ftv_b
	,		   JG_ZZ_VEND_SITE_INFO VSI		--
	,		   AP_SUPPLIER_SITES_ALL PVS
	where    AISC.CHECKRUN_NAME  = P_PAYMENT_BATCH -- 'HRB3'   -- P_PAYMENT_BATCH
    and    AISC.CHECKRUN_NAME = ACA.CHECKRUN_NAME
    and    ACA.CE_BANK_ACCT_USE_ID = CBAU.BANK_ACCT_USE_ID
    and    CBAU.BANK_ACCOUNT_ID = ABA_HAE.BANK_ACCOUNT_ID
    and	   ABA_HAE.BANK_BRANCH_ID = ABB_HAE.BRANCH_PARTY_ID -- +++
	  and 	 AISC.CHECKRUN_NAME = ASIC.CHECKRUN_NAME
    and	   AISC.ORG_ID = V_ORG_ID
	  and    AISC.STATUS in ('FORMATTING','BUILT')
	  and	   asic.org_id = v_org_id
	  and    ASIC.OK_TO_PAY_FLAG = 'Y' -- Very Important
	  and  	 ASIC.COUNTRY = FTV.TERRITORY_CODE  (+)
	  and    ASIC.EXTERNAL_BANK_ACCOUNT_ID = IEB.EXT_BANK_ACCOUNT_ID(+)
	  and		 iebb.country = ftv_b.TERRITORY_CODE  (+)
	--    	 and aisc.vendor_pay_group = P_REP_PAY_TYPE
	  and    ASIC.VENDOR_SITE_ID   = VSI.VENDOR_SITE_ID(+) -- +++++++++++++++++++++++
   	and		 ASIC.VENDOR_SITE_ID   = PVS.VENDOR_SITE_ID(+)
    and    IEP.EXT_PAYEE_ID = IPI.EXT_PMT_PARTY_ID
    and    IPI.INSTRUMENT_ID = IEB.EXT_BANK_ACCOUNT_ID
    and    IEB.BRANCH_ID = IEBB.BRANCH_PARTY_ID
    and    IEBV.BANK_PARTY_ID=IEBB.BANK_PARTY_ID
    and    IEBB.BANK_PARTY_ID   = IEB.BANK_ID
    and    iep.supplier_site_id=pvs.vendor_site_id*/
    select     distinct
			   nvl(iba.payment_process_request_name, ipsr.call_app_pay_service_req_code) CHECKRUN_NAME  		 			-- ==================================== Banks
	,	   	   iba.payment_method_code payment_method -- EFT CHECK
	,	   	   iba.internal_bank_account_id     	   hae_bank_account_id
	,	   	   iba.int_bank_account_name   	   hae_bank_account_name
	--,	   	   'NORM' 					       transfer_priority      -- NORM or HIGH
	,	   	   iba.payment_date
	,		   abb_hae.branch_number				   hae_bank_num
	,		   ABB_HAE.BANK_BRANCH_TYPE		   HAE_BANK_BRANCH_TYPE
	,		   CASE WHEN abb_hae.bank_branch_type = 'ABA' then abb_hae.branch_number else null end		hae_bank_aba_num
	,		   iba.int_bank_name			   hae_bank_name
	,		   iba.int_bank_branch_name		   hae_bank_branch_name
	,		   abb_hae.COUNTRY				   hae_bank_acct_country
	,		   iba.int_eft_swift_code 		   hae_bank_BIC
	,		   iba.int_bank_account_number    	   hae_bank_account_num
	,		   iba.int_bank_account_iban			   hae_bank_acct_IBAN_num
	,		   aba_hae.CURRENCY_CODE	       hae_bank_acct_curr_code
	,		   IBA.PAYEE_SUPPLIER_NUMBER    		 SUPP_NUMBER  -- ================================== Supp
	--,		   asic.selected_check_id	 selected_check_id
	,		   aps.vendor_name   		 supp_name
	,		   IBA.PAYEE_SUPPLIER_SITE_NAME 	 SUPP_SITE_CODE
	,		   aps.CUSTOMER_NUM
	,		   IBA.PAYEE_ADDRESS1 		 SUPP_ADDRESS_LINE1
	,		   iba.payee_address2 		 supp_address_line2
	,		   iba.payee_city			 	 supp_city
	,		   nvl(iba.payee_state, iba.payee_province) supp_state
	,		   iba.payee_postal_code   		 		 supp_zip
	,		   iba.payee_province 			 supp_PROVINCE
	,		   iba.payee_country		 	 supp_country
	,		   ftv.territory_short_name  supp_COUNTRY_NAME
									  -- =================================================Inv
	--,		   asic.check_id		  -- ==================================================Payments
	,		   iba.paper_document_number  	  	   CHECK_NUM--
	,		   IBA.PAYMENT_CURRENCY_CODE  	  	   PAYMENT_CURRENCY_CODE -- from  Payment Batch
	,		   IBA.PAYMENT_AMOUNT
	--,		   asic.OK_TO_PAY_FLAG
	--,		   asic.void_flag
	,		   'NORM'					   payment_priority
	,		   iebb.branch_number				 supp_bank_num	-- ================================ Supp  Banks
	,		   iebb.bank_branch_type		 supp_bank_branch_type
	,		   CASE WHEN iebb.bank_branch_type = 'ABA' then iebb.branch_number else null end		supp_bank_aba_num
	,		   iba.ext_bank_name			 supp_bank_name
	,		   iba.ext_bank_branch_name		 supp_bank_branch_name
	,		   iba.ext_eft_swift_code 		 supp_bank_BIC
	,		   IBA.EXT_BANK_ACCOUNT_NUMBER    	 SUPP_BANK_ACCT_NUM
	,		   iba.EXT_BANK_ACCOUNT_NAME	 supp_bank_account_name -- added 2012-03-14	Eric Rossing	Use Bank Account Name instead of Supplier Name for the SECPTY field 3
	,		   iba.external_bank_account_id	supp_bank_acct_id
	,		   iba.ext_bank_account_iban_number			 supp_bank_acct_IBAN_num
	,		   ieb.currency_code	     supp_bank_acct_curr_code
	,		   iebv.home_country				 supp_bank_acct_country
	,		   ftv_b.territory_short_name supp_bank_acct_country_desc
	,	   	   vsi.jgzz_site_info2 	  	   supp_remit_type             -- BANK_ACCOUNT_TYPE
	,		   IBA.PAYEE_COUNTRY				   SUPP_SITE_COUNTRY
	,		   ass.PAY_GROUP_LOOKUP_CODE SUPP_PAY_GROUP
	,		   ASS.EMAIL_ADDRESS		 SUPP_EMAIL
	,		   ass.remittance_email		 supp_remittance_email
	from 	   ce_bank_accounts aba_hae,
 	   	 ce_bank_branches_v abb_hae,
        iby_payments_all iba,
        iby_docs_payable_all idpa,
        iby_pay_service_requests ipsr,
        ap_checks_all aca1,
        fnd_territories_vl ftv,
        fnd_territories_vl ftv_b,
        jg_zz_vend_site_info vsi,
        ap_supplier_sites_all ass,
        ap_suppliers aps,
        iby_ext_bank_accounts ieb,
        iby_ext_bank_branches_v iebb,
        IBY_EXT_BANKS_V IEBV
	where   1=1
 and   iba.payment_process_request_name  = p_payment_batch -- 'HRB3'   -- P_PAYMENT_BATCH
 and	   iba.org_id = v_org_id
 and	  aba_hae.bank_branch_id = abb_hae.branch_party_id
 and   aba_hae.bank_account_id = iba.internal_bank_account_id
 and   iba.payment_id = idpa.payment_id
 and   to_number (idpa.calling_app_doc_unique_ref1) = aca1.checkrun_id
 and ipsr.payment_service_request_id = idpa.payment_service_request_id
 and   iba.PAYMENT_STATUS in ('FORMATTED')
 and   iba.payee_country = ftv.territory_code(+)
 and   iba.payee_country = ftv_b.territory_code(+)
 and   iba.external_bank_account_id = ieb.ext_bank_account_id (+)
 and   ieb.branch_id = iebb.branch_party_id
 and   iba.supplier_site_id   = vsi.vendor_site_id(+) -- +++++++++++++++++++++++
 and	  iba.supplier_site_id   = ass.vendor_site_id(+)
 and   ass.vendor_id = aps.vendor_id
 and   IEBV.BANK_PARTY_ID = IEBB.BANK_PARTY_ID
 and   ieb.bank_id = iebv.bank_party_id
	order by
		  iba.paper_document_number
	)
	LOOP
vRecCounter := vRecCounter + 1;
FND_FILE.PUT_LINE(FND_FILE.LOG, 'P a y m e n t  R e c o r d # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ' || vRecCounter);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '*********************************************************************************************************************************************');
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Haemo Bank Account Country: ' || c_pay_rec.hae_bank_acct_country);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Haemo Bank Account Currency Code: ' || c_pay_rec.hae_bank_acct_curr_code);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Supplier Bank Account Country: ' || c_pay_rec.supp_bank_acct_country);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Payment Currency Code: ' || c_pay_rec.payment_currency_code);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Supplier Bank Name: ' || c_pay_rec.supp_bank_name);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Supplier Bank Branch Name: ' || c_pay_rec.supp_bank_branch_name);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Supplier Pay Group: ' || c_pay_rec.supp_pay_group);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Payment Method: ' || c_pay_rec.payment_method);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Payment Batch Name:' || c_pay_rec.checkrun_name);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Haemo Bank Account ID:' || c_pay_rec.hae_bank_account_id);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Supplier Bank Account ID: ' || c_pay_rec.supp_bank_acct_id);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Supplier Name: ' || c_pay_rec.supp_name);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '    Supplier Bank Account Name: ' || c_pay_rec.supp_bank_account_name);
		FND_FILE.PUT_LINE(FND_FILE.LOG, '*********************************************************************************************************************************************');
-- Batch Header Record
-- Field 1 - record identifier
		put_csv_field('BATHDR');
-- Field 2 - instruction type (if local currency and local bank, LTR. otherwise FTR)
		v_domestic_payment_flag := (c_pay_rec.payment_currency_code = c_pay_rec.hae_bank_acct_curr_code AND c_pay_rec.supp_bank_acct_country = c_pay_rec.hae_bank_acct_country);
		if v_domestic_payment_flag THEN
			put_csv_field('LTR');
		ELSE
			put_csv_field('FTR');
		END IF;
		-- Field 3 - instructions in batch (fixed at 1)
		put_csv_field('1');

		-- Field 4 - batch reference (batch # + payment #)
		put_csv_field(p_payment_batch || '-' || c_pay_rec.check_num);
		-- Fields 5-9 - empty fields
		put_empty_fields(5);

		-- Field 10 - field marker
		put_csv_field('@1ST@');

		-- Field 11 - payment date
		v_date_time := TO_CHAR(c_pay_rec.payment_date, 'YYYYMMDD');

		put_csv_field(v_date_time);

		-- Field 12 - payment account number
		put_csv_field(REPLACE(c_pay_rec.hae_bank_account_num,'-'));

		-- Field 13 - transaction currency
		put_csv_field(c_pay_rec.payment_currency_code);

		-- Field 14 - transaction amount
		put_csv_field(c_pay_rec.payment_amount);

		-- Field 15-16 - empty fields
		put_empty_fields(2);

		-- Field 17 - Haemo account country
		put_csv_field(c_pay_rec.hae_bank_acct_country);

		-- Field 18 - Haemo account bank
		put_csv_field('HBAP');

		-- Field 19 - Haemo account currency
		put_csv_field(c_pay_rec.hae_bank_acct_curr_code);

		-- Field 20 - empty field
		put_empty_fields(1);

		-- Field 21 - Haemo account name
		split_name(REPLACE(REPLACE(v_hae_corp_name,'?','??'),',','?,'), 35, 11, v_split_fields, v_split_field_count);
		put_csv_field(v_split_fields(1));

		-- Field 22 - Haemo account name overflow
		put_csv_field(v_split_fields(2));

		-- Fields 23-26 - empty fields
		put_empty_fields(4);

		-- Field 27 - customer reference
		put_csv_field(c_pay_rec.check_num, TRUE);

		-- Second Party Record
		-- Field 1 - Record Type
		put_csv_field('SECPTY');

		-- Field 2 - Second Party Account Number
		put_csv_field(c_pay_rec.supp_bank_acct_num);

		-- Field 3 - Second Party Name
 -- changed 2012-03-14	Eric Rossing	Use Bank Account Name instead of Supplier Name for the SECPTY field 3
 --		split_name(REPLACE(REPLACE(c_pay_rec.supp_name,'?','??'),',','?,'), 35, 11, v_split_fields, v_split_field_count);
		split_name(REPLACE(REPLACE(c_pay_rec.supp_bank_account_name,'?','??'),',','?,'), 35, 11, v_split_fields, v_split_field_count);
		put_csv_field(v_split_fields(1));

		-- Fields 4-7 - empty
		put_empty_fields(4);

		-- Field 8 - Transaction Amount
		put_csv_field(c_pay_rec.payment_amount);

		-- Fields 9-10 - empty
		put_empty_fields(2);

		-- Fields 11-13 - Supplier Name overflow
		put_csv_field(v_split_fields(2));
		put_csv_field(v_split_fields(3));
		put_csv_field(v_split_fieldS(4));

		-- Field 14 - empty
		put_empty_fields(1);

		-- Field 15 - Advice Indicator
		put_csv_field('N');

		-- Field 16 - WHT Indicator
		put_csv_field('N');

		-- Fields 17-21 - empty
		put_empty_fields(5);

		-- Field 22 - static field label
		put_csv_field('@HVP@');

		-- Fields 23-34 - empty
		put_empty_fields(12);

		-- Field 35 - Bank ID/SWIFT Address Code
		if c_pay_rec.hae_bank_acct_country = 'CN' and c_pay_rec.supp_bank_name is not null then
			put_empty_fields(1);
		else
			if v_domestic_payment_flag then
				if (c_pay_rec.supp_bank_num is not null) then
					put_csv_field('BCD');
				else
					put_empty_fields(1);
				end if;
			else
				if (c_pay_rec.supp_bank_bic is not null) then
					put_csv_field('SWF');
				else
					put_empty_fields(1);
				end if;
			end if;
		end if;

		-- Field 36 - Bank ID/SWIFT Address
		if v_domestic_payment_flag then
			put_csv_field(c_pay_rec.supp_bank_num);
		else
			put_csv_field(c_pay_rec.supp_bank_bic);
		end if;

--12-03-08 - Eric Rossing - Modified to combine supp_bank_name and supp_bank_branch_name and split the result across fields 37
		-- Field 37-38 - Bank Name + Bank Branch Name (CN only)
		if c_pay_rec.hae_bank_acct_country = 'CN' then
			split_name(c_pay_rec.supp_bank_name || c_pay_rec.supp_bank_branch_name, 35, 11, v_split_fields, v_split_field_count);
			put_csv_field(v_split_fields(1));
			put_csv_field(v_split_fields(2));
		else
			put_empty_fields(2);
		end if;

		-- Fields 39-41 - empty fields
		put_empty_fields(3);
--12-03-08 - end of change

		-- Field 42 - Bank Country Code
		put_csv_field(c_pay_rec.supp_bank_acct_country);

		-- Fields 43-47 - empty
		put_empty_fields(5);

		-- Field 48 - Details of charges
		put_csv_field('OUR');

		-- Fields 49-54 - empty
		put_empty_fields(6);

		-- Field 55 - Bank to Bank Info 1
		if v_domestic_payment_flag then
			put_csv_field('', TRUE);
		else
			put_csv_field('/REC/ CBC ' || '700', TRUE);
		end if;

		-- Field 56 - Bank to Bank Info 2
--		put_csv_field(XX_CRASH_ME, TRUE);

  	END LOOP;  -- C_PAY_REC loop

	FND_FILE.PUT_LINE(FND_FILE.LOG, 'C_PAY_REC loop finished. Output complete');

EXCEPTION

	WHEN OTHERS
	THEN
		FND_FILE.PUT_LINE ( FND_FILE.LOG, 'err: OTHERS error message: ' || SQLERRM );
	ROLLBACK;
	RAISE eNoHandle;

end payments_ifile; -- procedure

END XXHA_CN_PAYMENTS;  -- End Package Body
/
