CREATE OR REPLACE PACKAGE        "XXHA_RECRUITER"
as
-- +=================================================================+
-- | Name        : XXHA_RECRUITER
-- | Description :
-- | Invoked by  : Report module XXHAHROPREQ.rdf
-- |
-- | History:
-- |
-- | When      Rev  Who          What
-- | --------  ---  -----------  ------------------------------------
-- | 20081223  1.0  P. Gutowski  Initial release
-- +=================================================================+
FUNCTION GET_RECRUITER(VAC_ID NUMBER)
         RETURN VARCHAR2;
END XXHA_RECRUITER;

/


CREATE OR REPLACE PACKAGE BODY        "XXHA_RECRUITER"
as
-- +=================================================================+
-- | Name        : XXHA_RECRUITER
-- | Description :
-- | Invoked by  : Report module XXHAHROPREQ.rdf
-- |
-- | History:
-- |
-- | When      Rev  Who          What
-- | --------  ---  -----------  ------------------------------------
-- | 20081223  1.0  P. Gutowski  Initial release
-- +=================================================================+
FUNCTION GET_RECRUITER (
          VAC_ID NUMBER
        ) RETURN VARCHAR2 IS
  L_REC NUMBER;
  L_FULL_NAME VARCHAR2(200);
BEGIN
  SELECT  RECRUITER_iD
  INTO    L_REC
  FROM    PER_VACANCIES
  WHERE   VACANCY_iD = VAC_ID;

  IF ( L_REC IS NOT NULL) THEN
     SELECT  PAPF.FULL_NAME
     INTO    L_FULL_NAME
     FROM    PER_ALL_PEOPLE_F PAPF
     WHERE   TRUNC(SYSDATE) BETWEEN PAPF.EFFECTIVE_START_DATE AND PAPF.EFFECTIVE_END_DATE
     AND PAPF.PERSON_iD = L_REC;

     RETURN L_FULL_NAME;

  ELSE
     RETURN NULL;
  END IF;

EXCEPTION
  WHEN OTHERS THEN RETURN NULL;
END GET_RECRUITER;

END XXHA_RECRUITER;

/
