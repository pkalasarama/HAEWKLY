/* Formatted on 2014/05/15 11:34 (Formatter Plus v4.8.8) */
CREATE OR REPLACE PACKAGE BODY apps.qp_custom
AS
/* $Header: QPXCUSTS.pls 115.2.11510.2 2004/11/12 00:39:38 sfiresto ship $ */
/*#
 * This package contains the specification for the GET_CUSTOM_PRICE API.  The
 * package body/function body is not shipped with Oracle Advanced Pricing.  The
 * user must create the Package Body for QP_CUSTOM containing the function body
 * for GET_CUSTOM_PRICE which must adhere to the Function specification provided
 * in the QP_CUSTOM package specification.
 *
 * @rep:scope public
 * @rep:product QP
 * @rep:displayname Custom Pricing
 * @rep:category BUSINESS_ENTITY QP_PRICE_FORMULA
 *
*Modification Log:
*Developer             Date                     Description
*-----------------   ------------------   ------------------------------------------------
* Sreeram Boppana    Nov-8-2012           Added function get_custom_price
* Don Browne         May-14-2014          Added whole blood formula
 */
   FUNCTION get_custom_price (
      p_price_formula_id       IN   NUMBER,
      p_list_price             IN   NUMBER,
      p_price_effective_date   IN   DATE,
      p_req_line_attrs_tbl     IN   qp_formula_price_calc_pvt.req_line_attrs_tbl
   )
      RETURN NUMBER
   IS
      l_order_price          NUMBER;             -- total order selling price
      l_header_id            NUMBER;                       -- order header id
      l_line_id              NUMBER;                         -- order line id
      l_line_quantity        NUMBER;                      -- selling quantity
      l_list_price           NUMBER;                  -- line item list price
      c_freight_formula_id   NUMBER := NULL;
      c_wb_formula_id        NUMBER := NULL;
      v_ratio                NUMBER;
   BEGIN
      SELECT line_id
        INTO l_line_id
        FROM qp_preq_lines_tmp
       WHERE line_index = p_req_line_attrs_tbl (1).line_index;

      oe_debug_pub.ADD ('<-----In Get_Custom_Price Function----->');
      oe_debug_pub.ADD ('p_price_formula_id:' || p_price_formula_id);
      oe_debug_pub.ADD ('p_price_efective_date:' || p_price_effective_date);
      oe_debug_pub.ADD ('Order Line_id:' || l_line_id);
      --
      oe_debug_pub.ADD ('Line Attributes are as follows...');

      FOR i IN p_req_line_attrs_tbl.FIRST .. p_req_line_attrs_tbl.LAST
      LOOP
         oe_debug_pub.ADD
                        ('--------------------------------------------------');
         oe_debug_pub.ADD ('line_index:'
                           || p_req_line_attrs_tbl (i).line_index
                          );
         oe_debug_pub.ADD (   'attribute_type:'
                           || p_req_line_attrs_tbl (i).attribute_type
                          );
         oe_debug_pub.ADD ('context:' || p_req_line_attrs_tbl (i).CONTEXT);
         oe_debug_pub.ADD ('attribute:' || p_req_line_attrs_tbl (i).ATTRIBUTE);
         oe_debug_pub.ADD ('value:' || p_req_line_attrs_tbl (i).VALUE);
         oe_debug_pub.ADD
                         ('--------------------------------------------------');
      END LOOP;

      BEGIN
         SELECT price_formula_id
           INTO c_freight_formula_id
           FROM qp_price_formulas_tl
          WHERE LANGUAGE = 'US' AND NAME = 'Freight 2.95 Percent MinMax';
      EXCEPTION
         WHEN OTHERS
         THEN
            c_freight_formula_id := NULL;
      END;

      BEGIN
         SELECT price_formula_id
           INTO c_wb_formula_id
           FROM qp_price_formulas_tl
          WHERE LANGUAGE = 'US' AND NAME = 'Whole Blood Freight Calc';
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;

      IF p_price_formula_id = c_freight_formula_id
      THEN
         oe_debug_pub.ADD ('Freight 2.95 Percent MinMax');

         --RETURN nvl(l_line_id,1);
         SELECT oola.header_id              -- get the header id for the order
           INTO l_header_id
           FROM oe_order_lines_all oola
          WHERE oola.line_id = l_line_id;

-- sum the selling price of all lines except for the surcharge line
-- in the current order
         SELECT SUM (oola.ordered_quantity * oola.unit_selling_price * .0295)
           INTO l_order_price
           FROM oe_order_lines_all oola
          WHERE oola.header_id = l_header_id;

--AND oola.inventory_item_id != C_surcharge_item_id;
         IF l_order_price IS NULL
         THEN
            l_order_price := NULL;
            RETURN l_order_price;
         ELSIF l_order_price <= 19.50
         THEN
            l_order_price := 19.50;
            RETURN l_order_price;
         ELSIF l_order_price >= 49
         THEN
            l_order_price := 49;
            RETURN l_order_price;
         ELSIF l_order_price BETWEEN 19.50 AND 49
         THEN
            RETURN l_order_price;
         END IF;
      --ELSE
          --RETURN C_freight_formula_id;
      END IF;

--------------------------------------------------
-- whole blood
--------------------------------------------------
      IF (p_price_formula_id = c_wb_formula_id)
      THEN
         BEGIN
            oe_debug_pub.ADD ('Whole Blood Freight Calc');

            --calc percentage of WB weight to entire shipment weight
            --only fires for a freight line, only use items associate with the delivery
            --that this freight item is on
            SELECT   SUM
                        (DECODE
                            (mc.segment1,
                             'WB', NVL
                                (inv_convert.inv_um_convert
                                    (item_id            => msi.inventory_item_id,
                                     PRECISION          => 9,
                                     from_quantity      =>   NVL
                                                                (this_ship_dtl.picked_quantity,
                                                                 0
                                                                )
                                                           * NVL
                                                                (weight.unit_weight,
                                                                 0
                                                                ),
                                     from_unit          => NVL
                                                              (weight.weight_uom_code,
                                                               'Kg'
                                                              ),
                                     to_unit            => 'Lbs',
                                     from_name          => NULL,
                                     to_name            => NULL
                                    ),
                                 0
                                ),
                             0
                            )
                        )
                   / SUM
                        (NVL
                            (inv_convert.inv_um_convert
                                (item_id            => msi.inventory_item_id,
                                 PRECISION          => 9,
                                 from_quantity      =>   NVL
                                                            (this_ship_dtl.picked_quantity,
                                                             0
                                                            )
                                                       * NVL
                                                            (weight.unit_weight,
                                                             0
                                                            ),
                                 from_unit          => NVL
                                                          (weight.weight_uom_code,
                                                           'Kg'
                                                          ),
                                 to_unit            => 'Lbs',
                                 from_name          => NULL,
                                 to_name            => NULL
                                ),
                             0
                            )
                        )
              INTO v_ratio
              FROM oe_order_lines_all ool,
                   wsh_delivery_details wdd,
                   wsh_dlvb_dlvy_v freight_line,
                   wsh_dlvb_dlvy_v this_shipment,
                   wsh_delivery_details this_ship_dtl,
                   mtl_system_items msi,
                   mtl_item_categories mic,
                   mtl_system_items weight,
                   mtl_category_sets mcs,
                   mtl_categories mc,
                   hr_organization_units hou
             WHERE ool.inventory_item_id = msi.inventory_item_id
               AND weight.organization_id = hou.organization_id
               AND weight.inventory_item_id = msi.inventory_item_id
               AND hou.NAME = 'Haemonetics Global Item Master'
               AND msi.organization_id = ool.ship_from_org_id
               AND mic.inventory_item_id = msi.inventory_item_id
               AND mic.organization_id = msi.organization_id
               AND mic.category_set_id = mcs.category_set_id
               AND mcs.category_set_name = 'Inventory'
               AND mc.category_id = mic.category_id
               AND this_ship_dtl.delivery_detail_id =
                                              this_shipment.delivery_detail_id
               AND this_ship_dtl.source_line_id = ool.line_id
               AND wdd.delivery_detail_id = freight_line.delivery_detail_id
               AND freight_line.delivery_id = this_shipment.delivery_id
               AND ool.ordered_item != 'FREIGHT'
               AND wdd.source_line_id = l_line_id;

            RETURN NVL (v_ratio, 0);
         EXCEPTION
            WHEN OTHERS
            THEN
               RETURN 0;
         END;
      END IF;

      oe_debug_pub.ADD ('<-----End Get_Custom_Price Function----->');
   END get_custom_price;
END qp_custom;
/