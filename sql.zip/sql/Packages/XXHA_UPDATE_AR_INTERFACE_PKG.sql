CREATE OR REPLACE package xxha_update_ar_interface_pkg as

procedure update_item_information(p_retcode OUT VARCHAR2,
                                  p_errbut  OUT VARCHAR2,
                                  p_org_id  IN NUMBER);                                  
                                  

end xxha_update_ar_interface_pkg; 
/


CREATE OR REPLACE package body xxha_update_ar_interface_pkg as

/*Procedure to Update Item Information in the AR Interface Table for Project related Invoices*/
PROCEDURE update_item_information(p_retcode OUT VARCHAR2,
                                  p_errbut  OUT VARCHAR2,
                                  p_org_id  IN NUMBER) as 
                                  
                                  
  /*Cursor to get the AR Interface Details along with project and task by looking invoice review information*/                                  
  CURSOR ra_int_line (cur_org_id NUMBER) IS
  SELECT RIL.interface_line_context,
         RIL.interface_line_attribute1,
         RIL.interface_line_attribute2,
         RIL.interface_line_attribute3,
         RIL.interface_line_attribute4,
         RIL.interface_line_attribute5,
         RIL.interface_line_attribute6,
         RIL.interface_line_attribute7,
         RIL.interface_line_attribute8,
         PT.service_type_code,
         FLV.meaning service_type,
         pp.segment1 project_number,
         i.project_id 
  from   pa_draft_invoices_all i,
         pa_draft_inv_items_bas ii,
	 pa_projects_all pp,
	 pa_tasks pt,
   	 fnd_lookup_values flv,
         ra_interface_lines_all RIL 
  WHERE  ii.project_id(+) = i.project_id
  AND    ii.draft_invoice_num(+) = i.draft_invoice_num		
  AND    NVL(ii.task_id, II.event_task_id) = pt.task_id (+) 
  AND    flv.lookup_type (+)= 'SERVICE TYPE'
  AND    flv.lookup_code(+) = pt.service_type_code
  AND    flv.language (+)= 'US'     
  AND    i.project_id = PP.project_id
  AND    RIL.interface_line_attribute1 = TO_CHAR(pp.segment1)
  AND    RIL.interface_line_attribute2 = TO_CHAR(I.draft_invoice_num)
  AND    TRIM(RIL.interface_line_attribute6) = TO_CHAR(ii.line_num)  
  AND    RIL.batch_source_name = 'PROJECTS INVOICES'
  AND    NVL(RIL.inventory_item_id, 0) = 0 
  AND    NVL(RIL.mtl_system_items_seg1, '-') = '-'
  AND    i.org_id = cur_org_id;
  
  lc_int_line ra_int_line%ROWTYPE;
  
  ln_inventory_item_id  NUMBER:=0;
  lv_segment1           VARCHAR2(50);
  lv_primary_uom_code   VARCHAR2(10);
  lv_primary_unit_of_measure VARCHAR2(20);
                                  
  lv_sqlerrm VARCHAR2(500);                                  
                                  
BEGIN        

   FND_FILE.PUT_LINE(FND_FILE.LOG,'     '); 
   FND_FILE.PUT_LINE(FND_FILE.LOG,'-----------------------------------------------------------------------------------------------------------------------------------------------------'); 
--   FND_FILE.PUT_LINE(FND_FILE.LOG,'Project Number   Draft Invoice  Invoice Number  Project Org        Project Manager   Line Number   Amount     Error Message'); 
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Report Log Information');  
   FND_FILE.PUT_LINE(FND_FILE.LOG,'-----------------------------------------------------------------------------------------------------------------------------------------------------'); 

  OPEN ra_int_line(p_org_id);
  LOOP
  
     FETCH ra_int_line INTO lc_int_line;
     EXIT WHEN ra_int_line%NOTFOUND;
     
     BEGIN
       /* Query to fetch the matching Item for the Task Service Type*/
       SELECT DISTINCT MSI.inventory_item_id,
              MSI.SEGMENT1,
              MSI.primary_uom_code              ,
              MSI.primary_unit_of_measure
       INTO   ln_inventory_item_id,
              lv_segment1,
              lv_primary_uom_code,
              lv_primary_unit_of_measure
       FROM   pa_lookups pl,
              mtl_system_items_b MSI
       WHERE  MSI.segment1 = pl.description
       AND    MSI.organization_id = 103
       AND    PL.lookup_type = 'XXHA_SERVICE_TYPE_INVITEM'
       AND    PL.meaning = lc_int_line.service_type;     
     
     
     EXCEPTION WHEN OTHERS THEN
     
     lv_sqlerrm:= SQLERRM;

	FND_FILE.PUT_LINE(FND_FILE.LOG,lc_int_line.interface_line_attribute1||' - '||
				     lc_int_line.interface_line_attribute2||' - '||
				     lc_int_line.interface_line_attribute3||' - '||
				     lc_int_line.interface_line_attribute4||' - '||
				     lc_int_line.interface_line_attribute5||' - '||
				     lc_int_line.interface_line_attribute6||' - '||
				     lc_int_line.interface_line_attribute7||' - '||
				     'Mapping Not Found'||' - '||
				     lv_sqlerrm);                                 
     
       dbms_output.put_line('Fetching item information errored out');

       RETURN;
    
     END;
          
     
     BEGIN
     
        /* Update the Item Information in the RA_INTERFACE_LINES_ALL interface table */
        UPDATE ra_interface_lines_all RIL
        SET    inventory_item_id = ln_inventory_item_id,
               MTL_SYSTEM_ITEMS_SEG1 = lv_segment1,
               UOM_CODE = lv_primary_uom_code,
               UOM_NAME = lv_primary_unit_of_measure
        WHERE  RIL.interface_line_context  = lc_int_line.interface_line_context
        AND    NVL(RIL.interface_line_attribute1,'-') = NVL(lc_int_line.interface_line_attribute1,'-')
        AND    NVL(RIL.interface_line_attribute2,'-') = NVL(lc_int_line.interface_line_attribute2,'-')
        AND    NVL(RIL.interface_line_attribute3,'-') = NVL(lc_int_line.interface_line_attribute3,'-')
        AND    NVL(RIL.interface_line_attribute4,'-') = NVL(lc_int_line.interface_line_attribute4,'-')
        AND    NVL(RIL.interface_line_attribute5,'-') = NVL(lc_int_line.interface_line_attribute5,'-')
        AND    NVL(RIL.interface_line_attribute6,'-') = NVL(lc_int_line.interface_line_attribute6,'-')
        AND    NVL(RIL.interface_line_attribute7,'-') = NVL(lc_int_line.interface_line_attribute7,'-')
        AND    NVL(RIL.interface_line_attribute8,'-') = NVL(lc_int_line.interface_line_attribute8,'-')
        AND    RIL.org_id = p_org_id;
        
        dbms_output.put_line(lc_int_line.interface_line_attribute1||' '||
                             lc_int_line.interface_line_attribute2||' '||
                             lc_int_line.interface_line_attribute3||' '||
                             lc_int_line.interface_line_attribute4||' '||
                             lc_int_line.interface_line_attribute5||' '||
                             lc_int_line.interface_line_attribute6||' '||
                             lc_int_line.interface_line_attribute7||'-'||
                             ln_inventory_item_id||'-'||
                             lv_segment1);
                             
	FND_FILE.PUT_LINE(FND_FILE.LOG,lc_int_line.interface_line_attribute1||' - '||
				     lc_int_line.interface_line_attribute2||' - '||
				     lc_int_line.interface_line_attribute3||' - '||
				     lc_int_line.interface_line_attribute4||' - '||
				     lc_int_line.interface_line_attribute5||' - '||
				     lc_int_line.interface_line_attribute6||' - '||
				     lc_int_line.interface_line_attribute7||' - '||
				     ln_inventory_item_id||' - '||
				     lv_segment1);                                     
               
     EXCEPTION WHEN OTHERS THEN
     
       dbms_output.put_line('Updating RA Interface Table Errored Out');     
       
       FND_FILE.PUT_LINE(FND_FILE.LOG,lc_int_line.interface_line_attribute1||' - '||
     				     lc_int_line.interface_line_attribute2||' - '||
     				     lc_int_line.interface_line_attribute3||' - '||
     				     lc_int_line.interface_line_attribute4||' - '||
     				     lc_int_line.interface_line_attribute5||' - '||
     				     lc_int_line.interface_line_attribute6||' - '||
     				     lc_int_line.interface_line_attribute7||' - '||
     				     'Error in Updation'||' - '||
				     lv_sqlerrm); 
     
     END;    
     
     ln_inventory_item_id := NULL;
     lv_segment1 := NULL;
     lv_primary_uom_code := NULL;
     lv_primary_unit_of_measure := NULL;
     
  END LOOP;
  
  dbms_output.put_line(ra_int_line%ROWCOUNT);

 FND_FILE.PUT_LINE(FND_FILE.LOG,' ');      
 FND_FILE.PUT_LINE(FND_FILE.LOG,'-----------------------------------------------------------------------------------------------------------------------------------------------------');   
 FND_FILE.PUT_LINE(FND_FILE.LOG,' ');    
  
  CLOSE ra_int_line;
  
  COMMIT;
                                  
END update_item_information;                                  
                                  

end xxha_update_ar_interface_pkg; 
/
