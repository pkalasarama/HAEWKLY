CREATE OR REPLACE package XXHA_INV_FG_ITEM_P1_FIX
as
Procedure process_fg_items
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
		,p_separate_var in varchar2
        );

end XXHA_INV_FG_ITEM_P1_FIX;

/


CREATE OR REPLACE package body      XXHA_INV_FG_ITEM_P1_FIX
as



procedure update_p1_fg_items
         (p_separate_var in varchar2
		)
		 is

cursor c_lets_upd_items_mst is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code = 'MST';

cursor c_lets_update_items_a is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'A'
and organization_code < 'C';

cursor c_lets_update_items_c is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'C'
and organization_code < 'E';

cursor c_lets_update_items_e is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'E'
and organization_code < 'J';

cursor c_lets_update_items_j is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'J';

l_err_occur varchar2 (2000) := 'S';
l_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
    x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
  l_commit_var   number;
begin
l_commit_var := 0;
-----------------------------------------------------------------------
IF p_separate_var = 'MST' THEN
 for v_lets_upd_items_mst in c_lets_upd_items_mst loop
 l_commit_var := l_commit_var +1;
 --  x_item_table.delete;
  -- l_item_table.delete;
   l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_lets_upd_items_mst.item_number;
   l_item_table(1).Organization_Code           := v_lets_upd_items_mst.organization_code;
   l_item_table(1).Template_Name               := v_lets_upd_items_mst.template_code;
   --l_item_table(1).purchasing_enabled_flag  := 'Y';
   --l_item_table(1).Inventory_Item_Status_Code  := 'Active';
   --l_item_table(1).Long_Description            := 'test item';
   EGO_ITEM_PUB.Process_Items(
         p_api_version           => 1.0
         ,p_init_msg_list         => FND_API.g_TRUE
         ,p_commit                => FND_API.g_FALSE
         ,p_Item_Tbl              => l_item_table
         ,x_Item_Tbl              => x_item_table
         ,x_return_status         => x_return_status
         ,x_msg_count             => x_msg_count);
	IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_upd_items_mst.inventory_item_id
	 and organization_id =   v_lets_upd_items_mst.organization_id;
	-- commit;
	ELSE
	  --rollback;
	  l_err_occur := 'E';
	END IF;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
END IF;

-----------------------------------------------------------------------
IF p_separate_var = 'A' THEN
 for v_lets_update_items in c_lets_update_items_a loop
  -- x_item_table.delete;
  -- l_item_table.delete;
   l_commit_var := l_commit_var + 1;
   l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_lets_update_items.item_number;
   l_item_table(1).Organization_Code           := v_lets_update_items.organization_code;
   l_item_table(1).Template_Name               := v_lets_update_items.template_code;
   --l_item_table(1).purchasing_enabled_flag  := 'Y';
   --l_item_table(1).Long_Description            := 'test item';
   EGO_ITEM_PUB.Process_Items(
         p_api_version           => 1.0
         ,p_init_msg_list         => FND_API.g_TRUE
         ,p_commit                => FND_API.g_FALSE
         ,p_Item_Tbl              => l_item_table
         ,x_Item_Tbl              => x_item_table
         ,x_return_status         => x_return_status
         ,x_msg_count             => x_msg_count);
	IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	ELSE
	 -- rollback;
	  l_err_occur := 'E';
	END IF;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
END IF;

IF p_separate_var = 'C' THEN
 for v_lets_update_items in c_lets_update_items_c loop
  -- x_item_table.delete;
  -- l_item_table.delete;
   l_commit_var := l_commit_var +1;
   l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_lets_update_items.item_number;
   l_item_table(1).Organization_Code           := v_lets_update_items.organization_code;
   l_item_table(1).Template_Name               := v_lets_update_items.template_code;
   --l_item_table(1).purchasing_enabled_flag  := 'Y';
   --l_item_table(1).Long_Description            := 'test item';
   EGO_ITEM_PUB.Process_Items(
         p_api_version           => 1.0
         ,p_init_msg_list         => FND_API.g_TRUE
         ,p_commit                => FND_API.g_FALSE
         ,p_Item_Tbl              => l_item_table
         ,x_Item_Tbl              => x_item_table
         ,x_return_status         => x_return_status
         ,x_msg_count             => x_msg_count);
	IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	ELSE
	 -- rollback;
	  l_err_occur := 'E';
	END IF;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
 END IF;
 IF p_separate_var = 'E' THEN
 for v_lets_update_items in c_lets_update_items_e loop
  -- x_item_table.delete;
  -- l_item_table.delete;
  l_commit_var := l_commit_var + 1;
   l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_lets_update_items.item_number;
   l_item_table(1).Organization_Code           := v_lets_update_items.organization_code;
   l_item_table(1).Template_Name               := v_lets_update_items.template_code;
   --l_item_table(1).purchasing_enabled_flag  := 'Y';
   --l_item_table(1).Long_Description            := 'test item';
   EGO_ITEM_PUB.Process_Items(
         p_api_version           => 1.0
         ,p_init_msg_list         => FND_API.g_TRUE
         ,p_commit                => FND_API.g_FALSE
         ,p_Item_Tbl              => l_item_table
         ,x_Item_Tbl              => x_item_table
         ,x_return_status         => x_return_status
         ,x_msg_count             => x_msg_count);
	IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	ELSE
	 -- rollback;
	  l_err_occur := 'E';
	END IF;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
 END IF;
 IF p_separate_var = 'J' THEN
 for v_lets_update_items in c_lets_update_items_j loop
  -- x_item_table.delete;
  -- l_item_table.delete;
   l_commit_var := l_commit_var + 1;
   l_item_table(1).Transaction_Type            := 'UPDATE'; -- Replace this with 'UPDATE' for update transaction.
   l_item_table(1).Segment1                        := v_lets_update_items.item_number;
   l_item_table(1).Organization_Code           := v_lets_update_items.organization_code;
   l_item_table(1).Template_Name               := v_lets_update_items.template_code;
   --l_item_table(1).purchasing_enabled_flag  := 'Y';
   --l_item_table(1).Long_Description            := 'test item';
   EGO_ITEM_PUB.Process_Items(
         p_api_version           => 1.0
         ,p_init_msg_list         => FND_API.g_TRUE
         ,p_commit                => FND_API.g_FALSE
         ,p_Item_Tbl              => l_item_table
         ,x_Item_Tbl              => x_item_table
         ,x_return_status         => x_return_status
         ,x_msg_count             => x_msg_count);
	IF (x_return_status = FND_API.G_RET_STS_SUCCESS) THEN
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	ELSE
	 -- rollback;
	  l_err_occur := 'E';
	END IF;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
 END IF;
 /*
 IF l_err_occur = 'S' THEN
   commit;
   dbms_output.put_line('Commit--------');
 ELSE
   rollback;
   dbms_output.put_line('Rollback--------');
 ENd IF;
 */
end;
-------->>--------------------------------------------------------------------------------------------------------------------

procedure upd_p1_fg_items_int
         (p_separate_var in varchar2
		)
		 is

cursor c_lets_upd_items_mst is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code = 'MST';

cursor c_lets_update_items_a is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'A'
and organization_code < 'C';

cursor c_lets_update_items_c is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'C'
and organization_code < 'E';

cursor c_lets_update_items_e is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'E'
and organization_code < 'J';

cursor c_lets_update_items_j is
select * from xxha_P1_fix_FG_Data_by_org
where organization_code <> 'MST'
and organization_code >= 'E'
and organization_code < 'J';

l_err_occur varchar2 (2000) := 'S';
l_item_table          EGO_Item_PUB.Item_Tbl_Type;
   x_item_table          EGO_Item_PUB.Item_Tbl_Type;
    x_return_status       VARCHAR2(1);
   x_msg_count           NUMBER(10);
   x_msg_data            VARCHAR2(1000);
   x_message_list        Error_Handler.Error_Tbl_Type;
  l_commit_var   number;
begin
l_commit_var := 0;
-----------------------------------------------------------------------
IF p_separate_var = 'MST' THEN
 for v_lets_upd_items_mst in c_lets_upd_items_mst loop
 l_commit_var := l_commit_var +1;
    insert into mtl_system_items_interface
		   (inventory_item_id,organization_id,template_name,process_flag,transaction_type,set_process_id)
	values
		   (v_lets_upd_items_mst.inventory_item_id,v_lets_upd_items_mst.organization_id,v_lets_upd_items_mst.template_code,'1','UPDATE','12345')
     ;
    update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_upd_items_mst.inventory_item_id
	 and organization_id =   v_lets_upd_items_mst.organization_id;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
END IF;

-----------------------------------------------------------------------
IF p_separate_var = 'A' THEN

 for v_lets_update_items in c_lets_update_items_e loop
    l_commit_var := l_commit_var + 1;
    insert into mtl_system_items_interface
		   (inventory_item_id,organization_id,template_name,process_flag,transaction_type,set_process_id)
	values
		   (v_lets_update_items.inventory_item_id,v_lets_update_items.organization_id,v_lets_update_items.template_code,'1','UPDATE','12345')
     ;
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
 END IF;

IF p_separate_var = 'C' THEN
 for v_lets_update_items in c_lets_update_items_e loop
    l_commit_var := l_commit_var + 1;
    insert into mtl_system_items_interface
		   (inventory_item_id,organization_id,template_name,process_flag,transaction_type,set_process_id)
	values
		   (v_lets_update_items.inventory_item_id,v_lets_update_items.organization_id,v_lets_update_items.template_code,'1','UPDATE','12345')
     ;
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
 END IF;
 IF p_separate_var = 'E' THEN
 for v_lets_update_items in c_lets_update_items_e loop
    l_commit_var := l_commit_var + 1;
    insert into mtl_system_items_interface
		   (inventory_item_id,organization_id,template_name,process_flag,transaction_type,set_process_id)
	values
		   (v_lets_update_items.inventory_item_id,v_lets_update_items.organization_id,v_lets_update_items.template_code,'1','UPDATE','12345')
     ;
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
 END IF;
 IF p_separate_var = 'J' THEN
  for v_lets_update_items in c_lets_update_items_e loop
    l_commit_var := l_commit_var + 1;
    insert into mtl_system_items_interface
		   (inventory_item_id,organization_id,template_name,process_flag,transaction_type,set_process_id)
	values
		   (v_lets_update_items.inventory_item_id,v_lets_update_items.organization_id,v_lets_update_items.template_code,'1','UPDATE','12345')
     ;
	 update xxha_P1_fix_FG_Data_by_org
	 set status = 'S'
	 where inventory_item_id =  v_lets_update_items.inventory_item_id
	 and organization_id =   v_lets_update_items.organization_id;
	 --commit;
	IF l_commit_var = 1000 THEN
	  l_commit_var := 0;
	  commit;
	END IF;
 end loop;
 commit;
 END IF;
 /*
 IF l_err_occur = 'S' THEN
   commit;
   dbms_output.put_line('Commit--------');
 ELSE
   rollback;
   dbms_output.put_line('Rollback--------');
 ENd IF;
 */
end;



--------->> end-------------------------------------------------------------------------------------------------------------------
procedure insert_fg_item_data
is

cursor c_get_items is
select items.segment1,items.inventory_item_id,items.description, category_concat_segs
from apps.mtl_item_categories_v cat,apps.mtl_system_items items
where cat.organization_id = 103
and cat.inventory_item_id = items.inventory_item_id
and cat.organization_id = items.organization_id
--and items.segment1 = '623FC-P'
and (category_concat_segs like 'CA.Disp%'
or category_concat_segs like 'CA.Equi%'
or category_concat_segs like 'CP.Disp%'
or category_concat_segs like 'CP.Equi%'
or category_concat_segs like 'CS.Disp%'
or category_concat_segs like 'CS.Equi%'
or category_concat_segs like 'CS.Disp%'
or category_concat_segs like 'CS.Equi%'
or category_concat_segs like 'MS.Disp%'
or category_concat_segs like 'MS.Misc%'
or category_concat_segs like 'OE.Disp%'
or category_concat_segs like 'OE.Equi%'
or category_concat_segs like 'OE.Misc%'
or category_concat_segs like 'OP.Disp%'
or category_concat_segs like 'OP.Equi%'
or category_concat_segs like 'OP.Misc%'
or category_concat_segs like 'PL%'
or category_concat_segs like 'PT%'
or category_concat_segs like 'RC%'
or category_concat_segs like 'SU%'
or category_concat_segs like 'TEG%'
or category_concat_segs like 'TH%'
or category_concat_segs like 'SV.Serv.Part.Misc%'
)
and category_set_id = 1
;

cursor c_get_org_items is
select Inventory_item_id,item_number,item_description,status,inventory_cat
from xxha_P1_fix_FG_Data;

cursor c_get_ora_items_buy (q_inventory_item_id number)is
select organization_code,items.organization_id
from mtl_system_items items,mtl_parameters param
where items.organization_id = param.organization_id
and items.inventory_item_id = q_inventory_item_id
and organization_code in
(
'ATO',
'ATS',
'ATV',
'AVO',
'BEO',
'BES',
'BEV',
'BTS',
'CAO',
'CHO',
'CHS',
'CHV',
'CNO',
'CNS',
'CZO',
'CZS',
'CZV',
'DEO',
'DES',
'DEV',
'EDC',
'FRO',
'FRS',
'FRV',
'GBO',
'GBS',
'GBV',
'GSO',
'HKO',
'HKS',
'HMS',
'ILO',
'ITO',
'ITS',
'ITV',
'JPC',
'JPL',
'JPO',
'JPS',
'KRV',
'MSO',
'MST',
'NLO',
'NLS',
'NLV',
'SEO',
'SES',
'SEV',
'SIO',
'STS',
'STV',
'TWO',
'TWS',
'UCS',
'UNO')
;

cursor c_get_ora_items_make (q_inventory_item_id number)is
select organization_code,items.organization_id
from mtl_system_items items,mtl_parameters param
where items.organization_id = param.organization_id
and items.inventory_item_id = q_inventory_item_id
and organization_code in
(
'BDO',
'BTO',
'HMO',
'GBX',
'PTO',
'UPO'
)
;

begin

for v_get_items in c_get_items loop
  insert into xxha_P1_fix_FG_Data
  (Inventory_item_id,item_number,item_description,status,inventory_cat)
  values
  (v_get_items.inventory_item_id,v_get_items.segment1,v_get_items.description,'NEW', v_get_items.category_concat_segs)
  ;
end loop;
commit;

for v_get_org_items in c_get_org_items loop
  for v_get_ora_items_buy in c_get_ora_items_buy (v_get_org_items.inventory_item_id) loop
    insert into xxha_P1_fix_FG_Data_by_org
  		   (Inventory_item_id,item_number,item_description,status,inventory_cat,organization_id,organization_code,template_code)
    values
  		   (v_get_org_items.inventory_item_id,v_get_org_items.item_number,v_get_org_items.item_description,'NEW', v_get_org_items.inventory_cat,v_get_ora_items_buy.organization_id,v_get_ora_items_buy.organization_code,'HAE Conversion FG BUY')
    ;
  end loop;


end loop;
commit;

for v_get_org_items in c_get_org_items loop
  for v_get_ora_items_make in c_get_ora_items_make (v_get_org_items.inventory_item_id) loop
    insert into xxha_P1_fix_FG_Data_by_org
  		   (Inventory_item_id,item_number,item_description,status,inventory_cat,organization_id,organization_code,template_code)
    values
  		   (v_get_org_items.inventory_item_id,v_get_org_items.item_number,v_get_org_items.item_description,'NEW', v_get_org_items.inventory_cat,v_get_ora_items_make.organization_id,v_get_ora_items_make.organization_code,'HAE Conversion FG MAKE')
    ;
  end loop;


end loop;
commit;

end;



Procedure process_fg_items
          (x_errbuf  out  varchar2
        ,x_retcode  out  varchar2
		,p_separate_var in varchar2
        ) is

begin
IF p_separate_var  = 'INSERT' THEN
insert_fg_item_data;
commit;
ELSE
 update_p1_fg_items(p_separate_var);
 --upd_p1_fg_items_int(p_separate_var);
commit;
END IF;


end;

END XXHA_INV_FG_ITEM_P1_FIX;

/
