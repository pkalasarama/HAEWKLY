CREATE OR REPLACE package      XXHA_INV_COMMON_UTILITIES_PK

as

-- +=============================================================================+

-- | Name             :  XXHA_INV_COMMON_UTILITIES_PK

-- | Description      :  This package supports the processing of Items information

-- |                     staged for conversion or interfacing.

-- |

-- |History:

-- |  Version  When        Who            What

-- |  -------  ----------  -------------  ---------------------------------------

-- |  1.0      2008-08-18  L.Richards     Initial release

-- +=============================================================================+



-----------------------------------

-- Common Errors placeholders

-----------------------------------

gn_request_id            xxha_common_errors.request_id%type := fnd_global.conc_request_id;  --Request ID of running concurrent program

gn_record_number         xxha_common_errors.record_number%type;       --Record number of staged record

gc_record_identifier     xxha_common_errors.record_identifier%type;   --Record identifier of staged record

gc_error_code            xxha_common_errors.error_code%type;          --Error Code for detected error

gc_error_msg             xxha_common_errors.error_msg%type;           --Description of error

gc_comments              xxha_common_errors.comments%type;            --Comment related to error

gc_table_name            xxha_common_errors.table_name%type;          --Staging table namehet

gc_attribute1            xxha_common_errors.attribute1%type;          --Attribute1

gc_attribute2            xxha_common_errors.attribute2%type;          --Attribute2

gc_attribute3            xxha_common_errors.attribute3%type;          --Attribute3

gc_attribute4            xxha_common_errors.attribute4%type;          --Attribute4 stores the concurrent program name

gc_attribute5            xxha_common_errors.attribute5%type;          --Attribute5 stores the validated (eg. ROUTING, OPERATION, RESOURCE, BILL, INVCOMP, SUBCOMP)



gc_status  varchar2(1);

gc_setup_error  varchar2(1) := 'N';



gc_language_code  fnd_languages.language_code%type :='US';

gc_category_set_name  mtl_category_sets_tl.category_set_name%type :='Inventory';

gc_material_sub_element  bom_resources.resource_code%type :='Material';

gc_org_code_MST  mtl_parameters.organization_code%type := 'MST';

gc_template_PD  mtl_item_templates.template_name%type := 'Purchasing - Disposables';

gc_template_PE  mtl_item_templates.template_name%type := 'Purchasing - Equipment';

gc_template_DSA  mtl_item_templates.template_name%type := 'Disposable Sub Assy';

gc_template_ESA  mtl_item_templates.template_name%type := 'Equipment Sub Assy';

gc_template_EFG  mtl_item_templates.template_name%type := 'Equipment FG';

gc_template_DFG  mtl_item_templates.template_name%type := 'Disposable FG';

gc_template_RP  mtl_item_templates.template_name%type := 'Returned Part';



type gr_icSetupRec is record (

        setup_error  varchar2(1)

       ,category_set_id  mtl_category_sets_tl.category_set_id%type

       ,org_id_MST  mtl_parameters.organization_id%type

       ,template_id_PD  mtl_item_templates.template_id%type

       ,stock_enabled_flag_PD  mtl_system_items.stock_enabled_flag%type

       ,mtl_trx_enabled_flag_PD  mtl_system_items.mtl_transactions_enabled_flag%type

       ,make_buy_code_PD  mtl_system_items.planning_make_buy_code%type

       ,lot_control_code_PD  mtl_system_items.lot_control_code%type

       ,template_id_PE  mtl_item_templates.template_id%type

       ,stock_enabled_flag_PE  mtl_system_items.stock_enabled_flag%type

       ,mtl_trx_enabled_flag_PE  mtl_system_items.mtl_transactions_enabled_flag%type

       ,make_buy_code_PE  mtl_system_items.planning_make_buy_code%type

       ,lot_control_code_PE  mtl_system_items.lot_control_code%type

       ,template_id_DSA  mtl_item_templates.template_id%type

       ,stock_enabled_flag_DSA  mtl_system_items.stock_enabled_flag%type

       ,mtl_trx_enabled_flag_DSA  mtl_system_items.mtl_transactions_enabled_flag%type

       ,make_buy_code_DSA  mtl_system_items.planning_make_buy_code%type

       ,lot_control_code_DSA  mtl_system_items.lot_control_code%type

       ,template_id_ESA  mtl_item_templates.template_id%type

       ,stock_enabled_flag_ESA  mtl_system_items.stock_enabled_flag%type

       ,mtl_trx_enabled_flag_ESA  mtl_system_items.mtl_transactions_enabled_flag%type

       ,make_buy_code_ESA  mtl_system_items.planning_make_buy_code%type

       ,lot_control_code_ESA  mtl_system_items.lot_control_code%type

       ,template_id_EFG  mtl_item_templates.template_id%type

       ,stock_enabled_flag_EFG  mtl_system_items.stock_enabled_flag%type

       ,mtl_trx_enabled_flag_EFG  mtl_system_items.mtl_transactions_enabled_flag%type

       ,make_buy_code_EFG  mtl_system_items.planning_make_buy_code%type

       ,lot_control_code_EFG  mtl_system_items.lot_control_code%type

       ,template_id_DFG  mtl_item_templates.template_id%type

       ,stock_enabled_flag_DFG  mtl_system_items.stock_enabled_flag%type

       ,mtl_trx_enabled_flag_DFG  mtl_system_items.mtl_transactions_enabled_flag%type

       ,make_buy_code_DFG  mtl_system_items.planning_make_buy_code%type

       ,lot_control_code_DFG  mtl_system_items.lot_control_code%type

       ,template_id_RP  mtl_item_templates.template_id%type

       ,stock_enabled_flag_RP  mtl_system_items.stock_enabled_flag%type

       ,mtl_trx_enabled_flag_RP  mtl_system_items.mtl_transactions_enabled_flag%type

       ,make_buy_code_RP  mtl_system_items.planning_make_buy_code%type

       ,lot_control_code_RP  mtl_system_items.lot_control_code%type

       );



type gr_itemStatusRec is record (

     code  mtl_item_status.inventory_item_status_code%type

    ,description  mtl_item_status.description%type

    );

type g_itemStatusTabType is table of gr_itemStatusRec index by binary_integer;







-- +=========================================================================

-- | Check prerequisite setups

-- +=========================================================================

procedure check_setups (

         p_request_id  in  number

        ,p_conc_prog  in  varchar2

        ,x_icSetup  out  gr_icSetupRec

        );



-- +=========================================================================

-- | Check language setup

-- +=========================================================================

function language_setup_ok (

         p_lang_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check category set setup

-- +=========================================================================

function category_set_setup_ok (

         p_category_set_name  in  varchar2

        ,p_lang_code  in  varchar2

        ,x_category_set_id  out  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check master org setup

-- +=========================================================================

function master_org_setup_ok (

         p_org_code_mst  in  varchar2

        ,x_org_id_MST  out  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check template setup

-- +=========================================================================

function template_setup_ok (

         p_template_name  in  mtl_item_templates.template_name%type

        ,x_template_id  out  mtl_item_templates.template_id%type

        ,x_stock_enabled_flag  out  mtl_system_items.stock_enabled_flag%type

        ,x_mtl_trx_enabled_flag  out  mtl_system_items.mtl_transactions_enabled_flag%type

        ,x_make_buy_code  out  mtl_system_items.planning_make_buy_code%type

        ,x_lot_control_code  out  mtl_system_items.lot_control_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check zero cost dff setup

-- +=========================================================================

function zero_cost_dff_setup_ok (

         p_organization_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check material sub-element setup

-- +=========================================================================

function material_subelement_setup_ok (

         p_organization_code  in  varchar2

        ,p_resource_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check item status

-- +=========================================================================

function item_status_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_itemStatuses_tab  in  g_itemStatusTabType

        ,p_item_status_code  in  xxha_items_cleaned_stg.item_status%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check unit of measure

-- +=========================================================================

function uom_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_uom_type  in  varchar2

        ,p_uom_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check template

-- +=========================================================================

function template_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_template_code  in  xxha_items_cleaned_stg.template_code%type

        ,p_icSetup  in  gr_icSetupRec

        ,x_template_id  out  xxha_items_cleaned_stg.template_id%type

        ,x_stock_enabled_flag  out  mtl_system_items.stock_enabled_flag%type

        ,x_mtl_trx_enabled_flag  out  mtl_system_items.mtl_transactions_enabled_flag%type

        ,x_make_buy_code  out  mtl_system_items.planning_make_buy_code%type

        ,x_lot_control_code  out  mtl_system_items.lot_control_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check category

-- +=========================================================================

function category_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_category_set_id  in  mtl_category_sets_vl.category_set_id%type

        ,p_category_seg1  in  xxha_items_cleaned_stg.item_product_line%type

        ,p_category_seg2  in  xxha_items_cleaned_stg.item_product_type%type

        ,p_category_seg3  in  xxha_items_cleaned_stg.item_product_subtype%type

        ,p_category_seg4  in  xxha_items_cleaned_stg.item_platform%type

        ,x_category_id  out  mtl_categories_b.category_id%type

        ,x_category_product_line_dff  out  mtl_categories_b.attribute1%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check revision control

-- +=========================================================================

function revision_control_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_revision_control  in  xxha_items_cleaned_stg.revision_control%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check lot expiration

-- +=========================================================================

function lot_expiration_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_lot_expiration  in  xxha_items_cleaned_stg.lot_expiration%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check lot control

-- +=========================================================================

function lot_control_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_lot_control  in  xxha_items_cleaned_stg.lot_control%type

        ,p_template_lot_control  in  number

        ,p_lot_control_mst  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check serial number control

-- +=========================================================================

function serial_number_control_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_serial_number_control  in  xxha_items_cleaned_stg.serial_number_generation%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check attribute value is Y or N

-- +=========================================================================

function value_YN_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check outside processing unit type

-- +=========================================================================

function outproc_unit_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_outside_processing_unit_type  in  xxha_items_cleaned_stg.outside_processing_unit_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check attribute value for >= 0

-- +=========================================================================

function range_gr_eq_0 (

         p_item_number  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check container_type

-- +=========================================================================

function container_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_container_type  in  xxha_items_cleaned_stg.container_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check min-max qty

-- +=========================================================================

function minmax_qty_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_minmax_minimum_qty  in  xxha_items_cleaned_stg.minmax_minimum_qty%type

        ,p_minmax_maximum_qty  in  xxha_items_cleaned_stg.minmax_maximum_qty%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check source type

-- +=========================================================================

function source_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_source_type  in  xxha_items_cleaned_stg.source_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check safety stock code

-- +=========================================================================

function safety_stock_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_safety_stock  in  xxha_items_cleaned_stg.safety_stock%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check attribute value for > 0

-- +=========================================================================

function range_gr_0 (

         p_item_number  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check forecast type

-- +=========================================================================

function forecast_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_forecast_type  in  xxha_items_cleaned_stg.forecast_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check Service Request Code

-- +=========================================================================

function service_request_code_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_service_request_code  in  xxha_items_cleaned_stg.service_request_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check Billing Type Code

-- +=========================================================================

function billing_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_enable_service_billing  in  xxha_items_cleaned_stg.enable_service_billing%type

        ,p_billing_type  in  xxha_items_cleaned_stg.billing_type%type

        ,p_stock_enabled_flag  in  varchar2

        ,p_mtl_trx_enabled_flag  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check Recovered Part Disposition

-- +=========================================================================

function recovered_part_disposition_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_billing_type  in  xxha_items_cleaned_stg.billing_type%type

        ,p_recovered_part_disposition  in  xxha_items_cleaned_stg.recovered_part_disposition%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check for item at master organization

-- +=========================================================================

procedure check_item_at_master (

         p_organization_id_mst  in  number

        ,p_item_number  in  varchar2

        ,x_inventory_item_id  out  number

        ,x_lot_control  out  number

        );



procedure check_item_at_org (

         p_organization_id  in  number

        ,p_item_number  in  varchar2

        ,x_inventory_item_id  out  number

        ,x_item_at_org  out  boolean

        ) ;

procedure get_item_category (

         p_organization_code  in  varchar2

        ,p_item_number  in  varchar2

		,p_category_set_id in number

        ,x_category_id  out  number

		,x_organization_id out  number

		,x_inventory_item_id out number

        ,x_category_exists  out  boolean

        )  ;



-- +=========================================================================

-- | Check organization

-- +=========================================================================

function inventory_org_ok(

         p_org_item  in  varchar2

        ,p_inventory_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,x_inv_org_id  out  xxha_item_invorgs_stg.inv_org_id%type

        ,x_zero_cost_dff  out  xxha_item_invorgs_stg.zero_cost_dff%type

        ,x_starting_revision  out  xxha_item_invorgs_stg.starting_revision%type

        ,x_org_cos_cc_id  out  xxha_item_invorgs_stg.org_cos_cc_id%type

        ,x_org_sales_cc_id  out  xxha_item_invorgs_stg.org_sales_cc_id%type

        ,x_org_expense_cc_id  out  xxha_item_invorgs_stg.org_expense_cc_id%type

        ,x_ou_org_id  out  hr_operating_units.organization_id%type

        ,x_sob_id  out  gl_sets_of_books.set_of_books_id%type

        ,x_coa_id out  gl_sets_of_books.chart_of_accounts_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check item type

-- +=========================================================================

function user_item_type_ok(

         p_org_item  in  varchar2

        ,p_user_item_type  in  xxha_item_invorgs_stg.user_item_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check UOM conversion allowed

-- +=========================================================================

function conversions_ok(

         p_org_item  in  varchar2

        ,p_conversions  in  xxha_item_invorgs_stg.conversions%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check if item assignment to organization already exists

-- +=========================================================================

function item_at_org (

         p_org_item  in  varchar2

        ,p_inventory_item_id  in  xxha_item_invorgs_stg.inventory_item_id%type

        ,p_inv_org_id  in  xxha_item_invorgs_stg.inv_org_id%type

        ) return boolean;



---------------------------------------------------------------

-- Derive and check account code combination

---------------------------------------------------------------

function account_derivation_ok (

         p_org_item  in  varchar2

        ,p_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,p_coa_id  in  xxha_item_invorgs_stg.coa_id%type

        ,p_acct_type  in  varchar2

        ,p_org_cc_id  in  xxha_item_invorgs_stg.org_cos_cc_id%type

        ,p_category_product_line_dff  in  xxha_items_cleaned_stg.category_product_line_dff%type

        ,x_orgitm_cc_id  out  xxha_item_invorgs_stg.orgitm_cos_cc_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check attribute value is Y or N on item assignments to organization

-- +=========================================================================

function asg_value_YN_ok (

         p_org_item  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check purchasing tax code

-- +=========================================================================

function purchasing_tax_code_ok (

         p_org_item  in  varchar2

        ,p_ou_org_id  in  xxha_item_invorgs_stg.ou_org_id%type

        ,p_purchasing_tax_code  in  xxha_item_invorgs_stg.purchasing_tax_code%type

        ,x_purchasing_tax_id  out  xxha_item_invorgs_stg.purchasing_tax_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check default buyer

-- +=========================================================================

function default_buyer_name_ok (

         p_org_item  in  varchar2

        ,p_default_buyer_name  in  xxha_item_invorgs_stg.default_buyer_name%type

        ,x_buyer_id  out  xxha_item_invorgs_stg.buyer_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check planner

-- +=========================================================================

function planner_ok (

         p_org_item  in  varchar2

        ,p_ou_org_id  in  xxha_item_invorgs_stg.ou_org_id%type

        ,p_planner  in  xxha_item_invorgs_stg.planner%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check 'Make' or 'Buy' flag

-- +=========================================================================

function make_or_buy_ok(

         p_org_item  in  varchar2

        ,p_make_or_buy  in  xxha_item_invorgs_stg.make_or_buy%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check postprocessing lead time with 'Make' or 'Buy' flag

-- +=========================================================================

function postprocessing_lead_time_ok(

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_inventory_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,p_make_buy_code  in  xxha_item_invorgs_stg.make_or_buy%type

        ,p_postprocessing_lead_time  in  xxha_items_cleaned_stg.postprocessing_lead_time%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check for organization

-- +=========================================================================

function organization_ok (

         p_org_item  in  varchar2

        ,p_org_type  in  varchar2

        ,p_organization_code  in  mtl_parameters.organization_code%type

        ,x_organization_id  out  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check attribute value for >= 0

-- +=========================================================================

function asg_range_gr_eq_0 (

         p_org_item  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check invoicing tax code

-- +=========================================================================

function tax_code_ok (

         p_org_item  in  varchar2

        ,p_ou_org_id  in  xxha_item_invorgs_stg.ou_org_id%type

        ,p_tax_code  in  xxha_item_invorgs_stg.tax_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check payment terms name

-- +=========================================================================

function payment_terms_name_ok (

         p_org_item  in  varchar2

        ,p_payment_terms_name  in  xxha_item_invorgs_stg.payment_terms_name%type

        ,x_payment_terms_id  out  xxha_item_invorgs_stg.payment_terms_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Compare the revision number against the latest starting revision that

-- | has been setup for organizations staged for the item

-- +=========================================================================

function compare_w_org_starting_rev_ok (

         p_item_rev  in  varchar2

        ,p_item_number  in  xxha_item_revisions_stg.item_number%type

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_max_org_starting_rev  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check chronology of staged item revisions

-- +=========================================================================

function staged_chronology_ok (

         p_item_rev  in  varchar2

        ,p_item_number  in  xxha_item_revisions_stg.item_number%type

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_effective_date  in  xxha_item_revisions_stg.effective_date%type

        ,p_ci_flag  in  xxha_item_revisions_stg.ci_flag%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check for a higher item revision in master org

-- +=========================================================================

function higher_revision_exists (

         p_item_rev  in  varchar2

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_item_number  in  xxha_item_revisions_stg.item_number%type

        ,p_inventory_item_id  in  xxha_item_revisions_stg.inventory_item_id%type

        ,p_org_id_mst  in  mtl_parameters.organization_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean;



-- +=========================================================================

-- | Check if revision already exists at master org

-- +=========================================================================

function revision_exists (

         p_item_rev  in  varchar2

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_inventory_item_id  in  xxha_item_revisions_stg.inventory_item_id%type

        ,p_org_id_mst  in  mtl_parameters.organization_id%type

        ) return boolean;



-- +=========================================================================

-- | Check for starting revision of an item at an org

-- | If it is not found, create interface record for it if create_flag = Y

-- +=========================================================================

procedure check_on_orgitem_starting_rev (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_inventory_item_id  in  xxha_items_cleaned_stg.inventory_item_id%type

        ,p_start_date_active  in  xxha_items_cleaned_stg.start_date_active%type

        ,p_inventory_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,p_inv_org_id  in  xxha_item_invorgs_stg.inv_org_id%type

        ,p_starting_rev  in  xxha_item_invorgs_stg.starting_revision%type

        ,p_set_process_id  in  mtl_item_revisions_interface.set_process_id%type

        ,p_now  in  date

        ,p_user_id  in  number

        ,p_create_flag  in  varchar2

        );





procedure get_template_code(p_template_code varchar2,
                            p_template_name out varchar2);

procedure check_unit_of_issue(p_item_number varchar2
                             ,p_primary_uom_code varchar2
                            ,p_unit_of_issue in out varchar2
							,x_unit_of_issue_valid out boolean);

procedure check_item_at_org_uom (

         p_organization_id  in  number

        ,p_item_number  in  varchar2

        ,x_inventory_item_id  out  number

		, x_uom_code out varchar2

        ,x_item_at_org  out  boolean

        ) ;
END XXHA_INV_COMMON_UTILITIES_PK;

/


CREATE OR REPLACE package body       XXHA_INV_COMMON_UTILITIES_PK

as

-- +=============================================================================+

-- | Name             :  XXHA_INV_COMMON_UTILITIES_PK

-- | Description      :  This package supports the processing of Items information

-- |                     staged for conversion or interfacing.

-- |

-- |History:

-- |  Version  When        Who            What

-- |  -------  ----------  -------------  ---------------------------------------

-- |  1.0      2008-08-19  P Kundu     		Initial release
-- |  1.1      2009-02-19  P Kundu     		Changes as per testing release
-- |  1.0      2009-04-19  P Kundu     		Changes as per ECO Testing release
-- |  1.2	   2010-09-08  Vasil S. Valkov	Added '4=User-defined expiration date' 
-- |										to lot_expiration_ok proc
-- +=============================================================================+





-- +=========================================================================

-- | Log setup errors not specific to any record

-- +=========================================================================

procedure log_setup_error

          is

   e_error  exception;

begin

   gc_setup_error := 'Y';

   xxha_common_utilities_pkg.insert_error_prc(

                             gn_request_id

                            ,null            -- gn_record_number

                            ,null            -- gc_record_identifier

                            ,gc_error_code

                            ,gc_error_msg

                            ,gc_comments

                            ,null            -- gc_table_name

                            ,null            -- gc_attribute1

                            ,null            -- gc_attribute2

                            ,null            -- gc_attribute3

                            ,gc_attribute4   -- gc_attribute4 (concurrent program name)

                            ,'SETUP'         -- gc_attribute5 (validation type)

                            ,gc_status

                            );

   if (gc_status = 'N') then

      raise e_error;

   end if;

exception

   when others then

      fnd_file.put_line(fnd_file.log,'Error in XXHA_INV_CONV_ITM_P2_PK.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);

end log_setup_error;





-- +=========================================================================

-- | Check prerequisite setups

-- +=========================================================================

procedure get_template_code(p_template_code varchar2,
                            p_template_name out varchar2)
							is
begin

select template_name
into p_template_name
from mtl_item_templates
where (template_name like p_template_code||'-%' or template_name = p_template_code)
;

exception
when no_data_found then
  p_template_name := p_template_code||' Template Not Found ';
when others then
  p_template_name := p_template_code||' Template Not Found ';
/*
  IF p_template_code = 'PD' Then
    p_template_name := 'Purchasing - Disposables';
  ELSIF p_template_code = 'PE' Then
    p_template_name := 'Purchasing - Equipment';
  ELSIF p_template_code = 'DSA' Then
    p_template_name := 'Disposables Sub Assy';
  ELSIF p_template_code = 'ESA' Then
    p_template_name := 'Equipment Sub Assy';
  ELSIF p_template_code = 'EFG' Then
    p_template_name := 'Equipment Finished Goods';
  ELSIF p_template_code = 'DFG' Then
    p_template_name := 'Disposable Finished Goods';
  ELSIF p_template_code = 'RP' Then
    p_template_name := 'Returned Part';
  ELSIF p_template_code = 'LCI' Then
    p_template_name := 'Lot Control Item';
  ELSIF p_template_code = 'NCI' Then
    p_template_name := 'Non Controlled Item';
  ELSE
    p_template_name := p_template_code||' Template Not Found ';
  END IF;
*/





end;
procedure check_setups (

         p_request_id  in  number

        ,p_conc_prog  in  varchar2

        ,x_icSetup  out  gr_icSetupRec

        ) is

  cursor c_ios

            is

    SELECT  DISTINCT(ios.inventory_org_code)

    FROM    XXHA_ITEM_INVORGS_STG  ios

    WHERE   ios.inventory_org_code IS NOT NULL;



  cursor c_tmplorg

            is

    SELECT  distinct

            decode(ics.template_code

                  ,'PD', gc_template_PD

                  ,'PE', gc_template_PE

                  ,'DSA', gc_template_DSA

                  ,'ESA', gc_template_ESA

                  ,'EFG', gc_template_EFG

                  ,'DFG', gc_template_DFG

                  ,'RP', gc_template_RP

                  )  template_name

           ,ios.inventory_org_code  item_org_code

           ,mp2.organization_code  template_org_code

    from    xxha_items_cleaned_stg  ics

           ,xxha_item_invorgs_stg  ios

           ,mtl_item_templates  mit

           ,mtl_parameters  mp

           ,mtl_parameters  mp2

    WHERE   1=1

    and     mit.template_name = decode(ics.template_code

                                      ,'PD', gc_template_PD

                                      ,'PE', gc_template_PE

                                      ,'DSA', gc_template_DSA

                                      ,'ESA', gc_template_ESA

                                      ,'EFG', gc_template_EFG

                                      ,'DFG', gc_template_DFG

                                      ,'RP', gc_template_RP

                                      )

    and     mit.context_organization_id IS NOT NULL

    AND     ios.item_number = ics.item_number

    AND     mp.organization_code = ios.inventory_org_code

    AND     mp.organization_id <> mit.context_organization_id

    and     mp2.organization_id = mit.context_organization_id;



begin

   gn_request_id := p_request_id;

   gc_attribute4 := p_conc_prog;

   gc_comments := null;



   if (not language_setup_ok(gc_language_code,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not category_set_setup_ok(gc_category_set_name,x_icSetup.category_set_id,gc_language_code,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not master_org_setup_ok(gc_org_code_MST,x_icSetup.org_id_MST,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not template_setup_ok(gc_template_PD

                      ,x_icSetup.template_id_PD,x_icSetup.stock_enabled_flag_PD

                      ,x_icSetup.mtl_trx_enabled_flag_PD,x_icSetup.make_buy_code_PD,x_icSetup.lot_control_code_PD

                      ,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not template_setup_ok(gc_template_PE

                      ,x_icSetup.template_id_PE,x_icSetup.stock_enabled_flag_PE

                      ,x_icSetup.mtl_trx_enabled_flag_PE,x_icSetup.make_buy_code_PE,x_icSetup.lot_control_code_PE

                      ,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not template_setup_ok(gc_template_DSA

                      ,x_icSetup.template_id_DSA,x_icSetup.stock_enabled_flag_DSA

                      ,x_icSetup.mtl_trx_enabled_flag_DSA,x_icSetup.make_buy_code_DSA,x_icSetup.lot_control_code_DSA

                      ,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not template_setup_ok(gc_template_ESA

                      ,x_icSetup.template_id_ESA,x_icSetup.stock_enabled_flag_ESA

                      ,x_icSetup.mtl_trx_enabled_flag_ESA,x_icSetup.make_buy_code_ESA,x_icSetup.lot_control_code_ESA

                      ,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not template_setup_ok(gc_template_EFG

                      ,x_icSetup.template_id_EFG,x_icSetup.stock_enabled_flag_EFG

                      ,x_icSetup.mtl_trx_enabled_flag_EFG,x_icSetup.make_buy_code_EFG,x_icSetup.lot_control_code_EFG

                      ,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not template_setup_ok(gc_template_DFG

                      ,x_icSetup.template_id_DFG,x_icSetup.stock_enabled_flag_DFG

                      ,x_icSetup.mtl_trx_enabled_flag_DFG,x_icSetup.make_buy_code_DFG,x_icSetup.lot_control_code_DFG

                      ,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;

   if (not template_setup_ok(gc_template_RP

                      ,x_icSetup.template_id_RP,x_icSetup.stock_enabled_flag_RP

                      ,x_icSetup.mtl_trx_enabled_flag_RP,x_icSetup.make_buy_code_RP,x_icSetup.lot_control_code_RP

                      ,gc_error_code,gc_error_msg) ) then

      log_setup_error;

   end if;



   for iosrec in c_ios

   loop

      if (not zero_cost_dff_setup_ok(iosrec.inventory_org_code,gc_error_code,gc_error_msg) ) then

         log_setup_error;

      end if;

      if (not material_subelement_setup_ok(iosrec.inventory_org_code,gc_material_sub_element,gc_error_code,gc_error_msg) ) then

         log_setup_error;

      end if;

   end loop;



   for tmplorgrec in c_tmplorg

   loop

      gc_error_code := 'SETUP-070';

      gc_error_msg := 'Template '||tmplorgrec.template_name||' defined for '||tmplorgrec.template_org_code

                 ||' cannot be used for items at '||tmplorgrec.item_org_code;

      log_setup_error;

   end loop;



   x_icSetup.setup_error := gc_setup_error;



end check_setups;





-- +=========================================================================

-- | Check language setup

-- +=========================================================================

function language_setup_ok (

         p_lang_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

begin

   select  'Y'

   into    l_found

   FROM    fnd_languages FL

   WHERE   FL.language_code = p_lang_code;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'SETUP-010';

      x_err_msg := 'Language code '||p_lang_code||' has not been set up.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Language Code: '||SQLERRM;

      return(false);

end language_setup_ok;





-- +=========================================================================

-- | Check category set setup

-- +=========================================================================

function category_set_setup_ok (

         p_category_set_name  in  varchar2

        ,p_lang_code  in  varchar2

        ,x_category_set_id  out  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean is

begin

   SELECT  mcst.category_set_id

   into    x_category_set_id

   FROM    mtl_category_sets_tl  MCST

   WHERE   MCST.category_set_name = p_category_set_name

   AND     MCST.language = p_lang_code;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'SETUP-020';

      x_err_msg := p_lang_code||' category set '||p_category_set_name||' has not been set up.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Category Set: '||SQLERRM;

      return(false);

end category_set_setup_ok;





-- +=========================================================================

-- | Check master org setup

-- +=========================================================================

function master_org_setup_ok (

         p_org_code_mst  in  varchar2

        ,x_org_id_MST  out  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean is

begin

   SELECT  mp.organization_id

   into    x_org_id_mst

   FROM    mtl_parameters  MP

   WHERE   MP.organization_code = p_org_code_mst

   AND     MP.master_organization_id = MP.organization_id ;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'SETUP-030';

      x_err_msg := 'Master Org '||p_org_code_mst||' has not been set up.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Master Org: '||SQLERRM;

      return(false);

end master_org_setup_ok;





-- +=========================================================================

-- | Check template setup

-- +=========================================================================

function template_setup_ok (

         p_template_name  in  mtl_item_templates.template_name%type

        ,x_template_id  out  mtl_item_templates.template_id%type

        ,x_stock_enabled_flag  out  mtl_system_items.stock_enabled_flag%type

        ,x_mtl_trx_enabled_flag  out  mtl_system_items.mtl_transactions_enabled_flag%type

        ,x_make_buy_code  out  mtl_system_items.planning_make_buy_code%type

        ,x_lot_control_code  out  mtl_system_items.lot_control_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean is



   cursor c_ta (

            q_template_id  mtl_item_templates.template_id%type

           ,q_attribute_name  mtl_item_templ_attributes_v.attribute_name%type

           ) is

      select  ta.attribute_value

      from    mtl_item_templ_attributes_v  ta

             ,mtl_item_templates  t

      where   1=1

      and     t.template_id = q_template_id

      and     ta.template_id(+) = t.template_id

      and     ta.attribute_name = q_attribute_name

      and     ta.enabled_flag = 'Y';



   l_template_id  mtl_item_templates.template_id%type;

   l_make_buy_code  varchar2(1);

   l_lot_control_code  varchar2(1);

begin

   SELECT  mit.template_id

          ,mit.template_id

   into    x_template_id

          ,l_template_id

   FROM    mtl_item_templates  MIT

   WHERE   MIT.template_name = p_template_name;



   open c_ta (l_template_id,'MTL_SYSTEM_ITEMS.STOCK_ENABLED_FLAG');

   fetch c_ta into x_stock_enabled_flag;

   close c_ta;



   open c_ta (l_template_id,'MTL_SYSTEM_ITEMS.MTL_TRANSACTIONS_ENABLED_FLAG');

   fetch c_ta into x_mtl_trx_enabled_flag;

   close c_ta;



   open c_ta (l_template_id,'MTL_SYSTEM_ITEMS.PLANNING_MAKE_BUY_CODE');

   fetch c_ta into l_make_buy_code;

   close c_ta;

   x_make_buy_code := to_number(l_make_buy_code);



   open c_ta (l_template_id,'MTL_SYSTEM_ITEMS.LOT_CONTROL_CODE');

   fetch c_ta into l_lot_control_code;

   close c_ta;

   x_lot_control_code := to_number(l_lot_control_code);



   return(true);

exception

   when no_data_found then

      x_err_cd := 'SETUP-040';

      x_err_msg := 'Template '||p_template_name||' has not been set up.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Template: '||SQLERRM;

      return(false);

end template_setup_ok;





-- +=========================================================================

-- | Check zero cost dff setup

-- +=========================================================================

function zero_cost_dff_setup_ok (

         p_organization_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

begin

   SELECT  'Y'

   into    l_found

   FROM    mtl_parameters  MP

   WHERE   MP.attribute6 IS NULL

   AND     MP.organization_code = p_organization_code;



   x_err_cd := 'SETUP-050';

   x_err_msg := 'Zero Cost DFF (ATTRIBUTE6) for Org '||p_organization_code||' has not been set up.';

   return(false);

exception

   when no_data_found then

      return(true);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'ZeroCost DFF: '||SQLERRM;

      return(false);

end zero_cost_dff_setup_ok;





-- +=========================================================================

-- | Check material sub-element setup

-- +=========================================================================

function material_subelement_setup_ok (

         p_organization_code  in  varchar2

        ,p_resource_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

begin

   SELECT  'Y'

   into    l_found

   FROM    bom_resources  BR

          ,mtl_parameters MP

   WHERE   1=1

   and     MP.organization_code = p_organization_code

   and     BR.organization_id = MP.organization_id

   AND     BR.resource_code = p_resource_code

   AND     nvl(BR.disable_date,TRUNC(SYSDATE)) >= TRUNC(SYSDATE);



   return(true);

exception

   when no_data_found then

      x_err_cd := 'SETUP-060';

      x_err_msg := 'Sub Element '||p_resource_code||' for Org '||p_organization_code||' has not been set up or is disabled';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'ZeroCost DFF: '||SQLERRM;

      return(false);

end material_subelement_setup_ok;





-- +=========================================================================

-- | Check item status

-- +=========================================================================

function item_status_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_itemStatuses_tab  in  g_itemStatusTabType

        ,p_item_status_code  in  xxha_items_cleaned_stg.item_status%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is



   i  number := 0;

   done  boolean := false;

   found  boolean := false;

begin

   while (not done)

   loop

      i := i + 1;

      if (i > p_itemStatuses_tab.count) then

         done := true;

      else

         if (p_itemStatuses_tab(i).code = p_item_status_code) then

            found := true;

            done := true;

         end if;

      end if;

   end loop;



   if (not found) then

      x_err_cd := 'ITEM-02';

      x_err_msg := 'Invalid Item Status';

      x_comments := 'Check that status '''||p_item_status_code||''' is defined and active.';

      return(false);

   else

      return(true);

   end if;

end item_status_ok;





-- +=========================================================================

-- | Check unit of measure

-- +=========================================================================

function uom_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_uom_type  in  varchar2

        ,p_uom_code  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

   e_noprimary  exception;

begin

   if (p_uom_type = 'Primary'  and  p_uom_code is null) then

      raise e_noprimary;

   end if;

   if (p_uom_code is null) then

      return(true);

   end if;



   select  'Y'

   into    l_found

   from    mtl_units_of_measure_tl

   where   uom_code = p_uom_code

   and     language = 'US'

   and     disable_date is null;



   return(true);

exception

   when e_noprimary then

      x_err_cd := 'ITEM-03A';

      x_err_msg := 'Missing Primary UOM on item';

      x_comments := 'Provide a primary UOM on the ITEMS_CLEANED table';

      return(false);

   when no_data_found then

      x_err_cd := 'ITEM-03';

      x_err_msg := 'Invalid '||p_uom_type||' UOM';

      x_comments := 'Check that UOM '||p_uom_code||' is defined and active.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'UOM: '||SQLERRM;

      return(false);

end uom_ok;





-- +=========================================================================

-- | Check template

-- +=========================================================================

function template_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_template_code  in  xxha_items_cleaned_stg.template_code%type

        ,p_icSetup  in  gr_icSetupRec

        ,x_template_id  out  xxha_items_cleaned_stg.template_id%type

        ,x_stock_enabled_flag  out  mtl_system_items.stock_enabled_flag%type

        ,x_mtl_trx_enabled_flag  out  mtl_system_items.mtl_transactions_enabled_flag%type

        ,x_make_buy_code  out  mtl_system_items.planning_make_buy_code%type

        ,x_lot_control_code  out  mtl_system_items.lot_control_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_template_name  varchar2(30);

   e_null  exception;

   e_code  exception;

begin
return true;
   if (p_template_code is null) then

      raise e_null;

   end if;

   if (p_template_code not in ('PD','PE','DSA','ESA','EFG','DFG','RP')) then

      raise e_code;

   end if;



   if (p_template_code = 'PD') then

      x_template_id := p_icSetup.template_id_PD;

      x_stock_enabled_flag := p_icSetup.stock_enabled_flag_PD;

      x_mtl_trx_enabled_flag := p_icSetup.mtl_trx_enabled_flag_PD;

      x_make_buy_code := p_icSetup.make_buy_code_PD;

      x_lot_control_code := p_icSetup.lot_control_code_PD;

   elsif (p_template_code = 'PE') then

      x_template_id := p_icSetup.template_id_PE;

      x_stock_enabled_flag := p_icSetup.stock_enabled_flag_PE;

      x_mtl_trx_enabled_flag := p_icSetup.mtl_trx_enabled_flag_PE;

      x_make_buy_code := p_icSetup.make_buy_code_PE;

      x_lot_control_code := p_icSetup.lot_control_code_PE;

   elsif (p_template_code = 'DSA') then

      x_template_id := p_icSetup.template_id_DSA;

      x_stock_enabled_flag := p_icSetup.stock_enabled_flag_DSA;

      x_mtl_trx_enabled_flag := p_icSetup.mtl_trx_enabled_flag_DSA;

      x_make_buy_code := p_icSetup.make_buy_code_DSA;

      x_lot_control_code := p_icSetup.lot_control_code_DSA;

   elsif (p_template_code = 'ESA') then

      x_template_id := p_icSetup.template_id_ESA;

      x_stock_enabled_flag := p_icSetup.stock_enabled_flag_ESA;

      x_mtl_trx_enabled_flag := p_icSetup.mtl_trx_enabled_flag_ESA;

      x_make_buy_code := p_icSetup.make_buy_code_ESA;

      x_lot_control_code := p_icSetup.lot_control_code_ESA;

   elsif (p_template_code = 'EFG') then

      x_template_id := p_icSetup.template_id_EFG;

      x_stock_enabled_flag := p_icSetup.stock_enabled_flag_EFG;

      x_mtl_trx_enabled_flag := p_icSetup.mtl_trx_enabled_flag_EFG;

      x_make_buy_code := p_icSetup.make_buy_code_EFG;

      x_lot_control_code := p_icSetup.lot_control_code_EFG;

   elsif (p_template_code = 'DFG') then

      x_template_id := p_icSetup.template_id_DFG;

      x_stock_enabled_flag := p_icSetup.stock_enabled_flag_DFG;

      x_mtl_trx_enabled_flag := p_icSetup.mtl_trx_enabled_flag_DFG;

      x_make_buy_code := p_icSetup.make_buy_code_DFG;

      x_lot_control_code := p_icSetup.lot_control_code_DFG;

   elsif (p_template_code = 'RP') then

      x_template_id := p_icSetup.template_id_RP;

      x_stock_enabled_flag := p_icSetup.stock_enabled_flag_RP;

      x_mtl_trx_enabled_flag := p_icSetup.mtl_trx_enabled_flag_RP;

      x_make_buy_code := p_icSetup.make_buy_code_RP;

      x_lot_control_code := p_icSetup.lot_control_code_RP;

   end if;



   return(true);

exception

   when e_null then

      x_err_cd := 'ITEM-04';

      x_err_msg := 'No template assigned';

      x_comments := 'Template Codes: PD, PE, DSA, ESA, EFG, DFG, RP';

      return(false);

   when e_code then

      x_err_cd := 'ITEM-05';

      x_err_msg := 'Invalid Template Code';

      x_comments := 'Valid values (PD, PE, DSA, ESA, EFG, DFG, RP) does not include '||p_template_code;

      return(false);

end template_ok;





-- +=========================================================================

-- | Check category

-- +=========================================================================

function category_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_category_set_id  in  mtl_category_sets_vl.category_set_id%type

        ,p_category_seg1  in  xxha_items_cleaned_stg.item_product_line%type

        ,p_category_seg2  in  xxha_items_cleaned_stg.item_product_type%type

        ,p_category_seg3  in  xxha_items_cleaned_stg.item_product_subtype%type

        ,p_category_seg4  in  xxha_items_cleaned_stg.item_platform%type

        ,x_category_id  out  mtl_categories_b.category_id%type

        ,x_category_product_line_dff  out  mtl_categories_b.attribute1%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

   l_category  varchar2(200);

   l_category_id  mtl_categories_b.category_id%type;

   l_category_product_line_dff  mtl_categories_b.attribute1%type;

   e_nullseg  exception;

   e_code  exception;

begin

   l_category := p_category_seg1||'.'||p_category_seg2||'.'||p_category_seg3||'.'||p_category_seg4;

--dbms_output.put_line(l_category ||' set '||p_category_set_id);

   if (   p_category_seg1 is null or p_category_seg2 is null

       or p_category_seg3 is null or p_category_seg4 is null ) then

      raise e_nullseg;

   end if;



   SELECT  mcb.category_id

          ,mcb.attribute1

   INTO    l_category_id

          ,l_category_product_line_dff

   FROM    mtl_categories_b mcb

          ,mtl_category_sets_vl mcs

   WHERE   1=1

   AND     mcs.category_set_id = p_category_set_id

   and     mcb.structure_id = mcs.structure_id

   AND     mcb.segment1 = p_category_seg1

   AND     mcb.segment2 = p_category_seg2

   AND     mcb.segment3 = p_category_seg3

   AND     mcb.segment4 = p_category_seg4

   AND     mcb.attribute1 is not null

   AND     NVL(mcb.disable_date, SYSDATE) >= SYSDATE;



   ----------------------------------------------------------

   -- At this point the category id has been fetched.

   ----------------------------------------------------------

   x_category_id := l_category_id;

   x_category_product_line_dff := l_category_product_line_dff;



   ----------------------------------------------------------

   -- Check if category/category_set combination is valid

   ----------------------------------------------------------

   begin

      SELECT  'Y'

      into    l_found

      FROM    mtl_category_set_valid_cats MCSVC

      WHERE   MCSVC.category_set_id = p_category_set_id

      AND     MCSVC.category_id = l_category_id;



   exception

      when no_data_found then

         x_err_cd := 'ITEM-08';

         x_err_msg :=  'Invalid combination of category set and category';

         x_comments := 'The list of valid categories for category set '||gc_category_set_name

                        ||' does not include '||l_category;

         return(false);

      when others then

         x_err_cd := 'SQL-010';

         x_err_msg := 'Category/CategorySet: '||SQLERRM;

         return(false);

   end;



   return(true);

exception

   when e_nullseg then

      x_err_cd := 'ITEM-07A';

      x_err_msg := 'Missing Category Segment(s)';

      x_comments := 'Check '||l_category||' for Product Line, Product Type, Product SubType and Platform.';

      return(false);

   when no_data_found then

      x_err_cd := 'ITEM-07';

      x_err_msg := 'Invalid Category for Category Set '||gc_category_set_name;

      x_comments := 'Check that category '||l_category||' is defined and that the Accounting Product Line DFF is specified';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Category: '||SQLERRM;

      return(false);

end category_ok;





-- +=========================================================================

-- | Check revision control

-- +=========================================================================

function revision_control_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_revision_control  in  xxha_items_cleaned_stg.revision_control%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (p_revision_control not in (1,2)) then

      x_err_cd := 'ITEM-08';

      x_err_msg := 'Invalid Revision Control';

      x_comments := 'Valid values (1=No, 2=Yes) does  not include '||p_revision_control;

      l_result := false;

   end if;



   return(l_result);

end revision_control_ok;





-- +=========================================================================

-- | Check lot expiration

-- +=========================================================================

function lot_expiration_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_lot_expiration  in  xxha_items_cleaned_stg.lot_expiration%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

	-- 20100908 Vasil: Added code for User-defined lot expiration type. Version 1.2s
   if (nvl(p_lot_expiration,1) not in (1,2,4)) then

      x_err_cd := 'ITEM-09';

      x_err_msg := 'Invalid Lot Expiration flag';

      x_comments := 'Valid values (1=No shelf life control, 2=Item shelf life days, 4=User-defined expiration date) does  not include '||p_lot_expiration;

      l_result := false;

   end if;



   return(l_result);

end lot_expiration_ok;





-- +=========================================================================

-- | Check lot control

-- +=========================================================================

function lot_control_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_lot_control  in  xxha_items_cleaned_stg.lot_control%type

        ,p_template_lot_control  in  number

        ,p_lot_control_mst  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_lot_control,1) not in (1,2)) then

      x_err_cd := 'ITEM-10';

      x_err_msg := 'Invalid Lot Control flag';

      x_comments := 'Valid values (1=No lot control, 2=Full lot control) does  not include '||p_lot_control;

      l_result := false;

   end if;



   -- does item already exist?

   if (p_lot_control_mst is not null) then

      -- is switch from 'Full Control' to 'No Control'

      if (p_lot_control_mst = 2  and  nvl(nvl(p_lot_control,p_template_lot_control),1) = 1 ) then

         x_err_cd := 'ITEM-10';

         x_err_msg := 'Cannot switch from Full Lot Control [2] to No Lot Control [1] on an existing item';

         x_comments := 'Check specific value provided or template setting';

         l_result := false;

      end if;

   end if;



   return(l_result);

end lot_control_ok;





-- +=========================================================================

-- | Check serial number control

-- +=========================================================================

function serial_number_control_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_serial_number_control  in  xxha_items_cleaned_stg.serial_number_generation%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_serial_number_control,1) not in (1,2,5,6)) then

      x_err_cd := 'ITEM-11';

      x_err_msg := 'Invalid Serial Number Control flag';

      x_comments := 'Valid values (1=No serial number control, 2=Predefined serial numbers, '

                    ||'5=At inventory receipt, 6=At sales order issue) does  not include '||p_serial_number_control;

      l_result := false;

   end if;



   return(l_result);

end serial_number_control_ok;





-- +=========================================================================

-- | Check attribute value is Y or N

-- +=========================================================================

function value_YN_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_attr_value,'N') not in ('N','Y')) then

      x_err_cd := 'ITEM-12';

      x_err_msg := 'Invalid '||p_attr_name;

      x_comments := 'Valid values (N=No, Y=Yes) does  not include '||p_attr_value;

      l_result := false;

   end if;



   return(l_result);

end value_YN_ok;





-- +=========================================================================

-- | Check outside processing unit type

-- +=========================================================================

function outproc_unit_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_outside_processing_unit_type  in  xxha_items_cleaned_stg.outside_processing_unit_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_outside_processing_unit_type,'ASSEMBLY') not in ('ASSEMBLY','RESOURCE') ) then

      x_err_cd := 'ITEM-13';

      x_err_msg := 'Invalid Outside Processing Unit Type';

      x_comments := 'Valid values (ASSEMBLY, RESOURCE) does  not include '||p_outside_processing_unit_type;

      l_result := false;

   end if;



   return(l_result);

end outproc_unit_type_ok;





-- +=========================================================================

-- | Check attribute value for >= 0

-- +=========================================================================

function range_gr_eq_0 (

         p_item_number  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (p_attr_value is not null) then

      if (p_attr_value < 0) then

         x_err_cd := 'ITEM-14';

         x_err_msg := 'Invalid value for '||p_attr_name;

         x_comments := 'Valid range ( >= 0 ) does not include '||p_attr_value;

         l_result := false;

      end if;

   end if;



   return(l_result);

end range_gr_eq_0;





-- +=========================================================================

-- | Check container_type

-- +=========================================================================

function container_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_container_type  in  xxha_items_cleaned_stg.container_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

begin

   if (p_container_type is null) then

      return(true);

   end if;



   select  'Y'

   into    l_found

   from    fnd_lookup_values

   where   lookup_type = 'CONTAINER_TYPE'

   and     lookup_code = p_container_type

   and     enabled_flag = 'Y'

   and language = 'US'

   and     sysdate between nvl(start_date_active,sysdate)

                       and nvl(end_date_active,sysdate);



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ITEM-15';

      x_err_msg := 'Invalid Container Type';

      x_comments := 'Check that container type '||p_container_type||' is defined and active.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Container Type: '||SQLERRM;

      return(false);

end container_type_ok;





-- +=========================================================================

-- | Check min-max qty

-- +=========================================================================

function minmax_qty_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_minmax_minimum_qty  in  xxha_items_cleaned_stg.minmax_minimum_qty%type

        ,p_minmax_maximum_qty  in  xxha_items_cleaned_stg.minmax_maximum_qty%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (    p_minmax_minimum_qty is not null

       and p_minmax_maximum_qty is not null) then

      if (p_minmax_minimum_qty > p_minmax_maximum_qty) then

         x_err_cd := 'ITEM-16';

         x_err_msg := 'Invalid MinMax Quantity range';

         x_comments := 'MinMax Minimum '||p_minmax_minimum_qty||'cannot be less than MinMax Maximum '||p_minmax_maximum_qty;

         l_result := false;

      end if;

   end if;



   return(l_result);

end minmax_qty_ok;





-- +=========================================================================

-- | Check source type

-- +=========================================================================

function source_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_source_type  in  xxha_items_cleaned_stg.source_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_source_type,1) not in (1,2,3) ) then

      x_err_cd := 'ITEM-17';

      x_err_msg := 'Invalid Source Type';

      x_comments := 'Valid values (1=Inventory, 2=Supplier, 3=Subinventory) does not include '||p_source_type;

      l_result := false;

   end if;



   return(l_result);

end source_type_ok;





-- +=========================================================================

-- | Check safety stock code

-- +=========================================================================

function safety_stock_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_safety_stock  in  xxha_items_cleaned_stg.safety_stock%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_safety_stock,1) not in (1,2) ) then

      x_err_cd := 'ITEM-18';

      x_err_msg := 'Invalid Safety Stock code ('||p_safety_stock||') on Item '||p_item_number;

      x_comments := 'Valid values (1=Non-MRP planned, 2=MRP planned percent) does not include '||p_safety_stock;

      l_result := false;

   end if;



   return(l_result);

end safety_stock_ok;





-- +=========================================================================

-- | Check attribute value for > 0

-- +=========================================================================

function range_gr_0 (

         p_item_number  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (p_attr_value is not null) then

      if (p_attr_value < 0) then

         x_err_cd := 'ITEM-19';

         x_err_msg := 'Invalid value for '||p_attr_name;

         x_comments := 'Valid range (  > 0 ) does not include '||p_attr_value;

         l_result := false;

      end if;

   end if;



   return(l_result);

end range_gr_0;





-- +=========================================================================

-- | Check forecast type

-- +=========================================================================

function forecast_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_forecast_type  in  xxha_items_cleaned_stg.forecast_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_forecast_type,1) not in (1,2,3) ) then

      x_err_cd := 'ITEM-20';

      x_err_msg := 'Invalid Forecast Type';

      x_comments := 'Valid values (1=Order Forcast, 2=Sales Forcast, 3=Historical Sales) does not include '||p_forecast_type;

      l_result := false;

   end if;



   return(l_result);

end forecast_type_ok;





-- +=========================================================================

-- | Check Service Request Code

-- +=========================================================================

function service_request_code_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_service_request_code  in  xxha_items_cleaned_stg.service_request_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_service_request_code,'E') not in ('E','D','I') ) then

      x_err_cd := 'ITEM-21';

      x_err_msg := 'Invalid Service Request Code';

      x_comments := 'Valid values (E=Enabled, D=Disabled, I=Inactive) does not include '||p_service_request_code;

      l_result := false;

   end if;



   return(l_result);

end service_request_code_ok;





-- +=========================================================================

-- | Check Billing Type Code

-- +=========================================================================

function billing_type_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_enable_service_billing  in  xxha_items_cleaned_stg.enable_service_billing%type

        ,p_billing_type  in  xxha_items_cleaned_stg.billing_type%type

        ,p_stock_enabled_flag  in  varchar2

        ,p_mtl_trx_enabled_flag  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

   e_no_service_billing  exception;

   e_bad_billing_type  exception;

   e_item_stockable_transactable  exception;

begin



   begin

      if (nvl(p_enable_service_billing,'N') = 'N') then

         if (p_billing_type is not null) then

            raise e_no_service_billing;

         end if;

      else  -- service billing is enabled

         if (nvl(p_billing_type,'M') not in ('E','L','M')) then

            raise e_bad_billing_type;

         else  -- code is valid

            if (    nvl(p_billing_type,'M') in ('E','L')

                and (p_stock_enabled_flag = 'Y'  or  p_mtl_trx_enabled_flag = 'Y') ) then

               raise e_item_stockable_transactable;

            end if;

         end if;

      end if;



   exception

      when e_no_service_billing then

         x_err_cd := 'ITEM-22';

         x_err_msg := 'Billing Type is only applicable if Service Billing is enabled';

         x_comments := 'Service Billing must be Enabled to set the Billing Type';

         l_result := false;

      when e_bad_billing_type then

         x_err_cd := 'ITEM-23';

         x_err_msg := 'Invalid Billing Type';

         x_comments := 'Valid values (M=Material, L=Labour, E=Expense) does not include '||p_billing_type;

         l_result := false;

      when e_item_stockable_transactable then

         x_err_cd := 'ITEM-24';

         x_err_msg := 'Invalid Billing Type';

         x_comments := 'Stockable and Transactable items cannot have Billing Type of E(xpense) or L(abour)';

         l_result := false;

   end;



   return(l_result);

end billing_type_ok;





-- +=========================================================================

-- | Check Recovered Part Disposition

-- +=========================================================================

function recovered_part_disposition_ok (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_billing_type  in  xxha_items_cleaned_stg.billing_type%type

        ,p_recovered_part_disposition  in  xxha_items_cleaned_stg.recovered_part_disposition%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

   e_rpd  exception;

   e_null  exception;

begin



   begin

      if (nvl(p_billing_type,'M') = 'M') then

         if (p_recovered_part_disposition not in ('M','N','S')) then

            raise e_rpd;

         end if;

      else  -- assume billing type is L(abour) or E(xpense)

         if (p_recovered_part_disposition is not null) then

            raise e_null;

         end if;

      end if;



   exception

      when e_rpd then

         x_err_cd := 'ITEM-25';

         x_err_msg := 'Invalid Recovered Part Disposition';

         x_comments := 'Valid values (M=Fast Return, N=No Return, S=Slow Return) does not include '||p_recovered_part_disposition;

         l_result := false;

      when e_null then

         x_err_cd := 'ITEM-26';

         x_err_msg := 'Recovered Part Disposition is not applicable';

         x_comments := 'Recovered Part Disposition should be NULL for L(abour) and E(xpense) billing types';

         l_result := false;

   end;



   return(l_result);

end recovered_part_disposition_ok;





-- +=========================================================================

-- | Check for item at master organization

-- +=========================================================================

procedure check_item_at_master (

         p_organization_id_mst  in  number

        ,p_item_number  in  varchar2

        ,x_inventory_item_id  out  number

        ,x_lot_control  out  number

        ) is

begin

   select  inventory_item_id

          ,lot_control_code

   into    x_inventory_item_id

          ,x_lot_control

   from    mtl_system_items_b

   where   organization_id = p_organization_id_mst

   and     segment1 = p_item_number;



exception

   when others then

      null;

end check_item_at_master;



procedure check_item_at_org (

         p_organization_id  in  number

        ,p_item_number  in  varchar2

        ,x_inventory_item_id  out  number

        ,x_item_at_org  out  boolean

        ) is

begin

   x_item_at_org := TRUE;

   select  inventory_item_id

   into    x_inventory_item_id

   from    mtl_system_items_b

   where   organization_id = p_organization_id

   and     segment1 = p_item_number;



exception

   when no_data_found then

   x_item_at_org := FALSE;

   when others then

      x_item_at_org := FALSE;

end check_item_at_org;

procedure check_item_at_org_uom (

         p_organization_id  in  number

        ,p_item_number  in  varchar2

        ,x_inventory_item_id  out  number

		, x_uom_code out varchar2

        ,x_item_at_org  out  boolean

        ) is

begin

   x_item_at_org := TRUE;

   select  inventory_item_id,primary_uom_code

   into    x_inventory_item_id,x_uom_code

   from    mtl_system_items_b

   where   organization_id = p_organization_id

   and     segment1 = p_item_number;



exception

   when no_data_found then

   x_item_at_org := FALSE;

   when others then

      x_item_at_org := FALSE;

end check_item_at_org_uom;


procedure get_item_category (

         p_organization_code  in  varchar2

        ,p_item_number  in  varchar2

		,p_category_set_id in number

        ,x_category_id  out  number

		,x_organization_id out  number

        ,x_inventory_item_id out number

		,x_category_exists  out  boolean

        ) is

begin

   x_category_exists := TRUE;

    select cat.category_id,cat.organization_id,cat.inventory_item_id

	into x_category_id,x_organization_id ,x_inventory_item_id

	from mtl_item_categories cat,mtl_system_items items, mtl_parameters param

	where cat.inventory_item_id = items.inventory_item_id

	and  cat.organization_id = items.organization_id

	and  param.organization_id = items.organization_id

	and  cat.category_set_id = p_category_set_id

	and  param.organization_code = p_organization_code

    and items.segment1 = p_item_number;



exception

   when no_data_found then

   x_category_exists := FALSE;

   when others then

      x_category_exists := FALSE;

end get_item_category;



/***************************************************************************/

/***************************************************************************/

/***************************************************************************/



-- +=========================================================================

-- | Check organization

-- +=========================================================================

function inventory_org_ok(

         p_org_item  in  varchar2

        ,p_inventory_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,x_inv_org_id  out  xxha_item_invorgs_stg.inv_org_id%type

        ,x_zero_cost_dff  out  xxha_item_invorgs_stg.zero_cost_dff%type

        ,x_starting_revision  out  xxha_item_invorgs_stg.starting_revision%type

        ,x_org_cos_cc_id  out  xxha_item_invorgs_stg.org_cos_cc_id%type

        ,x_org_sales_cc_id  out  xxha_item_invorgs_stg.org_sales_cc_id%type

        ,x_org_expense_cc_id  out  xxha_item_invorgs_stg.org_expense_cc_id%type

        ,x_ou_org_id  out  hr_operating_units.organization_id%type

        ,x_sob_id  out  gl_sets_of_books.set_of_books_id%type

        ,x_coa_id out  gl_sets_of_books.chart_of_accounts_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_inv_org_id  mtl_parameters.organization_id%type;

begin

   select  mp.organization_id

          ,mp.organization_id

          ,mp.attribute6  zero_cost_dff

          ,mp.starting_revision

          ,mp.cost_of_sales_account

          ,mp.sales_account

          ,mp.expense_account

   into    l_inv_org_id

          ,x_inv_org_id

          ,x_zero_cost_dff

          ,x_starting_revision

          ,x_org_cos_cc_id

          ,x_org_sales_cc_id

          ,x_org_expense_cc_id

   from    mtl_parameters  mp

   where   organization_code = p_inventory_org_code;



   begin

      select  to_number(hoi.org_information3)  ou_org_id

             ,hou.set_of_books_id  sob_id

             ,chart_of_accounts_id  coa_id

      into    x_ou_org_id

             ,x_sob_id

             ,x_coa_id

      from    hr_organization_information  hoi

             ,hr_operating_units  hou

             ,gl_sets_of_books  sob

      where   1=1

      and     hoi.organization_id = l_inv_org_id

      and     hoi.org_information_context = 'Accounting Information'

      and     hou.organization_id = to_number(hoi.org_information3)

      and     sob.set_of_books_id = hou.set_of_books_id;



   exception

      when no_data_found then

         x_err_cd := 'ORGITM-01A';

         x_err_msg := 'Unable to fetch Accounting Information';

         x_comments := 'Check Accounting Information setups for Org '||p_inventory_org_code;

         return(false);

      when others then

         x_err_cd := 'SQL-010';

         x_err_msg := 'Organization Accounting Information: '||SQLERRM;

         return(false);

   end;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-01';

      x_err_msg := 'Invalid Organization Code';

      x_comments := 'Check that Organization code '||p_inventory_org_code||' is valid.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Organization: '||SQLERRM;

      return(false);

end inventory_org_ok;





-- +=========================================================================

-- | Check item type

-- +=========================================================================

function user_item_type_ok(

         p_org_item  in  varchar2

        ,p_user_item_type  in  xxha_item_invorgs_stg.user_item_type%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

begin

   select  'Y'

   into    l_found

   from    fnd_lookup_values

   where   lookup_type = 'ITEM_TYPE'

   and     meaning = p_user_item_type

   and     enabled_flag = 'Y'

   and    language = 'US'

   and     sysdate between nvl(start_date_active,sysdate)

                       and nvl(end_date_active,sysdate);

   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-02';

      x_err_msg := 'Invalid Item Type';

      x_comments := 'Check that Item Type '||p_user_item_type||' is defined and active.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Item Type: '||SQLERRM;

      return(false);

end user_item_type_ok;





-- +=========================================================================

-- | Check UOM conversion allowed

-- +=========================================================================

function conversions_ok(

         p_org_item  in  varchar2

        ,p_conversions  in  xxha_item_invorgs_stg.conversions%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_conversions,3) not in (1,2,3) ) then

      x_err_cd := 'ORGITM-03';

      x_err_msg := 'Invalid Conversion Code';

      x_comments := 'Valid values (1=Item specific, 2=Standard, 3=Both standard and item specific) does not include '||p_conversions;

      l_result := false;

   end if;



   return(l_result);

end conversions_ok;





-- +=========================================================================

-- | Check if item assignment to organization already exists

-- +=========================================================================

function item_at_org (

         p_org_item  in  varchar2

        ,p_inventory_item_id  in  xxha_item_invorgs_stg.inventory_item_id%type

        ,p_inv_org_id  in  xxha_item_invorgs_stg.inv_org_id%type

        ) return boolean is

   l_found  varchar2(1);

begin

   select  'Y'

   into    l_found

   from    mtl_system_items_b

   where   organization_id = p_inv_org_id

   and     inventory_item_id = p_inventory_item_id;



   return(true);

exception

   when others then

      return(false);

end item_at_org;





---------------------------------------------------------------

-- Derive and check account code combination

---------------------------------------------------------------

function account_derivation_ok (

         p_org_item  in  varchar2

        ,p_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,p_coa_id  in  xxha_item_invorgs_stg.coa_id%type

        ,p_acct_type  in  varchar2

        ,p_org_cc_id  in  xxha_item_invorgs_stg.org_cos_cc_id%type

        ,p_category_product_line_dff  in  xxha_items_cleaned_stg.category_product_line_dff%type

        ,x_orgitm_cc_id  out  xxha_item_invorgs_stg.orgitm_cos_cc_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

  lc_concat_segments  varchar2(100);

  ln_ccid  number;



  e_skip  exception;

  e_error  exception;



begin

  -- if (p_org_code = 'MST') then

     -- raise e_skip;

   --end if;



   if (p_org_cc_id is null) then

      x_err_cd := 'ORGITM-04';

      x_err_msg := 'No '||p_acct_type||' account available for organization';

      x_comments := 'Check that account '||p_acct_type||' is specified for Org '||p_org_code;

      raise e_error;

   end if;

   if (p_category_product_line_dff is null) then

      x_err_cd := 'ORGITM-05';

      x_err_msg := 'DFF   NULL    No Product Line DFF available';

      x_comments := 'Check that DFF is defined on the category setup.';

      raise e_error;

   end if;

  -- dbms_output.put_line('---------------1-----------------'||p_org_code);

   ----------------------------------------

   -- Derive the new concatenated segments

   -----------------------------------------

   begin

      select  segment1

              ||'.'||p_category_product_line_dff

              ||'.'||segment3

              ||'.'||segment4

              ||'.'||segment5

              ||'.'||segment6

              ||'.'||segment7

              ||'.'||segment8

              ||'.'||segment9

      into    lc_concat_segments

      from    gl_code_combinations glc

      where   glc.code_combination_id = p_org_cc_id;

--dbms_output.put_line('---------------2-----------------'||lc_concat_segments);



   exception

      when no_data_found then

         x_err_cd := 'ORGITM-06';

         x_err_msg := 'Unable to fetch '||p_acct_type||' account segments';

         x_comments := 'Check the '||p_acct_type||' account in '||p_org_code||' organization setup.';

         raise e_error;

      when others then

         x_err_cd := 'TECH-001';

         x_err_msg := substr('Error fetching '||p_acct_type||' account segments : '||SQLERRM,1,2000);

         x_comments := 'Report error to Contact System Administrator';

         fnd_file.put_line(fnd_file.log,'Error fetching '||p_acct_type||' account on organization '

                                      ||p_org_code||' is: ' ||sqlerrm);

         raise e_error;

   end;



   -------------------------------------

   -- Derivation of CC_ID

   --------------------------------------

   begin

      ln_ccid:= FND_FLEX_EXT.GET_CCID(

                         'SQLGL'

                        ,'GL#'

                        ,p_coa_id

                        ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')

                        ,lc_concat_segments

                        );

--dbms_output.put_line('---------------3-----------------'||ln_ccid);





      if (ln_ccid = 0) then

         x_err_cd := 'ORGITM-07';

         x_err_msg :=  'Invalid '||p_acct_type||' account';

         x_comments := 'Check code combination '||lc_concat_segments||' - Org is '||p_org_code;

         raise e_error;

      else

         x_orgitm_cc_id := ln_ccid;

--dbms_output.put_line('---------------4-----------------'||ln_ccid);



      end if;

   exception

      when others then

         x_err_cd := 'TECH-002';

         x_err_msg := substr('Error getting CC_ID for '||p_acct_type||' account : '||SQLERRM,1,2000);

         x_comments := 'Combination is '||lc_concat_segments||' ... Report error to Contact System Administrator';

         fnd_file.put_line(fnd_file.log,'Error getting CCID for '||lc_concat_segments || ' is : ' ||sqlerrm);

         raise e_error;

   end;

--dbms_output.put_line('---------------5-----------------'||ln_ccid);

return (true);

exception

   when e_skip then

      return(true);

   when e_error then

      return(false);

end account_derivation_ok;





-- +=========================================================================

-- | Check attribute value is Y or N on item assignments to organization

-- +=========================================================================

function asg_value_YN_ok (

         p_org_item  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_attr_value,'N') not in ('N','Y')) then

      x_err_cd := 'ORGITM-08';

      x_err_msg := 'Invalid '||p_attr_name;

      x_comments := 'Valid values (N=No, Y=Yes) does not include '||p_attr_value;

      l_result := false;

   end if;



   return(l_result);

end asg_value_YN_ok;





-- +=========================================================================

-- | Check purchasing tax code

-- +=========================================================================

function purchasing_tax_code_ok (

         p_org_item  in  varchar2

        ,p_ou_org_id  in  xxha_item_invorgs_stg.ou_org_id%type

        ,p_purchasing_tax_code  in  xxha_item_invorgs_stg.purchasing_tax_code%type

        ,x_purchasing_tax_id  out  xxha_item_invorgs_stg.purchasing_tax_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

begin

   if (p_purchasing_tax_code is null) then

      return(true);

   end if;



   select  t.tax_id

   into    x_purchasing_tax_id

   from    ap_tax_codes_all  t

   where   t.org_id = p_ou_org_id

   and     t.name = p_purchasing_tax_code;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-09';

      x_err_msg := 'Invalid Purchasing Tax Code';

      x_comments := 'Check that purchasing tax code '||p_purchasing_tax_code||' is defined and active.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Purchasing Tax Code: '||SQLERRM;

      return(false);

end purchasing_tax_code_ok;





-- +=========================================================================

-- | Check default buyer

-- +=========================================================================

function default_buyer_name_ok (

         p_org_item  in  varchar2

        ,p_default_buyer_name  in  xxha_item_invorgs_stg.default_buyer_name%type

        ,x_buyer_id  out  xxha_item_invorgs_stg.buyer_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

begin

   if (p_default_buyer_name is null) then

      return(true);

   end if;



   select  agent_id

   into    x_buyer_id

   from    po_agents_v

   where   agent_name = p_default_buyer_name;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-10';

      x_err_msg := 'Invalid Default Buyer Name';

      x_comments := 'Check that '||p_default_buyer_name||' is setup as a buyer';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Buyer: '||SQLERRM;

      return(false);

end default_buyer_name_ok;





-- +=========================================================================

-- | Check planner

-- +=========================================================================

function planner_ok (

         p_org_item  in  varchar2

        ,p_ou_org_id  in  xxha_item_invorgs_stg.ou_org_id%type

        ,p_planner  in  xxha_item_invorgs_stg.planner%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

begin

   if (p_planner is null) then

      return(true);

   end if;

   --dbms_output.put_line(p_planner||p_ou_org_id);

   select  'Y'

   into    l_found

   from    mtl_planners

   where   planner_code = p_planner

   and     organization_id = p_ou_org_id;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-11';

      x_err_msg := 'Invalid Planner';

      x_comments := 'Check that planner '||p_planner||' is setup';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Planner: '||SQLERRM;

      return(false);

end planner_ok;





-- +=========================================================================

-- | Check 'Make' or 'Buy' flag

-- +=========================================================================

function make_or_buy_ok(

         p_org_item  in  varchar2

        ,p_make_or_buy  in  xxha_item_invorgs_stg.make_or_buy%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (nvl(p_make_or_buy,1) not in (1,2) ) then

      x_err_cd := 'ORGITM-12';

      x_err_msg := 'Invalid plannin Make or Buy flag';

      x_comments := 'Valid values (1=Make, 2=Buy) does not include '||p_make_or_buy;

      l_result := false;

   end if;



   return(l_result);

end make_or_buy_ok;





-- +=========================================================================

-- | Check postprocessing lead time with 'Make' or 'Buy' flag

-- +=========================================================================

function postprocessing_lead_time_ok(

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_inventory_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,p_make_buy_code  in  xxha_item_invorgs_stg.make_or_buy%type

        ,p_postprocessing_lead_time  in  xxha_items_cleaned_stg.postprocessing_lead_time%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   -- if 'make', the postprocessing lead time must be zero (0)
   return l_result;
   if (p_make_buy_code = 1) then

      if (nvl(p_postprocessing_lead_time,0) <> 0) then

         x_err_cd := 'ORGITM-12A';

         x_err_msg := 'Invalid Postprocessing Lead Time for ''Make'' item';

         x_comments := 'Postprocessing Lead Time ['||p_postprocessing_lead_time||'] must be zero when Make/Buy flag is ''Make'' [General Planning]';

         l_result := false;

      end if;

   end if;



   return(l_result);

end postprocessing_lead_time_ok;





-- +=========================================================================

-- | Check for organization

-- +=========================================================================

function organization_ok (

         p_org_item  in  varchar2

        ,p_org_type  in  varchar2

        ,p_organization_code  in  mtl_parameters.organization_code%type

        ,x_organization_id  out  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

begin

   if (p_organization_code is null) then

      return(true);

   end if;



   select  organization_id

   into    x_organization_id

   from    mtl_parameters

   where   organization_code = p_organization_code;



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-13';

      x_err_msg := 'Invalid '||p_org_type||' Organization';

      x_comments := 'Check '||p_organization_code||' organization setup.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Organization Code: '||SQLERRM;

      return(false);

end organization_ok;





-- +=========================================================================

-- | Check attribute value for >= 0

-- +=========================================================================

function asg_range_gr_eq_0 (

         p_org_item  in  varchar2

        ,p_attr_name  in  varchar2

        ,p_attr_value  in  number

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (p_attr_value is not null) then

      if (p_attr_value < 0) then

         x_err_cd := 'ORGITM-14';

         x_err_msg := 'Invalid '||p_attr_name;

         x_comments := 'Allowed '||p_attr_name||' range ( >= 0 ) does not include '||p_attr_value;

         l_result := false;

      end if;

   end if;



   return(l_result);

end asg_range_gr_eq_0;





-- +=========================================================================

-- | Check invoicing tax code

-- +=========================================================================

function tax_code_ok (

         p_org_item  in  varchar2

        ,p_ou_org_id  in  xxha_item_invorgs_stg.ou_org_id%type

        ,p_tax_code  in  xxha_item_invorgs_stg.tax_code%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_found  varchar2(1);

begin

   if (p_tax_code is null) then

      return(true);

   end if;



   select  'Y'

   into    l_found

   from    ar_vat_tax_all  t

   where   t.org_id = p_ou_org_id

   and     t.tax_code = p_tax_code

   and     trunc(sysdate) between t.start_date

                              and nvl(t.end_date,trunc(sysdate))

   and     t.enabled_flag = 'Y';



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-15';

      x_err_msg := 'Invalid Invoicing Tax Code';

      x_comments := 'Check that invoicing tax code '||p_tax_code||' is defined and active.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Invoicing Tax Code: '||SQLERRM;

      return(false);

end tax_code_ok;





-- +=========================================================================

-- | Check payment terms name

-- +=========================================================================

function payment_terms_name_ok (

         p_org_item  in  varchar2

        ,p_payment_terms_name  in  xxha_item_invorgs_stg.payment_terms_name%type

        ,x_payment_terms_id  out  xxha_item_invorgs_stg.payment_terms_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

begin

   if (p_payment_terms_name is null) then

      return(true);

   end if;



   select  t.term_id

   into    x_payment_terms_id

   from    ra_terms_tl  t

          ,ra_terms_b  b

   where   t.name = p_payment_terms_name

   and     t.language = 'US'

   and     b.term_id = t.term_id

   and     sysdate between nvl(b.start_date_active,sysdate)

                       and nvl(b.end_date_active,sysdate);



   return(true);

exception

   when no_data_found then

      x_err_cd := 'ORGITM-16';

      x_err_msg := 'Invalid Payment Terms Name';

      x_comments := 'Check that payment term '||p_payment_terms_name||' is defined and active.';

      return(false);

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Payment Term: '||SQLERRM;

      return(false);

end payment_terms_name_ok;





-- +=========================================================================

-- | Compare the revision number against the latest starting revision that

-- | has been setup for organizations staged for the item

-- +=========================================================================

function compare_w_org_starting_rev_ok (

         p_item_rev  in  varchar2

        ,p_item_number  in  xxha_item_revisions_stg.item_number%type

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_max_org_starting_rev  in  varchar2

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_result  boolean := true;

begin

   if (p_revision_no < p_max_org_starting_rev) then

      x_err_cd := 'ITMREV-01';

      x_err_msg := 'Revisions are out of synch.';

      x_comments := 'The revision is lower than the Org Starting Revision ('||p_max_org_starting_rev||

                    ') of at least one Org staged for the item';

      x_comments := 'The revision is lower than the At least one organization has been set up with a Starting Revision ('

                    ||p_max_org_starting_rev||') higher than the staged revision';

      l_result := false;

   end if;



   return(l_result);

end compare_w_org_starting_rev_ok;





-- +=========================================================================

-- | Check chronology of staged item revisions

-- +=========================================================================

function staged_chronology_ok (

         p_item_rev  in  varchar2

        ,p_item_number  in  xxha_item_revisions_stg.item_number%type

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_effective_date  in  xxha_item_revisions_stg.effective_date%type

        ,p_ci_flag  in  xxha_item_revisions_stg.ci_flag%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_rev_count  number := 0;

begin

   if (p_effective_date is null) then

      return(true);

   end if;



   select  count(1)

   into    l_rev_count

   from    xxha_item_revisions_stg  x

   where   x.item_number = p_item_number

   and     x.ci_flag = p_ci_flag

   and     x.status in ('NEW','VS','VE')

   and     x.effective_date is not null

   and (   (    x.revision_no > p_revision_no

            and x.effective_date < p_effective_date)

        or (    x.revision_no < p_revision_no

            and x.effective_date > p_effective_date)

       );



   if (l_rev_count > 0) then

      x_err_cd := 'ITMREV-01A';

      x_err_msg := 'Revisions are not properly ordered.';

      x_comments := 'Revisions must be chronologically ordered - check Revision '||p_item_rev||' and Effective Date '||p_effective_date;

      return(false);

   end if;



   return(true);

exception

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Revision Chronology: '||SQLERRM;

      return(false);

end staged_chronology_ok;





-- +=========================================================================

-- | Check for a higher item revision in master org

-- +=========================================================================

function higher_revision_exists (

         p_item_rev  in  varchar2

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_item_number  in  xxha_item_revisions_stg.item_number%type

        ,p_inventory_item_id  in  xxha_item_revisions_stg.inventory_item_id%type

        ,p_org_id_mst  in  mtl_parameters.organization_id%type

        ,x_err_cd  out  varchar2

        ,x_err_msg  out  varchar2

        ,x_comments  out  varchar2

        ) return boolean is

   l_rev_count  number := 0;

   l_revision  mtl_item_revisions_b.revision%type;

begin

   select  count(1)

          ,min(x.revision)

   into    l_rev_count

          ,l_revision

   from    mtl_item_revisions_b  x

   where   x.inventory_item_id = p_inventory_item_id

   and     x.organization_id = p_org_id_mst

   and     x.revision > p_revision_no;



   if (l_rev_count > 0) then

      x_err_cd := 'ITMREV-02';

      x_err_msg := 'At least one later revision already exists.';

      x_comments := 'Revisions must be created in order.  '''||l_revision||''' already exists.';

      return(false);

   end if;



   --------------------------------------------------------------------------------

   -- At this point, no higher revision has been found to exist.

   -- So ... check for higher revision that has been interfaced and pending import

   --------------------------------------------------------------------------------

   l_rev_count := 0;

   l_revision := null;



   select  count(1)

          ,min(x.revision)

   into    l_rev_count

          ,l_revision

   from    mtl_item_revisions_interface  x

   where   x.inventory_item_id = p_inventory_item_id

   and     x.organization_id = p_org_id_mst

   and     x.revision > p_revision_no

   and     x.process_flag = 1  -- Pending

   and     x.transaction_type = 'CREATE';



   if (l_rev_count > 0) then

      x_err_cd := 'ITMREV-03';

      x_err_msg := 'At least one later revision is already interfaced and pending processing.';

      x_comments := 'Revisions must be created in order.  '''||l_revision||''' is already interfaced.';

      return(false);

   end if;



   return(true);

exception

   when others then

      x_err_cd := 'SQL-010';

      x_err_msg := 'Higher Revision: '||SQLERRM;

      return(false);

end higher_revision_exists;





-- +=========================================================================

-- | Check if revision already exists at master org

-- +=========================================================================

function revision_exists (

         p_item_rev  in  varchar2

        ,p_revision_no  in  xxha_item_revisions_stg.revision_no%type

        ,p_inventory_item_id  in  xxha_item_revisions_stg.inventory_item_id%type

        ,p_org_id_mst  in  mtl_parameters.organization_id%type

        ) return boolean is

   l_found  varchar2(1);

begin

   select  'Y'

   into    l_found

   from    mtl_item_revisions_b

   where   organization_id = p_org_id_mst

   and     inventory_item_id = p_inventory_item_id

   and     revision = p_revision_no;



   return(true);

exception

   when others then

      return(false);

end revision_exists;





-- +=========================================================================

-- | Check for starting revision of an item at an org

-- | If it is not found, create interface record for it if create_flag = Y

-- +=========================================================================

procedure check_on_orgitem_starting_rev (

         p_item_number  in  xxha_items_cleaned_stg.item_number%type

        ,p_inventory_item_id  in  xxha_items_cleaned_stg.inventory_item_id%type

        ,p_start_date_active  in  xxha_items_cleaned_stg.start_date_active%type

        ,p_inventory_org_code  in  xxha_item_invorgs_stg.inventory_org_code%type

        ,p_inv_org_id  in  xxha_item_invorgs_stg.inv_org_id%type

        ,p_starting_rev  in  xxha_item_invorgs_stg.starting_revision%type

        ,p_set_process_id  in  mtl_item_revisions_interface.set_process_id%type

        ,p_now  in  date

        ,p_user_id  in  number

        ,p_create_flag  in  varchar2

        ) is

   l_found  varchar2(1);

   e_skip  exception;

begin

   -- does item already exist?

   if (p_inventory_item_id is not null) then



      -- check if starting revision exists

      begin

         select  'Y'

         into    l_found

         from    mtl_item_revisions_b

         where   inventory_item_id = p_inventory_item_id

         and     organization_id = p_inv_org_id

         and     revision = p_starting_rev;



         -- revision exists, so exit procedure

         raise e_skip;



      exception

         when no_data_found then

            -- revision not found, so let fall thru

            null;

      end;

   end if;



   -- At this point, either the item and/or revision does not exist

   -- Need to decide if to create revision interface record

   if (p_create_flag = 'Y') then

      /*insert into mtl_item_revisions_interface (

             inventory_item_id

            ,item_number

            ,organization_id

            ,organization_code

            ,revision

            ,effectivity_date

            ,description

            ,last_update_date

            ,last_updated_by

            ,creation_date

            ,created_by

            ,transaction_type

            ,process_flag

            ,set_process_id

            )

      values (

             p_inventory_item_id

            ,p_item_number

            ,p_inv_org_id

            ,p_inventory_org_code

            ,p_starting_rev

            ,p_start_date_active

            ,'Starting Revision'

            ,p_now

            ,p_user_id

            ,p_now

            ,p_user_id

            ,'CREATE'

            ,1

            ,p_set_process_id

            );*/
      NULL;
   end if;



exception

   when e_skip then

      null;

end check_on_orgitem_starting_rev;


procedure check_unit_of_issue(p_item_number varchar2
                             ,p_primary_uom_code varchar2
                            ,p_unit_of_issue in out varchar2
							,x_unit_of_issue_valid out boolean)
							is


	l_primary_uom_class varchar2 (2000);
	l_uoi_uom_class varchar2 (2000);
	l_uoi_unit_of_measure varchar2 (2000);
begin
 x_unit_of_issue_valid := false;
  begin
  	select prim.uom_class,uoi.uom_class,uoi.unit_of_measure
	into l_primary_uom_class,l_uoi_uom_class, l_uoi_unit_of_measure
	from mtl_units_of_measure prim,mtl_units_of_measure uoi
	where prim.uom_code = p_primary_uom_code
	and uoi.uom_code = p_unit_of_issue
	;
    IF   l_primary_uom_class = l_uoi_uom_class THEN
	  p_unit_of_issue := l_uoi_unit_of_measure;
	  x_unit_of_issue_valid := true;
	ELSE
	x_unit_of_issue_valid := false;
	   --p_unit_of_issue := null;
	END IF;
  exception
  when no_data_found then
    x_unit_of_issue_valid := false;
  when others then
  x_unit_of_issue_valid := false;
  end;






end;


END XXHA_INV_COMMON_UTILITIES_PK;
/
