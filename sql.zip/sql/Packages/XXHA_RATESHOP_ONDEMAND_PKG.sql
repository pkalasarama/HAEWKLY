CREATE OR REPLACE PACKAGE "APPS"."XXHA_RATESHOP_ONDEMAND_PKG" 
  /*******************************************************************************************************
  * Object Name: XXHA_RATESHOP_ONDEMAND_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package will be used for ondemand process/ void xml/ rerateshop/ revert rateshop 
  *              based on different cirteria
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    27-JAN-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
AS
 PROCEDURE RS_OM_INSERT(
      errbuf OUT VARCHAR2 ,
      retcode OUT VARCHAR2,
      P_ORDER_NUMBER       IN VARCHAR2 ,
      p_sch_ship_date_from IN VARCHAR2,
      p_sch_ship_date_to   IN VARCHAR2,
      p_org_name           IN VARCHAR2,
      p_rerateshop         IN VARCHAR2 ,
      p_voidxmlfrehan      IN VARCHAR2 ,
      p_rmrateshop         IN VARCHAR2 )
  ;

END XXHA_RATESHOP_ONDEMAND_PKG;
/

create or replace PACKAGE BODY "XXHA_RATESHOP_ONDEMAND_PKG"
  /*******************************************************************************************************
  * Object Name: XXHA_RATESHOP_ONDEMAND_PKG
  * Object Type: PACKAGE BODY
  *
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    27-JAN-2015          Initial object creation.
  * Apps Associates    20-OCT-2015          Modified code for fixing rateshop issue
  * Apps Associates    04-DEC-2015          Modified code for fixing rateshop issue
  *
  *******************************************************************************************************/
AS
  PROCEDURE RS_OM_INSERT(
      errbuf OUT VARCHAR2 ,
      retcode OUT VARCHAR2,
      P_ORDER_NUMBER       IN VARCHAR2 ,
      p_sch_ship_date_from IN VARCHAR2,
      p_sch_ship_date_to   IN VARCHAR2,
      p_org_name           IN VARCHAR2,
      p_rerateshop         IN VARCHAR2 ,
      p_voidxmlfrehan      IN VARCHAR2 ,
      p_rmrateshop         IN VARCHAR2 )
  AS
    c_transaction_type VARCHAR2(100) :='RATESHOP';
    l_err              VARCHAR2(100);
    l_transaction_id   NUMBER;
    l_header_id        NUMBER;
    CURSOR c_orders
    IS
      SELECT order_number,
        header_id
      FROM oe_order_headers_all
      WHERE attribute20='RERATESHOP'
    UNION
    SELECT DISTINCT ooh.order_number,
      ooh.header_id
    FROM OE_ORDER_HEADERS_ALL OOH,
      OE_ORDER_LINES_ALL OOL ,
      MTL_PARAMETERS MP ,
      OE_TRANSACTION_TYPES_ALL OOTA ,
      OE_TRANSACTION_TYPES_TL oota01,
      OE_TRANSACTION_TYPES_ALL OOTA1 ,
      FND_LOOKUP_VALUES SHIP_METHOD,
      mtl_reservations res
    WHERE 1                   = 1
    AND ooh.booked_flag       ='Y'
    AND ooh.header_id         = ool.header_id
    AND ool.line_id           = res.demand_source_line_id
    AND ool.ship_from_org_id  = res.organization_id
    AND ool.inventory_item_id = res.inventory_item_id
    AND ool.ordered_quantity  > = res.reservation_quantity
      --  AND TRUNC(res.creation_date)    =TRUNC(sysdate)
    AND TRUNC(schedule_ship_date)  <=TRUNC(sysdate+1)
    AND OOH.ORDER_TYPE_ID           =OOTA.TRANSACTION_TYPE_ID
    AND oota.transaction_type_code  = 'ORDER'
    AND oota.ATTRIBUTE2             ='Y'
    AND OOTA.END_DATE_ACTIVE       IS NULL
    AND OOTA.TRANSACTION_TYPE_ID    = OOTA01.TRANSACTION_TYPE_ID
    AND OOTA01.language             = 'US'
    AND OOL.LINE_TYPE_ID            =OOTA1.TRANSACTION_TYPE_ID(+)
    AND oota1.transaction_type_code = 'LINE'
      --AND oota1.ATTRIBUTE2             ='Y'
    AND OOTA1.END_DATE_ACTIVE IS NULL
    AND ool.ship_from_org_id   = mp.organization_id
      -- AND mp.organization_code                          =NVL(l_org_name,mp.organization_code)
    AND xxha_wms_org_validation(mp.organization_code) = 'Y'
    AND ool.shipping_method_code                      = ship_method.lookup_code
    AND SHIP_METHOD.LOOKUP_TYPE                       = 'SHIP_METHOD'
    AND SHIP_METHOD.LANGUAGE                          = USERENV('LANG')
    AND UPPER(SHIP_METHOD.MEANING) LIKE 'GENERIC%'
    AND ool.split_from_line_id IS NOT NULL;
    CURSOR c_reserve_order_val (p_header_id NUMBER) -- AAA Cursor added to be used for order-line validation while performing reserve and split
    IS
      SELECT DISTINCT ool.header_id,
        ool.line_id
      FROM oe_order_lines_all ool,
        mtl_parameters mp ,
        oe_transaction_types_all oota1 ,
        fnd_lookup_values ship_method,
        (select demand_source_line_id,inventory_item_id,organization_id, sum(reservation_quantity) reservation_quantity
    from mtl_reservations
    group by demand_source_line_id,inventory_item_id,organization_id) res
      WHERE 1                         = 1
      AND ool.header_id               = p_header_id
      AND ool.line_type_id            =oota1.transaction_type_id
      AND oota1.transaction_type_code = 'LINE'
        --AND oota1.attribute2                              ='Y'
      AND oota1.end_date_active                        IS NULL
      AND ool.ship_from_org_id                          =mp.organization_id
      AND xxha_wms_org_validation(mp.organization_code) = 'Y'
      AND ool.shipping_method_code                      = ship_method.lookup_code(+)
      AND ship_method.lookup_type                       = 'SHIP_METHOD'
      AND ship_method.language                          = userenv('LANG')
      AND upper(ship_method.meaning) LIKE 'GENERIC%'
      AND ool.line_id           = res.demand_source_line_id
      AND res.organization_id   = ool.ship_from_org_id
      AND res.inventory_item_id = ool.inventory_item_id
      AND ool.ordered_quantity <>res.reservation_quantity;
    CURSOR c_voidxmldeliveries
    IS
      SELECT delivery_id,
        'BACKORDER' SCENARIO
      FROM wsh_new_deliveries
      WHERE attribute10='VOIDXML'
    UNION ALL
    SELECT DISTINCT da.delivery_id,
      'SHIPMETHOD' SCENARIO
    FROM wsh_delivery_details dd,
      wsh_delivery_assignments da
    WHERE 1                   =1
    AND dd.delivery_detail_id = da.delivery_detail_id
    AND dd.attribute10        ='VOIDXML';
    CURSOR c_rmrateshoporders
    IS
      SELECT order_number,
        header_id,
        attribute20
      FROM oe_order_headers_all
      WHERE attribute20 IN ('RSHOLD')
    UNION ALL
    SELECT NULL order_number,
      header_id,
      action_type attribute20
    FROM apps.XXHA_RATESHOP_TEMP
    WHERE processed_flag='N';
    CURSOR c_reserve_order_val_re(l_order_number VARCHAR2,l_sch_ship_date_from DATE,l_sch_ship_date_to DATE,l_org_name VARCHAR2)
    IS
      SELECT DISTINCT ool.header_id,
        ool.line_id
      FROM OE_ORDER_HEADERS_ALL OOH,
        OE_ORDER_LINES_ALL OOL ,
        MTL_PARAMETERS MP ,
        OE_TRANSACTION_TYPES_ALL OOTA ,
        OE_TRANSACTION_TYPES_ALL OOTA1 ,
        FND_LOOKUP_VALUES SHIP_METHOD,
        (select demand_source_line_id,inventory_item_id,organization_id, sum(reservation_quantity) reservation_quantity
    from mtl_reservations
    group by demand_source_line_id,inventory_item_id,organization_id) res
      WHERE 1             = 1
      AND OOH.order_number=NVL(l_order_number,OOH.order_number)
      AND ooh.header_id   = ool.header_id
      AND TRUNC(ool.schedule_ship_date) BETWEEN NVL(TRUNC(l_sch_ship_date_from),TRUNC(ool.schedule_ship_date)) AND NVL(TRUNC(l_sch_ship_date_to),TRUNC(ool.schedule_ship_date))
      AND OOH.ORDER_TYPE_ID           =OOTA.TRANSACTION_TYPE_ID
      AND oota.transaction_type_code  = 'ORDER'
      AND oota.ATTRIBUTE2             ='Y'
      AND OOTA.END_DATE_ACTIVE       IS NULL
      AND OOL.LINE_TYPE_ID            =OOTA1.TRANSACTION_TYPE_ID(+)
      AND oota1.transaction_type_code = 'LINE'
        --AND oota1.ATTRIBUTE2            ='Y'
      AND OOTA1.END_DATE_ACTIVE   IS NULL
      AND ool.ship_from_org_id     =mp.organization_id
      AND mp.organization_code     =NVL(l_org_name,mp.organization_code)
      AND ool.shipping_method_code = ship_method.lookup_code(+)
      AND SHIP_METHOD.LOOKUP_TYPE  = 'SHIP_METHOD'
      AND SHIP_METHOD.LANGUAGE     = USERENV('LANG')
        --  AND UPPER(SHIP_METHOD.MEANING) LIKE 'GENERIC%'
      AND ool.line_id           = res.demand_source_line_id
      AND res.organization_id   = ool.ship_from_org_id
      AND res.inventory_item_id = ool.inventory_item_id
      AND ool.ordered_quantity <>res.reservation_quantity
        --AND XXHA_WMS_RATESHOP_VALIDATION(ooh.header_id)='N'
        ;
    CURSOR reg_orders(l_order_number VARCHAR2,l_sch_ship_date_from DATE,l_sch_ship_date_to DATE,l_org_name VARCHAR2)
    IS
      SELECT DISTINCT ooh.order_number,
        ooh.header_id ,
        OOTA01.name order_type,
        mp.organization_code warehouse --aaa
      FROM OE_ORDER_HEADERS_ALL OOH,
        OE_ORDER_LINES_ALL OOL ,
        MTL_PARAMETERS MP ,
        OE_TRANSACTION_TYPES_ALL OOTA ,
        OE_TRANSACTION_TYPES_TL oota01,
        OE_TRANSACTION_TYPES_ALL OOTA1 ,
        FND_LOOKUP_VALUES SHIP_METHOD
      WHERE 1             = 1
      AND OOH.order_number=NVL(l_order_number,OOH.order_number)
      AND ooh.header_id   = ool.header_id
      AND TRUNC(ool.schedule_ship_date) BETWEEN NVL(TRUNC(l_sch_ship_date_from),TRUNC(ool.schedule_ship_date)) AND NVL(TRUNC(l_sch_ship_date_to),TRUNC(ool.schedule_ship_date))
      AND OOH.ORDER_TYPE_ID           =OOTA.TRANSACTION_TYPE_ID
      AND oota.transaction_type_code  = 'ORDER'
      AND oota.ATTRIBUTE2             ='Y'
      AND OOTA.END_DATE_ACTIVE       IS NULL
      AND OOTA.TRANSACTION_TYPE_ID    = OOTA01.TRANSACTION_TYPE_ID
      AND OOTA01.language             = 'US'
      AND OOL.LINE_TYPE_ID            =OOTA1.TRANSACTION_TYPE_ID(+)
      AND oota1.transaction_type_code = 'LINE'
        --AND oota1.ATTRIBUTE2            ='Y'
      AND OOTA1.END_DATE_ACTIVE                        IS NULL
      AND ool.ship_from_org_id                          =mp.organization_id
      AND mp.organization_code                          =NVL(l_org_name,mp.organization_code)
      AND NVL(ool.attribute11,ool.shipping_method_code) = ship_method.lookup_code(+)
      AND SHIP_METHOD.LOOKUP_TYPE                       = 'SHIP_METHOD'
      AND SHIP_METHOD.LANGUAGE                          = USERENV('LANG')
      AND UPPER(SHIP_METHOD.MEANING) LIKE 'GENERIC%';
    --    AND XXHA_WMS_RATESHOP_VALIDATION(ooh.header_id)='N';
    CURSOR c_rs_reserve_order_val(l_order_number VARCHAR2)
    IS
      SELECT DISTINCT ool.header_id,
        ool.line_id
      FROM OE_ORDER_HEADERS_ALL OOH,
        OE_ORDER_LINES_ALL OOL ,
        MTL_PARAMETERS MP ,
        OE_TRANSACTION_TYPES_ALL OOTA ,
        OE_TRANSACTION_TYPES_ALL OOTA1 ,
        FND_LOOKUP_VALUES SHIP_METHOD,
        (select demand_source_line_id,inventory_item_id,organization_id, sum(reservation_quantity) reservation_quantity
    from mtl_reservations
    group by demand_source_line_id,inventory_item_id,organization_id) res
      WHERE 1              = 1
      AND OOH.order_number =l_order_number
        --AND TRUNC(ooh.creation_date)     =TRUNC(sysdate)
        --AND TRUNC(ooh.BOOKED_DATE)     =TRUNC(sysdate) --V2.0 Removed by AA as per CRP2 req
      AND ooh.header_id = ool.header_id
        --AND TRUNC(ool.schedule_ship_date)=TRUNC(sysdate)--V2.0 Removed by AA as per CRP2 req -- BETWEEN nvl(TRUNC(l_sch_ship_date_from),trunc(ool.schedule_ship_date)) AND nvl(TRUNC(l_sch_ship_date_to),trunc(ool.schedule_ship_date))
      AND OOH.ORDER_TYPE_ID           =OOTA.TRANSACTION_TYPE_ID
      AND oota.transaction_type_code  = 'ORDER'
      AND oota.ATTRIBUTE2             ='Y'
      AND OOTA.END_DATE_ACTIVE       IS NULL
      AND OOL.LINE_TYPE_ID            =OOTA1.TRANSACTION_TYPE_ID(+)
      AND oota1.transaction_type_code = 'LINE'
        --AND oota1.ATTRIBUTE2             ='Y'
      AND OOTA1.END_DATE_ACTIVE IS NULL
      AND ool.ship_from_org_id   =mp.organization_id
        --AND mp.organization_code     ='USE'--V2.0 Removed by AA as per CRP2 req
      AND xxha_wms_org_validation(mp.organization_code) = 'Y'
      AND ool.shipping_method_code                      = ship_method.lookup_code
      AND SHIP_METHOD.LOOKUP_TYPE                       = 'SHIP_METHOD'
      AND SHIP_METHOD.LANGUAGE                          = USERENV('LANG')
        --  AND UPPER(SHIP_METHOD.MEANING) LIKE 'GENERIC%'
      AND ool.line_id           = res.demand_source_line_id
      AND res.organization_id   = ool.ship_from_org_id
      AND res.inventory_item_id = ool.inventory_item_id
      AND ool.ordered_quantity <>res.reservation_quantity
        --AND XXHA_WMS_RATESHOP_VALIDATION(ooh.header_id)='N' --V2.0 Removed by AA as per CRP2 req
        ;
    CURSOR reg_rateshop_orders(l_org_name VARCHAR2)
    IS
      SELECT DISTINCT ooh.order_number,
        ooh.header_id ,
        OOTA01.name order_type,
        mp.organization_code warehouse --aaa
      FROM OE_ORDER_HEADERS_ALL OOH,
        OE_ORDER_LINES_ALL OOL ,
        MTL_PARAMETERS MP ,
        OE_TRANSACTION_TYPES_ALL OOTA ,
        OE_TRANSACTION_TYPES_TL oota01,
        OE_TRANSACTION_TYPES_ALL OOTA1 ,
        FND_LOOKUP_VALUES SHIP_METHOD,
        mtl_reservations res
      WHERE 1                   = 1
      AND ooh.booked_flag       ='Y'
      AND ooh.header_id         = ool.header_id
      AND ool.line_id           = res.demand_source_line_id
      AND ool.ship_from_org_id  = res.organization_id
      AND ool.inventory_item_id = res.inventory_item_id
      AND ool.ordered_quantity  > = res.reservation_quantity
        --   AND TRUNC(res.creation_date)    =TRUNC(sysdate)
      AND TRUNC(schedule_ship_date)  <=TRUNC(sysdate+1)
      AND OOH.ORDER_TYPE_ID           =OOTA.TRANSACTION_TYPE_ID
      AND oota.transaction_type_code  = 'ORDER'
      AND oota.ATTRIBUTE2             ='Y'
      AND OOTA.END_DATE_ACTIVE       IS NULL
      AND OOTA.TRANSACTION_TYPE_ID    = OOTA01.TRANSACTION_TYPE_ID
      AND OOTA01.language             = 'US'
      AND OOL.LINE_TYPE_ID            =OOTA1.TRANSACTION_TYPE_ID(+)
      AND oota1.transaction_type_code = 'LINE'
        --AND oota1.ATTRIBUTE2             ='Y'
      AND OOTA1.END_DATE_ACTIVE                        IS NULL
      AND ool.ship_from_org_id                          = mp.organization_id
      AND mp.organization_code                          =NVL(l_org_name,mp.organization_code)
      AND xxha_wms_org_validation(mp.organization_code) = 'Y'
      AND ool.shipping_method_code                      = ship_method.lookup_code
      AND SHIP_METHOD.LOOKUP_TYPE                       = 'SHIP_METHOD'
      AND SHIP_METHOD.LANGUAGE                          = USERENV('LANG')
      AND UPPER(SHIP_METHOD.MEANING) LIKE 'GENERIC%'
      AND (ooh.attribute20 IS NULL
      OR ooh.attribute20!   ='RERATESHOP')
        /* AND ooh.ROWID IN
        (SELECT xxha_find_locked_rows (ooh.ROWID, 'oe_order_headers_all' )
        FROM oe_order_headers_all
        )*/
        ;
    pl_sch_ship_date_from DATE;
    pl_sch_ship_date_to   DATE;
    l_reserve_cnt         NUMBER := 0;
    l_cr_interval         NUMBER := 60; -- seconds
    l_cr_max_wait         NUMBER := 0;  -- seconds(0 = Will not time out)
    l_cr_phase_code       VARCHAR2(30);
    l_cr_status_code      VARCHAR2(30);
    l_cr_dev_phase        VARCHAR2(30);
    l_cr_dev_status       VARCHAR2(30);
    l_cr_message          VARCHAR2(240);
    l_jimport_cr_complete BOOLEAN;
    l_request_id          NUMBER;
    l_order_cnt           NUMBER :=0;
    l_hold_rateshop       NUMBER;
  BEGIN
    /*For Remove Rateshop scenario to revert ship method for order lines*/
    IF p_rmrateshop='Y' THEN
      fnd_file.put_line(fnd_file.log, 'Entered remove rateshiop block to perform 1. Revert ship method');
      FOR rec_rmrateshoporders IN c_rmrateshoporders
      LOOP
        IF rec_rmrateshoporders.attribute20='RMRATESHOP-ORG' THEN
          fnd_file.put_line(fnd_file.log,'Performing revert ship method on order: '||rec_rmrateshoporders.order_number);
          XXHA_SHIP_METHOD_DEFAULT_PRC(rec_rmrateshoporders.header_id); --revert ship method same as order header
          fnd_file.put_line(fnd_file.log,'Completed revert ship method on order: '||rec_rmrateshoporders.order_number);
          --This is to update attribute mentioned about revert ship method.
          /*        UPDATE oe_order_headers_all
          SET attribute20='RMDRATESHOP'
          WHERE header_id=rec_rmrateshoporders.header_id;
          */
          -- This is to update processed flag for processed records in temp table.
          UPDATE XXHA_RATESHOP_TEMP
          SET processed_flag = 'Y'
          WHERE header_id    = rec_rmrateshoporders.header_id;
          COMMIT;
        ELSE
          fnd_file.put_line(fnd_file.log,'Performing revert ship method on order: '||rec_rmrateshoporders.order_number);
          XXHA_SHIP_METHOD_DEFAULT_PRC(rec_rmrateshoporders.header_id); --revert ship method same as order header
          fnd_file.put_line(fnd_file.log,'Completed revert ship method on order: '||rec_rmrateshoporders.order_number);
          --This is to update attribute mentioned about revert ship method.
          /*    UPDATE oe_order_headers_all
          SET attribute20='RMDRATESHOP'
          WHERE header_id=rec_rmrateshoporders.header_id;
          -- This is to update processed flag for processed records in temp table.
          */
          UPDATE XXHA_RATESHOP_TEMP
          SET processed_flag = 'Y'
          WHERE header_id    = rec_rmrateshoporders.header_id;
          COMMIT;
        END IF;
      END LOOP;
       fnd_file.put_line(fnd_file.log, 'Entered RERATESHOP scenario');
      FOR rec_orders IN c_orders
      LOOP
        IF xxha_hold_attr(rec_orders.header_id) =0 AND XXHA_WMS_RS_PRECISION_VAL(rec_orders.header_id)='Y' THEN -- hold validation
          ---split line based on cursor having required validation
          FOR r_reserve_order_val IN c_reserve_order_val (rec_orders.header_id)
          LOOP
            dbms_output.put_line('Before start of XXHA_RS_ORDERLINE_SPLIT_PRC for headerId, lineId - ' || r_reserve_order_val.header_id ||','|| r_reserve_order_val.line_id);
            xxha_rs_orderline_split_prc( p_header_id => r_reserve_order_val.header_id, p_line_id => r_reserve_order_val.line_id, p_user_id => fnd_global.user_id);
            dbms_output.put_line('Completed XXHA_RS_ORDERLINE_SPLIT_PRC');
          END LOOP;
          fnd_file.put_line(fnd_file.log,'Performing rerateshop on order: '||rec_orders.order_number);
          XXHA_WM_RS_ORDER_RR(rec_orders.header_id);
          fnd_file.put_line(fnd_file.log,'Completed rerateshop on order: '||rec_orders.order_number);
          UPDATE oe_order_headers_all
          SET attribute20='SENT'
          WHERE header_id=rec_orders.header_id;
          COMMIT;
        END IF;--HOLD validation
      END LOOP;
    END IF;
    fnd_file.put_line(fnd_file.log, 'Started Ondemand concurrent program');
    --Code for Ondemand process
    IF (P_ORDER_NUMBER      IS NOT NULL AND p_sch_ship_date_from IS NOT NULL AND p_sch_ship_date_to IS NOT NULL AND p_org_name IS NOT NULL) THEN
      pl_sch_ship_date_from := FND_DATE.CANONICAL_TO_DATE (p_sch_ship_date_from);
      pl_sch_ship_date_to   := FND_DATE.CANONICAL_TO_DATE (p_sch_ship_date_to);
      l_order_cnt           := 0;
      FOR rec_reg_orders IN reg_orders(p_order_number,pl_sch_ship_date_from,pl_sch_ship_date_to,p_org_name)
      LOOP
        IF XXHA_HOLD_ATTR(rec_reg_orders.header_id)=0 AND XXHA_WMS_RS_PRECISION_VAL(rec_reg_orders.header_id)='Y' THEN -- rateshop/ hold validation
          l_order_cnt                             := 1;
          fnd_file.put_line(fnd_file.output, '*******************************************');
          fnd_file.put_line(fnd_file.output, 'Below are orders processed for Rateshop');
          fnd_file.put_line(fnd_file.output, 'Order Number: '||rec_reg_orders.order_number);
          fnd_file.put_line(fnd_file.output, 'Order Type: '||rec_reg_orders.order_type);
          fnd_file.put_line(fnd_file.output, 'Warehouse: '||rec_reg_orders.warehouse);
          fnd_file.put_line(fnd_file.log, 'Order Number: '||rec_reg_orders.order_number);
          FOR r_reserve_order_val_re IN c_reserve_order_val_re(rec_reg_orders.order_number,pl_sch_ship_date_from,pl_sch_ship_date_to,p_org_name)
          LOOP
            fnd_file.put_line(fnd_file.log,'Before start of XXHA_RS_ORDERLINE_SPLIT_PRC for headerId, lineId - ' || r_reserve_order_val_re.header_id ||','|| r_reserve_order_val_re.line_id);
            xxha_rs_orderline_split_prc( p_header_id => r_reserve_order_val_re.header_id, p_line_id => r_reserve_order_val_re.line_id, p_user_id => fnd_global.user_id);
            fnd_file.put_line(fnd_file.log,'Completed XXHA_RS_ORDERLINE_SPLIT_PRC');
          END LOOP;
          fnd_file.put_line(fnd_file.log,'before calling procedure XXHA_WM_RS_ORDER');
          XXHA_WM_RS_ORDER_RR(rec_reg_orders.header_id);
          fnd_file.put_line(fnd_file.log,'After calling procedure XXHA_WM_RS_ORDER');
        END IF; -- rateshop/ hold validation
      END LOOP;
      IF (l_order_cnt <> 1) THEN
        fnd_file.put_line(fnd_file.output, 'Order '||P_ORDER_NUMBER||' is not eligible for Rateshop');
      END IF;
    END IF;
    /*For RERATESHOP scenario*/
    IF p_rerateshop='Y' THEN
      --Added by Vijay for regular orders
      FOR rec_reg_rateshop_orders IN reg_rateshop_orders(p_org_name)
      LOOP
        IF xxha_hold_attr(rec_reg_rateshop_orders.header_id) =0 AND XXHA_WMS_RS_PRECISION_VAL(rec_reg_rateshop_orders.header_id)='Y' THEN --hold validation
          fnd_file.put_line(fnd_file.output, '*******************************************');
          fnd_file.put_line(fnd_file.output, 'Below are orders processed for Rateshop');
          fnd_file.put_line(fnd_file.output, 'Order Number: '||rec_reg_rateshop_orders.order_number);
          fnd_file.put_line(fnd_file.output, 'Order Type: '||rec_reg_rateshop_orders.order_type);
          fnd_file.put_line(fnd_file.output, 'Warehouse: '||rec_reg_rateshop_orders.warehouse);
          fnd_file.put_line(fnd_file.log, 'Order Number: '||rec_reg_rateshop_orders.order_number);
          FOR rec_rs_reserve_order_val IN c_rs_reserve_order_val(rec_reg_rateshop_orders.order_number)
          LOOP
            fnd_file.put_line(fnd_file.log,'Before start of XXHA_RS_ORDERLINE_SPLIT_PRC for headerId, lineId - ' || rec_rs_reserve_order_val.header_id ||','|| rec_rs_reserve_order_val.line_id);
            xxha_rs_orderline_split_prc( p_header_id => rec_rs_reserve_order_val.header_id, p_line_id => rec_rs_reserve_order_val.line_id, p_user_id => fnd_global.user_id);
            fnd_file.put_line(fnd_file.log,'Completed XXHA_RS_ORDERLINE_SPLIT_PRC');
          END LOOP;
          IF XXHA_WMS_RATESHOP_VALIDATION(rec_reg_rateshop_orders.header_id)='Y' THEN
            fnd_file.put_line(fnd_file.log,'before calling procedure XXHA_WM_RS_ORDER in rerateshop regular orders');
            XXHA_WM_RS_ORDER_RR(rec_reg_rateshop_orders.header_id);
            fnd_file.put_line(fnd_file.log,'After calling procedure XXHA_WM_RS_ORDER');
          ELSE
            fnd_file.put_line(fnd_file.log,'before calling procedure XXHA_WM_RS_ORDER in rerateshop regular orders');
            XXHA_WM_RS_ORDER_NEW(rec_reg_rateshop_orders.header_id);
            fnd_file.put_line(fnd_file.log,'After calling procedure XXHA_WM_RS_ORDER');
          END IF;
        END IF; -- hold validation
      END LOOP;
     
    END IF;
    /*For VOID scenario to cancel Freight/ Hanlding charges*/
    IF p_voidxmlfrehan='Y' THEN
      fnd_file.put_line(fnd_file.log, 'Entered VOID scenario to cancel Freight/ Hanlding charges');
      FOR rec_voidxmldeliveries IN c_voidxmldeliveries
      LOOP
        IF rec_voidxmldeliveries.DELIVERY_ID IS NOT NULL THEN
          fnd_file.put_line(fnd_file.log,'Performing cancel Freight/ Hanlding charges on DELIVERY: '||rec_voidxmldeliveries.DELIVERY_ID);
          XXHA_FREIGHT_HANDLING_PRC(rec_voidxmldeliveries.DELIVERY_ID, rec_voidxmldeliveries.SCENARIO);
          fnd_file.put_line(fnd_file.log,'completed cancel Freight/ Hanlding charges on DELIVERY: '||rec_voidxmldeliveries.DELIVERY_ID);
          IF rec_voidxmldeliveries.SCENARIO = 'BACKORDER' THEN
            UPDATE wsh_new_deliveries
            SET attribute10                    ='VOIDEDXML'
            WHERE DELIVERY_ID                  =rec_voidxmldeliveries.DELIVERY_ID;
          ELSIF rec_voidxmldeliveries.SCENARIO = 'SHIPMETHOD' THEN
            UPDATE WSH_DELIVERY_DETAILS
            SET ATTRIBUTE10           = 'VOIDEDXML'
            WHERE DELIVERY_DETAIL_ID IN
              (SELECT DA.DELIVERY_DETAIL_ID
              FROM WSH_DELIVERY_ASSIGNMENTS DA
              WHERE DA.DELIVERY_ID = rec_voidxmldeliveries.DELIVERY_ID
              );
          END IF;
          COMMIT;
        END IF;
      END LOOP;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log, 'Error Occured:'||SQLERRM);
  END RS_OM_INSERT;
END XXHA_RATESHOP_ONDEMAND_PKG;
/