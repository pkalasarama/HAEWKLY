CREATE OR REPLACE PACKAGE
   XXHA_INV_OHB_CONV_PK
-- +===================================================================+
-- |                       Oracle NAIO (India)                         |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- | Name             :  XXHA_INV_OHB_CONV_PK                          |
-- | Description      :  Package Specification consisting of a         |
-- |                     Validation Procedure and a Move procedure     |
-- |                     to move the data from the Legacy System to    |
-- |                     Oracle Inventory base Tables                  |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  16-10-2006  Narendra.S        Initial draft version      |
-- |1.0       31-10-2006  Narendra.S        After Review               |
-- |                                                                   |
-- +===================================================================+
AS
-------------------------------------------------------------------------
--The Global Variables
-------------------------------------------------------------------------
      gc_attribute1               xxha_common_errors.attribute1%TYPE;                                             --Attribute1 insert in common error table
      gc_attribute2               xxha_common_errors.attribute2%TYPE;                                             --Attribute2 insert in common error table
      gc_attribute3               xxha_common_errors.attribute3%TYPE;                                             --Attribute3 insert in common error table
      gc_attribute4               xxha_common_errors.attribute4%TYPE;                                             --Attribute4 insert in common error table
      gc_attribute5               xxha_common_errors.attribute5%TYPE;                                             --Attribute5 insert in common error table
      gc_conc_name                fnd_concurrent_programs.concurrent_program_name%TYPE:='XXHA_INV_OHB_CONV';      --Cocurrent program name to delete the records from common error table
      gc_comments                 xxha_common_errors.comments%TYPE;                                               --Comments   insert in common error table
      gc_error_code               xxha_common_errors.error_code%TYPE;                                             --Error_code insert in common error table
      gc_error_msg                xxha_common_errors.error_msg%TYPE;                                              --Error_msg  insert in common error table
      gc_log_message              VARCHAR2(2000);                                                                 --Variable to hold Log Messages
      gc_record_identifier        xxha_common_errors.record_identifier%TYPE;                                      --Record identifier of staging table
      gc_status                   VARCHAR2(2);                                                                    --Variable to get the Status of the Error Table insertion procedure
      gc_table_name               xxha_common_errors.table_name%TYPE:='USBPCS_ONHAND_CLEANED';                    --Variable to get Staging Table Name
      gn_login_id                 fnd_logins.login_id%type := FND_GLOBAL.LOGIN_ID;                                --Login name for running conversion program
      gn_request_id               fnd_concurrent_requests.request_id%TYPE := FND_GLOBAL.CONC_REQUEST_ID;          --Request Id of running concurrent Program
      gn_record_number            xxha_common_errors.record_number%TYPE;                                          --Record_number of staging table
      gn_user_id                  fnd_user.user_id%TYPE := FND_GLOBAL.USER_ID;                                    --User name for running conversion program
      gn_sob_id                   gl_sets_of_books.set_of_books_id%TYPE := FND_PROFILE.VALUE('GL_SET_OF_BKS_ID'); --variable to hold the Set Of Books Id
      gn_chart_of_accounts_id     gl_sets_of_books.chart_of_accounts_id%TYPE;                                     --variable to hold the Chart Of Accounts Id
      gn_ccid                     gl_code_combinations.code_combination_id%TYPE;                                  --variable to hold the Inventory Distribution Code combination Id
      gn_trans_type_id            mtl_transaction_types.transaction_type_id%TYPE;                                 --variable to hold the Transaction Type Id
      gc_default_segment6         gl_code_combinations.segment6%TYPE := '131350';                                 --variable to hold the Distribution Code Combination's Segment6 default value
      gd_transaction_date         mtl_material_transactions.transaction_date%TYPE := SYSDATE;                     --variable to hold the Transaction Date




      --Procedure to validate and process OnHand Balances records
      PROCEDURE VALIDATE_INV_OHB_DATA(
                                      x_err_buf    OUT VARCHAR2
                                     ,x_ret_code   OUT VARCHAR2
                                     ,p_debug_flag IN  VARCHAR2
                                     ,p_purge_flag IN  VARCHAR2
                                     ,p_trans_date IN  VARCHAR2
                                     );

      --Procedure to insert the records into the Interface Table
      PROCEDURE MOVE_INV_OHB_DATA(
                                  p_debug_flag IN  VARCHAR2
                                 ,x_ret_code   OUT VARCHAR2
                                 );


END XXHA_INV_OHB_CONV_PK;    --End of the XXHA_INV_OHB_CONV_PK Specification

/


CREATE OR REPLACE PACKAGE BODY
   XXHA_INV_OHB_CONV_PK
-- +===================================================================+
-- |                       Oracle NAIO (India)                         |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- | Name             :  XXHA_INV_OHB_CONV_PK                          |
-- | Description      :  Package Body consisting of a Validation       |
-- |                     Procedure and a Move procedure                |
-- |                     to move the data from the Legacy System to    |
-- |                     Oracle Inventory base Tables                  |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  16-10-2006  Narendra.S       Initial draft version       |
-- |1.0       31-10-2006  Narendra.S       After Review                |
-- |1.1       13-11-2006  Narendra.S       Replaced the LIKE operator  |
-- |                                       with '='in Subinventory     |
-- |                                       and Code Combination        |
-- |                                       Validation Blocks           |
-- |                                       Commented out the insertion |
-- |                                       of Attribute1 in table      |
-- |                                       MTL_TRANSACTIONS_INTERFACE  |
-- |1.2       14-12-2006  Narendra.S       Added Validations for       |
-- |                                       ExpirationDate and          |
-- |                                       OracleTemplateId columns    |
-- |1.3       18-02-2007 subbu             Modfied error message
-- |1.4       24-Feb-2007subbu	           Added TRUNC function for
-- |                                       Transaction Date
-- |1.5       07-Mar-2007 subbu            Added parameter for Transaction date
-- |                                       and logic in setup, to check for
-- |                                       all org in open period .
-- |                                       Removed TRIM function for the Lot Number
-- |                                       Added Logic to fail records if Quantity is Negative.
-- |                                       Added logic to check if Item is Revision Controlled
-- |1.6      20-Apr-2007 subbu             Added logic to check whether the subinv is locator
-- |                                       controlled and to check the cmbinition (locator1-3)
-- |                                       in oracle table
-- +===================================================================+
AS


-- +==============================================================================+
-- | PROCEDURE: INSERT_ERROR                                                      |
-- |                                                                              |
-- | DESCRIPTION: The Local Procedure which inserts the errors into the           |
-- |              error table                                                     |
-- |                                                                              |
-- | Call From  : VALIDATE_INV_OHB_DATA,MOVE_INV_OHB_DATA and VALIDATE_SETUP      |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: None                                                                   |
-- |  OUT: None                                                                   |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PRIVATE                                                               |
-- |                                                                              |
-- | HISTORY:                                                                     |
-- |  WHO            WHAT                                              WHEN       |
-- |  -------------- ------------------------------------------------- -----------|
-- |  Narendra.S     Initial Version.                                  16-10-2006 |
-- |  Narendra.S     After Review                                      31-10-2006 |
-- +==============================================================================+
PROCEDURE INSERT_ERROR
IS
   BEGIN
      XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(
                                                 gn_request_id
                                                ,gn_record_number
                                                ,gc_record_identifier
                                                ,gc_error_code
                                                ,gc_error_msg
                                                ,gc_comments
                                                ,gc_table_name
                                                ,gc_attribute1
                                                ,gc_attribute2
                                                ,gc_attribute3
                                                ,gc_attribute4
                                                ,gc_attribute5
                                                ,gc_status
                                                );
   EXCEPTION
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in the local procedure insert_error. Error is: ' ||SQLERRM);
   END INSERT_ERROR;     --End of the INSERT_ERROR procedure


-- +==============================================================================+
-- | PROCEDURE: UPDATE_PROCESSING_STATUS                                          |
-- |                                                                              |
-- | DESCRIPTION: The Local Procedure which updates the Staging table             |
-- |              processing status whenever there is an error                    |
-- |                                                                              |
-- | Call From  : MOVE_INV_OHB_DATA                                               |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_rec_num                                                              |
-- |       p_rec_status                                                           |
-- |  OUT:                                                                        |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PRIVATE                                                               |
-- |                                                                              |
-- | HISTORY:                                                                     |
-- |  WHO            WHAT                                              WHEN       |
-- |  -------------- ------------------------------------------------- -----------|
-- |  Narendra.S     Initial Version.                                  16-10-2006 |
-- |  Narendra.S     After Review                                      31-10-2006 |
-- +==============================================================================+
PROCEDURE UPDATE_PROCESSING_STATUS(
                                   p_recnum     NUMBER
                                  ,p_rec_status VARCHAR2
                                  )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN

    IF ( p_rec_status = 'PE' ) THEN
       UPDATE usbpcs_onhand_cleaned UOC
       SET    UOC.oraclecharfld1='PE'
       WHERE  UOC.oracleidentifier=p_recnum;
    END IF;

    COMMIT;
   EXCEPTION
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in the local procedure UPDATE_PROCESSING_STATUS  Error is: ' ||SQLERRM);
   END UPDATE_PROCESSING_STATUS; --End of the UPDATE_PROCESSING_STATUS procedure

-- +==============================================================================+
-- | PROCEDURE: VALIDATE_SETUP                                                    |
-- |                                                                              |
-- | DESCRIPTION: The Local Procedure which validates the Applications Setup      |
-- |                                                                              |
-- | Call From  : VALIDATE_INV_OHB_DATA                                           |
-- |                                                                              |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_debug_flag                                                           |
-- |  OUT: p_derivation_status                                                    |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PRIVATE                                                               |
-- |                                                                              |
-- | HISTORY:                                                                     |
-- |  WHO            WHAT                                              WHEN       |
-- |  -------------- ------------------------------------------------- -----------|
-- |  Narendra.S     Initial Version.                                  20-10-2006 |
-- |  Narendra.S     After Review                                      31-10-2006 |
-- +==============================================================================+

PROCEDURE VALIDATE_SETUP(
                         p_debug_flag        IN  VARCHAR2
                        ,p_derivation_status OUT VARCHAR2
                        )
IS
   --Start of changes V1.5
   CURSOR lcu_chk_org_open_period IS
   SELECT DISTINCT inventoryorg
   FROM usbpcs_onhand_cleaned;
   --End of changes V1.5
   lc_inv_cal_open_flag            org_acct_periods.open_flag%TYPE;                                        --variable to hold the Inventory Calendar Open Status

   BEGIN
       XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'Start Of Derivations');
       XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');

       -------------------------------------------------------------------------
       --Deriving the Transaction Type Id
       -------------------------------------------------------------------------
       p_derivation_status:='P';
       BEGIN
          SELECT MTP.transaction_type_id
          INTO   gn_trans_type_id
          FROM   mtl_transaction_types MTP
          WHERE  MTP.transaction_type_name = 'Miscellaneous receipt';

          gc_log_message := 'The derivation of Transaction Type Miscellaneous receipt is successful';
          XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
       EXCEPTION
          WHEN NO_DATA_FOUND THEN
              gc_error_code := 'SETUP-Error';
              gc_error_msg  := 'The Transaction Type Miscellaneous receipt has not been defined';
              gc_comments   := 'Please Define the Transaction Type Miscellaneous receipt';
              INSERT_ERROR;
              p_derivation_status:='F';
              gc_log_message:='SETUP-Error - The Transaction Type Miscellaneous receipt has not been defined';
              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
          WHEN OTHERS THEN
              gc_error_code := SQLCODE;
              gc_error_msg  := SQLERRM;
              gc_comments   := 'Please Define the Transaction Type Miscellaneous receipt';
              INSERT_ERROR;
              p_derivation_status:='F';
              gc_log_message:= SQLERRM;
              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
       END; -- end of deriving the transaction type Id

       -------------------------------------------------------------------------
       --Deriving the Chart Of Accounts Id
       -------------------------------------------------------------------------
       BEGIN
           SELECT GSOB.chart_of_accounts_id
           INTO   gn_chart_of_accounts_id
           FROM   gl_sets_of_books GSOB
           WHERE  GSOB.set_of_books_id = gn_sob_id;

           gc_log_message := 'The derivation of Chart Of Accounts Id is successful';
           XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
       EXCEPTION
          WHEN NO_DATA_FOUND THEN
               gc_error_code := 'SETUP-Error';
               gc_error_msg  := 'Unable to derive the Chart Of Accounts Id';
               gc_comments   := 'Please check the Set Of Books associated with the responsibility';
               INSERT_ERROR;
               p_derivation_status:='F';
               gc_log_message:='SETUP-Error - Unable to derive the Chart Of Accounts Id';
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
         WHEN OTHERS THEN
              gc_error_code := SQLCODE;
              gc_error_msg  := SQLERRM;
              gc_comments   := 'Please check the Set Of Books associated with the responsibility';
              INSERT_ERROR;
              p_derivation_status:='F';
              gc_log_message:= SQLERRM;
              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
       END; -- end of Deriving the Chart Of Accounts Id

       XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
       XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'End Of Derivations');


       --Start of Changes V1.5
       FOR lcu_org_open_period_rec IN lcu_chk_org_open_period
       LOOP
          -------------------------------------------------------------------------
	  --Deriving the Closing Status of the Transaction Date
	  -------------------------------------------------------------------------
	  BEGIN
	     SELECT OAP.open_flag
	     INTO   lc_inv_cal_open_flag
	     FROM   org_acct_periods OAP
	           ,mtl_parameters MP
	     WHERE  OAP.organization_id = MP.organization_id
	     AND    MP.organization_code=lcu_org_open_period_rec.inventoryorg
	     --Start of changes 1.4
	     AND    TRUNC(gd_transaction_date) BETWEEN trunc(OAP.period_start_date) AND trunc(OAP.schedule_close_date)
	     --End of changes 1.4
	     AND    OAP.open_flag NOT IN ('N','P')
	     AND    OAP.period_close_date IS NULL;
	  EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	      gc_error_code := 'SETUP-Error';
	      gc_error_msg  := 'The Transaction date '||gd_transaction_date||' does not fall in an open Inventory Period for the Organization '||lcu_org_open_period_rec.inventoryorg;
	      gc_comments   := 'Please Open the Inventory Period to which the Transaction Date belongs';
	      INSERT_ERROR;
	      p_derivation_status:='F';
	      gc_log_message       := 'The Transaction date '||gd_transaction_date||' does not fall in an open Inventory Period for the Organization '||lcu_org_open_period_rec.inventoryorg;
	      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
	  WHEN OTHERS THEN
	      gc_error_code       := SQLCODE;
	      gc_error_msg        := SQLERRM;
	      INSERT_ERROR;
	      p_derivation_status:='F';
	      gc_log_message       := SQLERRM;
	      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;
       END LOOP;
       --End of Changes V1.5


EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in the local procedure VALIDATE_SETUP. Error is: ' ||SQLERRM);
END VALIDATE_SETUP;     --End of VALIDATE_SETUP Procedure


-- +==============================================================================+
-- | PROCEDURE: VALIDATE_INV_OHB_DATA                                             |
-- |                                                                              |
-- | DESCRIPTION: Procedure to perform validations on staging table               |
-- |                                                                              |
-- |                                                                              |
-- | Call From  : From the Custom Concurrent Program                              |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_debug_flag                                                           |
-- |       p_purge_flag                                                           |
-- |  OUT: x_err_buf                                                              |
-- |       x_ret_code                                                             |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PUBLIC                                                                |
-- |                                                                              |
-- | HISTORY:                                                                     |
-- |  WHO            WHAT                                              WHEN       |
-- |  -------------- ------------------------------------------------- -----------|
-- |  Narendra.S     Initial Version.                                  16-10-2006 |
-- |  Narendra.S     After Review                                      31-10-2006 |
-- |  Narendra.S     Changes made as per onsite comments               13-11-2006 |
-- |                 the changes are replacing the LIKE operator                  |
-- |                 with '=' in Subinventory  and CodeCombination                |
-- |                 Validation Blocks                                            |
-- |                                                                              |
-- |                                                                              |
-- +==============================================================================+
PROCEDURE VALIDATE_INV_OHB_DATA(
                                x_err_buf    OUT VARCHAR2
                               ,x_ret_code   OUT VARCHAR2
                               ,p_debug_flag IN  VARCHAR2
                               ,p_purge_flag IN  VARCHAR2
                               ,p_trans_date IN  VARCHAR2
                               )
IS
      --The Local Variables
      ln_inv_org_id                   mtl_parameters.organization_id%TYPE;                                    --variable to hold the Inventory Organization Id
      ln_inv_item_id                  mtl_system_items_b.inventory_item_id%TYPE;                              --variable to hold the Inventory Item Id
      lc_sub_inventory                mtl_secondary_inventories.secondary_inventory_name%TYPE;                --variable to hold the Subinventory Code
      lc_inv_cal_open_flag            org_acct_periods.open_flag%TYPE;                                        --variable to hold the Inventory Calendar Open Status
      lc_uom_code                     mtl_system_items_b.primary_uom_code%TYPE;                               --variable to hold the Item's Unit Of Measure
      lc_revision_num                 mtl_item_revisions.revision%TYPE;                                       --variable to hold the Item's Revision
      lc_segment1                     gl_code_combinations.segment1%TYPE;                                     --variable to hold the Distribution Code Combination's Segment1
      lc_segment2                     gl_code_combinations.segment2%TYPE;                                     --variable to hold the Distribution Code Combination's Segment2
      lc_segment3                     gl_code_combinations.segment3%TYPE;                                     --variable to hold the Distribution Code Combination's Segment3
      lc_segment4                     gl_code_combinations.segment4%TYPE;                                     --variable to hold the Distribution Code Combination's Segment4
      lc_segment5                     gl_code_combinations.segment5%TYPE;                                     --variable to hold the Distribution Code Combination's Segment5
      lc_segment6                     gl_code_combinations.segment6%TYPE;                                     --variable to hold the Distribution Code Combination's Segment6
      lc_segment7                     gl_code_combinations.segment7%TYPE;                                     --variable to hold the Distribution Code Combination's Segment7
      lc_segment8                     gl_code_combinations.segment8%TYPE;                                     --variable to hold the Distribution Code Combination's Segment8
      lc_segment9                     gl_code_combinations.segment9%TYPE;                                     --variable to hold the Distribution Code Combination's Segment9
      lc_concat_segments              VARCHAR2(1000);                                                         --variable to hold the Inventory Distribution Code combination
      ln_lot_control_code             mtl_system_items_b.lot_control_code%TYPE;                               --variable to hold the Item's Lot Control Code
      ln_serial_number_control_code   mtl_system_items_b.serial_number_control_code%TYPE;                     --variable to hold the Item's Serial Number Control Code
      lc_validation_status            VARCHAR2(3);                                                            --variable to hold the Validation Status
      lc_derivation_status            VARCHAR2(3);                                                            --variable to hold the Derivation Status
      ln_total_rec                    NUMBER;                                                                 --variable to hold the Total No. Of Records in the Staging Table
      ln_valid_rec                    NUMBER;                                                                 --variable to hold the Total No. Of Valid Records in the Staging Table
      ln_invalid_rec                  NUMBER;                                                                 --variable to hold the Total No. Of Invalid Records in the Staging Table
      lc_org_exist                    VARCHAR2(1);                                                            --variable to hold the Organization exist flag
      lc_item_exist                   VARCHAR2(1);                                                            --variable to hold the Item exist flag
      lc_subinv_exist                 VARCHAR2(1);                                                            --variable to hold the SubInventory exist flag
      lc_debug_flag                   VARCHAR2(1);                                                            --variable to hold the debug flag
      ln_revision_qty_control_code    NUMBER;
      lc_loc_type                     mtl_secondary_inventories.LOCATOR_TYPE%TYPE;
      lc_locator_exist                VARCHAR2(10);

      --The Cursor on the Staging Table
      CURSOR lcu_ohb
      IS
      SELECT *
      FROM   usbpcs_onhand_cleaned
      WHERE  oraclecharfld1 IS NULL;

   BEGIN

      --Resetting the stating table to intial status
      gc_log_message := 'Resetting the staging table to intial status';
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

      UPDATE usbpcs_onhand_cleaned UOC
      SET  UOC.itemnumber       = TRIM(UOC.itemnumber)
          --Start  of Changes V1.5
          ,UOC.lotnumber        = UOC.lotnumber
          --End  of Changes V1.5
          ,UOC.onhand           = TRIM(UOC.onhand)
          ,UOC.subinventory     = TRIM(UOC.subinventory)
          ,UOC.locator1         = TRIM(UOC.locator1)
          ,UOC.inventoryorg     = TRIM(UOC.inventoryorg)
          ,UOC.expirationdate   = TRIM(UOC.expirationdate)
          ,UOC.revisionnbr      = TRIM(UOC.revisionnbr)
          ,UOC.oracletemplateid = TRIM(UOC.oracletemplateid)
          ,UOC.oracleidentifier = TRIM(UOC.oracleidentifier)
          ,UOC.oraclecharfld1   = NULL
          ,UOC.oraclecharfld2   = NULL
          ,UOC.oracleintfld1    = NULL
          ,UOC.oracleintfld2    = NULL
          ,UOC.oracleintfld3    = NULL
          ,UOC.oracleintfld4    = NULL
          ,UOC.oracleintfld8    = NULL;

      --Purging the Error Table Data
      gc_log_message := 'Purging the Error Table data';
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

       IF ( p_purge_flag = 'Y' ) THEN
         XXHA_COMMON_UTILITIES_PKG.DELETE_ERROR_PRC(gc_conc_name);
       END IF;

       COMMIT;

      gc_log_message := 'Calling the VALIDATE_SETUP Procedure';
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
      lc_debug_flag := p_debug_flag;


      --State of Changes V1.5
           gd_transaction_date:=to_char(to_date(p_trans_date, 'YYYY/MM/DD HH24:MI:SS'), 'DD-MON-RRRR');
      --State of Changes V1.5




      --Calling the VALIDATE_SETUP Procedure
      VALIDATE_SETUP(lc_debug_flag,lc_derivation_status);


   -------------------------------------------------------------------------
   --The Validations on the Staging Table
   -------------------------------------------------------------------------
   gc_log_message := 'If validation of SetUp fails then the conversion program ends with warning else it is going to perform validations';
   XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);


   IF ( lc_derivation_status = 'F' ) THEN
         x_ret_code:=2;              --Setting the Concurrent Programme status to Completed with Error
         XXHA_COMMON_UTILITIES_PKG.LAUNCH_ERROR_REPORT_PRC(gn_request_id,'On-Hand Bal Conversion','Item Number');
   ELSE

   BEGIN




      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'                                                           ');
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'Start Of Validations On Staging Table USBPCS_ONHAND_CLEANED');
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');

      gc_log_message := 'Starting.....validations for Inventory Organization,Item,SubInventory,Closing Status of the Transaction Date,Revision,Code Combination and Lot Number';
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);


        FOR lr_ohb IN lcu_ohb
        LOOP

        gc_log_message := 'Starting..... validations for the record '||lr_ohb.oracleidentifier;
        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

           -------------------------------------------------------------------------
           --Validating the Invetory Organization
           -------------------------------------------------------------------------
           lc_validation_status:='VS';
           gn_record_number    := lr_ohb.oracleidentifier;
           gc_record_identifier:= lr_ohb.itemnumber;

           BEGIN
              SELECT MP.organization_id
              INTO   ln_inv_org_id
              FROM   mtl_parameters MP
              WHERE  MP.organization_code = lr_ohb.inventoryorg;
              lc_org_exist:='Y';
           EXCEPTION
           WHEN NO_DATA_FOUND THEN
               gc_error_code := 'OHB01';
               gc_error_msg  := 'Invalid Organization '||lr_ohb.inventoryorg||' for the Item Number: '||lr_ohb.itemnumber;
               gc_comments   := 'Please check the Organization';
               INSERT_ERROR;
               lc_validation_status:= 'VE';
               lc_org_exist        := 'N';
               gc_log_message      := 'OHB01-Unable to derive the Organization Id for the Organization '||lr_ohb.inventoryorg;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status:= 'VE';
               lc_org_exist        := 'N';
               gc_log_message:= SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;

      IF ( lc_org_exist = 'Y' ) THEN

           -------------------------------------------------------------------------
           --Validating the Invetory Item
           -------------------------------------------------------------------------
           ln_revision_qty_control_code :=NULL;
           BEGIN
              SELECT MSIB.inventory_item_id
                    ,MSIB.primary_uom_code
                    ,MSIB.lot_control_code
                    ,MSIB.serial_number_control_code
                     --Start of Changes V1.5
                    ,MSIB.revision_qty_control_code
                     -- End of Changes V1.5
              INTO   ln_inv_item_id
                    ,lc_uom_code
                    ,ln_lot_control_code
                    ,ln_serial_number_control_code
                    ,ln_revision_qty_control_code
              FROM   mtl_system_items_b MSIB
              WHERE  MSIB.segment1 = lr_ohb.itemnumber
              AND    MSIB.organization_id = ln_inv_org_id;
              lc_item_exist:='Y';
           EXCEPTION
           WHEN NO_DATA_FOUND THEN
               gc_error_code := 'OHB02';
               gc_error_msg  := 'Invalid Item '||lr_ohb.itemnumber||' in the given Organization '||lr_ohb.inventoryorg;
               gc_comments   := 'Please define the Item in the corresponding Organization';
               INSERT_ERROR;
               lc_validation_status := 'VE';
               lc_item_exist        := 'N';
               gc_log_message       := 'OHB02-Unable to derive the Inventory Item Id for the Item '||lr_ohb.itemnumber||' in the given Organization '||lr_ohb.inventoryorg;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status:= 'VE';
               lc_item_exist       := 'N';
               gc_log_message      := SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;

            --Start of Changes V1.5
            --Check if the Item is Revision Controlled
            IF  ln_revision_qty_control_code <> 2 AND lr_ohb.revisionnbr  IS NOT NULL THEN
                gc_error_code := 'OHB02-1';
                gc_error_msg  := 'Item: '||lr_ohb.itemnumber||' is not under revision Control for Organization: '||lr_ohb.inventoryorg;
                gc_comments   := NULL;
                INSERT_ERROR;
                lc_validation_status := 'VE';
                lc_item_exist        := 'N';
            END IF;

            --Check if Onhand Quantity is Negative In staging table
            -------------------------------------------------------
            IF NVL(lr_ohb.onhand ,-1)<0 THEN
               gc_error_code := 'OHB02-2';
	       gc_error_msg  := 'Onhand quantity is either NULL or Negative in the staging table for the item : '||lr_ohb.itemnumber;
	       gc_comments   := NULL;
	       INSERT_ERROR;
	       lc_validation_status := 'VE';
           END IF;
            --End  of Changes V1.5


            -- Start of changes V1.1
           -------------------------------------------------------------------------
           --Validating the Subinventory Code
           -------------------------------------------------------------------------
           lc_loc_type :=NULL;
           BEGIN
              SELECT MSI.secondary_inventory_name,MSI.locator_type
              INTO   lc_sub_inventory,lc_loc_type
              FROM   mtl_secondary_inventories MSI
              WHERE  MSI.organization_id=ln_inv_org_id
              AND    MSI.secondary_inventory_name = lr_ohb.subinventory;
              lc_subinv_exist:='Y';
           EXCEPTION
           WHEN NO_DATA_FOUND THEN
               gc_error_code := 'OHB03';
               --gc_error_msg  := 'Item: '||lr_ohb.itemnumber||' has Invalid SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg;
               gc_error_msg  := 'No record found for the SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg||' for Item: '||lr_ohb.itemnumber ;
               gc_comments   := 'Please define the Subinventory in the Inventory Organization';
               INSERT_ERROR;
               lc_validation_status:= 'VE';
               lc_subinv_exist     := 'N';
               gc_log_message      := 'OHB03-Invalid SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status:= 'VE';
               lc_subinv_exist     := 'N';
               gc_log_message      := SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

           END;

           --Start of Changes V1.6
           -------------------------------------------------------------------
           --Chek if the subinventory is locator controlled or not.
           --Validate whether the combinetion(segment1,segment2,segment3) exist
           --if its a locaor controlled
           -------------------------------------------------------------------
           IF lc_loc_type=2 THEN --2 indicated locator controlled
             IF lr_ohb.locator1 IS NULL AND  lr_ohb.locator2 IS NULL AND lr_ohb.locator3 IS NULL THEN
                gc_error_code := 'OHB03-1';
                gc_error_msg        := 'Locator1-3 are holding NULL value for the locator controlled SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg;
		INSERT_ERROR;
		lc_validation_status:= 'VE';
		lc_subinv_exist     := 'N';
		gc_log_message      := 'Locator1-3 are holding NULL value for the locator controlled SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg;
                XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
             ELSE
                -- Validate whether the combinetion(segment1,segment2,segment3) exist
                --------------------------------------------------------------------
                BEGIN
	            SELECT 'Y'
	             INTO   lc_locator_exist
	             FROM   mtl_item_locations MIL
	             WHERE  subinventory_code    = lr_ohb.subinventory
	             AND    organization_id      =ln_inv_org_id
	             AND    NVL(MIL.segment1,'#') = NVL(lr_ohb.locator1,'#')
	             AND    NVL(MIL.segment2,0) = NVL(lr_ohb.locator2,0)
	             AND    NVL(MIL.segment3,0) = NVL(lr_ohb.locator3,0);
	        EXCEPTION
	           WHEN NO_DATA_FOUND THEN
	                gc_error_code := 'OHB03-2';
	                gc_error_msg  := 'No record found for the Locator1-3 combinition for  the SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg;
	                gc_comments   := NULL;
	                INSERT_ERROR;
	                lc_validation_status:= 'VE';
	                lc_subinv_exist     := 'N';
	                gc_log_message      := 'No record found for the Locator1-3 combinition for  the SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg;
	                XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
	           WHEN OTHERS THEN
	                gc_error_code       := 'OHB03-3'||' - '||SQLCODE;
	                gc_error_msg        := SQLERRM;
	                INSERT_ERROR;
	                lc_validation_status:= 'VE';
	                lc_subinv_exist     := 'N';
	                gc_log_message      := SQLERRM;
	                XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                END;
              END IF; --  lr_ohb.locator1 IS NULL AND  lr_ohb.locator2 IS NULL AND lr_ohb.locator3 IS NULL THEN
           ELSIF lc_loc_type NOT IN (1,2) THEN
              gc_error_code := 'OHB03-4';
              gc_error_msg  := 'The Locator Control code for SubInventory '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg||' is neither NONE nor PRESPECIFIED';
              gc_comments   := NULL;
              INSERT_ERROR;
              lc_validation_status:= 'VE';
              lc_subinv_exist     := 'N';
              gc_log_message      := 'No record found for the Locator1-3 combinition for  the SubInventory Code '||lr_ohb.subinventory||' for the Organization '||lr_ohb.inventoryorg;
              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

           END IF;
           --End of Changes V1.6



           -- End of changes V1.1
           -------------------------------------------------------------------------
           --Deriving the Closing Status of the Transaction Date
           -------------------------------------------------------------------------
         --State of Changes V1.5
         /*
          BEGIN
              SELECT OAP.open_flag
              INTO   lc_inv_cal_open_flag
              FROM   org_acct_periods OAP
              WHERE  OAP.organization_id = ln_inv_org_id
              --Start of changes 1.4
              AND    TRUNC(gd_transaction_date) BETWEEN trunc(OAP.period_start_date) AND trunc(OAP.schedule_close_date)
              --End of changes 1.4
              AND    OAP.open_flag NOT IN ('N','P')
              AND    OAP.period_close_date IS NULL;
           EXCEPTION
           WHEN NO_DATA_FOUND THEN
               gc_error_code := 'OHB04';
               gc_error_msg  := 'The Transaction date '||gd_transaction_date||' does not fall in an open Inventory Period for the Organization '||lr_ohb.inventoryorg||' for Item: '||lr_ohb.itemnumber;
               gc_comments   := 'Please Open the Inventory Period to which the Transaction Date belongs';
               INSERT_ERROR;
               lc_validation_status := 'VE';
               gc_log_message       := 'OHB04-The Transaction date '||gd_transaction_date||' does not fall in an open Inventory Period for the Organization '||lr_ohb.inventoryorg;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status := 'VE';
               gc_log_message       := SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;
           */
           --End of Changes V1.5
      END IF;

      -------------------------------------------------------------------------
      --Validating the Item Revision
      -------------------------------------------------------------------------
      IF  (lc_org_exist = 'Y' AND lc_item_exist = 'Y') THEN
           BEGIN
              SELECT MIRB.revision
              INTO   lc_revision_num
              FROM   mtl_item_revisions_b MIRB
              WHERE  MIRB.inventory_item_id= ln_inv_item_id
              AND    MIRB.organization_id  = ln_inv_org_id
              AND    MIRB.revision         = lr_ohb.revisionnbr
              --Start of changes V1.5
              --AND    gd_transaction_date BETWEEN MIRB.effectivity_date AND sysdate;
              AND    trunc(gd_transaction_date) BETWEEN trunc(MIRB.effectivity_date) AND trunc(gd_transaction_date);
              --End of changes V1.5
           EXCEPTION
           WHEN NO_DATA_FOUND THEN
               gc_error_code := 'OHB05';
               gc_error_msg  := 'The given Revision '||lr_ohb.revisionnbr||' is either invalid or falls before the Effective Date for the Organization '||lr_ohb.inventoryorg||' for Item: '||lr_ohb.itemnumber ;
               gc_comments   := 'Please provide a valid Item Revision';
               INSERT_ERROR;
               lc_validation_status := 'VE';
               gc_log_message       := 'OHB05-The given Revision '||lr_ohb.revisionnbr||' is either invalid or fall before the Effective Date';
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status := 'VE';
               gc_log_message       := SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;
      END IF;



      IF  (lc_org_exist = 'Y' AND lc_subinv_exist = 'Y') THEN
      -------------------------------------------------------------------------
      --Deriving the Distribution Account Code Combination
      -------------------------------------------------------------------------
           -- Start of changes V1.1
           BEGIN
              SELECT  GCC.segment1
                     ,GCC.segment2
                     ,GCC.segment3
                     ,GCC.segment4
                     ,GCC.segment5
                     ,GCC.segment6
                     ,GCC.segment7
                     ,GCC.segment8
                     ,GCC.segment9
              INTO    lc_segment1
                     ,lc_segment2
                     ,lc_segment3
                     ,lc_segment4
                     ,lc_segment5
                     ,lc_segment6
                     ,lc_segment7
                     ,lc_segment8
                     ,lc_segment9
              FROM   gl_sets_of_books GSOB
                    ,mtl_secondary_inventories MSI
                    ,gl_code_combinations GCC
              WHERE  MSI.organization_id=ln_inv_org_id
              AND    MSI.secondary_inventory_name = lc_sub_inventory
              AND    MSI.material_account=GCC.code_combination_id
              AND    GSOB.set_of_books_id=gn_sob_id
              AND    GSOB.chart_of_accounts_id=GCC.chart_of_accounts_id
              AND    GCC.enabled_flag = 'Y';

             -- End of changes V1.1

              lc_segment6 := gc_default_segment6;         --Resetting the segment6 to 131350

              lc_concat_segments := lc_segment1||'.'||lc_segment2||'.'||lc_segment3||'.'||lc_segment4||'.'||
                                    lc_segment5||'.'||lc_segment6||'.'||lc_segment7||'.'||lc_segment8||'.'||
                                    lc_segment9;

              gn_ccid := FND_FLEX_EXT.GET_CCID(
                                                'SQLGL'
                                               ,'GL#'
                                               ,gn_chart_of_accounts_id
                                               ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
                                               ,lc_concat_segments
                                              );
              IF gn_ccid = 0 THEN
                  gc_error_code := 'OHB06';
                  gc_error_msg  := 'Invalid Distribution Code Combination '||lc_concat_segments;
                  gc_comments   := 'Please check the Material Account in the Subinventory '||lr_ohb.subinventory||' for the Inventory Organization '||lr_ohb.inventoryorg;
                  INSERT_ERROR;
                  lc_validation_status := 'VE';
                  gc_log_message       := 'OHB06-Invalid Distribution Code Combination '||lc_concat_segments;
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
              END IF;

           EXCEPTION
           WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status := 'VE';
               gc_log_message       := SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;
      END IF;  --End of derivation of Distribution Account Code Combination

      -- Start of changes V1.2
      IF ( lc_item_exist = 'Y' ) THEN

           -------------------------------------------------------------------------
           --Validating the Lot Number and ExpirationDate
           -------------------------------------------------------------------------
           BEGIN
            IF ( ln_lot_control_code = 2 OR ln_serial_number_control_code = 5 ) THEN
              IF ( lr_ohb.lotnumber IS NULL ) THEN
                    gc_error_code := 'OHB07';
                    gc_error_msg  := 'The LotNumber column is Null for the item '||lr_ohb.itemnumber||' which is either Lot Controlled or Serial Controlled';
                    gc_comments   := 'Please provide the Lot Number';
                    INSERT_ERROR;
                    lc_validation_status := 'VE';
                    gc_log_message       := 'OHB07-The LotNumber column is Null for the item '||lr_ohb.itemnumber||' which is either Lot Controlled or Serial Controlled';
                    XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
              ELSIF ( ln_lot_control_code = 2 AND lr_ohb.lotnumber IS NOT NULL ) THEN
                   IF ( lr_ohb.expirationdate IS NULL ) THEN
                        gc_error_code := 'OHB08';
                        gc_error_msg  := 'The ExpirationDate column is Null for the Lot Controlled item '||lr_ohb.itemnumber;
                        gc_comments   := 'Please provide the Expiration Date';
                        INSERT_ERROR;
                        lc_validation_status := 'VE';
                        gc_log_message       := 'OHB08-The ExpirationDate column is Null for the Lot Controlled item '||lr_ohb.itemnumber;
                        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                   END IF;
              END IF;
            END IF;
           EXCEPTION
           WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status := 'VE';
               gc_log_message       := SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;

           -------------------------------------------------------------------------
           --Validating the OracleTemplateId
           -------------------------------------------------------------------------
           BEGIN
               IF ( ln_lot_control_code = 2 ) THEN
                   IF ( lr_ohb.oracletemplateid = 'E') THEN
                     gc_error_code := 'OHB09';
                     gc_error_msg  := 'Invalid OracleTemplateId E for the Lot Controlled item '||lr_ohb.itemnumber;
                     gc_comments   := 'Please provide the oracletemplateid other than E';
                     INSERT_ERROR;
                     lc_validation_status := 'VE';
                     gc_log_message       := 'OHB09-Invalid OracleTemplateId E for the Lot Controlled item '||lr_ohb.itemnumber;
                     XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                   END IF;
               END IF;
               IF ( ln_serial_number_control_code = 5 ) THEN
                    IF ( lr_ohb.oracletemplateid <> 'E') THEN
                      gc_error_code := 'OHB10';
                      gc_error_msg  := 'Invalid OracleTemplateId '||lr_ohb.oracletemplateid||' for the Serial Controlled item '||lr_ohb.itemnumber;
                      gc_comments   := 'Please provide the oracletemplateid as E';
                      INSERT_ERROR;
                      lc_validation_status := 'VE';
                      gc_log_message       := 'OHB10-Invalid OracleTemplateId '||lr_ohb.oracletemplateid||' for the Serial Controlled item '||lr_ohb.itemnumber;
                      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
                    END IF;
               END IF;
            EXCEPTION
            WHEN OTHERS THEN
               gc_error_code       := SQLCODE;
               gc_error_msg        := SQLERRM;
               INSERT_ERROR;
               lc_validation_status := 'VE';
               gc_log_message       := SQLERRM;
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;

      END IF; --End of Validating the Lot Number,Expiration Date,OracleTemplateId Columns
      -- End of changes V1.2

      gc_log_message := 'End of validations for the record '||lr_ohb.oracleidentifier;
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

-------------------------------------------------------------------------
--END OF VALIDATIONS
-------------------------------------------------------------------------

           ----------------------------------------------------------------------------
           --Updating the validation status and some derivated ids in the staging table
           -----------------------------------------------------------------------------
           BEGIN
             IF ( lc_validation_status = 'VE' ) THEN
              UPDATE usbpcs_onhand_cleaned UOC
              SET    UOC.oraclecharfld1  = 'VE'
                    ,UOC.oraclecharfld2  = lc_uom_code
                    ,UOC.oracleintfld1   = ln_inv_org_id
                    ,UOC.oracleintfld2   = ln_inv_item_id
                    ,UOC.oracleintfld3   = gn_trans_type_id
                    ,UOC.oracleintfld4   = gn_ccid
                    ,UOC.oracleintfld8   = gn_request_id
              WHERE  UOC.oracleidentifier=lr_ohb.oracleidentifier;
             ELSE
              UPDATE usbpcs_onhand_cleaned UOC
              SET    UOC.oraclecharfld1  = 'VS'
                    ,UOC.oraclecharfld2  = lc_uom_code
                    ,UOC.oracleintfld1   = ln_inv_org_id
                    ,UOC.oracleintfld2   = ln_inv_item_id
                    ,UOC.oracleintfld3   = gn_trans_type_id
                    ,UOC.oracleintfld4   = gn_ccid
                    ,UOC.oracleintfld8   = gn_request_id
              WHERE  UOC.oracleidentifier=lr_ohb.oracleidentifier;
             END IF;
           EXCEPTION
           WHEN NO_DATA_FOUND THEN
               gc_log_message:='There is no data found to not update the validation status(oraclecharfld1) and some other derived id s';
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           WHEN OTHERS THEN
               gc_log_message:='There is other reason to not update the validation status(oraclecharfld1) and some other derived id s';
               XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;

            lc_validation_status:=NULL;
           EXIT WHEN lcu_ohb%NOTFOUND;
        END LOOP;             -- End of the validations Loop

        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'End Of Validations On the Staging Table USBPCS_ONHAND_CLEAND');
        XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'                                                                              ');

        COMMIT;

           -------------------------------------------------------------------------
           --If there is invalid records in the staging table call the
           --error report other wise call the MOVE_INV_OHB_DATA which
           --moves all the valid records into the Interface Tables
           -------------------------------------------------------------------------
           BEGIN
              -- Counting total records from the staging table
              SELECT COUNT(*)
              INTO   ln_total_rec
              FROM   usbpcs_onhand_cleaned;


              -- Counting total valid records from the staging table
              SELECT COUNT(*)
              INTO   ln_valid_rec
              FROM   usbpcs_onhand_cleaned
              WHERE  oraclecharfld1 = 'VS';

              -- Counting total invalid records from the staging table
              SELECT COUNT(*)
              INTO   ln_invalid_rec
              FROM   usbpcs_onhand_cleaned
              WHERE  oraclecharfld1 = 'VE';

              -------------------------------------------------------------------------
              --Summary Of Data Validation Process
              -------------------------------------------------------------------------
              FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_ONHAND_CLEANED Records Validated ');
              FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                          :    ' ||ln_total_rec);
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation                  :    ' ||ln_valid_rec);
              FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored out                        :    ' ||ln_invalid_rec);
              FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));

              gc_log_message := 'If there are Invalid Records it sets the Concurrent Program status to Warning Otherwise it moves the records into the Interface Tables';
              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

              IF ( ln_invalid_rec > 0 OR ln_valid_rec = 0 ) THEN
                x_ret_code:=1;              --Setting the Concurrent Programme status to Completed with Warning
                XXHA_COMMON_UTILITIES_PKG.LAUNCH_ERROR_REPORT_PRC(gn_request_id,'On-Hand Bal Conversion','Item Number');
              ELSE
                XXHA_INV_OHB_CONV_PK.MOVE_INV_OHB_DATA(p_debug_flag,x_ret_code);
              END IF;
           EXCEPTION
              WHEN NO_DATA_FOUND THEN
                  gc_log_message:='There is no data found to determine whether it needs to run error report or execute MOVE_INV_OHB_DATA';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
              WHEN OTHERS THEN
                  gc_log_message:='There is other reason not to determine whether it needs to run error report or execute MOVE_INV_OHB_DATA';
                  XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);
           END;


   END; --End of Validations Block
  END IF;
END VALIDATE_INV_OHB_DATA; --End of the VALIDATE_INV_OHB_DATA Procedure


-- +==============================================================================+
-- | PROCEDURE: MOVE_INV_OHB_DATA                                                 |
-- |                                                                              |
-- | DESCRIPTION: Procedure to insert the valid records into the interface tables |
-- |                                                                              |
-- |                                                                              |
-- | Call From  : VALIDATE_INV_OHB_DATA                                           |
-- |                                                                              |
-- | PARAMETERS:                                                                  |
-- |   IN: p_debug_flag                                                           |
-- |  OUT: x_ret_code                                                             |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- | SCOPE: PUBLIC                                                                |
-- |                                                                              |
-- | HISTORY:                                                                     |
-- |  WHO            WHAT                                              WHEN       |
-- |  -------------- ------------------------------------------------- -----------|
-- |  Narendra.S     Initial Version.                                  16-10-2006 |
-- |  Narendra.S     After Review                                      31-10-2006 |
-- |  Narendra.S     Changes made as per onsite                        13-11-2006 |
-- |                 comments,the changes are commet out the                      |
-- |                 attribute1 column in MTL_TRANSACTIONS_INTERFACE              |
-- |                 INSERT statement                                             |
-- +==============================================================================+
PROCEDURE MOVE_INV_OHB_DATA(p_debug_flag IN VARCHAR2,x_ret_code OUT VARCHAR2)
IS
   --The Local Variables
   lc_material_transactions_id    mtl_transactions_interface.transaction_interface_id%TYPE;            --variable to hold the Material Transaction Id
   lc_rec_status                  VARCHAR2(3);                                                         --variable to hold the Record Status
   ln_invalid_processing_rec      NUMBER;                                                              --variable to hold the Total No.of invalid processing Records
   ln_total_processing_rec        NUMBER;                                                              --variable to hold the Total No.of processing Records
   ln_valid_processing_rec        NUMBER;                                                              --variable to hold the Total No.of valid processing Records
   lc_lc_type                     mtl_secondary_inventories.LOCATOR_TYPE%TYPE;
   --The Cursor on the Staging Table
   CURSOR lcu_ohb_processing
   IS
   SELECT *
   FROM   usbpcs_onhand_cleaned
   WHERE  oraclecharfld1='VS';

   BEGIN

    XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'Start Of processing the records into the interface tables');
    XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');

      FOR lr_ohb_processing IN lcu_ohb_processing
      LOOP

   -------------------------------------------------------------------------
   --Inserting the valid records into the Interface Tables
   -------------------------------------------------------------------------
         gc_record_identifier := lr_ohb_processing.itemnumber;
         gn_record_number     := lr_ohb_processing.oracleidentifier;
         lc_rec_status        := 'PS';

         SELECT mtl_material_transactions_s.nextval
         INTO   lc_material_transactions_id
         FROM   DUAL;

          BEGIN
          --Start of Changes V1.6
             lc_lc_type:=NULL;
             SELECT MSI.locator_type
	     INTO    lc_lc_type
	     FROM   mtl_secondary_inventories MSI
	            ,mtl_parameters MP
	     WHERE  MSI.organization_id          =MP.organization_id --ln_inv_org_id
	     AND    MP.organization_code         = lr_ohb_processing.inventoryorg -- 'CHS'
             AND    MSI.secondary_inventory_name = lr_ohb_processing.subinventory; --'Parts';
          --End of Changes V1.6


            gc_log_message := 'Processing the record '||lr_ohb_processing.oracleidentifier||' into mtl_transactions_interface';
            XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

              INSERT INTO mtl_transactions_interface(
                                                     last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    ,item_segment1
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                    ,loc_segment1
                                                    ,loc_segment2
                                                    ,loc_segment3
                                                    --,loc_segment4
                                                    --,loc_segment5
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    -- Start of changes V1.1
                                                    --,attribute1
                                                    -- End of changes V1.1
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,gn_user_id
                                                   ,SYSDATE
                                                   ,gn_user_id
                                                   ,'Conversion - BPCS'
                                                   ,0
                                                   ,0
                                                   ,1
                                                   ,3
                                                   ,2
                                                   ,lr_ohb_processing.itemnumber
                                                   ,lr_ohb_processing.oracleintfld2
                                                   ,lr_ohb_processing.revisionnbr
                                                   ,lr_ohb_processing.oracleintfld1
                                                   ,lr_ohb_processing.subinventory
                                                    --Start of Changes V1.6 added decode statement for all the three locator1-3
                                                   ,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator1)
                                                   ,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator2)
                                                   ,decode(lc_lc_type,1,NULL,lr_ohb_processing.locator3)
                                                   --Start of Changes V1.6
                                                  -- ,lr_ohb_processing.locator4
                                                  -- ,lr_ohb_processing.locator5
                                                   --End of Changes V1.6
                                                   ,lr_ohb_processing.onhand
                                                   ,lr_ohb_processing.oraclecharfld2
                                                   ,gd_transaction_date
                                                   ,lr_ohb_processing.oracleintfld3
                                                   ,lr_ohb_processing.oracleintfld4
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   -- Start of changes V1.1
                                                   -- ,lr_ohb_processing.sterilizationtype
                                                   -- End of changes V1.1
                                                  );
           EXCEPTION
           WHEN OTHERS THEN
              gc_error_code := SQLCODE;
              gc_error_msg  := SQLERRM;
              gc_comments   := 'Please Check the Data in the Staging Table';
              INSERT_ERROR;
              lc_rec_status:='PE';
              UPDATE_PROCESSING_STATUS(gn_record_number,lc_rec_status);
           END;

            ----------------------------------------------------------------------------------------
            --Inserting the data into MTL_TRANSACTION_LOTS_INTERFACE or MTL_SERIAL_NUMBERS_INTERFACE
            ----------------------------------------------------------------------------------------
            IF ( lr_ohb_processing.lotnumber IS NOT NULL AND lr_ohb_processing.oracletemplateid='E' ) THEN
             BEGIN

             gc_log_message := 'Processing the record '||lr_ohb_processing.oracleidentifier||' into mtl_serial_numbers_interface'||' because the item '||lr_ohb_processing.itemnumber||' is Serial Controlled';
             XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

              INSERT INTO mtl_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,gn_user_id
                                                     ,SYSDATE
                                                     ,gn_user_id
                                                     ,lc_material_transactions_id
                                                     ,lr_ohb_processing.lotnumber
                                                     );
             EXCEPTION
             WHEN OTHERS THEN
                gc_error_code := SQLCODE;
                gc_error_msg  := SQLERRM;
                gc_comments   := 'Please Check the Data in the Staging Table';
                INSERT_ERROR;
                lc_rec_status:='PE';
                UPDATE_PROCESSING_STATUS(gn_record_number,lc_rec_status);
             END;

            ELSIF ( lr_ohb_processing.lotnumber IS NOT NULL AND lr_ohb_processing.oracletemplateid<>'E' ) THEN
             BEGIN

              gc_log_message := 'Processing the record '||lr_ohb_processing.oracleidentifier||' into mtl_transaction_lots_interface'||' because the item '||lr_ohb_processing.itemnumber||' is Lot Controlled';
              XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

              INSERT INTO mtl_transaction_lots_interface(
                                                         transaction_interface_id
                                                        ,lot_number
                                                        ,lot_expiration_date
                                                        ,transaction_quantity
                                                        ,last_update_date
                                                        ,last_updated_by
                                                        ,creation_date
                                                        ,created_by
                                                        )
                                                 values(
                                                        lc_material_transactions_id
                                                       ,lr_ohb_processing.lotnumber
                                                       ,to_date(lr_ohb_processing.expirationdate,'RR-MM-DD')
                                                       ,lr_ohb_processing.onhand
                                                       ,SYSDATE
                                                       ,gn_user_id
                                                       ,SYSDATE
                                                       ,gn_user_id
                                                       );
             EXCEPTION
             WHEN OTHERS THEN
                gc_error_code := SQLCODE;
                gc_error_msg  := SQLERRM;
                gc_comments   := 'Please Check the Data in the Staging Table';
                INSERT_ERROR;
                lc_rec_status:='PE';
                UPDATE_PROCESSING_STATUS(gn_record_number,lc_rec_status);
             END;
            END IF;
        EXIT WHEN lcu_ohb_processing%NOTFOUND;
      END LOOP;        -- End of the processing Loop

         --Counting the total processing records
         SELECT COUNT(*)
         INTO   ln_total_processing_rec
         FROM   usbpcs_onhand_cleaned;

         --Counting the total invalid processing records
         SELECT COUNT(*)
         INTO   ln_invalid_processing_rec
         FROM   usbpcs_onhand_cleaned
         WHERE  oraclecharfld1 = 'PE';

         gc_log_message := 'If there are invalid processing records it rollbacks the data and sets the concurrent program status to warning';
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,gc_log_message);

         IF ( ln_invalid_processing_rec > 0 ) THEN
           ROLLBACK;
           XXHA_COMMON_UTILITIES_PKG.LAUNCH_ERROR_REPORT_PRC(gn_request_id,'On-Hand Bal Conversion','Item Number');
           x_ret_code:=1;       --Setting the Concurrent Programme status to Completed with Warning
         END IF;


         --Updating the status of staging table
         UPDATE usbpcs_onhand_cleaned UOC
         SET    UOC.oraclecharfld1 ='PS'
         WHERE  UOC.oraclecharfld1 <> 'PE';

         --Counting the total valid processing records
         SELECT COUNT(*)
         INTO   ln_valid_processing_rec
         FROM   usbpcs_onhand_cleaned
         WHERE  oraclecharfld1 = 'PS';

         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'******************************************************************************');
         XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(p_debug_flag,'End Of processing the records into the interface tables');

         -------------------------------------------------------------------------
         --Summary Of Data Processing Process
         -------------------------------------------------------------------------
         FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of USBPCS_ONHAND_CLEANED Records Processed');
         FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records                                        :'||ln_total_processing_rec);
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Processed to interface tables          :'||ln_valid_processing_rec);
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records failed to process to interface tables  :'||ln_invalid_processing_rec);
         FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));

     COMMIT;

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in xxha_ohb_conv_pkg.xxha_inv_move_ohb: ' || SQLERRM);

END MOVE_INV_OHB_DATA;    --End Of the MOVE_INV_OHB_DATA Procedure


END XXHA_INV_OHB_CONV_PK; --End of the XXHA_INV_OHB_CONV_PK Body

/
