CREATE OR REPLACE package XX_HAEMO_OVERIDE_DEBRIEF_COGS is

  PROCEDURE custom_account(x_return_status OUT NOCOPY VARCHAR2);

end XX_HAEMO_OVERIDE_DEBRIEF_COGS;

/


CREATE OR REPLACE package body XX_HAEMO_OVERIDE_DEBRIEF_COGS is

type t_account is record(
   segment1 varchar2(25),
   segment2 varchar2(25),
   segment3 varchar2(25),
   segment4 varchar2(25),
   segment5 varchar2(25),
   segment6 varchar2(25),
   segment7 varchar2(25),
   segment8 varchar2(25),
   segment9 varchar2(25));

procedure put_line(message varchar2) is
begin
--    dbms_output.put_line(message);
    fnd_file.put_line(fnd_file.log, message);
  end;
  procedure initialize is
  begin
    null;
    fnd_global.apps_initialize(0, -- SYSADMIN
                               51195, --fnd_resp_id=Customer Service Representative JP
                               20003 --
                               );
    csf_debrief_update_pkg.g_debrief_line_id := 1001875000120;
  exception
    when others then
      put_line('Error in initialize:' || sqlerrm);
      raise;
  end;
  function get_ccid(p_date            date default sysdate,
                    p_concat_segments varchar2 default null,
                    segment1          varchar2 default null,
                    segment2          varchar2 default null,
                    segment3          varchar2 default null,
                    segment4          varchar2 default null,
                    segment5          varchar2 default null,
                    segment6          varchar2 default null,
                    segment7          varchar2 default null,
                    segment8          varchar2 default null,
                    segment9          varchar2 default null,
                    p_chart_of_accounts_id number default null) return number is
--    l_SET_OF_BOOKS_ID      number;
--    l_chart_of_accounts_id number;
    l_ccid                 number;
    l_delimiter            VARCHAR2(1);
    l_concat_segments      VARCHAR2(46); --!! change here for another SOB
    l_date                 date;
  begin

/*    begin
      fnd_profile.GET('GL_SET_OF_BKS_ID', l_SET_OF_BOOKS_ID);

      select chart_of_accounts_id
        into l_chart_of_accounts_id
        from gl_sets_of_books g
       where SET_OF_BOOKS_ID = l_SET_OF_BOOKS_ID;
    exception
      when others then
        put_line('get_ccid: can not get chart_of_accounts_id');
        put_line('get_ccid:' || sqlerrm);
        return 0;
    end;
*/

    If p_chart_of_accounts_id is null then
        put_line('get_ccid: chart_of_accounts_id is null');
        return 0;
    end if;

    l_date            := NVL(p_date, sysdate);
    l_concat_segments := p_concat_segments;

    if (l_concat_segments is null) then
      if (segment1 is null or segment2 is null or segment3 is null or
         segment4 is null or segment5 is null or segment6 is null or
         segment7 is null or segment8 is null or segment9 is null) then
        put_line('get_ccid: all segments must be initialazed');
        return 0;
      end if;

      l_delimiter := FND_FLEX_EXT.get_delimiter('SQLGL',
                                                'GL#',
                                                p_chart_of_accounts_id);

      l_concat_segments := segment1 || l_delimiter || segment2 ||
                           l_delimiter || segment3 || l_delimiter ||
                           segment4 || l_delimiter || segment5 ||
                           l_delimiter || segment6 || l_delimiter ||
                           segment7 || l_delimiter || segment8 ||
                           l_delimiter || segment9;

    end if;

    put_line('get_ccid: chart_of_accounts_id = ' || p_chart_of_accounts_id);
    put_line('get_ccid: date = ' || l_date);

    --put_line('get_ccid: geting ccid for account = ' || l_concat_segments);

    l_ccid := FND_FLEX_EXT.GET_CCID('SQLGL',
                                    'GL#',
                                    p_chart_of_accounts_id,
                                    l_date,
                                    l_concat_segments);

    if (l_ccid = 0) then
      put_line('get_ccid: can not get ccid');
      put_line(FND_FLEX_EXT.get_message);
      return 0;
    end if;

    put_line('get_ccid: ccid  = ' || l_ccid);

    return l_ccid;

  exception
    when others then
      put_line('Error in get_ccid:' || sqlerrm);
      return 0;
  end get_ccid;

  PROCEDURE custom_account(x_return_status OUT NOCOPY VARCHAR2) is
    l_org_id number;
    --l_organization_id              number;
    l_issuing_inventory_org_id     Number;
    l_receiving_inventory_org_id   Number;
    l_receiving_sub_inventory_code Varchar2(50);
    l_transaction_type_id          Number;
    l_line_category_code           varchar2(10);
    l_subinv_type                  NUMBER;
    --   l_billing_type               Varchar2(3);
    l_debrief_line_id      CSF_DEBRIEF_LINES.DEBRIEF_LINE_ID%type;
    l_task_source_obj_type JTF_TASKS_B.source_object_type_code%type;
    l_task_source_obj_id   JTF_TASKS_B.Source_object_id%type;
    l_task_source_SR_obj_id   JTF_TASKS_B.Source_object_id%type;
    l_salesrep_id          number;
    l_salesrep_account     t_account;
    l_item_org_account     t_account;
    l_cogs_account         t_account;
    l_item_org_account_id  number;
    l_cogs_account_id      number;
    l_salesrep_account_id  number;
    l_item_id              mtl_system_items_b.inventory_item_id%type;
    l_chart_of_accounts_id  number := null;

    CURSOR l_cost_of_acct(p_org_id Number, p_item_id Number) IS
      SELECT cost_of_sales_account --, inventory_asset_flag
        FROM mtl_system_items_b
       WHERE organization_id = p_org_id
         AND inventory_item_id = p_item_id;

    CURSOR l_subinv(p_org_id NUMBER, p_subinv VARCHAR2) IS
      SELECT asset_inventory
        FROM mtl_secondary_inventories
       WHERE organization_id = p_org_id
         AND secondary_inventory_name = p_subinv;

  BEGIN
    --  csf_debrief_update_pkg.g_account_id := l_cogs_account_id;
    -- Custom logic based on csf_debrief_update_pkg.g_debrief_line_id
   put_line('starting XX_HAEMO_OVERIDE_DEBRIEF_COGS.custom_account');

    SELECT TO_NUMBER(DECODE(SUBSTRB(USERENV('CLIENT_INFO'), 1, 1),
                            ' ',
                            NULL,
                            SUBSTRB(USERENV('CLIENT_INFO'), 1, 10)))
      INTO l_org_id
      from dual;


    If l_org_id is null then
      put_line('l_org_id is null');
      x_return_status := fnd_api.g_ret_sts_error;
      return;
    end if;

    /* THIS customization should work for "Haemonetics Japan GK JP OU" only */
   /*
      If l_org_id != 156 then
      put_line('Non "Haemonetics Japan GK JP OU" operating unit. Exit.');
      x_return_status := fnd_api.G_RET_STS_SUCCESS;
      return;
      end if;
    */

    l_debrief_line_id := csf_debrief_update_pkg.g_debrief_line_id;

    If csf_debrief_update_pkg.g_debrief_line_id is null then
      put_line('csf_debrief_update_pkg.g_debrief_line_id is null');
      x_return_status := fnd_api.g_ret_sts_error;
      return;
    end if;

    put_line('l_org_id=' || l_org_id);
    put_line('l_debrief_line_id=' || l_debrief_line_id);

    begin
      select t.source_object_type_code,
             t.Source_object_id,
             dl.inventory_item_id,
             dl.issuing_inventory_org_id,
             dl.receiving_inventory_org_id,
             dl.receiving_sub_inventory_code,
             dl.transaction_type_id
        into l_task_source_obj_type,
             l_task_source_obj_id,
             l_item_id,
             l_issuing_inventory_org_id,
             l_receiving_inventory_org_id,
             l_receiving_sub_inventory_code,
             l_transaction_type_id
        from JTF_TASKS_B          t,
             JTF_TASK_ASSIGNMENTS ta,
             CSF_DEBRIEF_HEADERS  dh,
             CSF_DEBRIEF_LINES    dl
       where ta.TASK_id = t.TASK_id
         and dh.TASK_ASSIGNMENT_id = ta.TASK_ASSIGNMENT_id
         and dl.DEBRIEF_HEADER_id = dh.DEBRIEF_HEADER_id
         and dl.DEBRIEF_LINE_ID =l_debrief_line_id;
    exception
      WHEN others THEN
        put_line('Can not find Source_object');
        raise;
    end;

/*    if l_task_source_obj_type != 'SR' then
      put_line('task_source_obj_type != SR');
      x_return_status := fnd_api.g_ret_sts_success;
      return;
    end if;
*/

    if l_task_source_obj_type = 'DR' then
      put_line('Get SR id from DR');
      --x_return_status := fnd_api.g_ret_sts_success;
  	  begin
  		  select incident_id
  		  into l_task_source_SR_obj_id
  		  from csd_repairs
  		  where repair_line_id = l_task_source_obj_id;
  	  exception
        WHEN others THEN
          put_line('Can not find SR assinged to DR');
          raise;
      end;
      --return;
      else    l_task_source_SR_obj_id := l_task_source_obj_id;
    end if;


    if l_item_id is null then
      put_line('l_item_id is null');
      x_return_status := fnd_api.g_ret_sts_error;
      return;
    end if;

    put_line(l_task_source_obj_type || ' id=' || l_task_source_obj_id);
    put_line('SR id=' || l_task_source_SR_obj_id);
    put_line('l_item_id=' || l_item_id);
    put_line('issuing_inventory_org_id=' || l_issuing_inventory_org_id);
    put_line('receiving_inventory_org_id=' || l_receiving_inventory_org_id);

--Sales Rep--------------------------------

    begin
      begin
        select su.primary_salesrep_id
          into l_salesrep_id
          from HZ_CUST_SITE_USES_ALL  su,
               HZ_CUST_ACCT_SITES_ALL cas,
               cs_incidents_all_b     i
         where su.CUST_ACCT_SITE_id = cas.CUST_ACCT_SITE_id
           and su.org_id = cas.org_id --
           and i.ACCOUNT_ID = cas.cust_ACCount_id
           and su.site_use_code = 'BILL_TO'
           and su.status = 'A'
           and cas.status = 'A'
           and cas.bill_to_flag = 'P'
           --and cas.org_id = l_org_id --
           and cas.org_id = i.org_id
           and incident_id = l_task_source_SR_obj_id
           and su.primary_salesrep_id is not null
           and rownum=1;
      exception
        WHEN others THEN
          put_line('Can not find salesrep_id. Please check salesperson on Customer primamry Bill-to site. It should be filled.');
          raise;
      end;

      put_line('salesrep_id=' || l_salesrep_id);

      begin
        select cc.segment1,
               cc.segment2,
               cc.segment3,
               cc.segment4,
               cc.segment5,
               cc.segment6,
               cc.segment7,
               cc.segment8,
               cc.segment9,
               sp.gl_id_rev
          into l_salesrep_account.segment1,
               l_salesrep_account.segment2,
               l_salesrep_account.segment3,
               l_salesrep_account.segment4,
               l_salesrep_account.segment5,
               l_salesrep_account.segment6,
               l_salesrep_account.segment7,
               l_salesrep_account.segment8,
               l_salesrep_account.segment9,
               l_salesrep_account_id
          from gl_code_combinations cc,
               JTF_RS_SALESREPS sp,
               CS_INCIDENTS_ALL_B i
         where cc.code_combination_id = sp.gl_id_rev
              --sp.gl_id_freight
              --sp.gl_id_rec
           and sp.SALESREP_ID = l_salesrep_id
--           and sp.org_id = l_org_id;
           and sp.org_id = i.org_id
           and i.incident_id = l_task_source_SR_obj_id;
      exception
        WHEN others THEN
          put_line('There is no code combination for this SalesPerson in this Org_id');
          raise;
      end;

    exception
      when others then l_salesrep_account_id := null;
    end;

    put_line('salesrep_account_id=' || l_salesrep_account_id);

--END Sales Rep--------------------------------

--Item---------------------------------------------
    /* l_organization_id := nvl(l_receiving_inventory_org_id,
    nvl(l_issuing_inventory_org_id,
        cs_std.get_item_valdn_orgzn_id));*/

    select cttv.line_order_category_code
      into l_line_category_code
      from cs_transaction_types_vl cttv
     where cttv.transaction_type_id = l_transaction_type_id;

    put_line('line_category_code ' || l_line_category_code);

    if (l_line_category_code = 'RETURN') then
      --FS Recovery
      --  l_inv_transaction_type_id := 94; --RECEIVING
      OPEN l_subinv(l_receiving_inventory_org_id,
                    l_receiving_sub_inventory_code);
      FETCH l_subinv
        INTO l_subinv_type;
      CLOSE l_subinv;
      IF l_subinv_type = 1 THEN
        --- Asset Subinventory
        put_line('Asset Subinventory');
        OPEN l_cost_of_acct(l_receiving_inventory_org_id, l_item_id);
        FETCH l_cost_of_acct
          INTO l_item_org_account_id; --, l_inv_asset_flag;
        CLOSE l_cost_of_acct;
      ELSIF l_subinv_type = 2 THEN
        -- Expense Subinventory
        put_line('RETURN in Expense Subinventory, account is null');
        --l_item_org_account_id := NULL;
        return;
      END IF; -- End if for subinv type
    else
      --l_line_category_code = 'ORDER' or null
      --FS Usage
      -- l_inv_transaction_type_id := 93; --ISSUING
      OPEN l_cost_of_acct(l_issuing_inventory_org_id, l_item_id);
      FETCH l_cost_of_acct
        INTO l_item_org_account_id; --, l_inv_asset_flag;
      CLOSE l_cost_of_acct;
    end if;

    if l_item_org_account_id is null then
      put_line('cannot find item_org_account_idl');
      x_return_status := fnd_api.g_ret_sts_error;
      return;
    end if;

    put_line('item_org_account_id=' || l_item_org_account_id);

    begin
      select cc.segment1,
             cc.segment2,
             cc.segment3,
             cc.segment4,
             cc.segment5,
             cc.segment6,
             cc.segment7,
             cc.segment8,
             cc.segment9,
             cc.chart_of_accounts_id
        into l_item_org_account.segment1,
             l_item_org_account.segment2,
             l_item_org_account.segment3,
             l_item_org_account.segment4,
             l_item_org_account.segment5,
             l_item_org_account.segment6,
             l_item_org_account.segment7,
             l_item_org_account.segment8,
             l_item_org_account.segment9,
             l_chart_of_accounts_id
        from gl_code_combinations cc
       where cc.code_combination_id = l_item_org_account_id;
    exception
      WHEN others THEN
        put_line('item_org_account segments');
        x_return_status := fnd_api.g_ret_sts_error;
        raise;
    end;

--END Item---------------------------------------------

    put_line('item_org: '||
             l_item_org_account.segment1 || '-' ||
             l_item_org_account.segment2 || '-' ||
             l_item_org_account.segment3 || '-' ||
             l_item_org_account.segment4 || '-' ||
             l_item_org_account.segment5 || '-' ||
             l_item_org_account.segment6 || '-' ||
             l_item_org_account.segment7 || '-' ||
             l_item_org_account.segment8 || '-' ||
             l_item_org_account.segment9 || ' Chart of Account ID:'||l_chart_of_accounts_id);
--------------------------------------------------------------
    l_cogs_account := l_item_org_account;
--------------------------------------------------------------
    if l_salesrep_account.segment1 is not null then

        put_line('salesrep: '||
             l_salesrep_account.segment1 || '-' ||
             l_salesrep_account.segment2 || '-' ||
             l_salesrep_account.segment3 || '-' ||
             l_salesrep_account.segment4 || '-' ||
             l_salesrep_account.segment5 || '-' ||
             l_salesrep_account.segment6 || '-' ||
             l_salesrep_account.segment7 || '-' ||
             l_salesrep_account.segment8 || '-' ||
             l_salesrep_account.segment9);

        l_cogs_account.segment3 := l_salesrep_account.segment3;
        l_cogs_account.segment4 := l_salesrep_account.segment4;

      end if;

    put_line(' cogs   : '||
             l_cogs_account.segment1 || '-' || l_cogs_account.segment2 || '-' ||
             l_cogs_account.segment3 || '-' || l_cogs_account.segment4 || '-' ||
             l_cogs_account.segment5 || '-' || l_cogs_account.segment6 || '-' ||
             l_cogs_account.segment7 || '-' || l_cogs_account.segment8 || '-' ||
             l_cogs_account.segment9);

    l_cogs_account_id := get_ccid(sysdate,
                                  null,
                                  l_cogs_account.segment1,
                                  l_cogs_account.segment2,
                                  l_cogs_account.segment3,
                                  l_cogs_account.segment4,
                                  l_cogs_account.segment5,
                                  l_cogs_account.segment6,
                                  l_cogs_account.segment7,
                                  l_cogs_account.segment8,
                                  l_cogs_account.segment9,
                                  l_chart_of_accounts_id);

      if nvl(l_cogs_account_id,0)=0  then
         put_line('get_ccid did not return an account_id');
         x_return_status := fnd_api.g_ret_sts_error;
         return;
      end if;

    csf_debrief_update_pkg.g_account_id := l_cogs_account_id;
    x_return_status := fnd_api.g_ret_sts_success;
    put_line('ending XX_HAEMO_OVERIDE_DEBRIEF_COGS.custom_account');
  EXCEPTION
    WHEN others THEN
      put_line(SQLCODE || SQLERRM);
      x_return_status := fnd_api.g_ret_sts_error;
      fnd_message.set_name('JTF', 'JTF_TASK_UNKNOWN_ERROR');
      fnd_message.set_token('P_TEXT', SQLCODE || SQLERRM);
      fnd_msg_pub.add;
  END;

end XX_HAEMO_OVERIDE_DEBRIEF_COGS;

/
