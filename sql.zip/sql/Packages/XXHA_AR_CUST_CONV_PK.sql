CREATE OR REPLACE PACKAGE
XXHA_AR_CUST_CONV_PK
-- +==============================================================================+
-- |                       Oracle NAIO (India)                                    |
-- |                         Bangalore, India                                     |
-- +==============================================================================+
-- | Name               : XXHAARCUSTCNVS.pls                                      |
-- | Description        : This Package is for Customer conversion                 |
-- |                                                                              |
-- |                                                                              |
-- |                                                                              |
-- |Change Record:                                                                |
-- |===============                                                               |
-- |Version   Date        Author            Remarks                               |
-- |=======   ==========  =============     ======================================|
-- |DRAFT 1A  25-Sep-2006 Francis           Initial draft version                 |
-- |1.0	      23-Oct-2006 Francis           After Review                          |
-- |1.20      09-Dec-10   B.Marcoux         Adding processing to allow 'LEGAL'    |
-- |                                          records to be processed             |
-- |                                                                              |
-- +===============================================================================+
AS
-- Global Variable Declaration
gc_operating_unit_Name  VARCHAR2(150);                                        --Variable to hold Operating Unit Name
gn_request_id           NUMBER         :=FND_PROFILE.VALUE('CONC_REQUEST_ID');--Variable to hold Request id
gn_record_number        NUMBER;                                               --Variable to hold Record Number
gc_record_identifier    VARCHAR2(2000);                                       --Variable to hold Record Identifier
gc_err_rec_identifier   VARCHAR2(2000);                                       --Variable to hold Error Record Identifier
gc_error_code           VARCHAR2(2000);                                       --Variable to hold Error Code
gc_error_msg            VARCHAR2(2000);                                       --Variable to hold Error Message
gc_comments             VARCHAR2(2000);                                       --Variable to hold Comments
gc_table_name           VARCHAR2(2000) :='HAEMO_CUSTOMERS';                   --Variable to hold Table Name
gc_attribute1           VARCHAR2(2000);                                       --Variable to hold Attribute1
gc_attribute2           VARCHAR2(2000);                                       --Variable to hold Attribute2
gc_attribute3           VARCHAR2(2000);                                       --Variable to hold Attribute3
gc_attribute4           VARCHAR2(2000);                                       --Variable to hold Attribute4
gc_attribute5           VARCHAR2(2000);                                       --Variable to hold Attribute5
gc_status               VARCHAR2(2000);                                       --Variable to hold Status of the Insertion to Common Error Table
gc_con_name             VARCHAR2(240)  :='XXHA: Customer Conversion';         --Variable to hold Concurrent Program Name
gc_identifier           VARCHAR2(240)  :='CustNbr-ShipTo';                    --Variable to hold the Identifier for the Error Report
gc_debug_flag           VARCHAR2(1);                                          --Variable to hold the Debug Flag
gc_log_msg              VARCHAR2(4000);                                       --Variable to hold the log Message
gn_record_id            NUMBER;                                               --Variable to hold the Record Id
gc_status_flag          VARCHAR2(150);                                        --Variable to hold the Status Flag
gc_api_status           VARCHAR2(20);                                         --Variable to hold the API Status
gc_organization_name     VARCHAR2(1000);

-- Procedure to Validate the Setup
PROCEDURE CHECK_CUST_SETUP(
                           x_err_buf        OUT VARCHAR2
                          ,x_ret_code       OUT NUMBER
                          ,x_setup_err_flag OUT VARCHAR2
                          );

-- Procedure to Validate the Customer data
PROCEDURE   VALIDATE_CUST_DATA(
                               x_err_buf    OUT VARCHAR2
                              ,x_ret_code   OUT NUMBER
                              );
--Procedure to Process the Customer data by API
PROCEDURE   PROCESS_CUST_DATA(
                              x_err_buf     OUT VARCHAR2
                             ,x_ret_code    OUT NUMBER
                             ,p_debug       IN  VARCHAR2
                             ,p_purge_data  IN  VARCHAR2
                             );

END XXHA_AR_CUST_CONV_PK;
/


CREATE OR REPLACE PACKAGE BODY
   XXHA_AR_CUST_CONV_PK
-- +==================================================================================+
-- |                       Oracle NAIO (India)                                        |
-- |                         Bangalore, India                                         |
-- +======================================================================================+
-- | Name               : XXHA_AR_CUST_CONV_PK                                            |
-- | Description        : This Package body is for Customer Conversion                    |
-- |            a                                                                         |
-- |                                                                                      |
-- |                                                                                      |
-- |Change Record:                                                                        |
-- |===============                                                                       |
-- |Version   Date         Author           Remarks                                       |
-- |=======   ==========   =============    ==============================================|
-- |DRAFT 1A  25-Sep-2006  Francis          Initial draft version                         |
-- |1.0       23-Oct-2006  Francis          After Review                                  |
-- |                                                                                      |
-- |1.1       15-Nov-2006  Francis          Validation for FOB added                      |
-- |          23-Nov-2006  Fajna            Modified Validation for                       |
-- |                                        CUSTOMER CLASS,CUSTOMER_TYPE and              |
-- |                                        ADDRESS_CATEGORY Lookup to check the          |
-- |                                        meaning rather than code                      |
-- |                                                                                      |
-- |                                        Included UPPER Case Validation for            |
-- |                                        CUSTOMER CLASS,CUSTOMER_TYPE,                 |
-- |                                        ADDRESS_CATEGORY Lookups,Termscodedesc        |
-- |                                        Countrycode,Currencycode and Language         |
-- |                                                                                      |
-- |                                        Modified Operating Unit Field to              |
-- |                                        CharUserFld5                                  |
-- |                                                                                      |
-- |1.2       20-Dec-2006  Fajna            Modified Validation for CustomerType2         |
-- |                                        to get mapped to Look Up CUSTOMER_CATEGORY    |
-- |                                        instead of ADDRESS_CATEGORY.                  |
-- |                                                                                      |
-- |                                        Included API                                  |
-- |                                        hz_classification_v2pub.create_code_assignment|
-- |                                        for assigning Customer category code at the   |
-- |                                        Customer Level                                |
-- |                                                                                      |
-- |                                        Included NOT NULL Validation for Language,    |
-- |                                        CustomerType1,CustomerType2 and CustomerType3 |
-- |                                                                                      |
-- |                                        Removed Validation for  Sales Man Name and    |
-- |                                        included new Logic for retrieving Salesrepid  |
-- |                                                                                      |
-- |1.3     17-Jan-2007   Subbu             Added logic to validate and process the follow|
-- |                                        Logic to Validate Shippping method            |
-- |                                        Logic to Validate Tax code for site use       |
-- |                                        Logic to pass Tax reference for Site use      |
-- |                                        Logic to default No sale Credit for sales rep |
-- |                                        Logic to default No sales credit for Non US   |
-- |      				    Used attribute10 at customer header level	  |
-- |                                        for passing charuserfld3    		  |
-- |                                        Commented the logic that puts the customer    |
-- |                                        on hold                                       |
-- |                                        Commented the logic that passed               |
-- |                                        the credit limit at Customer Level.and made it|
-- |                                        at Site Use level.                            |
-- |                                        Logic to update Postalcode to '-' for NON US
-- |1.4     05-Feb-2007 Subbu               Added  null condition checking for enddate for
-- |                                        salesrep query
-- |
-- |1.5     08-Feb-2007 Subbu		    Replace countrycode with Operating unit check condition
-- |                                        for sales rep.
-- |                                        Added fnd_output when ever we are defaulting
-- |                                        the salesrep to No salesrep Credit
-- |
-- |                                        Added operating unit condition to the sql
-- |                                        where its trying to fetch/update records
-- |                                        using oracleidentifier
-- |                                        Added Logic to default to' No Sales Credit' for Any
-- |                                        kind of exception in Salesrep scenario
-- |
-- |1.6  12-Feb-2007  Subbu                 Modified Err Messahes
-- |     20-Feb-2007  Subbu                 Added logic to Assign pricelist at Site use level
-- |     20-Feb-2007  Subbu                 Added condition to add attribute3 at customer bill to level
-- |     24-Feb-2007  Subbu                 Added condition to check for start/end date for pricelist
-- |1.7  26-Feb-2007  Subbu                 Modified the output message of Salesrep
-- |                                        Commented logic  SUBSTR(HC.postalcode,1,3)
-- |1.8  02-Mar-07    Subbu                 Added Condition  for payment to process only for  BILLTO
-- |                                        Added reinitialist condition for pricelist in process
-- |     15-Mar-07    Subbu                 Added NULL check condition for NON US Postal code
-- |1.9  19-mar-07    Subbu	            Modified the postalcode check condition of sql which
-- |                                        check the existense of Address in Oracle
-- |                                        Added Re-Initialise condition for SHIP_METHOD and TAX_CODE
-- |                                        Added condition for address assignment incase of BILL/SHIP TO
-- |                                        Commented the logic for address count
-- |1.10 22-Mar-07   Subbu                  Modified the location length
-- |1.11 04-Apr-2007 Subbu                  Modified the attention logic for Shipto site use to populate customer name
-- |                                        to addressline1
-- |1.12 09-Apr-07   Subbu                  Logic to Re-Initialise the addressline4 for BILL_TO attention logic
-- |1.13 27-jun-07   P.Rajack               Added logic not to populate fob at the bill to site
-- |1.14 11-Jul-07   P.Rajack               Added logic for location field for Japan (pl/sql error)
-- |                                        and concatenated full bill to and ship no lpad
-- |1.15 17-Jul-07   P.Rajack               Added China operating unit to logic for shorter location field value
-- |1.16 30-jul-07   P.Rajack               Added logic for Japan to populate warehouse information into attribute4
-- |1.17 26-jun-09   B.Marcoux              Added logic to allow update of Destination (FOB) and Shipping Method for BillTo records.
-- |1.18 29-jun-09   B.Marcoux              Added logic to allow update of Freight Terms for BillTo and ShipTo records utilizing CharUserFld13
-- |1.19 04-Sep-09   B.Marcoux              Removed code that checked ThreeZip Territory processing to determine SalesRep.
-- |                                        New code adds SalesRep attached to ShipTo/BillTo record in input file.
-- |1.20 09-Dec-10   B.Marcoux              Adding processing to allow 'LEGAL' records to be processed
-- |                                        - Format Address Information to be like 'BillTo' records
-- +======================================================================================+
AS
--+=============================================================================+
--| Name        :   UPDATE_PROCESSED_VALUE                                      |
--|                                                                             |
--| Description :   Procedure to update processed_value into                    |
--|                 the haemo_customers table(Staging table)                    |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN: p_record_id                                                           |
--|       p_bill_to_site_use_id                                                 |
--|  OUT: None                                                                  |
--|                                                                             |
--|                                                                             |
--| Returns :                                                                   |
--+=============================================================================+
PROCEDURE   UPDATE_PROCESSED_VALUE(
                                   p_record_id             IN      NUMBER
                                  ,p_bill_to_site_use_id   IN      NUMBER   DEFAULT NULL
                                  )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  haemo_customers HC
   SET     HC.oracleintfld2    = p_bill_to_site_use_id
   WHERE   HC.oracleidentifier = p_record_id
   --Start of changes V1.5
   AND charuserfld5 =gc_operating_unit_name ;
   --End of changes V1.5
COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_AR_CUST_CONV_PK.UPDATE_PROCESSED_VALUE: ' || SQLERRM);
END UPDATE_PROCESSED_VALUE;
--+=============================================================================+
--| Name        :   UPDATE_ERROR                                                |
--|                                                                             |
--| Description :   Procedure to update error into the haemo_customers          |
--|                 table(Staging table)                                        |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN: p_record_id                                                           |
--|       p_status_flag                                                         |
--|
--|  OUT: None                                                                  |
--|                                                                             |
--|  Returns :                                                                  |
--+=============================================================================+
PROCEDURE   UPDATE_ERROR(
                         p_record_id             IN      NUMBER
                        ,p_status_flag           IN      VARCHAR2
                        )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  haemo_customers HC
   SET     HC.oraclecharfld1   = p_status_flag
   WHERE   HC.oracleidentifier = p_record_id
   --Start of changes V1.5
   AND charuserfld5 =gc_operating_unit_name ;
   --End of changes V1.5
COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_AR_CUST_CONV_PK.UPDATE_ERROR: ' || SQLERRM);
END UPDATE_ERROR;
--+=============================================================================+
--| Name        :   INSERT_ERROR_PRC                                            |
--|                                                                             |
--| Description :   Procedure to call xxha_common_utilities.insert_error_prc    |
--|                                                                             |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN:    gn_request_id                                                      |
--|          gn_record_number                                                   |
--|          gc_err_rec_identifier                                              |
--|          gc_error_code                                                      |
--|          gc_error_msg                                                       |
--|          gc_comments                                                        |
--|          gc_table_name                                                      |
--|          gc_attribute1                                                      |
--|          gc_attribute2                                                      |
--|          gc_attribute3                                                      |
--|          gc_attribute4                                                      |
--|          gc_attribute5                                                      |
--|  OUT:    gc_status                                                          |
--|                                                                             |
--|  Returns :                                                                  |
--+=============================================================================+
PROCEDURE INSERT_ERROR_PRC
IS
BEGIN
   XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(
                                            gn_request_id
                                           ,gn_record_number
                                           ,gc_err_rec_identifier
                                           ,gc_error_code
                                           ,gc_error_msg
                                           ,gc_comments
                                           ,gc_table_name
                                           ,gc_attribute1
                                           ,gc_attribute2
                                           ,gc_attribute3
                                           ,gc_attribute4
                                           ,gc_attribute5
                                           ,gc_status
                                           );
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_AR_CUST_CONV_PK.INSERT_ERROR_PRC. Error is: '||SQLERRM);
END INSERT_ERROR_PRC;
-- Start of changes V1.2
--+=============================================================================+
--| Name        :   XXHA_VALIDATE_SALESREP                                            |
--|                                                                             |
--| Description :   Procedure to call xxha_common_utilities.insert_error_prc    |
--|                                                                             |
--|                                                                             |
--| Parameters:                                                                 |
--|   IN:    p_rec_num                                                          |
--|                                                                             |
--|  OUT:    x_sales_rep_id                                                     |
--|          x_err_code                                                         |
--|          x_err_msg                                                          |
--|  Returns : x_sales_rep_id, x_err_code,   x_err_msg                          |
--+=============================================================================+
PROCEDURE XXHA_VALIDATE_SALESREP(
                                 p_rec_num      IN  NUMBER
                                ,x_sales_rep_id OUT NUMBER
                                ,x_err_code     OUT VARCHAR2
                                ,x_err_msg      OUT VARCHAR2
                                )
IS
--Local Variables
 lc_plan_type            VARCHAR2(30) := NULL;
 lc_ora_customer_type3   VARCHAR2(30) := NULL;
 lc_zip3                 VARCHAR2(30) := NULL;
 lc_salesrep             VARCHAR2(100):= NULL;
 lc_ora_salesrep         VARCHAR2(100):= NULL;
 lc_salesrep_fname       VARCHAR2(100):= NULL;
 lc_salesrep_lname       VARCHAR2(100):= NULL;
 lc_too_many_rows        VARCHAR2(1)  := NULL;
 ln_salesrep_id          NUMBER       := 0;
 lc_customertype3        VARCHAR2(50) := NULL; --subbu_feb26
BEGIN
gc_log_msg := 'Patrick00';
---------------------------------------------------------------------------
   --Validation to check whether customertype3 exists in usbpcs_plantype_xref
   ---------------------------------------------------------------------------
  BEGIN
      SELECT UPX.bpcs_plantype
            ,UPX.ora_customer_class
            --V1.7 start og changs
            --,SUBSTR(HC.postalcode,1,3)
            ,SUBSTR(HC.postalcode,1,5) --subbu_26
            --V1.7 End changs
            ,HC.customertype3 --subbu_feb26
      INTO   lc_plan_type
            ,lc_ora_customer_type3
            ,lc_zip3
            ,lc_customertype3 --subbu_feb26
      FROM   usbpcs_plantype_xref UPX
            ,haemo_customers HC
      WHERE  UPX.ora_customer_class=HC.customertype3
      AND    HC.oracleidentifier= p_rec_num
      --Start of changes V1.5
      AND charuserfld5 =gc_operating_unit_name ;
      --End of changes V1.5
lc_too_many_rows:='N';
   EXCEPTION
   WHEN TOO_MANY_ROWS THEN
      lc_too_many_rows:='Y';
   WHEN NO_DATA_FOUND THEN
      lc_salesrep:='No Sales Credit';
   END;
IF (lc_too_many_rows = 'Y') THEN
-- Start of Changes V1.5
     --x_err_code := 'CUST10';
     --x_err_msg  := 'SalesRep Derivation has returned multiple rows for Customertype3';
              BEGIN
                 SELECT RS.salesrep_id
                 INTO   ln_salesrep_id
                 FROM   ra_salesreps_all RS
                 WHERE  RS.name = 'No Sales Credit'
                 AND    RS.org_id= FND_PROFILE.VALUE('ORG_ID')
                 AND RS.end_date_active IS NULL;
  x_sales_rep_id:=ln_salesrep_id;
                 lc_salesrep:=NULL;
--FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'=========================');
                 --FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' has Salesrep defaulted to No Sales Credit');
FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' "No Sales Credit" Assigned
(CUSTOMERTYPE3): '||lc_customertype3); --subbu_feb26
EXCEPTION
              WHEN TOO_MANY_ROWS THEN
                 x_err_code := 'CUST10';
                 x_err_msg  := 'SalesRep Derivation has returned multiple rows for No Sales Credit';
              --Reject the Record
              WHEN NO_DATA_FOUND THEN
                 x_err_code := 'CUST10';
                 x_err_msg  := 'SalesRep Derivation has returned no rows for No Sales Credit';
              --Reject the Record
              WHEN OTHERS THEN
                 x_err_code := 'CUST10';
                 x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for No Sales Credit';
              --Reject the Record
            END;
     -- End of Changes V1.5
------------------------------------------------------------------------------
   --Validation to check if the No Sales Credit SalesRep exists in the base table
   ------------------------------------------------------------------------------
   ELSIF ( lc_salesrep = 'No Sales Credit' ) THEN
      BEGIN
         SELECT RS.salesrep_id
         INTO   ln_salesrep_id
         FROM   ra_salesreps_all RS
         WHERE  RS.name = lc_salesrep
         AND    RS.org_id= FND_PROFILE.VALUE('ORG_ID')
         AND RS.end_date_active IS NULL;
 x_sales_rep_id:=ln_salesrep_id;
         lc_salesrep:=NULL;
-- Start of Changes V1.5
         --FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customers with no Salesreps');
         --FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'=========================');
        -- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' has Salesrep defaulted to No Sales Credit');
           FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' "No Sales Credit" Assigned
(CUSTOMERTYPE3): '||lc_customertype3); --subbu_feb26
         -- End of Changes V1.5
EXCEPTION
      WHEN TOO_MANY_ROWS THEN
         x_err_code := 'CUST10';
         x_err_msg  := 'SalesRep Derivation has returned multiple rows for No Sales Credit';
      --Reject the Record
      WHEN NO_DATA_FOUND THEN
         x_err_code := 'CUST10';
         x_err_msg  := 'SalesRep Derivation has returned no rows for No Sales Credit';
      --Reject the Record
      WHEN OTHERS THEN
         x_err_code := 'CUST10';
         x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for No Sales Credit';
      --Reject the Record
      END;
 ELSIF ( lc_too_many_rows = 'N' ) THEN
      ---------------------------------------------------------------------------------------------------------------------
      --Validation to get the Salesrep from usbpcs_threezipterritory for the corresponding plan_type,customertype3 and zip3
      ---------------------------------------------------------------------------------------------------------------------
      BEGIN
         SELECT UT.salesrep
         INTO   lc_salesrep
         FROM   usbpcs_plantype_xref UPX
               ,usbpcs_threezipterritory UT
         WHERE  UPX.bpcs_plantype=UT.plan_type
         AND    UPX.bpcs_plantype=lc_plan_type
         AND    UPX.ora_customer_class=lc_ora_customer_type3
         AND    UT.zip3=lc_zip3;
 EXCEPTION
      WHEN OTHERS THEN
         -- Start of Changes V1.5
         --x_err_code := 'CUST10';
         --x_err_msg  := 'SalesRep Derivation has returned multiple rows for zip3 ';
           BEGIN
              SELECT RS.salesrep_id
              INTO   ln_salesrep_id
              FROM   ra_salesreps_all RS
              WHERE  RS.name = 'No Sales Credit'
              AND    RS.org_id= FND_PROFILE.VALUE('ORG_ID')
              AND RS.end_date_active IS NULL;
x_sales_rep_id:=ln_salesrep_id;
              lc_salesrep:=NULL;
-- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'=========================');
             -- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' has Salesrep defaulted to No Sales Credit');
             FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' "No Sales Credit" Assigned
(BPCS_PLANTYPE): '||lc_plan_type||' - (ORA_CUSTOMER_CLASS): '||lc_ora_customer_type3||' - (ZIP3): '||lc_zip3); --subbu_feb26
 EXCEPTION
           WHEN TOO_MANY_ROWS THEN
              x_err_code := 'CUST10';
              x_err_msg  := 'SalesRep Derivation has returned multiple rows for No Sales Credit';
           --Reject the Record
           WHEN NO_DATA_FOUND THEN
              x_err_code := 'CUST10';
              x_err_msg  := 'SalesRep Derivation has returned no rows for No Sales Credit';
           --Reject the Record
           WHEN OTHERS THEN
              x_err_code := 'CUST10';
              x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for No Sales Credit';
           --Reject the Record
         END;
--Reject the Record
		    /*
			WHEN NO_DATA_FOUND THEN
			-- x_err_code := 'CUST10';
			-- x_err_msg  := 'SalesRep Derivation has returned no rows for zip3';
			--Commented above  by subbu as on Jan 16
			-- Start Added below by subbu as on Jan 16
			-- -- Start of changes V1.3
			--*****************************************
			 BEGIN
			    SELECT RS.salesrep_id
			    INTO   ln_salesrep_id
			    FROM   ra_salesreps_all RS
			    WHERE  RS.name = 'No Sales Credit'
			    AND    RS.org_id= FND_PROFILE.VALUE('ORG_ID')
			    AND RS.end_date_active IS NULL;

			    x_sales_rep_id:=ln_salesrep_id;
			    lc_salesrep:=NULL;

			    -- Start of Changes V1.5
			   -- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customers with no Salesreps');
			    FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'=========================');
			    FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' has Salesrep defaulted
to No Sales Credit');
			    -- End  of Changes V1.5

			 EXCEPTION
			 WHEN TOO_MANY_ROWS THEN
			    x_err_code := 'CUST10';
			    x_err_msg  := 'SalesRep Derivation has returned multiple rows for No Sales Credit';
			 --Reject the Record
			 WHEN NO_DATA_FOUND THEN
			    x_err_code := 'CUST10';
			    x_err_msg  := 'SalesRep Derivation has returned no rows for No Sales Credit';
			 --Reject the Record
			 WHEN OTHERS THEN
			    x_err_code := 'CUST10';
			    x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for No Sales Credit';
			 --Reject the Record
			 END;
			  -- End Added below by subbu as on Jan 16
			  -- -- End of changes V1.3
			  --*****************************************

			 --Reject the Record
		      WHEN OTHERS THEN
			 x_err_code := 'CUST10';
			 x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for zip3 ';
			 --Reject the Record
			 */
         -- End of Changes V1.5
      END;
 IF ( lc_salesrep IS NOT NULL) THEN
         -----------------------------------
         --To get concatenated SalesRep name
         -----------------------------------
         BEGIN
            SELECT USX.orc_salesrep_lname||', '||USX.orc_salesrep_fname
            INTO   lc_ora_salesrep
            FROM   usbpcs_threezipterritory UT
                  ,usbpcs_salesrep_xref USX
            WHERE  UT.salesrep=USX.BPCS_SALESREP
            AND    UT.salesrep=lc_salesrep
            AND    UT.zip3=lc_zip3
            AND    UT.plan_type=lc_plan_type;
 EXCEPTION
		-- WHEN TOO_MANY_ROWS THEN
		   -- x_err_code := 'CUST10';
		  --  x_err_msg  := 'SalesRep Derivation has returned multiple rows for plan_type ';
		    --Reject the Record
		 --WHEN NO_DATA_FOUND THEN
		   -- x_err_code := 'CUST10';
		   -- x_err_msg  := 'SalesRep Derivation has returned no rows for plan_type';
		    --Reject the Record
 WHEN OTHERS THEN
              -- Start of Changes V1.5
              -- x_err_code := 'CUST10';
              -- x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for plan_type';
              --Reject the Record
              --x_err_code := 'CUST10';
              --x_err_msg  := 'SalesRep Derivation has returned multiple rows for zip3 ';
                BEGIN
                   SELECT RS.salesrep_id
                   INTO   ln_salesrep_id
                   FROM   ra_salesreps_all RS
                   WHERE  RS.name = 'No Sales Credit'
                   AND    RS.org_id= FND_PROFILE.VALUE('ORG_ID')
                   AND RS.end_date_active IS NULL;
 x_sales_rep_id:=ln_salesrep_id;
                   lc_salesrep:=NULL;
 -- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'=========================');
                  --  FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' has Salesrep defaulted to No Sales Credit');
                  FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' "No Sales Credit" Assigned
(SALESREP): '||lc_salesrep||' - (PLAN_TYPE): '||lc_plan_type||' - (ZIP3): '||lc_zip3); --subbu_feb26
 EXCEPTION
                WHEN TOO_MANY_ROWS THEN
                   x_err_code := 'CUST10';
                   x_err_msg  := 'SalesRep Derivation has returned multiple rows for No Sales Credit';
                --Reject the Record
                WHEN NO_DATA_FOUND THEN
                   x_err_code := 'CUST10';
                   x_err_msg  := 'SalesRep Derivation has returned no rows for No Sales Credit';
                --Reject the Record
                WHEN OTHERS THEN
                   x_err_code := 'CUST10';
                   x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for No Sales Credit';
                --Reject the Record
              END;
              -- End of Changes V1.5
         END;
      END IF; --End of lc_salesrep IS NOT NULL
IF ( lc_ora_salesrep IS NOT NULL) THEN
         ---------------------------------------------------------------
         --Validation to check if the Salesrep name exists in the system
         ---------------------------------------------------------------
         BEGIN
            SELECT RS.salesrep_id
            INTO   ln_salesrep_id
            FROM   ra_salesreps_all RS
            WHERE  RS.name = lc_ora_salesrep
            AND    RS.org_id= FND_PROFILE.VALUE('ORG_ID')
            AND RS.end_date_active IS NULL;
x_sales_rep_id :=  ln_salesrep_id;
         EXCEPTION
-- Start of Changes V1.5
         	--  WHEN TOO_MANY_ROWS THEN
         	--   x_err_code := 'CUST10';
         	--   x_err_msg  := 'SalesRep Derivation has returned multiple rows from base table';
         WHEN OTHERS THEN
           	 --x_err_code := 'CUST10';
           	 -- x_err_msg  := 'SalesRep Derivation has returned no rows from base table';
           	 -- Start of Changes V1.5
	            BEGIN
	               SELECT RS.salesrep_id
	               INTO   ln_salesrep_id
	               FROM   ra_salesreps_all RS
	               WHERE  RS.name = 'No Sales Credit'
	               AND    RS.org_id= FND_PROFILE.VALUE('ORG_ID')
	               AND RS.end_date_active IS NULL;
 x_sales_rep_id:=ln_salesrep_id;
	               lc_salesrep:=NULL;
-- Start of Changes V1.5
	               -- FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customers with no Salesreps');
	   	       --  FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'=========================');
      --  FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' has Salesrep defaulted to No Sales Credit');
	                FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customer :'||gc_organization_name ||' "No Sales Credit" Assigned
(SALESRE NAME) ): '||lc_ora_salesrep); --subbu_feb26
	               -- End  of Changes V1.5
 EXCEPTION
	            WHEN TOO_MANY_ROWS THEN
	               x_err_code := 'CUST10';
	               x_err_msg  := 'SalesRep Derivation has returned multiple rows for No Sales Credit';
	            --Reject the Record
	            WHEN NO_DATA_FOUND THEN
	               x_err_code := 'CUST10';
	               x_err_msg  := 'SalesRep Derivation has returned no rows for No Sales Credit';
	            --Reject the Record
	            WHEN OTHERS THEN
	               x_err_code := 'CUST10';
	               x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId for No Sales Credit';
	            --Reject the Record
                  END;
 --WHEN OTHERS THEN
       		 --     x_err_code := 'CUST10';
       		 --  x_err_msg  := 'SalesRep Derivation has errors while deriving the SalesRepId  from base table';
         END;
      END IF; --End of lc_ora_salesrep IS NOT NULL
      -- End of Changes V1.5
 END IF; --End of lc_salesrep = 'No Sales Credit'
EXCEPTION
WHEN OTHERS THEN
   x_err_code := sqlcode;
   x_err_msg  := sqlerrm;
END XXHA_VALIDATE_SALESREP;
-- End of changes V1.2
--+=============================================================================+
--| Name        :   CHECK_CUST_SETUP                                            |
--|                                                                             |
--| Description :   Procedure to validate the setup                             |
--|                                                                             |
--|                                                                             |
--| PARAMETERS:                                                                 |
--|   IN:    None                                                               |
--|  OUT:    x_err_buf                                                          |
--|         ,x_ret_code                                                         |
--|         ,x_setup_err_flag                                                   |
--|                                                                             |
--|                                                                             |
--| Returns :                                                                   |
--+=============================================================================+
PROCEDURE CHECK_CUST_SETUP (
                            x_err_buf        OUT VARCHAR2
                           ,x_ret_code       OUT NUMBER
                           ,x_setup_err_flag OUT VARCHAR2
                           )
IS
-- Local Variable Declaration
lc_credit_rating     ar_lookups.lookup_code%TYPE;        --Variable to hold Credit Rating Look Up Code
lc_risk_code         ar_lookups.lookup_code%TYPE;        --Variable to hold Risk Code Look Up Code
lc_profile_classes   hz_cust_profile_classes.name%TYPE;  --Variable to hold Profile Class Name
BEGIN
   --Reinitialize the Variables
   gc_status_flag    :=NULL;
   lc_credit_rating  :=NULL;
   lc_risk_code      :=NULL;
   lc_profile_classes:=NULL;
   ------------------------------
   -- Validate the Credit Rating
   ------------------------------
   BEGIN
      SELECT  AL.lookup_code
      INTO    lc_credit_rating
      FROM    ar_lookups  AL
      WHERE   AL.lookup_type  = 'CREDIT_RATING'
      AND     AL.lookup_code  = 'AVERAGE'
      AND     SYSDATE BETWEEN NVL(AL.start_date_active,SYSDATE) AND NVL(AL.end_date_active,SYSDATE)
      AND     AL.enabled_flag = 'Y';
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      gc_status_flag      :=  'VE';
      gc_error_code       :=  'SETUP-Error';
      gc_error_msg        :=  'The AVERAGE Lookup Code has not been defined for the CREDIT_RATING Lookup Type';
      gc_comments         :=   NULL;
      INSERT_ERROR_PRC;
   WHEN OTHERS THEN
      gc_status_flag      :=  'VE';
      gc_error_code       :=  'SETUP-Error'||' / '||SQLCODE;
      gc_error_msg        :=   SQLERRM;
      gc_comments         :=   NULL;
      INSERT_ERROR_PRC;
   END;
   IF  (gc_status_flag IS NOT NULL) THEN
      gc_log_msg:='Flag returned by the Credit Rating Validation IS '||gc_status_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   END IF;
-------------------------
   -- Validate the Risk Code
   -------------------------
   BEGIN
      SELECT  AL.lookup_code
      INTO    lc_risk_code
      FROM    ar_lookups  AL
      WHERE   AL.lookup_type =   'RISK_CODE'
      AND     AL.lookup_code =   'DEFAULT'
      AND     SYSDATE BETWEEN NVL(AL.start_date_active,SYSDATE) AND NVL(AL.end_date_active,SYSDATE)
      AND     AL.enabled_flag    =   'Y';
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      gc_status_flag      :=  'VE';
      gc_error_code       :=  'SETUP-Error';
      gc_error_msg        :=  'The DEFAULT Lookup Code has not been defined for the RISK_CODE Lookup Type';
      gc_comments         :=   NULL;
      INSERT_ERROR_PRC;
   WHEN OTHERS THEN
      gc_status_flag      :=  'VE';
      gc_error_code       :=  'SETUP-Error'||' / '||SQLCODE;
      gc_error_msg        :=   SQLERRM;
      gc_comments         :=   NULL;
      INSERT_ERROR_PRC;
   END;
   IF (gc_status_flag  IS NOT NULL) THEN
      gc_log_msg:='Flag returned by the Risk Code Validation IS '||gc_status_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   END IF;
-----------------------------
   -- Validate the profile class
   -----------------------------
   BEGIN
      SELECT  HCPC.name
      INTO    lc_profile_classes
      FROM    hz_cust_profile_classes HCPC
      -- Start of changes V1.1
      WHERE   UPPER(HCPC.name) =   'DEFAULT'
      -- End of changes V1.1
      AND     HCPC.status      =   'A';
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      gc_status_flag      :=  'VE';
      gc_error_code       :=  'SETUP-Error';
      gc_error_msg        :=  'The DEFAULT Profile Class has not been defined';
      gc_comments         :=   NULL;
      INSERT_ERROR_PRC;
   WHEN OTHERS THEN
      gc_status_flag      :=  'VE';
      gc_error_code       :=  'SETUP-Error'||' '||SQLCODE;
      gc_error_msg        :=   SQLERRM;
      gc_comments         :=   NULL;
      INSERT_ERROR_PRC;
   END;
   IF (gc_status_flag IS NOT NULL) THEN
      gc_log_msg:='Flag returned by the Profile Classes Validation IS '||gc_status_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   END IF;
IF (gc_status_flag  IS NULL) THEN
      gc_status_flag  :='VS';
      gc_log_msg:='Validation for Setup Is Successful - Patrick';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      x_setup_err_flag:='N';
   ELSE
      gc_log_msg:='Validation for Setup Is NOT Successful';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
      x_setup_err_flag:='Y';
      x_ret_code:=2;
   END IF;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_AR_CUST_CONV_PK.CHECK_CUST_SETUP: ' || SQLERRM);
   xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
   ROLLBACK;
   x_ret_code:=2;
END CHECK_CUST_SETUP;
--+=============================================================================+
--| Name        :   VALIDATE_CUST_DATA                                          |
--|                                                                             |
--| Description :   Procedure to validate the data which is in the staging table|
--|                                                                             |
--|                                                                             |
--| PARAMETERS:                                                                 |
--|   IN:    None                                                               |
--|  OUT:    x_err_buf                                                          |
--|          x_ret_code                                                         |
--|                                                                             |
--| Returns :                                                                   |
--+=============================================================================+
PROCEDURE   VALIDATE_CUST_DATA(
                               x_err_buf   OUT VARCHAR2
                              ,x_ret_code  OUT NUMBER
                              )
IS
------------------------------
-- Local Variables Declaration
------------------------------
lc_customer_type1   ar_lookups.lookup_code%TYPE;                  --Variable to hold CUSTOMER_TYPE Look Up Code
lc_customer_type2   ar_lookups.lookup_code%TYPE;                  --Variable to hold ADDRESS_CATEGORY Look Up Code
lc_customer_type3   ar_lookups.lookup_code%TYPE;                  --Variable to hold CUSTOMER CLASS Look Up Code
lc_destination      ar_lookups.lookup_code%TYPE;                  --Variable to hold FOB Look Up Code
ln_term_id          ra_terms_vl.term_id%TYPE;                     --Variable to hold Term Id
ln_salesrep_id      ra_salesreps.salesrep_id%TYPE;                --Variable to hold Sales Rep Id
lc_currency_code    fnd_currencies.currency_code%TYPE;            --Variable to hold Currency code
lc_language_code    fnd_languages.language_code%TYPE;             --Variable to hold Language code
ln_prev_cust_no     hz_cust_accounts.orig_system_reference%TYPE;  --Variable to hold the Customer Number
ln_count_validated  NUMBER;                                       --Variable to hold the number of records which have been validated
ln_count_passed_val NUMBER;                                       --Variable to hold the number of records which have passed validation
ln_count_error      NUMBER;                                       --Variable to hold the number of records which have failed validation
ln_ship_cnt         NUMBER;
ln_freight_cnt      NUMBER;
ln_tax_cnt           NUMBER;
ln_list_header_id  NUMBER;
------------------------------------------------------------------------------------------------
-- Cursor to select customer records from HAEMO_CUSTOMERS table for a particular operating unit
------------------------------------------------------------------------------------------------
CURSOR   lcu_customer_data IS
SELECT   HC.*
FROM     haemo_customers HC
WHERE    HC.charuserfld5 =  gc_operating_unit_name
AND      HC.oraclecharfld1  IS NULL
ORDER BY HC.customernbr,HC.customershipto;
--------------------------------------------------
 --Cursor to check if price list is already defined
 --------------------------------------------------
 CURSOR lcu_chk_price_list(p_price_list VARCHAR2)
 IS
  SELECT b.list_header_id
  FROM   qp_list_headers_tl QLHT
       , qp_list_headers_b b
  WHERE  QLHT.name=p_price_list
  and    b.list_header_id= QLHT.list_header_id
  --Start of Changes 1.6
  and trunc(sysdate) between NVL(trunc(b.start_date_active),trunc(sysdate)) and NVL(trunc(b.end_date_active),trunc(sysdate));
  --End of Changes 1.6
/* SELECT list_header_id
 FROM   qp_list_headers_tl QLHT
 WHERE  QLHT.name=p_price_list
 and trunc(sysdate) between NVL(trunc(start_date_active),trunc(sysdate)) and NVL(trunc(end_date_active),trunc(sysdate));*/
BEGIN
   --------------------------------------------
   -- Selecting the current Operating Unit name
   --------------------------------------------
   BEGIN
      SELECT  HOU.name
      INTO    gc_operating_unit_name
      FROM    hr_operating_units  HOU
      WHERE   HOU.organization_id   =  FND_PROFILE.VALUE('ORG_ID');
   EXCEPTION
   WHEN    NO_DATA_FOUND   THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Operating Unit Does not Exist in the Applications');
      x_ret_code := 2;
   END;
 --Reinitialize the Variables
   ln_prev_cust_no :=0;
 FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Customers with no Salesreps');
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'===========================');
   -----------------------------------------------
   -- FOR loop for Validating the Customer records
   -----------------------------------------------
   FOR lr_customer_data   IN  lcu_customer_data   --Start of lcu_customer_data Loop
   LOOP
 gn_record_id         :=  lr_customer_data.oracleidentifier;
      gn_record_number     :=  lr_customer_data.oracleidentifier;
      gc_err_rec_identifier:=  lr_customer_data.customernbr||'-'||lr_customer_data.customershipto;
      gc_status_flag       :=  NULL;
      lc_customer_type3    :=  NULL;
      lc_customer_type1    :=  NULL;
      lc_customer_type2    :=  NULL;
      ln_term_id           :=  NULL;
      ln_salesrep_id       :=  NULL;
      lc_currency_code     :=  NULL;
      lc_language_code     :=  NULL;
      lc_destination       :=  NULL;
      --V1.8 Start of Changes
ln_list_header_id    :=NULL;
      --V1.8 Start of Changes
---------------------
      -- Validate Pricelist
      ---------------------
      --Start of Changes V1.6
      IF (lr_customer_data.charuserfld14 IS NOT NULL) AND (lr_customer_data.CountryCode <> 'US') THEN
         ln_list_header_id:=NULL;
         OPEN  lcu_chk_price_list(lr_customer_data.charuserfld14);
         FETCH lcu_chk_price_list INTO ln_list_header_id;
            IF lcu_chk_price_list%NOTFOUND THEN
               --Log error message
               gc_status_flag      :=  'VE';
               gc_error_code       :='CUST22';
               gc_error_msg        :='Price List Name: '||lr_customer_data.charuserfld14||' does not exists in Oracle for the
Customer Number: '||lr_customer_data.customernbr;
               INSERT_ERROR_PRC;
             --Also add header information  FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Price List Name: '||lr_customer_data.charuserfld14||' does not exists in Oracle for the Customer Number: '||lr_customer_data.customernbr	);
END IF;
         CLOSE lcu_chk_price_list;
      END IF;
      --End of Changes V1.6
-------------------------
      -- Validate Customer Name
      -------------------------
      IF  (lr_customer_data.customername IS NULL) THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST01';
         gc_error_msg        :=  'Customer Name has not been provided in the staging table for the Customer Number:
'||lr_customer_data.customernbr;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      IF (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the Customer Name Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
      --------------------------
      -- Validate Customer Class
      --------------------------
      BEGIN
         IF (lr_customer_data.CustomerType3   IS NOT NULL) THEN
            SELECT  AL.lookup_code
            INTO    lc_customer_type3
            FROM    ar_lookups  AL
            -- Start of changes V1.1
            WHERE   UPPER(AL.meaning)  =   UPPER(lr_customer_data.CustomerType3)
            -- End of changes V1.1
            AND     AL.lookup_type     =   'CUSTOMER CLASS'
            AND     SYSDATE BETWEEN NVL(AL.start_date_active,SYSDATE) AND NVL(AL.end_date_active,SYSDATE)
            AND     AL.enabled_flag    =   'Y';
         -- Start of changes V1.2
         ELSE
            gc_status_flag      :=  'VE';
            gc_error_code       :=  'CUST02';
            --gc_error_msg        :=  'The CustomerType3 should be provided in the Staging Table column CustomerType3';
            gc_error_msg        :=  'Field CUSTOMERTYPE3 is holding NULL in the staging table for the Customer:
'||lr_customer_data.customername;
            gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END IF;
         -- End of changes V1.2
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST02';
         --gc_error_msg        :=  'The value in CustomerType3: ' ||lr_customer_data.CustomerType3||' has not been defined for the CUSTOMER CLASS Lookup Type';
         gc_error_msg        :=  'No Data found in the Lookup table for field CUSTOMERTYPE3:
'||lr_customer_data.CustomerType3||' against the lookup type CUSTOMER CLASS for the customer:
'||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      WHEN OTHERS THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST02'||' / '||SQLCODE;
         gc_error_msg        :=   SQLERRM;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END;
      IF (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the CustomerType3 Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
-------------------------------------------
      --Validate Term Code and derive the Term Id
      -------------------------------------------
      --V1.8 Start of Changes
      IF NVL(lr_customer_data.customershipto,0)=0 THEN --for BILL_TO
      --V1.8 End of Changes
	      BEGIN
		 IF (lr_customer_data.termscodedesc IS NOT NULL) THEN
		    SELECT  RT.term_id
		    INTO    ln_term_id
		    FROM    ra_terms_vl  RT
			   ,haemo_terms_code HTC
		    -- Start of changes V1.1
		    WHERE   UPPER(HTC.bpcs_term_code_desc) =   UPPER(lr_customer_data.termscodedesc)
		    -- End of changes V1.1
		    AND     ROWNUM  =   1
		    AND     RT.name =   HTC.oracle_term_code ;
		 ELSE
		    gc_status_flag      :=  'VE';
		    gc_error_code       :=  'CUST03';
		    --gc_error_msg        :=  'The Payment Term should be provided in the Staging Table column termscodedesc';
		    gc_error_msg        :=  'The Payment Term should be provided in the Staging Table column termscodedesc
for the Customer: '||lr_customer_data.customername;
		    gc_comments         :=   NULL;
		    INSERT_ERROR_PRC;
		 END IF;
	      EXCEPTION
	      WHEN NO_DATA_FOUND THEN
		 gc_status_flag      :=  'VE';
		 gc_error_code       :=  'CUST03';
		 --gc_error_msg        :=  'NThe value in Termscodedesc: '||lr_customer_data.termscodedesc||' is not a valid Payment Term';
		 gc_error_msg        :=  'No Data found for the Payment Term( Field TERMSCODEDESC):
'||lr_customer_data.termscodedesc||' for the Customer: '||lr_customer_data.customername;
		 gc_comments         :=   NULL;
		 INSERT_ERROR_PRC;
	      WHEN OTHERS THEN
		 gc_status_flag      :=  'VE';
		 gc_error_code       :=  'CUST03'||' / '||SQLCODE;
		 gc_error_msg        :=   SQLERRM;
		 gc_comments         :=   NULL;
		 INSERT_ERROR_PRC;
	      END;
	END IF;
IF  (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the Termscodedesc Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
--------------------
      -- Validate Address1
      --------------------
      IF (lr_customer_data.AddressLine1    IS NULL) THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST04';
         gc_error_msg        :=  'Field ADDRESS1  id holding NULL in the staging table for the Customer:
'||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      IF (gc_status_flag  IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the AddressLine1 Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
----------------
      -- Validate City
      ----------------
      -- Start of changes V1.1
      IF (lr_customer_data.City IS NULL AND UPPER(lr_customer_data.CountryCode) = 'US') THEN
      -- End of changes V1.1
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST05';
         --gc_error_msg        :=  'City has not been provided in the staging table';
         gc_error_msg        :=  'Fiels CITY is holding NULL for the Country code: '||lr_customer_data.CountryCode||' for the
customer: '||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      IF (gc_status_flag  IS  NOT NULL) THEN
         gc_log_msg:='Flag returned by the City Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
-----------------
      -- Validate State
      -----------------
      -- Start of changes V1.1
      IF (lr_customer_data.State  IS NULL AND UPPER(lr_customer_data.CountryCode) = 'US') THEN
      -- End of changes V1.1
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST06';
         --gc_error_msg        :=  'State has not been provided in the staging table';
         gc_error_msg        :=  'Field STATE is holding NULL for the Country code: '||lr_customer_data.CountryCode||' for
the customer: '||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      IF (gc_status_flag IS NOT NULL) THEN
         gc_log_msg  :=  'Flag returned by the State Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
----------------------
      -- Validate the County
      ----------------------
      -- Start of changes V1.1
      IF (lr_customer_data.CountyRegion  IS NULL AND UPPER(lr_customer_data.CountryCode) = 'US') THEN
      -- End of changes V1.1
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST07';
         --gc_error_msg        :=  'County has not been provided in the staging table';
         gc_error_msg        :=  'Field County is holding NULL for the Country code: '||lr_customer_data.CountryCode||' for
the customer: '||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      IF  (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the CountyRegion Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
-----------------------
      -- Validate Postal Code
      -----------------------
      -- Start of changes V1.1
      IF  (lr_customer_data.PostalCode IS NULL AND UPPER(lr_customer_data.CountryCode) = 'US') THEN
      -- End of changes V1.1
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST08';
         --gc_error_msg        :=  'Field Postal Code has not been provided in the staging table';
         gc_error_msg        :=  'Field POSTALCODE is holding NULL for the Country code: '||lr_customer_data.CountryCode||'
for the customer: '||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      IF (gc_status_flag  IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the PostalCode Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
------------------------
      -- Validate Country code
      ------------------------
      IF (lr_customer_data.CountryCode IS NULL) THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST09';
         --gc_error_msg        :=  'Field Country Code has not been provided in the staging table';
         gc_error_msg        :=  'Field COUNTRYCODE is holding NULL in the staging table for the customer:
'||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      IF (gc_status_flag  IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the Country Code Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
-- Start of changes V1.2
      --------------------------
      -- Validate Sales Man Name
      --------------------------
    /*  BEGIN
      IF (lr_customer_data.salesmanname IS NOT NULL) THEN
         SELECT  RS.salesrep_id
         INTO    ln_salesrep_id
         FROM    ra_salesreps    RS
         WHERE   RS.name  = lr_customer_data.salesmanname;
      END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         ln_salesrep_id        :=  NULL;
         --Based on the clarification log it has been commented out and This is would be used latter
         --gc_status_flag      :=  'VE';
         --gc_error_code       :=  'CUST10';
         --gc_error_msg        :=  'SalesRep has not been defined';
         --gc_comments         :=   NULL;
         --INSERT_ERROR_PRC;
      WHEN OTHERS THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST10'||' '||SQLCODE;
         gc_error_msg        :=   SQLERRM;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END;
      IF  (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the Salesmanname Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;*/
--***********************************************************************************************************8*
-- Start of Changes V1.5
       --IF lr_customer_data.countrycode='US' THEN
       --Commented the above and changed to below as the countrycode store US even for NON operating unit
       IF TRIM(lr_customer_data.charuserfld5) = 'Haemonetics Corp US OU' THEN
       -- End of Changes V1.5
gc_organization_name :=lr_customer_data.customername; --added by subbu
-- 1.19 - BMarcoux - Code Removed
--          IF lr_customer_data.customershipto<>0 THEN
	               --  End of changes V1.3

/*	    XXHA_VALIDATE_SALESREP( p_rec_num      => lr_customer_data.oracleidentifier           */
/*	  	     	           ,x_sales_rep_id => ln_salesrep_id                                    */
/*				   ,x_err_code     => gc_error_code                                                 */
/*				   ,x_err_msg      => gc_error_msg                                                  */
/*				   );                                                                               */

/*	     gc_log_msg:='ln_salesrep_id IS '||ln_salesrep_id;                                    */
/*	     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);                   */

/*	     IF (ln_salesrep_id IS NULL) THEN                                                     */
/*      		 gc_status_flag      :=  'VE';                                                    */
/*      		 gc_error_code       :=  gc_error_code;                                           */
/*      		 gc_error_msg        :=  gc_error_msg;                                            */
/*      		 gc_comments         :=   NULL;                                                   */
/*      		 INSERT_ERROR_PRC;                                                                */
/*	     END IF;                                                                              */
-- 1.19 - BMarcoux - Start of new code
            IF lr_customer_data.salesmanname IS NOT NULL THEN
	             BEGIN
	                SELECT RS.salesrep_id
	                INTO   ln_salesrep_id
	                FROM   ra_salesreps_all RS
	   	            WHERE  RS.name            = lr_customer_data.salesmanname
	   	            AND    RS.org_id          = FND_PROFILE.VALUE('ORG_ID')
	   	            AND    RS.end_date_active IS NULL;
	   	         EXCEPTION
	   	            WHEN OTHERS THEN
	    	               BEGIN
      		                gc_status_flag      :=  'VE';
      		                gc_error_code       :=  'CUST19';
      		                gc_error_msg        :=  'SalesmanName is Invalid: '|| lr_customer_data.salesmanname;

      		                gc_comments         :=   NULL;
      		                INSERT_ERROR_PRC;
 	                     EXCEPTION
 	                        WHEN OTHERS THEN
	   		                       gc_status_flag      :=  'VE';
	   		                       gc_error_code       :=  'CUST20';
	   		                       gc_error_msg        :=  'SalesRep Derivation has errors while deriving the
SalesRep No Sales Credit';
	   		                       gc_comments         :=   NULL;
	   		                       INSERT_ERROR_PRC;
	   	                 END;
		           END;
            END IF; -- IF lr_customer_data.salesmanname IS NOT NULL

            ELSE
	             NULL;
-- 1.19 - BMarcoux - Code Removed
--          END IF;--lr_customer_data.customershipto<>0

       END IF;-- IF TRIM(lr_customer_data.charuserfld5) = 'Haemonetics Corp US OU' THEN
--***********************************************************************************************************8*
-- End of changes V1.2
      -------------------------
      -- Validate Customer Type
      -------------------------
      BEGIN
         IF (lr_customer_data.CustomerType1 IS NOT NULL ) THEN
            SELECT  AL.lookup_code
            INTO    lc_customer_type1
            FROM    ar_lookups  AL
            -- Start of changes V1.1
            WHERE   UPPER(AL.meaning)  =   UPPER(lr_customer_data.CustomerType1)
            -- End of changes V1.1
            AND     AL.lookup_type     =   'CUSTOMER_TYPE'
            AND     SYSDATE BETWEEN NVL(AL.start_date_active,SYSDATE) AND NVL(AL.end_date_active,SYSDATE)
            AND     AL.enabled_flag    =   'Y';
         -- Start of changes V1.2
         ELSE
            gc_status_flag      :=  'VE';
            gc_error_code       :=  'CUST11';
            gc_error_msg        :=  'Field CUSTOMERTYPE1(Customer Type) should be provided in the Staging Table for the
Customer: '||lr_customer_data.customername;
            gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END IF;
         -- End of changes V1.2
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST11';
         --gc_error_msg        :=  'The value in CustomerType1: ' ||lr_customer_data.CustomerType1||' has not been defined for the CUSTOMER_TYPE Lookup Type';
         gc_error_msg        :=  'No Data found in the LOOKUP table for the field CUSTOMERTYPE1(Customer Type):
'||lr_customer_data.CustomerType1||' for the customer: '||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      WHEN OTHERS THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST11'||' / '||SQLCODE;
         gc_error_msg        :=   SQLERRM;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END;
      IF (gc_status_flag  IS  NOT NULL) THEN
         gc_log_msg:='Flag returned by the CustomerType1 Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
      -------------------------
      -- Validate Currency Code
      -------------------------
      BEGIN
         IF (lr_customer_data.currencycode    IS  NOT NULL   AND NVL(lr_customer_data.CustomerShipTo,0) = 0 ) THEN
            SELECT  FC.currency_code
            INTO    lc_currency_code
            FROM    fnd_currencies  FC
            -- Start of changes V1.1
            WHERE   UPPER(FC.currency_code)   = UPPER(lr_customer_data.currencycode);
            -- End of changes V1.1
         ELSIF (lr_customer_data.currencycode    IS  NULL   AND NVL(lr_customer_data.CustomerShipTo,0) = 0) THEN
            gc_status_flag      :=  'VE';
            gc_error_code       :=  'CUST12';
            gc_error_msg        :=  'Field CURRENCYCODE is NULL in the staging table for Customer:
'||lr_customer_data.customername;
            gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST12';
         gc_error_msg        :=  'No Data found for the Currency Code: '||lr_customer_data.currencycode||' for the Customer:
'||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      WHEN OTHERS THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST12'||' / '||SQLCODE;
         gc_error_msg        :=   SQLERRM;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END;
      IF (gc_status_flag  IS  NOT NULL) THEN
         gc_log_msg:='Flag returned by the Currency Code Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
---------------------------------
      -- Validate Customer Category Code
      ----------------------------------
      BEGIN
         IF (lr_customer_data.CustomerType2   IS NOT NULL) THEN
            SELECT  AL.lookup_code
            INTO    lc_customer_type2
            FROM    ar_lookups  AL
            -- Start of changes V1.1
            WHERE   UPPER(AL.meaning)     =   UPPER(lr_customer_data.CustomerType2)
            -- End of changes V1.1
            -- Start of changes V1.2
            AND     AL.lookup_type        =   'CUSTOMER_CATEGORY'
            -- End of changes V1.2
            AND     SYSDATE BETWEEN NVL(AL.start_date_active,SYSDATE) AND NVL(AL.end_date_active,SYSDATE)
            AND     AL.enabled_flag    =   'Y';
         -- Start of changes V1.2
         ELSE
            gc_status_flag      :=  'VE';
            gc_error_code       :=  'CUST13';
            gc_error_msg        :=  'Field CUSTOMERTYPE2(Customer Category Code) is NULL in the Staging Table for the
Customer: '||lr_customer_data.customername;
            gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END IF;
         -- End of changes V1.2
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST13';
         --gc_error_msg        :=  'The value in CustomerType2: ' ||lr_customer_data.CustomerType2||' has not been defined for the CUSTOMER_CATEGORY Lookup Type';
         gc_error_msg        :=  'No Data found in Lookup table for field CUSTOMERTYPE2(Customer Category Code):
'||lr_customer_data.CustomerType2||' for the Customer: '||lr_customer_data.customername;
gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      WHEN OTHERS THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST13'||' / '||SQLCODE;
         gc_error_msg        :=   SQLERRM;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END;
      IF (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the Customer Category Code Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
---------------------------------------------------------------
      -- Validation to check whether each Customer has Bill To or not
      ---------------------------------------------------------------
IF (ln_prev_cust_no <> lr_customer_data.customernbr) THEN
         IF (NVL(lr_customer_data.customershipto,0) = 0) THEN
            NULL;
            gc_log_msg:='Flag returned by the BILL TO Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         ELSE
            gc_status_flag      :=  'VE';
            gc_error_code       :=  'CUST14';
            gc_error_msg        :=  'BILL TO does not exist for this customer: '||lr_customer_data.customername;
            gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END IF;
        ln_prev_cust_no  :=lr_customer_data.customernbr;
      END IF;
IF (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the BILL TO Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
-----------------------------------
      -- Validate  party and charuserfld4
      -----------------------------------
       IF (lr_customer_data.party IS NOT NULL) THEN
         IF (lr_customer_data.charuserfld4 IS NULL) THEN
            gc_status_flag      :=  'VE';
            gc_error_code       :=  'CUST15';
            gc_error_msg        :=  'The Party has been specified but the Party Name has not been provided in field
CHARUSERFLD4 for the Customer: '||lr_customer_data.customername;
            gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END IF;
      END IF;
      IF  (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the Party Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
--------------------
      -- Validate language
      --------------------
      BEGIN
      IF (lr_customer_data.language IS NOT NULL) THEN
         SELECT  FL.language_code
         INTO    lc_language_code
         FROM    fnd_languages  FL
         -- Start of changes V1.1
         WHERE   UPPER(FL.language_code)    =   UPPER(lr_customer_data.language);
         -- End of changes V1.1
      -- Start of changes V1.2
      ELSE
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST16';
         gc_error_msg        :=  'Field LANGUAGE is NULL in the Staging Table for the Customer:
'||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END IF;
      -- End of changes V1.2
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST16';
         gc_error_msg        :=  'No Data found for the Language: '||lr_customer_data.language||' for the Customer:
'||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      WHEN OTHERS THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST16'||' / '||SQLCODE;
         gc_error_msg        :=   SQLERRM;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END;
      IF  gc_status_flag IS NOT NULL THEN
         gc_log_msg:='Flag returned by the Language Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
-- Start of changes V1.1 -- Added Validation for FOB
      -------------------------
      -- Validate FOB
      -------------------------
      BEGIN
         IF (lr_customer_data.destination   IS NOT NULL) THEN
            SELECT  AL.lookup_code
            INTO    lc_destination
            FROM    ar_lookups  AL
            WHERE   AL.lookup_code     =   lr_customer_data.destination
            AND     AL.lookup_type     =   'FOB'
            AND     SYSDATE BETWEEN NVL(AL.start_date_active,SYSDATE) AND NVL(AL.end_date_active,SYSDATE)
            AND     AL.enabled_flag    =   'Y';
         END IF;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST17';
         gc_error_msg        :=  'No Data found in the lookup table for field DESTINATION(FOB):
'||lr_customer_data.destination||' for the Customer: '||lr_customer_data.customername;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      WHEN OTHERS THEN
         gc_status_flag      :=  'VE';
         gc_error_code       :=  'CUST17'||' / '||SQLCODE;
         gc_error_msg        :=   SQLERRM;
         gc_comments         :=   NULL;
         INSERT_ERROR_PRC;
      END;
      IF (gc_status_flag IS NOT NULL) THEN
         gc_log_msg:='Flag returned by the FOB Validation IS '||gc_status_flag||' ,Oracleidentifier -
'||lr_customer_data.oracleidentifier;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
      -- End of changes V1.1
-- Start of changes V1.18
      ---------------------------
      -- Validate FREIGHT TERMS
      --------------------------
      BEGIN
         IF TRIM(lr_customer_data.charuserfld13) IS NOT NULL THEN

           SELECT  COUNT(*)
             INTO  ln_freight_cnt
             FROM  SO_LOOKUPS
            WHERE  LOOKUP_TYPE = 'FREIGHT_TERMS'
              AND  ENABLED_FLAG = 'Y'
              AND  TRUNC(SYSDATE) BETWEEN NVL(START_DATE_ACTIVE, TRUNC(SYSDATE))
              AND  NVL(END_DATE_ACTIVE, TRUNC(SYSDATE))
              AND  LOOKUP_CODE = lr_customer_data.charuserfld13;

          IF ln_freight_cnt =0 then
             gc_status_flag      :=  'VE';
	     gc_error_code       :=  'CUST23';
	     gc_error_msg        :=  'No data found for Freight Terms code: ' ||lr_customer_data.charuserfld13||' for the
Customer: '||lr_customer_data.customername;
	     gc_comments         :=   NULL;
             INSERT_ERROR_PRC;
          END IF;
         END IF;
EXCEPTION
      WHEN NO_DATA_FOUND THEN
          gc_status_flag      :=  'VE';
          gc_error_code       :=  'CUST23';
          gc_error_msg        :=  'Freight Terms code: ' ||lr_customer_data.charuserfld13||' has not been defined in the
lookup table';
          gc_comments         :=   NULL;
          INSERT_ERROR_PRC;
       WHEN OTHERS THEN
          gc_status_flag      :=  'VE';
          gc_error_code       :=  'CUST23'||' / '||SQLCODE;
          gc_error_msg        :=   SQLERRM;
          gc_comments         :=   NULL;
          INSERT_ERROR_PRC;
       END;
      -- End of changes V1.18
-- Start of changes V1.3
      ---------------------------
      -- Validate SHIPPING METHOD
      --------------------------
      BEGIN
         IF TRIM(lr_customer_data.charuserfld12) IS NOT NULL THEN

      	    SELECT count(*)
      	    INTO  ln_ship_cnt
      	    FROM  oe_ship_methods_v
      	    WHERE lookup_type='SHIP_METHOD'
      	    AND   lookup_code=lr_customer_data.charuserfld12;

          IF ln_ship_cnt =0 then
             gc_status_flag      :=  'VE';
	     gc_error_code       :=  'CUST18';
	     gc_error_msg        :=  'No data found for Shipping Method code: ' ||lr_customer_data.charuserfld12||' for the
Customer: '||lr_customer_data.customername;
	     gc_comments         :=   NULL;
             INSERT_ERROR_PRC;
          END IF;
         END IF;
EXCEPTION
      WHEN NO_DATA_FOUND THEN
          gc_status_flag      :=  'VE';
          gc_error_code       :=  'CUST18';
          gc_error_msg        :=  'Shipping Method code: ' ||lr_customer_data.charuserfld12||' has not been defined in the
lookup table';
          gc_comments         :=   NULL;
          INSERT_ERROR_PRC;
       WHEN OTHERS THEN
          gc_status_flag      :=  'VE';
          gc_error_code       :=  'CUST18'||' / '||SQLCODE;
          gc_error_msg        :=   SQLERRM;
          gc_comments         :=   NULL;
          INSERT_ERROR_PRC;
       END;
 ---------------------------
       -- Validate TAX CODE
       --------------------------
       BEGIN
          IF TRIM(lr_customer_data.charuserfld11) IS NOT NULL THEN


       	    /*SELECT count(*)  ---11i code modified
       	    INTO  ln_tax_cnt
	    FROM    ar_vat_tax_all AVTA  ---11i code modified

	    WHERE   SYSDATE BETWEEN NVL(AVTA.START_DATE,SYSDATE) AND NVL(AVTA.END_DATE,SYSDATE+1)---11i code modified

	    AND     AVTA.enabled_flag ='Y'---11i code modified
      and     org_id=FND_PROFILE.VALUE('ORG_ID')---11i code modified
      AND     AVTA.tax_code  = lr_customer_data.charuserfld11;---11i code modified*/

 ---R12 Remediated
SELECT count(*)
       	    INTO  ln_tax_cnt
	    FROM    ---ar_vat_tax_all AVTA  ---11i code modified
              ZX_TAX_CLASSIFICATIONS_V AVTA         ---R12 Remediated
	    WHERE   ---SYSDATE BETWEEN NVL(AVTA.START_DATE,SYSDATE) AND NVL(AVTA.END_DATE,SYSDATE+1)---11i code modified
               SYSDATE BETWEEN NVL(avta.start_date_active,SYSDATE) AND NVL(avta.end_date_active,SYSDATE+1)---R12 Remediated
	    AND     AVTA.enabled_flag ='Y'---R12 Remediated
	    and     org_id=FND_PROFILE.VALUE('ORG_ID')---11i code modified
      ---AND     AVTA.tax_code  = lr_customer_data.charuserfld11;---11i code modified
      AND     AVTA.LOOKUP_CODE = lr_customer_data.charuserfld11  ---R12 Remediated
      and     tax_class = 'OUTPUT';  ---R12 Remediated;
 IF ln_tax_cnt =0 then
            gc_status_flag      :=  'VE';
	    gc_error_code       :=  'CUST19';
	    gc_error_msg        :=  'No Data found for the Tax Code: ' ||lr_customer_data.charuserfld11||' for the Customer:
'||lr_customer_data.customername;
	    gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END IF;

       END IF;
 EXCEPTION
       WHEN NO_DATA_FOUND THEN
           gc_status_flag      :=  'VE';
           gc_error_code       :=  'CUST19';
           gc_error_msg        :=  'Tax Code: ' ||lr_customer_data.charuserfld11||' has not been defined ';
           gc_comments         :=   NULL;
           INSERT_ERROR_PRC;
        WHEN OTHERS THEN
           gc_status_flag      :=  'VE';
           gc_error_code       :=  'CUST19'||' / '||SQLCODE;
           gc_error_msg        :=   SQLERRM;
           gc_comments         :=   NULL;
           INSERT_ERROR_PRC;
        END;

      -- End  of changes V1.3
---------------------------------------------------------------
      --It updates the status to 'VS' ,if the validations are through
      ---------------------------------------------------------------
      IF (gc_status_flag  IS NULL) THEN
         gc_status_flag  :='VS';

         UPDATE_ERROR(gn_record_id ,gc_status_flag);
 UPDATE  haemo_customers HC
         SET     HC.oracleintfld8       =   gn_request_id
                ,HC.oracleintfld3       =   ln_term_id
                ,HC.oracleintfld1       =   ln_salesrep_id
                -- Start of changes V1.1
                ,HC.oraclecharfld2      =   lc_customer_type1
                ,HC.oraclecharfld3      =   lc_customer_type3
                ,HC.oraclecharfld4      =   lc_customer_type2
                -- End of changes V1.1
                --Start  of changes V1.6
                ,HC.intuserfld1         =   ln_list_header_id
                --End  of changes V1.6

         WHERE   HC.oracleidentifier    =   lr_customer_data.oracleidentifier
         --Start of changes V1.5
	 AND charuserfld5 =gc_operating_unit_name ;
         --End of changes V1.5
 gc_log_msg:='Validation Is Successful for the Oracleidentifier - '||gn_record_id;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      ELSE
         UPDATE_ERROR(gn_record_id ,gc_status_flag);

         UPDATE  haemo_customers HC
         SET     HC.oracleintfld8      =   gn_request_id
         WHERE   HC.oracleidentifier   =   lr_customer_data.oracleidentifier
         --Start of changes V1.5
	 AND charuserfld5 =gc_operating_unit_name ;
         --End of changes V1.5
gc_log_msg:='Validation Is NOT Successful for the Oracleidentifier - '||gn_record_id;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;
 END LOOP; -- End loop for lcu_customer_data
COMMIT;
---------------------------------------------------
   -- This is to count the records which are Validated
   ---------------------------------------------------
  ln_count_validated:=0;
  BEGIN
      SELECT  COUNT(*)
      INTO    ln_count_validated
      FROM    haemo_customers HC
      WHERE   HC.charuserfld5     =   gc_operating_unit_name
      AND     HC.oraclecharfld1  IS NOT NULL
      AND     HC.oracleintfld8    =   gn_request_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      ln_count_validated  :=0;
   END;
-----------------------------------------------------------
   -- This is to count the records which have passed Validation
   ------------------------------------------------------------
   ln_count_passed_val:=0;
   BEGIN
     SELECT  COUNT(*)
     INTO    ln_count_passed_val
     FROM    haemo_customers HC
     WHERE   HC.charuserfld5     =   gc_operating_unit_name
     AND     HC.oraclecharfld1   =  'VS'
     AND     HC.oracleintfld8    =   gn_request_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      ln_count_passed_val  :=0;
   END;
------------------------------------------------------------------
   -- This is to count the error records which have failed validation
   ------------------------------------------------------------------
   ln_count_error:=0;
   BEGIN
      SELECT  COUNT(*)
      INTO    ln_count_error
      FROM    haemo_customers HC
      WHERE   HC.charuserfld5     =   gc_operating_unit_name
      AND     HC.oraclecharfld1   =  'VE'
      AND     HC.oracleintfld8    =   gn_request_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      ln_count_error   :=0;
   END;
 FND_FILE.PUT_LINE(FND_FILE.LOG,'****************************************************************************');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary Information of HAEMO_CUSTOMERS Records Validated                    ');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'****************************************************************************');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                 :'||ln_count_validated);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation         :'||ln_count_passed_val);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored Out               :'||ln_count_error);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'****************************************************************************');

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_AR_CUST_CONV_PK.VALIDATE_CUST_DATA: ' || SQLERRM);
  -- xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
   x_ret_code:=1;
END VALIDATE_CUST_DATA;
--+=============================================================================+
--| Name        :   PROCESS_CUST_DATA                                           |
--|                                                                             |
--| Description :   Procedure to call the API for customer conversion.          |
--|                                                                             |
--|                                                                             |
--| PARAMETERS:                                                                 |
--|   IN:    p_debug                                                            |
--|         ,p_purge_data                                                       |
--|  OUT:    x_err_buf                                                          |
--|         ,x_ret_code                                                         |
--|                                                                             |
--| Returns :                                                                   |
--+=============================================================================+
PROCEDURE PROCESS_CUST_DATA(
                            x_err_buf       OUT VARCHAR2
                           ,x_ret_code      OUT NUMBER
                           ,p_debug         IN  VARCHAR2
                           ,p_purge_data    IN  VARCHAR2
                           )
IS

-- Local Variables Declaration
x_errbuf                        VARCHAR2(4000);
x_retcode                       NUMBER;
x_setup_errbuf                  VARCHAR2(4000);
x_setup_retcode                 NUMBER;
lc_setup_err_flag               VARCHAR2(1);
ln_error_count                  NUMBER;
ln_error_count_stg              NUMBER;
ln_error_count_com              NUMBER;
ln_process_count                NUMBER;
ln_count_total                  NUMBER;
ln_count_error                  NUMBER;
ln_cust_count                   NUMBER;
ln_address_count                NUMBER;
ln_request_id                   NUMBER;
lc_party_name                   hz_parties.party_name%TYPE;
ln_bill_to_site_use_id          haemo_customers.oracleintfld2%TYPE;
lc_con_short_name               fnd_concurrent_programs.concurrent_program_name%TYPE:='XXHA_CUSTOMER_CONV';
ln_bill_to_site_use_id1       NUMBER;
-- Common return variables
ln_count                        NUMBER;
lc_data                         VARCHAR2(4000);
-- Declaration for API hz_cust_account_v2pub.create_cust_account
customer_rec_type               hz_cust_account_v2pub.cust_account_rec_type;
organization_rec_type           hz_party_v2pub.organization_rec_type;
customer_profile_rec_type       hz_customer_profile_v2pub.customer_profile_rec_type;
ln_cust_account_id              hz_cust_accounts.cust_account_id%TYPE;
lc_account_number               hz_cust_accounts.account_number%TYPE;
ln_party_id                     hz_parties.party_id%TYPE;
lc_party_number                 hz_parties.party_number%TYPE;
ln_profile_id                   NUMBER;
-- Start of changes V1.2
-- Declaration for API hz_classification_v2pub.create_code_assignment
assignment_rec_type             hz_classification_v2pub.code_assignment_rec_type;
ln_code_assignment_id           hz_code_assignments.code_assignment_id%TYPE;
-- End of changes V1.2
--Declaration for API   hz_customer_profile_v2pub.create_cust_profile_amt
cust_profile_amt_rec_type       hz_customer_profile_v2pub.cust_profile_amt_rec_type;
ln_cust_acct_profile_amt_id     NUMBER;
ln_cust_account_profile_id      hz_customer_profiles.cust_account_profile_id%TYPE;
--Declaration for API           hz_location_v2pub.create_location
location_rec_type               hz_location_v2pub.location_rec_type;
ln_location_id                  hz_locations.location_id%TYPE;
--Declaration for API hz_party_site_v2pub.create_party_site
party_site_rec_type             hz_party_site_v2pub.party_site_rec_type;
ln_party_site_id                hz_party_sites.party_site_id%TYPE;
lc_party_site_number            hz_party_sites.party_site_number%TYPE;
--Declaration for API hz_cust_account_site_v2pub.create_cust_acct_site
cust_acct_site_rec_type         hz_cust_account_site_v2pub.cust_acct_site_rec_type;
ln_cust_acct_site_id            hz_cust_acct_sites.cust_acct_site_id%TYPE;
--Declaration for API hz_cust_account_site_v2pub.create_cust_site_use
cust_site_use_rec_type          hz_cust_account_site_v2pub.cust_site_use_rec_type;
cust_profile_site_rec_type      hz_customer_profile_v2pub.customer_profile_rec_type;
ln_site_use_id                  hz_cust_site_uses.site_use_id%TYPE;
-- Declaration for API hz_party_v2pub.create_person
person_rec_type                 hz_party_v2pub.person_rec_type;
ln_person_party_id              hz_parties.party_id%TYPE;
lc_person_party_number          hz_parties.party_number%TYPE;
ln_person_profile_id            NUMBER;
-- Declaration for API hz_party_contact_v2pub.create_org_contact
org_contact_rec_type            hz_party_contact_v2pub.org_contact_rec_type;
ln_org_contact_id               hz_org_contacts.org_contact_id%TYPE;
ln_org_party_rel_id             hz_org_contacts.party_relationship_id%TYPE;
ln_org_party_id                 hz_parties.party_id%TYPE;
ln_org_party_number             hz_parties.party_number%TYPE;
-- Declaration for API hz_cust_account_role_v2pub.create_cust_account_role
cust_account_role_rec_type      hz_cust_account_role_v2pub.cust_account_role_rec_type;
ln_cust_account_role_id         NUMBER;
-- Declaration for API  hz_contact_point_v2pub.create_contact_point
contact_point_rec_type          hz_contact_point_v2pub.contact_point_rec_type;
edi_rec_type                    hz_contact_point_v2pub.edi_rec_type ;
email_rec_type                  hz_contact_point_v2pub.email_rec_type ;
phone_rec_type                  hz_contact_point_v2pub.phone_rec_type;
telex_rec_type                  hz_contact_point_v2pub.telex_rec_type  ;
web_rec_type                    hz_contact_point_v2pub.web_rec_type     ;
ln_contact_point_id             hz_contact_points.contact_point_id%TYPE;
lc_contact_type                 hz_contact_points.contact_point_type%TYPE;
------------------------------------------------------------------------
-- Cursor for selecting the Customer data which are having status = 'VS'
------------------------------------------------------------------------
CURSOR   lcu_process_data
IS
SELECT   HC.*
FROM     haemo_customers HC
where    hc.oraclecharfld1  = 'VS'
AND      HC.charuserfld5    =  gc_operating_unit_name
ORDER BY HC.party,hc.charuserfld4,HC.customernbr,HC.customershipto,HC.addressline1,HC.city,HC.state,HC.postalcode,HC.countyregion,HC.countrycode;
BEGIN
gc_log_msg := 'a1';
---------------------------------------
   -- Update statement to trim the columns
   ---------------------------------------
   UPDATE haemo_customers HC
   SET
   HC.customernbr                    =    TRIM(HC.customernbr)
  ,HC.customershipto                 =    TRIM(HC.customershipto)
  ,HC.customername                   =    TRIM(HC.customername)
  ,HC.addressline1                   =    TRIM(HC.addressline1)
  ,HC.addressline2                   =    TRIM(HC.addressline2)
  ,HC.addressline3                   =    TRIM(HC.addressline3)
  ,HC.state                          =    TRIM(HC.state)
  ,HC.postalcode                     =    TRIM(HC.postalcode)
  ,HC.creditlimit                    =    TRIM(HC.creditlimit)
  ,HC.countrycode                    =    TRIM(HC.countrycode)
  ,HC.dayscreditlimit                =    TRIM(HC.dayscreditlimit)
  ,HC.customersalesman               =    TRIM(HC.customersalesman)
  ,HC.salesmanname                   =    TRIM(HC.salesmanname)
  ,HC.attention                      =    TRIM(HC.attention)
  ,HC.contacttitle                   =    TRIM(HC.contacttitle)
  ,HC.contactfname                   =    TRIM(HC.contactfname)
  ,HC.contactlname                   =    TRIM(HC.contactlname)
  ,HC.contactemail                   =    TRIM(HC.contactemail)
  ,HC.contactphone                   =    TRIM(HC.contactphone)
  ,HC.contactphoneext                =    TRIM(HC.contactphoneext)
  ,HC.contactfax                     =    TRIM(HC.contactfax)
  ,HC.contacttelex                   =    TRIM(HC.contacttelex)
  ,HC.customertype1                  =    TRIM(HC.customertype1)
  ,HC.customertype1desc              =    TRIM(HC.customertype1desc)
  ,HC.customertype2                  =    TRIM(HC.customertype2)
  ,HC.customertype3                  =    TRIM(HC.customertype3)
  ,HC.currencycode                   =    TRIM(HC.currencycode)
  ,HC.dunnbr                         =    TRIM(HC.dunnbr)
  ,HC.taxexemptionnbr                =    TRIM(HC.taxexemptionnbr)
  ,HC.exemptioncert                  =    TRIM(HC.exemptioncert)
  ,HC.expirationdate                 =    TRIM(HC.expirationdate)
  ,HC.maxtaxexempamt                 =    TRIM(HC.maxtaxexempamt)
  ,HC.countyregion                   =    TRIM(HC.countyregion)
  ,HC.party                          =    TRIM(HC.party)
  ,HC.city                           =    TRIM(HC.city)
  ,HC.bank                           =    TRIM(HC.bank)
  ,HC.globalidentifier               =    TRIM(HC.globalidentifier)
  ,HC.distribenduser                 =    TRIM(HC.distribenduser)
  ,HC.language                       =    TRIM(HC.language)
  ,HC.taxable                        =    TRIM(HC.taxable)
  ,HC.altcustomername1               =    TRIM(HC.altcustomername1)
  ,HC.altcustomername2               =    TRIM(HC.altcustomername2)
  ,HC.termscode                      =    TRIM(HC.termscode)
  ,HC.termscodedesc                  =    TRIM(HC.termscodedesc)
  ,HC.charuserfld1                   =    TRIM(HC.charuserfld1)
  ,HC.charuserfld2                   =    TRIM(HC.charuserfld2)
  ,HC.charuserfld3                   =    TRIM(HC.charuserfld3)
  ,HC.charuserfld5                   =    TRIM(HC.charuserfld5)
  ,HC.charuserfld4                   =    TRIM(HC.charuserfld4)
  ,HC.charuserfld6                   =    TRIM(HC.charuserfld6)
  ,HC.charuserfld7                   =    TRIM(HC.charuserfld7)
  ,HC.charuserfld8                   =    TRIM(HC.charuserfld8)
-- Start of changes V1.18
  ,HC.charuserfld9                   =    TRIM(HC.charuserfld9)
  ,HC.charuserfld10                  =    TRIM(HC.charuserfld10)
  ,HC.charuserfld11                  =    TRIM(HC.charuserfld11)
  ,HC.charuserfld12                  =    TRIM(HC.charuserfld12)
  ,HC.charuserfld13                  =    TRIM(HC.charuserfld13)
  ,HC.charuserfld14                  =    TRIM(HC.charuserfld14)
  ,HC.charuserfld15                  =    TRIM(HC.charuserfld15)
-- End of changes V1.18
 ,HC.intuserfld1                    =    TRIM(HC.intuserfld1)
  ,HC.intuserfld2                    =    TRIM(HC.intuserfld2)
  ,HC.intuserfld3                    =    TRIM(HC.intuserfld3)
  ,HC.decuserfld1                    =    TRIM(HC.decuserfld1)
  ,HC.decuserfld2                    =    TRIM(HC.decuserfld2)
  ,HC.decuserfld3                    =    TRIM(HC.decuserfld3)
  ,HC.datex                          =    TRIM(HC.datex)
  ,HC.tobeexamined                   =    TRIM(HC.tobeexamined)
  ,HC.furtherreview                  =    TRIM(HC.furtherreview)
  ,HC.oracleidentifier               =    TRIM(HC.oracleidentifier)
  ,HC.oraclecharfld1                 =    TRIM(HC.oraclecharfld1)
  ,HC.oraclecharfld2                 =    TRIM(HC.oraclecharfld2)
  ,HC.oraclecharfld3                 =    TRIM(HC.oraclecharfld3)
  ,HC.oraclecharfld4                 =    TRIM(HC.oraclecharfld4)
  ,HC.oraclecharfld5                 =    TRIM(HC.oraclecharfld5)
  ,HC.oraclecharfld6                 =    TRIM(HC.oraclecharfld6)
  ,HC.oraclecharfld7                 =    TRIM(HC.oraclecharfld7)
  ,HC.oraclecharfld8                 =    TRIM(HC.oraclecharfld8)
  ,HC.oracleintfld1                  =    TRIM(HC.oracleintfld1)
  ,HC.oracleintfld2                  =    TRIM(HC.oracleintfld2)
  ,HC.oracleintfld3                  =    TRIM(HC.oracleintfld3)
  ,HC.oracleintfld4                  =    TRIM(HC.oracleintfld4)
  ,HC.oracleintfld5                  =    TRIM(HC.oracleintfld5)
  ,HC.oracleintfld6                  =    TRIM(HC.oracleintfld6)
  ,HC.oracleintfld7                  =    TRIM(HC.oracleintfld7)
  ,HC.oracleintfld8                  =    TRIM(HC.oracleintfld8);
   COMMIT;
gc_debug_flag:=p_debug;
----------------------------------------
   -- Purge the record from the error table
   ----------------------------------------
   IF (p_purge_data = 'Y') THEN
      xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>lc_con_short_name);
   END IF;
gc_log_msg := 'a2';
-------------------------------------------------------------
   -- Procedure which is called to validate the SETUP
   -------------------------------------------------------------
   CHECK_CUST_SETUP(
                    x_err_buf  => x_errbuf
                   ,x_ret_code => x_retcode
                   ,x_setup_err_flag=>lc_setup_err_flag
                   );

   IF (lc_setup_err_flag = 'N') THEN --  setup error flag is 'No'
      -------------------------------------------------------------
      -- Procedure which is called to validate the customer records
      -------------------------------------------------------------
      VALIDATE_CUST_DATA(
                         x_err_buf  => x_errbuf
                        ,x_ret_code => x_retcode
                        );

      IF ((x_retcode !=0) AND x_errbuf IS NOT NULL) THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Procedure Validate_cust_data has the following error: '||x_errbuf);
         x_ret_code:=1;
      END IF;
-----------------------------------------------------
      -- To count the records which are having status ='VE'
      -----------------------------------------------------
      ln_error_count:=0;
      BEGIN
         SELECT  COUNT(*)
         INTO    ln_error_count
         FROM    haemo_customers HC
         WHERE   HC.charuserfld5      =    gc_operating_unit_name
         AND     HC.oraclecharfld1    =   'VE';
      EXCEPTION
      WHEN NO_DATA_FOUND   THEN
         ln_error_count  :=0;
      END;
IF (ln_error_count  =0)  THEN
      ------------------------------------------------------
      -- For Loop for processing the customer records by API
      ------------------------------------------------------
      FOR lr_process_data    IN  lcu_process_data
      LOOP
      gn_record_id               :=  lr_process_data.oracleidentifier;
      gn_record_number           :=  lr_process_data.oracleidentifier;
      gc_err_rec_identifier      :=  lr_process_data.customernbr||'-'||lr_process_data.customershipto;
      gc_status_flag             :=  NULL;
      ln_cust_count              :=  0;
      -- Start of changes V1.2
      ln_code_assignment_id      :=  NULL;
      -- End of changes V1.2
      ln_party_id                :=  NULL;
      ln_cust_account_id         :=  NULL;
      ln_cust_account_profile_id :=  NULL;
      ln_address_count           :=  NULL;
gc_log_msg := 'a3';
         -------------------------------------------------------------------------
         --If party and charuserfld4 are null then identifier would be customernbr
         --If party and charuserfld4 are not null then  identifier would be party
         -------------------------------------------------------------------------
         IF (lr_process_data.party     IS  NULL      AND lr_process_data.charuserfld4 IS  NULL) THEN
            gc_record_identifier    :=  lr_process_data.customernbr;
         ELSIF (lr_process_data.party  IS  NOT NULL  AND lr_process_data.charuserfld4 IS  NOT NULL) THEN
            gc_record_identifier    :=  lr_process_data.party;
         END IF;
gc_log_msg := 'a4';
         -----------------------------------------------------------------
         -- To check whether the Customer exists in the application or not
         -----------------------------------------------------------------
         BEGIN
            SELECT  HCA.party_id
                   ,HCA.cust_account_id
            INTO    ln_party_id
                   ,ln_cust_account_id
            FROM    hz_cust_accounts  HCA
            WHERE   HCA.orig_system_reference = gc_record_identifier;
         EXCEPTION
         WHEN NO_DATA_FOUND THEN
            ln_cust_count      := 1;
            ln_party_id        := NULL;
            ln_cust_account_id := NULL;
         WHEN OTHERS THEN
            gc_status_flag       := 'PE';
            gc_error_code       :=   SQLCODE;
            gc_error_msg        :=   SQLERRM||' / '||'Error in the Party Name';
            gc_comments         :=   NULL;
            INSERT_ERROR_PRC;
         END;
-----------------------------------------------------------------------
         --IF Customer does not exist, then create Customer and Customer Profile
         -----------------------------------------------------------------------
         IF (ln_cust_count = 1) THEN

            ----------------------------------------------------------------
            -- API hz_cust_account_v2pub.create_cust_account is called here
            ----------------------------------------------------------------
            BEGIN
               gc_api_status    := NULL;
               gc_error_code    := NULL;
               gc_error_msg     := NULL;
               gc_comments      := NULL;
gc_log_msg := 'a5';
               ------------------------------------------------------------------------------------------------
               -- if party and charuserfld4 are null then customername would be passed as organization_name
               -- if party and charuserfld4 are not null then charuserfld4 would be passed as organization_name
               ------------------------------------------------------------------------------------------------
IF (lr_process_data.party     IS  NULL     AND lr_process_data.charuserfld4  IS  NULL) THEN
                  organization_rec_type.organization_name             :=  lr_process_data.customername;
               ELSIF   (lr_process_data.party IS  NOT NULL AND lr_process_data.charuserfld4 IS NOT NULL) THEN
                  organization_rec_type.organization_name             :=  lr_process_data.charuserfld4;
               END IF;
organization_rec_type.organization_type                 :=  'EXTERNAL';
               organization_rec_type.gsa_indicator_flag                :=  'N';
               organization_rec_type.duns_number_c                     :=   lr_process_data.dunnbr;
               organization_rec_type.organization_name_phonetic        :=   lr_process_data.altcustomername1;
               organization_rec_type.created_by_module                 :=   fnd_global.user_id;
customer_rec_type.created_by_module                     :=   fnd_global.user_id;
               customer_rec_type.ATTRIBUTE1                            :=   lr_process_data.charuserfld8;
               customer_rec_type.ATTRIBUTE2                            :=   lr_process_data.globalidentifier;
               customer_rec_type.status                                :=  'A';
               -- customer_rec_type.orig_system_reference              :=   lr_process_data.customernbr;
               customer_rec_type.orig_system_reference                 :=   gc_record_identifier;
               -- Start of changes V1.1
               customer_rec_type.customer_type                         :=   lr_process_data.oraclecharfld2;
               customer_rec_type.customer_class_code                   :=   lr_process_data.oraclecharfld3;
               -- End of changes V1.1
               -- Start of changes V1.2
               --customer_rec_type.primary_salesrep_id                 :=   lr_process_data.oracleintfld1;
               -- Start of changes V1.2
-- Start of changes V1.3
               -- IF  lr_process_data.charuserfld12 IS NOT NULL THEN
               --   customer_rec_type.ship_via                      := lr_process_data.charuserfld12;
               --  END IF;
               -- End of changes V1.3
customer_profile_rec_type.created_by_module             :=   fnd_global.user_id;
               customer_profile_rec_type.status                        :=  'A';
               customer_profile_rec_type.collector_id                  :=   1;
---------------------------------------------------------------------------------------------
               --If CustomerType1 is 'R' then Credit_checking would be 'Y' else Credit_checking would be 'N'
               ---------------------------------------------------------------------------------------------
               IF (lr_process_data.CustomerType1 = 'R')  THEN
                  customer_profile_rec_type.credit_checking            :=  'Y';
               ELSE
                  customer_profile_rec_type.credit_checking            :=  'N';
               END IF;

               customer_profile_rec_type.discount_terms                :=  'Y';
               customer_profile_rec_type.send_statements               :=  'N';
               customer_profile_rec_type.credit_balance_statements     :=  'N';
 ---------------------------------------------------------------------------------
               -- if Creditlimit is > 1 then Credit_hold would 'Y' else Credit_hold would be 'N'
               ---------------------------------------------------------------------------------
               --   Modified bu subbu on Jan 22
               -- Start of changes V1.3
               -- IF (lr_process_data.creditlimit  > 1) THEN
               --   customer_profile_rec_type.credit_hold                :=  'Y';
               -- ELSE
                  customer_profile_rec_type.credit_hold                :=  'N';
               -- END IF;
                -- End of changes V1.3
customer_profile_rec_type.profile_class_id              :=   0;
               customer_profile_rec_type.credit_rating                 :=  'AVERAGE';
               customer_profile_rec_type.risk_code                     :=  'DEFAULT';
               customer_profile_rec_type.standard_terms                :=   lr_process_data.oracleintfld3;
               customer_profile_rec_type.override_terms                :=  'Y';
               customer_profile_rec_type.payment_grace_days            :=   5;
               customer_profile_rec_type.cons_inv_flag                 :=  'N';
               customer_profile_rec_type.cons_inv_type                 :=  'Summary';
fnd_msg_pub.Initialize;
               hz_cust_account_v2pub.create_cust_account (
                                                          p_init_msg_list          =>    FND_API.G_FALSE
                                                         ,p_cust_account_rec       =>    customer_rec_type
                                                         ,p_organization_rec       =>    organization_rec_type
                                                         ,p_customer_profile_rec   =>    customer_profile_rec_type
                                                         ,p_create_profile_amt     =>    FND_API.G_TRUE
                                                         ,x_cust_account_id        =>    ln_cust_account_id
                                                         ,x_account_number         =>    lc_account_number
                                                         ,x_party_id               =>    ln_party_id
                                                         ,x_party_number           =>    lc_party_number
                                                         ,x_profile_id             =>    ln_profile_id
                                                         ,x_return_status          =>    gc_api_status
                                                         ,x_msg_count              =>    ln_count
                                                         ,x_msg_data               =>    lc_data
                                                         );
               IF (gc_api_status ='S') THEN
                  NULL;
               ELSIF (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
                  IF (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=    SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded =>
FND_API.G_FALSE),1,255);
                        gc_comments         :=   'API- hz_cust_account_v2pub.create_cust_account';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
               gc_log_msg:='Flag Return By API - hz_cust_account_v2pub.create_cust_account IS '||NVL(gc_status_flag,'PS')||'
,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_01';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_cust_account_v2pub.create_cust_account';
               INSERT_ERROR_PRC ;
            END; --API create_cust_account
 -- Start of changes V1.2
            ------------------------------------------------------
            --Assigning the Customer Category Code to the Customer
            ------------------------------------------------------
            BEGIN
               gc_api_status    := NULL;
               gc_error_code    := NULL;
               gc_error_msg     := NULL;
               gc_comments      := NULL;
assignment_rec_type.owner_table_name                        := 'HZ_PARTIES';
               assignment_rec_type.owner_table_id                          :=  ln_party_id;
               assignment_rec_type.class_category                          := 'CUSTOMER_CATEGORY'  ;
               assignment_rec_type.class_code                              :=  lr_process_data.oraclecharfld4;
               assignment_rec_type.primary_flag                            := 'Y';
               assignment_rec_type.content_source_type                     :=  hz_party_v2pub.g_miss_content_source_type;
               assignment_rec_type.created_by_module                       :=  fnd_global.user_id;
               fnd_msg_pub.Initialize;
               hz_classification_v2pub.create_code_assignment(
                                                               p_init_msg_list         =>    FND_API.G_FALSE,
                                                               p_code_assignment_rec   =>    assignment_rec_type,
                                                               x_return_status         =>    gc_api_status,
                                                               x_msg_count             =>    ln_count,
                                                               x_msg_data              =>    lc_data,
                                                               x_code_assignment_id    =>    ln_code_assignment_id
                                                            );
               IF (gc_api_status ='S') THEN
                  NULL;
               ELSIF (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
                  IF (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=    SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded =>
FND_API.G_FALSE),1,255);
                        gc_comments         :=   'API- hz_cust_account_v2pub.create_cust_account';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
               gc_log_msg:='Flag Return By API - hz_classification_v2pub.create_code_assignment IS
'||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_01';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_classification_v2pub.create_code_assignment';
               INSERT_ERROR_PRC ;
            END; --API create_code_assignment
            -- End of changes V1.2
--Commented by subbu as on Jan 22
           -- Start of changes V1.3
          /*
            ----------------------------------------------------------------------
            --API hz_customer_profile_v2pub.create_cust_profile_amt is called here
            ----------------------------------------------------------------------
            IF (NVL(lr_process_data.CustomerShipTo,0) = 0) THEN -- Profile needs to be created only for BILL TO
               BEGIN
                  ------------------------------------------------
                  -- This is to derive the Cust_account_profile_id
                  ------------------------------------------------
                  BEGIN
                     SELECT  HCP.cust_account_profile_id
                     INTO    ln_cust_account_profile_id
                     FROM    hz_customer_profiles    HCP
                     WHERE   HCP.cust_account_id =ln_cust_account_id;

                      gc_log_msg:='************DEBUG1********************'||ln_cust_account_profile_id;
                      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                      gc_log_msg:='************DEBUG2********************'||ln_cust_account_id;
                      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                  EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     ln_cust_account_profile_id:=NULL;
                     gc_status_flag      :=   'PE';
                     gc_error_code       :=   'API_ERROR';
                     gc_error_msg        :=   'cust_account_profile_id Not Found';
                     gc_comments         :=   'hz_customer_profile_v2pub.create_cust_profile_amt';
                     INSERT_ERROR_PRC ;
                  WHEN OTHERS THEN
                     ln_cust_account_profile_id:=NULL;
                     gc_status_flag       := 'PE';
                     gc_error_code       :=   SQLCODE;
                     gc_error_msg        :=   SQLERRM||'/ cust_account_profile_id';
                     gc_comments         :=  'hz_customer_profile_v2pub.create_cust_profile_amt';
                     INSERT_ERROR_PRC;
                  END;

                   --Added By SUBBU on Jan 22
                  BEGIN
                     ln_bill_to_site_use_id:=NULL;

                     SELECT  HC.oracleintfld2
                     INTO    ln_bill_to_site_use_id
                     FROM    haemo_customers HC
                     WHERE   HC.customernbr = lr_process_data.customernbr
                     AND     NVL(HC.customerShipTo,0) = 0;

                     --cust_site_use_rec_type.bill_to_site_use_id         := ln_bill_to_site_use_id;
                     --cust_profile_amt_rec_type.site_use_id                :=  ln_bill_to_site_use_id;
                  EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     ln_bill_to_site_use_id :=NULL;
                  WHEN TOO_MANY_ROWS THEN
                     ln_bill_to_site_use_id :=NULL;
                  WHEN OTHERS THEN
                     gc_status_flag         :=  'PE';
                     gc_error_code          :=   SQLCODE;
                     gc_error_msg           :=   SQLERRM||' / '||'Error in bill_to_site_use_id';
                     gc_comments            :=   NULL;
                    INSERT_ERROR_PRC;

                  END;

                  gc_api_status    := NULL;
                  gc_error_code    := NULL;
                  gc_error_msg     := NULL;
                  gc_comments      := NULL;
                  cust_profile_amt_rec_type.cust_account_profile_id     :=  ln_cust_account_profile_id;
                  cust_profile_amt_rec_type.cust_account_id             :=  ln_cust_account_id;
                  --Added by subbu on Jan22



                  cust_profile_amt_rec_type.currency_code               :=  UPPER(lr_process_data.currencycode) ;

                  gc_log_msg:='************DEBUG3********************'||lr_process_data.creditlimit;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                  cust_profile_amt_rec_type.overall_credit_limit        :=  lr_process_data.creditlimit;
                  cust_profile_amt_rec_type.created_by_module           :=  fnd_global.user_id;

                  fnd_msg_pub.Initialize;
                  hz_customer_profile_v2pub.create_cust_profile_amt (
                                                                    p_init_msg_list              =>  FND_API.G_FALSE
                                                                   ,p_check_foreign_key          =>  FND_API.G_TRUE
                                                                   ,p_cust_profile_amt_rec       =>
cust_profile_amt_rec_type
                                                                   ,x_cust_acct_profile_amt_id   =>
ln_cust_acct_profile_amt_id
                                                                   ,x_return_status              =>  gc_api_status
                                                                   ,x_msg_count                  =>  ln_count
                                                                   ,x_msg_data                   =>  lc_data
                                                                  ) ;


                  gc_log_msg:='************DEBUG4********************'||gc_api_status;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                  gc_log_msg:='************DEBUG5********************'||lc_data;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);





                  IF  (gc_api_status ='S') THEN
                     NULL;
                  ELSIF   (gc_api_status ='E') THEN
                     gc_status_flag       := 'PE';
                     IF (ln_count >= 1) THEN
                        FOR I IN 1..ln_count
                        LOOP
                           gc_error_code       :=   'API_ERROR';
                           gc_error_msg        :=    SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded =>
FND_API.G_FALSE),1,255);
                           gc_comments         :=   'API- hz_customer_profile_v2pub.create_cust_profile_amt';
                           INSERT_ERROR_PRC ;
                        END LOOP;
                     END IF;
                  END IF;
                  gc_log_msg:='Flag Return By API - hz_customer_profile_v2pub.create_cust_profile_amt IS
'||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               EXCEPTION
               WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_02';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_customer_profile_v2pub.create_cust_profile_amt';
               INSERT_ERROR_PRC ;
               END;--API create_cust_profile_amt
            END IF; -- end if for checking Bill To
            */
            -- End of changes V1.3
         END IF; --end if for ln_cust_count = 1
gc_log_msg := 'Patrick8';
--------------------------------------------------------------------------
         -- This is to check whether the address is exist in the application or not
         --------------------------------------------------------------------------
         BEGIN
            if (lr_process_data.attention  is not null) then
               /*SELECT  1------11i code modified
               INTO    ln_address_count
               FROM    ra_addresses_all RAA
               -- Start of changes V1.1
               WHERE   UPPER(RAA.country)          =   UPPER(lr_process_data.countrycode)
               -- End of changes V1.1
               AND     RAA.address1                =   lr_process_data.attention
               AND     NVL(RAA.address2,0)         =   NVL(lr_process_data.addressline1,0)
               AND     NVL(RAA.address3,0)         =   NVL(lr_process_data.addressline2,0)
               AND     NVL(RAA.city,0)             =   NVL(lr_process_data.city,0)

              -- Start of changes V1.3
              --AND     NVL(RAA.postal_code,0)     =NVL(lr_process_data.postalcode,0)
               --AND     NVL(RAA.postal_code,0)      =
DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),'-')

   --Start of Changed V1.9
               AND     NVL(RAA.postal_code,0)      =
DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),NVL(lr_process_data.postalcode,'-'))
              -- End of changes V1.3
   --End of Changed V1.9

               AND     NVL(RAA.state,0)            =   NVL(lr_process_data.state,0)
               AND     NVL(RAA.county,0)           =   NVL(lr_process_data.countyregion,0)
               AND     RAA.org_id                  =   FND_PROFILE.VALUE('ORG_ID')
               AND     RAA.customer_id             =   ln_cust_account_id;*/
---R12 Remediated
select  1
INTO    ln_address_count
from    ---ra_addresses_all RAA
			   hz_party_sites hps,---R12 Remediated
         hz_locations hl,---R12 Remediated
         hz_cust_acct_sites_all HCASA---R12 Remediated
               -- Start of changes V1.1
 where   ---UPPER(RAA.country)          =   UPPER(lr_process_data.countrycode)
			         UPPER(HL.COUNTRY)          =   UPPER(lr_process_data.countrycode)
               -- End of changes V1.1
               ---AND     RAA.address1                =   lr_process_data.attention
AND     HL.ADDRESS1                 =   lr_process_data.attention
               ---AND     NVL(RAA.address2,0)         =   NVL(lr_process_data.addressline1,0)
AND     NVL(HL.ADDRESS2,0)         =   NVL(lr_process_data.addressline1,0)
               ---AND     NVL(RAA.address3,0)         =   NVL(lr_process_data.addressline2,0)
AND     NVL(HL.ADDRESS3,0)         =   NVL(lr_process_data.addressline2,0)
               ---AND     NVL(RAA.city,0)             =   NVL(lr_process_data.city,0)
AND     NVL(HL.CITY,0)             =   NVL(lr_process_data.city,0)
-- Start of changes V1.3
              --AND     NVL(RAA.postal_code,0)     =NVL(lr_process_data.postalcode,0)
               --AND     NVL(RAA.postal_code,0)= DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),'-')
              ---Start of Changed V1.9
               ---AND     NVL(RAA.postal_code,0)= DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),NVL(lr_process_data.postalcode,'-'))
AND     NVL(HL.POSTAL_CODE,0)      =
DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),NVL(lr_process_data.postalcode,'-'))
    -- End of changes V1.3
   --End of Changed V1.9
 ---AND     NVL(RAA.state,0)            =   NVL(lr_process_data.state,0)
AND     NVL(HL.STATE,0)            =   NVL(lr_process_data.state,0)
               ---AND     NVL(RAA.county,0)           =   NVL(lr_process_data.countyregion,0)
AND     NVL(HL.COUNTY,0)           =   NVL(lr_process_data.countyregion,0)
               ---AND     RAA.org_id                  =   FND_PROFILE.VALUE('ORG_ID')
and hcasa.org_id                =   fnd_profile.value('ORG_ID')
and hps.location_id                               = hl.location_id----
and hps.party_site_id                             = hcasa.party_site_id----
       ---AND     RAA.customer_id          =   ln_cust_account_id;
and     hcasa.cust_account_id       =   ln_cust_account_id;
elsif (lr_process_data.attention is null) then
               /*SELECT  1         ---11i code modified
               INTO    ln_address_count
               FROM    ra_addresses_all RAA
               -- Start of changes V1.1
               WHERE   UPPER(RAA.country)          =   UPPER(lr_process_data.countrycode)
               -- End of changes V1.1
               AND     RAA.address1                =   lr_process_data.addressline1
               AND     NVL(RAA.address2,0)         =   NVL(lr_process_data.addressline2,0)
               AND     NVL(RAA.address3,0)         =   NVL(lr_process_data.addressline3,0)
               AND     NVL(RAA.city,0)             =   NVL(lr_process_data.city,0)

               -- Start of changes V1.3
                --AND     NVL(RAA.postal_code,0)   =   NVL(lr_process_data.postalcode,0)

    --Start of Changed V1.9
               AND     NVL(RAA.postal_code,0)      =
DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),NVL(lr_process_data.postalcode,'-'))
               -- End of changes V1.3
   --End of changes V1.9

               AND     NVL(RAA.state,0)            =   NVL(lr_process_data.state,0)
               AND     NVL(RAA.county,0)           =   NVL(lr_process_data.countyregion,0)
               AND     RAA.org_id                  =   FND_PROFILE.VALUE('ORG_ID')
               AND     RAA.customer_id             =   ln_cust_account_id;*/
---R12 Remediated
SELECT 1
INTO ln_address_count
FROM                            ---ra_addresses_all RAA
  hz_party_sites HPS,          ----
  hz_locations HL,            -----
  hz_cust_acct_sites_all HCASA----
  -- Start of changes V1.1
WHERE ---UPPER(RAA.country)          =   UPPER(lr_process_data.countrycode)
  UPPER(HL.COUNTRY) = UPPER(lr_process_data.countrycode)
  -- End of changes V1.1
  ---AND     RAA.address1                =   lr_process_data.addressline1
AND HL.ADDRESS1 = lr_process_data.attention
  ---AND     NVL(RAA.address2,0)         =   NVL(lr_process_data.addressline2,0)
AND NVL(HL.ADDRESS2,0) = NVL(lr_process_data.addressline1,0)
  ---AND     NVL(RAA.address3,0)         =   NVL(lr_process_data.addressline3,0)
AND NVL(HL.ADDRESS3,0) = NVL(lr_process_data.addressline2,0)
  ---AND     NVL(RAA.city,0)             =   NVL(lr_process_data.city,0)
AND NVL(HL.CITY,0) = NVL(lr_process_data.city,0)
  -- Start of changes V1.3
  --AND     NVL(RAA.postal_code,0)   =   NVL(lr_process_data.postalcode,0)
  --Start of Changed V1.9
  ---AND     NVL(RAA.postal_code,0) = DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),NVL(lr_process_data.postalcode,'-'))
AND NVL(HL.POSTAL_CODE,0) =
DECODE(lr_process_data.countrycode,'US',NVL(lr_process_data.postalcode,0),NVL(lr_process_data.postalcode,'-'))
  -- End of changes V1.3                                                                                            --End of changes V1.9
  ---AND     NVL(RAA.state,0)            =   NVL(lr_process_data.state,0)
AND NVL(HL.STATE,0) = NVL(lr_process_data.state,0)
  ---AND     NVL(RAA.county,0)           =   NVL(lr_process_data.countyregion,0)
AND NVL(HL.COUNTY,0) = NVL(lr_process_data.countyregion,0)
  ---AND     RAA.org_id                  =   FND_PROFILE.VALUE('ORG_ID')
AND hcasa.org_id      = fnd_profile.value('ORG_ID')
AND hps.location_id   = hl.location_id     ----
AND hps.party_site_id = hcasa.party_site_id----
  ---AND     RAA.customer_id             =   ln_cust_account_id;
AND HCASA.CUST_ACCOUNT_ID = ln_cust_account_id;
            END IF;
         EXCEPTION
         WHEN NO_DATA_FOUND THEN
            ln_address_count     :=  0;
         WHEN TOO_MANY_ROWS THEN
            ln_address_count     :=  1;
         WHEN OTHERS  THEN
            gc_status_flag       :=  'PE';
            gc_error_code        :=   SQLCODE;
            gc_error_msg         :=   SQLERRM||'/ Address Checking';
            gc_comments          :=   NULL;
            INSERT_ERROR_PRC;
         END;
--FND_FILE.PUT_LINE(FND_FILE.LOG, 'ln_address_count ' || ln_address_count);
--fND_FILE.PUT_LINE(FND_FILE.LOG, 'ln_address_count ' || ln_address_count||' oracleidentifier '||lr_process_data.oracleidentifier||' custm '||lr_process_data.customernbr);
		--  fND_FILE.PUT_LINE(FND_FILE.LOG, 'Customer id ' ||ln_cust_account_id);
---------------------------------------------------------------------
         --IF the Address has already been created, then do not call these API
         ---------------------------------------------------------------------
       --Start of Changes V1.9
       -- IF (ln_address_count = 0) THEN
       --End of Changes V1.9
            -------------------------------------------------------
            -- API hz_location_v2pub.create_location is called here
            -------------------------------------------------------
            BEGIN
               gc_api_status       :=  NULL;
               gc_error_code       :=  NULL;
               gc_error_msg        :=  NULL;
               gc_comments         :=  NULL;
gc_log_msg := 'Patrick7';
-----------------------------------------------------------------------------------------------------------------------------
----------------------------------
-- if attention is not null then attention will be assign to address1,addressline1 would be assign to address2 and addressline2 would be assign to address3
 -- if attention is null then addressline1 would be assign to address1,addressline2 would be assign to address2 and addressline3 would be assign to address3

-----------------------------------------------------------------------------------------------------------------------------
----------------------------------
               --Start of ChangesV1.9
              IF (NVL(lr_process_data.CustomerShipTo,0) = 0) THEN  --BILL_TO
		               IF (lr_process_data.attention   IS NOT NULL) THEN
			  			         location_rec_type.address1                        :=  lr_process_data.attention;
					  	         location_rec_type.address2                        :=  lr_process_data.addressline1;
					  	         location_rec_type.address3                        :=  lr_process_data.addressline2;
					  	         location_rec_type.address4                        :=  lr_process_data.addressline3;
					         ELSIF (lr_process_data.attention IS NULL) THEN
					  	         location_rec_type.address1                        :=  lr_process_data.addressline1;
					  	         location_rec_type.address2                        :=  lr_process_data.addressline2;
					  	         location_rec_type.address3                        :=  lr_process_data.addressline3;
					  	         --Start of changes V1.12
					  	         location_rec_type.address4                        :=  NULL;
					  	         --End of changes V1.12
              END IF;
-- 1.20 - BMarcoux - Start of Processing for 'LEGAL' Processing
              ELSIF (NVL(lr_process_data.CustomerShipTo,0) = 9999) THEN  --LEGAL
		               IF (lr_process_data.attention   IS NOT NULL) THEN
			  			         location_rec_type.address1                        :=  lr_process_data.attention;
					  	         location_rec_type.address2                        :=  lr_process_data.addressline1;
					  	         location_rec_type.address3                        :=  lr_process_data.addressline2;
					  	         location_rec_type.address4                        :=  lr_process_data.addressline3;
					         ELSIF (lr_process_data.attention IS NULL) THEN
					  	         location_rec_type.address1                        :=  lr_process_data.addressline1;
					  	         location_rec_type.address2                        :=  lr_process_data.addressline2;
					  	         location_rec_type.address3                        :=  lr_process_data.addressline3;
					  	         location_rec_type.address4                        :=  NULL;
					         END IF;
-- 1.20 - BMarcoux - End of Processing for 'LEGAL' Processing
              ELSE
		               IF (lr_process_data.attention   IS NOT NULL) THEN
			  			         location_rec_type.address1                        := lr_process_data.customername||' / '|| lr_process_data.attention;
			  			         location_rec_type.address2                        :=  lr_process_data.addressline1;
			  			         location_rec_type.address3                        :=  lr_process_data.addressline2;
			  			         location_rec_type.address4                        :=  lr_process_data.addressline3;
					         ELSIF (lr_process_data.attention IS NULL) THEN
			  			         --Start of changes V1.11
			  			         --location_rec_type.address1                       :=  lr_process_data.addressline1;
			  			         --location_rec_type.address2                       :=  lr_process_data.addressline2;
			  			         --location_rec_type.address3                       :=  lr_process_data.addressline3;
			  			         location_rec_type.address1                         := lr_process_data.customername;
			  			         location_rec_type.address2                         :=  lr_process_data.addressline1;
			  			         location_rec_type.address3                         :=  lr_process_data.addressline2;
			  			         location_rec_type.address4                         :=  lr_process_data.addressline3;
			  			         --End of changes V1.11
					         END IF;
              END IF;
	    --End of ChangesV1.9
location_rec_type.city                               :=  lr_process_data.city;
-- Start of changes V1.3
               --location_rec_type.postal_code                        :=  lr_process_data.postalcode;
               IF lr_process_data.countrycode='US' THEN
                  location_rec_type.postal_code                        :=  lr_process_data.postalcode;
               ELSE
                  --Start of ChangesV1.8
                  IF lr_process_data.postalcode IS NULL THEN
                     location_rec_type.postal_code                       :='-';
                   ELSE
                     location_rec_type.postal_code                        :=  lr_process_data.postalcode;
                   END IF;
                 --End of ChangesV1.8
               END IF;
--location_rec_type.postal_code      :=  DECODE(lr_process_data.countrycode,'US',lr_process_data.postalcode,'-');
               -- End of changes V1.3
location_rec_type.state                              :=  lr_process_data.state;
               location_rec_type.county                             :=  lr_process_data.countyregion;
               -- Start of changes V1.1
               location_rec_type.country                            :=  UPPER(lr_process_data.countrycode);
               -- End of changes V1.1
               location_rec_type.created_by_module                  :=  fnd_global.user_id;
               location_rec_type.address_lines_phonetic             :=  lr_process_data.altcustomername2;
               location_rec_type.language                           :=  UPPER(lr_process_data.language);
fnd_msg_pub.Initialize;
               hz_location_v2pub.create_location(
                                                 p_init_msg_list  => FND_API.G_FALSE
                                                ,p_location_rec   => location_rec_type
                                                ,x_location_id    => ln_location_id
                                                ,x_return_status  => gc_api_status
                                                ,x_msg_count      => ln_count
                                                ,x_msg_data       => lc_data
                                                );
               IF  (gc_api_status ='S') THEN
                  NULL;
               ELSIF (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
                  IF (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=   SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded =>
FND_API.G_FALSE),1,255);
                        gc_comments         :=   'API- hz_location_v2pub.create_location';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
               gc_log_msg:='Flag Return By API - hz_location_v2pub.create_location IS '||NVL(gc_status_flag,'PS')||'
,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_03';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_location_v2pub.create_location';
               INSERT_ERROR_PRC ;
            END; --create_location
gc_log_msg := 'Patrick5';
            -----------------------------------------------------------
            -- API hz_party_site_v2pub.create_party_site is called here
            -----------------------------------------------------------
            BEGIN
               gc_api_status       :=  NULL;
               gc_error_code       :=  NULL;
               gc_error_msg        :=  NULL;
               gc_comments         :=  NULL;
               party_site_rec_type.party_id                  :=    ln_party_id;
               party_site_rec_type.location_id               :=    ln_location_id ;
               party_site_rec_type.identifying_address_flag  :=   'Y';
               party_site_rec_type.party_site_name           :=   'Customer Site';
               party_site_rec_type.created_by_module         :=    fnd_global.user_id;
               party_site_rec_type.language                  :=    UPPER(lr_process_data.language);

               fnd_msg_pub.Initialize;
               hz_party_site_v2pub.create_party_site (
                                                        p_init_msg_list      =>  FND_API.G_FALSE
                                                       ,p_party_site_rec     =>  party_site_rec_type
                                                       ,x_party_site_id      =>  ln_party_site_id
                                                       ,x_party_site_number  =>  lc_party_site_number
                                                       ,x_return_status      =>  gc_api_status
                                                       ,x_msg_count          =>  ln_count
                                                       ,x_msg_data           =>  lc_data
                                                   );
               IF (gc_api_status ='S') THEN
                  NULL;
               ELSIF (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
                  IF (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=   SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded =>
FND_API.G_FALSE),1,255);
                        gc_comments         :=   'hz_party_site_v2pub.create_party_site';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
               gc_log_msg:='Flag Return By API - hz_party_site_v2pub.create_party_site IS '||NVL(gc_status_flag,'PS')||'
,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_04';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_party_site_v2pub.create_party_site';
               INSERT_ERROR_PRC ;
            END;--create_party_site
gc_log_msg := 'Patrick4';
----------------------------------------------------------------------
            -- API hz_cust_account_site_v2pub.create_cust_acct_site is called here
            ----------------------------------------------------------------------
            BEGIN
               gc_api_status    := NULL;
               gc_error_code    := NULL;
               gc_error_msg     := NULL;
               gc_comments      := NULL;

               cust_acct_site_rec_type.created_by_module         := fnd_global.user_id;
               cust_acct_site_rec_type.cust_account_id           := ln_cust_account_id;
               cust_acct_site_rec_type.party_site_id             := ln_party_site_id;
               cust_acct_site_rec_type.status                    := 'A';
               -- Start of changes V1.1
               -- Start of changes V1.2
               -- cust_acct_site_rec_type.customer_category_code    := lr_process_data.oraclecharfld4;
               -- End of changes V1.1
               -- End of changes V1.2
               cust_acct_site_rec_type.language                  := UPPER(lr_process_data.language);
               -- This commented for testing
               -- cust_acct_site_rec_type.translated_customer_name := lr_process_data.altcustomername2;
fnd_msg_pub.Initialize;
               hz_cust_account_site_v2pub.create_cust_acct_site (
                                                                p_init_msg_list       =>  FND_API.G_FALSE
                                                               ,p_cust_acct_site_rec  =>  cust_acct_site_rec_type
                                                               ,x_cust_acct_site_id   =>  ln_cust_acct_site_id
                                                               ,x_return_status       =>  gc_api_status
                                                               ,x_msg_count           =>  ln_count
                                                               ,x_msg_data            =>  lc_data
                                                                );
               IF (gc_api_status ='S') THEN
               gc_log_msg := 'Rajack1';
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                  NULL;
               ELSIF (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
                  IF (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=   SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded =>
FND_API.G_FALSE),1,255);
                        gc_comments         :=   'hz_cust_account_site_v2pub.create_cust_acct_site';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
               gc_log_msg:='Flag Return By API - hz_cust_account_site_v2pub.create_cust_acct_site IS
'||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_05';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_cust_account_site_v2pub.create_cust_acct_site';
               INSERT_ERROR_PRC ;
            END;--create_cust_acct_site
--  END IF; --ln_address_count = 0
----------------------------------------------------------------
         -- API hz_cust_account_site_v2pub.create_cust_site_use is called
         ----------------------------------------------------------------
         BEGIN
            -----------------------------------------------------------------------------------------------
            -- IF CustomerShipTo is 0 then  site_use_code would be BILL TO else site_use_code would SHIP TO
            -----------------------------------------------------------------------------------------------
gc_log_msg := 'Patrick3';
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            IF (NVL(lr_process_data.CustomerShipTo,0) = 0) THEN
               cust_site_use_rec_type.primary_salesrep_id            :=  lr_process_data.oracleintfld1;
--1.17 Destination (FOB)
               cust_site_use_rec_type.fob_point  := lr_process_data.destination;  -- added 26-jun-09 BMarcoux
--               cust_site_use_rec_type.fob_point  := null;        -- added 27-jun-07 prajack
--1.17
-- Start of changes V1.18
               cust_site_use_rec_type.Freight_Term  := lr_process_data.charuserfld13;
-- End of changes V1.18
               IF (lr_process_data.charuserfld4 IS NOT NULL AND lr_process_data.Party IS NOT NULL) THEN
                  cust_site_use_rec_type.primary_flag                := 'N';
               ELSE
                  cust_site_use_rec_type.primary_flag                := 'Y';
               END IF;
               cust_site_use_rec_type.site_use_code                  := 'BILL_TO';
               cust_site_use_rec_type.bill_to_site_use_id            :=  NULL;
-- Start of changes V1.3
               IF lr_process_data.charuserfld11 IS NOT NULL THEN
	          cust_site_use_rec_type.tax_code:=lr_process_data.charuserfld11;
	       END IF;
	       IF lr_process_data.charuserfld10 IS NOT NULL THEN
	          cust_site_use_rec_type.tax_reference:=lr_process_data.charuserfld10;
	       END IF;
               -- End of changes V1.3
               --Start of changesV1.6
               IF lr_process_data.oraclecharfld8 IS NOT NULL THEN
                  cust_site_use_rec_type.attribute3:=lr_process_data.oraclecharfld8;
               END IF;
               --End of changesV1.6
            ELSE
               cust_site_use_rec_type.primary_flag                   := 'N';
-- 1.20 - BMarcoux - Start of Processing for 'LEGAL' Processing
            IF (NVL(lr_process_data.CustomerShipTo,0) <> 9999) THEN
               cust_site_use_rec_type.site_use_code := 'SHIP_TO';
            ELSE
               cust_site_use_rec_type.site_use_code := 'LEGAL';
            END IF;
--          cust_site_use_rec_type.site_use_code := 'SHIP_TO';
-- 1.20 - BMarcoux - Start of Processing for 'LEGAL' Processing
cust_site_use_rec_type.fob_point                      :=  lr_process_data.destination;
-- Start of changes V1.18
               cust_site_use_rec_type.Freight_Term                   :=  lr_process_data.charuserfld13;
-- End of changes V1.18
               cust_site_use_rec_type.primary_salesrep_id            :=  lr_process_data.oracleintfld1;
gc_log_msg := 'Patrick3-1';
xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
-------------------------------------------------------------------
               -- This is to derive the bill_to_site_use_id from the staging table
               -------------------------------------------------------------------
               BEGIN
                  ln_bill_to_site_use_id:=NULL;

                  SELECT  HC.oracleintfld2
                  INTO    ln_bill_to_site_use_id
                  FROM    haemo_customers HC
                  WHERE   HC.customernbr = lr_process_data.customernbr
                  AND     NVL(HC.customerShipTo,0) = 0;
-- 1.20 - BMarcoux - Start of Processing for 'LEGAL' Processing
--        'LEGAL' records do not have a bill_to_site_use_id
            IF (NVL(lr_process_data.CustomerShipTo,0) <> 9999) THEN
               cust_site_use_rec_type.bill_to_site_use_id := ln_bill_to_site_use_id;
            ELSE
               cust_site_use_rec_type.bill_to_site_use_id := NULL;
            END IF;
--          cust_site_use_rec_type.bill_to_site_use_id := ln_bill_to_site_use_id;
-- 1.20 - BMarcoux - Start of Processing for 'LEGAL' Processing
 EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  ln_bill_to_site_use_id :=NULL;
               WHEN TOO_MANY_ROWS THEN
                  ln_bill_to_site_use_id :=NULL;
               WHEN OTHERS THEN
                  gc_status_flag         :=  'PE';
                  gc_error_code          :=   SQLCODE;
                  gc_error_msg           :=   SQLERRM||' / '||'Error in bill_to_site_use_id';
                  gc_comments            :=   NULL;
                  INSERT_ERROR_PRC;
 END;
END IF;  -- CustomerShipTo=0
gc_log_msg := 'Patrick3-2';
xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
gc_api_status   :=NULL;
            gc_error_code   :=NULL;
            gc_error_msg    :=NULL;
            gc_comments     :=NULL;
--------------------------------------------------------------------------------------------------
            -- If CustomerShipTo = 0 then customernbr would be assign to attribute1
            -- else customernbr and LPAD(lr_process_data.CustomerShipTo,4,'0') would be assigned to attribute1
            -- Added logic for populating warehouse code to attribute4 only at the ship to level for Japan
            ---------------------------------------------------------------------------------------------------
            IF  (NVL(lr_process_data.CustomerShipTo,0) = 0) THEN
cust_site_use_rec_type.attribute1               :=  lr_process_data.customernbr;
               cust_site_use_rec_type.attribute4  :=  null;       -- added July-30-2007
ELSE
 IF gc_operating_unit_name = 'Haemonetics Japan K.K. JP OU'
               THEN
gc_log_msg := 'Value of charuserfld1 is - '||lr_process_data.charuserfld1;
xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
cust_site_use_rec_type.attribute1  :=
lr_process_data.customernbr||lr_process_data.CustomerShipTo;
cust_site_use_rec_type.attribute4  :=  lr_process_data.charuserfld1;       -- added July-30-2007
               ELSE
cust_site_use_rec_type.attribute1  :=
lr_process_data.customernbr||LPAD(lr_process_data.CustomerShipTo,4,'0');
END IF;
END IF;
cust_site_use_rec_type.created_by_module            :=  fnd_global.user_id;
            cust_site_use_rec_type.cust_acct_site_id            :=  ln_cust_acct_site_id;
-- This is commented based on Kandarp's email
            -- cust_site_use_rec_type.location                  :=  SUBSTR(lr_process_data.customername,1,28)
            --                                                         ||' '||cust_site_use_rec_type.attribute1;
            --Start of changes V1.10
           /* cust_site_use_rec_type.location                     :=   SUBSTR(lr_process_data.city,1,10)||' '||
                                                                     SUBSTR(lr_process_data.state,1,3)||' '||
                                                                     SUBSTR(lr_process_data.customername,1,10)||' '||
                                                                     SUBSTR(LPAD(lr_process_data.customershipto,4,'0'),1,4)||'-'||lr_process_data.oracleidentifier;*/
gc_log_msg := 'Organization Name is - '||gc_operating_unit_name ;
xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
IF gc_operating_unit_name = 'Haemonetics Japan K.K. JP OU' OR
                  gc_operating_unit_name = 'Haemonetics Medical Devices (Shanghai) Trading Co., Ltd. CN OU'   -- JUL-17-07(v 1.15)
THEN
 cust_site_use_rec_type.location := substr(lr_process_data.customername,1,7)||
                                                      '-'||lr_process_data.oracleidentifier;
 ELSE
cust_site_use_rec_type.location                     :=   SUBSTR(lr_process_data.city,1,8)||' '||
                                                                     SUBSTR(lr_process_data.state,1,3)||' '||
                                                                     SUBSTR(lr_process_data.customername,1,7)||'-'||lr_process_data.oracleidentifier;
END IF;
-- Start of changes V1.3
--1.17
--	         IF  lr_process_data.charuserfld12 IS  NOT NULL AND   (NVL(lr_process_data.CustomerShipTo,1) <> 0)   THEN
     IF  lr_process_data.charuserfld12 IS  NOT NULL THEN
--1.17
	             cust_site_use_rec_type.ship_via := lr_process_data.charuserfld12;    --Ship Method
      ELSE
	            --Start of Changed V1.9
	            cust_site_use_rec_type.ship_via := NULL;                               --Ship Method
	            --End of Changed V1.9
     END IF;
-- Start of changes V1.18
	     	 cust_site_use_rec_type.attribute2 := lr_process_data.charuserfld15;      --Attribute 2 for Customer notes
--	     	 cust_site_use_rec_type.attribute2 := lr_process_data.charuserfld13;      --Attribute 2 for Customer notes
-- Start of changes V1.18
   IF lr_process_data.charuserfld11 IS NOT NULL THEN
                    cust_site_use_rec_type.tax_code:=lr_process_data.charuserfld11;       --For tax Code
                 ELSE
                    --Start of Changed V1.9
                    cust_site_use_rec_type.tax_code:=NULL;       --For tax Code
                    --End of Changed V1.9
                 END IF;
IF lr_process_data.charuserfld10 IS NOT NULL THEN
                    cust_site_use_rec_type.tax_reference:=lr_process_data.charuserfld10;  --Tax Regisstration
                 ELSE
                    --Start of Changed V1.9
                    cust_site_use_rec_type.tax_reference:=NULL;  --Tax Regisstration
                    --End of Changed V1.9
                 END IF;
             -- End of changes V1.3
--Start of changesV1.6
gc_log_msg := 'Patrick3-6';
xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               --IF lr_process_data.intuserfld1 IS NOT NULL THEN
               --IF (lr_process_data.charuserfld14 IS NOT NULL) AND (lr_process_data.CountryCode <> 'US') THEN
               IF  lr_process_data.charuserfld14 IS NOT NULL    THEN
                  cust_site_use_rec_type.price_list_id :=lr_process_data.intuserfld1;
               ELSE
                   -- Start of changes 1.8
                   cust_site_use_rec_type.price_list_id :=NULL;
                   -- End of changes 1.8
 END IF;
    --End   of changesV1.6
fnd_msg_pub.Initialize;
gc_log_msg := 'Start of site api....';
 hz_cust_account_site_v2pub.create_cust_site_use(
                                                            p_init_msg_list         =>  FND_API.G_FALSE
                                                           ,p_cust_site_use_rec     =>  cust_site_use_rec_type
                                                           ,p_customer_profile_rec  =>  customer_profile_rec_type
                                                           ,p_create_profile        =>  FND_API.G_TRUE
                                                           ,p_create_profile_amt    =>  FND_API.G_TRUE
                                                           ,x_site_use_id           =>  ln_site_use_id
                                                           ,x_return_status         =>  gc_api_status
                                                           ,x_msg_count             =>  ln_count
                                                           ,x_msg_data              =>  lc_data
                                                           );
            IF (gc_api_status ='S') THEN
               -------------------------------------------------------------
               -- This is for updating Bill To Location in the staging table
               -------------------------------------------------------------
               IF (NVL(lr_process_data.CustomerShipTo,0) = 0) THEN
                  UPDATE_PROCESSED_VALUE(gn_record_id,ln_site_use_id);
               END IF;
            ELSIF (gc_api_status ='E') THEN
               gc_status_flag       := 'PE';
               IF (ln_count >= 1) THEN
                  FOR I IN 1..ln_count
                  LOOP
                     gc_error_code       :=   'API_ERROR';
                     gc_error_msg        :=    SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                     gc_comments         :=   'hz_cust_account_site_v2pub.create_cust_site_use';
                     INSERT_ERROR_PRC ;
                  END LOOP;
               END IF;
            END IF;
            gc_log_msg:='Flag Return By API - hz_cust_account_site_v2pub.create_cust_site_use IS '||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         EXCEPTION
         WHEN OTHERS THEN
            gc_status_flag      :=   'PE';
            gc_error_code       :=   'API_06';
            gc_error_msg        :=    SQLCODE||'-'||SQLERRM||'-'||cust_site_use_rec_type.location;
            gc_comments         :=   'API - hz_cust_account_site_v2pub.create_cust_site_use';
            INSERT_ERROR_PRC ;
         END;--create_cust_site_use
-- Added By subbu as on Jan 22
	-- Start of changes V1.3
	--*******************************************************************************8
	IF (NVL(lr_process_data.CustomerShipTo,0) = 0) THEN
	    ln_bill_to_site_use_id1 :=ln_site_use_id;
	END IF;
        ----------------------------------------------------------------------
        IF ln_bill_to_site_use_id1 is NOT NULL AND lr_process_data.creditlimit IS NOT NULL THEN
	   --API hz_customer_profile_v2pub.create_cust_profile_amt is called here
	   ----------------------------------------------------------------------
	   IF (NVL(lr_process_data.CustomerShipTo,0) = 0) THEN -- Profile needs to be created only for BILL TO
	       BEGIN
	          ------------------------------------------------
	          -- This is to derive the Cust_account_profile_id
	          ------------------------------------------------
	          BEGIN
	              SELECT  HCP.cust_account_profile_id
	              INTO    ln_cust_account_profile_id
	              FROM    hz_customer_profiles    HCP
	              WHERE   HCP.cust_account_id =ln_cust_account_id
	              AND SITE_USE_ID=ln_bill_to_site_use_id1;

	              gc_log_msg:='************DEBUG1********************'||ln_cust_account_profile_id;
	              xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
	              gc_log_msg:='************DEBUG2********************'||ln_cust_account_id;
	              xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
 EXCEPTION
	          WHEN NO_DATA_FOUND THEN
	                ln_cust_account_profile_id:=NULL;
	                gc_status_flag      :=   'PE';
	                gc_error_code       :=   'API_ERROR';
	                gc_error_msg        :=   'cust_account_profile_id Not Found';
	                gc_comments         :=   'hz_customer_profile_v2pub.create_cust_profile_amt';
	                INSERT_ERROR_PRC ;
	            WHEN OTHERS THEN
	                 ln_cust_account_profile_id:=NULL;
	                 gc_status_flag       := 'PE';
	                 gc_error_code       :=   SQLCODE;
	                 gc_error_msg        :=   SQLERRM||'/ cust_account_profile_id';
	                 gc_comments         :=  'hz_customer_profile_v2pub.create_cust_profile_amt';
	                 INSERT_ERROR_PRC;
	             END;
gc_api_status    := NULL;
	             gc_error_code    := NULL;
	             gc_error_msg     := NULL;
	             gc_comments      := NULL;
	             cust_profile_amt_rec_type.cust_account_profile_id     :=  ln_cust_account_profile_id;
	             cust_profile_amt_rec_type.cust_account_id             :=  ln_cust_account_id;
	             --Added by subbu on Jan22
cust_profile_amt_rec_type.currency_code               :=  UPPER(lr_process_data.currencycode) ;
gc_log_msg:='************DEBUG3********************'||lr_process_data.creditlimit;
	             xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
cust_profile_amt_rec_type.overall_credit_limit        :=  lr_process_data.creditlimit;
	             cust_profile_amt_rec_type.created_by_module           :=  fnd_global.user_id;
	             cust_profile_amt_rec_type.site_use_id                 :=  ln_bill_to_site_use_id1;
fnd_msg_pub.Initialize;
	             hz_customer_profile_v2pub.create_cust_profile_amt (
	                                                               p_init_msg_list              =>  FND_API.G_FALSE
	                                                              ,p_check_foreign_key          =>  FND_API.G_TRUE
	                                                              ,p_cust_profile_amt_rec       =>  cust_profile_amt_rec_type
	                                                              ,x_cust_acct_profile_amt_id   =>  ln_cust_acct_profile_amt_id
	                                                              ,x_return_status              =>  gc_api_status
	                                                              ,x_msg_count                  =>  ln_count
	                                                              ,x_msg_data                   =>  lc_data
	                                                             ) ;
gc_log_msg:='************DEBUG4********************'||gc_api_status;
	             xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
gc_log_msg:='************DEBUG5********************'||lc_data;
	             xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
 IF  (gc_api_status ='S') THEN
	                      NULL;
	                   ELSIF   (gc_api_status ='E') THEN
	                      gc_status_flag       := 'PE';
	                      IF (ln_count >= 1) THEN
	                         FOR I IN 1..ln_count
	                         LOOP
	                            gc_error_code       :=   'API_ERROR';
	                            gc_error_msg        :=    SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
	                            gc_comments         :=   'API- hz_customer_profile_v2pub.create_cust_profile_amt';
	                            INSERT_ERROR_PRC ;
	                         END LOOP;
	                      END IF;
	                   END IF;
	                   gc_log_msg:='Flag Return By API - hz_customer_profile_v2pub.create_cust_profile_amt IS '||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
	                   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
	                EXCEPTION
	                WHEN OTHERS THEN
	                gc_status_flag      :=   'PE';
	                gc_error_code       :=   'API_02';
	                gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
	                gc_comments         :=   'API - hz_customer_profile_v2pub.create_cust_profile_amt';
	                INSERT_ERROR_PRC ;
	                END;--API create_cust_profile_amt
	             END IF; -- end if for checking Bill To
         END IF; --end if for ln_cust_count = 1
         -- End of changes V1.3
         --*******************************************************************************8
 IF (lr_process_data.contactemail IS NOT NULL     OR
             lr_process_data.contactphone    IS NOT NULL  OR
             lr_process_data.contactfax      IS NOT NULL  OR
             lr_process_data.contacttelex    IS NOT NULL) OR
            (lr_process_data.contactlname IS NOT NULL     OR lr_process_data.contactfname IS NOT NULL)THEN
--------------------------------------------------
            -- API hz_party_v2pub.create_person is called here
            --------------------------------------------------
            BEGIN
               gc_api_status       :=  NULL;
               gc_error_code       :=  NULL;
               gc_error_msg        :=  NULL;
               gc_comments         :=  NULL;
               person_rec_type.created_by_module           :=  fnd_global.user_id;
               --------------------------------------------------------------------------------------------------------
               -- if person_first_name or person_last_name  are null then 'Not Applicable' would be assigned as default
               --------------------------------------------------------------------------------------------------------
               IF (lr_process_data.contactlname IS NOT NULL) THEN
                  person_rec_type.person_last_name         :=  lr_process_data.contactlname;
               ELSE
                  person_rec_type.person_last_name         :=  'Not Applicable';
               END IF;
                  person_rec_type.person_first_name        :=  lr_process_data.contactfname;
fnd_msg_pub.Initialize;
               hz_party_v2pub.create_person(
                                            p_init_msg_list =>  fnd_api.g_false
                                           ,p_person_rec    =>  person_rec_type
                                           ,x_party_id      =>  ln_person_party_id
                                           ,x_party_number  =>  lc_person_party_number
                                           ,x_profile_id    =>  ln_person_profile_id
                                           ,x_return_status =>  gc_api_status
                                           ,x_msg_count     =>  ln_count
                                           ,x_msg_data      =>  lc_data
                                           );
               IF  (gc_api_status ='S') THEN
                  NULL;
               ELSIF   (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
                  IF (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=   SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                        gc_comments         :=   'hz_party_v2pub.create_person';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
               gc_log_msg:='Flag Return By API - hz_party_v2pub.create_person IS '||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_07';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_party_v2pub.create_person';
               INSERT_ERROR_PRC ;
            END;--create_person
            ---------------------------------------------------------------
            -- API hz_party_contact_v2pub.create_org_contact is called here
            ---------------------------------------------------------------
            BEGIN
                gc_api_status    :=NULL;
                gc_error_code    :=NULL;
                gc_error_msg     :=NULL;
                gc_comments      :=NULL;
                org_contact_rec_type.created_by_module        :=  fnd_global.user_id;
                org_contact_rec_type.comments                 :=  NULL;
                -- org_contact_rec_type.contact_number           :=  lr_process_data.contactphone;
                org_contact_rec_type.title                    :=  NULL;
                org_contact_rec_type.job_title                :=  NULL;
                org_contact_rec_type.party_site_id            :=  ln_party_site_id;
                org_contact_rec_type.orig_system_reference    :=  NULL;
 org_contact_rec_type.party_rel_rec.relationship_id     := NULL;
                org_contact_rec_type.party_rel_rec.subject_id          := ln_person_party_id;
                --The subject_id is Party Id of hz_party_v2pub.create_person
org_contact_rec_type.party_rel_rec.subject_type        := 'PERSON';
                org_contact_rec_type.party_rel_rec.subject_table_name  := 'HZ_PARTIES';
                org_contact_rec_type.party_rel_rec.object_id           :=  ln_party_id;
                --The object_id is party_id of hz_cust_account_v2pub.create_cust_account
org_contact_rec_type.party_rel_rec.object_type         := 'ORGANIZATION';
                org_contact_rec_type.party_rel_rec.object_table_name   := 'HZ_PARTIES';
                org_contact_rec_type.party_rel_rec.relationship_code   := 'CONTACT_OF';
                org_contact_rec_type.party_rel_rec.relationship_type   := 'CONTACT';
                org_contact_rec_type.party_rel_rec.status              := 'A';
                org_contact_rec_type.party_rel_rec.created_by_module   :=fnd_global.user_id;
fnd_msg_pub.Initialize;
                hz_party_contact_v2pub.create_org_contact(
                                                           p_init_msg_list   =>  FND_API.G_FALSE
                                                          ,p_org_contact_rec =>  org_contact_rec_type
                                                          ,x_org_contact_id  =>  ln_org_contact_id
                                                          ,x_party_rel_id    =>  ln_org_party_rel_id
                                                          ,x_party_id        =>  ln_org_party_id
                                                          ,x_party_number    =>  ln_org_party_number
                                                          ,x_return_status   =>  gc_api_status
                                                          ,x_msg_count       =>  ln_count
                                                          ,x_msg_data        =>  lc_data
                                                         );
               IF (gc_api_status ='S') THEN
                  NULL;
               ELSIF   (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
                  IF (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=   SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                        gc_comments         :=   'hz_party_contact_v2pub.create_org_contact';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
gc_log_msg:='Flag Return By API - hz_party_contact_v2pub.create_org_contact IS '||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_08';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_party_contact_v2pub.create_org_contact';
               INSERT_ERROR_PRC ;
            END;-- create_org_contact
-------------------------------------------------------------------------
            -- API hz_cust_account_role_v2pub.create_cust_account_role is called here
            -------------------------------------------------------------------------
            BEGIN
               gc_api_status    :=NULL;
               gc_error_code    :=NULL;
               gc_error_msg     :=NULL;
               gc_comments      :=NULL;
cust_account_role_rec_type.party_id              := ln_org_party_id;
               -- pass the party id of hz_party_contact_v2pub.create_org_contact
               cust_account_role_rec_type.cust_account_id       := ln_cust_account_id;
               cust_account_role_rec_type.cust_acct_site_id     := ln_cust_acct_site_id;
               -- Do not pass the cust_acct_site_id if you want the contact at customer level
               cust_account_role_rec_type.primary_flag          := 'N';
               cust_account_role_rec_type.status                := 'A';
               cust_account_role_rec_type.role_type             := 'CONTACT';
               cust_account_role_rec_type.orig_system_reference := NULL;
               cust_account_role_rec_type.created_by_module     := fnd_global.user_id;
 fnd_msg_pub.Initialize;
               hz_cust_account_role_v2pub.create_cust_account_role(
                                                                  p_init_msg_list         =>  fnd_api.g_false
                                                                 ,p_cust_account_role_rec =>  cust_account_role_rec_type
                                                                 ,x_cust_account_role_id  =>  ln_cust_account_role_id
                                                                 ,x_return_status         =>  gc_api_status
                                                                 ,x_msg_count             =>  ln_count
                                                                 ,x_msg_data              =>  lc_data
                                                                );
               IF  (gc_api_status ='S') THEN
                  NULL;
               ELSIF  (gc_api_status ='E') THEN
                  gc_status_flag       := 'PE';
 IF  (ln_count >= 1) THEN
                     FOR I IN 1..ln_count
                     LOOP
                        gc_error_code       :=   'API_ERROR';
                        gc_error_msg        :=   SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                        gc_comments         :=   'hz_cust_account_role_v2pub.create_cust_account_role';
                        INSERT_ERROR_PRC ;
                     END LOOP;
                  END IF;
               END IF;
               gc_log_msg:='Flag Return By API - hz_cust_account_role_v2pub.create_cust_account_role  IS '||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_09';
               gc_error_msg        :=    SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_cust_account_role_v2pub.create_cust_account_role';
               INSERT_ERROR_PRC ;
            END;--create_cust_account_role
-----------------------------------------------------------------------------------------------
            -- API hz_contact_point_v2pub.create_contact_point is called here for email,phone,fax and telex
            -----------------------------------------------------------------------------------------------
            BEGIN
               FOR  I   IN  1..4
               LOOP
                  gc_api_status    :=NULL;
                  gc_error_code    :=NULL;
                  gc_error_msg     :=NULL;
                  gc_comments      :=NULL;
lc_contact_type  :=NULL;
                  SELECT DECODE (i
                                ,1,'EMAIL'
                                ,2,'PHONE'
                                ,3,'FAX'
                                ,4,'TELEX')
                  INTO lc_contact_type
                  FROM dual;
                  IF (lc_contact_type= 'EMAIL' AND lr_process_data.contactemail IS NOT NULL) THEN
 ----------------------------------------------------------------------
                     -- API hz_contact_point_v2pub.create_contact_point is called for email
                     ----------------------------------------------------------------------
                     email_rec_type.email_address := lr_process_data.contactemail;
                     contact_point_rec_type.contact_point_type         := 'EMAIL';

                     contact_point_rec_type.owner_table_name           := 'HZ_PARTIES';
                     contact_point_rec_type.owner_table_id             :=  ln_org_party_id;
                     contact_point_rec_type.created_by_module          :=  fnd_global.user_id;
                     fnd_msg_pub.Initialize;
                     hz_contact_point_v2pub.create_contact_point(
                                                                 p_init_msg_list        =>   FND_API.G_FALSE
                                                                ,p_contact_point_rec    =>   contact_point_rec_type
                                                                ,p_edi_rec              =>   edi_rec_type
                                                                ,p_email_rec            =>   email_rec_type
                                                                ,p_phone_rec            =>   phone_rec_type
                                                                ,p_telex_rec            =>   telex_rec_type
                                                                ,p_web_rec              =>   web_rec_type
                                                                ,x_contact_point_id     =>   ln_contact_point_id
                                                                ,x_return_status        =>   gc_api_status
                                                                ,x_msg_count            =>   ln_count
                                                                ,x_msg_data             =>   lc_data
                                                                );
                  ELSIF (lc_contact_type= 'PHONE' AND lr_process_data.contactphone IS NOT NULL) THEN
                     ----------------------------------------------------------------------
                     -- API hz_contact_point_v2pub.create_contact_point is called for phone
                     ----------------------------------------------------------------------
                     contact_point_rec_type.contact_point_type     := 'PHONE';
                     phone_rec_type.raw_phone_number               := lr_process_data.contactphone;
                     phone_rec_type.phone_line_type                := 'GEN';
                     phone_rec_type.phone_extension                := lr_process_data.contactphoneext;

                     contact_point_rec_type.owner_table_name           := 'HZ_PARTIES';
                     contact_point_rec_type.owner_table_id             :=  ln_org_party_id;
                     contact_point_rec_type.created_by_module          :=  fnd_global.user_id;
                     fnd_msg_pub.Initialize;
                     hz_contact_point_v2pub.create_contact_point(
                                                                 p_init_msg_list        =>   FND_API.G_FALSE
                                                                ,p_contact_point_rec    =>   contact_point_rec_type
                                                                ,p_edi_rec              =>   edi_rec_type
                                                                ,p_email_rec            =>   email_rec_type
                                                                ,p_phone_rec            =>   phone_rec_type
                                                                ,p_telex_rec            =>   telex_rec_type
                                                                ,p_web_rec              =>   web_rec_type
                                                                ,x_contact_point_id     =>   ln_contact_point_id
                                                                ,x_return_status        =>   gc_api_status
                                                                ,x_msg_count            =>   ln_count
                                                                ,x_msg_data             =>   lc_data
                                                                );
                  ELSIF (lc_contact_type= 'FAX' AND lr_process_data.contactfax IS NOT NULL) THEN
                     ----------------------------------------------------------------------
                     -- API hz_contact_point_v2pub.create_contact_point is called for fax
                     ----------------------------------------------------------------------
                     phone_rec_type.phone_line_type                := 'FAX';
                     contact_point_rec_type.contact_point_type     := 'PHONE';
                     phone_rec_type.raw_phone_number               :=  lr_process_data.contactfax;
                     phone_rec_type.phone_extension                :=  NULL;
                     contact_point_rec_type.owner_table_name       := 'HZ_PARTIES';
                     contact_point_rec_type.owner_table_id         :=  ln_org_party_id;
                     contact_point_rec_type.created_by_module      :=  fnd_global.user_id;
                     fnd_msg_pub.Initialize;
                     hz_contact_point_v2pub.create_contact_point(
                                                                 p_init_msg_list        =>   FND_API.G_FALSE
                                                                ,p_contact_point_rec    =>   contact_point_rec_type
                                                                ,p_edi_rec              =>   edi_rec_type
                                                                ,p_email_rec            =>   email_rec_type
                                                                ,p_phone_rec            =>   phone_rec_type
                                                                ,p_telex_rec            =>   telex_rec_type
                                                                ,p_web_rec              =>   web_rec_type
                                                                ,x_contact_point_id     =>   ln_contact_point_id
                                                                ,x_return_status        =>   gc_api_status
                                                                ,x_msg_count            =>   ln_count
                                                                ,x_msg_data             =>   lc_data
                                                                );
                  ELSIF (lc_contact_type= 'TELEX' AND lr_process_data.contacttelex IS NOT NULL) THEN
                     ----------------------------------------------------------------------
                     -- API hz_contact_point_v2pub.create_contact_point is called for telex
                     ----------------------------------------------------------------------
                     contact_point_rec_type.contact_point_type          := 'TLX';
                     telex_rec_type.telex_number                        := lr_process_data.contacttelex;
                     contact_point_rec_type.owner_table_name            := 'HZ_PARTIES';
                     contact_point_rec_type.owner_table_id              :=  ln_org_party_id;
                     contact_point_rec_type.created_by_module           :=  fnd_global.user_id;
                     fnd_msg_pub.Initialize;
                     hz_contact_point_v2pub.create_contact_point(
                                                                 p_init_msg_list        =>   FND_API.G_FALSE
                                                                ,p_contact_point_rec    =>   contact_point_rec_type
                                                                ,p_edi_rec              =>   edi_rec_type
                                                                ,p_email_rec            =>   email_rec_type
                                                                ,p_phone_rec            =>   phone_rec_type
                                                                ,p_telex_rec            =>   telex_rec_type
                                                                ,p_web_rec              =>   web_rec_type
                                                                ,x_contact_point_id     =>   ln_contact_point_id
                                                                ,x_return_status        =>   gc_api_status
                                                                ,x_msg_count            =>   ln_count
                                                                ,x_msg_data             =>   lc_data
                                                                );
                  END IF;

                  IF  (gc_api_status ='S') THEN
                     NULL;
                  ELSIF   (gc_api_status ='E') THEN
                     gc_status_flag       := 'PE';
                     IF (ln_count >= 1) THEN
                        FOR I IN 1..ln_count
                        LOOP
                           gc_error_code       :=   'API_ERROR';
                           gc_error_msg        :=   SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded =>FND_API.G_FALSE),1,255);
                           gc_comments         :=   'hz_contact_point_v2pub.create_contact_point';
                           INSERT_ERROR_PRC ;
                        END LOOP;
                     END IF;
                  END IF;
                  gc_log_msg:='Flag Return By API - hz_contact_point_v2pub.create_contact_point ('||lc_contact_type||') IS '||NVL(gc_status_flag,'PS')||' ,Oracleidentifier - '||lr_process_data.oracleidentifier;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               END LOOP;
            EXCEPTION
            WHEN OTHERS THEN
               gc_status_flag      :=   'PE';
               gc_error_code       :=   'API_10';
               gc_error_msg        :=   SQLCODE||'-'||SQLERRM;
               gc_comments         :=   'API - hz_contact_point_v2pub.create_contact_point';
               INSERT_ERROR_PRC ;
            END;--create_contact_point

         END IF; -- END IF for contactemail or contactphone or contactfax or contacttelex

         IF (gc_debug_flag = 'Y') THEN
  FND_FILE.PUT_LINE(FND_FILE.LOG,'****************************************************************************************');
         END IF;
IF (gc_status_flag   IS NULL) THEN
            gc_status_flag      :=   'PS';
            UPDATE_ERROR(gn_record_id ,gc_status_flag);
         ELSE
            UPDATE_ERROR(gn_record_id ,gc_status_flag);
         END IF;

      END LOOP; -- end loop for CURSOR lcu_process_data
-------------------------------------------------------------------------
   -- This is to count the error records from xxha_common_errors error table
   -------------------------------------------------------------------------
   ln_error_count_com :=0;
   BEGIN
      SELECT  COUNT(*)
      INTO    ln_error_count_com
      FROM    xxha_common_errors XCE
      WHERE   XCE.request_id =  gn_request_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      ln_error_count_com  :=0;
   END;
ln_request_id:=gn_request_id;
---------------------------------------------------------------
   -- This is to display the status of the records in the log file
   ---------------------------------------------------------------
   IF   (ln_error_count_com =0) THEN
        COMMIT;
        FND_FILE.PUT_LINE(FND_FILE.LOG,'******************************************');
        FND_FILE.PUT_LINE(FND_FILE.LOG,'All the Records Are Processed and Commited');
        FND_FILE.PUT_LINE(FND_FILE.LOG,'******************************************');
   ELSE
        ROLLBACK;
        FND_FILE.PUT_LINE(FND_FILE.LOG,'*********************************************');
        FND_FILE.PUT_LINE(FND_FILE.LOG,'All the Records Are Processed and Rolled Back');
        FND_FILE.PUT_LINE(FND_FILE.LOG,'*********************************************');
        xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
        x_ret_code:=1;
   END IF;
--------------------------------------------------------------------
   -- This is to count the total number of records from haemo_customers
   --------------------------------------------------------------------
  ln_count_total:=0;
  BEGIN
      SELECT  COUNT(*)
      INTO    ln_count_total
      FROM    haemo_customers HC
      WHERE   HC.charuserfld5     =  gc_operating_unit_name
      AND     HC.oraclecharfld1   IS NOT NULL
      AND     HC.oracleintfld8    =   ln_request_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      ln_count_total  :=0;
   END;
--------------------------------------------------------------
   -- This is to count the records which are having status = 'PS'
   --------------------------------------------------------------
   ln_process_count:=0;
   BEGIN
      SELECT  COUNT(*)
      INTO    ln_process_count
      FROM    haemo_customers HC
      WHERE   HC.charuserfld5     =   gc_operating_unit_name
      AND     HC.oraclecharfld1   =   'PS'
      AND     HC.oracleintfld8    =   ln_request_id;
   EXCEPTION
   WHEN  NO_DATA_FOUND THEN
      ln_process_count  :=0;
   END;
   --------------------------------------------------------------
   -- This is to count the records which are having status = 'VS'
   --------------------------------------------------------------
  ln_count_error:=0;
  BEGIN
      SELECT  COUNT(*)
      INTO    ln_count_error
      FROM    haemo_customers HC
      WHERE   HC.charuserfld5     =   gc_operating_unit_name
      AND     HC.oraclecharfld1   =   'PE'
      AND     HC.oracleintfld8    =   ln_request_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      ln_count_error  :=0;
   END;
FND_FILE.PUT_LINE(FND_FILE.LOG,'****************************************************************************');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary Information of HAEMO_CUSTOMERS Records Processed                    ');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'****************************************************************************');
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Number of Records                 :'||ln_count_total);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Processed                 :'||ln_process_count);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored Out               :'||ln_count_error);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'****************************************************************************');
ELSE
      FND_FILE.PUT_LINE(FND_FILE.LOG,'ERROR Record Exists in the Staging table');
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
      x_ret_code:=1;
   END IF; -- Error Count end if
ELSE
x_ret_code:=2;
END IF; -- Setup error flag is 'No' (end if)
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_AR_CUST_CONV_PK.PROCESS_CUST_DATA: ' || SQLERRM);
   xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_con_name,gc_identifier);
   ROLLBACK;
   x_ret_code:=1;
END PROCESS_CUST_DATA;
END XXHA_AR_CUST_CONV_PK;
/
