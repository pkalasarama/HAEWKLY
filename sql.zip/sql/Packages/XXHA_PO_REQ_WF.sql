CREATE OR REPLACE PACKAGE XXHA_PO_REQ_WF AUTHID CURRENT_USER is

procedure proj_intermediate_lookup ( itemtype        in  varchar2,
                     itemkey         in  varchar2,
                     actid           in  number,
                     funcmode        in  varchar2,
                     result          out varchar2 );

END XXHA_PO_REQ_WF;

/


CREATE OR REPLACE PACKAGE BODY XXHA_PO_REQ_WF is


procedure proj_intermediate_lookup  ( itemtype        in  varchar2,
                     itemkey         in  varchar2,
                     actid           in  number,
                     funcmode        in  varchar2,
                     result          out varchar2    )
is
  x_progress     varchar2(100);
  success        varchar2(2);
  x_expenditure_type_in   varchar2(30) := NULL;
  x_project_type varchar2(20) := NULL;
  x_expenditure_type_out  varchar2(30) := NULL;
  x_expenditure_category varchar2(30) := NULL;

  X_VENDOR_EMPLOYEE_ID  NUMBER ;
  X_PREPARER_ID   NUMBER;

  X_SUGGESTED_VENDOR_ID NUMBER;

  X_VENDOR_EMPLOYEE_NUMBER VARCHAR2(100);

  X_LE_SEGMENT VARCHAR2(100);

  X_DEP_SEGMENT VARCHAR2(100);
  X_TO_PERSON_ID NUMBER;
  x_class_code varchar2(100);

  x_EXPENDITURE_TYPE varchar2(100);

  x_PROJECT_ORGANIZATION_NAME varchar2(100);

  X_PRODUCT_SEG varchar2(100);

  X_MGMT_SEG varchar2(100);

  X_ACCT_SEG varchar2(100);

begin

  x_progress := 'XXHA_PO_REQ_WF.proj_intermediate_lookup: 01';
  /* DEBUG */  PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);


  -- Do nothing in cancel or timeout mode
  --
  if (funcmode <> wf_engine.eng_run) then

      result := wf_engine.eng_null;
      return;

  end if;

  X_TO_PERSON_ID := wf_engine.GetItemAttrText ( itemtype => itemtype,
                                                itemkey  => itemkey,
                                                aname    => 'TO_PERSON_ID');

  x_class_code := wf_engine.GetItemAttrText ( itemtype => itemtype,
                                                itemkey  => itemkey,
                                                aname    => 'CLASS_CODE');

  x_EXPENDITURE_TYPE := wf_engine.GetItemAttrText ( itemtype => itemtype,
                                                itemkey  => itemkey,
                                                aname    => 'EXPENDITURE_TYPE');

       x_PROJECT_ORGANIZATION_NAME := wf_engine.GetItemAttrText ( itemtype => itemtype,
                                                itemkey  => itemkey,
                                                aname    => 'PROJECT_ORGANIZATION_NAME');






SELECT glcc.segment1, glcc.segment5
  INTO x_le_segment, x_dep_segment
  FROM per_all_assignments_f paf, gl_code_combinations glcc
 WHERE paf.person_id = x_to_person_id
   AND SYSDATE BETWEEN paf.effective_start_date AND paf.effective_end_date
   AND paf.default_code_comb_id = glcc.code_combination_id;

                    wf_engine.SetItemAttrText  (  itemtype=>itemtype,
                                  itemkey=>itemkey,
                                  aname=>'X_HSS_LE_SEG',
                                  avalue=>X_LE_SEGMENT );

                                  wf_engine.SetItemAttrText  (  itemtype=>itemtype,
                                  itemkey=>itemkey,
                                  aname=>'X_HSS_DEP_SEG',
                                  avalue=>X_DEP_SEGMENT );


SELECT segment_value
  INTO x_product_seg
  FROM pa_segment_value_lookup_sets psvls, pa_segment_value_lookups psvl
 WHERE psvls.segment_value_lookup_set_name = 'Product Line Lookup Set'
   AND psvls.segment_value_lookup_set_id = psvl.segment_value_lookup_set_id
   AND segment_value_lookup = x_class_code;



SELECT segment_value
  INTO x_mgmt_seg
  FROM pa_segment_value_lookup_sets psvls, pa_segment_value_lookups psvl
 WHERE psvls.segment_value_lookup_set_name = 'Management Unit Lookup Set'
   AND psvls.segment_value_lookup_set_id = psvl.segment_value_lookup_set_id
   AND segment_value_lookup = x_project_organization_name;


SELECT segment_value
  INTO x_acct_seg
  FROM pa_segment_value_lookup_sets psvls, pa_segment_value_lookups psvl
 WHERE psvls.segment_value_lookup_set_name = 'Expenditure Type Lookup set'
   AND psvls.segment_value_lookup_set_id = psvl.segment_value_lookup_set_id
   AND segment_value_lookup = x_expenditure_type;


 wf_engine.SetItemAttrText  (  itemtype=>itemtype,
                                  itemkey=>itemkey,
                                  aname=>'X_HSS_PL_SEG',
                                  avalue=>X_PRODUCT_SEG );

                                  wf_engine.SetItemAttrText  (  itemtype=>itemtype,
                                  itemkey=>itemkey,
                                  aname=>'X_HSS_MGMT_SEG',
                                  avalue=>X_MGMT_SEG );

                                  wf_engine.SetItemAttrText  (  itemtype=>itemtype,
                                  itemkey=>itemkey,
                                  aname=>'X_HSS_ACCT_SEG',
                                  avalue=>X_ACCT_SEG );


  result := 'COMPLETE:SUCCESS';
  RETURN;

EXCEPTION
  WHEN OTHERS THEN
      wf_core.context('XXHA_PO_REQ_WF.proj_intermediate_lookup',
                                                       'expenditure type',x_progress);
        raise;

end proj_intermediate_lookup;

END XXHA_PO_REQ_WF;

/
