CREATE OR REPLACE PACKAGE XXHA_RTV_PAYMENT_SCHED_STATUS AS

/*****************************************************************************************
* Package Name : XXHA_RTV_PAYMENT_SCHED_STATUS                                           *
* Purpose      : This package provides a function to determine the status of a payment.  *
*                                                                                        *
* Function     : XXHA_RTV_STATUS                                                         *
*                                                                                        *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*  ar_payment_schedules_all  S                                                           *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        06-Jan-2009     B. Marcoux           Initial Version                        *
*****************************************************************************************/

  FUNCTION XXHA_RTV_STATUS (p_cti NUMBER, p_org_id NUMBER, p_status_trx VARCHAR2)
  RETURN VARCHAR2;

END XXHA_RTV_PAYMENT_SCHED_STATUS;
/


CREATE OR REPLACE PACKAGE BODY XXHA_RTV_PAYMENT_SCHED_STATUS AS

/*****************************************************************************************
* Package Name : XXHA_RTV_PAYMENT_SCHED_STATUS                                           *
* Purpose      : This package provides a function to determine the status of a payment.  *
*                                                                                        *
* Called From  : XXHA_RAXINV - Invoicing                                                 *
*                                                                                        *
* Parameters             Type       Description                                          *
* p_cti                  Nbr                                                             *
* p_org_id               Nbr                                                             *
* p_status_trx           Nbr                                                             *
*                                                                                        *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*  ar_payment_schedules_all  S                                                           *
*                                                                                        *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        06-Jan-2009     B. Marcoux           Initial Version                        *
*****************************************************************************************/


/* ************************************************************************************ */
/* Given customer_transaction_id and org_id and selected status, return actual status   */
FUNCTION XXHA_RTV_STATUS (p_cti NUMBER, p_org_id NUMBER, p_status_trx VARCHAR2) 
RETURN VARCHAR2 IS
lp_status       VARCHAR2(5);

BEGIN

-- Status can be OP or CL, if any record has a status of OP then we want OP
-- (as OP is greater than CL, we use the max function)
-- A status of OP should be the overriding factor when determining the status (per Roberto Casanova)
SELECT MAX(apsa.status)
  INTO lp_status
  FROM ar_payment_schedules_all apsa
 WHERE
       apsa.customer_trx_id = p_cti
   AND apsa.org_id          = p_org_id
;


--SELECT apsa.status 
--  INTO lp_status
--  FROM ar_payment_schedules_all apsa
-- WHERE
--       apsa.customer_trx_id = p_cti
--   AND apsa.org_id          = p_Org_id
--   AND apsa.status          = DECODE(p_status_trx, 'CL', 'CL','OP','OP','BOTH',apsa.status)
--   AND apsa.due_date        = 
--           (SELECT MAX(Due_Date) 
--              FROM ar_payment_schedules_all apsa
--             WHERE
--                   apsa.customer_trx_id = p_cti
--               AND apsa.org_id          = p_Org_id)
--;


RETURN lp_status;

EXCEPTION
   WHEN OTHERS THEN
           RETURN 'NA';

END XXHA_RTV_STATUS;
END XXHA_RTV_PAYMENT_SCHED_STATUS;
/
