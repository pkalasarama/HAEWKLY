

CREATE OR REPLACE PACKAGE BODY "APPS"."XXHA_WMS_RESERVE_CONC_HOOK" AS
  /*******************************************************************************************************
  * Object Name: XXHA_RATESHOP_ONDEMAND_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package is modified to restrict the outbound exception items for reservation in WMS orgs
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    27-APR-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
--  Global constant holding the package name
G_PKG_NAME                    CONSTANT VARCHAR2(30) := 'XXHA_WMS_RESERVE_CONC_HOOK';

Procedure Qty_Per_Business_Rule
(p_x_rsv_tbl           IN OUT NOCOPY /* file.sql.39 change */ XXHA_WMS_RESERVE_CONC.rsv_tbl_type)
IS
BEGIN
   -- Write your code here
   NULL;
END Qty_Per_Business_Rule;

Procedure Simulated_Results
(p_x_rsv_tbl           IN OUT NOCOPY /* file.sql.39 change */ XXHA_WMS_RESERVE_CONC.rsv_tbl_type)
IS
BEGIN
   -- Write your code here
   NULL;
END Simulated_Results;


END XXHA_WMS_RESERVE_CONC_HOOK;
/