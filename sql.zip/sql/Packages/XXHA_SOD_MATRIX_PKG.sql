create or replace PACKAGE XXHA_SOD_MATRIX_PKG AUTHID CURRENT_USER
AS

/************************************************************************************************************************
* Package Name : XXHA_SOD_MATRIX_PKG                                                                                    *
* Purpose      : This package will be utilized to capture all conflicting responsibilities and to define the            *
*                  SOD conflict.                                                                                        *
*                                                                                                                       *
* PROCEDURES   : PROCESS_DATA                                                                                           *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        02-OCT-2017     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

--------------------------------------------------------------------------------
-- PROCEDURE PROCESS_DATA

PROCEDURE PROCESS_DATA(
                      p_REPORT_TYPE    IN  VARCHAR2
                    , p_DATE           IN  DATE
                    , p_SEQUENCE       OUT NUMBER
                      );

END XXHA_SOD_MATRIX_PKG;