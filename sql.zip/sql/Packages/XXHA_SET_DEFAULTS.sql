CREATE OR REPLACE PACKAGE XXHA_SET_DEFAULTS IS

/************************************************************************************************************************
* Package Name : XXHA_SET_DEFAULTS                                                                                      *
* Purpose      : This package provides a function to validate the release status.                                       *
*                                                                                                                       *
* Procedures   : validate_release_status                                                                                *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
* - WSH_DELIVERY_LINE_STATUS_V        I                                                                                 *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        07-AUG-2014     Harish Kollipara     Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

PROCEDURE validate_release_status (
      p_application_id                 IN  NUMBER,
      p_entity_short_name              IN  VARCHAR2,
      p_validation_entity_short_name   IN  VARCHAR2,
      p_validation_tmplt_short_name    IN  VARCHAR2,
      p_record_set_tmplt_short_name    IN  VARCHAR2,
      p_scope                          IN  VARCHAR2,
      x_result_out                     OUT NOCOPY NUMBER);
END XXHA_SET_DEFAULTS;
/


CREATE OR REPLACE PACKAGE BODY XXHA_SET_DEFAULTS IS

/************************************************************************************************************************
* Package Name : XXHA_SET_DEFAULTS                                                                                      *
* Purpose      : This package provides a function to validate the release status.                                       *
*                                                                                                                       *
* Procedures   : validate_release_status                                                                                *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
* - WSH_DELIVERY_LINE_STATUS_V        I                                                                                 *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        07-AUG-2014     Harish Kollipara     Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

PROCEDURE validate_release_status (
      p_application_id                 IN  NUMBER,
      p_entity_short_name              IN  VARCHAR2,
      p_validation_entity_short_name   IN  VARCHAR2,
      p_validation_tmplt_short_name    IN  VARCHAR2,
      p_record_set_tmplt_short_name    IN  VARCHAR2,
      p_scope                          IN  VARCHAR2,
      x_result_out                     OUT NOCOPY NUMBER)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      x_header_id        NUMBER := oe_header_security.g_record.header_id;
      l_Release_Status   VARCHAR2 (1);
      l_pick_status      VARCHAR2 (1);
      l_ship_status      VARCHAR2 (1);
      l_pick_rel_status  VARCHAR2 (1);
      l_ship_qty         NUMBER;
      l_pick_rel_cnt     NUMBER;

   BEGIN

   l_pick_rel_cnt :=0;

      BEGIN
         SELECT count(1)
           INTO l_pick_rel_cnt
           FROM WSH_DELIVERY_LINE_STATUS_V
          WHERE SOURCE_CODE = 'OE'
            AND SOURCE_header_id = x_header_id
            AND PICK_STATUS in ('S', 'Y','C'); --Shipped,staged

         IF NVL(l_pick_rel_cnt,0) > 0 THEN      
            l_pick_rel_status := 'S';
         ELSE
            l_pick_rel_status := 'X';
         END IF;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               l_pick_rel_status := 'X';
            WHEN OTHERS THEN
               l_pick_rel_status := 'X';
      END;

      BEGIN
         SELECT SUM (wv.SHIPPED_QUANTITY)
           INTO l_ship_qty
           FROM WSH_DELIVERY_LINE_STATUS_V wv, oe_order_lines_all ool
          WHERE wv.SOURCE_CODE = 'OE'
            AND wv.SOURCE_header_id = x_header_id
            AND ool.line_id = wv.source_line_id
            AND ool.LINE_CATEGORY_CODE = 'ORDER'
            AND wv.PICK_STATUS = 'S';

         IF NVL (l_ship_qty, 0) > 0
         THEN 
            l_ship_status := 'S';
         ELSE
            l_ship_status := 'X';
         END IF;
         EXCEPTION
            WHEN OTHERS THEN
               l_ship_status := 'X';
      END;

      IF l_pick_rel_status = 'S' OR l_ship_status = 'S' THEN
         x_result_out := 1;
      ELSE
         x_result_out := 0;
      END IF;

      COMMIT;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN 
         COMMIT;
         x_result_out := 0;
      WHEN TOO_MANY_ROWS THEN 
         COMMIT;
         x_result_out := 1;
      WHEN OTHERS THEN 
         COMMIT;
         x_result_out := 0;
   END validate_release_status;
END XXHA_SET_DEFAULTS;
/
