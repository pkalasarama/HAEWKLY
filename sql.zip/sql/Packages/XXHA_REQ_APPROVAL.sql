CREATE OR REPLACE PACKAGE      xxha_req_approval AS
/*****************************************************************************
 PURPOSE: package body Used in Requisition Workflow
 HISTORY
 =============================================================================
 VERSION DATE          AUTHOR(S)       DESCRIPTION
 ------- -----------   --------------- ----------------------------------------
 1.0     07-Jun-2010   Dave Lund       Created this package.
********************************************************************************/
 -- Read the profile option that enables/disables the debug log
 g_po_wf_debug VARCHAR2(1) := NVL(FND_PROFILE.VALUE('PO_SET_DEBUG_WORKFLOW_ON'),'N');
 g_requestor_id per_people_f.person_id%TYPE;
 procedure change_preparor_to_requestor(     itemtype        in varchar2,
                                 itemkey         in varchar2,
                                 actid           in number,
                                 funcmode        in varchar2,
                                 resultout       out NOCOPY varchar2    )
;
end xxha_req_approval;
/


CREATE OR REPLACE PACKAGE BODY      xxha_req_approval AS
/*****************************************************************************
==========================================================================
 PURPOSE: package body Used in Requisition Workflow 
 HISTORY
 =============================================================================
 =============================================================================
 VERSION DATE          AUTHOR(S)       DESCRIPTION
 ------- -----------   --------------- ----------------------------------------
 1.0     07-Jun-2010   Dave Lund       Created this package.
********************************************************************************/
 -- Read the profile option that enables/disables the debug log
 procedure change_preparor_to_requestor(     itemtype        in varchar2,
                                 itemkey         in varchar2,
                                 actid           in number,
                                 funcmode        in varchar2,
                                 resultout       out NOCOPY varchar2    )
 IS 
 /*****************************************************************************
 PURPOSE: Requisition approval hierarchy changed from preparor to requestor
*****************************************************************************/
 x_progress 			varchar2(100);
 l_doc_string 			varchar2(200);
 l_preparer_user_name 		varchar2(100);
 l_document_id 			NUMBER;
 l_preparer_id			NUMBER;
 x_username    			varchar2(100);
 x_user_display_name 		varchar2(240);
 x_req_username    			varchar2(100);
 x_req_display_name 		varchar2(240);
 x_ff_username    		varchar2(100);
 x_ff_user_display_name 	varchar2(240);
 x_ft_username    		varchar2(100);
 x_ft_user_display_name 	varchar2(240);
 l_forward_to_id     		number;
 l_forward_from_id   		number;
 l_supervisor_id   		number;
 ls_function_name		VARCHAR2(50) := 'change_preparor_to_requestor: ';
 BEGIN
   x_progress := 'xx_req_cust.set_prep_id: 01';
   /* DEBUG */
   IF (g_po_wf_debug = 'Y') THEN
	PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey, ls_function_name || 'START');
  	PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey,x_progress);
   END IF;
        l_document_id := wf_engine.GetItemAttrNumber (itemtype => itemtype,
                                          itemkey  => itemkey,
                                          aname    => 'DOCUMENT_ID');
      BEGIN
	       SELECT distinct to_person_id
	       INTO   l_preparer_id
	       FROM   po_requisition_lines_all
	       WHERE  requisition_header_id = l_document_id;
       EXCEPTION
         WHEN Others THEN
	   IF (g_po_wf_debug = 'Y') THEN
          PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey, ls_function_name || 'Preparer_id Exception '||SQLERRM);
   	   END IF;
       END;
	g_requestor_id := apps.PO_WF_UTIL_PKG.GetItemAttrNumber ( itemtype   => itemType,
                                  itemkey    => itemkey,
                                  aname      => 'REQUESTOR_ID'
                       			  );
--    apps.PO_REQAPPROVAL_INIT1.get_user_name(g_requestor_id, x_req_username,	x_req_display_name);
  begin
    select full_name 
    into x_req_display_name
    from per_people_x
    where person_id = l_preparer_id;
  exception when others then 
  x_req_display_name := 'dave';
  end;
	wf_engine.SetItemAttrText ( itemtype   => itemType,
					    itemkey    => itemkey,
					    aname      => 'REQUESTOR_DISPLAY_NAME' ,
					    avalue     => x_req_display_name); 
    apps.PO_WF_UTIL_PKG.SetItemAttrNumber ( itemtype   => itemType,
                                  itemkey    => itemkey,
                                  aname      => 'PREPARER_ID',
                                  avalue     => l_preparer_id);
    apps.PO_WF_UTIL_PKG.setItemAttrNumber ( itemtype   => itemType,
                                  itemkey    => itemkey,
                                  aname      => 'REQUESTOR_ID',
                                  avalue     => l_preparer_id);
    apps.PO_WF_UTIL_PKG.SetItemAttrNumber ( itemtype   => itemType,
                                  itemkey    => itemkey,
                                  aname      => 'FORWARD_FROM_ID',
                                  avalue     => l_preparer_id);
    apps.PO_REQAPPROVAL_INIT1.get_user_name(l_preparer_id, x_username,
    					x_user_display_name);
	     wf_engine.SetItemAttrText ( itemtype   => itemType,
					itemkey    => itemkey,
					aname      => 'PREPARER_USER_NAME' ,
					avalue     => x_username);
	     wf_engine.SetItemAttrText ( itemtype   => itemType,
					itemkey    => itemkey,
					aname      => 'PREPARER_DISPLAY_NAME' ,
					avalue     => x_user_display_name);
	     l_forward_from_id :=  wf_engine.GetItemAttrNumber (itemtype => itemtype,
						   itemkey  => itemkey,
						   aname    => 'FORWARD_FROM_ID');
	IF (l_forward_from_id <> l_preparer_id) THEN
	   	IF (g_po_wf_debug = 'Y') THEN
          		PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey, ls_function_name || 'Forward_from_id <> Preparer_Id');
   	   	END IF;
		apps.PO_REQAPPROVAL_INIT1.get_user_name(l_forward_from_id, x_ff_username,
                                         x_ff_user_display_name);
		apps.PO_REQAPPROVAL_INIT1.get_user_name(l_forward_from_id, x_ff_username,
						   x_ff_user_display_name);
		wf_engine.SetItemAttrText ( itemtype   => itemType,
					    itemkey    => itemkey,
					    aname      => 'FORWARD_FROM_USER_NAME' ,
					    avalue     => x_ff_username);
		wf_engine.SetItemAttrText ( itemtype   => itemType,
					    itemkey    => itemkey,
					    aname      => 'FORWARD_FROM_DISP_NAME' ,
					    avalue     => x_ff_user_display_name);
	ELSE
	      IF (g_po_wf_debug = 'Y') THEN
               PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey, ls_function_name || 'Forward_from_id = Preparer_Id');
   	      END IF;
		wf_engine.SetItemAttrText ( itemtype   => itemType,
					    itemkey    => itemkey,
					    aname      => 'FORWARD_FROM_USER_NAME' ,
					    avalue     => x_username);
		wf_engine.SetItemAttrText ( itemtype   => itemType,
					    itemkey    => itemkey,
					    aname      => 'FORWARD_FROM_DISP_NAME' ,
					    avalue     => x_user_display_name);
	END IF;
	wf_engine.SetItemAttrNumber (itemtype => itemtype,
					     itemkey  => itemkey,
					     aname    => 'RESPONDER_ID',
					     avalue   => l_preparer_id);
	wf_engine.SetItemAttrText ( itemtype   => itemType,
					    itemkey    => itemkey,
					    aname      => 'RESPONDER_USER_NAME' ,
					    avalue     => x_username);
	wf_engine.SetItemAttrText ( itemtype   => itemType,
					    itemkey    => itemkey,
					    aname      => 'RESPONDER_DISPLAY_NAME' ,
					    avalue     => x_user_display_name);
	BEGIN
		   select supervisor_id
		   INTO l_supervisor_id
		   from per_assignments_f
		   where person_id = l_preparer_id and
		   trunc(sysdate) BETWEEN effective_start_date
		   AND effective_end_date
		   AND primary_flag = 'Y'
		   AND ASSIGNMENT_TYPE = 'E';
	EXCEPTION
         WHEN Others THEN
	   IF (g_po_wf_debug = 'Y') THEN
          PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey, ls_function_name || 'Supervisor_id Exception '||SQLERRM);
   	   END IF;
    END;
    apps.PO_REQAPPROVAL_INIT1.get_user_name(l_supervisor_id, x_ft_username,
	    					x_ft_user_display_name);
	wf_engine.SetItemAttrText ( itemtype   => itemType,
						itemkey    => itemkey,
						aname      => 'APPROVER_USER_NAME' ,
						avalue     => x_ft_username);
	wf_engine.SetItemAttrText ( itemtype   => itemType,
						itemkey    => itemkey,
						aname      => 'APPROVER_DISPLAY_NAME' ,
						avalue     => x_ft_user_display_name);

--If forwarded to another approver do not overwrite

  l_forward_to_id :=  wf_engine.GetItemAttrNumber (itemtype => itemtype,
						   itemkey  => itemkey,
						   aname    => 'FORWARD_TO_ID');

  if l_forward_to_id is null then

	     wf_engine.SetItemAttrText ( itemtype   => itemType,
								itemkey    => itemkey,
								aname      => 'FORWARD_TO_DISPLAY_NAME' ,
								avalue     => x_ft_user_display_name);
	     wf_engine.SetItemAttrNumber ( itemtype   => itemType,
								itemkey    => itemkey,
								aname      => 'FORWARD_TO_ID' ,
								avalue     => l_supervisor_id);
	     wf_engine.SetItemAttrText ( itemtype   => itemType,
								itemkey    => itemkey,
								aname      => 'FORWARD_TO_USERNAME' ,
								avalue     => x_ft_username);
	     wf_engine.SetItemAttrText ( itemtype   => itemType,
								itemkey    => itemkey,
								aname      => 'FORWARD_TO_USERNAME_RESPONSE' ,
								avalue     => x_ft_user_display_name);
  end if;

   IF (g_po_wf_debug = 'Y') THEN
          PO_WF_DEBUG_PKG.insert_debug(itemtype,itemkey, ls_function_name || 'Activity Performed');
   END IF;
   resultout := wf_engine.eng_completed || ':' ||  'ACTIVITY_PERFORMED';
END change_preparor_to_requestor;
END xxha_req_approval;
/
