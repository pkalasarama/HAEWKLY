CREATE OR REPLACE PACKAGE      XXHA_DRM_ACCOUNTS_INT_HOURLY
IS

/*****************************************************************************************
* Name/Purpose : Package Body XXHA_DRM_ACCOUNTS_INT_HOURLY                                *
*                This job extracts the customer account delta�s every hour from EBS and   *
*                creates a hierarchical structure to be loaded into DRM and SalesForce   *
*                                                                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 10-OCT-2013     Varun Uppal          Initial Creation                                  *
* 30-OCT-2013     Manuel Fernandes     Concurrent program -- R12 changes                 *
* 7-DEC-2013      Varun Uppal          Patch to fix missing sites and update process     *
*                                      running status                                    *
* 21-JAN-2014     Varun Uppal          Patch to add ETL_PATH for new sites and CUR_REC   *
*                                      code to fix the contract_number,customer_name     *
*                                      for mismatches with DRM Hierarchy                 *
* 31-JAN-2014     Varun Uppal	       Code to match Key Acct Node Name to Key Acct Num  *
*                                      for New Contracts                                 *
* 06-FEB-2014     Varun Uppal	       Add additional join in Source extract from EBS to * 
*                                      ensure that sites are matched to the correct cust *
*                                      when a party has multiple customers               *
* 12-FEB-2014     Varun Uppal          Code enhancements for NA DRM Solution             *
* 27-MAR-2014     Ian Menzies          Fix for removing special chars from node names    *
*                                       and to prevent cust name change problems         *
*****************************************************************************************/

  PROCEDURE CUST_ACCTS_DELTA(
      errbuf OUT VARCHAR2,
      retcode OUT NUMBER,
      LAST_PROC_DT IN TIMESTAMP DEFAULT CAST(
        CAST(
          LOCALTIMESTAMP AS TIMESTAMP WITH TIME ZONE ) AT TIME ZONE 'America/new_york' AS TIMESTAMP ));
  PROCEDURE GET_EBS_ACCTS(
      START_TMSTMP IN TIMESTAMP ,
      END_TMSTMP   IN TIMESTAMP);
  PROCEDURE GET_NEW_DRM_CONTRACTS ;
  PROCEDURE GET_NEW_DRM_TRANS_ACCTS;
  PROCEDURE GET_EXISTING_DRM_TRANS_ACCTS;
  PROCEDURE ADD_SFDC_ACCTS;
END XXHA_DRM_ACCOUNTS_INT_HOURLY;
/


CREATE OR REPLACE PACKAGE BODY      XXHA_DRM_ACCOUNTS_INT_HOURLY
IS
   /*****************************************************************************************
   * Name/Purpose : Package Body XXHA_DRM_ACCOUNTS_INT_HOURLY                                *
   *                This job extracts the customer account delta�s every hour from EBS and   *
   *                creates a hierarchical structure to be loaded into DRM and SalesForce   *
   *                                                                                        *
   * Date            Author               Description                                       *
   * -----------     -----------------    ---------------                                   *
   * 10-OCT-2013     Varun Uppal          Initial Creation                                  *
   * 30-OCT-2013     Manuel Fernandes     Concurrent program -- R12 changes                 *
   * 7-DEC-2013      Varun Uppal          Patch to fix missing sites and update process     *
   *                                      running status                                    *
   * 21-JAN-2014     Varun Uppal          Patch to add ETL_PATH for new sites and CUR_REC   *
   *                                      code to fix the contract_number,customer_name     *
   *                                      for mismatches with DRM Hierarchy                 *
   * 31-JAN-2014     Varun Uppal        Code to match Key Acct Node Name to Key Acct Num  *
   *                                      for New Contracts                                 *
   * 06-FEB-2014     Varun Uppal        Add additional join in Source extract from EBS to *
   *                                      ensure that sites are matched to the correct cust *
   *                                      when a party has multiple customers               *
   * 12-FEB-2014     Varun Uppal          Code enhancements for NA DRM Solution             *
   * 03-MAR-2014     Ian Menzies          Fix to duplication issue introduced above         *
   * 18-MAR-2014     Ian Menzies          Fix to nightly job failure halting hourly jobs    *
   * 20-MAR-2014     Ian Menzies          R12 remediation for changes to address            *
   * 27-MAR-2014     Ian Menzies          Fix for removing special chars from node names    *
   *                                       and to prevent cust name change problems         *
   * 22-JUL-2014     Ian Menzies          Fix to multi-cust defaulting and add fields for   *
   *                                       EU SFDC lost after EU DRM go live                *
   *****************************************************************************************/

   PROCEDURE CUST_ACCTS_DELTA (
      errbuf            OUT VARCHAR2,
      retcode           OUT NUMBER,
      LAST_PROC_DT   IN     TIMESTAMP DEFAULT CAST (
                                                 CAST (
                                                    LOCALTIMESTAMP AS TIMESTAMP WITH TIME ZONE)
                                                    AT TIME ZONE 'America/new_york' AS TIMESTAMP))
   IS
      v_night_proc_cnt            NUMBER;
      v_curr_process_status_cnt   NUMBER;
      v_start_tmstmp              TIMESTAMP (6);
      v_end_tmstmp                TIMESTAMP (6);
      v_delta_cnt                 NUMBER;
      v_int_cnt                   NUMBER;
   BEGIN
      FND_FILE.PUT_LINE (FND_FILE.LOG, 'Procedure begins: ' || CURRENT_DATE);

      -- check nightly process status to ensure it is not running
      SELECT NVL (COUNT (*), 0)
        INTO v_night_proc_cnt
        FROM HAEMO.XXHA_DRM_INT_PROCESS_STATUS
       WHERE     process_name = 'DRM_NIGHTLY_PROCESS'
             AND process_running_status = 'Y';


      -- check if hourly process status to ensure it is not running
      SELECT NVL (COUNT (*), 0)
        INTO v_curr_process_status_cnt
        FROM HAEMO.XXHA_DRM_INT_PROCESS_STATUS
       WHERE     process_name = 'DRM_HOURLY_PROCESS'
             AND process_running_status = 'Y';

      -- get the last processed timestamp for hourly process to start new process
      SELECT MAX (PROCESS_END_TMSTMP)
        INTO v_start_tmstmp
        FROM HAEMO.XXHA_DRM_INT_PROCESS_STATUS
       WHERE     PROCESS_NAME = 'DRM_HOURLY_PROCESS'
             AND PROCESS_RUNNING_STATUS = 'N';

      FND_FILE.PUT_LINE (FND_FILE.LOG,
                         'start timestamp is: ' || v_start_tmstmp);

      SELECT NVL (LAST_PROC_DT, CURRENT_TIMESTAMP)
        INTO V_END_TMSTMP
        FROM DUAL;

      FND_FILE.PUT_LINE (FND_FILE.LOG, 'end timestamp is: ' || v_end_tmstmp);

      -- ADD Code to set process_running_status to 'X' for Hourly Process
      IF v_curr_process_status_cnt != 0
      THEN
         UPDATE HAEMO.XXHA_DRM_INT_PROCESS_STATUS
            SET process_running_status = 'X'
          WHERE     process_name = 'DRM_HOURLY_PROCESS'
                AND process_running_status = 'Y';
      END IF;


      -- ADD Code to set process_running_status to 'X' for Nightly Process
      IF v_night_proc_cnt != 0
      THEN
         UPDATE HAEMO.XXHA_DRM_INT_PROCESS_STATUS
            SET process_running_status = 'X'
          WHERE     process_name = 'DRM_NIGHTLY_PROCESS'
                AND process_running_status = 'Y';
      END IF;

      IF v_night_proc_cnt = 0 AND v_curr_process_status_cnt = 0
      THEN
         --DBMS_OUTPUT.PUT_LINE('GET DATA: ' || CURRENT_DATE);
         -- add new process entry into the table
         INSERT
           INTO HAEMO.XXHA_DRM_INT_PROCESS_STATUS (PROCESS_NAME,
                                                   PROCESS_RUNNING_STATUS,
                                                   PROCESS_START_TMSTMP,
                                                   PROCESS_END_TMSTMP)
         VALUES ('DRM_HOURLY_PROCESS',
                 'Y',
                 v_start_tmstmp,
                 v_end_tmstmp);

         GET_EBS_ACCTS (START_TMSTMP   => v_start_tmstmp,
                        END_TMSTMP     => v_end_tmstmp);

         SELECT NVL (COUNT (*), 0)
           INTO v_delta_cnt
           FROM HAEMO.XXHA_EBS_CUST_DELTA_STG;

         IF v_delta_cnt > 0
         THEN
            --DBMS_OUTPUT.PUT_LINE('Call sub procs: ' || CURRENT_DATE);
            GET_NEW_DRM_CONTRACTS ();
            GET_NEW_DRM_TRANS_ACCTS ();
            GET_EXISTING_DRM_TRANS_ACCTS ();

            SELECT NVL (COUNT (*), 0)
              INTO v_int_cnt
              FROM HAEMO.XXHA_EBS_CUST_DELTA_INT;

            IF v_int_cnt > 0
            THEN
               ADD_SFDC_ACCTS ();
            ELSE
               --DBMS_OUTPUT.PUT_LINE('Procedure begins: ' || CURRENT_DATE);
               FND_FILE.PUT_LINE (FND_FILE.LOG, 'No SFDC accounts to add: ');
            END IF;
         ELSE
            --DBMS_OUTPUT.PUT_LINE('Procedure begins: ' || CURRENT_DATE);
            FND_FILE.PUT_LINE (FND_FILE.LOG,
                               'No Records added to Delta Stage: ');
         END IF;

         -- set the status for the current process
         UPDATE HAEMO.XXHA_DRM_INT_PROCESS_STATUS
            SET process_running_status = 'N'
          WHERE     process_running_status = 'Y'
                AND process_name = 'DRM_HOURLY_PROCESS'
                AND process_start_tmstmp = v_start_tmstmp;

         COMMIT;

         FND_FILE.PUT_LINE (FND_FILE.LOG, 'Procedure ends: ' || CURRENT_DATE);
      ELSE
         --DBMS_OUTPUT.PUT_LINE('Procedure begins: ' || CURRENT_DATE);
         FND_FILE.PUT_LINE (FND_FILE.LOG,
                            'Nightly or Daily Processs Running');
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RAISE_APPLICATION_ERROR (-20100, 'No data to process');
   END CUST_ACCTS_DELTA;

   PROCEDURE GET_EBS_ACCTS (START_TMSTMP   IN TIMESTAMP,
                            END_TMSTMP     IN TIMESTAMP)
   IS
      v_start_tmstmp   TIMESTAMP (6);
      v_end_tmstmp     TIMESTAMP (6);
      v_rec_cnt        NUMBER (10);
   BEGIN
      FND_FILE.PUT_LINE (FND_FILE.LOG, 'get ebs cust acct begins: ');

      v_start_tmstmp := START_TMSTMP;
      v_end_tmstmp := END_TMSTMP;

      -- Truncate temp table and get change records from EBS tables for accounts
      EXECUTE IMMEDIATE 'TRUNCATE TABLE HAEMO.XXHA_EBS_CUST_DELTA_STG';

      FND_FILE.PUT_LINE (FND_FILE.LOG, 'start delta insert');

      INSERT INTO HAEMO.XXHA_EBS_CUST_DELTA_STG (CUSTOMER_ID,
                                                 CUSTOMER_NUMBER,
                                                 CUSTOMER_NAME,
                                                 CUSTOMER_TYPE,
                                                 ADDRESS,
                                                 ORG_ID,
                                                 CITY,
                                                 STATE,
                                                 POSTAL_CODE,
                                                 COUNTRY,
                                                 AGENT,
                                                 SITE_USE_CODE,
                                                 SITE_USE_ID,
                                                 SITE_NUMBER,
                                                 PRIMARY_SALESREP_ID,
                                                 STATUS,
                                                 PHONE_NUMBER,
                                                 FAX_NUMBER,
                                                 CONTRACT_NUMBER,
                                                 CUST_UPDT_DATE,
                                                 CUST_CREATION_DATE,
                                                 ADDR_UPDT_DATE,
                                                 ADDR_CREATION_DATE,
                                                 SITE_UPDT_DATE,
                                                 SITE_CREATION_DATE,
                                                 ADDRESS_ID,
                                                 SALES_CHANNEL,
                                                 CATEGORY,
                                                 CLASS,
                                                 OU_NAME,
                                                 LANGUAGE)
         WITH CUST_PHONE
              AS (  SELECT MAX (
                              DECODE (
                                 NVL (CONT_POINT.PHONE_LINE_TYPE,
                                      CONT_POINT.CONTACT_POINT_TYPE),
                                 'GEN',    DECODE (
                                              CONT_POINT.PHONE_AREA_CODE,
                                              NULL, NULL,
                                              CONT_POINT.PHONE_AREA_CODE || '-')
                                        || DECODE (
                                              CONT_POINT.CONTACT_POINT_TYPE,
                                              'TLX', CONT_POINT.TELEX_NUMBER,
                                              CONT_POINT.PHONE_NUMBER)
                                        || DECODE (
                                              CONT_POINT.PHONE_EXTENSION,
                                              NULL, NULL,
                                                 ' x'
                                              || CONT_POINT.PHONE_EXTENSION),
                                 NULL, NULL))
                              AS PHONE_NUMBER,
                           MAX (
                              DECODE (
                                 NVL (CONT_POINT.PHONE_LINE_TYPE,
                                      CONT_POINT.CONTACT_POINT_TYPE),
                                 'FAX',    DECODE (
                                              CONT_POINT.PHONE_AREA_CODE,
                                              NULL, NULL,
                                              CONT_POINT.PHONE_AREA_CODE || '-')
                                        || DECODE (
                                              CONT_POINT.CONTACT_POINT_TYPE,
                                              'TLX', CONT_POINT.TELEX_NUMBER,
                                              CONT_POINT.PHONE_NUMBER)
                                        || DECODE (
                                              CONT_POINT.PHONE_EXTENSION,
                                              NULL, NULL,
                                                 ' x'
                                              || CONT_POINT.PHONE_EXTENSION),
                                 NULL, NULL))
                              AS FAX_NUMBER,
                           --NVL(CONT_POINT.PHONE_LINE_TYPE,CONT_POINT.CONTACT_POINT_TYPE) AS PHONE_TYPE ,
                           CAS.CUST_ACCT_SITE_ID AS CUST_ACCT_SITE_ID
                      FROM APPS.HZ_CUST_ACCT_SITES_ALL CAS,
                           APPS.HZ_CONTACT_POINTS CONT_POINT
                     WHERE     CAS.PARTY_SITE_ID = CONT_POINT.OWNER_TABLE_ID(+)
                           AND CONT_POINT.OWNER_TABLE_NAME(+) =
                                  'HZ_PARTY_SITES'
                           AND NVL (CONT_POINT.PHONE_LINE_TYPE,
                                    CONT_POINT.CONTACT_POINT_TYPE) IN ('GEN',
                                                                       'FAX')
                  GROUP BY CAS.CUST_ACCT_SITE_ID)
         SELECT DISTINCT
                RC_hca.cust_account_id AS CUSTOMER_ID,
                RC_hca.account_number AS CUSTOMER_NUMBER,
                SUBSTRB (rc_hp.party_name, 1, 50) AS RC_CUSTOMER_NAME,
                L_CLASS.MEANING AS CUSTOMER_TYPE,
                   hl.address1
                || ' '
                || DECODE (hl.address2, NULL, NULL, hl.address2 || ' ')
                || DECODE (hl.address3, NULL, NULL, hl.address3 || ' ')
                || DECODE (hl.address4, NULL, NULL, hl.address4 || ' ')
                   AS address,
                hcas.org_id,
                hl.city,
                hl.state,
                DECODE (hl.country,
                        'US', SUBSTR (LTRIM (RTRIM (hl.postal_code)), 0, 5),
                        LTRIM (RTRIM (hl.postal_code)))
                   AS postal_code,
                hl.country,
                hcas.attribute5 AS AGENT,
                RS_hcsu.site_use_code,
                RS_hcsu.site_use_id,
                party_site_number AS site_number,             --ra.site_number
                RS_hcsu.primary_salesrep_id,
                hcas.status AS status,        --ra.status           AS STATUS,
                cust_phone.phone_number,
                CUST_PHONE.FAX_NUMBER,
                hcas.ORG_ID || RC_hca.ACCOUNT_NUMBER,
                RC_hca.LAST_UPDATE_DATE,
                RC_hca.CREATION_DATE,
                GREATEST (hcas.LAST_UPDATE_DATE, hl.LAST_UPDATE_DATE)
                   LAST_UPDATE_DATE,
                hcas.CREATION_DATE,
                RS_hcsu.LAST_UPDATE_DATE,
                RS_hcsu.CREATION_DATE,
                hcas.cust_acct_site_id AS address_id,          --RA.ADDRESS_ID
                l_channel.meaning,
                l_cat.meaning,
                l_class.meaning,
                SUBSTR (otl.name, -5, 2) ou_name,
                hl.language
           FROM hz_cust_accounts rc_hca,
                hz_parties rc_hp,                        /*RA_CUSTOMERS RC, */
                hz_cust_acct_sites_all hcas,
                hz_party_sites hps,
                hz_locations hl,
                HZ_CUST_SITE_USES_ALL rs_hcsu,
                AR_LOOKUPS L_CAT,
                AR_LOOKUPS L_CLASS,
                AR_LOOKUPS L_TYPE,
                fnd_lookup_values L_CHANNEL,
                HR_ALL_ORGANIZATION_UNITS_TL OTL,
                (SELECT DISTINCT
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (load_data) = 'TRUE')
                DRM_SUB,
                CUST_PHONE
          WHERE     rc_hca.party_id = rc_hp.party_id
                AND rc_hp.party_id = hps.party_id
                AND hcas.org_id = drm_sub.org_id
                AND hcas.party_site_id = hps.party_site_id
                AND rc_hca.cust_account_id = hcas.cust_account_id
                AND hcas.cust_acct_site_id = rs_hcsu.cust_acct_site_id
                AND hps.location_id = hl.location_id
                AND otl.organization_id = hcas.org_id
                AND otl.language = 'US'
                AND rs_hcsu.SITE_USE_CODE IN ('SHIP_TO', 'BILL_TO')
                AND RC_hp.CATEGORY_CODE = L_CAT.LOOKUP_CODE(+) /*RC.CUSTOMER_CATEGORY_CODE */
                AND L_CAT.LOOKUP_TYPE(+) = 'CUSTOMER_CATEGORY'
                AND RC_hca.CUSTOMER_CLASS_CODE = L_CLASS.LOOKUP_CODE(+)
                AND L_CLASS.LOOKUP_TYPE(+) = 'CUSTOMER CLASS'
                AND RC_hca.CUSTOMER_TYPE = L_TYPE.LOOKUP_CODE(+)
                AND L_TYPE.LOOKUP_TYPE(+) = 'CUSTOMER_TYPE'
                AND rc_hca.sales_channel_code = L_CHANNEL.LOOKUP_CODE(+)
                AND L_CHANNEL.lookup_type(+) = 'SALES_CHANNEL'
                AND L_CHANNEL.language(+) = 'US'
                AND L_CHANNEL.view_application_id(+) = 660
                AND RC_hca.CUSTOMER_TYPE != 'I'
                AND hcas.cust_acct_site_id = cust_phone.cust_acct_site_id(+) /* AND RA.ADDRESS_ID          = cust_phone.cust_acct_site_id (+) */
                AND (   rc_hca.LAST_UPDATE_DATE BETWEEN v_start_tmstmp
                                                    AND v_end_tmstmp
                     OR rc_hca.CREATION_DATE BETWEEN v_start_tmstmp
                                                 AND v_end_tmstmp
                     OR hcas.LAST_UPDATE_DATE BETWEEN v_start_tmstmp
                                                  AND v_end_tmstmp
                     OR hcas.CREATION_DATE BETWEEN v_start_tmstmp
                                               AND v_end_tmstmp
                     OR RS_hcsu.LAST_UPDATE_DATE BETWEEN v_start_tmstmp
                                                     AND v_end_tmstmp
                     OR RS_hcsu.CREATION_DATE BETWEEN v_start_tmstmp
                                                  AND v_end_tmstmp
                     OR hl.LAST_UPDATE_DATE BETWEEN v_start_tmstmp
                                                AND v_end_tmstmp
                     OR hl.CREATION_DATE BETWEEN v_start_tmstmp
                                             AND v_end_tmstmp)
         UNION
         SELECT DISTINCT
                RC_hca.cust_account_id AS CUSTOMER_ID,
                RC_hca.account_number AS CUSTOMER_NUMBER,
                SUBSTRB (rc_hp.party_name, 1, 50) AS RC_CUSTOMER_NAME,
                L_CLASS.MEANING AS CUSTOMER_TYPE,
                   hl.address1
                || ' '
                || DECODE (hl.address2, NULL, NULL, hl.address2 || ' ')
                || DECODE (hl.address3, NULL, NULL, hl.address3 || ' ')
                || DECODE (hl.address4, NULL, NULL, hl.address4 || ' ')
                   AS address,
                hcas.org_id,
                hl.city,
                hl.state,
                DECODE (hl.country,
                        'US', SUBSTR (LTRIM (RTRIM (hl.postal_code)), 0, 5),
                        LTRIM (RTRIM (hl.postal_code)))
                   AS postal_code,
                hl.country,
                hcas.attribute5 AS AGENT,
                RS_hcsu.site_use_code,
                RS_hcsu.site_use_id,
                party_site_number AS site_number,             --ra.site_number
                RS_hcsu.primary_salesrep_id,
                hcas.status AS status,        --ra.status           AS STATUS,
                cust_phone.phone_number,
                CUST_PHONE.FAX_NUMBER,
                hcas.ORG_ID || RC_hca.ACCOUNT_NUMBER,
                RC_hca.LAST_UPDATE_DATE,
                RC_hca.CREATION_DATE,
                GREATEST (hcas.LAST_UPDATE_DATE, hl.LAST_UPDATE_DATE)
                   LAST_UPDATE_DATE,
                hcas.CREATION_DATE,
                RS_hcsu.LAST_UPDATE_DATE,
                RS_hcsu.CREATION_DATE,
                hcas.cust_acct_site_id AS address_id,          --RA.ADDRESS_ID
                l_channel.meaning,
                l_cat.meaning,
                l_class.meaning,
                SUBSTR (otl.name, -5, 2) ou_name,
                hl.language
           FROM hz_cust_accounts rc_hca,
                hz_parties rc_hp,                        /*RA_CUSTOMERS RC, */
                hz_cust_acct_sites_all hcas,
                hz_party_sites hps,
                hz_locations hl,
                HZ_CUST_SITE_USES_ALL rs_hcsu,
                AR_LOOKUPS L_CAT,
                AR_LOOKUPS L_CLASS,
                AR_LOOKUPS L_TYPE,
                fnd_lookup_values L_CHANNEL,
                HR_ALL_ORGANIZATION_UNITS_TL OTL,
                (SELECT DISTINCT
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (load_data) = 'TRUE')
                DRM_SUB,
                CUST_PHONE
          WHERE     rc_hca.party_id = rc_hp.party_id
                AND rc_hp.party_id = hps.party_id
                AND hcas.org_id = drm_sub.org_id
                AND hcas.party_site_id = hps.party_site_id
                AND rc_hca.cust_account_id = hcas.cust_account_id
                AND hcas.cust_acct_site_id = rs_hcsu.cust_acct_site_id
                AND hps.location_id = hl.location_id
                AND otl.organization_id = hcas.org_id
                AND otl.language = 'US'
                AND rs_hcsu.SITE_USE_CODE IN ('SHIP_TO', 'BILL_TO')
                AND RC_hp.CATEGORY_CODE = L_CAT.LOOKUP_CODE(+) /*RC.CUSTOMER_CATEGORY_CODE */
                AND L_CAT.LOOKUP_TYPE(+) = 'CUSTOMER_CATEGORY'
                AND RC_hca.CUSTOMER_CLASS_CODE = L_CLASS.LOOKUP_CODE(+)
                AND L_CLASS.LOOKUP_TYPE(+) = 'CUSTOMER CLASS'
                AND RC_hca.CUSTOMER_TYPE = L_TYPE.LOOKUP_CODE(+)
                AND L_TYPE.LOOKUP_TYPE(+) = 'CUSTOMER_TYPE'
                AND rc_hca.sales_channel_code = L_CHANNEL.LOOKUP_CODE(+)
                AND L_CHANNEL.lookup_type(+) = 'SALES_CHANNEL'
                AND L_CHANNEL.language(+) = 'US'
                AND L_CHANNEL.view_application_id(+) = 660
                AND RC_hca.CUSTOMER_TYPE != 'I'
                AND hcas.cust_acct_site_id = cust_phone.cust_acct_site_id(+) /* AND RA.ADDRESS_ID          = cust_phone.cust_acct_site_id (+) */
                AND rs_hcsu.site_use_id IN (SELECT site_use_id
                                              FROM HAEMO.XXHA_EBS_CUST_DELTA_FLAG);

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Records inserted into delta table: ' || SQL%ROWCOUNT);
      --DBMS_OUTPUT.PUT_LINE('Records inserted into delta table: ' || sql%rowcount);

      COMMIT;

      -- REMOVE records that are not true delta's with respect to SFDC accounts
      -- Add code to remove DUP site_use_id's added above 12/7/2013

      DELETE FROM HAEMO.XXHA_EBS_CUST_DELTA_STG TMP
            WHERE tmp.site_use_id IN (  SELECT site_use_id
                                          FROM HAEMO.XXHA_EBS_CUST_DELTA_STG
                                      GROUP BY site_use_id
                                        HAVING COUNT (*) > 1);

      -- end of code to remove duplicates 12/7/2013

      DELETE FROM HAEMO.XXHA_EBS_CUST_DELTA_STG TMP
            WHERE tmp.site_use_id IN (SELECT SITE_USE_ID
                                        FROM (SELECT CUSTOMER_ID,
                                                     CUSTOMER_NUMBER,
                                                     CUSTOMER_NAME,
                                                     CUSTOMER_TYPE,
                                                     ADDRESS,
                                                     ORG_ID,
                                                     CITY,
                                                     STATE,
                                                     POSTAL_CODE,
                                                     COUNTRY,
                                                     AGENT,
                                                     SITE_USE_CODE,
                                                     SITE_USE_ID,
                                                     SITE_NUMBER,
                                                     PRIMARY_SALESREP_ID,
                                                     STATUS,
                                                     PHONE_NUMBER,
                                                     FAX_NUMBER,
                                                     CONTRACT_NUMBER,
                                                     SALES_CHANNEL,
                                                     CATEGORY,
                                                     CLASS,
                                                     OU_NAME,
                                                     LANGUAGE
                                                FROM HAEMO.XXHA_EBS_CUST_DELTA_STG
                                               WHERE SITE_USE_ID NOT IN (SELECT site_use_id
                                                                           FROM HAEMO.XXHA_EBS_CUST_DELTA_FLAG)
                                              INTERSECT
                                              SELECT CUSTOMER_ID,
                                                     CUSTOMER_NUMBER,
                                                     CUSTOMER_NAME,
                                                     CUSTOMER_TYPE,
                                                     ADDRESS,
                                                     ORG_ID,
                                                     CITY,
                                                     STATE,
                                                     POSTAL_CODE,
                                                     COUNTRY,
                                                     AGENT,
                                                     SITE_USE_CODE,
                                                     SITE_USE_ID,
                                                     SITE_NUMBER,
                                                     PRIMARY_SALESREP_ID,
                                                     STATUS,
                                                     PHONE_NUMBER,
                                                     FAX_NUMBER,
                                                     CONTRACT_NUMBER,
                                                     SALES_CHANNEL,
                                                     CATEGORY,
                                                     CLASS,
                                                     OU_NAME,
                                                     LANGUAGE
                                                FROM HAEMO.XXHA_EBS_CUST_MASTER_STG));

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Records deleted out of delta table: ' || SQL%ROWCOUNT);

      COMMIT;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE HAEMO.XXHA_EBS_CUST_DELTA_FLAG';

      SELECT NVL (COUNT (*), 0)
        INTO V_REC_CNT
        FROM HAEMO.XXHA_EBS_CUST_DELTA_STG
       WHERE ORG_ID IN (SELECT DISTINCT
                               LTRIM (
                                  SUBSTR (NODE_NAME,
                                          INSTR (NODE_NAME, ' - ') + 2))
                                  AS ORG_ID
                          FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                         WHERE     LEVEL_HIER = '3'
                               AND UPPER (LOAD_DATA) = 'TRUE');

      FND_FILE.PUT_LINE (FND_FILE.LOG,
                         'Records to process in delta table: ' || v_rec_cnt);

      FND_FILE.PUT_LINE (FND_FILE.LOG, 'get ebs cust acct ends: ');
   END GET_EBS_ACCTS;

   PROCEDURE GET_NEW_DRM_CONTRACTS
   IS
   BEGIN
      FND_FILE.PUT_LINE (FND_FILE.LOG, 'Insert for New Contracts Delta: ');

      MERGE INTO HAEMO.XXHA_EBS_CUST_DELTA_INT A
           USING (SELECT EBS.CUSTOMER_ID,
                         EBS.CUSTOMER_NUMBER,
                         EBS.CUSTOMER_NAME,
                         EBS.CUSTOMER_TYPE,
                         EBS.ADDRESS,
                         EBS.ORG_ID,
                         EBS.CITY,
                         EBS.STATE,
                         EBS.POSTAL_CODE,
                         EBS.COUNTRY,
                         EBS.AGENT,
                         EBS.SITE_USE_CODE,
                         EBS.SITE_USE_ID,
                         EBS.SITE_NUMBER,
                         EBS.PRIMARY_SALESREP_ID,
                         EBS.STATUS,
                         EBS.PHONE_NUMBER,
                         EBS.FAX_NUMBER,
                         EBS.CONTRACT_NUMBER,
                         'NEW CONTRACTS' AS change_desc,
                         EBS.SALES_CHANNEL,
                         EBS.CATEGORY,
                         EBS.CLASS,
                         EBS.OU_NAME,
                         EBS.LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_STG EBS
                         INNER JOIN
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE LEVEL_HIER = '3') DRM_SUB
                            ON     DRM_SUB.ORG_ID = EBS.ORG_ID
                               AND DRM_SUB.LOAD_DATA = 'TRUE'
                         LEFT JOIN HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                            ON     ebs.contract_number =
                                      NVL (dm.contract_number,
                                           dm.manual_contract_number)
                               AND dm.level_hier = '4'
                   WHERE     NVL (dm.contract_number,
                                  dm.manual_contract_number)
                                IS NULL
                         AND NOT EXISTS
                                    (SELECT dm.derived_contract_number
                                       FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                                      WHERE REGEXP_LIKE (
                                               DM.DERIVED_CONTRACT_NUMBER,
                                               EBS.CONTRACT_NUMBER))
                         AND NOT EXISTS
                                    (SELECT DM.MANUAL_CONTRACT_NUMBER
                                       FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                                      WHERE REGEXP_LIKE (
                                               dm.manual_contract_number,
                                               ebs.contract_number))) B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET CUSTOMER_ID = B.CUSTOMER_ID,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    ADDRESS = B.ADDRESS,
                    ORG_ID = B.ORG_ID,
                    CITY = B.CITY,
                    STATE = B.STATE,
                    POSTAL_CODE = B.POSTAL_CODE,
                    COUNTRY = B.COUNTRY,
                    AGENT = B.AGENT,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (CUSTOMER_ID,
                     CUSTOMER_NUMBER,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     ADDRESS,
                     ORG_ID,
                     CITY,
                     STATE,
                     POSTAL_CODE,
                     COUNTRY,
                     AGENT,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     CONTRACT_NUMBER,
                     CHANGE_DESC,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.CUSTOMER_ID,
                     B.CUSTOMER_NUMBER,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.ADDRESS,
                     B.ORG_ID,
                     B.CITY,
                     B.STATE,
                     B.POSTAL_CODE,
                     B.COUNTRY,
                     B.AGENT,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.CONTRACT_NUMBER,
                     B.CHANGE_DESC,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Rows inserted for New Contracts Delta: ' || SQL%ROWCOUNT);
   END GET_NEW_DRM_CONTRACTS;

   PROCEDURE GET_NEW_DRM_TRANS_ACCTS
   IS
   BEGIN
      FND_FILE.PUT_LINE (FND_FILE.LOG, 'Insert for New Sites Delta: ');

      MERGE INTO HAEMO.XXHA_EBS_CUST_DELTA_INT A
           USING (SELECT EBS.CUSTOMER_ID,
                         EBS.CUSTOMER_NUMBER,
                         EBS.CUSTOMER_NAME,
                         EBS.CUSTOMER_TYPE,
                         EBS.ADDRESS,
                         EBS.ORG_ID,
                         EBS.CITY,
                         EBS.STATE,
                         EBS.POSTAL_CODE,
                         EBS.COUNTRY,
                         EBS.AGENT,
                         EBS.SITE_USE_CODE,
                         EBS.SITE_USE_ID,
                         EBS.SITE_NUMBER,
                         EBS.PRIMARY_SALESREP_ID,
                         EBS.STATUS,
                         EBS.PHONE_NUMBER,
                         EBS.FAX_NUMBER,
                         EBS.CONTRACT_NUMBER,
                         'NEW SITES' AS change_desc,
                         EBS.SALES_CHANNEL,
                         EBS.CATEGORY,
                         EBS.CLASS,
                         EBS.OU_NAME,
                         EBS.LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_STG EBS
                         INNER JOIN
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE LEVEL_HIER = '3') DRM_SUB
                            ON     DRM_SUB.ORG_ID = EBS.ORG_ID
                               AND DRM_SUB.LOAD_DATA = 'TRUE'
                         LEFT JOIN HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                            ON     EBS.SITE_USE_ID = DM.TRANS_ACCT_NUMBER
                               AND DM.LEVEL_HIER = '6'
                   WHERE     dm.trans_acct_number IS NULL
                         AND EXISTS
                                (SELECT dm.contract_number
                                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                                  WHERE ebs.contract_number =
                                           NVL (dm.contract_number,
                                                dm.manual_contract_number)
                                 UNION ALL
                                 SELECT dm.derived_contract_number
                                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                                  WHERE REGEXP_LIKE (
                                           DM.DERIVED_CONTRACT_NUMBER,
                                           EBS.CONTRACT_NUMBER)
                                 UNION ALL
                                 SELECT DM.MANUAL_CONTRACT_NUMBER
                                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                                  WHERE REGEXP_LIKE (
                                           dm.MANUAL_contract_number,
                                           ebs.contract_number))) B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET CUSTOMER_ID = B.CUSTOMER_ID,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    ADDRESS = B.ADDRESS,
                    ORG_ID = B.ORG_ID,
                    CITY = B.CITY,
                    STATE = B.STATE,
                    POSTAL_CODE = B.POSTAL_CODE,
                    COUNTRY = B.COUNTRY,
                    AGENT = B.AGENT,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (CUSTOMER_ID,
                     CUSTOMER_NUMBER,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     ADDRESS,
                     ORG_ID,
                     CITY,
                     STATE,
                     POSTAL_CODE,
                     COUNTRY,
                     AGENT,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     CONTRACT_NUMBER,
                     CHANGE_DESC,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.CUSTOMER_ID,
                     B.CUSTOMER_NUMBER,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.ADDRESS,
                     B.ORG_ID,
                     B.CITY,
                     B.STATE,
                     B.POSTAL_CODE,
                     B.COUNTRY,
                     B.AGENT,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.CONTRACT_NUMBER,
                     B.CHANGE_DESC,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Rows inserted for New Sites Delta: ' || SQL%ROWCOUNT);
   END GET_NEW_DRM_TRANS_ACCTS;

   PROCEDURE GET_EXISTING_DRM_TRANS_ACCTS
   IS
   BEGIN
      FND_FILE.PUT_LINE (FND_FILE.LOG, 'Insert for existing Sites Delta: ');

      MERGE INTO HAEMO.XXHA_EBS_CUST_DELTA_INT A
           USING (SELECT DISTINCT EBS.CUSTOMER_ID,
                                  EBS.CUSTOMER_NUMBER,
                                  EBS.CUSTOMER_NAME,
                                  EBS.CUSTOMER_TYPE,
                                  EBS.ADDRESS,
                                  EBS.ORG_ID,
                                  EBS.CITY,
                                  EBS.STATE,
                                  EBS.POSTAL_CODE,
                                  EBS.COUNTRY,
                                  EBS.AGENT,
                                  EBS.SITE_USE_CODE,
                                  EBS.SITE_USE_ID,
                                  EBS.SITE_NUMBER,
                                  EBS.PRIMARY_SALESREP_ID,
                                  EBS.STATUS,
                                  EBS.PHONE_NUMBER,
                                  EBS.FAX_NUMBER,
                                  EBS.CONTRACT_NUMBER,
                                  'EXISTING SITES' AS CHANGE_DESC,
                                  EBS.SALES_CHANNEL,
                                  EBS.CATEGORY,
                                  EBS.CLASS,
                                  EBS.OU_NAME,
                                  EBS.LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_STG EBS
                         INNER JOIN
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE LEVEL_HIER = '3') DRM_SUB
                            ON     DRM_SUB.ORG_ID = EBS.ORG_ID
                               AND DRM_SUB.LOAD_DATA = 'TRUE'
                         LEFT JOIN HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                            ON     ebs.site_use_id = dm.trans_acct_number
                               AND dm.level_hier = '6'
                   WHERE     dm.trans_acct_number IS NOT NULL
                         AND EXISTS
                                (SELECT dm.contract_number
                                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                                  WHERE ebs.contract_number =
                                           NVL (dm.contract_number,
                                                dm.manual_contract_number)
                                 UNION ALL
                                 SELECT dm.derived_contract_number
                                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DM
                                  WHERE REGEXP_LIKE (
                                           dm.derived_contract_number,
                                           ebs.contract_number))) B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET CUSTOMER_ID = B.CUSTOMER_ID,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    ADDRESS = B.ADDRESS,
                    ORG_ID = B.ORG_ID,
                    CITY = B.CITY,
                    STATE = B.STATE,
                    POSTAL_CODE = B.POSTAL_CODE,
                    COUNTRY = B.COUNTRY,
                    AGENT = B.AGENT,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (CUSTOMER_ID,
                     CUSTOMER_NUMBER,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     ADDRESS,
                     ORG_ID,
                     CITY,
                     STATE,
                     POSTAL_CODE,
                     COUNTRY,
                     AGENT,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     CONTRACT_NUMBER,
                     CHANGE_DESC,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.CUSTOMER_ID,
                     B.CUSTOMER_NUMBER,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.ADDRESS,
                     B.ORG_ID,
                     B.CITY,
                     B.STATE,
                     B.POSTAL_CODE,
                     B.COUNTRY,
                     B.AGENT,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.CONTRACT_NUMBER,
                     B.CHANGE_DESC,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Rows inserted for existing Sites Delta: ' || SQL%ROWCOUNT);
   END GET_EXISTING_DRM_TRANS_ACCTS;

   PROCEDURE ADD_SFDC_ACCTS
   IS
      v_wm_seq   NUMBER (10, 0);
   BEGIN
      FND_FILE.PUT_LINE (FND_FILE.LOG, 'add SFDC New Contract Accounts: ');

      SELECT HAEMO.XXHA_WM_DRM_SFDC_INT_SEQ.NEXTVAL INTO v_wm_seq FROM DUAL;

      INSERT
        INTO HAEMO.XXHA_WM_DRM_SFDC_INT_STATUS (PROCESS_ID,
                                                PROCESS_NAME,
                                                PROCESS_RUNNING_STATUS)
      VALUES (v_wm_seq, 'WM-SFDC Hourly', 'Y');

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS process_id,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', ADDRESS, NULL)
                            AS BILLING_STREET,
                         DECODE (SITE_USE_CODE, 'BILL_TO', CITY, NULL)
                            AS BILLING_CITY,
                         DECODE (SITE_USE_CODE, 'BILL_TO', STATE, NULL)
                            AS BILLING_STATE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', POSTAL_CODE, NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', COUNTRY, NULL)
                            AS BILLING_COUNTRY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', ADDRESS, NULL)
                            AS SHIPPING_STREET,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', CITY, NULL)
                            AS SHIPPING_CITY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', STATE, NULL)
                            AS SHIPPING_STATE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', POSTAL_CODE, NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', COUNTRY, NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         CDI.CONTRACT_NUMBER,
                         CDI.CUSTOMER_NAME AS CONTRACT_NAME,
                            -- code change on 01/31/2014 by Varun Uppal to match key_acct_numbers for new contracts with DRM Node Name
                            REPLACE (cdi.Customer_name, '''', '')
                         || ' - '
                         || cdi.ORG_ID
                         || ' - '
                         || cdi.CUSTOMER_NUMBER
                         || ' - Default'
                            AS KEY_ACCT_NUMBER,
                         SUB.CUSTOMER_NAME AS KEY_ACCT_NAME,
                         SITE_USE_ID AS TRANS_ACCT_NUMBER,
                         CDI.CUSTOMER_NAME TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE AS SFDC_ORG,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI,
                         (  SELECT CONTRACT_NUMBER, CUSTOMER_NAME
                              FROM HAEMO.XXHA_EBS_CUST_DELTA_INT SUB
                             WHERE CHANGE_DESC = 'NEW CONTRACTS'
                          GROUP BY CONTRACT_NUMBER, CUSTOMER_NAME) SUB,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE level_hier = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'NEW CONTRACTS'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND CDI.CONTRACT_NUMBER = SUB.CONTRACT_NUMBER(+)
                         AND EXISTS
                                (SELECT STG.SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)) B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);


      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Rows inserted for SFDC New Contract Accounts: ' || SQL%ROWCOUNT);

      FND_FILE.PUT_LINE (FND_FILE.LOG,
                         'Update SFDC existing Site Accounts: ');

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS PROCESS_ID,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.ADDRESS,
                                 NULL)
                            AS BILLING_STREET,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.CITY,
                                 NULL)
                            AS BILLING_CITY,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.STATE,
                                 NULL)
                            AS BILLING_STATE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.POSTAL_CODE,
                                 NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.COUNTRY,
                                 NULL)
                            AS BILLING_COUNTRY,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.ADDRESS,
                                 NULL)
                            AS SHIPPING_STREET,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.CITY,
                                 NULL)
                            AS SHIPPING_CITY,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.STATE,
                                 NULL)
                            AS SHIPPING_STATE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.POSTAL_CODE,
                                 NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.COUNTRY,
                                 NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         cdi.CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         KA.CONTRACT_NUMBER,
                         KA.description AS CONTRACT_NAME,
                         KA.KEY_ACCT_NUMBER,
                         KA.KEY_DESC AS KEY_ACCT_NAME,
                         SUB.TRANS_ACCT_NUMBER,
                         SUB.description AS TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE AS SFDC_ORG,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI,
                         HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB,
                         (SELECT trx.TRANS_ACCT_NUMBER,
                                 TRX.DESCRIPTION AS TRX_DESC,
                                 SUB.KEY_ACCT_NUMBER,
                                 SUB.DESCRIPTION AS KEY_DESC,
                                 ca.contract_number,
                                 ca.description
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                 (SELECT parent_id,
                                         node_ID,
                                         KEY_ACCT_NUMBER,
                                         DESCRIPTION
                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                   WHERE LEVEL_HIER = '5') SUB,
                                 HAEMO.XXHA_DRM_ACCT_STG_CURRENT TRX
                           WHERE     CA.NODE_ID = SUB.PARENT_ID
                                 AND TRX.PARENT_ID = SUB.NODE_ID) KA,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE level_hier = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'EXISTING SITES'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND CDI.SITE_USE_ID = SUB.TRANS_ACCT_NUMBER
                         AND CDI.SITE_USE_ID = KA.TRANS_ACCT_NUMBER(+)
                         AND SUB.LEVEL_HIER = '6'
                         AND EXISTS
                                (SELECT STG.SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)) B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);


      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Rows inserted for SFDC existing Site Accounts: ' || SQL%ROWCOUNT);

      -- INSERT for new Sites
      -- Code update on 01/21/2014 by VUPPAL to add ETL_PATH for new_site inserts below
      FND_FILE.PUT_LINE (FND_FILE.LOG, 'add SFDC new Site Accounts: ');

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS PROCESS_ID,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', ADDRESS, NULL)
                            AS BILLING_STREET,
                         DECODE (SITE_USE_CODE, 'BILL_TO', CITY, NULL)
                            AS BILLING_CITY,
                         DECODE (SITE_USE_CODE, 'BILL_TO', STATE, NULL)
                            AS BILLING_STATE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', POSTAL_CODE, NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', COUNTRY, NULL)
                            AS BILLING_COUNTRY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', ADDRESS, NULL)
                            AS SHIPPING_STREET,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', CITY, NULL)
                            AS SHIPPING_CITY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', STATE, NULL)
                            AS SHIPPING_STATE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', POSTAL_CODE, NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', COUNTRY, NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         CDI.CONTRACT_NUMBER,
                         KA.CONTRACT_NAME,
                         KA.KEY_ACCT_NUMBER,
                         NVL (KA.DESCRIPTION, ka.key_acct_number)
                            AS KEY_ACCT_NAME,
                         CDI.SITE_USE_ID AS TRANS_ACCT_NUMBER,
                         CDI.CUSTOMER_NAME AS TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE AS SFDC_ORG,
                         'PATH 1' AS ETL_PATH,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI, --  HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB
                         (SELECT CONTRACT_NUMBER,
                                 CONTRACT_NAME,
                                 KEY_ACCT_NUMBER,
                                 DESCRIPTION,
                                 ZIP_START,
                                 ZIP_END
                            FROM (SELECT DISTINCT
                                         CA.CONTRACT_NUMBER,
                                         CA.DESCRIPTION CONTRACT_NAME,
                                         SUB.KEY_ACCT_NUMBER,
                                         SUB.DESCRIPTION,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                  0,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  - 1)))
                                            AS ZIP_START,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  + 1)))
                                            AS ZIP_END,
                                         COUNT (
                                            *)
                                         OVER (
                                            PARTITION BY CA.CONTRACT_NUMBER)
                                            AS CNT_CONTRACT_NUM
                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                         (SELECT description,
                                                 key_acct_number,
                                                 parent_id,
                                                 zipcode_range
                                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                           WHERE LEVEL_HIER = '5') SUB
                                   WHERE CA.NODE_ID = SUB.PARENT_ID) SUB
                           WHERE CNT_CONTRACT_NUM = 1
                          UNION ALL
                          SELECT CONTRACT_NUMBER,
                                 CONTRACT_NAME,
                                 KEY_ACCT_NUMBER,
                                 DESCRIPTION,
                                 ZIP_START,
                                 ZIP_END
                            FROM (SELECT DISTINCT
                                         CA.CONTRACT_NUMBER,
                                         CA.DESCRIPTION CONTRACT_NAME,
                                         SUB.KEY_ACCT_NUMBER,
                                         SUB.DESCRIPTION,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                  0,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  - 1)))
                                            AS ZIP_START,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  + 1)))
                                            AS ZIP_END,
                                         COUNT (
                                            *)
                                         OVER (
                                            PARTITION BY CA.CONTRACT_NUMBER)
                                            AS CNT_CONTRACT_NUM
                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                         (SELECT description,
                                                 key_acct_number,
                                                 parent_id,
                                                 zipcode_range
                                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                           WHERE LEVEL_HIER = '5') SUB
                                   WHERE CA.NODE_ID = SUB.PARENT_ID) SUB
                           WHERE     CNT_CONTRACT_NUM > 1
                                 AND KEY_ACCT_NUMBER LIKE '%- Default'
                                 AND CONTRACT_NUMBER IN (SELECT DISTINCT
                                                                contract_number
                                                           FROM (SELECT DISTINCT
                                                                        contract_number,
                                                                        key_acct_number,
                                                                        zip_start,
                                                                        zip_end,
                                                                          TO_NUMBER (
                                                                             (LEAD (
                                                                                 zip_start,
                                                                                 1,
                                                                                 NULL)
                                                                              OVER (
                                                                                 PARTITION BY contract_number
                                                                                 ORDER BY
                                                                                    zip_start)))
                                                                        - zip_end
                                                                           AS zip_overlap
                                                                   FROM (WITH sub
                                                                              AS (SELECT DISTINCT
                                                                                         CA.CONTRACT_NUMBER,
                                                                                         SUB.KEY_ACCT_NUMBER,
                                                                                         sub.zipcode_range
                                                                                            AS str
                                                                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                                                                         (SELECT key_acct_number,
                                                                                                 parent_id,
                                                                                                 zipcode_range
                                                                                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                                                                           WHERE LEVEL_HIER =
                                                                                                    '5')
                                                                                         SUB
                                                                                   WHERE     CA.NODE_ID =
                                                                                                SUB.PARENT_ID
                                                                                         AND sub.zipcode_range
                                                                                                IS NOT NULL)
                                                                         SELECT T.contract_number,
                                                                                T.key_acct_number,
                                                                                TRIM (
                                                                                   x.COLUMN_VALUE.EXTRACT (
                                                                                      'e/text()'))
                                                                                   AS zip_range,
                                                                                TO_NUMBER (
                                                                                   LTRIM (
                                                                                      RTRIM (
                                                                                         SUBSTR (
                                                                                            TRIM (
                                                                                               x.COLUMN_VALUE.EXTRACT (
                                                                                                  'e/text()')),
                                                                                            0,
                                                                                              INSTR (
                                                                                                 TRIM (
                                                                                                    x.COLUMN_VALUE.EXTRACT (
                                                                                                       'e/text()')),
                                                                                                 '-')
                                                                                            - 1))))
                                                                                   AS ZIP_START,
                                                                                TO_NUMBER (
                                                                                   LTRIM (
                                                                                      RTRIM (
                                                                                         SUBSTR (
                                                                                            TRIM (
                                                                                               x.COLUMN_VALUE.EXTRACT (
                                                                                                  'e/text()')),
                                                                                              INSTR (
                                                                                                 TRIM (
                                                                                                    x.COLUMN_VALUE.EXTRACT (
                                                                                                       'e/text()')),
                                                                                                 '-')
                                                                                            + 1))))
                                                                                   AS ZIP_END
                                                                           FROM SUB t,
                                                                                TABLE (
                                                                                   XMLSEQUENCE (
                                                                                      xmltype (
                                                                                            '<e><e>'
                                                                                         || REPLACE (
                                                                                               t.str,
                                                                                               ',',
                                                                                               '</e><e>')
                                                                                         || '</e></e>').EXTRACT (
                                                                                         'e/e'))) x)
                                                                        sub)
                                                                ka
                                                          WHERE ka.zip_overlap <
                                                                   0)) KA,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE level_hier = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'NEW SITES'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND CDI.CONTRACT_NUMBER = KA.CONTRACT_NUMBER
                         AND EXISTS
                                (SELECT SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)
                  UNION ALL
                  SELECT DISTINCT
                         v_wm_seq,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', ADDRESS, NULL)
                            AS BILLING_STREET,
                         DECODE (SITE_USE_CODE, 'BILL_TO', CITY, NULL)
                            AS BILLING_CITY,
                         DECODE (SITE_USE_CODE, 'BILL_TO', STATE, NULL)
                            AS BILLING_STATE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', POSTAL_CODE, NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', COUNTRY, NULL)
                            AS BILLING_COUNTRY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', ADDRESS, NULL)
                            AS SHIPPING_STREET,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', CITY, NULL)
                            AS SHIPPING_CITY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', STATE, NULL)
                            AS SHIPPING_STATE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', POSTAL_CODE, NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', COUNTRY, NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         CDI.CONTRACT_NUMBER,
                         CDI.CUSTOMER_NAME,
                         KA.KEY_ACCT_NUMBER,
                         NVL (KA.DESCRIPTION, ka.key_acct_number),
                         CDI.SITE_USE_ID,
                         CDI.CUSTOMER_NAME AS TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE,
                         'PATH 2',
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI, --  HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB
                         (SELECT DISTINCT contract_number,
                                          key_acct_number,
                                          description,
                                          zip_start,
                                          zip_end
                            -- to_number((lead(zip_start,1,NULL) over(partition BY contract_number order by zip_start))) - zip_end AS zip_overlap
                            FROM (WITH sub
                                       AS (SELECT DISTINCT
                                                  CA.CONTRACT_NUMBER,
                                                  SUB.KEY_ACCT_NUMBER,
                                                  sub.description,
                                                  sub.zipcode_range AS str
                                             FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                                  (SELECT key_acct_number,
                                                          description,
                                                          parent_id,
                                                          zipcode_range
                                                     FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                                    WHERE LEVEL_HIER = '5')
                                                  SUB
                                            WHERE     CA.NODE_ID =
                                                         SUB.PARENT_ID
                                                  AND sub.zipcode_range
                                                         IS NOT NULL)
                                  SELECT T.contract_number,
                                         T.key_acct_number,
                                         t.description,
                                         TRIM (
                                            x.COLUMN_VALUE.EXTRACT (
                                               'e/text()'))
                                            AS zip_range,
                                         TO_NUMBER (
                                            LTRIM (
                                               RTRIM (
                                                  SUBSTR (
                                                     TRIM (
                                                        x.COLUMN_VALUE.EXTRACT (
                                                           'e/text()')),
                                                     0,
                                                       INSTR (
                                                          TRIM (
                                                             x.COLUMN_VALUE.EXTRACT (
                                                                'e/text()')),
                                                          '-')
                                                     - 1))))
                                            AS ZIP_START,
                                         TO_NUMBER (
                                            LTRIM (
                                               RTRIM (
                                                  SUBSTR (
                                                     TRIM (
                                                        x.COLUMN_VALUE.EXTRACT (
                                                           'e/text()')),
                                                       INSTR (
                                                          TRIM (
                                                             x.COLUMN_VALUE.EXTRACT (
                                                                'e/text()')),
                                                          '-')
                                                     + 1))))
                                            AS ZIP_END
                                    FROM SUB t,
                                         TABLE (
                                            XMLSEQUENCE (
                                               xmltype (
                                                     '<e><e>'
                                                  || REPLACE (t.str,
                                                              ',',
                                                              '</e><e>')
                                                  || '</e></e>').EXTRACT (
                                                  'e/e'))) x) sub
                           WHERE CONTRACT_NUMBER NOT IN (SELECT DISTINCT
                                                                contract_number
                                                           FROM (SELECT DISTINCT
                                                                        contract_number,
                                                                        key_acct_number,
                                                                        zip_start,
                                                                        zip_end,
                                                                          TO_NUMBER (
                                                                             (LEAD (
                                                                                 zip_start,
                                                                                 1,
                                                                                 NULL)
                                                                              OVER (
                                                                                 PARTITION BY contract_number
                                                                                 ORDER BY
                                                                                    zip_start)))
                                                                        - zip_end
                                                                           AS zip_overlap
                                                                   FROM (WITH sub
                                                                              AS (SELECT DISTINCT
                                                                                         CA.CONTRACT_NUMBER,
                                                                                         SUB.KEY_ACCT_NUMBER,
                                                                                         sub.zipcode_range
                                                                                            AS str
                                                                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                                                                         (SELECT key_acct_number,
                                                                                                 parent_id,
                                                                                                 zipcode_range
                                                                                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                                                                           WHERE LEVEL_HIER =
                                                                                                    '5')
                                                                                         SUB
                                                                                   WHERE     CA.NODE_ID =
                                                                                                SUB.PARENT_ID
                                                                                         AND sub.zipcode_range
                                                                                                IS NOT NULL)
                                                                         SELECT T.contract_number,
                                                                                T.key_acct_number,
                                                                                TRIM (
                                                                                   x.COLUMN_VALUE.EXTRACT (
                                                                                      'e/text()'))
                                                                                   AS zip_range,
                                                                                TO_NUMBER (
                                                                                   LTRIM (
                                                                                      RTRIM (
                                                                                         SUBSTR (
                                                                                            TRIM (
                                                                                               x.COLUMN_VALUE.EXTRACT (
                                                                                                  'e/text()')),
                                                                                            0,
                                                                                              INSTR (
                                                                                                 TRIM (
                                                                                                    x.COLUMN_VALUE.EXTRACT (
                                                                                                       'e/text()')),
                                                                                                 '-')
                                                                                            - 1))))
                                                                                   AS ZIP_START,
                                                                                TO_NUMBER (
                                                                                   LTRIM (
                                                                                      RTRIM (
                                                                                         SUBSTR (
                                                                                            TRIM (
                                                                                               x.COLUMN_VALUE.EXTRACT (
                                                                                                  'e/text()')),
                                                                                              INSTR (
                                                                                                 TRIM (
                                                                                                    x.COLUMN_VALUE.EXTRACT (
                                                                                                       'e/text()')),
                                                                                                 '-')
                                                                                            + 1))))
                                                                                   AS ZIP_END
                                                                           FROM SUB t,
                                                                                TABLE (
                                                                                   XMLSEQUENCE (
                                                                                      xmltype (
                                                                                            '<e><e>'
                                                                                         || REPLACE (
                                                                                               t.str,
                                                                                               ',',
                                                                                               '</e><e>')
                                                                                         || '</e></e>').EXTRACT (
                                                                                         'e/e'))) x)
                                                                        sub)
                                                                ka
                                                          WHERE ka.zip_overlap <
                                                                   0)) KA,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE level_hier = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'NEW SITES'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND CDI.CONTRACT_NUMBER = KA.CONTRACT_NUMBER
                         AND TO_NUMBER (CDI.POSTAL_CODE) BETWEEN KA.ZIP_START
                                                             AND KA.ZIP_END
                         AND EXISTS
                                (SELECT SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)) B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    ETL_PATH = B.ETL_PATH,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     ETL_PATH,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.ETL_PATH,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            'Rows inserted for SFDC new Site Accounts for MATCHING ZIP: '
         || SQL%ROWCOUNT);

      -- ADD Second insert to ensure that Sites not matching on ZIP RANGE get to default

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS PROCESS_ID,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', ADDRESS, NULL)
                            AS BILLING_STREET,
                         DECODE (SITE_USE_CODE, 'BILL_TO', CITY, NULL)
                            AS BILLING_CITY,
                         DECODE (SITE_USE_CODE, 'BILL_TO', STATE, NULL)
                            AS BILLING_STATE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', POSTAL_CODE, NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', COUNTRY, NULL)
                            AS BILLING_COUNTRY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', ADDRESS, NULL)
                            AS SHIPPING_STREET,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', CITY, NULL)
                            AS SHIPPING_CITY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', STATE, NULL)
                            AS SHIPPING_STATE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', POSTAL_CODE, NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', COUNTRY, NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         CDI.CONTRACT_NUMBER,
                         KA.CONTRACT_NAME,
                         KA.KEY_ACCT_NUMBER,
                         NVL (KA.DESCRIPTION, ka.key_acct_number)
                            AS KEY_ACCT_NAME,
                         CDI.SITE_USE_ID AS TRANS_ACCT_NUMBER,
                         CDI.CUSTOMER_NAME AS TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE AS SFDC_ORG,
                         'PATH 3' AS ETL_PATH,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI, --  HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB
                         (SELECT CONTRACT_NUMBER,
                                 CONTRACT_NAME,
                                 KEY_ACCT_NUMBER,
                                 DESCRIPTION,
                                 ZIP_START,
                                 ZIP_END
                            FROM (SELECT DISTINCT
                                         CA.CONTRACT_NUMBER,
                                         CA.DESCRIPTION CONTRACT_NAME,
                                         SUB.KEY_ACCT_NUMBER,
                                         SUB.DESCRIPTION,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                  0,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  - 1)))
                                            AS ZIP_START,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  + 1)))
                                            AS ZIP_END,
                                         COUNT (
                                            *)
                                         OVER (
                                            PARTITION BY CA.CONTRACT_NUMBER)
                                            AS CNT_CONTRACT_NUM
                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                         (SELECT description,
                                                 key_acct_number,
                                                 parent_id,
                                                 zipcode_range
                                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                           WHERE LEVEL_HIER = '5') SUB
                                   WHERE CA.NODE_ID = SUB.PARENT_ID) SUB
                           WHERE     CNT_CONTRACT_NUM > 1
                                 --  and KEY_ACCT_NUMBER like '%- Default'
                                 AND CONTRACT_NUMBER NOT IN (SELECT CONTRACT_NUMBER
                                                               FROM (SELECT DISTINCT
                                                                            CA.CONTRACT_NUMBER,
                                                                            SUB.KEY_ACCT_NUMBER,
                                                                            SUB.DESCRIPTION,
                                                                            LTRIM (
                                                                               RTRIM (
                                                                                  SUBSTR (
                                                                                     SUB.ZIPCODE_RANGE,
                                                                                     0,
                                                                                       INSTR (
                                                                                          SUB.ZIPCODE_RANGE,
                                                                                          '-')
                                                                                     - 1)))
                                                                               AS ZIP_START,
                                                                            LTRIM (
                                                                               RTRIM (
                                                                                  SUBSTR (
                                                                                     SUB.ZIPCODE_RANGE,
                                                                                       INSTR (
                                                                                          SUB.ZIPCODE_RANGE,
                                                                                          '-')
                                                                                     + 1)))
                                                                               AS ZIP_END,
                                                                            COUNT (
                                                                               *)
                                                                            OVER (
                                                                               PARTITION BY CA.CONTRACT_NUMBER,
                                                                                            LTRIM (
                                                                                               RTRIM (
                                                                                                  SUBSTR (
                                                                                                     SUB.ZIPCODE_RANGE,
                                                                                                       INSTR (
                                                                                                          SUB.ZIPCODE_RANGE,
                                                                                                          '-')
                                                                                                     + 1))))
                                                                               AS CNT_CONTRACT_NUM
                                                                       FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                                                            (SELECT description,
                                                                                    key_acct_number,
                                                                                    parent_id,
                                                                                    zipcode_range
                                                                               FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                                                              WHERE LEVEL_HIER =
                                                                                       '5')
                                                                            SUB
                                                                      WHERE CA.NODE_ID =
                                                                               SUB.PARENT_ID)
                                                                    SUB
                                                              WHERE CNT_CONTRACT_NUM >
                                                                       1)) KA,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE level_hier = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'NEW SITES'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND CDI.CONTRACT_NUMBER = KA.CONTRACT_NUMBER
                         AND KEY_ACCT_NUMBER LIKE '%Default'
                         AND EXISTS
                                (SELECT SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)
                         AND (v_wm_seq, SITE_USE_ID) NOT IN (SELECT process_id,
                                                                    trans_acct_number
                                                               FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG))
                 B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    ETL_PATH = B.ETL_PATH,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     ETL_PATH,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.ETL_PATH,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);


      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            'Rows inserted for SFDC new Site Accounts for Default ZIP: '
         || SQL%ROWCOUNT);

      -- ADD military type sites

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS PROCESS_ID,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', ADDRESS, NULL)
                            AS BILLING_STREET,
                         DECODE (SITE_USE_CODE, 'BILL_TO', CITY, NULL)
                            AS BILLING_CITY,
                         DECODE (SITE_USE_CODE, 'BILL_TO', STATE, NULL)
                            AS BILLING_STATE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', POSTAL_CODE, NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', COUNTRY, NULL)
                            AS BILLING_COUNTRY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', ADDRESS, NULL)
                            AS SHIPPING_STREET,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', CITY, NULL)
                            AS SHIPPING_CITY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', STATE, NULL)
                            AS SHIPPING_STATE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', POSTAL_CODE, NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', COUNTRY, NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         CDI.SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         ka.CONTRACT_NUMBER,
                         KA.CONTRACT_NAME,
                         KA.KEY_ACCT_NUMBER,
                         NVL (KA.KEY_ACCT_NAME, ka.key_acct_number)
                            AS KEY_ACCT_NAME,
                         CDI.SITE_USE_ID AS TRANS_ACCT_NUMBER,
                         CDI.CUSTOMER_NAME AS TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE AS SFDC_ORG,
                         KA.ETL_PATH,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI, --  HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB
                         (SELECT CA.CONTRACT_NUMBER,
                                 CA.DESCRIPTION CONTRACT_NAME,
                                 KA.DESCRIPTION KEY_ACCT_NAME,
                                 KA.KEY_ACCT_NUMBER,
                                 CDI.SITE_USE_ID,
                                 CASE
                                    WHEN COUNT (DISTINCT KA.NODE_ID)
                                            OVER (PARTITION BY CA.NODE_ID) =
                                            1
                                    THEN
                                       'PATH 4'
                                    ELSE
                                       'PATH 5'
                                 END
                                    ETL_PATH,
                                 ROW_NUMBER ()
                                 OVER (
                                    PARTITION BY CDI.SITE_USE_ID
                                    ORDER BY
                                       CASE
                                          WHEN KA.CONTRACT_NUMBER =
                                                  CDI.CONTRACT_NUMBER
                                          THEN
                                             1
                                          WHEN REGEXP_LIKE (
                                                  KA.MANUAL_CONTRACT_NUMBER,
                                                  CDI.CONTRACT_NUMBER)
                                          THEN
                                             2
                                          WHEN CA.CONTRACT_NUMBER LIKE
                                                  '%' || CDI.CUSTOMER_NUMBER
                                          THEN
                                             3
                                          ELSE
                                             10
                                       END,
                                       CASE
                                          WHEN KA.KEY_ACCT_NUMBER LIKE
                                                  '%Default'
                                          THEN
                                             1
                                          ELSE
                                             10
                                       END,
                                       CASE
                                          WHEN REGEXP_LIKE (
                                                  KA.KA_DERIVED_CONTRACT_NUM,
                                                  CDI.CONTRACT_NUMBER)
                                          THEN
                                             1
                                          ELSE
                                             10
                                       END,
                                       CA.LEAF_DESCENDANTS,
                                       LENGTH (CA.DERIVED_CONTRACT_NUMBER))
                                    rnk
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                 HAEMO.XXHA_DRM_ACCT_STG_CURRENT KA,
                                 HAEMO.XXHA_EBS_CUST_DELTA_INT CDI
                           WHERE     CA.NODE_ID = KA.PARENT_ID
                                 AND CA.LEVEL_HIER = 4
                                 AND REGEXP_LIKE (CA.DERIVED_CONTRACT_NUMBER,
                                                  CDI.CONTRACT_NUMBER)
                                 AND NOT EXISTS
                                            (SELECT 0
                                               FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG STG
                                              WHERE STG.SITE_USE_ID =
                                                       CDI.SITE_USE_ID)) KA,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE LEVEL_HIER = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'NEW SITES'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND KA.SITE_USE_ID = CDI.SITE_USE_ID
                         AND KA.rnk = 1
                         AND EXISTS
                                (SELECT SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)
                         AND (v_wm_seq, CDI.SITE_USE_ID) NOT IN (SELECT process_id,
                                                                        trans_acct_number
                                                                   FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG))
                 B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    ETL_PATH = B.ETL_PATH,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     ETL_PATH,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.ETL_PATH,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);


      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            'Rows inserted for SFDC new Site Accounts for Military Type Accounts: '
         || SQL%ROWCOUNT);

      -- Add sites for matches on Manual Contract Number

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS PROCESS_ID,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', ADDRESS, NULL)
                            AS BILLING_STREET,
                         DECODE (SITE_USE_CODE, 'BILL_TO', CITY, NULL)
                            AS BILLING_CITY,
                         DECODE (SITE_USE_CODE, 'BILL_TO', STATE, NULL)
                            AS BILLING_STATE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', POSTAL_CODE, NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', COUNTRY, NULL)
                            AS BILLING_COUNTRY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', ADDRESS, NULL)
                            AS SHIPPING_STREET,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', CITY, NULL)
                            AS SHIPPING_CITY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', STATE, NULL)
                            AS SHIPPING_STATE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', POSTAL_CODE, NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', COUNTRY, NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         KA.CONTRACT AS CONTRACT_NUMBER,
                         KA.CONTRACT_NAME,
                         KA.KEY_ACCT_NUMBER,
                         NVL (KA.DESCRIPTION, ka.key_acct_number)
                            AS KEY_ACCT_NAME,
                         CDI.SITE_USE_ID AS TRANS_ACCT_NUMBER,
                         CDI.CUSTOMER_NAME AS TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE AS SFDC_ORG,
                         'PATH 6' AS ETL_PATH,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI, --  HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB
                         (SELECT DRM.NODE_NAME,
                                 SUB.CONTRACT_NUMBER,
                                 SUB.CONTRACT_NAME,
                                 DRM.DESCRIPTION,
                                 DRM.KEY_ACCT_NUMBER,
                                 SUB.CONTRACT
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DRM,
                                 (SELECT DISTINCT
                                         NODE_NAME,
                                         CDI.CONTRACT_NUMBER,
                                         CURR.DESCRIPTION CONTRACT_NAME,
                                         CURR.CONTRACT_NUMBER AS CONTRACT
                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CURR,
                                         HAEMO.XXHA_EBS_CUST_DELTA_INT CDI
                                   WHERE     MANUAL_CONTRACT_NUMBER
                                                IS NOT NULL
                                         AND CDI.CHANGE_DESC = 'NEW SITES'
                                         AND REGEXP_LIKE (
                                                MANUAL_CONTRACT_NUMBER,
                                                cdi.contract_number)
                                         AND LEVEL_HIER = '4') SUB
                           WHERE     DRM.PARENT_NODE = SUB.NODE_NAME
                                 AND DRM.NODE_NAME LIKE '% - Default'
                                 AND SUB.CONTRACT_NUMBER NOT IN (SELECT DISTINCT
                                                                        CONTRACT_NUMBER
                                                                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                                                  WHERE LEVEL_HIER =
                                                                           '4'))
                         KA,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE level_hier = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'NEW SITES'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND CDI.CONTRACT_NUMBER = KA.CONTRACT_NUMBER
                         AND EXISTS
                                (SELECT SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)
                         AND (v_wm_seq, SITE_USE_ID) NOT IN (SELECT process_id,
                                                                    trans_acct_number
                                                               FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG))
                 B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    ETL_PATH = B.ETL_PATH,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     ETL_PATH,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.ETL_PATH,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);

      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            'Rows inserted for SFDC new Site Accounts for Manual Contract Accounts: '
         || SQL%ROWCOUNT);

      -- Add code to cover sites not being picked up above on 12/7/13

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS PROCESS_ID,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', ADDRESS, NULL)
                            AS BILLING_STREET,
                         DECODE (SITE_USE_CODE, 'BILL_TO', CITY, NULL)
                            AS BILLING_CITY,
                         DECODE (SITE_USE_CODE, 'BILL_TO', STATE, NULL)
                            AS BILLING_STATE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', POSTAL_CODE, NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'BILL_TO', COUNTRY, NULL)
                            AS BILLING_COUNTRY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', ADDRESS, NULL)
                            AS SHIPPING_STREET,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', CITY, NULL)
                            AS SHIPPING_CITY,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', STATE, NULL)
                            AS SHIPPING_STATE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', POSTAL_CODE, NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (SITE_USE_CODE, 'SHIP_TO', COUNTRY, NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         CDI.CONTRACT_NUMBER,
                         KA.CONTRACT_NAME,
                         KA.KEY_ACCT_NUMBER,
                         NVL (KA.DESCRIPTION, ka.key_acct_number)
                            AS KEY_ACCT_NAME,
                         CDI.SITE_USE_ID AS TRANS_ACCT_NUMBER,
                         CDI.CUSTOMER_NAME AS TRANS_ACCT_NAME,
                         CHANGE_DESC,
                         DRM_SUB.SFDC_INSTANCE AS SFDC_ORG,
                         'PATH 7' AS ETL_PATH,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT CDI, --  HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB
                         (SELECT CONTRACT_NUMBER,
                                 CONTRACT_NAME,
                                 KEY_ACCT_NUMBER,
                                 DESCRIPTION,
                                 ZIP_START,
                                 ZIP_END
                            FROM (SELECT DISTINCT
                                         CA.CONTRACT_NUMBER,
                                         CA.DESCRIPTION CONTRACT_NAME,
                                         SUB.KEY_ACCT_NUMBER,
                                         SUB.DESCRIPTION,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                  0,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  - 1)))
                                            AS ZIP_START,
                                         LTRIM (
                                            RTRIM (
                                               SUBSTR (
                                                  SUB.ZIPCODE_RANGE,
                                                    INSTR (SUB.ZIPCODE_RANGE,
                                                           '-')
                                                  + 1)))
                                            AS ZIP_END,
                                         COUNT (
                                            *)
                                         OVER (
                                            PARTITION BY CA.CONTRACT_NUMBER)
                                            AS CNT_CONTRACT_NUM
                                    FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                         (SELECT description,
                                                 key_acct_number,
                                                 parent_id,
                                                 zipcode_range
                                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                                           WHERE LEVEL_HIER = '5') SUB
                                   WHERE CA.NODE_ID = SUB.PARENT_ID) SUB) KA,
                         (SELECT DISTINCT
                                 LTRIM (
                                    SUBSTR (NODE_NAME,
                                            INSTR (NODE_NAME, ' - ') + 2))
                                    AS ORG_ID,
                                 SFDC_INSTANCE,
                                 UPPER (LOAD_DATA) AS LOAD_DATA
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                           WHERE level_hier = '3') DRM_SUB
                   WHERE     CHANGE_DESC = 'NEW SITES'
                         AND CDI.ORG_ID = DRM_SUB.ORG_ID
                         AND DRM_SUB.LOAD_DATA = 'TRUE'
                         AND CDI.CONTRACT_NUMBER = KA.CONTRACT_NUMBER
                         AND KEY_ACCT_NUMBER LIKE '%Default'
                         AND EXISTS
                                (SELECT SITE_USE_ID
                                   FROM HAEMO.XXHA_EBS_CUST_DELTA_STG STG
                                  WHERE STG.SITE_USE_ID = CDI.SITE_USE_ID)
                         AND (v_wm_seq, SITE_USE_ID) NOT IN (SELECT process_id,
                                                                    trans_acct_number
                                                               FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG))
                 B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    ETL_PATH = B.ETL_PATH,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     ETL_PATH,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.ETL_PATH,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);


      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            'Rows inserted for SFDC new Site Accounts where no match occured above: '
         || SQL%ROWCOUNT);



      -- end of code being added for site insert on 12/7/13

      -- MERGE change data back into HAEMO.XXHA_EBS_CUST_MASTER_STG
      -- ADD Distinct to MERGE below on 12/7/13

      MERGE INTO HAEMO.XXHA_EBS_CUST_MASTER_STG A
           USING (SELECT DISTINCT DL.CUSTOMER_ID,
                                  DL.CUSTOMER_NUMBER,
                                  DL.CUSTOMER_NAME,
                                  DL.CUSTOMER_TYPE,
                                  DL.ADDRESS,
                                  DL.ORG_ID,
                                  DL.CITY,
                                  DL.STATE,
                                  DL.POSTAL_CODE,
                                  DL.COUNTRY,
                                  DL.AGENT,
                                  DL.SITE_USE_CODE,
                                  DL.SITE_USE_ID,
                                  DL.SITE_NUMBER,
                                  DL.PRIMARY_SALESREP_ID,
                                  DL.STATUS,
                                  DL.PHONE_NUMBER,
                                  DL.FAX_NUMBER,
                                  DL.CONTRACT_NUMBER,
                                  STG.CUST_UPDT_DATE,
                                  STG.CUST_CREATION_DATE,
                                  STG.ADDR_UPDT_DATE,
                                  STG.ADDR_CREATION_DATE,
                                  STG.SITE_UPDT_DATE,
                                  STG.SITE_CREATION_DATE,
                                  STG.ADDRESS_ID,
                                  STG.SALES_CHANNEL,
                                  STG.CATEGORY,
                                  STG.CLASS,
                                  STG.OU_NAME,
                                  STG.LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_DELTA_INT DL,
                         HAEMO.XXHA_EBS_CUST_DELTA_STG STG,
                         HAEMO.XXHA_EBS_SFDC_ACCT_STG SFDC
                   WHERE     STG.SITE_USE_ID = DL.SITE_USE_ID
                         AND STG.SITE_USE_ID = SFDC.TRANS_ACCT_NUMBER) B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET CUSTOMER_ID = B.CUSTOMER_ID,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    CUST_UPDT_DATE = B.CUST_UPDT_DATE,
                    CUST_CREATION_DATE = B.CUST_CREATION_DATE,
                    ADDRESS_ID = B.ADDRESS_ID,
                    ADDRESS = B.ADDRESS,
                    ORG_ID = B.ORG_ID,
                    CITY = B.CITY,
                    STATE = B.STATE,
                    POSTAL_CODE = B.POSTAL_CODE,
                    COUNTRY = B.COUNTRY,
                    AGENT = B.AGENT,
                    ADDR_UPDT_DATE = B.ADDR_UPDT_DATE,
                    ADDR_CREATION_DATE = B.ADDR_CREATION_DATE,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    SITE_UPDT_DATE = B.SITE_UPDT_DATE,
                    SITE_CREATION_DATE = B.SITE_CREATION_DATE,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (CUSTOMER_ID,
                     CUSTOMER_NUMBER,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     CUST_UPDT_DATE,
                     CUST_CREATION_DATE,
                     ADDRESS_ID,
                     ADDRESS,
                     ORG_ID,
                     CITY,
                     STATE,
                     POSTAL_CODE,
                     COUNTRY,
                     AGENT,
                     ADDR_UPDT_DATE,
                     ADDR_CREATION_DATE,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     SITE_UPDT_DATE,
                     SITE_CREATION_DATE,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     CONTRACT_NUMBER,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.CUSTOMER_ID,
                     B.CUSTOMER_NUMBER,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.CUST_UPDT_DATE,
                     B.CUST_CREATION_DATE,
                     B.ADDRESS_ID,
                     B.ADDRESS,
                     B.ORG_ID,
                     B.CITY,
                     B.STATE,
                     B.POSTAL_CODE,
                     B.COUNTRY,
                     B.AGENT,
                     B.ADDR_UPDT_DATE,
                     B.ADDR_CREATION_DATE,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.SITE_UPDT_DATE,
                     B.SITE_CREATION_DATE,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.CONTRACT_NUMBER,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);


      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
         'Rows merged into EBS CUST Master: ' || SQL%ROWCOUNT);

      -- PURGE status table for older records

      DELETE FROM HAEMO.XXHA_DRM_INT_PROCESS_STATUS
            WHERE     process_name = 'DRM_HOURLY_PROCESS'
                  AND process_end_tmstmp < SYSDATE - 14
                  AND EXISTS
                         (SELECT COUNT (*)
                            FROM HAEMO.XXHA_DRM_INT_PROCESS_STATUS
                           WHERE process_name = 'DRM_HOURLY_PROCESS'
                          HAVING COUNT (*) > 24);


      UPDATE HAEMO.XXHA_WM_DRM_SFDC_INT_STATUS
         SET PROCESS_RUNNING_STATUS = 'N'
       WHERE PROCESS_ID = v_wm_seq;

      COMMIT;
   END ADD_SFDC_ACCTS;
END XXHA_DRM_ACCOUNTS_INT_HOURLY;
/
