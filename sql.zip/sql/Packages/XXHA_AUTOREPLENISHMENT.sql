create or replace PACKAGE XXHA_AUTOREPLENISHMENT IS  

-- Eric Rossing
-- 10/26/2010
-- Package to create orders from inventory snapshots

PROCEDURE generate_orders
/* This procedure is run as a concurrent request to generate orders based on
   the current inventory snapshot for a customer. Only customers and sites
   in the XXHA_AUTOREP_* tables and flagged as enabled for autoreplenishment
   will be checked for reordering.
*/
			(	errbuf			OUT	VARCHAR2, --Holds the error message, if any
				retcode			OUT	NUMBER,   --Holds the Concurrent Program status code for the job.  0=Successful, 1=Warning, 2=Error
				P_CUSTOMER_ID	IN	NUMBER,   --The Oracle Customer ID of the customer for whom to generate orders
				P_SAFETY_MARGIN	IN	NUMBER    --The minimum number of days between order-generation runs. If the time since the last order generation run is less than this margin, no orders will be generated
			);
			
PROCEDURE archive_inventory
/* This procedure is used to archive a customer's inventory data, moving it
   from XXHA_AUTOREP_INVENTORY to XXHA_AUTOREP_INV_ARCHIVE. This is done just
   before a new snapshot is loaded.
*/
			(	errbuf			OUT	VARCHAR2, --Holds the error message, if any
				P_CUSTOMER_ID	IN	NUMBER    --The Oracle customer ID of the customer for whom to archive inventory
			);

end XXHA_AUTOREPLENISHMENT;
/

create or replace PACKAGE BODY XXHA_AUTOREPLENISHMENT IS
  /*******************************************************************************************************
  * Object Name: XXHA_WM_SHIPMENT_XML_PKG
  * Object Type: PACKAGE BODY
  *
  * Description: This Package will be used in shipshipment process
  *
  * Modification Log:
  * Developer          Date              Description
  *-----------------   ------------      --------------------------------------------------------------
  * Eric Rossing                         Initial object creation.
  * Eric Rossing       23-MAR-2016       Modify order header query to report Ship Tos that do not link to a Bill To as an error
  *
  *******************************************************************************************************/

PROCEDURE generate_orders
			(	errbuf			OUT	VARCHAR2,
				retcode			OUT	NUMBER,
				P_CUSTOMER_ID	IN	NUMBER,
				P_SAFETY_MARGIN	IN	NUMBER
			) IS

	V_ORDER_ID				XXHA_AUTOREP_ORDER_HEADER.HEADER_ID%TYPE;
	V_LINE_ID				XXHA_AUTOREP_ORDER_LINE.LINE_ID%TYPE;
	V_LINE_NUMBER			XXHA_AUTOREP_ORDER_LINE.LINE_NUMBER%TYPE;
	
	V_LINE_COUNT			NUMBER;
	V_LAST_RUN_DATE			DATE;
	V_THIS_RUN_DATE			DATE := SYSDATE;
	V_ENABLED				VARCHAR2(1);
	
BEGIN
	--Log input parameters
--	FND_FILE.PUT_LINE(FND_FILE.LOG,'Input parameters');
--	FND_FILE.PUT_LINE(FND_FILE.LOG,'P_CUSTOMER_ID   = ' || P_CUSTOMER_ID);
--	FND_FILE.PUT_LINE(FND_FILE.LOG,'P_SAFETY_MARGIN = ' || P_SAFETY_MARGIN);
--	FND_FILE.PUT_LINE(FND_FILE.LOG,'');

	--Make sure customer is part of AutoReplenishment system
	SELECT COUNT(1)
	INTO V_LINE_COUNT
	FROM XXHA_AUTOREP_CUSTOMERS
	WHERE CUSTOMER_ID = P_CUSTOMER_ID;
	
	IF V_LINE_COUNT > 0 THEN
	
		--Make sure customer is enabled for AutoReplenishment and it has been at least P_SAFETY_MARGIN days since the last order-generation run
		SELECT NVL(LAST_RUN_DATE,TO_DATE('01-APR-2007')), AUTOREP_ENABLED
		INTO V_LAST_RUN_DATE, V_ENABLED
		FROM XXHA_AUTOREP_CUSTOMERS
		WHERE CUSTOMER_ID = P_CUSTOMER_ID;
		
		IF V_ENABLED = 'Y' AND V_LAST_RUN_DATE + P_SAFETY_MARGIN <= SYSDATE THEN
		
			--Loop over each site belonging to the customer that is enabled for AutoReplenishment and has inventory in the current snapshot
			FOR C_ORD_HDR_REC IN (
				SELECT DISTINCT XAI.SITE_ID,
					CASE WHEN HCASA_SHIP.ATTRIBUTE8 IS NULL THEN HCASA_BILL.ATTRIBUTE8 ELSE HCASA_SHIP.ATTRIBUTE8 END BLANKET_PO_NUMBER,
          HCSUA_SHIP.BILL_TO_SITE_USE_ID,
          HPS_SHIP.PARTY_SITE_NUMBER
				FROM XXHA_AUTOREP_INVENTORY XAI,
					XXHA_AUTOREP_SITES XAS,
					XXHA_AUTOREP_CUSTOMERS XAC,
					HZ_CUST_ACCT_SITES_ALL HCASA_SHIP,
					HZ_CUST_SITE_USES_ALL HCSUA_SHIP,
					HZ_CUST_SITE_USES_ALL HCSUA_BILL,
					HZ_CUST_ACCT_SITES_ALL HCASA_BILL,
          HZ_PARTY_SITES HPS_SHIP
				WHERE XAI.SITE_ID = XAS.SITE_ID
					AND XAC.CUSTOMER_ID = XAS.CUSTOMER_ID
					AND XAS.CUSTOMER_ID = P_CUSTOMER_ID
					AND XAS.SITE_ID = HCASA_SHIP.CUST_ACCT_SITE_ID
					AND HCASA_SHIP.CUST_ACCT_SITE_ID = HCSUA_SHIP.CUST_ACCT_SITE_ID(+) -- Eric Rossing - 23-MAR-2016 - Modify order header query to allow for Ship Tos that do not link to a Bill To
					AND HCSUA_SHIP.BILL_TO_SITE_USE_ID = HCSUA_BILL.SITE_USE_ID (+) -- Eric Rossing - 23-MAR-2016 - Modify order header query to allow for Ship Tos that do not link to a Bill To
					AND HCSUA_BILL.CUST_ACCT_SITE_ID = HCASA_BILL.CUST_ACCT_SITE_ID (+) -- Eric Rossing - 23-MAR-2016 - Modify order header query to allow for Ship Tos that do not link to a Bill To
					AND HCSUA_SHIP.SITE_USE_CODE (+) = 'SHIP_TO' -- Eric Rossing - 23-MAR-2016 - Modify order header query to allow for Ship Tos that do not link to a Bill To
          AND HCASA_SHIP.PARTY_SITE_ID = HPS_SHIP.PARTY_SITE_ID (+)
					AND XAS.AUTOREP_ENABLED = 'Y'
				ORDER BY SITE_ID
			)
			LOOP
      
        IF C_ORD_HDR_REC.BLANKET_PO_NUMBER IS NOT NULL AND C_ORD_HDR_REC.BILL_TO_SITE_USE_ID IS NOT NULL THEN
			
          --Create temporary order line records based on the site's Reorder Levels
          INSERT INTO XXHA_AUTOREP_ORDER_LINE_TEMP
            SELECT XAITRV.INVENTORY_ITEM_ID,
              XAITRV.REORDER_QTY
            FROM	XXHA_AUTOREP_INV_TO_REORDER_VW XAITRV,
              MTL_UOM_CONVERSIONS MUC
            WHERE XAITRV.SITE_ID = C_ORD_HDR_REC.SITE_ID
              AND XAITRV.INVENTORY_ITEM_ID = MUC.INVENTORY_ITEM_ID
              AND MUC.UOM_CODE (+) = 'Ca';
          
          --Create temporary order line records based on the site's Inventory Balance Ratios
          INSERT INTO XXHA_AUTOREP_ORDER_LINE_TEMP
            SELECT XAIB.RELATED_ITEM_ID,
              ((XAIE_P.TOTAL_INVENTORY + NVL(TMP.QUANTITY,0)) * XAIB.BALANCE_RATIO) - NVL(XAIE_R.TOTAL_INVENTORY,0)
            FROM XXHA_AUTOREP_ORDER_LINE_TEMP TMP,
              XXHA_AUTOREP_INV_BALANCE XAIB,
              XXHA_AUTOREP_INVENTORY_EA XAIE_P,
              XXHA_AUTOREP_INVENTORY_EA XAIE_R,
              MTL_UOM_CONVERSIONS MUC
            WHERE TMP.INVENTORY_ITEM_ID (+) = XAIB.PRIMARY_ITEM_ID
              AND XAIB.SITE_ID = C_ORD_HDR_REC.SITE_ID
              AND XAIB.SITE_ID = XAIE_P.SITE_ID
              AND XAIB.PRIMARY_ITEM_ID = XAIE_P.INVENTORY_ITEM_ID
              AND XAIB.SITE_ID = XAIE_R.SITE_ID (+)
              AND XAIB.RELATED_ITEM_ID = XAIE_R.INVENTORY_ITEM_ID (+)
              AND XAIB.RELATED_ITEM_ID = MUC.INVENTORY_ITEM_ID (+)
              AND MUC.UOM_CODE(+) = 'Ca'
              AND ((XAIE_P.TOTAL_INVENTORY + NVL(TMP.QUANTITY,0)) * XAIB.BALANCE_RATIO) - NVL(XAIE_R.TOTAL_INVENTORY,0) > (CASE WHEN (MUC.CONVERSION_RATE IS NOT NULL) AND (XAIB.MINIMUM_ORDER_QTY_UOM = 'Ca') THEN XAIB.MINIMUM_ORDER_QTY * MUC.CONVERSION_RATE ELSE XAIB.MINIMUM_ORDER_QTY END);
            
          --Determine whether there is anything that needs to be ordered for the site
          SELECT COUNT(1)
          INTO V_LINE_COUNT
          FROM XXHA_AUTOREP_ORDER_LINE_TEMP;
            
          IF V_LINE_COUNT > 0 THEN
          
            --Get the next ORDER_ID from the sequence
            SELECT HAEMO.XXHA_AUTOREP_ORD_HDR_ID.nextval
            INTO V_ORDER_ID
            FROM DUAL;
          
            --Initialize the line number counter
            V_LINE_NUMBER := 0;
            
            --For each item in the temporary order line table, select the maximum quantity and loop over the results
            FOR C_ORD_LINE_REC IN (
              SELECT TMP.INVENTORY_ITEM_ID,
                MAX(CASE WHEN MUC.CONVERSION_RATE IS NOT NULL THEN CEIL(TMP.QUANTITY / MUC.CONVERSION_RATE) * MUC.CONVERSION_RATE ELSE TMP.QUANTITY END) AS ORDER_QTY
              FROM XXHA_AUTOREP_ORDER_LINE_TEMP TMP,
                (SELECT * FROM MTL_UOM_CONVERSIONS WHERE UOM_CODE='Ca') MUC
              WHERE TMP.INVENTORY_ITEM_ID = MUC.INVENTORY_ITEM_ID (+)
              GROUP BY TMP.INVENTORY_ITEM_ID
            )
            LOOP
              --Increment the order line number counter
              V_LINE_NUMBER := V_LINE_NUMBER + 1;
  
              --Get the next line ID from the sequence
              SELECT HAEMO.XXHA_AUTOREP_ORD_LIN_ID.nextval
              INTO V_LINE_ID
              FROM DUAL;
            
              --Create a new order line
              INSERT INTO XXHA_AUTOREP_ORDER_LINE
              VALUES (V_LINE_ID,
                  V_ORDER_ID,
                  V_LINE_NUMBER,
                  C_ORD_LINE_REC.INVENTORY_ITEM_ID,
                  C_ORD_LINE_REC.ORDER_QTY,
                  'Ea');
              
            END LOOP;
            
            --Empty the order line temporary table
            DELETE FROM XXHA_AUTOREP_ORDER_LINE_TEMP;
            
            --Create the order header record
            INSERT INTO XXHA_AUTOREP_ORDER_HEADER
            VALUES (V_ORDER_ID,
              V_THIS_RUN_DATE,
              P_CUSTOMER_ID,
              C_ORD_HDR_REC.SITE_ID,
              C_ORD_HDR_REC.BLANKET_PO_NUMBER,
              'CREATED',
              NULL);
              
          END IF;
          
        ELSE
          retcode := 2;
          IF C_ORD_HDR_REC.BLANKET_PO_NUMBER IS NULL THEN
            errbuf := 'No Blanket PO found for Site ' || C_ORD_HDR_REC.PARTY_SITE_NUMBER || '. ';
          ELSE
            errbuf := '';
          END IF;
          IF C_ORD_HDR_REC.BILL_TO_SITE_USE_ID IS NULL THEN
            errbuf := errbuf || 'No Bill To Location found for Site ' || C_ORD_HDR_REC.PARTY_SITE_NUMBER || '.';
          END IF;
          ROLLBACK;
          EXIT;
        END IF;
			END LOOP;
      
      COMMIT;

			--Update the last run date for the customer to the current date
			UPDATE XXHA_AUTOREP_CUSTOMERS
			SET LAST_RUN_DATE = V_THIS_RUN_DATE
			WHERE CUSTOMER_ID = P_CUSTOMER_ID;
			
		ELSE -- either customer is not enabled or last run date is within the safety margin
			retcode := 1; -- exit with a warning
			IF V_ENABLED <> 'Y' THEN
				errbuf := 'Customer not enabled for AutoReplenishment.';
--				FND_FILE.PUT_LINE(FND_FILE.LOG,errbuf);
--				FND_FILE.PUT_LINE(FND_FILE.OUTPUT,errbuf);
			ELSE
				errbuf := 'Last run at ' || TO_CHAR(V_LAST_RUN_DATE,'DD-MON-YY HH24:MI:SS') || ' is within safety margin of ' || P_SAFETY_MARGIN || ' days.  No orders generated.';
--				FND_FILE.PUT_LINE(FND_FILE.LOG,errbuf);
--				FND_FILE.PUT_LINE(FND_FILE.OUTPUT,errbuf);
			END IF;
			
		END IF;
	ELSE -- customer not found in AutoReplenishment Customer table
		retcode := 1; -- exit with a warning
		errbuf := 'Customer not found in AutoReplenishment Customer table.';
--		FND_FILE.PUT_LINE(FND_FILE.LOG,errbuf);
--		FND_FILE.PUT_LINE(FND_FILE.OUTPUT,errbuf);
	END IF;
	
EXCEPTION
	when others then
--		FND_FILE.PUT_LINE(FND_FILE.LOG,'Unhandled Error: ' || SQLERRM);
		retcode := 2; -- exit with an error
    errbuf := SQLERRM;
	
END generate_orders;

PROCEDURE archive_inventory
			(	errbuf			OUT	VARCHAR2,
				P_CUSTOMER_ID	IN	NUMBER
			) IS
BEGIN
	--Copy customer's inventory records to the inventory archive table
	INSERT INTO XXHA_AUTOREP_INV_ARCHIVE
	SELECT * FROM XXHA_AUTOREP_INVENTORY
	WHERE SITE_ID IN (SELECT SITE_ID FROM XXHA_AUTOREP_SITES WHERE CUSTOMER_ID = P_CUSTOMER_ID);
	
	--Delete customer's inventory records from the inventory table
	DELETE FROM XXHA_AUTOREP_INVENTORY
	WHERE SITE_ID IN (SELECT SITE_ID FROM XXHA_AUTOREP_SITES WHERE CUSTOMER_ID = P_CUSTOMER_ID);
	
EXCEPTION
	when others then
		errbuf := SQLERRM;

END archive_inventory;

END XXHA_AUTOREPLENISHMENT;