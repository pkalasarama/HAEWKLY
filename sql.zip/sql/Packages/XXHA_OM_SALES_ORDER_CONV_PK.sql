CREATE OR REPLACE PACKAGE
       XXHA_OM_SALES_ORDER_CONV_PK AUTHID CURRENT_USER
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |                                                                   |
-- |Name         :XXHA_OM_SALES_ORDER_CONV_PK                          |
-- |                                                                   |
-- |Description  :Package to validate Sales Order Data from Legacy     |
-- |              and insert into Interface Tables                     |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date         Author           Remarks                    |
-- |=======   ==========   =============    ===========================|
-- |DRAFT 1A  03-Nov-2006  Fajna K P        Initial draft version      |
-- |1.0       23-Nov-2006  Fajna K P        After Review               |
-- |                                                                   |
-- +===================================================================+
AS

--Declaring GlobalVariables
gn_record_number         xxha_common_errors.record_number%TYPE;                   --Variable to store Oracle Identifier of the record
gc_record_identifier     xxha_common_errors.record_identifier%TYPE;               --Variable to store Record identifier of the record
gc_error_code            xxha_common_errors.error_code%TYPE;                      --Variable to store Error Code of the record
gc_error_msg             xxha_common_errors.error_msg%TYPE;                       --Variable to store Error Message of the record
gc_comments              xxha_common_errors.comments%TYPE;                        --Variable to store Error Comments of the record
gc_table_name            xxha_common_errors.table_name%TYPE;                      --Variable to store Table Name
gc_attribute1            xxha_common_errors.attribute1%TYPE;                      --Variable to store Attribute1
gc_attribute2            xxha_common_errors.attribute2%TYPE;                      --Variable to store Attribute2
gc_attribute3            xxha_common_errors.attribute3%TYPE;                      --Variable to store Attribute3
gc_attribute4            xxha_common_errors.attribute4%TYPE;                      --Variable to store Attribute4
gc_attribute5            xxha_common_errors.attribute5%TYPE;                      --Variable to store Attribute5
gc_status                VARCHAR2(2);                                             --Variable to store status of data insertion in Common Error table
gc_operating_unit_name   oe_headers_iface_all.sold_from_org%TYPE;                 --Variable to get the Operating unit Name
gc_debug_flag            VARCHAR2(1);                                             --Variable to store the Debug Flag
gc_log_msg               VARCHAR2(3000);                                          --Variable to store the Log Message
gn_request_id            xxha_common_errors.request_id%TYPE                       := FND_GLOBAL.CONC_REQUEST_ID;           -- Variable to store the Concurrent Request Id
gc_record_identify       xxha_common_errors.record_identifier%TYPE                :='Sales Order';                         -- Variable to store the Record identifier of the Program that appears as Column in the Common Error Report
gc_program_name          VARCHAR2(1000)                                           :='Sales Order Conversion';              -- Variable to store the Concurrent Program Name that appears as Heading in the Common Error Report
gc_operating_unit        oe_headers_iface_all.sold_from_org_id%TYPE               := FND_PROFILE.VALUE('ORG_ID');          -- Variable to store the Operating Unit
gn_sob_id                gl_sets_of_books.set_of_books_id%TYPE                    := FND_PROFILE.VALUE('GL_SET_OF_BKS_ID');-- Variable to store the Set Of Books Id
gc_freight_terms_code    oe_lookups.lookup_code%TYPE                              :='TBD';                                 -- Variable to store the default freight terms look up code
gc_freight_terms_type    oe_lookups.lookup_type%TYPE                              :='FREIGHT_TERMS';                       -- Variable to store the freight terms look up type
gc_shipping_method_type  fnd_lookup_values_vl.lookup_type%TYPE                    :='SHIP_METHOD';                         -- Variable to store the default freight terms look up type
gc_payment_terms_code    ra_terms_vl.name%TYPE                                    :='IMMEDIATE';                           -- Variable to store the default payment terms code if given values are invalid
gc_operation_code        oe_headers_iface_all.operation_code%TYPE                 :='CREATE';                              -- Variable to store the default Operation Code
gc_order_category        oe_headers_iface_all.order_category%TYPE                 :='ORDER';                               -- Variable to store the default Order Category
gc_conversion_type       gl_daily_rates.conversion_type%type                      :='Corporate';                           -- Variable to store the default Conversion type
gc_con_prg_shot_name     fnd_concurrent_programs.concurrent_program_name%TYPE     :='XXHA_SALES_ORDER_CONV';               -- Variable to store the Concurrent Program Short Name
gn_user_id               fnd_user.user_id%TYPE                                    := FND_GLOBAL.USER_ID;                   -- Variable to store the User Id
gc_tax_code              oe_lines_iface_all.tax_code%TYPE                         :='Location';                            -- Variable to store the default Tax Code for Lines

--Procedure to validate Sales Order Records
PROCEDURE validate_sales_orders (x_errbuf        OUT VARCHAR2
                                ,x_retcode       OUT VARCHAR2
                                ,p_debug         IN  VARCHAR2
                                ,p_purge_data    IN  VARCHAR2
                                );

END XXHA_OM_SALES_ORDER_CONV_PK;

/


CREATE OR REPLACE PACKAGE BODY
   XXHA_OM_SALES_ORDER_CONV_PK
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |                                                                   |
-- |Name         :XXHA_OM_SALES_ORDER_CONV_PK                          |
-- |                                                                   |
-- |Description  :Package to validate Sales Order Data from Legacy     |
-- |              and insert into Interface Tables                     |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  03-Nov-2006 Fajna K P        Initial draft version       |
-- |1.0       23-Nov-2006 Fajna K P        After Review                |
-- |1.1       13-Feb-2007 subbu            Modified Err msg                                                            |
-- +===================================================================+
AS

-- +===================================================================+
-- | Name        :  UPDATE_RECORD_STATUS                               |
-- | Description :  Procedure to update  the status of processd        |
-- |                records                                            |
-- |                                                                   |
-- | Call From   :  The Procedure is called from PROCESS_SALES_ORDERS  |
-- |                Procedure                                          |
-- | Parameters  :                                                     |
-- |  IN         :  p_status_flag                                      |
-- |                p_record_id                                        |
-- |                p_request_id                                       |
-- |                p_table_no                                         |
-- | Returns     :  NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE UPDATE_RECORD_STATUS(
                               p_status_flag  IN      VARCHAR2
                              ,p_record_id    IN      NUMBER
                              ,p_request_id   IN      NUMBER
                              ,p_table_no     IN      VARCHAR2
                              )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   IF (p_table_no='1') THEN
      UPDATE  usbpcs_orderheader_cleaned UOC
      SET     UOC.oraclecharfld1   =   p_status_flag
             ,UOC.oracleintfld8    =   p_request_id
      WHERE   UOC.oracleidentifier =   p_record_id;
   ELSIF (p_table_no='2') THEN
      UPDATE  usbpcs_orderline_cleaned UOC
      SET     UOC.oraclecharfld1   =   p_status_flag
             ,UOC.oracleintfld8    =   p_request_id
      WHERE   UOC.oracleidentifier =   p_record_id;
   END IF;

   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_OM_SALES_ORDER_CONV_PK.UPDATE_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_RECORD_STATUS;

-- +========================================================================+
-- | Name       :   INSERT_ERROR_MSG                                        |
-- | Description:   Procedure to call xxsc_common_utilities                 |
-- |                to insert errors into error table                       |
-- |                records                                                 |
-- |                                                                        |
-- | Call From  :   The Procedure is called from CHK_SALES_ORDER_SETUP      |
-- |                Function, PROCESS_SALES_ORDERS and VALIDATE_SALES_ORDERS|
-- |                Procedures                                              |
-- | Parameters :   NONE                                                    |
-- | Returns    :   NONE                                                    |
-- |                                                                        |
-- |                                                                        |
-- +========================================================================+
PROCEDURE INSERT_ERROR_MSG
IS
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gn_request_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                            );
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in xxha_common_utilities_pkg.INSERT_ERROR_MSG. Error is: ' ||SQLERRM);
END INSERT_ERROR_MSG;

-- +===================================================================+
-- | Name       :   CHK_SALES_ORDER_SETUP                              |
-- | Description:   Function to check setup`s for sales order          |
-- |                                                                   |
-- | Call From  :   The Function is called from  VALIDATE_SALES_ORDERS |
-- |                Procedure                                          |
-- | Parameters :   NONE                                               |
-- | Returns    :   Returns Y/N                                        |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
FUNCTION CHK_SALES_ORDER_SETUP RETURN VARCHAR2
IS
lc_currency_code                    gl_sets_of_books.currency_code%TYPE;   --Variable to store the Currency Code for Operating Unit
lc_setup_op_unit_err_flag           VARCHAR2(1):='N';                      --Variable to store the status of Set up check for Operating Unit
lc_setup_freightterms_err_flag      VARCHAR2(1):='N';                      --Variable to store the status of Set up check for Freight terms Code
lc_setup_convtype_err_flag          VARCHAR2(1):='N';                      --Variable to store the status of Set up check for Conversion Type
lc_setup_currcode_err_flag          VARCHAR2(1):='N';                      --Variable to store the status of Set up check for Currency Code for Operating Unit
lc_setup_taxcode_err_flag           VARCHAR2(1):='N';                      --Variable to store the status of Set up check for Tax Code


--------------------------------------------------------
--Cursor to check if the Operating Unit has been defined
--------------------------------------------------------
CURSOR  lcu_chk_operating_unit(p_operating_unit NUMBER)
IS
SELECT  HOU.name
FROM    hr_operating_units HOU
WHERE   SYSDATE BETWEEN NVL(HOU.date_from,SYSDATE) AND NVL(HOU.date_to,SYSDATE+1)
AND     organization_id = p_operating_unit;

------------------------------------------------------------------------------
--Cursor to check if the Currency Code for the Operating Unit has been defined
------------------------------------------------------------------------------
CURSOR  lcu_get_currency_code(p_sob_id VARCHAR2)
IS
SELECT  GSOB.currency_code
FROM    gl_sets_of_books GSOB
WHERE   GSOB.set_of_books_id = p_sob_id;

--------------------------------------------------------
--Cursor to check if freight terms code has been defined
--------------------------------------------------------
CURSOR  lcu_chk_freight_terms_code(p_freight_terms_code VARCHAR2)
IS
SELECT 'N'
FROM    oe_lookups OL
WHERE   SYSDATE BETWEEN NVL(OL.start_date_active,SYSDATE) AND NVL(OL.end_date_active,SYSDATE+1)
AND     OL.enabled_flag ='Y'
AND     OL.lookup_code  = p_freight_terms_code
AND     OL.lookup_type  = gc_freight_terms_type;

--------------------------------------------------------
--Cursor to check if Conversion Type has been defined
--------------------------------------------------------
CURSOR  lcu_chk_conversion_type(p_conversion_type VARCHAR2)
IS
SELECT 'N'
FROM    gl_daily_conversion_types GDCT
WHERE   GDCT.conversion_type  = p_conversion_type;

----------------------------------------------
--Cursor to check if Tax Code has been defined
----------------------------------------------
CURSOR  lcu_chk_tax_code(p_tax_code VARCHAR2)
IS
SELECT 'N'
FROM    ar_vat_tax_all AVTA
WHERE   SYSDATE BETWEEN NVL(AVTA.START_DATE,SYSDATE) AND NVL(AVTA.END_DATE,SYSDATE+1)
AND     AVTA.enabled_flag ='Y'
AND     AVTA.tax_code  = p_tax_code;


BEGIN
   ------------------------------------
   --Check if Operating Unit is defined
   ------------------------------------
   gc_log_msg:='Operating unit: '||gc_operating_unit;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   gc_table_name                                  :='USBPCS_ORDERHEADER_CLEANED';

   OPEN  lcu_chk_operating_unit(gc_operating_unit);
   FETCH lcu_chk_operating_unit INTO gc_operating_unit_name;
     IF (lcu_chk_operating_unit%NOTFOUND) THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='Operating Unit: '||gc_operating_unit_name||' is Invalid';
        gc_comments   :='Please define the Operating Unit';
        INSERT_ERROR_MSG;
        lc_setup_op_unit_err_flag:='Y';
     END IF; --lcu_chk_operating_unit%NOTFOUND
   CLOSE lcu_chk_operating_unit;

   gc_log_msg:='Flag returned by the Operating Unit Cursor is: '||lc_setup_op_unit_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ----------------------------------------------------------
   --Check if Currency Code for the Operating Unit is defined
   ----------------------------------------------------------
   lc_currency_code:=NULL;
   gc_log_msg:='Set of Books Id: '||gn_sob_id;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   OPEN  lcu_get_currency_code(gn_sob_id);
   FETCH lcu_get_currency_code INTO lc_currency_code;
     IF (lcu_get_currency_code%NOTFOUND) THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='Set of Books/Currency Code for the Operating Unit: '||gc_operating_unit_name||' has not been defined';
        gc_comments   :='Please define the Set of Books/Currency Code';
        INSERT_ERROR_MSG;
        lc_setup_currcode_err_flag:='Y';
     END IF; --lcu_get_currency_code%NOTFOUND
   CLOSE lcu_get_currency_code;

   gc_log_msg:='Flag returned by the Currency Code Cursor is: '||lc_setup_currcode_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ----------------------------------------
   --Check if Freight Terms Code is defined
   ----------------------------------------
   OPEN  lcu_chk_freight_terms_code(gc_freight_terms_code);
   FETCH lcu_chk_freight_terms_code INTO lc_setup_freightterms_err_flag;
     IF (lcu_chk_freight_terms_code%NOTFOUND) THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='FREIGHT TERMS CODE: '||gc_freight_terms_code||' is Invalid';
        gc_comments   :='Please define the value in the FREIGHT_TERMS Lookup';
        INSERT_ERROR_MSG;
        lc_setup_freightterms_err_flag:='Y';
     END IF; --lcu_chk_freight_terms_code%NOTFOUND
   CLOSE lcu_chk_freight_terms_code;

   gc_log_msg:='Flag returned by the Freight_terms_code Cursor is: '||lc_setup_freightterms_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   -------------------------------------
   --Check if Conversion type is defined
   -------------------------------------
   OPEN  lcu_chk_conversion_type(gc_conversion_type);
   FETCH lcu_chk_conversion_type INTO lc_setup_convtype_err_flag;
     IF (lcu_chk_conversion_type%NOTFOUND) THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='CONVERSION TYPE: '||gc_conversion_type||' is Invalid';
        gc_comments   :='Please define the Conversion Type';
        INSERT_ERROR_MSG;
        lc_setup_convtype_err_flag:='Y';
     END IF; --lcu_chk_conversion_type%NOTFOUND
   CLOSE lcu_chk_conversion_type;

   gc_log_msg:='Flag returned by the Conversion_type Cursor is: '||lc_setup_convtype_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ------------------------------
   --Check if Tax code is defined
   ------------------------------
   OPEN  lcu_chk_tax_code(gc_tax_code);
   FETCH lcu_chk_tax_code INTO lc_setup_taxcode_err_flag;
     IF (lcu_chk_tax_code%NOTFOUND) THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='TAX CODE: '||gc_tax_code||' is Invalid';
        gc_comments   :='Please define the TAX CODE';
        INSERT_ERROR_MSG;
        lc_setup_taxcode_err_flag:='Y';
     END IF;--lcu_chk_tax_code%NOTFOUND
   CLOSE lcu_chk_tax_code;

   gc_log_msg:='Flag returned by the Tax Code Cursor is: '||lc_setup_taxcode_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


   ----------------------------------------------------------------
   --If any of the above setup`s are missing, error out the program
   ----------------------------------------------------------------
   IF (lc_setup_op_unit_err_flag ='Y' OR lc_setup_currcode_err_flag='Y' OR lc_setup_freightterms_err_flag='Y' OR lc_setup_convtype_err_flag='Y' OR lc_setup_taxcode_err_flag='Y') THEN
      RETURN 'N';
   ELSE
      RETURN 'Y';
   END IF; --End of Checking for Set up Errors

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error encountered while checking Setup in the function CHK_SALES_ORDER_SETUP  '||SQLERRM);
   RAISE;

END CHK_SALES_ORDER_SETUP;

-- +=====================================================================+
-- | Name            : PROCESS_SALES_ORDERS                              |
-- | Description     : Procedure to import the Sales Orders into base    |
-- |                   tables                                            |
-- |                                                                     |
-- | Call From       : The Procedure is called from VALIDATE_SALES_ORDERS|
-- |                   Procedure                                         |
-- | Parameters      :                                                   |
-- |  OUT            : x_retcode                                         |
-- |                                                                     |
-- |                                                                     |
-- | Returns         : x_retcode                                         |
-- |                                                                     |
-- |                                                                     |
-- +=====================================================================+

PROCEDURE PROCESS_SALES_ORDERS (
                               x_retcode  OUT VARCHAR2
                               )
IS
lc_currencycode                gl_sets_of_books.currency_code%TYPE;  --Variable to store the Currency Code for the Operating Unit
ln_header_rec_fetched          NUMBER:=0;                            --Variable to store the total number of header records for the Operating Unit
ln_header_rec_processed        NUMBER:=0;                            --Variable to store the total number of header records processed successfully
ln_header_rec_not_processed    NUMBER:=0;                            --Variable to store the total number of header records that failed processing
ln_line_rec_fetched            NUMBER:=0;                            --Variable to store the total number of line records
ln_line_rec_processed          NUMBER:=0;                            --Variable to store the total number of line records processed successfully
ln_line_rec_not_processed      NUMBER:=0;                            --Variable to store the total number of line records that failed processing
ln_error_count                 NUMBER:=0;                            --Variable to store the total number of error records for the Request Id


------------------------------------------------------------------------------------------------
--Cursor to get all the Sales Order header records from the staging table for the Operating Unit
------------------------------------------------------------------------------------------------
CURSOR   lcu_get_valid_salesorders(p_operating_unit VARCHAR2)
IS
SELECT   *
FROM     usbpcs_orderheader_cleaned UOC
WHERE    UOC.oraclegenuse1 = p_operating_unit
AND      UOC.oraclecharfld1='VS'
ORDER BY UOC.ordernbr;

--------------------------------------------------------
--Cursor to get the Currency Code for the Operating Unit
--------------------------------------------------------
CURSOR   lcu_get_currency_code(p_sob_id VARCHAR2)
IS
SELECT   GSOB.currency_code
FROM     gl_sets_of_books GSOB
WHERE    GSOB.SET_OF_BOOKS_ID = p_sob_id;

-----------------------------------------------------------------------
--Cursor to get all the Sales Order Line records from the staging table
-----------------------------------------------------------------------
CURSOR   lcu_get_valid_salesorder_lines(p_operating_unit VARCHAR2,p_order_number VARCHAR2)
IS
SELECT   *
FROM     usbpcs_orderline_cleaned UOLC
WHERE    UOLC.oraclegenuse1=p_operating_unit
AND      UOLC.ordernbr=p_order_number
ORDER BY UOLC.orderlinenbr;

---------------------------------------------
--Cursor to get total count of Header records
---------------------------------------------
CURSOR   lcu_get_header_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderheader_cleaned UOC
WHERE    UOC.oraclegenuse1=p_operating_unit;

-------------------------------------------
--Cursor to get total count of Line records
-------------------------------------------
CURSOR   lcu_get_line_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderline_cleaned UOLC
WHERE    UOLC.oraclegenuse1=p_operating_unit;

------------------------------------------------------------------------------
--Cursor to get total count of header records which got Processed Successfully
------------------------------------------------------------------------------
CURSOR   lcu_get_header_processed_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderheader_cleaned UOC
WHERE    UOC.oraclecharfld1='PS'
AND      UOC.oraclegenuse1=p_operating_unit;

---------------------------------------------------------------------
--Cursor to get total count of header records which failed Processing
---------------------------------------------------------------------
CURSOR   lcu_get_header_unprocess_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderheader_cleaned UOC
WHERE    UOC.oraclecharfld1='PE'
AND      UOC.oraclegenuse1 =p_operating_unit;

----------------------------------------------------------------------------
--Cursor to get total count of line records which got Processed Successfully
----------------------------------------------------------------------------
CURSOR   lcu_get_line_processed_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderline_cleaned UOLC
WHERE    UOLC.oraclecharfld1='PS'
AND      UOLC.oraclegenuse1 =p_operating_unit;

-------------------------------------------------------------------
--Cursor to get total count of line records which failed Processing
-------------------------------------------------------------------
CURSOR   lcu_get_line_unprocessed_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderline_cleaned UOLC
WHERE    UOLC.oraclecharfld1='PE'
AND      UOLC.oraclegenuse1 = p_operating_unit;

----------------------------------------------
--Cursor to get total count of Errored records
----------------------------------------------
CURSOR  lcu_get_errored_count(p_request_id VARCHAR2)
IS
SELECT  COUNT(*)
FROM    xxha_common_errors XCE
WHERE   XCE.request_id =  p_request_id;


BEGIN
   gc_log_msg:='*************START OF SALES ORDER HEADER PROCESSING*************';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   FOR lr_valid_salesorders IN lcu_get_valid_salesorders(gc_operating_unit_name)
   LOOP
      --Assigning values for Header record number and record identifier
      gn_record_number       := lr_valid_salesorders.oracleidentifier;
      gc_record_identifier   := lr_valid_salesorders.ordernbr;
      lc_currencycode        := NULL;

      --Checking the Currency code for the Operating Unit
      OPEN  lcu_get_currency_code(gn_sob_id);
      FETCH lcu_get_currency_code INTO lc_currencycode;
      CLOSE lcu_get_currency_code;

      BEGIN
         --Inserting into OE_HEADERS_IFACE_ALL table
            INSERT INTO OE_HEADERS_IFACE_ALL
                                             (
                                              orig_sys_document_ref
                                             ,order_source_id
                                             ,org_id
                                             ,ordered_date
                                             ,order_type_id
                                             ,conversion_type_code
                                             ,transactional_curr_code
                                             ,tax_exempt_flag
                                             ,payment_term_id
                                             ,shipping_method_code
                                             ,freight_terms_code
                                             ,customer_po_number
                                             ,sold_to_org_id
                                             ,sold_to_org
                                             ,ship_from_org_id
                                             ,ship_to_org_id
                                             ,invoice_to_org_id
                                             ,customer_id
                                             ,booked_flag
                                             ,closed_flag
                                             ,creation_date
                                             ,created_by
                                             ,last_update_date
                                             ,last_updated_by
                                             ,last_update_login
                                             ,request_date
                                             ,operation_code
                                             ,order_category
                                             ,sold_from_org_id
                                             )
                                       VALUES
                                             (
                                              lr_valid_salesorders.ordernbr         --orig_sys_document_ref
                                             ,lr_valid_salesorders.oracleintfld7    --order_source_id
                                             ,gc_operating_unit                     --org_id
                                             ,lr_valid_salesorders.oraclecharfld2   --ordered_date
                                             ,lr_valid_salesorders.oracleintfld5    --order_type_id
                                             ,DECODE(lr_valid_salesorders.currencycode,lc_currencycode,NULL,gc_conversion_type)--If Functional Currency is equal to Transactional Currency,Insert the Conversion Type Code 'Corporate'
                                             ,lr_valid_salesorders.currencycode     --transactional_curr_code
                                             ,'S'                                   --tax_exempt_flag
                                             ,lr_valid_salesorders.oracleintfld2    --payment_term_id
                                             ,lr_valid_salesorders.oraclecharfld4   --shipping_method_code
                                             ,gc_freight_terms_code                 --freight_terms_code
                                             ,lr_valid_salesorders.customerpo       --customer_po_number
                                             ,lr_valid_salesorders.oracleintfld1    --sold_to_org_id
                                             ,NULL
                                             ,lr_valid_salesorders.oracleintfld6    --ship_from_org_id
                                             ,lr_valid_salesorders.oracleintfld3    --ship_to_org_id
                                             ,lr_valid_salesorders.oracleintfld4    --invoice_to_org_id
                                             ,lr_valid_salesorders.oracleintfld1    --customer_id
                                             ,'N'                                   --booked_flag
                                             ,'N'                                   --closed_flag
                                             ,SYSDATE
                                             ,gn_user_id
                                             ,SYSDATE
                                             ,gn_user_id
                                             ,gn_user_id
                                             ,lr_valid_salesorders.oraclecharfld5   --request_date
                                             ,gc_operation_code
                                             ,gc_order_category
                                             ,gc_operating_unit                     --sold_from_org_id
                                             );

         --Updating Headers staging table  with status PS if insertion is successful
         UPDATE_RECORD_STATUS('PS',lr_valid_salesorders.oracleidentifier,gn_request_id,'1');

        gc_log_msg:='Updating status of Headers staging table to PS for the Order number: '||lr_valid_salesorders.ordernbr;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      EXCEPTION
      WHEN OTHERS THEN
         gc_error_code       :='SO23';
         gc_error_msg        :='Procedure PROCESS_SALES_ORDERS has processing Errors in the Header Part due to error '||SQLERRM;
         gc_comments         := NULL;
         INSERT_ERROR_MSG;

         --Updating Headers staging table  with status PE in case of Processing Errors
         UPDATE_RECORD_STATUS('PE',lr_valid_salesorders.oracleidentifier,gn_request_id,'1');

         gc_log_msg:='Updating status of Headers staging table to PE for the Order number: '||lr_valid_salesorders.ordernbr;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         --x_retcode:=2;
         --RETURN;
      END;

         FOR  lr_valid_salesorder_lines IN lcu_get_valid_salesorder_lines(gc_operating_unit_name,lr_valid_salesorders.ordernbr)
         LOOP
            --Assigning values for Line record number and record identifier
            gn_record_number       := lr_valid_salesorder_lines.oracleidentifier;
            gc_record_identifier   := lr_valid_salesorders.ordernbr||' Line :'||lr_valid_salesorder_lines.orderlinenbr;

            gc_log_msg:='***START OF SALES ORDER LINE PROCESSING*** for Order: '||lr_valid_salesorders.ordernbr||' and Line Number: '||lr_valid_salesorder_lines.orderlinenbr;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            BEGIN
               INSERT INTO OE_LINES_IFACE_ALL
                                          (order_source_id
                                          ,orig_sys_document_ref
                                          ,orig_sys_line_ref
                                          ,inventory_item_id
                                        --,schedule_ship_date
                                        --,schedule_date
                                          ,ordered_quantity
                                          ,order_quantity_uom
                                        --,shipped_quantity
                                        --,fulfilled_quantity
                                          ,ship_from_org_id
                                          ,ship_to_org_id
                                          ,invoice_to_org_id
                                          ,unit_list_price
                                         ,unit_selling_price
                                          ,calculate_price_flag
                                          ,tax_code
                                          ,tax_exempt_flag
                                          ,customer_po_number
                                          ,customer_line_number
                                          ,closed_flag
                                          ,attribute1
                                          ,created_by
                                          ,creation_date
                                          ,last_update_date
                                          ,last_updated_by
                                          ,last_update_login
                                          ,operation_code
                                          ,request_date
                                          ,sold_from_org_id
                                          ,ship_to_customer_id
                                          ,invoice_to_customer_id
                                          ,deliver_to_customer_id
                                         )
                                         VALUES
                                         (
                                           lr_valid_salesorders.oracleintfld7
                                          ,lr_valid_salesorders.ordernbr
                                          ,lr_valid_salesorder_lines.orderlinenbr
                                          ,lr_valid_salesorder_lines.oracleintfld1
                                        --,lr_valid_salesorder_lines.oraclecharfld2    --schedule_ship_date
                                        --,lr_valid_salesorder_lines.oraclecharfld3    --schedule_date
                                          ,(NVL(lr_valid_salesorder_lines.qtyordered,0)-NVL(lr_valid_salesorder_lines.qtyshipped,0))
                                          ,lr_valid_salesorder_lines.uom
                                          --,lr_valid_salesorder_lines.qtyshipped
                                          --,lr_valid_salesorder_lines.qtyallocated
                                          ,lr_valid_salesorders.oracleintfld6          --warehouse id
                                          ,lr_valid_salesorders.oracleintfld3          --site use id
                                          ,lr_valid_salesorders.oracleintfld4          --bill to site use id
                                         ,lr_valid_salesorder_lines.listprice
                                        ,lr_valid_salesorder_lines.netsellingprice
                                          ,'N'     -- 'Y'                                         --calculate_price_flag
                                          ,gc_tax_code
                                          ,'S'
                                          ,lr_valid_salesorder_lines.purchaseordernbr
                                          ,lr_valid_salesorder_lines.purchaseorderlinenbr
                                          ,'N'
                                          ,lr_valid_salesorder_lines.contract
                                          ,gn_user_id
                                          ,SYSDATE
                                          ,SYSDATE
                                          ,gn_user_id
                                          ,gn_user_id
                                          ,gc_operation_code
                                          ,lr_valid_salesorder_lines.oraclecharfld4    --request_date
                                          ,lr_valid_salesorders.oraclecharfld3
                                          ,lr_valid_salesorders.oracleintfld1
                                          ,lr_valid_salesorders.oracleintfld1
                                          ,lr_valid_salesorders.oracleintfld1
                                          );


               --Updating lines staging table  with status PS if insertion was successful
               UPDATE_RECORD_STATUS('PS',lr_valid_salesorder_lines.oracleidentifier,gn_request_id,'2');

               gc_log_msg:='Updating status of lines staging table to PS for the Order number: '||lr_valid_salesorders.ordernbr ||' and Line Number: ' ||lr_valid_salesorder_lines.orderlinenbr;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            EXCEPTION
               WHEN OTHERS THEN
                  gc_error_code       :='SO24';
                  gc_error_msg        :='Procedure PROCESS_SALES_ORDERS has processing Errors in the Line Part due to error '||SQLERRM;
                  gc_comments         := NULL;
                  INSERT_ERROR_MSG;

                  --Updating lines staging table  with status PE in case of Processing Errors
                  UPDATE_RECORD_STATUS('PE',lr_valid_salesorder_lines.oracleidentifier,gn_request_id,'2');

                  gc_log_msg:='Updating status of lines staging table to PE for the Order number: '||lr_valid_salesorders.ordernbr ||' and Line Number: ' ||lr_valid_salesorder_lines.orderlinenbr;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                  --x_retcode:=2;
                  --RETURN;
            END;
         END LOOP; --End Loop for Lines

   END LOOP;--End Loop for Headers

   --Get the total no of Header records
   OPEN  lcu_get_header_count(gc_operating_unit_name);
   FETCH lcu_get_header_count INTO ln_header_rec_fetched;
   CLOSE lcu_get_header_count;

   --Get total no of Header records Processed successfully
   OPEN lcu_get_header_processed_count(gc_operating_unit_name);
   FETCH lcu_get_header_processed_count INTO ln_header_rec_processed;
   CLOSE lcu_get_header_processed_count;

   --Get total no of Header records failed Processing
   OPEN lcu_get_header_unprocess_count(gc_operating_unit_name);
   FETCH lcu_get_header_unprocess_count INTO ln_header_rec_not_processed;
   CLOSE lcu_get_header_unprocess_count;

   --Get the tonal no of Line records
   OPEN  lcu_get_line_count(gc_operating_unit_name);
   FETCH lcu_get_line_count INTO ln_line_rec_fetched;
   CLOSE lcu_get_line_count;

   --Get total no of Line records Processed successfully
   OPEN lcu_get_line_processed_count(gc_operating_unit_name);
   FETCH lcu_get_line_processed_count INTO ln_line_rec_processed;
   CLOSE lcu_get_line_processed_count;

   --Get total no of Line records failed Processing
   OPEN lcu_get_line_unprocessed_count(gc_operating_unit_name);
   FETCH lcu_get_line_unprocessed_count INTO ln_line_rec_not_processed;
   CLOSE lcu_get_line_unprocessed_count;


   --Summary information of Header Records Processed
   --========================================
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Summary information of USBPCS_ORDERHEADER_CLEANED Records Processed ');
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Total Records                                        :    ' ||ln_header_rec_fetched);
   fnd_file.put_line(fnd_file.LOG,'Total Records Processed to Interface Tables          :    ' ||ln_header_rec_processed );
   fnd_file.put_line(fnd_file.LOG,'Total Records failed to process to Interface Tables  :    ' ||ln_header_rec_not_processed);

   --Summary information of Line Records Processed
   --========================================
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Summary information of USBPCS_ORDERLINE_CLEANED Records Processed ');
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Total Records                                        :    ' ||ln_line_rec_fetched);
   fnd_file.put_line(fnd_file.LOG,'Total Records Processed to Interface Tables          :    ' ||ln_line_rec_processed );
   fnd_file.put_line(fnd_file.LOG,'Total Records failed to process to Interface Tables  :    ' ||ln_line_rec_not_processed);

   ---------------------------------------------------------------
   -- This is to display the status of the records in the log file
   ---------------------------------------------------------------
   OPEN lcu_get_errored_count(gn_request_id);
   FETCH lcu_get_errored_count INTO ln_error_count;
   CLOSE lcu_get_errored_count;


   IF (ln_error_count =0) THEN
      COMMIT;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*******************************************');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'All the Records Are Processed and Committed');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*******************************************');
   ELSE
      ROLLBACK;
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*********************************************');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'All the Records Are Processed and Rolled Back');
      FND_FILE.PUT_LINE(FND_FILE.LOG,'*********************************************');
      --xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_record_identify);
      x_retcode:=1;
   END IF; --ln_error_count =0
EXCEPTION
WHEN OTHERS THEN
   ROLLBACK;
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_OM_SALES_ORDER_CONV_PK.PROCESS_SALES_ORDERS: ' || SQLERRM);
   --xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_record_identify);
   INSERT_ERROR_MSG;
   x_retcode:=2;
END PROCESS_SALES_ORDERS;

-- +===================================================================+
-- | Name          : VALIDATE_SALES_ORDERS                             |
-- | Description   : Procedure to validate the sales order records     |
-- | Call From     : This procedure is registered as Concurrent        |
-- |                 Program Executable file name                      |
-- |                                                                   |
-- | Parameters    :                                                   |
-- |  OUT          : x_errbuf                                          |
-- |                 x_retcode                                         |
-- |  IN           : p_debug                                           |
-- |                 p_purge_data                                      |
-- |                                                                   |
-- | Returns       : x_errbuf                                          |
-- |                 x_retcode                                         |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE VALIDATE_SALES_ORDERS (
                                 x_errbuf       OUT VARCHAR2
                                ,x_retcode      OUT VARCHAR2
                                ,p_debug         IN VARCHAR2
                                ,p_purge_data    IN VARCHAR2
                                )
IS
--Declaring Set Up Error Flags
lc_setup_error_flag              VARCHAR2(1):='N';    --Variable to store the status of Set up error
lc_setup_exist                   VARCHAR2(1):='N';    --Variable to store the status of Set up exists
lc_retcode                       VARCHAR2(1):= NULL;  --Variable to store the status of Concurrent Program
--Declaring Header Error Flags
lc_header_origsys_err_flag       VARCHAR2(1):='N';    --Variable to store the status of Order Header Document Reference Validation
lc_header_ordernbr_err_flag      VARCHAR2(1):='N';    --Variable to store the status of Order Header Number Validation
lc_header_ent_date_err_flag      VARCHAR2(1):='N';    --Variable to store the status of Order Header Entered Date Validation
lc_header_req_date_err_flag      VARCHAR2(1):='N';    --Variable to store the status of Order Header Request Date Validation
lc_header_date_err_flag          VARCHAR2(1):='N';    --Variable to store the status of Order Header Date Validation
lc_header_terms_code_err_flag    VARCHAR2(1):='N';    --Variable to store the status of Order Header Terms Code Validation
lc_header_ship_via_err_flag      VARCHAR2(1):='N';    --Variable to store the status of Order Header Ship Via Validation
lc_header_ship_number_err_flag   VARCHAR2(1):='N';    --Variable to store the status of Order Header Ship To Number Validation
lc_header_ordertype_err_flag     VARCHAR2(1):='N';    --Variable to store the status of Order Header Order Type Validation
lc_header_warehouse_err_flag     VARCHAR2(1):='N';    --Variable to store the status of Order Header Warehouse Validation
lc_header_currency_err_flag      VARCHAR2(1):='N';    --Variable to store the status of Order Header Currency Validation
lc_header_ordersource_err_flag   VARCHAR2(1):='N';    --Variable to store the status of Order Header Order Source Validation
lc_header_error_flag             VARCHAR2(1):='N';    --Variable to store the status of Order Header Error
lc_mast_err_flag                 VARCHAR2(1):='N';    --Variable to store the status if Any Header is errored out
--Declaring Line Error Flags
lc_line_nbr_err_flag             VARCHAR2(1):='N';    --Variable to store the status of Order Line Number Validation
lc_line_item_err_flag            VARCHAR2(1):='N';    --Variable to store the status of Order Line Item Number Validation
lc_line_uom_err_flag             VARCHAR2(1):='N';    --Variable to store the status of Order Line UOM Validation
lc_line_qty_err_flag             VARCHAR2(1):='N';    --Variable to store the status of Order Line Quantity
lc_line_ship_date_err_flag       VARCHAR2(1):='N';    --Variable to store the status of Order Line Ship Date Validation
lc_line_rcv_date_err_flag        VARCHAR2(1):='N';    --Variable to store the status of Order Line Rcv Date Validation
lc_line_request_date_err_flag    VARCHAR2(1):='N';    --Variable to store the status of Order Line Request Date Validation
lc_line_date_err_flag            VARCHAR2(1):='N';    --Variable to store the status of Order Line Date Validation
lc_selprice_err_flag             VARCHAR2(1):='N';    --Variable to store the status of Order Line Selling Price Validation
lc_listprice_err_flag            VARCHAR2(1):='N';    --Variable to store the status of Order Line List Price Validation
lc_line_error_flag               VARCHAR2(1):='N';    --Variable to store the status of Order Line Error
--Declaring Value holding Variables
lc_default_termscode             oe_headers_iface_all.payment_term%TYPE;         --Variable to store the Terms Code
lc_shipping_method_code          oe_headers_iface_all.shipping_method_code%TYPE; --Variable to store the Shipping_method_code
ln_order_source_id               oe_headers_iface_all.order_source_id%TYPE;      --Variable to store the Order_source_id
ln_terms_id                      oe_headers_iface_all.payment_term_id%TYPE;      --Variable to store the Payment_term_id
ln_cust_account_id               oe_headers_iface_all.customer_id%TYPE;          --Variable to store the Customer_id
ln_site_use_id                   oe_headers_iface_all.ship_to_org_id%TYPE;       --Variable to store the Ship_to_org_id
ln_bill_to_site_use_id           oe_headers_iface_all.invoice_to_org_id%TYPE;    --Variable to store the Invoice_to_org_id
ln_order_type_id                 oe_headers_iface_all.order_type_id%TYPE;        --Variable to store the Order_type_id
ln_warehouse_id                  oe_headers_iface_all.ship_from_org_id%TYPE;     --Variable to store the Ship_from_org_id
ln_inventory_item_id             oe_lines_iface_all.inventory_item_id%TYPE;      --Variable to store the Inventory_item_id
lc_primary_uom                   oe_lines_iface_all.order_quantity_uom%TYPE;     --Variable to store the Primary UOM Code
lc_actual_uom                    mtl_units_of_measure.uom_code%TYPE;             --Variable to store the Actual UOM Code
lc_uom                           oe_lines_iface_all.order_quantity_uom%TYPE;     --Variable to store the Order_quantity_uom
ld_header_entered_date           oe_headers_iface_all.ordered_date%TYPE;         --Variable to store the Ordered_date
ld_header_request_date           oe_headers_iface_all.request_date%TYPE;         --Variable to store the Request_date
ld_line_SchedShip_date           oe_lines_iface_all.schedule_ship_date%TYPE;     --Variable to store the Schedule_ship_date
ld_line_schedrcv_date            oe_lines_iface_all.schedule_date%TYPE;          --Variable to store the Schedule_date
ld_line_request_date             oe_lines_iface_all.request_date%TYPE;           --Variable to store the Request_date
--Declaring the Count Variables
ln_header_rec_fetched            NUMBER:=0;                                      --Variable to store the Header Records Validated
ln_header_rec_validated          NUMBER:=0;                                      --Variable to store the Header Records Passed Validation
ln_header_rec_invalid            NUMBER:=0;                                      --Variable to store the Header Records Failed Validation
ln_line_rec_fetched              NUMBER:=0;                                      --Variable to store the Line Records Validated
ln_line_rec_validated            NUMBER:=0;                                      --Variable to store the Line Records Passed Validation
ln_line_rec_invalid              NUMBER:=0;                                      --Variable to store the Line Records Failed Validation

-----------------------------------------------------------------------------------------
--Cursor to get all the Sales orders from the Header Staging Table for the Operating Unit
-----------------------------------------------------------------------------------------
CURSOR   lcu_get_order_headers(p_operating_unit_name VARCHAR2)
IS
SELECT   *
FROM     usbpcs_orderheader_cleaned UOC
WHERE    UOC.oraclegenuse1=p_operating_unit_name
AND      UOC.oraclecharfld1 IS NULL
ORDER BY ordernbr;

----------------------------------------------------------------------
--Cursor to get all the Sales Order Lines from the Lines Staging Table
----------------------------------------------------------------------
CURSOR   lcu_get_order_lines (p_operating_unit_name VARCHAR2,p_order_number VARCHAR2)
IS
SELECT   *
FROM     usbpcs_orderline_cleaned UOLC
WHERE    UOLC.oraclegenuse1=p_operating_unit_name
AND      UOLC.ordernbr=p_order_number
AND      UOLC.oraclecharfld1 IS NULL
ORDER BY orderlinenbr;

---------------------------------------------------------------------
--Cursor to check if the Orig System Document Rference already exists
---------------------------------------------------------------------
CURSOR   lcu_chk_order_doc_ref(p_order_number VARCHAR2)
IS
SELECT   'N'
FROM     oe_order_headers_all OOHA
WHERE    OOHA.flow_status_code<>'CANCELLED'
AND      OOHA.orig_sys_document_ref=p_order_number;

-----------------------------------------------
--Cursor to check if the Order Number is Unique
-----------------------------------------------
CURSOR   lcu_chk_order_number(p_order_number VARCHAR2)
IS
SELECT   'N'
FROM     usbpcs_orderheader_cleaned UOC
WHERE    UOC.ordernbr = p_order_number
AND      UOC.oraclecharfld1 ='VS';

--------------------------------------------
--Cursor to check if the Terms Code is Valid
--------------------------------------------
CURSOR   lcu_chk_bpcsterms_code(p_terms_code VARCHAR2)
IS
SELECT   HTC.oracle_term_code
FROM     haemo_terms_code HTC
WHERE    UPPER(HTC.bpcs_term_code_desc)= UPPER(p_terms_code)
AND      ROWNUM=1;

------------------------------------------------
--Cursor to default if the Terms Code is Invalid
------------------------------------------------
CURSOR   lcu_chk_raterms_code(p_terms_code VARCHAR2)
IS
SELECT   RT.term_id
FROM     ra_terms_vl  RT
WHERE    SYSDATE BETWEEN NVL(RT.start_date_active, SYSDATE) AND NVL(RT.end_date_active, SYSDATE)
AND      RT.name = p_terms_code;

------------------------------------------------------
--Cursor to check if the Shipping Method Code is Valid
------------------------------------------------------
CURSOR   lcu_chk_shipping_method_code(p_ship_via VARCHAR2)
IS
SELECT   FLVV.lookup_code
FROM     fnd_lookup_values_vl FLVV
WHERE    enabled_flag='Y'
AND      SYSDATE BETWEEN NVL(FLVV.start_date_active, SYSDATE) AND NVL(FLVV.end_date_active, SYSDATE)
AND      lookup_type= gc_shipping_method_type
AND      UPPER(meaning)= DECODE(TRIM(UPPER(p_ship_via)),'AIR PRIOR','TRAX-AIR','ASAP DGM','TRAX-OVRD','3D','TRAX-3D','EXPEDITOR','TRAX-EXP','UPS','UPS','AM10','TRAX-AM10','FED X','FEDEX','TRAP','TRAX-OVRD','COLLECT','TRAX-OVRD','ON','TRAX-ON','OVRD','TRAX-OVRD','PFS','TRAX-OVRD','PICK UP','TRAX-OVRD','DANZAS','TRAX-OVRD','PANIL','TRAX-OVRD','OCEAN','TRAX-OCEAN','OVR','TRAX-OVRD','GRD','TRAX-GRD','UPS GROUND','UPS-GROUND');

------------------------------------------------------------------------------
--Cursor to check if the Combination of Customer, Ship To and Bill To is Valid
------------------------------------------------------------------------------
CURSOR   lcu_chk_ship_to_number(p_cust_number VARCHAR2,p_ship_to_number VARCHAR2)
IS
SELECT   HCSUA.site_use_id
        ,HCSUA.bill_to_site_use_id
        ,HCASA.cust_account_id
FROM     hz_cust_site_uses_all HCSUA
        ,hz_cust_acct_sites_all HCASA
WHERE    HCSUA.cust_acct_site_id= HCASA.cust_acct_site_id
AND      HCSUA.site_use_code='SHIP_TO'
-- AND      HCSUA.attribute1=p_cust_number||LPAD(TO_CHAR(p_ship_to_number),4,'0'); 22-sep-07
AND      HCSUA.attribute1=p_cust_number;


--------------------------------------------
--Cursor to check if the Order Type is Valid
--------------------------------------------
CURSOR   lcu_chk_order_type(p_order_type VARCHAR2)
IS
SELECT   OTTL.transaction_type_id
FROM     oe_transaction_types_tl OTTL
WHERE    OTTL.name = p_order_type
AND      UPPER(LANGUAGE)='US';

-------------------------------------------
--Cursor to check if the Warehouse is Valid
-------------------------------------------
CURSOR   lcu_chk_warehouse(p_warehouse VARCHAR2)
IS
SELECT   MP.organization_id
FROM     mtl_parameters MP
WHERE    UPPER(MP.organization_code) = UPPER(p_warehouse);

-----------------------------------------------
--Cursor to check if the Currency code is Valid
-----------------------------------------------
CURSOR   lcu_chk_currency(p_currency VARCHAR2)
IS
SELECT   'N'
FROM     fnd_currencies FC
WHERE    SYSDATE BETWEEN NVL(FC.start_date_active, SYSDATE) AND NVL(FC.end_date_active, SYSDATE)
AND      UPPER(FC.currency_code) = UPPER(p_currency)
AND      FC.enabled_flag = 'Y';

----------------------------------------------
--Cursor to check if the Order Source is Valid
----------------------------------------------
CURSOR   lcu_chk_order_source(p_order_source VARCHAR2)
IS
SELECT   OOS.order_source_id
FROM     oe_order_sources OOS
WHERE    OOS.enabled_flag = 'Y'
AND      OOS.name = DECODE(TRIM(p_order_source),'GHX','GHX','CNV','Conversion');

----------------------------------------------------
--Cursor to check if the Order Line Number is unique
----------------------------------------------------
CURSOR   lcu_chk_order_line_number(p_order_number VARCHAR2, p_order_line_number VARCHAR2)
IS
SELECT   'N'
FROM     usbpcs_orderline_cleaned UOLC
WHERE    UOLC.ordernbr     = p_order_number
AND      UOLC.orderlinenbr = p_order_line_number
AND      UOLC.oraclecharfld1 ='VS';

---------------------------------------------------
--Cursor to get INVENTORY_ITEM_ID and UOM for items
---------------------------------------------------
CURSOR   lcu_chk_item(p_ship_from_org_id VARCHAR2,p_item VARCHAR2)
IS
SELECT   MSIB.inventory_item_id
        ,MSIB.primary_uom_code
FROM     mtl_system_items_b MSIB
WHERE    MSIB.organization_id = p_ship_from_org_id
AND      MSIB.segment1        = p_item;

----------------------------------------------
--Cursor to check if the UOM Provided is Valid
----------------------------------------------
CURSOR   lcu_chk_uom(p_uom VARCHAR2)
IS
SELECT   MUOM.uom_code
FROM     mtl_units_of_measure MUOM
WHERE    SYSDATE BETWEEN NVL(MUOM.creation_date, SYSDATE) AND NVL(MUOM.disable_date, SYSDATE)
AND      MUOM.language='US'
AND      UPPER(MUOM.uom_code)=UPPER(p_uom);

---------------------------------------------
--Cursor to get total count of Header records
---------------------------------------------
CURSOR   lcu_get_header_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderheader_cleaned UOC
WHERE    UOC.oraclegenuse1=p_operating_unit;

-------------------------------------------
--Cursor to get total count of Line records
-------------------------------------------
CURSOR   lcu_get_line_count(p_operating_unit VARCHAR2)
IS
SELECT   COUNT(1)
FROM     usbpcs_orderline_cleaned UOLC
WHERE    UOLC.oraclegenuse1=p_operating_unit;

---------------------------------------------------------------------
--Cursor to get total count of header records which passed validation
---------------------------------------------------------------------
CURSOR  lcu_get_header_valid_count(p_operating_unit VARCHAR2)
IS
SELECT  COUNT(1)
FROM    usbpcs_orderheader_cleaned UOC
WHERE   UOC.oraclecharfld1='VS'
AND     UOC.oraclegenuse1=p_operating_unit;

---------------------------------------------------------------------
--Cursor to get total count of header records which failed validation
---------------------------------------------------------------------
CURSOR  lcu_get_header_invalid_count(p_operating_unit VARCHAR2)
IS
SELECT  COUNT(1)
FROM    usbpcs_orderheader_cleaned UOC
WHERE   UOC.oraclecharfld1='VE'
AND     UOC.oraclegenuse1=p_operating_unit;

-------------------------------------------------------------------
--Cursor to get total count of line records which passed validation
-------------------------------------------------------------------
CURSOR  lcu_get_line_valid_count(p_operating_unit VARCHAR2)
IS
SELECT  COUNT(1)
FROM    usbpcs_orderline_cleaned UOLC
WHERE   UOLC.oraclecharfld1='VS'
AND     UOLC.oraclegenuse1=p_operating_unit;

-------------------------------------------------------------------
--Cursor to get total count of line records which failed validation
-------------------------------------------------------------------
CURSOR  lcu_get_line_invalid_count(p_operating_unit VARCHAR2)
IS
SELECT  COUNT(1)
FROM    usbpcs_orderline_cleaned UOLC
WHERE   UOLC.oraclecharfld1='VE'
AND     UOLC.oraclegenuse1=p_operating_unit;

BEGIN
   gc_log_msg:='*************START OF SALES ORDER HEADER VALIDATION*************';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --Assign the debug parameter to the global variable
   gc_debug_flag        :=p_debug;
   --Initialize the record variables
   gn_record_number     :=NULL;
   gc_record_identifier :=NULL;
   gc_table_name        :=NULL;

   ----------------------------------------
   -- Purge the record from the error table
   ----------------------------------------
   IF (NVL(p_purge_data,'N') = 'Y') THEN
      xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>gc_con_prg_shot_name);
   END IF;--end of purging data

   ----------------
   --Validate setup
   ----------------
   --Call the function "CHK_SALES_ORDER_SETUP" to check if Setup`s exist
   lc_setup_exist:=CHK_SALES_ORDER_SETUP;

   gc_log_msg:='Status returned by the Setup function CHK_SALES_ORDER_SETUP :'||lc_setup_exist;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --If setup`s exist then validate the records from the Header and Line Staging tables, else error out the program
   IF (lc_setup_exist='Y') THEN
      FOR lr_order_headers IN lcu_get_order_headers(gc_operating_unit_name)
      LOOP
         --Re Initialize the Header error variables
         lc_header_origsys_err_flag       :='N';
         lc_header_ordernbr_err_flag      :='N';
         lc_header_ent_date_err_flag      :='N';
         lc_header_req_date_err_flag      :='N';
         lc_header_date_err_flag          :='N';
         lc_header_terms_code_err_flag    :='N';
         lc_header_ship_via_err_flag      :='N';
         lc_header_ship_number_err_flag   :='N';
         lc_header_ordertype_err_flag     :='N';
         lc_header_warehouse_err_flag     :='N';
         lc_header_currency_err_flag      :='N';
         lc_header_ordersource_err_flag   :='N';
         gn_record_number                 := lr_order_headers.oracleidentifier;
         gc_record_identifier             := lr_order_headers.ordernbr;
         gc_table_name                    :='USBPCS_ORDERHEADER_CLEANED';
         gc_error_code                    := NULL;
         gc_error_msg                     := NULL;
         gc_comments                      := NULL;

         -------------------------------------------------------------------
         -- Orig System Header Document Reference (Order Number)  Validation
         -------------------------------------------------------------------

         IF (lr_order_headers.ordernbr IS NOT NULL) THEN
            --Check if Header Document Reference already exists in Oracle
            OPEN  lcu_chk_order_doc_ref(lr_order_headers.ordernbr);
            FETCH lcu_chk_order_doc_ref INTO lc_header_origsys_err_flag;
               IF (lcu_chk_order_doc_ref%FOUND) THEN
                  --Log error message
                  gc_error_code       :='SO01';
                  gc_error_msg        :='Sales Order Header Document Reference: '||lr_order_headers.ordernbr||' already exists in Oracle';
                  gc_comments         :='Please use a different Order Header Document Reference';
                  INSERT_ERROR_MSG;
                  lc_header_origsys_err_flag:='Y';
               END IF; --lcu_chk_order_doc_ref%FOUND
            CLOSE lcu_chk_order_doc_ref;

            gc_log_msg:='Flag returned by the Header Document Reference Cursor for Existence is: '||lc_header_origsys_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            --Check if Header Document Reference repeats in the Table
            OPEN lcu_chk_order_number(lr_order_headers.ordernbr);
            FETCH lcu_chk_order_number INTO lc_header_ordernbr_err_flag;
               IF (lcu_chk_order_number%FOUND) THEN
                  --Log error message
                  gc_error_code       :='SO02';
                  gc_error_msg        :='Sales Order Header Document Reference: '||lr_order_headers.ordernbr||' repeats in the Table ';
                  gc_comments         :='Please use unique Order Header Document Reference';
                  INSERT_ERROR_MSG;
                  lc_header_ordernbr_err_flag:='Y';
               END IF;--lcu_chk_order_number%FOUND
            CLOSE lcu_chk_order_number;

            gc_log_msg:='Flag returned by the Header Document Reference Cursor for Uniqueness is: '||lc_header_ordernbr_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ELSE
            -- Log Error if the Header Document Reference is NULL
            gc_error_code       :='SO03';
            gc_error_msg        :='Field '||'Ordernbr'||' is NULL in the staging table';
            gc_comments         :='Please provide the Ordernbr';
            INSERT_ERROR_MSG;
            lc_header_origsys_err_flag:='Y';

            gc_log_msg:='Flag returned by the Header Document Reference Cursor for NULL Value:'||lc_header_origsys_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         END IF; --lr_order_headers.ordernbr IS NOT NULL

         IF (lc_header_origsys_err_flag='Y' OR lc_header_ordernbr_err_flag='Y') THEN
            lc_header_origsys_err_flag:='Y';
         END IF;

         gc_log_msg:='Flag returned by the Header Document Reference Validation Cursor is: '||lc_header_origsys_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------------------------------
         -- Entered Date/Request date Validation
         ---------------------------------------
         -- Check if the dateentered and requestshipdate are given in Proper Format
         ld_header_entered_date           :=NULL;
         ld_header_request_date           :=NULL;

         BEGIN
            IF (lr_order_headers.dateentered IS NOT NULL) THEN
               --Check whether dateentered is in a Valid Format
               BEGIN
                  ld_header_entered_date:=TO_DATE(lr_order_headers.dateentered,'YYYYMMDD');
               EXCEPTION
               WHEN OTHERS THEN
                  gc_error_code       :='SO04';
                  gc_error_msg        :='Value in the filed DATEENTERED cannot be converted to Date format for the Sales Order: '||lr_order_headers.ordernbr;
                  gc_comments         :='Please provide the Entered date in YYYYMMDD format';
                  INSERT_ERROR_MSG;
                  lc_header_ent_date_err_flag:='Y';
               END;
            END IF;

            gc_log_msg:='Flag returned by the Dateentered validation cursor is: '||lc_header_ent_date_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            IF (lr_order_headers.requestshipdate IS NOT NULL) THEN
               --Check whether requestshipdate is in a Valid Format
               BEGIN
                  ld_header_request_date:=TO_DATE(lr_order_headers.requestshipdate,'YYYYMMDD');
               EXCEPTION
               WHEN OTHERS THEN
                  gc_error_code       :='SO05';
                  gc_error_msg        :='Value in the field REQUESTSHIPDATE cannot be converted to Date format for the Sales Order: '||lr_order_headers.ordernbr;
                  gc_comments         :='Please provide the Request Ship Date in YYYYMMDD format';
                  INSERT_ERROR_MSG;
                  lc_header_req_date_err_flag:='Y';
               END;
            END IF; --lr_order_headers.dateentered IS NOT NULL AND lr_order_headers.requestshipdate IS NOT NULL

            gc_log_msg:='Flag returned by the requestshipdate validation cursor is: '||lc_header_req_date_err_flag;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            IF  (lc_header_ent_date_err_flag='Y' OR  lc_header_req_date_err_flag='Y') THEN
               lc_header_date_err_flag:='Y';
            END IF; --end of checking date error for Header

         EXCEPTION
         WHEN OTHERS THEN
            gc_error_code       :='SO06';
            gc_error_msg        :='Unexpected error encountered during date validation for the Order: '||lr_order_headers.ordernbr;
            gc_comments         := SQLERRM||' Please ensure that Entered/Requestdate Fields are having valid date in the format YYYYMMDD ';
            INSERT_ERROR_MSG;
            lc_header_date_err_flag:='Y';
         END ;--main validation

         gc_log_msg:='Flag returned by the Entered/Requestdate Validation is: '||lc_header_date_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -----------------------
         --Terms Code validation
         -----------------------
         --Check if the Terms Code exists in Cross Reference Table.If not defaluting to 'IMMEDIATE'
         ln_terms_id:=NULL;
         lc_default_termscode:=NULL;

         OPEN lcu_chk_bpcsterms_code(lr_order_headers.termscode);
         FETCH lcu_chk_bpcsterms_code INTO lc_default_termscode;
            IF (lcu_chk_bpcsterms_code%NOTFOUND) THEN
               lc_default_termscode:=gc_payment_terms_code; --defaluting to 'IMMEDIATE'
            END IF;
            OPEN lcu_chk_raterms_code(lc_default_termscode);
            FETCH lcu_chk_raterms_code INTO ln_terms_id;
               IF (lcu_chk_raterms_code%NOTFOUND) THEN
                  --Log error message
                  gc_error_code       :='SO07';
                  gc_error_msg        :='Invalid Terms Code: '||lc_default_termscode||' for the Sales Order: '||lr_order_headers.ordernbr;
                  gc_comments         :='Please define this Terms Code ';
                  INSERT_ERROR_MSG;
                  lc_header_terms_code_err_flag:='Y';
               END IF; --lcu_default_terms_code%NOTFOUND
            CLOSE lcu_chk_raterms_code;
         CLOSE lcu_chk_bpcsterms_code;

         gc_log_msg:='Flag returned by the Terms code Validation Cursor is: '||lc_header_terms_code_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------------------------
         --Shipping Method Code validation
         ---------------------------------
         --Check if the Ship Via exists
         lc_shipping_method_code          :=NULL;

         IF (TRIM(lr_order_headers.shipvia) IS NULL) THEN
            lc_shipping_method_code:=NULL;
         ELSE
            OPEN lcu_chk_shipping_method_code(lr_order_headers.shipvia);
            FETCH lcu_chk_shipping_method_code INTO lc_shipping_method_code;
               IF (lcu_chk_shipping_method_code%NOTFOUND) THEN
                  --Log error message
                  gc_error_code       :='SO08';
                  gc_error_msg        :='Look Up Meaning  corresponding to Ship Via: '||lr_order_headers.shipvia||' is Invalid'||' for the Order: '||lr_order_headers.ordernbr;
                  gc_comments         :='Please define the Shipping Method Code';
                  INSERT_ERROR_MSG;
                  lc_header_ship_via_err_flag:='Y';
               END IF; --lcu_chk_shipping_method_code%NOTFOUND
            CLOSE lcu_chk_shipping_method_code;
         END IF; --TRIM(lr_order_headers.shipvia) IS NULL

         gc_log_msg:='Flag returned by the Shipping Method code Validation Cursor is: '||lc_header_ship_via_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------------------------------------------------------------------------------
         --Validation to check whether the Combination of Customer, Ship To and Bill To is Valid
         ---------------------------------------------------------------------------------------
         --Check if the Ship To Number is valid
         ln_site_use_id         :=NULL;
         ln_bill_to_site_use_id :=NULL;
         ln_cust_account_id     :=NULL;

         OPEN lcu_chk_ship_to_number(lr_order_headers.customernbr,lr_order_headers.shiptonumber);
         FETCH lcu_chk_ship_to_number INTO ln_site_use_id,ln_bill_to_site_use_id,ln_cust_account_id;
            IF (lcu_chk_ship_to_number%NOTFOUND) THEN
               --Log error message
               gc_error_code       :='SO09';
               gc_error_msg        :='Customer Site Details cannot be found for the Customer Number: '||
                                      lr_order_headers.customernbr||' for the Order number: '||lr_order_headers.ordernbr;
               gc_comments         := 'Customer number - '||lr_order_headers.customernbr||' not found in attribute1';

--                gc_error_msg        :='Customer Site Details cannot be found for the Customer Number: '||lr_order_headers.customernbr||' and Ship To Number: '||lr_order_headers.shiptonumber||' for the Order number: '||lr_order_headers.ordernbr;
--                gc_comments         :='The Concatenated Value of Customer Number and Customer ship To: '||lr_order_headers.customernbr||LPAD(TO_CHAR(lr_order_headers.shiptonumber),4,'0')||' does not exist in the Attribute1 of the Customer';
               INSERT_ERROR_MSG;
               lc_header_ship_number_err_flag:='Y';
            END IF; --lcu_chk_ship_to_number%NOTFOUND
         CLOSE lcu_chk_ship_to_number;

         gc_log_msg:='Flag returned by the Ship To Number Validation Cursor is: '||lc_header_ship_number_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -----------------------
         --Order Type Validation
         -----------------------
         --Check if the Order Type is valid
         ln_order_type_id:=NULL;
         OPEN lcu_chk_order_type(lr_order_headers.newordertype);
         FETCH lcu_chk_order_type INTO ln_order_type_id;
            IF (lcu_chk_order_type%NOTFOUND) THEN
               --Log error message
               gc_error_code       :='SO10';
               gc_error_msg        :='The Order Type: '||lr_order_headers.newordertype||' does not exist for the Order number: '||lr_order_headers.ordernbr;
               gc_comments         :='Please define the Order Type';
               INSERT_ERROR_MSG;
               lc_header_ordertype_err_flag:='Y';
            END IF; --lcu_chk_order_type%NOTFOUND
         CLOSE lcu_chk_order_type;

         gc_log_msg:='Flag returned by the Order Type Validation Cursor is: '||lc_header_ordertype_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -----------------------
         --Warehouse Validation
         -----------------------
         --Check if the Order Type is valid
         ln_warehouse_id:=NULL;
         IF (TRIM(lr_order_headers.warehouse) IS NOT NULL) THEN
            OPEN lcu_chk_warehouse(lr_order_headers.warehouse);
            FETCH lcu_chk_warehouse INTO ln_warehouse_id;
               IF (lcu_chk_warehouse%NOTFOUND) THEN
                  --Log error message
                  gc_error_code       :='SO11';
                  gc_error_msg        :='The Organization: '||lr_order_headers.warehouse||' does not exist for the Order number: '||lr_order_headers.ordernbr;
                  gc_comments         :='Please define the Organization';
                  INSERT_ERROR_MSG;
                  lc_header_warehouse_err_flag:='Y';
               END IF;--lcu_chk_warehouse%NOTFOUND
            CLOSE lcu_chk_warehouse;
         ELSE
            gc_error_code       :='SO12';
            gc_error_msg        :='The Warehouse field is NULL for the Order: '||lr_order_headers.ordernbr;
            gc_comments         :='Please Provide value for Warehouse';
            INSERT_ERROR_MSG;
            lc_header_warehouse_err_flag:='Y';
         END IF; --End of check for Warehouse

         gc_log_msg:='Flag returned by the Warehouse Validation Cursor is: '||lc_header_warehouse_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         --------------------------
         --Currency code Validation
         --------------------------
         --Check if Currency code is valid
         OPEN lcu_chk_currency(lr_order_headers.currencycode);
         FETCH lcu_chk_currency INTO lc_header_currency_err_flag;
            IF (lcu_chk_currency%NOTFOUND) THEN
               --Log error message
               gc_error_code       :='SO13';
               gc_error_msg        :='Currency code: '||lr_order_headers.currencycode||' does not exist or is Invalid for the Order number: '||lr_order_headers.ordernbr;
               gc_comments         :='Please define this currency code';
               INSERT_ERROR_MSG;
               lc_header_currency_err_flag:='Y';
            END IF; --lcu_chk_currency%NOTFOUND
         CLOSE lcu_chk_currency;

         gc_log_msg:='Flag returned by the Currency code Validation Cursor is: '||lc_header_currency_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         --------------------------
         -- Order Source Validation
         --------------------------
         --Check if Order Source is valid
         ln_order_source_id:=NULL;
         OPEN lcu_chk_order_source(lr_order_headers.ordersource);
         FETCH lcu_chk_order_source INTO ln_order_source_id;
            IF (lcu_chk_order_source%NOTFOUND) THEN
               --Log error message
               gc_error_code       :='SO14';
               gc_error_msg        :='Order Source: '||lr_order_headers.ordersource||' does not exist or is Invalid for the Order number: '||lr_order_headers.ordernbr;
               gc_comments         :='Order Source should be either GHX or CNV';
               INSERT_ERROR_MSG;
               lc_header_ordersource_err_flag:='Y';
            END IF;--lcu_chk_order_source%NOTFOUND
         CLOSE lcu_chk_order_source;

         gc_log_msg:='Order Number is: '||lr_order_headers.ordernbr;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         gc_log_msg:='Flag returned by the Order Source Validation Cursor is: '||lc_header_ordersource_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


            FOR lr_order_lines IN lcu_get_order_lines (gc_operating_unit_name,lr_order_headers.ordernbr)
            LOOP
               gc_log_msg:='***START OF SALES ORDER LINE VALIDATION*** For the Order: '||lr_order_headers.ordernbr||' and Line: '||lr_order_lines.orderlinenbr;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               lc_line_nbr_err_flag            :='N';
               lc_line_item_err_flag           :='N';
               lc_line_uom_err_flag            :='N';
               lc_line_qty_err_flag            :='N';
               lc_line_request_date_err_flag   :='N';
               lc_line_ship_date_err_flag      :='N';
               lc_line_rcv_date_err_flag       :='N';
               lc_selprice_err_flag            :='N';
               lc_listprice_err_flag           :='N';
               gn_record_number                := lr_order_lines.oracleidentifier;
               gc_record_identifier            := lr_order_headers.ordernbr||' Line :'||lr_order_lines.orderlinenbr;
               gc_table_name                   :='USBPCS_ORDERLINE_CLEANED';
               gc_error_code                   := NULL;
               gc_error_msg                    := NULL;
               gc_comments                     := NULL;

               -----------------------------
               -- Validate Order Line Number
               -----------------------------

               IF (lr_order_lines.orderlinenbr IS NOT NULL) THEN
                  OPEN  lcu_chk_order_line_number(lr_order_lines.ordernbr,lr_order_lines.orderlinenbr);
                  FETCH lcu_chk_order_line_number INTO lc_line_nbr_err_flag;
                     IF (lcu_chk_order_line_number%FOUND) THEN
                       -- Log Error if the Order Line Number Repeats
                        gc_error_code       :='SO15';
                        gc_error_msg        :='The Line Number: '||lr_order_lines.orderlinenbr||' repeats in the Order: '||lr_order_lines.ordernbr;
                        gc_comments         := NULL;
                        INSERT_ERROR_MSG;
                        lc_line_nbr_err_flag :='Y';
                     END IF;--lcu_chk_order_line_number%FOUND
                  CLOSE lcu_chk_order_line_number;

                  gc_log_msg:='Flag returned by the Order Line Number Uniqueness Validation is: '||lc_line_nbr_err_flag ;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               ELSE
                  -- Log Error if the Order Line number is NULL
                  gc_error_code       :='SO16';
                  gc_error_msg        :='Order Line number is null for Order: '||lr_order_lines.ordernbr;
                  gc_comments         :='Please provide value for Order Line number column';
                  INSERT_ERROR_MSG;
                  lc_line_nbr_err_flag:='Y';

                  gc_log_msg:='Flag returned by the Order Line Number NULL Validation is: '||lc_line_nbr_err_flag ;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               END IF; --lr_order_lines.orderlinenbr IS NOT NULL

               gc_log_msg:='Flag returned by the Order Line Number Validation Cursor is: '||lc_line_nbr_err_flag ;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               --------------------------
               -- Validate Inventory Item
               --------------------------
               --Check if Inventory Item already exists in the System
               ln_inventory_item_id:=NULL;
               lc_primary_uom      :=NULL;
               lc_actual_uom       :=NULL;
               lc_uom              :=NULL;

               IF (lr_order_lines.itemnbr IS NOT NULL) THEN
                  OPEN  lcu_chk_item(ln_warehouse_id,lr_order_lines.itemnbr);
                  FETCH lcu_chk_item INTO ln_inventory_item_id,lc_primary_uom;
                     IF (lcu_chk_item%NOTFOUND) THEN
                        --Log error message
                        gc_error_code       :='SO17';
                        gc_error_msg        :='Inventory Item with Segment1: '||lr_order_lines.itemnbr||' does not exist for the Organization: '||lr_order_headers.warehouse||' for the Order Number '||lr_order_lines.ordernbr;
                        gc_comments         :='Please define this item for the Organization';
                        INSERT_ERROR_MSG;
                        lc_line_item_err_flag:='Y';
                     END IF; --lcu_chk_item%NOTFOUND
                  CLOSE lcu_chk_item;

                  IF (lr_order_lines.uom IS NOT NULL) THEN
                     OPEN  lcu_chk_uom(lr_order_lines.uom);
                     FETCH lcu_chk_uom INTO lc_actual_uom;
                        IF (lcu_chk_uom%NOTFOUND) THEN
                           --Log error message
                           gc_error_code       :='SO18';
                           gc_error_msg        :='UOM: '||lr_order_lines.uom||' is Invalid for the Order number: '||lr_order_lines.ordernbr;
                           gc_comments         :='Please define the UOM';
                           INSERT_ERROR_MSG;
                           lc_line_uom_err_flag:='Y';
                        ELSE
                           lc_uom:=lc_actual_uom;
                        END IF; --lcu_chk_uom%NOTFOUND
                     CLOSE lcu_chk_uom;
                  ELSE
                     lc_uom:=lc_primary_uom;
                  END IF; --lr_order_lines.uom IS NOT NULL
                  gc_log_msg:='Flag returned by the UOM Validation is: '||lc_line_uom_err_flag;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               ELSE
                  --Log error message
                  gc_error_code       :='SO19';
                  gc_error_msg        :='Itemnbr Field is NULL for the Order number: '||lr_order_lines.ordernbr;
                  gc_comments         :='Please Provide value for Itemnbr';
                  INSERT_ERROR_MSG;
                  lc_line_item_err_flag:='Y';
               END IF; --lr_order_lines.itemnbr is NOT NULL

               gc_log_msg:='Flag returned by the Item Number Validation is: '||lc_line_item_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ---------------------------
               -- Qtyordered Validation
               ---------------------------
               IF (NVL(lr_order_lines.qtyordered,0)=0) THEN
                  --Log error message
                  gc_error_code       :='SO20';
                  gc_error_msg        :='Qtyordered: '||lr_order_lines.qtyordered||' is Null/0 for the Order number: '||lr_order_lines.ordernbr;
                  gc_comments         :='Please provide value for Qtyordered';
                  INSERT_ERROR_MSG;
                  lc_line_qty_err_flag:='Y';
               ELSE
                  IF (NVL(lr_order_lines.qtyordered,0) - NVL(lr_order_lines.qtyshipped,0))=0 THEN
                     --Log error message
                     gc_error_code       :='SO21';
                     gc_error_msg        :='Net Quantity is 0 for the Order number: '||lr_order_lines.ordernbr;
                     gc_comments         :='Qtyordered-Qtyshipped must be a positive value';
                     INSERT_ERROR_MSG;
                     lc_line_qty_err_flag:='Y';
                  END IF;
               END IF;

               gc_log_msg:='Flag returned by the Quantity Ordered Validation is: '||lc_line_qty_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ---------------------------
               -- Requesteddate Validation
               ---------------------------
               ld_line_SchedShip_date:=NULL;
               ld_line_schedrcv_date :=NULL;
               ld_line_request_date  :=NULL;

               --Check whether Requested date is in a Valid Format
               IF (lr_order_lines.requesteddate IS NOT NULL) THEN
                  BEGIN
                     ld_line_request_date:=TO_DATE(lr_order_lines.requesteddate,'YYYYMMDD');
                  EXCEPTION
                  WHEN OTHERS THEN
                     gc_error_code       :='SO22';
                     gc_error_msg        :='Value in the field REQUESTEDDATE is not in Date Format for the Order Number '||lr_order_lines.ordernbr;
                     gc_comments         :='Please provide the Requested date in YYYYMMDD format';
                     INSERT_ERROR_MSG;
                     lc_line_request_date_err_flag:='Y';
                  END;
               END IF; --lr_order_lines.requesteddate IS NOT NULL

               gc_log_msg:='Flag returned by the  RequestedDate  Validation is: '||lc_line_request_date_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


               --Check whether Schedule Ship Date is in a Valid Format
            /*   IF (lr_order_lines.schedshipdate IS NOT NULL) THEN
                  --Check whether Schedule Ship Date is in a Valid Format
                  BEGIN
                     ld_line_SchedShip_date:=TO_DATE(lr_order_lines.schedshipdate,'YYYYMMDD');
                  EXCEPTION
                  WHEN OTHERS THEN
                     gc_error_code       :='SO21';
                     gc_error_msg        :='Invalid Schedshipdate';
                     gc_comments         :='Please provide the Schedule Ship date in YYYYMMDD format';
                     INSERT_ERROR_MSG;
                     lc_line_ship_date_err_flag:='Y';
                  END;
               END IF; --lr_order_lines.schedshipdate IS NOT NULL

               gc_log_msg:='Flag returned by the  SchedShipDate  validation is: '||lc_line_ship_date_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               --Check whether schedule Schedule Rcv Date is in a Valid Format
               IF (lr_order_lines.schedrcvdate IS NOT NULL) THEN
                  BEGIN
                     ld_line_schedrcv_date:=TO_DATE(lr_order_lines.schedrcvdate,'YYYYMMDD');
                  EXCEPTION
                  WHEN OTHERS THEN
                     gc_error_code       :='SO52';
                     gc_error_msg        :='Invalid Schedrcvdate ';
                     gc_comments         :='Please provide the Schedule Rcv Date in YYYYMMDD format';
                     INSERT_ERROR_MSG;
                     lc_line_rcv_date_err_flag:='Y';
                  END;
               END IF; --lr_order_lines.schedrcvdate IS NOT NULL AND TRIM(lr_order_lines.schedrcvdate)<>'0'

               gc_log_msg:='Flag returned by the  SchedRcvDate  Validation is: '||lc_line_rcv_date_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);  */


               IF (lc_line_request_date_err_flag='Y') THEN
                  lc_line_date_err_flag:='Y';
               END IF;

               gc_log_msg:='Flag returned by the  SchedShipDate Validation is: '||lc_line_date_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               --Validation for Selling Price and List Price has been Removed
               -------------------------
               -- Validate Selling price
               -------------------------
               --Check if Selling Price is NOT NULL
               IF (lr_order_lines.netsellingprice IS NULL) THEN
                  --Log errors
                  gc_error_code       :='SO23';
                  gc_error_msg        :='Selling price: '||'for the Order Number: '||lr_order_headers.ordernbr||' and line number: '||lr_order_lines.orderlinenbr||' is NULL';
                  gc_comments         :='Please provide a value for selling price';
                  INSERT_ERROR_MSG;
                  lc_selprice_err_flag:='Y';
               END IF; --lr_order_lines.netsellingprice is NULL

               gc_log_msg:='Flag returned by the Selling price Validation is: '||lc_selprice_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ----------------------
               -- Validate List Price
               ----------------------
               --Check if List Price is NOT NULL
               IF (lr_order_lines.listprice IS NULL) THEN
                  --Log errors
                  gc_error_code       :='SO24';
                  gc_error_msg        :='List price: '||'for the Order Number: '||lr_order_headers.ordernbr||' and line number: '||lr_order_lines.orderlinenbr||' is NULL';
                  gc_comments         :='Please provide a value for list price';
                  INSERT_ERROR_MSG;
                  lc_listprice_err_flag:='Y';
               END IF; --lr_order_lines.listprice is NULL

               gc_log_msg:='Flag returned by the List price Validation is: '||lc_listprice_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


               --Updating status of Lines Staging Table
               IF (lc_line_nbr_err_flag  = 'Y'  OR
                   lc_line_item_err_flag = 'Y'  OR
                   lc_line_date_err_flag = 'Y'  OR
                   lc_line_uom_err_flag  = 'Y'  OR
                   lc_line_qty_err_flag  = 'Y') THEN
                   lc_line_error_flag   := 'Y';

                  --Updating status to 'VE' for Lines if Validation Errors
                  UPDATE usbpcs_orderline_cleaned
                  SET    oraclecharfld1  ='VE'
                        ,oracleintfld8   = gn_request_id
                  WHERE  oracleidentifier= lr_order_lines.oracleidentifier;

                  gc_log_msg :='Updated line table with status VE';
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               ELSE
                  --Updating status to 'VS' for Lines if no Validation Errors
                  UPDATE usbpcs_orderline_cleaned
                  SET    oraclecharfld1  = 'VS'
                        ,oracleintfld1   = ln_inventory_item_id
                        ,uom             = lc_uom
                     -- ,oraclecharfld2  = ld_line_SchedShip_date
                     -- ,oraclecharfld3  = ld_line_schedrcv_date
                        ,oraclecharfld4  = ld_line_request_date
                        ,oracleintfld8   = gn_request_id
                  WHERE  oracleidentifier= lr_order_lines.oracleidentifier;

                  gc_log_msg :='Updated line table with status VS';
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               END IF; --end of updating status of Lines Staging Table



            --COMMIT;
            END LOOP;--End of Line Loop

         gc_log_msg :='After lines loop..';
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


            -- If  there exist any errors in the above validations then update the status of the header records
         IF (lc_header_origsys_err_flag        ='Y'  OR
             lc_header_date_err_flag           ='Y'  OR
             lc_header_terms_code_err_flag     ='Y'  OR
             lc_header_ship_via_err_flag       ='Y'  OR
             lc_header_ship_number_err_flag    ='Y'  OR
             lc_header_ordertype_err_flag      ='Y'  OR
             lc_header_warehouse_err_flag      ='Y'  OR
             lc_header_currency_err_flag       ='Y'  OR
             lc_header_ordersource_err_flag    ='Y') THEN
             lc_header_error_flag             :='Y';

            --If any errors in the above validation then update the status of the record to VE
            UPDATE usbpcs_orderheader_cleaned
            SET    oraclecharfld1='VE'
                  ,oracleintfld8   =gn_request_id
            WHERE  oracleidentifier=lr_order_headers.oracleidentifier;

            gc_log_msg :='Updated Header table with status VE for the Order: '||lr_order_headers.ordernbr;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         ELSE
            --If NO errors in the above validation then update the status of the record to VS
            UPDATE usbpcs_orderheader_cleaned
            SET   oraclecharfld1  = 'VS'
                 ,oracleintfld1   = ln_cust_account_id
                 ,oracleintfld2   = ln_terms_id
                 ,oracleintfld3   = ln_site_use_id
                 ,oracleintfld4   = ln_bill_to_site_use_id
                 ,oracleintfld5   = ln_order_type_id
                 ,oracleintfld6   = ln_warehouse_id
                 ,oracleintfld7   = ln_order_source_id
                 ,oraclecharfld2  = ld_header_entered_date
                 ,oraclecharfld3  = gc_operating_unit
                 ,oraclecharfld4  = lc_shipping_method_code
                 ,oraclecharfld5  = ld_header_request_date
                 ,oracleintfld8   = gn_request_id
            WHERE oracleidentifier= lr_order_headers.oracleidentifier;

            gc_log_msg :='Updated Header table with status VS for the Order: '||lr_order_headers.ordernbr;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         END IF; --End of updating the status of the header records

      END LOOP; --End of main Header loop
   ELSE
      lc_setup_error_flag:='Y';
   END IF; -- IF lc_setup_exist='Y'
   COMMIT;

   IF (lc_line_error_flag='Y' OR lc_header_error_flag='Y') THEN
      lc_mast_err_flag:='Y';
   END IF;


   --Reinitialize the Variables
   ln_header_rec_fetched   :=0;
   ln_header_rec_validated :=0;
   ln_header_rec_invalid   :=0;
   ln_line_rec_fetched     :=0;
   ln_line_rec_validated   :=0;
   ln_line_rec_invalid     :=0;

   --Get the total no of header records
   OPEN  lcu_get_header_count(gc_operating_unit_name);
   FETCH lcu_get_header_count INTO ln_header_rec_fetched;
   CLOSE lcu_get_header_count;

   --Get total no of header records validated successfully
   OPEN lcu_get_header_valid_count(gc_operating_unit_name);
   FETCH lcu_get_header_valid_count INTO ln_header_rec_validated;
   CLOSE lcu_get_header_valid_count;


   --Get total no of header records failed validation
   OPEN lcu_get_header_invalid_count(gc_operating_unit_name);
   FETCH lcu_get_header_invalid_count INTO ln_header_rec_invalid;
   CLOSE lcu_get_header_invalid_count;

   --Get the total no of line records
   OPEN  lcu_get_line_count(gc_operating_unit_name);
   FETCH lcu_get_line_count INTO ln_line_rec_fetched;
   CLOSE lcu_get_line_count;

   --Get total no of line records validated successfully
   OPEN lcu_get_line_valid_count(gc_operating_unit_name);
   FETCH lcu_get_line_valid_count INTO ln_line_rec_validated;
   CLOSE lcu_get_line_valid_count;

   --Get total no of line records failed validation
   OPEN lcu_get_line_invalid_count(gc_operating_unit_name);
   FETCH lcu_get_line_invalid_count INTO ln_line_rec_invalid;
   CLOSE lcu_get_line_invalid_count;

   IF (lc_setup_error_flag='Y')  THEN      --If SET UP errors (setup)
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_record_identify);
      x_retcode:=2;
      RETURN;
   END IF; --lc_setup_error_flag='Y'

   --If Validation error then set the status of the program to warning and display the Summary Information
   --Summary Information of USBPCS_ORDERHEADER_CLEANED Records Validated
   --===================================================================
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Summary information of USBPCS_ORDERHEADER_CLEANED Records Validated ');
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Total Records Validated                    :    ' ||ln_header_rec_fetched);
   fnd_file.put_line(fnd_file.LOG,'Total Records Passed Validation            :    ' ||ln_header_rec_validated);
   fnd_file.put_line(fnd_file.LOG,'Total Records Errored out                  :    ' ||ln_header_rec_invalid);

   --Summary Information of USBPCS_ORDERLINE_CLEANED Records Validated
   --=================================================================
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Summary information of USBPCS_ORDERLINE_CLEANED Records Validated ');
   fnd_file.put_line(fnd_file.LOG,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.LOG,'Total Records Validated                    :    ' ||ln_line_rec_fetched);
   fnd_file.put_line(fnd_file.LOG,'Total Records Passed Validation            :    ' ||ln_line_rec_validated);
   fnd_file.put_line(fnd_file.LOG,'Total Records Errored out                  :    ' ||ln_line_rec_invalid);

   IF (lc_mast_err_flag='Y') THEN
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_record_identify);
      x_retcode:=1;
      RETURN;
   END IF;
   IF (lc_mast_err_flag='N' AND lc_setup_error_flag='N') THEN --If no Errors then call the Process Program

      PROCESS_SALES_ORDERS (x_retcode =>lc_retcode
                           );

      IF (lc_retcode=1 OR lc_retcode=2) THEN
         xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_record_identify);
         x_retcode:=lc_retcode;
         RETURN;
      END IF; --lc_retcode=1 OR lc_retcode=2

   END IF; --end of (lc_header_error_flag='Y'AND lc_setup_error_flag ='N')
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_OM_SALES_ORDER_CONV_PK.VALIDATE_SALES_ORDERS. Error is: ' ||SQLERRM);
   x_errbuf:=SQLERRM;
   x_retcode:=2;
   ROLLBACK;
END VALIDATE_SALES_ORDERS;

END XXHA_OM_SALES_ORDER_CONV_PK;


/
