CREATE OR REPLACE PACKAGE      XXHA_AP_INVOICE_CONV_PKG
                AUTHID CURRENT_USER AS
gn_sob_id                gl_sets_of_books.set_of_books_id%TYPE                    := FND_PROFILE.VALUE('GL_SET_OF_BKS_ID');-- Variable to store the Set Of Books Id
gn_user_id               fnd_user.user_id%TYPE                                    := FND_GLOBAL.USER_ID; -- Variable to store the User Id
gc_record_error          xxha_AP_header_temp.record_status%type              :='E';
gc_record_success        xxha_AP_header_temp.record_status%type              :='S';
gc_record_interfaced     xxha_AP_header_temp.record_status%type              :='I';
gc_distr_line_type       xxha_ap_lines_temp.line_type_lookup_code%type           := 'ITEM';
gn_record_number         xxha_common_errors.record_number%TYPE;                   --Variable to store Oracle Identifier of the record
gc_record_identifier     xxha_common_errors.record_identifier%TYPE;               --Variable to store Record identifier of the record
gc_error_code            xxha_common_errors.error_code%TYPE;                      --Variable to store Error Code of the record
gc_error_msg             xxha_common_errors.error_msg%TYPE;                       --Variable to store Error Message of the record
gc_comments              xxha_common_errors.comments%TYPE;                        --Variable to store Error Comments of the record
gc_table_name            xxha_common_errors.table_name%TYPE;                      --Variable to store Table Name
gc_attribute1            xxha_common_errors.attribute1%TYPE;                      --Variable to store Attribute1
gc_attribute2            xxha_common_errors.attribute2%TYPE;                      --Variable to store Attribute2
gc_attribute3            xxha_common_errors.attribute3%TYPE;                      --Variable to store Attribute3
gc_attribute4            xxha_common_errors.attribute4%TYPE;                      --Variable to store Attribute4
gc_attribute5            xxha_common_errors.attribute5%TYPE;                      --Variable to store Attribute5
gn_request_id            xxha_common_errors.request_id%TYPE                       := FND_GLOBAL.CONC_REQUEST_ID;           -- Variable to store the Concurrent Request Id
gc_record_identify       xxha_common_errors.record_identifier%TYPE                :='AP INVOICE';                         -- Variable to store the Record identifier of the Program that appears as Column in the Common Error Report
gc_program_name          VARCHAR2(1000)                                           :='AP Invoice Conversion';              -- Variable to store the Concurrent Program Name that appears as Heading in the Common Error Report
gc_operating_unit        po_headers_ALL.org_id%TYPE                               := FND_PROFILE.VALUE('ORG_ID');          -- Variable to store the Operating Unit
gc_debug_flag            VARCHAR2(1);                                             --Variable to store the Debug Flag
gc_log_msg               VARCHAR2(3000);                                          --Variable to store the Log Message
gc_status                VARCHAR2(2);                                             --Variable to store status of data insertion in Common Error table
gc_sysdate               date                                                     := trunc(SYSDATE);
gc_gl_date               date ;

      FUNCTION exists_in_ap  ( p_invoice_num                  IN VARCHAR2
                              , p_vendor_id                 IN NUMBER
                              , p_vendor_site_id            IN NUMBER
                              , p_org_id                    IN NUMBER
                              ) RETURN BOOLEAN;
       FUNCTION exists_in_ap_interface
                              ( p_voucher_num                  IN VARCHAR2
                              , p_vendor_id                 IN NUMBER
                              , p_vendor_site_id            IN NUMBER
                              , p_org_id                    IN NUMBER
                              ) RETURN BOOLEAN;
---------------------------------------------------------
   --  Load standard AP Invoice interface table
--------------------------------------------------------
       PROCEDURE load_standard_data(
                      p_error_status           OUT VARCHAR2);
      PROCEDURE main_proc(
      ERRBUF                  OUT VARCHAR2 ,
      RETCODE                 OUT VARCHAR2,
      p_debug_flag          IN  VARCHAR2 DEFAULT 'N',
      p_purge_flag             IN  VARCHAR2 DEFAULT 'N',
      p_load_flag           IN  VARCHAR2 DEFAULT 'N',
      p_reset_errors           IN  VARCHAR2 DEFAULT 'N',
      P_GL_DATE                IN  VARCHAR2);
      PROCEDURE Map_val_ap_data( p_error_status OUT VARCHAR2);
END XXHA_AP_INVOICE_CONV_PKG;

/


CREATE OR REPLACE PACKAGE BODY      XXHA_AP_INVOICE_CONV_PKG IS

/******************************************************************************************
*
*           Name : XXHA_AP_INVOICE_CONV_PKB.sql
*
*    Description : Creates package body for processing / converting
*                  APPOIM - AP Invoices
*
*    Author/DATE : Sreeram Boppana
*
*     Parameters : Not Applicable
*
*      Called BY : Concurrent Request:
*
*       Calls To : PKG XXHA_Common_Package
*                  PKG FND_GLOBALS
*                  PKG FND_FLEX_EXT -- Validate Accounting string
*
*   Modification History:
*    Date:         Programmer        Change
*  -----------   ----------------  -------------------------------------
*  29-DEC-2008   Sreeram boppana      Initial version
*
*******************************************************************************************
* Revision History:
*******************************************************************************************/

-- ========================================================================================
-- ====================================    Set of Books details   =========================
-- ========================================================================================
l_start_program_time     VARCHAR2(30)  := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');
   l_end_program_time    VARCHAR2 (30) := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');

   PROCEDURE INSERT_ERROR_MSG
IS
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gn_request_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                            );
FND_FILE.PUT_LINE(FND_FILE.LOG,'insert cmpleted' ||gn_record_number);
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in xxha_common_utilities_pkg.INSERT_ERROR_MSG. Error is: ' ||SQLERRM);
END INSERT_ERROR_MSG;

-- ========================================================================================
-- ====================================    Check Invoice exists in AP =====================
-- ========================================================================================
       FUNCTION exists_in_ap            ( p_invoice_num                  IN VARCHAR2
                                       , p_vendor_id               IN NUMBER
                                       , p_vendor_site_id          IN NUMBER
                                       , p_org_id                  IN NUMBER
                                        ) RETURN BOOLEAN  IS

              lv_invoice_id  ap_invoices_all.invoice_id%TYPE;

       BEGIN
             BEGIN
                   SELECT * INTO lv_invoice_id
                     FROM (SELECT invoice_id
                             FROM ap_invoices_all
                            WHERE invoice_num    = p_invoice_num
                              AND vendor_site_id = p_vendor_site_id
                              AND vendor_id      = p_vendor_id
                              AND org_id         = p_org_id
                            ORDER BY invoice_id)
                    WHERE ROWNUM = 1;
             EXCEPTION
                   WHEN OTHERS THEN
                        NULL;
             END;

            RETURN SQL%FOUND;

       END exists_in_ap;

-- ========================================================================================
-- ====================================    Check Invoice exists in Interface ==============
-- ========================================================================================
       FUNCTION exists_in_ap_interface  ( p_voucher_num                  IN VARCHAR2
                                       , p_vendor_id               IN NUMBER
                                       , p_vendor_site_id          IN NUMBER
                                       , p_org_id                  IN NUMBER
                                        ) RETURN BOOLEAN  IS

              lv_voucher_num ap_invoices_interface.voucher_num%TYPE;

       -- Voucher number is always unique for all orgs...but still checking for

       BEGIN

             BEGIN
                   SELECT * INTO lv_voucher_num
                     FROM (SELECT voucher_num
                             FROM ap_invoices_interface
                            WHERE voucher_num    = p_voucher_num
                              AND vendor_site_id = p_vendor_site_id
                              AND vendor_id      = p_vendor_id
                              AND org_id         = p_org_id
                            ORDER BY voucher_num)
                   WHERE ROWNUM = 1;
            EXCEPTION
                 WHEN OTHERS THEN
                      NULL; -- continue
            END;

            RETURN SQL%FOUND;
END exists_in_ap_interface;

-- +==============================================================================
-- | Name       : purge_staging_table
-- |
-- | Description: Procedure to purge staging table records
-- |
-- | Call From  : Loader Concurrent Program
-- |
-- | Parameters:
-- |   IN:
-- |       p_ou_org_id
-- |  OUT:
-- |
-- | Scope: PUBLIC
-- |
-- +==============================================================================
PROCEDURE purge_staging_table (
         p_ou_org_id  in  number
        ) is
BEGIN

   DELETE  XXHA_AP_HEADER_TEMP1
  -- WHERE   ORG_ID = P_OU_ORG_ID
   where   entity_name = P_OU_ORG_ID;

   DELETE  XXHA_AP_LINES_TEMP1
  -- WHERE   ORG_ID = P_OU_ORG_ID
   where   entity_name = P_OU_ORG_ID;

   commit;

END purge_staging_table;

PROCEDURE reset_record_status
IS
BEGIN
    UPDATE xxha_ap_header_temp1
       SET record_status = NULL
           ,error_message = NULL
     WHERE RECORD_STATUS = GC_RECORD_ERROR
     --AND ORG_ID = GC_OPERATING_UNIT
     and entity_name = GC_OPERATING_UNIT;

     UPDATE xxha_ap_lines_temp1
       SET record_status = NULL
           ,error_message = NULL
     WHERE RECORD_STATUS = GC_RECORD_ERROR
     --and org_id = gc_operating_unit
     and entity_name = GC_OPERATING_UNIT
     AND INVOICE_ID IN ( SELECT INVOICE_ID
                                 FROM xxha_ap_header_temp1
                                WHERE RECORD_STATUS IS NULL
                                --AND ORG_ID = GC_OPERATING_UNIT
                                and entity_name = GC_OPERATING_UNIT);

  fnd_concurrent.af_commit;
EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END reset_record_status;



-- ========================================================================================
-- ====================================    Insert standard data   =========================
-- ========================================================================================

PROCEDURE load_standard_data(   p_error_status           OUT VARCHAR2) is
  l_std_header_records number :=0;
   l_std_line_records   number :=0;

l_invoice_id  AP_invoices_interface.invoice_id%type;
l_invoice_line_id  AP_INVOICE_LINES_INTERFACE.invoice_line_id%type;

                      CURSOR l_ap_header_std_cur
                      IS
                      SELECT * FROM xxha_ap_header_temp1 a
                      WHERE A.RECORD_STATUS = GC_RECORD_SUCCESS
                    --  AND A.ORG_ID = GC_OPERATING_UNIT
                      and a.entity_name = GC_OPERATING_UNIT
                      AND A.REQUEST_ID = GN_REQUEST_ID
                      AND NOT EXISTS (SELECT 1 FROM XXHA_AP_LINES_TEMP1 B WHERE B.RECORD_STATUS = GC_RECORD_ERROR AND B.INVOICE_REF = A.INVOICE_REF );


                      CURSOR l_ap_lines_std_cur(p_ap_inv_id number)
                      IS
                      SELECT * FROM xxha_ap_lines_temp1 b
                      WHERE B.RECORD_STATUS = GC_RECORD_SUCCESS
                      --AND B.ORG_ID = GC_OPERATING_UNIT
                      and b.entity_name = GC_OPERATING_UNIT
                      and b.invoice_id = p_ap_inv_id;


                      begin

                         FOR l_invoice_rec IN l_ap_header_std_cur
     LOOP
       -- SAVEPOINT insert_header;
       Fnd_File.PUT_LINE(Fnd_File.LOG,'insider header insert');

        select AP_INVOICES_INTERFACE_S.nextval into l_invoice_id from dual;



     insert into ap_invoices_interface
  (invoice_id,
   invoice_num,
   invoice_type_lookup_code,
   invoice_date,
   vendor_id,
   vendor_site_id,
   invoice_amount,
   invoice_currency_code,
   source,
   --accts_pay_code_combination_id,
   org_id,
   terms_id,
   --po_number,
   creation_date,
   created_by,
   last_update_date,
   last_updated_by)
  VALUES
  (L_INVOICE_ID,
   L_INVOICE_REC.INVOICE_REF, --invoice_num
   (CASE
              WHEN L_INVOICE_REC.CURRENT_INVOICE_AMOUNT <0
              THEN 'STANDARD'
              WHEN L_INVOICE_REC.CURRENT_INVOICE_AMOUNT >0
              THEN 'CREDIT'
           END ), --trans_type
   --'STANDARD',--trans_type
   --to_date(l_invoice_rec.INVOICE_DATE_lg,'YYYYMMDD'),--invoice_date
   --to_date(l_invoice_rec.INVOICE_DATE,'YYYYMMDD'),--invoice_date
   to_date(l_invoice_rec.INVOICE_DATE,'DD-MON-YY'),--invoice_date
   l_invoice_rec.vendor_id,--vend_id,
   L_INVOICE_REC.VENDOR_SITE_ID,--vend_site_id,
   l_invoice_rec.Current_invoice_amount*-1 ,--inv_amount
   l_invoice_rec.CURRENCY_CODE_LG,--currency
   'CONVERSION', --source--'Intercompany',-- 'INVOICE GATEWAY', --'Legacy Invoices',--
   --1138, --account
   --l_invoice_rec.org_id,
   l_invoice_rec.entity_name,
   l_invoice_rec.terms_id,
   --l_invoice_rec.Purchase_order_number,
   SYSDATE,
   gn_user_id,
   SYSDATE,
   gn_user_id);
Fnd_File.PUT_LINE(Fnd_File.LOG,'After header insert');
l_std_header_records := l_std_header_records+1;
          FOR l_invoice_line_rec IN l_ap_lines_std_cur(l_invoice_rec.invoice_id) Loop
Fnd_File.PUT_LINE(Fnd_File.LOG,'insider lines insert');
            select AP_INVOICE_LINES_INTERFACE_S.nextval into l_invoice_line_id from dual;

          INSERT into ap_invoice_lines_interface
    (invoice_id,
     invoice_line_id,
     line_number,
     line_type_lookup_code,
     amount,
     description,
     accounting_date,
     dist_code_concatenated,
     dist_code_combination_id,
     --po_number,
      creation_date,
   created_by,
   last_update_date,
   last_updated_by)
    VALUES
    (l_invoice_id,
     l_invoice_line_id,
     l_invoice_line_rec.line_number_LG,
     'ITEM', --line_type
     l_invoice_line_rec.invoice_payment_amount*-1,
     l_invoice_line_rec.invoice_description, --description
     --to_date(l_invoice_line_rec.transaction_DATE,'YYYYMMDD'),--GL_DATE_LG
     l_invoice_rec.gl_date,--gc_gl_date,
     l_invoice_line_rec.Dist_Code_Concatenated,
     l_invoice_line_rec.Dist_Code_combination_id,
      --l_invoice_rec.Purchase_order_number,
      SYSDATE,
      gn_user_id,
      SYSDATE,
     gn_user_id);
Fnd_File.PUT_LINE(Fnd_File.LOG,'after lines insert');
l_std_line_records  := l_std_line_records+1;

          update xxha_ap_lines_temp1
          set record_status = gc_record_interfaced
          where invoice_id = l_invoice_rec.invoice_id
          and   invoice_line_id = l_invoice_line_rec.invoice_line_id
          and  line_number = l_invoice_line_rec.line_number_LG;

          END Loop; --Lines

          update xxha_ap_header_temp1
          set record_status = gc_record_interfaced
          where invoice_id = l_invoice_id
          and   invoice_num = l_invoice_rec.invoice_ref;

                      END LOOP; -- header
                      Commit;
                Fnd_File.PUT_LINE(Fnd_File.LOG,'Commit executed'||sqlerrm);

       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'***********************Interface table Load report  *****************');
       Fnd_File.PUT_LINE(Fnd_File.LOG,' ');
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,' ');
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of Headers insertedinto interface: '||to_char( l_std_header_records));
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of Lines inserted into interface: '||to_char( l_std_line_records));
       Fnd_File.PUT_LINE(Fnd_File.LOG,' ');
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,' ');
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'***********************Interface table Load report End  *****************');

        EXCEPTION WHEN OTHERS THEN
                     Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From load standard data'||sqlerrm);
END load_standard_data;
---------------------------------------------------------
   --  Proc 1. Main Loading Procedure
   ---------------------------------------------------------
   PROCEDURE main_proc(
      ERRBUF                  OUT VARCHAR2 ,
      RETCODE                 OUT VARCHAR2,
      p_debug_flag          IN  VARCHAR2 DEFAULT 'N',
      p_purge_flag             IN  VARCHAR2 DEFAULT 'N',
      p_load_flag           IN  VARCHAR2 DEFAULT 'N',
      p_reset_errors           IN  VARCHAR2 DEFAULT 'N',
      P_GL_DATE                IN  VARCHAR2)
   IS
      l_map_data_status               NUMBER;
      l_validate_records_status       VARCHAR2(5);
      l_load_data_status              NUMBER;
      l_requestid                     NUMBER;
      --l_userid                        number;
   BEGIN

       gc_gl_date := to_date(p_gl_date,'DD-MON-YYYY');
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_debug_flag'||p_debug_flag);
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_purge_flag'||p_purge_flag);
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_load_flag'||p_load_flag);
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_reset_errors'||p_reset_errors);
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_reset_errors'||gc_gl_date);
     gc_debug_flag := p_debug_flag;
      l_start_program_time := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');
      Fnd_File.PUT_LINE(Fnd_File.LOG, 'Begin  AP INvoice Conversion Main : '||l_start_program_time);
      IF p_reset_errors = 'Y' THEN
         BEGIN
           --reset_record_status;
           null;
         EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From main_proc/block reset_record_status');
             RAISE;
         END;
      END IF;
      IF p_purge_flag = 'Y' THEN
         BEGIN
           purge_staging_table(gc_operating_unit);
            EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From main_proc/block purge_staging_table');
             RAISE;
         END;
      END IF;

      BEGIN
           Map_val_ap_data( l_validate_records_status );
         EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From main_proc/block map_po_records'||sqlerrm);
             RAISE;
      END;
--IF l_validate_records_status <> gc_record_error THEN
      IF (p_load_flag = 'Y') THEN
          BEGIN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Loading interface ');
            load_standard_data (l_load_data_status);
          EXCEPTION
            WHEN OTHERS THEN
              RAISE;
          END;
      END IF;
     --Fnd_File.PUT_LINE(Fnd_File.LOG,'Correct the errors in Validation and reprocess');
--END IF;
      IF l_load_data_status = 1  THEN
     Fnd_File.PUT_LINE(Fnd_File.LOG,'Error in loading the data into the Interface tables, Transaction(s) Rollbacked');
         retcode:=1;
      END IF;
      l_end_program_time := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');
      Fnd_File.PUT_LINE(Fnd_File.LOG, 'End of AP Invoice Conversion Main : '||l_end_program_time);
    --  po_err_print(l_requestid);
      --write_trailer(p_entity_name);
   EXCEPTION
     WHEN OTHERS THEN
       Fnd_File.PUT_LINE(Fnd_File.LOG,'Program ended unsuccessfully');
       retcode:=-1;
       errbuf := SQLCODE||':'||SQLERRM;
   END main_proc;    -- end of main_proc

PROCEDURE Map_val_ap_data( p_error_status           OUT VARCHAR2)
   IS
   L_HEADER_STATUS          XXHA_AP_HEADER_TEMP1.RECORD_STATUS%TYPE :=NULL;
   L_LINE_STATUS          XXHA_AP_LINES_TEMP1.RECORD_STATUS%TYPE :=NULL;
   L_VENDOR_ID             XXHA_AP_HEADER_TEMP1.VENDOR_ID%TYPE;
   l_vendor_site_id        xxha_ap_header_temp1.vendor_site_id%type;
   l_term_id               ap_terms.term_id%type;
   l_currency_code         fnd_currencies.currency_code%type;
   l_location_id           hr_locations.location_id%type;
   l_organization_id       mtl_parameters.organization_id%type;
   L_DISTR_ACC_ID         GL_CODE_COMBINATIONS_KFV.CODE_COMBINATION_ID%TYPE;
   L_REC_ERROR             XXHA_AP_HEADER_TEMP1.ERROR_MESSAGE%TYPE;
   l_header_err         xxha_ap_header_temp1.error_message%type;
   L_INVOICE_ID       XXHA_AP_HEADER_TEMP1.INVOICE_ID%TYPE;
   L_INVOICE_LINE_ID  XXHA_AP_LINES_TEMP1.INVOICE_LINE_ID%TYPE;
   l_invoice_line_sum   xxha_ap_lines_temp1.invoice_payment_amount%type;
   l_uom_code              mtl_units_of_measure.uom_code%type;
   L_CHARGE_ACC_ID         GL_CODE_COMBINATIONS_KFV.CODE_COMBINATION_ID%TYPE;
   l_coa_id                gl_sets_of_books.chart_of_accounts_id%type;
   L_OPERATING_UNIT_NAME   HR_OPERATING_UNITS.NAME%TYPE;
   l_operating_unit_id   HR_OPERATING_UNITS.ORGANIZATION_ID%type;

         -- open cursor to get the headers info
      CURSOR l_ap_header_cur
      IS
      select *
      FROM
      XXHA_AP_HEADER_TEMP1
      where entity_name = l_operating_unit_id--l_operating_unit_name
      and record_status is null;
      -- open cursor to get the headers info
      CURSOR l_ap_line_cur (l_ap_invoice_ref Varchar2)
      IS
      select *
      FROM
      xxha_ap_lines_temp1
      where invoice_ref = l_ap_invoice_ref
      AND RECORD_STATUS IS NULL;



   BEGIN
      -- initialize hard coded values for mapping
      -- add other hard coded values here
      -- end of initilize hard coded values
      -- Update default values and direct mapping values
/*
                               M A P  and V A L I D A T E   AP Invoices
*/
            p_error_status := null;
            gc_log_msg:='START of AP Mapping-Validation Process'||gc_operating_unit;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

SELECT ORGANIZATION_ID--name
INTO l_operating_unit_id --l_operating_unit_name
from hr_operating_units
WHERE ORGANIZATION_ID = GC_OPERATING_UNIT;
UPDATE XXHA_AP_HEADER_TEMP1 SET TERMS_NAME=DECODE(TERMS_NAME,'Z110','1% 10 Days/Net 30','Z1N3','1% 10 Days/Net 30','NT00','Immediate','Z087','Immediate','NT10','Net 10',
'NT15','Net 15','NT30','Net 30','NT40','Net 40','NT45','Net 45',
'NT50','Net 50','NT60','Net 60','29','Net 21','21','2% 10 Days/Net 30','IN14','10% Imm/Net 30',
'','Net 15','IN32','Immediate','NT55','Net 55','NT70','Net 70','Z083','Immediate','Z099','Net 45','Z553',
'Net 30',TERMS_NAME);



  FOR l_ap_headers_rec IN l_ap_header_cur
     LOOP
   --Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'  ');
   Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'No of AP Headers Selected  '||l_ap_header_cur%rowcount);

     gc_log_msg:='before initiation';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
     l_header_status   := gc_record_success;
     gc_error_msg      := null;
     gc_error_code     := null;
     gc_comments       := null;
     gn_record_number := '123456'; --l_ap_headers_rec.invoice_ref;
     gc_record_identifier := l_ap_headers_rec.invoice_ref;

     gc_log_msg:='in the loop';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
     l_rec_error       := null;
     l_header_err      := null;
     gc_log_msg:='after assignment';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   --Initialize header variables
   l_invoice_id := null;
   l_invoice_line_id := null;
   l_vendor_id :=null;
   l_vendor_site_id := null;
   l_location_id := null;
     l_term_id := null;
      l_currency_code := null;
   l_organization_id := null;

   select XXHA_AP_INTERFACE_S.nextval into l_invoice_id from dual;

        BEGIN


           --1. Vendor Site ID , first returned vendor site will be used in that operating unit

           BEGIN
           Fnd_File.PUT_LINE(Fnd_File.LOG,'In vendor');
           SELECT vendor_site_id,vendor_id
           INTO   l_vendor_site_id,l_vendor_id
           FROM po_vendor_sites_all pvs
           WHERE --pvs.vendor_id = l_vendor_id
           --AND pvs.vendor_site_code =  l_ap_headers_rec.vendor_name
            PVS.ORG_ID = GC_OPERATING_UNIT
           --AND pvs.attribute1 = l_ap_headers_rec.vendor_number
           AND pvs.attribute1 = l_ap_headers_rec.attribute1
           AND pvs.pay_site_flag = 'Y'
           AND nvl(Inactive_date,trunc(sysdate)) >=trunc(sysdate)
           AND ROWNUM = 1;
            IF l_vendor_site_id is null THEN
           gc_error_code       :='AP01';
           gc_error_msg        :='Vendor : '||l_ap_headers_rec.vendor_name||' doesnot have valid pay site defined in Oracle';
           gc_comments         :='Please Give a Valid vendor/paysite site';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           gc_error_code       :='AP02';
           gc_error_msg        :='Vendor : '||l_ap_headers_rec.vendor_name||' doesnot have valid pay site defined in Oracle';
           gc_comments         :='Please Give a Valid vendor/paysite site';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END ;

           --2. Terms ID
           Begin
           Fnd_File.PUT_LINE(Fnd_File.LOG,'In Terms');
                    SELECT term_id
                      INTO l_term_id
                      FROM AP_TERMS
                     WHERE UPPER(NAME) LIKE UPPER(L_AP_HEADERS_REC.TERMS_NAME)
                       AND enabled_flag = 'Y'
                       AND ((SYSDATE BETWEEN start_date_active AND end_date_active)
                           OR (SYSDATE >= start_date_active AND end_date_active IS NULL))
                       AND rownum < 2;

           IF l_term_id is null THEN
           gc_error_code       :='AP03';
           gc_error_msg        :='Terms code  : '||l_ap_headers_rec.terms_code||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Terms Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           gc_error_code       :='AP04';
           gc_error_msg        :='Terms code  : '||l_ap_headers_rec.terms_code||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Terms Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END;
        --3. Currency Code
         Begin
         Fnd_File.PUT_LINE(Fnd_File.LOG,'In Currency');
            select currency_code
            into l_currency_code
            from fnd_currencies  fc
            where fc.enabled_flag = 'Y'
            and   fc.currency_code = l_ap_headers_rec.currency_code_lg;
             IF l_currency_code is null THEN
               gc_error_code       :='AP05';
               gc_error_msg        :='Currency Code  : '||l_ap_headers_rec.currency_code_lg||' is not valid in Oracle';
               gc_comments         :='Please Give a Valid Currency Code';
               l_rec_error         := l_rec_error||' '||gc_error_msg;
               INSERT_ERROR_MSG;
               l_header_status := gc_record_error;
             END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           gc_error_code       :='AP05';
           gc_error_msg        :='Currency Code  : '||l_ap_headers_rec.currency_code_lg||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Currency Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END;
         Fnd_File.PUT_LINE(Fnd_File.LOG,'before exists in ap');
           IF  exists_in_ap  ( l_ap_headers_rec.invoice_num
                             ,l_vendor_id
                              ,l_vendor_site_id
                                       , gc_operating_unit
                                        )
                                        THEN
            gc_error_code       :='AP07';
           gc_error_msg        :='Invoice  : '||l_ap_headers_rec.invoice_num||'already exists in AP';
           gc_comments         :='Duplicate invoice';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;

         END IF;
         Fnd_File.PUT_LINE(Fnd_File.LOG,'before exists in ap interface');
         IF  exists_in_ap_interface  ( l_ap_headers_rec.invoice_num
                             ,l_vendor_id
                              ,l_vendor_site_id
                                       , gc_operating_unit
                                        )
                                        THEN
            gc_error_code       :='AP08';
           gc_error_msg        :='Invoice  : '||l_ap_headers_rec.invoice_num||'already exists in Interface';
           gc_comments         :='Duplicate invoice';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;

         END IF;

                 gc_log_msg:= 'Vendor_id'||l_vendor_id||' Terms_id '||l_term_id||
      'vendor_site_id'||l_vendor_site_id||'  Currency_code '||l_currency_code;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

        p_error_status := l_header_status;

         l_header_err      := l_rec_error;
         l_invoice_line_sum := null;



       FOR l_ap_lines_rec IN l_ap_line_cur (l_ap_headers_rec.invoice_ref) LOOP
              l_uom_code := null;

              select XXHA_AP_INTERFACE_Line_S.nextval into l_invoice_line_id from dual;

   --Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'No of AP Lines selected  '||l_ap_line_cur%rowcount);
   --Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'  ');

       BEGIN
       gc_log_msg:='Inside lines validation';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
       l_line_status   :=null;
       L_REC_ERROR     :=NULL;
       l_charge_acc_id := null;
         gc_record_identifier := l_ap_lines_rec.invoice_ref||' - '||l_ap_lines_rec.line_number_lg;

             /* Begin
              SELECT code_combination_id
              INTO l_charge_acc_id
              from gl_code_combinations_kfv gck
                  ,gl_sets_of_books gsob
              where  gck.chart_of_accounts_id = gsob.chart_of_accounts_id
                and  gsob.set_of_books_id = gn_sob_id --1002
                --and  concatenated_segments = nvl(l_ap_lines_rec.DIST_CODE_CONCATENATED,'100.000.600.9030.0000.131200.000.000000.000000');
                and  concatenated_segments = l_ap_lines_rec.DIST_CODE_CONCATENATED;
                IF l_charge_acc_id is null THEN
                gc_error_code       :='APL01';
               gc_error_msg        :='Distribution account  : '||l_ap_lines_rec.DIST_CODE_CONCATENATED||' is not valid in Oracle';
               gc_comments         :='Please Give a Valid Charge Account';
               l_rec_error         := l_rec_error||' '||gc_error_msg;
               INSERT_ERROR_MSG;
               l_line_status := gc_record_error;
                END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           gc_error_code       :='APL02';
           gc_error_msg        :='Charge Account  : '||l_ap_lines_rec.DIST_CODE_CONCATENATED||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Charge Account';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
           END;*/
           begin
         select bks.chart_of_accounts_id
         into l_coa_id
         FROM  GL_SETS_OF_BOOKS     BKS
         where BKS.set_of_books_id = gn_sob_id; --1002
         FND_FILE.PUT_LINE(FND_FILE.LOG,'l_coa_id='||L_COA_ID);
         l_charge_acc_id := fnd_flex_ext.get_ccid
                                               ('SQLGL'
                                                , 'GL#'
                                                , l_coa_id
                                                , TO_CHAR(sysdate,'DD-MON-YYYY')
                                                , l_ap_lines_rec.DIST_CODE_CONCATENATED
                                              ) ;
    FND_FILE.PUT_LINE(FND_FILE.LOG,'l_charge_acc_id='||l_charge_acc_id);
         IF l_charge_acc_id is null THEN
                gc_error_code       :='APL01';
               gc_error_msg        :='Distribution account  : '||l_ap_lines_rec.DIST_CODE_CONCATENATED||' is not valid in Oracle';
               gc_comments         :='Please Give a Valid Charge Account';
               l_rec_error         := l_rec_error||' '||gc_error_msg;
               INSERT_ERROR_MSG;
               l_line_status := gc_record_error;
                END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           gc_error_code       :='APL02';
           gc_error_msg        :='Charge Account  : '||l_ap_lines_rec.DIST_CODE_CONCATENATED||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Charge Account';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
           END;

         l_invoice_line_sum := l_invoice_line_sum+l_ap_lines_rec.invoice_payment_amount;



           gc_log_msg:='before lines update';
            XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(GC_DEBUG_FLAG,GC_LOG_MSG);
  update xxha_ap_lines_temp1 xls
      set record_status = nvl( l_line_status,gc_record_success)
      ,error_message    = l_rec_error
      ,invoice_id       =  l_invoice_id
      ,INVOICE_LINE_ID  = L_INVOICE_LINE_ID
      --,org_id           = gc_operating_unit
      ,dist_code_combination_id   = l_charge_acc_id
      ,creation_date             =SYSDATE
      ,created_by = gn_user_id
      ,last_update_date = SYSDATE
      ,last_updated_by = gn_user_id
      --,request_id = gn_request_id
      where invoice_ref = l_ap_lines_rec.invoice_ref
      and   line_number_lg = l_ap_lines_rec.line_number_lg
      and   entity_name     = l_ap_lines_rec.entity_name
      and   record_status is null ;

           gc_log_msg:='After lines update';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      p_error_status := nvl(p_error_status,l_line_status);



      EXCEPTION WHEN OTHERS THEN
      gc_log_msg:='Error   '||sqlerrm||'    occured during AP Line map and validate process for invoice-'||l_ap_lines_rec.invoice_ref||' Line number - '||l_ap_lines_rec.line_number_lg;
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(GC_DEBUG_FLAG,GC_LOG_MSG);
      update xxha_ap_lines_temp1 xls
      set record_status = gc_record_error
      ,error_message    = gc_log_msg||' '||l_rec_error
      where invoice_ref = l_ap_lines_rec.invoice_ref
      and   line_number_lg = l_ap_lines_rec.line_number_lg
      and   entity_name     = l_ap_headers_rec.entity_name;
      END;
       END LOOP; -- Close cursor for Standard PO Lines


       IF l_invoice_line_sum <> l_ap_headers_rec.current_invoice_amt THEN
       gc_error_code       :='AP06';
           gc_error_msg        :='Invoice amount and Line amounts not matching for : '||l_ap_headers_rec.Invoice_ref ;
           gc_comments         :='Invoice will go on hold ';
           l_header_err         := l_header_err||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
         END IF;
       gc_log_msg:='Before header update';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

  update xxha_ap_header_temp1 xhs
      set record_status =  nvl( l_header_status,gc_record_success)
      ,error_message    =  l_header_err
      ,vendor_id        = l_vendor_id
      ,Terms_id         = l_term_id
      ,vendor_site_id   = l_vendor_site_id
      ,INVOICE_ID       = L_INVOICE_ID
      --,org_id           = gc_operating_unit
      ,request_id = gn_request_id
      ,creation_date             =SYSDATE
      ,created_by = gn_user_id
      ,last_update_date = SYSDATE
      ,last_updated_by = gn_user_id
 where invoice_ref      = l_ap_headers_rec.invoice_ref
  and   entity_name     = l_ap_headers_rec.entity_name;
           gc_log_msg:='after header update  -'||l_ap_headers_rec.invoice_ref;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      EXCEPTION WHEN OTHERS THEN
      gc_log_msg:='Error  '||sqlerrm||'   occured during header map and validate process for '||l_ap_headers_rec.invoice_ref||' - '||length(l_rec_error);
      XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(GC_DEBUG_FLAG,GC_LOG_MSG);
      update xxha_ap_header_temp1 xhs
      set record_status = gc_record_error
      ,error_message    = gc_log_msg||' '||l_rec_error
     where invoice_ref = l_ap_headers_rec.invoice_ref
      and  entity_name     = l_ap_headers_rec.entity_name;

      END;
       END LOOP; -- Close cursor for Standard PO Header

       fnd_concurrent.af_commit;
       --p_error_status := l_header_status;
end Map_val_ap_data;

END   XXHA_AP_INVOICE_CONV_PKG;

/
