create or replace 
PACKAGE "XXHA_SHIPPING_DOCS_PKG"
AS
/*******************************************************************************************************
    * Object Name: XXHA_SHIPPING_DOCS_PKG
    * Object Type: Package
    * Description: This package is created for Shipping Documents Requirement and it calls the shipping 
	*              reports.
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    02-MAR-2015          Initial object creation.
*******************************************************************************************************/ 
  PROCEDURE XXHA_DROP_REPORT_PRC(
      p_deliv_id    IN NUMBER,
      p_doc_printer IN VARCHAR2);
  PROCEDURE XXHA_SHIPPING_DOCS_PRC(
      ERRBUF        IN OUT VARCHAR2,
      RETCODE       IN OUT VARCHAR2,
      p_deliv_id    IN NUMBER,
      p_doc_printer IN VARCHAR2 );
END XXHA_SHIPPING_DOCS_PKG;
/

create or replace 
PACKAGE BODY "XXHA_SHIPPING_DOCS_PKG"
AS
/*******************************************************************************************************
    * Object Name: XXHA_SHIPPING_DOCS_PKG
    * Object Type: Package
    * Description: This package is created for Shipping Documents Requirement and it calls the shipping 
	*              reports.
    * Modification Log:
    * Developer          Date                 Description
    *-----------------   ------------------   ------------------------------------------------
    * Apps Associates    02-MAR-2015          Initial object creation.
*******************************************************************************************************/ 
  PROCEDURE XXHA_DROP_REPORT_PRC(
      p_deliv_id    IN NUMBER,
      p_doc_printer IN VARCHAR2 )
  AS
    l_user_id1             NUMBER         := to_number(fnd_profile.value('USER_ID'));
    l_resp_id1             NUMBER         := NULL;
    l_resp_appl_id1        NUMBER         := NULL;
    l_responsibility_name1 VARCHAR2 (255) := 'US Order Management Super User OC';
    l_option_return1       BOOLEAN;
    lc_boolean1            BOOLEAN;
    ln_request_id1         NUMBER;
    l_orgn_id              NUMBER;
  BEGIN
   begin
    	SELECT DISTINCT organization_id 
	 INTO l_orgn_id
	FROM wsh_delivery_assignments wda,
	  wsh_delivery_details wdd
	WHERE wda.delivery_id      = p_deliv_id
	AND wda.delivery_detail_id = wdd.delivery_detail_id;
    EXCEPTION
    WHEN OTHERS THEN
	--DBMS_OUTPUT.PUT_LINE('Error occured in retrieving organization ID for delivery ID '||p_delivery_id);
	fnd_file.put_line(fnd_file.log, 'Error occured in retrieving organization ID for delivery ID '||p_deliv_id);
	end;
    BEGIN
      SELECT frt.application_id,
        frt.responsibility_id
      INTO l_resp_appl_id1,
        l_resp_id1
      FROM fnd_responsibility_tl frt
      WHERE frt.LANGUAGE          = 'US'
      AND frt.responsibility_name = l_responsibility_name1;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_resp_appl_id1 := '';
      l_resp_id1      := '';
    END;
    fnd_global.apps_initialize (user_id => l_user_id1, resp_id => l_resp_id1, resp_appl_id => l_resp_appl_id1);
    --fnd_global.apps_initialize (29067,20420,1);
    l_option_return1 := fnd_request.set_print_options (printer => p_doc_printer, style => NULL, copies => 1, save_output => TRUE, print_together => 'N' );
    DBMS_OUTPUT.put_line ('Printer:' || p_doc_printer);
    lc_boolean1 := fnd_request.add_layout ( template_appl_name => 'HAEMO', template_code => 'XXHA_WMSDRPREP', template_language => 'en', --Use language from template definition
    template_territory => 'US',                                                                                                          --Use territory from template definition
    output_format => 'PDF'                                                                                                               --Use output format from template definition
    );
    ln_request_id1 := fnd_request.submit_request ( 'HAEMO' -- Application
    , 'XXHA_WMSDRPREP'                                     -- Program
    , NULL                                                 -- Description
    , NULL                                                 -- Start Time
    , FALSE                                                -- Sub Request
    , l_orgn_id , p_deliv_id );
    COMMIT;
    IF ln_request_id1 = 0 THEN
      DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
    END IF;
  END;
  PROCEDURE XXHA_SHIPPING_DOCS_PRC(
      ERRBUF        IN OUT VARCHAR2,
      RETCODE       IN OUT VARCHAR2,
      p_deliv_id    IN NUMBER,
      p_doc_printer IN VARCHAR2 )
  AS
    l_user_id             NUMBER         := to_number(fnd_profile.value('USER_ID'));
    l_resp_id             NUMBER         := NULL;
    l_resp_appl_id        NUMBER         := NULL;
    l_responsibility_name VARCHAR2 (255) := 'US Order Management Super User OC';
    --local variables for XXHA: Packing Slip Report US
    l_option_return BOOLEAN;
    lc_boolean      BOOLEAN;
    ln_request_id   NUMBER;
    --local variables for barcoded packing slip report
    l_Cust_Attr_4 HZ_Cust_Accounts.ATTRIBUTE4%TYPE;
    l_request_id  NUMBER;
    l_call_status BOOLEAN;
    l_set_print   BOOLEAN;
    -- l_request_id1                    NUMBER;
    -- l_call_status1                   BOOLEAN;
    -- l_set_print1                     BOOLEAN;
    --local variables for Commercial Invoice report
    l_ship_from_country VARCHAR2(60);
    l_ship_to_country   VARCHAR2(60);
    l_request_id2       NUMBER;
    l_call_status2      BOOLEAN;
    l_set_print2        BOOLEAN;
    --local variables for Bill of Lading report
    l_mode_of_transport VARCHAR2(30);
    l_lookup_desc       VARCHAR2(240);
    l_request_id3       NUMBER;
    l_call_status3      BOOLEAN;
    l_set_print3        BOOLEAN;
    -- local variables for Separator
    l_option_return3 BOOLEAN;
    lc_boolean3      BOOLEAN;
    ln_request_id3   NUMBER;
    ln_request_id4   NUMBER;
    l_out_request    VARCHAR2(1000);
    --local variables for Certificate of Compliance
    l_header_id            NUMBER;
    l_cert_flag            VARCHAR2(1);
    l_item_num             VARCHAR2(50);
    l_lot_num              VARCHAR2(50);
    l_user_id2             NUMBER         := to_number(fnd_profile.value('USER_ID'));
    l_resp_id2             NUMBER         := NULL;
    l_resp_appl_id2        NUMBER         := NULL;
    l_responsibility_name2 VARCHAR2 (255) := 'US Order Management Super User OC';
    l_option_return2       BOOLEAN;
    ln_request_id2         NUMBER;
    p_action_code          VARCHAR2(100);
    p_delivery_id          NUMBER;
    p_delivery_name        VARCHAR2(30);
    p_asg_trip_id          NUMBER;
    p_asg_trip_name        VARCHAR2(30);
    p_asg_pickup_stop_id   NUMBER;
    p_asg_pickup_loc_id    NUMBER;
    p_asg_pickup_loc_code  VARCHAR2(30);
    p_asg_pickup_arr_date  DATE;
    p_asg_pickup_dep_date  DATE;
    p_asg_dropoff_stop_id  NUMBER;
    p_asg_dropoff_loc_id   NUMBER;
    p_asg_dropoff_loc_code VARCHAR2(30);
    p_asg_dropoff_arr_date DATE;
    p_asg_dropoff_dep_date DATE;
    p_sc_action_flag       VARCHAR2(10);
    p_sc_close_trip_flag   VARCHAR2(10);
    p_sc_create_bol_flag   VARCHAR2(10);
    p_sc_stage_del_flag    VARCHAR2(10);
    p_sc_trip_ship_method  VARCHAR2(30);
    p_sc_actual_dep_date   VARCHAR2(30);
    p_sc_report_set_id     NUMBER;
    p_sc_report_set_name   VARCHAR2(60);
    p_wv_override_flag     VARCHAR2(10);
    x_trip_id              VARCHAR2(30);
    x_trip_name            VARCHAR2(30);
    x_return_status        VARCHAR2(10);
    x_msg_count            NUMBER;
    x_msg_data             VARCHAR2(2000);
    x_msg_details          VARCHAR2(3000);
    x_msg_summary          VARCHAR2(3000);
    p_api_version          NUMBER;
    p_init_msg_list        VARCHAR2(30);
    p_commit               VARCHAR2(30);
    lv_return_status       VARCHAR2 (1);
    ln_msg_count           NUMBER;
    lv_msg_data            VARCHAR2 (400);
    ln_trip_id             VARCHAR2 (20);
    lv_trip_name           VARCHAR2 (30);
    l_line_tbl wsh_util_core.id_tab_type;
    l_del_rows_tbl wsh_util_core.id_tab_type;
    ln_line_no      NUMBER := 0;
    l_msg_index_out NUMBER;
    CURSOR cur_trip(l_deliv_id NUMBER)
    IS
      SELECT wdd.delivery_detail_id
      FROM wsh_delivery_details wdd ,
        wsh_delivery_assignments wda,
        wsh_new_deliveries wnd
      WHERE wdd.delivery_detail_id = wda.delivery_detail_id
      AND wda.delivery_id          = wnd.delivery_id
      AND wda.delivery_id          = l_deliv_id;
    --PRAGMA autonomous_transaction;
    l_cr_interval         NUMBER := 1; -- seconds
    l_cr_max_wait         NUMBER := 0; -- seconds(0 = Will not time out)
    l_cr_phase_code       VARCHAR2(30);
    l_cr_status_code      VARCHAR2(30);
    l_cr_dev_phase        VARCHAR2(30);
    l_cr_dev_status       VARCHAR2(30);
    l_cr_message          VARCHAR2(240);
    l_jimport_cr_complete BOOLEAN;
    l_orgn_id number;
  BEGIN
    /*start of code for calling Certificate of Compliance*/
    /*   BEGIN
    XXHA_COC_PDF_PKG.XXHA_COC_PRC(p_deliv_id, p_doc_printer);
    END;
    /*End of code for calling COC*/
    
    begin
    	SELECT DISTINCT organization_id 
	 INTO l_orgn_id
	FROM wsh_delivery_assignments wda,
	  wsh_delivery_details wdd
	WHERE wda.delivery_id      = p_deliv_id
	AND wda.delivery_detail_id = wdd.delivery_detail_id;
    EXCEPTION
    WHEN OTHERS THEN
	--DBMS_OUTPUT.PUT_LINE('Error occured in retrieving organization ID for delivery ID '||p_delivery_id);
	fnd_file.put_line(fnd_file.log, 'Error occured in retrieving organization ID for delivery ID '||p_deliv_id);
	end;
    BEGIN
      SELECT frt.application_id,
        frt.responsibility_id
      INTO l_resp_appl_id,
        l_resp_id
      FROM fnd_responsibility_tl frt
      WHERE frt.LANGUAGE          = 'US'
      AND frt.responsibility_name = l_responsibility_name;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_resp_appl_id := '';
      l_resp_id      := '';
    END;
    fnd_global.apps_initialize (user_id => l_user_id, resp_id => l_resp_id, resp_appl_id => l_resp_appl_id );
    --fnd_global.apps_initialize (29067,20420,1);
    p_action_code := 'GENERATE-PACK-SLIP'; -- Releases Lines related to a delivery
    p_delivery_id := p_deliv_id;           -- delivery ID that action is performed on
    -- Call to WSH_DELIVERIES_PUB.Delivery_Action.
    WSH_DELIVERIES_PUB.Delivery_Action ( p_api_version_number => 1.0, p_init_msg_list => P_init_msg_list, x_return_status => x_return_status, x_msg_count => x_msg_count, x_msg_data => x_msg_data, p_action_code => p_action_code, p_delivery_id => p_delivery_id, p_delivery_name => p_delivery_name, p_asg_trip_id => p_asg_trip_id, p_asg_trip_name => p_asg_trip_name, p_asg_pickup_stop_id => p_asg_pickup_stop_id, p_asg_pickup_loc_id => p_asg_pickup_loc_id, p_asg_pickup_loc_code => p_asg_pickup_loc_code, p_asg_pickup_arr_date => p_asg_pickup_arr_date, p_asg_pickup_dep_date => p_asg_pickup_dep_date, p_asg_dropoff_stop_id => p_asg_dropoff_stop_id, p_asg_dropoff_loc_id => p_asg_dropoff_loc_id, p_asg_dropoff_loc_code => p_asg_dropoff_loc_code, p_asg_dropoff_arr_date => p_asg_dropoff_arr_date, p_asg_dropoff_dep_date => p_asg_dropoff_dep_date, p_sc_action_flag => p_sc_action_flag, p_sc_close_trip_flag => p_sc_close_trip_flag, p_sc_create_bol_flag => p_sc_create_bol_flag, p_sc_stage_del_flag =>
    p_sc_stage_del_flag, p_sc_trip_ship_method => p_sc_trip_ship_method, p_sc_actual_dep_date => p_sc_actual_dep_date, p_sc_report_set_id => p_sc_report_set_id, p_sc_report_set_name => p_sc_report_set_name, p_wv_override_flag => p_wv_override_flag, x_trip_id => x_trip_id, x_trip_name => x_trip_name );
    /*Start of Code for calling Barcoded Packing Slip reports*/
    BEGIN
      -- Check to see if customer is set up for Bar-Coded Packing Slip
      SELECT cst.Attribute4
      INTO l_Cust_Attr_4
      FROM wsh_new_deliveries del ,
        hz_cust_accounts cst ,
        hz_parties party
      WHERE del.delivery_id = p_deliv_id
      AND del.Customer_ID   = cst.CUST_ACCOUNT_ID(+)
      AND cst.Party_Id      = party.Party_Id;
      /*Start of Code for calling "XXHA: Packing Slip Barcoded US" shipping report*/
      BEGIN
        -- If Customer is set up for Bar-Coded Packing Slip then process
        IF l_Cust_Attr_4 = 'Yes' THEN
          -- Set Printer Options
          l_set_print := FND_REQUEST.SET_PRINT_OPTIONS(printer => p_doc_printer, style => NULL, copies => 2, save_output => TRUE, print_together => 'N' );
          -- Call package to set Layout
          l_call_status := fnd_request.add_layout ( template_appl_name => 'HAEMO' -- Template Application Name
          , template_code => 'XXHA_WSHRDPAK_BC_US'                                -- Template Code
          , template_language => 'en'                                             -- Template Language
          , template_territory => 'US'                                            -- Template Territory
          , output_format => 'PDF'                                                -- Output Format
          );
          -- Call Package to submit the Concurrent Program
          l_request_id := fnd_request.submit_request ( 'HAEMO' -- Application
          , 'XXHA_WSHRDPAK_BC_US'                              --P_CONCURRENT_PGM -- Program (i.e. 'XXHA_WSHRDPAK_BC_US')
          , NULL                                               -- Description
          , NULL                                               -- Start Time
          , FALSE                                              -- Sub Request
          , l_orgn_id                                               --P_ORGANIZATION_ID
          , p_deliv_id                                         --6329059   --P_DELIVERY_FROM
          , p_deliv_id                                         --6329059   --P_DELIVERY_TO
          , NULL , NULL , NULL , NULL , NULL , NULL , 'N'      --P_PRINT_CUST_ITEM
          , 'D'                                                --P_ITEM_DISPLAY
          , 'DRAFT'                                            --P_PRINT_MODE
          , 'BOTH'                                             --P_PRINT_ALL
          , 'INV'                                              --P_SORT
          , NULL                                               --P_DELIVERY_DATE_LOW
          , NULL                                               --P_DELIVERY_DATE_HIGH
          , NULL                                               --P_FREIGHT_CODE
          , 3                                                  --P_QUANTITY_PRECISION
          , 'Y'                                                --P_DISPLAY_UNSHIPPED
          );
          COMMIT;
          l_jimport_cr_complete := fnd_concurrent.wait_for_request(l_request_id, l_cr_interval, l_cr_max_wait, l_cr_phase_code, l_cr_status_code, l_cr_dev_phase, l_cr_dev_status, l_cr_message);
          IF (l_cr_dev_phase     = 'COMPLETE' AND l_cr_dev_status != 'NORMAL') THEN
            dbms_output.put_line('Reserve Program with request id -'||l_request_id||', completion phase - '||l_cr_dev_phase||' and completion stauts - '||l_cr_dev_status);
          END IF;
          COMMIT;
          -- Write Message to Job Log if Concurrent Program was submitted
          fnd_file.put_line(fnd_file.log,'                                                                           ');
          fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
          fnd_file.put_line(fnd_file.log,'XXHA: Packing Slip Report Barcoded US' || ' - Submitted - Request ID#: ' || l_request_id);
          fnd_file.put_line(fnd_file.log,'Customer Attribute 4 (Auto_Prt_Pack_Slip): ' || l_Cust_Attr_4);
          fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
          fnd_file.put_line(fnd_file.log,'                                                                           ');
          -- Write Message to Job Log if Concurrent Program was *NOT* submitted
        ELSE
          /*Start of Code for calling XXHA: Packing Slip Report Barcoded US */
          l_option_return := fnd_request.set_print_options (printer => p_doc_printer, style => NULL, copies => 2, save_output => TRUE, print_together => 'N' );
          DBMS_OUTPUT.put_line ('Printer:' || p_doc_printer);
          lc_boolean := fnd_request.add_layout ( template_appl_name => 'HAEMO', template_code => 'XXHA_WSHRDPAK_US', template_language => 'en', --Use language from template definition
          template_territory => 'US',                                                                                                           --Use territory from template definition
          output_format => 'PDF'                                                                                                                --Use output format from template definition
          );
          ln_request_id := fnd_request.submit_request ( 'HAEMO' -- Application
          , 'XXHA_WSHRDPAK_US'                                  -- Program (i.e. 'XXHA_WSHRDPAK_BCD_US_PTO')
          , NULL                                                -- Description
          , NULL                                                -- Start Time
          , FALSE                                               -- Sub Request
          , l_orgn_id , p_deliv_id , 'N' , 'D' , 'DRAFT' , 'BOTH' , 'INV' , NULL , NULL , NULL , 3 , 'Y' , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL );
          COMMIT;
          IF ln_request_id = 0 THEN
            DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
          END IF;
          l_jimport_cr_complete := fnd_concurrent.wait_for_request(ln_request_id, l_cr_interval, l_cr_max_wait, l_cr_phase_code, l_cr_status_code, l_cr_dev_phase, l_cr_dev_status, l_cr_message);
          IF (l_cr_dev_phase     = 'COMPLETE' AND l_cr_dev_status != 'NORMAL') THEN
            dbms_output.put_line('Reserve Program with request id -'||ln_request_id||', completion phase - '||l_cr_dev_phase||' and completion stauts - '||l_cr_dev_status);
          END IF;
          COMMIT;
          /*End of Code for calling XXHA: Packing Slip Report Barcoded US*/
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
      END;
      /*End of Code for calling "XXHA: Packing Slip Barcoded US" shipping report*/
    END;
    /*End of Code for calling Barcoded Packing Slip report*/
    /*Start oF code for calling XXHA: Commercial Invoice Report US*/
    BEGIN
      SELECT sf_hl.country,
        hl.country
      INTO l_ship_from_country,
        l_ship_to_country
      FROM hz_parties party,
        hz_cust_accounts cust,
        hz_cust_acct_sites_all cust_site,
        hz_cust_site_uses_all sites,
        hz_party_sites hps,
        hz_locations hl,
        mtl_parameters mp,
        hr_organization_units hou,
        hr_locations sf_hl,
        oe_order_lines_all oel,
        oe_order_headers_all oeh,
        wsh_new_deliveries wnd,
        wsh_delivery_assignments wda,
        wsh_delivery_details wdd
      WHERE party.party_id            = cust.party_id
      AND cust.cust_account_id        = cust_site.cust_account_id
      AND cust_site.cust_acct_site_id = sites.cust_acct_site_id
      AND cust_site.party_site_id     = hps.party_site_id
      AND hps.location_id             = hl.location_id
      AND sites.site_use_id           = oel.ship_to_org_id
      AND oeh.header_id               = oel.header_id
      AND oel.line_id                 = wdd.source_line_id
      AND wdd.delivery_Detail_id      = wda.delivery_Detail_id
      AND wda.delivery_id             = wnd.delivery_id
      AND oel.ship_from_org_id        = mp.organization_id
      AND mp.organization_id          = hou.organization_id
      AND hou.location_id             = sf_hl.location_id
        --AND oeh.order_number = '1401668'
        --AND  hl.country != sf_hl.country
      AND wnd.delivery_id = p_deliv_id
      GROUP BY sf_hl.country,
        hl.country ;
      BEGIN
        IF (l_ship_from_country != l_ship_to_country) THEN
          -- Set Printer Options
          l_set_print2 := FND_REQUEST.SET_PRINT_OPTIONS(printer => p_doc_printer, style => NULL, copies => 1, save_output => TRUE, print_together => 'N' );
          -- Call package to set Layout
          l_call_status2 := fnd_request.add_layout ( template_appl_name => 'HAEMO' -- Template Application Name
          , template_code => 'XXHA_WSHRDINV_US'                                    -- Template Code
          , template_language => 'en'                                              -- Template Language
          , template_territory => 'US'                                             -- Template Territory
          , output_format => 'PDF'                                                 -- Output Format
          );
          -- Call Package to submit the Concurrent Program
          l_request_id2 := fnd_request.submit_request ( 'HAEMO' -- Application
          , 'XXHA_WSHRDINV_US'                                  --P_CONCURRENT_PGM
          , NULL                                                -- Description
          , NULL                                                -- Start Time
          , FALSE                                               -- Sub Request
          , NULL                                                --P_TRIP_STOP_ID
          , NULL                                                --P_DEPARTURE_DATE_LOW
          , NULL                                                --P_DEPARTURE_DATE_HIGH
          , NULL                                                --P_FREIGHT_CODE
          , l_orgn_id                                                --P_ORGANIZATION_ID
          , p_deliv_id                                          --P_DELIVERY_ID
          , 'D'                                                 --P_ITEM_DISPLAY
          , 'MSTK'                                              --P_ITEM_FLEX_CODE
          , NULL                                                --P_Currency_Code
          , 'N'                                                 --P_PRINT_CUST_ITEM
          , 'Haemoscope'                                        --P_CROSS_REF_TYPE
          );
          COMMIT;
          l_jimport_cr_complete := fnd_concurrent.wait_for_request(l_request_id2, l_cr_interval, l_cr_max_wait, l_cr_phase_code, l_cr_status_code, l_cr_dev_phase, l_cr_dev_status, l_cr_message);
          IF (l_cr_dev_phase     = 'COMPLETE' AND l_cr_dev_status != 'NORMAL') THEN
            dbms_output.put_line('Reserve Program with request id -'||l_request_id2||', completion phase - '||l_cr_dev_phase||' and completion stauts - '||l_cr_dev_status);
          END IF;
          COMMIT;
        END IF;
      END;
    END;
    /*End of code for calling XXHA: Commercial Invoice Report US*/
    /*Start of code for calling Bill of Lading report*/
    BEGIN
      SELECT DECODE(upper(wdd.mode_of_transport),'PARCEL',wdd.mode_of_transport,'Non-Parcel') MODE_OF_TRANSPORT,
        wl.description
      INTO l_mode_of_transport,
        l_lookup_desc
      FROM wsh_carrier_services_v wcs,
        wsh_delivery_details wdd ,
        wsh_delivery_assignments wda,
        wsh_new_deliveries wnd,
        wsh_lookups wl
      WHERE wcs.carrier_id       = wdd.carrier_id
      AND wdd.delivery_detail_id = wda.delivery_detail_id
      AND wda.delivery_id        = wnd.delivery_id
      AND wda.delivery_id        = p_deliv_id
      AND wdd.mode_of_transport  = wl.lookup_code
      AND wl.lookup_type(+)      = 'XXHA_WSH_BOL_MODE_OF_TRANSPORT'
      AND wl.enabled_flag        = 'Y'
      GROUP BY wdd.mode_of_transport,
        wl.description;
      BEGIN
        IF (l_mode_of_transport != 'PARCEL' AND l_lookup_desc = 'YES BOL') THEN
          -- Set Printer Options
          BEGIN
            p_action_code := 'AUTOCREATE-TRIP'; -- Releases Lines related to a delivery
            p_delivery_id := p_deliv_id;        -- delivery ID that action is performed on
            -- Call to WSH_DELIVERIES_PUB.Delivery_Action.
            WSH_DELIVERIES_PUB.Delivery_Action ( p_api_version_number => 1.0, p_init_msg_list => P_init_msg_list, x_return_status => x_return_status, x_msg_count => x_msg_count, x_msg_data => x_msg_data, p_action_code => p_action_code, p_delivery_id => p_delivery_id, p_delivery_name => p_delivery_name, p_asg_trip_id => p_asg_trip_id, p_asg_trip_name => p_asg_trip_name, p_asg_pickup_stop_id => p_asg_pickup_stop_id, p_asg_pickup_loc_id => p_asg_pickup_loc_id, p_asg_pickup_loc_code => p_asg_pickup_loc_code, p_asg_pickup_arr_date => p_asg_pickup_arr_date, p_asg_pickup_dep_date => p_asg_pickup_dep_date, p_asg_dropoff_stop_id => p_asg_dropoff_stop_id, p_asg_dropoff_loc_id => p_asg_dropoff_loc_id, p_asg_dropoff_loc_code => p_asg_dropoff_loc_code, p_asg_dropoff_arr_date => p_asg_dropoff_arr_date, p_asg_dropoff_dep_date => p_asg_dropoff_dep_date, p_sc_action_flag => p_sc_action_flag, p_sc_close_trip_flag => p_sc_close_trip_flag, p_sc_create_bol_flag => 'Y', p_sc_stage_del_flag =>
            p_sc_stage_del_flag, p_sc_trip_ship_method => p_sc_trip_ship_method, p_sc_actual_dep_date => p_sc_actual_dep_date, p_sc_report_set_id => p_sc_report_set_id, p_sc_report_set_name => p_sc_report_set_name, p_wv_override_flag => p_wv_override_flag, x_trip_id => x_trip_id, x_trip_name => x_trip_name );
            COMMIT;
            fnd_file.put_line(fnd_file.log,'Status: ' || x_return_status||x_trip_name);
          END;
          BEGIN
            p_action_code := 'PRINT-BOL'; -- Releases Lines related to a delivery
            p_delivery_id := p_deliv_id;  -- delivery ID that action is performed on
            -- Call to WSH_DELIVERIES_PUB.Delivery_Action.
            WSH_DELIVERIES_PUB.Delivery_Action ( p_api_version_number => 1.0, p_init_msg_list => P_init_msg_list, x_return_status => x_return_status, x_msg_count => x_msg_count, x_msg_data => x_msg_data, p_action_code => p_action_code, p_delivery_id => p_delivery_id, p_delivery_name => p_delivery_name, p_asg_trip_id => p_asg_trip_id, p_asg_trip_name => p_asg_trip_name, p_asg_pickup_stop_id => p_asg_pickup_stop_id, p_asg_pickup_loc_id => p_asg_pickup_loc_id, p_asg_pickup_loc_code => p_asg_pickup_loc_code, p_asg_pickup_arr_date => p_asg_pickup_arr_date, p_asg_pickup_dep_date => p_asg_pickup_dep_date, p_asg_dropoff_stop_id => p_asg_dropoff_stop_id, p_asg_dropoff_loc_id => p_asg_dropoff_loc_id, p_asg_dropoff_loc_code => p_asg_dropoff_loc_code, p_asg_dropoff_arr_date => p_asg_dropoff_arr_date, p_asg_dropoff_dep_date => p_asg_dropoff_dep_date, p_sc_action_flag => p_sc_action_flag, p_sc_close_trip_flag => p_sc_close_trip_flag, p_sc_create_bol_flag => 'Y', p_sc_stage_del_flag =>
            p_sc_stage_del_flag, p_sc_trip_ship_method => p_sc_trip_ship_method, p_sc_actual_dep_date => p_sc_actual_dep_date, p_sc_report_set_id => p_sc_report_set_id, p_sc_report_set_name => p_sc_report_set_name, p_wv_override_flag => p_wv_override_flag, x_trip_id => x_trip_id, x_trip_name => x_trip_name );
            COMMIT;
            fnd_file.put_line(fnd_file.log,'Status 1: ' || x_return_status||x_trip_name);
          END;
          l_set_print3 := FND_REQUEST.SET_PRINT_OPTIONS(printer => p_doc_printer, style => NULL, copies => 2, save_output => TRUE, print_together => 'N' );
          -- Call package to set Layout
          l_call_status3 := fnd_request.add_layout ( template_appl_name => 'HAEMO' -- Template Application Name
          , template_code => 'XXHEMO_WSHRDBOL'                                     -- Template Code
          , template_language => 'en'                                              -- Template Language
          , template_territory => 'US'                                             -- Template Territory
          , output_format => 'PDF'                                                 -- Output Format
          );
          -- Call Package to submit the Concurrent Program
          /*  l_set_options := FND_REQUEST.SET_OPTIONS
          (implicit => 'NO',
          protected => 'NO',
          language  => 'AMERICAN',
          territory => 'US',
          datagroup => NULL,
          numeric_characters => ',.');*/
          l_request_id3 := fnd_request.submit_request ( 'HAEMO' -- Application
          , 'XXHEMO_WSHRDBOL'                                   --P_CONCURRENT_PGM
          , NULL                                                -- Description
          , NULL                                                -- Start Time
          , FALSE                                               -- Sub Request
          , l_orgn_id                                                --P_ORGANIZATION_ID
          , NULL                                                --P_DELIVERY_DATE_LOW
          , NULL                                                --P_DELIVERY_DATE_HIGH
          , NULL                                                --P_FREIGHT_CODE
          , p_deliv_id                                          --P_DELIVERY_ID
          , NULL                                                --P_TRIP_ID
          , NULL                                                --P_DELIVERY_LEG_ID
          , 'D'                                                 --P_ITEM_DISPLAY
          , 'MSTK'                                              --P_ITEM_FLEX_CODE
          );
          COMMIT;
          l_jimport_cr_complete := fnd_concurrent.wait_for_request(l_request_id3, l_cr_interval, l_cr_max_wait, l_cr_phase_code, l_cr_status_code, l_cr_dev_phase, l_cr_dev_status, l_cr_message);
          IF (l_cr_dev_phase     = 'COMPLETE' AND l_cr_dev_status != 'NORMAL') THEN
            dbms_output.put_line('Reserve Program with request id -'||l_request_id3||', completion phase - '||l_cr_dev_phase||' and completion stauts - '||l_cr_dev_status);
          END IF;
          COMMIT;
        END IF;
      END;
    END;
    /*End of code for calling Bill of Lading report*/
    /*start of code for calling Certificate of Compliance*/
    BEGIN
      XXHA_COC_PDF_PKG.XXHA_COC_PRC(p_deliv_id, p_doc_printer);
    END;
    /*End of code for calling COC*/
    /*start of code for calling XXHA Shipping Documents Separator*/
    BEGIN
      -- l_option_return3 := fnd_request.set_print_options (printer => p_doc_printer, style => NULL, copies => 1, save_output => TRUE, print_together => 'N' );
      DBMS_OUTPUT.put_line ('Printer:' || p_doc_printer);
      lc_boolean3 := fnd_request.add_layout ( template_appl_name => 'HAEMO', template_code => 'XXHA_SEPARATOR', template_language => 'en', --Use language from template definition
      template_territory => 'US',                                                                                                          --Use territory from template definition
      output_format => 'PDF'                                                                                                               --Use output format from template definition
      );
      ln_request_id3 := fnd_request.submit_request ( 'HAEMO' -- Application
      , 'XXHA_SEPARATOR'                                     -- Program
      , NULL                                                 -- Description
      , NULL                                                 -- Start Time
      , FALSE                                                -- Sub Request
      , p_deliv_id );
      COMMIT;
      l_jimport_cr_complete := fnd_concurrent.wait_for_request(ln_request_id3, l_cr_interval, l_cr_max_wait, l_cr_phase_code, l_cr_status_code, l_cr_dev_phase, l_cr_dev_status, l_cr_message);
      IF (l_cr_dev_phase     = 'COMPLETE' AND l_cr_dev_status != 'NORMAL') THEN
        dbms_output.put_line('Reserve Program with request id -'||ln_request_id3||', completion phase - '||l_cr_dev_phase||' and completion stauts - '||l_cr_dev_status);
      END IF;
      COMMIT;
      IF ln_request_id3 = 0 THEN
        DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
      END IF;
    END;
    /*End of code for calling XXHA Shipping Documents Separator*/
    BEGIN
      SELECT file_name
      INTO l_out_request
    from FND_CONC_REQ_OUTPUTS
    where concurrent_request_id=ln_request_id3;
    EXCEPTION
    WHEN OTHERS THEN
      NULL;
    END;
    IF l_out_request IS NOT NULL and p_doc_printer is not null THEN
      ln_request_id4 := fnd_request.submit_request ( 'HAEMO' -- Application
      , 'XXHA_DLV_SEPARATOR'                                 -- Program
      , NULL                                                 -- Description
      , NULL                                                 -- Start Time
      , FALSE                                                -- Sub Request
      , p_doc_printer,l_out_request );
      COMMIT;
    END IF;
  END XXHA_SHIPPING_DOCS_PRC;
END XXHA_SHIPPING_DOCS_PKG;
/