create or replace PACKAGE BODY XXHA_WM_IP_BOM_EXTRACT_PKG
/*********************************************************************************************
* Package Name : XXHA_WM_IP_BOM_EXTRACT_PKG                                                  *
* Purpose      : This package provides a procedure to launch the XXHA: IP BOM Extract        *
*                Concurrent Request                                                          *
*                                                                                            *
* Used By      : webMethods Free Trade Agreement interface                                   *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        22-SEP-2017     E. Rossing           Initial Package Creation                   *
*                                                                                            *
*********************************************************************************************/
AS
PROCEDURE WM_CALL_IP_BOM_EXTRACT( p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg  OUT VARCHAR
			    ) 
IS
    v_program                   VARCHAR2(20):='XXHA_IP_BOM_EXTRACT'; -- XXHA: IP BOM Extract
    v_application               VARCHAR2(20):='HAEMO'; -- Application
    v_application_id            NUMBER;
    v_user_id                   NUMBER;
    v_user_responsibility_id    NUMBER;
    v_dev_status                VARCHAR2(80);
    v_message                   VARCHAR2(200);

BEGIN

      -- Fetch Application id for AP Application
      v_errmsg:='Fetching Application Id';

      SELECT application_id
      INTO   v_application_id
      FROM   fnd_responsibility_tl
      WHERE  responsibility_name = p_user_responsibility
      and language='US';

      -- Fetch the User Id
      v_errmsg:='Fetching User Id';

      v_user_id:=wm_conc_request_pkg.get_user_id(p_user);

      -- Fetch the Responsibility Id
      v_errmsg:='Fetching Responsibility Id for ' || p_user_responsibility;

      v_user_responsibility_id:=wm_conc_request_pkg.get_user_responsibility_id(p_user_responsibility);

      v_errmsg:='Calling request';

 	  --- Call to Initialize Session Variables

	  Fnd_Global.apps_initialize(v_user_id,v_user_responsibility_id,v_application_id);


	  -- Call to submit request

	  v_request_id := Fnd_Request.submit_request( v_application,
			  					  v_program,
			  					  NULL,
			  					  sysdate,
			  					  FALSE);

	COMMIT;

	IF v_request_id <>0 THEN

		WM_CONC_REQUEST_PKG.CHECK_CONC_PROG_STATUS(v_request_id,10,v_dev_status,	v_message, v_errmsg);

      	v_status := v_dev_status;

		o_message := v_message;
	ELSE
		v_status := 'FAILED';
	END IF;
    
EXCEPTION
 WHEN OTHERS THEN
 v_errmsg:=v_errmsg||SQLERRM||NVL(userenv('LANG'),'NOLANG');
 v_status:='FAILED';

END WM_CALL_IP_BOM_EXTRACT;

END XXHA_WM_IP_BOM_EXTRACT_PKG;