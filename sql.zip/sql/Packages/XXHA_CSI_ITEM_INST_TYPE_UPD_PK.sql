CREATE OR REPLACE PACKAGE        "XXHA_CSI_ITEM_INST_TYPE_UPD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_CSI_ITEM_INST_TYPE_UPD_PK                            |
-- | Description  : During conversion of CSI_ITEM_INSTANCES, Item Instance    |
-- |                Type was derived thru the lookups                         |
-- |                (type=HAE_CSI_INST_TYPE_CONV) based on the ownership of   |
-- |                                                                          |
-- |                For whatever reason ... a new Instance Type needs to be   |
-- |                assigned under the following conditions:                  |
-- |                 . item number is '06002-110-NA' or '06002-CP-110'        |
-- |                 . owning customer is classed as PLASMA                   |
-- |                 . current instance type is BUS_POT                       |
-- |                 . location of item is a ShipTo site in the US operating  |
-- |                    unit                                                  |
-- |                                                                          |
-- |                The new Instance Type will be USE_PLAN                    |
-- |                                                                          |
-- | Invoked by   : Concurrent program XXHA_CSI_ITEM_INST_TYPE_UPD            |
-- |                                                                          |
-- | COMMENT      : *** Intended as a one-time only process                   |
-- |                                                                          |
-- |History:                                                                  |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  02-Oct-07   OCS            Initial release                           |
-- +==========================================================================+
as

---------------------------------------------------------------
-- Main executable routine for drivng the Customer Salesrep Update
---------------------------------------------------------------
procedure main (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_instance_id  in  number -- instance_id used for testing only
        ,p_mode  in  varchar2  -- R(report only), U(pdate)
        ,p_debug  in  varchar2  -- Y(es), N(o)
        );

end XXHA_CSI_ITEM_INST_TYPE_UPD_PK;

/


CREATE OR REPLACE PACKAGE BODY        "XXHA_CSI_ITEM_INST_TYPE_UPD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_CSI_ITEM_INST_TYPE_UPD_PK                            |
-- | Description  : This package uses seeded API to update the Instance Type  |
-- |                of converted Item Instances in Customer Install Base.     |
-- |                Refer to package spec for a more complete description.    |
-- |                                                                          |
-- | Invoked by   : Concurrent executable XXHA_CSI_ITEM_INST_TYPE_UPD         |
-- |                                                                          |
-- | COMMENT      : *** Intended as a one-time only process                   |
-- |                                                                          |
-- |                                                                          |
-- |History:                                                                  |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  02-Oct-07   OCS            Initial release                           |
-- +==========================================================================+
as

-------------------------------------
-- Global Variables Declaration
-------------------------------------
e_trxtype  exception;
e_abort  exception;
e_skip  exception;

gd_today  date := sysdate;
gc_program_name  varchar2(50) := 'XXHA_CSI_ITEM_INST_TYPE_UPD';                -- Program Name In parameter for launch_error_prc procedure
gn_org_id_US  number := 102;                                                   -- ORG_ID for US operating unit
gc_trans_type_IBUI  csi_txn_types.source_transaction_type%TYPE :='IB_UI';      -- Installed Base User Interface
gc_appln_short_name_CSI  fnd_application.application_short_name%type :='CSI';  -- Variable to store Application Short Name
gn_version_nbr  number := 1;                                                -- version number of new transaction

gc_debug_flag  varchar2(1);                                  -- Debug_flag for display debug
gc_log_msg  varchar2(1000);                                  -- Log_msg to display msgs
gc_api_status  varchar2(20);
gn_cnt_read  number := 0;
gn_cnt_skip  number := 0;
gn_cnt_nochng  number := 0;
gn_cnt_tries  number := 0;
gn_cnt_ok  number := 0;
gn_cnt_notok  number := 0;
gc_error_msg  xxha_common_errors.error_msg%type;

-- fetches relevant customer profile info
cursor gcu_ii (
           q_instance_id  number
          ) is
select  cii.instance_id
       ,cii.object_version_number
       ,msi.segment1  item_number
       ,nvl(cii.instance_type_code,'null')  instance_type_code
       ,substr(hp.party_name,1,80) party_name
       ,hcsu.site_use_code
from    csi_item_instances  cii
       ,mtl_system_items_b  msi
       ,hz_parties  hp
       ,hz_cust_accounts  hca
       ,hz_cust_site_uses_all  hcsu
       ,hz_cust_acct_sites_all  hcas
where   1=1
and     cii.instance_id = nvl(q_instance_id,cii.instance_id)
and     msi.inventory_item_id = cii.inventory_item_id
and     msi.organization_id = cii.inv_master_organization_id
and     msi.segment1 in ('06002-110-NA','06002-CP-110')
and     hp.party_id = cii.owner_party_id
and     hca.party_id = cii.owner_party_id
and     hca.customer_class_code = 'PLASMA'
and     cii.location_type_code = 'HZ_PARTY_SITES'
and     hcas.party_site_id = cii.location_id
and     hcsu.cust_acct_site_id = hcas.cust_acct_site_id
and     hcsu.org_id = gn_org_id_US;

gr_ii_rec  gcu_ii%rowtype;

---------------------------------------------------------------
-- Main driver routine for processing customer profile with aim
-- of updating the salesrep info.
---------------------------------------------------------------
procedure MAIN (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_instance_id  in  number -- instance_id used for testing only
        ,p_mode  in  varchar2  -- R(report only), U(pdate)
        ,p_debug  in  varchar2  -- Y(es), N(o)
        ) is

  --------------------------
  -- Record Type Declaration
  -------------------------
  lr_instance_rec           csi_datastructures_pub.instance_rec;              --Record to hold the attributes of an item instance
  lr_ext_attrib_values_tbl  csi_datastructures_pub.extend_attrib_values_tbl;  --Record to hold the values of an item instances extended attributes.
  lr_party_tbl              csi_datastructures_pub.party_tbl;                 --Record to hold information about an instance-party relationship
  lr_account_tbl            csi_datastructures_pub.party_account_tbl;         --Record to hold information about a party-account relationship.
  lr_pricing_attrib_tbl     csi_datastructures_pub.pricing_attribs_tbl;       --Record to hold the pricing attributes of an item instance.
  lr_org_assignments_tbl    csi_datastructures_pub.organization_units_tbl;    --Record to hold information about an instance-org association
  lr_asset_assignment_tbl   csi_datastructures_pub.instance_asset_tbl;        --Record to hold information about instance-asset association.
  lr_transaction_rec        csi_datastructures_pub.transaction_rec;           --Record to hold the attributes of an Installed Base  transaction.
  lr_miss_party_tbl         csi_datastructures_pub.party_tbl;                 --Record to hold Null information about an instance-party relationship
  lr_miss_account_tbl       csi_datastructures_pub.party_account_tbl;         --Record to hold Null information about a party-account relationship.
  lr_instance_id_lst        csi_datastructures_pub.id_tbl;                    --TABLE OF NUMBER INDEX BY BINARY_INTEGER;

  -----------------------------
  -- Local Variable Declaration
  -----------------------------
  lc_init_msg_list            VARCHAR2(240);  --Variable to get error message given by api
  ln_validation_level         NUMBER;         --Variable for validation level
  ln_transaction_type_id      number;

  -- common return variables
  ln_count  number;
  lc_data  varchar2(4000);

  -- local variables
  lc_err_code  varchar2(30);
  lc_err_msg  varchar2(1000);

  -- local plsql table to capture records where salesrep is already assigned, but derives salesrep
  -- No Sales Credit; in this case, the salesrep will not be updated, but will be reported
  type nochngRec is record (
           instance_id  number
          ,instance_type_code  varchar2(30)
          ,site_use_code  varchar2(30)
          ,party_name  varchar2(80)
          );
  type nochngTabType is table of nochngRec index by binary_integer;
  nochngTab  nochngTabType;
  i  binary_integer := 0;

  e_mode  exception;

begin
  gc_debug_flag := p_debug;          -- Debug Flag
  gc_log_msg  :='Start of MAIN ...'; -- Indicator to show start of Validation Procedure
  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

  if (p_mode = 'R') then
     fnd_file.put_line(fnd_file.output,'Executing in REPORT ONLY mode - no changes will be saved');
     fnd_file.put_line(fnd_file.output,'========================================================');
  elsif (p_mode = 'U') then
     fnd_file.put_line(fnd_file.output,'Executing in UPDATE mode - changes will be saved');
     fnd_file.put_line(fnd_file.output,'================================================');
  else
     lc_err_msg := 'Execution mode not recognized.  Valid modes are R (Report Only) and U (Update)';
     raise e_mode;
  end if;
  fnd_file.put_line(fnd_file.output,' ');

  begin
    select  ctt.transaction_type_id
    into    ln_transaction_type_id
    from    csi_txn_types  ctt
           ,fnd_application  fa
    where   fa.application_short_name = gc_appln_short_name_CSI
    and     ctt.source_application_id = fa.application_id
    and     ctt.source_transaction_type = gc_trans_type_IBUI;
  exception
    when others then
       lc_err_msg := 'Cannot get TRX Type ID for '||gc_trans_type_IBUI;
       raise e_trxtype;
  end;

  ------------------------------------------------------------------------------
  -- Loop thru item instance records
  ------------------------------------------------------------------------------
  for x_ii_rec in gcu_ii (p_instance_id)
  loop
     gn_cnt_read := gn_cnt_read + 1;

     lc_err_code := null;
     lc_err_msg := null;

     gr_ii_rec := x_ii_rec;

     gc_log_msg  :='Processing .. InstId='||gr_ii_rec.instance_id||' OVN='||gr_ii_rec.object_version_number
                           ||' InstTypCd='||gr_ii_rec.instance_type_code
                               ||' Owner='||gr_ii_rec.party_name||' SiteUse'||gr_ii_rec.site_use_code;
     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

     -- does item instance qualify?
     if (    gr_ii_rec.instance_type_code = 'BUS_POT'
         and gr_ii_rec.site_use_code = 'SHIP_TO'
        ) then

        -- running in update mode?
        if (p_mode = 'U') then
           gn_cnt_tries := gn_cnt_tries + 1;

           -- prepare for item instance update
           lr_instance_rec.instance_id := gr_ii_rec.instance_id;
           lr_instance_rec.object_version_number := gr_ii_rec.object_version_number;
           lr_instance_rec.instance_type_code := 'USE_PLAN';

           -- prepare trx rec
           lr_transaction_rec.transaction_date  := gd_today;
           lr_transaction_rec.source_transaction_date := gd_today;
           lr_transaction_rec.transaction_type_id := ln_transaction_type_id;
           lr_transaction_rec.object_version_number := gn_version_nbr;

           -- invoke update API
           fnd_msg_pub.Initialize;
           csi_item_instance_pub.update_item_instance(
                                 p_api_version => 1.0
                                ,p_commit => fnd_api.g_false
                                ,p_init_msg_list => lc_init_msg_list
                                ,p_validation_level => ln_validation_level
                                ,p_instance_rec => lr_instance_rec
                                ,p_ext_attrib_values_tbl => lr_ext_attrib_values_tbl
                                ,p_party_tbl => lr_party_tbl
                                ,p_account_tbl => lr_account_tbl
                                ,p_pricing_attrib_tbl => lr_pricing_attrib_tbl
                                ,p_org_assignments_tbl => lr_org_assignments_tbl
                                ,p_asset_assignment_tbl => lr_asset_assignment_tbl
                                ,p_txn_rec => lr_transaction_rec
                                ,x_instance_id_lst => lr_instance_id_lst
                                ,x_return_status => gc_api_status
                                ,x_msg_count => ln_count
                                ,x_msg_data => lc_data
                                );

           if (gc_api_status = FND_API.G_RET_STS_SUCCESS) then
              gn_cnt_ok := gn_cnt_ok + 1;
              commit;
           else
              -- must be an error ...
              gn_cnt_notok := gn_cnt_notok + 1;

              fnd_file.put_line(fnd_file.log
                      ,'Inst ID: '||gr_ii_rec.instance_id ||'  Error in API  csi_item_instance_pub.UPDATE_ITEM_INSTANCE'
                      );
              if (ln_count >= 1) THEN
                 for i in 1..ln_count
                 loop
                    gc_error_msg := SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                    fnd_file.put_line(fnd_file.log,gc_error_msg);
                 end loop;
              end if;
              rollback;
           end if;

        end if;  -- update is U

     else  -- record does not qualify
        -- buffer for No Change reporting

        gn_cnt_nochng := gn_cnt_nochng + 1;

        i := i + 1;
        nochngTab(i).instance_id := gr_ii_rec.instance_id;
        nochngTab(i).instance_type_code := gr_ii_rec.instance_type_code;
        nochngTab(i).site_use_code := gr_ii_rec.site_use_code;
        nochngTab(i).party_name := gr_ii_rec.party_name;

     end if;

  end loop;

  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,'These item instances were not updated');
  fnd_file.put_line(fnd_file.output,'  -- Review Instance Type and/or Site Use');
  fnd_file.put_line(fnd_file.output,'-------------------------------------------------------');
  if (nochngTab.count < 1) then
     fnd_file.put_line(fnd_file.output,'**** List is empty ****');
  else
     for j in nochngTab.first..nochngTab.last
     loop
        fnd_file.put_line(fnd_file.output
                ,'InstId/InstType/SiteUse/Owner: '||nochngTab(j).instance_id||' / '||nochngTab(j).instance_type_code
                                              ||' / '||nochngTab(j).site_use_code||' / '||nochngTab(j).party_name
                );
     end loop;
  end if;

  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,'***************************************');
  fnd_file.put_line(fnd_file.output,'Statistics for Instance Type Update');
  fnd_file.put_line(fnd_file.output,'***************************************');
  fnd_file.put_line(fnd_file.output,'Records Read               :  ' ||gn_cnt_read);
  fnd_file.put_line(fnd_file.output,'Records Unchanged          :  ' ||gn_cnt_nochng);
  fnd_file.put_line(fnd_file.output,'Number of Updates          :  ' ||gn_cnt_tries);
  fnd_file.put_line(fnd_file.output,'Successful Updates         :  ' ||gn_cnt_ok);
  fnd_file.put_line(fnd_file.output,'Failed Updates             :  ' ||gn_cnt_notok);
  fnd_file.put_line(fnd_file.output,'----------');
  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,'See log for Update Failures');

  if (gn_cnt_notok > 0) then
     p_retcode := 1;
  end if;

exception
  when e_abort then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,'Below is a summary of processing prior to termination');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'These item instances were not updated');
     fnd_file.put_line(fnd_file.output,'  -- Review Instance Type and/or Site Use');
     fnd_file.put_line(fnd_file.output,'-------------------------------------------------------');
     if (nochngTab.count < 0) then
        fnd_file.put_line(fnd_file.output,'**** List is empty ****');
     else
        for j in nochngTab.first..nochngTab.last
        loop
           fnd_file.put_line(fnd_file.output
                   ,'InstId/InstType/SiteUse/Owner: '||nochngTab(j).instance_id||' / '||nochngTab(j).instance_type_code
                                                 ||' / '||nochngTab(j).site_use_code||' / '||nochngTab(j).party_name
                   );
        end loop;
     end if;

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'***************************************');
     fnd_file.put_line(fnd_file.output,'Statistics for Instance Type Update');
     fnd_file.put_line(fnd_file.output,'***************************************');
     fnd_file.put_line(fnd_file.output,'Records Read               :  ' ||gn_cnt_read);
     fnd_file.put_line(fnd_file.output,'Records Unchanged          :  ' ||gn_cnt_nochng);
     fnd_file.put_line(fnd_file.output,'Number of Updates          :  ' ||gn_cnt_tries);
     fnd_file.put_line(fnd_file.output,'Successful Updates         :  ' ||gn_cnt_ok);
     fnd_file.put_line(fnd_file.output,'Failed Updates             :  ' ||gn_cnt_notok);
     fnd_file.put_line(fnd_file.output,'----------');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'See log for Update Failures');
  when e_mode then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'No records processed');
  when e_trxtype then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'No records processed');
  when others then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,'Error in XXHA_AR_CUST_SLSREP_UPD_PK.MAIN ' ||SQLERRM);
end MAIN;

end XXHA_CSI_ITEM_INST_TYPE_UPD_PK;

/
