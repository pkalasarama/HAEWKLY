CREATE OR REPLACE package XXHA_SPRVSR_N_APPRVL_LMT AS

  -- Author  : SVOVK
  -- Created : 3/20/2013 10:50:27 AM
  -- Purpose :

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;

  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;
  procedure get_autdit_table(ERRBUF OUT VARCHAR2, RETCODE OUT NUMBER, p_uid in number);
end XXHA_SPRVSR_N_APPRVL_LMT;

/


CREATE OR REPLACE PACKAGE BODY XXHA_SPRVSR_N_APPRVL_LMT AS
--+=======================================================================+
--|               Data Intensity, Inc.                                    |
--|           22 Crosby Drive, Suite 100    Bedford, MA 01730             |
--+=======================================================================+
--|                                                                       |
--| DESCRIPTION                                                           |
--|     Package builds HR hierarchy from requested person up to BOD and   |
--|prints Name,Default Expense Account Job Code and Approval limits for   |
--|each employee (Approval                                                |
--|limits for each operating unit for which every job has some approval   |
--|limit for Purchase Requisition).                                       |
--|                                                                       |
--| PROCEDURE LIST                                                        |
--|     get_audit_table                                                   |
--| HISTORY                                                               |
--|   April 2013 svovk        Created                                     |
--|   April 2013 ngrigoriev   Modified                                    |
--+======================================================================*/
  procedure get_autdit_table(ERRBUF OUT VARCHAR2,
                             RETCODE OUT NUMBER,
                             p_uid  in number) is
    v_xmldoc      CLOB;
    v_buffer      VARCHAR2(32000);
    v_amount      NUMBER := 10;
    v_offset      NUMBER := 1;
    v_sql_text    DBMS_XMLGEN.ctxHandle;
    v_start_pos   number := 0;
    v_index       number := 0;
    v_string      varchar2(32767);
    v_read_length number := 480;
    V_SQL         sys_refcursor;
  BEGIN
    ERRBUF  := 'OK';
    RETCODE := 0;
    fnd_file.put_line(FND_FILE.LOG,
                      'User id=' || p_uid);

    Open V_SQL for '
select
cursor (select full_name,
gc.SEGMENT1||''.''||gc.SEGMENT2||''.''||gc.SEGMENT3||''.''||gc.SEGMENT4||''.''||gc.SEGMENT5||''.''||gc.SEGMENT6||''.''||gc.SEGMENT7||''.''||gc.SEGMENT8||''.''||gc.SEGMENT9 DEF_ACC_CODE
from per_people_f pp, per_assignments_f pa, GL_CODE_COMBINATIONS GC
where pp.person_id = :user_id
and (sysdate between  pp.effective_start_date and pp.effective_end_date)
and (sysdate between pa.effective_start_date and pa.effective_end_date)
and pa.person_id = pp.person_id
and pa.default_code_comb_id = GC.CODE_COMBINATION_ID(+)) INPUT,
cursor (
select perhie.person_id, -- this select return only full hierarchies
       perhie.full_name,
       perhie.job_name,
       perhie.amount_limit,
       perhie.org_id,
       perhie.lvl,
       perhie.DEF_ACC_CODE,
       hou.name ||'' (''|| gsob.currency_code||'')'' as name

  from (select perhie.person_id, -- this select catch amount_limit for selected job_ids for which exists ''Purchase Req'' rules (for org_ids)
               perhie.business_group_id,
               perhie.full_name,
               perhie.supervisor_id,
               perhie.job_id,
               perhie.organization_id,
               perhie.job_name,
               perhie.lvl,
               ppca.org_id,
               pcf.enabled_flag,
               pcr.amount_limit,
               perhie.DEF_ACC_CODE,
               count(distinct lvl) over(partition by ppca.org_id) as cntlvlorg,
               maxlvlpid
          from (select perhie.person_id, -- this one builds hierarchy from some person up to BOD and writes job_ids
                       perhie.business_group_id,
                       perhie.full_name,
                       perhie.supervisor_id,
                       perhie.job_id,
                       perhie.organization_id,
                       job.name as job_name,
                       perhie.DEF_ACC_CODE,
                       level lvl,
                       max(level) over() as maxlvlpid
                  from (select pp.person_id, -- this select returns current state of positions
                               pp.business_group_id,
                               pp.full_name,
                               pa.supervisor_id,
                               pa.job_id,
                               pa.organization_id,
                               gc.SEGMENT1||''.''||gc.SEGMENT2||''.''||gc.SEGMENT3||''.''||gc.SEGMENT4||''.''||gc.SEGMENT5||''.''||gc.SEGMENT6||''.''||gc.SEGMENT7||''.''||gc.SEGMENT8||''.''||gc.SEGMENT9 DEF_ACC_CODE
                          from per_assignments_f pa, per_people_f pp, GL_CODE_COMBINATIONS GC
                         where 1 = 1
                           and pa.person_id = pp.person_id
                           and pa.business_group_id = pp.business_group_id
                           and sysdate between pp.effective_start_date and
                               pp.effective_end_date
                           and sysdate between pa.effective_start_date and
                               pa.effective_end_date
                           and pa.default_code_comb_id = GC.CODE_COMBINATION_ID(+)) perhie,
                       PER_JOBS job
                 where perhie.job_id = job.job_id
                 --start with full_name
                 start with person_id = :user_id
                connect by prior supervisor_id = person_id) perhie,
               PO_POSITION_CONTROLS_ALL ppca,
               po_control_rules pcr,
               po_control_functions pcf

         where ppca.JOB_ID = perhie.job_id
              --and ppca.org_id = perhie.organization_id
           and ppca.control_group_id = pcr.control_group_id
           and ppca.control_function_id = pcf.control_function_id
           and pcf.enabled_flag = ''Y'' --enabled
           and pcf.CONTROL_FUNCTION_NAME = ''Approve Purchase Requisitions'' ---- THIS MAKES THE QUERY FOR PURCHASE REQUISITION APPROVALS
           and pcr.object_code = ''DOCUMENT_TOTAL'') perhie,
       hr_operating_units hou,
       gl_sets_of_books gsob
 where 1 = 1
   and perhie.cntlvlorg = perhie.maxlvlpid --hierarchy is full
   and hou.organization_id = perhie.org_id
   and hou.set_of_books_id = gsob.set_of_books_id
   and perhie.lvl > 1
) XXHASALR from dual'
      using p_uid, p_uid;

    v_sql_text := dbms_xmlgen.newContext(V_SQL);
    dbms_xmlgen.setNullHandling(v_sql_text, dbms_xmlgen.NULL_ATTR);

    v_xmldoc := dbms_xmlgen.getxml(v_sql_text);
    v_amount := dbms_lob.getlength(v_xmldoc);

    if v_amount > 1 then
      while v_start_pos <= v_amount loop
        v_index     := v_index + 1;
        v_string    := dbms_lob.substr(v_xmldoc,
                                       v_read_length,
                                       v_start_pos + 1);
        v_start_pos := v_start_pos + v_read_length;
        fnd_file.put(FND_FILE.OUTPUT, v_string);
      end loop;
    else
      SELECT dbms_xmlgen.newContext('SELECT ''Report Output was blank for the given criteria'' nodatafound DATA FROM dual')
        INTO v_sql_text
        FROM DUAL;
      v_xmldoc := dbms_xmlgen.getxml(v_sql_text);
      v_amount := dbms_lob.getlength(v_xmldoc);
      dbms_lob.read(v_xmldoc, v_amount, v_offset, v_buffer);
      fnd_file.put(FND_FILE.OUTPUT, v_buffer);
    end if;

  EXCEPTION
    when others then
      dbms_xmlgen.closeContext(v_sql_text);
      errbuf  := sqlerrm;
      retcode := sqlcode;
      raise;
  end;
END XXHA_SPRVSR_N_APPRVL_LMT;

/
