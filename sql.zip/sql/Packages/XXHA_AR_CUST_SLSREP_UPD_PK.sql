CREATE OR REPLACE PACKAGE        "XXHA_AR_CUST_SLSREP_UPD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_AR_CUST_SLSREP_UPD_PK                                |
-- | Description  : The Customer Salesrep updates the Salesrep info on the    |
-- |                customer SHIP_TO site use profile.  This update is        |
-- |                applicable for US operating unit only (ORG_ID=102).       |
-- |                                                                          |
-- |                The salerep is typically based on the plan type/zip       |
-- |                combination.  Plan type is based on the customer class.   |
-- |                Zip comes of the address postal code.                     |
-- |                                                                          |
-- |                Override exceptions apply when the site use is flagged    |
-- |                with USBPCS Override code.  In these cases the salesrep   |
-- |                is based on the plan type/override code combination.      |
-- |                A BillTo override (if it is registered) takes precedence  |
-- |                over a ShipTo override.                                   |
-- |                                                                          |
-- |                The default value 'No Sales Credit' applies if the        |
-- |                Salesrep cannot be determined.                            |
-- |                                                                          |
-- | Invoked by   : Concurrent program XXHA_CUST_SLSREP_UPD                   |
-- |                                                                          |
-- |History:                                                            |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  20-Sep-07   OCS            Initial release                           |
-- +==========================================================================+
as

---------------------------------------------------------------
-- Main executable routine for drivng the Customer Salesrep Update
---------------------------------------------------------------
procedure main (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_customer_name  in  varchar2  -- customer name used for testing only
        ,p_mode  in  varchar2  -- R(report only), U(pdate)
        ,p_debug  in  varchar2  -- Y(es), N(o)
        );

end XXHA_AR_CUST_SLSREP_UPD_PK;

/


CREATE OR REPLACE PACKAGE BODY        "XXHA_AR_CUST_SLSREP_UPD_PK"
-- +==========================================================================+
-- |                             Oracle Cosulting                             |
-- +==========================================================================+
-- | Name         : XXHA_AR_CUST_SLSREP_UPD_PK                                |
-- | Description  : This package updates the salesrep info on customer        |
-- |                site use profiles.  Refer to package spec for a more      |
-- |                complete description.                                     |
-- |                                                                          |
-- | Note         : This is applicable to the US operating unit only          |
-- |                                                                          |
-- | Invoked by   : Concurrent executable XXHA_CUST_SLSREP_UPD                |
-- |                                                                          |
-- |History:                                                            |
-- |===============                                                           |
-- |Ver  Date        Author         Remarks                                   |
-- |===  ==========  =============  ==========================================|
-- |1.0  20-Sep-07   OCS            Initial release                           |
-- +==========================================================================+
as

-------------------------------------
-- Global Variables Declaration
-------------------------------------
e_abort  exception;
e_nsc  exception;
e_skip  exception;

gd_today  date := sysdate;
gc_program_name  varchar2(50) := 'XXHA_AR_CUST_SLSREP_UPD';  -- Program Name In parameter for launch_error_prc procedure
gn_org_id_US  number := 102;                                 -- ORG_ID for US operating unit
gn_salesrep_id_NSC  number;                                  -- Salesrep ID for No Sales Credit
gn_salesrep_name_NSC  varchar2(30) := 'No Sales Credit';     -- Salesrep Name for No Sales Credit
gc_debug_flag  varchar2(1);                                  -- Debug_flag for display debug
gc_log_msg  varchar2(1000);                                  -- Log_msg to display msgs
gc_api_status  varchar2(20);
gn_cnt_read  number := 0;
gn_cnt_skip  number := 0;
gn_cnt_nochng  number := 0;
gn_cnt_tries  number := 0;
gn_cnt_ok  number := 0;
gn_cnt_notok  number := 0;
gn_cnt_nsc  number := 0;
gc_error_msg  xxha_common_errors.error_msg%type;

-- fetches relevant customer profile info
cursor gcu_prf (
           q_customer_name  varchar2
          ) is
  select  ca.account_number  customer_number
         ,ca.customer_class_code
         ,p.party_name  customer_name
         ,lcc.meaning  customer_class
         ,csu.site_use_id
         ,csu.primary_flag
         ,csu.status
         ,csu.attribute1  usbpcs_override
         ,csu.primary_salesrep_id
         ,sr.name  primary_salesrep_name
         ,csu.cust_acct_site_id  address_id
         ,csu.site_use_code
         ,csu.object_version_number
         ,csu.org_id
         ,l.address1
         ,l.address2
         ,l.postal_code  zip
         ,l.country
  from    hz_cust_site_uses_all  csu
         ,hz_cust_acct_sites_all  cas
         ,hz_party_sites  ps
         ,hz_locations  l
         ,hz_cust_accounts  ca
         ,hz_parties  p
         ,ar_lookups  lcc  -- customer class
         ,ra_salesreps_all  sr
  where   1=1
  and     p.party_name = nvl(q_customer_name,p.party_name)
--and p.party_name in ('ARC','Advanced Perfusion Care','Heartland Blood Center','Blood Systems Inc')
  and     csu.site_use_code in ('SHIP_TO')
  and     csu.org_id = gn_org_id_US
  and     csu.attribute1 is not null
  and     cas.cust_acct_site_id = csu.cust_acct_site_id
  and     ps.party_site_id = cas.party_site_id
  and     l.location_id = ps.location_id
  and     ca.cust_account_id = cas.cust_account_id
  and     p.party_id = ca.party_id
  and     lcc.lookup_type(+) = 'CUSTOMER CLASS'
  and     lcc.lookup_code(+) = ca.customer_class_code
  and     sr.salesrep_id(+) = csu.primary_salesrep_id
  and     sr.org_id(+) = gn_org_id_US;

gr_prf_rec  gcu_prf%rowtype;

--+=============================================================================+
--| Name        :   SET_SALESREP_ID_NSC                                         |
--|                                                                             |
--| Description :   Procedure to set the value for 'No Sales Credit' salesrep   |
--|                                                                             |
--+=============================================================================+
procedure SET_SALESREP_ID_NSC (
          x_err_code  out  varchar2
         ,x_err_msg  out  varchar2
         )
is
begin
   select  rs.salesrep_id
   into    gn_salesrep_id_NSC
   from    ra_salesreps_all  rs
   where   rs.name = gn_salesrep_name_NSC
   and     rs.org_id = gn_org_id_US
   and     rs.end_date_active is null;

exception
   when too_many_rows then
      x_err_code := 'CUST10';
      x_err_msg  := 'SalesRep Derivation returned multiple rows for '||gn_salesrep_name_NSC;
      raise e_nsc;
   when no_data_found then
      x_err_code := 'CUST10';
      x_err_msg  := 'SalesRep Derivation returned no rows for '||gn_salesrep_name_NSC;
      raise e_nsc;
   when others then
      x_err_code := 'CUST10';
      x_err_msg  := 'SalesRep Derivation errored for '||gn_salesrep_name_NSC||' : '||sqlerrm;
      raise e_nsc;

end SET_SALESREP_ID_NSC;

--+=============================================================================+
--| Name        :   DERIVE_SALESREP                                             |
--|                                                                             |
--| Description :   Procedure to derive salesrep                                |
--|                                                                             |
--+=============================================================================+
procedure DERIVE_SALESREP (
          p_org_id  in  number
         ,p_customer_name  in  varchar2
         ,p_customer_class  in  varchar2
         ,p_address1  in  varchar2
         ,p_address2  in  varchar2
         ,p_usbpcs_override  in  varchar2
         ,p_site_use_code  in  varchar2
         ,p_zip  in  varchar2
         ,p_country  in  varchar2
         ,p_primary_salesrep_id  in  number
         ,x_salesrep_id  out  number
         ,x_salesrep_name  out  varchar2
         ,x_err_code  out  varchar2
         ,x_err_msg  out  varchar2
         )
is
   lc_nsc_reason  varchar2(100) := null;  -- reason for No Sales Credit salesrep
   lc_plan_type  varchar2(30) := null;
   lc_override_code_billto  varchar2(30) := null;
   lc_override_code_shipto  varchar2(30) := null;
   lc_salesrep  varchar2(100) := null;
   lc_ora_salesrep  varchar2(100) := null;
   ln_salesrep_id  number := 0;

begin
   ---------------------------------------------------------------------------
   -- Check for customer class in usbpcs_plantype_xref
   ---------------------------------------------------------------------------
   if (p_customer_class is null) then
      lc_nsc_reason := 'Class: '||'NULL';
      raise e_nsc;
   end if;

   begin
      select  upx.bpcs_plantype
      into    lc_plan_type
      from    usbpcs_plantype_xref  upx
      where   upx.ora_customer_class = p_customer_class;

      gc_log_msg:='For customer class '||p_customer_class||' plan type returned is '||lc_plan_type;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   exception
      when others then
         lc_nsc_reason := 'Class: '||p_customer_class;
         raise e_nsc;
   end;

   ---------------------------------------------------------------------------
   -- Check for Salesrep override
   ---------------------------------------------------------------------------

   -- is there a USBPCS override defined?
   if (p_usbpcs_override is not null) then

      -- yes, so build override codes to check for plan type/override combination
      lc_override_code_billto := lc_plan_type||':'||substr(p_usbpcs_override,1,12)||'0000';
      lc_override_code_shipto := lc_plan_type||':'||p_usbpcs_override;
      gc_log_msg:='Override code for BILL_TO is '||lc_override_code_billto;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      gc_log_msg:='Override code for SHIP_TO is '||lc_override_code_shipto;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      -- search with BILL_TO first
      begin
         select  description  salesrep
         into    lc_salesrep
         from    fnd_lookup_values_vl
         where   lookup_type = 'HAE_CUST_SLSREP_OVERRIDE'
         and     lookup_code = lc_override_code_billto
         and     enabled_flag = 'Y'
         and     gd_today between nvl(start_date_active,gd_today)
                              and nvl(end_date_active,gd_today);

         gc_log_msg:='BILL_TO search returned salesrep code '||lc_salesrep;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         if (lc_salesrep is null) then
            -- found, but salesrep not specified
            lc_nsc_reason := 'PlanType/BillTo Override: '||lc_override_code_billto;
            raise e_nsc;
         end if;

      exception
         when no_data_found then
            -- no salesrep found with BILL_TO, so search with SHIP_TO

            begin
               select  description  salesrep
               into    lc_salesrep
               from    fnd_lookup_values_vl
               where   lookup_type = 'HAE_CUST_SLSREP_OVERRIDE'
               and     lookup_code = lc_override_code_shipto
               and     enabled_flag = 'Y'
               and     gd_today between nvl(start_date_active,gd_today)
                                    and nvl(end_date_active,gd_today);

               gc_log_msg:='SHIP_TO search returned salesrep code '||lc_salesrep;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               if (lc_salesrep is null) then
                  -- found, but salesrep not specified
                  lc_nsc_reason := 'PlanType/ShipTo Override: '||lc_override_code_shipto;
                  raise e_nsc;
               end if;
            exception
               when no_data_found then
                  -- no salesrep found with SHIP_TO
                  --    allow to drop thru for plan type/zip search
                  null;
               when others then
                  lc_nsc_reason := 'PlanType/ShipTo Override: '||lc_override_code_shipto;
                  raise e_nsc;
            end;
         when others then
            lc_nsc_reason := 'PlanType/BillTo Override: '||lc_override_code_billto;
            raise e_nsc;
      end;

   end if;

   -- is salesrep still unknown?
   if (lc_salesrep is null) then

      -- yes - it means ....
      --         there was no override code defined
      --     or  no match for the specific plan_type/override combination
      -- so ... derive salesrep from five_zip_territory xref table - applicable for US addresses only

      if (p_country <> 'US') then
         raise e_skip;
      end if;

      ----------------------------------------------------------------------------------------------
      -- Get Salesrep based on plan_type and zip code
      ----------------------------------------------------------------------------------------------
      begin
         select  ut.salesrep
         into    lc_salesrep
         from    haemo.five_zip_territory  ut
         where   ut.plan_type = lc_plan_type
         and     ut.zip3 = p_zip;

         gc_log_msg:='PlanType/Zip '||lc_plan_type|| '/' ||p_zip||' returned Salesrep Code '||lc_salesrep;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         if (lc_salesrep is null) then
            lc_nsc_reason := 'PlanType/Zip: '||lc_plan_type|| '/' ||p_zip;
            raise e_nsc;
         end if;

      exception
         when others then
            lc_nsc_reason := 'PlanType/Zip: '||lc_plan_type|| '/' ||p_zip;
            raise e_nsc;
      end;

   end if;

   -----------------------------------------------------
   -- Get concatenated SalesRep name for USBPCS Salesrep
   -----------------------------------------------------
   -- at this point, salesrep must be not null, else exception e_nsc would have tripped

   begin
      select  decode(usx.orc_salesrep_fname
                    ,null, usx.orc_salesrep_lname
                    ,usx.orc_salesrep_lname||', '||usx.orc_salesrep_fname)
      into    lc_ora_salesrep
      from    usbpcs_salesrep_xref   usx
      where   usx.bpcs_salesrep = lc_salesrep;

      gc_log_msg:='Salesrep code '||lc_salesrep||' matched to name '||lc_ora_salesrep;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      if (lc_ora_salesrep is null) then
         lc_nsc_reason := 'USBPCS Salesrep: '||lc_salesrep;
         raise e_nsc;
      end if;

   exception
      when others then
         lc_nsc_reason := 'USBPCS Salesrep: '||lc_salesrep;
         raise e_nsc;
   end;

   -----------------------------------------------------
   -- Get Salesrep ID based on concatenated name
   -----------------------------------------------------
   -- at this point, oracle salesrep name must be not null, else exception e_nsc would have tripped
   begin
      select  rs.salesrep_id
      into    ln_salesrep_id
      from    ra_salesreps_all  rs
      where   rs.name = lc_ora_salesrep
      and     rs.org_id = p_org_id
      and     rs.end_date_active is null;

      gc_log_msg:='Salesrep Name '||lc_ora_salesrep||' matched to ID '||ln_salesrep_id;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   exception
      when no_data_found then
         lc_nsc_reason := 'Salesrep Name: '||lc_ora_salesrep;
         raise e_nsc;
      when too_many_rows then
         lc_nsc_reason := 'Salesrep Name: '||lc_ora_salesrep;
         raise e_nsc;
      when others then
         lc_nsc_reason := 'Salesrep Name: '||lc_ora_salesrep;
         raise e_nsc;
   end;

   -- set values for outbound parameters
   x_salesrep_id :=  ln_salesrep_id;
   x_salesrep_name := lc_ora_salesrep;
   x_err_code := null;
   x_err_msg := null;

exception
   when e_nsc then
      fnd_file.put_line(fnd_file.log
                       ,'Customer: '||p_customer_name ||'  "No Sales Credit" derived ... '||lc_nsc_reason
                       );
      fnd_file.put_line(fnd_file.log
                       ,'......... '||p_address1||',  '||p_address2
                       );

      x_salesrep_id := gn_salesrep_id_NSC;
      x_salesrep_name := gn_salesrep_name_NSC;
      x_err_code := null;
      x_err_msg := null;
   when e_skip then
      x_salesrep_id := null;
      x_salesrep_name := null;
      x_err_code := null;
      x_err_msg := null;
      raise;
   when others then
      x_err_code := sqlcode;
      x_err_msg := sqlerrm;

end DERIVE_SALESREP;

---------------------------------------------------------------
-- Main driver routine for processing customer profile with aim
-- of updating the salesrep info.
---------------------------------------------------------------
procedure MAIN (
         p_errbuff  out  varchar2
        ,p_retcode  out  number
        ,p_customer_name  in  varchar2  -- customer name used for testing only
        ,p_mode  in  varchar2  -- R(report only), U(pdate)
        ,p_debug  in  varchar2  -- Y(es), N(o)
        ) is

  -- declaration for API hz_cust_account_site_v2pub.update_cust_site_use
  lr_cust_site_use_rec  hz_cust_account_site_v2pub.cust_site_use_rec_type;

  -- common return variables
  ln_count  number;
  lc_data  varchar2(4000);

  -- local variables
  ln_ovn  number;  -- object version number
  ln_salesrep_id  number;
  lc_salesrep_name  varchar2(240);
  lc_err_code  varchar2(30);
  lc_err_msg  varchar2(1000);

  -- local plsql table to capture records where salesrep is already assigned, but derives salesrep
  -- No Sales Credit; in this case, the salesrep will not be updated, but will be reported
  type keepRec is record (
           customer_name  varchar2(240)
          ,address1  varchar2(240)
          ,address2  varchar2(240)
          ,primary_salesrep_name  varchar2(240)
          );
  type keepTabType is table of keepRec index by binary_integer;
  keepTab  keepTabType;
  i  binary_integer := 0;

  e_mode  exception;

begin
  gc_debug_flag := p_debug;          -- Debug Flag
  gc_log_msg  :='Start of MAIN ...'; -- Indicator to show start of Validation Procedure
  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

  if (p_mode = 'R') then
     fnd_file.put_line(fnd_file.output,'Executing in REPORT ONLY mode - no changes will be saved');
     fnd_file.put_line(fnd_file.output,'========================================================');
  elsif (p_mode = 'U') then
     fnd_file.put_line(fnd_file.output,'Executing in UPDATE mode - changes will be saved');
     fnd_file.put_line(fnd_file.output,'================================================');
  else
     lc_err_msg := 'Execution mode not recognized.  Valid modes are R (Report Only) and U (Update)';
     raise e_mode;
  end if;
  fnd_file.put_line(fnd_file.output,' ');

  -- set the salesrep_id for 'No Sales Credit'
  set_salesrep_id_nsc(lc_err_code,lc_err_msg);

  ------------------------------------------------------------------------------
  -- Loop thru customer profile records
  ------------------------------------------------------------------------------
  for x_prf_rec in gcu_prf (p_customer_name)
  loop
     gn_cnt_read := gn_cnt_read + 1;

     ln_ovn := null;
     ln_salesrep_id := null;
     lc_salesrep_name := null;
     lc_err_code := null;
     lc_err_msg := null;

     begin
        gr_prf_rec := x_prf_rec;

        gc_log_msg  :='Processing .. '||gr_prf_rec.customer_name||' '||gr_prf_rec.customer_class
                                 ||' '||gr_prf_rec.usbpcs_override||' '||gr_prf_rec.primary_salesrep_id;
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
        gc_log_msg  :='              '||gr_prf_rec.address1||' '||gr_prf_rec.address2||'   '||gr_prf_rec.zip;
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

        derive_salesrep(
               gr_prf_rec.org_id
              ,gr_prf_rec.customer_name
              ,gr_prf_rec.customer_class
              ,gr_prf_rec.address1
              ,gr_prf_rec.address2
              ,gr_prf_rec.usbpcs_override
              ,gr_prf_rec.site_use_code
              ,gr_prf_rec.zip
              ,gr_prf_rec.country
              ,gr_prf_rec.primary_salesrep_id
              ,ln_salesrep_id
              ,lc_salesrep_name
              ,lc_err_code
              ,lc_err_msg
              );

        if (lc_err_code is not null) then
           raise e_abort;
        end if;

        if (ln_salesrep_id = gn_salesrep_id_NSC) then
           gn_cnt_nsc := gn_cnt_nsc + 1;
        end if;

        -- is derived salesrep same as current salesrep?
        if (ln_salesrep_id = nvl(gr_prf_rec.primary_salesrep_id,-1234567) ) then
           -- yes, do nothing ... update count
           gn_cnt_nochng := gn_cnt_nochng + 1;

        -- is derived salesrep 'No Sales Credit'?
        elsif (ln_salesrep_id = gn_salesrep_id_NSC) then
           -- yes, buffer for reporting, but retain assigned salesrep
           gn_cnt_nochng := gn_cnt_nochng + 1;

           i := i + 1;
           keepTab(i).customer_name := gr_prf_rec.customer_name;
           keepTab(i).address1 := gr_prf_rec.address1;
           keepTab(i).address2 := gr_prf_rec.address2;
           keepTab(i).primary_salesrep_name := gr_prf_rec.primary_salesrep_name;

        else -- different salesrep

           -- output salesrep change
           gn_cnt_tries := gn_cnt_tries + 1;
           fnd_file.put_line(fnd_file.output
                            ,        'Customer: '||gr_prf_rec.customer_name
                             ||'  Updating from '||nvl(gr_prf_rec.primary_salesrep_name,'NULL')
                                         ||' to '||lc_salesrep_name
                            );
            fnd_file.put_line(fnd_file.output
                            ,        '......... '||gr_prf_rec.address1||',  '||gr_prf_rec.address2
                            );

           -- running in update mode?
           if (p_mode = 'U') then

              -- prep for API call
              lr_cust_site_use_rec := null;
              lr_cust_site_use_rec.site_use_id := gr_prf_rec.site_use_id;
              lr_cust_site_use_rec.primary_salesrep_id := ln_salesrep_id;
              ln_ovn := gr_prf_rec.object_version_number;

              -- call API to set new value
              hz_cust_account_site_v2pub.update_cust_site_use (
                           p_init_msg_list => FND_API.G_FALSE
                          ,p_cust_site_use_rec => lr_cust_site_use_rec
                          ,p_object_version_number => ln_ovn
                          ,x_return_status => gc_api_status
                          ,x_msg_count => ln_count
                          ,x_msg_data => lc_data
                          );

              if (gc_api_status = FND_API.G_RET_STS_SUCCESS) then
                 gn_cnt_ok := gn_cnt_ok + 1;
              else
                 -- must be an error ...
                 gn_cnt_notok := gn_cnt_notok + 1;

                 fnd_file.put_line(fnd_file.log
                         ,'Customer: '||gr_prf_rec.customer_name ||'  Error in API  hz_cust_account_site_v2pub.UPDATE_CUST_SITE_USE'
                         );
                 fnd_file.put_line(fnd_file.log
                         ,'......... '||gr_prf_rec.address1||',  '||gr_prf_rec.address2
                         );
                 if (ln_count >= 1) THEN
                    for i in 1..ln_count
                    loop
                       gc_error_msg := SUBSTR(FND_MSG_PUB.GET(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                       fnd_file.put_line(fnd_file.output,gc_error_msg);
                    end loop;
                 end if;
              end if;
           end if;  -- update mode is U
        end if;

     exception
        when e_skip then
           gn_cnt_skip := gn_cnt_skip + 1;
     end;

     -- is process running in update mode?
     if (p_mode = 'U') then
        commit;
     end if;

  end loop;

  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,'-------------------------------------------------------');
  fnd_file.put_line(fnd_file.output,'These customers had derived salesrep of No Sales Credit');
  fnd_file.put_line(fnd_file.output,'      **** The assigned salesrep was retained ****');
  fnd_file.put_line(fnd_file.output,'-------------------------------------------------------');
  if (keepTab.count < 0) then
     fnd_file.put_line(fnd_file.output,'**** List is empty ****');
  else
     for j in keepTab.first..keepTab.last
     loop
        fnd_file.put_line(fnd_file.output
                ,'Customer/Salesrep: '||keepTab(j).customer_name ||'  /  '||keepTab(j).primary_salesrep_name
                );
        fnd_file.put_line(fnd_file.output
                ,'.................  '||keepTab(j).address1 ||',  '||keepTab(j).address2
                );
     end loop;
  end if;

  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,'***************************************');
  fnd_file.put_line(fnd_file.output,'Statistics for Customer Salesrep Update');
  fnd_file.put_line(fnd_file.output,'***************************************');
  fnd_file.put_line(fnd_file.output,'Records Read               :  ' ||gn_cnt_read);
  fnd_file.put_line(fnd_file.output,'Records Skipped            :  ' ||gn_cnt_skip);
  fnd_file.put_line(fnd_file.output,'Records Unchanged          :  ' ||gn_cnt_nochng);
  fnd_file.put_line(fnd_file.output,'Number of Updates          :  ' ||gn_cnt_tries);
  fnd_file.put_line(fnd_file.output,'Successful Updates         :  ' ||gn_cnt_ok);
  fnd_file.put_line(fnd_file.output,'Failed Updates             :  ' ||gn_cnt_notok);
  fnd_file.put_line(fnd_file.output,'----------');
  fnd_file.put_line(fnd_file.output,'"No Sales Credit" count    :  ' ||gn_cnt_nsc);
  fnd_file.put_line(fnd_file.output,' ');
  fnd_file.put_line(fnd_file.output,'See log for No Sales Credit assignments');


exception
  when e_abort then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,'Below is a summary of processing prior to termination');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'-------------------------------------------------------');
     fnd_file.put_line(fnd_file.output,'These customers had derived salesrep of No Sales Credit');
     fnd_file.put_line(fnd_file.output,'      **** The assigned salesrep was retained ****');
     fnd_file.put_line(fnd_file.output,'-------------------------------------------------------');
     if (keepTab.count < 0) then
        fnd_file.put_line(fnd_file.output,'**** List is empty ****');
     else
        for j in keepTab.first..keepTab.last
        loop
           fnd_file.put_line(fnd_file.output
                   ,'Customer/Salesrep: '||keepTab(j).customer_name ||'  /  '||keepTab(j).primary_salesrep_name
                   );
           fnd_file.put_line(fnd_file.output
                   ,'.................  '||keepTab(j).address1 ||',  '||keepTab(j).address2
                   );
        end loop;
     end if;

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,rpad('*',70,'*'));
     fnd_file.put_line(fnd_file.output,'Statistics for Customer Salesrep Update ');
     fnd_file.put_line(fnd_file.output,rpad('*',70,'*'));
     fnd_file.put_line(fnd_file.output,'Records Read               :  ' ||gn_cnt_read);
     fnd_file.put_line(fnd_file.output,'Records Skipped            :  ' ||gn_cnt_skip);
     fnd_file.put_line(fnd_file.output,'Records Unchanged          :  ' ||gn_cnt_nochng);
     fnd_file.put_line(fnd_file.output,'Number of Updates          :  ' ||gn_cnt_tries);
     fnd_file.put_line(fnd_file.output,'Successful Updates         :  ' ||gn_cnt_ok);
     fnd_file.put_line(fnd_file.output,'Failed Updates             :  ' ||gn_cnt_notok);
     fnd_file.put_line(fnd_file.output,'----------');
     fnd_file.put_line(fnd_file.output,'"No Sales Credit" count    :  ' ||gn_cnt_nsc);
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'See log for No Sales Credit assignments');
  when e_mode then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'No records processed');
  when e_nsc then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,lc_err_msg);

     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'*** PROCESSING ABORTED - REFER TO LOG FILE *** ');
     fnd_file.put_line(fnd_file.output,' ');
     fnd_file.put_line(fnd_file.output,'No records processed');
  when others then
     p_retcode := 2;
     fnd_file.put_line(fnd_file.log,'Error in XXHA_AR_CUST_SLSREP_UPD_PK.MAIN ' ||SQLERRM);
end MAIN;

end XXHA_AR_CUST_SLSREP_UPD_PK;

/
