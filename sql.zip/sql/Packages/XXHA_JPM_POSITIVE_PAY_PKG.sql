CREATE OR REPLACE PACKAGE      XXHA_JPM_POSITIVE_PAY_PKG  AS
--Version 1.0
/*****************************************************************************************
* Package Name : XXHA_JPM_POSITIVE_PAY_PKG                                                
* Purpose      : This procedure generates positive pay output file                      
*                	  		  					 	 						             
*                                                                                        
*                                                                                        
* 																	                     
*                                                                                        
*                                                                                        
* Tables Accessed:                                                                      
* ----------------
* Access Type (I - Insert, S - Select, U - Update, D - Delete)          
* AP_BANK_ACCOUNTS - Select
* AP_BANK_BRANCHES - Select
* AP_CHECKS        - Select 
* AP_CHECK_STOCKS  - Select
* AP_CHECKS_ALL    - Update                     
*                                                                       
* Change History:                                                                       
* ----------------                                                                                        
* Ver		Date			Author				Description                            
* ------	-----------		-----------------	---------------                        
* 1.0		07-Dec-2009		Eric Rossing		Initial Creation
* 1.1		04-Feb-2010		Eric Rossing		Added parameter p_bank_branch
* 1.2		19-May-2010		Eric Rossing		Replaced bank, branch, and account # parameters with account id parameter
* 1.3		17-Sep-2010		Eric Rossing		Added length restriction of 39 characters to vendor name, added vendor address line 1, restricted to 35 characters
* 1.4		19-Oct-2010		Eric Rossing		Added carriage return (CR) character to end of line to force CR/LF line breaks required by JPMorgan Chase's processing
*****************************************************************************************/

-- 9/17/10 - Eric Rossing - added whole_word_trim function to handle trimming for vendor name and address line 1 fields
FUNCTION whole_word_trim (
					input_string		IN	VARCHAR2
				,	max_length			IN	NUMBER
				) RETURN VARCHAR2;

PROCEDURE gen_ppay (
					errbuf				OUT	VARCHAR2
				,	retcode				OUT	VARCHAR2
--				,	p_bank_name			IN	varchar2
--				,	p_bank_branch			IN	varchar2
--				,	p_bank_acct_number	IN	varchar2
				,	p_bank_acct_id		IN	NUMBER
				,	p_check_start_date	IN	date
				,	p_check_end_date	IN	date
               ) ;

END XXHA_JPM_POSITIVE_PAY_PKG;
/


CREATE OR REPLACE PACKAGE BODY      XXHA_JPM_POSITIVE_PAY_PKG  AS
/***********************************************************************************************************************************
* Package Name : XXHA_JPM_POSITIVE_PAY_PKG
* Purpose      : This procedure generates positive pay output file
*
*
*
*
*
*
* Tables Accessed:
* ----------------
* Access Type (I - Insert, S - Select, U - Update, D - Delete)
* AP_BANK_ACCOUNTS - Select
* AP_BANK_BRANCHES - Select
* AP_CHECKS        - Select
* AP_CHECK_STOCKS  - Select
* AP_CHECKS_ALL    - Update
*
* Change History:
* ----------------
* Ver		Date			Author				Description
* ------	-----------		-----------------	---------------
* 1.0		07-Dec-2009		Eric Rossing		Initial Creation
* 1.1		04-Feb-2010		Eric Rossing		Added parameter p_bank_branch
* 1.2		19-May-2010		Eric Rossing		Replaced bank, branch, and account # parameters with account id parameter
* 1.3		17-Sep-2010		Eric Rossing		Added length restriction of 39 characters to vendor name, added vendor address line 1, restricted to 35 characters
* 1.4		19-Oct-2010		Eric Rossing		Added carriage return (CR) character to end of line to force CR/LF line breaks required by JPMorgan Chase's processing
***********************************************************************************************************************************/

-- 9/17/10 - Eric Rossing - added whole_word_trim function to handle trimming for vendor name and address line 1 fields
FUNCTION whole_word_trim (
					input_string		IN	VARCHAR2
				,	max_length			IN	NUMBER
				) RETURN VARCHAR2
IS
	l_str	LONG;
	l_pos	NUMBER;
BEGIN
	if length(input_string)>max_length then
		l_str := substr(input_string, 1, max_length);
		l_pos := instr(l_str, ' ', -1);
		return substr(l_str, 1, l_pos-1);
	else
		return input_string;
	end if;
END whole_word_trim;
PROCEDURE gen_ppay (
					errbuf				OUT	VARCHAR2
				,	retcode				OUT	VARCHAR2
--				,	p_bank_name			IN	varchar2
--				,	p_bank_branch			IN	varchar2
--				,	p_bank_acct_number	IN	varchar2
				,	p_bank_acct_id		IN	NUMBER
				,	p_check_start_date	IN	date
				,	p_check_end_date	IN	date
               )
IS
cursor cur_bank_account is
/*select DISTINCT abb.BANK_NUM  --- 11i code modified
,		aba.BANK_ACCOUNT_NUM
from	ap_bank_accounts_all aba
,		ap_bank_branches abb
where	aba.bank_branch_id = abb.bank_branch_id
--and    abb.bank_name = NVL(p_bank_name,'Mellon Bank, NA')
--and    abb.bank_branch_name = NVL(p_bank_branch,'')
--and    aba.bank_account_num = NVL(p_bank_acct_number,'0910602') ;
and		aba.bank_account_id = p_bank_acct_id;*/

select distinct abb.branch_number              ---R12 Remediated
,		            aba.bank_account_num
from	---ap_bank_accounts_all aba
         ce_bank_accounts aba
---,		ap_bank_branches abb
,       ce_bank_branches_v abb
where	---aba.bank_branch_id = abb.bank_branch_id
         aba.bank_branch_id = abb.branch_party_id
--- and    aba.bank_id        = abb.bank_party_id
--and    abb.bank_name = NVL(p_bank_name,'Mellon Bank, NA')
--and    abb.bank_branch_name = NVL(p_bank_branch,'')
--and    aba.bank_account_num = NVL(p_bank_acct_number,'0910602') ;
and		  aba.bank_account_id = p_bank_acct_id;
cursor cur_check_content(p_org_id in number, p_bank_num in varchar2, p_bank_acct_num in varchar2) is
/*select lpad(abb.BANK_NUM,10,0) BANK_NUM -- Oracle Standard Report had substr to 9 characters, but Mellon bank has 10 characters
,      aba.BANK_ACCOUNT_NUM raw_bank_account_num                       ---      11i code modified
,	   REPLACE(aba.BANK_ACCOUNT_NUM,'-') bank_account_num
,      ac.CHECK_NUMBER
,	   ac.check_id
,	   ac.check_stock_id
,      ac.AMOUNT raw_amount
,      LPAD(TRIM(TO_CHAR(ac.amount * 100)),10,'0') amount
,      ac.CHECK_DATE
,      ac.VENDOR_NAME
-- 9/17/10 - Eric Rossing - added vendor address line 1 field
,	   ac.address_line1 VENDOR_ADDRESS
,      decode(ac.STATUS_LOOKUP_CODE,'ISSUED','NEGOTIABLE',ac.STATUS_LOOKUP_CODE) STATUS_LOOKUP_CODE
,      ac.CURRENCY_CODE
from   ap_checks_all ac
,      ap_check_stocks_all acs
,      ap_bank_accounts_all aba
,      ap_bank_branches abb
where 1 = 1
   and ac.payment_method_lookup_code = 'CHECK'
   and ac.check_stock_id = acs.check_stock_id
   and acs.bank_account_id = aba.bank_account_id
   and aba.bank_branch_id = abb.bank_branch_id
   and abb.bank_num = p_bank_num
   and aba.bank_account_num = p_bank_acct_num
   and ac.org_id = p_org_id
   AND (
        (trunc(ac.check_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
         OR
        (trunc(ac.void_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
       )
order by 1,2,3 ;*/
---R12 Remediated
select
      ---lpad(abb.BANK_NUM,10,0) BANK_NUM  ---11i code modified
       lpad(abb.branch_number,10,0) BANK_NUM ---R12 Remediated     -- Oracle Standard Report had substr to 9 characters, but Mellon bank has 10 characters
,      aba.BANK_ACCOUNT_NUM raw_bank_account_num
,	   REPLACE(aba.BANK_ACCOUNT_NUM,'-') bank_account_num
,      ac.CHECK_NUMBER
,	   ac.check_id
---,	   ac.check_stock_id    ---11i code modified
,      ac.payment_document_id ---R12 Remediated
,      ac.AMOUNT raw_amount
,      LPAD(TRIM(TO_CHAR(ac.amount * 100)),10,'0') amount
,      ac.CHECK_DATE
,      ac.VENDOR_NAME
-- 9/17/10 - Eric Rossing - added vendor address line 1 field
,	   ac.address_line1 VENDOR_ADDRESS
,      decode(ac.STATUS_LOOKUP_CODE,'ISSUED','NEGOTIABLE',ac.STATUS_LOOKUP_CODE) STATUS_LOOKUP_CODE
,      ac.CURRENCY_CODE
from   ap_checks_all ac
---,      ap_check_stocks_all acs  ---11i code modified
,       ce_payment_documents  acs ---R12 Remediated
---,      ap_bank_accounts_all aba  ---11i code modified
,      ce_bank_accounts  aba        ---R12 Remediated
---,      ap_bank_branches abb  ---11i code modified
,      CE_BANK_BRANCHES_V abb   ---R12 Remediated
where 1 = 1
  and ac.payment_method_code = 'CHECK'
  --- and ac.check_stock_id = acs.check_stock_id  ---11i code modified
  and ac.payment_document_id = acs.payment_document_id ---R12 Remediated
   ---and acs.bank_account_id = aba.bank_account_id ---11i code modified
  and acs.internal_bank_account_id = aba.bank_account_id ---R12 Remediated
   ---and aba.bank_branch_id = abb.bank_branch_id;---11i code modified
  and aba.bank_branch_id = abb.branch_party_id ---R12 Remediated
  ---and abb.bank_num = p_bank_num---11i code modified
  and abb.branch_number = p_bank_num---R12 Remediated
  and aba.bank_account_num = p_bank_acct_num
  and ac.org_id = p_org_id
  AND (
        (trunc(ac.check_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
         OR
        (trunc(ac.void_date) between trunc(p_check_start_date) and trunc(p_check_end_date))
       )
order by 1,2,3;
-- file  definition
l_file             UTL_FILE.FILE_TYPE;
l_file_name        VARCHAR2(100) := NULL;
l_file_name_log    VARCHAR2(100) := NULL;

l_acct_ou          VARCHAR2(2) := NULL;
l_acct_curr_code   VARCHAR2(3) := NULL;
-- file paths
l_file_path        VARCHAR2(200);
l_org_id      	   NUMBER;
l_detail_rec  	   varchar2(250);
l_trailer_rec  	   varchar2(250);
l_status_lookup_code_val varchar2(1) := ' ';
l_add_issue_count  NUMBER := 0;
l_tot_issue_amount NUMBER := 0;
l_void_issue_count NUMBER := 0;
l_tot_void_amount  NUMBER := 0;
l_tot_record_count NUMBER := 0;
l_temp				VARCHAR2(100) := NULL;
BEGIN
-- Deriving the organizaiton id
--FND_CLIENT_INFO.SET_ORG_CONTEXT(FND_PROFILE.VALUE('ORG_ID')); deleted for R12 Moac remediation
FND_REQUEST.SET_ORG_ID(MO_GLOBAL.get_current_org_id); --added for MOAC remediation

  l_org_id := MO_GLOBAL.get_current_org_id ; --FND_PROFILE.VALUE('ORG_ID');
  BEGIN
  -- Getting file path
	SELECT VALUE
	INTO l_file_path
	FROM HAEMO.HAEMO_INTERFACE_PARAMETERS
	WHERE PARAMETER_GROUP='BANK_DB_FOLDER' AND KEY='ALL';
-- Creating the File Name Specified
   /* SELECT substr(hou.name, length(hou.name)-4,2), aba.currency_code---11i code modified
	INTO l_acct_ou, l_acct_curr_code
	FROM ap_bank_accounts_all aba,
	     hr_operating_units hou
	WHERE aba.org_id = hou.organization_id and
	      aba.bank_account_id = p_bank_acct_id;*/
 select substr(hou.name, length(hou.name)-4,2), aba.currency_code   ---R12 Remediated
into l_acct_ou, l_acct_curr_code
from ---ap_bank_accounts_all aba,
        ce_bank_accounts aba,
        ce_bank_acct_uses_all cbaua,
	      hr_operating_units hou
where cbaua.org_id = hou.organization_id
and  aba.bank_account_id = cbaua.bank_account_id
and  aba.bank_account_id = p_bank_acct_id;
l_file_name := 'HAE_CJPM_' ||TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') || '_' || FND_GLOBAL.conc_request_id || '_' || l_acct_ou || l_acct_curr_code || '.dat';
FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Positive Pay File created in '||l_file_path||
                   ' Directory and file name is  '||l_file_name);
EXCEPTION
      WHEN OTHERS THEN
        FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error'||SUBSTR(SQLERRM,1,100));
        errbuf :='Error in defining file name';
  END;
  -- opening the file to write
  BEGIN
   l_file := UTL_FILE.FOPEN(l_file_path,l_file_name ,'w','32767');
   EXCEPTION
WHEN UTL_FILE.WRITE_ERROR THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR writing data '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR writing data '||SUBSTR(SQLERRM,1,100));
    errbuf :='Errors while writing file';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
WHEN UTL_FILE.INVALID_PATH THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid Path '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR Invalid Path '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Errors Invalid Path';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
WHEN UTL_FILE.INVALID_MODE THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid Mode '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR Invalid Mode '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Errors Invalid mode';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
WHEN UTL_FILE.READ_ERROR THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR in reading the data '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -  ERROR in reading the data '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Unknown Errors in reading the file ';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
WHEN UTL_FILE.INVALID_FILENAME THEN
    FND_FILE.PUT_LINE( FND_FILE.LOG, ' -  ERROR Invalid File Name '||SUBSTR(SQLERRM,1,100));
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT,' -  ERROR Invalid File Name data '||SUBSTR(SQLERRM,1,100));
    ROLLBACK;
    errbuf :='Error Invalid File Name';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
WHEN UTL_FILE.INVALID_OPERATION THEN
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'Error'||SUBSTR(SQLERRM,1,200));
    ROLLBACK;
    errbuf :='Error Invalid Operation';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
    RETURN;
   WHEN OTHERS THEN
    FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'Error'||SUBSTR(SQLERRM,1,200));
    ROLLBACK;
    errbuf :='Unknown Errors';
    retcode := -1;
    UTL_FILE.FCLOSE(l_file);
   RETURN;
   END; -- done with file handling
  FOR c_bank_acct in cur_bank_account
  LOOP
  l_void_issue_count := 0;
   l_tot_void_amount  := 0;
   l_add_issue_count  := 0;
   l_tot_issue_amount := 0;
   FOR c_details in cur_check_content(l_org_id,c_bank_acct.branch_number,c_bank_acct.bank_account_num)
      LOOP
l_detail_rec := NULL ;
IF c_details.status_lookup_code = 'VOIDED' THEN
		  l_status_lookup_code_val := 'V' ;
		ELSE
		  l_status_lookup_code_val := 'I' ;
		END IF ;
l_detail_rec := l_status_lookup_code_val || ' ' || LPAD(to_char(c_bank_acct.bank_account_num),20,'0') || ' ' || to_char(LPAD(c_details.check_number,18,0)) ||
    	                ' ' || to_char(lpad(c_details.amount,18,0)) || ' ' || TO_CHAR(c_details.check_date,'YYYYMMDD') || ' ' || LPAD(' ',8,' ') || ' ' || LPAD(' ',15,' ') ||
-- 9/17/10 - Eric Rossing - added trimming to vendor name to 39 characters to match printed checks, and added vendor address line 1, trimmed to 35 to match printed checks
-- 10/19/10 - Eric Rossing - added carriage return (CR) character to end of line to force CR/LF line breaks required by JPMorgan Chase's processing
						RPAD(whole_word_trim(c_details.vendor_name,39),50,' ') || RPAD(whole_word_trim(c_details.vendor_address,35),50,' ') || LPAD(' ',6,' ') || CHR(13);

		-- This update is required as per the standard Oracle report AFTER_REPORT trigger which does the same
        UPDATE ap_checks_all
        SET    positive_pay_status_code = DECODE(status_lookup_code,
			   							  		'NEGOTIABLE','SENT AS NEGOTIABLE',
        		  						   	 	'ISSUED', 'SENT AS NEGOTIABLE',
        										'CLEARED','SENT AS NEGOTIABLE',
        										'CLEARED BUT UNACCOUNTED', 'SENT AS NEGOTIABLE',
											    'RECONCILED','SENT AS NEGOTIABLE',
                          						'RECONCILED UNACCOUNTED','SENT AS NEGOTIABLE',
											    'VOIDED','SENT AS VOIDED',
											    'SPOILED' ,'SENT AS VOIDED',
                          						'SET UP','SENT AS VOIDED',
                          						'OVERFLOW','SENT AS VOIDED')
        WHERE check_id = c_details.check_id
        and   check_number = c_details.check_number
      ---  and   check_stock_id = c_details.check_stock_id ;---11i code modified
				AND   payment_document_id = c_details.payment_document_id ;---R12 Remediated
	l_tot_record_count := l_tot_record_count + 1;
        if c_details.status_lookup_code = 'VOIDED' then
    	  l_void_issue_count := l_void_issue_count + 1;
		  l_tot_void_amount  := l_tot_void_amount + NVL(c_details.amount,0);
    	else
    	  l_add_issue_count  := l_add_issue_count + 1 ;
		  l_tot_issue_amount := l_tot_issue_amount + NVL(c_details.amount,0);
    	end if;

        fnd_file.put_line(FND_FILE.OUTPUT,l_detail_rec);
        utl_file.put_line(l_file,l_detail_rec);

      END LOOP ;
fnd_file.put_line(FND_FILE.LOG,'DEBUG: l_add_issue_count:'||l_add_issue_count||'; l_tot_issue_amount:'||l_tot_issue_amount||'; l_void_issue_count:'||l_void_issue_count||'; l_tot_void_amount:'||l_tot_void_amount);
END LOOP ;
 utl_file.fclose(l_file);
  --added by DL 7/1/10 to call the PGP encryption program
  fnd_file.put_line(FND_FILE.LOG,'Encryting File');
  xxhae_pgp_encryption(l_file_path||'/'||l_file_name,'Y');
IF NVL(l_tot_record_count,0) = 0 THEN
     utl_file.fremove(l_file_path, l_file_name);
     FND_FILE.PUT_LINE( FND_FILE.OUTPUT, 'No File was created because of ' ||to_char(l_tot_record_count) || ' records ');
  END IF;
  commit; -- Commit is required for the AP_CHECKS update
 -- Outer Block exception
  EXCEPTION
    WHEN OTHERS THEN
       FND_FILE.PUT_LINE( FND_FILE.OUTPUT, ' -Unexpected error '||SQLERRM);
       FND_FILE.PUT_LINE(FND_FILE.LOG,' Unexpected error : '||SQLERRM);
       IF cur_bank_account%ISOPEN THEN
           CLOSE cur_bank_account;
       END IF;
         IF cur_check_content%ISOPEN THEN
           CLOSE cur_check_content;
       END IF;
       UTL_FILE.FCLOSE_ALL;    -- close the file
       errbuf :='Unknown Errors occured';
       retcode := -1;
 END gen_ppay;
 END XXHA_JPM_POSITIVE_PAY_PKG;
/
