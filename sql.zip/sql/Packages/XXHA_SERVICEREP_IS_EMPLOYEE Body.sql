create or replace PACKAGE BODY XXHA_SERVICEREP_IS_EMPLOYEE AS
/**********************************************************************************************************************************
 *
 * Package Name : XXHA_SERVICEREP_IS_EMPLOYEE
 * Description:  This function will determine if a SERVICEREP is still an employee.  
 *               It is used by the Concurrent Program, 'XXHA: SubInventory Assignments Report US'. (XXHA_SubInventoryAssignments.rdf)
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 * -------------   -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      05-MAY-2015     Initial Function Creation
 *
 **********************************************************************************************************************************/

FUNCTION SERVICEREP_IS_EMP(p_Resource_ID IN NUMBER, p_Subinventory_Code IN VARCHAR2) RETURN VARCHAR2 IS

l_USER_ID                      FND_USER.USER_ID%TYPE                            := NULL;
l_END_DATE_ACTIVE              jtf_rs_defresources_vl.END_DATE_ACTIVE%TYPE      := NULL;
l_EFFECTIVE_DATE_END           CSP_INV_LOC_Assignments.EFFECTIVE_DATE_END%TYPE  := NULL;
l_PERSON_ID                    PER_ALL_PEOPLE_F.PERSON_ID%TYPE                  := NULL;
l_FULL_NAME                    PER_ALL_PEOPLE_F.FULL_NAME%TYPE                  := NULL;
l_END_DATE                     FND_USER.END_DATE%TYPE                           := NULL;
l_PROCESS_EMP                  VARCHAR2(01)                                     := NULL;

BEGIN

    SELECT jtf.USER_ID
         , jtf.END_DATE_ACTIVE
         , csp.EFFECTIVE_DATE_END
      INTO l_USER_ID
         , l_END_DATE_ACTIVE
         , l_EFFECTIVE_DATE_END
      FROM apps.jtf_rs_defresources_vl       jtf
         , APPS.CSP_INV_LOC_Assignments      csp
         , APPS.CSP_SEC_Inventories          SECINV
     WHERE jtf.resource_id                 = p_Resource_ID
       AND jtf.resource_id                 = csp.resource_id
       AND csp.Organization_ID             = SECINV.Organization_ID(+)
       AND csp.Subinventory_Code           = SECINV.Secondary_Inventory_Name (+)
       AND SECINV.Secondary_Inventory_Name = p_Subinventory_Code
       AND ROWNUM                          = 1
      ORDER BY
           jtf.USER_ID
         , jtf.END_DATE_ACTIVE
         , csp.EFFECTIVE_DATE_START DESC;

    SELECT per.PERSON_ID
         , per.Full_Name
         , FND.End_date
      INTO l_PERSON_ID
         , l_Full_name
         , l_END_DATE
      FROM fnd_user               FND
        ,  per_all_people_f       per
        ,  per_all_Assignments_f  paf
     WHERE FND.USER_ID          = NVL(l_USER_ID,-999)
       AND Per.Person_Id        = FND.Employee_Id
       AND per.person_id        = paf.person_id
       AND TRUNC(SYSDATE)       BETWEEN TRUNC(PER.Effective_start_date) AND NVL(TRUNC(PER.Effective_end_date), TRUNC(SYSDATE))
       AND TRUNC(SYSDATE)       BETWEEN TRUNC(paf.Effective_start_date) AND NVL(TRUNC(paf.Effective_end_date), TRUNC(SYSDATE));

    -- Set l_PROCESS_EMP to 'Y'
    l_PROCESS_EMP := 'Y';

    -- If Employee is not 'EMPLOYEE','HAE CONTINGENT' or 'HAE EX-CONTINGENT'
    IF SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE (TRUNC(SYSDATE),l_PERSON_ID)),1,8) NOT IN ('EMPLOYEE','HAE CONT','HAE EX-C') THEN
       l_PROCESS_EMP := 'N';
    END IF;

    -- If FND.END_DATE is before SYSDATE
    IF NVL(TRUNC(l_END_DATE),TRUNC(SYSDATE)+1) < TRUNC(SYSDATE) THEN
       l_PROCESS_EMP := 'N';
    END IF;

    -- If jtf.END_DATE_ACTIVE is before SYSDATE
    IF NVL(TRUNC(l_END_DATE_ACTIVE),TRUNC(SYSDATE)+1) < TRUNC(SYSDATE) THEN
       l_PROCESS_EMP := 'N';
    END IF;

    -- If csp.EFFECTIVE_DATE_END is before SYSDATE
    IF NVL(TRUNC(l_EFFECTIVE_DATE_END),TRUNC(SYSDATE)+1) < TRUNC(SYSDATE) THEN
       l_PROCESS_EMP := 'N';
    END IF;

    RETURN l_PROCESS_EMP;

END SERVICEREP_IS_EMP;

END XXHA_SERVICEREP_IS_EMPLOYEE;