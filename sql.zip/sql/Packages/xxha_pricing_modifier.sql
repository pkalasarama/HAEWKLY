CREATE OR REPLACE FUNCTION xxha_pricing_modifier(
    p_line_id NUMBER)
  RETURN VARCHAR2
AS

/*****************************************************************************************
* Name/Purpose : XXHA Pricing Modifier Extension *
*                                                                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 23-FEB-2015     Vijay Medikonda      XXHA Pricing Modifier Extension                *
*****************************************************************************************/
  l_modifier_dff VARCHAR2(100):='N';
BEGIN
  BEGIN
    SELECT DISTINCT qll.attribute1 DFF
    INTO l_modifier_dff
    FROM OE_PRICE_ADJUSTMENTS opa,
      QP_LIST_LINES qll
    WHERE opa.line_id          =p_line_id
    AND opa.list_line_id       =qll.list_line_id
    AND NVL(qll.attribute1,'N')='Y';
  EXCEPTION
  WHEN OTHERS THEN
    l_modifier_dff:='N';
  END;
RETURN l_modifier_dff;
END;