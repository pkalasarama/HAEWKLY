/* Formatted on 2014/09/16 15:33 (Formatter Plus v4.8.8) */
CREATE OR REPLACE PACKAGE BODY apps.msd_dem_custom_hooks
AS
/* $Header: msddemchkb.pls 120.1.12020000.2 2012/10/03 12:19:40 mpmurali ship $ */
/**********************************************************************************************************************************
*
* Script:     msd_dem_custom_hooks.sql
* Description:  Allows custom updates to demantra data.
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    16-Sep-2014  Initial Creation
*
**********************************************************************************************************************************/

   /* Item Hook */
   PROCEDURE item_hook (
      errbuf    OUT NOCOPY   VARCHAR2,
      retcode   OUT NOCOPY   VARCHAR2
   )
   IS
   BEGIN
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         retcode := -1;
         errbuf := 'Error in msd_dem_custom_hooks.item_hook';
         RETURN;
   END item_hook;

   /* Location Hook */
   PROCEDURE location_hook (
      errbuf    OUT NOCOPY   VARCHAR2,
      retcode   OUT NOCOPY   VARCHAR2
   )
   IS
      CURSOR loc_recs
      IS
         SELECT DISTINCT ebs_site_dest_key
                    FROM msdem.t_src_loc_tmpl
                   WHERE e1_customer_country = 'N/A'
                     AND ebs_site_dest_key IS NOT NULL;

      v_city      VARCHAR2 (255);
      v_state     VARCHAR2 (255);
      v_country   VARCHAR2 (255);
   BEGIN
      fnd_file.put_line
                    (fnd_file.LOG,
                     'Start msd_dem_custom_hooks.location_hook customization'
                    );

      FOR i IN loc_recs
      LOOP
         BEGIN
            SELECT city, state, country
              INTO v_city, v_state, v_country
              FROM msc.msc_trading_partner_sites
             WHERE partner_site_id = i.ebs_site_dest_key;

            UPDATE msdem.t_src_loc_tmpl
               SET e1_customer_country = NVL (v_country, 'N/A'),
                   e1_customer_city = NVL (v_city, 'N/A'),
                   e1_customer_state = NVL (v_state, 'N/A')
             WHERE ebs_site_dest_key = i.ebs_site_dest_key;
         EXCEPTION
            WHEN OTHERS
            THEN
               fnd_file.put_line
                     (fnd_file.LOG,
                         'Select from msc_trading_partners_sites failed for '
                      || i.ebs_site_dest_key
                      || ' with '
                      || SQLERRM
                     );
         END;
      END LOOP;

      COMMIT;
      fnd_file.put_line
                       (fnd_file.LOG,
                        'End msd_dem_custom_hooks.location_hook customization'
                       );
   EXCEPTION
      WHEN OTHERS
      THEN
         retcode := -1;
         errbuf := 'Error in msd_dem_custom_hooks.location_hook';
   END location_hook;

   /* History Hook */
   PROCEDURE history_hook (
      errbuf    OUT NOCOPY   VARCHAR2,
      retcode   OUT NOCOPY   VARCHAR2
   )
   IS
   BEGIN
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         retcode := -1;
         errbuf := 'Error in msd_dem_custom_hooks.history_hook';
         RETURN;
   END history_hook;

   /* Upload Hook */
   PROCEDURE upload_hook (
      errbuf    OUT NOCOPY   VARCHAR2,
      retcode   OUT NOCOPY   VARCHAR2
   )
   IS
   BEGIN
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         retcode := -1;
         errbuf := 'Error in msd_dem_custom_hooks.upload_hook';
         RETURN;
   END upload_hook;
END msd_dem_custom_hooks;
/