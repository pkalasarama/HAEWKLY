CREATE OR REPLACE PACKAGE XXHA_WSHRDPAK_PK AUTHID CURRENT_USER
AS

/*************************************************************************************************************
* Package Name : XXHA_WSHRDPAK_PK                                                                            *
* Purpose      : Package to submit Concurrent Programs 'XXHA: Packing Slip Report Barcoded Dist US - SLO'    *
*                   and 'XXHA: Packing Slip Report Barcoded Dist US - PTO'                                   *
*                                                                                                            *
* Procedures   : Process_PGM                                                                                 *
*                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)            *
* - wsh_new_deliveries                S                                                                      *
* - hz_cust_accounts                  S                                                                      *
* - hz_parties                        S                                                                      *
* - XDO_TEMPLATES_VL                  S                                                                      *
* - XDO_LOBS                          S                                                                      *
* - fnd_concurrent_programs_vl        S                                                                      *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver        Date            Author               Description                                                *
* ------     -----------     -----------------    ---------------                                            *
* 1.0        24-MAY-2011     BMarcoux             Intial Program Creation.                                   *
*                                                                                                            *
**************************************************************************************************************/

   --GlobalVariables
   gc_log_msg               VARCHAR2(3000);
   gc_debug_flag            VARCHAR2(1);

   --Procedure to Process Concurrent Program
   PROCEDURE Process_PGM (
                                    x_errbuf              OUT VARCHAR2
                                  , x_retcode             OUT VARCHAR2
                                  , P_ORGANIZATION_ID     IN  VARCHAR2
                                  , P_DELIVERY_ID         IN  VARCHAR2
                                  , P_PRINT_CUST_ITEM     IN  VARCHAR2
                                  , P_ITEM_DISPLAY        IN  VARCHAR2
                                  , P_PRINT_MODE          IN  VARCHAR2
                                  , P_PRINT_ALL           IN  VARCHAR2
                                  , P_SORT                IN  VARCHAR2
                                  , P_DELIVERY_DATE_LOW   IN  DATE
                                  , P_DELIVERY_DATE_HIGH  IN  DATE
                                  , P_FREIGHT_CODE        IN  VARCHAR2
                                  , P_QUANTITY_PRECISION  IN  NUMBER
                                  , P_DISPLAY_UNSHIPPED   IN  VARCHAR2
                                  , P_CONCURRENT_PGM      IN  VARCHAR2
                                  , P_TEMPLATE_CODE       IN  VARCHAR2
                                 );

END XXHA_WSHRDPAK_PK;



/


CREATE OR REPLACE PACKAGE BODY XXHA_WSHRDPAK_PK AS

/*************************************************************************************************************
* Package Name : XXHA_WSHRDPAK_PK                                                                            *
* Purpose      : Package to submit Concurrent Programs 'XXHA: Packing Slip Report Barcoded Dist US - SLO'    *
*                   and 'XXHA: Packing Slip Report Barcoded Dist US - PTO'                                   *
*                                                                                                            *
* Procedures   : Process_PGM                                                                                 *
*                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)            *
* - wsh_new_deliveries                S                                                                      *
* - hz_cust_accounts                  S                                                                      *
* - hz_parties                        S                                                                      *
* - XDO_TEMPLATES_VL                  S                                                                      *
* - XDO_LOBS                          S                                                                      *
* - fnd_concurrent_programs_vl        S                                                                      *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver        Date            Author               Description                                                *
* ------     -----------     -----------------    ---------------                                            *
* 1.0        24-MAY-2011     BMarcoux             Intial Program Creation.                                   *
*                                                                                                            *
**************************************************************************************************************/

PROCEDURE Process_PGM (
                                    x_errbuf              OUT VARCHAR2
                                  , x_retcode             OUT VARCHAR2
                                  , P_ORGANIZATION_ID     IN  VARCHAR2
                                  , P_DELIVERY_ID         IN  VARCHAR2
                                  , P_PRINT_CUST_ITEM     IN  VARCHAR2
                                  , P_ITEM_DISPLAY        IN  VARCHAR2
                                  , P_PRINT_MODE          IN  VARCHAR2
                                  , P_PRINT_ALL           IN  VARCHAR2
                                  , P_SORT                IN  VARCHAR2
                                  , P_DELIVERY_DATE_LOW   IN  DATE
                                  , P_DELIVERY_DATE_HIGH  IN  DATE
                                  , P_FREIGHT_CODE        IN  VARCHAR2
                                  , P_QUANTITY_PRECISION  IN  NUMBER
                                  , P_DISPLAY_UNSHIPPED   IN  VARCHAR2
                                  , P_CONCURRENT_PGM      IN  VARCHAR2
                                  , P_TEMPLATE_CODE       IN  VARCHAR2
                                 )
IS

l_user_id                       FND_User.User_ID%TYPE;
l_resp_id                       FND_Responsibility_TL.RESPONSIBILITY_ID%TYPE;
l_resp_appl_id                  FND_Responsibility_TL.APPLICATION_ID%TYPE;
l_Cust_Attr_4                   HZ_Cust_Accounts.ATTRIBUTE4%TYPE;

l_Template_code                 XDO_TEMPLATES_VL.Template_code%TYPE;
l_Application_Short_Name        XDO_TEMPLATES_VL.Application_Short_Name%TYPE;
l_Language                      XDO_LOBS.Language%TYPE;
l_Territory                     XDO_LOBS.Territory%TYPE;
l_Default_Output_Type           XDO_TEMPLATES_VL.Default_Output_Type%TYPE;

l_user_concurrent_program_name  fnd_concurrent_programs_vl.user_concurrent_program_name%TYPE;
l_printer_name                  fnd_concurrent_programs_vl.printer_name%TYPE;
l_output_print_style            fnd_concurrent_programs_vl.output_print_style%TYPE;
l_save_output_flag              fnd_concurrent_programs_vl.save_output_flag%TYPE;
l_copies                        NUMBER := 1;

l_request_id                    NUMBER;
l_call_status                   BOOLEAN;
l_set_print                     BOOLEAN;

BEGIN

-- Check to see if customer is set up for Bar-Coded Packing Slips
SELECT
    cst.Attribute4
INTO
    l_Cust_Attr_4
FROM
    wsh_new_deliveries     del
,   hz_cust_accounts       cst
,   hz_parties             party
WHERE
    del.delivery_id      = P_DELIVERY_ID
AND del.Customer_ID      = cst.CUST_ACCOUNT_ID(+)
AND cst.Party_Id         = party.Party_Id;

-- Retrieve Concurrent Program User Name (i.e. 'XXHA: Packing Slip Report Barcoded Dist US - PTO�),
-- Printer Name, Output Print Style and Save Output Flag
-- for submit message and for setting Print Options
SELECT
    cp.user_concurrent_program_name
,   cp.printer_name
,   cp.output_print_style
,   cp.save_output_flag
INTO
    l_user_concurrent_program_name
,   l_printer_name
,   l_output_print_style
,   l_save_output_flag
FROM
    fnd_concurrent_programs_vl   cp
WHERE
    cp.concurrent_program_name = P_CONCURRENT_PGM;

   BEGIN

   -- If Customer is set up for Bar-Coded Packing Slips then process
   IF l_Cust_Attr_4 = 'Yes' THEN

   -- Set Printer Options
   l_set_print := FND_REQUEST.SET_PRINT_OPTIONS(l_printer_name, l_output_print_style, l_copies, TRUE, 'N');

   IF l_set_print = FALSE THEN
     fnd_file.put_line(fnd_file.log,l_user_concurrent_program_name || ' - Set Printer Options Error');
     END IF;

   -- Retrieve Template values
   SELECT
       XTL.Template_code
   ,   XTL.Application_Short_Name
   ,   XLO.Language
   ,   XLO.Territory
   ,   XTL.Default_Output_Type
   INTO
       l_Template_code
   ,   l_Application_Short_Name
   ,   l_Language
   ,   l_Territory
   ,   l_Default_Output_Type
   FROM
       XDO_TEMPLATES_VL  XTL
   ,   XDO_LOBS          XLO
   WHERE
       XTL.Template_code = P_TEMPLATE_CODE --(i.e. 'XXHA_WSHRDPAK_BCD_US_PTO')
   AND XTL.Template_code = XLO.lob_code
   AND XLO.lob_type      = 'TEMPLATE';

   -- Call package to set Layout
   l_call_status :=
   fnd_request.add_layout
   (
     l_Application_Short_Name	 -- Template Application Name
   , l_Template_code		       -- Template Code
   , l_Language			           -- Template Language
   , l_Territory		           -- Template Territory
   , l_Default_Output_Type	   -- Output Format
   );

   -- Call Package to submit the Concurrent Program
   l_request_id := fnd_request.submit_request
   (
     'HAEMO'			             -- Application
   , P_CONCURRENT_PGM		       -- Program (i.e. 'XXHA_WSHRDPAK_BCD_US_PTO')
   , NULL			                 -- Description
   , NULL			                 -- Start Time
   , FALSE			               -- Sub Request
   , P_ORGANIZATION_ID
   , P_DELIVERY_ID
   , P_PRINT_CUST_ITEM
   , P_ITEM_DISPLAY
   , P_PRINT_MODE
   , P_PRINT_ALL
   , P_SORT
   , P_DELIVERY_DATE_LOW
   , P_DELIVERY_DATE_HIGH
   , P_FREIGHT_CODE
   , P_QUANTITY_PRECISION
   , P_DISPLAY_UNSHIPPED

   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
   );

   COMMIT;

   -- Write Message to Job Log if Concurrent Program was submitted
   fnd_file.put_line(fnd_file.log,'                                                                           ');
   fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
   fnd_file.put_line(fnd_file.log,l_user_concurrent_program_name || ' - Submitted - Request ID#: ' || l_request_id);
   fnd_file.put_line(fnd_file.log,'Customer Attribute 4 (Auto_Prt_Pack_Slip): ' || l_Cust_Attr_4);
   fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
   fnd_file.put_line(fnd_file.log,'                                                                           ');

   -- Write Message to Job Log if Concurrent Program was *NOT* submitted
   ELSE
   fnd_file.put_line(fnd_file.log,'                                                                 ');
   fnd_file.put_line(fnd_file.log,'-----------------------------------------------------------------');
   fnd_file.put_line(fnd_file.log,l_user_concurrent_program_name || ' ***NOT SUBMITTED*** ');
   fnd_file.put_line(fnd_file.log,'Customer Attribute 4 (Auto_Prt_Pack_Slip): ' || l_Cust_Attr_4);
   fnd_file.put_line(fnd_file.log,'-----------------------------------------------------------------');
   fnd_file.put_line(fnd_file.log,'                                                                 ');
   END IF;

   EXCEPTION WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
   END;

END Process_PGM;

END XXHA_WSHRDPAK_PK;



/
