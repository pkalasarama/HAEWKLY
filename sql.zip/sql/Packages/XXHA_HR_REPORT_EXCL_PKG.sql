CREATE OR REPLACE PACKAGE xxha_hr_report_excl_pkg AS

    FUNCTION bonus_exclusions (p_business_group VARCHAR2,
                               p_grade_seg1     VARCHAR2,
                               p_grade_seg2     VARCHAR2,
                               p_dept           VARCHAR2)  RETURN CHAR ;

    FUNCTION merit_exclusions (p_business_group VARCHAR2,
                               p_grade_seg1     VARCHAR2,
                               p_grade_seg2     VARCHAR2) RETURN CHAR;

END xxha_hr_report_excl_pkg;

/


CREATE OR REPLACE PACKAGE BODY xxha_hr_report_excl_pkg AS

/**********************(Bonus Exclusions)****************************************/
  FUNCTION bonus_exclusions (p_business_group VARCHAR2,
                             p_grade_seg1     VARCHAR2,
                             p_grade_seg2     VARCHAR2,
                             p_dept           VARCHAR2)  RETURN CHAR IS
  l_cnt number;
  BEGIN

    IF p_business_group = 'BG_US' THEN

            IF p_grade_seg1 < '19' OR p_grade_seg1 = '88' THEN
                  RETURN 'Y';
            ELSIF p_grade_seg1 = '19' AND p_grade_seg2 = 'USN' THEN
                  RETURN 'Y';
            ELSIF p_grade_seg1 = '20' AND p_grade_seg2 = 'USN' THEN
                  RETURN 'Y';
            ELSE
                  RETURN 'N';
            END IF;

    ELSIF (p_business_group = 'BG_CH' OR
           p_business_group = 'BG_AT' OR
           p_business_group = 'BG_BE' OR
           p_business_group = 'BG_DE' OR
           p_business_group = 'BG_FR' OR
           p_business_group = 'BG_NL' OR
           p_business_group = 'BG_CZ' OR
           p_business_group = 'BG_SE' OR
           p_business_group = 'BG_IT') THEN


              IF p_grade_seg1 < '24' THEN
                RETURN 'Y';
              ELSIF p_grade_seg1 > '23' AND  p_grade_seg1 < '30' THEN
                IF SUBSTR(p_grade_seg2,3,2) = '-S' OR p_dept = '6000' THEN
                  RETURN 'Y';
                 ELSE
                   RETURN 'N';
                 END IF;
                ELSE
                 RETURN 'N';
              END IF;

    ELSIF p_business_group = 'BG_GB' THEN

             IF p_grade_seg1 < '24' and p_grade_seg2 = 'GB' THEN
               RETURN 'Y';
             ELSIF p_grade_seg2 = 'GB-S' OR p_dept = '6000' THEN
                RETURN 'Y';
             ELSE
               RETURN 'N';
             END IF;

    ELSIF p_business_group = 'BG_JP' THEN

             IF p_grade_seg2 = 'JP-S' OR p_dept = '6000' THEN
                RETURN 'Y';
             ELSE
               RETURN 'N';
             END IF;

    ELSIF (p_business_group = 'BG_HK' OR
           p_business_group = 'BG_KR' OR
           p_business_group = 'BG_CN' OR
           p_business_group = 'BG_TW') THEN

           IF p_dept = '6000' THEN
             RETURN 'Y';
           ELSE
             RETURN 'N';
           END IF;

    ELSE
        RETURN 'N';
    END IF;

  END bonus_exclusions;

/**********************(Merit Exclusions)****************************************/
  FUNCTION merit_exclusions (p_business_group VARCHAR2,
                             p_grade_seg1     VARCHAR2,
                             p_grade_seg2     VARCHAR2) RETURN CHAR IS

    l_grd_seg1  NUMBER;

  BEGIN

    IF p_grade_seg1 = 'OC' OR p_grade_seg1 = 'XX' OR p_grade_seg1 IS NULL THEN
       RETURN 'N'; --NULL;
    ELSE
       l_grd_seg1 := to_number(p_grade_seg1);
    END IF;

    IF p_business_group = 'BG_US' THEN
      IF l_grd_seg1 < 19 THEN
        RETURN 'Y';
      ELSIF l_grd_seg1 = 19 AND p_grade_seg2 = 'USN' THEN
        RETURN 'Y';
      ELSIF l_grd_seg1 = 20 AND p_grade_seg2 = 'USN' THEN
        RETURN 'Y';
      ELSE
        RETURN 'N';
      END IF;

    ELSIF p_business_group = 'BG_GB' and l_grd_seg1 < 18 THEN
      RETURN 'Y';

    ELSE
      RETURN 'N';
    END IF;

  END merit_exclusions;

END xxha_hr_report_excl_pkg ;

/
