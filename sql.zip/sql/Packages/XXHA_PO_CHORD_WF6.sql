CREATE OR REPLACE PACKAGE XXHA_PO_CHORD_WF6 AUTHID CURRENT_USER as
/* $Header: POXWCO6S.pls 115.3 2002/11/26 19:47:00 sbull ship $ 

 -- ======================================================================================
 -- NAME : XXHA_PO_CHORD_WF6
 -- PROGRAM TYPE
 -- Package Spec
 --
 -- DESCRIPTION
 -- This is a custom version of the delivered package PO_CHORD_WF6
 --
 -- HISTORY
 -- 
 -- ======================================================================================
 -- Modification Date  Modified By    Activity
 -- =====================================================================================
 --  19-MAY-2010       Dave Lund      Created
 --                                   There are no changes to the spec. Only lines commented out in the body
 --
*/

	SUBTYPE	t_header_control_type 	 IS
		PO_CHORD_WF1.t_header_control_type;

	SUBTYPE	t_lines_control_type 	 IS
		PO_CHORD_WF2.t_lines_control_type; 

	SUBTYPE	t_shipments_control_type IS
		PO_CHORD_WF3.t_shipments_control_type;

	SUBTYPE	t_dist_control_type 	 IS
		PO_CHORD_WF4.t_dist_control_type;

	SUBTYPE	t_release_control_type 	 IS
		PO_CHORD_WF5.t_release_control_type;

	/* This record type holds tolerance percentages
	** defined by user in the workflow builder.
	** The prefix denotes the table which 
	** the attribute is referring to :
	** h: po_headers_all
	** l: po_lines_all
	** s: po_line_locations_all
	** d: po_distributions_all
	*/

	TYPE	t_tolerance_control_type	IS RECORD(
	h_blanket_total_t	NUMBER,
	h_amount_limit_t	NUMBER,
	h_po_total_t            NUMBER,
	l_quantity_t		NUMBER,
	l_unit_price_t		NUMBER,
	l_quantity_committed_t	NUMBER,
	l_committed_amount_t	NUMBER,
	l_price_limit_t 	NUMBER,
	s_quantity_t		NUMBER,
	s_price_override_t	NUMBER,
	d_quantity_ordered_t	NUMBER
	);


	PROCEDURE standard_po_reapproval(itemtype IN VARCHAR2,
			   		itemkey  IN VARCHAR2,
			   		actid    IN NUMBER,
			   		FUNCMODE IN VARCHAR2,
			   		RESULT   OUT NOCOPY VARCHAR2);

	PROCEDURE planned_po_reapproval(itemtype IN VARCHAR2,
			   		itemkey  IN VARCHAR2,
			   		actid    IN NUMBER,
			   		FUNCMODE IN VARCHAR2,
			   		RESULT   OUT NOCOPY VARCHAR2);

	PROCEDURE blanket_po_reapproval(itemtype IN VARCHAR2,
			   		itemkey  IN VARCHAR2,
			   		actid    IN NUMBER,
			   		FUNCMODE IN VARCHAR2,
			   		RESULT   OUT NOCOPY VARCHAR2);

	PROCEDURE contract_po_reapproval(itemtype IN VARCHAR2,
			   		itemkey  IN VARCHAR2,
			   		actid    IN NUMBER,
			   		FUNCMODE IN VARCHAR2,
			   		RESULT   OUT NOCOPY VARCHAR2);

	PROCEDURE blanket_release_reapproval(itemtype IN VARCHAR2,
			   		itemkey  IN VARCHAR2,
			   		actid    IN NUMBER,
			   		FUNCMODE IN VARCHAR2,
			   		RESULT   OUT NOCOPY VARCHAR2);

	PROCEDURE scheduled_release_reapproval(itemtype IN VARCHAR2,
			   		itemkey  IN VARCHAR2,
			   		actid    IN NUMBER,
			   		FUNCMODE IN VARCHAR2,
			   		RESULT   OUT NOCOPY VARCHAR2);

	PROCEDURE get_default_tolerance(
			itemtype         IN VARCHAR2,
                        itemkey          IN VARCHAR2,
			x_tolerance_control IN OUT NOCOPY t_tolerance_control_type);

	PROCEDURE debug_default_tolerance(
			itemtype         IN VARCHAR2,
                        itemkey          IN VARCHAR2,
			x_tolerance_control t_tolerance_control_type);


END XXHA_PO_CHORD_WF6;
/


CREATE OR REPLACE PACKAGE BODY XXHA_PO_CHORD_WF6 AS
/* $Header: POXWCO6B.pls 115.14.11510.7 2008/03/18 09:27:06 ankugarg ship $ 

 -- ======================================================================================
 -- NAME : XXHA_PO_CHORD_WF6
 -- PROGRAM TYPE
 -- Package Body
 --
 -- DESCRIPTION
 -- This is a custom version of the delivered package P_CHORD_WF6
 --
 -- HISTORY
 -- 
 -- ======================================================================================
 -- Modification Date  Modified By    Activity
 -- =====================================================================================
 --  19-MAY-2010       Dave Lund      Created
 --                                   Only changes to delivered code were to comment out 
 --                                   conditions for reapproval that are not required
 --
*/
  
-- Read the profile option that enables/disables the debug log
g_po_wf_debug VARCHAR2(1) := NVL(FND_PROFILE.VALUE('PO_SET_DEBUG_WORKFLOW_ON'),'N');

/**************************************************************************
 *  The following procedures determine what reapproval rules will be applied
 *  by the workflow system. Please be careful when modifying this
 *  package. 
 *  These rules determine whether the document is routed through the full
 *  approval process.
 *
 *  There are 6 procedures in this package, each for a different
 *  document type. 
 *
 *  1. standard_po_reapproval		: Standard Purchase Order
 *  2. planned_po_reapproval		: Planned Purchase Order
 *  3. blanket_po_reapproval		: Blanket Purchase Agreement
 *  4. contract_po_reapproval		: Contract Purchase Agreement
 *  5. blanket_release_reapproval	: Blanket Release
 *  6. scheduled_release_reapproval	: Scheduled Release
 *
 * How to customerize this package:
 * (1) Backup this file
 * (2) Do not change procedure definition.
 * (3) Only modify the IF statement logic.
 *
 * The workflow system compares the current and previous version of
 * the document and reports all modifications.
 * For example, Standard Purchase Order has 4 sections, namely
 * header, lines, shipments, and distributions.
 * The modifications are thus stored in the following data structure:
 * x_header_control, x_lines_control, x_shipments_control and
 * x_dist_control.
 * ( See POXWCO1S.pls, POXWCO2S.pls, POXWCO3S.pls POXWCO4S.pls
 *   for definition )
 *
 * The data structure x_tolerance_control holds the default tolerance
 * percentage in the workflow definition. They are stored as
 * item attributes in the workflow.
 *
 * Two types of value are stored in the data structure:
 * (1) 'Y' or 'N' type		(name same as table column name)
 * (2) Numbers in Percentage	(name with '_change')
 *
 **************************************************************************
 */

/**************************************************************************
 *									  *
 * 	Reapproval Rules for Standard Purchase Order 			  *
 * 									  *
 **************************************************************************/

PROCEDURE standard_po_reapproval(itemtype IN VARCHAR2,
		   		itemkey  IN VARCHAR2,
		   		actid    IN NUMBER,
		   		FUNCMODE IN VARCHAR2,
		   		RESULT   OUT NOCOPY VARCHAR2)
IS
	x_header_control 	t_header_control_type;
	x_lines_control 	t_lines_control_type;
	x_shipments_control 	t_shipments_control_type;
	x_dist_control 		t_dist_control_type;
	x_tolerance_control	t_tolerance_control_type;
	x_result		VARCHAR2(1);
	l_retroactive_change     VARCHAR2(1) := 'N'; --  RETROACTIVE FPI
        l_autoapprove_retro     VARCHAR2(1) := 'N'; --  RETROACTIVE FPI
	l_actionoriginated_from   varchar2(30);     --Bug5567534

BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: standard_po_reapproval ***');
	END IF;

	IF funcmode <> 'RUN' THEN
		result := 'COMPLETE';
		return;
	END IF;

	/* RETROACTIVE FPI START.
	 * Get the value of the attribute CO_H_RETROACTIVE_APPROVAL if
	 * this approval is initiated due to the retroactive change in
	 * the release. If this value is N, then we send the document
	 * through Change Order Workflow.
	*/
	l_retroactive_change := PO_WF_UTIL_PKG.GetItemAttrText
					(itemtype => itemtype,
                                         itemkey  => itemkey,
                                         aname    => 'CO_R_RETRO_CHANGE');

	If (l_retroactive_change = 'Y') then

		 l_autoapprove_retro := PO_WF_UTIL_PKG.GetItemAttrText
					(itemtype => itemtype,
					 itemkey  => itemkey,
					 aname    => 'CO_H_RETROACTIVE_AUTOAPPROVAL');
            /*Bug5567534 Get the wf attribute value 'INTERFACE_SOURCE_CODE'.This would be
	      the value which indicates where the approval workflow is called from.If
	      approval is called from "Retroactive" concurrent program only then check
	      for the "automatic approval" wf attribute */

	    l_actionoriginated_from := PO_WF_UTIL_PKG.GetItemAttrText
                                      (itemtype => itemtype,
                                       itemkey  => itemkey,
                                       aname    => 'INTERFACE_SOURCE_CODE');

		if (l_autoapprove_retro = 'Y') AND (l_actionoriginated_from = 'RETRO') THEN

			IF (g_po_wf_debug = 'Y') THEN
   			PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  N $$$$$$');
			END IF;

			RESULT := 'N';

			return;
		end if; /*l_autoapprove_retro = 'Y' */

	end if; /* l_retroactive_change = 'Y' */
 
	/* RETROACTIVE FPI END */
		po_chord_wf1.get_wf_header_control(itemtype, itemkey, x_header_control);
		po_chord_wf2.get_wf_lines_control(itemtype, itemkey, x_lines_control);
		po_chord_wf3.get_wf_shipments_control(itemtype, itemkey, x_shipments_control);
		po_chord_wf4.get_wf_dist_control(itemtype, itemkey, x_dist_control);
		xxha_po_chord_wf6.get_default_tolerance(itemtype, itemkey, x_tolerance_control);

		/***************************************************************
		 * Check if the modifications to the document header requires
		 * full reapproval.
		 *
		 *	 Legends:
		 *
		 *	 'Y' means modified
		 *	 'N' means not modified
		 *	 Numbers are in Percentage
		 *
		 ***************************************************************/

/*bug 4487674: vendor site id should be considered for the reapproval,
  rules, and if the same has changed the document should be routed through
  the approval hierarchy */

--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--		IF 	x_header_control.agent_id			='Y'
--		  OR    x_header_control.vendor_site_id                 ='Y' --bug4487674
--		  OR	x_header_control.vendor_contact_id		='Y'
--		  OR	x_header_control.confirming_order_flag		='Y'
--		  OR	x_header_control.ship_to_location_id		='Y'
--		  OR	x_header_control.bill_to_location_id		='Y'
--		  OR	x_header_control.terms_id			='Y'
--		  OR	x_header_control.ship_via_lookup_code		='Y'
--		  OR	x_header_control.fob_lookup_code		='Y'
--		  OR	x_header_control.freight_terms_lookup_code	='Y'
--		  OR	x_header_control.note_to_vendor			='Y'
--		  OR	x_header_control.acceptance_required_flag 	='Y'
--		  OR	x_header_control.acceptance_due_date		='Y'
--		  OR	
    IF (x_header_control.po_total_change >
			 nvl(x_tolerance_control.h_po_total_t,0))

		THEN
			IF (g_po_wf_debug = 'Y') THEN
   			PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   				'########## header_require_reapproval result: Y');
			END IF;
			x_result:='Y';
		ELSE
			IF (g_po_wf_debug = 'Y') THEN
   			PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   				'########## header_require_reapproval result: N');
			END IF;
			x_result:='N';
		END IF;

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--       IF  	x_lines_control.line_num		='Y'
--	  OR	x_lines_control.item_id			='Y'
--	  OR	x_lines_control.item_revision		='Y'
--	  OR	x_lines_control.item_description	='Y'
--	  OR	x_lines_control.category_id		='Y'
--	  OR	x_lines_control.unit_meas_lookup_code	='Y'
--	  OR	x_lines_control.from_header_id		='Y'
--	  OR	x_lines_control.from_line_id		='Y'
--	  OR	x_lines_control.hazard_class_id		='Y'
--	  OR	x_lines_control.contract_num		='Y'
--	  OR	x_lines_control.vendor_product_num 	='Y'
--	  OR	x_lines_control.un_number_id	 	='Y'
--	  OR	x_lines_control.price_type_lookup_code 	='Y'
--	  OR	x_lines_control.note_to_vendor		='Y'
--	  OR
   IF (x_lines_control.quantity_change >
		 nvl(x_tolerance_control.l_quantity_t,0))
 	  OR	(x_lines_control.unit_price_change >
		 nvl(x_tolerance_control.l_unit_price_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## lines_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## lines_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_shipments_control.shipment_num		='Y'
--	  OR	x_shipments_control.ship_to_location_id		='Y'
--	  OR	x_shipments_control.promised_date		='Y'
--	  OR	x_shipments_control.need_by_date		='Y'
--	  OR	x_shipments_control.last_accept_date		='Y'
	--  OR	
   IF (x_shipments_control.quantity_change >
		 nvl(x_tolerance_control.s_quantity_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

/* Bug 1081717: kagarwal
** Added the Check for change in Charge Account for Distributions
** x_dist_control.code_combination_id = 'Y'
*/
/* Bug 2747157: kagarwal
** Added the Check for change in Gl Date for Distributions
** x_dist_control.gl_encumbered_date = 'Y' .
*/

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_dist_control.distribution_num		='Y'
 --         OR	x_dist_control.deliver_to_person_id	='Y'
 --         OR    x_dist_control.code_combination_id = 'Y'
--          OR    x_dist_control.gl_encumbered_date = 'Y'
--	  OR
  IF (x_dist_control.quantity_ordered_change	>
		 nvl(x_tolerance_control.d_quantity_ordered_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

   --<CONTERMS FPJ START>
   IF x_result <> 'Y' THEN
       -- Check if contract terms were changed
       x_result := PO_CONTERMS_WF_PVT.contract_terms_changed(
                                      itemtype => itemtype,
                                      itemkey  => itemkey);
   END IF;
   --<CONTERMS FPJ END>
	IF x_result = 'Y' THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'$$$$$$$ Document requires full approval =  Y $$$$$$');
		END IF;
		RESULT := 'Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'$$$$$$$ Document requires full approval =  N $$$$$$');
		END IF;
		RESULT := 'N';
	END IF;

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** Finish: standard_po_reapproval ***');
	END IF;

	return;

EXCEPTION

 WHEN OTHERS THEN
  wf_core.context('POAPPRV', 'po_chord_wf6.stanard_po_reapproval', 'others');
  RAISE;

END;

/**************************************************************************
 *									  *
 * 	Reapproval Rules for Planned Purchase Order 			  *
 * 									  *
 **************************************************************************/

PROCEDURE planned_po_reapproval(itemtype IN VARCHAR2,
		   		itemkey  IN VARCHAR2,
		   		actid    IN NUMBER,
		   		FUNCMODE IN VARCHAR2,
		   		RESULT   OUT NOCOPY VARCHAR2)
IS
	x_header_control 	t_header_control_type;
	x_lines_control 	t_lines_control_type;
	x_shipments_control 	t_shipments_control_type;
	x_dist_control 		t_dist_control_type;
	x_tolerance_control	t_tolerance_control_type;
	x_result		VARCHAR2(1);
BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: planned_po_reapproval ***');
	END IF;

	IF funcmode <> 'RUN' THEN
		result := 'COMPLETE';
		return;
	END IF;

	po_chord_wf1.get_wf_header_control(itemtype, itemkey, x_header_control);
	po_chord_wf2.get_wf_lines_control(itemtype, itemkey, x_lines_control);
	po_chord_wf3.get_wf_shipments_control(itemtype, itemkey, x_shipments_control);
	po_chord_wf4.get_wf_dist_control(itemtype, itemkey, x_dist_control);
	xxha_po_chord_wf6.get_default_tolerance(itemtype, itemkey, x_tolerance_control);

	-- 'Y' means modified
	-- Numbers are in Percentage

/*bug 4487674: vendor site id should be considered for the reapproval,
  rules, and if the same has changed the document should be routed through
  the approval hierarchy */

--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--        IF 	x_header_control.agent_id			='Y'
--	  OR    x_header_control.vendor_site_id                 ='Y'  --bug 4487674
--	  OR	x_header_control.vendor_contact_id		='Y'
--	  OR	x_header_control.confirming_order_flag		='Y'
--	  OR	x_header_control.ship_to_location_id		='Y'
--	  OR	x_header_control.bill_to_location_id		='Y'
--	  OR	x_header_control.terms_id			='Y'
--	  OR	x_header_control.ship_via_lookup_code		='Y'
--	  OR	x_header_control.fob_lookup_code		='Y'
--	  OR	x_header_control.freight_terms_lookup_code	='Y'
--	  OR	x_header_control.note_to_vendor			='Y'
--	  OR	x_header_control.acceptance_required_flag 	='Y'
--	  OR	x_header_control.acceptance_due_date		='Y'
--	  OR	x_header_control.start_date			='Y'
--	  OR	x_header_control.end_date			='Y'
--	  OR	
  IF (x_header_control.amount_limit_change >
	         nvl(x_tolerance_control.h_amount_limit_t,0))
	THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## header_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## header_require_reapproval result: N');
		END IF;
		x_result:='N';
	END IF;

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF  	x_lines_control.line_num		='Y'
--	  OR	x_lines_control.item_id			='Y'
--	  OR	x_lines_control.item_revision		='Y'
--	  OR	x_lines_control.item_description	='Y'
--	  OR	x_lines_control.category_id		='Y'
--	  OR	x_lines_control.unit_meas_lookup_code	='Y'
--	  OR	x_lines_control.from_header_id		='Y'
--	  OR	x_lines_control.from_line_id		='Y'
--	  OR	x_lines_control.hazard_class_id		='Y'
--	  OR	x_lines_control.contract_num		='Y'
--	  OR	x_lines_control.vendor_product_num 	='Y'
--	  OR	x_lines_control.un_number_id	 	='Y'
--	  OR	x_lines_control.price_type_lookup_code 	='Y'
--	  OR	x_lines_control.note_to_vendor		='Y'
--	  OR
  IF (x_lines_control.quantity_change >
		 nvl(x_tolerance_control.l_quantity_t,0))
 	  OR	(x_lines_control.unit_price_change >
		 nvl(x_tolerance_control.l_unit_price_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## lines_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## lines_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_shipments_control.shipment_num		='Y'
--	  OR	x_shipments_control.ship_to_location_id		='Y'
--	  OR	x_shipments_control.promised_date		='Y'
--	  OR	x_shipments_control.need_by_date		='Y'
--	  OR	x_shipments_control.last_accept_date		='Y'
--	  OR	
  IF (x_shipments_control.quantity_change >
		 nvl(x_tolerance_control.s_quantity_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

/* Bug 1081717: kagarwal
** Added the Check for change in Charge Account for Distributions
** x_dist_control.code_combination_id = 'Y'
*/
/* Bug 2747157: kagarwal
** Added the Check for change in Gl Date for Distributions
** x_dist_control.gl_encumbered_date = 'Y' .
*/

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_dist_control.distribution_num		='Y'
--          OR	x_dist_control.deliver_to_person_id	='Y'
--          OR    x_dist_control.code_combination_id = 'Y'
--          OR    x_dist_control.gl_encumbered_date = 'Y'
--	  OR	
  IF (x_dist_control.quantity_ordered_change >
		 nvl(x_tolerance_control.d_quantity_ordered_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

	IF x_result = 'Y' THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  Y $$$$$$');
		END IF;
		RESULT := 'Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  N $$$$$$');
		END IF;
		RESULT := 'N';
	END IF;


	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** Finish: planned_po_reapproval ***');
	END IF;
	return;

EXCEPTION

 WHEN OTHERS THEN
  wf_core.context('POAPPRV', 'po_chord_wf6.planned_po_reapproval', 'others');
  RAISE;

END;

/**************************************************************************
 *									  *
 * 	Reapproval Rules for Blanket Purchase Agreement			  *
 * 									  *
 **************************************************************************/

PROCEDURE blanket_po_reapproval(itemtype IN VARCHAR2,
		   		itemkey  IN VARCHAR2,
		   		actid    IN NUMBER,
		   		FUNCMODE IN VARCHAR2,
		   		RESULT   OUT NOCOPY VARCHAR2)
IS
	x_header_control 	t_header_control_type;
	x_lines_control 	t_lines_control_type;
        x_shipments_control     t_shipments_control_type;   /* <TIMEPHASED FPI> */
	x_tolerance_control	t_tolerance_control_type;
	x_result		VARCHAR2(1);
        l_ga_org_assign_change  VARCHAR2(1); -- Bug 2911017
BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: blanket_po_reapproval ***');
	END IF;

	IF funcmode <> 'RUN' THEN
		result := 'COMPLETE';
		return;
	END IF;

	po_chord_wf1.get_wf_header_control(itemtype, itemkey, x_header_control);

	po_chord_wf2.get_wf_lines_control(itemtype, itemkey, x_lines_control);

        /* Get all relevant shipments attribute values */
	po_chord_wf3.get_wf_shipments_control(itemtype, itemkey, x_shipments_control);   /* <TIMEPHASED FPI> */

	xxha_po_chord_wf6.get_default_tolerance(itemtype, itemkey, x_tolerance_control);

	-- 'Y' means modified
	-- Numbers are in Percentage

/*bug 4487674: vendor site id should be considered for the reapproval,
  rules, and if the same has changed the document should be routed through
  the approval hierarchy */

--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--        IF 	x_header_control.agent_id			='Y'
--	  OR    x_header_control.vendor_site_id       		='Y' --bug 4487674
--	  OR	x_header_control.vendor_contact_id		='Y'
--	  OR	x_header_control.confirming_order_flag		='Y'
--	  OR	x_header_control.ship_to_location_id		='Y'
--	  OR	x_header_control.bill_to_location_id		='Y'
--	  OR	x_header_control.terms_id			='Y'
--	  OR	x_header_control.ship_via_lookup_code		='Y'
--	  OR	x_header_control.fob_lookup_code		='Y'
--	  OR	x_header_control.freight_terms_lookup_code	='Y'
--	  OR	x_header_control.note_to_vendor			='Y'
--	  OR	x_header_control.acceptance_required_flag 	='Y'
--	  OR	x_header_control.acceptance_due_date		='Y'
--	  OR	x_header_control.start_date			='Y'
--	  OR	x_header_control.end_date			='Y'
--          OR    x_header_control.amount_limit                   ='Y'   --6616522
--	  OR	
  IF (x_header_control.amount_limit_change >
		 nvl(x_tolerance_control.h_amount_limit_t,0))
	  OR	(x_header_control.blanket_total_change >
		 nvl(x_tolerance_control.h_blanket_total_t,0))

	THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## header_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## header_require_reapproval result: N');
		END IF;
		x_result:='N';
	END IF;

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF  	x_lines_control.line_num		='Y'
--	  OR	x_lines_control.item_id			='Y'
--	  OR	x_lines_control.item_revision		='Y'
--	  OR	x_lines_control.item_description	='Y'
--	  OR	x_lines_control.category_id		='Y'
--	  OR	x_lines_control.unit_meas_lookup_code	='Y'
--	  OR	x_lines_control.from_header_id		='Y'
--	  OR	x_lines_control.from_line_id		='Y'
--	  OR	x_lines_control.hazard_class_id		='Y'
--	  OR	x_lines_control.contract_num		='Y'
--	  OR	x_lines_control.vendor_product_num 	='Y'
--	  OR	x_lines_control.un_number_id	 	='Y'
--	  OR	x_lines_control.price_type_lookup_code 	='Y'
--	  OR	x_lines_control.note_to_vendor		='Y'
--	  OR	
  IF (x_lines_control.quantity_change >
		 nvl(x_tolerance_control.l_quantity_t,0))
 	  OR	(x_lines_control.unit_price_change >
 		 nvl(x_tolerance_control.l_unit_price_t,0))
 	  OR	(x_lines_control.not_to_exceed_price_change >
		 nvl(x_tolerance_control.l_price_limit_t,0))
 	  OR	(x_lines_control.quantity_committed_change >
		 nvl(x_tolerance_control.l_quantity_committed_t,0))
 	  OR	(x_lines_control.committed_amount_change >
		 nvl(x_tolerance_control.l_committed_amount_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## lines_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## lines_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

        /* <TIMEPHASED FPI START> */
        /* Bug 2808011. Added price_override to the reapproval rules */
        IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--           IF     x_shipments_control.shipment_num                ='Y'
--            OR    x_shipments_control.ship_to_location_id         ='Y'
--            OR    x_shipments_control.ship_to_organization_id     ='Y'
--            OR    x_shipments_control.promised_date               ='Y'
--            OR    x_shipments_control.need_by_date                ='Y'
--            OR    x_shipments_control.last_accept_date            ='Y'
--            OR    x_shipments_control.price_discount              ='Y'
--            OR    x_shipments_control.start_date                  ='Y'
--            OR    x_shipments_control.end_date                    ='Y'
--            OR    x_shipments_control.price_override              ='Y'
--            OR    
        IF (x_shipments_control.quantity_change >
                   nvl(x_tolerance_control.s_quantity_t,0))
            OR    (x_shipments_control.price_override_change >
                   nvl(x_tolerance_control.s_price_override_t,0))
           THEN
                IF (g_po_wf_debug = 'Y') THEN
                   PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
                           '########## shipments_require_reapproval result: Y');
                END IF;
                x_result:='Y';
           ELSE
                IF (g_po_wf_debug = 'Y') THEN
                   PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
                           '########## shipments_require_reapproval result: N');
                END IF;
                x_result:='N';
           END IF;
        END IF;
        /* <TIMEPHASED FPI END> */

        -- Bug 2911017 START
        -- Require reapproval if the GA org assignments have been changed.
        IF x_result <> 'Y' THEN
           l_ga_org_assign_change :=
              PO_WF_UTIL_PKG.GetItemAttrText (itemtype , itemkey,'GA_ORG_ASSIGN_CHANGE');
           IF l_ga_org_assign_change = 'Y' THEN
                IF (g_po_wf_debug = 'Y') THEN
                   PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
                           '########## GA org assignments require reapproval result: Y');
                END IF;
                x_result:='Y';
           ELSE
                IF (g_po_wf_debug = 'Y') THEN
                   PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
                           '########## GA org assignments require reapproval result: N');
                END IF;
                x_result:='N';
           END IF;
        END IF;
        -- Bug 2911017 END
    --<CONTERMS FPJ START>
    IF x_result <> 'Y' THEN
       -- Check if contract terms were changed
       x_result := PO_CONTERMS_WF_PVT.contract_terms_changed(
                                      itemtype => itemtype,
                                      itemkey  => itemkey);
    END IF;
    --<CONTERMS FPJ END>
	IF x_result = 'Y' THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  Y $$$$$$');
		END IF;
		RESULT := 'Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  N $$$$$$');
		END IF;
		RESULT := 'N';
	END IF;


	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** Finish: blanket_po_reapproval ***');
	END IF;

END;

/**************************************************************************
 *									  *
 * 	Reapproval Rules for Contract Purchase Agreement		  *
 * 									  *
 **************************************************************************/

PROCEDURE contract_po_reapproval(itemtype IN VARCHAR2,
		   		itemkey  IN VARCHAR2,
		   		actid    IN NUMBER,
		   		FUNCMODE IN VARCHAR2,
		   		RESULT   OUT NOCOPY VARCHAR2)
IS
	x_header_control 	t_header_control_type;
	x_tolerance_control	t_tolerance_control_type;
        l_ga_org_assign_change  VARCHAR2(1); -- Bug 6857012
BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: contract_po_reapproval ***');
	END IF;

	IF funcmode <> 'RUN' THEN
		result := 'COMPLETE';
		return;
	END IF;

	po_chord_wf1.get_wf_header_control(itemtype, itemkey, x_header_control);
	xxha_po_chord_wf6.get_default_tolerance(itemtype, itemkey, x_tolerance_control);

	-- 'Y' means modified
	-- Numbers are in Percentage

/*bug 4487674: vendor site id should be considered for the reapproval,
  rules, and if the same has changed the document should be routed through
  the approval hierarchy */
--Bug5391471 : Blanket total change/amount agreed should be considered for reapproval.


--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--        IF 	x_header_control.agent_id			='Y'
--	  OR    x_header_control.vendor_site_id			='Y' --bug 4487674
--	  OR	x_header_control.vendor_contact_id		='Y'
--	  OR	x_header_control.confirming_order_flag		='Y'
--	  OR	x_header_control.ship_to_location_id		='Y'
--	  OR	x_header_control.bill_to_location_id		='Y'
--	  OR	x_header_control.terms_id			='Y'
--	  OR	x_header_control.ship_via_lookup_code		='Y'
--	  OR	x_header_control.fob_lookup_code		='Y'
--	  OR	x_header_control.freight_terms_lookup_code	='Y'
--	  OR	x_header_control.note_to_vendor			='Y'
--	  OR	x_header_control.acceptance_required_flag 	='Y'
--	  OR	x_header_control.acceptance_due_date		='Y'
--	  OR	x_header_control.start_date			='Y'
--	  OR	x_header_control.end_date			='Y'
--	  OR	
    IF (x_header_control.amount_limit_change >
		 nvl(x_tolerance_control.h_amount_limit_t,0))
          OR	(x_header_control.blanket_total_change >
		 nvl(x_tolerance_control.h_blanket_total_t,0))
        THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## header_require_reapproval result: Y');
		END IF;
		result:='Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## header_require_reapproval result: N');
		END IF;
		result:='N';
	END IF;

        -- Bug 6857012 START
        -- Require reapproval if the GA org assignments have been changed.
        IF result <> 'Y' THEN
           l_ga_org_assign_change :=
              PO_WF_UTIL_PKG.GetItemAttrText (itemtype , itemkey,'GA_ORG_ASSIGN_CHANGE');
           IF l_ga_org_assign_change = 'Y' THEN
                IF (g_po_wf_debug = 'Y') THEN
                   PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
                           '########## GA org assignments require reapproval result: Y');
                END IF;
                result:='Y';
           ELSE
                IF (g_po_wf_debug = 'Y') THEN
                   PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
                           '########## GA org assignments require reapproval result: N');
                END IF;
                result:='N';
           END IF;
        END IF;
        -- Bug 6857012 END

    --<CONTERMS FPJ START>
    IF result <> 'Y' THEN
       -- Check if contract terms were changed
       result := PO_CONTERMS_WF_PVT.contract_terms_changed(
                                      itemtype => itemtype,
                                      itemkey  => itemkey);
    END IF;
    -- Adding the following debug stmt to indicate the final result
    -- now that the contract terms are also there
    IF (g_po_wf_debug = 'Y') THEN
            IF result = 'Y' THEN
         		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
         			'$$$$$$$ Document requires full approval =  Y $$$$$$');
            ELSE
         		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
         			'$$$$$$$ Document requires full approval =  N $$$$$$');
            END IF; -- if result <>'Y'
    END IF; -- if debug 'Y'

   --<CONTERMS FPJ END>

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** Finish: contract_po_reapproval ***');
	END IF;
	return;

EXCEPTION

 WHEN OTHERS THEN
  wf_core.context('POAPPRV', 'po_chord_wf6.contract_po_reapproval', 'others');
  RAISE;

END;

/**************************************************************************
 *									  *
 * 	Reapproval Rules for Blanket Release	 			  *
 * 									  *
 **************************************************************************/

PROCEDURE blanket_release_reapproval(itemtype IN VARCHAR2,
		  	 	     itemkey  IN VARCHAR2,
		   		     actid    IN NUMBER,
		   		     FUNCMODE IN VARCHAR2,
		   		     RESULT   OUT NOCOPY VARCHAR2)
IS
	x_release_control 	t_release_control_type;
	x_shipments_control 	t_shipments_control_type;
	x_dist_control 		t_dist_control_type;
	x_tolerance_control	t_tolerance_control_type;
	x_result		VARCHAR2(1);
	l_retroactive_change     VARCHAR2(1) := 'N'; --  RETROACTIVE FPI
	l_autoapprove_retro     VARCHAR2(1) := 'N'; --  RETROACTIVE FPI
	l_actionoriginated_from   varchar2(30);     --Bug5567534

BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: blanket_release_reapproval ***');
	END IF;

	IF funcmode <> 'RUN' THEN
		result := 'COMPLETE';
		return;
	END IF;

	/* RETROACTIVE FPI CHANGE START.
	 * Get the value of the attribute CO_H_RETROACTIVE_APPROVAL if
	 * this approval is initiated due to the retroactive change in
	 * the release. If this value is Y, then we send the document
	 * through Change Order Workflow.
	*/
	l_retroactive_change := PO_WF_UTIL_PKG.GetItemAttrText
					(itemtype => itemtype,
                                         itemkey  => itemkey,
                                         aname    => 'CO_R_RETRO_CHANGE');

	If (l_retroactive_change = 'Y') then

		l_autoapprove_retro := PO_WF_UTIL_PKG.GetItemAttrText
					(itemtype => itemtype,
					 itemkey  => itemkey,
					 aname    => 'CO_H_RETROACTIVE_AUTOAPPROVAL');

               /*Bug5567534 Get the wf attribute value 'INTERFACE_SOURCE_CODE'.This would be
     	         the value which indicates where the approval workflow is called from.If
	         approval is called from "Retroactive" concurrent program only then check
	         for the "automatic approval" wf attribute */

		 l_actionoriginated_from := PO_WF_UTIL_PKG.GetItemAttrText
		    	                    (itemtype => itemtype,
			                     itemkey  => itemkey,
                                             aname    => 'INTERFACE_SOURCE_CODE');

		if (l_autoapprove_retro = 'Y') AND (l_actionoriginated_from = 'RETRO') then

			IF (g_po_wf_debug = 'Y') THEN
   			PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   				'$$$$$$$ Document requires full approval =  N $$$$$$');
			END IF;
			RESULT := 'N';

			return;
		end if; /* l__autoapprove_retro = 'Y' */

	end if; /* l_retroactive_change = 'Y' */
	/* RETROACTIVE FPI CHANGE END */

		po_chord_wf5.get_wf_release_control(itemtype, itemkey, x_release_control);
		po_chord_wf3.get_wf_shipments_control(itemtype, itemkey, x_shipments_control);
		po_chord_wf4.get_wf_dist_control(itemtype, itemkey, x_dist_control);
		xxha_po_chord_wf6.get_default_tolerance(itemtype, itemkey, x_tolerance_control);

		-- 'Y' means modified
		-- Numbers are in Percentage
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--		IF 	x_release_control.agent_id			='Y'
--		  OR	x_release_control.acceptance_required_flag	='Y'
--		  OR	x_release_control.acceptance_due_date		='Y'
--		  OR	x_release_control.release_num			='Y'
--		  OR	x_release_control.release_date			='Y'
    IF 'X' = 'Y'
		THEN
			IF (g_po_wf_debug = 'Y') THEN
   			PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			 '########## blanket_release_require_reapproval result: Y');
			END IF;
			x_result:='Y';
		ELSE
			IF (g_po_wf_debug = 'Y') THEN
   			PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			 '########## blanket_release_require_reapproval result: N');
			END IF;
			x_result:='N';
		END IF;


	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_shipments_control.shipment_num		='Y'
--	  OR	x_shipments_control.ship_to_location_id		='Y'
--	  OR	x_shipments_control.promised_date		='Y'
--	  OR	x_shipments_control.need_by_date		='Y'
--	  OR	x_shipments_control.last_accept_date		='Y'
--	  OR	
  IF (x_shipments_control.quantity_change >
		 nvl(x_tolerance_control.s_quantity_t,0))
	  OR	(x_shipments_control.price_override_change >
		 nvl(x_tolerance_control.s_price_override_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

/* Bug 1081717: kagarwal
** Added the Check for change in Charge Account for Distributions
** x_dist_control.code_combination_id = 'Y'
*/
/* Bug 2747157: kagarwal
** Added the Check for change in Gl Date for Distributions
** x_dist_control.gl_encumbered_date = 'Y' .
*/

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_dist_control.distribution_num		='Y'
--          OR	x_dist_control.deliver_to_person_id	='Y'
--          OR    x_dist_control.code_combination_id = 'Y'
--          OR    x_dist_control.gl_encumbered_date = 'Y'
--	  OR
  IF (x_dist_control.quantity_ordered_change >
		 nvl(x_tolerance_control.d_quantity_ordered_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

	IF x_result = 'Y' THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  Y $$$$$$');
		END IF;
		RESULT := 'Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  N $$$$$$');
		END IF;
		RESULT := 'N';
	END IF;


	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** Finish: blanket_release_reapproval ***');
	END IF;
	return;

EXCEPTION

 WHEN OTHERS THEN
  wf_core.context('POAPPRV', 'po_chord_wf6.release_reapproval', 'others');
  RAISE;

END;

/**************************************************************************
 *									  *
 * 	Reapproval Rules for Scheduled Release	 			  *
 * 									  *
 **************************************************************************/

PROCEDURE scheduled_release_reapproval(itemtype IN VARCHAR2,
		   		itemkey  IN VARCHAR2,
		   		actid    IN NUMBER,
		   		FUNCMODE IN VARCHAR2,
		   		RESULT   OUT NOCOPY VARCHAR2)
IS
	x_release_control 	t_release_control_type;
	x_shipments_control 	t_shipments_control_type;
	x_dist_control 		t_dist_control_type;
	x_tolerance_control	t_tolerance_control_type;
	x_result		VARCHAR2(1);
BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: scheduled_release_reapproval ***');
	END IF;

	IF funcmode <> 'RUN' THEN
		result := 'COMPLETE';
		return;
	END IF;

	po_chord_wf5.get_wf_release_control(itemtype, itemkey, x_release_control);
	po_chord_wf3.get_wf_shipments_control(itemtype, itemkey, x_shipments_control);
	po_chord_wf4.get_wf_dist_control(itemtype, itemkey, x_dist_control);
	xxha_po_chord_wf6.get_default_tolerance(itemtype, itemkey, x_tolerance_control);

	-- 'Y' means modified
	-- Numbers are in Percentage
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--        IF 	x_release_control.agent_id			='Y'
--	  OR	x_release_control.acceptance_required_flag	='Y'
--	  OR	x_release_control.acceptance_due_date		='Y'
--	  OR	x_release_control.release_num			='Y'
--	  OR	x_release_control.release_date			='Y'
  IF 'X' = 'Y'
	THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		 '########## scheduled_release_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		 '########## scheduled_release_require_reapproval result: N');
		END IF;
		x_result:='N';
	END IF;


	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_shipments_control.shipment_num		='Y'
--	  OR	x_shipments_control.ship_to_location_id		='Y'
--	  OR	x_shipments_control.price_discount		='Y'
--	  OR	x_shipments_control.cancel_flag			='Y'
--	  OR	x_shipments_control.closed_code			='Y'
--	  OR
  IF (x_shipments_control.quantity_change >
		 nvl(x_tolerance_control.s_quantity_t,0))
	  OR	(x_shipments_control.price_override_change >
 		 nvl(x_tolerance_control.s_price_override_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## shipments_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

/* Bug 1081717: kagarwal
** Added the Check for change in Charge Account for Distributions
** x_dist_control.code_combination_id = 'Y'
*/
/* Bug 2747157: kagarwal
** Added the Check for change in Gl Date for Distributions
** x_dist_control.gl_encumbered_date = 'Y' .
*/

	IF x_result <> 'Y' THEN
--commented out by DL on 5/19/2010 to force re-approvals only for $$ value changes
--         IF 	x_dist_control.deliver_to_person_id	='Y'
--          OR    x_dist_control.code_combination_id = 'Y'
--          OR    x_dist_control.gl_encumbered_date = 'Y'
--	  OR	
  IF (x_dist_control.quantity_ordered_change >
		 nvl(x_tolerance_control.d_quantity_ordered_t,0))
	 THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: Y');
		END IF;
		x_result:='Y';
	 ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'########## dist_require_reapproval result: N');
		END IF;
		x_result:='N';
	 END IF;
	END IF;

	IF x_result = 'Y' THEN
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  Y $$$$$$');
		END IF;
		RESULT := 'Y';
	ELSE
		IF (g_po_wf_debug = 'Y') THEN
   		PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   			'$$$$$$$ Document requires full approval =  N $$$$$$');
		END IF;
		RESULT := 'N';
	END IF;


	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** Finish: scheduled_release_reapproval ***');
	END IF;
	return;

EXCEPTION

 WHEN OTHERS THEN
  wf_core.context('POAPPRV', 'po_chord_wf6.scheduled_release_reapproval', 'others');
  RAISE;

END;


/**************************************************************************
 *									  *
 * 	Get user-defined tolerance percentages from workflow definition   *
 * 									  *
 **************************************************************************/

PROCEDURE get_default_tolerance(
	itemtype         IN VARCHAR2,
        itemkey          IN VARCHAR2,
	x_tolerance_control IN OUT NOCOPY t_tolerance_control_type)
IS
BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: get_default_tolerance ***');
	END IF;


	x_tolerance_control.h_blanket_total_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_H_BLANKET_TOTAL_T');

	x_tolerance_control.h_amount_limit_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_H_AMOUNT_LIMIT_T');

     /* Bug 4278227 - changed the attribute name from CO_H_PO_TOTAL_CHANGE to
      CO_H_PO_TOTAL_T */

        x_tolerance_control.h_po_total_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_H_PO_TOTAL_T');

	x_tolerance_control.l_quantity_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_L_QUANTITY_T');

	x_tolerance_control.l_unit_price_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_L_UNIT_PRICE_T');

	x_tolerance_control.l_quantity_committed_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_L_QTY_COMMITTED_T');

	x_tolerance_control.l_committed_amount_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_L_COMMITTED_AMT_T');

	x_tolerance_control.l_price_limit_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_L_NOT_TO_EXCEED_PRICE_T');

	x_tolerance_control.s_quantity_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_S_QUANTITY_T');

	x_tolerance_control.s_price_override_t :=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_S_PRICE_OVERRIDE_T');

	x_tolerance_control.d_quantity_ordered_t:=
                wf_engine.GetItemAttrText(itemtype,
                itemkey,
		'CO_D_QUANTITY_ORDERED_T');

	debug_default_tolerance(itemtype, itemkey,x_tolerance_control);

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** FINISH: get_default_tolerance ***');
	END IF;

EXCEPTION

 WHEN OTHERS THEN
  wf_core.context('POAPPRV', 'po_chord_wf6.get_default_tolerance', 'others');
  RAISE;

END;

PROCEDURE debug_default_tolerance(
	itemtype         IN VARCHAR2,
	itemkey          IN VARCHAR2,
	x_tolerance_control t_tolerance_control_type)
IS
BEGIN

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** In Procedure: debug_default_tolerance ***');
	END IF;

	/* Header Percentage Attibutes */
        IF (g_po_wf_debug = 'Y') THEN
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - h_blanket_total_t        : '||
   		x_tolerance_control.h_blanket_total_t );
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - h_amount_limit_t         : '||
   		x_tolerance_control.h_amount_limit_t );
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - h_po_total_t         : '||
   		x_tolerance_control.h_po_total_t );
        END IF;

	/* Line Percentage Attibutes */
        IF (g_po_wf_debug = 'Y') THEN
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - l_quantity_t             : '||
   		x_tolerance_control.l_quantity_t );
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - l_unit_price_t           : '||
   		x_tolerance_control.l_unit_price_t );
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - l_quantity_committed_t   : '||
   		x_tolerance_control.l_quantity_committed_t );
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - l_committed_amount_t     : '||
   		x_tolerance_control.l_committed_amount_t );
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - l_price_limit_t          : '||
   		x_tolerance_control.l_price_limit_t );
        END IF;

	/* Shipment Percentage Attributes */
        IF (g_po_wf_debug = 'Y') THEN
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - s_quantity_t             : '||
   		x_tolerance_control.s_quantity_t );
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - s_price_override_t       : '||
   		x_tolerance_control.s_price_override_t );
        END IF;

	/* Distributions Attributes */
        IF (g_po_wf_debug = 'Y') THEN
           PO_WF_DEBUG_PKG.insert_debug(itemtype, itemkey,
                   'Tolerance - d_quantity_ordered_t     : '||
   		x_tolerance_control.d_quantity_ordered_t );
        END IF;

	IF (g_po_wf_debug = 'Y') THEN
   	PO_WF_DEBUG_PKG.INSERT_DEBUG(ITEMTYPE, ITEMKEY,
   		'*** FINISH: debug_default_tolerance ***');
	END IF;

EXCEPTION

 WHEN OTHERS THEN
  wf_core.context('POAPPRV', 'po_chord_wf6.debug_default_tolerance', 'others');
  RAISE;

END;

END XXHA_PO_CHORD_WF6;
/
