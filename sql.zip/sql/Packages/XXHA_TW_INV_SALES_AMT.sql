CREATE OR REPLACE PACKAGE XXHA_TW_INV_SALES_AMT AS

/*********************************************************************************************
* Package Name : XXHA_TW_INV_SALES_AMT                                                       *
* Purpose      : This package provides functions to create the Taiwan Sales Amount.          *
*                This package will be used by the XML Report 'XXHA: AR Invoice Report TW'.   *
*                It is called from within FUNCTION 'CF_TW_INV_SALES_AMTFormula'.             *
*                                                                                            *
* Functions    : GET_TW_CHAR                                                                 *
*              : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        14-APR-2011     B. Marcoux           Incident# 56638                            *
*                                                 New Processing to create Taiwan Character  *
*                                                   from Sales Amount.                       *
*********************************************************************************************/

  FUNCTION PROCESS_DATA (P_INV_SALES_AMT   VARCHAR2) RETURN VARCHAR2;

END XXHA_TW_INV_SALES_AMT;
/


CREATE OR REPLACE PACKAGE BODY XXHA_TW_INV_SALES_AMT AS

/*********************************************************************************************
* Package Name : XXHA_TW_INV_SALES_AMT                                                       *
* Purpose      : This package provides functions to create the Taiwan Sales Amount.          *
*                This package will be used by the XML Report 'XXHA: AR Invoice Report TW'.   *
*                It is called from within FUNCTION 'CF_TW_INV_SALES_AMTFormula'.             *
*                                                                                            *
* Functions    : GET_TW_CHAR                                                                 *
*              : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        14-APR-2011     B. Marcoux           Incident# 56638                            *
*                                                 New Processing to create Taiwan Character  *
*                                                   from Sales Amount.                       *
*********************************************************************************************/

--------------------------------------------------------------------------------
  FUNCTION GET_TW_CHAR(P_NUMBER NUMBER) RETURN VARCHAR2 IS

    v_string    VARCHAR2(10);

  BEGIN

    SELECT TAIWAN_NUMBER
      INTO v_string
      FROM HAEMO.XXHA_TAIWAN_NUMBERS
     WHERE US_NUMBER = P_NUMBER;

    RETURN (v_string);

  END;

--------------------------------------------------------------------------------
  FUNCTION PROCESS_DATA(P_INV_SALES_AMT VARCHAR2) RETURN VARCHAR2 IS

    v_counter    INTEGER  := 0;
    v_number     INTEGER  := 0;
    v_length     INTEGER  := 8;
    v_tw_char    VARCHAR2(100);
    v_output     VARCHAR2(100);

  BEGIN

-- Take the first eight (8) characters (left to right)
    FOR v_counter IN 1..v_length LOOP
        v_number  := SUBSTR(P_INV_SALES_AMT,v_counter,1);
        v_tw_char := GET_TW_CHAR(v_number);
        v_output  := v_output || v_tw_char || ' ';
    END LOOP;

    RETURN v_output;

    EXCEPTION
      WHEN OTHERS THEN
        RETURN '';
    END;

END XXHA_TW_INV_SALES_AMT;
/
