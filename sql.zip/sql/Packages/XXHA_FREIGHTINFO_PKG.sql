CREATE OR REPLACE PACKAGE XXHA_FREIGHTINFO_PKG AS 

-- Eric Rossing 
-- 17-OCT-2013
-- Connect as APPS Schema    
--
-- This package provides utility functions for the webMethods Freight Info interface (Precision-to-Oracle)
--
-- ===================================================== 
-- Change Log
-- 2013-10-17	Eric Rossing	Initial release
-- 2013-10-22 Eric Rossing  Updated to delete only one order because original expression can't handle large volume
-- ===================================================== 

PROCEDURE CLEAN_ORDER_IMPORT_TABLES 
(
  P_ORDER_SOURCE_ID IN VARCHAR2,
  P_ORIG_SYS_DOCUMENT_REF IN VARCHAR2
);

PROCEDURE UPDATE_FREIGHT_INFO_PROC_FLAG
(
  P_PROCESSED_FLAG IN VARCHAR2,
  P_DELIVERY_NAME IN VARCHAR2
);

END XXHA_FREIGHTINFO_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_FREIGHTINFO_PKG AS 

-- Eric Rossing 
-- 17-OCT-2013
-- Connect as APPS Schema    
--
-- This package provides utility functions for the webMethods Freight Info interface (Precision-to-Oracle)
--
-- ===================================================== 
-- Change Log
-- 2013-10-17	Eric Rossing	Initial release
-- 2013-10-22 Eric Rossing  Updated to delete only one order because original expression can't handle large volume
-- ===================================================== 

PROCEDURE CLEAN_ORDER_IMPORT_TABLES 
(
  P_ORDER_SOURCE_ID IN VARCHAR2,
  P_ORIG_SYS_DOCUMENT_REF IN VARCHAR2
) IS
BEGIN

  DELETE FROM OE_HEADERS_IFACE_ALL WHERE ORDER_SOURCE_ID = P_ORDER_SOURCE_ID AND ORIG_SYS_DOCUMENT_REF = P_ORIG_SYS_DOCUMENT_REF;
  DELETE FROM OE_LINES_IFACE_ALL WHERE ORDER_SOURCE_ID = P_ORDER_SOURCE_ID AND ORIG_SYS_DOCUMENT_REF = P_ORIG_SYS_DOCUMENT_REF;

END;

PROCEDURE UPDATE_FREIGHT_INFO_PROC_FLAG
(
  P_PROCESSED_FLAG IN VARCHAR2,
  P_DELIVERY_NAME IN VARCHAR2
) IS

BEGIN

  UPDATE HAEMO.XXHA_FREIGHT_INFO_LOG SET PROCESSED_FLAG=P_PROCESSED_FLAG WHERE DELIVERY_NAME=P_DELIVERY_NAME;

END;

END XXHA_FREIGHTINFO_PKG;
/
