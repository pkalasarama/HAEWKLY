create or replace PACKAGE XXHA_SCHEDULED_JOBS_PKG AUTHID CURRENT_USER
AS

/*****************************************************************************************************************************
* Package Name : XXHA_SCHEDULED_JOBS_PKG                                                                                     *
* Purpose      : This package will be utilized to resubmit Scheduled Jobs that may have aborted and were not re-scheduled.   *
*                                                                                                                            *
* PROCEDURES   : RESUBMIT_SCHEDULED_JOBS                                                                                     *
*              : LOAD_SCHEDULED_JOBS_TABLE                                                                                   *
*                                                                                                                            *
* Change History                                                                                                             *
*                                                                                                                            *
* Ver        Date            Author               Description                                                                *
* ------     -----------     -----------------    ---------------                                                            *
* 1.0        19-SEP-2017     BMarcoux             Initial Package creation.                                                  *
*                                                                                                                            *
*****************************************************************************************************************************/

--------------------------------------------------------------------------------
-- PROCEDURE RESUBMIT_SCHEDULED_JOBS

PROCEDURE RESUBMIT_SCHEDULED_JOBS(
                      x_errbuf                             OUT  VARCHAR2
                    , x_retcode                            OUT  VARCHAR2
                      );

--------------------------------------------------------------------------------
-- PROCEDURE LOAD_SCHEDULED_JOBS_TABLE

PROCEDURE LOAD_SCHEDULED_JOBS_TABLE(
                      x_errbuf                             OUT  VARCHAR2
                    , x_retcode                            OUT  VARCHAR2
                      );

END XXHA_SCHEDULED_JOBS_PKG;