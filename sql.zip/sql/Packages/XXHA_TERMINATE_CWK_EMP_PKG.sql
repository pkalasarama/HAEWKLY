CREATE OR REPLACE PACKAGE XXHA_TERMINATE_CWK_EMP_PKG AS

/***********************************************************************************************
* Package Name : XXHA_TERMINATE_CWK_EMP_PKG                                                    *
*                                                                                              *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to terminate a contingent worker.                               *
*                                                                                              *
* Procedures   : p_terminate                                                                   *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
* hr_all_organization_units_tl     S                                                           *
* per_business_groups              S                                                           *
* per_jobs_tl                      S                                                           *
* per_all_people_f                 S                                                           *
* hr_locations_all_tl              S                                                           *
* per_periods_of_service           S                                                           *
* per_assignments_f                S                                                           *
* fnd_user                         S                                                           *
* per_person_types                 S                                                           *
* per_person_type_usages_f         S                                                           *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        15-JUL-2013     B. Marcoux           Initial Version                              *
* 2.0        15-OCT-2013     B. Marcoux           Changed value for 'l_leaving_reason' from    *
*                                                  'TINV' to 'CWK_EOC'.                        *
*                                                 Update to package for BG France.             *
* 3.0        21-OCT-2013     B. Marcoux           Removed 'RAISE' when error is encountered    *
*                                                 Also added code to check for errors before   *
*                                                 calling API's.                               *
*                                                                                              *
***********************************************************************************************/

/* ****************************************************************************************** */
/* This procedure will terminate a contingent worker                                          */

PROCEDURE p_terminate (p_person_id               IN   per_all_people_f.person_id%TYPE
                     , p_period_of_service_ids   IN   per_periods_of_service.period_of_service_id%TYPE
                     , p_term_date               IN   DATE
                      ); 

END XXHA_TERMINATE_CWK_EMP_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_TERMINATE_CWK_EMP_PKG AS

/***********************************************************************************************
* Package Name : XXHA_TERMINATE_CWK_EMP_PKG                                                    *
*                                                                                              *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to terminate a contingent worker.                               *
*                                                                                              *
* Procedures   : p_terminate                                                                   *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
* hr_all_organization_units_tl     S                                                           *
* per_business_groups              S                                                           *
* per_jobs_tl                      S                                                           *
* per_all_people_f                 S                                                           *
* hr_locations_all_tl              S                                                           *
* per_periods_of_service           S                                                           *
* per_assignments_f                S                                                           *
* fnd_user                         S                                                           *
* per_person_types                 S                                                           *
* per_person_type_usages_f         S                                                           *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        15-JUL-2013     B. Marcoux           Initial Version                              *
* 2.0        15-OCT-2013     B. Marcoux           Changed value for 'l_leaving_reason' from    *
*                                                  'TINV' to 'CWK_EOC'.                        *
*                                                 Update to package for BG France.             *
* 3.0        21-OCT-2013     B. Marcoux           Removed 'RAISE' when error is encountered    *
*                                                 Also added code to check for errors before   *
*                                                 calling API's.                               *
*                                                                                              *
***********************************************************************************************/

/* ****************************************************************************************** */
/* This procedure will terminate a contingent worker                                          */

  PROCEDURE p_terminate (p_person_id               IN   per_all_people_f.person_id%TYPE
                       , p_period_of_service_ids   IN   per_periods_of_service.period_of_service_id%TYPE
                       , p_term_date               IN   DATE) IS

-- Variables
   v_supervisor_warning                        BOOLEAN;
   v_event_warning                             BOOLEAN;
   v_interview_warning                         BOOLEAN;
   v_review_warning                            BOOLEAN;
   v_recruiter_warning                         BOOLEAN;
   v_asg_future_changes_warning                BOOLEAN;
   v_pay_proposal_warning                      BOOLEAN;
   v_dod_warning                               BOOLEAN;
   v_entries_changed_warning                   VARCHAR2 (2000);
   v_last_std_process_date_out                 DATE;

   l_Emp_Name                                  per_all_people_f.full_name%TYPE;
   l_Emp_Number                                per_all_people_f.employee_number%TYPE;
   l_Organization                              hr_all_organization_units_tl.name%TYPE;
   l_Job                                       per_jobs_tl.name%TYPE;
   l_Location                                  hr_locations_all_tl.location_code%TYPE;
   l_Business_Group_ID                         per_business_groups.Business_Group_ID%TYPE;
   l_period_of_service_id                      per_periods_of_service.period_of_service_id%TYPE;
   l_person_id                                 per_all_people_f.person_id%TYPE;
   l_person_type_id                            per_person_types.person_type_id%TYPE;
   l_person_type_id_ptu                        per_person_type_usages_f.person_type_id%TYPE;
   l_user_person_type                          per_person_types.user_person_type%TYPE;
   l_person_type_usage_id                      per_person_type_usages_f.person_type_usage_id%TYPE;
   l_person_type_usage_id1                     per_person_type_usages_f.person_type_usage_id%TYPE;
   l_PPF_OBJECT_VERSION_NUMBER                 per_all_people_f.OBJECT_VERSION_NUMBER%TYPE;
   l_PAF_OBJECT_VERSION_NUMBER                 per_assignments_f.OBJECT_VERSION_NUMBER%TYPE;
   l_PPOS_OBJECT_VERSION_NUMBER                per_periods_of_service.OBJECT_VERSION_NUMBER%TYPE;
   l_PTU_OBJECT_VERSION_NUMBER                 per_person_type_usages_f.OBJECT_VERSION_NUMBER%TYPE;
   l_PTU_OBJECT_VERSION_NUMBER1                per_person_type_usages_f.OBJECT_VERSION_NUMBER%TYPE;
   l_person_type_id_term                       per_person_types.person_type_id%TYPE;
   l_person_type_id_terms                      per_person_types.person_type_id%TYPE;

   l_assignment_status_type_id                 NUMBER;
   l_leaving_reason                            VARCHAR2(100)                    := 'CWK_EOC';
-- l_leaving_reason                            VARCHAR2(100)                    := 'TINV';
   l_last_standard_process_date                DATE;
   l_final_process_date                        DATE;
   l_org_now_no_manager_warning                BOOLEAN;
   l_asg_future_changes_warning                BOOLEAN;
   l_entries_changed_warning                   BOOLEAN;
   l_entries_changed_warning_char              VARCHAR2(100);
   l_ppf_effective_start_date                  VARCHAR2(100);
   l_ppf_effective_end_date                    VARCHAR2(100);
   l_paf_effective_start_date                  VARCHAR2(100);
   l_paf_effective_end_date                    VARCHAR2(100);
   l_ptu_effective_start_date_in               VARCHAR2(100);
   l_ptu_effective_start_date_in1              DATE;
   l_ptu_effective_end_date_in                 VARCHAR2(100);
   l_ptu_effective_start_date                  DATE;
   L_PTU_EFFECTIVE_END_DATE                    DATE;
   L_BUSINESS_GROUP_NAME                       VARCHAR2(240);
   L_PDS_INFORMATION_CATEGORY                  VARCHAR2(240);
   L_PDS_INFORMATION13                         VARCHAR2(100);
   L_PDS_INFORMATION10                         VARCHAR2(100);
   l_process                                   VARCHAR2(25);
   l_error                                     VARCHAR2(10)                     := NULL;
   
-- AUDIT
   gc_request_id                               xxha_common_errors.request_id%TYPE             := fnd_global.conc_request_id;
   gc_record_identifier                        xxha_common_errors.record_identifier%TYPE;    
   gc_record_number                            xxha_common_errors.record_number%TYPE;
   gc_error_code                               xxha_common_errors.error_code%TYPE;
   gc_error_msg                                xxha_common_errors.error_msg%TYPE;
   gc_comments                                 xxha_common_errors.comments%TYPE;
   gc_attribute1                               xxha_common_errors.attribute1%TYPE;
   gc_attribute2                               xxha_common_errors.attribute2%TYPE;
   gc_attribute3                               xxha_common_errors.attribute3%TYPE;
   gc_attribute4                               xxha_common_errors.attribute4%TYPE;
   gc_attribute5                               xxha_common_errors.attribute5%TYPE;
   gc_table_name                               xxha_common_errors.TABLE_NAME%TYPE             := 'XXHA_TERMINATE_CWK_EMP';
   gc_status                                   VARCHAR2(2);
   lc_status                                   VARCHAR2(1000);

-- Cursor to retrieve data
   CURSOR C1 
   IS 
   SELECT
         ppf.full_name                         Emp_Name
      ,  ppf.employee_number                   Emp_Number
      ,  houT.name                             Organization
      ,  jbt.name                              Job
      ,  hlT.location_code                     Location
      ,  PBG.BUSINESS_GROUP_ID                 BUSINESS_GROUP_ID
      ,  pbg.name                              Business_group_name
      ,  ppos.period_of_service_id             period_of_service_id
      ,  ppf.person_id                         person_id
      ,  ppt.person_type_id                    person_type_id
      ,  ptu.person_type_id                    person_type_id_ptu
      ,  ppt.user_person_type                  user_person_type
      ,  ptu.person_type_usage_id              person_type_usage_id
      ,  ppts.person_type_id                   person_type_id_term
      ,  pptss.person_type_id                  person_type_id_terms
      ,  ppf.OBJECT_VERSION_NUMBER             ppf_OBJECT_VERSION_NUMBER
      ,  paf.OBJECT_VERSION_NUMBER             paf_OBJECT_VERSION_NUMBER
      ,  ppos.OBJECT_VERSION_NUMBER            ppos_OBJECT_VERSION_NUMBER
      ,  ptu.OBJECT_VERSION_NUMBER             PTU_OBJECT_VERSION_NUMBER
      ,  to_char(ppf.effective_start_date, 'YYYYMMDD')
      ,  to_char(ppf.effective_end_date, 'YYYYMMDD')
      ,  to_char(paf.effective_start_date, 'YYYYMMDD')
      ,  to_char(paf.effective_end_date, 'YYYYMMDD')
      ,  to_char(ptu.effective_start_date, 'YYYYMMDD')
      ,  to_char(ptu.effective_end_date, 'YYYYMMDD')
   FROM  
         hr_all_organization_units_tl          houT
      ,  per_business_groups                   pbg
      ,  per_jobs_tl                           jbt
      ,  per_all_people_f                      ppf
      ,  hr_locations_all_tl                   hlT
      ,  per_periods_of_service                ppos
      ,  per_assignments_f                     paf
      ,  fnd_user                              usr
      ,  per_person_types                      ppt
      ,  per_person_type_usages_f              ptu
      , (SELECT ptu1.business_group_id
              , ptu1.person_type_id
           from per_person_types  ptu1
          where user_person_type  like '%HAE Ex-contingent%') ppts
      , (SELECT ptu1.business_group_id
              , ptu1.person_type_id
           from per_person_types  ptu1
          where user_person_type  = 'Ex-employee') pptss
   WHERE 
         paf.period_of_service_id            = ppos.period_of_service_id
     AND paf.person_id                       = ppf.person_id
     AND paf.business_group_id               = pbg.business_group_id
     AND paf.organization_id                 = houT.organization_id
     AND houT.language                       = userenv('LANG')
     AND paf.job_id                          = jbt.job_id(+)
     AND jbt.language (+)                    = userenv('LANG')
     AND paf.location_id                     = hlT.location_id(+)
     AND hlT.language (+)                    = userenv('LANG')
     AND SYSDATE                             BETWEEN paf.effective_start_date and paf.effective_end_date
     AND SYSDATE                             BETWEEN ppf.effective_start_date and ppf.effective_end_date
     AND SYSDATE                             BETWEEN ptu.effective_start_date and ptu.effective_end_date
     AND ppf.person_id                       = usr.employee_id(+)
     AND ppf.PERSON_TYPE_ID                  = ppt.PERSON_TYPE_ID
     AND paf.business_group_id               = ppt.BUSINESS_GROUP_ID
     AND paf.business_group_id               = ppts.BUSINESS_GROUP_ID(+)
     AND paf.business_group_id               = pptss.BUSINESS_GROUP_ID(+)
     AND paf.person_id                       = ptu.person_id
     AND paf.person_id                       = p_person_id;

-- Cursor to retrieve newly created record in 'per_person_type_usages_f' for Contingent Worker (CWK)
   CURSOR C2
   IS
   SELECT
         ppf.full_name                         Emp_Name
      ,  ppf.employee_number                   Emp_Number
      ,  houT.name                             Organization
      ,  jbt.name                              Job
      ,  hlT.location_code                     Location
      ,  ptu.person_type_usage_id              person_type_usage_id
      ,  ptu.OBJECT_VERSION_NUMBER             PTU_OBJECT_VERSION_NUMBER
      ,  ptu1.effective_start_date             effective_start_date
   FROM  
         hr_all_organization_units_tl          houT
      ,  per_business_groups                   pbg
      ,  per_jobs_tl                           jbt
      ,  per_all_people_f                      ppf
      ,  hr_locations_all_tl                   hlT
      ,  per_periods_of_service                ppos
      ,  per_assignments_f                     paf
      ,  fnd_user                              usr
      ,  per_person_type_usages_f              ptu
      , (SELECT MAX(ptu.effective_start_date)  effective_start_date
                  , max(ptu.object_version_number) max_obj
                  , ptu.person_id              person_id
               from per_person_type_usages_f   ptu
           group by ptu.person_id)             ptu1
   WHERE 
         paf.period_of_service_id            = ppos.period_of_service_id
     AND paf.person_id                       = ppf.person_id
     AND paf.business_group_id               = pbg.business_group_id
     AND paf.organization_id                 = houT.organization_id
     AND houT.language                       = userenv('LANG')
     AND paf.job_id                          = jbt.job_id(+)
     AND jbt.language (+)                    = userenv('LANG')
     AND paf.location_id                     = hlT.location_id(+)
     AND hlT.language (+)                    = userenv('LANG')
     AND ptu1.effective_start_date           BETWEEN paf.effective_start_date and paf.effective_end_date
     AND ptu1.effective_start_date           BETWEEN ppf.effective_start_date and ppf.effective_end_date
     AND ptu1.effective_start_date           BETWEEN ptu.effective_start_date and ptu.effective_end_date
     AND ppf.person_id                       = usr.employee_id(+)
     AND paf.person_id                       = ptu.person_id
     AND ptu.person_id                       = ptu1.person_id
     AND ptu.object_version_number           = ptu1.max_obj
     AND paf.person_id                       = p_person_id;

BEGIN

       OPEN C1;

       FETCH 
         C1
       INTO
         l_Emp_Name
       , l_Emp_Number
       , l_Organization
       , l_Job
       , l_Location
       , L_BUSINESS_GROUP_ID
       , l_business_group_name
       , l_period_of_service_id
       , l_person_id
       , l_person_type_id
       , l_person_type_id_ptu
       , l_user_person_type
       , l_person_type_usage_id
       , l_person_type_id_term
       , l_person_type_id_terms
       , l_PPF_OBJECT_VERSION_NUMBER
       , l_PAF_OBJECT_VERSION_NUMBER
       , l_PPOS_OBJECT_VERSION_NUMBER
       , l_PTU_OBJECT_VERSION_NUMBER
       , l_ppf_effective_start_date
       , l_ppf_effective_end_date
       , l_paf_effective_start_date
       , l_paf_effective_end_date
       , l_ptu_effective_start_date_in
       , l_ptu_effective_end_date_in;

       BEGIN
       
       l_error := NULL;
       
       IF L_BUSINESS_GROUP_NAME = 'BG_FR'
       THEN L_PDS_INFORMATION_CATEGORY := 'FR';
            L_PDS_INFORMATION13        := 
            SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),1,4) || '/' || SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),5,2) || '/' || SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),7,2) || ' 00:00:00';
            L_PDS_INFORMATION10        :=
            SUBSTR(TO_CHAR(P_TERM_DATE,'YYYYMMDD'),1,4) || '/' || SUBSTR(TO_CHAR(P_TERM_DATE,'YYYYMMDD'),5,2) || '/' || SUBSTR(TO_CHAR(P_TERM_DATE,'YYYYMMDD'),7,2) || ' 00:00:00';
            l_process := 'FR';
       ELSE L_PDS_INFORMATION_CATEGORY := NULL;
            L_PDS_INFORMATION13        := NULL;
            L_PDS_INFORMATION10        := NULL;
            l_process := 'NON-FR';
       END IF;
       
       IF l_process = 'FR' THEN
       hr_ex_employee_api.actual_termination_emp
       (
         p_validate                    => FALSE
       , p_effective_date              => p_term_date
       , p_period_of_service_id        => p_period_of_service_ids
       , p_object_version_number       => l_PPOS_OBJECT_VERSION_NUMBER
       , p_actual_termination_date     => p_term_date
       , p_last_standard_process_date  => l_last_standard_process_date
       , p_person_type_id              => l_person_type_id_terms
       , p_assignment_status_type_id   => l_assignment_status_type_id
       , p_leaving_reason              => l_leaving_reason
       , p_attribute_category          => NULL
       , p_attribute1                  => SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),1,4) || '/' || SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),5,2) || '/' || SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),7,2) || ' 00:00:00'
       , P_ATTRIBUTE2                  => 'End of Contract'
       , P_PDS_INFORMATION_CATEGORY    => L_PDS_INFORMATION_CATEGORY
       , P_PDS_INFORMATION13           => L_PDS_INFORMATION13
       , P_PDS_INFORMATION10           => L_PDS_INFORMATION10
       -- OUT
       , p_last_std_process_date_out   => v_last_std_process_date_out
       , p_supervisor_warning          => v_supervisor_warning
       , p_event_warning               => v_event_warning
       , p_interview_warning           => v_interview_warning
       , p_review_warning              => v_review_warning
       , p_recruiter_warning           => v_recruiter_warning
       , p_asg_future_changes_warning  => v_asg_future_changes_warning
       , p_entries_changed_warning     => v_entries_changed_warning
       , p_pay_proposal_warning        => v_pay_proposal_warning
       , p_dod_warning                 => v_dod_warning
       );
       END IF;

       IF l_process <> 'FR' THEN
       hr_ex_employee_api.actual_termination_emp
       (
         p_validate                    => FALSE
       , p_effective_date              => p_term_date
       , p_period_of_service_id        => p_period_of_service_ids
       , p_object_version_number       => l_PPOS_OBJECT_VERSION_NUMBER
       , p_actual_termination_date     => p_term_date
       , p_last_standard_process_date  => l_last_standard_process_date
       , p_person_type_id              => l_person_type_id_terms
       , p_assignment_status_type_id   => l_assignment_status_type_id
       , p_leaving_reason              => l_leaving_reason
       , p_attribute_category          => NULL
       , p_attribute1                  => SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),1,4) || '/' || SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),5,2) || '/' || SUBSTR(to_CHAR(p_term_date,'YYYYMMDD'),7,2) || ' 00:00:00'
       , P_ATTRIBUTE2                  => 'End of Contract'
       -- OUT
       , p_last_std_process_date_out   => v_last_std_process_date_out
       , p_supervisor_warning          => v_supervisor_warning
       , p_event_warning               => v_event_warning
       , p_interview_warning           => v_interview_warning
       , p_review_warning              => v_review_warning
       , p_recruiter_warning           => v_recruiter_warning
       , p_asg_future_changes_warning  => v_asg_future_changes_warning
       , p_entries_changed_warning     => v_entries_changed_warning
       , p_pay_proposal_warning        => v_pay_proposal_warning
       , p_dod_warning                 => v_dod_warning
       );
       END IF;

       EXCEPTION
       WHEN OTHERS THEN
       fnd_file.put_line(fnd_file.log,'XXHA_TERMINATE_CWK_EMP_PKG Error : ' || sqlerrm);
       DBMS_OUTPUT.PUT_LINE('XXHA_TERMINATE_CWK_EMP_PKG Error : ' || sqlerrm);
       GC_RECORD_NUMBER                := 1;
       GC_RECORD_IDENTIFIER            := p_person_id;
       GC_ERROR_CODE                   := 'BA1';
       GC_ERROR_MSG                    := 'ERROR - hr_ex_employee_api.actual_termination_emp';
       GC_COMMENTS                     := sqlerrm;
       GC_ATTRIBUTE1                   := (l_Emp_Number || ' - ' || l_Emp_Name);
       GC_ATTRIBUTE2                   := L_BUSINESS_GROUP_NAME;
       GC_ATTRIBUTE3                   := l_PTU_OBJECT_VERSION_NUMBER;
       GC_ATTRIBUTE4                   := l_person_type_id;
       GC_ATTRIBUTE5                   := l_person_type_usage_id;
       XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);
       l_error := 'Y';
       --RAISE;
       END;

       IF l_error IS NULL THEN
          -- Write out to audit
          GC_RECORD_NUMBER                := 2;
          GC_RECORD_IDENTIFIER            := p_person_id;
          GC_ERROR_CODE                   := 'BA1';
          GC_ERROR_MSG                    := 'UPDATE COMPLETE - hr_ex_employee_api.actual_termination_emp';
          GC_COMMENTS                     := l_Emp_Number;
          GC_ATTRIBUTE1                   := l_Emp_Name;
          GC_ATTRIBUTE2                   := L_BUSINESS_GROUP_NAME;
          GC_ATTRIBUTE3                   := l_PTU_OBJECT_VERSION_NUMBER;
          GC_ATTRIBUTE4                   := l_person_type_id;
          GC_ATTRIBUTE5                   := l_person_type_usage_id;
          XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

          -- Update Term Details
          hr_ex_employee_api.update_term_details_emp
          (
            p_period_of_service_id        => p_period_of_service_ids
          , p_effective_date              => p_term_date
          , p_object_version_number       => l_PPOS_OBJECT_VERSION_NUMBER
          , p_leaving_reason              => l_leaving_reason
          , p_notified_termination_date   => p_term_date
          );
       END IF;

       BEGIN

       IF l_error IS NULL THEN

          OPEN C2;

          FETCH 
            C2 
          INTO
            l_Emp_Name
          , l_Emp_Number
          , l_Organization
          , l_Job
          , l_Location
          , l_person_type_usage_id1
          , l_PTU_OBJECT_VERSION_NUMBER1
          , l_ptu_effective_start_date_in1;

          hr_person_type_usage_api.update_person_type_usage
          (
            p_validate                    => false
          , p_person_type_usage_id        => l_person_type_usage_id1
          , p_effective_date              => l_ptu_effective_start_date_in1
          , p_datetrack_mode              => 'CORRECTION'
          , p_object_version_number       => l_PTU_OBJECT_VERSION_NUMBER1          
          , p_person_type_id              => l_person_type_id_term
          , p_attribute_category          => NULL
          , p_attribute1                  => NULL
          , p_attribute2                  => NULL
          , p_attribute3                  => NULL
          , p_attribute4                  => NULL
          , p_attribute5                  => NULL
          , p_attribute6                  => NULL
          , p_attribute7                  => NULL
          , p_attribute8                  => NULL
          , p_attribute9                  => NULL
          , p_attribute10                 => NULL
          , p_attribute11                 => NULL
          , p_attribute12                 => NULL
          , p_attribute13                 => NULL
          , p_attribute14                 => NULL
          , p_attribute15                 => NULL
          , p_attribute16                 => NULL
          , p_attribute17                 => NULL
          , p_attribute18                 => NULL
          , p_attribute19                 => NULL
          , p_attribute20                 => NULL
          , p_attribute21                 => NULL
          , p_attribute22                 => NULL
          , p_attribute23                 => NULL
          , p_attribute24                 => NULL
          , p_attribute25                 => NULL
          , p_attribute26                 => NULL
          , p_attribute27                 => NULL
          , p_attribute28                 => NULL
          , p_attribute29                 => NULL
          , p_attribute30                 => NULL
          , p_effective_start_date        => l_ptu_effective_start_date
          , p_effective_end_date          => l_ptu_effective_end_date
          );
       END IF;

       EXCEPTION
       WHEN OTHERS THEN
       fnd_file.put_line(fnd_file.log,'XXHA_TERMINATE_CWK_EMP_PKG Error : ' || sqlerrm);
       DBMS_OUTPUT.PUT_LINE('XXHA_TERMINATE_CWK_EMP_PKG Error : ' || sqlerrm);
       GC_RECORD_NUMBER                := 3;
       GC_RECORD_IDENTIFIER            := p_person_id;
       GC_ERROR_CODE                   := 'BA1';
       GC_ERROR_MSG                    := 'ERROR - hr_person_type_usage_api.update_person_type_usage';
       GC_COMMENTS                     := sqlerrm;
       GC_ATTRIBUTE1                   := (l_Emp_Number || ' - ' || l_Emp_Name);
       GC_ATTRIBUTE2                   := l_person_type_id_term;
       GC_ATTRIBUTE3                   := l_PTU_OBJECT_VERSION_NUMBER1;
       GC_ATTRIBUTE4                   := l_person_type_id;
       GC_ATTRIBUTE5                   := l_person_type_usage_id;
       XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);
       --RAISE;
       END;

       IF l_error IS NULL THEN
          -- Write out to audit
          GC_RECORD_NUMBER                := 4;
          GC_RECORD_IDENTIFIER            := p_person_id;
          GC_ERROR_CODE                   := 'BA1';
          GC_ERROR_MSG                    := 'UPDATE COMPLETE - hr_person_type_usage_api.update_person_type_usage';
          GC_COMMENTS                     := l_Emp_Number;
          GC_ATTRIBUTE1                   := l_Emp_Name;
          GC_ATTRIBUTE2                   := l_person_type_id_term;
          GC_ATTRIBUTE3                   := l_PTU_OBJECT_VERSION_NUMBER1;
          GC_ATTRIBUTE4                   := l_person_type_id;
          GC_ATTRIBUTE5                   := l_person_type_usage_id;
          XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);
       END IF;

END;
-- END for BEGIN

END XXHA_TERMINATE_CWK_EMP_PKG;
/
