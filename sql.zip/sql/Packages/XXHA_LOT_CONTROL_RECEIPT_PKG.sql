CREATE OR REPLACE package xxha_lot_control_receipt_pkg
as
    PROCEDURE MAIN(
	       err_buf      out  VARCHAR2
              ,ret_code     OUT  VARCHAR2
              ,p_transaction_type_name IN VARCHAR2
              ,p_account_alias IN VARCHAR2
              ,p_commit_flag  IN   VARCHAR2 DEFAULT 'Y'
              );
end xxha_lot_control_receipt_pkg;
/


CREATE OR REPLACE package body xxha_lot_control_receipt_pkg
as
    PROCEDURE MAIN(
	       err_buf      out  VARCHAR2
              ,ret_code     OUT  VARCHAR2
              ,p_transaction_type_name IN VARCHAR2
              ,p_account_alias IN VARCHAR2
              ,p_commit_flag  IN   VARCHAR2 DEFAULT 'Y'
              ) is

        Cursor c_transaction_data is
        SELECT mp.organization_id,
               rc.organization_code,
               item.inventory_item_id,
               rc.revision,
               item.primary_uom_code,
               sub.secondary_inventory_name,
               rc.locator,
               rc.transaction_qty,
               rc.lot_number,
               rc.lot_expiration_date,
               substr(locator,1,(instr(locator,'.')-1)) loc_segment1,
               '0' loc_segment2,
               '0' loc_segment3
        FROM HAEMO.XXHA_OH_LOT_CONTROL_RECEIPT rc,
             mtl_parameters mp,
             mtl_secondary_inventories sub,
             mtl_system_items_b item
        WHERE  1= 1
        AND   rc.segment1 = item.segment1
        and   rc.organization_code = mp.organization_code
        and   item.organization_id = mp.organization_id
        and   rc.subinventory_code = sub.secondary_inventory_name
        and   sub.organization_id = mp.organization_id 
        -- and   rc.segment1 = 'T0024-00 LOT' and rc.subinventory_code = 'DEP001'
        ;

 
  lc_code_combination_id   number;
  lc_transaction_type_id   number;
  lc_transaction_action_id number;
  lc_transaction_source_type_id  number;
  lc_material_transactions_id number;
  lc_count number := 0;
  lc_locator_id   number;
  lc_disposition_id number; 
  lc_reason_id             number; 
BEGIN


/*
select code_combination_id
into lc_code_combination_id
from gl_code_combinations_kfv
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000';
*/

select transaction_type_id, 
       transaction_action_id, 
       transaction_source_type_id
into   lc_transaction_type_id,
       lc_transaction_action_id,
       lc_transaction_source_type_id
from   mtl_transaction_types
where  UPPER(transaction_type_name) = UPPER(p_transaction_type_name);

begin
 select reason_id 
 into   lc_reason_id
 from   MTL_TRANSACTION_REASONS 
 where  reason_name = 'LOT CNV'; 
exception
    when no_data_found then 
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Txn Reason not setup; Error :'||substr(sqlerrm,1,80));
      ret_code := 3;   
      rollback;     
    when others then
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Txn Reason generic error :'||substr(sqlerrm,1,80));
      ret_code := 3;   
      rollback; 
end; 


for r_transaction_data in c_transaction_data
loop


   begin 
    
    -- Due to the way the account alias is setup in PROD for JPO and ATO we have to use this workaround as INV ADJ in these
    -- two orgs refer to a different account in complete contrast to other orgs.
    if r_transaction_data.organization_code in ('JPO','ATO') then
      select code_combination_id, null
      into lc_code_combination_id, lc_disposition_id
      from gl_code_combinations_kfv
      where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000';
    else
     select distribution_account,disposition_id
     into   lc_code_combination_id, lc_disposition_id
     from   MTL_GENERIC_DISPOSITIONS a 
     where  segment1 = p_account_alias -- default:'INV ADJ' 
     and    organization_id = r_transaction_data.organization_id;  -- (BTS:105)
    end if ;
     -- FND_FILE.PUT_LINE(FND_FILE.LOG,'distribution_account: '||lc_code_combination_id);
   exception
    when no_data_found then 
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Account Alias not setup; Error :'||substr(sqlerrm,1,80));
      ret_code := 3;   
      rollback;     
    when others then
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Account Alias generic error :'||substr(sqlerrm,1,80));
      ret_code := 3;   
      rollback;  
   
   end ; 

   SELECT mtl_material_transactions_s.nextval
   INTO   lc_material_transactions_id
   FROM   DUAL;

--   if (r_transaction_data.locator is not null and r_transaction_data.locator != '..' )
--   then
--   begin
--   select loc.inventory_location_id
--   into lc_locator_id
--   from mtl_item_locations_kfv loc
--    where 1=1 
--        and   loc.concatenated_segments =  r_transaction_data.locator
--        and   loc.organization_id = r_transaction_data.organization_id
--        and   loc.inventory_item_id = r_transaction_data.inventory_item_id
--        and   loc.subinventory_code = r_transaction_data.secondary_inventory_name
--        -- and   mp.organization_id = item.organization_id
--        -- and   loc.subinventory_code = sub.secondary_inventory_name
--        -- and  sub.organization_id = mp.organization_id;

--   exception
--   when others
--   then
--       FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in deriving locator_id '||sqlerrm);
--       raise;
--   end;
--   else
--       lc_locator_id := null;
--   end if;

   insert into mtl_transactions_interface
	(
                                                     last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                    --,locator_id
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    ,transaction_source_name
                                                    ,loc_segment1
                                                    ,loc_segment2
                                                    ,loc_segment3
                                                    ,reason_id 
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id
                                                   ,'LOT ACCT ALIAS RECEIPT'
                                                   ,1 -- source_line_id
                                                   ,1 -- source_header_id
                                                   ,1 -- process_flag (1 = 'YES', 2 = 'NO') 
                                                   ,3 -- transaction_mode (Choose 3 per eTRM: https://etrm.oracle.com/pls/trm11510/etrm_pnav.show_object?c_name=MTL_TRANSACTIONS_INTERFACE&c_owner=INV&c_type=TABLE)
                                                   ,2 -- lock_flag
                                                   ,r_transaction_data.inventory_item_id
                                                   ,r_transaction_data.revision
                                                   ,r_transaction_data.organization_id
                                                   ,r_transaction_data.secondary_inventory_name
                                                   --,lc_locator_id
                                                   ,r_transaction_data.transaction_qty
                                                   ,r_transaction_data.primary_uom_code
                                                   ,sysdate
                                                   ,lc_transaction_type_id
                                                   ,lc_code_combination_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   ,null
                                                   ,r_transaction_data.loc_segment1
                                                   ,r_transaction_data.loc_segment2
                                                   ,r_transaction_data.loc_segment3  
                                                   ,lc_reason_id                                                 
                                                  );
                                                  
   if UPPER(p_transaction_type_name) = UPPER('Miscellaneous receipt') -- UPPER('Account alias receipt')    
   then
      INSERT INTO MTL_TRANSACTION_LOTS_INTERFACE
       (      TRANSACTION_INTERFACE_ID,
              LAST_UPDATE_DATE,
              LAST_UPDATED_BY,
              CREATION_DATE,
              CREATED_BY,
              LOT_NUMBER,
              TRANSACTION_QUANTITY,
              LOT_EXPIRATION_DATE
        )
      VALUES ( lc_material_transactions_id, -- v_material_trx_seq,
            SYSDATE,
            fnd_global.user_id,
            SYSDATE,
            fnd_global.user_id,
            r_transaction_data.lot_number,
            r_transaction_data.transaction_qty, -- DECODE(p_issue_or_receipt,'ISSUE',-1*p_transaction_quantity,'RECEIPT',p_transaction_quantity)
            r_transaction_data.lot_expiration_date
           );

   end if;     
                                                   

--   if p_transaction_type_name = 'Miscellanous receipt'
--   then
--		INSERT INTO mtl_serial_numbers_interface(
--                                                       last_update_date
--                                                      ,last_updated_by
--                                                      ,creation_date
--                                                      ,created_by
--                                                      ,transaction_interface_id
--                                                      ,fm_serial_number
--						      ,to_serial_number
--						       ,source_code
--                                                      )
--                                               VALUES(
--                                                      SYSDATE
--                                                     ,fnd_global.user_id
--                                                     ,SYSDATE
--                                                     ,fnd_global.user_id
--                                                     ,lc_material_transactions_id
--                                                     ,r_transaction_data.serial_number
--						     ,r_transaction_data.serial_number
--						     ,'INV ADJ'
--                                                     );

--   end if;
   lc_count := lc_count + 1;
end loop;
if (p_commit_flag = 'Y')
then
   commit;
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Committed');

else
   rollback;
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Rolled Back');
end if;

FND_FILE.PUT_LINE(FND_FILE.LOG,'Number of records processed '||lc_count);


EXCEPTION
WHEN OTHERS
THEN
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Error :'||substr(sqlerrm,1,80));
    ret_code := 3;   
    rollback;    
END MAIN;
end xxha_lot_control_receipt_pkg ;
/
