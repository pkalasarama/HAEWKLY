CREATE OR REPLACE PACKAGE XXHA_SEND_FILES_PKG IS
  PROCEDURE SEND_REQ_LOG(errbuf   OUT VARCHAR2,
                         retcode  OUT NUMBER,
                         P_REQ_ID IN VARCHAR2,
                         P_EMAIL  IN VARCHAR2);
  PROCEDURE xxha_Generate_SR_Tasks(errbuf               OUT NOCOPY VARCHAR2,
                                   retcode              OUT NOCOPY NUMBER,
                                   P_Api_Version_Number IN NUMBER,
                                   p_period_size        IN NUMBER,
                                   p_org_id             IN NUMBER);
END XXHA_SEND_FILES_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_SEND_FILES_PKG IS

  PROCEDURE SEND_REQ_LOG(errbuf  OUT VARCHAR2,
                         retcode OUT NUMBER,
                         P_REQ_ID IN VARCHAR2,
                         P_EMAIL  IN VARCHAR2
                         ) IS

lRequest_id        NUMBER;
i                  number :=1;
lEmail             VARCHAR2(240);
lFileName          VARCHAR2(240);
lEmailSubject      VARCHAR2(240):=null;
lEmailBody         VARCHAR2(255);
lShortFileName     VARCHAR2(255);
lQuery             VARCHAR2(10000);
v_c                sys_refcursor;
lPrompt            VarChar2(1000);
lVal               VarChar2(1000);
lValF              VarChar2(1000);
lValueSet_Id       Number;
lValidation_type   VarChar2(1);
lUserClause        varchar2(1000):='';
lString            varchar2(1000):='';
lSelect            varchar2(1000):='';
lParamsString      varchar2(2000):='';
lmapping_code      VarChar2(1000);
lsuccess           Number;
lappl_id           Number;
lresp_id           Number;


BEGIN
 select responsibility_application_id, responsibility_id
   into lappl_id, lresp_id
   from fnd_concurrent_requests
  where request_id = P_REQ_ID;

 fnd_global.apps_initialize(0, lresp_id, lappl_id);

 lQuery := 'select a.FORM_LEFT_PROMPT||'': '' PROMPT,  case ';
 while(i <= 25) loop
   lQuery := lQuery||' when row_number() over (order by a.COLUMN_SEQ_NUM) = '||i||' then r.argument'||i||chr(13)||chr(10);
   i := i + 1;
 end loop;

 while(i <= 100) loop
   lQuery := lQuery||' when row_number() over (order by a.COLUMN_SEQ_NUM) = '||i||' then ra.argument'||i||chr(13)||chr(10);
   i := i + 1;
 end loop;

 lQuery := lQuery||'end as val, a.FLEX_VALUE_SET_ID, vs.validation_type' || chr(10) ||
          ' from fnd_concurrent_requests r,' || chr(10) ||
          'fnd_concurrent_programs p,' || chr(10) ||
          'fnd_descr_flex_col_usage_vl a,' || chr(10) ||
          'fnd_flex_value_sets vs,' || chr(10) ||
          'FND_CONC_REQUEST_ARGUMENTS ra' || chr(10) ||
          'where r.request_id = :request_id' || chr(10) ||
          'and r.concurrent_program_id = p.concurrent_program_id' || chr(10) ||
          'and r.program_application_id = p.application_id' || chr(10) ||
          'and r.request_id = ra.request_id(+)' || chr(10) ||
          'and a.FLEX_VALUE_SET_ID = vs.flex_value_set_id(+)' || chr(10) ||
          'and a.descriptive_flexfield_name = ''$SRS$.''||p.concurrent_program_name'|| chr(10) ||
          'order by a.COLUMN_SEQ_NUM';

  open v_c for lQuery using P_REQ_ID;
  loop
      fetch v_c into lPrompt, lVal, lValueSet_Id, lValidation_type;
      EXIT WHEN v_c%NOTFOUND;

      if (lValidation_type = 'F') and (lVal is not null) then

        select ID_COLUMN_NAME
          into lUserClause
          from FND_FLEX_VALIDATION_TABLES
         where flex_value_set_id = lValueSet_Id;

        lUserClause := lUserClause||' = '''||lVal||'''';

        fnd_flex_val_api.get_table_vset_select(p_value_set_id => lValueSet_Id,
                                               p_inc_id_col => 'N',
                                               p_inc_meaning_col => 'N',
                                               p_inc_user_where_clause => 'Y',
                                               p_user_where_clause => lUserClause,
                                               x_select => lSelect,
                                               x_mapping_code => lmapping_code,
                                               x_success => lsuccess);

        if instr(lSelect, ':') = 0 then
          begin
            execute immediate lSelect
            into lValF;

            lString := lPrompt||lValF||' (ID: '||lVal||')';
          exception
            when NO_DATA_FOUND then lString := lPrompt||lVal/*||' (Warning: no value meaning found.)'*/;
            when OTHERS then lString := lPrompt||lVal;
          end;
        else
          lString := lPrompt||lVal/*||' (Warning: There is no way to get value meaning, because value set is depended. Expected functionality.)'*/;
        end if;
      elsif (lValidation_type = 'I') and (lVal is not null) then

        begin
          SELECT DESCRIPTION
            INTO lValF
            FROM FND_FLEX_VALUES_VL
           WHERE FLEX_VALUE_SET_ID = lValueSet_Id
             AND FLEX_VALUE = lVal;

          lString := lPrompt||lValF||' (ID: '||lVal||')';
        exception
          when NO_DATA_FOUND then lString := lPrompt||lVal/*||' (Warning: no value meaning found.)'*/;
        end;
      else
        lString := lPrompt||lVal;
      end if;

      lParamsString := lParamsString||lString|| CHR(13) || CHR(10);
  end loop;
  close v_c;

  FND_FILE.PUT_LINE(FND_FILE.LOG,'lParamsString: '||lParamsString);
  FND_FILE.PUT_LINE(FND_FILE.LOG,'lQuery: '||lQuery);

    select
    P_EMAIL as lEmail,
    cr.logfile_name as lFileName,
    cpt.user_concurrent_program_name||' program Log file(Request_id='||cr.request_id||')' as lEmailSubject,
    'Log file from '||cpt.user_concurrent_program_name||' program  ' || CHR(13) || CHR(10) ||
    'Request_id='||cr.request_id|| CHR(13) || CHR(10) ||
    'Parameters:  ' || CHR(13) || CHR(10) || lParamsString as lEmailBody,
    substr(cr.logfile_name, 1, instr(cr.logfile_name,'/',-1)) as lShortFileName
    into   lEmail,
           lFileName,
           lEmailSubject,
           lEmailBody,
           lShortFileName
    from fnd_concurrent_requests cr,
        fnd_concurrent_programs_tl cpt
    where cr.concurrent_program_id = cpt.concurrent_program_id
        and cpt.language = userenv('LANG')
        and cr.request_id = P_REQ_ID;

     lRequest_id := fnd_request.submit_request ( application => 'HAEMO'
                                                , program => 'XXHA_SEND_EMAIL'
                                                , start_time => null
                                                , argument1 => lEmail
                                                , argument2 => lFileName
                                                , argument3 => lEmailSubject
                                                , argument4 => lEmailBody
                                                , argument5 => lShortFileName
                                                , argument6 => ''
                                                );
        commit;
   FND_FILE.PUT_LINE(FND_FILE.LOG,'lRequest_id(XXHA_SEND_MAIL): '||lRequest_id);
 EXCEPTION
    WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error: '||sqlerrm);
  END SEND_REQ_LOG;

PROCEDURE xxha_Generate_SR_Tasks (
  	errbuf			         OUT  NOCOPY VARCHAR2,
    retcode			         OUT  NOCOPY NUMBER,
  	P_Api_Version_Number IN   NUMBER,
  	p_period_size 		   IN   NUMBER,
    p_org_id 		         IN   NUMBER
  	) IS

lRequest_id        NUMBER;
lEmail             varchar(500);
lSubject           varchar(500);
lBody              varchar(500);
v_request_phase varchar2(100);
v_request_status varchar2(100);
v_request_message varchar2(500);
v_request_dev_phase varchar2(100);
v_request_dev_status varchar2(100);
BEGIN

    FND_REQUEST.SET_ORG_ID(MO_GLOBAL.get_current_org_id);

    lRequest_id := fnd_request.submit_request ( application => 'CSF'
                                                , program => 'CSFPMSRT'
                                                , description => 'Preventive Maintenance Generate Service requests and Tasks'
                                                , start_time => sysdate
                                                , sub_request => null
                                                , ARGUMENT1 => P_API_VERSION_NUMBER
                                                , ARGUMENT2 => P_PERIOD_SIZE);
                                               --commented by sreeram , argument3 => p_org_id);
    commit;
    FND_FILE.PUT_LINE(FND_FILE.LOG,'lRequest_id(CSFPMSRT): '||lRequest_id);
    if fnd_concurrent.wait_for_request(lRequest_id,
                                                            180,
                                                            0,
                                                            v_request_phase,
                                                            v_request_status,
                                                            v_request_dev_phase,
                                                            v_request_dev_status,
                                                            v_request_message) then
    FOR rec IN
    (select
    --t.flex_value_meaning,
    t.description

      from FND_FLEX_VALUES_tl t,
           FND_FLEX_VALUES v,
           fnd_flex_value_sets vs
      where t.flex_value_id = v.flex_value_id
        and v.FLEX_VALUE_SET_ID = vs.FLEX_VALUE_SET_ID
        and vs.FLEX_VALUE_SET_name = 'XXHA_CS_PM_PGM_EMAIL_LIST'
        and t.language = userenv('LANG')
        and t.flex_value_meaning like fnd_global.org_name||'%'
        and v.enabled_flag = 'Y'
        and TRUNC( SYSDATE) BETWEEN TRUNC( NVL( v.start_date_active, SYSDATE ) )
                                AND TRUNC( NVL( v.end_date_active, SYSDATE ) )
    union
    select
    --t.flex_value_meaning,
    t.description
      from FND_FLEX_VALUES_tl t,
           FND_FLEX_VALUES v,
           fnd_flex_value_sets vs
      where t.flex_value_id = v.flex_value_id
        and v.FLEX_VALUE_SET_ID = vs.FLEX_VALUE_SET_ID
        and vs.FLEX_VALUE_SET_name = 'XXHA_CS_PM_PGM_EMAIL_LIST'
        and t.language = userenv('LANG')
        and t.flex_value_meaning like 'ALL%'
        and v.enabled_flag = 'Y'
        and TRUNC( SYSDATE) BETWEEN TRUNC( NVL( v.start_date_active, SYSDATE ) )
                                AND TRUNC( NVL( v.end_date_active, SYSDATE ) )
                                )
         loop
       	     lEmail := lEmail || rec.description || ', ';
       	 end loop;
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Org_name: '||fnd_global.org_name);
    FND_FILE.PUT_LINE(FND_FILE.LOG,'lEmail: '||lEmail);
    SEND_REQ_LOG(errbuf, retcode, lRequest_id, lEmail);
    end if;

EXCEPTION
    WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error: '||sqlerrm);

end xxha_Generate_SR_Tasks;


END XXHA_SEND_FILES_PKG;
/
