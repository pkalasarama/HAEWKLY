CREATE OR REPLACE PACKAGE      XXHA_DRM_ACCOUNTS_INT_NIGHTLY
IS

/*****************************************************************************************
* Name/Purpose : Package Body XXHA_DRM_ACCOUNTS_INT_NIGHTLY                                *
*                This job refreshes the DRM hierarchy every night and adds the cust account *
*                deltas captured during the day from EBS back into DRM                   *
*                                                                                        *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 10-OCT-2013     Varun Uppal          Initial Creation                                  *
* 21-JAN-2014     Varun Uppal          Update DRM_HIER_UPDATES procedure                 *
* 12-FEB-2014     Varun Uppal          Code enhancements for NA DRM                      *
* 27-MAR-2014     Ian Menzies          Fix for removing special chars from node names    *
*                                       and to prevent cust name change problems         *
*****************************************************************************************/

      PROCEDURE CUST_ACCTS_DELTA;
      PROCEDURE REFRESH_DRM_ACCT_STG;
      PROCEDURE DRM_HIER_UPDATES;
      PROCEDURE ADD_DRM_ACCTS;
     
END XXHA_DRM_ACCOUNTS_INT_NIGHTLY;
/


CREATE OR REPLACE PACKAGE BODY      XXHA_DRM_ACCOUNTS_INT_NIGHTLY
IS
   /*****************************************************************************************
   * Name/Purpose : Package Body XXHA_DRM_ACCOUNTS_INT_NIGHTLY                                *
   *                This job refreshes the DRM hierarchy every night and adds the cust account *
   *                deltas captured during the day from EBS back into DRM                   *
   *                                                                                        *
   * Date            Author               Description                                       *
   * -----------     -----------------    ---------------                                   *
   * 10-OCT-2013     Varun Uppal          Initial Creation                                  *
   * 21-JAN-2014     Varun Uppal          Update DRM_HIER_UPDATES procedure                 *
   * 12-FEB-2014     Varun Uppal          Code enhancements for NA DRM                      *
   * 18-MAR-2014     Ian Menzies          Fix for adding new site to Multi-Cust Contract    *
   * 27-MAR-2014     Ian Menzies          Fix for removing special chars from node names    *
   *                                       and to prevent cust name change problems         *
   * 22-JUL-2014     Ian Menzies          Enhancement to allow for name changes to flow     *
   *****************************************************************************************/

   PROCEDURE CUST_ACCTS_DELTA
   IS
      v_ERROR_MESSAGE             VARCHAR2 (4000);
      v_night_proc_cnt            NUMBER;
      v_curr_process_status_cnt   NUMBER;
      v_start_tmstmp              TIMESTAMP (6);
   BEGIN
      DBMS_OUTPUT.PUT_LINE ('Procedure begins: ' || CURRENT_DATE);

      -- check nightly process status to ensure it is not running
      SELECT NVL (COUNT (*), 0)
        INTO v_night_proc_cnt
        FROM HAEMO.XXHA_DRM_INT_PROCESS_STATUS
       WHERE     process_name = 'DRM_NIGHTLY_PROCESS'
             AND process_running_status = 'Y';


      -- check if hourly process status to ensure it is not running
      SELECT NVL (COUNT (*), 0)
        INTO v_curr_process_status_cnt
        FROM HAEMO.XXHA_DRM_INT_PROCESS_STATUS
       WHERE     process_name = 'DRM_HOURLY_PROCESS'
             AND process_running_status = 'Y';

      IF v_night_proc_cnt = 0 AND v_curr_process_status_cnt = 0
      THEN
         SELECT CURRENT_TIMESTAMP INTO v_start_tmstmp FROM DUAL;

         -- add new process entry into the table
         INSERT
           INTO HAEMO.XXHA_DRM_INT_PROCESS_STATUS (PROCESS_NAME,
                                                   PROCESS_RUNNING_STATUS,
                                                   PROCESS_START_TMSTMP)
         VALUES ('DRM_NIGHTLY_PROCESS', 'Y', v_start_tmstmp);


         REFRESH_DRM_ACCT_STG ();
         DRM_HIER_UPDATES ();
         ADD_DRM_ACCTS ();

         -- set the status for the current process
         UPDATE HAEMO.XXHA_DRM_INT_PROCESS_STATUS
            SET process_running_status = 'N',
                process_end_tmstmp = CURRENT_TIMESTAMP
          WHERE     process_running_status = 'Y'
                AND process_name = 'DRM_NIGHTLY_PROCESS'
                AND process_start_tmstmp = v_start_tmstmp;

         COMMIT;


         DBMS_OUTPUT.PUT_LINE ('Procedure ends: ' || CURRENT_DATE);
      ELSE
         DBMS_OUTPUT.PUT_LINE ('Nightly or Daily Processs Running');
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_ERROR_MESSAGE := 'ERROR: ' || SQLERRM;
         DBMS_OUTPUT.PUT_LINE (v_ERROR_MESSAGE);

         RAISE;
   END CUST_ACCTS_DELTA;

   PROCEDURE REFRESH_DRM_ACCT_STG
   IS
      v_ERROR_MESSAGE   VARCHAR2 (4000);
   BEGIN
      DBMS_OUTPUT.PUT_LINE ('Delete DRM_STG_PREV begins: ' || CURRENT_DATE);

      DELETE FROM HAEMO.XXHA_DRM_ACCT_STG_PREV;

      DBMS_OUTPUT.PUT_LINE (
         'Begin DRM Current Copy into PREV: ' || CURRENT_DATE);

      INSERT INTO HAEMO.XXHA_DRM_ACCT_STG_PREV
         SELECT * FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT;

      DBMS_OUTPUT.PUT_LINE (
         'Rows inserted into DRM_STG_PREV: ' || SQL%ROWCOUNT);

      COMMIT;

      DBMS_OUTPUT.PUT_LINE ('DRM Current Copied into PREV: ' || CURRENT_DATE);

      DBMS_OUTPUT.PUT_LINE (
         'Begin DRM EXP Copy into CURRENT: ' || CURRENT_DATE);

      DELETE FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT;

      INSERT INTO HAEMO.XXHA_DRM_ACCT_STG_CURRENT
         SELECT * FROM HAEMO.XXHA_DRM_ACCT_STG_EXP;

      DBMS_OUTPUT.PUT_LINE (
         'Rows inserted into DRM_STG_CURRENT: ' || SQL%ROWCOUNT);

      COMMIT;

      DBMS_OUTPUT.PUT_LINE ('DRM EXP Copied into CURRENT: ' || CURRENT_DATE);
   EXCEPTION
      WHEN OTHERS
      THEN
         v_ERROR_MESSAGE := 'ERROR: ' || SQLERRM;
         DBMS_OUTPUT.PUT_LINE (v_ERROR_MESSAGE);

         RAISE;
   END REFRESH_DRM_ACCT_STG;

   PROCEDURE DRM_HIER_UPDATES
   IS
      v_ERROR_MESSAGE   VARCHAR2 (4000);
      v_wm_seq          NUMBER (10, 0);
   BEGIN
      DBMS_OUTPUT.PUT_LINE (
         'DRM Hierarchy Updt Proc begins: ' || CURRENT_DATE);


      SELECT HAEMO.XXHA_WM_DRM_SFDC_INT_SEQ.NEXTVAL INTO v_wm_seq FROM DUAL;

      INSERT
        INTO HAEMO.XXHA_WM_DRM_SFDC_INT_STATUS (PROCESS_ID,
                                                PROCESS_NAME,
                                                PROCESS_RUNNING_STATUS)
      VALUES (v_wm_seq, 'WM-SFDC Hourly', 'Y');

      MERGE INTO HAEMO.XXHA_EBS_SFDC_ACCT_STG A
           USING (SELECT DISTINCT
                         v_wm_seq AS PROCESS_ID,
                         CDI.CUSTOMER_NAME,
                         CUSTOMER_TYPE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.ADDRESS,
                                 NULL)
                            AS BILLING_STREET,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.CITY,
                                 NULL)
                            AS BILLING_CITY,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.STATE,
                                 NULL)
                            AS BILLING_STATE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.POSTAL_CODE,
                                 NULL)
                            AS BILLING_POSTAL_CODE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'BILL_TO', CDI.COUNTRY,
                                 NULL)
                            AS BILLING_COUNTRY,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.ADDRESS,
                                 NULL)
                            AS SHIPPING_STREET,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.CITY,
                                 NULL)
                            AS SHIPPING_CITY,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.STATE,
                                 NULL)
                            AS SHIPPING_STATE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.POSTAL_CODE,
                                 NULL)
                            AS SHIPPING_POSTAL_CODE,
                         DECODE (CDI.SITE_USE_CODE,
                                 'SHIP_TO', CDI.COUNTRY,
                                 NULL)
                            AS SHIPPING_COUNTRY,
                         PHONE_NUMBER,
                         FAX_NUMBER,
                         CDI.ORG_ID,
                         AGENT,
                         cdi.CUSTOMER_NUMBER,
                         SITE_USE_CODE,
                         SITE_USE_ID,
                         SITE_NUMBER,
                         PRIMARY_SALESREP_ID,
                         STATUS,
                         con.CONTRACT_NUMBER,
                         CON.DESCRIPTION AS CONTRACT_NAME,
                         KEY_ACC.KEY_ACCT_NUMBER,
                         NVL (KEY_ACC.DESCRIPTION, key_acc.node_name)
                            AS KEY_ACCT_NAME,
                         SUB.TRANS_ACCT_NUMBER,
                         SUB.description AS TRANS_ACCT_NAME,
                         'EXISTING SITES' AS CHANGE_DESC,
                         SUB.SFDC_INSTANCE AS SFDC_ORG,
                         'DRM_HIER' AS ETL_PATH,
                         SALES_CHANNEL,
                         CATEGORY,
                         CLASS,
                         OU_NAME,
                         LANGUAGE
                    FROM HAEMO.XXHA_EBS_CUST_MASTER_STG CDI,
                         HAEMO.XXHA_DRM_ACCT_STG_CURRENT SUB,
                         HAEMO.XXHA_DRM_ACCT_STG_CURRENT KEY_ACC,
                         HAEMO.XXHA_DRM_ACCT_STG_CURRENT CON,
                         (SELECT ca.node_name cust_node_name,
                                 ca.description cust_acct_name,
                                 ca.contract_number,
                                 ka.description key_acct_name,
                                 ka.key_acct_number,
                                 ta.node_name trans_node_name,
                                 ta.description trans_acct_name,
                                 ta.trans_acct_number
                            FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT CA,
                                 HAEMO.XXHA_DRM_ACCT_STG_CURRENT KA,
                                 HAEMO.XXHA_DRM_ACCT_STG_CURRENT TA,
                                 HAEMO.XXHA_EBS_CUST_MASTER_STG CD
                           WHERE     CA.NODE_ID = KA.PARENT_ID
                                 AND KA.NODE_ID = TA.PARENT_ID
                                 AND CD.SITE_USE_ID = TA.TRANS_ACCT_NUMBER
                                 AND TA.LEVEL_HIER = 6
                          MINUS
                          SELECT ca.node_name cust_node_name,
                                 ca.description cust_acct_name,
                                 ca.contract_number,
                                 ka.description key_acct_name,
                                 ka.key_acct_number,
                                 ta.node_name trans_node_name,
                                 ta.description trans_acct_name,
                                 ta.trans_acct_number
                            FROM HAEMO.XXHA_DRM_ACCT_STG_prev CA,
                                 HAEMO.XXHA_DRM_ACCT_STG_prev KA,
                                 HAEMO.XXHA_DRM_ACCT_STG_PREV TA,
                                 HAEMO.XXHA_EBS_CUST_MASTER_STG CD
                           WHERE     CA.NODE_ID = KA.PARENT_ID
                                 AND KA.NODE_ID = TA.PARENT_ID
                                 AND CD.SITE_USE_ID = TA.TRANS_ACCT_NUMBER
                                 AND TA.LEVEL_HIER = 6) CHNG
                   WHERE     CDI.SITE_USE_ID = CHNG.TRANS_ACCT_NUMBER
                         AND CHNG.TRANS_ACCT_NUMBER = SUB.TRANS_ACCT_NUMBER
                         AND SUB.LEVEL_HIER = '6'
                         AND KEY_ACC.LEVEL_HIER = '5'
                         AND KEY_ACC.NODE_ID = SUB.PARENT_ID
                         AND KEY_ACC.PARENT_ID = CON.NODE_ID
                         AND CON.LEVEL_HIER = '4') B
              ON (A.SITE_USE_ID = B.SITE_USE_ID)
      WHEN MATCHED
      THEN
         UPDATE SET process_id = b.process_id,
                    CUSTOMER_NAME = B.CUSTOMER_NAME,
                    CUSTOMER_TYPE = B.CUSTOMER_TYPE,
                    BILLING_STREET = B.BILLING_STREET,
                    BILLING_CITY = B.BILLING_CITY,
                    BILLING_STATE = B.BILLING_STATE,
                    BILLING_POSTAL_CODE = B.BILLING_POSTAL_CODE,
                    BILLING_COUNTRY = B.BILLING_COUNTRY,
                    SHIPPING_STREET = B.SHIPPING_STREET,
                    SHIPPING_CITY = B.SHIPPING_CITY,
                    SHIPPING_STATE = B.SHIPPING_STATE,
                    SHIPPING_POSTAL_CODE = B.SHIPPING_POSTAL_CODE,
                    SHIPPING_COUNTRY = B.SHIPPING_COUNTRY,
                    ORG_ID = B.ORG_ID,
                    AGENT = B.AGENT,
                    CUSTOMER_NUMBER = B.CUSTOMER_NUMBER,
                    SITE_USE_CODE = B.SITE_USE_CODE,
                    SITE_NUMBER = B.SITE_NUMBER,
                    PRIMARY_SALESREP_ID = B.PRIMARY_SALESREP_ID,
                    STATUS = B.STATUS,
                    PHONE_NUMBER = B.PHONE_NUMBER,
                    FAX_NUMBER = B.FAX_NUMBER,
                    CONTRACT_NUMBER = B.CONTRACT_NUMBER,
                    CONTRACT_NAME = B.CONTRACT_NAME,
                    KEY_ACCT_NUMBER = B.KEY_ACCT_NUMBER,
                    KEY_ACCT_NAME = B.KEY_ACCT_NAME,
                    TRANS_ACCT_NUMBER = B.TRANS_ACCT_NUMBER,
                    TRANS_ACCT_NAME = B.TRANS_ACCT_NAME,
                    CHANGE_DESC = B.CHANGE_DESC,
                    SFDC_ORG = B.SFDC_ORG,
                    ETL_PATH = B.ETL_PATH,
                    SALES_CHANNEL = B.SALES_CHANNEL,
                    CATEGORY = B.CATEGORY,
                    CLASS = B.CLASS,
                    OU_NAME = B.OU_NAME,
                    LANGUAGE = B.LANGUAGE
      WHEN NOT MATCHED
      THEN
         INSERT     (PROCESS_ID,
                     CUSTOMER_NAME,
                     CUSTOMER_TYPE,
                     BILLING_STREET,
                     BILLING_CITY,
                     BILLING_STATE,
                     BILLING_POSTAL_CODE,
                     BILLING_COUNTRY,
                     SHIPPING_STREET,
                     SHIPPING_CITY,
                     SHIPPING_STATE,
                     SHIPPING_POSTAL_CODE,
                     SHIPPING_COUNTRY,
                     PHONE_NUMBER,
                     FAX_NUMBER,
                     ORG_ID,
                     AGENT,
                     CUSTOMER_NUMBER,
                     SITE_USE_CODE,
                     SITE_USE_ID,
                     SITE_NUMBER,
                     PRIMARY_SALESREP_ID,
                     STATUS,
                     CONTRACT_NUMBER,
                     CONTRACT_NAME,
                     KEY_ACCT_NUMBER,
                     KEY_ACCT_NAME,
                     TRANS_ACCT_NUMBER,
                     TRANS_ACCT_NAME,
                     CHANGE_DESC,
                     SFDC_ORG,
                     ETL_PATH,
                     SALES_CHANNEL,
                     CATEGORY,
                     CLASS,
                     OU_NAME,
                     LANGUAGE)
             VALUES (B.PROCESS_ID,
                     B.CUSTOMER_NAME,
                     B.CUSTOMER_TYPE,
                     B.BILLING_STREET,
                     B.BILLING_CITY,
                     B.BILLING_STATE,
                     B.BILLING_POSTAL_CODE,
                     B.BILLING_COUNTRY,
                     B.SHIPPING_STREET,
                     B.SHIPPING_CITY,
                     B.SHIPPING_STATE,
                     B.SHIPPING_POSTAL_CODE,
                     B.SHIPPING_COUNTRY,
                     B.PHONE_NUMBER,
                     B.FAX_NUMBER,
                     B.ORG_ID,
                     B.AGENT,
                     B.CUSTOMER_NUMBER,
                     B.SITE_USE_CODE,
                     B.SITE_USE_ID,
                     B.SITE_NUMBER,
                     B.PRIMARY_SALESREP_ID,
                     B.STATUS,
                     B.CONTRACT_NUMBER,
                     B.CONTRACT_NAME,
                     B.KEY_ACCT_NUMBER,
                     B.KEY_ACCT_NAME,
                     B.TRANS_ACCT_NUMBER,
                     B.TRANS_ACCT_NAME,
                     B.CHANGE_DESC,
                     B.SFDC_ORG,
                     B.ETL_PATH,
                     B.SALES_CHANNEL,
                     B.CATEGORY,
                     B.CLASS,
                     B.OU_NAME,
                     B.LANGUAGE);


      UPDATE HAEMO.XXHA_WM_DRM_SFDC_INT_STATUS
         SET PROCESS_RUNNING_STATUS = 'N'
       WHERE PROCESS_ID = v_wm_seq;


      COMMIT;

      DBMS_OUTPUT.PUT_LINE ('DRM Hierarchy Updt Proc ends: ' || CURRENT_DATE);
   EXCEPTION
      WHEN OTHERS
      THEN
         V_ERROR_MESSAGE := 'ERROR: ' || SQLERRM;
         DBMS_OUTPUT.PUT_LINE (v_ERROR_MESSAGE);

         RAISE;
   END DRM_HIER_UPDATES;

   PROCEDURE ADD_DRM_ACCTS
   IS
      v_ERROR_MESSAGE             VARCHAR2 (4000);
      v_night_proc_cnt            NUMBER;
      v_curr_process_status_cnt   NUMBER;
      v_start_tmstmp              TIMESTAMP (6);
      V_ADD                       VARCHAR2 (10) := 'Add';          -- add node
      v_prop                      VARCHAR2 (20) := 'ChangeProp'; -- Change Property
      V_PARENT_NODE               VARCHAR2 (100);
      V_LEAF_PROP                 VARCHAR2 (10) := 'false';
      V_LEAF_PROP_SITE            VARCHAR2 (10) := 'true';
      V_cnt                       NUMBER;

      CURSOR C_CON_DATA
      IS
         SELECT DISTINCT
                DRM.CONTRACT_NUMBER,
                   TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || DRM.ORG_ID
                || ' - '
                || DRM.CUSTOMER_NUMBER
                   AS NODE_NAME,
                SUB.VERSION,
                SUB.HIERARCHY_NAME,
                SUB.PARENT_NODE,
                   TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || drm.ORG_ID
                || ' - '
                || DRM.CUSTOMER_NUMBER
                || ' - Default'
                   AS KEY_ACCT_NAME,
                DRM.CONTRACT_NAME
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                (SELECT DISTINCT
                        VERSION,
                        HIERARCHY_NAME,
                        NODE_NAME AS PARENT_NODE,
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (LOAD_DATA) = 'TRUE') sub,
                haemo.xxha_wm_drm_sfdc_int_status wms,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr
          WHERE     wms.process_id = drm.process_id
                AND WMS.WM_SFDC_PROCESS_STATUS = 'Y'
                AND NVL (wms.wm_drm_process_status, 'N') != 'Y'
                AND WMS.PROCESS_RUNNING_STATUS = 'N'
                AND DRM.CHANGE_DESC = 'NEW CONTRACTS'
                AND DRM.ORG_ID = SUB.ORG_ID
                AND UPPER (
                          TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                                     '?~!@#$%^&*()+=|\}]{["/>.<,''',
                                     '_')
                       || ' - '
                       || DRM.ORG_ID
                       || ' - '
                       || DRM.CUSTOMER_NUMBER) = UPPER (CURR.NODE_NAME(+))
                AND curr.node_name IS NULL;

      CURSOR C_CON_DATA_SITE
      IS
         SELECT DISTINCT
                DRM.CONTRACT_NAME,
                SUB.VERSION,
                SUB.HIERARCHY_NAME,
                   TRANSLATE (CONVERT (DRM.TRANS_ACCT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || DRM.TRANS_ACCT_NUMBER
                   AS trans_acct_node_name,
                   TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || drm.ORG_ID
                || ' - '
                || DRM.CUSTOMER_NUMBER
                || ' - Default'
                   AS KEY_ACCT_NODE_NAME
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                (SELECT DISTINCT
                        VERSION,
                        HIERARCHY_NAME,
                        PARENT_NODE,
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (LOAD_DATA) = 'TRUE') SUB,
                haemo.xxha_wm_drm_sfdc_int_status wms,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr_tan
          WHERE     wms.process_id = drm.process_id
                AND wms.wm_sfdc_process_status = 'Y'
                AND WMS.PROCESS_RUNNING_STATUS = 'N'
                AND NVL (wms.wm_drm_process_status, 'N') != 'Y'
                AND DRM.CHANGE_DESC IN ('NEW CONTRACTS')
                AND DRM.ORG_ID = SUB.ORG_ID
                AND UPPER (
                       TRANSLATE (CONVERT (DRM.TRANS_ACCT_NAME, 'US7ASCII'),
                                  '?~!@#$%^&*()+=|\}]{["/>.<,''',
                                  '_')) = UPPER (CURR.NODE_NAME(+))
                AND curr.node_name IS NULL
                AND DRM.TRANS_ACCT_NUMBER = CURR_TAN.TRANS_ACCT_NUMBER(+)
                AND CURR_TAN.TRANS_ACCT_NUMBER IS NULL
         UNION ALL
         SELECT DISTINCT
                DRM.CONTRACT_NAME,
                SUB.VERSION,
                SUB.HIERARCHY_NAME,
                   TRANSLATE (CONVERT (DRM.TRANS_ACCT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || DRM.TRANS_ACCT_NUMBER
                   AS trans_acct_node_name,
                ka.node_name
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                (SELECT DISTINCT
                        VERSION,
                        HIERARCHY_NAME,
                        PARENT_NODE,
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (LOAD_DATA) = 'TRUE') SUB,
                (SELECT PARENT_NODE,
                        contract_number,
                        NODE_NAME,
                        key_acct_number
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '5') KA,
                haemo.xxha_wm_drm_sfdc_int_status wms,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr_tan
          WHERE     wms.process_id = drm.process_id
                AND wms.wm_sfdc_process_status = 'Y'
                AND WMS.PROCESS_RUNNING_STATUS = 'N'
                AND NVL (wms.wm_drm_process_status, 'N') != 'Y'
                AND DRM.CHANGE_DESC IN ('NEW SITES')
                AND DRM.ORG_ID = SUB.ORG_ID
                AND ka.key_acct_number = drm.key_acct_number
                AND UPPER (
                          TRANSLATE (
                             CONVERT (DRM.TRANS_ACCT_NAME, 'US7ASCII'),
                             '?~!@#$%^&*()+=|\}]{["/>.<,''',
                             '_')
                       || ' - '
                       || DRM.TRANS_ACCT_NUMBER) = UPPER (CURR.NODE_NAME(+))
                AND curr.node_name IS NULL
                AND DRM.TRANS_ACCT_NUMBER = CURR_TAN.TRANS_ACCT_NUMBER(+)
                AND CURR_TAN.TRANS_ACCT_NUMBER IS NULL;

      CURSOR C_CON_PROP
      IS
         SELECT DISTINCT
                DRM.CONTRACT_NUMBER,
                   TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || DRM.ORG_ID
                || ' - '
                || DRM.CUSTOMER_NUMBER
                   AS NODE_NAME,
                SUB.VERSION,
                SUB.HIERARCHY_NAME,
                drm.customer_name
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                (SELECT DISTINCT
                        VERSION,
                        HIERARCHY_NAME,
                        PARENT_NODE,
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (LOAD_DATA) = 'TRUE') SUB,
                haemo.xxha_wm_drm_sfdc_int_status wms,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr
          WHERE     wms.process_id = drm.process_id
                AND wms.wm_sfdc_process_status = 'Y'
                AND WMS.PROCESS_RUNNING_STATUS = 'N'
                AND NVL (wms.wm_drm_process_status, 'N') != 'Y'
                AND DRM.CHANGE_DESC = 'NEW CONTRACTS'
                AND DRM.ORG_ID = SUB.ORG_ID
                AND UPPER (
                          TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                                     '?~!@#$%^&*()+=|\}]{["/>.<,''',
                                     '_')
                       || ' - '
                       || DRM.ORG_ID
                       || ' - '
                       || DRM.CUSTOMER_NUMBER) = UPPER (CURR.NODE_NAME(+))
                AND curr.node_name IS NULL;

      CURSOR C_KA_PROP
      IS
         SELECT DISTINCT
                DRM.CONTRACT_NUMBER,
                   TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || DRM.ORG_ID
                || ' - '
                || DRM.CUSTOMER_NUMBER
                || ' - Default'
                   AS NODE_NAME,
                   REPLACE (DRM.CONTRACT_NAME, '''', '')
                || ' - '
                || drm.ORG_ID
                || ' - '
                || DRM.CUSTOMER_NUMBER
                || ' - Default'
                   KEY_ACCT_NUM,
                SUB.VERSION,
                SUB.HIERARCHY_NAME,
                drm.customer_name,
                DRM.CUSTOMER_NUMBER
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                (SELECT DISTINCT
                        VERSION,
                        HIERARCHY_NAME,
                        PARENT_NODE,
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (LOAD_DATA) = 'TRUE') SUB,
                haemo.xxha_wm_drm_sfdc_int_status wms,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr
          WHERE     wms.process_id = drm.process_id
                AND wms.wm_sfdc_process_status = 'Y'
                AND WMS.PROCESS_RUNNING_STATUS = 'N'
                AND NVL (wms.wm_drm_process_status, 'N') != 'Y'
                AND DRM.CHANGE_DESC = 'NEW CONTRACTS'
                AND DRM.ORG_ID = SUB.ORG_ID
                AND UPPER (
                          TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                                     '?~!@#$%^&*()+=|\}]{["/>.<,''',
                                     '_')
                       || ' - '
                       || DRM.ORG_ID
                       || ' - '
                       || DRM.CUSTOMER_NUMBER) = UPPER (CURR.NODE_NAME(+))
                AND curr.node_name IS NULL;

      CURSOR C_TRANS_PROP
      IS
         SELECT DISTINCT
                DRM.CONTRACT_Number,
                SUB.VERSION,
                SUB.HIERARCHY_NAME,
                   TRANSLATE (CONVERT (DRM.TRANS_ACCT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || DRM.TRANS_ACCT_NUMBER
                   AS NODE_NAME,
                DRM.TRANS_ACCT_NUMBER,
                DRM.CUSTOMER_NAME,
                DRM.CUSTOMER_NUMBER,
                DECODE (DRM.BILLING_STREET,
                        NULL, DRM.SHIPPING_STREET,
                        DRM.BILLING_STREET)
                   AS ADDRESS,
                DECODE (DRM.BILLING_CITY,
                        NULL, DRM.SHIPPING_CITY,
                        DRM.BILLING_CITY)
                   AS CITY,
                DECODE (DRM.BILLING_STATE,
                        NULL, DRM.SHIPPING_STATE,
                        DRM.BILLING_STATE)
                   AS STATE,
                DECODE (DRM.BILLING_POSTAL_CODE,
                        NULL, DRM.SHIPPING_POSTAL_CODE,
                        DRM.BILLING_POSTAL_CODE)
                   AS POSTALCODE,
                DECODE (DRM.BILLING_COUNTRY,
                        NULL, DRM.SHIPPING_COUNTRY,
                        DRM.BILLING_COUNTRY)
                   AS COUNTRY
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                (SELECT DISTINCT
                        VERSION,
                        HIERARCHY_NAME,
                        PARENT_NODE,
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (LOAD_DATA) = 'TRUE') SUB,
                haemo.xxha_wm_drm_sfdc_int_status wms,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr_tan
          WHERE     wms.process_id = drm.process_id
                AND wms.wm_sfdc_process_status = 'Y'
                AND WMS.PROCESS_RUNNING_STATUS = 'N'
                AND NVL (wms.wm_drm_process_status, 'N') != 'Y'
                AND DRM.CHANGE_DESC IN ('NEW CONTRACTS')
                AND DRM.ORG_ID = SUB.ORG_ID
                AND UPPER (
                          TRANSLATE (CONVERT (DRM.CONTRACT_NAME, 'US7ASCII'),
                                     '?~!@#$%^&*()+=|\}]{["/>.<,''',
                                     '_')
                       || ' - '
                       || DRM.ORG_ID
                       || ' - '
                       || DRM.CUSTOMER_NUMBER) = UPPER (CURR.NODE_NAME(+))
                AND curr.node_name IS NULL
                AND DRM.TRANS_ACCT_NUMBER = CURR_TAN.TRANS_ACCT_NUMBER(+)
                AND CURR_TAN.TRANS_ACCT_NUMBER IS NULL
         UNION ALL
         SELECT DISTINCT
                CDI.CONTRACT_NUMBER,
                SUB.VERSION,
                SUB.HIERARCHY_NAME,
                   TRANSLATE (CONVERT (DRM.TRANS_ACCT_NAME, 'US7ASCII'),
                              '?~!@#$%^&*()+=|\}]{["/>.<,''',
                              '_')
                || ' - '
                || DRM.TRANS_ACCT_NUMBER
                   AS NODE_NAME,
                DRM.TRANS_ACCT_NUMBER,
                DRM.CUSTOMER_NAME,
                DRM.CUSTOMER_NUMBER,
                DECODE (DRM.BILLING_STREET,
                        NULL, DRM.SHIPPING_STREET,
                        DRM.BILLING_STREET)
                   AS ADDRESS,
                DECODE (DRM.BILLING_CITY,
                        NULL, DRM.SHIPPING_CITY,
                        DRM.BILLING_CITY)
                   AS CITY,
                DECODE (DRM.BILLING_STATE,
                        NULL, DRM.SHIPPING_STATE,
                        DRM.BILLING_STATE)
                   AS STATE,
                DECODE (DRM.BILLING_POSTAL_CODE,
                        NULL, DRM.SHIPPING_POSTAL_CODE,
                        DRM.BILLING_POSTAL_CODE)
                   AS POSTALCODE,
                DECODE (DRM.BILLING_COUNTRY,
                        NULL, DRM.SHIPPING_COUNTRY,
                        DRM.BILLING_COUNTRY)
                   AS COUNTRY
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                HAEMO.XXHA_EBS_CUST_DELTA_INT CDI,
                (SELECT DISTINCT
                        VERSION,
                        HIERARCHY_NAME,
                        PARENT_NODE,
                        LTRIM (
                           SUBSTR (NODE_NAME, INSTR (NODE_NAME, ' - ') + 2))
                           AS ORG_ID
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                  WHERE LEVEL_HIER = '3' AND UPPER (LOAD_DATA) = 'TRUE') SUB,
                (SELECT DISTINCT
                        DRM.CONTRACT_NUMBER,
                        DRM.node_name,
                        sub.node_name AS KEY_ACCT_NAME
                   FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT DRM,
                        (SELECT PARENT_NODE, NODE_NAME
                           FROM HAEMO.XXHA_DRM_ACCT_STG_CURRENT
                          WHERE     LEVEL_HIER = '5'
                                AND NODE_NAME LIKE '%Default') SUB
                  WHERE DRM.NODE_NAME = SUB.PARENT_NODE) KA,
                haemo.xxha_wm_drm_sfdc_int_status wms,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT curr_tan
          WHERE     wms.process_id = drm.process_id
                AND wms.wm_sfdc_process_status = 'Y'
                AND WMS.PROCESS_RUNNING_STATUS = 'N'
                AND NVL (wms.wm_drm_process_status, 'N') != 'Y'
                AND DRM.CHANGE_DESC IN ('NEW SITES')
                AND DRM.ORG_ID = SUB.ORG_ID
                AND KA.CONTRACT_NUMBER = DRM.CONTRACT_NUMBER
                AND CDI.SITE_USE_ID = DRM.TRANS_ACCT_NUMBER
                AND UPPER (
                          TRANSLATE (
                             CONVERT (DRM.TRANS_ACCT_NAME, 'US7ASCII'),
                             '?~!@#$%^&*()+=|\}]{["/>.<,''',
                             '_')
                       || ' - '
                       || DRM.TRANS_ACCT_NUMBER) = UPPER (CURR.NODE_NAME(+))
                AND curr.node_name IS NULL
                AND DRM.TRANS_ACCT_NUMBER = CURR_TAN.TRANS_ACCT_NUMBER(+)
                AND CURR_TAN.TRANS_ACCT_NUMBER IS NULL;


      CURSOR C_TRANS_EX_PROP
      IS
         SELECT DRM.CONTRACT_NUMBER,
                CURR.VERSION,
                CURR.HIERARCHY_NAME,
                CURR.NODE_NAME,
                CURR.TRANS_ACCT_NUMBER,
                DRM.CUSTOMER_NAME AS CUSTOMER_NAME_EBS,
                DECODE (DRM.BILLING_STREET,
                        NULL, DRM.SHIPPING_STREET,
                        DRM.BILLING_STREET)
                   AS ADDRESS_EBS,
                DECODE (DRM.BILLING_CITY,
                        NULL, DRM.SHIPPING_CITY,
                        DRM.BILLING_CITY)
                   AS CITY_EBS,
                DECODE (DRM.BILLING_STATE,
                        NULL, DRM.SHIPPING_STATE,
                        DRM.BILLING_STATE)
                   AS STATE_EBS,
                DECODE (DRM.BILLING_POSTAL_CODE,
                        NULL, DRM.SHIPPING_POSTAL_CODE,
                        DRM.BILLING_POSTAL_CODE)
                   AS POSTALCODE_EBS,
                DECODE (DRM.BILLING_COUNTRY,
                        NULL, DRM.SHIPPING_COUNTRY,
                        DRM.BILLING_COUNTRY)
                   AS COUNTRY_EBS,
                CURR.ADDRESS,
                CURR.CITY,
                CURR.STATE,
                CURR.POSTAL_CODE AS POSTALCODE,
                CURR.COUNTRY,
                CURR.CUSTOMER_NAME
           FROM HAEMO.XXHA_EBS_SFDC_ACCT_STG DRM,
                HAEMO.XXHA_DRM_ACCT_STG_CURRENT CURR
          WHERE     CHANGE_DESC = 'EXISTING SITES'
                AND CURR.LEVEL_HIER = '6'
                AND CURR.TRANS_ACCT_NUMBER = DRM.TRANS_ACCT_NUMBER;
   BEGIN
      DBMS_OUTPUT.PUT_LINE (
         'Add DRM Accts Procedure begins: ' || CURRENT_DATE);


      EXECUTE IMMEDIATE 'TRUNCATE TABLE HAEMO.XXHA_DRM_ACCT_IMP';


      --DBMS_OUTPUT.PUT_LINE('Add DRM Accts for NEW CONTRACTS: ' || current_date);


      -- Add, Version, Hierarchy, Node, Parent Node, Leaf Property, Description,
      FOR cur_rec IN c_con_data
      LOOP
         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PARENT_NODE,
                                              LEAF_PROPERTY,
                                              DESCRIPTION)
              VALUES (V_ADD,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      CUR_REC.PARENT_NODE,
                      V_LEAF_PROP,
                      CUR_REC.CONTRACT_NAME);
      END LOOP;

      FOR cur_rec IN c_con_data
      LOOP
         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PARENT_NODE,
                                              LEAF_PROPERTY,
                                              DESCRIPTION)
              VALUES (V_ADD,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.KEY_ACCT_NAME,
                      CUR_REC.NODE_NAME,
                      V_LEAF_PROP,
                      CUR_REC.CONTRACT_NAME);
      END LOOP;

      FOR CUR_REC IN C_CON_DATA_SITE
      LOOP
         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PARENT_NODE,
                                              LEAF_PROPERTY,
                                              DESCRIPTION)
              VALUES (V_ADD,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.trans_acct_node_name,
                      CUR_REC.KEY_ACCT_NODE_NAME,
                      V_LEAF_PROP_SITE,
                      CUR_REC.CONTRACT_NAME);
      END LOOP;

      --Change Property
      --ChangeProp, Version, Hierarchy, Node, Property Name, Value

      FOR cur_rec IN c_con_PROP
      LOOP
         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Contract Number',
                      CUR_REC.CONTRACT_NUMBER);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Customer Name',
                      CUR_REC.CUSTOMER_NAME);
      END LOOP;

      FOR cur_rec IN c_ka_PROP
      LOOP
         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Contract Number',
                      CUR_REC.CONTRACT_NUMBER);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Customer Name',
                      CUR_REC.CUSTOMER_NAME);


         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Customer Number',
                      CUR_REC.CUSTOMER_NUMBER);

         IF CUR_REC.NODE_NAME != CUR_REC.KEY_ACCT_NUM
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'Key Account Number',
                         CUR_REC.KEY_ACCT_NUM);
         END IF;
      END LOOP;

      --NUMERICZIPCODE,ALPHAZIPCODE,CONTRACTNUMBER,CUSTOMERNAME,TRANSACTIONNUMBER,CUSTOMERNUMBER
      --Address,City,State,PostalCode,COUNTRY


      FOR cur_rec IN c_TRANS_PROP
      LOOP
         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Contract Number',
                      CUR_REC.CONTRACT_NUMBER);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Customer Name',
                      CUR_REC.CUSTOMER_NAME);


         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Customer Number',
                      CUR_REC.CUSTOMER_NUMBER);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Transaction Number',
                      CUR_REC.TRANS_ACCT_NUMBER);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Address',
                      CUR_REC.address);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'City',
                      CUR_REC.City);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'State',
                      CUR_REC.State);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Postal Code',
                      CUR_REC.PostalCode);

         INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                              VERSION,
                                              HIERARCHY,
                                              NODE_NAME,
                                              PROPERTY_NAME,
                                              PROPERTY_VALUE)
              VALUES (V_PROP,
                      CUR_REC.VERSION,
                      CUR_REC.HIERARCHY_NAME,
                      CUR_REC.NODE_NAME,
                      'Country',
                      CUR_REC.COUNTRY);

         IF LENGTH (
               TRIM (TRANSLATE (CUR_REC.POSTALCODE, ' +-.0123456789', ' ')))
               IS NULL
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'Numeric Zip Code',
                         CUR_REC.PostalCode);
         ELSE
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'Alpha Zip Code',
                         CUR_REC.PostalCode);
         END IF;
      END LOOP;

      --NUMERICZIPCODE,ALPHAZIPCODE,CUSTOMERNAME,ADDRESS
      --City,State,PostalCode,COUNTRY

      FOR cur_rec IN c_TRANS_EX_PROP
      LOOP
         IF CUR_REC.CUSTOMER_NAME_EBS != CUR_REC.CUSTOMER_NAME
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'Customer Name',
                         CUR_REC.CUSTOMER_NAME_EBS);
         END IF;

         IF CUR_REC.ADDRESS_EBS != CUR_REC.ADDRESS
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'Address',
                         CUR_REC.ADDRESS_EBS);
         END IF;

         IF CUR_REC.CITY_EBS != CUR_REC.CITY
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'City',
                         CUR_REC.CITY_EBS);
         END IF;

         IF CUR_REC.STATE_EBS != CUR_REC.STATE
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'State',
                         CUR_REC.STATE_EBS);
         END IF;

         IF CUR_REC.POSTALCODE_EBS != CUR_REC.POSTALCODE
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'Postal Code',
                         CUR_REC.POSTALCODE_EBS);
         END IF;

         IF CUR_REC.COUNTRY_EBS != CUR_REC.COUNTRY
         THEN
            INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                 VERSION,
                                                 HIERARCHY,
                                                 NODE_NAME,
                                                 PROPERTY_NAME,
                                                 PROPERTY_VALUE)
                 VALUES (V_PROP,
                         CUR_REC.VERSION,
                         CUR_REC.HIERARCHY_NAME,
                         CUR_REC.NODE_NAME,
                         'Country',
                         CUR_REC.COUNTRY_EBS);
         END IF;

         IF LENGTH (
               TRIM (TRANSLATE (CUR_REC.POSTALCODE, ' +-.0123456789', ' ')))
               IS NULL
         THEN
            IF CUR_REC.POSTALCODE_EBS != CUR_REC.POSTALCODE
            THEN
               INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                    VERSION,
                                                    HIERARCHY,
                                                    NODE_NAME,
                                                    PROPERTY_NAME,
                                                    PROPERTY_VALUE)
                    VALUES (V_PROP,
                            CUR_REC.VERSION,
                            CUR_REC.HIERARCHY_NAME,
                            CUR_REC.NODE_NAME,
                            'Numeric Zip Code',
                            CUR_REC.POSTALCODE_EBS);
            END IF;
         ELSE
            IF CUR_REC.POSTALCODE_EBS != CUR_REC.POSTALCODE
            THEN
               INSERT INTO HAEMO.XXHA_DRM_ACCT_IMP (REC_TYPE,
                                                    VERSION,
                                                    HIERARCHY,
                                                    NODE_NAME,
                                                    PROPERTY_NAME,
                                                    PROPERTY_VALUE)
                    VALUES (V_PROP,
                            CUR_REC.VERSION,
                            CUR_REC.HIERARCHY_NAME,
                            CUR_REC.NODE_NAME,
                            'Alpha Zip Code',
                            CUR_REC.POSTALCODE_EBS);
            END IF;
         END IF;
      END LOOP;

      SELECT NVL (COUNT (*), 0)
        INTO V_CNT
        FROM HAEMO.XXHA_DRM_ACCT_IMP
       WHERE REC_TYPE = 'Add';

      DBMS_OUTPUT.PUT_LINE ('Nodes to be added in DRM: ' || v_cnt);

      SELECT NVL (COUNT (*), 0)
        INTO V_CNT
        FROM HAEMO.XXHA_DRM_ACCT_IMP
       WHERE REC_TYPE != 'Add';

      DBMS_OUTPUT.PUT_LINE (
         'Node Properties to be updated in DRM: ' || v_cnt);


      DBMS_OUTPUT.PUT_LINE ('Add DRM Accts Procedure ends: ' || CURRENT_DATE);
   EXCEPTION
      WHEN OTHERS
      THEN
         v_ERROR_MESSAGE := 'ERROR: ' || SQLERRM;
         DBMS_OUTPUT.PUT_LINE (v_ERROR_MESSAGE);
         RAISE;
   END ADD_DRM_ACCTS;
END XXHA_DRM_ACCOUNTS_INT_NIGHTLY;
/
