create or replace PACKAGE BODY XXHA_SERV_REQ_CLOSE_SUBMIT_PKG AS

/*****************************************************************************************************************************
* Package Name : XXHA_SERV_REQ_CLOSE_SUBMIT_PKG                                                                              *
*                                                                                                                            *
* Purpose      : Package to submit Concurrent Program 'XXHA: Service Request Closure Report'                                 *
*                                                                                                                            *
* Procedures   : Process_PGM                                                                                                 *
*                                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                            *
* - XDO_TEMPLATES_VL                  S                                                                                      *
* - XDO_LOBS                          S                                                                                      *
* - fnd_concurrent_programs_vl        S                                                                                      *
* - XXHA_SERV_REQ_CLOSE_V             S                                                                                      *
*                                                                                                                            *
* Change History                                                                                                             *
*                                                                                                                            *
* Ver        Date            Author               Description                                                                *
* ------     -----------     -----------------    ---------------                                                            *
* 1.0        24-AUG-2016     BMarcoux             Intial Program Creation.                                                   *
*                                                                                                                            *
* 5.0        06-JUN-2017     Bruce Marcoux        INC0107201 - Service Batch - Records processed with errors email not sent. *
*                                                  Modification to place spreadsheets on server and be picked up by          *
*                                                  WebMethods processing and placed on shared drive instead of being         *
*                                                  emailed as an attachment. Added PARM: P_REPORT_PROGRAM_ID.                *
******************************************************************************************************************************/

PROCEDURE Process_PGM(
                      x_errbuf                       OUT VARCHAR2
                    , x_retcode                      OUT VARCHAR2
                    , P_SESSION_ID                   IN  NUMBER
                    , P_CONCURRENT_PGM               IN  VARCHAR2
                    , P_TEMPLATE_CODE                IN  VARCHAR2
                    , P_DEBUG                        IN  VARCHAR2
                    , P_EMAIL_SERVER                 IN  VARCHAR2
                    , P_EMAIL_PORT                   IN  VARCHAR2
                    , P_TEST_EMAIL_ACCOUNT           IN  VARCHAR2
                    , P_PRODUCTION_INSTANCE_DB_NAME  IN  VARCHAR2
                    , P_Value_Set_ID_EMail           IN  NUMBER
                    , P_REPORT_PROGRAM_ID            IN  NUMBER
                     )
IS

l_Sequence_Number                 XXHA_SERV_REQ_CLOSE_DTL.SEQUENCE_NBR%TYPE                     := 0;

l_Template_code                   XDO_TEMPLATES_VL.Template_code%TYPE                           := NULL;
l_Application_Short_Name          XDO_TEMPLATES_VL.Application_Short_Name%TYPE                  := NULL;
l_Language                        XDO_LOBS.Language%TYPE                                        := NULL;
l_Territory                       XDO_LOBS.Territory%TYPE                                       := NULL;
l_Default_Output_Type             XDO_TEMPLATES_VL.Default_Output_Type%TYPE                     := NULL;

l_user_concurrent_program_name    fnd_concurrent_programs_vl.user_concurrent_program_name%TYPE  := NULL;
l_printer_name                    fnd_concurrent_programs_vl.printer_name%TYPE                  := NULL;
l_output_print_style              fnd_concurrent_programs_vl.output_print_style%TYPE            := NULL;
l_save_output_flag                fnd_concurrent_programs_vl.save_output_flag%TYPE              := NULL;
l_copies                          NUMBER                                                        := 1;

l_request_id                      NUMBER;
l_call_status                     BOOLEAN;
l_set_print                       BOOLEAN;

-- Cursor to see if any data exists for the Session
CURSOR cur_100
IS
SELECT
    NVL(SEQUENCE_NBR,0)
FROM
    XXHA_SERV_REQ_CLOSE_V    XXHA
WHERE
    XXHA.Session_ID        = P_SESSION_ID
;

BEGIN

   -- Cursor to get record count for the session
   OPEN cur_100;
   FETCH cur_100 INTO l_Sequence_Number;
   CLOSE cur_100;

   -- Data does not exist, write out message and don't submit the reports (if no data exists, bursting will fail)
   IF l_Sequence_Number = 0 THEN
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                 ');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'P_SESSION_ID: ' || P_SESSION_ID);
     FND_FILE.PUT_LINE(FND_FILE.LOG,'No Records exist to be processed - Process Ending');
     FND_FILE.PUT_LINE(FND_FILE.LOG,'                                                 ');
   ELSE

   -- Data does exist, so submit the reports
   BEGIN

      -- Retrieve Concurrent Program User Name (i.e. 'XXHA: Service Request Closure Report�),
      -- Printer Name, Output Print Style and Save Output Flag
      -- for submit message and for setting Print Options
      SELECT
          cp.user_concurrent_program_name
      ,   cp.printer_name
      ,   cp.output_print_style
      ,   cp.save_output_flag
      INTO
          l_user_concurrent_program_name
      ,   l_printer_name
      ,   l_output_print_style
      ,   l_save_output_flag    
      FROM
         fnd_concurrent_programs_vl   cp
      WHERE
          cp.concurrent_program_name = P_CONCURRENT_PGM;

      -- Processing to submit the Concurrent Program for Service Requests that were 'CLOSED'
      BEGIN

         -- Retrieve Template values
         SELECT
             XTL.Template_code
         ,   XTL.Application_Short_Name
         ,   XLO.Language
         ,   XLO.Territory
         ,   XTL.Default_Output_Type
         INTO
             l_Template_code
         ,   l_Application_Short_Name
         ,   l_Language
         ,   l_Territory
         ,   l_Default_Output_Type
         FROM
             XDO_TEMPLATES_VL  XTL
         ,   XDO_LOBS          XLO
         WHERE
             XTL.Template_code = P_TEMPLATE_CODE --(i.e. 'XXHA_SERV_REQ_CLOSE_RPT')
         AND XTL.Template_code = XLO.lob_code
         AND XLO.lob_type      = 'TEMPLATE';

         -- Call package to set Layout
         l_call_status :=
         fnd_request.add_layout 
         (
           l_Application_Short_Name                    -- Template Application Name
         , l_Template_code                             -- Template Code
         , l_Language                                  -- Template Language
         , l_Territory                                 -- Template Territory
         , l_Default_Output_Type                       -- Output Format
         );

         -- Call Package to submit the Concurrent Program for Service Requests that were 'CLOSED'
         l_request_id := fnd_request.submit_request
         (
           'HAEMO'                                     -- Application
         , P_CONCURRENT_PGM                            -- Program (i.e. 'XXHA_SERV_REQ_CLOSE_RPT')
         , 'XXHA: Service Request Closure-Closed'      -- Description
         , NULL                                        -- Start Time
         , FALSE                                       -- Sub Request
         , P_SESSION_ID
         , P_DEBUG
         , 'N'                                         -- Error Flag (XXHA_SERV_REQ_CLOSE_HDR.ERRORS_EXIST)
         , P_EMAIL_SERVER                              -- BR-Exchange.Haemo.net
         , P_EMAIL_PORT                                -- 25
         , P_TEST_EMAIL_ACCOUNT                        -- HaemoEBS-TST@haemonetics.com
         , P_PRODUCTION_INSTANCE_DB_NAME               -- HAEPRD
         , P_Value_Set_ID_EMail                        -- Value Set ID for 'XXHA_CS_PM_PGM_EMAIL_LIST'
         , P_REPORT_PROGRAM_ID                         -- Program ID for XXHA_SERV_REQ_CLOSE.rdf
         , NULL--, NULL--, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         );
   
         COMMIT;

         -- Write Message to Job Log if Concurrent Program was submitted
         fnd_file.put_line(fnd_file.log,'                                                                           ');
         fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
         fnd_file.put_line(fnd_file.log,l_user_concurrent_program_name || ' - Submitted - Request ID#: ' || l_request_id);
         fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
         fnd_file.put_line(fnd_file.log,'                                                                           ');

      EXCEPTION WHEN OTHERS THEN         
         DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
      END;

      -- Processing to submit the Concurrent Program for Service Requests that were 'EXCLUDED'
      BEGIN

         -- Retrieve Template values
         SELECT
             XTL.Template_code
         ,   XTL.Application_Short_Name
         ,   XLO.Language
         ,   XLO.Territory
         ,   XTL.Default_Output_Type
         INTO
             l_Template_code
         ,   l_Application_Short_Name
         ,   l_Language
         ,   l_Territory
         ,   l_Default_Output_Type
         FROM
             XDO_TEMPLATES_VL  XTL
         ,   XDO_LOBS          XLO
         WHERE
             XTL.Template_code = P_TEMPLATE_CODE --(i.e. 'XXHA_SERV_REQ_CLOSE_RPT')
         AND XTL.Template_code = XLO.lob_code
         AND XLO.lob_type      = 'TEMPLATE';

         -- Call package to set Layout
         l_call_status :=
         fnd_request.add_layout 
         (
           l_Application_Short_Name                    -- Template Application Name
         , l_Template_code                             -- Template Code
         , l_Language                                  -- Template Language
         , l_Territory                                 -- Template Territory
         , l_Default_Output_Type                       -- Output Format
         );

         -- Call Package to submit the Concurrent Program for Service Requests that were 'EXCLUDED'
         l_request_id := fnd_request.submit_request
         (
           'HAEMO'                                     -- Application
         , P_CONCURRENT_PGM                            -- Program (i.e. 'XXHA_SERV_REQ_CLOSE_RPT')
         , 'XXHA: Service Request Closure-Excluded'    -- Description
         , NULL                                        -- Start Time
         , FALSE                                       -- Sub Request
         , P_SESSION_ID
         , P_DEBUG
         , 'X'                                         -- Error Flag (XXHA_SERV_REQ_CLOSE_HDR.ERRORS_EXIST)
         , P_EMAIL_SERVER                              -- BR-Exchange.Haemo.net
         , P_EMAIL_PORT                                -- 25
         , P_TEST_EMAIL_ACCOUNT                        -- HaemoEBS-TST@haemonetics.com
         , P_PRODUCTION_INSTANCE_DB_NAME               -- HAEPRD
         , P_Value_Set_ID_EMail                        -- Value Set ID for 'XXHA_CS_PM_PGM_EMAIL_LIST'
         , P_REPORT_PROGRAM_ID                         -- Program ID for XXHA_SERV_REQ_CLOSE.rdf
         , NULL--, NULL--, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         );
   
         COMMIT;

         -- Write Message to Job Log if Concurrent Program was submitted
         fnd_file.put_line(fnd_file.log,'                                                                           ');
         fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
         fnd_file.put_line(fnd_file.log,l_user_concurrent_program_name || ' - Submitted - Request ID#: ' || l_request_id);
         fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
         fnd_file.put_line(fnd_file.log,'                                                                           ');

      EXCEPTION WHEN OTHERS THEN         
         DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
      END;

      -- Processing to submit the Concurrent Program for Service Requests that were in 'ERROR'
      BEGIN

         -- Retrieve Template values
         SELECT
             XTL.Template_code
         ,   XTL.Application_Short_Name
         ,   XLO.Language
         ,   XLO.Territory
         ,   XTL.Default_Output_Type
         INTO
             l_Template_code
         ,   l_Application_Short_Name
         ,   l_Language
         ,   l_Territory
         ,   l_Default_Output_Type
         FROM
             XDO_TEMPLATES_VL  XTL
         ,   XDO_LOBS          XLO
         WHERE
             XTL.Template_code = P_TEMPLATE_CODE --(i.e. 'XXHA_SERV_REQ_CLOSE_RPT')
         AND XTL.Template_code = XLO.lob_code
         AND XLO.lob_type      = 'TEMPLATE';

         -- Call package to set Layout
         l_call_status :=
         fnd_request.add_layout 
         (
           l_Application_Short_Name                    -- Template Application Name
         , l_Template_code                             -- Template Code
         , l_Language                                  -- Template Language
         , l_Territory                                 -- Template Territory
         , l_Default_Output_Type                       -- Output Format
         );

         -- Call Package to submit the Concurrent Program for Service Requests that were in 'ERROR'
         l_request_id := fnd_request.submit_request
         (
           'HAEMO'                                     -- Application
         , P_CONCURRENT_PGM                            -- Program (i.e. 'XXHA_SERV_REQ_CLOSE_RPT')
         , 'XXHA: Service Request Closure-Errors'      -- Description
         , NULL                                        -- Start Time
         , FALSE                                       -- Sub Request
         , P_SESSION_ID
         , P_DEBUG
         , 'Y'                                         -- Error Flag (XXHA_SERV_REQ_CLOSE_HDR.ERRORS_EXIST)
         , P_EMAIL_SERVER                              -- BR-Exchange.Haemo.net
         , P_EMAIL_PORT                                -- 25
         , P_TEST_EMAIL_ACCOUNT                        -- HaemoEBS-TST@haemonetics.com
         , P_PRODUCTION_INSTANCE_DB_NAME               -- HAEPRD
         , P_Value_Set_ID_EMail                        -- Value Set ID for 'XXHA_CS_PM_PGM_EMAIL_LIST'
         , P_REPORT_PROGRAM_ID                         -- Program ID for XXHA_SERV_REQ_CLOSE.rdf
         , NULL--, NULL--, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         );
   
         COMMIT;

         -- Write Message to Job Log if Concurrent Program was submitted
         fnd_file.put_line(fnd_file.log,'                                                                           ');
         fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
         fnd_file.put_line(fnd_file.log,l_user_concurrent_program_name || ' - Submitted - Request ID#: ' || l_request_id);
         fnd_file.put_line(fnd_file.log,'---------------------------------------------------------------------------');
         fnd_file.put_line(fnd_file.log,'                                                                           ');

      EXCEPTION WHEN OTHERS THEN         
         DBMS_OUTPUT.PUT_LINE(SQLCODE||' Error :'||SQLERRM);
      END;

   END;
   END IF;

END Process_PGM;

END XXHA_SERV_REQ_CLOSE_SUBMIT_PKG;