CREATE OR REPLACE package      XXHA_Project_WF
AUTHID CURRENT_USER as

/*
* $Header: XXHA_Project_WF.sql 15-06-2011.11: 00:00 Vishal KumarExp $
*
* HAEMONETICS
*
* File Name:            XXHA_Project_WF
* Author:         Vishal Kumar
* Original:        15-06-2011
* Function:
* Description:
* This Script creates package body for XHA_Project_WF
*
* Notes:
*
* Modified:                  (MM/DD/YYYY)
* Vishal Kumar         15-06-2011        Created*/

procedure PA_ASSIGN_WF(itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2);

                procedure PA_APPRV_WF(itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2);


PROCEDURE Initiate(p_task_id          IN NUMBER,
                   p_task_number      IN VARCHAR2,
                   p_project_id       IN NUMBER,
                   P_initiator        IN NUMBER,
                   p_itemkey          OUT VARCHAR2);

                   -- Procedure to copy the pa_tasks information to xxha_pa_tasks_alert to maintain audit information
PROCEDURE insert_tasks(p_task_id number,
                       p_project_id number);

                       procedure PA_REV_ASSIGN_WF(itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2);

                PROCEDURE PA_PROJECT_INITIATE(p_project_id       IN NUMBER,
                   P_initiator        IN NUMBER,
                   p_itemkey          OUT VARCHAR2);

                   PROCEDURE insert_project(p_project_id number);

                   PROCEDURE insert_key_members(p_project_id number,p_project_role_id number );

                    procedure PA_SET_STATUS(itemtype    in varchar2,
		                   itemkey      in varchar2,
		                   actid        in number,
		                   funcmode    in varchar2,
                resultout out nocopy varchar2);

                end;

/


CREATE OR REPLACE package body      XXHA_Project_WF as

/* Version 2.0
* $Header: XXHA_Project_WF.sql 15-06-2011.11: 00:00 Vishal KumarExp $
*
* HAEMONATICS
*
* File Name:            XXHA_Project_WF
* Author:         Vishal Kumar
* Original:        15-06-2011
* Function:
* Description:
* This Script creates package body for XHA_Project_WF
*
* Notes:
*
* Modified:                  (MM/DD/YYYY)
* Vishal Kumar         15-06-2011        Created*
*  2.0        11-Sep-2011    Vishal Kumar          Introduced Logic to allow same person on
*						different roles to approve the Budget    */


  procedure PA_ASSIGN_WF(itemtype    in varchar2,
                 itemkey      in varchar2,
                 actid        in number,
                 funcmode    in varchar2,
                 resultout out nocopy varchar2)

                 IS

       l_project_id  NUMBER;

       L_CNT NUMBER;
       L_CNT2 NUMBER;
       l_proj_stus_code  VARCHAR2(100);
       l_workflow_started_by_id  number;
       l_project_role_type VARCHAR2(100);

       l_workflow_performer_id number;

       l_workflow_notifier_id  number;

        l_workflow_performer_name varchar2(100);

        l_workflow_notifier_name  varchar2(100);

 lv_init_role_name       VARCHAR2(20):='XXHA_PRJ_ROLE';
 lv_init_role_dispname   VARCHAR2(50) :='XXHA_PRJ_ROLE';

 l_profile_cnt number;


                 BEGIN


                 l_workflow_started_by_id := wf_engine.GetItemAttrNumber(itemtype      => itemtype,
                                     itemkey       => itemkey,
                                     aname          => 'WORKFLOW_STARTED_BY_ID' );


                  l_project_id := wf_engine.GetItemAttrNumber(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_ID' );

                                 l_proj_stus_code := wf_engine.GetItemAttrText(itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_STATUS_CODE' );


                                   select count(*) into  l_profile_cnt from fnd_profile_options_tl f , fnd_profile_options e ,fnd_profile_option_values a,fnd_user d
WHERE  f.USER_PROFILE_OPTION_NAME = 'PA: Cross Project User -- Update'
and  f.PROFILE_OPTION_NAME=e.profile_option_name
and e.profile_option_id = a.profile_option_id
and a.level_value = d.user_id
and d.user_id=l_workflow_started_by_id
and a.PROFILE_OPTION_VALUE='Y'
and rownum=1;

        if l_profile_cnt =0 then

                SELECT count(*)
                 INTO l_cnt
                 FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
                     AND ppa.person_id = fu.employee_id
                     AND fu.user_id = l_workflow_started_by_id
                        AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
                        and rownum=1;
               if l_cnt=0
               then
                 resultout := wf_engine.eng_completed||':'||'N';

               else
               SELECT project_role_type
              INTO l_project_role_type
              FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
              and rownum=1;
              end if;

         elsif l_profile_cnt <>0 then
              SELECT count(*)
              INTO l_cnt
              FROM pa_project_players ppa, fnd_user fu
             WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
               and rownum=1;
               if l_cnt <>0
                then
                 SELECT project_role_type
              INTO l_project_role_type
              FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
              and rownum=1;
              end if;

        end if;

              --- insert into xxha_workflow_track VALUES (l_proj_stus_code,2 );

-- SELECT project_role_type,count(*)
--   INTO l_project_role_type,l_cnt
--   FROM pa_project_players ppa, fnd_user fu
--  WHERE ppa.project_id = l_project_id
--    AND ppa.person_id = fu.employee_id
--    AND fu.user_id = l_workflow_started_by_id
--    AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
--    and rownum=1
--    group by project_role_type;

 --   if l_cnt=0 then

 --   resultout := wf_engine.eng_completed||':'||'N';

 --      insert into xxha_workflow_track VALUES (l_project_role_type,1,l_project_id );


 --      insert into xxha_workflow_track VALUES (L_CNT,2,l_project_id );

 --     commit;

          select count(*) into l_cnt2 from xxha_proj_workflow_track where project_id=l_project_id and ITEMKEY='APPROVED' ;

        if l_cnt2=0 then



           if (l_project_role_type ='1000' or l_profile_cnt<>0) then

              select person_id  into l_workflow_performer_id from PA_PROJECT_PLAYERS WHERE PROJECT_ROLE_TYPE  ='PROGRAM MANAGER' and project_id=l_project_id and    sysdate between start_date_active and nvl(end_date_active, sysdate+1);

                 select person_id  into l_workflow_notifier_id from PA_PROJECT_PLAYERS WHERE PROJECT_ROLE_TYPE  ='PROJECT MANAGER' and project_id=l_project_id  AND    sysdate between start_date_active and nvl(end_date_active, sysdate+1);

                 SELECT    f.user_name into l_workflow_performer_name
                 FROM    fnd_user f
             , pa_employees e
                 WHERE   f.employee_id = l_workflow_performer_id
                 AND     f.employee_id = e.person_id
                 and    rownum=1;


                 SELECT    f.user_name into l_workflow_notifier_name
                 FROM    fnd_user f
                          , pa_employees e
                 WHERE   f.employee_id = l_workflow_notifier_id
                 AND     f.employee_id = e.person_id
                 and rownum=1;

           wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROGRAM_MANAGER',
              avalue        =>  l_workflow_performer_name);

                 --- insert into xxha_workflow_track VALUES (l_workflow_performer_name,3 );

              wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJECT_MANAGER',
              avalue        =>  l_workflow_notifier_name);

               ----   insert into xxha_workflow_track VALUES (l_workflow_notifier_name,4 );


               WF_DIRECTORY.RemoveUsersFromAdHocRole(Role_name => lv_init_role_name);

               if l_workflow_performer_name=l_workflow_notifier_name then


                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                 else

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_notifier_name);


                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                              end if;

                 resultout := wf_engine.eng_completed||':'||'Y';

                     else

                 resultout := wf_engine.eng_completed||':'||'N';

                     END IF;

     elsif l_cnt2>=1 then
                  ---insert into xxha_workflow_track VALUES (L_CNT,'L_CNT  '||'  '||'5' );

      if (l_project_role_type ='1000' or l_project_role_type ='PROJECT MANAGER' or l_profile_cnt<>0) then

      ----insert into xxha_workflow_track VALUES (l_project_role_type,'l_project_role_type  '||'  '||'6' );

              select person_id  into l_workflow_performer_id from PA_PROJECT_PLAYERS WHERE PROJECT_ROLE_TYPE  ='1000' and project_id=l_project_id  AND    sysdate between start_date_active and nvl(end_date_active, sysdate+1);

                 select person_id  into l_workflow_notifier_id from PA_PROJECT_PLAYERS WHERE PROJECT_ROLE_TYPE  ='PROJECT MANAGER' and project_id=l_project_id  AND    sysdate between start_date_active and nvl(end_date_active, sysdate+1);

                 SELECT    f.user_name into l_workflow_performer_name
                 FROM    fnd_user f
                      , pa_employees e
                 WHERE   f.employee_id = l_workflow_performer_id
                 AND     f.employee_id = e.person_id
                 and rownum=1;


                 SELECT    f.user_name into l_workflow_notifier_name
                 FROM    fnd_user f
                      , pa_employees e
                     WHERE   f.employee_id = l_workflow_notifier_id
                 AND     f.employee_id = e.person_id
                 and rownum=1;

           wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJ_ACCT',
              avalue        =>  l_workflow_performer_name);

                 --- insert into xxha_workflow_track VALUES (l_workflow_performer_name,7 );

              wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJECT_MANAGER',
              avalue        =>  l_workflow_notifier_name);

                ---  insert into xxha_workflow_track VALUES (l_workflow_notifier_name,8 );


               WF_DIRECTORY.RemoveUsersFromAdHocRole(Role_name => lv_init_role_name);

                   if l_workflow_performer_name=l_workflow_notifier_name then


                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                 else

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_notifier_name);


                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                              end if;

                 resultout := wf_engine.eng_completed||':'||'R';

                     else

                 resultout := wf_engine.eng_completed||':'||'N';

                     END IF;

                     else

                 resultout := wf_engine.eng_completed||':'||'N';

     end if;

                 EXCEPTION

 WHEN FND_API.G_EXC_ERROR
     THEN

      resultout := wf_engine.eng_completed||':'||'N';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
        --- RAISE;

 WHEN FND_API.G_EXC_UNEXPECTED_ERROR
     THEN

      resultout := wf_engine.eng_completed||':'||'N';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
        --- RAISE;
 WHEN NO_DATA_FOUND THEN
  resultout := wf_engine.eng_completed||':'||'N';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
 WHEN OTHERS
     THEN
     resultout := wf_engine.eng_completed||':'||'N';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
   ---  RAISE;

 END PA_ASSIGN_WF;

 procedure PA_APPRV_WF(itemtype    in varchar2,
                 itemkey      in varchar2,
                 actid        in number,
                 funcmode    in varchar2,
                 resultout out nocopy varchar2)

                 IS

       l_project_id  NUMBER;

       L_CNT NUMBER;
       L_CNT2 NUMBER;
       l_proj_stus_code  VARCHAR2(100);
       l_workflow_started_by_id  number;
       l_project_role_type VARCHAR2(100);

       l_workflow_performer_id number;

       l_workflow_notifier_id  number;

        l_workflow_performer_name varchar2(100);

        l_workflow_notifier_name  varchar2(100);

        l_proj_stus_name varchar2(100);

 lv_init_role_name       VARCHAR2(20):='XXHA_PRJ_ROLE';
 lv_init_role_dispname   VARCHAR2(50) :='XXHA_PRJ_ROLE';

 l_proj_number varchar2(100);
 l_project_name varchar2(100);

 l_project_description varchar2(100);
 l_project_org varchar2(100);

 l_project_type varchar2(100);

 l_product_code varchar2(100);

 l_project_ref varchar2(100);

 lv_update_date date;

 km_update_date  date;


                 BEGIN


                 l_workflow_started_by_id := wf_engine.GetItemAttrNumber(itemtype      => itemtype,
                                     itemkey       => itemkey,
                                     aname          => 'WORKFLOW_STARTED_BY_ID' );


                  l_project_id := wf_engine.GetItemAttrNumber(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_ID' );


                        l_proj_number :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PA_PROJECT_NUMBER' );
 l_project_name :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_NAME' );

 l_project_description :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_DESCRIPTION' );
 l_project_org :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'CARRYING_OUT_ORG_NAME' );

 l_project_type :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_TYPE' );

 l_product_code :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PM_PROJECT_PRODUCT_CODE' );

 l_project_ref     :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PM_PROJECT_REFERENCE' );



              select last_update_date into lv_update_date from pa_projects_all where project_id=l_project_id ;

               select max(last_update_date) into km_update_date from pa_project_players where project_id=l_project_id ;

                insert into xxha_proj_workflow_track VALUES ('APPROVED',l_project_id,l_proj_number,
                l_project_name ,l_project_description,l_project_org ,l_project_type ,l_product_code ,l_project_ref,lv_update_date,km_update_date);


                 resultout := wf_engine.eng_completed||':'||'Y';


                 EXCEPTION

 WHEN FND_API.G_EXC_ERROR
     THEN

      resultout := wf_engine.eng_completed||':'||'Y';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_APPRV_WF', itemtype, itemkey, to_char(actid), funcmode);
        -- RAISE;

 WHEN FND_API.G_EXC_UNEXPECTED_ERROR
     THEN
     resultout := wf_engine.eng_completed||':'||'Y';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_APPRV_WF', itemtype, itemkey, to_char(actid), funcmode);
         ---RAISE;
 WHEN NO_DATA_FOUND THEN
  resultout := wf_engine.eng_completed||':'||'Y';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_APPRV_WF', itemtype, itemkey, to_char(actid), funcmode);
 WHEN OTHERS
     THEN
     resultout := wf_engine.eng_completed||':'||'Y';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_APPRV_WF', itemtype, itemkey, to_char(actid), funcmode);
   ---  RAISE;


 END PA_APPRV_WF;


 -- Procedure to initiate "XXHA Project WORKFLOW" workflow and
 -- this procedure will be called from a trigger on xxha_pa_tasks_alert table
 PROCEDURE Initiate(p_task_id          IN NUMBER,
                    p_task_number      IN VARCHAR2,
                    p_project_id       IN NUMBER,
                    P_initiator        IN NUMBER,
                    p_itemkey          OUT VARCHAR2) as

    lv_item_type           VARCHAR2(20) := 'XPAPROWF';
    ln_itemkey             NUMBER:=0;

    lv_initiator      FND_USER.USER_NAME%TYPE;
    lv_project_number PA_PROJECTS_ALL.SEGMENT1%TYPE;
    lv_project_status_code PA_PROJECTS_ALL.project_status_code%TYPE;

 BEGIN

 --- insert into xxha_workflow_track values (lv_initiator,1);
  ---commit;

      SELECT FU.user_name
      INTO   lv_initiator
      FROM   fnd_user FU
      WHERE  FU.user_id = p_initiator
      AND ROWNUM=1;



      SELECT xxha_prjsc_wf_seq.nextval
      INTO   ln_itemkey
      FROM   DUAL;


 ----insert into xxha_workflow_track values (ln_itemkey,2);
      select segment1,project_status_code
      INTO   lv_project_number,lv_project_status_code
      from   pa_projects_all
      where  project_id = p_project_id;

    ---- insert into xxha_workflow_track values (p_task_id,3);


          WF_ENGINE.CreateProcess(itemtype   => lv_item_type,
                              itemkey    => ln_itemkey,
                              process    => 'XXHA_PROJ_WF',
                              user_key   => lv_project_number||' '||SUBSTR(p_task_number, 1, 10),
                              owner_role => lv_initiator);

                         ----     insert into xxha_workflow_track values (lv_project_number||' '||SUBSTR(p_task_number, 1, 10),5);


   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'TASK_ID',
                                  avalue   => p_task_id);

      ----  insert into xxha_workflow_track values (p_task_id,4);

   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'WORKFLOW_STARTED_BY_ID',
                                  avalue   => p_initiator);



   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'PROJECT_ID',
                                  avalue   => p_project_id);


   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'PROJECT_STATUS_CODE',
                                  avalue   => lv_project_status_code);

                                   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'PA_PROJECT_NUMBER',
                                  avalue   => lv_project_number);



                                    WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'WORKFLOW_STARTED_BY_NAME',
                                  avalue   => lv_initiator);

                    ----              insert into xxha_workflow_track values (p_project_id,6);


       WF_ENGINE.StartProcess(itemtype => lv_item_type,
                              itemkey  => ln_itemkey);

       p_itemkey :=  ln_itemkey;

 EXCEPTION when others then

   NULL;

 END   Initiate;

 -- Procedure to copy the pa_tasks information to xxha_pa_tasks_alert to maintain audit information
 PROCEDURE insert_tasks(p_task_id number,
                        p_project_id number) as
 BEGIN

 INSERT INTO  XXHA_PROJ_TASK_ALERT  XPT
     SELECT *
     FROM PA_TASKS PT
     WHERE PT.PROJECT_ID = p_project_id
     AND   PT.TASK_ID = p_task_id;

 EXCEPTION when others then

   NULL;

 END insert_tasks;


  procedure PA_REV_ASSIGN_WF(itemtype    in varchar2,
                 itemkey      in varchar2,
                 actid        in number,
                 funcmode    in varchar2,
                 resultout out nocopy varchar2)

                 IS

       l_project_id  NUMBER;

       L_CNT NUMBER;
       L_CNT2 NUMBER;
       l_proj_stus_code  VARCHAR2(100);
       l_workflow_started_by_id  number;
       l_project_role_type VARCHAR2(100);

       l_workflow_performer_id number;

       l_workflow_notifier_id  number;

        l_workflow_performer_name varchar2(100);

        l_workflow_notifier_name  varchar2(100);

        lv_initiator varchar2(100);

 lv_init_role_name       VARCHAR2(20):='XXHA_PRJ_REV_ROLE';
 lv_init_role_dispname   VARCHAR2(50) :='XXHA_PRJ_REV_ROLE';

 l_proj_number varchar2(100);
 l_project_name varchar2(100);

 l_project_description varchar2(100);
 l_project_org varchar2(100);

 l_project_type varchar2(100);

 l_product_code varchar2(100);

 l_project_ref varchar2(100);
 l_profile_cnt  number;


                 BEGIN




                 l_workflow_started_by_id := wf_engine.GetItemAttrNumber(itemtype      => itemtype,
                                     itemkey       => itemkey,
                                     aname          => 'WORKFLOW_STARTED_BY_ID' );


 --insert into xxha_workflow_track VALUES ('You are here2',l_workflow_started_by_id);

 --commit;

                  l_project_id := wf_engine.GetItemAttrNumber(     itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_ID' );

                                 l_proj_stus_code := wf_engine.GetItemAttrText(itemtype      => itemtype,
                                 itemkey       => itemkey,
                                 aname          => 'PROJECT_STATUS_CODE' );


                                 SELECT  Project_Number,
 Project_Name ,
 Project_Description ,
 Project_Organization ,
 Project_Type ,
 Product_Source ,
 Source_Reference INTO l_proj_number,
                l_project_name ,l_project_description,l_project_org ,l_project_type ,l_product_code ,l_project_ref
               FROM xxha_proj_workflow_track WHERE PROJECT_ID=l_project_id AND ROWNUM=1;

 -- insert into xxha_workflow_track VALUES ('project number'||l_proj_number,l_project_id );


                wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PA_PROJECT_NUMBER',
              avalue        => l_proj_number);

               wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJECT_NAME',
              avalue        =>  l_project_name);

               wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJECT_DESCRIPTION',
              avalue        =>  l_project_description);

               wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'CARRYING_OUT_ORG_NAME',
              avalue        => l_project_org);

               wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJECT_TYPE',
              avalue        =>  l_project_type);
               wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PM_PROJECT_PRODUCT_CODE',
              avalue        => l_product_code);
               wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PM_PROJECT_REFERENCE',
              avalue        => l_project_ref );

              --- insert into xxha_workflow_track VALUES ('project number'||l_proj_number,l_project_name );

                SELECT FU.user_name
      INTO   lv_initiator
      FROM   fnd_user FU
      WHERE  FU.user_id =l_workflow_started_by_id
      AND ROWNUM=1;

          select person_id  into l_workflow_performer_id from PA_PROJECT_PLAYERS WHERE PROJECT_ROLE_TYPE  ='1000' and project_id=l_project_id  AND    sysdate between start_date_active and nvl(end_date_active, sysdate+1);

                 select person_id  into l_workflow_notifier_id from PA_PROJECT_PLAYERS WHERE PROJECT_ROLE_TYPE  ='PROJECT MANAGER' and project_id=l_project_id  AND    sysdate between start_date_active and nvl(end_date_active, sysdate+1);

                 SELECT    f.user_name into l_workflow_performer_name
                 FROM    fnd_user f
                      , pa_employees e
                 WHERE   f.employee_id = l_workflow_performer_id
                 AND     f.employee_id = e.person_id
                 AND ROWNUM=1;


                 SELECT    f.user_name into l_workflow_notifier_name
                 FROM    fnd_user f
                      , pa_employees e
                     WHERE   f.employee_id = l_workflow_notifier_id
                 AND     f.employee_id = e.person_id
                 AND ROWNUM=1;

           wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJ_ACCT',
              avalue        =>  l_workflow_performer_name);

                 --- insert into xxha_workflow_track VALUES (l_workflow_performer_name,7 );

              wf_engine.SetItemAttrText
                         (itemtype  => itemtype,
                  itemkey   => itemkey,
              aname        => 'PROJECT_MANAGER',
              avalue        =>  l_workflow_notifier_name);

                ---  insert into xxha_workflow_track VALUES (l_workflow_notifier_name,8 );


               WF_DIRECTORY.RemoveUsersFromAdHocRole(Role_name => lv_init_role_name);

                if l_workflow_performer_name=l_workflow_notifier_name then


                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                 else

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_performer_name);

                 WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, l_workflow_notifier_name);


                 WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   => lv_init_role_name);

                              end if;
-- SELECT project_role_type,count(*)
--   INTO l_project_role_type,l_cnt
--   FROM pa_project_players ppa, fnd_user fu
--  WHERE ppa.project_id = l_project_id
--    AND ppa.person_id = fu.employee_id
--    AND fu.user_id = l_workflow_started_by_id
--     AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
--     AND ROWNUM=1
--    group by project_role_type;

       select count(*) into  l_profile_cnt from fnd_profile_options_tl f , fnd_profile_options e ,fnd_profile_option_values a,fnd_user d
WHERE  f.USER_PROFILE_OPTION_NAME = 'PA: Cross Project User -- Update'
and  f.PROFILE_OPTION_NAME=e.profile_option_name
and e.profile_option_id = a.profile_option_id
and a.level_value = d.user_id
and d.user_id=l_workflow_started_by_id
and a.PROFILE_OPTION_VALUE='Y'
and rownum=1;

        if l_profile_cnt =0 then

                SELECT count(*)
                 INTO l_cnt
                 FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
                     AND ppa.person_id = fu.employee_id
                     AND fu.user_id = l_workflow_started_by_id
                        AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
                        and rownum=1;
               if l_cnt=0
               then
                 resultout := wf_engine.eng_completed||':'||'N';

               else
               SELECT project_role_type
              INTO l_project_role_type
              FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
              and rownum=1;
              end if;

         elsif l_profile_cnt <>0 then
              SELECT count(*)
              INTO l_cnt
              FROM pa_project_players ppa, fnd_user fu
             WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
               and rownum=1;
               if l_cnt <>0
                then
                 SELECT project_role_type
              INTO l_project_role_type
              FROM pa_project_players ppa, fnd_user fu
                WHERE ppa.project_id = l_project_id
               AND ppa.person_id = fu.employee_id
               AND fu.user_id = l_workflow_started_by_id
                AND    sysdate between ppa.start_date_active and nvl(ppa.end_date_active, sysdate+1)
              and rownum=1;
              end if;

        end if;



          select count(*) into l_cnt2 from xxha_proj_workflow_track where project_id=l_project_id and ITEMKEY='APPROVED' ;



     if l_cnt2>=1 then
                ---  insert into xxha_workflow_track VALUES (L_CNT,'L_CNT  '||'  '||'5' );

      if (l_project_role_type ='1000' or l_project_role_type ='PROJECT MANAGER' or l_profile_cnt<>0 ) then

      ----insert into xxha_workflow_track VALUES (l_project_role_type,'l_project_role_type  '||'  '||'6' );



                 resultout := wf_engine.eng_completed||':'||'Y';

                     else

                 resultout := wf_engine.eng_completed||':'||'N';

                     END IF;
     ELSE
                     resultout := wf_engine.eng_completed||':'||'N';

     end if;

                 EXCEPTION

 WHEN FND_API.G_EXC_ERROR
     THEN
      resultout := wf_engine.eng_completed||':'||'N';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_REV_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
        --- RAISE;

 WHEN FND_API.G_EXC_UNEXPECTED_ERROR
     THEN
      resultout := wf_engine.eng_completed||':'||'N';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_REV_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
        --- RAISE;
 WHEN NO_DATA_FOUND THEN
  resultout := wf_engine.eng_completed||':'||'N';
   WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'INITIATOR_ROLE',
                              avalue   =>  lv_init_role_name);
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_REV_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
 WHEN OTHERS
     THEN
     resultout := wf_engine.eng_completed||':'||'N';
     WF_CORE.CONTEXT('XXHA_Project_WF','PA_REV_ASSIGN_WF', itemtype, itemkey, to_char(actid), funcmode);
  ---   RAISE;





 END PA_REV_ASSIGN_WF;


 PROCEDURE PA_PROJECT_INITIATE(p_project_id       IN NUMBER,
                    P_initiator        IN NUMBER,
                    p_itemkey          OUT VARCHAR2) as

    lv_item_type           VARCHAR2(20) := 'XPAPROWF';
    ln_itemkey             NUMBER:=0;

    lv_initiator      FND_USER.USER_NAME%TYPE;
    lv_project_number PA_PROJECTS_ALL.SEGMENT1%TYPE;
    lv_project_status_code PA_PROJECTS_ALL.project_status_code%TYPE;

 BEGIN


  ---commit;

      SELECT FU.user_name
      INTO   lv_initiator
      FROM   fnd_user FU
      WHERE  FU.user_id = p_initiator
      and rownum=1;

    --- insert into xxha_workflow_track values (lv_initiator,1);

      SELECT xxha_prjsc_wf_seq.nextval
      INTO   ln_itemkey
      FROM   DUAL;


 ----insert into xxha_workflow_track values (ln_itemkey,2);
      select segment1,project_status_code
      INTO   lv_project_number,lv_project_status_code
      from   pa_projects_all
      where  project_id = p_project_id;



          WF_ENGINE.CreateProcess(itemtype   => lv_item_type,
                              itemkey    => ln_itemkey,
                              process    => 'XXHA_PROJ_WF',
                              user_key   => lv_project_number,
                              owner_role => lv_initiator);

                           ---   insert into xxha_workflow_track values (lv_project_number||' '||SUBSTR(p_task_number, 1, 10),5);




        ---insert into xxha_workflow_track values (p_task_id,4);

   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'WORKFLOW_STARTED_BY_ID',
                                  avalue   => p_initiator);



   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'PROJECT_ID',
                                  avalue   => p_project_id);


   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'PROJECT_STATUS_CODE',
                                  avalue   => lv_project_status_code);

                                   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'PA_PROJECT_NUMBER',
                                  avalue   => lv_project_number);



                                    WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'WORKFLOW_STARTED_BY_NAME',
                                  avalue   => lv_initiator);

                            ----      insert into xxha_workflow_track values (p_project_id,6);


       WF_ENGINE.StartProcess(itemtype => lv_item_type,
                              itemkey  => ln_itemkey);

       p_itemkey :=  ln_itemkey;


 END  PA_PROJECT_INITIATE;

    PROCEDURE insert_project(p_project_id number) as
 BEGIN

 INSERT INTO  XXHA_PROJ_ALERT  XPT
     SELECT *
     FROM PA_projects_all PT
     WHERE PT.PROJECT_ID = p_project_id;


 EXCEPTION when others then

   NULL;

 END insert_project;


  PROCEDURE insert_key_members(p_project_id number,p_project_role_id number) as
 BEGIN

  ---insert into xxha_workflow_track values ('p_project_id'||p_project_id,1);

  ---- insert into xxha_workflow_track values ('RESOURCE_ID'||p_project_role_id,2);

  --- commit;

 INSERT INTO  XXHA_KEY_MEMBERS_ALERT XPT
     SELECT *
     FROM PA_PROJECT_PARTIES PT
     WHERE PT.PROJECT_ID = p_project_id
     and PT.RESOURCE_ID=p_project_role_id;



     ----insert into xxha_workflow_track values ('RESOURCE_ID'||p_project_role_id,3);


 EXCEPTION when others then

    NULL;

 END insert_key_members;


 procedure PA_SET_STATUS(itemtype    in varchar2,
                itemkey      in varchar2,
                actid        in number,
                funcmode    in varchar2,
                resultout out nocopy varchar2)

                IS

      l_project_id  NUMBER;

      L_CNT NUMBER;
      L_CNT2 NUMBER;
      l_proj_stus_code  VARCHAR2(100);
      l_workflow_started_by_id  number;
      l_project_role_type VARCHAR2(100);

      l_workflow_performer_id number;

      l_workflow_notifier_id  number;

       l_workflow_performer_name varchar2(100);

       l_workflow_notifier_name  varchar2(100);

       l_proj_stus_name varchar2(100);

lv_init_role_name       VARCHAR2(20):='XXHA_PRJ_ROLE';
lv_init_role_dispname   VARCHAR2(50) :='XXHA_PRJ_ROLE';

l_proj_number varchar2(100);
l_project_name varchar2(100);

l_project_description varchar2(100);
l_project_org varchar2(100);

l_project_type varchar2(100);

l_product_code varchar2(100);

l_project_ref varchar2(100);

l_last_update_login fnd_user.last_update_login%type;


                BEGIN


                l_workflow_started_by_id := wf_engine.GetItemAttrNumber(itemtype      => itemtype,
                                    itemkey       => itemkey,
                                    aname          => 'WORKFLOW_STARTED_BY_ID' );


                 l_project_id := wf_engine.GetItemAttrNumber(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PROJECT_ID' );


                       l_proj_number :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PA_PROJECT_NUMBER' );
l_project_name :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PROJECT_NAME' );

l_project_description :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PROJECT_DESCRIPTION' );
l_project_org :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'CARRYING_OUT_ORG_NAME' );

l_project_type :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PROJECT_TYPE' );

l_product_code :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PM_PROJECT_PRODUCT_CODE' );

l_project_ref     :=wf_engine.GetItemAttrText(     itemtype      => itemtype,
                                itemkey       => itemkey,
                                aname          => 'PM_PROJECT_REFERENCE' );



--                                l_proj_stus_code := wf_engine.GetItemAttrText(itemtype      => itemtype,
--                                itemkey       => itemkey,
--                                aname          => 'PROJECT_STATUS_CODE' );

--                                 l_proj_stus_name := wf_engine.GetItemAttrText(itemtype      => itemtype,
--                                itemkey       => itemkey,
--                                aname          => 'PROJECT_STATUS_NAME' );

             --- insert into xxha_workflow_track VALUES (l_proj_stus_code,786,l_project_id );

             IF L_PROJECT_ID IS NOT NULL THEN

            --- UPDATE PA_PROJECTS_ALL SET PROJECT_STATUS_CODE='APPROVED' WHERE PROJECT_ID=l_project_id;

            select last_update_login into l_last_update_login  from fnd_user where user_id=l_workflow_started_by_id and rownum=1;


UPDATE pa_projects
   SET project_status_code = 'APPROVED',
       wf_status_code = NULL,
       closed_date = NULL,
       last_update_date = SYSDATE,
       last_updated_by =l_workflow_started_by_id,
       last_update_login =l_last_update_login
 WHERE project_id = l_project_id;

--               insert into xxha_proj_workflow_track VALUES ('APPROVED',l_project_id,l_proj_number,
--               l_project_name ,l_project_description,l_project_org ,l_project_type ,l_product_code ,l_project_ref  );


                resultout := wf_engine.eng_completed||':'||'Y';

                ELSE

               --- UPDATE PA_PROJECTS_ALL SET PROJECT_STATUS_CODE='REJECTED' WHERE PROJECT_ID=l_project_id;
--
                 UPDATE pa_projects
         SET    project_status_code ='REJECTED',
            wf_status_code      = NULL,
            closed_date         = null,
            last_update_date    = sysdate,
            last_updated_by     = l_workflow_started_by_id,
            last_update_login   = l_last_update_login
         WHERE  project_id = l_project_id;

      resultout := wf_engine.eng_completed||':'||'N';



END IF;
                EXCEPTION

WHEN FND_API.G_EXC_ERROR
    THEN
    resultout := wf_engine.eng_completed||':'||'Y';
    WF_CORE.CONTEXT('XXHA_Project_WF','PA_SET_STATUS', itemtype, itemkey, to_char(actid), funcmode);
       --- RAISE;

WHEN FND_API.G_EXC_UNEXPECTED_ERROR
    THEN
    resultout := wf_engine.eng_completed||':'||'Y';
    WF_CORE.CONTEXT('XXHA_Project_WF','PA_SET_STATUS', itemtype, itemkey, to_char(actid), funcmode);
      ---  RAISE;
WHEN NO_DATA_FOUND THEN
 resultout := wf_engine.eng_completed||':'||'Y';
    WF_CORE.CONTEXT('XXHA_Project_WF','PA_SET_STATUS', itemtype, itemkey, to_char(actid), funcmode);
WHEN OTHERS
    THEN
    resultout := wf_engine.eng_completed||':'||'Y';
    WF_CORE.CONTEXT('XXHA_Project_WF','PA_SET_STATUS', itemtype, itemkey, to_char(actid), funcmode);
   --- RAISE;


END PA_SET_STATUS;


 end XXHA_Project_WF;

/
