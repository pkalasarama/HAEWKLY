create or replace 
PACKAGE        "XXHA_REC_EMP_HIRE_PKG" AUTHID CURRENT_USER
AS
  /*#########################################################################
  ------------------------< Create Employee >-------------------------------
  ##########################################################################*/
  PROCEDURE CREATE_EMPLOYEE(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2 );
	  
 /*#########################################################################
  ------------------------< Create TEMP_To_REHIRE >-------------------------------
  ##########################################################################*/
  PROCEDURE CREATE_TEMP_TO_REHIRE(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2 );	
	  
 /*#########################################################################
  ------------------------< Create IS_CANDIDATE_REHIRE >-------------------------------
  ##########################################################################*/
  PROCEDURE CREATE_IS_REHIRE(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2 );
	  
  /*#########################################################################
  ------------------------< Create Rehire_Ex_Employee >-------------------------------
  ##########################################################################*/
  PROCEDURE REHIRE_EX_EMPLOYEE(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2 );	
  
  /*#########################################################################
  ------------------------< Create REHIRE_EXEMP_CONTINGENT >-------------------------------
  ##########################################################################*/
  PROCEDURE REHIRE_EXEMP_CONTINGENT(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2);	  

 /*#########################################################################
  ------------------------< Update_Fut_EMP_SYSDATE >-------------------------------
  ##########################################################################*/
  PROCEDURE Update_Fut_EMP_SYSDATE(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2 );		  
  	  
  /*#########################################################################
  ------------------------< Create Employee Assignments >-------------------------------
  ##########################################################################*/
  PROCEDURE Create_emp_asgnmnt(
      p_HR_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_API_MODE   IN VARCHAR2,
      P_ERR_MSG OUT VARCHAR2 );
	  
/*###########################################################################################################################
  ------------------------< Create Employee Assignments for Ex-employee Rehire to Contingent >-------------------------------
  ###########################################################################################################################*/
  PROCEDURE Create_Contingent_asgnmnt(
      p_HR_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_API_MODE   IN VARCHAR2,
      P_ERR_MSG OUT VARCHAR2 );	  
  /*#########################################################################
  ------------------------< CREATE EMPLOYEEADDRESS >-------------------------
  ##########################################################################*/
  PROCEDURE CREATE_EMPLOYEE_ADDRESS(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2);
  /*#########################################################################
  ------------------------< Create Employee Phone Detail  >------------------
  ##########################################################################*/
  PROCEDURE CREATE_EMP_PH_DETAILS(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      p_phone      IN VARCHAR2,
      P_PHONE_TYPE IN VARCHAR2,
      P_ERR_MSG OUT VARCHAR2);
  /*#########################################################################
  ------------------------< Create Employee Salary >-------------------------
  ##########################################################################*/
  PROCEDURE CREATE_EMP_SALARY_DETAILS(
      P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
      P_ERR_MSG OUT VARCHAR2);
	  
 --##########################################################################################################################
   ------------------< Pragma Autonomous Transaction for Updating the status when record is failed>------------------------
 --##########################################################################################################################
			/*PROCEDURE Update_Last_Error(
			P_STAT_STG IN VARCHAR2,
			P_ERR_COD IN VARCHAR2,
			P_ERR_MSG IN VARCHAR2,
			P_SEQ_NO IN Number);*/
  /*#########################################################################
  ------------------------< Main Procedure to call above procedures >--------
  ##########################################################################*/
  PROCEDURE MAIN(
      ERRBUFF out  VARCHAR2,
      RETCODE out number,
	  P_Candidate_Number in number);
END XXHA_REC_EMP_HIRE_PKG;
/

create or replace 
PACKAGE BODY "XXHA_REC_EMP_HIRE_PKG"
AS
  /*#########################################################################
  Package : XXHA_REC_EMP_HIRE_PKG
  Date: 08/MAY/2015
  Description: This Package used to load new employees and assignment details using API
  Approach.
  Change Date      Change Description Version
  ---------------------------------------------------------------------------
  ##########################################################################*/
  g_error     NUMBER;
  g_error_msg VARCHAR2(1000);
  G_PERSON_ID NUMBER;
  --G_ADDRESS_ID    NUMBER;
  G_ASSIGNMENT_ID NUMBER;
  /*#########################################################################
  ------------------------< Validate Employee >-------------------------------
  ##########################################################################*/
PROCEDURE Validate_employee(
    p_hr_emp_val_rec IN OUT XXHA_REC_EMP_INT_STG% ROWTYPE)
IS
  l_business_group Hr_Locations_All.Attribute6%TYPE ;
  l_organization_id   NUMBER;
  l_business_group_id NUMBER;
  L_ACCOUNT_ATT       VARCHAR2(50);
  l_set_of_books_id   NUMBER;
  L_count             NUMBER      := 0;
  l_err_flag          VARCHAR2(1) := 'N';
  L_LOCATION_ID       NUMBER ;
  L_Person_Type_id Per_Person_Types.person_type_id%type;
  L_Ledger_Name           VARCHAR2(250);
  L_segment1              NUMBER;
  L_hourly_salary         VARCHAR2(30);
  L_Govt_Entity           VARCHAR2(300);
  L_exp_ccid              NUMBER;
  L_sup_id                NUMBER;
  L_JOB_ID                NUMBER ;
  L_Job_Code              VARCHAR2(300);
  L_Payroll_Name          VARCHAR2(300);
  l_PAYROLL_ID            NUMBER ;
  l_GRADE_ID              NUMBER ;
  l_PAY_BASIS_ID          NUMBER ;
  L_Salary_Basis          VARCHAR2(300);
  L_COUNTry               VARCHAR2(300);
  l_assg_cat              VARCHAR2(30);
  L_COUNTY_NAME           VARCHAR2(240);
  L_SEQ_NO                NUMBER;
  l_n_code_combination_id NUMBER;
  l_code                  VARCHAR2(240);
  l_ca_province           NUMBER;
  l_bg number := 0;
BEGIN
  L_SEQ_NO := P_HR_EMP_VAL_REC.TRANSACTION_ID_STG;
  fnd_file.put_line(fnd_file.log,'-----------------------------------------------');
  fnd_file.put_line(fnd_file.log,'Sequence Number in Validate employee:'||L_SEQ_NO);
  fnd_file.put_line(fnd_file.log,'Validate employee open');
  
  -- Set Who columns and Request ID
  UPDATE XXHA_REC_EMP_INT_STG
  SET CREATION_date  = sysdate ,
    CREATED_BY       = fnd_global.user_id ,
    LAST_UPDATE_date = sysdate ,
    LAST_UPDATED_BY  = fnd_global.user_id,
    REQUEST_ID       = fnd_global.conc_request_id
  WHERE STATUS_STG   = 'N';
  fnd_file.put_line( apps.fnd_file.LOG, 'Concurrent Request ID: '||fnd_global.conc_request_id);
  --Validation for business group
  BEGIN
    SELECT Attribute6
    INTO l_business_group
    FROM Hr_Locations_All
    WHERE Location_Code=P_HR_EMP_VAL_REC.REQ_PRI_LOC_CUST_CODE;
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_BUSINESS_GROUP   = l_business_group
    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
    COMMIT;
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Business Group Name:'||l_business_group);
    --- Check if the Location is enabled for Taleo New Hire Interface
    IF l_business_group IS NOT NULL THEN
      SELECT COUNT(1)
      INTO l_bg
      FROM hr_lookups
      WHERE lookup_type                 = 'XXHA_TALEO_NEW_HIRE_BG'
      AND lookup_code                          = l_business_group
      AND enabled_flag                  = 'Y'
      AND NVL(end_date_active,sysdate) >= sysdate;
      IF l_bg                           > 0 THEN
        IF l_business_group            IS NOT NULL THEN
          SELECT Business_Group_Id
          INTO l_business_group_id
          FROM Per_Business_Groups
          WHERE Name      =l_business_group
          AND enabled_flag='Y';
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_BUSINESS_GROUP_ID = l_business_group_id
          WHERE TRANSACTION_ID_STG  = L_SEQ_NO;
          COMMIT;
          FND_FILE.PUT_LINE(FND_FILE.LOG,'Business Group ID:'||l_business_group_id);
        ELSE
          fnd_file.put_line(fnd_file.log,'Business Group is Null:'||SQLERRM);
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'VE100:',
            ERROR_MSG = ERROR_MSG
            ||'Business group name is null, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END IF;
        --Validation for last name
        BEGIN
          IF p_hr_emp_val_rec.LAST_NAME IS NULL THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'VE101:',
              ERROR_MSG = ERROR_MSG
              ||'Last name is null, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating Last Name:'||SQLERRM);
        End;
        -- Validation for preferred name -- Commented by Vinay Kaveti on 22-Feb-16
  /*      BEGIN
          IF p_hr_emp_val_rec.CANDIDATE_UDF_2 IS NULL THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'VE102:',
              ERROR_MSG = ERROR_MSG
              ||'Preferred name is null, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating Preferred Name:'||SQLERRM);
        END;  */
        --Validation for Person Type
        BEGIN
          IF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS) = 'TEMPORARY WORKER' THEN
            SELECT person_type_id
            INTO L_Person_Type_id
            FROM Per_Person_Types
            WHERE Upper(User_Person_Type) = Upper('HAE Contingent Worker')
            AND Business_Group_Id         = l_business_group_id
            AND active_flag               ='Y';
            fnd_file.put_line(fnd_file.log,'Person Type ID for Temporary Worker Before Update:'||L_Person_Type_id);
            UPDATE XXHA_REC_EMP_INT_STG
            SET NEW_PERSON_TYP_ID    = L_Person_Type_id
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'Person Type ID for Temporary Worker After Update:'||L_Person_Type_id);
          ELSE
            SELECT person_type_id
            INTO L_Person_Type_id
            FROM Per_Person_Types
            WHERE Upper(User_Person_Type) = Upper('Employee')
            AND Business_Group_Id         = l_business_group_id
            AND active_flag               ='Y';
            fnd_file.put_line(fnd_file.log,'Person Type ID of an employee Before Update:'||L_Person_Type_id);
            UPDATE XXHA_REC_EMP_INT_STG
            SET NEW_PERSON_TYP_ID    = L_Person_Type_id
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'Person Type ID of an Employee After Update:'||L_Person_Type_id);
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Person Type:'||SQLERRM);
        END;
        --Validation Email Address
        BEGIN
          IF p_hr_emp_val_rec.EMAIL IS NULL THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'EA100:',
              ERROR_MSG = ERROR_MSG
              ||'Email id is null, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Email Address'||SQLERRM);
        END;
        --Validation for candidate number null
        BEGIN
          fnd_file.put_line(fnd_file.log,'IN Candidate Number null Validation:'||p_hr_emp_val_rec.candidate_number);
          IF p_hr_emp_val_rec.candidate_number IS NULL THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'CN100:',
              ERROR_MSG = ERROR_MSG
              ||'Candidate number is null, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Candidate Number Null Validation:'||sqlerrm);
        END;
        --Validation for Hire date
        BEGIN
          IF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS)    <> 'TEMPORARY WORKER' THEN
            IF p_hr_emp_val_rec.OFFER_ACTUAL_START_DATE IS NULL THEN
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'OD100:',
                ERROR_MSG = ERROR_MSG
                ||'Hire Date is NULL, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
            END IF;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Hire Date Validation:'||SQLERRM);
        END;
        --Added Validation for Birth Date
        /* BEGIN
        IF p_hr_emp_val_rec.BIRTH_DAY IS NULL THEN
        UPDATE XXHA_REC_EMP_INT_STG
        SET STATUS_STG = 'VE',
        ERROR_CODE     = ERROR_CODE
        ||'BD100:',
        ERROR_MSG = ERROR_MSG
        ||'Date of Birth is NULL, '
        WHERE TRANSACTION_ID_STG = L_SEQ_NO;
        COMMIT;
        END IF;
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in Birth Date Validation:'||SQLERRM);
        END;*/
        --
        --Validation for SSN number
        /* BEGIN
        SELECT COUNT(*)
        INTO L_count
        FROM per_all_people_f
        WHERE NATIONAL_IDENTIFIER = p_hr_emp_val_rec.SSN
        --modified
        AND business_group_id = l_business_group_id
        AND SYSDATE BETWEEN EFFECTIVE_START_DATE AND EFFECTIVE_END_DATE
        AND p_hr_emp_val_rec.SSN IS NOT NULL;
        fnd_file.put_line(fnd_file.log,'SSN Number:'||p_hr_emp_val_rec.SSN);
        fnd_file.put_line(fnd_file.log,'Count in SSN Validation:'||L_count);
        IF L_count <> 0 THEN
        UPDATE XXHA_REC_EMP_INT_STG
        SET STATUS_STG = 'VE' ,
        ERROR_CODE     = ERROR_CODE
        ||',VE113' ,
        ERROR_MSG = ERROR_MSG
        ||',Emp SSN No Already Exist'
        WHERE TRANSACTION_ID_STG = L_SEQ_NO;
        COMMIT;
        END IF;
        L_count  := 0;
        l_err_flag := 'N';
        EXCEPTION
        WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in SSN number validation:'||SQLERRM);
        END; */
        --validation for REQUISITION_UDF_3
        BEGIN
          IF p_hr_emp_val_rec.REQUISITION_UDF_3 IS NULL THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'RU103:',
              ERROR_MSG = ERROR_MSG
              || 'Requisition UDF 3 is NULL, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Requisition UDF 3'||SQLERRM);
        END;
        --Validation for Requisition UDF 5
        BEGIN
          IF p_hr_emp_val_rec.REQUISITION_UDF_5 IS NULL THEN
            g_error                             :=1;
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'RU105:',
              ERROR_MSG = ERROR_MSG
              || 'Requisition UDF 5 is NULL, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Requisition UDF 5'||SQLERRM);
          g_error:=1;
        END;
        /*###########################################################################################
        ------------------------< validation for Ledger in assignments >------
        ############################################################################################*/
        BEGIN
          SELECT Description
          INTO L_Ledger_Name
          FROM Hr_Lookups Hl ,
            XXHA_REC_EMP_INT_STG CUST
          WHERE Lookup_Type                               ='XXHA_LEDGER_BUSINESS_GROUP'
          AND SUBSTR(Hl.Meaning,0,Instr(Hl.Meaning,':')-1)=l_business_group
          AND SUBSTR(Hl.Meaning,Instr(Hl.Meaning,':')  +1)=p_hr_emp_val_rec.Req_Pri_Loc_Cust_Code
          AND TRANSACTION_ID_STG                          = L_SEQ_NO
          AND TRUNC(sysdate) BETWEEN NVL(Hl.start_date_active,TRUNC(sysdate)) AND NVL(Hl.end_date_active,'31-DEC-4712')
          AND enabled_flag ='Y';
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_LEDGER_NAME      = L_Ledger_Name
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          FND_FILE.PUT_LINE(FND_FILE.LOG,'Ledger Name for Assignments:'||L_Ledger_Name);
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'LD100:',
            ERROR_MSG = ERROR_MSG
            ||'Exception Occured - Ledger Validation, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END;
        /*########################################################################################################
        ------------------------< Validation to derive set of books id for UPDATE_EMP_ASG >------
        #########################################################################################################*/
        BEGIN
          SELECT ledger_id
          INTO l_set_of_books_id
          FROM gl_ledgers
          WHERE upper(name)=upper(L_Ledger_Name);
          fnd_file.put_line(fnd_file.log,'Passing set of books Id:'||l_set_of_books_id);
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_SET_OF_BOOKS_ID  = l_set_of_books_id
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'LE100:',
            ERROR_MSG = ERROR_MSG
            ||'Exception Occured while getting  set of books id, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END;
        /*#################################################################################
        ------------------------< Validation for ccid (purchase order information tab)>------
        Validation for REQUISITION_UDF_7,REQUISITION_UDF_8,REQUISITION_UDF_9
        ##################################################################################*/
        BEGIN
          SELECT p_hr_emp_val_rec.requisition_udf_8
            ||'.000.'
            ||p_hr_emp_val_rec.BUSINESS_UNIT
            ||'.'
            ||p_hr_emp_val_rec.REQUISITION_UDF_9
            ||'.'
            ||SUBSTR(p_hr_emp_val_rec.Correspondence,1,instr(p_hr_emp_val_rec.Correspondence,' - ')-1)
            ||'.605020.000.000000.000000'
          INTO l_code
          FROM dual;
          --purchase order information tab - Default Expense Account
          SELECT UNIQUE code_combination_id
          INTO L_exp_ccid
          FROM gl_code_combinations
          WHERE 1         = 1
          AND segment1    = p_hr_emp_val_rec.requisition_udf_8
          AND SEGMENT2    = '000'                          --   Given in mapping document to hard code - page 25
          AND SEGMENT3    = p_hr_emp_val_rec.BUSINESS_UNIT --requisition_udf_7
          AND SEGMENT4    = p_hr_emp_val_rec.REQUISITION_UDF_9
          AND SEGMENT5    =SUBSTR(p_hr_emp_val_rec.Correspondence,1,instr(p_hr_emp_val_rec.Correspondence,' - ')-1)
          AND Segment6    = '605020' --- Hard code to 605020 provided in screen short 25
          AND segment7    = '000'
          AND segment8    ='000000'
          AND segment9    ='000000'
          AND enabled_flag='Y';
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_EXPENSE_CCID     = L_exp_ccid
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'Code Combination ID for purchase order information : '||L_exp_ccid);
        EXCEPTION
        WHEN no_data_found THEN
          l_n_code_combination_id    := fnd_flex_ext.get_ccid ('SQLGL', 'GL#', 101, TO_CHAR (SYSDATE, 'YYYY/MM/DD HH24:MI:SS'), l_code );
          IF l_n_code_combination_id <> 0 THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET NEW_EXPENSE_CCID     = l_n_code_combination_id
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'Code Combination ID for purchase order information : '||l_n_code_combination_id);
          ELSE
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'EA101:',
              ERROR_MSG = ERROR_MSG
              ||'Invalid Expense Account'
              ||p_hr_emp_val_rec.requisition_udf_8
              ||'.000.'
              ||p_hr_emp_val_rec.BUSINESS_UNIT
              ||'.'
              ||p_hr_emp_val_rec.REQUISITION_UDF_9
              ||'.'
              --||p_hr_emp_val_rec.Correspondence
              ||SUBSTR(p_hr_emp_val_rec.Correspondence,1,instr(p_hr_emp_val_rec.Correspondence,' - ')-1)
              ||'.605020.000.000000.000000, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        WHEN OTHERS THEN
          g_error:=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'EA102:',
            ERROR_MSG = ERROR_MSG
            ||'Invalid Expense Account'
            ||p_hr_emp_val_rec.requisition_udf_8
            ||'.000.'
            ||p_hr_emp_val_rec.BUSINESS_UNIT
            ||'.'
            ||p_hr_emp_val_rec.REQUISITION_UDF_9
            ||'.'
            --||p_hr_emp_val_rec.Correspondence
            ||SUBSTR(p_hr_emp_val_rec.Correspondence,1,instr(p_hr_emp_val_rec.Correspondence,' - ')-1)
            ||'.605020.000.000000.000000, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END;
        -- Validation for supervisor
        BEGIN
          IF p_hr_emp_val_rec.HIRING_MGR_EMP_ID IS NOT NULL THEN
            SELECT papf.PERSON_ID
            INTO L_sup_id
            FROM PER_ALL_PEOPLE_F PAPF
            WHERE 1 = 1
              --AND PAPF.BUSINESS_GROUP_ID = l_business_group_id
            AND PAPF.EMPLOYEE_NUMBER = p_hr_emp_val_rec.HIRING_MGR_EMP_ID
            AND TRUNC (NVL(p_hr_emp_val_rec.OFFER_ACTUAL_START_DATE,sysdate)) BETWEEN NVL ( PAPF.EFFECTIVE_START_DATE, TRUNC (SYSDATE)) AND NVL ( PAPF.EFFECTIVE_END_DATE, TRUNC (SYSDATE));
            fnd_file.put_line(fnd_file.log,'l_business_group_id in supervisor validation : '||l_business_group_id);
          END IF;
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_SUPERVISOR_ID    =L_sup_id
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'L_sup_id : '||L_sup_id);
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'HM100:',
            ERROR_MSG = ERROR_MSG
            ||'Supervisor Not exists, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'Error occured in supervisor validation'||sqlerrm);
        END;
        --Validation for Salary/Hourly
        BEGIN
          IF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS)<>'TEMPORARY WORKER' THEN
            IF p_hr_emp_val_rec.SALARY_HOURLY        = 1 THEN
              SELECT lookup_code
              INTO L_hourly_salary
              FROM Hr_Lookups
              WHERE Lookup_Type ='HOURLY_SALARIED_CODE'
              AND upper(meaning)=upper('Hourly')
              AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
              AND enabled_flag ='Y';
              UPDATE XXHA_REC_EMP_INT_STG
              SET NEW_HOURLY_SALARY    = L_hourly_salary
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
              fnd_file.put_line(fnd_file.log,'L_hourly_salary :'||L_hourly_salary);
            elsif p_hr_emp_val_rec.SALARY_HOURLY=2 THEN
              SELECT lookup_code
              INTO L_hourly_salary
              FROM Hr_Lookups
              WHERE Lookup_Type ='HOURLY_SALARIED_CODE'
              AND upper(meaning)=upper('Salaried')
              AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
              AND enabled_flag ='Y';
              UPDATE XXHA_REC_EMP_INT_STG
              SET NEW_HOURLY_SALARY    = L_hourly_salary
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
              fnd_file.put_line(fnd_file.log,'L_hourly_salary :'||L_hourly_salary);
            ELSE
              g_error:=1;
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'SA100:',
                ERROR_MSG = ERROR_MSG
                ||'Salary/Hourly is not specified, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
            END IF;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Exception occured in Validating Salary/Hourly'||SQLERRM);
          g_error_msg := SUBSTR(sqlerrm,1,100);
          g_error     :=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'SA101:',
            ERROR_MSG = ERROR_MSG
            ||'Salary/Hourly failed '
            ||g_error_msg
            ||', '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
        END;
        /*###########################################################################################
        ------------------------< Validation for Government Reporting Entity in assignments >------
        ############################################################################################*/
        BEGIN
          SELECT Description
          INTO L_Govt_Entity
          FROM Hr_Lookups Hl
          WHERE Lookup_Type ='XXHA_GOVT_REPORTING_ENTITY'
          AND Meaning       =p_hr_emp_val_rec.Req_Pri_Loc_Cust_Code
          AND TRUNC(sysdate) BETWEEN NVL(Hl.start_date_active,TRUNC(sysdate)) AND NVL(Hl.end_date_active,'31-DEC-4712')
          AND enabled_flag ='Y';
          fnd_file.put_line(fnd_file.log,'Government Legal Entity :'||L_Govt_Entity);
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_GOVT_ENTITY      = L_Govt_Entity
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_Govt_Entity :=NULL;
        WHEN OTHERS THEN
          g_error     :=1;
          g_error_msg := SUBSTR(sqlerrm,1,100);
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'GR100:',
            ERROR_MSG = ERROR_MSG
            ||'Exception Occurred while getting Government Legal Entity '
            ||g_error_msg
            ||', '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END;
        /*########################################################################################################
        ------------------------< Validation to derive organization id I.e. P_segment1 for UPDATE_EMP_ASG >------
        #########################################################################################################*/
        BEGIN
          IF L_Govt_Entity IS NOT NULL THEN
            SELECT organization_id
            INTO L_segment1
            FROM hr_legal_entities
            WHERE upper(name)    =upper(L_Govt_Entity)
            AND business_group_id=l_business_group_id;
            UPDATE XXHA_REC_EMP_INT_STG
            SET NEW_LEGAL_ENTITY_ID  = L_segment1
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
            fnd_file.put_line(fnd_file.log,'Passing segment1 to populate GRE :'||L_segment1);
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          g_error     :=1;
          g_error_msg := SUBSTR(sqlerrm,1,100);
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'OR100:',
            ERROR_MSG = ERROR_MSG
            ||'Exception Occurred while getting  L_segment1 for Government Legal Entity, '
            ||g_error_msg
            ||', '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END;
        /*###########################################################################################################
        --Validation for Organization code(Of Department) for Assignments  (Requisition Organization Customer Code)
        ##############################################################################################################*/
        BEGIN
          --Getting the values and using them as global variables
          IF p_hr_emp_val_rec.ORG_CODE IS NOT NULL THEN
            SELECT organization_id
            INTO l_organization_id
            FROM hr_all_organization_units
            WHERE TYPE            = 'DEPT' --Mentioned in the requirement document
            AND BUSINESS_GROUP_ID =l_business_group_id
            AND NAME              = p_hr_emp_val_rec.ORG_CODE;
            UPDATE XXHA_REC_EMP_INT_STG
            SET NEW_ORGANIZATION_ID  = l_organization_id
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Organization Id in assignments:'||l_organization_id);
          ELSE
            g_error:=1;
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'VE114:',
              ERROR_MSG = ERROR_MSG
              ||'Requisition Organization Customer Code is null, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'OG114:',
            ERROR_MSG = ERROR_MSG
            ||'Organization code not valid, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'Exception occured in Organization Customer Code'||SQLERRM);
          g_error:=1;
        END;
        /*#########################################################################
        ------------------------< validation for job in assignments >-----------------
        Requisition_Udf_3, REQ_JOB_CODE
        ##########################################################################*/
        BEGIN
          L_count := 0;
          SELECT JOB_ID ,
            Attribute1
          INTO L_JOB_ID ,
            L_ACCOUNT_ATT
          FROM per_job_definitions JD,
            Per_Jobs Pj
          WHERE 1     =1
          AND Pj.Name =
            (SELECT Requisition_Udf_3
              ||'.'
              ||SUBSTR(REQ_JOB_CODE,0,Instr(REQ_JOB_CODE,':')-1)
            FROM Xxha_Rec_Emp_Int_Stg
            WHERE TRANSACTION_ID_STG=L_SEQ_NO
            )
          AND Jd.Job_Definition_Id     = Pj.Job_Definition_Id
          AND NVL(pj.date_to,sysdate) >= sysdate
          AND TRUNC(sysdate) BETWEEN NVL(Jd.start_date_active,TRUNC(sysdate)) AND NVL(Jd.end_date_active,'31-DEC-4712')
          AND Jd.enabled_flag ='Y';
          fnd_file.put_line(fnd_file.log,'NEW_JOB_ID :'||L_JOB_ID);
          fnd_file.put_line(fnd_file.log,'L_ACCOUNT_ATT :'||L_ACCOUNT_ATT);
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_JOB_ID           = L_JOB_ID
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
          fnd_file.put_line(fnd_file.log,'Getting the job id From lookup table');
          IF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS) <> 'TEMPORARY WORKER' THEN
            BEGIN
              SELECT meaning
              INTO L_Job_Code
              FROM Hr_Lookups
              WHERE Lookup_Type     ='XXHA_JOB_BUS_GROUP' --'XX_JOB_BUSINESS_GROUP'
              AND upper(lookup_code)=upper(l_business_group)
              AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
              AND enabled_flag ='Y';
              fnd_file.put_line(fnd_file.log,'Job Code from lookups :'||L_Job_Code);
              SELECT JOB_ID ,
                Attribute1
              INTO L_JOB_ID ,
                L_ACCOUNT_ATT
              FROM per_job_definitions JD,
                Per_Jobs Pj
              WHERE 1                      =1
              AND Pj.Name                  =L_Job_Code
              AND Jd.Job_Definition_Id     = Pj.Job_Definition_Id
              AND NVL(pj.date_to,sysdate) >= sysdate
              AND TRUNC(sysdate) BETWEEN NVL(Jd.start_date_active,TRUNC(sysdate)) AND NVL(Jd.end_date_active,'31-DEC-4712')
              AND Jd.enabled_flag ='Y';
              fnd_file.put_line(fnd_file.log,'NEW_JOB_ID :'||L_JOB_ID);
              UPDATE XXHA_REC_EMP_INT_STG
              SET NEW_JOB_ID           = L_JOB_ID
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
            EXCEPTION
            WHEN NO_data_found THEN
              SELECT COUNT(*)
              INTO L_count
              FROM per_job_definitions JD,
                Per_Jobs Pj
              WHERE 1=1
              AND Pj.Name LIKE 'Title Pending%' --here getting multiple values
                --already validation of this name is done in first begin, so there will be no value with that combination
              AND Jd.Job_Definition_Id     = Pj.Job_Definition_Id
              AND pj.business_group_id     =l_business_group_id
              AND NVL(pj.date_to,sysdate) >= sysdate
              AND TRUNC(sysdate) BETWEEN NVL(Jd.start_date_active,TRUNC(sysdate)) AND NVL(Jd.end_date_active,'31-DEC-4712')
              AND JD.enabled_flag ='Y';
              IF L_count          = 1 THEN
                SELECT JOB_ID ,
                  Attribute1
                INTO L_JOB_ID ,
                  L_ACCOUNT_ATT
                FROM per_job_definitions JD,
                  Per_Jobs Pj
                WHERE 1=1
                AND Pj.Name LIKE 'Title Pending%' --here getting multiple values
                  --already validation of this name is done in first begin, so there will be no value with that combination
                AND Jd.Job_Definition_Id     = Pj.Job_Definition_Id
                AND pj.business_group_id     =l_business_group_id
                AND NVL(pj.date_to,sysdate) >= sysdate --Added this to restrict multiple values
                AND enabled_flag             ='Y';
                fnd_file.put_line(fnd_file.log,'In Else condition Getting NEW_JOB_ID :'||L_JOB_ID);
                fnd_file.put_line(fnd_file.log,'In Else condition Getting L_ACCOUNT_ATT :'||L_ACCOUNT_ATT);
                UPDATE XXHA_REC_EMP_INT_STG
                SET NEW_JOB_ID           = L_JOB_ID
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
              ELSE
                UPDATE XXHA_REC_EMP_INT_STG
                SET STATUS_STG = 'VE',
                  ERROR_CODE   = ERROR_CODE
                  ||'JC100:',
                  ERROR_MSG = ERROR_MSG
                  ||'Job Code Validation failed, '
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
                Fnd_File.Put_Line(Fnd_File.Log,'Job Code Validation failed, ');
              END IF;
            END;
          elsIF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS) = 'TEMPORARY WORKER' THEN
            BEGIN
              SELECT COUNT(1)
              INTO L_count
              FROM per_job_definitions JD,
                Per_Jobs Pj
              WHERE 1=1
              AND Pj.Name LIKE 'Temporary%'
              AND Jd.Job_Definition_Id     = Pj.Job_Definition_Id
              AND pj.business_group_id     =l_business_group_id
              AND NVL(pj.date_to,sysdate) >= sysdate
              AND TRUNC(sysdate) BETWEEN NVL(Jd.start_date_active,TRUNC(sysdate)) AND NVL(Jd.end_date_active,'31-DEC-4712')
              AND JD.enabled_flag ='Y';
              fnd_file.put_line(fnd_file.log,'Temporary Worker NEW_JOB_ID :'||L_JOB_ID);
              fnd_file.put_line(fnd_file.log,'Temporary Worker L_ACCOUNT_ATT :'||L_ACCOUNT_ATT);
              IF l_count > 1 THEN
                SELECT JOB_ID ,
                  Attribute1
                INTO L_JOB_ID ,
                  L_ACCOUNT_ATT
                FROM per_job_definitions JD,
                  Per_Jobs Pj
                WHERE 1=1
                AND Pj.Name LIKE 'Temporary%'
                  ||'.'
                  ||p_hr_emp_val_rec.c_country_abb
                  ||'%'
                AND Jd.Job_Definition_Id     = Pj.Job_Definition_Id
                AND pj.business_group_id     =l_business_group_id
                AND NVL(pj.date_to,sysdate) >= sysdate
                AND TRUNC(sysdate) BETWEEN NVL(Jd.start_date_active,TRUNC(sysdate)) AND NVL(Jd.end_date_active,'31-DEC-4712')
                AND JD.enabled_flag ='Y';
                fnd_file.put_line(fnd_file.log,'Temporary Worker NEW_JOB_ID :'||L_JOB_ID);
                fnd_file.put_line(fnd_file.log,'Temporary Worker L_ACCOUNT_ATT :'||L_ACCOUNT_ATT);
                UPDATE XXHA_REC_EMP_INT_STG
                SET NEW_JOB_ID           = L_JOB_ID
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
              ELSE
                SELECT JOB_ID ,
                  Attribute1
                INTO L_JOB_ID ,
                  L_ACCOUNT_ATT
                FROM per_job_definitions JD,
                  Per_Jobs Pj
                WHERE 1=1
                AND Pj.Name LIKE 'Temporary%'
                AND Jd.Job_Definition_Id     = Pj.Job_Definition_Id
                AND pj.business_group_id     =l_business_group_id
                AND NVL(pj.date_to,sysdate) >= sysdate
                AND TRUNC(sysdate) BETWEEN NVL(Jd.start_date_active,TRUNC(sysdate)) AND NVL(Jd.end_date_active,'31-DEC-4712')
                AND JD.enabled_flag ='Y';
                fnd_file.put_line(fnd_file.log,'Temporary Worker NEW_JOB_ID :'||L_JOB_ID);
                fnd_file.put_line(fnd_file.log,'Temporary Worker L_ACCOUNT_ATT :'||L_ACCOUNT_ATT);
                UPDATE XXHA_REC_EMP_INT_STG
                SET NEW_JOB_ID           = L_JOB_ID
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'JC100:',
                ERROR_MSG = ERROR_MSG
                ||'Job Code Validation failed, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
              Fnd_File.Put_Line(Fnd_File.Log,'Job Code Validation failed, ');
            END;
          END IF;
        END;
        /*#########################################################################
        ------------------------< validation for grade in assignments >---------------
        ##########################################################################*/
  /*       BEGIN    -- Vinay
          IF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS)='TEMPORARY WORKER' THEN
            l_GRADE_ID                             :=NULL;
          ELSE
            --2
            IF L_JOB_ID IS NOT NULL THEN
              BEGIN
                SELECT COUNT(pg.grade_id)
                INTO l_GRADE_ID
                FROM Per_Grades Pg,
                  Per_Valid_Grades Pvg,
                  XXHA_REC_EMP_INT_STG cust
                WHERE Pg.Grade_Id                         =Pvg.Grade_Id
                AND SUBSTR(Pg.Name,0,Instr(Pg.Name,'.')-1)= Cust.Req_Job_Grade--SUBSTR(Cust.Req_Job_Grade,0,Instr(Cust.Req_Job_Grade,'.')-1)
                AND TRANSACTION_ID_STG                    =L_SEQ_NO
                AND NVL(Pvg.date_to,sysdate+1)            > sysdate
                AND Pvg.Job_Id                            =L_JOB_ID
                AND pg.business_group_id                  = cust.new_business_group_id;
                fnd_file.put_line(fnd_file.log,'Getting the Grade Count l_GRADE_ID :'||l_GRADE_ID);
                --1
                IF l_GRADE_ID = 1 THEN
                  SELECT pg.grade_id
                  INTO L_grade_id
                  FROM Per_Grades Pg,
                    Per_Valid_Grades Pvg,
                    XXHA_REC_EMP_INT_STG cust
                  WHERE Pg.Grade_Id                         =Pvg.Grade_Id
                  AND SUBSTR(Pg.Name,0,Instr(Pg.Name,'.')-1)= Cust.Req_Job_Grade--SUBSTR(Cust.Req_Job_Grade,0,Instr(Cust.Req_Job_Grade,'.')-1)
                  AND TRANSACTION_ID_STG                    =L_SEQ_NO
                  AND NVL(Pvg.date_to,sysdate+1)            > sysdate
                  AND Pvg.Job_Id                            =L_JOB_ID
                  AND pg.business_group_id                  = cust.new_business_group_id;
                  fnd_file.put_line(fnd_file.log,'2.Getting the Grade L_grade_id :'||L_grade_id);
                  UPDATE XXHA_REC_EMP_INT_STG
                  SET NEW_GRADE_ID         = L_grade_id
                  WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                  COMMIT;
                elsif l_GRADE_ID > 1 AND p_hr_emp_val_rec.REQ_PRI_LOC_CUST_CODE='CH HAE Signy' THEN
                  --3
                  BEGIN
                    SELECT Pg.Grade_Id
                    INTO L_grade_id
                    FROM Per_Grades Pg,
                      Per_Valid_Grades Pvg ,
                      XXHA_REC_EMP_INT_STG cust
                    WHERE Pg.Grade_Id=Pvg.Grade_Id
                    AND SUBSTR(Pg.Name,Instr(Pg.Name,'.') +1,Instr(Pg.Name,'.',1,2)-Instr(Pg.Name,'.')-1) LIKE 'CH%'
                    AND TRANSACTION_ID_STG         =L_SEQ_NO
                    AND Pvg.Job_Id                 =L_JOB_ID --265277
                    AND NVL(Pvg.date_to,sysdate+1) > sysdate
                    AND Pg.Name                    =cust.Req_Job_Grade
                    AND pg.business_group_id       = cust.new_business_group_id;
                    UPDATE XXHA_REC_EMP_INT_STG
                    SET NEW_GRADE_ID         = L_grade_id
                    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                    COMMIT;
                    fnd_file.put_line(fnd_file.log,'3.Getting the Grade L_grade_id :'||L_grade_id);
                  EXCEPTION
                  WHEN no_data_found THEN
                    g_error:=1;
                    Fnd_File.Put_Line(Fnd_File.Log,'Failed to get grade starting with CH'||Sqlerrm);
                  WHEN too_many_rows THEN
                    g_error:=1;
                    Fnd_File.Put_Line(Fnd_File.Log,'Too Many Rows While getting grade starting with CH'||Sqlerrm);
                  END;
                  --3
                elsif l_GRADE_ID > 1 AND p_hr_emp_val_rec.REQ_PRI_LOC_CUST_CODE='Signy, Switzerland' THEN
                  --4
                  BEGIN
                    SELECT Pg.Grade_Id
                    INTO L_grade_id
                    FROM Per_Grades Pg,
                      Per_Valid_Grades Pvg ,
                      XXHA_REC_EMP_INT_STG cust
                    WHERE Pg.Grade_Id=Pvg.Grade_Id
                    AND SUBSTR(Pg.Name,Instr(Pg.Name,'.') +1,Instr(Pg.Name,'.',1,2)-Instr(Pg.Name,'.')-1) LIKE 'CH%'
                    AND TRANSACTION_ID_STG         =L_SEQ_NO
                    AND Pvg.Job_Id                 =L_JOB_ID --265277
                    AND NVL(Pvg.date_to,sysdate+1) > sysdate
                    AND Pg.Name                    =cust.Req_Job_Grade
                    AND pg.business_group_id       = cust.new_business_group_id;
                    UPDATE XXHA_REC_EMP_INT_STG
                    SET NEW_GRADE_ID         = L_grade_id
                    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                    COMMIT;
                    fnd_file.put_line(fnd_file.log,'4.Getting the Grade L_grade_id :'||L_grade_id);
                  EXCEPTION
                  WHEN no_data_found THEN
                    g_error     :=1;
                    g_error_msg := SUBSTR(sqlerrm,1,100);
                    UPDATE XXHA_REC_EMP_INT_STG
                    SET STATUS_STG = 'VE',
                      ERROR_CODE   = ERROR_CODE
                      ||'GR101:',
                      ERROR_MSG = ERROR_MSG
                      ||'Failed to get grade starting with CH 2nd Condition'
                      ||g_error_msg
                      ||', '
                    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                    COMMIT;
                    Fnd_File.Put_Line(Fnd_File.Log,'Failed to get grade starting with CH 2nd Condition'||Sqlerrm);
                  WHEN too_many_rows THEN
                    g_error     :=1;
                    g_error_msg := SUBSTR(sqlerrm,1,100);
                    UPDATE XXHA_REC_EMP_INT_STG
                    SET STATUS_STG = 'VE',
                      ERROR_CODE   = ERROR_CODE
                      ||'GR102:',
                      ERROR_MSG = ERROR_MSG
                      ||'Too Many Rows While getting grade starting with CH 2nd Condition'
                      ||g_error_msg
                      ||', '
                    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                    COMMIT;
                    Fnd_File.Put_Line(Fnd_File.Log,'Too Many Rows While getting grade starting with CH 2nd Condition'||Sqlerrm);
                  END;
                ELSIF l_GRADE_ID > 1 THEN
                  BEGIN
                    SELECT pg.grade_id
                    INTO L_grade_id
                    FROM Per_Grades Pg,
                      Per_Valid_Grades Pvg,
                      XXHA_REC_EMP_INT_STG cust,
                      hr_lookups f
                    WHERE Pg.Grade_Id                         =Pvg.Grade_Id
                    AND SUBSTR(Pg.Name,0,Instr(Pg.Name,'.')-1)= Cust.Req_Job_Grade--SUBSTR(Cust.Req_Job_Grade,0,Instr(Cust.Req_Job_Grade,'.')-1)
                    AND TRANSACTION_ID_STG                    =L_SEQ_NO
                    AND NVL(Pvg.date_to,sysdate+1)            > sysdate
                    AND Pvg.Job_Id                            =L_JOB_ID
                    AND pg.business_group_id                  = cust.new_business_group_id
                    AND f.lookup_type                         = 'HAE_TALEO_SALARY_GRADE'
                    AND f.description                         = cust.REQ_PRI_LOC_CUST_CODE
                    AND pg.name LIKE Cust.Req_Job_Grade
                      ||'.'
                      ||f.meaning
                      ||'%';
                    fnd_file.put_line(fnd_file.log,'2.Getting the Grade L_grade_id :'||L_grade_id);
                    UPDATE XXHA_REC_EMP_INT_STG
                    SET NEW_GRADE_ID         = L_grade_id
                    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                    COMMIT;
                  EXCEPTION
                  WHEN no_data_found THEN
                    g_error:=1;
                    UPDATE XXHA_REC_EMP_INT_STG
                    SET STATUS_STG = 'VE',
                      ERROR_CODE   = ERROR_CODE
                      ||'GR107:',
                      ERROR_MSG = ERROR_MSG
                      ||'Grade validation failed with Lookup, '
                    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                    COMMIT;
                    Fnd_File.Put_Line(Fnd_File.Log,'No Grade with the combination including the location');
                  WHEN OTHERS THEN
                    g_error:=1;
                    UPDATE XXHA_REC_EMP_INT_STG
                    SET STATUS_STG = 'VE',
                      ERROR_CODE   = ERROR_CODE
                      ||'GR108:',
                      ERROR_MSG = ERROR_MSG
                      ||'Exception in Grade validation with Location, '
                    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                    COMMIT;
                    Fnd_File.Put_Line(Fnd_File.Log,'Exception in Grade validation with Location '||sqlerrm);
                  END;
                ELSE
                  g_error:=1;
                  UPDATE XXHA_REC_EMP_INT_STG
                  SET STATUS_STG = 'VE',
                    ERROR_CODE   = ERROR_CODE
                    ||'GR103:',
                    ERROR_MSG = ERROR_MSG
                    ||'Grade validation failed, '
                  WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                  COMMIT;
                  Fnd_File.Put_Line(Fnd_File.Log,'No Grade with the combination');
                END IF;
              EXCEPTION
              WHEN no_data_found THEN
                g_error     :=1;
                g_error_msg := SUBSTR(sqlerrm,1,100);
                UPDATE XXHA_REC_EMP_INT_STG
                SET STATUS_STG = 'VE',
                  ERROR_CODE   = ERROR_CODE
                  ||'GR104:',
                  ERROR_MSG = ERROR_MSG
                  ||'Failed to get grade starting with segment1'
                  ||g_error_msg
                  ||', '
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
                Fnd_File.Put_Line(Fnd_File.Log,'Failed to get grade starting with segment1'||Sqlerrm);
              WHEN too_many_rows THEN
                g_error     :=1;
                g_error_msg := SUBSTR(sqlerrm,1,100);
                UPDATE XXHA_REC_EMP_INT_STG
                SET STATUS_STG = 'VE',
                  ERROR_CODE   = ERROR_CODE
                  ||'GR105:',
                  ERROR_MSG = ERROR_MSG
                  ||'Too Many Rows While getting grade starting with Segment1'
                  ||g_error_msg
                  ||', '
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
                Fnd_File.Put_Line(Fnd_File.Log,'Too Many Rows While getting grade starting with Segment1'||Sqlerrm);
              END;
            END IF;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          g_error     :=1;
          g_error_msg := SUBSTR(sqlerrm,1,100);
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'GR106:',
            ERROR_MSG = ERROR_MSG
            ||'Exception occured in Grade Validation'
            ||g_error_msg
            ||', '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          Fnd_File.Put_Line(Fnd_File.Log,'Exception occured in Grade Validation'||Sqlerrm);
        END;   */  -- Vinay 
        /*#########################################################################
        ------------------------< Validation for payroll name in assignments >------
        ##########################################################################*/
        -- Code for getting the payroll Name
        BEGIN
          IF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS)='TEMPORARY WORKER' THEN
            l_PAYROLL_ID                           :=NULL;
          ELSE
            BEGIN
              --Modified it based on the count, if multiple rows then use below query
              /*  IF p_hr_emp_val_rec.payroll_schedule IS NULL THEN
              SELECT SUBSTR(Hl.Meaning,Instr(Hl.Meaning,':')+1)
              INTO L_Payroll_Name --Meaning
              FROM Hr_Lookups Hl,
              XXHA_REC_EMP_INT_STG CUST
              WHERE Lookup_Type                               ='XXHA_PAYROLL_LOC_CODE'
              AND SUBSTR(Hl.Meaning,0,Instr(Hl.Meaning,':')-1)=CUST.REQ_PRI_LOC_CUST_CODE --'Braintree, MA, US'
              --And description=cust.payroll_schedule
              AND TRANSACTION_ID_STG = L_SEQ_NO;
              fnd_file.put_line(fnd_file.log,'Getting the payroll Name:'||L_Payroll_Name);
              ELSE
              SELECT SUBSTR(Hl.Meaning,Instr(Hl.Meaning,':')+1)
              INTO L_Payroll_Name --Meaning
              FROM Hr_Lookups Hl,
              XXHA_REC_EMP_INT_STG CUST
              WHERE Lookup_Type                               ='XXHA_PAYROLL_LOC_CODE'
              AND SUBSTR(Hl.Meaning,0,Instr(Hl.Meaning,':')-1)=CUST.REQ_PRI_LOC_CUST_CODE --'Braintree, MA, US'
              AND description                                 =cust.payroll_schedule
              AND TRANSACTION_ID_STG                                      = L_SEQ_NO;
              fnd_file.put_line(fnd_file.log,'Getting the payroll Name:'||L_Payroll_Name);
              END IF;*/
              -- Code for getting pay roll id.
              SELECT COUNT(1)--SUBSTR(Hl.Meaning,Instr(Hl.Meaning,':')+1)
              INTO L_count   --Meaning
              FROM Hr_Lookups Hl,
                XXHA_REC_EMP_INT_STG CUST
              WHERE Lookup_Type                               ='XXHA_PAYROLL_LOC_CODE'
              AND SUBSTR(Hl.Meaning,0,Instr(Hl.Meaning,':')-1)=CUST.REQ_PRI_LOC_CUST_CODE --'Braintree, MA, US'
                --And description=cust.payroll_schedule
              AND TRANSACTION_ID_STG = L_SEQ_NO
              AND TRUNC(sysdate) BETWEEN NVL(Hl.start_date_active,TRUNC(sysdate)) AND NVL(Hl.end_date_active,'31-DEC-4712')
              AND Hl.enabled_flag ='Y';
              fnd_file.put_line(fnd_file.log,'Getting the payroll Name:'||L_Payroll_Name);
              IF L_count > 1 THEN
                SELECT SUBSTR(Hl.Meaning,Instr(Hl.Meaning,':')+1)
                INTO L_Payroll_Name --Meaning
                FROM Hr_Lookups Hl,
                  XXHA_REC_EMP_INT_STG CUST
                WHERE Lookup_Type                               ='XXHA_PAYROLL_LOC_CODE'
                AND SUBSTR(Hl.Meaning,0,Instr(Hl.Meaning,':')-1)=CUST.REQ_PRI_LOC_CUST_CODE --'Braintree, MA, US'
                AND description                                 =cust.payroll_schedule
                AND TRANSACTION_ID_STG                          = L_SEQ_NO
                AND TRUNC(sysdate) BETWEEN NVL(Hl.start_date_active,TRUNC(sysdate)) AND NVL(Hl.end_date_active,'31-DEC-4712')
                AND Hl.enabled_flag ='Y';
                fnd_file.put_line(fnd_file.log,'Getting the payroll Name:'||L_Payroll_Name);
              elsif L_count = 1 THEN
                SELECT SUBSTR(Hl.Meaning,Instr(Hl.Meaning,':')+1)
                INTO L_Payroll_Name --Meaning
                FROM Hr_Lookups Hl,
                  XXHA_REC_EMP_INT_STG CUST
                WHERE Lookup_Type                               ='XXHA_PAYROLL_LOC_CODE'
                AND SUBSTR(Hl.Meaning,0,Instr(Hl.Meaning,':')-1)=CUST.REQ_PRI_LOC_CUST_CODE --'Braintree, MA, US'
                  --And description=cust.payroll_schedule
                AND TRANSACTION_ID_STG = L_SEQ_NO
                AND TRUNC(sysdate) BETWEEN NVL(Hl.start_date_active,TRUNC(sysdate)) AND NVL(Hl.end_date_active,'31-DEC-4712')
                AND Hl.enabled_flag ='Y';
                fnd_file.put_line(fnd_file.log,'Getting the payroll Name:'||L_Payroll_Name);
              ELSE
                L_Payroll_Name:= NULL;
                UPDATE XXHA_REC_EMP_INT_STG
                SET STATUS_STG = 'VE',
                  ERROR_CODE   = ERROR_CODE
                  ||'PN100:',
                  ERROR_MSG = ERROR_MSG
                  ||'Payroll name not exists, '
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
                fnd_file.put_line(fnd_file.log,'Payroll Name:'||L_Payroll_Name||' does not exist in the Lookup');
              END IF;
              IF L_Payroll_Name IS NOT NULL THEN
                SELECT payroll_id
                INTO l_PAYROLL_ID
                FROM PAY_ALL_PAYROLLS_F
                WHERE BUSINESS_GROUP_ID = l_business_group_id
                AND PAYROLL_NAME        = L_Payroll_Name;
                FND_FILE.PUT_LINE(FND_FILE.LOG,'Payroll ID:'||l_PAYROLL_ID);
                UPDATE XXHA_REC_EMP_INT_STG
                SET NEW_PAYROLL_ID       = l_PAYROLL_ID
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              g_error     :=1;
              g_error_msg := sqlerrm;
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'VE127:',
                ERROR_MSG = ERROR_MSG
                ||'Exception Occured while getting payroll id '
                ||g_error_msg
                ||', '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
              fnd_file.put_line(fnd_file.log,'exception in pay roll id');
            END;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          Fnd_File.Put_Line(Fnd_File.Log,'Exception occured in Payroll Validation'||Sqlerrm);
        END;
        IF p_hr_emp_val_rec.C_COUNTRY_ABB IS NULL THEN
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'VE145:',
            ERROR_MSG = ERROR_MSG
            ||'Country Abbrevation is NULL, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END IF;
        IF p_hr_emp_val_rec.C_STATE_ABB IS NULL THEN
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'VE146:',
            ERROR_MSG = ERROR_MSG
            ||'State Abbrevation is NULL, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
        END IF;
        /*#########################################################################
        ------------------------< Validation for Pay basis in assignments >------
        ##########################################################################*/
        BEGIN
          IF upper(p_hr_emp_val_rec.EMPLOYEE_STATUS)='TEMPORARY WORKER' THEN
            l_PAY_BASIS_ID                         :=NULL;
          ELSE
            IF p_hr_emp_val_rec.C_COUNTRY_ABB IS NOT NULL THEN
              BEGIN
                --Consider Validation based on country as well, Need to add country column in the staging table and control file. then add the logic
                SELECT TERRITORY_SHORT_NAME
                INTO L_COUNTry
                FROM FND_TERRITORIES_VL
                WHERE upper(territory_code) = upper(p_hr_emp_val_rec.C_COUNTRY_ABB);
                fnd_file.put_line(fnd_file.log,'country :'||L_COUNTry);
                SELECT Description
                INTO L_Salary_Basis
                FROM Hr_Lookups Hl
                  --,XXHA_REC_EMP_INT_STG CUST
                WHERE Lookup_Type                                 ='XXHA_SALARY_BASIS_BG'
                AND SUBSTR(Hl.Meaning,0,Instr(Hl.Meaning,':')     -1) =upper(l_business_group)
                AND upper(SUBSTR(Hl.Meaning,Instr(Hl.Meaning,':') +1))=upper(L_COUNTry)
                AND TRUNC(sysdate) BETWEEN NVL(Hl.start_date_active,TRUNC(sysdate)) AND NVL(Hl.end_date_active,'31-DEC-4712')
                AND enabled_flag ='Y';
                fnd_file.put_line(fnd_file.log,'l_PAY_BASIS_ID :'||L_Salary_Basis);
                SELECT PAY_BASIS_ID
                INTO l_PAY_BASIS_ID
                FROM PER_PAY_BASES
                WHERE BUSINESS_GROUP_ID = l_business_group_id
                AND name                =L_Salary_Basis;
                fnd_file.put_line(fnd_file.log,'l_PAY_BASIS_ID :'||l_PAY_BASIS_ID);
                UPDATE XXHA_REC_EMP_INT_STG
                SET NEW_PAY_BASIS_ID     = l_PAY_BASIS_ID
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
                FND_FILE.PUT_LINE(FND_FILE.LOG,'Pay Basis ID:'||l_PAY_BASIS_ID);
              EXCEPTION
              WHEN OTHERS THEN
                g_error    :=1;
                g_error_msg:=sqlerrm;
                UPDATE XXHA_REC_EMP_INT_STG
                SET STATUS_STG = 'VE',
                  ERROR_CODE   = ERROR_CODE
                  ||'VE128:',
                  ERROR_MSG = ERROR_MSG
                  ||'Exception Occured while getting pay basis id, '
                  ||g_error_msg
                  ||', '
                WHERE TRANSACTION_ID_STG = L_SEQ_NO;
                COMMIT;
                fnd_file.put_line(fnd_file.log,'exception in pay roll id');
              END;
            END IF;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          Fnd_File.Put_Line(Fnd_File.Log,'Exception occured in Salary Basis Validation'||Sqlerrm);
        END;
        /*#########################################################################
        ------------------------< Validation for location in assignments >------
        ##########################################################################*/
        BEGIN
          SELECT Location_Id
          INTO L_LOCATION_ID
          FROM hr_locations_all
          WHERE upper(location_code)=upper(p_hr_emp_val_rec.REQ_PRI_LOC_CUST_CODE);
          --and business_group_id=l_business_group_id;
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_LOCATION_ID      = L_LOCATION_ID
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          FND_FILE.PUT_LINE(FND_FILE.LOG,'Location Id:'||L_LOCATION_ID);
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'VE130:',
            ERROR_MSG = ERROR_MSG
            ||'Location Not exist, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          L_LOCATION_ID := L_LOCATION_ID; --122418;
          fnd_file.put_line(fnd_file.log,'L_LOCATION_ID :'||L_LOCATION_ID);
          fnd_file.put_line(fnd_file.log,'exception in Location Id');
        END;
        /*#########################################################################
        ------------------------< Validation for Assignment Category >----------
        ##########################################################################*/
        BEGIN
          SELECT DISTINCT lookup_code
          INTO l_assg_cat
          FROM fnd_lookup_values_vl
          WHERE lookup_type = 'EMP_CAT'
          AND UPPER (meaning) LIKE UPPER (p_hr_emp_val_rec.EMPLOYEE_STATUS)
          AND p_hr_emp_val_rec.EMPLOYEE_STATUS IS NOT NULL
          AND enabled_flag                      = 'Y'
          AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
          AND NVL(end_date_active,NVL(p_hr_emp_val_rec.OFFER_ACTUAL_START_DATE,sysdate)) >= NVL(p_hr_emp_val_rec.OFFER_ACTUAL_START_DATE,sysdate);
          UPDATE XXHA_REC_EMP_INT_STG
          SET NEW_ASSG_CAT         = l_assg_cat
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'l_assg_cat :'||l_assg_cat);
        EXCEPTION
        WHEN OTHERS THEN
          g_error:=1;
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'VE116:',
            ERROR_MSG = ERROR_MSG
            ||'Assignment Category Not exist, '
          WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          COMMIT;
          fnd_file.put_line(fnd_file.log,'Assignment Not exist:' ||SQLERRM);
        END;
        --Validating Postal COde length for MY
        UPDATE XXHA_REC_EMP_INT_STG
        SET STATUS_STG = 'VE',
          ERROR_CODE   = ERROR_CODE
          ||'MY100:',
          ERROR_MSG = ERROR_MSG
          ||'MY - Zip code length not valid, '
        WHERE TRANSACTION_ID_STG           = L_SEQ_NO
        AND p_hr_emp_val_rec.C_COUNTRY_abb = 'MY'
        AND LENGTH(zip_code)              <> 5;
        COMMIT;
        --------- Get County for US
        IF p_hr_emp_val_rec.C_COUNTRY_ABB = 'US' THEN
          BEGIN
            SELECT COUNTY_NAME
            INTO L_COUNTY_NAME
            FROM PAY_US_NEW_CITIES_V
            WHERE upper(city_name) = upper(p_hr_emp_val_rec.city)
            AND STATE_ABBREV       = p_hr_emp_val_rec.c_state_abb
            AND p_hr_emp_val_rec.zip_code BETWEEN ZIP_START AND ZIP_END;
            UPDATE XXHA_REC_EMP_INT_STG
            SET NEW_COUNTY_NAME      = L_COUNTY_NAME
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          EXCEPTION
          WHEN OTHERS THEN
            /*g_error:=1;
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'AC100:',
            ERROR_MSG = ERROR_MSG
            ||'County not found, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;*/
            NULL;
          END;
        ELSIF p_hr_emp_val_rec.C_COUNTRY_ABB = 'CA' THEN
          BEGIN
            SELECT COUNT(1)
            INTO l_ca_province
            FROM PAY_US_NEW_CITIES_V c,
              hr_lookups l
            WHERE upper(c.city_name) = upper(p_hr_emp_val_rec.city)
            AND p_hr_emp_val_rec.zip_code BETWEEN c.ZIP_START AND c.ZIP_END
            AND c.state_NAME  = 'Canada'
            AND l.lookup_type = 'CA_PROVINCE'
            AND l.lookup_code = p_hr_emp_val_rec.c_state_abb
            AND l.meaning     = c.county_name;
            IF l_ca_province  = 0 THEN
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'PO100:',
                ERROR_MSG = ERROR_MSG
                ||'Province invalid, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
            END IF;
          EXCEPTION
          WHEN OTHERS THEN
            g_error:=1;
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'PO101:',
              ERROR_MSG = ERROR_MSG
              ||'Province not found, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            COMMIT;
          END;
        END IF;
        --------- Validation on State ABB
        l_count := 0;
        BEGIN
          IF p_hr_emp_val_rec.c_country_abb = 'CA' THEN
            SELECT COUNT(1)
            INTO L_count
            FROM FND_COMMON_LOOKUPS
            WHERE LOOKUP_TYPE LIKE 'CA_PROVINCE'
            AND lookup_code                     = p_hr_emp_val_rec.c_state_abb
            AND p_hr_emp_val_rec.c_state_abb   IS NOT NULL
            AND p_hr_emp_val_rec.c_country_abb IS NOT NULL
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
            AND enabled_flag ='Y';
            IF L_count       = 0 THEN
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'ST100:',
                ERROR_MSG = ERROR_MSG
                ||'State not valid, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
            END IF;
          ELSIF p_hr_emp_val_rec.c_country_abb IN ('MY','MX') THEN
            SELECT COUNT(1)
            INTO L_count
            FROM FND_COMMON_LOOKUPS
            WHERE LOOKUP_TYPE LIKE p_hr_emp_val_rec.c_country_abb
              ||'_STATE'
            AND description                     = p_hr_emp_val_rec.c_state_abb
            AND p_hr_emp_val_rec.c_state_abb   IS NOT NULL
            AND p_hr_emp_val_rec.c_country_abb IS NOT NULL
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
            AND enabled_flag ='Y';
            IF L_count       = 0 THEN
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'ST101:',
                ERROR_MSG = ERROR_MSG
                ||'State not valid, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
            END IF;
          ELSE
            SELECT COUNT(1)
            INTO L_count
            FROM FND_COMMON_LOOKUPS
            WHERE LOOKUP_TYPE LIKE p_hr_emp_val_rec.c_country_abb
              ||'_STATE'
            AND lookup_code                     = p_hr_emp_val_rec.c_state_abb
            AND p_hr_emp_val_rec.c_state_abb   IS NOT NULL
            AND p_hr_emp_val_rec.c_country_abb IS NOT NULL
            AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712')
            AND enabled_flag ='Y';
            IF L_count       = 0 THEN
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'ST102:',
                ERROR_MSG = ERROR_MSG
                ||'State not valid, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
              COMMIT;
            END IF;
          END IF;
        END;
        -- Validate Recruitment Source Type
        l_count := 0;
        BEGIN
          IF p_hr_emp_val_rec.rec_source_type IS NOT NULL THEN
            SELECT COUNT(1)
            INTO l_count
            FROM FND_FLEX_VALUE_SETS ffvs,
              fnd_flex_values ffv
            WHERE ffvs.flex_value_set_name = 'HAE_Recruiting_Source_Types'
            AND ffvs.flex_value_set_id     = ffv.flex_value_set_id
            AND ffv.flex_value             = p_hr_emp_val_rec.rec_source_type
            AND TRUNC(sysdate) BETWEEN NVL(ffv.start_date_active,TRUNC(sysdate)) AND NVL(ffv.end_date_active,'31-DEC-4712')
            AND ffv.enabled_flag ='Y';
            IF l_count           = 0 THEN
              UPDATE XXHA_REC_EMP_INT_STG
              SET STATUS_STG = 'VE',
                ERROR_CODE   = ERROR_CODE
                ||'RE100:',
                ERROR_MSG = ERROR_MSG
                ||'Recruitment Source Type is not valid, '
              WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            END IF;
          END IF;
        END;
        -- Validate Shift value for US and GB
        IF l_business_group IN ('BG_US','BG_GB') THEN
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG = 'VE',
            ERROR_CODE   = ERROR_CODE
            ||'SH100:',
            ERROR_MSG = ERROR_MSG
            ||'Shift is NULL, '
          WHERE TRANSACTION_ID_STG                = L_SEQ_NO
          AND p_hr_emp_val_rec.Requisition_UDF_6 IS NULL;
        END IF;
        IF l_business_group = 'BG_US' THEN
          SELECT COUNT(1)
          INTO l_count
          FROM FND_FLEX_VALUE_SETS ffvs,
            fnd_flex_values ffv
          WHERE ffvs.flex_value_set_name = 'HAE_HR_SHIFT_US'
          AND ffvs.flex_value_set_id     = ffv.flex_value_set_id
          AND ffv.flex_value             = p_hr_emp_val_rec.Requisition_UDF_6
          AND TRUNC(sysdate) BETWEEN NVL(ffv.start_date_active,TRUNC(sysdate)) AND NVL(ffv.end_date_active,'31-DEC-4712')
          AND ffv.enabled_flag ='Y';
          IF l_count           = 0 THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'SH101:',
              ERROR_MSG = ERROR_MSG
              ||'Shift value is invalid, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          END IF;
        END IF;
        IF l_business_group = 'BG_GB' THEN
          SELECT COUNT(1)
          INTO l_count
          FROM FND_FLEX_VALUE_SETS ffvs,
            fnd_flex_values ffv
          WHERE ffvs.flex_value_set_name = 'HAE_HR_SHIFT_GB'
          AND ffvs.flex_value_set_id     = ffv.flex_value_set_id
          AND ffv.flex_value             = p_hr_emp_val_rec.Requisition_UDF_6
          AND TRUNC(sysdate) BETWEEN NVL(ffv.start_date_active,TRUNC(sysdate)) AND NVL(ffv.end_date_active,'31-DEC-4712')
          AND ffv.enabled_flag ='Y';
          IF l_count           = 0 THEN
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'VE',
              ERROR_CODE   = ERROR_CODE
              ||'SH102:',
              ERROR_MSG = ERROR_MSG
              ||'Shift value is invalid, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          END IF;
        END IF;
        UPDATE XXHA_REC_EMP_INT_STG
        SET STATUS_STG = 'VE',
          ERROR_CODE   = ERROR_CODE
          ||'MY102:',
          ERROR_MSG = ERROR_MSG
          ||'MY Emp Class is NULL, '
        WHERE my_employee_class                    IS NULL
        AND TRANSACTION_ID_STG                      = L_SEQ_NO
        AND c_country_abb                           = 'MY'
        AND upper(p_hr_emp_val_rec.EMPLOYEE_STATUS)<>'TEMPORARY WORKER';
        UPDATE XXHA_REC_EMP_INT_STG
        SET STATUS_STG           = 'V'
        WHERE TRANSACTION_ID_STG = L_SEQ_NO
        AND STATUS_STG           = 'N';
        COMMIT;
      ELSE
        fnd_file.put_line(fnd_file.log,'Business Group not enabled in the Lookup:'||SQLERRM);
        UPDATE XXHA_REC_EMP_INT_STG
        SET STATUS_STG = 'VE',
          ERROR_CODE   = ERROR_CODE
          ||'VE500:',
          ERROR_MSG = ERROR_MSG
          ||'Business Group not enabled in the Lookup, '
        WHERE TRANSACTION_ID_STG = L_SEQ_NO;
        COMMIT;
      END IF;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception occured in Validating Business Group:'||SQLERRM);
  END;
END Validate_employee;
--##########################################################################################################################
------------------< Procedure to update the date of birth,After rehiring the temporary employee>------------------------
--##########################################################################################################################
PROCEDURE Update_TEMP_EMP_DOB(
    ip_emp_number     IN PER_ALL_PEOPLE_F.EMPLOYEE_NUMBER%TYPE,
    ip_person_Id      IN per_people_f.person_id%TYPE,
    ip_assignment_id  IN per_assignments_f.assignment_id%TYPE,
    ip_business_group IN per_business_groups.name%TYPE,
    --,ip_Object_Version_Num In PER_ALL_PEOPLE_F.OBJECT_VERSION_NUMBER%TYPE
    IP_OFFER_ACTUAL_START_DATE IN DATE )
IS
  L_OBJECT_NUMBER PER_ALL_PEOPLE_F.OBJECT_VERSION_NUMBER%TYPE; --:=ip_Object_Version_Num;
  lc_dt_ud_mode VARCHAR2(100)                             := NULL;
  lc_employee_number PER_ALL_PEOPLE_F.EMPLOYEE_NUMBER%TYPE:=ip_emp_number; --p_hr_emp_rec.New_EMPLOYEE_NUMBER;
  -- Out Variables for Find Date Track Mode API
  -- ----------------------------------------------------------------
  lb_correction           BOOLEAN;
  lb_update               BOOLEAN;
  lb_update_override      BOOLEAN;
  lb_update_change_insert BOOLEAN;
  -- Out Variables for Update Employee API
  -- -----------------------------------------------------------
  ld_effective_start_date DATE;
  ld_effective_end_date   DATE;
  lc_full_name PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
  ln_comment_id PER_ALL_PEOPLE_F.COMMENT_ID%TYPE;
  lb_name_combination_warning BOOLEAN;
  lb_assign_payroll_warning   BOOLEAN;
  lb_orig_hire_warning        BOOLEAN;
  l_context PER_ALL_PEOPLE_F.ATTRIBUTE_CATEGORY%TYPE;
BEGIN
  --Code to get object version number
  BEGIN
    SELECT MAX (object_version_number)
    INTO L_OBJECT_NUMBER
    FROM per_all_people_f
    WHERE 1       = 1
    AND person_id =ip_person_Id --p_hr_emp_rec.New_PERSON_ID
    AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE)) ;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception while getting Object Version Number in Update_TEMP_EMP_DOB:'||L_OBJECT_NUMBER);
  END;
  fnd_file.put_line(fnd_file.log,'Object Version Number in Update_TEMP_EMP_DOB:'||L_OBJECT_NUMBER);
  fnd_file.put_line(fnd_file.log,'EMPLOYEE NUMBER: '||ip_emp_number); --p_hr_emp_rec.New_EMPLOYEE_NUMBER
  fnd_file.put_line(fnd_file.log,'EMPLOYEE NUMBER: '||lc_employee_number);
  fnd_file.put_line(fnd_file.log,'Assignment_Id '||ip_assignment_id); --p_hr_emp_rec.New_Assignment_Id
  -- Find Date Track Mode
  -- --------------------------------
  BEGIN
    dt_api.find_dt_upd_modes ( p_effective_date =>IP_OFFER_ACTUAL_START_DATE,                                                           --to_date(sysdate),  --kmd
    p_base_table_name => 'PER_ALL_ASSIGNMENTS_F', p_base_key_column => 'ASSIGNMENT_ID', p_base_key_value =>to_number(ip_assignment_id), --ln_assignment_id, --p_hr_emp_rec.New_Assignment_Id
    -- Output data elements
    -- -------------------------------
    p_correction => lb_correction, p_update => lb_update, p_update_override => lb_update_override, p_update_change_insert => lb_update_change_insert );
    fnd_file.put_line(fnd_file.log,'Assignment_Id in dt_api: '||ip_assignment_id); --p_hr_emp_rec.New_Assignment_Id);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception of Date Track Mode');
  END;
  IF ( lb_update_override = TRUE OR lb_update_change_insert = TRUE ) THEN
    -- UPDATE_OVERRIDE
    -- ---------------------------------
    lc_dt_ud_mode := 'UPDATE_OVERRIDE';
  END IF;
  IF ( lb_correction = TRUE ) THEN
    -- CORRECTION
    -- ----------------------
    lc_dt_ud_mode := 'CORRECTION';
  END IF;
  IF ( lb_update = TRUE ) THEN
    -- UPDATE
    -- --------------
    lc_dt_ud_mode := 'UPDATE';
  END IF;
  fnd_file.put_line(fnd_file.log, 'Person_Id before update api: '||ip_person_Id); --p_hr_emp_rec.New_PERSON_ID);
  -- Update Employee API
  -- ---------------------------------
  --if p_hr_emp_rec.New_business_group='BG_US' then
  IF ip_business_group ='BG_US' THEN
    fnd_file.put_line(fnd_file.log,'Business_group in Update DOB: '|| ip_business_group);
    hr_person_api.update_us_person (
    --p_effective_date =>to_date(sysdate), --to_date('10-JUL-2015'),--
    p_effective_date =>IP_OFFER_ACTUAL_START_DATE,                       --to_date('21-JUL-2015'), -- kmd
    p_datetrack_update_mode =>lc_dt_ud_mode, p_person_id =>ip_person_Id, --p_hr_emp_rec.New_PERSON_ID,
    p_date_of_birth => to_date('01-JAN-1990'),                           --P_HR_EMP_REC.DATEOFBIRTH,
    -- Output Data Elements
    -- ----------------------------------
    p_employee_number => lc_employee_number, p_object_version_number =>L_OBJECT_NUMBER, --ln_object_version_number,
    p_effective_start_date => ld_effective_start_date, p_effective_end_date => ld_effective_end_date, p_full_name => lc_full_name, p_comment_id => ln_comment_id, p_name_combination_warning => lb_name_combination_warning, p_assign_payroll_warning => lb_assign_payroll_warning, p_orig_hire_warning => lb_orig_hire_warning );
    --COMMIT; --Commented on Aug 19
    fnd_file.put_line(fnd_file.log,'L_OBJECT_NUMBER In Update employee: '||L_OBJECT_NUMBER);
    fnd_file.put_line(fnd_file.log,'lc_employee_number In Update employee: '||lc_employee_number);
  ELSE
    fnd_file.put_line(fnd_file.log,'Update person for MY and other');
    hr_person_api.update_person ( p_effective_date => IP_OFFER_ACTUAL_START_DATE,--to_date(sysdate), --kmd
    p_datetrack_update_mode =>lc_dt_ud_mode, p_person_id =>ip_person_Id,         --p_hr_emp_rec.New_PERSON_ID,   --g_person_id,--
    p_date_of_birth =>to_date('01-JAN-1990'),
    -- Output Data Elements
    -- ----------------------------------
    p_employee_number => lc_employee_number, p_object_version_number =>L_OBJECT_NUMBER, --ln_object_version_number,
    p_effective_start_date => ld_effective_start_date, p_effective_end_date => ld_effective_end_date, p_full_name => lc_full_name, p_comment_id => ln_comment_id, p_name_combination_warning => lb_name_combination_warning, p_assign_payroll_warning => lb_assign_payroll_warning, p_orig_hire_warning => lb_orig_hire_warning );
    --commit;  --commented on July-6th
    --G_Employee_number:=lc_employee_number; -- Can update employee number in staging table
    fnd_file.put_line(fnd_file.log,'Employee_number_after_update:'||lc_employee_number);
    fnd_file.put_line(fnd_file.log,'L_OBJECT_NUMBER In Update employee2: '||L_OBJECT_NUMBER);
  END IF;
  --P_ERR_MSG:=1;
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  fnd_file.put_line(fnd_file.log,'Error occured in PROCEDURE Update_TEMP_EMP_DOB'||SQLERRM);
  fnd_file.put_line(fnd_file.output,'DOB Update to Default is failed: '||SQLERRM);
  --P_ERR_MSG:=2;
END Update_TEMP_EMP_DOB;
-----------------------End of Update employee for DOB----------------------------
/*#########################################################################
------------------------< Update_Fut_EMP_SYSDATE >-------------------------------
##########################################################################*/
-----------Updating Future Employee Sysdate--------------------------
PROCEDURE Update_Fut_EMP_SYSDATE(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  L_Future_Count      NUMBER;
  l_person_start_date DATE;
  L_PERSON_ID per_people_f.person_id%TYPE;
  L_ASSIGNMENT_ID per_assignments_f.assignment_id%TYPE;
  l_error_msg VARCHAR2(4000);
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
BEGIN
  l_seq_no := p_hr_emp_rec.transaction_id_stg;
  fnd_file.put_line(fnd_file.log,'In future employee condition');
  SELECT COUNT(*),
    Papf.Effective_Start_Date,
    papf.person_id
  INTO l_Future_Count,
    l_person_start_date,
    L_PERSON_ID
  FROM Per_All_People_F Papf,
    Hr.Per_Person_Type_Usages_F Pptu,
    Hr.Per_Person_Types Ppt
  WHERE 1                    =1
  AND Papf.Person_Id         = Pptu.Person_Id
  AND pptu.person_type_id    = ppt.person_type_id
  AND Papf.Business_Group_Id = p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
  AND (Ppt.User_Person_Type LIKE 'Employee%'
  OR Ppt.User_Person_Type LIKE 'HAE Contingent Worker')
  AND Pptu.Effective_Start_Date > Sysdate
  AND Papf.Effective_Start_Date > Sysdate
    --AND Papf.Attribute15          =P_Hr_Emp_Rec.Candidate_Number --'211931';
  AND papf.first_name = p_hr_emp_rec.first_name
  AND papf.last_name  = p_hr_emp_rec.last_name
  AND PPT.active_flag ='Y' --July-8th
  GROUP BY Papf.Effective_Start_Date,
    papf.person_id;
  fnd_file.put_line(fnd_file.log,'Future Employees Count:'||l_Future_Count);
  SELECT assignment_id
  INTO L_ASSIGNMENT_ID
  FROM per_all_assignments_f
  WHERE person_id=L_PERSON_ID;
  fnd_file.put_line(fnd_file.log,'Assignemnt Id in Future Employees:'||L_ASSIGNMENT_ID);
  IF l_Future_Count > 0 AND p_hr_emp_rec.OFFER_ACTUAL_START_DATE <> l_person_start_date THEN
    -- Need to use api to update the start date from  the file
    --------------Updating the start date for the future employee
    BEGIN
      fnd_file.put_line(fnd_file.log,'Begin');
      HR_CHANGE_START_DATE_API.UPDATE_START_DATE (P_VALIDATE => false , P_Person_Id => L_PERSON_ID , P_Old_Start_Date =>To_Date(l_person_start_date,'dd-mon-yy') --To_Date('24-MAY-15','dd-mon-yy')
      ,P_NEW_START_DATE =>To_Date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE,'dd-mon-yy')                                                                              --To_Date('21-MAY-15','dd-mon-yy')
      ,P_UPDATE_TYPE => 'E' , P_APPLICANT_NUMBER => NULL , P_WARN_EE => l_error_msg );
      P_ERR_MSG:=NULL; --July-8th
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'after update start date api');
      fnd_file.put_line(fnd_file.log,'error:' || l_error_msg);
      UPDATE per_all_people_f
      SET Attribute15 =P_Hr_Emp_Rec.Candidate_Number,
        known_as      = P_HR_EMP_REC.CANDIDATE_UDF_2 -- dk 0813 recheck
      WHERE person_id = L_PERSON_ID;
      --COMMIT;
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_PERSON_ID        = L_PERSON_ID,
        NEW_ASSIGNMENT_ID      = L_ASSIGNMENT_ID
      WHERE TRANSACTION_ID_STG = l_seq_no;
      --COMMIT;
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'In exception while updating the sysdate for future employee:'||SQLERRM);
      fnd_file.put_line(fnd_file.output,'Updating Future Employee got failed:'||SQLERRM);
      P_ERR_MSG:='Future Employee Update - Failed';
    END;
  ELSE
    Fnd_File.Put_Line(Fnd_File.Log,'start data in file and start date of the future employee is equal');
  END IF;
EXCEPTION
WHEN OTHERS THEN
  Fnd_File.Put_Line(Fnd_File.Log,'Exception in future employee: '||SQLERRM);
  Fnd_File.Put_Line(Fnd_File.output,'Exception in future employee update: '||SQLERRM);
  P_ERR_MSG:='Future Employee Update - Failed';
END Update_Fut_EMP_SYSDATE;
/*#########################################################################
------------------------< Rehire_Ex_Employee >-------------------------------
##########################################################################*/
-----------Added Ex employee--------------------------
PROCEDURE REHIRE_EX_EMPLOYEE(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  l_object_ver_number per_people_f.object_version_number%TYPE;
  L_PERSON_ID per_people_f.person_id%TYPE;
  L_ASSIGNMENT_ID per_assignments_f.assignment_id%TYPE;
  l_asg_ovn per_people_f.object_version_number%TYPE;
  l_per_effective_start_date per_people_v.effective_start_date%TYPE;
  l_per_effective_end_date per_people_v.effective_end_date%TYPE;
  l_assignment_sequence per_people_assignments_view.assignment_sequence%TYPE;
  l_assignment_number per_people_assignments_view.assignment_number%TYPE;
  l_assign_payroll_warning BOOLEAN;
  L_ex_count               NUMBER;
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  ln_object_version PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_object_version_number PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_address_id PER_ADDRESSES.ADDRESS_ID%TYPE;
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  BEGIN
    fnd_file.put_line(fnd_file.log,'P_Hr_Emp_Rec.Candidate_Number:'||P_Hr_Emp_Rec.Candidate_Number);
    SELECT COUNT(*),
      MAX(papf.object_version_number)--COUNT(*)
      ,
      papf.person_id
    INTO L_ex_count,
      L_OBJECT_VER_NUMBER ,
      L_PERSON_ID
    FROM Per_All_People_F Papf,
      Hr.Per_Person_Type_Usages_F Pptu,
      Hr.Per_Person_Types Ppt
    WHERE 1                    =1
    AND Papf.Person_Id         = Pptu.Person_Id
    AND pptu.person_type_id    = ppt.person_type_id
    AND Papf.Business_Group_Id = p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
    AND Ppt.User_Person_Type LIKE 'Ex-employee%'
    AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
    AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
      --AND Papf.Attribute15=P_Hr_Emp_Rec.Candidate_Number --'100800';
    AND papf.first_name = p_hr_emp_rec.first_name
    AND papf.last_name  = p_hr_emp_rec.last_name
    AND ppt.active_flag ='Y' --July-8th
    GROUP BY papf.person_id;
  EXCEPTION
  WHEN no_data_found THEN
    L_OBJECT_VER_NUMBER := 0;
  END;
  fnd_file.put_line(fnd_file.log,'l_ex_count :'||L_ex_count);
  fnd_file.put_line(fnd_file.log,'L_OBJECT_VER_NUMBER :'||L_OBJECT_VER_NUMBER);
  fnd_file.put_line(fnd_file.log,'L_PERSON_ID :'||L_PERSON_ID);
  L_ASG_OVN := 0;
  --IF L_OBJECT_VER_NUMBER > 0  then --AND EMP_COUNT = 0 THEN --present he is not an employee, previously he was an employee
  IF L_ex_count =1 THEN
    fnd_file.put_line(fnd_file.log,'calling Re_hire_ex_employee');
    hr_employee_api.Re_hire_ex_employee(p_hire_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_person_id => L_PERSON_ID, --46388,--
    p_rehire_reason => NULL,
    ----out variables
    P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_PER_OBJECT_VERSION_NUMBER => L_OBJECT_VER_NUMBER, P_ASG_OBJECT_VERSION_NUMBER => L_ASG_OVN, P_PER_EFFECTIVE_START_DATE => L_PER_EFFECTIVE_START_DATE, P_PER_EFFECTIVE_END_DATE => L_PER_EFFECTIVE_END_DATE, P_ASSIGNMENT_SEQUENCE => L_ASSIGNMENT_SEQUENCE, P_ASSIGNMENT_NUMBER => L_ASSIGNMENT_NUMBER, P_ASSIGN_PAYROLL_WARNING => L_ASSIGN_PAYROLL_WARNING);
    --commit;
    -- Added code to modify the end date the existing address and update the address for rehire employee
    BEGIN
      SELECT MAX(object_version_number),
        address_id
      INTO ln_object_version,
        ln_address_id
      FROM per_addresses
      WHERE person_id=L_PERSON_ID
      GROUP BY address_id;
      ln_object_version_number     :=ln_object_version;
      IF P_HR_EMP_REC.C_COUNTRY_ABB = 'US' THEN
        hr_person_address_api.update_us_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the US address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'GB' THEN
        hr_person_address_api.update_gb_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the GB address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'AT' THEN
        hr_person_address_api.update_AT_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the AT address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'AU' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the AU address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'DK' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the DK address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'DE' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the DE address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'IT' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the IT address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MX' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the MX address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MY' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the MY address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'BE' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the BE address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'HK' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the HK address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'NL' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the NL address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'SG' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the SE address');
      ELSE
        hr_person_address_api.update_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating other business group address');
        --COMMIT;
      END IF;
      fnd_file.put_line(fnd_file.log,'Success while end dating the address');
    EXCEPTION
    WHEN OTHERS THEN
      -- ROLLBACK;
      g_error:=1;
      fnd_file.put_line(fnd_file.log,'In exception while end dating the address'||sqlerrm);
      P_ERR_MSG:=sqlerrm; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET STATUS_STG = 'VE',
        ERROR_CODE   = ERROR_CODE
        ||'VE137:',
        ERROR_MSG = ERROR_MSG
        ||'Error in Ex-Employee Rehire End date address, ' ,
        LOAD_MSG = 'Rehire Ex Employee - Error '
        ||P_ERR_MSG
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
    END;
    ----------------End Of Changes----------------
    P_ERR_MSG:=NULL; --July-8th
    --COMMIT;
    UPDATE per_all_people_f
    SET Attribute15 =P_Hr_Emp_Rec.Candidate_Number ,
      known_as      = P_HR_EMP_REC.CANDIDATE_UDF_2, -- dk 0813 recheck
      attribute13   = 'YES',
      ATTRIBUTE12 = null, --1007
      attribute14 = null --1007
    WHERE person_id =L_PERSON_ID;
    --COMMIT;
    --G_PERSON_ID := NEW_PERSON_ID;
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_PERSON_ID        = L_PERSON_ID,
      NEW_ASSIGNMENT_ID      = L_ASSIGNMENT_ID
    WHERE TRANSACTION_ID_STG = l_seq_no;
    --COMMIT;
    --G_ASSIGNMENT_ID := L_ASSIGNMENT_ID;
    fnd_file.put_line(fnd_file.log,'Person id after rehire:'||L_person_id);
    fnd_file.put_line(fnd_file.log,'Assignment Id after Rehire:'||L_ASSIGNMENT_ID);
  END IF;
EXCEPTION
WHEN OTHERS THEN
  g_error:=1;
  fnd_file.put_line(fnd_file.log,'Exception in Ex-Employee Rehire :'||sqlerrm);
  P_ERR_MSG:=sqlerrm; --July-8th
  UPDATE XXHA_REC_EMP_INT_STG
  SET STATUS_STG = 'VE',
    ERROR_CODE   = ERROR_CODE
    ||'VE136:',
    ERROR_MSG = ERROR_MSG
    ||'Error in Ex-Employee Rehire, ' ,
    LOAD_MSG = 'Rehire Ex Employee - Error '
    ||P_ERR_MSG
  WHERE TRANSACTION_ID_STG = l_SEQ_NO;
  --COMMIT;
END REHIRE_EX_EMPLOYEE;
/*#########################################################################
------------------------< REHIRE_EXEMP_CONTINGENT >-------------------------------
##########################################################################*/
PROCEDURE REHIRE_EXEMP_CONTINGENT(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  l_object_ver_number per_people_f.object_version_number%TYPE;
  L_PERSON_ID per_people_f.person_id%TYPE;
  L_ASSIGNMENT_ID per_assignments_f.assignment_id%TYPE;
  l_asg_ovn per_people_f.object_version_number%TYPE;
  l_per_effective_start_date per_people_v.effective_start_date%TYPE;
  l_per_effective_end_date per_people_v.effective_end_date%TYPE;
  l_assignment_sequence per_people_assignments_view.assignment_sequence%TYPE;
  l_assignment_number per_people_assignments_view.assignment_number%TYPE;
  l_assign_payroll_warning BOOLEAN;
  L_ex_count               NUMBER;
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  ln_object_version PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_object_version_number PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_address_id PER_ADDRESSES.ADDRESS_ID%TYPE;
  L_Person_Type_id Per_Person_Types.person_type_id%type;
  L_ERR_MSG VARCHAR2(4000);
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  BEGIN
    fnd_file.put_line(fnd_file.log,'Candidate_Number in rehire contingent worker:'||P_Hr_Emp_Rec.Candidate_Number);
    fnd_file.put_line(fnd_file.log,'NEW_BUSINESS_GROUP_ID in Rehire contingent worker:'||p_hr_emp_rec.NEW_BUSINESS_GROUP_ID);
    SELECT COUNT(*),
      MAX(papf.object_version_number),
      papf.person_id
    INTO L_ex_count,
      L_OBJECT_VER_NUMBER ,
      L_PERSON_ID
    FROM Per_All_People_F Papf,
      Hr.Per_Person_Type_Usages_F Pptu,
      Hr.Per_Person_Types Ppt,
      per_all_assignments_f paaf --Added
    WHERE 1                    =1
    AND Papf.Person_Id         = Pptu.Person_Id
    AND pptu.person_type_id    = ppt.person_type_id
    AND Papf.Business_Group_Id = p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
    AND Ppt.User_Person_Type LIKE 'Ex-employee%'
    AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
    AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
      --AND Papf.Attribute15=P_Hr_Emp_Rec.Candidate_Number
      --Added
    AND Upper(Papf.First_Name)   = Upper(P_Hr_Emp_Rec.First_Name)
    AND upper(papf.last_name)    = upper(P_Hr_Emp_Rec.LAST_NAME)
    AND paaf.person_id           =papf.person_id
    AND paaf.employment_category = P_Hr_Emp_Rec.NEW_ASSG_CAT
      --Added
    AND ppt.active_flag ='Y'
    GROUP BY papf.person_id;
  EXCEPTION
  WHEN no_data_found THEN
    L_OBJECT_VER_NUMBER := 0;
  END;
  SELECT person_type_id
  INTO L_person_type_id
  FROM Per_Person_Types
  WHERE user_person_type LIKE 'HAE Contingent Worker'
  AND business_group_id=p_hr_emp_rec.NEW_BUSINESS_GROUP_ID;
  fnd_file.put_line(fnd_file.log,'l_ex_count :'||L_ex_count);
  fnd_file.put_line(fnd_file.log,'L_OBJECT_VER_NUMBER :'||L_OBJECT_VER_NUMBER);
  fnd_file.put_line(fnd_file.log,'L_PERSON_ID :'||L_PERSON_ID);
  fnd_file.put_line(fnd_file.log,'L_person_type_id :'||L_person_type_id);
  L_ASG_OVN := 0;
  --IF L_OBJECT_VER_NUMBER > 0  then --AND EMP_COUNT = 0 THEN --present he is not an employee, previously he was an employee
  IF L_ex_count =1 THEN
    fnd_file.put_line(fnd_file.log,'calling ex_employee to Rehire Contingent Worker');
    hr_employee_api.Re_hire_ex_employee(p_hire_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_person_id => L_PERSON_ID, --46388,--
    p_rehire_reason => NULL, p_person_type_id => L_person_type_id,                                                                --'11143',
    ----out variables
    P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_PER_OBJECT_VERSION_NUMBER => L_OBJECT_VER_NUMBER, P_ASG_OBJECT_VERSION_NUMBER => L_ASG_OVN, P_PER_EFFECTIVE_START_DATE => L_PER_EFFECTIVE_START_DATE, P_PER_EFFECTIVE_END_DATE => L_PER_EFFECTIVE_END_DATE, P_ASSIGNMENT_SEQUENCE => L_ASSIGNMENT_SEQUENCE, P_ASSIGNMENT_NUMBER => L_ASSIGNMENT_NUMBER, P_ASSIGN_PAYROLL_WARNING => L_ASSIGN_PAYROLL_WARNING);
    --commit;
    P_ERR_MSG:=NULL; --July-8th
    UPDATE per_all_people_f
    SET Attribute15 =P_Hr_Emp_Rec.Candidate_Number ,
      known_as      = P_HR_EMP_REC.CANDIDATE_UDF_2, -- dk 0813 recheck
      ATTRIBUTE12   = TO_CHAR(sysdate+180,'DD-MON-YYYY'),
      ATTRIBUTE13   = NULL,--'YES',                    --Haemo Email Required, -- 1007
      ATTRIBUTE14   = P_Hr_Emp_Rec.offer_udf_3, --Vendor
      ATTRIBUTE17   = p_hr_emp_rec.email        --Non Hameo Email Address 08/20
    WHERE person_id =L_PERSON_ID;
    --COMMIT;
    --G_PERSON_ID := NEW_PERSON_ID;
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_PERSON_ID        = L_PERSON_ID,
      NEW_ASSIGNMENT_ID      = L_ASSIGNMENT_ID
    WHERE TRANSACTION_ID_STG = l_seq_no;
    fnd_file.put_line(fnd_file.log,'Person id after rehire:'||L_person_id);
    fnd_file.put_line(fnd_file.log,'Assignment Id after Rehire:'||L_ASSIGNMENT_ID);
    Create_Contingent_asgnmnt (p_hr_emp_rec => P_Hr_Emp_Rec, p_api_mode => 'CORRECTION',p_err_msg => L_ERR_MSG);
    fnd_file.put_line(fnd_file.log,'After Create_Contingent_asgnmnt Procedure:'||L_ASSIGNMENT_ID);
  END IF;
EXCEPTION
WHEN OTHERS THEN
  g_error:=1;
  fnd_file.put_line(fnd_file.log,'Exception in Contingent Worker Rehire :'||sqlerrm);
  P_ERR_MSG:=sqlerrm; --July-8th
  UPDATE XXHA_REC_EMP_INT_STG
  SET STATUS_STG = 'VE',
    ERROR_CODE   = ERROR_CODE
    ||'VE140:',
    ERROR_MSG = ERROR_MSG
    ||'Error in Rehiring Contingent Worker, ' ,
    LOAD_MSG = 'Rehire Ex Employee as Contingent - Error '
    ||P_ERR_MSG
  WHERE TRANSACTION_ID_STG = l_SEQ_NO;
  --COMMIT;
END REHIRE_EXEMP_CONTINGENT;
/*#########################################################################
------------------------< CREATE_IS_REHIRE >-------------------------------
##########################################################################*/
---------------Added Is this a candidate rehire --------------------
PROCEDURE CREATE_IS_REHIRE(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  L_PERSON_ID per_people_f.person_id%TYPE;
  l_object_ver_number per_people_f.object_version_number%TYPE;
  L_ASSIGNMENT_ID per_assignments_f.assignment_id%TYPE;
  l_asg_ovn per_people_f.object_version_number%TYPE;
  l_per_effective_start_date per_people_v.effective_start_date%TYPE;
  l_per_effective_end_date per_people_v.effective_end_date%TYPE;
  l_assignment_sequence per_people_assignments_view.assignment_sequence%TYPE;
  l_assignment_number per_people_assignments_view.assignment_number%TYPE;
  l_assign_payroll_warning BOOLEAN;
  l_Candidate_Rehire_Count NUMBER;
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  --Begin
  l_MAIL_HOST  VARCHAR2(240) := 'smtp-bo.haemo.net';
  l_email_FROM VARCHAR2(240) := 'oracle_workflow@haemonetics.com';
  --l_email_TO                   VARCHAR2(240)  := 'krishnamurthy.dasari@haemonetics.com, divya.kantem@haemonetics.com';
  l_email_TO                   VARCHAR2(240)  := 'vijay.medikonda@haemonetics.com'; --'krishnamurthy.dasari@haemonetics.com'; --
  l_email_SUBJECT              VARCHAR2(1000) := 'Taleo - Rehire not matched';
  l_email_MESSAGE              VARCHAR2(3000) := '';
  l_period_of_service_id       NUMBER;
  l_obj_ver                    NUMBER;
  l_final_process_date         DATE;
  l_org_now_no_manager_warning BOOLEAN;
  l_asg_future_changes_warning BOOLEAN;
  l_entries_changed_warning    VARCHAR2(1000);
  l_person_type_id             NUMBER;
  l_person_type                VARCHAR2(240);
  ln_object_version PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_object_version_number PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_address_id PER_ADDRESSES.ADDRESS_ID%TYPE;
BEGIN
  l_seq_no := p_hr_emp_rec.transaction_id_stg;
  fnd_file.put_line(fnd_file.log,'Sequence Number in Is Rehire employee:'||l_seq_no);
  --IF P_HR_EMP_REC.IS_THIS_CAND_REHIRE IS NOT NULL THEN
  SELECT COUNT(*),
    MAX(papf.object_version_number),
    Papf.Person_Id,
    Ppt.User_Person_Type
  INTO l_Candidate_Rehire_Count,
    L_OBJECT_VER_NUMBER,
    L_PERSON_ID,
    l_person_type
  FROM Per_All_People_F Papf,
    Hr.Per_Person_Type_Usages_F Pptu,
    Hr.Per_Person_Types Ppt
  WHERE 1                    =1
  AND Papf.Person_Id         = Pptu.Person_Id
  AND pptu.person_type_id    = ppt.person_type_id
  AND Papf.Business_Group_Id =p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
  AND (Ppt.User_Person_Type LIKE 'Ex-employee%'
  OR ppt.user_person_type LIKE 'HAE Ex%')
  AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
  AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
  AND Upper(Papf.First_Name) = Upper(P_Hr_Emp_Rec.First_Name)
  AND upper(papf.last_name)  = upper(p_hr_emp_rec.LAST_NAME)
    --AND Papf.employee_number=P_Hr_Emp_Rec.Candidate_Number
  AND ppt.active_flag ='Y' --July-8th
  GROUP BY Papf.Person_Id,
    Ppt.User_Person_Type;
  --END IF;
  fnd_file.put_line(fnd_file.log,'candidate rehire count:'||l_Candidate_Rehire_Count||' '||L_PERSON_ID);
  IF l_Candidate_Rehire_Count =1 THEN
    BEGIN
      /*  IF l_person_type LIKE 'HAE%' THEN
      SELECT Person_Type_Id
      INTO L_Person_Type_id
      FROM Per_Person_Types
      WHERE Upper(User_Person_Type) = Upper('HAE Contingent Worker')
      AND business_group_id         =p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
      AND active_flag               ='Y';
      ELSE
      SELECT Person_Type_Id
      INTO L_Person_Type_id
      FROM Per_Person_Types
      WHERE Upper(User_Person_Type) = Upper('Employee')
      AND business_group_id         =p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
      AND active_flag               ='Y';
      END IF;*/
      -- 08/20
      IF upper(p_hr_emp_rec.EMPLOYEE_STATUS) = 'TEMPORARY WORKER' THEN
        SELECT Person_Type_Id
        INTO L_Person_Type_id
        FROM Per_Person_Types
        WHERE Upper(User_Person_Type) = Upper('HAE Contingent Worker')
        AND business_group_id         =p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
        AND active_flag               ='Y';
      ELSE
        SELECT Person_Type_Id
        INTO L_Person_Type_id
        FROM Per_Person_Types
        WHERE Upper(User_Person_Type) = Upper('Employee')
        AND business_group_id         =p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
        AND active_flag               ='Y';
      END IF;
      SELECT MAX(period_of_service_id),
        MAX(object_version_number),
        MAX(NVL(last_standard_process_date,actual_termination_Date))
      INTO l_period_of_service_id,
        l_obj_ver,
        l_final_process_date
      FROM per_periods_of_service
      WHERE person_id              = L_PERSON_ID
      AND final_process_date      IS NULL --Commented , because of this condition we are getting null Values
      AND actual_termination_Date IS NOT NULL
      GROUP BY person_id;
      fnd_file.put_line(fnd_file.log,'Termination Final processing - before '||l_obj_ver);
      fnd_file.put_line(fnd_file.log,'p_final_process_date: '||l_final_process_date);
      BEGIN
        hr_ex_employee_api.final_process_emp( p_validate => false    -- in     boolean  default false
        ,p_period_of_service_id => l_period_of_service_id            -- in     number
        ,p_object_version_number => l_obj_ver                        --in out nocopy number
        ,p_final_process_date => l_final_process_date                --in out nocopy date
        ,p_org_now_no_manager_warning => l_org_now_no_manager_warning-- out nocopy boolean
        ,p_asg_future_changes_warning => l_asg_future_changes_warning-- out nocopy boolean
        ,p_entries_changed_warning => l_entries_changed_warning      -- out nocopy varchar2
        );
        fnd_file.put_line(fnd_file.log,'Termination Final processing - after '||l_obj_ver);
      END;
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Termination Final processing - exception '||SQLERRM);
    END;
    --process it to rehire
    hr_employee_api.Re_hire_ex_employee(p_hire_date => p_hr_emp_rec.OFFER_ACTUAL_START_DATE, --to_date('20-MAY-2015'), --
    p_person_id => L_PERSON_ID, p_rehire_reason => NULL,
    ----out variables
    P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_PER_OBJECT_VERSION_NUMBER => L_OBJECT_VER_NUMBER, p_person_type_id => l_person_type_id, P_ASG_OBJECT_VERSION_NUMBER => L_ASG_OVN, P_PER_EFFECTIVE_START_DATE => L_PER_EFFECTIVE_START_DATE, P_PER_EFFECTIVE_END_DATE => L_PER_EFFECTIVE_END_DATE, P_ASSIGNMENT_SEQUENCE => L_ASSIGNMENT_SEQUENCE, P_ASSIGNMENT_NUMBER => L_ASSIGNMENT_NUMBER, P_ASSIGN_PAYROLL_WARNING => L_ASSIGN_PAYROLL_WARNING);
    --COMMIT;
    -- Added code to modify the end date the existing address and update the address for rehire employee
    BEGIN
      SELECT MAX(object_version_number),
        address_id
      INTO ln_object_version,
        ln_address_id
      FROM per_addresses
      WHERE person_id            =L_PERSON_ID
      AND primary_flag           = 'Y'
      AND NVL(DATE_TO, sysdate) >= sysdate
      GROUP BY address_id;
      fnd_file.put_line(fnd_file.log,'ln_address_id '||ln_address_id);
      ln_object_version_number     :=ln_object_version;
      IF P_HR_EMP_REC.C_COUNTRY_ABB = 'US' THEN
        hr_person_address_api.update_us_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the US address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'GB' THEN
        hr_person_address_api.update_gb_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the GB address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'AT' THEN
        hr_person_address_api.update_AT_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the AT address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'AU' THEN
        hr_person_address_api.update_AU_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the AU address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'DK' THEN
        hr_person_address_api.update_DK_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the DK address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'DE' THEN
        hr_person_address_api.update_DE_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the DE address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'IT' THEN
        hr_person_address_api.update_IT_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the IT address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MX' THEN
        hr_person_address_api.update_MX_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the MX address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MY' THEN
        hr_person_address_api.update_MY_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the MY address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'BE' THEN
        hr_person_address_api.update_BE_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the BE address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'HK' THEN
        hr_person_address_api.update_hK_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the HK address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'NL' THEN
        hr_person_address_api.update_NL_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the NL address');
      elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'SG' THEN
        hr_person_address_api.update_SG_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating the SE address');
      ELSE
        hr_person_address_api.update_person_address ( -- Input data elements
        -- -----------------------------
        p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
        --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
        p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
        -- Output data elements
        -- --------------------------------
        p_object_version_number => ln_object_version_number );
        fnd_file.put_line(fnd_file.log,'Success while end dating other business group address');
        --COMMIT;
      END IF;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'Success while end dating the address in Is candidate Rehire');
    EXCEPTION
    WHEN OTHERS THEN
      -- ROLLBACK;
      g_error:=1;
      fnd_file.put_line(fnd_file.log,'In exception while end dating the address in IS candidate Rehire'||sqlerrm);
      P_ERR_MSG:=sqlerrm; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET STATUS_STG = 'VE',
        ERROR_CODE   = ERROR_CODE
        ||'VE138:',
        ERROR_MSG = ERROR_MSG
        ||'Error in Is candidate Rehire End date address, ' ,
        LOAD_MSG = 'Create Is Rehire - Error '
        ||P_ERR_MSG
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
    END;
    ----------------End Of Changes----------------
    P_ERR_MSG:=NULL; --July-8th
    if upper(p_hr_emp_rec.EMPLOYEE_STATUS) = 'TEMPORARY WORKER' -- 1007
    then
    UPDATE per_all_people_f
    SET Attribute15 =P_Hr_Emp_Rec.Candidate_Number ,
      known_as      = P_HR_EMP_REC.CANDIDATE_UDF_2, -- dk 0813 recheck
      attribute13   = NULL,
      ATTRIBUTE12 = TO_CHAR(NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate)+180,'DD-MON-YYYY') -- 1007
    WHERE person_id = L_PERSON_ID;
    else
        UPDATE per_all_people_f
    SET Attribute15 =P_Hr_Emp_Rec.Candidate_Number ,
      known_as      = P_HR_EMP_REC.CANDIDATE_UDF_2, -- dk 0813 recheck
      attribute13   = 'YES',
      ATTRIBUTE12 = NULL, -- 1007
      attribute14 = null -- 1007
    WHERE person_id = L_PERSON_ID;
    end if;
    --COMMIT;
    G_PERSON_ID :=L_PERSON_ID; --NEW_PERSON_ID;
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_PERSON_ID        = L_PERSON_ID,
      NEW_ASSIGNMENT_ID      = L_ASSIGNMENT_ID
    WHERE TRANSACTION_ID_STG = l_seq_no;
    --COMMIT;
    --G_ASSIGNMENT_ID :=L_ASSIGNMENT_ID;
    fnd_file.put_line(fnd_file.log,'Candidate Rehire Person id:'||L_person_id);
    fnd_file.put_line(fnd_file.log,'Candidate Rehire Assignment Id:'||L_ASSIGNMENT_ID);
  ELSE
    fnd_file.put_line(fnd_file.log,'Candidate not found for Rehiring'||L_ASSIGNMENT_ID);
    fnd_file.put_line(fnd_file.log,'Send notice to HROPERATIONS@Haemonetics.com alerting them of an unmatched hire');
    -- call the email procedure
    BEGIN
      l_email_MESSAGE:='Candidate #'||P_Hr_Emp_Rec.Candidate_Number||' not exist in Oracle for rehiring';
      XXHA_SEND_MAIL ( l_MAIL_HOST, l_email_FROM, l_email_TO, l_email_SUBJECT,l_email_MESSAGE);
      --dbms_output.put_line('Success');
      fnd_file.put_line(fnd_file.log,'SuccessFully sent an email:');
      P_ERR_MSG:='Candidate not found for Rehiring'; --July-8th
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'Failed to send an Email:');
      P_ERR_MSG:=sqlerrm; --July-8th
    END;
    g_error:=1;
    UPDATE XXHA_REC_EMP_INT_STG
    SET STATUS_STG = 'VE',
      ERROR_CODE   = ERROR_CODE
      ||'VE134:',
      ERROR_MSG = ERROR_MSG
      ||'Sent an alert of Unmatched Is Candidate Rehire, ' ,
      LOAD_MSG = 'Create Is Rehire - Error '
      ||P_ERR_MSG
    WHERE TRANSACTION_ID_STG = l_seq_no;
  END IF;
EXCEPTION
WHEN OTHERS THEN
  --g_error=1;
  fnd_file.put_line(fnd_file.log,'Send notice to HROPERATIONS@Haemonetics.com alerting unmatched hire '||sqlerrm);
  -- call the email procedure
  BEGIN
    l_email_MESSAGE:='Candidate #'||P_Hr_Emp_Rec.Candidate_Number||' not exist in Oracle for rehiring';
    XXHA_SEND_MAIL ( l_MAIL_HOST, l_email_FROM, l_email_TO, l_email_SUBJECT,l_email_MESSAGE);
    --dbms_output.put_line('Success');
    fnd_file.put_line(fnd_file.log,'SuccessFully sent an email:');
    P_ERR_MSG:='Candidate not found for Rehiring'; --July-8th
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Failed to send an Email:');
    P_ERR_MSG:=sqlerrm; --July-8th
  END;
  g_error:=1;
  UPDATE XXHA_REC_EMP_INT_STG
  SET STATUS_STG = 'VE',
    ERROR_CODE   = ERROR_CODE
    ||'VE135:',
    ERROR_MSG = ERROR_MSG
    ||'Sent an alert of Unmatched Is Candidate Rehire, ' ,
    LOAD_MSG = 'Create Is Rehire - Error '
    ||P_ERR_MSG
  WHERE TRANSACTION_ID_STG = l_seq_no;
  P_ERR_MSG               :=sqlerrm; --July-8th
END CREATE_IS_REHIRE;
/*#########################################################################
------------------------< Create TEMP_To_REHIRE >------------------------
##########################################################################*/
PROCEDURE Create_Temp_To_Rehire(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  L_PERSON_ID per_people_f.person_id%TYPE;
  L_ASSIGNMENT_ID per_assignments_f.assignment_id%TYPE;
  l_object_ver_number per_people_f.object_version_number%TYPE; --:= 10;
  l_asg_ovn per_people_f.object_version_number%TYPE;
  l_per_effective_start_date per_people_v.effective_start_date%TYPE;
  l_per_effective_end_date per_people_v.effective_end_date%TYPE;
  l_assignment_sequence per_people_assignments_view.assignment_sequence%TYPE;
  l_assignment_number per_people_assignments_view.assignment_number%TYPE;
  l_assign_payroll_warning BOOLEAN;
  l_TP_count               NUMBER;
  ---------Terminate Contingent Worker Variables:---------------------
  --Common Variables
  l_terminate_emp_flag         VARCHAR2(1) := 'N';
  l_terminate_msg              VARCHAR2(600);
  l_le_terminate_emp_exception EXCEPTION;
  --- DECLARE variables for HR_EX_EMPLOYEE_WORKER_API.actual_termination_emp
  --- IN variables
  --L_Effective_Date DATE;
  l_termination_reason per_periods_of_service.leaving_reason%type;
  L_Person_Type_id per_person_types.person_type_id%type;
  l_period_of_service_id per_periods_of_service.period_of_service_id%type;
  l_actual_termination_date per_periods_of_service.actual_termination_date%type;
  l_last_standard_process_date per_periods_of_service.last_standard_process_date%type; --:=to_date('04-FEB-2015');
  l_object_version_number per_periods_of_service.object_version_number%type;
  l_start_date per_periods_of_service.date_start%type;
  l_notif_term_date DATE;
  --- OUT variables
  l_supervisor_warning         BOOLEAN; --:= false;
  l_event_warning              BOOLEAN; --:= false;
  l_interview_warning          BOOLEAN; --:= false;
  l_review_warning             BOOLEAN; --:= false;
  l_recruiter_warning          BOOLEAN; --:= false;
  l_asg_future_changes_warning BOOLEAN; --:= false;
  l_entries_changed_warning    VARCHAR2(300);
  l_pay_proposal_warning       BOOLEAN; --:= false;
  l_dod_warning                BOOLEAN; --:= false;
  l_alu_change_warning         VARCHAR2(300);
  --- DECLARE variables for HR_EX_EMPLOYEE_WORKER_API.final_process_emp
  --- IN variables
  l_final_process_date per_periods_of_service.final_process_date%type;
  --- OUT variables
  l_org_now_no_manager_warning   BOOLEAN; --:= false;
  l_f_asg_future_changes_warning BOOLEAN; --:= false;
  L_F_Entries_Changed_Warning    VARCHAR2(300);
  L_OFFER_ACTUAL_START_DATE      DATE;
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  l_sqlerrm VARCHAR2(1000);
  l_per_obj NUMBER;
  L_emp_number PER_ALL_PEOPLE_F.EMPLOYEE_NUMBER%TYPE;
  --ip_business_group per_business_groups.name%TYPE
  ln_object_version PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_object_version_number PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  ln_address_id PER_ADDRESSES.ADDRESS_ID%TYPE;
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  Fnd_File.Put_Line(Fnd_File.Log,'Getting the value of TEMP_TO_PERM_HIRE :'||P_HR_EMP_REC.TEMP_TO_PERM_HIRE);
  BEGIN
    SELECT COUNT(*) ,
      papf.person_id,
      papf.employee_number --Added employee number for updating DOB
    INTO l_TP_count,
      L_PERSON_ID,
      L_emp_number
    FROM Per_All_People_F Papf,
      Hr.Per_Person_Type_Usages_F Pptu,
      Hr.Per_Person_Types Ppt
    WHERE 1                    =1
    AND Papf.Person_Id         = Pptu.Person_Id
    AND Pptu.Person_Type_Id    = Ppt.Person_Type_Id
    AND Papf.Business_Group_Id = p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
    AND Ppt.User_Person_Type LIKE 'HAE Contingent Worker'
    AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
    AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
    AND Upper(Papf.First_Name) = Upper(P_Hr_Emp_Rec.First_Name)
    AND upper(papf.last_name)  = upper(p_hr_emp_rec.LAST_NAME)
    AND ppt.active_flag        ='Y' --July-8th
    GROUP BY papf.person_id,
      papf.employee_number; --Added employee number for updating DOB
    Fnd_File.Put_Line(Fnd_File.Log,'L_TP_count :'||l_TP_count);
    Fnd_File.Put_Line(Fnd_File.Log,'L_PERSON_ID :'||L_PERSON_ID);
    Fnd_File.Put_Line(Fnd_File.Log,'L_emp_number :'||L_emp_number);
  EXCEPTION
  WHEN OTHERS THEN
    g_error:=1;
    UPDATE XXHA_REC_EMP_INT_STG
    SET STATUS_STG = 'LE',
      ERROR_CODE   = ERROR_CODE
      ||':LE135',
      ERROR_MSG = ERROR_MSG
      ||'Exception in getting count in temp_to_rehire, ' ,
      LOAD_MSG = 'Create Temp to Rehire - Error '
      ||P_ERR_MSG
    WHERE TRANSACTION_ID_STG = L_SEQ_NO;
    --COMMIT;
    Fnd_File.Put_Line(Fnd_File.Log,'Exception in getting the countt of temp to rehire:'||sqlerrm);
    --p_err_msg  := 'Exception in temp_to_rehire:' ||SQLERRM;
  END;
  --if 2
  IF l_TP_count > 0 THEN
    SELECT OFFER_ACTUAL_START_DATE-1
    INTO L_OFFER_ACTUAL_START_DATE
    FROM XXHA_REC_EMP_INT_STG
    WHERE TRANSACTION_ID_STG     = L_SEQ_NO;
    l_last_standard_process_date:=L_OFFER_ACTUAL_START_DATE;
    Fnd_File.Put_Line(Fnd_File.Log,'l_last_standard_process_date:'||l_last_standard_process_date);
    ------Api to terminate Hae contingent worker------------
    BEGIN
      --4
      -- Code to get termination reason code and person type id value
      BEGIN
        SELECT lookup_code
        INTO l_termination_reason
        FROM Hr_Lookups
        WHERE Upper(Meaning)= Upper('Hired As An Employee')
        AND lookup_type     ='LEAV_REAS'
        AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
        AND enabled_flag ='Y';                                                                                  --July-8th
        fnd_file.put_line(fnd_file.log,'Termination reason:'||l_termination_reason);
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in deriving termination reason'||SQLERRM);
      END;
      BEGIN
        SELECT Person_Type_Id
        INTO L_Person_Type_id
        FROM Per_Person_Types
        WHERE Upper(User_Person_Type) = Upper('HAE Ex-contingent Worker') -- 08/20
        AND business_group_id         =p_hr_emp_rec.NEW_BUSINESS_GROUP_ID
        AND active_flag               ='Y'; --July-8th
        fnd_file.put_line(fnd_file.log,'Person Type Id of Ex-Contingent Worker:'||L_Person_Type_id);
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception occured in deriving termination reason'||SQLERRM);
      END;
      BEGIN
        fnd_file.put_line(fnd_file.log,'L_PERSON_ID in l_period_of_service_id is:'||L_PERSON_ID);
        SELECT pos.period_of_service_id,
          pos.object_version_number,
          date_start
        INTO l_period_of_service_id,
          l_object_version_number,
          l_start_date
        FROM per_periods_of_service pos
        WHERE pos.person_id                                     =L_PERSON_ID
        AND NVL(TRUNC(actual_termination_date),TRUNC(sysdate)) >= TRUNC(sysdate); --Added this condition to pick only active record (Because of version number we were getting the issue)
        fnd_file.put_line(fnd_file.log,'l_period_of_service_id : '|| l_period_of_service_id ||',l_object_version_number : '||l_object_version_number ||',l_start_date : '||l_start_date);
      EXCEPTION
      WHEN OTHERS THEN
        l_terminate_msg := 'Error while selecting employee details : '||SUBSTR(sqlerrm,1,150);
        raise l_le_terminate_emp_exception;
      END;
      --
      SAVEPOINT terminate_employee_s1;
      --
      BEGIN
        /*
        * This API terminates an employee.
        * This API converts a person of type Employee >to a person of type
        * Ex-Employee. The person's period of service and any employee assignments are ended.
        */
        fnd_file.put_line(fnd_file.log,'in actual_termination_emp: ');
        fnd_file.put_line(fnd_file.log,'l_object_version_number: '||l_object_version_number);
        fnd_file.put_line(fnd_file.log,'l_period_of_service_id: '||l_period_of_service_id);
        fnd_file.put_line(fnd_file.log,'L_OFFER_ACTUAL_START_DATE: '||L_OFFER_ACTUAL_START_DATE);
        fnd_file.put_line(fnd_file.log,'l_last_standard_process_date: '||l_last_standard_process_date);
        fnd_file.put_line(fnd_file.log,'L_Person_Type_id: '||L_Person_Type_id);
        fnd_file.put_line(fnd_file.log,'l_termination_reason: '||l_termination_reason);
        hr_ex_employee_api.actual_termination_emp (p_validate => false , p_effective_date =>L_OFFER_ACTUAL_START_DATE,                                                 --to_date('04-FEB-2015'),
        p_period_of_service_id => l_period_of_service_id , p_object_version_number => l_object_version_number , p_actual_termination_date =>L_OFFER_ACTUAL_START_DATE, --to_date('04-FEB-2015'),  --L_OFFER_ACTUAL_START_DATE,
        p_last_standard_process_date => l_last_standard_process_date , p_person_type_id => L_Person_Type_id , p_leaving_reason => l_termination_reason
        --Out
        ,p_supervisor_warning => l_supervisor_warning , p_event_warning => l_event_warning , p_interview_warning => l_interview_warning , p_review_warning => l_review_warning , p_recruiter_warning => l_recruiter_warning , p_asg_future_changes_warning => l_asg_future_changes_warning , p_entries_changed_warning => l_entries_changed_warning , p_pay_proposal_warning => l_pay_proposal_warning , p_dod_warning => l_dod_warning , p_alu_change_warning => l_alu_change_warning );
        fnd_file.put_line(fnd_file.log,'l_object_version_number actual_termination_emp: '||l_object_version_number);
        IF l_object_version_number IS NULL THEN
          l_terminate_emp_flag     := 'N';
          l_terminate_msg          := 'Warning validating API: hr_ex_employee_api.actual_termination_emp';
          fnd_file.put_line(fnd_file.log,'l_object_version_number is null in actual_termination_emp: ');
          raise l_le_terminate_emp_exception;
        END IF;
        l_terminate_emp_flag := 'Y';
        P_ERR_MSG            :=NULL; --July-8th
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'actual_termination_emp Exception:'||sqlerrm);
        l_terminate_msg := 'Error validating API: hr_ex_employee_api.actual_termination_emp : '||SUBSTR(sqlerrm,1,150);
        raise l_le_terminate_emp_exception;
        P_ERR_MSG:=sqlerrm; --July-8th
      END;
      IF l_terminate_emp_flag = 'Y' THEN
        BEGIN
          l_notif_term_date := L_OFFER_ACTUAL_START_DATE; --TRUNC(sysdate);
          fnd_file.put_line(fnd_file.log,'l_notif_term_date: '||l_notif_term_date);
          -- END IF;
          /*
          * This API updates employee termination information.
          * The ex-employee must exist in the relevant business group
          */
          apps.hr_ex_employee_api.update_term_details_emp (p_validate => false--l_validate
          ,p_effective_date =>L_OFFER_ACTUAL_START_DATE,                      --to_date('04-FEB-2015'),
          p_period_of_service_id => l_period_of_service_id , p_notified_termination_date => l_notif_term_date , p_projected_termination_date => l_notif_term_date
          --In/Out
          ,p_object_version_number => l_object_version_number );
          fnd_file.put_line(fnd_file.log,'in update_term_details_emp: '||l_object_version_number);
          P_ERR_MSG:=NULL; --July-8th
        EXCEPTION
        WHEN OTHERS THEN
          l_terminate_msg      := 'Error validating API: hr_ex_employee_api.update_term_details_emp : '||SUBSTR(sqlerrm,1,150);
          l_terminate_emp_flag := 'N';
          raise l_le_terminate_emp_exception;
          P_ERR_MSG:=sqlerrm; --July-8th
        END;                  --hr_ex_employee_api.update_term_details_emp
        BEGIN
          /*
          * This API set the final process date for a terminated employee.
          * This API covers the second step in terminating a period of service and all
          * current assignments for an employee. It updates the period of service
          * details and date-effectively deletes all employee assignments as of the final process date.
          */
          l_final_process_date := p_hr_emp_rec.OFFER_ACTUAL_START_DATE-1;
          apps.hr_ex_employee_api.final_process_emp (p_validate => false--l_validate
          ,p_period_of_service_id => l_period_of_service_id
          --Out
          ,p_object_version_number => l_object_version_number , p_final_process_date => l_final_process_date , p_org_now_no_manager_warning => l_org_now_no_manager_warning , p_asg_future_changes_warning => l_f_asg_future_changes_warning , p_entries_changed_warning => l_f_entries_changed_warning );
          fnd_file.put_line(fnd_file.log,'in final process: '||l_final_process_date);
          fnd_file.put_line(fnd_file.log,'in final process: '||l_object_version_number);
          P_ERR_MSG:=NULL; --July-8th
        EXCEPTION
        WHEN OTHERS THEN
          l_terminate_msg := 'Error validating API: hr_ex_employee_api.final_process_emp : '||SUBSTR(sqlerrm,1,150);
          raise l_le_terminate_emp_exception;
          P_ERR_MSG:=sqlerrm; --July-8th
        END;                  --hr_ex_employee_api.final_process_emp
      END IF;
      fnd_file.put_line(fnd_file.log,'calling Re_hire_ex_employee for temp to perm ');
      fnd_file.put_line(fnd_file.log,'L_OBJECT_VER_NUMBER :'||l_object_version_number);
      fnd_file.put_line(fnd_file.log,'NEW_PERSON_ID :'||L_PERSON_ID);
      SELECT MAX(object_version_number)
      INTO l_per_obj
      FROM per_all_people_f
      WHERE person_id = l_person_id
      AND TRUNC(sysdate) BETWEEN TRUNC(effective_start_Date) AND TRUNC(effective_end_Date);
      fnd_file.put_line(fnd_file.log,'l_per_obj :'||l_per_obj);
      hr_employee_api.Re_hire_ex_employee(p_hire_date =>p_hr_emp_rec.OFFER_ACTUAL_START_DATE, --to_date('06-FEB-2015'), --p_hr_emp_rec.hire_date,
      p_person_id => L_PERSON_ID, p_rehire_reason => NULL,
      ----out variables
      P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_PER_OBJECT_VERSION_NUMBER => l_per_obj,--l_object_version_number, --L_OBJECT_VER_NUMBER,
      P_ASG_OBJECT_VERSION_NUMBER => L_ASG_OVN, P_PER_EFFECTIVE_START_DATE => L_PER_EFFECTIVE_START_DATE, P_PER_EFFECTIVE_END_DATE => L_PER_EFFECTIVE_END_DATE, P_ASSIGNMENT_SEQUENCE => L_ASSIGNMENT_SEQUENCE, P_ASSIGNMENT_NUMBER => L_ASSIGNMENT_NUMBER, P_ASSIGN_PAYROLL_WARNING => L_ASSIGN_PAYROLL_WARNING);
      --COMMIT;
      -- Added code to modify the end date the existing address and update the address for rehire employee
      BEGIN
        BEGIN
          SELECT MAX(object_version_number),
            address_id
          INTO ln_object_version,
            ln_address_id
          FROM per_addresses
          WHERE person_id=L_PERSON_ID
          GROUP BY address_id;
        EXCEPTION
        WHEN no_data_found THEN
          ln_object_version:=NULL;
        END;
        IF ln_object_version           IS NOT NULL THEN
          ln_object_version_number     :=ln_object_version;
          IF P_HR_EMP_REC.C_COUNTRY_ABB = 'US' THEN
            hr_person_address_api.update_us_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the US address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'GB' THEN
            hr_person_address_api.update_gb_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the GB address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'AT' THEN
            hr_person_address_api.update_AT_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the AT address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'AU' THEN
            hr_person_address_api.update_AU_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the AU address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'DK' THEN
            hr_person_address_api.update_dk_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the DK address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'DE' THEN
            hr_person_address_api.update_de_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the DE address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'IT' THEN
            hr_person_address_api.update_it_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the IT address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MX' THEN
            hr_person_address_api.update_mx_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the MX address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MY' THEN
            hr_person_address_api.update_my_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the MY address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'BE' THEN
            hr_person_address_api.update_be_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the BE address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'HK' THEN
            hr_person_address_api.update_hk_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the HK address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'NL' THEN
            hr_person_address_api.update_nl_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the NL address');
          elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'SG' THEN
            hr_person_address_api.update_sg_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating the SE address');
          ELSE
            hr_person_address_api.update_person_address ( -- Input data elements
            -- -----------------------------
            p_effective_date => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE), p_address_id => ln_address_id,
            --p_date_from => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE),
            p_date_to => to_date(p_hr_emp_rec.OFFER_ACTUAL_START_DATE)-1,
            -- Output data elements
            -- --------------------------------
            p_object_version_number => ln_object_version_number );
            fnd_file.put_line(fnd_file.log,'Success while end dating other business group address');
            --COMMIT;
          END IF;
        END IF;
        --COMMIT;
        fnd_file.put_line(fnd_file.log,'Success while end dating the address in temp to rehire');
      EXCEPTION
      WHEN OTHERS THEN
        -- ROLLBACK;
        g_error:=1;
        fnd_file.put_line(fnd_file.log,'In exception while end dating the address in temo to rehire'||sqlerrm);
        P_ERR_MSG:=sqlerrm; --July-8th
        UPDATE XXHA_REC_EMP_INT_STG
        SET STATUS_STG = 'VE',
          ERROR_CODE   = ERROR_CODE
          ||'VE139:',
          ERROR_MSG = ERROR_MSG
          ||'Error in Temp to Rehire End date address, ' ,
          LOAD_MSG = 'Create Temp to Rehire - Error '
          ||P_ERR_MSG
        WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      END;
      ----------------End Of Changes----------------
      p_err_msg:=NULL; --July-8th
      fnd_file.put_line(fnd_file.log,'P_PER_EFFECTIVE_START_DATE at temp to perm rehire:'||L_PER_EFFECTIVE_START_DATE);
      fnd_file.put_line(fnd_file.log,'Object version number after temp to perm rehire:'||l_per_obj);
      UPDATE per_all_people_f
      SET Attribute15 =P_Hr_Emp_Rec.Candidate_Number ,
        attribute13   = 'YES' ,
        known_as      = P_HR_EMP_REC.CANDIDATE_UDF_2 -- dk 0813 recheck
        ,ATTRIBUTE12 = null --1007
        ,attribute14 = null --1007
      WHERE person_id = L_PERSON_ID;
      --COMMIT;
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_PERSON_ID        = L_PERSON_ID,
        NEW_ASSIGNMENT_ID      = L_ASSIGNMENT_ID
      WHERE TRANSACTION_ID_STG = l_seq_no;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'Person id at temp to perm rehire:'||L_PERSON_ID);
      fnd_file.put_line(fnd_file.log,'Assignment Id at temp to perm rehire:'||L_ASSIGNMENT_ID);
      fnd_file.put_line(fnd_file.log,'Business Group in Temp to Rehire:'||p_hr_emp_rec.New_Business_Group);
      fnd_file.put_line(fnd_file.log,'Emp Number in Temp to Rehire:'||L_emp_number);
      ----------------------------Calling update procedure to update DOB--------------------
      BEGIN
        fnd_file.put_line(fnd_file.log,'Before Calling Update Procedure');
        --Update_TEMP_EMP_DOB(L_emp_number,L_PERSON_ID,L_ASSIGNMENT_ID,p_hr_emp_rec.New_Business_Group,l_per_obj);
        Update_TEMP_EMP_DOB(L_emp_number,L_PERSON_ID,L_ASSIGNMENT_ID,p_hr_emp_rec.New_Business_Group, p_hr_emp_rec.OFFER_ACTUAL_START_DATE);
        fnd_file.put_line(fnd_file.log,'After Calling Update Procedure');
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.log,'Exception in Calling Update procedure for Updating Dob:'||sqlerrm);
      END;
      ---------------------------------------------------------------------------------------
    EXCEPTION
    WHEN l_le_terminate_emp_exception THEN
      ROLLBACK TO terminate_employee_s1;
      fnd_file.put_line(fnd_file.log,'Failed in Temp to Rehire  '||sqlerrm);
      P_ERR_MSG :=sqlerrm; --July-10th
      UPDATE XXHA_REC_EMP_INT_STG
      SET STATUS_STG = 'LE',
        ERROR_CODE   = ERROR_CODE
        ||':LE133',
        ERROR_MSG = ERROR_MSG
        ||'Failed in Temp to Rehire ' ,
        LOAD_MSG = 'Create Temp to Rehire - Error '
        ||P_ERR_MSG
      WHERE TRANSACTION_ID_STG = L_SEQ_NO;
      --COMMIT; --July-8th
    WHEN OTHERS THEN
      l_sqlerrm:= SUBSTR(sqlerrm,1,1000);
      fnd_file.put_line(fnd_file.log,'Terminate Employee. Error OTHERS while validating: '||sqlerrm);
      ROLLBACK TO Terminate_Employee_S1;
      P_ERR_MSG :=sqlerrm; --July-10th
      UPDATE XXHA_REC_EMP_INT_STG
      SET STATUS_STG = 'LE',
        ERROR_CODE   = ERROR_CODE
        ||'LE134:',
        ERROR_MSG = ERROR_MSG
        ||'Failed in Temp to Rehire '
        || l_sqlerrm ,
        LOAD_MSG = 'Create Temp to Rehire - Error '
        ||P_ERR_MSG
      WHERE TRANSACTION_ID_STG = L_SEQ_NO;
      --COMMIT; July-8th
    END;
    -- P_ERR_MSG:=sqlerrm; --July-8th commented on July-10th
  END IF;
  --end if;
EXCEPTION
WHEN OTHERS THEN
  fnd_file.put_line(fnd_file.log,'At temp to rehire Exception');
  P_ERR_MSG:=sqlerrm; --July-8th
END Create_Temp_To_Rehire;
/*#########################################################################
------------------------< Create Employee >-------------------------------
##########################################################################*/
PROCEDURE Create_employee(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  l_employee_number per_people_f.employee_number%TYPE;
  L_PERSON_ID per_people_f.person_id%TYPE;
  L_ASSIGNMENT_ID per_assignments_f.assignment_id%TYPE;
  l_object_ver_number per_people_f.object_version_number%TYPE; --:= 10;
  l_asg_ovn per_people_f.object_version_number%TYPE;
  l_per_effective_start_date per_people_v.effective_start_date%TYPE;
  l_per_effective_end_date per_people_v.effective_end_date%TYPE;
  l_full_name per_people_f.full_name%TYPE;
  l_per_comment_id per_people_f.comment_id%TYPE;
  l_assignment_sequence per_people_assignments_view.assignment_sequence%TYPE;
  l_assignment_number per_people_assignments_view.assignment_number%TYPE;
  l_name_combination_warning BOOLEAN;
  l_assign_payroll_warning   BOOLEAN;
  l_orig_hire_warning        BOOLEAN;
  l_error_msg                VARCHAR2(4000);
  l_context2                 NUMBER;
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  L_emp_count NUMBER := 0;
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  fnd_file.put_line(fnd_file.log,'EMP creation Start');
  --Added to get attribute category for email.
  BEGIN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context2
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_PEOPLE'
    AND descriptive_flex_context_name = p_hr_emp_rec.NEW_BUSINESS_GROUP
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'l_context2:'||l_context2);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception in getting attribute category ID:'||l_context2);
  END;
  -----------Create Employee employee--------------------------
  IF g_error=0 THEN -- For testing load commented
    fnd_file.put_line(fnd_file.log,'Before HR_EMPLOYEE_API.CREATE_EMPLOYEE:');
    IF upper(P_HR_EMP_REC.EMPLOYEE_STATUS) = 'TEMPORARY WORKER' THEN
      fnd_file.put_line(fnd_file.log,'Create Temporary Worker');
      HR_EMPLOYEE_API.CREATE_EMPLOYEE (P_VALIDATE => FALSE, P_HIRE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_BUSINESS_GROUP_ID => p_hr_emp_rec.NEW_BUSINESS_GROUP_ID, P_FIRST_NAME => P_HR_EMP_REC.FIRST_NAME, P_LAST_NAME => P_HR_EMP_REC.LAST_NAME, p_person_type_id=> p_hr_emp_rec.new_person_typ_id, P_MIDDLE_NAMES => P_HR_EMP_REC.MIDDLE_NAME, p_known_as => P_HR_EMP_REC.CANDIDATE_UDF_2, p_sex =>'F',
      --p_original_date_of_hire => p_hr_emp_rec.OFFER_ACTUAL_START_DATE,
      --P_NATIONAL_IDENTIFIER => p_hr_emp_rec.candidate_number,                                                         --candidate_number,--
      p_email_address => p_hr_emp_rec.email, P_ATTRIBUTE12 => TO_CHAR(NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate)+180,'DD-MON-YYYY'), -- dk 08/13
      p_date_of_birth => TO_DATE('01-JAN-1990'), p_attribute_category =>l_context2,                                                          --3137, --l_context2, --
      p_attribute13 => NULL,--'YES',  -- 1007                                                                                                              --upper(p_hr_emp_rec.requisition_udf_5), -- should be always Yes
      p_attribute14 => p_hr_emp_rec.offer_udf_3, p_attribute15 => p_hr_emp_rec.candidate_number,
      ---------------Out Variables-----------------------
      p_employee_number => L_employee_number, P_PERSON_ID => L_PERSON_ID, P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_PER_OBJECT_VERSION_NUMBER => L_OBJECT_VER_NUMBER , P_ASG_OBJECT_VERSION_NUMBER => L_ASG_OVN, P_PER_EFFECTIVE_START_DATE => L_PER_EFFECTIVE_START_DATE , P_PER_EFFECTIVE_END_DATE => L_PER_EFFECTIVE_END_DATE, P_FULL_NAME => L_FULL_NAME , P_PER_COMMENT_ID => L_PER_COMMENT_ID , P_ASSIGNMENT_SEQUENCE => L_ASSIGNMENT_SEQUENCE, P_ASSIGNMENT_NUMBER => L_ASSIGNMENT_NUMBER , P_NAME_COMBINATION_WARNING => L_NAME_COMBINATION_WARNING, P_ASSIGN_PAYROLL_WARNING => L_ASSIGN_PAYROLL_WARNING , p_orig_hire_warning => l_orig_hire_warning);
    ELSE
      fnd_file.put_line(fnd_file.log,'Create Employee');
      HR_EMPLOYEE_API.CREATE_EMPLOYEE (P_VALIDATE => FALSE, P_HIRE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_BUSINESS_GROUP_ID => p_hr_emp_rec.NEW_BUSINESS_GROUP_ID, P_FIRST_NAME => P_HR_EMP_REC.FIRST_NAME, P_LAST_NAME => P_HR_EMP_REC.LAST_NAME, p_person_type_id=> p_hr_emp_rec.new_person_typ_id, P_MIDDLE_NAMES => P_HR_EMP_REC.MIDDLE_NAME, p_known_as => P_HR_EMP_REC.CANDIDATE_UDF_2, p_sex =>'F',
      --p_original_date_of_hire => p_hr_emp_rec.OFFER_ACTUAL_START_DATE,
      P_NATIONAL_IDENTIFIER => p_hr_emp_rec.candidate_number,                                                                                                         --SSN,                                                                                                                      --candidate_number,--
      p_email_address => p_hr_emp_rec.email, P_ATTRIBUTE12 => null,--P_HR_EMP_REC.OFFER_UDF_1 --1007
      p_date_of_birth => TO_DATE('01-JAN-1990'), p_attribute_category =>l_context2, --3137, --l_context2, --
      p_attribute13 => 'YES',                                                                                                                                         --upper(p_hr_emp_rec.requisition_udf_5), -- should be always Yes
      p_attribute14 => NULL,--p_hr_emp_rec.offer_udf_3, --1007
      p_attribute15 => p_hr_emp_rec.candidate_number,
      ---------------Out Variables-----------------------
      p_employee_number => L_employee_number, P_PERSON_ID => L_PERSON_ID, P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_PER_OBJECT_VERSION_NUMBER => L_OBJECT_VER_NUMBER , P_ASG_OBJECT_VERSION_NUMBER => L_ASG_OVN, P_PER_EFFECTIVE_START_DATE => L_PER_EFFECTIVE_START_DATE , P_PER_EFFECTIVE_END_DATE => L_PER_EFFECTIVE_END_DATE, P_FULL_NAME => L_FULL_NAME , P_PER_COMMENT_ID => L_PER_COMMENT_ID , P_ASSIGNMENT_SEQUENCE => L_ASSIGNMENT_SEQUENCE, P_ASSIGNMENT_NUMBER => L_ASSIGNMENT_NUMBER , P_NAME_COMBINATION_WARNING => L_NAME_COMBINATION_WARNING, P_ASSIGN_PAYROLL_WARNING => L_ASSIGN_PAYROLL_WARNING , p_orig_hire_warning => l_orig_hire_warning);
    END IF;
    --COMMIT;
    P_ERR_MSG       :=NULL;            --July-8th
    G_PERSON_ID     := L_PERSON_ID;    -- Dkantem revisit
    G_ASSIGNMENT_ID := L_ASSIGNMENT_ID;-- Dkantem revisit
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_PERSON_ID        = L_PERSON_ID,
      NEW_ASSIGNMENT_ID      = L_ASSIGNMENT_ID
    WHERE TRANSACTION_ID_STG = l_seq_no;
    --commit;
    fnd_file.put_line(fnd_file.log,'OUT Global Person id After Emp Creation :' ||L_PERSON_ID);
    fnd_file.put_line(fnd_file.log,'OUT Global Assignment id After Emp Creation :' ||L_ASSIGNMENT_ID);
    fnd_file.put_line(fnd_file.log,'OUT-Employee number generated by system :' ||L_employee_number);
  END IF;
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  UPDATE XXHA_REC_EMP_INT_STG
  SET STATUS_STG = 'LE',
    ERROR_CODE   = ERROR_CODE
    ||':LE110',
    ERROR_MSG = ERROR_MSG
    ||'Failed in Employee Creation ' ,
    LOAD_MSG = 'Create Employee - Error '
    ||P_ERR_MSG
  WHERE TRANSACTION_ID_STG = L_SEQ_NO;
  --COMMIT;
  fnd_file.put_line(fnd_file.log,'Exception in Employee Creation :' ||sqlerrm);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END CREATE_EMPLOYEE;
/*#########################################################################
------------------------< Create Employee Assignments >----------------------
##########################################################################*/
PROCEDURE Create_emp_asgnmnt(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_api_mode   IN VARCHAR2,
    p_err_msg OUT VARCHAR2)
IS
  -- Local Variables
  -- -----------------------
  L_API_MODE       VARCHAR2(200);
  L_ASSIGNMENT_ID  NUMBER ;
  LN_OBJECT_NUMBER NUMBER;
  --l_object_version_number      NUMBER;
  l_ASSIGNMENT_STATUS_TYPE_ID  NUMBER := 1;
  L_CAGR_GRADE_DEF_ID          NUMBER;
  L_CAGR_CONCATENATED_SEGMENTS VARCHAR2 (100);
  l_gsp_post_process_warning   VARCHAR2 (30);
  -- Out Variables for Find Date Track Mode API
  -- -----------------------------------------------------------------
  lb_correction           BOOLEAN;
  lb_update               BOOLEAN;
  lb_update_override      BOOLEAN;
  lb_update_change_insert BOOLEAN;
  -- Out Variables for Update Employee Assignment API
  -- ----------------------------------------------------------------------------
  ln_soft_coding_keyflex_id hr_soft_coding_keyflex.soft_coding_keyflex_id%TYPE;
  lc_concatenated_segments VARCHAR2(2000);
  ln_comment_id per_all_assignments_f.comment_id%TYPE;
  lb_no_managers_warning BOOLEAN;
  -- Out Variables for Update Employee Assgment Criteria
  -- -------------------------------------------------------------------------------
  ln_special_ceiling_step_id per_all_assignments_f.special_ceiling_step_id%TYPE;
  -- l_group_name VARCHAR2(30);
  ld_effective_start_date per_all_assignments_f.effective_start_date%TYPE;
  ld_effective_end_date per_all_assignments_f.effective_end_date%TYPE;
  lb_org_now_no_manager_warning BOOLEAN;
  lb_other_manager_warning      BOOLEAN;
  lb_spp_delete_warning         BOOLEAN;
  lc_entries_changed_warning    VARCHAR2(30);
  lb_tax_district_changed_warn  BOOLEAN;
  --NEW_JOB_ID                    NUMBER;
  --LN_PEOPLE_GROUP_ID            NUMBER;
  L_ERR_MSG         VARCHAR2 (280);
  l_probation_units VARCHAR2(30);
  l_probation       NUMBER;
  L_ASS_ATTRIBUTE1  NUMBER;
  L_count           NUMBER      := 0;
  l_err_flag        VARCHAR2(1) := 'N';
  l_segment1        NUMBER;
  l_set_of_books_id NUMBER;
  -------------Local Variables for Assignments Criteria-------------------
  L_EFFECTIVE_DATE          DATE          := SYSDATE;
  L_DATETRACK_UPDATE_MODE   VARCHAR2(200) := 'CORRECTION';
  L_VALIDATE                BOOLEAN       := FALSE;
  L_CALLED_FROM_MASS_UPDATE BOOLEAN       := NULL;
  L_POSITION_ID             NUMBER        := NULL;
  --P_ORGANIZATION_ID            NUMBER        := l_organization_id;
  L_employment_category      VARCHAR2(200) := NULL;
  L_CONCAT_SEGMENTS          VARCHAR2(200) := NULL;
  L_CONTRACT_ID              NUMBER        := NULL;
  L_ESTABLISHMENT_ID         NUMBER        := NULL;
  L_SCL_SEGMENT1             VARCHAR2(200) := NULL;
  L_GRADE_LADDER_PGM_ID      NUMBER        := NULL;
  l_SUPERVISOR_ASSIGNMENT_ID NUMBER        := NULL;
  l_OBJECT_VERSION_NUMBER    NUMBER ;
  l_SPP_DELETE_WARNING       BOOLEAN;
  l_DISTRICT_CHANGED_WARNING BOOLEAN;
  l_effective_end_date per_all_assignments_f.effective_end_date%TYPE;
  l_effective_start_date per_all_assignments_f.effective_start_date%TYPE := SYSDATE;
  l_entries_changed_warning VARCHAR2(1)                                  := 'N';
  l_group_name pay_people_groups.group_name%TYPE;
  l_old_group_name pay_people_groups.group_name%TYPE;
  l_no_managers_warning BOOLEAN;
  -- l_object_version_number per_all_assignments_f.object_version_number%TYPE;
  l_org_now_no_manager_warning BOOLEAN;
  l_other_manager_warning      BOOLEAN;
  l_hourly_salaried_warning    BOOLEAN;
  --NEW_PAYROLL_ID_updated       BOOLEAN;
  l_people_group_id per_all_assignments_f.people_group_id%TYPE;
  l_special_ceiling_step_id per_all_assignments_f.special_ceiling_step_id%TYPE;-- := p_special_ceiling_step_id;
  --l_spp_delete_warning           BOOLEAN;
  l_tax_district_changed_warning BOOLEAN;
  l_flex_num fnd_id_flex_segments.id_flex_num%TYPE;
  --
  l_api_updating BOOLEAN;
  L_Person_Type_id per_all_assignments_f.business_group_id%TYPE;
  l_comment_id per_all_assignments_f.comment_id%TYPE;
  l_entries_changed VARCHAR2(1);
  l_legislation_code per_business_groups.legislation_code%TYPE;
  l_new_payroll_id per_all_assignments_f.payroll_id%TYPE;
  L_PROC VARCHAR2(72) :='hr_assignment_api.update_emp_asg_criteria';
  L_SOFT_CODING_KEYFLEX_ID per_all_assignments_f.soft_coding_keyflex_id%TYPE;
  l_concatenated_segments hr_soft_coding_keyflex.concatenated_segments%TYPE;
  l_old_conc_segments hr_soft_coding_keyflex.concatenated_segments%TYPE;
  L_Y          NUMBER;
  M_attribute1 VARCHAR2(300);
  M_attribute2 VARCHAR2(300);
  l_context    VARCHAR2(300);--NUMBER; --Dkantem
  l_segment2   VARCHAR2(240);
  l_start_date DATE;
  -------------End Of Local Variables for Assignments Criteria-------------------
BEGIN
  g_error := 0;
  fnd_file.put_line(fnd_file.log,'B4 UPDATE_EMP_ASG');
  --object_version_number is mandatory parameter for "HR_ASSIGNMENT_API.UPDATE_EMP_ASG" it will takes the latest number I.e last modified assignments number
  SELECT new_assignment_id
  INTO l_assignment_id
  FROM XXHA_REC_EMP_INT_STG
  WHERE transaction_id_stg = p_hr_emp_rec.transaction_id_stg;
  fnd_file.put_line(fnd_file.log,'l_assignment_id '||l_assignment_id);
  BEGIN
    SELECT MAX (object_version_number)--, effective_start_date
    INTO LN_OBJECT_NUMBER             --, l_start_date
    FROM per_all_assignments_f
    WHERE 1           = 1
    AND assignment_id = l_assignment_id--P_HR_EMP_REC.NEW_ASSIGNMENT_ID revisit
      ;
    --AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE)) ;
    SELECT MAX (effective_start_date)
    INTO l_start_date
    FROM per_all_assignments_f
    WHERE 1           = 1
    AND assignment_id = l_assignment_id--P_HR_EMP_REC.NEW_ASSIGNMENT_ID revisit
      ;
    fnd_file.put_line(fnd_file.log,'Object Version Number in Update_emp_asg:'||LN_OBJECT_NUMBER||' '||l_start_date);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception while getting Object Version Number in Update_emp_asg:'||SQLERRM||LN_OBJECT_NUMBER||' '||l_start_date);
  END;
  --L_ASSIGNMENT_ID := G_ASSIGNMENT_ID;--P_HR_EMP_REC.NEW_ASSIGNMENT_ID; revisit
  fnd_file.put_line(fnd_file.log,'Object Version Number in Update_emp_asg:'||LN_OBJECT_NUMBER);
  /*##################################################################################
  ------------------------<Added Logic to populate probation and notice period >----
  ####################################################################################*/
  BEGIN
    IF TO_CHAR(P_HR_EMP_REC.PROBATION_PERIOD) IS NULL OR TO_CHAR(P_HR_EMP_REC.PROBATION_PERIOD) = '0' THEN
      l_probation_units                       := NULL;
      l_probation                             := NULL;
    ELSE
      l_probation_units := 'M'; --meaning Months
      l_probation       := P_HR_EMP_REC.PROBATION_PERIOD;
    END IF;
    fnd_file.put_line(fnd_file.log,'l_probation_units:'||l_probation_units);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception of Probation and Notice period:'||L_ASS_ATTRIBUTE1);
  END;
  ------------------- For Requisition Udf 6, to update the shift value------------------------
  BEGIN
    IF p_hr_emp_rec.NEW_BUSINESS_GROUP ='BG_US' OR p_hr_emp_rec.NEW_BUSINESS_GROUP='BG_GB' THEN
      L_ASS_ATTRIBUTE1                :=1;
      fnd_file.put_line(fnd_file.log,'L_ASS_ATTRIBUTE1:'||L_ASS_ATTRIBUTE1);
    ELSE
      L_ASS_ATTRIBUTE1 :=NULL;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception of getting shift value for US:'||L_ASS_ATTRIBUTE1);
  END;
  ------------Attribute values of my employee class---------------
  BEGIN
    IF P_HR_EMP_REC.my_employee_class        = 1 THEN
      M_attribute1                          :='Exempt';
    elsif P_HR_EMP_REC.my_employee_class     =2 THEN
      M_attribute1                          :='Manager';
    elsif P_HR_EMP_REC.my_employee_class     =3 THEN
      M_attribute1                          :='Non-Exempt';
    elsif P_HR_EMP_REC.my_employee_class     =4 THEN
      M_attribute1                          :='Shift Exempt';
    elsif P_HR_EMP_REC.my_employee_class     =5 THEN
      M_attribute1                          :='Shift Manager';
    elsif P_HR_EMP_REC.my_employee_class     =6 THEN
      M_attribute1                          :='Shift Non-Exempt';
    elsif upper(P_HR_EMP_REC.EMPLOYEE_STATUS)='TEMPORARY WORKER' THEN
      M_attribute1                          := 'Contingent Worker';
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception in getting Attribute_values:'||sqlerrm);
  END;
  ------------Attribute values of MY Normal Work Schedule---------------
  BEGIN
    IF P_HR_EMP_REC.my_normal_work_sch   =1 THEN
      M_attribute2                      :='4-WWWOOR';
    elsif P_HR_EMP_REC.my_normal_work_sch=2 THEN
      M_attribute2                      :='5-WWWWOR';
    elsif P_HR_EMP_REC.my_normal_work_sch=3 THEN
      M_attribute2                      :='5-Mon to Fri';
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception in getting Attribute_values:'||sqlerrm);
  END;
  ---- Added Dkantem, To get Assignment Attribute category value based on Business group
  BEGIN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_ASSIGNMENTS'
    AND descriptive_flex_context_name =p_hr_emp_rec.NEW_BUSINESS_GROUP --p_hr_emp_rec.L_BUSINESS_GROUP
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'l_context:'||l_context);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_ASSIGNMENTS'
    AND descriptive_flex_context_name ='Global Data Elements'
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'l_context in nodatafound:'||l_context);
  WHEN OTHERS THEN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_ASSIGNMENTS'
    AND descriptive_flex_context_name ='Global Data Elements'
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'l_context in nodatafound:'||l_context);
    fnd_file.put_line(fnd_file.log,'Exception while getting Attribute category value:'||sqlerrm);
  END;
  IF p_hr_emp_rec.NEW_BUSINESS_GROUP ='BG_AU' THEN
    l_segment2                      := 'N';
  ELSE
    l_segment2 := NULL;
  END IF;
  fnd_file.put_line(fnd_file.log,'In HR_ASSIGNMENT_API.UPDATE_EMP_ASG Api:');
  L_API_MODE := 'CORRECTION';
  --begin --addedP_SOFT_CODING_KEYFLEX_ID:
  IF g_error =0 THEN
    --IF P_HR_EMP_REC.NEW_ORGANIZATION_ID IS NOT NULL THEN
    fnd_file.put_line(fnd_file.log,'In HR_ASSIGNMENT_API.UPDATE_EMP_ASG Api: 1 '||P_HR_EMP_REC.OFFER_ACTUAL_START_DATE);
    IF P_HR_EMP_REC.NEW_LEGAL_ENTITY_ID IS NOT NULL THEN                                                                                                                                                                                                                                                                                                                                                                                                                                                                                --NEW_LEGAL_ENTITY_ID
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG (P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate),                                                                                                                                                                                                                                                                                                                                                                                                    --SYSDATE, revisit
      P_DATETRACK_UPDATE_MODE => L_API_MODE, P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_OBJECT_VERSION_NUMBER => LN_OBJECT_NUMBER, p_supervisor_id => P_HR_EMP_REC.NEW_SUPERVISOR_ID, P_ASSIGNMENT_STATUS_TYPE_ID => l_ASSIGNMENT_STATUS_TYPE_ID, P_DEFAULT_CODE_COMB_ID => P_HR_EMP_REC.NEW_EXPENSE_CCID, P_FREQUENCY => 'W', P_NORMAL_HOURS => NVL(P_HR_EMP_REC.NORMAL_WORK_HR_PER_WEEK,40) , P_PERF_REVIEW_PERIOD => 1, P_PERF_REVIEW_PERIOD_FREQUENCY => 'Y' , P_PROBATION_PERIOD => l_probation, p_probation_unit => l_probation_units, --'W',
      P_SAL_REVIEW_PERIOD => 1, P_SAL_REVIEW_PERIOD_FREQUENCY => 'Y', P_SET_OF_BOOKS_ID => P_HR_EMP_REC.new_set_of_books_id, P_HOURLY_SALARIED_CODE => P_HR_EMP_REC.NEW_HOURLY_SALARY, P_ASS_ATTRIBUTE1 =>L_ASS_ATTRIBUTE1,
      --P_ASS_ATTRIBUTE2 =>M_attribute2,
      P_ASS_ATTRIBUTE_CATEGORY=>l_context, p_segment1 => P_HR_EMP_REC.NEW_LEGAL_ENTITY_ID,                                                                                                                                                                                                              --101,
      p_segment2 => l_segment2,                                                                                                                                                                                                                                                                         -- For AU Leave Loading
      p_cagr_grade_def_id => l_cagr_grade_def_id, p_cagr_concatenated_segments => l_cagr_concatenated_segments, p_concatenated_segments => l_concatenated_segments, p_soft_coding_keyflex_id =>l_SOFT_CODING_KEYFLEX_ID, p_comment_id => l_comment_id, P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE, --P_HR_EMP_REC.offer_actual_start_date,
      p_effective_end_date => l_effective_end_date, P_NO_MANAGERS_WARNING => L_NO_MANAGERS_WARNING, P_OTHER_MANAGER_WARNING => L_OTHER_MANAGER_WARNING, p_hourly_salaried_warning => l_hourly_salaried_warning, p_gsp_post_process_warning => l_gsp_post_process_warning );
      fnd_file.put_line(fnd_file.log,'p_segment1 : '||P_HR_EMP_REC.NEW_LEGAL_ENTITY_ID);
      fnd_file.put_line(fnd_file.log,'P_SET_OF_BOOKS_ID : '|| P_HR_EMP_REC.new_set_of_books_id);
      fnd_file.put_line(fnd_file.log,'l_concatenated_segments : '||l_concatenated_segments);
      fnd_file.put_line(fnd_file.log,'Soft coding keyflex id : '||L_SOFT_CODING_KEYFLEX_ID);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
    ELSE
      fnd_file.put_line(fnd_file.log,'In HR_ASSIGNMENT_API.UPDATE_EMP_ASG Api: 2 '||P_HR_EMP_REC.OFFER_ACTUAL_START_DATE);
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG (P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdatE),                                                                                                                                                                                                                                                                                                                                                                                                    --'12-Jul-15', --to_date('dd-mon-yy')--                                                                                                                                                                                                                                                                                                                                                                                                               --SYSDATE, revisit
      P_DATETRACK_UPDATE_MODE => L_API_MODE, P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_OBJECT_VERSION_NUMBER => LN_OBJECT_NUMBER, p_supervisor_id => P_HR_EMP_REC.NEW_SUPERVISOR_ID, P_ASSIGNMENT_STATUS_TYPE_ID => l_ASSIGNMENT_STATUS_TYPE_ID, P_DEFAULT_CODE_COMB_ID => P_HR_EMP_REC.NEW_EXPENSE_CCID, P_FREQUENCY => 'W', P_NORMAL_HOURS => NVL(P_HR_EMP_REC.NORMAL_WORK_HR_PER_WEEK,40) , P_PERF_REVIEW_PERIOD => 1, P_PERF_REVIEW_PERIOD_FREQUENCY => 'Y' , P_PROBATION_PERIOD => l_probation, p_probation_unit => l_probation_units, --'W',
      P_SAL_REVIEW_PERIOD => 1, P_SAL_REVIEW_PERIOD_FREQUENCY => 'Y', P_SET_OF_BOOKS_ID => P_HR_EMP_REC.new_set_of_books_id,                                                                                                                                                                                                                                                                                                                                                                                                            --1001 ,
      P_HOURLY_SALARIED_CODE => P_HR_EMP_REC.NEW_HOURLY_SALARY, P_ASS_ATTRIBUTE1 =>M_attribute1,                                                                                                                                                                                                                                                                                                                                                                                                                                        --'Exempt',  --  -- For US we need to pass L_ASS_ATTRIBUTE1 for attribute1
      P_ASS_ATTRIBUTE2 =>M_attribute2,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  --'4-WWWOOR', --
      P_ASS_ATTRIBUTE_CATEGORY=>l_context, p_cagr_grade_def_id => l_cagr_grade_def_id, p_cagr_concatenated_segments => l_cagr_concatenated_segments, p_concatenated_segments => l_concatenated_segments, p_soft_coding_keyflex_id =>L_SOFT_CODING_KEYFLEX_ID, p_comment_id => l_comment_id, P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE,                                                                                                                                                                                            --P_HR_EMP_REC.offer_actual_start_date,
      p_effective_end_date => l_effective_end_date, P_NO_MANAGERS_WARNING => L_NO_MANAGERS_WARNING, P_OTHER_MANAGER_WARNING => L_OTHER_MANAGER_WARNING, p_hourly_salaried_warning => l_hourly_salaried_warning, p_gsp_post_process_warning => l_gsp_post_process_warning );
      fnd_file.put_line(fnd_file.log,'p_segment1 : '||P_HR_EMP_REC.NEW_ORGANIZATION_ID);
      fnd_file.put_line(fnd_file.log,'P_SET_OF_BOOKS_ID : '|| P_HR_EMP_REC.new_set_of_books_id);
      fnd_file.put_line(fnd_file.log,'l_concatenated_segments : '||l_concatenated_segments);
      fnd_file.put_line(fnd_file.log,'Soft coding keyflex id : '||L_SOFT_CODING_KEYFLEX_ID);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
    END IF;
  END IF;
  ---------------------------Begin of Update Assignments Criteria------------------------------
  BEGIN
    fnd_file.put_line(fnd_file.log,'starting update_emp_asg_criteria');
    /*#########################################################################
    ------------------------< Code to get version number >----------
    ##########################################################################*/
    BEGIN
      SELECT MAX (object_version_number)
      INTO l_OBJECT_VERSION_NUMBER
      FROM per_all_assignments_f
      WHERE 1           = 1
      AND assignment_id = L_ASSIGNMENT_ID;
      --AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE)) ;
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'In Exception while getting Object Version Number in Update_emp_asg Criteria:'||LN_OBJECT_NUMBER);
    END;
    fnd_file.put_line(fnd_file.log,'object Version number:'||l_OBJECT_VERSION_NUMBER);
    fnd_file.put_line(fnd_file.log,'Grade Id:'||P_HR_EMP_REC.NEW_GRADE_ID);
    fnd_file.put_line(fnd_file.log,'Position Id:'||l_POSITION_ID);
    fnd_file.put_line(fnd_file.log,'JOB_ID:'||P_HR_EMP_REC.NEW_JOB_ID);
    fnd_file.put_line(fnd_file.log,'P PAYROLL ID:'||P_HR_EMP_REC.NEW_PAYROLL_ID);
    fnd_file.put_line(fnd_file.log,'P_LOCATION_ID:'||P_HR_EMP_REC.NEW_LOCATION_ID);
    fnd_file.put_line(fnd_file.log,'Organization_ID:'||P_HR_EMP_REC.NEW_ORGANIZATION_ID);
    fnd_file.put_line(fnd_file.log,'PAY_BASIS_ID:'||P_HR_EMP_REC.NEW_PAY_BASIS_ID);
    fnd_file.put_line(fnd_file.log,'NEW_ASSG_CAT:'||P_HR_EMP_REC.NEW_ASSG_CAT);
    fnd_file.put_line(fnd_file.log,'P_HR_EMP_REC.NEW_SUPERVISOR_ID:'||P_HR_EMP_REC.NEW_SUPERVISOR_ID);
    fnd_file.put_line(fnd_file.log,'P_SOFT_CODING_KEYFLEX_ID:'||L_SOFT_CODING_KEYFLEX_ID);
    fnd_file.put_line(fnd_file.log,'L_CONCATENATED_SEGMENTS:'||L_CONCATENATED_SEGMENTS);
    IF g_error=0 AND p_hr_emp_rec.NEW_BUSINESS_GROUP ='BG_US' THEN
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG_CRITERIA(P_VALIDATE => L_VALIDATE , P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.offer_actual_start_date, sysdate) , P_DATETRACK_UPDATE_MODE => L_DATETRACK_UPDATE_MODE , P_CALLED_FROM_MASS_UPDATE => L_CALLED_FROM_MASS_UPDATE , P_ASSIGNMENT_ID => L_ASSIGNMENT_ID , P_OBJECT_VERSION_NUMBER => l_OBJECT_VERSION_NUMBER , P_GRADE_ID =>P_HR_EMP_REC.NEW_GRADE_ID,--9091, --48082, --9091->US, --L_grade_id,  hard coded the values as,there is no combination
      P_POSITION_ID => L_POSITION_ID , P_JOB_ID =>P_HR_EMP_REC.NEW_JOB_ID,                                                                                                                                                                                                                                                                                                                         --51351,                                                                                                                                                                                                                                                                                     --369286,    --51351->US                                                                                                                                                                                                                                                                                 --51351, --P_JOB_ID ,
      P_PAYROLL_ID => P_HR_EMP_REC.NEW_PAYROLL_ID , P_LOCATION_ID => P_HR_EMP_REC.NEW_LOCATION_ID , P_SPECIAL_CEILING_STEP_ID => L_SPECIAL_CEILING_STEP_ID , P_ORGANIZATION_ID =>P_HR_EMP_REC.NEW_ORGANIZATION_ID, P_PAY_BASIS_ID => P_HR_EMP_REC.NEW_PAY_BASIS_ID ,
      --Added
      P_EMPLOYMENT_CATEGORY => P_HR_EMP_REC.NEW_ASSG_CAT, P_CONCAT_SEGMENTS => L_CONCAT_SEGMENTS , P_GRADE_LADDER_PGM_ID => L_GRADE_LADDER_PGM_ID , P_SUPERVISOR_ASSIGNMENT_ID => L_SUPERVISOR_ASSIGNMENT_ID ,
      --P_EMPLOYMENT_CATEGORY => P_EMPLOYMENT_CATEGORY ,
      P_CONTRACT_ID => L_CONTRACT_ID , P_ESTABLISHMENT_ID => L_ESTABLISHMENT_ID , P_SCL_SEGMENT1 => L_SCL_SEGMENT1 , P_GROUP_NAME =>L_GROUP_NAME, --L_GROUP_NAME , --P_GROUP_NAME , --
      P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE,                                                                                            --P_HR_EMP_REC.offer_actual_start_date ,
      P_EFFECTIVE_END_DATE => L_EFFECTIVE_END_DATE , P_PEOPLE_GROUP_ID =>l_PEOPLE_GROUP_ID,                                                       -- L_PEOPLE_GROUP_ID , --
      P_ORG_NOW_NO_MANAGER_WARNING => L_ORG_NOW_NO_MANAGER_WARNING , P_OTHER_MANAGER_WARNING =>L_OTHER_MANAGER_WARNING , P_SPP_DELETE_WARNING => L_SPP_DELETE_WARNING , P_ENTRIES_CHANGED_WARNING => L_ENTRIES_CHANGED_WARNING , P_TAX_DISTRICT_CHANGED_WARNING => L_TAX_DISTRICT_CHANGED_WARNING , P_SOFT_CODING_KEYFLEX_ID => L_SOFT_CODING_KEYFLEX_ID , P_CONCATENATED_SEGMENTS => L_CONCATENATED_SEGMENTS , p_gsp_post_process_warning => l_gsp_post_process_warning ) ;
      P_ERR_MSG:=NULL; --July-8th
    ELSE
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG_CRITERIA(P_VALIDATE => L_VALIDATE , P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate) ,P_DATETRACK_UPDATE_MODE => L_DATETRACK_UPDATE_MODE , P_CALLED_FROM_MASS_UPDATE => L_CALLED_FROM_MASS_UPDATE , P_ASSIGNMENT_ID => L_ASSIGNMENT_ID , P_OBJECT_VERSION_NUMBER => l_OBJECT_VERSION_NUMBER , P_GRADE_ID =>P_HR_EMP_REC.NEW_GRADE_ID,--48082, --9091->US, --L_grade_id,  hard coded the values as,there is no combination
      P_POSITION_ID => L_POSITION_ID , P_JOB_ID =>P_HR_EMP_REC.NEW_JOB_ID,                                                                                                                                                                                                                                                                                                                       --369286,                                                                                                                                                                                                                                                                                     --51351->US                                                                                                                                                                                                                                                                                 --51351, --P_JOB_ID ,
      P_PAYROLL_ID => P_HR_EMP_REC.NEW_PAYROLL_ID , P_LOCATION_ID => P_HR_EMP_REC.NEW_LOCATION_ID , P_SPECIAL_CEILING_STEP_ID => L_SPECIAL_CEILING_STEP_ID , P_ORGANIZATION_ID =>P_HR_EMP_REC.NEW_ORGANIZATION_ID, P_PAY_BASIS_ID => P_HR_EMP_REC.NEW_PAY_BASIS_ID ,
      --Added
      P_EMPLOYMENT_CATEGORY => P_HR_EMP_REC.NEW_ASSG_CAT, P_CONCAT_SEGMENTS => L_CONCAT_SEGMENTS , P_GRADE_LADDER_PGM_ID => L_GRADE_LADDER_PGM_ID , P_SUPERVISOR_ASSIGNMENT_ID => L_SUPERVISOR_ASSIGNMENT_ID ,
      --P_EMPLOYMENT_CATEGORY => P_EMPLOYMENT_CATEGORY ,
      P_CONTRACT_ID => L_CONTRACT_ID , P_ESTABLISHMENT_ID => L_ESTABLISHMENT_ID , P_SCL_SEGMENT1 => L_SCL_SEGMENT1 , P_GROUP_NAME =>L_GROUP_NAME, --L_GROUP_NAME , --P_GROUP_NAME , --
      P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE,                                                                                            --P_HR_EMP_REC.offer_actual_start_date ,
      P_EFFECTIVE_END_DATE => L_EFFECTIVE_END_DATE , P_PEOPLE_GROUP_ID =>l_PEOPLE_GROUP_ID,                                                       -- L_PEOPLE_GROUP_ID , --
      P_ORG_NOW_NO_MANAGER_WARNING => L_ORG_NOW_NO_MANAGER_WARNING , P_OTHER_MANAGER_WARNING =>L_OTHER_MANAGER_WARNING , P_SPP_DELETE_WARNING => L_SPP_DELETE_WARNING , P_ENTRIES_CHANGED_WARNING => L_ENTRIES_CHANGED_WARNING , P_TAX_DISTRICT_CHANGED_WARNING => L_TAX_DISTRICT_CHANGED_WARNING , P_SOFT_CODING_KEYFLEX_ID => L_SOFT_CODING_KEYFLEX_ID , P_CONCATENATED_SEGMENTS => L_CONCATENATED_SEGMENTS , p_gsp_post_process_warning => l_gsp_post_process_warning ) ;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'In assignments criteria, L_SOFT_CODING_KEYFLEX_ID :'||L_SOFT_CODING_KEYFLEX_ID);
      P_ERR_MSG:=NULL; --July-8th
    END IF;
    --end if;
  EXCEPTION
  WHEN OTHERS THEN
    --COMMIT;
    fnd_file.put_line(fnd_file.log,'In Exception in assignments Criteria:'||SQLERRM);
    g_error  :=1;
    P_ERR_MSG:=sqlerrm; --July-8th
  END;
  ---------------------------End of Update Assignments Criteria--------------------------------
EXCEPTION
WHEN OTHERS THEN
  --COMMIT;
  fnd_file.put_line(fnd_file.log,'In Exception in Assignments:'||SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END CREATE_EMP_ASGNMNT;
/*#########################################################################
------------------------< Create Contingent Assignments >----------------------
##########################################################################*/
PROCEDURE Create_Contingent_asgnmnt(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_api_mode   IN VARCHAR2,
    p_err_msg OUT VARCHAR2)
IS
  -- Local Variables
  -- -----------------------
  L_API_MODE       VARCHAR2(200);
  L_ASSIGNMENT_ID  NUMBER ;
  LN_OBJECT_NUMBER NUMBER;
  --l_object_version_number      NUMBER;
  l_ASSIGNMENT_STATUS_TYPE_ID  NUMBER := 1;
  L_CAGR_GRADE_DEF_ID          NUMBER;
  L_CAGR_CONCATENATED_SEGMENTS VARCHAR2 (100);
  l_gsp_post_process_warning   VARCHAR2 (30);
  -- Out Variables for Find Date Track Mode API
  -- -----------------------------------------------------------------
  lb_correction           BOOLEAN;
  lb_update               BOOLEAN;
  lb_update_override      BOOLEAN;
  lb_update_change_insert BOOLEAN;
  -- Out Variables for Update Employee Assignment API
  -- ----------------------------------------------------------------------------
  ln_soft_coding_keyflex_id hr_soft_coding_keyflex.soft_coding_keyflex_id%TYPE;
  lc_concatenated_segments VARCHAR2(2000);
  ln_comment_id per_all_assignments_f.comment_id%TYPE;
  lb_no_managers_warning BOOLEAN;
  -- Out Variables for Update Employee Assgment Criteria
  -- -------------------------------------------------------------------------------
  ln_special_ceiling_step_id per_all_assignments_f.special_ceiling_step_id%TYPE;
  -- l_group_name VARCHAR2(30);
  ld_effective_start_date per_all_assignments_f.effective_start_date%TYPE;
  ld_effective_end_date per_all_assignments_f.effective_end_date%TYPE;
  lb_org_now_no_manager_warning BOOLEAN;
  lb_other_manager_warning      BOOLEAN;
  lb_spp_delete_warning         BOOLEAN;
  lc_entries_changed_warning    VARCHAR2(30);
  lb_tax_district_changed_warn  BOOLEAN;
  L_ERR_MSG                     VARCHAR2 (280);
  l_probation_units             VARCHAR2(30);
  l_probation                   NUMBER;
  L_ASS_ATTRIBUTE1              NUMBER;
  L_count                       NUMBER      := 0;
  l_err_flag                    VARCHAR2(1) := 'N';
  l_segment1                    NUMBER;
  l_set_of_books_id             NUMBER;
  -------------Local Variables for Assignments Criteria-------------------
  L_EFFECTIVE_DATE          DATE          := SYSDATE;
  L_DATETRACK_UPDATE_MODE   VARCHAR2(200) := 'CORRECTION';
  L_VALIDATE                BOOLEAN       := FALSE;
  L_CALLED_FROM_MASS_UPDATE BOOLEAN       := NULL;
  L_POSITION_ID             NUMBER        := NULL;
  --P_ORGANIZATION_ID            NUMBER        := l_organization_id;
  L_employment_category      VARCHAR2(200) := NULL;
  L_CONCAT_SEGMENTS          VARCHAR2(200) := NULL;
  L_CONTRACT_ID              NUMBER        := NULL;
  L_ESTABLISHMENT_ID         NUMBER        := NULL;
  L_SCL_SEGMENT1             VARCHAR2(200) := NULL;
  L_GRADE_LADDER_PGM_ID      NUMBER        := NULL;
  l_SUPERVISOR_ASSIGNMENT_ID NUMBER        := NULL;
  l_OBJECT_VERSION_NUMBER    NUMBER ;
  l_SPP_DELETE_WARNING       BOOLEAN;
  l_DISTRICT_CHANGED_WARNING BOOLEAN;
  l_effective_end_date per_all_assignments_f.effective_end_date%TYPE;
  l_effective_start_date per_all_assignments_f.effective_start_date%TYPE := SYSDATE;
  l_entries_changed_warning VARCHAR2(1)                                  := 'N';
  l_group_name pay_people_groups.group_name%TYPE;
  l_old_group_name pay_people_groups.group_name%TYPE;
  l_no_managers_warning        BOOLEAN;
  l_org_now_no_manager_warning BOOLEAN;
  l_other_manager_warning      BOOLEAN;
  l_hourly_salaried_warning    BOOLEAN;
  l_people_group_id per_all_assignments_f.people_group_id%TYPE;
  l_special_ceiling_step_id per_all_assignments_f.special_ceiling_step_id%TYPE;-- := p_special_ceiling_step_id;
  l_tax_district_changed_warning BOOLEAN;
  l_flex_num fnd_id_flex_segments.id_flex_num%TYPE;
  --
  l_api_updating BOOLEAN;
  L_Person_Type_id per_all_assignments_f.business_group_id%TYPE;
  l_comment_id per_all_assignments_f.comment_id%TYPE;
  l_entries_changed VARCHAR2(1);
  l_legislation_code per_business_groups.legislation_code%TYPE;
  l_new_payroll_id per_all_assignments_f.payroll_id%TYPE;
  L_PROC VARCHAR2(72) :='hr_assignment_api.update_emp_asg_criteria';
  L_SOFT_CODING_KEYFLEX_ID per_all_assignments_f.soft_coding_keyflex_id%TYPE;
  l_concatenated_segments hr_soft_coding_keyflex.concatenated_segments%TYPE;
  l_old_conc_segments hr_soft_coding_keyflex.concatenated_segments%TYPE;
  L_Y          NUMBER;
  M_attribute1 VARCHAR2(300);
  M_attribute2 VARCHAR2(300);
  l_context    VARCHAR2(300);--NUMBER; --Dkantem
  l_segment2   VARCHAR2(240);
  l_start_date DATE;
  -------------End Of Local Variables for Assignments Criteria-------------------
BEGIN
  g_error := 0;
  fnd_file.put_line(fnd_file.log,'Contingent B4 UPDATE_EMP_ASG');
  --object_version_number is mandatory parameter for "HR_ASSIGNMENT_API.UPDATE_EMP_ASG" it will takes the latest number I.e last modified assignments number
  SELECT new_assignment_id
  INTO l_assignment_id
  FROM XXHA_REC_EMP_INT_STG
  WHERE transaction_id_stg = p_hr_emp_rec.transaction_id_stg;
  fnd_file.put_line(fnd_file.log,'l_assignment_id '||l_assignment_id);
  BEGIN
    SELECT MAX (object_version_number)--, effective_start_date
    INTO LN_OBJECT_NUMBER             --, l_start_date
    FROM per_all_assignments_f
    WHERE 1           = 1
    AND assignment_id = l_assignment_id--P_HR_EMP_REC.NEW_ASSIGNMENT_ID revisit
      ;
    --AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE)) ;
    SELECT MAX (effective_start_date)
    INTO l_start_date
    FROM per_all_assignments_f
    WHERE 1           = 1
    AND assignment_id = l_assignment_id--P_HR_EMP_REC.NEW_ASSIGNMENT_ID revisit
      ;
    fnd_file.put_line(fnd_file.log,'Object Version Number in Contingent Update_emp_asg:'||LN_OBJECT_NUMBER||' '||l_start_date);
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Exception while getting Object Version Number in Contingent Update_emp_asg:'||SQLERRM||LN_OBJECT_NUMBER||' '||l_start_date);
  END;
  --L_ASSIGNMENT_ID := G_ASSIGNMENT_ID;--P_HR_EMP_REC.NEW_ASSIGNMENT_ID; revisit
  fnd_file.put_line(fnd_file.log,'Object Version Number in Contingent Update_emp_asg:'||LN_OBJECT_NUMBER);
  ------------------- For Requisition Udf 6, to update the shift value------------------------
  BEGIN
    IF p_hr_emp_rec.NEW_BUSINESS_GROUP ='BG_US' THEN
      L_ASS_ATTRIBUTE1                :=1;
      fnd_file.put_line(fnd_file.log,'L_ASS_ATTRIBUTE1:'||L_ASS_ATTRIBUTE1);
    ELSE
      L_ASS_ATTRIBUTE1 :=NULL;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'In Contingent Exception of getting shift value for US:'||L_ASS_ATTRIBUTE1);
  END;
  ---- Added Dkantem, To get Assignment Attribute category value based on Business group
  BEGIN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_ASSIGNMENTS'
    AND descriptive_flex_context_name =p_hr_emp_rec.NEW_BUSINESS_GROUP --p_hr_emp_rec.L_BUSINESS_GROUP
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'l_context:'||l_context);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_ASSIGNMENTS'
    AND descriptive_flex_context_name ='Global Data Elements'
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'Contingent l_context in nodatafound:'||l_context);
  WHEN OTHERS THEN
    SELECT DISTINCT descriptive_flex_context_code
    INTO l_context
    FROM fnd_descr_flex_contexts_tl
    WHERE descriptive_flexfield_name LIKE 'PER_ASSIGNMENTS'
    AND descriptive_flex_context_name ='Global Data Elements'
    AND source_lang                   = USERENV('LANG');
    fnd_file.put_line(fnd_file.log,'Contingent l_context in nodatafound:'||l_context);
    fnd_file.put_line(fnd_file.log,'Contingent Exception while getting Attribute category value:'||sqlerrm);
  END;
  IF p_hr_emp_rec.NEW_BUSINESS_GROUP ='BG_AU' THEN
    l_segment2                      := 'N';
  ELSE
    l_segment2 := NULL;
  END IF;
  fnd_file.put_line(fnd_file.log,'In Contingent HR_ASSIGNMENT_API.UPDATE_EMP_ASG Api:');
  L_API_MODE := 'CORRECTION';
  IF g_error  =0 THEN
    fnd_file.put_line(fnd_file.log,'In Contingent HR_ASSIGNMENT_API.UPDATE_EMP_ASG Api: 1 '||P_HR_EMP_REC.OFFER_ACTUAL_START_DATE);
    IF P_HR_EMP_REC.NEW_LEGAL_ENTITY_ID IS NOT NULL THEN                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     --NEW_LEGAL_ENTITY_ID
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG (P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate),                                                                                                                                                                                                                                                                                                                                                                                                                         --SYSDATE, revisit
      P_DATETRACK_UPDATE_MODE => L_API_MODE, P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_OBJECT_VERSION_NUMBER => LN_OBJECT_NUMBER, p_supervisor_id => P_HR_EMP_REC.NEW_SUPERVISOR_ID, P_ASS_ATTRIBUTE1 =>L_ASS_ATTRIBUTE1, P_ASS_ATTRIBUTE_CATEGORY=>l_context, p_cagr_grade_def_id => l_cagr_grade_def_id, p_cagr_concatenated_segments => l_cagr_concatenated_segments, p_concatenated_segments => l_concatenated_segments, p_soft_coding_keyflex_id =>l_SOFT_CODING_KEYFLEX_ID, p_comment_id => l_comment_id, P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE, --P_HR_EMP_REC.offer_actual_start_date,
      p_effective_end_date => l_effective_end_date, P_NO_MANAGERS_WARNING => L_NO_MANAGERS_WARNING, P_OTHER_MANAGER_WARNING => L_OTHER_MANAGER_WARNING, p_hourly_salaried_warning => l_hourly_salaried_warning, p_gsp_post_process_warning => l_gsp_post_process_warning );
      fnd_file.put_line(fnd_file.log,'Contingent l_concatenated_segments : '||l_concatenated_segments);
      fnd_file.put_line(fnd_file.log,'Contingent Soft coding keyflex id : '||L_SOFT_CODING_KEYFLEX_ID);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
    ELSE
      fnd_file.put_line(fnd_file.log,'In Contingent  HR_ASSIGNMENT_API.UPDATE_EMP_ASG Api: 2 '||P_HR_EMP_REC.OFFER_ACTUAL_START_DATE);
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG (P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdatE),                                                                                                                                                                                                                                                                                                                                               --'12-Jul-15', --to_date('dd-mon-yy')--                                                                                                                                                                                                                                                                                                                                                                                                               --SYSDATE, revisit
      P_DATETRACK_UPDATE_MODE => L_API_MODE, P_ASSIGNMENT_ID => L_ASSIGNMENT_ID, P_OBJECT_VERSION_NUMBER => LN_OBJECT_NUMBER, p_supervisor_id => P_HR_EMP_REC.NEW_SUPERVISOR_ID, p_cagr_grade_def_id => l_cagr_grade_def_id, p_cagr_concatenated_segments => l_cagr_concatenated_segments, p_concatenated_segments => l_concatenated_segments, p_soft_coding_keyflex_id =>L_SOFT_CODING_KEYFLEX_ID, p_comment_id => l_comment_id, P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE, --P_HR_EMP_REC.offer_actual_start_date,
      p_effective_end_date => l_effective_end_date, P_NO_MANAGERS_WARNING => L_NO_MANAGERS_WARNING, P_OTHER_MANAGER_WARNING => L_OTHER_MANAGER_WARNING, p_hourly_salaried_warning => l_hourly_salaried_warning, p_gsp_post_process_warning => l_gsp_post_process_warning );
      fnd_file.put_line(fnd_file.log,'Contingent l_concatenated_segments : '||l_concatenated_segments);
      fnd_file.put_line(fnd_file.log,'Contingent Soft coding keyflex id : '||L_SOFT_CODING_KEYFLEX_ID);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
    END IF;
  END IF;
  ---------------------------Begin of Update Assignments Criteria------------------------------
  BEGIN
    fnd_file.put_line(fnd_file.log,'starting Contingent update_emp_asg_criteria');
    /*#########################################################################
    ------------------------< Code to get version number >----------
    ##########################################################################*/
    BEGIN
      SELECT MAX (object_version_number)
      INTO l_OBJECT_VERSION_NUMBER
      FROM per_all_assignments_f
      WHERE 1           = 1
      AND assignment_id = L_ASSIGNMENT_ID;
      --AND TRUNC (SYSDATE) BETWEEN NVL (effective_start_date, TRUNC ( SYSDATE)) AND NVL (effective_end_date, TRUNC (SYSDATE)) ;
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'In Exception while getting Object Version Number in Contingent Update_emp_asg Criteria:'||LN_OBJECT_NUMBER);
    END;
    fnd_file.put_line(fnd_file.log,'Contingent object Version number:'||l_OBJECT_VERSION_NUMBER);
    fnd_file.put_line(fnd_file.log,'Contingent JOB_ID:'||P_HR_EMP_REC.NEW_JOB_ID);
    fnd_file.put_line(fnd_file.log,'Contingent P_LOCATION_ID:'||P_HR_EMP_REC.NEW_LOCATION_ID);
    fnd_file.put_line(fnd_file.log,'Contingent Organization_ID:'||P_HR_EMP_REC.NEW_ORGANIZATION_ID);
    fnd_file.put_line(fnd_file.log,'Contingent NEW_ASSG_CAT:'||P_HR_EMP_REC.NEW_ASSG_CAT);
    fnd_file.put_line(fnd_file.log,'Contingent P_HR_EMP_REC.NEW_SUPERVISOR_ID:'||P_HR_EMP_REC.NEW_SUPERVISOR_ID);
    fnd_file.put_line(fnd_file.log,'Contingent P_SOFT_CODING_KEYFLEX_ID:'||L_SOFT_CODING_KEYFLEX_ID);
    fnd_file.put_line(fnd_file.log,'Contingent L_CONCATENATED_SEGMENTS:'||L_CONCATENATED_SEGMENTS);
    IF g_error=0 AND p_hr_emp_rec.NEW_BUSINESS_GROUP ='BG_US' THEN
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG_CRITERIA(P_VALIDATE => L_VALIDATE , P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.offer_actual_start_date, sysdate) , P_DATETRACK_UPDATE_MODE => L_DATETRACK_UPDATE_MODE , P_CALLED_FROM_MASS_UPDATE => L_CALLED_FROM_MASS_UPDATE , P_ASSIGNMENT_ID => L_ASSIGNMENT_ID , P_OBJECT_VERSION_NUMBER => l_OBJECT_VERSION_NUMBER , P_JOB_ID =>P_HR_EMP_REC.NEW_JOB_ID,      --51351,                                                                                                                                                                                                                                                                                     --369286,    --51351->US                                                                                                                                                                                                                                                                                 --51351, --P_JOB_ID ,
      P_LOCATION_ID => P_HR_EMP_REC.NEW_LOCATION_ID , P_SPECIAL_CEILING_STEP_ID => L_SPECIAL_CEILING_STEP_ID , P_ORGANIZATION_ID =>P_HR_EMP_REC.NEW_ORGANIZATION_ID, P_EMPLOYMENT_CATEGORY => P_HR_EMP_REC.NEW_ASSG_CAT, P_SUPERVISOR_ASSIGNMENT_ID => L_SUPERVISOR_ASSIGNMENT_ID , P_SCL_SEGMENT1 => L_SCL_SEGMENT1 , P_GROUP_NAME =>L_GROUP_NAME, P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE, --P_HR_EMP_REC.offer_actual_start_date ,
      P_EFFECTIVE_END_DATE => L_EFFECTIVE_END_DATE , P_PEOPLE_GROUP_ID =>l_PEOPLE_GROUP_ID, P_ORG_NOW_NO_MANAGER_WARNING => L_ORG_NOW_NO_MANAGER_WARNING , P_OTHER_MANAGER_WARNING =>L_OTHER_MANAGER_WARNING , P_SPP_DELETE_WARNING => L_SPP_DELETE_WARNING , P_ENTRIES_CHANGED_WARNING => L_ENTRIES_CHANGED_WARNING , P_TAX_DISTRICT_CHANGED_WARNING => L_TAX_DISTRICT_CHANGED_WARNING , P_SOFT_CODING_KEYFLEX_ID => L_SOFT_CODING_KEYFLEX_ID , P_CONCATENATED_SEGMENTS => L_CONCATENATED_SEGMENTS , p_gsp_post_process_warning => l_gsp_post_process_warning ) ;
      P_ERR_MSG:=NULL; --July-8th
    ELSE
      HR_ASSIGNMENT_API.UPDATE_EMP_ASG_CRITERIA(P_VALIDATE => L_VALIDATE , P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate) , P_DATETRACK_UPDATE_MODE => L_DATETRACK_UPDATE_MODE , P_CALLED_FROM_MASS_UPDATE => L_CALLED_FROM_MASS_UPDATE , P_ASSIGNMENT_ID => L_ASSIGNMENT_ID , P_OBJECT_VERSION_NUMBER => l_OBJECT_VERSION_NUMBER , P_GRADE_ID =>P_HR_EMP_REC.NEW_GRADE_ID, P_POSITION_ID => L_POSITION_ID , P_JOB_ID =>P_HR_EMP_REC.NEW_JOB_ID, --369286,                                                                                                                                                                                                                                                                                     --51351->US
      --51351, --P_JOB_ID ,
      P_PAYROLL_ID => P_HR_EMP_REC.NEW_PAYROLL_ID , P_LOCATION_ID => P_HR_EMP_REC.NEW_LOCATION_ID , P_SPECIAL_CEILING_STEP_ID => L_SPECIAL_CEILING_STEP_ID , P_ORGANIZATION_ID =>P_HR_EMP_REC.NEW_ORGANIZATION_ID, P_EMPLOYMENT_CATEGORY => P_HR_EMP_REC.NEW_ASSG_CAT, P_SUPERVISOR_ASSIGNMENT_ID => L_SUPERVISOR_ASSIGNMENT_ID , P_CONTRACT_ID => L_CONTRACT_ID , P_ESTABLISHMENT_ID => L_ESTABLISHMENT_ID , P_SCL_SEGMENT1 => L_SCL_SEGMENT1 , P_GROUP_NAME =>L_GROUP_NAME, --L_GROUP_NAME , --P_GROUP_NAME , --
      P_EFFECTIVE_START_DATE =>L_EFFECTIVE_START_DATE,                                                                                                                                                                                                                                                                                                                                                                                                                        --P_HR_EMP_REC.offer_actual_start_date ,
      P_EFFECTIVE_END_DATE => L_EFFECTIVE_END_DATE , P_PEOPLE_GROUP_ID =>l_PEOPLE_GROUP_ID,                                                                                                                                                                                                                                                                                                                                                                                   -- L_PEOPLE_GROUP_ID , --
      P_ORG_NOW_NO_MANAGER_WARNING => L_ORG_NOW_NO_MANAGER_WARNING , P_OTHER_MANAGER_WARNING =>L_OTHER_MANAGER_WARNING , P_SPP_DELETE_WARNING => L_SPP_DELETE_WARNING , P_ENTRIES_CHANGED_WARNING => L_ENTRIES_CHANGED_WARNING , P_TAX_DISTRICT_CHANGED_WARNING => L_TAX_DISTRICT_CHANGED_WARNING , P_SOFT_CODING_KEYFLEX_ID => L_SOFT_CODING_KEYFLEX_ID , P_CONCATENATED_SEGMENTS => L_CONCATENATED_SEGMENTS , p_gsp_post_process_warning => l_gsp_post_process_warning ) ;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'In Contingent assignments criteria, L_SOFT_CODING_KEYFLEX_ID :'||L_SOFT_CODING_KEYFLEX_ID);
      P_ERR_MSG:=NULL; --July-8th
    END IF;
    --end if;
  EXCEPTION
  WHEN OTHERS THEN
    --COMMIT;
    fnd_file.put_line(fnd_file.log,'In Exception in contingent assignments Criteria:'||SQLERRM);
    g_error  :=1;
    P_ERR_MSG:=sqlerrm; --July-8th
  END;
  ---------------------------End of Update Assignments Criteria--------------------------------
EXCEPTION
WHEN OTHERS THEN
  --COMMIT;
  fnd_file.put_line(fnd_file.log,'In Exception in Contingent Assignments:'||SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END Create_Contingent_asgnmnt;
/*#########################################################################
------------------------< CREATE EMPLOYEEADDRESS >-------------------------
##########################################################################*/
PROCEDURE Create_employee_address(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG% ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  l_address_id per_addresses.address_id%TYPE;
  L_OBJECT_VERSION_NUMBER PER_ADDRESSES.OBJECT_VERSION_NUMBER%TYPE;
  L_STYLE       VARCHAR2(30);
  L_COUNTY_NAME VARCHAR2(30);
  L_count       NUMBER      := 0;
  l_err_flag    VARCHAR2(1) := 'N';
  l_err_msg     VARCHAR2(2000);
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  l_person_id NUMBER;
  l_Addr      NUMBER;
  l_obj       NUMBER;
  l_state     VARCHAR2(240);
  CURSOR addr(ip_person_id IN NUMBER)
  IS
    SELECT *
    FROM per_addresses
    WHERE person_id  = ip_person_id
    AND date_to     IS NULL
    AND primary_flag = 'Y';
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  SELECT new_person_id
  INTO l_person_id
  FROM XXHA_REC_EMP_INT_STG
  WHERE TRANSACTION_ID_STG = p_hr_emp_rec.TRANSACTION_ID_STG;
  Fnd_File.Put_Line(Fnd_File.Log,'In Address - Person ID '||l_person_id);
  --- check if Address already exists
  SELECT COUNT(1)
  INTO l_addr
  FROM per_addresses
  WHERE person_id   = l_person_id
  AND address_line1 = P_HR_EMP_REC.address
  AND address_line2 = P_HR_EMP_REC.address2
  AND country       = P_HR_EMP_REC.c_country_abb
  AND postal_code   = P_HR_EMP_REC.zip_code
    --and town_or_city
    --and region_1
  AND date_to     IS NULL
  AND primary_flag = 'Y';
  Fnd_File.Put_Line(Fnd_File.Log,'In Address - l_addr '||l_addr);
  IF l_addr = 0 THEN
    FOR addr_rec IN addr (l_person_id)
    LOOP
      l_obj := addr_rec.object_version_number;
      Fnd_File.Put_Line(Fnd_File.Log,'In Address - Before Address End date '||addr_rec.address_id||' '||l_obj);
      hr_person_address_api.update_person_address (p_validate => false ,p_effective_date => NVL(P_HR_EMP_REC.offer_actual_start_Date, sysdate)
      --,p_validate_county               in     boolean  default true
      ,p_address_id => addr_rec.address_id , p_object_version_number => l_obj , p_date_from => addr_rec.date_from , p_date_to => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate)-1--rec_addr.date_to
      -- Start of fix for Bug #2431588
      ,p_primary_flag => addr_rec.primary_flag--'N'
      -- End of fix for Bug #2431588
      ,p_address_type => addr_rec.address_type , p_comments => addr_rec.comments , p_address_line1 => addr_rec.address_line1 , p_address_line2 => addr_rec.address_line2 , p_address_line3 => addr_rec.address_line3 , p_town_or_city => addr_rec.town_or_city , p_region_1 => addr_rec.region_1 , p_region_2 => addr_rec.region_2 , p_region_3 => addr_rec.region_3 , p_postal_code => addr_rec.postal_code , p_country => addr_rec.country , p_party_id => addr_rec.party_id );
      Fnd_File.Put_Line(Fnd_File.Log,'In Address - Address End dated '||addr_rec.address_id||' '||l_obj);
    END LOOP;
    --Address Style
    BEGIN
      SELECT DESCRIPTIVE_FLEX_CONTEXT_CODE
      INTO L_STYLE
      FROM fnd_descr_flex_contexts_tl
      WHERE DESCRIPTIVE_FLEXFIELD_NAME  = 'Address Location'
      AND language                      = USERENV('LANG')
      AND DESCRIPTIVE_FLEX_CONTEXT_CODE = P_HR_EMP_REC.C_COUNTRY_ABB;
      Fnd_File.Put_Line(Fnd_File.Log,'Address Style '||L_STYLE);
    EXCEPTION
    WHEN no_data_found THEN
      SELECT DESCRIPTIVE_FLEX_CONTEXT_CODE
      INTO L_STYLE
      FROM fnd_descr_flex_contexts_tl
      WHERE DESCRIPTIVE_FLEXFIELD_NAME  = 'Address Location'
      AND language                      = USERENV('LANG')
      AND DESCRIPTIVE_FLEX_CONTEXT_CODE = P_HR_EMP_REC.C_COUNTRY_ABB
        ||'_GLB';
      Fnd_File.Put_Line(Fnd_File.Log,'Address Style 1 '||L_STYLE);
    END;
    /* IF P_HR_EMP_REC.C_COUNTRY_ABB = 'US' THEN
    SELECT B.COUNTY_NAME
    INTO L_COUNTY_NAME
    FROM pay_us_city_names a,
    pay_us_counties b,
    pay_us_states c,
    pay_us_zip_codes z
    WHERE a.state_code = c.state_code
    AND a.county_code  = b.county_code
    AND b.state_code   = c.state_code
    AND a.city_code    =z.city_code
    AND a.state_code   =z.state_code
    AND c.state_code   = z.state_code
    AND b.county_code  = Z.COUNTY_CODE
    AND A.COUNTY_CODE  =Z.COUNTY_CODE
    AND P_HR_EMP_REC.ZIP_CODE BETWEEN Z.ZIP_START AND z.zip_end
    AND (A.DISABLE = 'N'
    OR A.DISABLE  IS NULL)
    --AND rownum     =1
    ORDER BY A.CITY_NAME,
    C.STATE_ABBREV,
    Z.ZIP_START;
    END IF;*/
    -- L_STYLE := P_HR_EMP_REC.C_COUNTRY_ABB; -- DK
    -- Create Employee Adress for US
    -- --------------------------------------
    IF g_error=0 AND P_HR_EMP_REC.C_COUNTRY_ABB = 'US' OR L_STYLE = 'US' THEN
      HR_PERSON_ADDRESS_API.CREATE_US_PERSON_ADDRESS ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_DATE_TO => TO_DATE (NULL)                                                     --,P_ADDRESS_TYPE                  =>     'PHCA' --Primary Home Country Address
      , P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, P_ADDRESS_LINE2 => p_hr_emp_rec.address2, P_ADDRESS_LINE3 => '', P_CITY => P_HR_EMP_REC.CITY, P_STATE => P_HR_EMP_REC.C_STATE_ABB, P_ZIP_CODE => P_HR_EMP_REC.ZIP_CODE,
      --P_ZIP_CODE =>3064, --P_HR_EMP_REC.ZIP_CODE,  --Testing roll back
      P_COUNTY => P_HR_EMP_REC.NEW_COUNTY_NAME --'Norfolk'
      , P_COUNTRY => p_hr_emp_rec.C_COUNTRY_ABB
      --outs
      , P_ADDRESS_ID => L_address_id, P_OBJECT_VERSION_NUMBER => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      -- Add individual Address procedures based on the address style
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MY' THEN
      SELECT lookup_code
      INTO l_state
      FROM FND_COMMON_LOOKUPS
      WHERE LOOKUP_TYPE LIKE P_HR_EMP_REC.c_country_abb
        ||'_STATE'
      AND description                 = P_HR_EMP_REC.c_state_abb
      AND P_HR_EMP_REC.c_state_abb   IS NOT NULL
      AND P_HR_EMP_REC.c_country_abb IS NOT NULL
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      AND enabled_flag ='Y';
      HR_PERSON_ADDRESS_API.create_MY_person_address ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, P_ADDRESS_LINE2 =>P_HR_EMP_REC.ADDRESS2,
      --P_postal_CODE =>P_HR_EMP_REC.ZIP_CODE,
      P_postal_CODE => P_HR_EMP_REC.ZIP_CODE,          --Testing Roll back
      p_city => P_HR_EMP_REC.CITY, P_REGION => l_state,--P_HR_EMP_REC.C_COUNTRY_ABB||P_HR_EMP_REC.C_STATE_ABB, --
      P_COUNTRY =>p_hr_emp_rec.C_COUNTRY_ABB,
      --outs
      P_ADDRESS_ID => L_address_id, P_OBJECT_VERSION_NUMBER => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'MX' THEN
      SELECT lookup_code
      INTO l_state
      FROM FND_COMMON_LOOKUPS
      WHERE LOOKUP_TYPE LIKE P_HR_EMP_REC.c_country_abb
        ||'_STATE'
      AND description                 = P_HR_EMP_REC.c_state_abb
      AND P_HR_EMP_REC.c_state_abb   IS NOT NULL
      AND P_HR_EMP_REC.c_country_abb IS NOT NULL
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      AND enabled_flag ='Y';
      HR_PERSON_ADDRESS_API.CREATE_MX_PERSON_ADDRESS ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_DATE_TO => TO_DATE (NULL)                                                      --,P_ADDRESS_TYPE                  =>     'PHCA' --Primary Home Country Address
      ,P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, P_ADDRESS_LINE2 => P_HR_EMP_REC.ADDRESS2, P_ADDRESS_LINE3 => '', P_CITY => P_HR_EMP_REC.CITY, P_STATE => l_state,               --P_HR_EMP_REC.C_STATE_ABB,
      P_postal_CODE => P_HR_EMP_REC.ZIP_CODE, P_COUNTRY => p_hr_emp_rec.C_COUNTRY_ABB
      --outs
      , P_ADDRESS_ID => L_address_id, P_OBJECT_VERSION_NUMBER => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'CA' THEN
      hr_person_address_api.create_person_address ( P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE, P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate),
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2,
      --P_ADDRESS_LINE3 => 'Edmonton Centre',
      p_town_or_city => P_HR_EMP_REC.CITY, p_region_1 => P_HR_EMP_REC.C_STATE_ABB, p_postal_code => P_HR_EMP_REC.ZIP_CODE,
      --                                            P_COUNTY => 'Alberta' ,
      p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
    elsif L_STYLE='AT_GLB' THEN
      hr_person_address_api.create_AT_person_address (-- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, -- P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      --------------------------------AU - Australia---------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'AU' THEN
      hr_person_address_api.create_AU_person_address (-- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, p_city => P_HR_EMP_REC.CITY, P_STATE => P_HR_EMP_REC.C_STATE_ABB, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      -----------------------------------DE----------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'DE' THEN
      hr_person_address_api.create_DE_person_address (-- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY,
      --p_region
      p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      ---------------------------Italy IT----------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'IT' THEN
      hr_person_address_api.create_IT_person_address (-- Input data elements
      -- ------------------------------
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y',
      --            P_STYLE => 'MY_GLB',
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE,
      --p_province
      p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      ------------------------------------------- BE = Belgium ----------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'BE' THEN
      hr_person_address_api.create_BE_person_address (                                                                         -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y',
      --            P_STYLE => 'MY_GLB',
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      ------------------------------------------- HK = hong kong ----------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'HK' THEN
      hr_person_address_api.create_HK_person_address (                                                                         -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2,
      --P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE,
      --p_city => P_HR_EMP_REC.CITY,
      p_district => P_HR_EMP_REC.C_STATE_ABB, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      ------------------------------------------- NL = Netherland ----------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'NL' THEN
      hr_person_address_api.create_NL_person_address (                                                                        -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY,
      --p_region
      p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      ------------------------------------------- SE = Sweden ----------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'SE' THEN
      hr_person_address_api.create_SE_person_address (                                                                        -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, P_POSTAL_CODE => P_HR_EMP_REC.ZIP_CODE, p_city => P_HR_EMP_REC.CITY, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => L_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = L_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| L_address_id);
      ------------------------------------------- GB = Great Britain ----------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'GB' THEN
      hr_person_address_api.create_GB_person_address (                                                                        -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,-- P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, p_town => P_HR_EMP_REC.C_STATE_ABB, p_county => L_COUNTY_NAME, P_POSTCODE => P_HR_EMP_REC.ZIP_CODE,
      -- p_city => P_HR_EMP_REC.CITY,
      p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      ------------------------------------- FR = France ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'FR' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'FR', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate),
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2, p_town_or_city => P_HR_EMP_REC.CITY, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      ------------------------------------- JP = Japan ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'JP' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'JP_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate),
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 => P_HR_EMP_REC.ADDRESS, p_address_line2 => p_hr_emp_rec.address2,
      --p_town_or_city => P_HR_EMP_REC.CITY,
      p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      ------------------------------------- IN = INDIA ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'IN' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'IN_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate),
      --P_DATE_TO => TO_DATE (NULL),
      P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS,
      --p_address_line2 => p_hr_emp_rec.address2,
      --p_town_or_city => P_HR_EMP_REC.CITY,
      --p_postal_code => P_HR_EMP_REC.ZIP_CODE,
      p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  KR- Korea ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'KR' THEN
      hr_person_address_api.create_person_address (                                                                            -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate) , P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                               --'KR', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  CN- China ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'CN' THEN
      hr_person_address_api.create_person_address (                                                                          -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE,sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                             --'CN_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  TW- Taiwan ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'TW' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'TW_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.C_STATE_ABB, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  CH- ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'CH' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,--P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'CH_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.C_STATE_ABB, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      -------------------------------------- NZ- ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'NZ' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID =>l_person_id, --P_HR_EMP_REC.New_PERSON_ID,
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'CH_GLB', --
      P_DATE_FROM =>NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.C_STATE_ABB, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  SG- ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'SG' THEN
      hr_person_address_api.create_SG_person_address (                                                                      -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE =>NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE,sysdate), P_PERSON_ID =>l_person_id, --P_HR_EMP_REC.New_PERSON_ID,
      P_PRIMARY_FLAG => 'Y',
      --p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_city => P_HR_EMP_REC.CITY,
      --P_region_1 =>P_HR_EMP_REC.C_STATE_ABB,
      p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  ES- ------------------------------ Need to check this with Divya
      /* elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'ES' THEN
      hr_person_address_api.create_ES_person_address (-- Input data elements
      P_VALIDATE => FALSE,
      P_EFFECTIVE_DATE => nvl(P_HR_EMP_REC.offer_actual_start_date,sysdate),
      P_PERSON_ID =>l_person_id, --P_HR_EMP_REC.New_PERSON_ID,
      P_PRIMARY_FLAG => 'Y',
      p_style => L_STYLE, --'CH_GLB', --
      P_DATE_FROM => nvl(P_HR_EMP_REC.offer_actual_start_date,sysdate),
      --P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS,
      --p_address_line2 => P_HR_EMP_REC.address2,
      p_city => P_HR_EMP_REC.CITY,
      p_province_name =>P_HR_EMP_REC.C_STATE_ABB,
      p_postal_code => P_HR_EMP_REC.ZIP_CODE,
      p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=null; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id); */
      --------------------------------------  HU- ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'HU' THEN
      hr_person_address_api.create_person_address (                                                                            -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id, --P_HR_EMP_REC.New_PERSON_ID,
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                               --'CH_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.C_STATE_ABB, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  RU- ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'RU' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID =>l_person_id, --P_HR_EMP_REC.New_PERSON_ID,
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'CH_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.C_STATE_ABB, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  BR- ------------------------------
    elsif P_HR_EMP_REC.C_COUNTRY_ABB = 'BR' THEN
      hr_person_address_api.create_person_address (                                                                           -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID =>l_person_id, --P_HR_EMP_REC.New_PERSON_ID,
      P_PRIMARY_FLAG => 'Y', p_style => L_STYLE,                                                                              --'CH_GLB', --
      P_DATE_FROM => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.C_STATE_ABB, p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
      --------------------------------------  CZ- Chek republic ------------------------------
    ELSE
      hr_person_address_api.create_person_address (                                                                                                                                                                                    -- Input data elements
      P_VALIDATE => FALSE, P_EFFECTIVE_DATE => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_PERSON_ID => l_person_id,                                                                                                         --P_HR_EMP_REC.NEW_PERSON_ID, revisit
      P_PRIMARY_FLAG => 'Y', p_style => 'GENERIC',                                                                                                                                                                                     --L_STYLE
      P_DATE_FROM => NVL(P_HR_EMP_REC.OFFER_ACTUAL_START_DATE, sysdate), P_ADDRESS_LINE1 =>P_HR_EMP_REC.ADDRESS, p_address_line2 => P_HR_EMP_REC.address2, p_town_or_city => P_HR_EMP_REC.CITY, P_region_1 =>P_HR_EMP_REC.C_STATE_ABB, --'Brno-venkov',
      p_postal_code => P_HR_EMP_REC.ZIP_CODE, p_country => p_hr_emp_rec.C_COUNTRY_ABB,
      -- Output data elements
      -- --------------------------------
      p_address_id => l_address_id, p_object_version_number => l_object_version_number);
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
      UPDATE XXHA_REC_EMP_INT_STG
      SET NEW_ADDRESS_ID       = l_address_id
      WHERE TRANSACTION_ID_STG = l_SEQ_NO;
      --COMMIT;
      fnd_file.put_line(fnd_file.log,'p_address_id :'|| l_address_id);
    END IF;
  ELSE
    fnd_file.put_line(fnd_file.log,'Address already exists');
  END IF;
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  fnd_file.put_line(fnd_file.log,'EXCEPTION Occured in Address Creation:"'||SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END Create_employee_address;
/*#########################################################################
------------------------< Create Employee Phone Detail  >------------------
##########################################################################*/
PROCEDURE Create_emp_ph_details(
    P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE ,
    p_phone      IN VARCHAR2,
    P_phone_type IN VARCHAR2,
    p_err_msg OUT VARCHAR2)
IS
  ln_phone_id per_phones.phone_id%TYPE;
  l_object_version_number per_phones.object_version_number%TYPE;
  LS_Home_Phone   VARCHAR2(300);
  LS_Mobile_Phone VARCHAR2(300);
  l_person_id     NUMBER;
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  --Added
  SELECT new_person_id
  INTO l_person_id
  FROM XXHA_REC_EMP_INT_STG
  WHERE TRANSACTION_ID_STG = p_hr_emp_rec.TRANSACTION_ID_STG;
  Fnd_File.Put_Line(Fnd_File.Log,'In emp_ph_details - Person ID '||l_person_id);
  --Validation for Home Phone
  BEGIN
    IF P_HR_EMP_REC.HOME_PHONE IS NOT NULL THEN
      SELECT lookup_code
      INTO LS_Home_Phone
      FROM Hr_Lookups
      WHERE meaning   ='Primary'--'Home'
      AND lookup_type ='PHONE_TYPE'
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      AND enabled_flag='Y';                                                                                   --July-8th
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception occured in Validating Home'||SQLERRM);
  END;
  --Validation for Mobile Phone
  BEGIN
    IF P_HR_EMP_REC.MOBILE_PHONE IS NOT NULL THEN
      SELECT lookup_code
      INTO LS_Mobile_Phone
      FROM Hr_Lookups
      WHERE meaning   = 'Alternate'--'Mobile'-- - Home'
      AND lookup_type ='PHONE_TYPE'
      AND TRUNC(sysdate) BETWEEN NVL(start_date_active,TRUNC(sysdate)) AND NVL(end_date_active,'31-DEC-4712') --July-9th
      AND enabled_flag='Y';                                                                                   --July-8th
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'Exception occured in Validating Mobile Phone'||SQLERRM);
  END;
  -- Create Home Phone Detail
  -- -----------------------------------------------------------
  IF g_error=0 THEN
    fnd_file.put_line(fnd_file.log,'g_person_id in Create or Update Phone:'||g_person_id);
    fnd_file.put_line(fnd_file.log,'NEW_PERSON_ID in Create or Update Phone:'||P_HR_EMP_REC.NEW_PERSON_ID);
    fnd_file.put_line(fnd_file.log,'L_person_id in Create or Update Phone:'||L_person_id);
    hr_phone_api.Create_or_update_phone (-- Input data elements
    -- -----------------------------
    p_date_from => NVL(p_hr_emp_rec.OFFER_ACTUAL_START_DATE, sysdate), p_phone_type => P_phone_type, p_phone_number => p_phone, p_parent_id =>l_person_id, --P_HR_EMP_REC.NEW_PERSON_ID,  --revisit g_person_id,--
    p_parent_table => 'PER_ALL_PEOPLE_F', p_effective_date => NVL(p_hr_emp_rec.OFFER_ACTUAL_START_DATE,sysdate),
    -- Output data elements
    -- --------------------------------
    p_phone_id => ln_phone_id, p_object_version_number => l_object_version_number);
    --COMMIT;
    P_ERR_MSG:=NULL; --July-8th
    fnd_file.put_line(fnd_file.log,'Phone id is ' ||LN_PHONE_ID);
  END IF;
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  --g_error  :=1;
  -- P_ERR_MSG:=sqlerrm;
  fnd_file.put_line(fnd_file.log,'P_ERR_MSG:'||P_ERR_MSG);
  fnd_file.put_line(fnd_file.log,SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
  fnd_file.put_line(fnd_file.log,'P_ERR_MSG:'||P_ERR_MSG);
END Create_emp_ph_details;
/*#########################################################################
------------------------< Create Employee Salary >-------------------------
##########################################################################*/
PROCEDURE Create_emp_salary_details(
    p_hr_emp_rec IN OUT XXHA_REC_EMP_INT_STG% ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  lb_inv_next_sal_date_warning BOOLEAN;
  lb_proposed_salary_warning   BOOLEAN;
  lb_approved_warning          BOOLEAN;
  lb_payroll_warning           BOOLEAN;
  ln_pay_proposal_id           NUMBER;
  l_object_version_number      NUMBER;
  l_assignment_id              NUMBER;
BEGIN
  -- Create or Update Employee Salary Proposal
  -- ----------------------------------------------------------------
  IF g_error=0 AND p_hr_emp_rec.OFFER_ANNUALIZED_SALARY IS NOT NULL THEN
    SELECT new_assignment_id
    INTO l_assignment_id
    FROM XXHA_REC_EMP_INT_STG
    WHERE transaction_id_stg = p_hr_emp_rec.transaction_id_stg;
    fnd_file.put_line(fnd_file.log,'BG id in Salary proposal:'||FND_PROFILE.VALUE('PER_BUSINESS_GROUP_ID'));
    fnd_file.put_line(fnd_file.log,'Assignment id in Salary proposal:'||l_assignment_id);--p_hr_emp_rec.NEW_ASSIGNMENT_ID); revisit
    fnd_file.put_line(fnd_file.log,'Offer Annualized Salary in Salary proposal:'||p_hr_emp_rec.OFFER_ANNUALIZED_SALARY);
    fnd_file.put_line(fnd_file.log,'offer actual start Date:'||P_HR_EMP_REC.OFFER_ACTUAL_START_DATE);
    hr_maintain_proposal_api.Cre_or_upd_salary_proposal (
    -- Input data elements
    -- ------------------------------
    P_BUSINESS_GROUP_ID =>p_hr_emp_rec.NEW_BUSINESS_GROUP_ID, P_ASSIGNMENT_ID => l_assignment_id, --p_hr_emp_rec.NEW_ASSIGNMENT_ID, revisit
    P_CHANGE_DATE => NVL(P_HR_EMP_REC.offer_actual_start_date,sysdate),                           --OFFER_ACTUAL_START_DATE, revisit
    p_comments => 'New Hire', p_next_sal_review_date => P_HR_EMP_REC.next_review_date, p_proposal_reason => 'NEWH', p_proposed_salary_n => p_hr_emp_rec.OFFER_ANNUALIZED_SALARY, p_approved => 'Y',
    -- Output data elements
    -- --------------------------------
    p_pay_proposal_id => ln_pay_proposal_id, p_object_version_number => l_object_version_number, p_inv_next_sal_date_warning => lb_inv_next_sal_date_warning, p_proposed_salary_warning => lb_proposed_salary_warning, p_approved_warning => lb_approved_warning, p_payroll_warning => lb_payroll_warning);
    --COMMIT;
    P_ERR_MSG                                :=NULL; --July-8th
  elsif p_hr_emp_rec.OFFER_ANNUALIZED_SALARY IS NULL THEN
    P_ERR_MSG                                :=NULL;
  END IF;
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  fnd_file.put_line(fnd_file.log,'Exception in Salary:'||SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END Create_emp_salary_details;
/*#########################################################################
------------------------< Costing >-------------------------------------------
##########################################################################*/
PROCEDURE Create_emp_costing(
    P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG% ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  l_concat_segments            VARCHAR2(200);
  l_combination_name           VARCHAR2(200);
  l_cost_allocation_id         NUMBER;
  l_EFFECTIVE_START_DATE       DATE;
  l_EFFECTIVE_END_DATE         DATE;
  L_COST_ALLOCATION_KEYFLEX_ID NUMBER;
  L_OBJECT_VERSION_NUMBER      NUMBER;
  L_Department                 VARCHAR2(200);
  L_ACCOUNT                    VARCHAR2(200);
  L_Legal_entity               VARCHAR2(200);
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  l_assignment_id NUMBER;
  l_job           VARCHAR2(240);
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  SELECT new_assignment_id
  INTO l_assignment_id
  FROM XXHA_REC_EMP_INT_STG
  WHERE transaction_id_stg = p_hr_emp_rec.transaction_id_stg;
  --Validation for Correspondence/Department
  BEGIN
    SELECT A.flex_value
    INTO L_Department
    FROM fnd_flex_values_vl a,
      fnd_flex_value_sets b
    WHERE 1                 = 1
    AND A.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
      --AND A.DESCRIPTION         = P_HR_EMP_REC.CORRESPONDENCE
    AND a.flex_value          = SUBSTR(P_HR_EMP_REC.Correspondence,1,instr(P_HR_EMP_REC.Correspondence,' - ')-1)
    AND B.FLEX_VALUE_SET_NAME = 'HAE_GLOBAL_GL_COA_DEPARTMENT'
    AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
    AND a.enabled_flag ='Y';                                                                                    --July-8th
  EXCEPTION
  WHEN OTHERS THEN
    g_error:=1;
    UPDATE XXHA_REC_EMP_INT_STG
    SET STATUS_STG = 'VE',
      ERROR_CODE   = ERROR_CODE
      ||'VE123:',
      ERROR_MSG = ERROR_MSG
      ||'Department Not exist, '
    WHERE TRANSACTION_ID_STG = l_seq_no;
    --COMMIT;
    --p_err_msg  := 'Department Not exist' ||SQLERRM;
    fnd_file.put_line(fnd_file.log,'Exception in Department');
  END;
  --Validation for Cost Code Account
  BEGIN
    --fnd_file.put_line(fnd_file.log,'L_ACCOUNT_ATT : '||L_ACCOUNT_ATT);
    /*SELECT A.flex_value
    INTO L_Account
    FROM fnd_flex_values_vl a,
    fnd_flex_value_sets b
    WHERE 1                 = 1
    AND A.FLEX_VALUE_SET_ID = B.FLEX_VALUE_SET_ID
    AND a.description LIKE '%'
    ||'2904' --L_ACCOUNT_ATT  There is no account exists for the job provided in the data file, so for now hard coded
    ||'%'
    AND B.FLEX_VALUE_SET_NAME = 'HAE_GLOBAL_GL_COA_ACCOUNT'                                                     -- Given to get value from DFF job
    AND TRUNC(sysdate) BETWEEN NVL(a.start_date_active,TRUNC(sysdate)) AND NVL(a.end_date_active,'31-DEC-4712') --July-9th
    AND enabled_flag ='Y';                                                                                      --July-8th
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_COST_ACCOUNT     = L_Account
    WHERE TRANSACTION_ID_STG = l_seq_no;*/
    --COMMIT;
    SELECT NVL(job_information10,'Indirect')
    INTO l_job
    FROM per_jobs pj,
      XXHA_REC_EMP_INT_STG s
    WHERE pj.job_id          = s.NEW_JOB_ID
    AND s.transaction_id_stg = l_seq_no;
    fnd_file.put_line(fnd_file.log,'l_job :'|| l_job);
    IF l_job     = 'Indirect' THEN
      l_account := '600010';
    elsif l_job  = 'Direct' THEN
      l_account := '600000';
    END IF;
    fnd_file.put_line(fnd_file.log,'Cost account :'|| L_Account);
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_COST_ACCOUNT     = L_Account
    WHERE TRANSACTION_ID_STG = l_seq_no;
  EXCEPTION
  WHEN OTHERS THEN
    g_error:=1;
    UPDATE XXHA_REC_EMP_INT_STG
    SET STATUS_STG = 'VE',
      ERROR_CODE   = ERROR_CODE
      ||'VE124:',
      ERROR_MSG = ERROR_MSG
      ||'Account Not exist, ' ,
      LOAD_MSG = 'Create Costing - Error '
      ||P_ERR_MSG
    WHERE TRANSACTION_ID_STG = l_seq_no;
    --COMMIT;
    --p_err_msg  := 'Account Not exist' ||SQLERRM;
    fnd_file.put_line(fnd_file.log,'Exception in ACCOUNT'||SQLERRM);
  END;
  IF g_error=0 THEN
    fnd_file.put_line(fnd_file.log,'In PAY_COST_ALLOCATION_API');
    fnd_file.put_line(fnd_file.log,'l_assignment_id:'||l_assignment_id);
    fnd_file.put_line(fnd_file.log,'P_BUSINESS_GROUP_ID:'||p_hr_emp_rec.NEW_BUSINESS_GROUP_ID);
    fnd_file.put_line(fnd_file.log,'P_SEGMENT1:'||P_HR_EMP_REC.requisition_udf_8);
    fnd_file.put_line(fnd_file.log,'P_SEGMENT3:'||P_HR_EMP_REC.BUSINESS_UNIT);
    fnd_file.put_line(fnd_file.log,'P_SEGMENT4:'||P_HR_EMP_REC.requisition_udf_9);
    fnd_file.put_line(fnd_file.log,'P_SEGMENT5:'||L_DEPARTMENT);
    fnd_file.put_line(fnd_file.log,'P_SEGMENT6:'||L_Account);
    fnd_file.put_line(fnd_file.log,'p_concat_segments:'||l_concat_segments);
    PAY_COST_ALLOCATION_API.CREATE_COST_ALLOCATION (p_validate => FALSE , P_EFFECTIVE_DATE => P_HR_EMP_REC.offer_actual_start_date , p_assignment_id => l_assignment_id,--p_hr_emp_rec.NEW_ASSIGNMENT_ID , revisit
    P_PROPORTION => 1 , P_BUSINESS_GROUP_ID => p_hr_emp_rec.NEW_BUSINESS_GROUP_ID , P_SEGMENT1 => P_HR_EMP_REC.requisition_udf_8,                                       --L_LEGAL_ENTITY ,
    --P_SEGMENT2 => NULL ,  -- not required
    P_SEGMENT3 => P_HR_EMP_REC.BUSINESS_UNIT ,              -- requisition_udf_8
    P_SEGMENT4 => P_HR_EMP_REC.requisition_udf_9           ---     L_MANAGEMENT_UNIT
    ,P_SEGMENT5 => L_DEPARTMENT , P_SEGMENT6 => L_Account , --600000  for Malaysia as there are no values with the combination
    p_concat_segments =>NULL,                               --l_concat_segments , --
    --Out variables
    p_combination_name => l_combination_name , p_cost_allocation_id => l_cost_allocation_id , p_effective_start_date => l_effective_start_date , p_effective_end_date => l_effective_end_date , P_COST_ALLOCATION_KEYFLEX_ID => L_COST_ALLOCATION_KEYFLEX_ID , P_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER );
    --COMMIT;
    P_ERR_MSG:=NULL; --July-8th
    fnd_file.put_line(fnd_file.log,'After PAY_COST_ALLOCATION_API');
  END IF;
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  fnd_file.put_line(fnd_file.log,'In Exception After PAY_COST_ALLOCATION_API');
  fnd_file.put_line(fnd_file.log,SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END Create_emp_costing;
/*#########################################################################
------------------------< Employee extra information >----------------------
##########################################################################*/
PROCEDURE CREATE_PERSON_EXTRA_INFO(
    L_BUSINESS_GROUP       VARCHAR2,
    L_TRANSACTION_ID_STG   NUMBER,
    L_PERSON_ID            NUMBER,
    L_INFORMATION_TYPE     VARCHAR2,
    L_INFORMATION_CATEGORY VARCHAR2,
    L_INFORMATION1         VARCHAR2,
    L_INFORMATION2         VARCHAR2,
    L_INFORMATION3         VARCHAR2,
    L_INFORMATION4         VARCHAR2,
    L_INFORMATION5         VARCHAR2,
    L_INFORMATION6         VARCHAR2,
    L_INFORMATION7         VARCHAR2,
    L_INFORMATION8         VARCHAR2,
    L_INFORMATION9         VARCHAR2,
    L_INFORMATION10        VARCHAR2,
    L_INFORMATION11        VARCHAR2,
    L_INFORMATION12        VARCHAR2,
    L_INFORMATION13        VARCHAR2,
    L_INFORMATION14        VARCHAR2,
    L_INFORMATION15        VARCHAR2,
    L_PERSON_EXTRA_INFO_ID OUT NUMBER,
    L_OBJECT_VERSION_NUMBER OUT NUMBER )
IS
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
  P_ERR_MSG    VARCHAR2(10);
  ln_person_id NUMBER;
BEGIN
  l_seq_no := L_TRANSACTION_ID_STG;
  --l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  --Added
  SELECT new_person_id
  INTO ln_person_id
  FROM XXHA_REC_EMP_INT_STG
  WHERE TRANSACTION_ID_STG =l_seq_no; --p_hr_emp_rec.TRANSACTION_ID_STG;
  Fnd_File.Put_Line(Fnd_File.Log,'In emp_ph_details - Person ID '||l_person_id);
  --IF g_error=0 AND l_business_group ='BG_MY' THEN   --Commented and modified by Krishna
  IF g_error=0 --AND L_BUSINESS_GROUP NOT IN ('BG_US')
    THEN
    hr_person_extra_info_api.create_person_extra_info (p_validate => false , p_person_id => Ln_PERSON_ID , P_INFORMATION_TYPE => L_INFORMATION_TYPE-- this is same as your extra person information flex filed code.
    ,p_pei_attribute_category => NULL , P_PEI_INFORMATION_CATEGORY => L_INFORMATION_CATEGORY                                                       -- this is same as your extra person information flex filed code.
    ,P_PEI_INFORMATION1 => L_INFORMATION1 , P_PEI_INFORMATION2 => L_INFORMATION2 , P_PEI_INFORMATION3 => L_INFORMATION3 , P_PEI_INFORMATION4 => L_INFORMATION4 , P_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID
    -- out values
    ,P_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER );
    --COMMIT;
    P_ERR_MSG:=NULL; --July-8th
    fnd_file.put_line(fnd_file.log,'L_INFORMATION_TYPE :' ||l_person_extra_info_id);
    UPDATE XXHA_REC_EMP_INT_STG
    SET NEW_PER_EXTRA_INFO_ID=l_person_extra_info_id
    WHERE TRANSACTION_ID_STG = l_seq_no;
    --COMMIT;
  END IF;
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  fnd_file.put_line(fnd_file.log,'In Extra Person Info Exception:'||SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END CREATE_PERSON_EXTRA_INFO;
/*#########################################################################
------------------------< Create Employee Element Entry >----------------------
##########################################################################*/
PROCEDURE CREATE_ELEMENT_ENTRY(
    P_HR_EMP_REC IN OUT XXHA_REC_EMP_INT_STG%ROWTYPE,
    p_err_msg OUT VARCHAR2)
IS
  ln_element_link_id PAY_ELEMENT_LINKS_F.ELEMENT_LINK_ID%TYPE;
  ld_effective_start_date DATE;
  ld_effective_end_date   DATE;
  ln_element_entry_id PAY_ELEMENT_ENTRIES_F.ELEMENT_ENTRY_ID%TYPE;
  l_object_version_number PAY_ELEMENT_ENTRIES_F.OBJECT_VERSION_NUMBER %TYPE;
  lb_create_warning                                                   BOOLEAN;
  ln_input_value_id PAY_INPUT_VALUES_F.INPUT_VALUE_ID%TYPE;
  LN_SCREEN_ENTRY_VALUE PAY_ELEMENT_ENTRY_VALUES_F.SCREEN_ENTRY_VALUE%TYPE;
  LN_ELEMENT_TYPE_ID PAY_ELEMENT_TYPES_F.ELEMENT_TYPE_ID%TYPE;
  L_ELEMENT_TYPE_ID PAY_ELEMENT_TYPES_F.ELEMENT_TYPE_ID%TYPE;
  INPUT_VALUE_ID1 PAY_INPUT_VALUES_F.INPUT_VALUE_ID%TYPE;
  INPUT_VALUE_ID2 PAY_INPUT_VALUES_F.INPUT_VALUE_ID%TYPE;
  INPUT_VALUE_ID3 PAY_INPUT_VALUES_F.INPUT_VALUE_ID%TYPE;
  CURSOR c_element_name
  IS
    SELECT *
      --INTO l_element_type_id
    FROM PAY_ELEMENT_TYPES_F
    WHERE business_group_id=p_hr_emp_rec.NEW_BUSINESS_GROUP_ID --3137 -- As this if for only Malaysia, hard coded Malaysia BG ID
    AND element_name      IN ('Call and Data Plan Allowance MYR','Meal Subs Allowance MYR','Perfect Attd Reward Allowance MYR', 'Prod Acmt Reward Allowance MYR','Shift Premium Allowance MYR','Toll Allowance MYR','Travel Allowance MYR', 'Special Assignment Allowance MYR');
  l_entry_value NUMBER;
  l_seq_no XXHA_REC_EMP_INT_STG.transaction_id_stg%type;
BEGIN
  l_seq_no := P_HR_EMP_REC.TRANSACTION_ID_STG;
  P_ERR_MSG:=NULL;
  FOR Rec_element_name IN c_element_name
  LOOP
    fnd_file.put_line(fnd_file.log,'Entered into loop');
    IF Rec_element_name.element_name   ='Call and Data Plan Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.call_data;
    elsif Rec_element_name.element_name='Meal Subs Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.MEAL_SUBS;
    elsif Rec_element_name.element_name='Perfect Attd Reward Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.PERFECT_ATTD_RWD;
    elsif Rec_element_name.element_name='Prod Acmt Reward Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.PROD_ACMT_RWD;
    elsif Rec_element_name.element_name='Shift Premium Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.SHIFT_PRE_ALLOWANCE; -- Add this column in the staging table, Added
    elsif Rec_element_name.element_name='Toll Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.TOLL_ALLOWANCE;
    elsif Rec_element_name.element_name='Travel Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.travel_allowance;
    elsif Rec_element_name.element_name='Special Assignment Allowance MYR' THEN
      l_entry_value                   := P_HR_EMP_REC.shift_asg_allowance; -- revisit change the column name
    END IF;
    SELECT ELEMENT_TYPE_ID
    INTO l_element_type_id
    FROM PAY_ELEMENT_TYPES_F
    WHERE ELEMENT_NAME =Rec_element_name.element_name; --'Travel Allowance MYR'; --'Call and Data Plan Allowance MYR';
    -- ------------------------------
    LN_ELEMENT_LINK_ID := HR_ENTRY_API.GET_LINK ( p_assignment_id => G_ASSIGNMENT_ID,
    --p_hr_emp_rec.NEW_ASSIGNMENT_ID, revisit
    p_element_type_id => l_element_type_id, p_session_date => SYSDATE );
    fnd_file.put_line(fnd_file.log, 'API: Element Link Id: ' || ln_element_link_id );
    SELECT INPUT_VALUE_ID
    INTO INPUT_VALUE_ID1
    FROM PAY_INPUT_VALUES_F
    WHERE ELEMENT_TYPE_ID =Rec_element_name.ELEMENT_TYPE_ID; --l_element_type_id;  --64260
    -- Create Element Entry
    -- ------------------------------
    --IF g_error=0 AND l_entry_value IS NOT NULL AND l_business_group ='BG_MY' THEN  --Commented and modified by Krishna
    IF g_error=0 AND l_entry_value IS NOT NULL AND p_hr_emp_rec.NEW_BUSINESS_GROUP NOT IN ('BG_US') THEN
      pay_element_entry_api.create_element_entry ( -- Input data elements
      -- -----------------------------
      P_EFFECTIVE_DATE => P_HR_EMP_REC.offer_actual_start_date, P_BUSINESS_GROUP_ID => p_hr_emp_rec.NEW_BUSINESS_GROUP_ID , p_assignment_id => G_ASSIGNMENT_ID,-- p_hr_emp_rec.NEW_ASSIGNMENT_ID, revisit
      p_element_link_id => ln_element_link_id, P_ENTRY_TYPE => 'E' , p_input_value_id1 => input_value_id1 ,
      --P_INPUT_VALUE_ID2 => INPUT_VALUE_ID2 ,
      p_entry_value1 => l_entry_value --1 --p_hr_emp_rec.TRAVEL_ALLOWANCE
      -- Output data elements
      -- --------------------------------
      ,p_effective_start_date => ld_effective_start_date, p_effective_end_date => ld_effective_end_date, p_element_entry_id => ln_element_entry_id, p_object_version_number => l_object_version_number, p_create_warning => lb_create_warning );
      fnd_file.put_line(fnd_file.log, ' API: pay_element_entry_api.create_element_entry successfull - Element Entry Id: ' || ln_element_entry_id );
      --COMMIT;
      P_ERR_MSG:=NULL; --July-8th
    END IF;
  END LOOP;
  fnd_file.put_line(fnd_file.log,'P_ERR_MSG '||P_ERR_MSG);
EXCEPTION
WHEN OTHERS THEN
  --ROLLBACK;
  fnd_file.put_line(fnd_file.log,SQLERRM);
  g_error  :=1;
  P_ERR_MSG:=sqlerrm; --July-8th
END CREATE_ELEMENT_ENTRY;
--##########################################################################################################################
------------------< Pragma Autonomous Transaction for Updating the status when record is failed>------------------------
--##########################################################################################################################
PROCEDURE Update_Last_Error_Rec(
    P_STAT_STG IN VARCHAR2,
    P_ERR_COD  IN VARCHAR2,
    P_ERR_MSG  IN VARCHAR2,
    P_SEQ_NO   IN NUMBER)
IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  UPDATE XXHA_REC_EMP_INT_STG
  SET STATUS_STG = P_STAT_STG,
    ERROR_CODE   = ERROR_CODE
    ||':'
    ||P_ERR_COD,
    ERROR_MSG = ERROR_MSG
    ||','
    ||P_ERR_MSG ,
    LOAD_MSG = LOAD_MSG
    ||','
    ||P_ERR_MSG
  WHERE TRANSACTION_ID_STG = P_SEQ_NO
  AND STATUS_STG           ='V';
  FND_FILE.PUT_LINE(FND_FILE.log,'In Update_Last_Error_Rec');
  --COMMIT; --change dk
EXCEPTION
WHEN OTHERS THEN
  FND_FILE.PUT_LINE(FND_FILE.log,'In Update_Last_Error_Rec exception:'||sqlerrm);
END Update_Last_Error_Rec;
/*#########################################################################
------------------------< Main >-------------------------------------------
##########################################################################*/
PROCEDURE MAIN(
    ERRBUFF OUT VARCHAR2,
    RETCODE OUT NUMBER,
    P_Candidate_Number IN NUMBER)
IS
  ------------------------< Cursor to Validate and load >----------------------------------------------------
  CURSOR cur_val_stg
  IS
    SELECT stg.* FROM XXHA_REC_EMP_INT_STG STG WHERE 1 =1 AND STATUS_STG = 'N' and candidate_number = nvl(P_Candidate_Number,candidate_number);
  CURSOR cur_load_stg
  IS
    SELECT stg.* FROM XXHA_REC_EMP_INT_STG STG WHERE 1 =1 AND STATUS_STG = 'V' and candidate_number = nvl(P_Candidate_Number,candidate_number);

  NEW_PERSON_ID NUMBER;
  L_ROWID       VARCHAR2(500);
  p_hcm_emp_val_rec XXHA_REC_EMP_INT_STG%ROWTYPE;
  L_ERR_MSG               VARCHAR2(4000);
  L_PERSON_EXTRA_INFO_ID  NUMBER;
  ln_element_entry_id     NUMBER;
  L_OBJECT_VERSION_NUMBER NUMBER;
  L_Future_Count_Main     NUMBER;
  L_Ex_count_Main         NUMBER;
  l_seq_no XXHA_REC_EMP_INT_STG.TRANSACTION_ID_STG%TYPE;
  empexec              EXCEPTION;
  l_empexec_status     VARCHAR2(2000);
  l_empexec_err_code   VARCHAR2(2000);
  l_empexec_err_msg    VARCHAR2(4000);
  l_empexec_seq_no     NUMBER;
  L_emp_count          NUMBER;
  L_Ex_Contingent_Main NUMBER;
BEGIN
  ---------------IF candidate number is not null then updating the derived id's and columns to null--------------
  fnd_file.put_line(fnd_file.log,'P_Candidate_Number :'||P_Candidate_Number);
  IF P_Candidate_Number IS NOT NULL THEN
    UPDATE XXHA_REC_EMP_INT_STG
    SET STATUS_STG         ='N',
      error_code           =NULL,
      error_msg            =NULL,
      NEW_BUSINESS_GROUP_ID=NULL,
      NEW_PERSON_ID        =NULL,
      NEW_ASSIGNMENT_ID    =NULL,
      NEW_ADDRESS_ID       =NULL,
      NEW_BUSINESS_GROUP   =NULL,
      NEW_LEDGER_NAME      =NULL,
      NEW_PERSON_TYP_ID    =NULL,
      NEW_ORGANIZATION_ID  =NULL,
      NEW_LOCATION_ID      =NULL,
      NEW_GRADE_ID         =NULL,
      NEW_JOB_ID           =NULL,
      NEW_PAYROLL_ID       =NULL,
      NEW_PAY_BASIS_ID     =NULL,
      NEW_EXPENSE_CCID     =NULL,
      NEW_SUPERVISOR_ID    =NULL,
      NEW_COST_ACCOUNT     =NULL ,
      LAST_UPDATE_date     = sysdate ,
      LAST_UPDATED_BY      = fnd_global.user_id
    WHERE candidate_number = P_Candidate_Number;
    --COMMIT;
  END IF;
  fnd_file.put_line(fnd_file.log,'In main Start 1 ');
  ------------------------< Validate Employee  details >----------------------------
  fnd_file.put_line(fnd_file.log,'VAl emp start');
  BEGIN --July 8th not required
    OPEN cur_val_stg;
    LOOP
      fnd_file.put_line(fnd_file.log,'Before fetch of Validate Employee');
      FETCH cur_val_stg INTO p_hcm_emp_val_rec;
      EXIT
    WHEN CUR_VAL_STG%NOTFOUND;
      g_error :=0;
      --For Future Employee Scenario
      L_Future_Count_Main                     := 0;
      L_Ex_count_Main                         := 0;
      L_Ex_Contingent_Main                    :=0;
      IF p_hcm_emp_val_rec.INT_CAND_INDICATOR <> 'TRUE' THEN ------ then process the records else SKIP
        fnd_file.put_line(fnd_file.log,'B4 Validate employee open :'|| P_HCM_EMP_VAL_REC.ORG_CODE);
        VALIDATE_EMPLOYEE(P_HR_EMP_VAL_REC => P_HCM_EMP_VAL_REC);
        fnd_file.put_line(fnd_file.log,'After Validate_employee open');
      ELSIF p_hcm_emp_val_rec.INT_CAND_INDICATOR = 'TRUE' THEN
        fnd_file.put_line(fnd_file.log,'B4 Validate employee open :'|| P_HCM_EMP_VAL_REC.ORG_CODE);
        UPDATE XXHA_REC_EMP_INT_STG
        SET status_stg        ='VE' ,
          error_code          = 'INC001',
          ERROR_MSG           ='Internal Candidate - Handle manually'
        WHERE 1               =1
        AND transaction_id_stg=p_hcm_emp_val_rec.transaction_id_stg;
        COMMIT;
        fnd_file.put_line(fnd_file.log,'Internal Candidate - Need to handle manually');
      END IF;
      -- Employee with Future effective date
      BEGIN
        fnd_file.put_line(fnd_file.log,'In Future Employee Scenario');
        SELECT COUNT(*)
        INTO L_Future_Count_Main
        FROM Per_All_People_F Papf,
          Hr.Per_Person_Type_Usages_F Pptu,
          Hr.Per_Person_Types Ppt
        WHERE 1                 =1
        AND Papf.Person_Id      = Pptu.Person_Id
        AND pptu.person_type_id = ppt.person_type_id
        AND Ppt.User_Person_Type LIKE 'Employee%'
        AND Pptu.Effective_Start_Date > Sysdate
        AND Papf.Effective_Start_Date > Sysdate
          --AND Papf.Attribute15          =p_hcm_emp_val_rec.Candidate_Number
        AND papf.first_name = p_hcm_emp_val_rec.first_name
        AND papf.last_name  = p_hcm_emp_val_rec.last_name
        AND ppt.active_flag ='Y' --July-8th
        GROUP BY Papf.Effective_Start_Date,
          papf.person_id;
        fnd_file.put_line(fnd_file.log,'Future Employees Count:'||L_Future_Count_Main);
      EXCEPTION
      WHEN no_data_found THEN
        fnd_file.put_line(fnd_file.log,'In Exception- No Future Employee:'||L_Future_Count_Main);
      END;
      --Added these 2 queries after if as we are getting business group id null
      --For Ex Employee Rehire Scenario
      BEGIN
        fnd_file.put_line(fnd_file.log,'p_hcm_emp_val_rec.Candidate_Number:'||p_hcm_emp_val_rec.Candidate_Number);
        SELECT COUNT(*)
        INTO L_Ex_count_Main
        FROM Per_All_People_F Papf,
          Hr.Per_Person_Type_Usages_F Pptu,
          Hr.Per_Person_Types Ppt
        WHERE 1                    =1
        AND Papf.Person_Id         = Pptu.Person_Id
        AND pptu.person_type_id    = ppt.person_type_id
        AND Papf.Business_Group_Id = p_hcm_emp_val_rec.NEW_BUSINESS_GROUP_ID
        AND Ppt.User_Person_Type LIKE 'Ex-employee%'
        AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
        AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
          --AND Papf.Attribute15=p_hcm_emp_val_rec.Candidate_Number --'100800';
        AND papf.first_name = p_hcm_emp_val_rec.first_name
        AND papf.last_name  = p_hcm_emp_val_rec.last_name
        AND ppt.active_flag ='Y' --July-8th
        GROUP BY papf.person_id;
        fnd_file.put_line(fnd_file.log,'In EX Employee for Rehire:'||L_Ex_count_Main);
      EXCEPTION
      WHEN no_data_found THEN
        fnd_file.put_line(fnd_file.log,'In Exception- No EX Employee for Rehire:'||L_Ex_count_Main);
      END;
      --Added Rehiring Ex-Employee to Contingent WORKER
      /*BEGIN
      fnd_file.put_line(fnd_file.log,'Candidate_Number in Rehiring Contingent Worker:'||p_hcm_emp_val_rec.Candidate_Number);
      fnd_file.put_line(fnd_file.log,'BUSINESS_GROUP_ID in Rehiring Contingent Worker:'||p_hcm_emp_val_rec.NEW_BUSINESS_GROUP_ID);
      SELECT COUNT(*)
      INTO L_Ex_Contingent_Main --L_Ex_count_Main
      FROM Per_All_People_F Papf,
      Hr.Per_Person_Type_Usages_F Pptu,
      Hr.Per_Person_Types Ppt,
      per_all_assignments_f paaf --Added
      WHERE 1                    =1
      AND Papf.Person_Id         = Pptu.Person_Id
      AND pptu.person_type_id    = ppt.person_type_id
      AND Papf.Business_Group_Id = 0 --p_hcm_emp_val_rec.NEW_BUSINESS_GROUP_ID
      AND Ppt.User_Person_Type LIKE 'HAE Ex-contingent Worker'--'Ex-employee%' --08/20
      AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
      AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
      --AND Papf.Attribute15=p_hcm_emp_val_rec.Candidate_Number
      --Added
      AND Upper(Papf.First_Name)   = Upper(p_hcm_emp_val_rec.First_Name)
      AND upper(papf.last_name)    = upper(p_hcm_emp_val_rec.LAST_NAME)
      AND paaf.person_id           =papf.person_id
      --AND paaf.employment_category = p_hcm_emp_val_rec.NEW_ASSG_CAT -- 08/20
      and upper(p_hr_emp_val_rec.EMPLOYEE_STATUS) = 'TEMPORARY WORKER'
      --Added
      AND ppt.active_flag ='Y'
      GROUP BY papf.person_id;
      fnd_file.put_line(fnd_file.log,'EX Employee count to Rehire as a contingent worker:'||L_Ex_Contingent_Main);
      EXCEPTION
      WHEN no_data_found THEN
      fnd_file.put_line(fnd_file.log,'In Exception- No EX Employee to Rehire as a contingent worker:'||sqlerrm);
      END;*/
    END LOOP;
    CLOSE cur_val_stg;
    -------------------------< Calling Temp to Rehire Procedure >--------------------------------
    fnd_file.put_line(fnd_file.log,'**************************************');
    OPEN cur_load_stg;
    LOOP
      g_error :=0;
      fnd_file.put_line(fnd_file.log,'Before fetch of Load Employee ');
      --July-8th
      BEGIN
        FETCH cur_load_stg INTO p_hcm_emp_val_rec;
        EXIT
      WHEN cur_load_stg%NOTFOUND;
        fnd_file.put_line(fnd_file.log,'**************************************');
        l_seq_no:=p_hcm_emp_val_rec.transaction_id_stg;
        fnd_file.put_line(fnd_file.log,'Processing '||p_hcm_emp_val_rec.TRANSACTION_ID_STG);
        IF p_hcm_emp_val_rec.TEMP_TO_PERM_HIRE=1 AND p_hcm_emp_val_rec.STATUS_STG = 'V' THEN
          fnd_file.put_line(fnd_file.log,'In TEMP_TO_REHIRE');
          --Added July-7th
          --Begin
          L_ERR_MSG:= NULL;
          CREATE_TEMP_TO_REHIRE(P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG );
          --IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'TEMP_TO_REHIRE is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'TEMP_TO_REHIRE Before raise exception');
            l_empexec_status   := 'LE';
            l_empexec_err_code := 'LE201';
            l_empexec_err_msg  := 'Temp to Rehire load error - '||L_ERR_MSG;
            l_empexec_seq_no   := L_SEQ_NO;
            raise empexec;
            --COMMIT;
          END IF;
          fnd_file.put_line(fnd_file.log,'After Calling Temp to Rehire');
          fnd_file.put_line(fnd_file.log,L_ERR_MSG);
          L_ERR_MSG := NULL;
          --end if;
          -------------------------< Calling IS Rehire Procedure >--------------------------------
        elsif p_hcm_emp_val_rec.IS_THIS_CAND_REHIRE=1 AND p_hcm_emp_val_rec.STATUS_STG= 'V' THEN
          CREATE_IS_REHIRE(P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG );
          -- IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'IS_THIS_CAND_REHIRE is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'IS_THIS_CAND_REHIRE Before raise exception');
            l_empexec_status   := 'LE';
            l_empexec_err_code := 'LE202';
            l_empexec_err_msg  := 'Is Candidate Rehire load error - '||L_ERR_MSG;
            l_empexec_seq_no   := L_SEQ_NO;
            raise empexec;
            --raise empexec;
            --COMMIT;
          END IF;
          fnd_file.put_line(fnd_file.log,'After Calling Is candidate Rehire');
          fnd_file.put_line(fnd_file.log,L_ERR_MSG);
          L_ERR_MSG := NULL;
          -------------------------< Calling Ex Employee to Rehire Procedure >--------------------------------
        elsif L_Ex_count_Main = 1 AND p_hcm_emp_val_rec.STATUS_STG= 'V' THEN
          REHIRE_EX_EMPLOYEE(P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG );
          --IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'Ex Employee to Rehire is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'Ex Employee to Rehire Before raise exception');
            l_empexec_status   := 'LE';
            l_empexec_err_code := 'LE203';
            l_empexec_err_msg  := 'Ex-Employee Rehire load error - '||L_ERR_MSG;
            l_empexec_seq_no   := L_SEQ_NO;
            raise empexec;
            --COMMIT;
          END IF;
          fnd_file.put_line(fnd_file.log,'After Calling Ex-Employee Rehire');
          fnd_file.put_line(fnd_file.log,L_ERR_MSG);
          L_ERR_MSG := NULL;
          -------------------------< Calling Ex Employee to Rehire as a contingent worker>--------------------------------
        elsif L_Ex_count_Main = 1 AND p_hcm_emp_val_rec.STATUS_STG= 'V' AND upper(p_hcm_emp_val_rec.EMPLOYEE_STATUS) = 'TEMPORARY WORKER' THEN
          REHIRE_EXEMP_CONTINGENT(P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG );
          --IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'Ex Employee to Rehire as Contingent Worker is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'Ex Employee to Rehire as Contingent worker Before raise exception');
            l_empexec_status   := 'LE';
            l_empexec_err_code := 'LE214';
            l_empexec_err_msg  := 'Ex-Employee Rehire as Contingent worker load error - '||L_ERR_MSG;
            l_empexec_seq_no   := L_SEQ_NO;
            raise empexec;
            --COMMIT;
          END IF;
          fnd_file.put_line(fnd_file.log,'After Calling Ex-Employee Rehire to Contingent Worker');
          fnd_file.put_line(fnd_file.log,L_ERR_MSG);
          L_ERR_MSG := NULL;
          -------------------------< Calling Update Future Employee >--------------------------------
        elsif L_Future_Count_Main =1 AND p_hcm_emp_val_rec.STATUS_STG= 'V' THEN
          Update_Fut_EMP_SYSDATE(P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG );
          --IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'Update_Fut_EMP_SYSDATE is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'Update_Fut_EMP_SYSDATE Before raise exception');
            --Update_Last_Error_Rec(':LE',':LE203',':Future Employee load error,',L_SEQ_NO);
            l_empexec_status   := 'LE';
            l_empexec_err_code := 'LE204';
            l_empexec_err_msg  := 'Future Employee load error - '||L_ERR_MSG;
            l_empexec_seq_no   := L_SEQ_NO;
            raise empexec;
            --COMMIT;
          END IF;
          fnd_file.put_line(fnd_file.log,'After Calling Ex-Employee Rehire');
          fnd_file.put_line(fnd_file.log,L_ERR_MSG);
          L_ERR_MSG                       := NULL;
        elsif p_hcm_emp_val_rec.STATUS_STG = 'V' THEN
          --------------- check if employee exists with the same name ---------------------------------
          L_emp_count                                 := 0;
          IF upper(p_hcm_emp_val_rec.EMPLOYEE_STATUS) <> 'TEMPORARY WORKER' THEN
            BEGIN
              SELECT COUNT(*)
              INTO L_emp_count
              FROM Per_All_People_F Papf,
                Hr.Per_Person_Type_Usages_F Pptu,
                Hr.Per_Person_Types Ppt
              WHERE 1                    =1
              AND Papf.Person_Id         = Pptu.Person_Id
              AND pptu.person_type_id    = ppt.person_type_id
              AND Papf.Business_Group_Id = p_hcm_emp_val_rec.NEW_BUSINESS_GROUP_ID
              AND Ppt.User_Person_Type LIKE 'Employee%'
              AND Sysdate BETWEEN Pptu.Effective_Start_Date AND Pptu.Effective_End_Date
              AND Sysdate BETWEEN Papf.Effective_Start_Date AND Papf.Effective_End_Date
              AND Papf.first_name =p_hcm_emp_val_rec.first_name
              AND papf.last_name  = p_hcm_emp_val_rec.last_name
              AND ppt.active_flag ='Y'
              GROUP BY papf.person_id;
              fnd_file.put_line(fnd_file.log,'Employee Exists : '||L_emp_count);
            EXCEPTION
            WHEN no_data_found THEN
              l_emp_count := 0;
            WHEN OTHERS THEN
              l_emp_count := 0;
            END;
          END IF;
          IF L_emp_count = 0 THEN
            ------------------------< Calling employee Creation Procedure >-------------------------------------------
            CREATE_EMPLOYEE (P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG );
            --IF l_err_msg IS NOT NULL THEN
            IF l_err_msg IS NULL THEN
              fnd_file.put_line(fnd_file.log,'CREATE_EMPLOYEE is Successful');
            ELSE
              fnd_file.put_line(fnd_file.log,'CREATE_EMPLOYEE Before raise exception');
              --Update_Last_Error_Rec(':LE',':LE204',':Employee load error,',L_SEQ_NO);
              l_empexec_status   := 'LE';
              l_empexec_err_code := 'LE205';
              l_empexec_err_msg  := 'Employee load error - '||L_ERR_MSG;
              l_empexec_seq_no   := L_SEQ_NO;
              raise empexec;
              --COMMIT;
            END IF;
            fnd_file.put_line(fnd_file.log,'After Calling employee Creation');
            fnd_file.put_line(fnd_file.log,'L_ERR_MSG:'||L_ERR_MSG);
            L_ERR_MSG := NULL;
          ELSE
            NULL;
            fnd_file.put_line(fnd_file.log,'Emp already exists ');
            -- send email
          END IF;
        END IF;
        -----------------------< Calling employee Address Creation Procedure >-------------------------------------------
        fnd_file.put_line(fnd_file.log,'Sequence Number in Address:'||l_seq_no ||' '||g_error||' '||L_Ex_Contingent_Main);
        IF p_hcm_emp_val_rec.STATUS_STG = 'V' AND g_error<>1 AND upper(p_hcm_emp_val_rec.EMPLOYEE_STATUS) <> 'TEMPORARY WORKER' THEN -- condition is failing and going out of the loop, when no data found
          fnd_file.put_line(fnd_file.log,'B4 Calling employee Address Creation Procedure');
          CREATE_EMPLOYEE_ADDRESS(P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG) ;
          --IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'CREATE_EMPLOYEE_ADDRESS is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'CREATE_EMPLOYEE_ADDRESS Before raise exception');
            fnd_file.put_line(fnd_file.log,'L_SEQ_NO----------:'||L_SEQ_NO);
            l_empexec_status   := 'L'; --'LE';
            l_empexec_err_code := NULL;--'LE206';
            l_empexec_err_msg  := 'Employee Address error - '||L_ERR_MSG;
            l_empexec_seq_no   := L_SEQ_NO;
            UPDATE XXHA_REC_EMP_INT_STG
            SET status_stg ='L' ,
              LOAD_MSG     ='Employee Address error - '
              ||L_ERR_MSG
            WHERE 1               =1
            AND transaction_id_stg=L_SEQ_NO;
            --raise empexec;
            --COMMIT;
          END IF;
          fnd_file.put_line(fnd_file.log,'After Calling employee Address Creation Procedure');
          L_ERR_MSG := NULL;
        END IF;
        ------------------------< Calling employee Assignment >-------------------------------------------
        --IF L_Ex_Contingent_Main <> 1 THEN
        Create_emp_asgnmnt (p_hr_emp_rec => p_hcm_emp_val_rec, p_api_mode => 'CORRECTION',p_err_msg => L_ERR_MSG);
        FND_FILE.PUT_LINE(FND_FILE.LOG,'After Calling employee Assignment');
        --IF l_err_msg IS NOT NULL THEN
        IF l_err_msg IS NULL THEN
          fnd_file.put_line(fnd_file.log,'Create_emp_asgnmnt is Successful');
        ELSE
          fnd_file.put_line(fnd_file.log,'Create_emp_asgnmnt Before raise exception');
          --Update_Last_Error_Rec(':LE',':LE206',':Employee Asgment load error,',L_SEQ_NO);
          l_empexec_status   := 'LE';
          l_empexec_err_code := 'LE207';
          l_empexec_err_msg  := 'Employee Asgment load error - '||L_ERR_MSG;
          l_empexec_seq_no   := L_SEQ_NO;
          raise empexec;
          --COMMIT;
        END IF;
        L_ERR_MSG := NULL;
        -----------------------< Calling employee Home Phone details Creation Procedure >-------------------------------------------
        IF upper(p_hcm_emp_val_rec.EMPLOYEE_STATUS) <> 'TEMPORARY WORKER' THEN
          IF p_hcm_emp_val_rec.HOME_PHONE           IS NOT NULL THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Before Calling Phone 1'||l_err_msg);
            CREATE_EMP_PH_DETAILS(P_HR_EMP_REC => p_hcm_emp_val_rec,p_phone=>p_hcm_emp_val_rec.HOME_PHONE,P_PHONE_TYPE => 'H1',p_err_msg => L_ERR_MSG);
            FND_FILE.PUT_LINE(FND_FILE.LOG,'l_err_msg after call:'||l_err_msg);
            --IF l_err_msg IS NOT NULL THEN
            IF l_err_msg IS NULL THEN
              fnd_file.put_line(fnd_file.log,'CREATE_EMP_PH_DETAILS is Successful');
            ELSE
              fnd_file.put_line(fnd_file.log,'CREATE_EMP_PH_DETAILS Before raise exception');
              --COMMIT;
              /*  l_empexec_status   := 'LE';
              l_empexec_err_code := 'LE208';
              l_empexec_err_msg  := 'Home phone load error - '||L_ERR_MSG;
              l_empexec_seq_no   := L_SEQ_NO;
              raise empexec;*/
            END IF; --err
          END IF;
          L_ERR_MSG                         := NULL;
          IF p_hcm_emp_val_rec.MOBILE_PHONE IS NOT NULL THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Before Calling Phone 2');
            CREATE_EMP_PH_DETAILS(P_HR_EMP_REC => p_hcm_emp_val_rec,p_phone=>p_hcm_emp_val_rec.MOBILE_PHONE,P_PHONE_TYPE => 'MH' ,p_err_msg => L_ERR_MSG);
            --IF l_err_msg IS NOT NULL THEN
            IF l_err_msg IS NULL THEN
              fnd_file.put_line(fnd_file.log,'CREATE_EMP_PH_DETAILS 2 is Successful');
            ELSE
              fnd_file.put_line(fnd_file.log,'CREATE_EMP_PH_DETAILS 2 Before raise exception');
              --Update_Last_Error_Rec(':LE',':LE208',':Mobile phone load error,',L_SEQ_NO);
              l_empexec_status   := 'LE';
              l_empexec_err_code := 'LE209';
              l_empexec_err_msg  := 'Mobile phone load error - '||L_ERR_MSG;
              l_empexec_seq_no   := L_SEQ_NO;
              raise empexec;
              --COMMIT;
            END IF;
          END IF;
          L_ERR_MSG := NULL;
          -----------------------< Calling employee Salary details Creation Procedure >-------------------------------------------
          FND_FILE.PUT_LINE(FND_FILE.LOG,'Before Calling Salary');
          CREATE_EMP_SALARY_DETAILS(P_HR_EMP_REC => p_hcm_emp_val_rec, p_err_msg => L_ERR_MSG);
          --IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'CREATE_EMP_SALARY_DETAILS is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'CREATE_EMP_SALARY_DETAILS Before raise exception');
            --Added on 30th July
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'L',
              ERROR_CODE   = ERROR_CODE
              ||'L',
              ERROR_MSG = ERROR_MSG
              ||'Failed to create Salary Details and do it manually, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
            --COMMIT;
          END IF;
          L_ERR_MSG := NULL;
          -----------------------< Calling employee Costing Procedure >-------------------------------------------
          FND_FILE.PUT_LINE(FND_FILE.LOG,'Before Calling Emp Costing');
          Create_emp_costing(P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG);
          --IF l_err_msg IS NOT NULL THEN
          IF l_err_msg IS NULL THEN
            fnd_file.put_line(fnd_file.log,'Create_emp_costing is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'Create_emp_costing Before raise exception');
            --Added on 30th July
            UPDATE XXHA_REC_EMP_INT_STG
            SET STATUS_STG = 'L',
              ERROR_CODE   = ERROR_CODE
              ||'L',
              ERROR_MSG = ERROR_MSG
              ||'Creating the Costing Details is Failed and Create it Manually, '
            WHERE TRANSACTION_ID_STG = L_SEQ_NO;
          END IF;
          L_ERR_MSG := NULL;
          -----------------------< Calling employee RECRUITMENT DETAILS >-------------------------------------------
          --BEGIN
          FND_FILE.PUT_LINE(FND_FILE.LOG,'HAE RECRUITMENT DETAILS Start:'||g_person_id);
          --g_person_id is getting null, so fetched the id in the called procedure and overriding the g_person_id value with ln_person_id
          CREATE_PERSON_EXTRA_INFO( L_BUSINESS_GROUP => p_hcm_emp_val_rec.NEW_BUSINESS_GROUP, L_TRANSACTION_ID_STG => p_hcm_emp_val_rec.TRANSACTION_ID_STG, L_PERSON_ID => g_person_id, L_INFORMATION_TYPE => 'HAE_RECRUITMENT_DETAILS', L_INFORMATION_CATEGORY => 'HAE_RECRUITMENT_DETAILS', L_INFORMATION1 => TO_CHAR(TO_DATE(p_hcm_emp_val_rec.HIRE_DATE,'DD/MM/RRRR'),'RRRR/MM/DD HH:MI:SS'), L_INFORMATION2 => p_hcm_emp_val_rec.REQ_NUMBER, L_Information3 => p_hcm_emp_val_rec.REC_SOURCE_TYPE, L_INFORMATION4 => p_hcm_emp_val_rec.REC_SOURCE, L_Information5 => NULL,--p_hcm_emp_val_rec.REC_SOURCE_DETAIL,
          L_INFORMATION6 => NULL, L_INFORMATION7 => NULL, L_INFORMATION8 => NULL, L_INFORMATION9 => NULL, L_INFORMATION10 => NULL, L_INFORMATION11 => NULL, L_INFORMATION12 => NULL, L_INFORMATION13 => NULL, L_INFORMATION14 => NULL, L_INFORMATION15 => NULL, l_PERSON_EXTRA_INFO_ID => L_PERSON_EXTRA_INFO_ID ,                                                                                                                                                                                                                                                            -- out values
          l_OBJECT_VERSION_NUMBER => L_OBJECT_VERSION_NUMBER                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  -- out values
          );
          --end if;
          --COMMIT;
          IF L_PERSON_EXTRA_INFO_ID IS NOT NULL THEN
            fnd_file.put_line(fnd_file.log,'CREATE_PERSON_EXTRA_INFO is Successful');
          ELSE
            fnd_file.put_line(fnd_file.log,'CREATE_PERSON_EXTRA_INFO Before raise exception');
            --Update_Last_Error_Rec(':LE',':LE211',':Extra info load error,',L_SEQ_NO);
            l_empexec_status   := 'LE';
            l_empexec_err_code := 'LE212';
            l_empexec_err_msg  := 'Extra info load error - '||L_ERR_MSG;
            l_empexec_seq_no   := L_SEQ_NO;
            UPDATE XXHA_REC_EMP_INT_STG
            SET status_stg ='L' ,
              --error_code          = 'LE212',
              --ERROR_MSG           ='Person Extra Information - Failed'
              load_msg            = 'Person Extra Information - Failed'
            WHERE 1               =1
            AND transaction_id_stg=L_SEQ_NO;
            --raise empexec;
          END IF;
          FND_FILE.PUT_LINE(FND_FILE.LOG,'HAE RECRUITMENT DETAILS End');
          L_ERR_MSG := NULL;
          --END IF;
          -----------------------< Calling CREATE ELEMENT ENTRY >-------------------------------------------
          --IF l_business_group ='BG_MY' THEN
          FND_FILE.PUT_LINE(FND_FILE.LOG,'Before Calling Element Entry');
          IF p_hcm_emp_val_rec.NEW_BUSINESS_GROUP NOT IN ('BG_US') THEN
            CREATE_ELEMENT_ENTRY (P_HR_EMP_REC => p_hcm_emp_val_rec,p_err_msg => L_ERR_MSG);
            --IF l_err_msg IS NOT NULL THEN
            IF l_err_msg IS NULL THEN
              fnd_file.put_line(fnd_file.log,'CREATE_ELEMENT_ENTRY is Successful');
            ELSE
              fnd_file.put_line(fnd_file.log,'CREATE_ELEMENT_ENTRY Before raise exception');
              --Update_Last_Error_Rec(':LE',':LE212',':Element entry load error,',L_SEQ_NO);
              l_empexec_status   := 'L'; --'LE';
              l_empexec_err_code := NULL;--'LE213';
              l_empexec_err_msg  := 'Element entry load error - '||L_ERR_MSG;
              l_empexec_seq_no   := L_SEQ_NO;
              raise empexec;
              --COMMIT;
            END IF;
            --L_ERR_MSG := NULL;
          END IF;
        END IF; -- to restrict for Rehire Contingent Worker
        --Updating the status to S from V
        fnd_file.put_line(fnd_file.log,'L_ERR_MSG :'||L_ERR_MSG);
        IF g_error=0 AND L_ERR_MSG IS NULL THEN
          UPDATE XXHA_REC_EMP_INT_STG
          SET STATUS_STG     ='S' ,
            last_update_date = sysdate ,
            LAST_UPDATED_BY  = fnd_global.user_id
            --WHERE STATUS_STG       ='V'
          WHERE STATUS_STG      IN ('V','L')
          AND TRANSACTION_ID_STG = L_SEQ_NO;
          --Commit;
        END IF;
        --COMMIT; -- change dk
      EXCEPTION
      WHEN empexec THEN
        --ROLLBACK; --to employee;
        fnd_file.put_line(fnd_file.log,'Rollback Exception:'||sqlerrm);
        fnd_file.put_line(fnd_file.log,'L_ERR_MSG in Rollback Exception:'||L_ERR_MSG);
        fnd_file.put_line(fnd_file.log,'L_SEQ_NO in Rollback Exception:'||L_SEQ_NO);
        --July-10th
        --Update_Last_Error_Rec(':LE',':LE201',':Is Candidate Rehire load error,',L_SEQ_NO);
        Update_Last_Error_Rec(l_empexec_status,l_empexec_err_code,l_empexec_err_msg,l_empexec_seq_no);
      END;
    END LOOP;
    CLOSE cur_load_stg;
    --Only Validation
    UPDATE XXHA_REC_EMP_INT_STG
    SET error_code     = ltrim(rtrim(error_code,':'),':') ,
      error_msg        = ltrim(rtrim(error_msg,','),','),
      last_update_date = sysdate ,
      LAST_UPDATED_BY  = fnd_global.user_id
    WHERE STATUS_STG  IN ('LE','VE');
    --COMMIT; -- change DK
    NULL;
  END; --July 8th not required
EXCEPTION
WHEN OTHERS THEN
  fnd_file.put_line(fnd_file.log,'Main Exception:'||sqlerrm);
END MAIN;
END XXHA_REC_EMP_HIRE_PKG;
/