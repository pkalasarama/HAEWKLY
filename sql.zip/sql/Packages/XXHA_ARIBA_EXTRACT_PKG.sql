create or replace PACKAGE XXHA_ARIBA_EXTRACT_PKG AUTHID CURRENT_USER AS 

/************************************************************************************************************************
* Package Name : XXHA_ARIBA_EXTRACT_PKG                                                                                 *
* Purpose      : This package provides a function to process the Ariba data into the tables.                            *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        29-OCT-2015     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

   PROCEDURE XXHA_PROCESS_DATA(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2
            ,p_Fiscal_Period_1  IN VARCHAR2
            ,p_Fiscal_Period_2  IN VARCHAR2
            ,p_Fiscal_Period_3  IN VARCHAR2);

   PROCEDURE XXHA_LOAD_ARIBA_INVOICES(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2
            ,p_Fiscal_Period_1  IN VARCHAR2
            ,p_Fiscal_Period_2  IN VARCHAR2
            ,p_Fiscal_Period_3  IN VARCHAR2);

   PROCEDURE XXHA_LOAD_ARIBA_PO3_EXTRACT(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2
            ,p_Fiscal_Period_1  IN VARCHAR2
            ,p_Fiscal_Period_2  IN VARCHAR2
            ,p_Fiscal_Period_3  IN VARCHAR2);

   PROCEDURE XXHA_LOAD_ARIBA_ACCOUNT(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2
            ,p_Fiscal_Period_1  IN VARCHAR2
            ,p_Fiscal_Period_2  IN VARCHAR2
            ,p_Fiscal_Period_3  IN VARCHAR2);

   PROCEDURE XXHA_CREATE_VIEW(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2
            ,p_date_from        IN VARCHAR2
            ,p_date_to          IN VARCHAR2);

END XXHA_ARIBA_EXTRACT_PKG;