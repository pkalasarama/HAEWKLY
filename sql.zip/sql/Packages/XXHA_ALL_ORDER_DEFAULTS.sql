/* Formatted on 2015/07/23 15:42 (Formatter Plus v4.8.8) */
CREATE OR REPLACE PACKAGE apps.xxha_all_order_defaults
AS
/*****************************************************************************************
* Name/Purpose : xxha_all_order_defaults                                                 *
* Description  : creates                                                                 *
*                package body xxha_all_order_defaults                                    *
*                Defaulting Rule API for Misc defaults                                   *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 30-MAY-2014     Manuel Fernandes     Initial Creation                                  *
* 21-Jul-2015     HArish Kollipara     Added replace_po_number used in OM defaulting     *
* 23-Jul-2015     D. Browne            Added whse function                               *
*****************************************************************************************/
   g_pkg_name   CONSTANT VARCHAR2 (30) := 'XXHA_ALL_ORDER_DEFAULTS';

   --
   FUNCTION icat_based_fob (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2;

   FUNCTION wb_freight_terms (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2;

   FUNCTION replace_po_number (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2;

   FUNCTION warehouse (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2;
END xxha_all_order_defaults;
/

/* Formatted on 2015/07/23 15:41 (Formatter Plus v4.8.8) */
CREATE OR REPLACE PACKAGE BODY apps.xxha_all_order_defaults
/*****************************************************************************************
* Name/Purpose : xxha_all_order_defaults                                                 *
* Description  : creates                                                                 *
*                package body xxha_all_order_defaults                                    *
*                Defaulting Rule API for Misc defaults                                   *
* Date            Author               Description                                       *
* -----------     -----------------    ---------------                                   *
* 30-MAY-2014     Manuel Fernandes     Initial Creation                                  *
* 21-Jul-2015     HArish Kollipara     Added replace_po_number used in OM defaulting     *
* 23-Jul-2015     D. Browne            Added whse function                               *
*****************************************************************************************/
AS
   g_pkg_name   CONSTANT VARCHAR2 (30) := 'XXHA_ALL_ORDER_DEFAULTS';
   
   FUNCTION replace_po_number (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2
   IS
      l_po_number   VARCHAR2 (600);
   BEGIN
      l_po_number :=
            REPLACE (ont_header_def_hdlr.g_record.cust_po_number, '-0-', '-');
      RETURN l_po_number;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN ont_header_def_hdlr.g_record.cust_po_number;
   END;

   --
   FUNCTION wb_freight_terms (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2
   IS
   BEGIN
      IF ont_header_def_hdlr.g_record.freight_terms_code = 'MXD_WBACC'
      THEN
         RETURN 'ACC';
      ELSIF ont_header_def_hdlr.g_record.freight_terms_code =
                                                          'MXD_WBPAID_HAE_DUE'
      THEN
         RETURN 'Due';
      ELSE
         RETURN NULL;
      END IF;
   END wb_freight_terms;

   FUNCTION icat_based_fob (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2
   IS
      r_fob_point   VARCHAR2 (100);
      v_category    VARCHAR2 (255);
   --
   BEGIN
      --desc OE_AK_ORDER_LINES_V
      --insert into haemo.zz_debug(x) values('icat INV ITEM ID:' || to_char(ONT_LINE_DEF_HDLR.g_record.inventory_item_id)||' ship_from_org_id:'||to_char(ONT_LINE_DEF_HDLR.g_record.ship_from_org_id) ||' hdr fob:'||ONT_HEADER_DEF_HDLR.g_record.fob_point_code || ' line nvl fob:'||nvl(ONT_LINE_DEF_HDLR.g_record.fob_point_code, 'MIXED WB TEST'));
      IF     ont_header_def_hdlr.g_record.fob_point_code = 'MIXED WB TEST'
         AND (    ont_line_def_hdlr.g_record.inventory_item_id IS NOT NULL
              AND ont_line_def_hdlr.g_record.inventory_item_id !=
                                                            fnd_api.g_miss_num
             )
         AND ont_line_def_hdlr.g_record.ship_from_org_id IS NOT NULL
         AND (   ont_line_def_hdlr.g_record.fob_point_code = 'MIXED WB TEST'
              OR ont_line_def_hdlr.g_record.fob_point_code =
                                                           fnd_api.g_miss_char
             )
      THEN
         --insert into haemo.zz_debug(x) values('icat inside fob'||to_char(ONT_LINE_DEF_HDLR.g_record.inventory_item_id));
         BEGIN
            SELECT mc.segment1
              INTO v_category
              FROM mtl_item_categories mic,
                   mtl_category_sets mcs,
                   mtl_categories mc
             WHERE inventory_item_id =
                                  ont_line_def_hdlr.g_record.inventory_item_id
               AND organization_id =
                                   ont_line_def_hdlr.g_record.ship_from_org_id
               AND mic.category_set_id = mcs.category_set_id
               AND mcs.category_set_name = 'Inventory'
               AND mc.category_id = mic.category_id;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_category := 'NONE';
         END;

         --insert into haemo.zz_debug(x) values('icat inside fob v_category'||v_category);
         IF v_category = 'WB'
         THEN
            r_fob_point := 'ORIGIN';
         ELSE
            r_fob_point := 'DESTINATION';
         END IF;

         --insert into haemo.zz_debug(x) values('icat new fob:' || r_fob_point);
         RETURN r_fob_point;
      END IF;

      RETURN NULL;
   END icat_based_fob;

   FUNCTION warehouse (
      p_database_object_name   IN   VARCHAR2,
      p_attribute_code         IN   VARCHAR2
   )
      RETURN VARCHAR2
   IS
   BEGIN 
      --RxC Standard Order type
      IF ont_header_def_hdlr.g_record.order_type_id = 2353
      THEN
         RETURN  ont_header_def_hdlr.g_record.ship_from_org_id;
      END IF;
      
      RETURN NULL;
   END;
--create table haemo.zz_debug (x varchar2(1000));
--select * from haemo.zz_debug
--delete from haemo.zz_debug where x like '%AVO%'--
END xxha_all_order_defaults;
/
