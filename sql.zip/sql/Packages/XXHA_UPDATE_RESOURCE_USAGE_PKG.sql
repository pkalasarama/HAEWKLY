CREATE OR REPLACE package XXHA_UPDATE_RESOURCE_USAGE_PKG
as
  PROCEDURE MAIN(
                   errbuf			    OUT VARCHAR2,
			             retcode			    OUT NUMBER,
                   res_name        varchar2,
                   source_org_code number,
                   dest_org_code   number
                   );
end XXHA_UPDATE_RESOURCE_USAGE_PKG;

/


CREATE OR REPLACE package body XXHA_UPDATE_RESOURCE_USAGE_PKG
as
    PROCEDURE MAIN(
                   errbuf			    OUT VARCHAR2,
			             retcode			    OUT NUMBER,
                   res_name        varchar2,
                   source_org_code number,
                   dest_org_code   number
                   ) is

  cursor res_items  is
       SELECT nvl(rtg.common_assembly_item_id, rtg.assembly_item_id) a_item,
           ors.usage_rate_or_amount usage_rate,
           os.effectivity_date,
           nvl(rtg.alternate_routing_designator, 0) alt_des
      FROM BOM_OPERATIONAL_ROUTINGS RTG,
           BOM_OPERATION_SEQUENCES  OS,
           BOM_RESOURCES            R,
           BOM_OPERATION_RESOURCES  ORS,
           (select *
            from BOM_OPERATIONAL_ROUTINGS rtg,
                 BOM_OPERATION_SEQUENCES  OS,
                 BOM_OPERATION_RESOURCES  ORS,
                 BOM_RESOURCES            R
            where RTG.COMMON_ROUTING_SEQUENCE_ID=OS.ROUTING_SEQUENCE_ID
            and OS.OPERATION_SEQUENCE_ID=ORS.OPERATION_SEQUENCE_ID
            and R.RESOURCE_ID = ORS.RESOURCE_ID
            and r.resource_code = res_name
            and rtg.organization_id=dest_org_code
            and os.effectivity_date <= sysdate
            and nvl(os.disable_date, sysdate) >= sysdate
            and rtg.routing_type = 1) rtg1
     WHERE R.RESOURCE_ID = ORS.RESOURCE_ID
       AND ORS.OPERATION_SEQUENCE_ID = OS.OPERATION_SEQUENCE_ID
       AND OS.ROUTING_SEQUENCE_ID = RTG.COMMON_ROUTING_SEQUENCE_ID
       and r.organization_id = source_org_code
       and r.resource_code = res_name
       and os.effectivity_date <= sysdate
       and nvl(os.disable_date, sysdate) >= sysdate
       and rtg.routing_type = 1
       and rtg.assembly_item_id=rtg1.assembly_item_id(+)
       and nvl(rtg.alternate_routing_designator,0)=nvl(rtg1.alternate_routing_designator,0)
       and ors.resource_seq_num=rtg1.resource_seq_num
       and os.operation_seq_num=rtg1.operation_seq_num
       and ors.usage_rate_or_amount!=rtg1.usage_rate_or_amount
     order by nvl(rtg.alternate_routing_designator, ' '),
              os.operation_seq_num;

  vt res_items%rowtype;
begin
  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Update resource - '||res_name);
  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Source organization id - '||source_org_code);
  FND_FILE.PUT_LINE(FND_FILE.LOG, 'Destination organization id - '||dest_org_code);
  for vt in res_items loop
      insert into bom_op_resources_interface
      (operation_sequence_id, resource_seq_num, process_flag, resource_id,
       transaction_type, usage_rate_or_amount, basis_type, creation_date,
       assembly_item_id, organization_id, operation_seq_num, effectivity_date,
       organization_code, alternate_routing_designator)
      SELECT os.operation_sequence_id, ors.resource_seq_num, 1, r.resource_id,
             'UPDATE', vt.usage_rate, ORS.BASIS_TYPE, rtg.creation_date,
             nvl(rtg.common_assembly_item_id, rtg.assembly_item_id), r.organization_id, os.operation_seq_num, vt.effectivity_date,
             mp.organization_code,
             rtg.alternate_routing_designator
        FROM BOM_OPERATIONAL_ROUTINGS RTG,
             BOM_OPERATION_SEQUENCES  OS,
             BOM_RESOURCES            R,
             BOM_OPERATION_RESOURCES  ORS,
             mtl_parameters           mp
       WHERE R.RESOURCE_ID = ORS.RESOURCE_ID
         AND ORS.OPERATION_SEQUENCE_ID = OS.OPERATION_SEQUENCE_ID
         AND OS.ROUTING_SEQUENCE_ID = RTG.COMMON_ROUTING_SEQUENCE_ID
         and r.organization_id = dest_org_code
         and r.resource_code = res_name
         and os.effectivity_date <= sysdate
         and nvl(os.disable_date, sysdate) >= sysdate
         and rtg.routing_type = 1
         and rtg.assembly_item_id(+) = vt.a_item
         and nvl(rtg.alternate_routing_designator, 0) = vt.alt_des
         and rtg.assembly_item_id is not null
         and r.organization_id = mp.organization_id;
  END LOOP;
  commit;
exception
when others then
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Error :'||substr(sqlerrm,1,80));
    retcode := 3;
    rollback;
END;
end XXHA_UPDATE_RESOURCE_USAGE_PKG;

/
