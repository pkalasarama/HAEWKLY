CREATE OR REPLACE PACKAGE xxha_ap_payment_event AUTHID CURRENT_USER AS
/*$Header: xxhaappaymentevent.pkh 120.1371 2013/10/30 4:00 KDAGOSTINO noship             $*/
/*==============================================================================
                                Haemonetics
                   Oracle Applications Release 12.1.3
      Description :   This package contains procedures used in a subscription
                      within the business event
                      oracle.apps.fnd.concurrent.program.completed. The
                      subscription looks for the Payables payment process and
                      executes a procedure to encrypt and rename the file.
      Module Name :   Accounts Payable (AP)/Payments (IBY)
      Program Name:   xxha_ap_payment_event (Package Header)
         File Name:   xxhaappaymentevent.pkh
      Company Name:   Haemonetics
      Schema owner:   APPS
    Run environment:  PL/SQL

   Modification History:
   Name            Date         Description
   --------------- ----------   ------------------------------------------------
   k. DAgostino    10/30/2013   Program created.
  ==============================================================================*/
	FUNCTION submit_encryption(p_sub_guid in RAW,
                             p_event in out WF_EVENT_T)
                             RETURN VARCHAR2;

--  FUNCTION xxha_capture_event_parameters(p_subscription_guid IN RAW,
--                                         p_event             IN OUT NOCOPY wf_event_t)
--                                         RETURN VARCHAR2;

end xxha_ap_payment_event;
/


CREATE OR REPLACE PACKAGE BODY xxha_ap_payment_event AS
/*$Header: xxhaappaymentevent.pkb 120.1371 2013/10/30 4:00 KDAGOSTINO noship             $*/
/*==============================================================================
                                Haemonetics
                   Oracle Applications Release 12.1.3
      Description :   This package contains procedures used in a subscription
                      within the business event
                      oracle.apps.fnd.concurrent.program.completed. The
                      subscription looks for the Payables payment process and
                      executes a procedure to encrypt and rename the file.
      Module Name :   Accounts Payable (AP)/Payments (IBY)
      Program Name:   xxha_ap_payment_event (Package Body)
         File Name:   xxhaappaymentevent.pkb
      Company Name:   Haemonetics
      Schema owner:   APPS
    Run environment:  PL/SQL

   Modification History:
   Name            Date         Description
   --------------- ----------   ------------------------------------------------
   k. DAgostino    10/30/2013   Program created.
   S. Boppana      06/17/2014   Added code to enforce user_id
  ==============================================================================*/
	FUNCTION submit_encryption
	(
		p_sub_guid in RAW,
		p_event in out WF_EVENT_T
	)RETURN VARCHAR2
	IS
    l_wf_parameter_list_t        wf_parameter_list_t;
    l_parameter3_name            VARCHAR2(30);
    l_parameter3_value           VARCHAR2(4000);
    l_parameter4_name            VARCHAR2(30);
    l_parameter4_value           VARCHAR2(4000);
		l_event_data	               CLOB;
		l_event_name	               VARCHAR2(100);
		l_status	                   VARCHAR2(100)	:= 'SUCCESS';
		l_err_msg	                   VARCHAR2(1000);
    l_request_id                 number;
    l_outbound_file_prefix       iby_sys_pmt_profiles_b.outbound_pmt_file_prefix%TYPE;
    l_payment_currency_code      iby_pay_instructions_all.payment_currency_code%TYPE;
    l_outbound_pmt_file_dir      iby_sys_pmt_profiles_b.outbound_pmt_file_directory%TYPE;
    L_OUTBOUND_FILENAME          VARCHAR2(50);
    L_CONCURRENT_PROGRAM_NAME    FND_CONCURRENT_PROGRAMS_TL.USER_CONCURRENT_PROGRAM_NAME%TYPE;

    lRequest_id NUMBER;
  L_PRIVKEY  VARCHAR2(50);
  L_PUBKEY  VARCHAR2(50);
  l_user_id number;
                 l_resp_id number;
                 l_resp_appl_id number;


  cursor lc_keys is
    select prk.default_value, pbk.default_value from
    (select default_value from FND_DESCR_FLEX_COL_USAGE_VL  a
    where a.DESCRIPTIVE_FLEXFIELD_NAME like '$SRS$.HAE_ENCRYPT_PGP'
      and a.END_USER_COLUMN_NAME = 'Haemo''s private key') prk,
    (select default_value from FND_DESCR_FLEX_COL_USAGE_VL  a
    WHERE A.DESCRIPTIVE_FLEXFIELD_NAME LIKE '$SRS$.HAE_ENCRYPT_PGP'
      AND A.END_USER_COLUMN_NAME = 'AP Check public key') PBK;

	BEGIN
---  Uncomment the following lines when debugging ----
--		l_event_data	:= p_event.GETEVENTDATA();
--		l_event_name	:= p_event.GETEVENTNAME();
--
--		IF (p_event.GETEVENTNAME() = 'oracle.apps.fnd.concurrent.program.completed') THEN
--			l_event_name := 'Program Completed';
--		ELSIF (p_event.GETEVENTNAME() = 'oracle.apps.fnd.concurrent.request.completed') THEN
--			l_event_name := 'Request Completed';
--		END IF;
---  End Debugging lines ----



    l_wf_parameter_list_t  := p_event.getparameterlist();
    l_request_id       := l_wf_parameter_list_t(1)
                           .getvalue();
    l_parameter3_name  := l_wf_parameter_list_t(3)
                           .getname();
    l_parameter3_value := l_wf_parameter_list_t(3)
                           .getvalue();
    l_parameter4_name  := l_wf_parameter_list_t(4)
                           .getname();
    l_parameter4_value := l_wf_parameter_list_t(4)
                           .getvalue();

  /*INSERT INTO haemo.haemo_ap_payment_event VALUES
			(l_event_name,
       l_request_id,
       l_parameter3_name,
       l_parameter3_value,
       l_parameter4_name,
       l_parameter4_value,
       l_payment_currency_code,
       l_outbound_pmt_file_dir,
       l_outbound_filename
       );

		COMMIT;
    */
-- Check for concurrent program "Format Payment Instructions with Text Output"
    L_PAYMENT_CURRENCY_CODE := '';
    l_outbound_pmt_file_dir := '';
    L_OUTBOUND_FILENAME     := '';
    Begin
    SELECT USER_CONCURRENT_PROGRAM_NAME
    INTO l_concurrent_program_name
    FROM FND_CONCURRENT_PROGRAMS_TL
    WHERE APPLICATION_ID = L_PARAMETER3_VALUE  -- application id 673
    AND CONCURRENT_PROGRAM_ID = L_PARAMETER4_VALUE
    AND LANGUAGE = 'US';
/*
    INSERT INTO HAEMO.HAEMO_AP_PAYMENT_EVENT VALUES
			(l_concurrent_program_name,
       l_request_id,
       l_parameter3_name,
       l_parameter3_value,
       l_parameter4_name,
       l_parameter4_value,
       l_payment_currency_code,
       l_outbound_pmt_file_dir,
       l_outbound_filename
       );
    commit;
*/
-- concurrent program id
    EXCEPTION WHEN OTHERS THEN
    FND_FILE.PUT_LINE(FND_FILE.LOG, 'Concurrent program name not found for '||SQLERRM);
    	/*INSERT INTO HAEMO.HAEMO_AP_PAYMENT_EVENT VALUES
			('Error1',
       l_request_id,
       l_parameter3_name,
       l_parameter3_value,
       l_parameter4_name,
       l_parameter4_value,
       l_payment_currency_code,
       l_outbound_pmt_file_dir,
       l_outbound_filename
       );
*/
    END;
    /*IF (l_parameter3_name = 'PROGRAM_APPLICATION_ID' and l_parameter3_value = 673) and
       (l_parameter4_name = 'CONCURRENT_PROGRAM_ID'  and l_parameter4_value = 305787) THEN*/
   fnd_file.put_line(fnd_file.log, 'Concurrent program name  found '||l_concurrent_program_name);
       BEGIN
          select ispp.outbound_pmt_file_prefix,
                 ipia.payment_currency_code,
                 ispp.outbound_pmt_file_directory,
                 ispp.outbound_pmt_file_prefix||fcr.request_id||ispp.outbound_pmt_file_extension,
                 fcr.requested_by,fcr.responsibility_id,fcr.responsibility_application_id 
                 into
                 l_outbound_file_prefix,
                 l_payment_currency_code,
                 l_outbound_pmt_file_dir,
                 l_outbound_filename,
                 l_user_id,
                 l_resp_id,
                 l_resp_appl_id
            from fnd_concurrent_requests fcr,
                 iby_pay_instructions_all ipia,
                 iby_acct_pmt_profiles_b iapp,
                 iby_sys_pmt_profiles_b ispp
           where fcr.request_id = l_request_id
             and fcr.argument1 = ipia.payment_instruction_id
             and ipia.payment_profile_id = iapp.payment_profile_id
             and iapp.system_profile_code = ispp.system_profile_code;
       EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_err_msg := SQLERRM;
            l_status := 'ERROR';
            RETURN (l_status);
          WHEN OTHERS THEN
            l_err_msg := SQLERRM;
            l_status := 'ERROR';
            RETURN (l_status);
       END;
       
              --added by sreeram 6/17/2014 for enforcing user_id
              fnd_global.APPS_INITIALIZE (l_user_id,l_resp_id,l_resp_appl_id);
              
          IF  l_concurrent_program_name = 'Format Payment Instructions with Text Output'     THEN
       --IF (l_outbound_file_prefix = 'HAEACH' or l_outbound_file_prefix = 'HAEWIRE') THEN
       IF L_OUTBOUND_FILE_PREFIX = 'U_HAE_PJPM_'  THEN
    begin
                 XXHAE_PGP_ENCRYPTION2(L_OUTBOUND_PMT_FILE_DIR||'/'||L_OUTBOUND_FILENAME,L_OUTBOUND_PMT_FILE_DIR||'/PGP_'||substr(L_OUTBOUND_FILENAME,3,length(L_OUTBOUND_FILENAME)),'N');
   EXCEPTION WHEN OTHERS THEN
fnd_file.put_line(fnd_file.log, 'encryption2 error  '||sqlerrm);

	end;
		COMMIT;
       END IF;

    ELSIF L_CONCURRENT_PROGRAM_NAME = 'Format Payment Instructions' THEN

    BEGIN

      OPEN LC_KEYS;
      if lc_keys%notfound then raise_application_error(-20001,'Failed to retrive default values for public/private keys'||chr(10)||'Program: HAE_ENCRYPT_PGP'); end if;
      FETCH LC_KEYS INTO L_PRIVKEY, L_PUBKEY;
      CLOSE LC_KEYS;

    EXCEPTION WHEN OTHERS THEN
   fnd_file.put_line(fnd_file.log, 'check Keys not found '||sqlerrm);
    end;

     BEGIN
         --  XXHAE_PGP_ENCRYPTION2(L_OUTBOUND_PMT_FILE_DIR||'/'||L_OUTBOUND_FILENAME,L_OUTBOUND_PMT_FILE_DIR||'/PGP_'||L_OUTBOUND_FILENAME,'N');

           lRequest_id := fnd_request.submit_request( application => 'HAEMO',
                                             program => 'HAE_ENCRYPT_PGP',
                                             argument1 => L_OUTBOUND_PMT_FILE_DIR||'/'||L_OUTBOUND_FILENAME,
                                             ARGUMENT2 => L_OUTBOUND_PMT_FILE_DIR||'/PGP_'||L_OUTBOUND_FILENAME,
                                             argument3 => l_pubkey,
                                             ARGUMENT4 => L_PRIVKEY,
                                             argument5 => 'Y' -- Changed to 'Y' by sreeram 5/21 to delete the original pdf file.
                                            );
  fnd_file.put_line(fnd_file.log, 'Concurrent program request id '||lRequest_id);
   exception when others then
  fnd_file.put_line(fnd_file.log, 'Concurrent program submission failed for encryprion '||lRequest_id);
	END;
    fnd_file.put_line(fnd_file.log, 'Concurrent program name  found '||l_concurrent_program_name);
    END IF;

/* The following insert is only here for debugging purposes and can be removed when unit testing is completed */
 	/*INSERT INTO haemo.haemo_ap_payment_event VALUES
			(l_event_name,
       l_request_id,
       l_parameter3_name,
       l_parameter3_value,
       l_parameter4_name,
       l_parameter4_value,
       l_payment_currency_code,
       l_outbound_pmt_file_dir,
       l_outbound_filename
       );

		COMMIT;*/
		RETURN (l_status);
	EXCEPTION
		WHEN OTHERS THEN
			l_err_msg := SQLERRM;
			l_status := 'ERROR';
			RETURN (l_status);
	END submit_encryption;

  /* The following function was created for debugging purposes and will retrieve all passed
     parameters and write them to e custom table (haemo.xxha_debug_tab). It may be deleted when
     moving to production. In addition, the subscription should also be excluded when migrating
     to the next environment.   */
 /* FUNCTION xxha_capture_event_parameters(p_subscription_guid IN RAW,
                                         p_event             IN OUT NOCOPY wf_event_t)
                                         RETURN VARCHAR2 IS
    l_wf_parameter_list_t        wf_parameter_list_t;
    l_parameter_name             VARCHAR2(30);
    l_parameter_value            VARCHAR2(4000);
    n_total_number_of_parameters INTEGER;
    n_current_parameter_position NUMBER := 1;
  BEGIN
    --Clear the debug table to begin with
    xxha_debug('DELETE');
    l_wf_parameter_list_t        := p_event.getparameterlist();
    n_total_number_of_parameters := l_wf_parameter_list_t.COUNT();
    xxha_debug('Name of the event is =>' || p_event.geteventname());
    xxha_debug('Key of the event is =>' || p_event.geteventkey());
    xxha_debug('Event Data is =>' || p_event.EVENT_DATA);
    xxha_debug('Total number of parameters passed to event are =>' ||
              n_total_number_of_parameters);
    WHILE (n_current_parameter_position <= n_total_number_of_parameters) LOOP
       l_parameter_name  := l_wf_parameter_list_t(n_current_parameter_position)
                           .getname();
       l_parameter_value := l_wf_parameter_list_t(n_current_parameter_position)
                           .getvalue();
       xxha_debug('Parameter Name=>' || l_parameter_name || ' has value =>' ||
                l_parameter_value);
       n_current_parameter_position := n_current_parameter_position + 1;
    END LOOP;
    RETURN 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      xxha_debug('Unhandled Exception=>' || SQLERRM);
  END xxha_capture_event_parameters;
 */
end xxha_ap_payment_event;
/
