CREATE OR REPLACE PACKAGE      xxha_sales_trace_import_pkg
IS
/**********************************************************************************************************************************
*
* Package:     xxha_sales_trace_import_pkg
* Description:  accepts web adi data and creates a sales order, for 3rd party sales tracings
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    27-Feb-2014  Initial Creation
*
**********************************************************************************************************************************/
   g_debug   VARCHAR2 (1) := 'Y';

   PROCEDURE import_order_conc (
      errbuf          OUT      VARCHAR2,
      errcode         OUT      VARCHAR2,
      p_delete_flag   IN       VARCHAR2
   );

   PROCEDURE import_order (
      p_unique_identifier          IN   VARCHAR2 DEFAULT NULL,
      p_third_party_cust           IN   VARCHAR2 DEFAULT NULL,
      p_third_party_cust_name      IN   VARCHAR2 DEFAULT NULL,
      p_end_cust                   IN   VARCHAR2 DEFAULT NULL,
      p_end_cust_ship_to_site      IN   VARCHAR2 DEFAULT NULL,
      p_third_party                IN   VARCHAR2 DEFAULT NULL,
      p_date_of_sale               IN   VARCHAR2 DEFAULT NULL,
      p_gl_date                    IN   VARCHAR2 DEFAULT NULL,
      p_cust_or_int_item           IN   VARCHAR2 DEFAULT NULL,
      p_uom                        IN   VARCHAR2 DEFAULT NULL,
      p_quantity                   IN   VARCHAR2 DEFAULT NULL,
      p_unit_price                 IN   VARCHAR2 DEFAULT NULL,
      p_currency                   IN   VARCHAR2 DEFAULT NULL,
      p_po                         IN   VARCHAR2 DEFAULT NULL,
      p_bill_to_site               IN   VARCHAR2 DEFAULT NULL,
      p_dist_svc_provider_ar_inv   IN   VARCHAR2 DEFAULT NULL
   );
END;
/


CREATE OR REPLACE PACKAGE BODY      xxha_sales_trace_import_pkg
IS
/**********************************************************************************************************************************
*
* Package:     xxha_sales_trace_import_pkg
* Description:  accepts web adi data and creates a sales order, for 3rd party sales tracings
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    27-Feb-2014  Initial Creation
* Dbrowne       1.1    12-MAR-2014  Modify blanket number query
* Dbrowne       2.0    03-MAR-2014  R12 MOAC Change
*
**********************************************************************************************************************************/
   PROCEDURE DEBUG (p_description IN VARCHAR2)
   IS
   BEGIN
      IF g_debug = 'Y'
      THEN
         fnd_file.put_line (fnd_file.LOG, p_description);
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         DEBUG (   'An error occurred in '
                || 'display_log'
                || ' - '
                || SUBSTR (SQLERRM, 1, 80)
               );
         RAISE;
   END DEBUG;

   PROCEDURE output (p_description IN VARCHAR2)
   IS
   BEGIN
      fnd_file.put_line (fnd_file.output, p_description);
   END;

   --PROCEDURE logit (p_mesg VARCHAR2)
   --IS
   --   PRAGMA AUTONOMOUS_TRANSACTION;
   --BEGIN
   --   INSERT INTO xxha_log_tmp
   --        VALUES (SYSDATE, p_mesg);

   --   COMMIT;
   --END;
   FUNCTION get_order_type_id (p_order_type IN VARCHAR2)
      RETURN NUMBER
   IS
      v_return   NUMBER;
   BEGIN
      SELECT transaction_type_id
        INTO v_return
        FROM oe_transaction_types_tl
       WHERE LANGUAGE = 'US' AND NAME = p_order_type;

      RETURN v_return;
   EXCEPTION
      WHEN OTHERS
      THEN
         DEBUG ('get_order_type_id ' || p_order_type);
         RETURN NULL;
   END;

   FUNCTION get_order_line_type_id (p_order_type IN VARCHAR2)
      RETURN NUMBER
   IS
      v_return   NUMBER;
   BEGIN
      SELECT ott.transaction_type_id
        INTO v_return
        FROM oe_transaction_types_tl ott, oe_transaction_types_all otta
       WHERE ott.transaction_type_id = otta.transaction_type_id
         AND transaction_type_code = 'LINE'
         AND LANGUAGE = 'US'
         AND NAME = p_order_type;

      RETURN v_return;
   EXCEPTION
      WHEN OTHERS
      THEN
         DEBUG ('get_order_line_type_id ' || p_order_type);
         RETURN NULL;
   END;

   FUNCTION validatedate (p_value IN VARCHAR2, p_error_message IN OUT VARCHAR2)
      RETURN DATE
   IS
      v_return   DATE;
   BEGIN
      SELECT TO_DATE (p_value, 'mm/dd/yyyy')
        INTO v_return
        FROM DUAL;

      RETURN v_return;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_message := p_error_message || ' Invalid date ' || p_value;
         RETURN NULL;
   END;

   FUNCTION validatenumber (
      p_value           IN       VARCHAR2,
      p_error_message   IN OUT   VARCHAR2
   )
      RETURN NUMBER
   IS
      v_return   NUMBER;
   BEGIN
      SELECT TO_NUMBER (p_value)
        INTO v_return
        FROM DUAL;

      RETURN v_return;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_message := p_error_message || ' Invalid number ' || p_value;
         RETURN 0;
   END;

   PROCEDURE validate_shipto (
      p_intf            IN OUT   xxha_sales_trace_intf%ROWTYPE,
      p_error_message   IN OUT   VARCHAR2
   )
   IS
      v_account_id    NUMBER;
      v_party_id      NUMBER;
      v_site_use_id   NUMBER;
      v_org_id        NUMBER;
   BEGIN
      fnd_profile.get ('ORG_ID', v_org_id);

      BEGIN
         --specific ship to site
         SELECT hca.cust_account_id, hp.party_id, hsu.site_use_id
           INTO v_account_id, v_party_id, v_site_use_id
           FROM hz_cust_accounts hca,
                hz_parties hp,
                hz_cust_acct_sites hcas,
                hz_cust_site_uses hsu,
                hz_party_sites hps,
                hz_locations hl
          WHERE hca.party_id = hp.party_id
            AND hp.status = 'A'
            AND hcas.status = 'A'
            AND hsu.status = 'A'
            AND hps.status = 'A'
            AND hca.status = 'A'
            AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
            AND hca.cust_account_id = hcas.cust_account_id
            AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
            AND site_use_code = 'SHIP_TO'
            AND hps.party_site_id = hcas.party_site_id
            AND hl.location_id = hps.location_id
            AND party_site_number = p_intf.end_cust_ship_to_site;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            IF p_intf.third_party IS NOT NULL
            THEN
               BEGIN
                  SELECT hca.cust_account_id, hp.party_id, hsu.site_use_id
                    INTO v_account_id, v_party_id, v_site_use_id
                    FROM hz_cust_accounts hca,
                         hz_parties hp,
                         hz_cust_acct_sites hcas,
                         hz_cust_site_uses hsu,
                         hz_party_sites hps,
                         hz_locations hl
                   WHERE hca.party_id = hp.party_id
                     AND hp.status = 'A'
                     AND hcas.status = 'A'
                     AND hsu.status = 'A'
                     AND hps.status = 'A'
                     AND hca.status = 'A'
                     AND site_use_code = 'SHIP_TO'
                     AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
                     AND hca.cust_account_id = hcas.cust_account_id
                     AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
                     AND hps.party_site_id = hcas.party_site_id
                     AND hl.location_id = hps.location_id
                     AND hsu.attribute3 = p_intf.third_party;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     p_error_message :=
                           p_error_message
                        || ' Invalid Ship 3rd Party: '
                        || p_intf.third_party
                        || ':'
                        || v_org_id;
                  WHEN TOO_MANY_ROWS
                  THEN
                     p_error_message :=
                        p_error_message
                        || ' Multiple Ship 3rd parties found.';
               END;
            ELSE
               p_error_message := p_error_message || ' Invalid Ship Site.';
            END IF;
      END;

      p_intf.ship_to_account_id := v_account_id;
      p_intf.ship_to_party_id := v_party_id;
      p_intf.ship_to_site_id := v_site_use_id;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_message := p_error_message || ' Invalid Ship Customer.';
   END;

   FUNCTION get_order_source_id
      RETURN NUMBER
   IS
      v_return   NUMBER;
   BEGIN
      SELECT order_source_id
        INTO v_return
        FROM oe_order_sources
       WHERE NAME = '3rd_Party_Tracing';

      RETURN v_return;
   END;

   PROCEDURE validate_item (
      p_intf    IN OUT   xxha_sales_trace_intf%ROWTYPE,
      p_error   IN OUT   VARCHAR2
   )
   IS
      v_org_id                NUMBER;
      v_master_org_id         NUMBER;
      v_test                  NUMBER;
      v_customer_order_flag   VARCHAR2 (1);
      v_org_ind_flag          VARCHAR2 (1);
      v_xref_org_id           NUMBER;
   BEGIN
      fnd_profile.get ('ORG_ID', v_org_id);

      SELECT parameter_value
        INTO v_master_org_id
        FROM oe_sys_parameters_all
       WHERE org_id = v_org_id AND parameter_code = 'MASTER_ORGANIZATION_ID';

      BEGIN
         SELECT inventory_item_id
           INTO p_intf.inventory_item_id
           FROM mtl_system_items
          WHERE segment1 = p_intf.cust_or_int_item
            AND organization_id = v_master_org_id
            AND enabled_flag = 'Y'
            AND customer_order_enabled_flag = 'Y'
            AND customer_order_flag = 'Y';
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;

      IF p_intf.inventory_item_id IS NULL
      THEN
         BEGIN
            SELECT org_independent_flag, inventory_item_id,
                   mcr.organization_id, cross_reference,
                   mcrt.cross_reference_type
              INTO v_org_ind_flag, p_intf.inventory_item_id,
                   v_xref_org_id, p_intf.xref_item,
                   p_intf.xref_type
              FROM mtl_cross_reference_types mcrt, mtl_cross_references_v mcr
             WHERE NVL (disable_date, SYSDATE + 1) > SYSDATE
               AND mcrt.cross_reference_type = mcr.cross_reference_type
               AND cross_reference = p_intf.cust_or_int_item;

            BEGIN
               SELECT inventory_item_id
                 INTO p_intf.inventory_item_id
                 FROM mtl_system_items
                WHERE inventory_item_id = p_intf.inventory_item_id
                  AND organization_id = v_master_org_id
                  AND enabled_flag = 'Y'
                  AND customer_order_enabled_flag = 'Y'
                  AND customer_order_flag = 'Y';
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  p_error := p_error || ' Item from xref not active.';
            END;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               p_error := p_error || ' No xref found.';
            WHEN TOO_MANY_ROWS
            THEN
               p_error := p_error || ' More than 1 xref found.';
         END;

         IF v_org_ind_flag = 'N'
         THEN
            IF v_master_org_id != v_xref_org_id
            THEN
               p_error := p_error || ' Item xref not setup for this org.';
            END IF;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         --logit (SQLERRM);
         p_error := p_error || ' No item found.';
   END;

   PROCEDURE validate_billto (
      p_intf            IN OUT   xxha_sales_trace_intf%ROWTYPE,
      p_error_message   IN OUT   VARCHAR2
   )
   IS
   BEGIN
      SELECT hca.cust_account_id, hp.party_id,
             hsu.site_use_id
        INTO p_intf.bill_to_account_id, p_intf.bill_to_party_id,
             p_intf.bill_to_site_id
        FROM hz_cust_accounts hca,
             hz_parties hp,
             hz_cust_acct_sites hcas,
             hz_cust_site_uses hsu,
             hz_party_sites hps,
             hz_locations hl
       WHERE hca.party_id = hp.party_id
         AND hp.status = 'A'
         AND hcas.status = 'A'
         AND hsu.status = 'A'
         AND hps.status = 'A'
         AND hca.status = 'A'
         AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
         AND hca.cust_account_id = hcas.cust_account_id
         AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
         AND hps.party_site_id = hcas.party_site_id
         AND hl.location_id = hps.location_id
         AND bill_to_flag = 'P'
         AND site_use_code = 'BILL_TO'
         AND hp.party_id = p_intf.ship_to_party_id;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_error_message :=
               p_error_message
            || ' No Primary Bill To found for '
            || p_intf.bill_to_party_id;
      WHEN TOO_MANY_ROWS
      THEN
         p_error_message :=
               p_error_message
            || ' Too many Bill To''s '
            || p_intf.bill_to_party_id;
      WHEN OTHERS
      THEN
         p_error_message :=
               p_error_message
            || ' Unknown bill to error '
            || p_intf.bill_to_party_id;
   END;

   PROCEDURE validate_deliverto (
      p_intf            IN OUT   xxha_sales_trace_intf%ROWTYPE,
      p_error_message   IN OUT   VARCHAR2
   )
   IS
      v_test   NUMBER;
   BEGIN
      SELECT hp.party_id, category_code,
             hca.cust_account_id
        INTO p_intf.deliver_to_party_id, p_intf.deliver_to_party_category,
             p_intf.deliver_to_account_id
        FROM hz_parties hp, hz_cust_accounts hca
       WHERE hp.party_id = hca.party_id
         AND hca.account_number = p_intf.third_party_cust
         AND hp.status = 'A'
         AND hca.status = 'A';

      --
      SELECT COUNT (*)
        INTO v_test
        FROM hz_cust_acct_relate_all
       WHERE related_cust_account_id = p_intf.bill_to_account_id
         AND cust_account_id = p_intf.deliver_to_account_id;

      IF v_test = 0
      THEN
         p_error_message := p_error_message || ' No active rel for deliver.';
      END IF;

      SELECT hca.cust_account_id, hsu.site_use_id
        INTO p_intf.deliver_to_account_id, p_intf.deliver_to_site_id
        FROM hz_cust_accounts_all hca,
             hz_parties hp,
             hz_cust_acct_sites_all hcas,
             hz_cust_site_uses_all hsu,
             hz_party_sites hps,
             hz_locations hl
       WHERE hca.party_id = hp.party_id
         AND hp.status = 'A'
         AND hcas.status = 'A'
         AND hsu.status = 'A'
         AND hps.status = 'A'
         AND site_use_code = 'DELIVER_TO'
         AND hca.status = 'A'
         AND primary_flag = 'Y'
         AND identifying_address_flag = 'Y'
         AND hcas.cust_acct_site_id = hsu.cust_acct_site_id
         AND hca.cust_account_id = hcas.cust_account_id
         AND hsu.cust_acct_site_id = hcas.cust_acct_site_id
         AND hps.party_site_id = hcas.party_site_id
         AND hl.location_id = hps.location_id
         AND hca.cust_account_id = p_intf.deliver_to_account_id;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_error_message :=
               p_error_message
            || ' Invalid deliver to '
            || p_intf.deliver_to_account_id;
      WHEN TOO_MANY_ROWS
      THEN
         --logit ('too many rows');
         p_error_message :=
                        p_error_message || ' More than one deliver to found.';
      WHEN OTHERS
      THEN
         p_error_message :=
               p_error_message
            || ' Invalid deliver to. '
            || p_intf.deliver_to_party_id;
   END;

   FUNCTION get_blanket (p_intf IN OUT xxha_sales_trace_intf%ROWTYPE)
      RETURN NUMBER
   IS
      v_blanket   NUMBER;
   BEGIN
      SELECT distinct order_number
        INTO v_blanket
        FROM oe_blanket_lines_v ool
       WHERE ool.sold_to_org_id = p_intf.bill_to_account_id
         AND NVL (ool.flow_status_code, 'NOT_TERMINATED') = 'ACTIVE'
         AND ool.inventory_item_id = p_intf.inventory_item_id
         AND NVL (on_hold_flag, 'N') = 'N'
         AND p_intf.gl_date BETWEEN start_date_active
                                 AND NVL (end_date_active, SYSDATE + 1);

      RETURN v_blanket;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   PROCEDURE import_order (
      p_unique_identifier          IN   VARCHAR2 DEFAULT NULL,
      p_third_party_cust           IN   VARCHAR2 DEFAULT NULL,
      p_third_party_cust_name      IN   VARCHAR2 DEFAULT NULL,
      p_end_cust                   IN   VARCHAR2 DEFAULT NULL,
      p_end_cust_ship_to_site      IN   VARCHAR2 DEFAULT NULL,
      p_third_party                IN   VARCHAR2 DEFAULT NULL,
      p_date_of_sale               IN   VARCHAR2 DEFAULT NULL,
      p_gl_date                    IN   VARCHAR2 DEFAULT NULL,
      p_cust_or_int_item           IN   VARCHAR2 DEFAULT NULL,
      p_uom                        IN   VARCHAR2 DEFAULT NULL,
      p_quantity                   IN   VARCHAR2 DEFAULT NULL,
      p_unit_price                 IN   VARCHAR2 DEFAULT NULL,
      p_currency                   IN   VARCHAR2 DEFAULT NULL,
      p_po                         IN   VARCHAR2 DEFAULT NULL,
      p_bill_to_site               IN   VARCHAR2 DEFAULT NULL,
      p_dist_svc_provider_ar_inv   IN   VARCHAR2 DEFAULT NULL
   )
   IS
      v_intf      xxha_sales_trace_intf%ROWTYPE;
      v_error     VARCHAR2 (200);
      v_test      NUMBER;
      v_org_id    NUMBER;
      v_user_id   NUMBER;
   BEGIN
      fnd_profile.get ('ORG_ID', v_org_id);
      fnd_profile.get ('USER_ID', v_user_id);
      mo_global.set_policy_context ('S', v_org_id);
      --logit ('Org id ' || v_org_id);
      v_intf := NULL;

      SELECT COUNT (*)
        INTO v_test
        FROM xxha_sales_trace_intf
       WHERE unique_identifier = p_unique_identifier AND import_flag != 'E';

      IF v_test = 0
      THEN
         v_intf.creation_date := SYSDATE;
         v_intf.unique_identifier := p_unique_identifier;
         v_intf.third_party_cust := p_third_party_cust;
         v_intf.third_party_cust_name := p_third_party_cust_name;
         v_intf.end_cust := p_end_cust;
         v_intf.end_cust_ship_to_site := p_end_cust_ship_to_site;
         v_intf.third_party := p_third_party;
         --
         v_intf.date_of_sale := validatedate (p_date_of_sale, v_error);
         --
         v_intf.gl_date := validatedate (p_gl_date, v_error);
         --
         v_intf.cust_or_int_item := p_cust_or_int_item;
         v_intf.uom := p_uom;
         --
         if p_quantity is null then
           v_error := v_error||' Quantity cannot be null.';
         end if;

         v_intf.quantity := validatenumber (p_quantity, v_error);
         --
         v_intf.unit_price := validatenumber (p_unit_price, v_error);
         --
         v_intf.currency := p_currency;
         v_intf.po := p_po;
         v_intf.import_flag := 'N';
         v_intf.bill_to_site := p_bill_to_site;
         v_intf.dist_svc_provider_ar_inv := p_dist_svc_provider_ar_inv;
         v_intf.user_id := v_user_id;
         v_intf.created_by := v_user_id;
         --
         --
         validate_shipto (v_intf, v_error);
         validate_billto (v_intf, v_error);
         validate_deliverto (v_intf, v_error);
         validate_item (v_intf, v_error);
         v_intf.sales_trace_intf_id := xxha_sales_trace_intf_seq.NEXTVAL;

         IF v_intf.deliver_to_party_category = 'DISTRIBUTOR'
         THEN
            v_intf.blanket_number := get_blanket (v_intf);
         END IF;

         IF v_intf.quantity > 0
         THEN
            v_intf.line_type := 'US Indirect Sales Line';
         END IF;

         IF v_intf.quantity < 0
         THEN
            v_intf.line_type := 'US Indirect Sales Return';
         END IF;

         IF v_intf.quantity = 0
         THEN
            v_error := v_error || ' Quantity cannot be zero.';
         END IF;

         v_intf.line_type_id := get_order_type_id (v_intf.line_type);

         IF v_error IS NULL
         THEN
            INSERT INTO xxha_sales_trace_intf
                 VALUES v_intf;

         ELSE
            fnd_message.set_name ('BNE', SUBSTR (v_error, 1, 30));
         END IF;
      ELSE
         fnd_message.set_name ('BNE', 'Already loaded');
      END IF;
   END;

   FUNCTION get_price_list
      RETURN NUMBER
   IS
      v_return   NUMBER;
   BEGIN
      SELECT price_list_id
        INTO v_return
        FROM oe_price_lists
       WHERE NAME = 'US Standard List Price USD';

      RETURN v_return;
   END;

   PROCEDURE import_order_conc (
      errbuf          OUT      VARCHAR2,
      errcode         OUT      VARCHAR2,
      p_delete_flag   IN       VARCHAR2
   )
   IS
      CURSOR c_header
      IS
         SELECT DISTINCT bill_to_site_id, ship_to_site_id,
                         deliver_to_site_id, bill_to_account_id,
                         deliver_to_account_id,
                         DECODE (blanket_number, NULL, 0, 1) blanket_flag,
                         deliver_to_party_category
                    FROM xxha_sales_trace_intf
                   WHERE import_flag = 'N';

      CURSOR c_lines (
         p_bill_site                   IN   NUMBER,
         p_ship_site                   IN   NUMBER,
         p_deliver_site                IN   NUMBER,
         p_blanket                     IN   NUMBER,
         p_deliver_to_party_category   IN   VARCHAR2
      )
      IS
         SELECT *
           FROM xxha_sales_trace_intf
          WHERE import_flag = 'N'
            AND bill_to_site_id = p_bill_site
            AND ship_to_site_id = p_ship_site
            AND deliver_to_site_id = p_deliver_site
            AND DECODE (blanket_number, NULL, 0, 1) = p_blanket
            AND NVL (deliver_to_party_category, 'None') =
                                     NVL (p_deliver_to_party_category, 'None');

      l_api_version_number           NUMBER                               := 1;
      l_return_status                VARCHAR2 (2000);
      l_msg_count                    NUMBER;
      l_msg_data                     VARCHAR2 (2000);
      l_header_rec                   oe_order_pub.header_rec_type;
      l_line_tbl                     oe_order_pub.line_tbl_type;
      l_action_request_tbl           oe_order_pub.request_tbl_type;
      l_line_adj_tbl                 oe_order_pub.line_adj_tbl_type;
      l_header_rec_out               oe_order_pub.header_rec_type;
      l_header_val_rec_out           oe_order_pub.header_val_rec_type;
      l_header_adj_tbl_out           oe_order_pub.header_adj_tbl_type;
      l_header_adj_val_tbl_out       oe_order_pub.header_adj_val_tbl_type;
      l_header_price_att_tbl_out     oe_order_pub.header_price_att_tbl_type;
      l_header_adj_att_tbl_out       oe_order_pub.header_adj_att_tbl_type;
      l_header_adj_assoc_tbl_out     oe_order_pub.header_adj_assoc_tbl_type;
      l_header_scredit_tbl_out       oe_order_pub.header_scredit_tbl_type;
      l_header_scredit_val_tbl_out   oe_order_pub.header_scredit_val_tbl_type;
      l_line_tbl_out                 oe_order_pub.line_tbl_type;
      l_line_val_tbl_out             oe_order_pub.line_val_tbl_type;
      l_line_adj_tbl_out             oe_order_pub.line_adj_tbl_type;
      l_line_adj_val_tbl_out         oe_order_pub.line_adj_val_tbl_type;
      l_line_price_att_tbl_out       oe_order_pub.line_price_att_tbl_type;
      l_line_adj_att_tbl_out         oe_order_pub.line_adj_att_tbl_type;
      l_line_adj_assoc_tbl_out       oe_order_pub.line_adj_assoc_tbl_type;
      l_line_scredit_tbl_out         oe_order_pub.line_scredit_tbl_type;
      l_line_scredit_val_tbl_out     oe_order_pub.line_scredit_val_tbl_type;
      l_lot_serial_tbl_out           oe_order_pub.lot_serial_tbl_type;
      l_lot_serial_val_tbl_out       oe_order_pub.lot_serial_val_tbl_type;
      l_action_request_tbl_out       oe_order_pub.request_tbl_type;
      l_msg_index                    NUMBER;
      v_user_id                      NUMBER;
      v_line_cnt                     NUMBER;
      v_test                         NUMBER;
      v_line_success_cnt             NUMBER                               := 0;
      v_line_error_cnt               NUMBER                               := 0;
      v_header_success_cnt           NUMBER                               := 0;
      v_header_error_cnt             NUMBER                               := 0;
      v_orders_booked                NUMBER                               := 0;
   BEGIN
      fnd_profile.get ('USER_ID', v_user_id);
      DEBUG ('User id is ' || v_user_id);

      IF p_delete_flag = 'Y'
      THEN
         DELETE      xxha_sales_trace_intf
               WHERE import_flag = 'N';

         output (SQL%ROWCOUNT || ' records deleted');
         COMMIT;
         RETURN;
      END IF;

      --delete errored records
      DELETE      xxha_sales_trace_intf
            WHERE import_flag = 'E';

      COMMIT;
      output ('Sales Tracing Order Import');
      output ('');
      output ('Order          Lines');
      output ('------------------------------');

      FOR h IN c_header
      LOOP
         oe_msg_pub.initialize;
         l_header_rec := oe_order_pub.g_miss_header_rec;
         l_header_rec.operation := oe_globals.g_opr_create;
         l_header_rec.order_type_id :=
                                      get_order_type_id ('US Indirect Sales');
         -- domestic return
         l_header_rec.sold_to_org_id := h.bill_to_account_id;
         l_header_rec.invoice_to_org_id := h.bill_to_site_id;
         l_header_rec.ship_to_org_id := h.ship_to_site_id;
         l_header_rec.deliver_to_org_id := h.deliver_to_site_id;
         l_header_rec.order_source_id := get_order_source_id;
         l_header_rec.price_list_id := get_price_list;
         l_header_rec.pricing_date := SYSDATE;
         l_header_rec.transactional_curr_code := 'USD';
         l_header_rec.tp_context := 'US Indirect Sales';
         l_header_rec.tp_attribute1 := h.deliver_to_party_category;
         l_action_request_tbl (1) := oe_order_pub.g_miss_request_rec;

         -- don't book Distributors
         -- without a blanket
         IF (h.deliver_to_party_category = 'DISTRIBUTOR'
             AND h.blanket_flag = 0
            )
         THEN
            l_header_rec.booked_flag := 'N';
            l_header_rec.flow_status_code := 'ENTERED';
         ELSE
            l_header_rec.booked_flag := 'Y';
            l_header_rec.flow_status_code := 'BOOKED';
            l_action_request_tbl (1).request_type := oe_globals.g_book_order;
            l_action_request_tbl (1).entity_code :=
                                                   oe_globals.g_entity_header;
         END IF;

         v_line_cnt := 0;
         DEBUG (   h.bill_to_site_id
                || ':'
                || h.ship_to_site_id
                || ':'
                || h.deliver_to_site_id
                || ':'
                || h.blanket_flag
                || ':'
                || h.deliver_to_party_category
               );
         l_line_tbl.DELETE;

         FOR l IN c_lines (h.bill_to_site_id,
                           h.ship_to_site_id,
                           h.deliver_to_site_id,
                           h.blanket_flag,
                           h.deliver_to_party_category
                          )
         LOOP
            SELECT COUNT (*)
              INTO v_test
              FROM oe_order_lines_all
             WHERE orig_sys_line_ref = l.unique_identifier;

            IF v_test = 0
            THEN
               v_line_cnt := v_line_cnt + 1;
               l_line_tbl (v_line_cnt) := oe_order_pub.g_miss_line_rec;
               l_line_tbl (v_line_cnt).operation := oe_globals.g_opr_create;
               --
               l_line_tbl (v_line_cnt).ordered_item := l.xref_item;
               l_line_tbl (v_line_cnt).item_identifier_type := l.xref_type;
               l_line_tbl (v_line_cnt).inventory_item_id :=
                                                          l.inventory_item_id;
               --
               l_line_tbl (v_line_cnt).ordered_quantity := l.quantity;
               l_line_tbl (v_line_cnt).unit_selling_price := l.unit_price;
               l_line_tbl (v_line_cnt).unit_list_price := l.unit_price;
               l_line_tbl (v_line_cnt).calculate_price_flag := 'N';
               l_line_tbl (v_line_cnt).cust_po_number :=
                                                   l.dist_svc_provider_ar_inv;
               l_line_tbl (v_line_cnt).orig_sys_line_ref :=
                                                          l.unique_identifier;
               l_line_tbl (v_line_cnt).line_type_id :=
                                         get_order_line_type_id (l.line_type);
               l_line_tbl (v_line_cnt).request_date := l.gl_date;
               l_line_tbl (v_line_cnt).promise_date := l.date_of_sale;
               l_line_tbl (v_line_cnt).pricing_date := l.date_of_sale;

               IF (    l.deliver_to_party_category = 'DISTRIBUTOR'
                   AND l.blanket_number IS NULL
                  )
               THEN
                  l_line_tbl (v_line_cnt).booked_flag := 'N';
                  l_line_tbl (v_line_cnt).flow_status_code := 'ENTERED';
               ELSE
                  l_line_tbl (v_line_cnt).booked_flag := 'Y';
                  l_line_tbl (v_line_cnt).flow_status_code := 'BOOKED';
                  l_line_tbl (v_line_cnt).blanket_number := l.blanket_number;
               END IF;

               UPDATE xxha_sales_trace_intf
                  SET import_flag = 'Y'
                WHERE sales_trace_intf_id = l.sales_trace_intf_id;
            ELSE
               --duplicate line
               UPDATE xxha_sales_trace_intf
                  SET import_flag = 'D'
                WHERE sales_trace_intf_id = l.sales_trace_intf_id;
            END IF;
         END LOOP;

         COMMIT;
         l_msg_data := NULL;
         l_msg_count := 0;
         oe_order_pub.process_order
                    (p_api_version_number          => l_api_version_number,
                     p_header_rec                  => l_header_rec,
                     p_line_tbl                    => l_line_tbl,
                     p_action_request_tbl          => l_action_request_tbl,
                     p_line_adj_tbl                => l_line_adj_tbl,
                     x_header_rec                  => l_header_rec_out,
                     x_header_val_rec              => l_header_val_rec_out,
                     x_header_adj_tbl              => l_header_adj_tbl_out,
                     x_header_adj_val_tbl          => l_header_adj_val_tbl_out,
                     x_header_price_att_tbl        => l_header_price_att_tbl_out,
                     x_header_adj_att_tbl          => l_header_adj_att_tbl_out,
                     x_header_adj_assoc_tbl        => l_header_adj_assoc_tbl_out,
                     x_header_scredit_tbl          => l_header_scredit_tbl_out,
                     x_header_scredit_val_tbl      => l_header_scredit_val_tbl_out,
                     x_line_tbl                    => l_line_tbl_out,
                     x_line_val_tbl                => l_line_val_tbl_out,
                     x_line_adj_tbl                => l_line_adj_tbl_out,
                     x_line_adj_val_tbl            => l_line_adj_val_tbl_out,
                     x_line_price_att_tbl          => l_line_price_att_tbl_out,
                     x_line_adj_att_tbl            => l_line_adj_att_tbl_out,
                     x_line_adj_assoc_tbl          => l_line_adj_assoc_tbl_out,
                     x_line_scredit_tbl            => l_line_scredit_tbl_out,
                     x_line_scredit_val_tbl        => l_line_scredit_val_tbl_out,
                     x_lot_serial_tbl              => l_lot_serial_tbl_out,
                     x_lot_serial_val_tbl          => l_lot_serial_val_tbl_out,
                     x_action_request_tbl          => l_action_request_tbl_out,
                     x_return_status               => l_return_status,
                     x_msg_count                   => l_msg_count,
                     x_msg_data                    => l_msg_data
                    );

         IF l_return_status = fnd_api.g_ret_sts_success
         THEN
            v_header_success_cnt := v_header_success_cnt + 1;
            v_line_success_cnt := v_line_success_cnt + l_line_tbl.COUNT;

            -- not booked for some other reason
            SELECT COUNT (*)
              INTO v_test
              FROM oe_order_headers_all
             WHERE header_id = l_header_rec_out.header_id
               AND flow_status_code = 'BOOKED';

            IF v_test = 0
            THEN
               output (l_header_rec_out.order_number);
               output ('***WARNING Order was NOT Booked');

               --
               IF l_header_rec.booked_flag = 'N'
               THEN
                  output ('No blanket found');
               END IF;

               --
               errcode := 1;
               errbuf := 'Not all orders were booked';

               FOR i IN 1 .. v_line_cnt
               LOOP
                  output ('               '
                          || l_line_tbl (i).orig_sys_line_ref
                         );
               END LOOP;
            ELSE
               v_orders_booked := v_orders_booked + 1;
            END IF;

            COMMIT;
         ELSE
            v_header_error_cnt := v_header_error_cnt + 1;
            v_line_error_cnt := v_line_error_cnt + l_line_tbl.COUNT;
            ROLLBACK;
            output ('***ERROR Order Creation Failed');
            errcode := 2;
            errbuf := 'Not all orders were imported';

            FOR i IN 1 .. l_msg_count
            LOOP
               oe_msg_pub.get (p_msg_index          => i,
                               p_encoded            => fnd_api.g_false,
                               p_data               => l_msg_data,
                               p_msg_index_out      => l_msg_index
                              );
               output (i || ':' || l_msg_data);
            END LOOP;

            FOR i IN 1 .. l_line_tbl.COUNT
            LOOP
               output ('               ' || l_line_tbl (i).orig_sys_line_ref);

               UPDATE xxha_sales_trace_intf
                  SET import_flag = 'E'
                WHERE unique_identifier = l_line_tbl (i).orig_sys_line_ref;
            END LOOP;

            COMMIT;
         END IF;
      END LOOP;

      output ('');
      output ('Import Results');
      output ('-------------------------------------');
      output ('Orders Created: ' || v_header_success_cnt);
      output ('Orders Booked:  ' || v_orders_booked);
      output ('Orders Errored: ' || v_header_error_cnt);
      output ('Lines Created:  ' || v_line_success_cnt);
      output ('Lines Errored:  ' || v_line_error_cnt);
   END;
END;
/
