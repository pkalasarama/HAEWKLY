CREATE OR REPLACE package XXHA_ECO_UTIL_PKG
-- +===========================================================================+
-- | Name        : XXHA_ECO_UTIL_PKG                         				   |
-- | Purpose     : Support the Interface of ECO into EBS.                      |
-- |                                                                           |
-- | Description : This is a utility Package to support ECO Processing         |
-- |                Interface		 		 								   |
-- |               ECO and Items                                               |
-- |                                                    					   |
-- |               Staged data is prpcessed.  UTIL Pkg is called     		   |
-- |               for any data checks that needs to be made for existing      |
-- |               records 			   			  	 		 	 			   |
-- |               															   |
-- |                                            							   |							   
-- |                                                                           |
-- | Comment     : This package is a utility package for  ECO Interaface	   |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20090315  1.0  Palash Kundu      Initial version                           |
-- +===========================================================================+

AS

-- Chk Item at Org
PROCEDURE chk_item_at_org
          (
           p_item_number IN VARCHAR2
		   ,p_org_code IN VARCHAR2
		   ,x_inv_item_id OUT NUMBER
		   ,x_org_id OUT NUMBER
		   ,x_item_exists OUT VARCHAR2
        );

--Check Rev at Org		
		
PROCEDURE chk_rev_at_org
          (
           p_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,p_rev    IN VARCHAR2
		   ,x_rev_effective_date OUT DATE
		   ,x_rev_exists OUT VARCHAR2
        );
--Check Comp at Org		
		
PROCEDURE chk_comp_at_org
          (
           p_assly_item_id IN NUMBER
		   ,p_comp_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,x_item_seq_number OUT VARCHAR2
		   ,x_op_seq_number OUT VARCHAR2
		   ,x_effective_date OUT VARCHAR2
		   ,x_comp_exists OUT VARCHAR2
        );

--check Ops at Org		
		
PROCEDURE chk_ops_at_org
          (
           p_assly_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,p_department_code IN VARCHAR2
		   ,x_op_seq_number IN OUT VARCHAR2
		   ,x_op_sequence_id OUT NUMBER
		   ,x_effective_date OUT VARCHAR2
		   ,x_ops_exists OUT VARCHAR2
        );
--Chk Ops Resource
		
PROCEDURE chk_ops_resource
          (
           p_op_sequence_id IN NUMBER
		   ,p_resource_code IN VARCHAR2
		   ,x_resource_seq_num OUT VARCHAR2
		   ,x_res_exists OUT VARCHAR2
        );

--Chk eco exists		
		
PROCEDURE chk_eco_exists
(p_eco_name IN xxha_eco_revisions_stg.eco_name%type,
 x_eco_exists OUT VARCHAR2
);

--get Operation Seq Num for BOM
PROCEDURE get_ops_at_org
          (
           p_assly_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,x_op_seq_number IN OUT VARCHAR2
		   ,x_op_sequence_id OUT NUMBER
		   ,x_effective_date OUT VARCHAR2
		   ,x_ops_exists OUT VARCHAR2
        );


-- Get assly Chk Comp

PROCEDURE get_assly_chk_comp
          (
            p_comp_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,x_item_seq_number OUT VARCHAR2
		   ,x_op_seq_number OUT VARCHAR2
		   ,x_effective_date OUT VARCHAR2
		   ,x_assly_item_number OUT VARCHAR2
		   ,x_comp_exists OUT VARCHAR2 
        );		
end XXHA_ECO_UTIL_PKG;
/


CREATE OR REPLACE package body      XXHA_ECO_UTIL_PKG
as
-- +===========================================================================+
-- | Name        : XXHA_ECO_UTIL_PKG                         				   |
-- | Purpose     : Support the Interface of ECO into EBS.                      |
-- |                                                                           |
-- | Description : This is a utility Package to support ECO Processing         |
-- |                Interface		 		 								   |
-- |               ECO and Items                                               |
-- |                                                    					   |
-- |               Staged data is prpcessed.  UTIL Pkg is called     		   |
-- |               for any data checks that needs to be made for existing      |
-- |               records 			   			  	 		 	 			   |
-- |               															   |
-- |                                            							   |							   
-- |                                                                           |
-- | Comment     : This package is a utility package for  ECO Interaface	   |
-- |                                                                           |
-- | History                                                                   |
-- | =======                                                                   |
-- | When      Rev  Who       What                                             |
-- | --------  ---  --------  ------------------------------------------------ |
-- | 20090315  1.0  Palash Kundu      Initial version                           |
-- +===========================================================================+

--checks Item exist at Org

PROCEDURE chk_item_at_org
          (
           p_item_number IN VARCHAR2
		   ,p_org_code IN VARCHAR2
		   ,x_inv_item_id OUT NUMBER
		   ,x_org_id OUT NUMBER
		   ,x_item_exists OUT VARCHAR2
        )
IS

BEGIN
  x_item_exists := 'Y';
  select inventory_item_id,items.organization_id
  into x_inv_item_id,x_org_id
  from mtl_system_items_b items,mtl_parameters param
  where items.organization_id = param.organization_id
  and items.segment1 = p_item_number
  and param.organization_code = p_org_code
  ;
 EXCEPTION
 WHEN no_data_found then
   x_item_exists := 'N'; 
  
END;

-- Checks Rev exist at Org

PROCEDURE chk_rev_at_org
          (
           p_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,p_rev    IN VARCHAR2
		   ,x_rev_effective_date OUT DATE
		   ,x_rev_exists OUT VARCHAR2
        )
IS

BEGIN
  x_rev_exists := 'Y';
  select effectivity_date
  into x_rev_effective_date
  from mtl_item_revisions_b
  where inventory_item_id = p_item_id
  and organization_id = p_org_id
  and revision = p_rev
  ;
 EXCEPTION
 WHEN no_data_found then
   x_rev_exists := 'N'; 
  
END;

--checked Bom Copmponent at Org.

PROCEDURE chk_comp_at_org
          (
           p_assly_item_id IN NUMBER
		   ,p_comp_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,x_item_seq_number OUT VARCHAR2
		   ,x_op_seq_number OUT VARCHAR2
		   ,x_effective_date OUT VARCHAR2
		   ,x_comp_exists OUT VARCHAR2 
        )
IS
  cursor c_chk_comp is
  select item_num,to_char(effectivity_date,'MM-DD-YYYY HH:MI:SS AM') effectivity_date,operation_seq_num
  from bom_bill_of_materials bom,bom_components_b comp
  where bom.organization_id = p_org_id
  and bom.assembly_item_id = p_assly_item_id
  and bom.bill_sequence_id = comp.bill_sequence_id
  and comp.component_item_id = p_comp_item_id
  and effectivity_date <= sysdate
  and nvl(disable_date,sysdate) >= sysdate
  and comp.implementation_date is not null
  and comp.implementation_date <= sysdate
  order by effectivity_date desc
  ;
BEGIN
  x_comp_exists := 'N';
  FOR v_chk_comp in c_chk_comp LOOP
    
    x_item_seq_number := v_chk_comp.item_num;
	x_effective_date  := v_chk_comp.effectivity_date;
	x_op_seq_number   := v_chk_comp.operation_seq_num;
	x_comp_exists := 'Y';
	
	
  END LOOP;	
  
END;	

--Check RTG Operation exist at Org

PROCEDURE chk_ops_at_org
          (
           p_assly_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,p_department_code IN VARCHAR2
		   ,x_op_seq_number IN OUT VARCHAR2
		   ,x_op_sequence_id OUT NUMBER
		   ,x_effective_date OUT VARCHAR2
		   ,x_ops_exists OUT VARCHAR2
        )
IS
  cursor c_chk_ops is
  select operation_seq_num,to_char(effectivity_date,'MM-DD-YYYY HH:MI:SS AM') effectivity_date,operation_sequence_id
  from bom_operational_routings rtg,bom_operation_sequences ops,bom_departments dept
  where rtg.organization_id = p_org_id
  and rtg.assembly_item_id = p_assly_item_id
  and rtg.routing_sequence_id = ops.routing_sequence_id
  and dept.department_id = ops.department_id
  and dept.organization_id = p_org_id
  and operation_seq_num = x_op_seq_number
  and effectivity_date <= sysdate
  and nvl(ops.disable_date,sysdate) >= sysdate
  and ops.implementation_date is not null
  and ops.implementation_date <= sysdate
  order by effectivity_date desc
  ;
BEGIN
  x_ops_exists := 'N';
  FOR v_chk_ops in c_chk_ops LOOP
    x_effective_date  := v_chk_ops.effectivity_date;
	x_op_seq_number   := v_chk_ops.operation_seq_num;
	x_op_sequence_id   := v_chk_ops.operation_sequence_id;
	x_ops_exists := 'Y';
	dbms_output.put_line(x_effective_date);
  END LOOP;	
  
END;	

--- get Opern Seq Num

PROCEDURE get_ops_at_org
          (
           p_assly_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,x_op_seq_number IN OUT VARCHAR2
		   ,x_op_sequence_id OUT NUMBER
		   ,x_effective_date OUT VARCHAR2
		   ,x_ops_exists OUT VARCHAR2
        )
IS
  cursor c_chk_ops is
  select operation_seq_num,to_char(effectivity_date,'MM-DD-YYYY HH:MI:SS AM') effectivity_date,operation_sequence_id
  from bom_operational_routings rtg,bom_operation_sequences ops
  where rtg.organization_id = p_org_id
  and rtg.assembly_item_id = p_assly_item_id
  and rtg.routing_sequence_id = ops.routing_sequence_id
  and effectivity_date <= sysdate
  and nvl(ops.disable_date,sysdate) >= sysdate
  and ops.implementation_date is not null
  and ops.implementation_date <= sysdate
  order by effectivity_date desc
  ;
BEGIN
  x_ops_exists := 'N';
  FOR v_chk_ops in c_chk_ops LOOP
    x_effective_date  := v_chk_ops.effectivity_date;
	x_op_seq_number   := v_chk_ops.operation_seq_num;
	x_op_sequence_id   := v_chk_ops.operation_sequence_id;
	x_ops_exists := 'Y';
	dbms_output.put_line(x_effective_date);
  END LOOP;	
  
END;	


--Check Operation Resource exist at Org.
	
PROCEDURE chk_ops_resource
          (
           p_op_sequence_id IN NUMBER
		   ,p_resource_code IN VARCHAR2
		   ,x_resource_seq_num OUT VARCHAR2
		   ,x_res_exists OUT VARCHAR2
        )
IS
  cursor c_chk_res is
  select resource_seq_num
  from bom_operation_resources ops_res,bom_resources res
  where ops_res.operation_sequence_id = p_op_sequence_id
  and ops_res.resource_id = res.resource_id
  and res.resource_code = p_resource_code
  ;
BEGIN
  x_res_exists := 'N';
  FOR v_chk_res in c_chk_res LOOP
    x_resource_seq_num   := v_chk_res.resource_seq_num;
	x_res_exists := 'Y';
	
  END LOOP;	
  
END;

--check eco exists

PROCEDURE chk_eco_exists
(p_eco_name IN xxha_eco_revisions_stg.eco_name%type,
 x_eco_exists OUT VARCHAR2
)is

BEGIN
  x_eco_exists := 'N';
  select 'Y'
  into x_eco_exists
  from ENG_ENGINEERING_CHANGES
  where change_notice = p_eco_name; 
  
  Exception
  When no_data_found then
    x_eco_exists := 'N';

END;

--get BOM component

PROCEDURE get_assly_chk_comp
          (
            p_comp_item_id IN NUMBER
		   ,p_org_id IN NUMBER
		   ,x_item_seq_number OUT VARCHAR2
		   ,x_op_seq_number OUT VARCHAR2
		   ,x_effective_date OUT VARCHAR2
		   ,x_assly_item_number OUT VARCHAR2
		   ,x_comp_exists OUT VARCHAR2 
        )
IS
  cursor c_chk_comp is
  select item_num,to_char(effectivity_date,'MM-DD-YYYY HH:MI:SS AM') effectivity_date,operation_seq_num,items.segment1
  from bom_bill_of_materials bom,bom_components_b comp,mtl_system_items items
  where bom.organization_id = items.organization_id
  and   bom.organization_id = p_org_id
  and bom.assembly_item_id = items.inventory_item_id
  and bom.bill_sequence_id = comp.bill_sequence_id
  and comp.component_item_id = p_comp_item_id
  and effectivity_date <= sysdate
  and nvl(disable_date,sysdate) >= sysdate
  and comp.implementation_date is not null
  and comp.implementation_date <= sysdate
  order by effectivity_date desc
  ;
BEGIN
  x_comp_exists := 'N';
  FOR v_chk_comp in c_chk_comp LOOP
    
    x_item_seq_number := v_chk_comp.item_num;
	x_effective_date  := v_chk_comp.effectivity_date;
	x_op_seq_number   := v_chk_comp.operation_seq_num;
	x_assly_item_number := v_chk_comp.segment1;
	x_comp_exists := 'Y';
	dbms_output.put_line('assly'||v_chk_comp.segment1);
	
	
  END LOOP;	
  dbms_output.put_line('assly'||p_org_id||p_comp_item_id||x_assly_item_number);
END;	


END XXHA_ECO_UTIL_PKG;
/
