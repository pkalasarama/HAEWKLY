create or replace PACKAGE BODY      XXHA_B_GET_SR_DATA_PKG 
-- +=========================================================================================+
-- | Name        : XXHA_B_GET_SR_DATA_PKG                                                    |
-- | Purpose     : Runs insert-select statements to populate HAEMO schema                    |
-- |               tables (XXHA_B_SR_TASK_DEBRIEFS, XXHA_B_SR_LINE_NOTE_DATA)                |
-- |               for the Quality Data and Service Contracts Hyperion reports.              |
-- |                                                                                         |
-- | Tables Accessed :                                                                       |
-- | Access Type----------------- (I - Insert, S - Select, U - Update, D - Delete)           |
-- |                                                                                         |
-- | XXHA_B_SR_TASK_DEBRIEFS         D, I                                                    |
-- | XXHA_B_SR_LINE_NOTE_DATA        D, I                                                    |
-- |                                                                                         |
-- | History                                                                                 |
-- | =======                                                                                 |
-- | When      Rev  Who               What                                                   |
-- | --------  ---  --------          -------------------------------------------------      |
-- | 20150428  1.0  imenzies          CR# ESC114183 New Package based on old quality data    |
-- |                                  mart to suport service calls report                    |
-- | 20160704  1.1  vkaveti           INC#NC0080376 Added 30 DFF columns to the package      |
-- | 20170111  1.2  vkaveti           INC#INC0076354_INC0091000_INC0076354                   |
-- |                                  Added UDI and Bill-To/Ship-To Address changes          |
-- | 20170525  1.2  BMarcoux          Added new columns 'LAST_UPDATED_USERID' and            |
-- |                                    'LAST_UPDATED_USERNAME' to table                     |
-- |                                    'HAEMO.XXHA_B_SR_LINE_NOTE_DATA'                     |
-- +=========================================================================================+
AS
   PROCEDURE GET_SR_DATA (x_errbuf OUT VARCHAR2, x_retcode OUT VARCHAR2)
   IS
      ln_record_count   NUMBER := 0;
   BEGIN
      EXECUTE IMMEDIATE
         ('alter session set "_optimizer_cost_based_transformation"=off');

      EXECUTE IMMEDIATE 'truncate table haemo.XXHA_B_SR_TASK_DEBRIEFS';

      ln_record_count := 0;

      BEGIN
         INSERT INTO HAEMO.XXHA_B_SR_TASK_DEBRIEFS (
                        INCIDENT_ID,
                        INCIDENT_NUMBER,
                        REPORTED_DATE,
                        INCIDENT_DATE,
                        DATE_CLOSED,
                        ORG_ID,
                        INCIDENT_OWNER,
                        INCIDENT_OWNER_GROUP,
                        INCIDENT_COUNTRY_CODE,
                        ADDRESS1,
                        ADDRESS2,
                        ADDRESS3,
                        ADDRESS4,
                        CITY,
                        STATE,
                        COUNTRY,
                        ZIP_CODE,
                        INVENTORY_ITEM_ID,
                        INSTANCE_SERIAL_NUMBER,
                        INSTANCE_PRODUCT_NAME,
                        INSTANCE_ITEM_PRODUCT_DESCR,
                        INSTALL_DATE,
                        SEVERITY,
                        URGENCY,
                        INCIDENT_PROBLEM_CODE,
                        INCIDENT_PROBLEM_DESC,
                        INCIDENT_PROBLEM_CODE_2,
                        INCIDENT_PROBLEM_DESC_2,
                        INCIDENT_PROBLEM_CODE_3,
                        INCIDENT_PROBLEM_DESC_3,
                        INCIDENT_PROBLEM_CODE_4,
                        INCIDENT_PROBLEM_DESC_4,
                        INCIDENT_PROBLEM_CODE_5,
                        INCIDENT_PROBLEM_DESC_5,
                        INCIDENT_PROBLEM_CODE_6,
                        INCIDENT_PROBLEM_DESC_6,
                        INCIDENT_RESOLUTION_CODE,
                        INCIDENT_RESOLUTION_DESC,
                        INCIDENT_RESOLUTION_CODE_2,
                        INCIDENT_RESOLUTION_DESC_2,
                        INCIDENT_RESOLUTION_CODE_3,
                        INCIDENT_RESOLUTION_DESC_3,
                        INCIDENT_RESOLUTION_CODE_4,
                        INCIDENT_RESOLUTION_DESC_4,
                        INCIDENT_RESOLUTION_CODE_5,
                        INCIDENT_RESOLUTION_DESC_5,
                        INCIDENT_RESOLUTION_CODE_6,
                        INCIDENT_RESOLUTION_DESC_6,
                        INCIDENT_TYPE,
                        INCIDENT_STATUS_ID,
                        INCIDENT_STATUS_MEANING,
                        LOGGED_BY,
                        CREATION_DATE,
                        SR_CREATION_CHANNEL,
                        LAST_UPDATE_DATE,
                        INCIDENT_CONTEXT,
                        PROBLEM_SUMMARY,
                        RESOLUTION_SUMMARY,
                        PURCHASE_ORDER_NUM,
                        TOTAL_AMOUNT,
                        TOTAL_SUBMITTED,
                        TOTAL_UNSUBMITTED,
                        PIR_NEED,
                        PROCESS_PHASE,
                        DEATH,
                        INJURY,
                        APPENDIX_A,
                        EXTENDED_HOSP,
                        CONTRACT_NUMBER,
                        CONTRACT_NUMBER_MODIFIER,
                        SERVICE_NAME,
                        ACCOUNT_NUMBER,
                        CUSTOMER_NAME,
                        CUSTOMER_TYPE,
                        CONTACT_PARTY_NAME,
                        CONTACT_TYPE,
                        PRIMARY_PHONE_AREA_CODE,
                        PRIMARY_PHONE_NUMBER,
                        EMAIL_ADDRESS,
                        URL,
                        TASK_ID,
                        TASK_NUMBER,
                        TASK_NAME,
                        TASK_PLANNED_START_DATE,
                        TASK_ACTUAL_START_DATE,
                        TASK_ACTUAL_END_DATE,
                        RESPONSE_TIME_IN_HRS,
                        TASK_OWNER,
                        TASK_STATUS,
                        TASK_PRIORITY,
                        REPAIR_STATUS_MEANING,
                        DEBRIEF_HEADER_ID,
                        DEBRIEF_NUMBER,
                        DEBRIEF_STATUS,
                        DEBRIEF_ASSIGNEE_RESOURCE,
                        DEBRIEF_ASSIGNEE_COUNTRY,
						udi_number,
						 DFF1_Value1,
   DFF1_Value2,
   DFF1_Value3,
   DFF1_Value4,
   DFF1_Value5,
 DFF1_Value6,
 DFF1_Value7,
 DFF1_Value8,
 DFF1_Value9,
 DFF1_Value10,
 DFF1_Value11,
  DFF1_Value12,
 DFF1_Value13,
 DFF1_Value14,
 DFF1_Value15,
 DFF2_Value1,
 DFF2_Value2,
 DFF2_Value3,
   DFF2_Value4,
   DFF2_Value5,
   DFF2_Value6,
 DFF2_Value7,
  DFF2_Value8,
   DFF2_Value9,
  DFF2_Value10,
 DFF2_Value11,
   DFF2_Value12,
 DFF2_Value13,
  DFF2_Value14,
  DFF2_Value15,bill_to_site_id,ship_to_site_id
)
            SELECT cia.incident_id,
                   cia.incident_number,
                   cia.incident_date reported_date,
                   cia.incident_occurred_date incident_date,
                   cia.close_date date_closed,
                   cia.org_id,
                   cio_r.resource_name incident_owner, 
                   ciog_r.resource_name incident_owner_group,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_country
                      ELSE
                         hl.country
                   END
                      incident_country_code,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_address
                      ELSE
                         hl.address1
                   END
                      address1,
                   hl.address2,
                   hl.address3,
                   hl.address4,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_city
                      ELSE
                         hl.city
                   END
                      city,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_state
                      ELSE
                         hl.state
                   END
                      state,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         ic.territory_short_name
                      ELSE
                         hlc.territory_short_name
                   END
                      country,
                   CASE
                      WHEN cia.incident_location_id IS NULL
                      THEN
                         cia.incident_postal_code
                      ELSE
                         hl.postal_code
                   END
                      zip_code,
                   NVL (cia.inventory_item_id, -1) inventory_item_id,
                   cii.serial_number instance_serial_number,
                   msi_inc.segment1 instance_product_name,
                   msi_inc.description instance_item_product_descr,
                   cii.install_date,
                   cisv.name severity,
                   ciu.name urgency,
                   cl_pc.lookup_code incident_problem_code,
                   cl_pc.description incident_problem_desc,
                   cl_pc2.lookup_code incident_problem_code_2,
                   cl_pc2.description incident_problem_desc_2,
                   cl_pc3.lookup_code incident_problem_code_3,
                   cl_pc3.description incident_problem_desc_3,
                   cl_pc4.lookup_code incident_problem_code_4,
                   cl_pc4.description incident_problem_desc_4,
                   cl_pc5.lookup_code incident_problem_code_5,
                   cl_pc5.description incident_problem_desc_5,
                   cl_pc6.lookup_code incident_problem_code_6,
                   cl_pc6.description incident_problem_desc_6,
                   cl_rc.lookup_code incident_resolution_code,
                   cl_rc.description incident_resolution_desc,
                   cl_rc2.lookup_code incident_resolution_code_2,
                   cl_rc2.description incident_resolution_desc_2,
                   cl_rc3.lookup_code incident_resolution_code_3,
                   cl_rc3.description incident_resolution_desc_3,
                   cl_rc4.lookup_code incident_resolution_code_4,
                   cl_rc4.description incident_resolution_desc_4,
                   cl_rc5.lookup_code incident_resolution_code_5,
                   cl_rc5.description incident_resolution_desc_5,
                   cl_rc6.lookup_code incident_resolution_code_6,
                   cl_rc6.description incident_resolution_desc_6,
                   cit.name incident_type,
                   cia.incident_status_id,
                   cis.name incident_status_meaning,
                   fu.user_name logged_by,
                   cia.creation_date,
                   cia.sr_creation_channel,
                   cia.last_update_date,
                   cia.incident_context,
                   cia_tl.summary problem_summary,
                   cia_tl.resolution_summary,
                   cia.customer_po_number,
                   ts.total_amount,
                   ts.total_submitted,
                   ts.total_unsubmitted,
                   cia.incident_context pir_need,
                   cia.incident_attribute_2 process_phase,
                   cia.incident_attribute_3 death,
                   cia.incident_attribute_4 injury,
                   cia.incident_attribute_5 appendix_a,
                   cia.incident_attribute_6 extended_hosp,
                   cia.contract_number,
                   sc.contract_number_modifier,
                   sd.service_name,
                   hca.account_number,
                   SUBSTRB (c_hp.party_name, 1, 50) customer_name,
                   DECODE (hca.customer_type, 'I', 'Internal', 'External')
                      customer_type,
                   NVL (ct_hp.party_name, hp.party_name) contact_party_name,
                   chscp.contact_point_type contact_type,
                   NVL (ct_hp.primary_phone_area_code,
                        hp.primary_phone_area_code)
                      primary_phone_area_code,
                   NVL (ct_hp.primary_phone_number, hp.primary_phone_number)
                      primary_phone_number,
                   NVL (ct_hp.email_address, hp.email_address) email_address,
                   NVL (ct_hp.url, hp.url) url,
                   cdt.task_id,
                   cdt.task_number,
                   cdt.task_name,
                   cdt.planned_start_date task_planned_start_date,
                   cdt.actual_start_date task_actual_start_date,
                   cdt.actual_end_date task_actual_end_date,
                   (  (  (cdt.actual_start_date - cia.incident_occurred_date)
                       * 24)
                    - (  xx_haemo_get_wkendday_count_us (
                            cia.incident_occurred_date,
                            cdt.actual_start_date)
                       * 24))
                      response_time_in_hrs,
                   cdt.owner_name task_owner,
                   cdt.task_status,
                   cdt.task_priority_name task_priority,
                   cdt.repair_status_meaning,
                   cdt.debrief_header_id,
                   cdt.debrief_number,
                   cdt.processed_flag debrief_status,
                   cdtda_r.resource_name debrief_assignee_resource,
                   da_hp.country debrief_assignee_country  ,
                  /*   (SELECT 
NOTE_TL.notes  
FROM JTF_NOTES_B b ,
  CS_INCIDENTS_ALL_B INC ,
  JTF_NOTES_TL NOTE_TL
WHERE b.SOURCE_OBJECT_CODE = 'SR'
AND b.note_type            = 'UDI'
AND INC.INCIDENT_ID        = b.SOURCE_OBJECT_ID
AND b.JTF_NOTE_ID          = NOTE_TL.JTF_NOTE_ID
AND NOTE_TL.LANGUAGE       = USERENV ('LANG')
AND INC.INCIDENT_NUMBER    = cia.incident_number
AND B.NOTE_STATUS='E') */ 
   XXHA_GET_CONC_UDI_NUM(cia.incident_number) udi_number,
   cdt.DFF1_Value1,
  cdt.DFF1_Value2,
  cdt.DFF1_Value3,
  cdt.DFF1_Value4,
  cdt.DFF1_Value5,
  cdt.DFF1_Value6,
  cdt.DFF1_Value7,
  cdt.DFF1_Value8,
  cdt.DFF1_Value9,
  cdt.DFF1_Value10,
  cdt.DFF1_Value11,
  cdt.DFF1_Value12,
  cdt.DFF1_Value13,
  cdt.DFF1_Value14,
  cdt.DFF1_Value15 ,
  cdt.DFF2_Value1,
  cdt.DFF2_Value2,
  cdt.DFF2_Value3,
  cdt.DFF2_Value4, 
  cdt.DFF2_Value5,
  cdt.DFF2_Value6,
  cdt.DFF2_Value7,
  cdt.DFF2_Value8, 
  cdt.DFF2_Value9,
  cdt.DFF2_Value10,
  cdt.DFF2_Value11,
  cdt.DFF2_Value12, 
  cdt.DFF2_Value13,
  cdt.DFF2_Value14,
  cdt.DFF2_Value15,cia.bill_to_site_id,cia.ship_to_site_id
              FROM apps.cs_incidents_all_b cia,
                   apps.cs_incidents_all_tl cia_tl,
                   apps.cs_hz_sr_contact_points chscp,
                   (SELECT jtv.source_object_id incident_id,
  jta.resource_id,
  csf_util_pvt.get_object_name (jtv.owner_type_code, jtv.owner_id) owner_name,


  jtv.owner_id,
  jtv.owner_type_code,
  jtv.task_number,
  jtv.task_name,
  jtv.task_id,
  jts1.name task_status,
  jts1.task_status_id,
  jtp.task_priority_id,
  jtp.name task_priority_name,
  jtv.planned_start_date,
  jtv.planned_end_date,
  jtv.actual_start_date,
  jtv.actual_end_date,
  cdh.debrief_number,
  cdh.debrief_header_id,
  cdh.debrief_date,
  cdh.processed_flag,
  'n/a' repair_status_meaning,
   jtv.attribute1 as DFF1_Value1,
  jtv.attribute2 as DFF1_Value2,
  jtv.attribute3 as DFF1_Value3,
  jtv.attribute4 as DFF1_Value4,
  jtv.attribute5 as DFF1_Value5,
  jtv.attribute6 as DFF1_Value6,
  jtv.attribute7 as DFF1_Value7,
  jtv.attribute8 as DFF1_Value8,
  jtv.attribute9 as DFF1_Value9,
  jtv.attribute10 as DFF1_Value10,
  jtv.attribute11 as DFF1_Value11,
  jtv.attribute12 as DFF1_Value12,
  jtv.attribute13 as DFF1_Value13,
  jtv.attribute14 as DFF1_Value14,
  jtv.attribute15 as DFF1_Value15,
  jta.attribute1 as DFF2_Value1,
  jta.attribute2 as DFF2_Value2,
  jta.attribute3 as DFF2_Value3,
  jta.attribute4  as DFF2_Value4,
  jta.attribute5 as DFF2_Value5,
  jta.attribute6 as DFF2_Value6,
  jta.attribute7 as DFF2_Value7,
  jta.attribute8  as DFF2_Value8,
  jta.attribute9 as DFF2_Value9,
  jta.attribute10 as DFF2_Value10,
  jta.attribute11 as DFF2_Value11,
  jta.attribute12  as DFF2_Value12,
  jta.attribute13 as DFF2_Value13,
  jta.attribute14 as DFF2_Value14,
  jta.attribute15 as DFF2_Value15
FROM jtf_tasks_vl jtv,
  jtf_task_assignments jta,
  jtf_task_statuses_vl jts1,
  jtf_task_priorities_vl jtp,
  csf_debrief_headers cdh
WHERE 1                         = 1
AND jtv.task_id                 = jta.task_id(+)  --and jtv.source_object_id ='1645024'


AND jta.assignee_role(+)        = 'ASSIGNEE'
AND jta.task_assignment_id      = cdh.task_assignment_id(+)

AND jtv.task_priority_id        = jtp.task_priority_id(+)
AND jtv.task_status_id          = jts1.task_status_id
AND jtv.source_object_type_code = 'SR'
UNION ALL
SELECT cr.incident_id,
  jta_1.resource_id,
  csf_util_pvt.get_object_name (jtv_1.owner_type_code, jtv_1.owner_id) owner_name,


  jtv_1.owner_id,
  jtv_1.owner_type_code,
  jtv_1.task_number,
  jtv_1.task_name,
  jtv_1.task_id,
  jts1.name task_status,
  jts1.task_status_id,
  jtp.task_priority_id,
  jtp.name task_priority_name,
  jtv_1.planned_start_date,
  jtv_1.planned_end_date,
  jtv_1.actual_start_date,
  jtv_1.actual_end_date,
  cdh.debrief_number,
  cdh.debrief_header_id,
  cdh.debrief_date,
  cdh.processed_flag,
  cl_r_stat.meaning repair_status_meaning,
  jtv_1.attribute1 as DFF1_Value1,
  jtv_1.attribute2 as DFF1_Value2,
  jtv_1.attribute3 as DFF1_Value3,
  jtv_1.attribute4 as DFF1_Value4,
  jtv_1.attribute5 as DFF1_Value5,
  jtv_1.attribute6 as DFF1_Value6,
  jtv_1.attribute7 as DFF1_Value7,
  jtv_1.attribute8 as DFF1_Value8,
  jtv_1.attribute9 as DFF1_Value9,
  jtv_1.attribute10 as DFF1_Value10,
  jtv_1.attribute11 as DFF1_Value11,
  jtv_1.attribute12 as DFF1_Value12,
  jtv_1.attribute13 as DFF1_Value13,
  jtv_1.attribute14 as DFF1_Value14,
  jtv_1.attribute15 as DFF1_Value15,
  jta_1.attribute1 as DFF2_Value1,
  jta_1.attribute2 as DFF2_Value2,
  jta_1.attribute3 as DFF2_Value3,
  jta_1.attribute4  as DFF2_Value4,
  jta_1.attribute5 as DFF2_Value5,
  jta_1.attribute6 as DFF2_Value6,
  jta_1.attribute7 as DFF2_Value7,
  jta_1.attribute8  as DFF2_Value8,
  jta_1.attribute9 as DFF2_Value9,
  jta_1.attribute10 as DFF2_Value10,
  jta_1.attribute11 as DFF2_Value11,
  jta_1.attribute12  as DFF2_Value12,
  jta_1.attribute13 as DFF2_Value13,
  jta_1.attribute14 as DFF2_Value14,
  jta_1.attribute15 as DFF2_Value15
FROM csd_repairs cr,
  jtf_tasks_vl jtv_1,
  jtf_task_assignments jta_1,
  jtf_task_statuses_vl jts1,
  jtf_task_priorities_vl jtp,
  csf_debrief_headers cdh,
  apps.cs_lookups cl_r_stat
WHERE 1                         = 1

AND cr.repair_line_id           = jtv_1.source_object_id  -- and cr.incident_id='1645024'
AND jtv_1.task_id                 = jta_1.task_id
AND jta_1.assignee_role           = 'ASSIGNEE'
AND jta_1.task_assignment_id      = cdh.task_assignment_id(+)

AND jtv_1.task_priority_id        = jtp.task_priority_id(+)
AND jtv_1.task_status_id          = jts1.task_status_id
AND cr.status                   = cl_r_stat.lookup_code(+)
AND cl_r_stat.lookup_type(+)    = 'CSZ_SRCH_STATUS_FLAG_CODE'

AND jtv_1.source_object_type_code = 'DR'
AND jts1.name                  IN ('Closed', 'Completed'))
 cdt,
                   apps.csi_item_instances cii,
                   apps.hz_parties hp,
                   apps.hz_relationships hrel,
                   apps.hz_parties ct_hp,
                   apps.hz_party_sites hps,
                   apps.hz_locations hl,
                   apps.fnd_territories_tl ic,
                   apps.fnd_territories_tl hlc,
                   apps.hz_cust_accounts hca,
                   apps.hz_parties c_hp,
                   apps.fnd_user fu,
                   apps.jtf_rs_all_resources_vl cio_r,
                   apps.jtf_rs_all_resources_vl ciog_r,
                   apps.jtf_rs_all_resources_vl cdtda_r,
                   apps.hz_parties da_hp,
                   apps.mtl_system_items_b msi_inc,
                   apps.cs_incident_severities_vl cisv,
                   apps.cs_incident_urgencies_vl ciu,
                   apps.cs_lookups cl_pc,
                   apps.cs_lookups cl_pc2,
                   apps.cs_lookups cl_pc3,
                   apps.cs_lookups cl_pc4,
                   apps.cs_lookups cl_pc5,
                   apps.cs_lookups cl_pc6,
                   apps.cs_lookups cl_rc,
                   apps.cs_lookups cl_rc2,
                   apps.cs_lookups cl_rc3,
                   apps.cs_lookups cl_rc4,
                   apps.cs_lookups cl_rc5,
                   apps.cs_lookups cl_rc6,
                   apps.cs_incident_statuses_vl cis,
                   apps.cs_incident_types_vl cit,
                   apps.okc_k_headers_all_b sc,
                   apps.oks_line_details_v sd,
                   (  SELECT incident_id,
                             SUM (
                                DECODE (NVL (estdtl.order_line_id, -999),
                                        -999, 0,
                                        estdtl.after_warranty_cost))
                                total_submitted,
                             SUM (
                                DECODE (NVL (estdtl.order_line_id, -999),
                                        -999, estdtl.after_warranty_cost,
                                        0))
                                total_unsubmitted,
                             SUM (estdtl.after_warranty_cost) total_amount
                        FROM cs_estimate_details estdtl
                       WHERE estdtl.charge_line_type <> 'ESTIMATE'
                    GROUP BY incident_id) ts
             WHERE     1 = 1
                   AND cia.incident_id = cia_tl.incident_id
                   AND cia_tl.language = USERENV ('LANG')
                   AND cia.incident_id = cdt.incident_id(+)
                   AND cia.incident_id = chscp.incident_id(+)
                   AND chscp.primary_flag(+) = 'Y'
                   AND cia.customer_product_id = cii.instance_id(+)
                   AND cia.incident_location_id = hps.party_site_id(+)
                   AND hps.location_id = hl.location_id(+)
                   AND cia.incident_country = ic.territory_code(+)
                   AND ic.language(+) = 'US'
                   AND hl.country = hlc.territory_code(+)
                   AND hlc.language(+) = 'US'
                   AND cia.account_id = hca.cust_account_id(+)
                   AND hca.party_id = c_hp.party_id(+)
                   AND chscp.party_id = hp.party_id(+)
                   AND chscp.party_id = hrel.party_id(+)
                   AND hrel.directional_flag(+) = 'F'
                   AND hrel.subject_id = ct_hp.party_id(+)
                   AND cia.incident_owner_id = cio_r.resource_id(+)
                   AND cia.owner_group_id = ciog_r.resource_id(+)
                   AND cdt.resource_id = cdtda_r.resource_id(+)
                   AND cdtda_r.person_party_id = da_hp.party_id(+)
                   AND cia.inventory_item_id = msi_inc.inventory_item_id(+)
                   AND msi_inc.organization_id(+) = 103
                   AND cia.incident_severity_id = cisv.incident_severity_id
                   AND cia.incident_urgency_id = ciu.incident_urgency_id(+)
                   AND ciu.language(+) = 'US'
                   AND cia.problem_code = cl_pc.lookup_code(+)
                   AND cl_pc.lookup_type(+) = 'REQUEST_PROBLEM_CODE'
                   AND cia.incident_attribute_1 = cl_pc2.lookup_code(+)
                   AND cl_pc2.lookup_type(+) = 'REQUEST_PROBLEM_CODE'
                   AND cia.incident_attribute_7 = cl_pc3.lookup_code(+)
                   AND cl_pc3.lookup_type(+) = 'REQUEST_PROBLEM_CODE'
                   AND cia.incident_attribute_8 = cl_pc4.lookup_code(+)
                   AND cl_pc4.lookup_type(+) = 'REQUEST_PROBLEM_CODE'
                   AND cia.incident_attribute_9 = cl_pc5.lookup_code(+)
                   AND cl_pc5.lookup_type(+) = 'REQUEST_PROBLEM_CODE'
                   AND cia.incident_attribute_10 = cl_pc6.lookup_code(+)
                   AND cl_pc6.lookup_type(+) = 'REQUEST_PROBLEM_CODE'
                   AND cia.resolution_code = cl_rc.lookup_code(+)
                   AND cl_rc.lookup_type(+) = 'REQUEST_RESOLUTION_CODE'
                   AND cia.incident_attribute_11 = cl_rc2.lookup_code(+)
                   AND cl_rc2.lookup_type(+) = 'REQUEST_RESOLUTION_CODE'
                   AND cia.incident_attribute_12 = cl_rc3.lookup_code(+)
                   AND cl_rc3.lookup_type(+) = 'REQUEST_RESOLUTION_CODE'
                   AND cia.incident_attribute_13 = cl_rc4.lookup_code(+)
                   AND cl_rc4.lookup_type(+) = 'REQUEST_RESOLUTION_CODE'
                   AND cia.incident_attribute_14 = cl_rc5.lookup_code(+)
                   AND cl_rc5.lookup_type(+) = 'REQUEST_RESOLUTION_CODE'
                   AND cia.incident_attribute_15 = cl_rc6.lookup_code(+)
                   AND cl_rc6.lookup_type(+) = 'REQUEST_RESOLUTION_CODE'
                   AND cia.created_by = fu.user_id
                   AND cia.incident_status_id = cis.incident_status_id
                   AND cia.incident_type_id = cit.incident_type_id
                   AND cia.contract_id = sc.id(+)
                   AND cia.contract_service_id = sd.line_id(+)
                   AND cia.incident_id = ts.incident_id(+)
                   AND cia.incident_status_id NOT IN (100, 1224);

         ln_record_count := SQL%ROWCOUNT;
      EXCEPTION
         WHEN OTHERS
         THEN
            FND_FILE.PUT_LINE (
               FND_FILE.LOG,
                  'Unexpected error occured while inserting into XXHA_B_SR_TASK_DEBRIEFS: '
               || SQLERRM);
      END;

      COMMIT;
      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            ln_record_count
         || ' - Records Successfully inserted in XXHA_B_SR_TASK_DEBRIEFS '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));
      ln_record_count := 0;

      EXECUTE IMMEDIATE 'truncate table haemo.XXHA_B_SR_LINE_NOTE_DATA';

      BEGIN
         INSERT INTO HAEMO.XXHA_B_SR_LINE_NOTE_DATA (
                        INCIDENT_ID,
                        INCIDENT_NUMBER,
                        REPORTED_DATE,
                        INCIDENT_DATE,
                        DATE_CLOSED,
                        ORG_ID,
                        OPERATING_UNIT,
                        INCIDENT_OWNER,
                        INCIDENT_OWNER_GROUP,
                        INCIDENT_COUNTRY_CODE,
                        ADDRESS1,
                        ADDRESS2,
                        ADDRESS3,
                        ADDRESS4,
                        CITY,
                        STATE,
                        COUNTRY,
                        ZIP_CODE,
                        INVENTORY_ITEM_ID,
                        INSTANCE_SERIAL_NUMBER,
                        INSTANCE_PRODUCT_NAME,
                        INSTANCE_ITEM_PRODUCT_DESCR,
                        INSTALL_DATE,
                        SEVERITY,
                        URGENCY,
                        INCIDENT_PROBLEM_CODE,
                        INCIDENT_PROBLEM_DESC,
                        INCIDENT_PROBLEM_CODE_2,
                        INCIDENT_PROBLEM_DESC_2,
                        INCIDENT_PROBLEM_CODE_3,
                        INCIDENT_PROBLEM_DESC_3,
                        INCIDENT_PROBLEM_CODE_4,
                        INCIDENT_PROBLEM_DESC_4,
                        INCIDENT_PROBLEM_CODE_5,
                        INCIDENT_PROBLEM_DESC_5,
                        INCIDENT_PROBLEM_CODE_6,
                        INCIDENT_PROBLEM_DESC_6,
                        INCIDENT_RESOLUTION_CODE,
                        INCIDENT_RESOLUTION_DESC,
                        INCIDENT_RESOLUTION_CODE_2,
                        INCIDENT_RESOLUTION_DESC_2,
                        INCIDENT_RESOLUTION_CODE_3,
                        INCIDENT_RESOLUTION_DESC_3,
                        INCIDENT_RESOLUTION_CODE_4,
                        INCIDENT_RESOLUTION_DESC_4,
                        INCIDENT_RESOLUTION_CODE_5,
                        INCIDENT_RESOLUTION_DESC_5,
                        INCIDENT_RESOLUTION_CODE_6,
                        INCIDENT_RESOLUTION_DESC_6,
                        INCIDENT_TYPE,
                        INCIDENT_STATUS_ID,
                        INCIDENT_STATUS_MEANING,
                        LOGGED_BY,
                        CREATION_DATE,
                        SR_CREATION_CHANNEL,
                        LAST_UPDATE_DATE,
                        INCIDENT_CONTEXT,
                        PROBLEM_SUMMARY,
                        RESOLUTION_SUMMARY,
                        PURCHASE_ORDER_NUM,
                        TOTAL_AMOUNT,
                        TOTAL_SUBMITTED,
                        TOTAL_UNSUBMITTED,
                        PIR_NEED,
                        PROCESS_PHASE,
                        DEATH,
                        INJURY,
                        APPENDIX_A,
                        EXTENDED_HOSP,
                        CONTRACT_NUMBER,
                        CONTRACT_NUMBER_MODIFIER,
                        SERVICE_NAME,
                        ACCOUNT_NUMBER,
                        CUSTOMER_NAME,
                        CUSTOMER_TYPE,
                        CONTACT_PARTY_NAME,
                        CONTACT_TYPE,
                        PRIMARY_PHONE_AREA_CODE,
                        PRIMARY_PHONE_NUMBER,
                        EMAIL_ADDRESS,
                        URL,
                        TASK_ID,
                        TASK_NUMBER,
                        TASK_NAME,
                        TASK_PLANNED_START_DATE,
                        TASK_ACTUAL_START_DATE,
                        TASK_ACTUAL_END_DATE,
                        RESPONSE_TIME_IN_HRS,
                        TASK_OWNER,
                        TASK_STATUS,
                        TASK_PRIORITY,
                        REPAIR_STATUS_MEANING,
                        DEBRIEF_HEADER_ID,
                        DEBRIEF_NUMBER,
                        DEBRIEF_STATUS,
                        DEBRIEF_ASSIGNEE_RESOURCE,
                        DEBRIEF_ASSIGNEE_COUNTRY,
						udi_number,
						 DFF1_Value1,
   DFF1_Value2,
   DFF1_Value3,
   DFF1_Value4,
   DFF1_Value5,
 DFF1_Value6,
 DFF1_Value7,
 DFF1_Value8,
 DFF1_Value9,
 DFF1_Value10,
 DFF1_Value11,
  DFF1_Value12,
 DFF1_Value13,
 DFF1_Value14,
 DFF1_Value15,
 DFF2_Value1,
 DFF2_Value2,
 DFF2_Value3,
   DFF2_Value4,
   DFF2_Value5,
   DFF2_Value6,
 DFF2_Value7,
  DFF2_Value8,
   DFF2_Value9,
  DFF2_Value10,
 DFF2_Value11,
   DFF2_Value12,
 DFF2_Value13,
  DFF2_Value14,
  DFF2_Value15,bill_to_site_id ,ship_to_site_id ,
                        NOTE,
                        NOTE_TYPE_MEANING,
                        DEBRIEF_LINE_ID,
                        DEBRIF_SERIAL_NUMBER,
                        LINE_PO_NUMBER,
                        BILLING_CATEGORY,
                        MATERIAL_USED,
                        MATERIAL_USED_DESCRIPTION,
                        MATERIAL_USED_QUANTITY,
                        MATERIAL_USED_MST_COST,
                        LABOR_HOURS,
                        LABOR_ITEM,
                        LABOR_ITEM_DESCRIPTION,
                        LABOR_START_DATE,
                        LABOR_END_DATE,
                        EXPENSE_ITEM,
                        EXPENSE_ITEM_DESCRIPTION,
                        EXPENSE_QUANTITY,
                        EXPENSE_UOM,
                        EXPENSE_ITEM_AMOUNT,
                        EXPENSES_CURRENCY_CODE,
                        CHARGE_LINE_AMOUNT,
                        CHARGE_LINE_SUBMITTED,
                        CHARGE_LINE_UNSUBMITTED,
                        ROW_SORT,
                        LAST_UPDATED_USERID,                         -- 20170525 - BMarcoux
                        LAST_UPDATED_USERNAME)                       -- 20170525 - BMarcoux
 SELECT qdt.incident_id,
                   qdt.incident_number,
                   qdt.reported_date,
                   qdt.incident_date,
                   qdt.date_closed,
                   qdt.org_id,
                   hou.name operating_unit,
                   qdt.incident_owner,
                   qdt.incident_owner_group,
                   qdt.incident_country_code,
                   qdt.address1,
                   qdt.address2,
                   qdt.address3,
                   qdt.address4,
                   qdt.city,
                   qdt.state,
                   qdt.country,
                   qdt.zip_code,
                   qdt.inventory_item_id,
                   qdt.instance_serial_number,
                   qdt.instance_product_name,
                   qdt.instance_item_product_descr,
                   qdt.install_date,
                   qdt.severity,
                   qdt.urgency,
                   qdt.incident_problem_code,
                   qdt.incident_problem_desc,
                   qdt.incident_problem_code_2,
                   qdt.incident_problem_desc_2,
                   qdt.incident_problem_code_3,
                   qdt.incident_problem_desc_3,
                   qdt.incident_problem_code_4,
                   qdt.incident_problem_desc_4,
                   qdt.incident_problem_code_5,
                   qdt.incident_problem_desc_5,
                   qdt.incident_problem_code_6,
                   qdt.incident_problem_desc_6,
                   qdt.incident_resolution_code,
                   qdt.incident_resolution_desc,
                   qdt.incident_resolution_code_2,
                   qdt.incident_resolution_desc_2,
                   qdt.incident_resolution_code_3,
                   qdt.incident_resolution_desc_3,
                   qdt.incident_resolution_code_4,
                   qdt.incident_resolution_desc_4,
                   qdt.incident_resolution_code_5,
                   qdt.incident_resolution_desc_5,
                   qdt.incident_resolution_code_6,
                   qdt.incident_resolution_desc_6,
                   qdt.incident_type,
                   qdt.incident_status_id,
                   qdt.incident_status_meaning,
                   qdt.logged_by,
                   qdt.creation_date,
                   qdt.sr_creation_channel,
                   qdt.last_update_date,
                   qdt.incident_context,
                   qdt.problem_summary,
                   qdt.resolution_summary,
                   qdt.purchase_order_num,
                   qdt.total_amount,
                   qdt.total_submitted,
                   qdt.total_unsubmitted,
                   qdt.pir_need,
                   qdt.process_phase,
                   qdt.death,
                   qdt.injury,
                   qdt.appendix_a,
                   qdt.extended_hosp,
                   qdt.contract_number,
                   qdt.contract_number_modifier,
                   qdt.service_name,
                   qdt.account_number,
                   qdt.customer_name,
                   qdt.customer_type,
                   qdt.contact_party_name,
                   qdt.contact_type,
                   qdt.primary_phone_area_code,
                   qdt.primary_phone_number,
                   qdt.email_address,
                   qdt.url,
                   qdt.task_id,
                   qdt.task_number,
                   qdt.task_name,
                   qdt.task_planned_start_date,
                   qdt.task_actual_start_date,
                   qdt.task_actual_end_date,
                   qdt.response_time_in_hrs,
                   qdt.task_owner,
                   qdt.task_status,
                   qdt.task_priority,
                   qdt.repair_status_meaning,
                   qdt.debrief_header_id,
                   qdt.debrief_number,
                   qdt.debrief_status,
                   qdt.debrief_assignee_resource,
                   qdt.debrief_assignee_country,
                   qdt.udi_number,
                                    qdt.DFF1_Value1,
                   qdt.DFF1_Value2,
                   qdt.DFF1_Value3,
                   qdt.DFF1_Value4,
                   qdt.DFF1_Value5,
                 qdt.DFF1_Value6,
                 qdt.DFF1_Value7,
                 qdt.DFF1_Value8,
                 qdt.DFF1_Value9,
                 qdt.DFF1_Value10,
                 qdt.DFF1_Value11,
                  qdt.DFF1_Value12,
                 qdt.DFF1_Value13,
                 qdt.DFF1_Value14,
                 qdt.DFF1_Value15,
                 qdt.DFF2_Value1,
                 qdt.DFF2_Value2,
                 qdt.DFF2_Value3,
                   qdt.DFF2_Value4,
                   qdt.DFF2_Value5,
                   qdt.DFF2_Value6,
                 qdt.DFF2_Value7,
                  qdt.DFF2_Value8,
                   qdt.DFF2_Value9,
                  qdt.DFF2_Value10,
                 qdt.DFF2_Value11,
                   qdt.DFF2_Value12,
                 qdt.DFF2_Value13,
                  qdt.DFF2_Value14,
                  qdt.DFF2_Value15,qdt.bill_to_site_id,qdt.ship_to_site_id,
                   NULL note,
                   NULL note_type_meaning,
                   cdl.debrief_line_id,
                   cdl.item_serial_number debrif_serial_number,
                   estdtl.line_po_number,
                   NVL (cbt.billing_category, ctbt.billing_type)
                      billing_category,
                   CASE
                      WHEN cbt.billing_category = 'M' THEN msi_bt.segment1
                   END
                      material_used,
                   CASE
                      WHEN cbt.billing_category = 'M' THEN msi_bt.description
                   END
                      material_used_description,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'M'
                      THEN
                         cdl.quantity
                   END
                      material_used_quantity,
                   CASE
                      WHEN cbt.billing_category = 'M' THEN mst_cst.item_cost
                   END
                      material_used_mst_cost,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'L'
                      THEN
                         cdl.quantity
                   END
                      labor_hours,
                   CASE
                      WHEN cbt.billing_category = 'L' THEN msi_bt.segment1
                   END
                      labor_item,
                   CASE
                      WHEN cbt.billing_category = 'L' THEN msi_bt.description
                   END
                      labor_item_description,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'L'
                      THEN
                         cdl.labor_start_date
                   END
                      labor_start_date,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'L'
                      THEN
                         cdl.labor_end_date
                   END
                      labor_end_date,
                   CASE
                      WHEN cbt.billing_category = 'E' THEN msi_bt.segment1
                   END
                      expense_item,
                   CASE
                      WHEN cbt.billing_category = 'E' THEN msi_bt.description
                   END
                      expense_item_description,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'E'
                      THEN
                         cdl.quantity
                   END
                      expense_quantity,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'E'
                      THEN
                         cdl.uom_code
                   END
                      expense_uom,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'E'
                      THEN
                         cdl.expense_amount
                   END
                      expense_item_amount,
                   CASE
                      WHEN NVL (cbt.billing_category, ctbt.billing_type) =
                              'E'
                      THEN
                         cdl.currency_code
                   END
                      expenses_currency_code,
                   estdtl.charge_line_amount,
                   estdtl.charge_line_submitted,
                   estdtl.charge_line_unsubmitted,
                   ROW_NUMBER ()
                   OVER (PARTITION BY qdt.incident_id
                         ORDER BY qdt.task_number, cdl.debrief_line_number)
                      row_sort,
                    csi.last_updated_by,                             -- 20170525 - BMarcoux
                    fnd.user_name                                    -- 20170525 - BMarcoux
              FROM haemo.xxha_b_sr_task_debriefs qdt,
                   apps.CS_SR_Incidents_V        csi,                -- 20170525 - BMarcoux
                   apps.FND_User                 fnd,                -- 20170525 - BMarcoux
                   apps.csf_debrief_lines cdl,
                   apps.mtl_system_items_b msi_bt,
                   apps.cst_item_costs mst_cst,
                   apps.cs_billing_type_categories cbt,
                   apps.cs_txn_billing_types ctbt,
                   apps.hr_organization_units hou,
                   (  SELECT source_id,
                             MAX (purchase_order_num) line_po_number,
                             SUM (
                                DECODE (NVL (estdtl.order_line_id, -999),
                                        -999, 0,
                                        estdtl.after_warranty_cost))
                                charge_line_submitted,
                             SUM (
                                DECODE (NVL (estdtl.order_line_id, -999),
                                        -999, estdtl.after_warranty_cost,
                                        0))
                                charge_line_unsubmitted,
                             SUM (estdtl.after_warranty_cost)
                                charge_line_amount
                        FROM cs_estimate_details estdtl
                       WHERE     estdtl.charge_line_type <> 'ESTIMATE'
                             AND estdtl.source_code = 'SD'
                    GROUP BY source_id) estdtl
             WHERE     1 = 1
                   AND qdt.debrief_header_id = cdl.debrief_header_id(+)
                   AND cdl.inventory_item_id = msi_bt.inventory_item_id(+)
                   AND msi_bt.organization_id(+) = 103
                   AND msi_bt.inventory_item_id =
                          mst_cst.inventory_item_id(+)
                   AND msi_bt.organization_id = mst_cst.organization_id(+)
                   AND mst_cst.cost_type_id(+) = 1
                   AND msi_bt.material_billable_flag = cbt.billing_type(+)
                   AND cdl.transaction_type_id = ctbt.transaction_type_id(+)
                   AND qdt.org_id = hou.organization_id(+)
                   AND cdl.debrief_line_id = estdtl.source_id(+)
                   AND qdt.incident_id     = csi.incident_id         -- 20170525 - BMarcoux
                   AND csi.last_updated_by = FND.USER_ID             -- 20170525 - BMarcoux
            UNION ALL
            SELECT qdt.incident_id,
                   qdt.incident_number,
                   qdt.reported_date,
                   qdt.incident_date,
                   qdt.date_closed,
                   qdt.org_id,
                   hou.name operating_unit,
                   qdt.incident_owner,
                   qdt.incident_owner_group,
                   qdt.incident_country_code,
                   qdt.address1,
                   qdt.address2,
                   qdt.address3,
                   qdt.address4,
                   qdt.city,
                   qdt.state,
                   qdt.country,
                   qdt.zip_code,
                   qdt.inventory_item_id,
                   qdt.instance_serial_number,
                   qdt.instance_product_name,
                   qdt.instance_item_product_descr,
                   qdt.install_date,
                   qdt.severity,
                   qdt.urgency,
                   qdt.incident_problem_code,
                   qdt.incident_problem_desc,
                   qdt.incident_problem_code_2,
                   qdt.incident_problem_desc_2,
                   qdt.incident_problem_code_3,
                   qdt.incident_problem_desc_3,
                   qdt.incident_problem_code_4,
                   qdt.incident_problem_desc_4,
                   qdt.incident_problem_code_5,
                   qdt.incident_problem_desc_5,
                   qdt.incident_problem_code_6,
                   qdt.incident_problem_desc_6,
                   qdt.incident_resolution_code,
                   qdt.incident_resolution_desc,
                   qdt.incident_resolution_code_2,
                   qdt.incident_resolution_desc_2,
                   qdt.incident_resolution_code_3,
                   qdt.incident_resolution_desc_3,
                   qdt.incident_resolution_code_4,
                   qdt.incident_resolution_desc_4,
                   qdt.incident_resolution_code_5,
                   qdt.incident_resolution_desc_5,
                   qdt.incident_resolution_code_6,
                   qdt.incident_resolution_desc_6,
                   qdt.incident_type,
                   qdt.incident_status_id,
                   qdt.incident_status_meaning,
                   qdt.logged_by,
                   qdt.creation_date,
                   qdt.sr_creation_channel,
                   qdt.last_update_date,
                   qdt.incident_context,
                   qdt.problem_summary,
                   qdt.resolution_summary,
                   qdt.purchase_order_num,
                   qdt.total_amount,
                   qdt.total_submitted,
                   qdt.total_unsubmitted,
                   qdt.pir_need,
                   qdt.process_phase,
                   qdt.death,
                   qdt.injury,
                   qdt.appendix_a,
                   qdt.extended_hosp,
                   qdt.contract_number,
                   qdt.contract_number_modifier,
                   qdt.service_name,
                   qdt.account_number,
                   qdt.customer_name,
                   qdt.customer_type,
                   qdt.contact_party_name,
                   qdt.contact_type,
                   qdt.primary_phone_area_code,
                   qdt.primary_phone_number,
                   qdt.email_address,
                   qdt.url,
                   NULL task_id,
                   NULL task_number,
                   NULL task_name,
                   NULL task_planned_start_date,
                   NULL task_actual_start_date,
                   NULL task_actual_end_date,
                   NULL response_time_in_hrs,
                   NULL task_owner,
                   NULL task_status,
                   NULL task_priority,
                   NULL repair_status_meaning,
                   NULL debrief_header_id,
                   NULL debrief_number,
                   NULL debrief_status,
                   NULL debrief_assignee_resource,
                   NULL debrief_assignee_country,
                   qdt.UDI_NUMBER,
NULL  DFF1_Value1,
NULL   DFF1_Value2,
NULL   DFF1_Value3,
NULL   DFF1_Value4,
NULL   DFF1_Value5,
NULL DFF1_Value6,
NULL DFF1_Value7,
NULL DFF1_Value8,
NULL DFF1_Value9,
NULL DFF1_Value10,
NULL DFF1_Value11,
NULL  DFF1_Value12,
NULL DFF1_Value13,
NULL DFF1_Value14,
NULL DFF1_Value15,
NULL DFF2_Value1,
NULL DFF2_Value2,
NULL DFF2_Value3,
NULL   DFF2_Value4,
NULL   DFF2_Value5,
NULL   DFF2_Value6,
NULL DFF2_Value7,
NULL  DFF2_Value8,
NULL   DFF2_Value9,
NULL  DFF2_Value10,
NULL DFF2_Value11,
NULL   DFF2_Value12,
NULL DFF2_Value13,
NULL  DFF2_Value14,
NULL  DFF2_Value15,qdt.bill_to_site_id,qdt.ship_to_site_id,
                   csn.note,
                   csn.note_type_meaning,
                   NULL debrief_line_id,
                   NULL debrif_serial_number,
                   NULL line_po_number,
                   NULL billing_category,
                   NULL material_used,
                   NULL material_used_description,
                   NULL material_used_quantity,
                   NULL material_used_mst_cost,
                   NULL labor_hours,
                   NULL labor_item,
                   NULL labor_item_description,
                   NULL labor_start_date,
                   NULL labor_end_date,
                   NULL expense_item,
                   NULL expense_item_description,
                   NULL expense_quantity,
                   NULL expense_uom,
                   NULL expense_item_amount,
                   NULL expenses_currency_code,
                   NULL charge_line_amount,
                   NULL charge_line_submitted,
                   NULL charge_line_unsubmitted,
                     1
                   - ROW_NUMBER ()
                     OVER (
                        PARTITION BY qdt.incident_id
                        ORDER BY
                           qdt.task_number DESC, csn.note_type_meaning DESC)
                      row_sort,
                    csi.last_updated_by,                             -- 20170525 - BMarcoux
                    fnd.user_name                                    -- 20170525 - BMarcoux
              FROM (SELECT ROW_NUMBER ()
                           OVER (PARTITION BY incident_id
                                 ORDER BY task_id, debrief_header_id)
                              row_rnk,
                           qdtb.*
                      FROM haemo.xxha_b_sr_task_debriefs qdtb) qdt,
                   apps.CS_SR_Incidents_V        csi,                -- 20170525 - BMarcoux
                   apps.FND_User                 fnd,                -- 20170525 - BMarcoux
                   apps.hr_organization_units hou,
                   apps.cs_sr_all_notes_v csn
             WHERE     qdt.row_rnk = 1
                   AND qdt.incident_id = csn.incident_id
                   AND csn.note_type_code<>'UDI'
                   AND qdt.incident_id     = csi.incident_id         -- 20170525 - BMarcoux
                   AND csi.last_updated_by = FND.USER_ID             -- 20170525 - BMarcoux 
                   AND qdt.org_id = hou.organization_id(+); 
 
         ln_record_count := SQL%ROWCOUNT;
      EXCEPTION
         WHEN OTHERS
         THEN
            FND_FILE.PUT_LINE (
               FND_FILE.LOG,
                  'Unexpected error occured while inserting into XXHA_B_SR_LINE_NOTE_DATA: '
               || SQLERRM);
      END;

      COMMIT;
      FND_FILE.PUT_LINE (
         FND_FILE.LOG,
            ln_record_count
         || ' - Records Successfully inserted in XXHA_B_SR_LINE_NOTE_DATA '
         || TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS'));
   END;
END XXHA_B_GET_SR_DATA_PKG;