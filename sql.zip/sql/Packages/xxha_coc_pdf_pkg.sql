
  CREATE OR REPLACE PACKAGE "APPS"."XXHA_COC_PDF_PKG" 
AS
  /*******************************************************************************************************
  * Object Name: XXHA_COC_PDF_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package will be used for CofC 
  *
  * Modification Log:
  * Developer          Version		Date                 Description
  *-----------------   ----------	------------------   ------------------------------------------------
  * Apps Associates    v1.0         16-JAN-2015          Initial object creation.
  * Apps Associates    v1.1         20-OCT-2015			 Restricted empty CofC file print	 
  *
  *
  *******************************************************************************************************/

  PROCEDURE xxha_coc_prc(
      p_deliv_id NUMBER,
      p_doc_printer IN VARCHAR2 );
  PROCEDURE xxha_coc_print(
      errbuf OUT VARCHAR2,
      retcode OUT VARCHAR2,
      p_delivery_id VARCHAR2,
      p_sno         VARCHAR2 );
  PROCEDURE xxha_submit_coc_print(
      p_delivery_id IN NUMBER,
      p_sno         IN VARCHAR2,
      p_doc_printer IN VARCHAR2);
END xxha_coc_pdf_pkg;
/

CREATE OR REPLACE PACKAGE BODY "APPS"."XXHA_COC_PDF_PKG" 
AS
  /*******************************************************************************************************
  * Object Name: XXHA_BE_SHIP_NOTIF_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package will be used shipconfirm business event plsql
  *
  * Modification Log:
  * Developer          Version		Date                 Description
  *-----------------   ----------	------------------   ------------------------------------------------
  * Apps Associates    v1.0         16-JAN-2015          Initial object creation.
  * Apps Associates    v1.1         20-OCT-2015			 Changed packslip report name being printed as per change request. Restricted empty CofC file print	 
  *
  *
  *******************************************************************************************************/

  l_filename   VARCHAR2(100) := 'Certificate_Of_Compliance.PDF';
  l_template   VARCHAR2(10)  := 'mixed';
  l_header_id  NUMBER;
  l_item_num   VARCHAR2(30);
  l_lot_num    VARCHAR2(30);
  l_cert_flag  VARCHAR2(1);
  l_request_id NUMBER;
  reqlength    NUMBER;
  eob          BOOLEAN := FALSE;
  l_http_request utl_http.req;
  l_http_response utl_http.resp;
  op_status_code NUMBER;
  request_env    VARCHAR2 (32767);
  request_env1   VARCHAR2 (32767);
  request_env2   VARCHAR2 (32767);
  request_env3   VARCHAR2 (32767);
  response_env   VARCHAR2 (32767);
  eof            BOOLEAN;
  BUFFER RAW(32767);
  buffer1 CLOB;
  l_output    VARCHAR2 (32767);
  l_key_str   NUMBER := 0;
  l_err_count NUMBER;
  l_count     NUMBER;
  l_blob BLOB;
  l_clob CLOB;
  p_blob BLOB;
  p_clob CLOB;
  l_text VARCHAR2(32767);
  l_substr_clob CLOB;
  l_start       NUMBER;
  l_end         NUMBER;
  l_length      NUMBER;
  l_substr_text VARCHAR2(32767);
  l_max         NUMBER := 32767;
  l_currval     NUMBER;
  l_func_blob BLOB;
  l_func_clob CLOB;
  l_pos pls_integer := 1;
  l_buffer RAW( 32767 );
  l_buffer64 RAW( 32767 );
  l_lob_len pls_integer   := dbms_lob.getlength( l_func_clob );
  l_template VARCHAR2(10) := 'mixed';
  v_blob_data BLOB;
  v_buffer RAW(32767);
  v_buffer_size binary_integer;
  v_amount binary_integer;
  v_offset    NUMBER(38) := 1;
  v_chunksize INTEGER;
  v_out_file utl_file.file_type;
  PROCEDURE xxha_coc_prc(
      p_deliv_id NUMBER,
      p_doc_printer IN VARCHAR2)
  IS
    CURSOR c_coc(l_delivery_id1 NUMBER)
    IS
      (SELECT DISTINCT ooh.header_id header_id,
        upper(ooh.attribute13) cert_flag,
        msib.segment1 item_num,
        dd.lot_number lot_num
      FROM apps.oe_order_headers_all ooh ,
        apps.oe_order_lines_all ool ,
        apps.wsh_delivery_details dd ,
        apps.wsh_delivery_assignments da ,
        apps.wsh_new_deliveries nd ,
        mtl_system_items_b msib
      WHERE 1                   =1
      AND ooh.header_id         = ool.header_id
      AND ool.header_id         = dd.source_header_id
      AND ool.line_id           = dd.source_line_id
      AND DD.LOT_NUMBER        IS NOT NULL
      AND dd.delivery_detail_id = da.delivery_detail_id
      AND da.delivery_id        = nd.delivery_id
      AND ool.inventory_item_id = msib.inventory_item_id
      AND ool.ship_from_org_id  = msib.organization_id
      AND da.delivery_id        = l_delivery_id1
      );
    l_cert_flag VARCHAR2(10) := 'N';
  BEGIN
    --deleted the existing records to load only new COCs
    fnd_file.put_line(fnd_file.LOG, 'Started Coc Print doc process');
    dbms_output.put_line('Started Coc Print doc process');
    BEGIN
      DELETE
      FROM xxha_coc_blob_tab
      WHERE delivery_id = p_deliv_id
      AND file_name LIKE 'Certificate_Of_Compliance%' ;
      COMMIT;
      dbms_output.put_line('Deleted CoC records from custom blob table for delivery ID: '||p_deliv_id);
    EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line('Error occured while deleted CoC records from custom blob table for delivery ID: '||p_deliv_id||'-'||SQLERRM);
    END;
    BEGIN
      FOR r_coc IN c_coc(p_deliv_id)
      LOOP
        l_cert_flag := r_coc.cert_flag;
        dbms_output.put_line('l_cert_flag: '||l_cert_flag);
        IF l_cert_flag = 'Y' THEN
          dbms_output.put_line('calling coc pdf proc: ');
          xxha_be_ship_notif_pkg.xxha_coc_pdf_prc( p_deliv_id, r_coc.header_id, r_coc.item_num, r_coc.lot_num, 'mixed' );
          COMMIT;
        END IF;
      END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.LOG, 'Error occured in Loop for calling - XXHA_BE_SHIP_NOTIF_PKG.XXHA_COC_PDF_PRC'||sqlerrm);
    END;
    IF l_cert_flag = 'Y' THEN
      BEGIN
        FOR r_coc_files IN
        (SELECT sno,
          delivery_id,
          LENGTH(blob_data) len_coc
        FROM xxha_coc_blob_tab
        WHERE delivery_id = p_deliv_id
        AND file_name LIKE 'Certificate_Of_Compliance%'
		AND LENGTH(blob_data) > 1000 -- v1.1 To restrict empty page when no CofC pdf is generated.
        )
        LOOP
          --IF r_coc_files.len_coc>1000 THEN -- Removed to print empty page when no CofC pdf is generated.
            xxha_submit_coc_print(r_coc_files.delivery_id, r_coc_files.sno, p_doc_printer);
          --END IF;
        END LOOP;
      EXCEPTION
      WHEN OTHERS THEN
        fnd_file.put_line(fnd_file.LOG, 'Error occured in Loop for calling - xxha_submit_coc_print');
      END;
    END IF;
    IF l_cert_flag = 'N' OR l_cert_flag IS NULL OR l_cert_flag <> 'Y' THEN
      fnd_file.put_line(fnd_file.LOG, 'Cert_Flag is not set to Y.');
    END IF;
    fnd_file.put_line(fnd_file.LOG, 'Completed Coc Print doc process.');
    dbms_output.put_line( 'Completed Coc Print doc process');
  END xxha_coc_prc;
  PROCEDURE xxha_coc_print(
      errbuf OUT VARCHAR2,
      retcode OUT VARCHAR2,
      p_delivery_id VARCHAR2,
      p_sno         VARCHAR2 )
  IS
  BEGIN
    fnd_file.put_line(fnd_file.LOG,'Entered coc print');
    SELECT blob_data
    INTO v_blob_data
    FROM xxha_coc_blob_tab
    WHERE delivery_id = to_number(p_delivery_id)
    AND sno           = to_number(p_sno);
    fnd_file.put_line(fnd_file.LOG,'Entered coc print ');
    /*start of writing the blob data into pdf*/
    v_chunksize := dbms_lob.getchunksize(v_blob_data);
    fnd_file.put_line(fnd_file.LOG,'v_chunksize:'||v_chunksize);
    IF (v_chunksize  < 32767) THEN
      v_buffer_size := v_chunksize;
    ELSE
      v_buffer_size := 32767;
    END IF;
    v_amount := v_buffer_size;
    fnd_file.put_line(fnd_file.LOG,'v_amount:'||v_amount);
    l_request_id   := fnd_profile.VALUE('CONC_REQUEST_ID');
    v_out_file     := utl_file.fopen( LOCATION => 'XXHA_CONCPRG_OUTPUT', filename => 'o'||l_request_id||'.out', open_mode => 'wb', max_linesize => 32767);
    WHILE v_amount >= v_buffer_size
    LOOP
      fnd_file.put_line(fnd_file.LOG,'entered loop:');
      dbms_lob.READ( lob_loc => v_blob_data,amount => v_amount, offset => v_offset, BUFFER => v_buffer);
      v_offset := v_offset + v_amount;
      fnd_file.put_line(fnd_file.LOG,'entered loop. v_offset:'||v_offset);
      utl_file.put_raw ( FILE => v_out_file, BUFFER => v_buffer, autoflush => TRUE);
      utl_file.fflush(FILE => v_out_file);
      fnd_file.put_line(fnd_file.LOG,'end loop');
    END LOOP;
    utl_file.fflush(FILE => v_out_file);
    utl_file.fclose(v_out_file);
    /*end of writing the blob data into pdf*/
    fnd_file.put_line(fnd_file.LOG,'completed coc print');
  END xxha_coc_print;
  PROCEDURE xxha_submit_coc_print(
      p_delivery_id IN NUMBER,
      p_sno         IN VARCHAR2,
      p_doc_printer IN VARCHAR2)
  AS
    l_user_id fnd_user.user_id%TYPE;
    l_resp_id fnd_responsibility.responsibility_id%TYPE;
    l_resp_appl_id fnd_application.application_id%TYPE;
    l_set_layout01       BOOLEAN;
    l_request_id         NUMBER;
    l_messase            VARCHAR2(2000);
    l_phase              VARCHAR2 (100);
    l_status             VARCHAR2 (100);
    l_dev_phase          VARCHAR2 (100);
    l_dev_status         VARCHAR2 (100);
    l_option_return01    BOOLEAN := FALSE;
    l_wait_for_request   BOOLEAN := FALSE;
    l_get_request_status BOOLEAN := FALSE;
    l_directory_path     VARCHAR2 (100);
    l_file_name          VARCHAR2 (100);
    b_set_nls            BOOLEAN;
    b_set_mode           BOOLEAN;
    l_doc_printer        VARCHAR2(100);
  BEGIN
    l_request_id := NULL;
    -- Get the Apps Intilization Variables
    BEGIN
      SELECT fresp.responsibility_id,
        fresp.application_id
      INTO l_resp_id,
        l_resp_appl_id
      FROM fnd_responsibility_tl fresp
      WHERE 1                       =1
      AND fresp.responsibility_name = 'US Order Management Super User OC'
      AND fresp.language            = userenv('LANG');
    EXCEPTION
    WHEN OTHERS THEN
      l_resp_id      :=NULL;
      l_resp_appl_id := NULL;
    END;
    --Initialize the Apps Variables
    l_user_id := fnd_global.user_id;--29027; --
    fnd_global.apps_initialize (user_id => l_user_id, resp_id => l_resp_id, resp_appl_id => l_resp_appl_id);
    -- set noprint option if printer parameter is null.
    IF p_doc_printer IS NOT NULL THEN
      l_doc_printer  := p_doc_printer;
    ELSE
      l_doc_printer := 'noprint';
    END IF;
    l_option_return01 := fnd_request.set_print_options ( printer => l_doc_printer, style => NULL, copies => 1, save_output => TRUE, print_together => 'N' );
    --l_option_return01 := TRUE;
    IF l_option_return01 THEN
      -- Submit the Request
      b_set_nls    := apps.fnd_submit.set_nls_options('AMERICAN');
      b_set_mode   := apps.fnd_submit.set_mode (FALSE);
      l_request_id := fnd_request.submit_request ( 'HAEMO' -- Application
      , 'XXHA_COC_REP'                                     -- Program (i.e. 'XXHA_WSHRDPAK_BCD_US_PTO')
      , NULL                                               -- Description
      , NULL                                               -- Start Time
      , FALSE                                              -- Sub Request
      ,p_delivery_id ,p_sno);
      COMMIT;
      fnd_file.put_line(fnd_file.log,'XXHA CoC Report submitted with request ID '||l_request_id);
      dbms_output.put_line('XXHA CoC Report submitted with request ID '||l_request_id);
      IF l_request_id > 0 THEN
        --waits for the request completion
        l_wait_for_request := fnd_concurrent.wait_for_request (request_id => l_request_id, INTERVAL => 1, max_wait => 0, phase => l_phase, status => l_status, dev_phase => l_dev_phase, dev_status => l_dev_status, MESSAGE => l_messase);
        COMMIT;
        -- Get the Request Completion Status.
        l_get_request_status := fnd_concurrent.get_request_status ( request_id => l_request_id, appl_shortname => NULL, PROGRAM => NULL, phase => l_phase, status => l_status, dev_phase => l_dev_phase, dev_status => l_dev_status, MESSAGE => l_messase );
        fnd_file.put_line(fnd_file.log,'XXHA CoC Report is '||l_dev_phase || ' with status '||l_dev_status );
        dbms_output.put_line('XXHA CoC Report is '||l_dev_phase || ' with status '||l_dev_status );
      ELSE
        fnd_file.put_line(fnd_file.log,'XXHA CoC Report. Error in wait for request.' );
        dbms_output.put_line('XXHA CoC Report. Error in wait for request.' );
      END IF; --l_request_id
    ELSE
      fnd_file.put_line(fnd_file.log,'XXHA CoC Report. Error while setting printer' );
      dbms_output.put_line('XXHA CoC Report. Error while setting printer' );
    END IF; --l_option_return01
  EXCEPTION
  WHEN OTHERS THEN
    fnd_file.put_line(fnd_file.log,'ERROR:' ||sqlerrm);
    dbms_output.put_line('ERROR:' ||sqlerrm);
  END xxha_submit_coc_print;
END xxha_coc_pdf_pkg;
/