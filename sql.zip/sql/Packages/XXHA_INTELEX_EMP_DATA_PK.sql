CREATE OR REPLACE PACKAGE XXHA_INTELEX_EMP_DATA_PK AUTHID CURRENT_USER AS
/**************************************************************************************************
* Package Name : XXHA_INTELEX_EMP_DATA_PK                                                         *
* Purpose      : This package provides functions to retrieve Intelex override data.               *
*                                                                                                 *
* Used By      : XXHA_INTELEX_V (View)                                                            *
*                                                                                                 *
* FUNCTIONS    : f_security_group                                                                 *
*              : f_license_type                                                                   *
*              : f_group                                                                          *
*              : f_home_location                                                                  *
*              : f_login_location                                                                 *
*                                                                                                 *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)          *
*   PER_PEOPLE_EXTRA_INFO    S                                                                    *
*   PER_ALL_PEOPLE_F         S                                                                    *
*   PER_Assignments_F        S                                                                    *
*                                                                                                 *
* Change History                                                                                  *
*                                                                                                 *
* Ver        Date            Author               Description                                     *
* ------     -----------     -----------------    ---------------                                 *
* 1.0        28-AUG-2013     B. Marcoux           Initial Package Creation                        *
* 2.0        22-NOV-2013     B. Marcoux           Correction to code when determining values      *
*                                                  for HOMELOCATIONCODE and LOGINLOCATIONCODE.    *
*                                                                                                 *
**************************************************************************************************/

--------------------------------------------------------------------------------
-- Retrieve SECURITY GROUP NAME
FUNCTION f_security_group (
                           p_Person_ID          IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                          )
RETURN VARCHAR2;


--------------------------------------------------------------------------------
-- Retrieve LICENSE TYPE
FUNCTION f_license_type (
                         p_Person_ID            IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                        )
RETURN VARCHAR2;


--------------------------------------------------------------------------------
-- Retrieve GROUPS
FUNCTION f_group (
                  p_Person_ID                   IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                 )
RETURN VARCHAR2;


--------------------------------------------------------------------------------
-- Retrieve HOMELOCATIONCODE
FUNCTION f_home_location (
                           p_Person_ID          IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                         , p_Name               IN  hr_all_organization_units_tl.Name%TYPE
                         , p_Location_Code      IN  hr_locations.location_Code%TYPE
                          )
RETURN VARCHAR2;


--------------------------------------------------------------------------------
-- Retrieve LOGINLOCATIONCODE
FUNCTION f_login_location (
                           p_Person_ID          IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                         , p_Name               IN  hr_all_organization_units_tl.Name%TYPE
                         , p_Location_Code      IN  hr_locations.location_Code%TYPE
                          )
RETURN VARCHAR2;

END XXHA_INTELEX_EMP_DATA_PK;
/


CREATE OR REPLACE PACKAGE BODY XXHA_INTELEX_EMP_DATA_PK AS
/**************************************************************************************************
* Package Name : XXHA_INTELEX_EMP_DATA_PK                                                         *
* Purpose      : This package provides functions to retrieve Intelex override data.               *
*                                                                                                 *
* Used By      : XXHA_INTELEX_V (View)                                                            *
*                                                                                                 *
* FUNCTIONS    : f_security_group                                                                 *
*              : f_license_type                                                                   *
*              : f_group                                                                          *
*              : f_home_location                                                                  *
*              : f_login_location                                                                 *
*                                                                                                 *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)          *
*   PER_PEOPLE_EXTRA_INFO    S                                                                    *
*   PER_ALL_PEOPLE_F         S                                                                    *
*   PER_Assignments_F        S                                                                    *
*                                                                                                 *
* Change History                                                                                  *
*                                                                                                 *
* Ver        Date            Author               Description                                     *
* ------     -----------     -----------------    ---------------                                 *
* 1.0        28-AUG-2013     B. Marcoux           Initial Package Creation                        *
* 2.0        22-NOV-2013     B. Marcoux           Correction to code when determining values      *
*                                                  for HOMELOCATIONCODE and LOGINLOCATIONCODE.    *
*                                                                                                 *
**************************************************************************************************/

--------------------------------------------------------------------------------
-- Retrieve SECURITY GROUP NAME
FUNCTION f_security_group (
                           p_Person_ID          IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                          )
RETURN VARCHAR2
IS

    -- Cursor 1
    CURSOR cs1 IS
    SELECT
         PE.PEI_INFORMATION1
    FROM
         PER_PEOPLE_EXTRA_INFO    PE
    WHERE
         pe.information_type    = 'HAE_INTELEX_ADMIN'
    AND  pe.PERSON_ID           = p_PERSON_ID;

    -- Cursor 2
    CURSOR cs2 IS
    SELECT
         NVL(COUNT(*),0)
    FROM
         HR.PER_ALL_PEOPLE_F    PPL
      ,  PER_Assignments_F      PAF
    WHERE
         PAF.Supervisor_ID    = p_PERSON_ID
    AND  PAF.Person_ID        = PPL.Person_ID
    AND  TRUNC(SYSDATE)       BETWEEN TRUNC(PAF.Effective_Start_Date) AND NVL(TRUNC(PAF.Effective_End_Date), SYSDATE)
    AND  TRUNC(SYSDATE)       BETWEEN TRUNC(PPL.Effective_Start_Date) AND NVL(TRUNC(PPL.Effective_End_Date), SYSDATE)
    AND  hr_person_type_usage_info.get_user_person_type (SYSDATE, paf.person_id) LIKE 'Employee%';

    l_Security_Group_dft      PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := 'Limited Access';     -- Set to Default Value for Employees
    l_Security_Group_sup      PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := 'Supervisor Access';  -- Set to Default Value for Supervisor Access
    l_Security_Group          PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := NULL;
    p_Security_Group          PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := NULL;
    l_Count                   NUMBER                                            := NULL;

BEGIN

    -- Set Default Value
    p_Security_Group := l_Security_Group_dft;

    -- See if person is a Supervisor to override the Default Value for Employees
    OPEN cs2;
    FETCH cs2 INTO l_Count;
    IF l_Count > 0 THEN
       p_Security_Group := l_Security_Group_sup;
    END IF;           
    CLOSE cs2;

    -- See if there are overrides for the person
    OPEN cs1;
    FETCH cs1 INTO l_Security_Group;
    IF cs1%FOUND AND l_Security_Group IS NOT NULL THEN
       p_Security_Group := l_Security_Group;
    END IF;

    CLOSE cs1;

    RETURN p_Security_Group;

END f_security_group;

--------------------------------------------------------------------------------
-- Retrieve LICENSE TYPE
FUNCTION f_license_type (
                         p_Person_ID          IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                        )
RETURN VARCHAR2
IS

    -- Cursor 1
    CURSOR cs1 IS
    SELECT
         PE.PEI_INFORMATION2
    FROM
         PER_PEOPLE_EXTRA_INFO    PE
    WHERE
         pe.information_type    = 'HAE_INTELEX_ADMIN'
    AND  pe.PERSON_ID           = p_PERSON_ID;

    -- Cursor 2
    CURSOR cs2 IS
    SELECT
         NVL(COUNT(*),0)
    FROM
         HR.PER_ALL_PEOPLE_F    PPL
      ,  PER_Assignments_F      PAF
    WHERE
         PAF.Supervisor_ID    = p_PERSON_ID
    AND  PAF.Person_ID        = PPL.Person_ID
    AND  TRUNC(SYSDATE)       BETWEEN TRUNC(PAF.Effective_Start_Date) AND NVL(TRUNC(PAF.Effective_End_Date), SYSDATE)
    AND  TRUNC(SYSDATE)       BETWEEN TRUNC(PPL.Effective_Start_Date) AND NVL(TRUNC(PPL.Effective_End_Date), SYSDATE)
    AND  hr_person_type_usage_info.get_user_person_type (SYSDATE, paf.person_id) LIKE 'Employee%';

    l_License_Type_dft        PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE2%TYPE         := 'Concurrent Access';  -- Set to Default Value for Employees
    l_License_Type_sup        PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE2%TYPE         := 'Concurrent Access';  -- Set to Default Value for Supervisor Access
    l_License_Type            PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE2%TYPE         := NULL;
    p_License_Type            PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE2%TYPE         := NULL;
    l_Count                   NUMBER                                            := NULL;

BEGIN

    -- Set Default Value
    p_License_Type := l_License_Type_dft;

    -- See if person is a Supervisor to override the Default Value for Employees
    OPEN cs2;
    FETCH cs2 INTO l_Count;
    IF l_Count > 0 THEN
       p_License_Type := l_License_Type_sup;
    END IF;           
    CLOSE cs2;

    -- See if there are overrides for the person
    OPEN cs1;
    FETCH cs1 INTO l_License_Type;
    IF cs1%FOUND AND l_License_Type IS NOT NULL THEN
       p_License_Type := l_License_Type;
    END IF;
       
    CLOSE cs1;

    RETURN p_License_Type;

END f_license_type;

--------------------------------------------------------------------------------
-- Retrieve GROUPS
FUNCTION f_group (
                  p_Person_ID          IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                 )
RETURN VARCHAR2
IS

    -- Cursor 1
    CURSOR cs1 IS
    SELECT
         PE.PEI_INFORMATION1
	   , PE.PEI_INFORMATION5
    FROM
         PER_PEOPLE_EXTRA_INFO    PE
    WHERE
         pe.information_type    = 'HAE_INTELEX_ADMIN'
    AND  pe.PERSON_ID           = p_PERSON_ID;

    -- Cursor 2
    CURSOR cs2 IS
    SELECT
         NVL(COUNT(*),0)
    FROM
         HR.PER_ALL_PEOPLE_F    PPL
      ,  PER_Assignments_F      PAF
    WHERE
         PAF.Supervisor_ID    = p_PERSON_ID
    AND  PAF.Person_ID        = PPL.Person_ID
    AND  TRUNC(SYSDATE)       BETWEEN TRUNC(PAF.Effective_Start_Date) AND NVL(TRUNC(PAF.Effective_End_Date), SYSDATE)
    AND  TRUNC(SYSDATE)       BETWEEN TRUNC(PPL.Effective_Start_Date) AND NVL(TRUNC(PPL.Effective_End_Date), SYSDATE)
    AND  hr_person_type_usage_info.get_user_person_type (SYSDATE, paf.person_id) LIKE 'Employee%';

    l_Security_Group_dft      PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := 'Limited Access';     -- Set to Default Value for Employees
    l_Security_Group_sup      PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := 'Supervisor Access';  -- Set to Default Value for Supervisor Access
    l_Security_Group          PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := NULL;
    p_Security_Group          PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE1%TYPE         := NULL;
    l_group                   NVARCHAR2(250)                                    := '0117f4de-cfeb-4705-929f-b8e3220d93f8';  -- Set to Default Value for Employees
    l_Role                    PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE5%TYPE         := NULL;
    l_Count                   NUMBER                                            := NULL;

BEGIN

    -- Set Default Value
    p_Security_Group := l_Security_Group_dft;

    -- See if person is a Supervisor to override the Default Value for Employees
    OPEN cs2;
    FETCH cs2 INTO l_Count;
    IF l_Count > 0 THEN
       p_Security_Group := l_Security_Group_sup;
    END IF;           
    CLOSE cs2;

    -- See if there are overrides for the person
    OPEN cs1;
    FETCH cs1 INTO l_Security_Group, l_Role;
    IF cs1%FOUND AND l_Security_Group IS NOT NULL THEN
       p_Security_Group := l_Security_Group;
    END IF;

    CLOSE cs1;

    IF p_Security_Group = 'System Administrator' THEN
       l_Group := 'adb6bea1-774d-465a-9e2c-89ff4d0a903b';
    ELSIF p_Security_Group = 'Full Access' THEN
       l_Group := 'f201901c-4e0d-48b5-95ef-fecf67b598e0';
    ELSIF p_Security_Group = 'Supervisor Access' THEN
       l_Group := 'e032b566-1eb1-4ee2-8dd2-c4416b9ec8dc';
    END IF;

    -- Determine values in l_Role (PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE5)
    IF l_Role LIKE '%HSE Manager%' THEN
       l_Group := (l_Group || ';HSE Manager()');
    ELSIF l_Role LIKE '%Department Supervisor%' THEN
       l_Group := (l_Group || ';Department Supervisor()');
    ELSIF l_Role LIKE '%Both%' THEN
       l_Group := (l_Group || ';HSE Manager();Department Supervisor()');
    END IF;

    RETURN l_Group;

END f_group;

--------------------------------------------------------------------------------
-- Retrieve HOMELOCATIONCODE
FUNCTION f_home_location (
                           p_Person_ID     IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                         , p_Name          IN  hr_all_organization_units_tl.Name%TYPE
                         , p_Location_Code IN  hr_locations.location_Code%TYPE
                          )
RETURN VARCHAR2
IS

    -- Cursor 1
    CURSOR cs1 IS
    SELECT
         PE.PEI_INFORMATION3
    FROM
         PER_PEOPLE_EXTRA_INFO    PE
    WHERE
         pe.information_type    = 'HAE_INTELEX_ADMIN'
    AND  pe.PERSON_ID           = p_PERSON_ID;

    -- Cursor 2
    CURSOR cs2 IS
    SELECT
         hla.attribute4
      ,  hla.location_code
      ,  hrh.d_parent_name
      ,  hrh.d_child_name
    FROM
         HR.PER_ALL_PEOPLE_F          PPL
      ,  PER_Assignments_F            PAF
      ,  hr_locations_all             hla
      ,  hr_all_organization_units    haou
      ,  (SELECT
            c1.ORGANIZATION_ID_CHILD
          , c1.D_CHILD_NAME
          , c1.ORGANIZATION_ID_PARENT
          , c1.D_PARENT_NAME
       FROM
            PER_ORGANIZATION_STRUCTURES_V   a1
          , PER_ORG_STRUCTURE_ELEMENTS_V    c1
          , PER_ORG_STRUCTURE_VERSIONS_V    b1
      WHERE
            a1.name                       = 'HAE Global HR Hierarchy'
        AND a1.ORGANIZATION_STRUCTURE_ID  = b1.ORGANIZATION_STRUCTURE_ID
        AND b1.ORG_STRUCTURE_VERSION_ID   = c1.ORG_STRUCTURE_VERSION_ID
        AND hr_general.effective_date     BETWEEN b1.DATE_FROM AND NVL(b1.DATE_TO, SYSDATE)) HRH
    WHERE
         PAF.PERSON_ID             = p_PERSON_ID
    AND  PAF.Person_ID             = PPL.Person_ID
    AND  TRUNC(SYSDATE)            BETWEEN TRUNC(PAF.Effective_Start_Date) AND NVL(TRUNC(PAF.Effective_End_Date), SYSDATE)
    AND  TRUNC(SYSDATE)            BETWEEN TRUNC(PPL.Effective_Start_Date) AND NVL(TRUNC(PPL.Effective_End_Date), SYSDATE)
    AND  PAF.location_id           = hla.location_id(+)
    AND  paf.organization_id       = haou.organization_id
    AND  paf.ORGANIZATION_ID       = hrh.ORGANIZATION_ID_CHILD(+)
    AND (HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE),PPL.PERSON_ID) LIKE 'Employee%'
    OR   HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE),PPL.PERSON_ID) LIKE 'HAE Contingent%');

    l_loc_region              hr_locations_all.attribute4%TYPE                  := NULL;
    l_loc_code                hr_locations_all.location_code%TYPE               := NULL;
    l_d_parent_name           PER_ORG_STRUCTURE_ELEMENTS_V.D_PARENT_NAME%TYPE   := NULL;
    l_d_child_name            PER_ORG_STRUCTURE_ELEMENTS_V.D_CHILD_NAME%TYPE    := NULL;
    l_home_location           PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE3%TYPE         := NULL;
    p_home_location           PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE3%TYPE         := NULL;

BEGIN

    -- Set first segment to hard-coded value 'Haemonetics'
    p_home_location := ('Haemonetics');

    -- Retrieve Data and append Location Region flexfield, location and parent org in the employee�s org hierarchy
    OPEN cs2;

    FETCH cs2 INTO l_loc_region, l_loc_code, l_d_parent_name, l_d_child_name;

    IF cs2%FOUND THEN
       IF l_loc_region IS NOT NULL THEN
          p_home_location := (p_home_location || ':' || l_loc_region);
       END IF;
       IF l_loc_code IS NOT NULL THEN
          p_home_location := (p_home_location || ':' || l_loc_code);
       END IF;
       IF l_d_parent_name IS NOT NULL THEN
          p_home_location := (p_home_location || ':' || l_d_parent_name);
       END IF;

       -- If Parent Org is Manufacturing, check Child
       --    If Child is Facilities then send Manufacturing
       --    If Child starts with 'Plant Manufacturing � ' then remove that and send the rest of the string
       IF l_d_parent_name = 'Manufacturing' THEN
          IF    l_d_child_name = 'Facilities' THEN
                p_home_location := (p_home_location || ':' || l_d_child_name);
--              p_home_location := (p_home_location || ':' || l_d_parent_name);
				ELSIF l_d_child_name LIKE 'Plant Manufacturing - %' THEN
                p_home_location := (p_home_location || ':' || SUBSTR(l_d_child_name, (INSTR(l_d_child_name,'-', 1, 1) + 2), LENGTH(l_d_child_name)));
          END IF;
       END IF;
    END IF;

    CLOSE cs2;

    -- See if there are overrides for the person
    OPEN cs1;
    FETCH cs1 INTO l_home_location;
    IF cs1%FOUND AND l_home_location IS NOT NULL THEN
       p_home_location := l_home_location;
    END IF;

    CLOSE cs1;

    RETURN p_home_location;

END f_home_location;

--------------------------------------------------------------------------------
-- Retrieve LOGINLOCATIONCODE
FUNCTION f_login_location (
                           p_Person_ID     IN  PER_ALL_PEOPLE_F.Person_ID%TYPE
                         , p_Name          IN  hr_all_organization_units_tl.Name%TYPE
                         , p_Location_Code IN  hr_locations.location_Code%TYPE
                          )
RETURN VARCHAR2
IS

    -- Cursor 1
    CURSOR cs1 IS
    SELECT
         PE.PEI_INFORMATION4
    FROM
         PER_PEOPLE_EXTRA_INFO    PE
    WHERE
         pe.information_type    = 'HAE_INTELEX_ADMIN'
    AND  pe.PERSON_ID           = p_PERSON_ID;

    -- Cursor 2
    CURSOR cs2 IS
    SELECT
         hla.attribute4
      ,  hla.location_code
      ,  hrh.d_parent_name
      ,  hrh.d_child_name
    FROM
         HR.PER_ALL_PEOPLE_F          PPL
      ,  PER_Assignments_F            PAF
      ,  hr_locations_all             hla
      ,  hr_all_organization_units    haou
      ,  (SELECT
            c1.ORGANIZATION_ID_CHILD
          , c1.D_CHILD_NAME
          , c1.ORGANIZATION_ID_PARENT
          , c1.D_PARENT_NAME
       FROM
            PER_ORGANIZATION_STRUCTURES_V   a1
          , PER_ORG_STRUCTURE_ELEMENTS_V    c1
          , PER_ORG_STRUCTURE_VERSIONS_V    b1
      WHERE
            a1.name                       = 'HAE Global HR Hierarchy'
        AND a1.ORGANIZATION_STRUCTURE_ID  = b1.ORGANIZATION_STRUCTURE_ID
        AND b1.ORG_STRUCTURE_VERSION_ID   = c1.ORG_STRUCTURE_VERSION_ID
        AND hr_general.effective_date     BETWEEN b1.DATE_FROM AND NVL(b1.DATE_TO, SYSDATE)) HRH
    WHERE
         PAF.PERSON_ID             = p_PERSON_ID
    AND  PAF.Person_ID             = PPL.Person_ID
    AND  TRUNC(SYSDATE)            BETWEEN TRUNC(PAF.Effective_Start_Date) AND NVL(TRUNC(PAF.Effective_End_Date), SYSDATE)
    AND  TRUNC(SYSDATE)            BETWEEN TRUNC(PPL.Effective_Start_Date) AND NVL(TRUNC(PPL.Effective_End_Date), SYSDATE)
    AND  PAF.location_id           = hla.location_id(+)
    AND  paf.organization_id       = haou.organization_id
    AND  paf.ORGANIZATION_ID       = hrh.ORGANIZATION_ID_CHILD(+)
    AND (HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE),PPL.PERSON_ID) LIKE 'Employee%'
    OR   HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE),PPL.PERSON_ID) LIKE 'HAE Contingent%');

    l_loc_region              hr_locations_all.attribute4%TYPE                  := NULL;
    l_loc_code                hr_locations_all.location_code%TYPE               := NULL;
    l_d_parent_name           PER_ORG_STRUCTURE_ELEMENTS_V.D_PARENT_NAME%TYPE   := NULL;
    l_d_child_name            PER_ORG_STRUCTURE_ELEMENTS_V.D_CHILD_NAME%TYPE    := NULL;
    l_login_location          PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE4%TYPE         := NULL;
    p_login_location          PER_PEOPLE_EXTRA_INFO.PEI_ATTRIBUTE4%TYPE         := NULL;

BEGIN

    -- Set first segment to hard-coded value 'Haemonetics'
    p_login_location := ('Haemonetics');

    -- Retrieve Data and append Location Region flexfield, location and parent org in the employee�s org hierarchy
    OPEN cs2;

    FETCH cs2 INTO l_loc_region, l_loc_code, l_d_parent_name, l_d_child_name;

    IF cs2%FOUND THEN
       IF l_loc_region IS NOT NULL THEN
          p_login_location := (p_login_location || ':' || l_loc_region);
       END IF;
       IF l_loc_code IS NOT NULL THEN
          p_login_location := (p_login_location || ':' || l_loc_code);
       END IF;
       IF l_d_parent_name IS NOT NULL THEN
          p_login_location := (p_login_location || ':' || l_d_parent_name);
       END IF;

       -- If Parent Org is Manufacturing, check Child
       --    If Child is Facilities then send Manufacturing
       --    If Child starts with 'Plant Manufacturing � ' then remove that and send the rest of the string
       IF l_d_parent_name = 'Manufacturing' THEN
          IF    l_d_child_name = 'Facilities' THEN
                p_login_location := (p_login_location || ':' || l_d_child_name);
--              p_login_location := (p_login_location || ':' || l_d_parent_name);
				ELSIF l_d_child_name LIKE 'Plant Manufacturing - %' THEN
                p_login_location := (p_login_location || ':' || SUBSTR(l_d_child_name, (INSTR(l_d_child_name,'-', 1, 1) + 2), LENGTH(l_d_child_name)));
          END IF;
       END IF;
    END IF;

    CLOSE cs2;

    -- See if there are overrides for the person
    OPEN cs1;
    FETCH cs1 INTO l_login_location;
    IF cs1%FOUND AND l_login_location IS NOT NULL THEN
       p_login_location := l_login_location;
    END IF;

    CLOSE cs1;

    RETURN p_login_location;

END f_login_location;

END XXHA_INTELEX_EMP_DATA_PK;
/
