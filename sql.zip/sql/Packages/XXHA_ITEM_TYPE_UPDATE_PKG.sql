create or replace PACKAGE XXHA_ITEM_TYPE_UPDATE_PKG AUTHID CURRENT_USER AS 

/************************************************************************************************************************
* Package Name : XXHA_ITEM_TYPE_UPDATE_PKG                                                                              *
* Purpose      : This package sets the Item Type for each child org to the Item Type for the MST Org.                   *
*                                                                                                                       *
* Procedures   : XXHA_ITEM_TYPE_UPDATE_TO_MST                                                                           *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        10-JAN-2018     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

   PROCEDURE XXHA_ITEM_TYPE_UPDATE_TO_MST(
                                        x_errbuf  OUT VARCHAR2
                                      , x_retcode OUT VARCHAR2
                                           );

END XXHA_ITEM_TYPE_UPDATE_PKG;