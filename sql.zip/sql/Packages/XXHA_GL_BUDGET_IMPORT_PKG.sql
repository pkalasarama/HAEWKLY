CREATE OR REPLACE PACKAGE XXHA_GL_BUDGET_IMPORT_PKG AS

-- Procedure to determine calling parameters for GL Budget Load Concurrent Request
-- Takes in the mandatory and optional parameters required for GL Budget Load Concurrent Request

-- Version History
-- 1.0       Eric Rossing         27-SEP-2011            Initial Creation

PROCEDURE HANDLE_BUDGET_IMPORT(p_budget_name IN VARCHAR2,
			    p_budget_organization IN VARCHAR2,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg OUT VARCHAR
			    );


END XXHA_GL_BUDGET_IMPORT_PKG;

/


CREATE OR REPLACE PACKAGE BODY XXHA_GL_BUDGET_IMPORT_PKG AS

-- Procedure to determine calling parameters for GL Budget Load Concurrent Request
-- Takes in the mandatory and optional parameters required for GL Budget Load Concurrent Request

-- Version History
-- 1.0       Eric Rossing         27-SEP-2011            Initial Creation

PROCEDURE HANDLE_BUDGET_IMPORT(p_budget_name IN VARCHAR2,
			    p_budget_organization IN VARCHAR2,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg OUT VARCHAR
			    )
	IS
	v_program  			 VARCHAR2(20):='GLBBSU'; -- Order Import
	v_application		 VARCHAR2(20):='SQLGL'; -- Application
	v_application_id		 NUMBER;
  v_user_name      VARCHAR2(20);
	v_user_id			 NUMBER;
  v_user_responsibility VARCHAR2(50);
	v_user_responsibility_id NUMBER;
  v_parameter_1   VARCHAR2(10);
  v_parameter_2   VARCHAR2(10);
  v_parameter_4   VARCHAR2(10);
  v_parameter_6   VARCHAR2(10);
  
BEGIN

	  -- Fetch Application id for ONT Application
	  v_errmsg:='Fetching the Application Id';

	  SELECT application_id
	  INTO   v_application_id
	  FROM   applsys.fnd_application
	  WHERE  application_short_name = 'SQLGL';

	  -- Fetch the User Name
	  v_errmsg:='Fetching the User Name';

    SELECT value
    INTO v_user_name
    FROM HAEMO.HAEMO_INTERFACE_PARAMETERS
    WHERE PARAMETER_GROUP='HYP_BUDGET_IMPORT'
    AND KEY='IMP_USER_NAME';
    
	  -- Fetch the User Id
	  v_errmsg:='Fetching the User Id';
	  v_user_id:=wm_conc_request_pkg.get_user_id(v_user_name);

	  -- Fetch the Responsibility
	  v_errmsg:='Fetching the Responsibility';

    SELECT value
    INTO v_user_responsibility
    FROM HAEMO.HAEMO_INTERFACE_PARAMETERS
    WHERE PARAMETER_GROUP='HYP_BUDGET_IMPORT'
    AND KEY='IMP_RESPONSIBILITY';
    
	  -- Fetch the Responsibility Id
	  v_errmsg:='Fetching the Responsibility Id';

        v_user_responsibility_id:= wm_conc_request_pkg.get_user_responsibility_id( v_user_responsibility);

 Fnd_Global.apps_initialize(v_user_id,v_user_responsibility_id,v_application_id);
 
    -- Fetch Parameters
    v_errmsg:='Fetching parameter 1';
    
    SELECT value
    INTO v_parameter_1
    FROM HAEMO.HAEMO_INTERFACE_PARAMETERS
    WHERE PARAMETER_GROUP='HYP_BUDGET_IMPORT'
    AND KEY='IMP_PARAMETER_1';
    
    v_errmsg:='Fetching parameter 2';
    
    SELECT value
    INTO v_parameter_2
    FROM HAEMO.HAEMO_INTERFACE_PARAMETERS
    WHERE PARAMETER_GROUP='HYP_BUDGET_IMPORT'
    AND KEY='IMP_PARAMETER_2';
    
    v_errmsg:='Fetching parameter 4';
    
    SELECT value
    INTO v_parameter_4
    FROM HAEMO.HAEMO_INTERFACE_PARAMETERS
    WHERE PARAMETER_GROUP='HYP_BUDGET_IMPORT'
    AND KEY='IMP_PARAMETER_4';
    
    v_errmsg:='Fetching parameter 6';
    
    SELECT value
    INTO v_parameter_6
    FROM HAEMO.HAEMO_INTERFACE_PARAMETERS
    WHERE PARAMETER_GROUP='HYP_BUDGET_IMPORT'
    AND KEY='IMP_PARAMETER_6';
    

	  -- Call to submit request
        v_errmsg:='Submitting the Concurrent Request';

	  Wm_Conc_Request_Pkg.wm_request_submit(v_application_id,
	  							v_user_responsibility_id,
	  							v_user_id,
	  							v_application,
			  			     		v_program,
			  			     		v_status,
			  			     		v_request_id,
			  			     		NULL,
			  			     		NULL,
			  			     		o_message,
			  			     		v_errmsg,
           			  	     			v_parameter_1,
           			  	     			v_parameter_2,
           			  	     			p_budget_name,
                              v_parameter_4,
           			  	     			p_budget_organization,
                              v_parameter_6);

EXCEPTION
WHEN OTHERS THEN
 v_errmsg:=v_errmsg||SQLERRM;


END HANDLE_BUDGET_IMPORT;

END XXHA_GL_BUDGET_IMPORT_PKG;

/
