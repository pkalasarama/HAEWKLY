CREATE OR REPLACE PACKAGE
   XXHA_CSI_INSTALL_BASE_CONV_PK
-- +===================================================================+
-- |                       Oracle NAIO (India)                         |
-- |                        Bangalore, India                           |
-- +===================================================================+
-- | Name             : XXHA_CSI_INSTALL_BASE_CONV_PK                  |
-- | Description      : This is the package for validating the install |
-- |                    base records and importing the valid records   |
-- |                    from staging tables to Oracle CSI tables.      |
-- |                                                                   |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A  13-Nov-06   Rahul Raut       Initial  Draft Version      |
-- |DRAFT 1B  29-Nov-06   Rahul Raut       Internal Review             |
-- |1.0       01-Dec-06   Rahul Raut       After Review                |
-- |1.1       21-Dec-06   Rahul Raut       Added global variable       |
-- |                                       Attribute_Id and            |
-- |                                       Attribute_Code for extended |
-- |                                       Attributes                  |
-- |                                       Added IN parameter p_version|
-- |                                       In CALL_CREATE_ITEM_INSTANCE|
-- |                                       Procedure.                  |
-- |1.2      26-Mar-07   Subbu             Added global variable for  LAST_PM
-- |                                       and NEXT_PM
-- +===================================================================+

AS

-- Global Variables Declaration

gn_record_number         xxha_common_errors.record_number%TYPE;                                              --Variable to store Record_number of staging table
gc_record_identifier     xxha_common_errors.record_identifier%TYPE;                                          --Variable to store record identifier of staging table
gc_error_code            xxha_common_errors.error_code%TYPE;                                                 --Variable to store Error_code in common error table
gc_error_msg             xxha_common_errors.error_msg%TYPE;                                                  --Variable to store Error_msg in common error table
gc_comments              xxha_common_errors.comments%TYPE;                                                   --Variable to store Variable to store Comments in common error table
gc_attribute1            xxha_common_errors.attribute1%TYPE;                                                 --Variable to store Attribute1 insert in common error table
gc_attribute2            xxha_common_errors.attribute2%TYPE;                                                 --Variable to store Attribute2 insert in common error table
gc_attribute3            xxha_common_errors.attribute3%TYPE;                                                 --Variable to store Attribute3 insert in common error table
gc_attribute4            xxha_common_errors.attribute4%TYPE;                                                 --Variable to store Attribute4 insert in common error table
gc_attribute5            xxha_common_errors.attribute5%TYPE;                                                 --Variable to store Attribute5 insert in common error table
gc_table_name            xxha_common_errors.table_name%TYPE;                                                 --Variable to store Staging Table Name
gc_status                VARCHAR2(2);                                                                        --Variable to store status flag of data insertion in common error table
gc_conc_name             fnd_concurrent_programs.concurrent_program_name%TYPE :='XXHA_CSI_INSTALL_BASE_CONV';--Variable to store Concurrent program name to delete the records from common error table
gc_debug_flag            VARCHAR2(1);                                                                        --Variable to store Debug_flag for displaying debug
gc_log_msg               VARCHAR2(1000);                                                                     --Variable to store Log_msg to display msgs
gc_error_report          VARCHAR2(1)                                          := 'N';                        --Variable to store Error_report Status if its <>'N'
gn_request_id            xxha_common_errors.request_id%TYPE                   := FND_GLOBAL.CONC_REQUEST_ID; --Variable to store Request Id of running concurrent Program
gc_program_name          VARCHAR2(50)                                         :='Install Base Conversion';   --Variable to store Program Name In parameter for launch_error_prc procedure
gc_rec_identifier        VARCHAR2(50)                                         :='Item Number ';              --Variable to store Record identifier In parameter for launch_error_prc procedure
gc_mst_org               mtl_parameters.organization_code%TYPE                :='MST';                       --Variable to store Inventory Oranization Id
gc_instance_name         csi_instance_statuses.name%TYPE                      :='Installed';                 --Variable to store Instance Status Name
gc_trans_type            csi_txn_types.source_transaction_type%TYPE           :='IB_UI';                     --Variable to store Source Transaction Type
gc_instance_usage_code   csi_lookups.lookup_code%TYPE                         :='OUT_OF_ENTERPRISE';         --Variable to store Instance Usage Code
gc_inst_version_label    csi_lookups.lookup_code%TYPE                         :='AS_CREATED';                --Variable to store Instance Version labels
gc_inst_loct_source_code csi_lookups.lookup_code%TYPE                         :='HZ_PARTY_SITES';            --Variable to store Instance Location Source Code
gc_party_source_table    csi_lookups.lookup_code%TYPE                         :='HZ_PARTIES';                --Variable to store Instance Party Source Table
gc_acct_class_code       csi_lookups.lookup_code%TYPE                         :='CUST_PROD';                 --Variable to store Accounting Class Code
gc_appln_short_name      fnd_application.application_short_name%TYPE          :='CSI';                       --Variable to store Application Short Name
gn_quantity              csi_item_instances.quantity%TYPE                     := 1;                          --Variable to store Instance Quantity
gc_rel_type_code         VARCHAR2(5)                                          := 'OWNER';                    --Variable to store Relationship type code
gc_io_relt_type_code     csi_lookups.lookup_code%TYPE                         :='SOLD_FROM';                 --Variable to store Instance Organization relation type code
gc_hae_csi_inst_type     csi_lookups.lookup_type%TYPE                         :='HAE_CSI_INST_TYPE_CONV';    --Variable to store HAE_CSI_INST_TYPE_CONV lookup type
gn_organization_id       hr_operating_units.organization_id%TYPE              := FND_PROFILE.VALUE('ORG_ID');--Variable to store Organization Id
gc_operating_unit_name   hr_operating_units.name%TYPE;                                                       --Variable to store the Operating unit Name
gc_us_ou_name            hr_operating_units.name%TYPE                         :='Haemonetics Corp US OU';    --Variable to store the US Operating unit Name
gc_jp_ou_name            hr_operating_units.name%TYPE                         :='Haemonetics Japan K.K. JP OU';--Variable to store the Japan Operating unit Name
gn_mst_org_id            mtl_parameters.master_organization_id%TYPE;                                         --Variable to store Master Inventory Org Id
gn_instance_id           csi_instance_statuses.instance_status_id%TYPE;                                      --Variable to store Instance Status Id
gn_transaction_id        csi_txn_types.transaction_type_id%TYPE;                                             --Variable to store transaction type Id
gc_external_reference    csi_item_instances.external_reference%TYPE           :='Third Party Billing';       --Variable to store external reference value
gc_item_no               VARCHAR2(1000);

--Start of Changes 1.1
gn_extend_attrib_id      csi_i_extended_attribs.attribute_id%TYPE;                                           --Variable to store attribute_id value for extended attribute
gc_extend_attrib_code    csi_i_extended_attribs.attribute_code%TYPE           :='SOFT_VERSION';              --Variable to store attribute_code value for extended attribute

--End of Changes 1.1

--Start of Changes 1.2
gc_ext_att_lpm    csi_i_extended_attribs.attribute_code%TYPE           :='LAST_PM';              --Variable to store attribute_code value for extended attribute
gc_ext_att_npm    csi_i_extended_attribs.attribute_code%TYPE           :='NEXT_PM';              --Variable to store attribute_code value for extended attribute
gn_extend_lpm_att_id      csi_i_extended_attribs.attribute_id%TYPE; 					      --Variable to store attribute_id value for extended attribute
gn_extend_npm_att_id      csi_i_extended_attribs.attribute_id%TYPE; 					       --Variable to store attribute_id value for extended attribut
--End of Changes 1.2

---------------------------------------------------------
--Procedure to validate and process Install Base records
---------------------------------------------------------
PROCEDURE VALIDATE_INSTALL_BASE_DATA(
                                     errbuf        OUT VARCHAR2
                                    ,retcode       OUT VARCHAR2
                                    ,p_debug       IN  VARCHAR2
                                    ,p_purge_data  IN  VARCHAR2
                                    );

--------------------------------------------
--Procedure to Process Install Base records
--------------------------------------------
PROCEDURE PROCESS_INSTALL_BASE_DATA(
                                     p_debug         IN  VARCHAR2
                                    ,x_process_flag  OUT VARCHAR2
                                   );
--------------------------------------------
--Procedure to Create Item Instance records
--------------------------------------------
--Start of Changes 1.1
PROCEDURE CALL_CREATE_ITEM_INSTANCE(
                                     p_debug         IN  VARCHAR2
                                    ,p_serialnbr     IN  VARCHAR2
                                    ,p_inv_item_id   IN  NUMBER
                                    ,p_uom_code      IN  VARCHAR2
                                    ,p_location_id   IN  NUMBER
                                    ,p_party_id      IN  NUMBER
                                    ,p_party_act_id  IN  NUMBER
                                    ,p_bill_to_id    IN  NUMBER
                                    ,p_ship_to_id    IN  NUMBER
                                    ,p_instance_typ  IN  VARCHAR2
                                    ,p_install_date  IN  VARCHAR2
                                    ,p_source_date   IN  VARCHAR2
                                    ,p_external_ref  IN  VARCHAR2
                                    ,p_version       IN  VARCHAR2
                                     ,p_last_pm       IN  VARCHAR2
                                     ,p_next_pm       IN  VARCHAR2
                                    ,x_instance_id   OUT NUMBER
                                    ,x_inst_party_id OUT NUMBER
                                    ,x_ip_account_id OUT NUMBER
                                    ,x_process_flag  OUT VARCHAR2
                                   );
--End of Changes 1.1
-------------------------------------------
--Procedure to update Item Instance records
-------------------------------------------
PROCEDURE CALL_UPDATE_ITEM_INSTANCE(
                                     p_debug             IN  VARCHAR2
                                    ,p_instance_id       IN  NUMBER
                                    ,p_inst_party_id     IN  NUMBER
                                    ,p_ip_account_id     IN  NUMBER
                                    ,p_ownership_chg     IN  VARCHAR2
                                    ,p_item_id           IN  NUMBER
                                    ,p_serialnbr         IN  VARCHAR2
                                    ,p_location_id       IN  NUMBER
                                    ,p_party_id          IN  NUMBER
                                    ,p_party_act_id      IN  NUMBER
                                    ,p_bill_to_id        IN  NUMBER
                                    ,p_ship_to_id        IN  NUMBER
                                    ,p_instance_typ      IN  VARCHAR2
                                    ,p_transaction_date  IN  VARCHAR2
                                    ,x_process_flag      OUT VARCHAR2
                                   );
END XXHA_CSI_INSTALL_BASE_CONV_PK;

/


CREATE OR REPLACE PACKAGE BODY
   XXHA_CSI_INSTALL_BASE_CONV_PK
AS
-- +===================================================================+
-- | Name            : INSERT_ERROR_PRC                                |
-- | Description     : Procedure to call                               |
-- |                   xxha_common_utilities.insert_error_prc          |
-- |                   For inserting error records into                |
-- |                   common error table                              |
-- | Call From       :Called from Procedure VALIDATE_INSTALL_BASE_DATA |
-- | Parameters      :                                                 |
-- |   IN: None                                                        |
-- |  OUT: None                                                        |
-- |                                                                   |
-- |                                                                   |
-- | Returns :None                                                     |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE INSERT_ERROR_PRC
IS
BEGIN
   gc_error_report:='Y';
   xxha_common_utilities_pkg.insert_error_prc(
                                              gn_request_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                             );
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
END INSERT_ERROR_PRC;

-- +===================================================================+
-- | Name        :  UPDATE_HEADER_RECORD_STATUS                        |
-- | Description :  Procedure to update  the status of processed       |
-- |                records in INSTALLBASE_CLEANED table               |
-- | Call From   :  Called from Procedure PROCESS_INSTALL_BASE_DATA    |
-- | Parameters  :  p_record_id                                        |
-- |                p_status_flag                                      |
-- |                                                                   |
-- | Returns     :  None                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE UPDATE_HEADER_RECORD_STATUS(
                                      p_record_id     IN   NUMBER
                                     ,p_status_flag   IN   VARCHAR2
                                     )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  installbase_cleaned IC
   SET     IC.oragen1         =   p_status_flag
   WHERE   IC.record_id       =   p_record_id;

   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.UPDATE_HEADER_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_HEADER_RECORD_STATUS;


-- +===================================================================+
-- | Name        :  UPDATE_LINE_RECORD_STATUS                          |
-- | Description :  Procedure to update  the status of processed       |
-- |                records in INSTALLBASETXN_CLEANED table            |
-- | Call From   :  Called from Procedure PROCESS_INSTALL_BASE_DATA    |
-- | Parameters  :  p_record_id                                        |
-- |                p_status_flag                                      |
-- |                                                                   |
-- | Returns     :  None                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE UPDATE_LINE_RECORD_STATUS (
                                     p_record_id     IN   NUMBER
                                    ,p_status_flag   IN   VARCHAR2
                                    )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  installbasetxn_cleaned IBT
   SET     IBT.oragen1         =   p_status_flag
   WHERE   IBT.record_id       =   p_record_id;

   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.UPDATE_LINE_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_LINE_RECORD_STATUS;

-- +===================================================================+
-- | Name            : VALIDATE_LOOKUP_VALUE                           |
-- | Description     : Procedure to validate the Lookup Codes Passed   |
-- |                                                                   |
-- | Call From       :  Called from Procedure CHECK_INSTALL_BASE_SETUP |
-- |                                                                   |
-- | Parameters      :                                                 |
-- |   IN            : p_lookup_type                                   |
-- |                  ,p_lookup_code                                   |
-- |  OUT            : x_exists_flag                                   |
-- | Returns         :x_exists_flag                                    |
-- +===================================================================+
PROCEDURE VALIDATE_LOOKUP_VALUE(
                                p_lookup_type    IN VARCHAR2
                               ,p_lookup_code    IN VARCHAR2
                               ,x_exists_flag    OUT VARCHAR2
                               )
IS
BEGIN
   SELECT 'N'
   INTO    x_exists_flag
   FROM    csi_lookups CL
   WHERE   CL.lookup_type=p_lookup_type
   AND     UPPER(CL.lookup_code)  =  p_lookup_code
   AND     CL.enabled_flag        = 'Y'
   AND     TRUNC(SYSDATE) BETWEEN TRUNC(NVL(CL.start_date_active, SYSDATE - 1)) AND   TRUNC(NVL(CL.end_date_active, SYSDATE  + 1 ));
EXCEPTION
WHEN NO_DATA_FOUND THEN
   x_exists_flag := NULL;
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.VALIDATE_LOOKUP_VALUE '||SQLERRM);
END VALIDATE_LOOKUP_VALUE;


-- +===================================================================+
-- | Name            : GET_LAST_TRANS_VALUE                            |
-- | Description     : Procedure to get value of Last Company and      |
-- |                   Ownership Transaction                           |
-- |                                                                   |
-- | Call From       : Called from Procedure VALIDATE_INSTALL_BASE_DATA|
-- |                                                                   |
-- | Parameters      :                                                 |
-- |   IN            : p_itemnbr                                       |
-- |                  ,p_serialnbr                                     |
-- |                  ,p_columnchng                                    |
-- |  OUT            : x_trans_value                                   |
-- |                                                                   |
-- |                                                                   |
-- |                                                                   |
-- | Returns         :  x_trans_value                                  |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE GET_LAST_TRANS_VALUE(
                               p_itemid         IN NUMBER
                              ,p_serialnbr      IN VARCHAR2
                              ,p_columnchng     IN VARCHAR2
                              ,x_trans_value    OUT VARCHAR2
                              )
IS
BEGIN
   SELECT IBT1.newcolumnvalue
   INTO   x_trans_value
   FROM   installbasetxn_cleaned IBT1
   WHERE  IBT1.serialnbr         =p_serialnbr
   AND    IBT1.itemid            =p_itemid
   AND    IBT1.columnchanged     =p_columnchng
   AND    IBT1.changeddate=(
                             SELECT MAX(IBT2.changeddate)
                             FROM   installbasetxn_cleaned IBT2
                             WHERE  IBT2.serialnbr    =p_serialnbr
                             AND    IBT2.itemid       =p_itemid
                             AND    IBT2.columnchanged=p_columnchng
                           );
EXCEPTION
WHEN NO_DATA_FOUND THEN
   x_trans_value := NULL;
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.GET_LAST_TRANS_VALUE '||SQLERRM);
END GET_LAST_TRANS_VALUE;

-- +===================================================================+
-- | Name            : GET_INSTANCE_TYPE                               |
-- | Description     : Procedure to get valid Instance Type Code       |
-- |                   against provided Ownership Status               |
-- |                                                                   |
-- | Call From       : Called from Procedure VALIDATE_INSTALL_BASE_DATA|
-- |                                                                   |
-- | Parameters      :                                                 |
-- |   IN            : p_ownership                                     |
-- |  OUT            : x_error_flag                                    |
-- |                  ,x_instance_type                                 |
-- | Returns : x_instance_type,x_error_flag                            |
-- +===================================================================+
PROCEDURE GET_INSTANCE_TYPE (
                             p_ownership     IN  VARCHAR2
                            ,x_instance_type OUT VARCHAR2
                            ,x_error_flag    OUT VARCHAR2
                            )
IS
-----------------------------------------------------------
--Cursor to get Instance type Code for Legacy Instance Type
-----------------------------------------------------------
CURSOR lcu_get_instance_code(
                             p_lookup_code VARCHAR2
                            )
IS
SELECT  CL.attribute1
FROM    csi_lookups CL
WHERE   CL.lookup_type = gc_hae_csi_inst_type
AND     CL.lookup_code = p_lookup_code;

BEGIN
   x_error_flag :='N';  --Variable to get error flag

   OPEN  lcu_get_instance_code(p_ownership);
   FETCH lcu_get_instance_code INTO x_instance_type;
      IF (lcu_get_instance_code%NOTFOUND) THEN
         x_error_flag  :='Y';
      END IF;
   CLOSE lcu_get_instance_code;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.GET_INSTANCE_TYPE: ' || SQLERRM);
END GET_INSTANCE_TYPE;

-- +===================================================================+
-- | Name            : GET_CUST_ACCOUNT_INFO                           |
-- | Description     : Procedure to validate and derive the            |
-- |                   Customer Detials                                |
-- |                                                                   |
-- | Call From       : Called from Procedure VALIDATE_INSTALL_BASE_DATA|                                                                   |
-- |                                                                   |
-- | Parameters      :                                                 |
-- |   IN            : p_attribute1                                    |
-- |  OUT            : x_party_id                                      |
-- |                  ,x_party_site_id                                 |
-- |                  ,x_cust_acct_id                                  |
-- |                  ,x_err_flag                                      |
-- |                                                                   |
-- | Returns : x_party_id,x_party_site_id,x_cust_acct_id,x_err_flag    |
-- +===================================================================+
PROCEDURE GET_CUST_ACCOUNT_INFO (
                                 p_attribute1     IN  VARCHAR2
                                ,x_party_id       OUT NUMBER
                                ,x_party_site_id  OUT NUMBER
                                ,x_cust_acct_id   OUT NUMBER
                                ,x_err_flag       OUT VARCHAR2
                                )
IS
BEGIN
   x_err_flag :='N';    --Variable to get error flag

   SELECT HCA.cust_account_id
         ,HCA.party_id
         ,HCAS.party_site_id
   INTO   x_cust_acct_id
         ,x_party_id
         ,x_party_site_id
   FROM   hz_cust_acct_sites_all HCAS
         ,hz_cust_site_uses_all  HCSU
         ,hz_cust_accounts       HCA
   WHERE  HCAS.cust_acct_site_id = HCSU.cust_acct_site_id
   AND    HCAS.cust_account_id   = HCA.cust_account_id
   AND    HCSU.ORG_ID            = gn_organization_id        -- PR APR-26-2007
   AND    HCSU.attribute1        = p_attribute1
   AND    NVL(HCSU.STATUS,'A')   = 'A';                      -- PR JUL-17-2007(V 1.8)
EXCEPTION
WHEN NO_DATA_FOUND THEN
   x_err_flag    :='Y';
   gc_error_code :='IB-15';
   gc_error_msg  :='Customer Account Details Not found against field attribute1: '||p_attribute1||' for the Item: '||gc_item_no;
   gc_comments   :='Please check the Location Number';
   INSERT_ERROR_PRC;
WHEN TOO_MANY_ROWS THEN
   x_err_flag    :='Y';
   gc_error_code :='IB-16';
   gc_error_msg  :='Multiple Customer Account Details found against: '||p_attribute1||' for the Item: '||gc_item_no;
   gc_comments   :='Please check the Location Number';
   INSERT_ERROR_PRC;
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Customer Account Details: '||SQLERRM);
END GET_CUST_ACCOUNT_INFO;

-- +===================================================================+
-- | Name            : CHECK_INSTALL_BASE_SETUP                        |
-- | Description     : Procedure to validate all the setup required for|
-- |                   running Install Base Conversion                 |
-- |                                                                   |
-- | Call From       : Called from Procedure VALIDATE_INSTALL_BASE_DATA|
-- |                                                                   |
-- | Parameters      :                                                 |
-- |   IN            : None                                            |
-- |  OUT            : x_setup_err_flag                                |
-- |                                                                   |
-- |                                                                   |
-- | Returns         : x_setup_err_flag                                |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE CHECK_INSTALL_BASE_SETUP (
                                    x_setup_err_flag OUT VARCHAR2
                                   )
IS
------------------------------
-- Local Variables Declaration
------------------------------
lc_instance_code_flag      VARCHAR2(1);                           --Variable to store temporary value of the procedure VALIDATE_LOOKUP_VALUE
ln_mst_org                 NUMBER;                                --Variable to store Master Inventory Organization Id
ln_instance_id             NUMBER;                                --Variable to store Instance Status Id
ln_transaction_type_id     csi_txn_types.transaction_type_id%TYPE;--Variable to store Trsansaction Type Id
ln_num                     NUMBER:=0;                             --Variable to track whether Lookup has been defined in the system
lc_err_flag                VARCHAR2(1):='N';                      --Variable to store Error_flag for checking the setup
----------------------------------------------------------
-- Cursor To check set up of lookup HAE_CSI_INST_TYPE_CONV
----------------------------------------------------------
CURSOR lcu_chk_hae_lookup(
                          p_lookup_type VARCHAR2
                         )
IS
SELECT  DISTINCT (CL.attribute1)
FROM    csi_lookups CL
WHERE   CL.lookup_type=p_lookup_type
AND     CL.enabled_flag = 'Y'
AND     TRUNC(SYSDATE) BETWEEN TRUNC(NVL(CL.start_date_active, SYSDATE - 1))  AND   TRUNC(NVL(CL.end_date_active, SYSDATE  + 1 ));

--------------------------------------------------------
--Cursor to check if the Operating Unit has been defined
--------------------------------------------------------
CURSOR  lcu_chk_operating_unit(
                               p_operating_unit NUMBER
                              )
IS
SELECT  HOU.name
FROM    hr_operating_units HOU
WHERE   SYSDATE BETWEEN NVL(HOU.date_from,SYSDATE) AND NVL(HOU.date_to,SYSDATE+1)
AND     organization_id = p_operating_unit;

----------------------------------------------
--Cursor to check Master Inventory Org Set Up
----------------------------------------------
CURSOR lcu_get_mst_org (
                        p_org_code VARCHAR2
                       )
IS
SELECT MP.master_organization_id
FROM   mtl_parameters MP
WHERE  MP.organization_code=p_org_code;

--------------------------------------
--Cursor to check Instance Status Name
--------------------------------------
CURSOR lcu_get_instance_id (
                            p_instance_name VARCHAR2
                           )
IS
SELECT CIS.instance_status_id
FROM   csi_instance_statuses CIS
WHERE  UPPER(CIS.name)=UPPER(p_instance_name);

-----------------------------------------
--Cursor to check Source Transaction Type
-----------------------------------------
CURSOR lcu_get_transaction_id (
                               p_trans_type VARCHAR2
                              )
IS
SELECT CTT.transaction_type_id
FROM   csi_txn_types   CTT
      ,fnd_application FA
WHERE  CTT.source_application_id    = FA.application_id
AND    FA.application_short_name    = gc_appln_short_name
AND    CTT.source_transaction_type  = p_trans_type;

--Start of Changes 1.1
---------------------------------------------
--Cursor to check Extended Attribute Template
---------------------------------------------
CURSOR lcu_get_attribute_id (
                             p_attr_code VARCHAR2
                            )
IS
SELECT  CIEA.attribute_id
FROM    CSI_I_EXTENDED_ATTRIBS CIEA
WHERE   CIEA.attribute_code=p_attr_code
AND     TRUNC(SYSDATE) BETWEEN TRUNC(NVL(CIEA.active_start_date, SYSDATE - 1)) AND TRUNC(NVL(CIEA.active_end_date, SYSDATE  + 1 ));
--End of Changes 1.1

BEGIN
   -- Reinitialise the Variable
   x_setup_err_flag        := 'N';
   lc_instance_code_flag   :=  NULL;
   gc_table_name           := 'INSTALLBASE_CLEANED';
   lc_err_flag             := 'N';

   ------------------------------------
   --Check if Operating Unit is defined
   ------------------------------------
   OPEN  lcu_chk_operating_unit(gn_organization_id);
   FETCH lcu_chk_operating_unit INTO gc_operating_unit_name;
      IF (lcu_chk_operating_unit%NOTFOUND) THEN
         lc_err_flag   := 'Y';
         gc_error_code := 'SETUP-Error';
         gc_error_msg  := 'Unable to derive the Operating Unit Name for the Org Id: '||gn_organization_id;
         gc_comments   := 'Please define the Operating Unit';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_chk_operating_unit;
   gc_log_msg:='Flag returned by the Operating Unit Validation: '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ---------------------------------------------
   --Validate Lookup Type HAE_CSI_INST_TYPE_CONV
   ---------------------------------------------
   FOR lcr_chk_hae_lookup IN lcu_chk_hae_lookup(gc_hae_csi_inst_type)
   LOOP
      ln_num   :=ln_num+1;
      VALIDATE_LOOKUP_VALUE (
                              p_lookup_type    => 'CSI_INST_TYPE_CODE'
                             ,p_lookup_code    =>  lcr_chk_hae_lookup.attribute1
                             ,x_exists_flag    =>  lc_instance_code_flag
                            );
      IF (lc_instance_code_flag IS NULL) THEN
         lc_err_flag       := 'Y';
         gc_error_code     := 'SETUP-Error';
         gc_error_msg      := 'Instance Type Code: '||lcr_chk_hae_lookup.attribute1||' has not been set up in the Lookup Type CSI_INST_TYPE_CODE';
         INSERT_ERROR_PRC;
      END IF;
      gc_log_msg:='Flag returned by the validation of Instance Type Code: '||lcr_chk_hae_lookup.attribute1||' is '||lc_err_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   END LOOP;

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   IF (ln_num =0) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Lookup Type: '||gc_hae_csi_inst_type||' has not been set up in the system';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type '||gc_hae_csi_inst_type||' validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ------------------------------------
    --Get Inventory Organization Id
   ------------------------------------
   OPEN  lcu_get_mst_org(gc_mst_org);
   FETCH lcu_get_mst_org INTO gn_mst_org_id;
      IF (lcu_get_mst_org%NOTFOUND) THEN
         lc_err_flag         := 'Y';
         gc_error_code       := 'SETUP-Error';
         gc_error_msg        := 'Organization: '||gc_mst_org||' has not been set up as valid Master Inventory Organization';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_get_mst_org;
   gc_log_msg:='Flag returned by the Inventory Organization validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   -------------------------------
   --Validate Instance Status Name
   -------------------------------
   OPEN  lcu_get_instance_id(gc_instance_name);
   FETCH lcu_get_instance_id INTO gn_instance_id;
      IF (lcu_get_instance_id%NOTFOUND) THEN
         lc_err_flag         := 'Y';
         gc_error_code       := 'SETUP-Error';
         gc_error_msg        := 'Instance Status: '||gc_instance_name||' has not been set up';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_get_instance_id;
   gc_log_msg:='Flag returned by the Instance Status Name validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ----------------------------------
   --Validate Source Transaction Type
   ----------------------------------
   OPEN  lcu_get_transaction_id(gc_trans_type);
   FETCH lcu_get_transaction_id INTO gn_transaction_id;
      IF (lcu_get_transaction_id%NOTFOUND) THEN
         lc_err_flag         := 'Y';
         gc_error_code       := 'SETUP-Error';
         gc_error_msg        := 'Transaction Type: '||gc_trans_type ||' has not been set up in the system';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_get_transaction_id;
   gc_log_msg:='Flag returned by the Source Transaction Type validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ----------------------------------------------------------
   --Validate Lookup Type CSI_ACCOUNTING_CLASS_CODE:CUST_PROD
   ----------------------------------------------------------
   VALIDATE_LOOKUP_VALUE (
                           p_lookup_type    =>'CSI_ACCOUNTING_CLASS_CODE'
                          ,p_lookup_code    =>gc_acct_class_code
                          ,x_exists_flag    =>lc_instance_code_flag
                         );
   IF (lc_instance_code_flag IS NULL) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Accounting Class Code: '||gc_acct_class_code||' has not been set up in the Lookup Type CSI_ACCOUNTING_CLASS_CODE';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type CSI_ACCOUNTING_CLASS_CODE validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ----------------------------------------------
   --Validate Lookup Type CSI_INSTANCE_USAGE_CODE
   ----------------------------------------------
   VALIDATE_LOOKUP_VALUE (
                           p_lookup_type    =>'CSI_INSTANCE_USAGE_CODE'
                          ,p_lookup_code    =>gc_instance_usage_code
                          ,x_exists_flag    =>lc_instance_code_flag
                         );
   IF (lc_instance_code_flag IS NULL) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Instance Usage Code: '||gc_instance_usage_code||' has not been set up in the Lookup Type CSI_INSTANCE_USAGE_CODE';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type CSI_INSTANCE_USAGE_CODE validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ---------------------------------------------------
   --Validate Lookup Type CSI_INSTANCE_VERSION_LABELS
   ---------------------------------------------------
   VALIDATE_LOOKUP_VALUE (
                           p_lookup_type    =>'CSI_INSTANCE_VERSION_LABELS'
                          ,p_lookup_code    =>gc_inst_version_label
                          ,x_exists_flag    =>lc_instance_code_flag
                         );
   IF (lc_instance_code_flag IS NULL) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Instance Version Label: '||gc_inst_version_label||' has not been set up in the Lookup Type CSI_INSTANCE_VERSION_LABELS';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type CSI_INSTANCE_VERSION_LABELS validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ----------------------------------------------------
   --Validate Lookup Type CSI_INST_LOCATION_SOURCE_CODE
   ----------------------------------------------------
   VALIDATE_LOOKUP_VALUE (
                           p_lookup_type    =>'CSI_INST_LOCATION_SOURCE_CODE'
                          ,p_lookup_code    =>gc_inst_loct_source_code
                          ,x_exists_flag    =>lc_instance_code_flag
                         );
   IF (lc_instance_code_flag IS NULL) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Instance Location Source Code: '||gc_inst_loct_source_code||' has not been set up in the Lookup Type CSI_INST_LOCATION_SOURCE_CODE';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type CSI_INST_LOCATION_SOURCE_CODE validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   ---------------------------------------------
   --Validate Lookup Type CSI_PARTY_SOURCE_TABLE
   ---------------------------------------------
   VALIDATE_LOOKUP_VALUE (
                           p_lookup_type    =>'CSI_PARTY_SOURCE_TABLE'
                          ,p_lookup_code    =>gc_party_source_table
                          ,x_exists_flag    =>lc_instance_code_flag
                         );
   IF (lc_instance_code_flag IS NULL) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Instance Party Source Table: '||gc_party_source_table||' has not been set up in the Lookup Type CSI_PARTY_SOURCE_TABLE';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type CSI_PARTY_SOURCE_TABLE validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   -----------------------------------------------------
   --Validate Lookup Type CSI_IO_RELATIONSHIP_TYPE_CODE
   -----------------------------------------------------
   VALIDATE_LOOKUP_VALUE (
                           p_lookup_type    =>'CSI_IO_RELATIONSHIP_TYPE_CODE'
                          ,p_lookup_code    =>gc_io_relt_type_code
                          ,x_exists_flag    =>lc_instance_code_flag
                         );
   IF (lc_instance_code_flag IS NULL) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Instance IO Relationship Type Code: '||gc_io_relt_type_code||' has not been set up in the Lookup Type CSI_IO_RELATIONSHIP_TYPE_CODE';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type CSI_IO_RELATIONSHIP_TYPE_CODE validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;

   --Start of Changes 1.1
   -----------------------------------------------------
   --Validate Lookup Type CSI_EXTEND_ATTRIB_POOL (SOFT_VERSION)
   -----------------------------------------------------
   VALIDATE_LOOKUP_VALUE (
                           p_lookup_type    =>'CSI_EXTEND_ATTRIB_POOL'
                          ,p_lookup_code    =>gc_extend_attrib_code
                          ,x_exists_flag    =>lc_instance_code_flag
                         );
   IF (lc_instance_code_flag IS NULL) THEN
      lc_err_flag       := 'Y';
      gc_error_code     := 'SETUP-Error';
      gc_error_msg      := 'Installed Base Extended Attribute Pool Code: '||gc_extend_attrib_code||' has not been set up in the Lookup Type CSI_EXTEND_ATTRIB_POOL';
      INSERT_ERROR_PRC;
   END IF;
   gc_log_msg:='Flag returned by the Lookup Type CSI_EXTEND_ATTRIB_POOL validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;


   ---------------------------------------
   --Get Attribute id of  SOFT_VERSION
   --------------------------------------
   OPEN  lcu_get_attribute_id(gc_extend_attrib_code);
   FETCH lcu_get_attribute_id INTO gn_extend_attrib_id;
      IF (lcu_get_attribute_id%NOTFOUND) THEN
         lc_err_flag         := 'Y';
         gc_error_code       := 'SETUP-Error';
         gc_error_msg        := 'Installed Base Extended Attribute: '||gc_extend_attrib_code ||' has not been set up in the Extended Attribute Template';
         INSERT_ERROR_PRC;
      END IF;
   CLOSE lcu_get_attribute_id;
   gc_log_msg:='Flag returned by the Extended Attribute Template validation '||lc_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF (lc_err_flag ='Y') THEN
      x_setup_err_flag:='Y';
      lc_err_flag:='N';
   END IF;
   --End of Changes 1.1

   --Start of Changes V1.6
   -----------------------------------------------------
   --Validate Lookup Type CSI_EXTEND_ATTRIB_POOL (LAST_PM)
    -----------------------------------------------------
    VALIDATE_LOOKUP_VALUE (
                            p_lookup_type    =>'CSI_EXTEND_ATTRIB_POOL'
                           ,p_lookup_code    =>gc_ext_att_lpm
                           ,x_exists_flag    =>lc_instance_code_flag
                          );
    IF (lc_instance_code_flag IS NULL) THEN
       lc_err_flag       := 'Y';
       gc_error_code     := 'SETUP-Error';
       gc_error_msg      := 'Installed Base Extended Attribute Pool Code: '||gc_ext_att_lpm||' has not been set up in the Lookup Type CSI_EXTEND_ATTRIB_POOL';
       INSERT_ERROR_PRC;
    END IF;
    gc_log_msg:='Flag returned by the Lookup Type CSI_EXTEND_ATTRIB_POOL validation '||lc_err_flag;
    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

    IF (lc_err_flag ='Y') THEN
       x_setup_err_flag:='Y';
       lc_err_flag:='N';
    END IF;


    -----------------------------------------------------
    --Validate Lookup Type CSI_EXTEND_ATTRIB_POOL (NEXT_PM)
     -----------------------------------------------------
     VALIDATE_LOOKUP_VALUE (
                             p_lookup_type    =>'CSI_EXTEND_ATTRIB_POOL'
                            ,p_lookup_code    =>gc_ext_att_npm
                            ,x_exists_flag    =>lc_instance_code_flag
                           );
     IF (lc_instance_code_flag IS NULL) THEN
        lc_err_flag       := 'Y';
        gc_error_code     := 'SETUP-Error';
        gc_error_msg      := 'Installed Base Extended Attribute Pool Code: '||gc_ext_att_npm||' has not been set up in the Lookup Type CSI_EXTEND_ATTRIB_POOL';
        INSERT_ERROR_PRC;
     END IF;
     gc_log_msg:='Flag returned by the Lookup Type CSI_EXTEND_ATTRIB_POOL validation '||lc_err_flag;
     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

     IF (lc_err_flag ='Y') THEN
        x_setup_err_flag:='Y';
        lc_err_flag:='N';
     END IF;


    ---------------------------------------
    --Get  Attribute id of LAST_PM
    --------------------------------------
    OPEN  lcu_get_attribute_id(gc_ext_att_lpm);
    FETCH lcu_get_attribute_id INTO gn_extend_lpm_att_id ;
       IF (lcu_get_attribute_id%NOTFOUND) THEN
          lc_err_flag         := 'Y';
          gc_error_code       := 'SETUP-Error';
          gc_error_msg        := 'Installed Base Extended Attribute: '||gc_extend_attrib_code ||' has not been set up in the Extended Attribute Template';
          INSERT_ERROR_PRC;
       END IF;
    CLOSE lcu_get_attribute_id;
    gc_log_msg:='Flag returned by the Extended Attribute Template validation '||lc_err_flag;
    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

    IF (lc_err_flag ='Y') THEN
       x_setup_err_flag:='Y';
       lc_err_flag:='N';
    END IF;


    ---------------------------------------
    --Get  Attribute id of NEXT_PM
    --------------------------------------
    OPEN  lcu_get_attribute_id(gc_ext_att_npm);
    FETCH lcu_get_attribute_id INTO gn_extend_npm_att_id;
       IF (lcu_get_attribute_id%NOTFOUND) THEN
          lc_err_flag         := 'Y';
          gc_error_code       := 'SETUP-Error';
          gc_error_msg        := 'Installed Base Extended Attribute: '||gc_extend_attrib_code ||' has not been set up in the Extended Attribute Template';
          INSERT_ERROR_PRC;
       END IF;
    CLOSE lcu_get_attribute_id;
    gc_log_msg:='Flag returned by the Extended Attribute Template validation '||lc_err_flag;
    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

    IF (lc_err_flag ='Y') THEN
       x_setup_err_flag:='Y';
       lc_err_flag:='N';
    END IF;
     --End of Changes V1.6
EXCEPTION
WHEN OTHERS THEN
  -- FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.CHECK_INSTALL_BASE_SETUP: ' ||SQLERRM);
   RAISE;
END CHECK_INSTALL_BASE_SETUP;


 -- +===================================================================+
 -- | Name            : VALIDATE_INSTALL_BASE_DATA                      |
 -- | Description     : Procedure to validate and process Installed Base|
 -- |                   Records From Staging tables To Oracle CSI Tables|
 -- |                                                                   |
 -- |                                                                   |
 -- | Call From       : Main Procedure registered Executable file  in   |
 -- |                   Application                                     |
 -- | Parameters      :                                                 |
 -- |   IN            :  p_debug                                        |
 -- |                   ,p_purge_data                                   |
 -- |  OUT            :  errbuf                                         |
 -- |                   ,retcode                                        |
 -- | Returns : errbuf,retcode                                          |
 -- +===================================================================+
PROCEDURE VALIDATE_INSTALL_BASE_DATA  (
                                       errbuf       OUT VARCHAR2
                                      ,retcode      OUT VARCHAR2
                                      ,p_debug      IN  VARCHAR2
                                      ,p_purge_data IN  VARCHAR2
                                      )
IS
-- Local Variable Declaration
lc_err_flag              VARCHAR2(1):='N';                                   --Variable to get error flag value for installbase_cleaned table
lc_txn_err_flag          VARCHAR2(1):='N';                                   --Variable to get error flag value for installbasetxn_cleaned table
lc_setup_err_flag        VARCHAR2(1):='N';                                   --Variable to take Setup procedure Out parameter
lc_temp_flag             VARCHAR2(1);                                        --Variable for temporary storage of value
lc_item_miss_flag        VARCHAR2(1):='N';                                   --Variable to get Item existence flag in staging table.
lc_loct_exist            VARCHAR2(1):='N';                                   --Variable to check Valid location nbr in System
lc_parent_exist          VARCHAR2(1):='N';                                   --Variable to check Valid parent nbr in System
lc_txn_loct_exist        VARCHAR2(1):='N';                                   --Variable to check Valid location nbr for company transaction in System
lc_txn_parent_exist      VARCHAR2(1):='N';                                   --Variable to check Valid location nbr for company transaction in System
lc_txn_oldloct_exist     VARCHAR2(1):='N';                                   --Variable to check valid location value for first  company transaction
lc_call_api_flag         VARCHAR2(1):='Y';                                   --Variable to check status of Data Validation
lc_process_flag          VARCHAR2(1):='N';                                   --Variable to check status of Data Process procedure
lc_inst_err_flag         VARCHAR2(1):='N';                                   --Variable to check staus of getting valid Instance type code
lc_cust_err_flag         VARCHAR2(1):='N';                                   --Variable to check staus of getting valid Customer Account Details
ln_installbase_fetch     NUMBER:=0;                                          --Variable to fetch records from INSTALLBASE_CLEANED table
ln_ibasetxn_fetch        NUMBER:=0;                                          --Variable to fetch records from INSTALLBASE_CLEANED table
ln_ibasetxn_reject_recs  NUMBER:=0;                                          --Variable to get rejected records
ln_ibase_reject_recs     NUMBER:=0;                                          --Variable to get rejected records
ln_ibasetxn_valid_recs   NUMBER:=0;                                          --Variable to get valid records for transaction table
ln_ibase_valid_recs      NUMBER:=0;                                          --Variable to get valid records for geadet table
ln_num_own               NUMBER:=0;                                          --Variable to check count of Ownership Transaction
ln_num                   NUMBER:=0;                                          --Variable to get number value
lc_comp_value            installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to get first location nbt value against company_id
lc_own_value             installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to get first Instance status value against ownership_stat_id
lc_new_comp              installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to get new columnvalue for company transaction
lc_new_own               installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to get new columnvalue for ownership transaction
lc_old_comp              installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to get old columnvalue for company transaction
lc_old_own               installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to get old columnvalue for ownership transaction
lc_store_comp            installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to store new columnvalue for company transaction
lc_store_own             installbasetxn_cleaned.newcolumnvalue%TYPE;         --Variable to store new columnvalue for ownership transaction
lc_primary_uom           mtl_system_items_b.primary_uom_code%TYPE;           --Variable to get primary UOM Code
lc_inst_type_code        csi_lookups.lookup_code%TYPE;                       --Variable to get Instance type code against ownershipstatus
lc_new_inst_type_code    csi_lookups.lookup_code%TYPE;                       --Variable to store Instance type code for new company transaction
lc_old_inst_type_code    csi_lookups.lookup_code%TYPE;                       --Variable to store Instance type code for old company transaction
ln_cust_acct_id          hz_cust_accounts.cust_account_id%TYPE;              --Variable to get customer Account Id
ln_party_id              hz_cust_accounts.party_id%TYPE;                     --Variable to get party id
ln_party_site_id         hz_cust_acct_sites_all.party_site_id%TYPE;          --Variable to get party site id
ln_bill_add              hz_cust_site_uses_all.site_use_id%TYPE;             --Variable to get Bill to address id
ln_ship_add              hz_cust_site_uses_all.site_use_id%TYPE;             --Variable to get Ship to address id
ln_inv_item_id           mtl_system_items_b.inventory_item_id%TYPE;          --Variable to get inventory Item Id
ln_txn_cust_acct_id      hz_cust_accounts.cust_account_id%TYPE;              --Variable to get cust_acct_id for company transaction
ln_txn_party_id          hz_cust_accounts.party_id%TYPE;                     --Variable to get party_id for company transaction
ln_txn_party_site_id     hz_cust_acct_sites_all.party_site_id%TYPE;          --Variable to get party_site_id for company transaction
ln_txn_bill_add          hz_cust_site_uses_all.site_use_id%TYPE;             --Variable to get Bill_ro_address_id for company transaction
ln_txn_ship_add          hz_cust_site_uses_all.site_use_id%TYPE;             --Variable to get Ship_ro_address_id for company transaction
ln_oldtxn_cust_acct_id   hz_cust_accounts.cust_account_id%TYPE;              --Variable to get cust_acct_id for first company transaction
ln_oldtxn_party_id       hz_cust_accounts.party_id%TYPE;                     --Variable to get party_id for first company transaction
ln_oldtxn_party_site_id  hz_cust_acct_sites_all.party_site_id%TYPE;          --Variable to get party_site_id for first company transaction
ln_oldtxn_bill_add       hz_cust_site_uses_all.site_use_id%TYPE;             --Variable to get Bill_ro_address_id for first company transaction
ln_oldtxn_ship_add       hz_cust_site_uses_all.site_use_id%TYPE;             --Variable to get Ship_ro_address_id for first company transaction
ln_mst_org               mtl_parameters.organization_id%TYPE;                --Variable to get Master Inventory Organization Id
lc_org_name              hr_operating_units.name%TYPE;                       --Variable to store Operating Unit name
ln_ibasetxn_orphan_recs  NUMBER:=0;                                          --Variable to get Number of Orphan Records from INSTALLBASETXN_CLEANED table
-----------------------------------------------------------------------------------
--Cursor to fetch all New Items records from staging table installbase_cleaned
-----------------------------------------------------------------------------------
CURSOR lcu_installbase
IS
SELECT *
FROM   installbase_cleaned IC
WHERE  IC.oragen1 IS NULL
--AND    DECODE(IC.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
AND    IC.sourcesys =gc_operating_unit_name ;

------------------------------------------------------------------------------------------------
--Cursor to fetch all New  Inventory Org records  from staging table installbasetxn_cleaned
------------------------------------------------------------------------------------------------
CURSOR lcu_installbasetxn (
                           p_item_id    NUMBER
                          ,p_serial_nbr VARCHAR2
                          )
IS
SELECT   *
FROM     installbasetxn_cleaned IBT
WHERE    IBT.itemid     = p_item_id
AND      IBT.serialnbr  = p_serial_nbr
AND      IBT.oragen1 IS NULL
--AND      DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name
AND    IBT.sourcesys =gc_operating_unit_name
ORDER BY IBT.changeddate;

----------------------------------------------------------------------
--Cursor to check existence of Item Number and Serial Number in Oracle
----------------------------------------------------------------------
CURSOR lcu_val_item_serial_exist(
                                 p_serial_nbr VARCHAR2
                                ,p_item_id    NUMBER
                                )
IS
SELECT 'N'
FROM    mtl_serial_numbers MSN
WHERE   MSN.serial_number     = p_serial_nbr
AND     MSN.inventory_item_id = p_item_id;

-------------------------------------------------------------------
--Cursor to check Serial Number duplication against the Item Number
--in staging table installbase_cleaned
-------------------------------------------------------------------
CURSOR lcu_val_dupl_serialnbr(
                               p_serial_nbr VARCHAR2
                              ,p_itemn_nbr  VARCHAR2
                             )
IS
SELECT 'N'
FROM    installbase_cleaned IC
WHERE   IC.serialnbr = p_serial_nbr
AND     IC.itemnbr   = p_itemn_nbr
AND     IC.oragen1 IS NOT NULL;

----------------------------------------------------------------------
--Cursor to validate Location Number For existence In Oracle AR tables
----------------------------------------------------------------------
CURSOR lcu_val_locationnbr(
                           p_locationnbr VARCHAR2
                          )
IS
SELECT HCSU.site_use_id
FROM   hz_cust_site_uses_all HCSU
WHERE  HCSU.attribute1     =p_locationnbr
AND    HCSU.site_use_code  ='SHIP_TO'
AND    HCSU.ORG_ID = gn_organization_id;        -- added pr 26-apr-07

--Start of Changes V1.3
----------------------------------------------------------------------
--Cursor to validate Location Number For existence In Oracle AR tables
----------------------------------------------------------------------
CURSOR lcu_val_locationnbr_bill(
                           p_locationnbr VARCHAR2
                          )
IS
SELECT HCSU.site_use_id
FROM   hz_cust_site_uses_all HCSU
WHERE  HCSU.attribute1     =p_locationnbr
AND    HCSU.site_use_code  ='BILL_TO'
AND    HCSU.ORG_ID = gn_organization_id;        -- added pr 26-apr-07

--End  of Changes V1.3

--------------------------------------------------------------------
--Cursor to validate Parent Number For existence In Oracle AR tables
--------------------------------------------------------------------
CURSOR lcu_val_parentnbr(
                         p_parentnbr VARCHAR2
                        )
IS
SELECT HCSU.site_use_id
FROM   hz_cust_site_uses_all HCSU
WHERE  HCSU.attribute1     = p_parentnbr
AND    HCSU.site_use_code  ='BILL_TO'
AND    HCSU.ORG_ID = gn_organization_id;        -- added pr 26-apr-07


----------------------------------------------------------------------
--Cursor to get bill_to_site_use_id against the Location Number
--provided in INSTALLBASETXN_CLEANED table
----------------------------------------------------------------------
CURSOR lcu_get_bill_id (
                        p_site_use_id NUMBER
                       )
IS
SELECT HCSU.bill_to_site_use_id
FROM   hz_cust_site_uses_all HCSU
WHERE  HCSU.site_use_id    = p_site_use_id
AND    HCSU.site_use_code  ='SHIP_TO'
AND    HCSU.ORG_ID = gn_organization_id;        -- added pr 26-apr-07


--Start of changes 1.1
-----------------------------------------------------------
--Cursor to get orphan records from INSTALLBASETXN_CLEANED
------------------------------------------------------------
CURSOR lcu_get_orphan
IS
SELECT *
FROM  installbasetxn_cleaned IBT
--WHERE DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name
WHERE    IBT.sourcesys =gc_operating_unit_name
AND   IBT.oragen1 IS NULL;

------------------------------------------------------------------------------------
--Cursor to check records from INSTALLBASETXN_CLEANED against INSTALLBASETXN_CLEANED
------------------------------------------------------------------------------------
CURSOR lcu_chk_header  (
                        p_serialnbr varchar2
                       ,p_itemid NUMBER
                       )
IS
SELECT DISTINCT('N')
FROM  installbase_cleaned IC
WHERE IC.serialnbr   =p_serialnbr
AND   IC.itemid      =p_itemid
--AND   DECODE(IC.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name;
AND    IC.sourcesys =gc_operating_unit_name ;

--End of changes 1.1

BEGIN
   gn_request_id               := fnd_global.conc_request_id;              -- Request Id of validating data
   gc_debug_flag               := p_debug;                                 -- Debug Flag
   gc_log_msg                  :='Start of VALIDATE_INSTALL_BASE_DATA...'; -- Indicator to show start of Validation Procedure
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   -------------------------------------------------------------------------
   -- Purge Data From Common Error table
   -- If value equals to 'Y' then delete all records from common error table
   -------------------------------------------------------------------------
   IF (p_purge_data = 'Y') THEN
      xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>gc_conc_name);
   END IF;

   ---------------------------
   -- Calling setup procedure
   ---------------------------
   CHECK_INSTALL_BASE_SETUP(x_setup_err_flag=>lc_setup_err_flag);

   --IF any setup are missing then error out the concurrent program else
   --start validating the Install Base records

   IF (lc_setup_err_flag <>'Y') THEN   -- start validating records

      --**************************************************************************
      -- Opening the cursor to fetch records from "installbase_cleaned" table
      --**************************************************************************
      FOR lr_installbase_rec IN lcu_installbase
      LOOP
         gc_record_identifier :=  NVL(lr_installbase_rec.itemnbr,'NULL')||' Serial Number '||NVL( lr_installbase_rec.serialnbr,'NULL')||' Item ID '||NVL( lr_installbase_rec.itemid,0);
         gn_record_number     :=  lr_installbase_rec.record_id;
         ln_installbase_fetch :=  ln_installbase_fetch + 1 ;
         gc_log_msg           := 'INSTALLBASE_CLEANED-'||gc_record_identifier;
         gc_table_name        := 'INSTALLBASE_CLEANED';
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         gc_item_no           := lr_installbase_rec.locationnbr;

         -- Reinitialise the Variables
         lc_err_flag          := 'N';
         lc_item_miss_flag    := 'N';
         ln_cust_acct_id      :=  NULL;
         ln_party_id          :=  NULL;
         ln_party_site_id     :=  NULL;
         ln_bill_add          :=  NULL;
         ln_ship_add          :=  NULL;
         ln_inv_item_id       :=  NULL;
         lc_primary_uom       :=  NULL;
         lc_comp_value        :=  NULL;
         lc_own_value         :=  NULL;
         lc_loct_exist        := 'N';
         lc_inst_type_code    :=  NULL;
         lc_inst_err_flag     :=  NULL;
         lc_cust_err_flag     :=  NULL;
         lc_temp_flag         :=  NULL;
         gc_error_code        :=  NULL;
         gc_error_msg         :=  NULL;
         gc_comments          :=  NULL;

         -------------------------------------
         -- Validation of Item Number for Null
         -------------------------------------
         IF (lr_installbase_rec.itemnbr IS NULL) THEN
            lc_err_flag         :='Y';
            gc_error_code       :='IB-01';
            gc_error_msg        :='Item Number has not been provided';
            gc_comments         :='Please provide the Item Number';
            INSERT_ERROR_PRC ;
         ELSE
            -------------------------------------------------------------
            --Validation of Item Number for existence in Oracle Inventory
            -------------------------------------------------------------
            BEGIN
               SELECT  MIB.inventory_item_id
                      ,MIB.primary_uom_code
               INTO    ln_inv_item_id
                      ,lc_primary_uom
               FROM    mtl_system_items_b MIB
               WHERE   MIB.segment1           =  lr_installbase_rec.itemnbr
               AND     MIB.organization_id    =  gn_mst_org_id
               AND     MIB.enabled_flag       = 'Y'
               AND     MIB.comms_nl_trackable_flag = 'Y'
               AND     TRUNC(SYSDATE)BETWEEN TRUNC(NVL(MIB.start_date_active, SYSDATE - 1))
               AND     TRUNC(NVL(MIB.end_date_active, SYSDATE  + 1  ));
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
               lc_item_miss_flag    :='Y';
               lc_err_flag          :='Y';
               gc_error_code        :='IB-02';
               gc_error_msg         :='Item Number: '||lr_installbase_rec.itemnbr||' has not been defined or has been defined with the Install Base Flag unchecked';
               gc_comments          :='Please check the Item Definition';
               INSERT_ERROR_PRC;
            WHEN OTHERS THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Inventory Item ID And Primary UOM Code: '||SQLERRM);
            END;
         END IF;
         gc_log_msg:='Flag returned by the validation of Item Number for existence in Oracle Inventory '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------------------------------
         -- Validation of Serial Number for Null
         ---------------------------------------
         IF (lr_installbase_rec.serialnbr IS NULL) THEN
            lc_err_flag          :='Y';
            gc_error_code        :='IB-03';
            gc_error_msg         :='Serial Number has not been provided for the Item Number: '||lr_installbase_rec.itemnbr;
            gc_comments          :='Please provide the Serial Number';
            INSERT_ERROR_PRC ;
         END IF ;
         gc_log_msg:='Flag returned by the Serial Number validation for null '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ----------------------------------
         -- Validation of Item Id  for Null
         ----------------------------------
         IF (lr_installbase_rec.itemid IS NULL) THEN
            lc_err_flag          :='Y';
            gc_error_code        :='IB-04';
            gc_error_msg         :='Field Item ID(itemid) is holding NULL in the staging table for the Item Number: '||lr_installbase_rec.itemnbr;
            gc_comments          :='Please provide the Item ID';
            INSERT_ERROR_PRC ;
         END IF ;
         gc_log_msg:='Flag returned by the Item Id validation for null '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------------------------------------------------
           -- Validation of Location Number for Null
         ---------------------------------------------------------
         IF (lr_installbase_rec.locationnbr IS NULL) THEN
            lc_err_flag          :='Y';
            lc_loct_exist        :='Y';
            gc_error_code        :='IB-05';
            gc_error_msg         :='Location Number has not been provided for the Item Number: '||lr_installbase_rec.itemnbr;
            gc_comments          :='Please provide the Location Number';
            INSERT_ERROR_PRC ;
         ELSE
         -------------------------------------------------------------
           -- Validation of Location Number for existence in AR Tables
         -------------------------------------------------------------

		 IF lr_installbase_rec.external_reference  ='ST' THEN
		    OPEN  lcu_val_locationnbr (lr_installbase_rec.locationnbr);
		    FETCH lcu_val_locationnbr INTO ln_ship_add;
		       IF (lcu_val_locationnbr%NOTFOUND) THEN
			  lc_err_flag   :='Y';
			  lc_loct_exist :='Y';
			  gc_error_code :='IB-06';
			  gc_error_msg  :='Customer Details cannot be derived for the given Location Number: '||lr_installbase_rec.locationnbr||' for the Item: '||lr_installbase_rec.itemnbr;
			  gc_comments   :='Attribute1 of the expected Customers address Ship to Site use should have the given Location Number';
			  INSERT_ERROR_PRC;
		       END IF;
		    CLOSE lcu_val_locationnbr;

		 ELSIF lr_installbase_rec.external_reference  ='BT' THEN

		    OPEN  lcu_val_locationnbr_bill (lr_installbase_rec.locationnbr);
		    FETCH lcu_val_locationnbr_bill INTO ln_bill_add;
		       IF (lcu_val_locationnbr_bill%NOTFOUND) THEN
		      lc_err_flag   :='Y';
		      lc_loct_exist :='Y';
		      gc_error_code :='IB-06';
		      gc_error_msg  :='Customer Details cannot be derived for the given Location Number: '||lr_installbase_rec.locationnbr||' for the Item: '||lr_installbase_rec.itemnbr;
		      gc_comments   :='Attribute1 of the expected Customers address Ship to Site use should have the given Location Number';
		      INSERT_ERROR_PRC;
		       END IF;
		    CLOSE lcu_val_locationnbr_bill;
		 END IF;
         END IF;
         gc_log_msg:='Flag returned by the Location Number validation for valid value '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -----------------------------------------------------------
           -- Validation of Parent Number for existence in AR Tables
         -----------------------------------------------------------
         IF (lr_installbase_rec.parentnbr IS NOT NULL) THEN
            OPEN  lcu_val_parentnbr (lr_installbase_rec.parentnbr);
            FETCH lcu_val_parentnbr INTO ln_bill_add;
               IF (lcu_val_parentnbr%NOTFOUND) THEN
                  lc_err_flag    :='Y';
                  gc_error_code  :='IB-07';
                  gc_error_msg   :='Customer Details cannot be derived for the given Parent Number: '||lr_installbase_rec.parentnbr||' for the Item: '||lr_installbase_rec.itemnbr;
                  gc_comments    :='Attribute1 of the expected Customers address Bill to Site use should have the given Parent Number';
                  INSERT_ERROR_PRC;
               END IF;
            CLOSE lcu_val_parentnbr;
         END IF;
         gc_log_msg:='Flag returned by the Parent Number validation for valid value '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          -----------------------------------------------------------
           --Validation to check Serial Number And Item Id Duplication
         -----------------------------------------------------------
         IF (lc_item_miss_flag <>'Y') THEN
            OPEN  lcu_val_item_serial_exist(lr_installbase_rec.serialnbr,ln_inv_item_id);
            FETCH lcu_val_item_serial_exist INTO lc_temp_flag;
               IF (lcu_val_item_serial_exist%FOUND) THEN
                  lc_err_flag    :='Y';
                  gc_error_code  :='IB-08';
                  gc_error_msg   :='The Serial Number: '||lr_installbase_rec.serialnbr||' and Item Number: '||lr_installbase_rec.itemnbr||' combination already exists in Oracle';
                  gc_comments    :='Please provide unique Serial Number against the given Item Number';
                  INSERT_ERROR_PRC;
               END IF;
            CLOSE lcu_val_item_serial_exist;
         END IF;
         gc_log_msg:='Flag returned by the Serial Number And Item Id Duplication '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          -----------------------------------------------------------------------
           --Validation to check Unique Serial Number In installbase_cleaned Table
          -------------------------------------------------------------------------
         IF (lr_installbase_rec.serialnbr IS NOT NULL) THEN
            OPEN lcu_val_dupl_serialnbr(lr_installbase_rec.serialnbr,lr_installbase_rec.itemnbr);
            FETCH lcu_val_dupl_serialnbr INTO lc_temp_flag;
               IF (lcu_val_dupl_serialnbr%FOUND) THEN
                  lc_err_flag    :='Y';
                  gc_error_code  :='IB-09';
                  gc_error_msg   :='Serial Number: '||lr_installbase_rec.serialnbr||' has been duplicated for the given Item Number: '||lr_installbase_rec.itemnbr||' in the staging table';
                  gc_comments    :='Please provide unique Serial Number against the given Item Number';
                  INSERT_ERROR_PRC;
               END IF;
            CLOSE lcu_val_dupl_serialnbr;
         END IF;
         gc_log_msg:='Flag returned by the Serial Number Duplication in installbase_cleaned Table '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

          ---------------------------------------------------------
            -- Derivation Of Customer Account
          ---------------------------------------------------------
         IF (lc_loct_exist <>'Y') THEN

            GET_CUST_ACCOUNT_INFO( p_attribute1   =>lr_installbase_rec.locationnbr
                                  ,x_party_id     =>ln_party_id
                                  ,x_party_site_id=>ln_party_site_id
                                  ,x_cust_acct_id =>ln_cust_acct_id
                                  ,x_err_flag     =>lc_cust_err_flag
                                  ) ;
         END IF;
         gc_log_msg:='Flag returned by the Customer Account Derivation '||lc_cust_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------------------------------------------------
         -- Derive Instance Type Code for valid Ownershipstatus
         ---------------------------------------------------------
         IF (lr_installbase_rec.ownershipstatus IS NOT NULL) THEN
            GET_INSTANCE_TYPE(
                              p_ownership    =>lr_installbase_rec.ownershipstatus
                             ,x_instance_type=>lc_inst_type_code
                             ,x_error_flag   =>lc_inst_err_flag
                             );
            IF (lc_inst_err_flag ='Y') THEN
               lc_err_flag   :='Y';
               gc_error_code :='IB-10';
               gc_error_msg  :='Invalid Ownership Status value: '||lr_installbase_rec.ownershipstatus||' for the Item: '||lr_installbase_rec.itemnbr;
               gc_comments   :='Please provide a value that has been defined in the Lookup HAE_CSI_INST_TYPE_CONV';
               INSERT_ERROR_PRC;
            END IF;
         END IF;
         gc_log_msg:='Flag returned by the Derivation of Instance Type Code against valid Ownershipstatus In installbase_cleaned Table '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -----------------------------------------------------------------------------------
         --Get the Last Company id Transaction Value (NEWCOLUMNVALUE) from installbasetxn_cleaned table
         --This value has to be matched with locationnbr value in installbase_cleaned table
         ------------------------------------------------------------------------------------
         GET_LAST_TRANS_VALUE(
                               p_itemid         =>lr_installbase_rec.itemid
                              ,p_serialnbr      =>lr_installbase_rec.serialnbr
                              ,p_columnchng     =>'company_id'
                              ,x_trans_value    =>lc_comp_value
                             );

         ---------------------------------------------------------------------------------
         --Validate Last Company Transaction Details against current status of Install Base Item
         ----------------------------------------------------------------------------------
         IF (lr_installbase_rec.locationnbr IS NOT NULL) THEN
            IF (NVL(lc_comp_value,lr_installbase_rec.locationnbr) <>lr_installbase_rec.locationnbr) THEN
               lc_err_flag   :='Y';
               gc_error_code :='IB-11';
               --gc_error_msg  :='The value in the NEWCOLUMNVALUE: COMPANY_ID of the last transaction of type Company ID in the INSTALLBASETXN_CLEANED table does not match the value in LOACATIONNBR: '||lr_installbase_rec.locationnbr||' of the parent record for the Item: '||lr_installbase_rec.itemnbr;
               gc_error_msg  :='The value in the NEWCOLUMNVALUE: COMPANY_ID of the last transaction in the INSTALLBASETXN_CLEANED table does not match the value in LOACATIONNBR: '||lr_installbase_rec.locationnbr||' of the parent record for the Item: '||lr_installbase_rec.itemnbr;
               gc_comments   :='Please check the records in INSTALLBASETXN_CLEANED and INSTALLBASE_CLEANED tables';
               INSERT_ERROR_PRC;
            END IF;
         END IF;
         gc_log_msg:='Flag returned by the Validation of Last Company Transaction Details against current Company status of Install Base Item '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -----------------------------------------------------------------------------------
         --Get the Last Ownershipstatus(NEWCOLUMNVALUE) value from installbasetxn_cleaned table
         --This value has to be matched with Ownershipstatus value in installbase_cleaned table
         ------------------------------------------------------------------------------------
         GET_LAST_TRANS_VALUE(
                               p_itemid         =>lr_installbase_rec.itemid
                              ,p_serialnbr      =>lr_installbase_rec.serialnbr
                              ,p_columnchng     =>'ownership_stat_id'
                              ,x_trans_value    =>lc_own_value
                              );
         ------------------------------------------------------------------------------------------
         --Validate Last Ownership Transaction Details against current status of Install Base Item
         ------------------------------------------------------------------------------------------

         IF (lr_installbase_rec.ownershipstatus IS NOT NULL) THEN
            IF (NVL(lc_own_value,lr_installbase_rec.ownershipstatus) <>lr_installbase_rec.ownershipstatus ) THEN
               lc_err_flag   :='Y';
               gc_error_code :='IB-12';
               --gc_error_msg  :='The value in the NEWCOLUMNVALUE: OWNERSHIP_STAT_ID of the last transaction of type Ownership Stat ID in the INSTALLBASETXN_CLEANED table does not match the value in OWNERSHIPSTATUS: '||lr_installbase_rec.ownershipstatus||' of the parent record for the Item: '||lr_installbase_rec.itemnbr;
               gc_error_msg  :='The value in the NEWCOLUMNVALUE: OWNERSHIP_STAT_ID of the last transaction in the INSTALLBASETXN_CLEANED table does not match the value in OWNERSHIPSTATUS: '||lr_installbase_rec.ownershipstatus||' of the parent record for the Item: '||lr_installbase_rec.itemnbr;

               gc_comments   :='Please check the records in INSTALLBASETXN_CLEANED and INSTALLBASE_CLEANED tables';
               INSERT_ERROR_PRC;
            END IF;
         END IF;
         gc_log_msg:='Flag returned by the Validation of Last Ownership Transaction Details against current Ownership status of Install Base Item '||lc_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


         -- Reinitialisation of the variables before they were used in Transaction Loop
         ln_num         :=  0;
         ln_num_own     :=  0;
         lc_old_comp    :=  NULL;
         lc_new_comp    :=  NULL;
         lc_store_comp  :=  NULL;
         lc_old_own     :=  NULL;
         lc_new_own     :=  NULL;
         lc_store_own   :=  NULL;

            --*********************************************************************************************************
            -- Opening the cursor to fetch Install Base Transaction records from "installbasetxn_cleaned" table
            --*********************************************************************************************************
            FOR lr_installbasetxn_rec IN lcu_installbasetxn(
                                                            lr_installbase_rec.itemid
                                                           ,lr_installbase_rec.serialnbr
                                                           )
            LOOP
               gn_record_number        := lr_installbasetxn_rec.record_id;
               ln_ibasetxn_fetch       := ln_ibasetxn_fetch + 1 ;
               gc_log_msg              :='INSTALLBASETXN_CLEANED-'||gc_record_identifier;
               gc_table_name           :='INSTALLBASETXN_CLEANED';
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               -- Reinitialisation Of variables
               lc_txn_err_flag         := 'N';
               lc_new_comp             :=  NULL;
               lc_new_own              :=  NULL;
               lc_txn_loct_exist       := 'N';
               lc_txn_parent_exist     := 'N';
               ln_txn_cust_acct_id     :=  NULL;
               ln_txn_party_id         :=  NULL;
               ln_txn_party_site_id    :=  NULL;
               ln_txn_bill_add         :=  NULL;
               ln_txn_ship_add         :=  NULL;
               ln_oldtxn_cust_acct_id  :=  NULL;
               ln_oldtxn_party_id      :=  NULL;
               ln_oldtxn_party_site_id :=  NULL;
               ln_oldtxn_bill_add      :=  NULL;
               ln_oldtxn_ship_add      :=  NULL;
               lc_txn_oldloct_exist    := 'N';
               lc_old_inst_type_code   :=  NULL;
               lc_inst_err_flag        := 'N';
               lc_cust_err_flag        :=  NULL;
               lc_new_inst_type_code   :=  NULL;
               gc_error_code           :=  NULL;
               gc_error_msg            :=  NULL;
               gc_comments             :=  NULL;

               ---------------------------------------------------------
               --Validation of column Column_Changed for Not Null
               ---------------------------------------------------------
               IF (lr_installbasetxn_rec.columnchanged IS NULL) THEN
                  lc_txn_err_flag     :='Y';
                  gc_error_code       :='IBL-21';
                  gc_error_msg        :='ColumnChanged has not been provided';
                  gc_comments         :='Please provide the ColumnChanged';
                  INSERT_ERROR_PRC ;
               ELSE
                  IF (lr_installbasetxn_rec.columnchanged NOT IN ('ownership_stat_id','company_id')) THEN
                     lc_txn_err_flag     :='Y';
                     gc_error_code       :='IBL-22';
                     gc_error_msg        :='Value for field COLUMNCHANGED: '||lr_installbasetxn_rec.columnchanged||' is invalid '||' for Itemid: '||lr_installbasetxn_rec.itemid||' and for the serial number: '||lr_installbasetxn_rec.serialnbr||' of the Item: '||gc_item_no;
                     gc_comments         :='Please provide the valid value for ColumnChanged';
                     INSERT_ERROR_PRC ;
                  END IF;
               END IF ;
               gc_log_msg:='Flag returned by the ColumnChanged Validation for Valid Value '||lc_txn_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                ---------------------------------------------------------
                 -- Validation of column ChangedDate for Not Null
                ---------------------------------------------------------
               IF (lr_installbasetxn_rec.changeddate IS NULL) THEN
                  lc_txn_err_flag     :='Y';
                  gc_error_code       :='IBL-23';
                  --gc_error_msg        :='ChangedDate has not been provided';
                  gc_error_msg        :='Field CHANGEDDATE is NULL in the staging table for Itemid: '||lr_installbasetxn_rec.itemid||' and for the serial number: '||lr_installbasetxn_rec.serialnbr||' of the Item: '||gc_item_no;
                  gc_comments         :='Please provide the ChangedDate';
                  INSERT_ERROR_PRC ;
               END IF ;
               gc_log_msg:='Flag returned by the ChangedDate Validation for Not Null '||lc_txn_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ---------------------------------------------------------
                 --Validation of column NewColumnValue for Not Null
               ---------------------------------------------------------
               IF (lr_installbasetxn_rec.newcolumnvalue IS NULL) THEN
                  lc_txn_err_flag     :='Y';
                  gc_error_code       :='IBL-24';
                  gc_error_msg        :='Field NEWCOLUMNVALUE is NULL for Itemid: '||lr_installbasetxn_rec.itemid||' and for the serial number: '||lr_installbasetxn_rec.serialnbr||' of the Item: '||gc_item_no;
                  gc_comments         :='Please provide the NewColumnValue';
                  INSERT_ERROR_PRC ;
               END IF ;
               gc_log_msg:='Flag returned by the NewColumnValue Validation for Not Null '||lc_txn_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                 ---------------------------------------------------------
                   --Validation of column OldColumnValue for Not Null
                 ---------------------------------------------------------
               IF (lr_installbasetxn_rec.oldcolumnvalue IS NULL) THEN
                  lc_txn_err_flag     :='Y';
                  gc_error_code       :='IBL-25';
                  gc_error_msg        :='Field OLDCOLUMNVALUE is NULL for for Itemid: '||lr_installbasetxn_rec.itemid||' and for the serial number: '||lr_installbasetxn_rec.serialnbr||' of the Item: '||gc_item_no;
                  gc_comments         :='Please provide the OldColumnValue';
                  INSERT_ERROR_PRC ;
               END IF ;
               gc_log_msg:='Flag returned by the OldColumnValue Validation for Not Null '||lc_txn_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               -------------------------------------------------------------------------
               --Validation to check the Oldcolumnvalue of current Company transactions has to be
               --matched to Newcolumnvalue of last company transaction
               --------------------------------------------------------------------------
               IF (lr_installbasetxn_rec.columnchanged='company_id') THEN
                  ln_num      :=ln_num+1;
                  lc_old_comp :=lr_installbasetxn_rec.oldcolumnvalue;
                  lc_new_comp :=lr_installbasetxn_rec.newcolumnvalue;

                  -- Perform the Validation except the first Company transaction
                  IF (ln_num <> 1) THEN
                     IF (lc_old_comp <> lc_store_comp) THEN
                        lc_txn_err_flag     :='Y';
                        gc_error_code       :='IBL-26';
                        gc_error_msg        :='The OLDCOLUMNVALUE: '||lr_installbasetxn_rec.oldcolumnvalue||' of the current Company Transaction does not match with NEWCOULMNVALUE: '||lr_installbasetxn_rec.newcolumnvalue||' of the previous Company Transaction for the Item: '||gc_item_no;
                        gc_comments         :='Please check the transactions in the INSTALLBASETXN_CLEANED table';
                        INSERT_ERROR_PRC ;
                     END IF;
                  END IF;--ln_num <> 1

                  lc_store_comp :=lc_new_comp;

               ----------------------------------------------------------------------------------
               --Validation to check the Oldcolumnvalue of current ownership transactions has to be
               --matched to Newcolumnvalue of last ownership transaction
               ----------------------------------------------------------------------------------
               ELSIF (lr_installbasetxn_rec.columnchanged='ownership_stat_id') THEN
                  ln_num_own  :=ln_num_own+1;
                  lc_old_own  :=lr_installbasetxn_rec.oldcolumnvalue;
                  lc_new_own  :=lr_installbasetxn_rec.newcolumnvalue;

                   -- Perform the Validation except the first Ownership transaction
                  IF (ln_num_own <> 1) THEN
                     IF (lc_old_own <> lc_store_own) THEN
                        lc_txn_err_flag     :='Y';
                        gc_error_code       :='IBL-27';
                        gc_error_msg        :='The OLDCOLUMNVALUE: '||lr_installbasetxn_rec.oldcolumnvalue||' of the current Ownership Transaction does not match with NEWCOULMNVALUE:  '||lr_installbasetxn_rec.newcolumnvalue||' of the previous Ownership Transaction for the Item: '||gc_item_no;
                        gc_comments         :='Please check the transactions in the INSTALLBASETXN_CLEANED table';
                        INSERT_ERROR_PRC ;
                     END IF;
                   END IF;
                   lc_store_own  :=lc_new_own;
               END IF;--lr_installbasetxn_rec.columnchanged='company_id'

               gc_log_msg:='Flag returned by the validation of Newcolumnvalue and oldcolumnvalue for same value '||lc_txn_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ------------------------------------------------------------------------------
               --Get Instance type details for the first Ownership transaction(Oldcolumnvalue)
               ------------------------------------------------------------------------------
               IF (ln_num_own=1) AND (lr_installbasetxn_rec.columnchanged='ownership_stat_id') THEN
                  -- Calling GET_INSTANCE_TYPE procedure to get Instance Type Details for Oldcolumnvalue
                  GET_INSTANCE_TYPE(
                                    p_ownership    =>lr_installbasetxn_rec.oldcolumnvalue
                                   ,x_instance_type=>lc_old_inst_type_code
                                   ,x_error_flag   =>lc_inst_err_flag
                                   );

                  IF (lc_inst_err_flag ='Y') THEN
                     lc_txn_err_flag   :='Y';
                     gc_error_code     :='IBL-28';
                     gc_error_msg      :='Invalid value provided for Ownership Status in OLDCOLUMNVALUE: '||lr_installbasetxn_rec.oldcolumnvalue||' for Ownership transaction for the Item: '||gc_item_no;
                     gc_comments       :='Please provide a value that has been defined in the Lookup HAE_CSI_INST_TYPE_CONV';
                     INSERT_ERROR_PRC;
                  END IF;
                  ------------------------------------------------------------------------------
                  --Get Instance type details for the second Ownership transaction(Newcolumnvalue)
                  --For the same record
                  ------------------------------------------------------------------------------
                  -- Calling GET_INSTANCE_TYPE procedure to get Instance Type Details for Newcolumnvalue
                  GET_INSTANCE_TYPE(
                                    p_ownership    =>lr_installbasetxn_rec.newcolumnvalue
                                   ,x_instance_type=>lc_new_inst_type_code
                                   ,x_error_flag   =>lc_inst_err_flag
                                   );
                  IF (lc_inst_err_flag ='Y') THEN
                     lc_txn_err_flag   :='Y';
                     gc_error_code     :='IBL-29';
                     gc_error_msg      :='Invalid value provided for Ownership Status in NEWCOLUMNVALUE: '||lr_installbasetxn_rec.newcolumnvalue||' for Ownership transaction for the Item: '||gc_item_no;
                     gc_comments       :='Please provide a value that has been defined in the Lookup HAE_CSI_INST_TYPE_CONV';
                     INSERT_ERROR_PRC;
                  END IF;
               ELSIF ((ln_num_own > 1)  AND (lr_installbasetxn_rec.columnchanged='ownership_stat_id')) THEN
                  ------------------------------------------------------------------------------
                  --Get Instance type details for the other Ownership transaction(Newcolumnvalue)
                  ------------------------------------------------------------------------------
                  -- Calling GET_INSTANCE_TYPE procedure to get Instance Type Details for Newcolumnvalue
                  GET_INSTANCE_TYPE(
                                    p_ownership    =>lr_installbasetxn_rec.newcolumnvalue
                                   ,x_instance_type=>lc_new_inst_type_code
                                   ,x_error_flag   =>lc_inst_err_flag
                                   );

                  IF (lc_inst_err_flag ='Y') THEN
                     lc_txn_err_flag   :='Y';
                     gc_error_code     :='IBL-30';
                     gc_error_msg      :='Invalid value provided for Ownership Status in NEWCOLUMNVALUE: '||lr_installbasetxn_rec.newcolumnvalue||' for Ownership transaction for the Item: '||gc_item_no;
                     gc_comments       :='Please provide a value that has been defined in the Lookup HAE_CSI_INST_TYPE_CONV';
                     INSERT_ERROR_PRC;
                  END IF;
               END IF;
               gc_log_msg:='Flag returned by the validation of Instance Type Code for Newcolumnvalue and oldcolumnvalue of Ownership transactions '||lc_txn_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               -----------------------------------------------------------------------------
               --Validation of Oldcolumnvalue(LocationNbr) of first company transaction
               --for existence in Oracle AR Tables
               ------------------------------------------------------------------------------
               IF (lr_installbasetxn_rec.columnchanged='company_id') THEN
                  IF (lr_installbasetxn_rec.oldcolumnvalue IS NOT NULL) AND (ln_num = 1) THEN
                     OPEN  lcu_val_locationnbr (lr_installbasetxn_rec.oldcolumnvalue);
                     FETCH lcu_val_locationnbr INTO ln_oldtxn_ship_add;
                        IF (lcu_val_locationnbr%NOTFOUND) THEN
                           lc_txn_err_flag      :='Y';
                           lc_txn_oldloct_exist :='Y';
                           gc_error_code        :='IBL-31';
                           gc_error_msg         :='Customer details can not be derived for the given value in OLDCOLUMNVALUE: '||lr_installbasetxn_rec.oldcolumnvalue||' of the Company transaction for the Item: '||gc_item_no;
                           gc_comments          :='Attribute1 of the expected Customers address Ship to Site use should have the given Location Number';
                           INSERT_ERROR_PRC;
                        ELSE
                           ----------------------------------------------------------
                           -- get customer account details for the company transaction
                           ----------------------------------------------------------
                           GET_CUST_ACCOUNT_INFO( p_attribute1   =>lr_installbasetxn_rec.oldcolumnvalue
                                                 ,x_party_id     =>ln_oldtxn_party_id
                                                 ,x_party_site_id=>ln_oldtxn_party_site_id
                                                 ,x_cust_acct_id =>ln_oldtxn_cust_acct_id
                                                 ,x_err_flag     =>lc_cust_err_flag
                                               ) ;
                        END IF;
                     CLOSE lcu_val_locationnbr;
                  END IF;
               END IF;
               gc_log_msg:='Flag returned by the validation of  oldcolumnvalue for company transactions '||lc_cust_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               -----------------------------------------------------------------------------
               --Validation of Newcolumnvalue(LocationNbr) of succeeding company transaction
               --for existence in Oracle AR Tables
               ------------------------------------------------------------------------------

               IF (lr_installbasetxn_rec.columnchanged='company_id' AND lr_installbasetxn_rec.newcolumnvalue IS NOT NULL) THEN
                     OPEN  lcu_val_locationnbr (lr_installbasetxn_rec.newcolumnvalue);
                     FETCH lcu_val_locationnbr INTO ln_txn_ship_add;
                        IF (lcu_val_locationnbr%NOTFOUND) THEN
                           lc_txn_err_flag      :='Y';
                           lc_txn_loct_exist    :='Y';
                           gc_error_code        :='IBL-32';
                           gc_error_msg         :='Customer details can not be derived for the given value in NEWCOLUMNVALUE: '||lr_installbasetxn_rec.newcolumnvalue||' of the Company transaction for the Item: '||gc_item_no;
                           gc_comments          :='Attribute1 of the expected Customers address Ship to Site use should have the given Location Number';
                           INSERT_ERROR_PRC;
                        ELSE
                           ----------------------------------------------------------
                           -- get customer account details for the company transaction
                           ----------------------------------------------------------
                           GET_CUST_ACCOUNT_INFO( p_attribute1   =>lr_installbasetxn_rec.newcolumnvalue
                                                 ,x_party_id     =>ln_txn_party_id
                                                 ,x_party_site_id=>ln_txn_party_site_id
                                                 ,x_cust_acct_id =>ln_txn_cust_acct_id
                                                 ,x_err_flag     =>lc_cust_err_flag
                                                ) ;
                        END IF;
                     CLOSE lcu_val_locationnbr;
               END IF;
               gc_log_msg:='Flag returned by the validation of Newcolumnvalue  for company transactions '||lc_cust_err_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               ---------------------------------------------------
               -- Get Bill To address for first company transaction
               ----------------------------------------------------
               IF ((lc_txn_oldloct_exist <>'Y') AND (lr_installbasetxn_rec.columnchanged='company_id') AND (ln_num = 1)) THEN
                  OPEN  lcu_get_bill_id (ln_oldtxn_ship_add);
                  FETCH lcu_get_bill_id INTO ln_oldtxn_bill_add;
                     IF (lcu_get_bill_id%NOTFOUND) THEN
                        ln_oldtxn_bill_add :=NULL;
                     END IF;
                  CLOSE lcu_get_bill_id;
               END IF;

               ---------------------------------------------------
               -- Get Bill To address for succeeding company transaction
               ----------------------------------------------------

               IF ((lc_txn_loct_exist <>'Y') AND (lr_installbasetxn_rec.columnchanged='company_id')) THEN
                  OPEN  lcu_get_bill_id (ln_txn_ship_add);
                  FETCH lcu_get_bill_id INTO ln_txn_bill_add;
                     IF (lcu_get_bill_id%NOTFOUND) THEN
                        ln_txn_bill_add :=NULL;
                     END IF;
                  CLOSE lcu_get_bill_id;
               END IF;

               ----------------------
               -- Status Flag Update
               ----------------------

               IF (lc_txn_err_flag = 'Y') THEN
                  UPDATE installbasetxn_cleaned IBT
                  SET    IBT.oragen1   = 'VE'
                        ,IBT.oragen12  = gn_request_id
                  WHERE  IBT.record_id = lr_installbasetxn_rec.record_id;
               ELSE
                  UPDATE installbasetxn_cleaned IBT
                  SET    IBT.oragen1   = 'VS'
                        ,IBT.oragen2   = ln_oldtxn_cust_acct_id
                        ,IBT.oragen3   = ln_oldtxn_party_id
                        ,IBT.oragen4   = ln_oldtxn_party_site_id
                        ,IBT.oragen5   = ln_oldtxn_bill_add
                        ,IBT.oragen6   = ln_oldtxn_ship_add
                        ,IBT.oragen7   = ln_txn_cust_acct_id
                        ,IBT.oragen8   = ln_txn_party_id
                        ,IBT.oragen9   = ln_txn_party_site_id
                        ,IBT.oragen10  = ln_txn_bill_add
                        ,IBT.oragen11  = ln_txn_ship_add
                        ,IBT.oragen12  = gn_request_id
                        ,IBT.oragen13  = lc_old_inst_type_code
                        ,IBT.oragen14  = lc_new_inst_type_code
                  WHERE  IBT.record_id = lr_installbasetxn_rec.record_id;
               END IF;
            END LOOP; -- End loop for installbasetxn_cleaned table

         -----------------------
         -- Status Flag Update
         -----------------------
         IF (lc_err_flag = 'Y') THEN
            UPDATE installbase_cleaned IC
            SET    IC.oragen1  = 'VE'
                  ,IC.oragen12 = gn_request_id
            WHERE  record_id   = lr_installbase_rec.record_id;
         ELSE
            UPDATE installbase_cleaned IC
            SET    IC.oragen1    = 'VS'
                  ,IC.oragen2    = lc_primary_uom
                  ,IC.oragen3    = ln_inv_item_id
                  ,IC.oragen4    = lc_inst_type_code
                  ,IC.oragen7    = ln_cust_acct_id
                  ,IC.oragen8    = ln_party_id
                  ,IC.oragen9    = ln_party_site_id
                  ,IC.oragen10   = ln_bill_add
                  ,IC.oragen11   = ln_ship_add
                  ,IC.oragen12   = gn_request_id
            WHERE  IC.record_id  = lr_installbase_rec.record_id;
         END IF;
      END LOOP; -- End loop for validation of installbase_cleaned table
      COMMIT;   --Commit for all updations

      --Start of changes 1.1
      ------------------------------------------------
      --Loop to print the orphan records
      --into Out put file of the concurrent program
      -------------------------------------------------

      FOR lcr_get_orphan_rec IN lcu_get_orphan
      LOOP
         lc_temp_flag   := NULL;

         OPEN lcu_chk_header(lcr_get_orphan_rec.serialnbr,lcr_get_orphan_rec.itemid);
         FETCH lcu_chk_header INTO lc_temp_flag;
            IF lcu_chk_header%NOTFOUND THEN
               FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Record Id: '||lcr_get_orphan_rec.record_id||' Item Id: '||lcr_get_orphan_rec.itemid||' Serial Number: '||lcr_get_orphan_rec.serialnbr||' Columnchanged: '||lcr_get_orphan_rec.columnchanged||' Changeddate: '||TO_CHAR(lcr_get_orphan_rec.changeddate,'DD/MM/RRRR HH:MI:SS AM'));
             END IF;
         CLOSE lcu_chk_header;
      END LOOP;
      --End of changes 1.1


      ------------------------------------------------------
      --Count the number of records get failed in validation
      ------------------------------------------------------
      BEGIN
         SELECT COUNT (*)
         INTO   ln_ibase_reject_recs
         FROM   installbase_cleaned IC
         WHERE  IC.oragen1='VE'
         --AND    DECODE(IC.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
         AND    IC.sourcesys =gc_operating_unit_name ;

         SELECT COUNT (*)
         INTO   ln_ibasetxn_reject_recs
         FROM   installbasetxn_cleaned IBT
         WHERE  IBT.oragen1='VE'
         --AND    DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
         AND    IBT.sourcesys =gc_operating_unit_name ;

         SELECT COUNT (*)
         INTO   ln_ibase_valid_recs
         FROM   installbase_cleaned IC
         WHERE  IC.oragen1='VS'
         --AND    DECODE(IC.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
         AND    IC.sourcesys =gc_operating_unit_name ;

         SELECT COUNT (*)
         INTO   ln_ibasetxn_valid_recs
         FROM   installbasetxn_cleaned IBT
         WHERE  IBT.oragen1='VS'
         --AND    DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
         AND    IBT.sourcesys =gc_operating_unit_name ;

         --Start of changes 1.1
         SELECT COUNT (*)
         INTO   ln_ibasetxn_orphan_recs
         FROM   installbasetxn_cleaned IBT
         WHERE  IBT.oragen1 IS NULL
         --AND    DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
         AND    IBT.sourcesys =gc_operating_unit_name ;
         --End of changes 1.1
      EXCEPTION
      WHEN OTHERS THEN
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Error Statistics for Validation Process: '||SQLERRM);
      END;

      ----------------------------------------
      -- Summary Of Data Validation Process
      ----------------------------------------

      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of INSTALLBASE_CLEANED Records Validated ');
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                             :  ' ||ln_installbase_fetch );
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation                     :  ' ||ln_ibase_valid_recs);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored out                           :  ' ||ln_ibase_reject_recs);
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of INSTALLBASETXN_CLEANED Records Validated ');
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Validated                             :  ' ||ln_ibasetxn_fetch);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Passed Validation                     :  ' ||ln_ibasetxn_valid_recs);
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Errored out                           :  ' ||ln_ibasetxn_reject_recs);
      --Start of changes 1.1
      IF ln_ibasetxn_orphan_recs > 0 THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Orphan Records Found(Refer Output File)       :  ' ||ln_ibasetxn_orphan_recs);
      END IF;
      --End of changes 1.1
      FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));

      ----------------------------------------------------------------------------------
      -- If any single record failed in validation then complete the program with warning
      -- and stop further processing of records .
      -----------------------------------------------------------------------------------
      IF ((ln_ibase_reject_recs > 0) OR (ln_ibasetxn_reject_recs >0))  THEN
         retcode := 1;           -- complete the request with warning
         lc_call_api_flag := 'N';
         xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
      END IF;

      --------------------------------------------------------------------------
      -- If all records validate successfully
      -- then process the records through procedure PROCESS_INSTALL_BASE_DATA
      ---------------------------------------------------------------------------
      IF (lc_call_api_flag = 'Y') THEN
         --************************************************************************
         --Calling Data Process Procedure to Process records into Oracle CSI tables
         --*************************************************************************

         PROCESS_INSTALL_BASE_DATA(p_debug =>p_debug,x_process_flag=>lc_process_flag);
         -----------------------------------------------------------------------------------------------
         -- If any single record failed to processed to Base table then complete the program with warning
         -----------------------------------------------------------------------------------------------
         IF (lc_process_flag = 'N') THEN
            retcode := 1; -- complete the request with warning
         END IF;
      END IF;
      ---------------------------------------------------------------------
      -- If set up is not done then errored out the program
      -- and stop further processing of records and launch the error report.
      ----------------------------------------------------------------------
   ELSE
      retcode :=2;
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
   END IF ; -- End of Setup procedure
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.VALIDATE_ITEM_DATA: ' || SQLERRM);
END VALIDATE_INSTALL_BASE_DATA;

-- +===================================================================+
-- | Name            : PROCESS_INSTALL_BASE_DATA                       |
-- | Description     : Procedure to process validated Install Base     |
-- |                   Records From Staging tables                     |
-- |                   To Oracle CSI Tables                            |
-- |                                                                   |
-- | Call From       : Called from Procedure VALIDATE_INSTALL_BASE_DATA|
-- | Parameters      :                                                 |
-- |   IN            : p_debug                                         |
-- |  OUT            : x_process_flag                                  |
-- |                                                                   |
-- | Returns         : x_process_flag                                  |
-- +===================================================================+
PROCEDURE PROCESS_INSTALL_BASE_DATA(
                                    p_debug         IN VARCHAR2
                                   ,x_process_flag  OUT VARCHAR2
                                   )
AS
----------------------------------------------------------
-- Cursor to fetch Install Base records having status 'VS'
-- from staging tables installbase_cleaned
----------------------------------------------------------

CURSOR lcu_installbase
IS
SELECT   *
FROM     installbase_cleaned  IC
WHERE    IC.oragen1='VS'
--AND      DECODE(IC.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
AND    IC.sourcesys =gc_operating_unit_name ;

----------------------------------------------------------------------
-- Cursor to fetch Install Base Transaction records having status 'VS'
-- from staging tables installbasetxn_cleaned
----------------------------------------------------------------------
CURSOR lcu_installbasetxn (
                           p_item_id     NUMBER
                          ,p_serial_nbr  VARCHAR2
                          )
IS
SELECT   *
FROM     installbasetxn_cleaned IBT
WHERE    IBT.itemid   = p_item_id
AND      IBT.serialnbr= p_serial_nbr
AND      IBT.oragen1  ='VS'
--AND      DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name
AND    IBT.sourcesys =gc_operating_unit_name
ORDER BY IBT.changeddate;

-------------------------------------------------------------------------------------------------
-- Cursor to check existence of Transaction Records for the serial number and item Id Combination
-- in staging tables installbasetxn_cleaned
-------------------------------------------------------------------------------------------------
CURSOR lcu_chk_txn_data(
                        p_item_id    NUMBER
                       ,p_serial_nbr VARCHAR2
                       )
IS
SELECT   DISTINCT('N')
FROM     installbasetxn_cleaned IBT
WHERE    IBT.serialnbr= p_serial_nbr
AND      IBT.itemid   = p_item_id
AND      IBT.ORAGEN1  ='VS'
--AND      DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
AND    IBT.sourcesys =gc_operating_unit_name ;


   -- Local Variable Declaration
lc_err_flag                 VARCHAR2(1):='N';                              --Variable to get error flag
lc_txn_err_flag             VARCHAR2(1):='N';                              --Variable to get error flag for Transaction Records
lc_update_process_flag      VARCHAR2(2);                                   --Variable to get status of Transaction update procedure
lc_first_own_value          installbasetxn_cleaned.newcolumnvalue%TYPE;    --Variable to get first Ownership status value
lc_temp_flag                VARCHAR2(1);                                   --Variable to store temporary value
lc_txn_exists               VARCHAR2(1);                                   --Variable to check transaction records in INSTALLBASETXN_CLEANED table
lc_process_flag             VARCHAR2(1);                                   --Variable to get Return status flag by the Api
lc_create_process_flag      VARCHAR2(1);                                   --Variable to get status of Create Item Instance Api
ln_instance_num             NUMBER:=0;                                     --Variable to get Instance Number
ln_inst_party_id            NUMBER:=0;                                     --Variable to get Instance Party Number
ln_ip_acct_id               NUMBER:=0;                                     --Variable to get Ip Account id
ln_party_act_id             hz_cust_accounts.cust_account_id%TYPE;         --Variable to get cust_acct_id for  company transaction
ln_party_id                 hz_cust_accounts.party_id%TYPE;                --Variable to get party_id for  company transaction
ln_location_id              hz_cust_acct_sites_all.party_site_id%TYPE;     --Variable to get party_site_id for company transaction
ln_bill_id                  hz_cust_site_uses_all.site_use_id%TYPE;        --Variable to get Ship_ro_address_id for company transaction
ln_ship_id                  hz_cust_site_uses_all.site_use_id%TYPE;        --Variable to get Ship_ro_address_id for  company transaction
ln_derived_location         installbasetxn_cleaned.oragen9%TYPE;           --Variable to get location id for Ownership Transaction
ln_ibasetxn_reject_recs     NUMBER:=0;                                     --Variable to fetch rejected records from INSTALLBASETXN_CLEANED table
ln_ibase_reject_recs        NUMBER:=0;                                     --Variable to fetch rejected records from INSTALLBASE_CLEANED table
ln_installbase_fetch        NUMBER:=0;                                     --Variable to fetch records from INSTALLBASE_CLEANED table
ln_ibasetxn_fetch           NUMBER:=0;                                     --Variable to fetch records from INSTALLBASETXN_CLEANED table
ln_ibasetxn_proces_recs     NUMBER:=0;                                     --Variable to fetch processed records from INSTALLBASETXN_CLEANED table
ln_ibase_process_recs       NUMBER:=0;                                     --Variable to fetch processed records from INSTALLBASE_CLEANED table
lc_install_date             VARCHAR2(50);                                  --Variable to get Changeddate value
lc_date                     VARCHAR2(50);                                  --Variable to get date value of changeddate with timestamp
lc_error_report             VARCHAR2(1):='N';                              --Variable to get error flag value for rollback and commit

BEGIN
   gn_request_id               := fnd_global.conc_request_id;         -- Request Id of processing data
   gc_debug_flag               := p_debug;                            -- Debug Flag
   gc_log_msg                  :='Start of PROCESS_INSTALL_BASE_DATA ...';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   lc_error_report             :='N';

   --*******************************************************
   -- Opening the cursor to fetch valid Install Base records
   --*******************************************************
   FOR lr_installbase_rec IN lcu_installbase
   LOOP
      gc_record_identifier     := NVL( lr_installbase_rec.itemnbr,'NULL')||' Serial Number '||NVL( lr_installbase_rec.serialnbr,'NULL')||' Item Id '||NVL( lr_installbase_rec.itemid,0);
      gn_record_number         := lr_installbase_rec.record_id;
      gc_log_msg               :='installbase_cleaned-'||gc_record_identifier ;
      gc_table_name            :='INSTALLBASE_CLEANED';                          -- Staging table name insertion in common error table
      ln_installbase_fetch     := ln_installbase_fetch+1;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      -- Reinitialise the Variables
      lc_txn_exists      :=  'N';
      ln_party_act_id    :=   NULL;
      ln_party_id        :=   NULL;
      ln_location_id     :=   NULL;
      ln_bill_id         :=   NULL;
      ln_ship_id         :=   NULL;
      lc_first_own_value :=   NULL;
      lc_err_flag        :=  'N';
      lc_install_date    :=   NULL;
      lc_date            :=   NULL;
      lc_temp_flag       :=   NULL;
      gc_error_code      :=   NULL;
      gc_error_msg       :=   NULL;
      gc_comments        :=   NULL;
      lc_process_flag    :=   NULL;
      lc_create_process_flag:=NULL;

      ------------------------------------------
      --Get the Install date with timestamp
      ------------------------------------------
      --Start of changes 1.1
      IF lr_installbase_rec.installdate IS NOT NULL THEN
         lc_date := TO_CHAR(lr_installbase_rec.installdate,'DD/MM/RRRR HH:MI:SS AM');
      ELSE
         lc_date := NULL;
      END IF;
      --End of changes 1.1

   /* BEGIN
         SELECT TO_CHAR(lr_installbasetxn_rec.changeddate,'DD/MM/RRRR HH:MI:SS AM')
         INTO   lc_date
         FROM   DUAL;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         lc_date := NULL;
      WHEN OTHERS THEN
         lc_txn_err_flag :='Y';
         FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in getting Changed Date with timestamp: ' || SQLERRM);
      END; */


      ------------------------------------------------------------------------------------------
      --Check if the Header Records has Transaction records present or not
      --If not create the Item Instance with the details provided in INSTALLBASE_CLEANED table
      ------------------------------------------------------------------------------------------
      OPEN  lcu_chk_txn_data (lr_installbase_rec.itemid,lr_installbase_rec.serialnbr);
      FETCH lcu_chk_txn_data INTO lc_temp_flag;
         IF (lcu_chk_txn_data%FOUND) THEN
            lc_txn_exists        :='Y';
         END IF;
      CLOSE lcu_chk_txn_data;

      gc_log_msg:='Flag returned by the existence Of transaction record for Header Record '||lc_txn_exists;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      IF (lc_txn_exists <>'Y') THEN
         --***********************************************************************
         -- Calling procedure CALL_CREATE_ITEM_INSTANCE to create Item Instance
         --************************************************************************
         CALL_CREATE_ITEM_INSTANCE (
                                    p_debug         =>p_debug
                                   ,p_serialnbr     =>lr_installbase_rec.serialnbr
                                   ,p_inv_item_id   =>lr_installbase_rec.oragen3
                                   ,p_uom_code      =>lr_installbase_rec.oragen2
                                   ,p_location_id   =>lr_installbase_rec.oragen9
                                   ,p_party_id      =>lr_installbase_rec.oragen8
                                   ,p_party_act_id  =>lr_installbase_rec.oragen7
                                   ,p_bill_to_id    =>lr_installbase_rec.oragen10
                                   ,p_ship_to_id    =>lr_installbase_rec.oragen11
                                   ,p_instance_typ  =>lr_installbase_rec.oragen4
                                   ,p_install_date  =>lc_date
                                   ,p_source_date   =>NVL(lc_date,SYSDATE)
                                   ,p_external_ref  =>TRIM(lr_installbase_rec.thirdpartynbr)
                                   --Start of Changes 1.1
                                   ,p_version       =>TRIM(lr_installbase_rec.version)
                                    --End of Changes 1.1
                                    --Start of Changes V1.6
                                    ,p_last_pm       =>TRIM(lr_installbase_rec.lastpmdate)
                                    ,p_next_pm       =>TRIM(lr_installbase_rec.nextpmdate)

                                    --End of Changes V1.6
                                   ,x_instance_id   =>ln_instance_num
                                   ,x_inst_party_id =>ln_inst_party_id
                                   ,x_ip_account_id =>ln_ip_acct_id
                                   ,x_process_flag  =>lc_process_flag
                                 );
         -------------------------------------------------
         --If the Item Instance get successfully created
         --And not having transaction record
         --Commit the Item Instance
         -------------------------------------------------
         IF (lc_process_flag ='S') THEN

            --Call the update procedure for update the record status which will run as a Autonomous transaction
            update_header_record_status(
                                        p_record_id    => lr_installbase_rec.record_id
                                       ,p_status_flag  =>'PS'
                                       );
         ELSE
            lc_error_report   :='Y';
            update_header_record_status(
                                        p_record_id    => lr_installbase_rec.record_id
                                       ,p_status_flag  =>'PE'
                                       );

         END IF;
      ------------------------------------------------------------------------------------
      --If the Transaction record Found then
      --create the Item Instance with the details provided in INSTALLBASETXN_CLEANED table
      ------------------------------------------------------------------------------------
      ELSE
         -------------------------------------------------------
         --Get The first Ownership Details for Creating Item Instance
         -------------------------------------------------------
         BEGIN
            SELECT   IBT.oragen13
            INTO     lc_first_own_value
            FROM     installbasetxn_cleaned IBT
            WHERE    IBT.serialnbr    =lr_installbase_rec.serialnbr
            AND      IBT.itemid       =lr_installbase_rec.itemid
            AND      IBT.columnchanged='ownership_stat_id'
            AND      ROWNUM           =1
            ORDER BY IBT.changeddate;
         EXCEPTION
         WHEN NO_DATA_FOUND THEN
            lc_first_own_value := lr_installbase_rec.oragen4;
         WHEN OTHERS THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Ownership Details for Creating Item Instance: '||SQLERRM);
         END;

         -----------------------------------------------------------
         -- Get The first Company Details for Creating Item Instance
         -----------------------------------------------------------
         BEGIN
            SELECT   IBT.oragen2
                    ,IBT.oragen3
                    ,IBT.oragen4
                    ,IBT.oragen5
                    ,IBT.oragen6
            INTO     ln_party_act_id
                    ,ln_party_id
                    ,ln_location_id
                    ,ln_bill_id
                    ,ln_ship_id
            FROM     installbasetxn_cleaned IBT
            WHERE    IBT.serialnbr    =lr_installbase_rec.serialnbr
            AND      IBT.itemid       =lr_installbase_rec.itemid
            AND      IBT.columnchanged='company_id'
            AND      ROWNUM           =1
            ORDER BY changeddate ;
         EXCEPTION
         WHEN NO_DATA_FOUND THEN
         --------------------------------------------------------
         --Assign Company Details from INSTALLBASE_CLEANED table
         --------------------------------------------------------
            ln_party_act_id := lr_installbase_rec.oragen7;
            ln_party_id     := lr_installbase_rec.oragen8;
            ln_location_id  := lr_installbase_rec.oragen9;
            ln_bill_id      := lr_installbase_rec.oragen10;
            ln_ship_id      := lr_installbase_rec.oragen11;
         WHEN OTHERS THEN
            FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Company Details for Creating Item Instance: '||SQLERRM);
         END;

         IF (lr_installbase_rec.installdate IS NULL) THEN
         ----------------------------------------------------------------------
         -- Get The Changeddate of first Transaction for Creating Item Instance
         ----------------------------------------------------------------------
            BEGIN
               SELECT   TO_CHAR(IBT.changeddate,'DD/MM/RRRR HH:MI:SS AM')
               INTO     lc_install_date
               FROM     installbasetxn_cleaned IBT
               WHERE    IBT.serialnbr =lr_installbase_rec.serialnbr
               AND      IBT.itemid    =lr_installbase_rec.itemid
               AND      ROWNUM        =1
               ORDER BY IBT.changeddate ;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'No Earliest Changeddate is found for Creating Item Instance: '||SQLERRM);
            WHEN OTHERS THEN
               FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in getting Earliest Changeddate for Creating Item Instance: '||SQLERRM);
            END;
         END IF; --lr_installbase_rec.installdate IS NULL

         --********************************************************************
         -- Calling procedure CALL_CREATE_ITEM_INSTANCE to create Item Instance
         --********************************************************************
         CALL_CREATE_ITEM_INSTANCE (
                                    p_debug         =>p_debug
                                   ,p_serialnbr     =>lr_installbase_rec.serialnbr
                                   ,p_inv_item_id   =>TO_NUMBER(lr_installbase_rec.oragen3)
                                   ,p_uom_code      =>lr_installbase_rec.oragen2
                                   ,p_location_id   =>ln_location_id
                                   ,p_party_id      =>ln_party_id
                                   ,p_party_act_id  =>ln_party_act_id
                                   ,p_bill_to_id    =>ln_bill_id
                                   ,p_ship_to_id    =>ln_ship_id
                                   ,p_instance_typ  =>lc_first_own_value
                                   ,p_install_date  =>lc_date
                                   ,p_source_date   =>NVL(lc_date,lc_install_date)
                                   ,p_external_ref  =>TRIM(lr_installbase_rec.thirdpartynbr)
                                   --Start of Changes 1.1
                                   ,p_version       =>TRIM(lr_installbase_rec.version)
                                    --End of Changes 1.1
                                   --Start of Changes 1.6
                                   ,p_last_pm       =>TRIM(lr_installbase_rec.lastpmdate)
                                   ,p_next_pm       =>TRIM(lr_installbase_rec.nextpmdate)
                                   --End of Changes 1.6
                                   ,x_instance_id   =>ln_instance_num
                                   ,x_inst_party_id =>ln_inst_party_id
                                   ,x_ip_account_id =>ln_ip_acct_id
                                   ,x_process_flag  =>lc_create_process_flag
                                 );

         ---------------------------------------------------------
         -- If the return status of create Instance is successfull
         -- then call update instance api
         ---------------------------------------------------------
         IF (lc_create_process_flag ='S') THEN

         --**********************************************************************
            -- Opening the cursor to fetch valid Install Base Transaction Records
         --**********************************************************************

            FOR lr_installbasetxn_rec IN lcu_installbasetxn(
                                                             lr_installbase_rec.itemid
                                                            ,lr_installbase_rec.serialnbr
                                                           )
            LOOP
               gn_record_number        := lr_installbasetxn_rec.record_id;
               ln_ibasetxn_fetch       := ln_ibasetxn_fetch+1;
               gc_table_name           :='INSTALLBASETXN_CLEANED';   -- Staging table name insertion in common error table


               -- Reinitialise the variables
               ln_derived_location     := NULL;
               lc_update_process_flag  := NULL;
               lc_date                 := NULL;
               lc_txn_err_flag         :='N';
               gc_error_code           := NULL;
               gc_error_msg            := NULL;
               gc_comments             := NULL;

               dbms_lock.sleep(1);
               ------------------------------------------
               --Get the Changed Date  with timestamp
               ------------------------------------------
               --Start of changes 1.1
               IF lr_installbasetxn_rec.changeddate IS NOT NULL THEN
                  lc_date := TO_CHAR(lr_installbase_rec.installdate,'DD/MM/RRRR HH:MI:SS AM');
               ELSE
                  lc_date := NULL;
               END IF;
               --End of changes 1.1

              /* BEGIN
                  SELECT TO_CHAR(lr_installbasetxn_rec.changeddate,'DD/MM/RRRR HH:MI:SS AM')
                  INTO   lc_date
                  FROM   DUAL;
               EXCEPTION
               WHEN NO_DATA_FOUND THEN
                  lc_date := NULL;
               WHEN OTHERS THEN
                  lc_txn_err_flag :='Y';
                  FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in getting Changed Date with timestamp: ' || SQLERRM);
               END; */

               --********************************************************************
               -- Calling procedure CALL_UPDATE_ITEM_INSTANCE to UPDATE Item Instance
               --*********************************************************************

               CALL_UPDATE_ITEM_INSTANCE (
                                           p_debug             =>p_debug
                                          ,p_instance_id       =>ln_instance_num
                                          ,p_inst_party_id     =>ln_inst_party_id
                                          ,p_ip_account_id     =>ln_ip_acct_id
                                          ,p_ownership_chg     =>lr_installbasetxn_rec.columnchanged
                                          ,p_item_id           =>lr_installbase_rec.itemid
                                          ,p_serialnbr         =>lr_installbase_rec.serialnbr
                                          ,p_location_id       =>lr_installbasetxn_rec.oragen9
                                          ,p_party_id          =>lr_installbasetxn_rec.oragen8
                                          ,p_party_act_id      =>lr_installbasetxn_rec.oragen7
                                          ,p_bill_to_id        =>lr_installbasetxn_rec.oragen10
                                          ,p_ship_to_id        =>lr_installbasetxn_rec.oragen11
                                          ,p_instance_typ      =>lr_installbasetxn_rec.oragen14
                                          ,p_transaction_date  =>lc_date
                                          ,x_process_flag      =>lc_update_process_flag
                                        );

               IF (lc_update_process_flag ='S') THEN

                  --Call the update procedure for update the record status which will run as a Autonomous transaction
                  update_line_record_status (
                                              p_record_id    => lr_installbasetxn_rec.record_id
                                             ,p_status_flag  =>'PS'
                                             );

               ELSE
                  lc_error_report   :='Y';
                  --Call the update procedure for update the record status which will run as a Autonomous transaction
                  update_line_record_status (
                                              p_record_id    => lr_installbasetxn_rec.record_id
                                             ,p_status_flag  =>'PS'
                                             );
               END IF;
            END LOOP; -- End loop for installbasetxn_cleaned table

            --Call the update procedure for update the record status which will run as a Autonomous transaction
            update_header_record_status(
                                        p_record_id    => lr_installbase_rec.record_id
                                       ,p_status_flag  =>'PS'
                                       );
         ELSE
            lc_error_report   :='Y';
            update_header_record_status(
                                        p_record_id    => lr_installbase_rec.record_id
                                       ,p_status_flag  =>'PE'
                                       );

         END IF;     ---End if for Condition  IF (lc_create_process_flag ='S')
      END IF;-- End if for condition IF (lc_txn_exists <>'Y')
   END LOOP; -- End loop for validation of installbase_cleaned table

   IF (lc_error_report ='Y') THEN
      ROLLBACK;
   ELSE
      COMMIT;   -- COMMIT for all transaction
   END IF;


   ----------------------------------
   --Get Error Stastastics
   ----------------------------------
   BEGIN

      SELECT COUNT (*)
      INTO   ln_ibase_reject_recs
      FROM   installbase_cleaned IC
      WHERE  IC.oragen1='PE'
      --AND    DECODE(IC.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
      AND    IC.sourcesys =gc_operating_unit_name ;

      SELECT COUNT (*)
      INTO   ln_ibasetxn_reject_recs
      FROM   installbasetxn_cleaned IBT
      WHERE  IBT.oragen1='PE'
      --AND    DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
      AND    IBT.sourcesys =gc_operating_unit_name ;

      SELECT COUNT (*)
      INTO   ln_ibase_process_recs
      FROM   installbase_cleaned IC
      WHERE  IC.oragen1='PS'
      --AND    DECODE(IC.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
      AND    IC.sourcesys =gc_operating_unit_name ;

      SELECT COUNT (*)
      INTO   ln_ibasetxn_proces_recs
      FROM   installbasetxn_cleaned IBT
      WHERE  IBT.oragen1='PS'
      --AND    DECODE(IBT.sourcesys,'Service Alliance',gc_us_ou_name,'MFGPRO',gc_jp_ou_name)=gc_operating_unit_name ;
      AND    IBT.sourcesys =gc_operating_unit_name ;

   EXCEPTION
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Error Statistics for Data Process Procedure: '||SQLERRM);
   END;

   ----------------------------------------
   -- Summary Of Data Process
   ----------------------------------------

   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of installbase_cleaned Records Processed');
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records                                       :  ' ||ln_installbase_fetch);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Processsed                            :  ' ||ln_ibase_process_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Failed To Process                     :  ' ||ln_ibase_reject_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Summary information of installbasetxn_cleaned Records Processed');
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records                                       :  ' ||ln_ibasetxn_fetch);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Processsed                            :  ' ||ln_ibasetxn_proces_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Total Records Failed To Process                     :  ' ||ln_ibasetxn_reject_recs);
   FND_FILE.PUT_LINE(FND_FILE.LOG,RPAD('*',80,'*'));
   ----------------------------------------------------------------------------------
   -- If any single record failed in data process then complete the program with warning
   -- and launch the error report
   -----------------------------------------------------------------------------------
   IF (lc_error_report ='Y') THEN
      x_process_flag := 'N';
      xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,gc_program_name,gc_rec_identifier);
   END IF;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.PROCESS_INSTALL_BASE_DATA: ' || SQLERRM);
END process_install_base_data;

-- +=======================================================================+
-- | Name            : CALL_CREATE_ITEM_INSTANCE                           |
-- | Description     : Procedure to Call create_item_instance API          |
-- |                                                                       |
-- | Call From       : Called from Procedure PROCESS_INSTALL_BASE_DATA     |
-- | Parameters :                                                          |
-- |   IN: p_debug                                                         |
-- |      ,p_serialnbr                                                     |
-- |      ,p_inv_item_id                                                   |
-- |      ,p_uom_code                                                      |
-- |      ,p_location_id                                                   |
-- |      ,p_party_id                                                      |
-- |      ,p_party_act_id                                                  |
-- |      ,p_bill_to_id                                                    |
-- |      ,p_ship_to_id                                                    |
-- |      ,p_instance_typ                                                  |
-- |      ,p_install_date                                                  |
-- |      ,p_source_date                                                   |
-- |      ,p_external_ref                                                  |
-- |      ,p_version                                                       |
-- |  OUT: x_instance_id                                                   |
-- |      ,x_inst_party_id                                                 |
-- |      ,x_ip_account_id                                                 |
-- |      ,x_process_flag                                                  |
-- |                                                                       |
-- | Returns : x_instance_id,x_inst_party_id,x_ip_account_id,x_process_flag|
-- +=======================================================================+

PROCEDURE CALL_CREATE_ITEM_INSTANCE(
                                    p_debug         IN  VARCHAR2
                                   ,p_serialnbr     IN  VARCHAR2
                                   ,p_inv_item_id   IN  NUMBER
                                   ,p_uom_code      IN  VARCHAR2
                                   ,p_location_id   IN  NUMBER
                                   ,p_party_id      IN  NUMBER
                                   ,p_party_act_id  IN  NUMBER
                                   ,p_bill_to_id    IN  NUMBER
                                   ,p_ship_to_id    IN  NUMBER
                                   ,p_instance_typ  IN  VARCHAR2
                                   ,p_install_date  IN  VARCHAR2
                                   ,p_source_date   IN  VARCHAR2
                                   ,p_external_ref  IN  VARCHAR2
                                   --Start of Changes 1.1
                                   ,p_version       IN  VARCHAR2
                                   --End of Changes 1.1
                                   --Start of Changes 1.6
                                   ,p_last_pm       IN  VARCHAR2
                                   ,p_next_pm       IN  VARCHAR2
                                   --End of Changes 1.6
                                   ,x_instance_id   OUT NUMBER
                                   ,x_inst_party_id OUT NUMBER
                                   ,x_ip_account_id OUT NUMBER
                                   ,x_process_flag  OUT VARCHAR2
                                   )

AS
--------------------------
-- Record Type Declaration
-------------------------
lr_instance_rec             csi_datastructures_pub.instance_rec;                 --Record to hold the attributes of an item instance
lr_ext_attrib_values_tbl    csi_datastructures_pub.extend_attrib_values_tbl;     --Record to hold the values of an item instances extended attributes.
lr_party_tbl                csi_datastructures_pub.party_tbl;                    --Record to hold information about an instance-party relationship
lr_account_tbl              csi_datastructures_pub.party_account_tbl;            --Record to hold information about a party-account relationship.
lr_pricing_attrib_tbl       csi_datastructures_pub.pricing_attribs_tbl;          --Record to hold the pricing attributes of an item instance.
lr_org_assignments_tbl      csi_datastructures_pub.organization_units_tbl;       --Record to hold information about an instance-org association
lr_asset_assignment_tbl     csi_datastructures_pub.instance_asset_tbl;           --Record to hold information about instance-asset association.
lr_transaction_rec          csi_datastructures_pub.transaction_rec;              --Record to hold the attributes of an Installed Base  transaction.
ln_record_cnt              NUMBER:=0;
-------------------------------
-- Local Variable Declaration
-------------------------------
lc_init_msg_list            VARCHAR2(240);                                       --Variable to get error message given by api
ln_validation_level         NUMBER  ;                                            --Variable for validation level
ln_msg_count                NUMBER:=0;                                           --Variable for error message count
lc_msg_data                 VARCHAR2(2000);                                      --Variable to store API error message
ln_version_nbr              NUMBER:=1;                                           --Variable for Default object version Number 1
lc_success                  VARCHAR2(1) := 'T';                                  --Variable to check success flag of API
lc_revision_nbr             mtl_item_revisions_b.revision%TYPE;                  --Variable to get starting revision
lc_temp_flag                VARCHAR2(1);                                         --Variable to hold temporary value

BEGIN
   gn_request_id          := FND_GLOBAL.CONC_REQUEST_ID;                         -- Request Id of processing data
   gc_debug_flag          := p_debug;                                            -- Debug Flag
   lc_temp_flag           := NULL;
   lc_revision_nbr        := NULL;
   -------------------------
   -- Derive the Sequences
   -------------------------
   BEGIN
      SELECT CSI_ITEM_INSTANCES_S.NEXTVAL
      INTO   x_instance_id
      FROM   SYS.DUAL;

      SELECT CSI_I_PARTIES_S.NEXTVAL
      INTO   x_inst_party_id
      FROM   SYS.DUAL;

      SELECT CSI_IP_ACCOUNTS_S.NEXTVAL
      INTO   x_ip_account_id
      FROM   SYS.DUAL;
   EXCEPTION
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Sequnce Value for Creating Item Instance: '||SQLERRM);
   END;

   -------------------------------------------------------------------------------
   -- Check the Inventory Item for revision control
   -- If revision_qty_control_code = 2 then the Inventory Item Is Revision Control
   --------------------------------------------------------------------------------
   BEGIN
      SELECT 'Y'
      INTO   lc_temp_flag
      FROM   mtl_system_items_b MIB
      WHERE  MIB.inventory_item_id=p_inv_item_id
      AND    MIB.organization_id =gn_mst_org_id
      AND    MIB.revision_qty_control_code = 2;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      lc_temp_flag :='N';
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'error while checking revision control Inventory Item: '||p_inv_item_id);
   END;

/* ----------------------------------------------------------
   -- Fetch Start_revision For the Inventory organization
   ----------------------------------------------------------
   BEGIN
      SELECT DISTINCT(MP.starting_revision)
      INTO   lc_revision_nbr
      FROM   mtl_parameters MP
      WHERE  MP.organization_id =gn_mst_org_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'No starting revision has been set for the inventory organization'||gc_mst_org);
      lc_revision_nbr :=NULL;
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'error while fetching starting_revision for the organization '||gc_mst_org);
   END;   */

   ----------------------------------------------------------
   -- Fetch latest revision against the Inventory Item
   -- which is having revision_qty_control_code = 2;
   ----------------------------------------------------------
   BEGIN
      SELECT   MIR.revision
      INTO     lc_revision_nbr
      FROM     mtl_item_revisions_b MIR
      WHERE    MIR.Inventory_item_id=p_inv_item_id
      AND      MIR.organization_id=gn_mst_org_id
      AND      ROWNUM=1
      ORDER BY MIR.EFFECTIVITY_DATE desc;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Rrevision has not been found for the inventory organization'||gc_mst_org);
      lc_revision_nbr :=NULL;
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'error while fetching starting_revision for the organization '||gc_mst_org);
   END;

   --------------------
   --For Item Instance
   --------------------
   lr_instance_rec.instance_id                 :=x_instance_id;
   lr_instance_rec.instance_number             :=x_instance_id;
   lr_instance_rec.inventory_item_id           :=p_inv_item_id;
   lr_instance_rec.vld_organization_id         :=gn_mst_org_id;
   lr_instance_rec.active_start_date           :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
   lr_instance_rec.install_date                :=TO_DATE(p_install_date,'DD/MM/RRRR HH:MI:SS AM');
   lr_instance_rec.location_type_code          :=gc_inst_loct_source_code;
   lr_instance_rec.location_id                 :=p_location_id;
   lr_instance_rec.object_version_number       :=ln_version_nbr;
   lr_instance_rec.quantity                    :=gn_quantity;
   lr_instance_rec.unit_of_measure             :=p_uom_code;
   lr_instance_rec.inv_master_organization_id  :=gn_mst_org_id;
   lr_instance_rec.serial_number               :=p_serialnbr;
   lr_instance_rec.instance_usage_code         :=gc_instance_usage_code;
   lr_instance_rec.instance_status_id          :=gn_instance_id;
   lr_instance_rec.accounting_class_code       :=gc_acct_class_code;
   lr_instance_rec.install_location_type_code  :=gc_inst_loct_source_code;
   lr_instance_rec.install_location_id         :=p_location_id;
   lr_instance_rec.merchant_view_flag          :='Y';
   lr_instance_rec.customer_view_flag          :='N';
   lr_instance_rec.manually_created_flag       :='Y';
   lr_instance_rec.sellable_flag               :='Y';
   lr_instance_rec.instance_type_code          :=p_instance_typ;
   --Start of changes V1.5
   IF p_version IS NOT NULL THEN
      lr_instance_rec.version_label_description:=p_version;
   ELSE
     lr_instance_rec.version_label_description:=NULL;
   END IF;
   --End of changes V1.5

   -----------------------------------------
   --If the Item Is revison Control
   --then pass the default revison Number
   -----------------------------------------

   IF (lc_temp_flag ='Y') THEN
      lr_instance_rec.inventory_revision       :=lc_revision_nbr;
   END IF;

   ----------------------------------------------------------
   -- Populate External Reference as Third Party Billing
   -- If Third Party Number Is not Null
   -----------------------------------------------------------
   IF (p_external_ref IS NOT NULL) THEN
      lr_instance_rec.external_reference       :=gc_external_reference;
   END IF;

   --------------------
   --For Parties
   --------------------
   lr_party_tbl(1).instance_party_id           :=x_inst_party_id;
   lr_party_tbl(1).instance_id                 :=x_instance_id;
   lr_party_tbl(1).party_source_table          :=gc_party_source_table;
   lr_party_tbl(1).party_id                    :=p_party_id;
   lr_party_tbl(1).contact_flag                :='N';
   lr_party_tbl(1).relationship_type_code      :=gc_rel_type_code;
   lr_party_tbl(1).active_start_date           :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
   lr_party_tbl(1).object_version_number       :=ln_version_nbr;

   --------------------
   --For Party Account
   --------------------
   lr_account_tbl(1).ip_account_id             :=x_ip_account_id;
   lr_account_tbl(1).instance_party_id         :=x_inst_party_id;
   lr_account_tbl(1).party_account_id          :=p_party_act_id;
   lr_account_tbl(1).relationship_type_code    :=gc_rel_type_code;
   lr_account_tbl(1).active_start_date         :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
   lr_account_tbl(1).object_version_number     :=ln_version_nbr;
   lr_account_tbl(1).parent_tbl_index          :='1';
   lr_account_tbl(1).bill_to_address           :=p_bill_to_id ;
   lr_account_tbl(1).ship_to_address           :=p_ship_to_id ;

   -------------------------
   --For Transaction Records
   --------------------------
   lr_transaction_rec.transaction_date         :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
   lr_transaction_rec.source_transaction_date  :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
   lr_transaction_rec.transaction_type_id      :=gn_transaction_id;
   lr_transaction_rec.object_version_number    :=ln_version_nbr;

   ----------------------------------
   --For Organization units Records
   -----------------------------------
   lr_org_assignments_tbl(1).instance_id           :=x_instance_id;
   lr_org_assignments_tbl(1).operating_unit_id     :=gn_organization_id;
   lr_org_assignments_tbl(1).relationship_type_code:=gc_io_relt_type_code;
   lr_org_assignments_tbl(1).active_start_date     :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
   lr_org_assignments_tbl(1).object_version_number :=ln_version_nbr;

   --Start of Changes 1.1
   IF p_version IS NOT NULL THEN
   ln_record_cnt:=ln_record_cnt+1;
      ----------------------------------
      --For Eextended Attributes Records
      ----------------------------------
      lr_ext_attrib_values_tbl(ln_record_cnt).attribute_id            :=gn_extend_attrib_id;
      lr_ext_attrib_values_tbl(ln_record_cnt).instance_id             :=x_instance_id;
      lr_ext_attrib_values_tbl(ln_record_cnt).attribute_value         :=p_version;
      lr_ext_attrib_values_tbl(ln_record_cnt).active_start_date       :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
      lr_ext_attrib_values_tbl(ln_record_cnt).object_version_number   :=ln_version_nbr;
   END IF;
     --Start of Changes 1.6
    IF p_last_pm IS NOT NULL THEN
     ln_record_cnt:=ln_record_cnt+1;
       ----------------------------------
       --For Eextended Attributes Records
       ----------------------------------
       lr_ext_attrib_values_tbl(ln_record_cnt).attribute_id            :=gn_extend_lpm_att_id;
       lr_ext_attrib_values_tbl(ln_record_cnt).instance_id             :=x_instance_id;
       lr_ext_attrib_values_tbl(ln_record_cnt).attribute_value         :=p_last_pm;
       lr_ext_attrib_values_tbl(ln_record_cnt).active_start_date       :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
       lr_ext_attrib_values_tbl(ln_record_cnt).object_version_number   :=ln_version_nbr;
    END IF;


   IF p_next_pm IS NOT NULL THEN
    ln_record_cnt:=ln_record_cnt+1;
      ----------------------------------
      --For Eextended Attributes Records
      ----------------------------------
      lr_ext_attrib_values_tbl(ln_record_cnt).attribute_id            :=gn_extend_npm_att_id;
      lr_ext_attrib_values_tbl(ln_record_cnt).instance_id             :=x_instance_id;
      lr_ext_attrib_values_tbl(ln_record_cnt).attribute_value         :=p_next_pm;
      lr_ext_attrib_values_tbl(ln_record_cnt).active_start_date       :=TO_DATE(p_source_date,'DD/MM/RRRR HH:MI:SS AM');
      lr_ext_attrib_values_tbl(ln_record_cnt).object_version_number   :=ln_version_nbr;
   END IF;
    --End of Changes 1.6





   --End of Changes 1.1

   --****************************************
      -- Calling Create Item Instance Api
   --****************************************

   BEGIN

      fnd_msg_pub.Initialize;
      csi_item_instance_pub.create_item_instance(
                                                 p_api_version             => 1
                                                ,p_commit                  => fnd_api.g_false
                                                ,p_init_msg_list           => lc_init_msg_list
                                                ,p_validation_level        => ln_validation_level
                                                ,p_instance_rec            => lr_instance_rec
                                                ,p_ext_attrib_values_tbl   => lr_ext_attrib_values_tbl
                                                ,p_party_tbl               => lr_party_tbl
                                                ,p_account_tbl             => lr_account_tbl
                                                ,p_pricing_attrib_tbl      => lr_pricing_attrib_tbl
                                                ,p_org_assignments_tbl     => lr_org_assignments_tbl
                                                ,p_asset_assignment_tbl    => lr_asset_assignment_tbl
                                                ,p_txn_rec                 => lr_transaction_rec
                                                ,x_return_status           => x_process_flag
                                                ,x_msg_count               => ln_msg_count
                                                ,x_msg_data                => lc_msg_data
                                               );

      IF (x_process_flag != APPS.FND_API.G_RET_STS_SUCCESS) THEN
         lc_msg_data:= APPS.FND_MSG_PUB.Get(
                                             p_msg_index    => APPS.FND_MSG_PUB.G_LAST
                                             ,p_encoded     => APPS.FND_API.G_FALSE
                                          );
         gc_error_code       := 'API_Error';
         gc_error_msg        :=  lc_msg_data ;
         insert_error_prc ;
         lc_success := 'F';
      END IF;
      gc_log_msg:='Status returned by the csi_item_instance_pub.create_item_instance API against Instance Id '||x_instance_id||' is '||x_process_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   END;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.CALL_CREATE_ITEM_INSTANCE: ' || SQLERRM);
END CALL_CREATE_ITEM_INSTANCE;

-- +===================================================================+
-- | Name            : CALL_UPDATE_ITEM_INSTANCE                       |
-- | Description     : Procedure to Call update_item_instance API      |
-- |                                                                   |
-- | Call From       : Called from Procedure PROCESS_INSTALL_BASE_DATA |
-- | Parameters :                                                      |
-- |   IN: p_debug                                                     |
-- |      ,p_instance_id                                               |
-- |      ,p_inst_party_id                                             |
-- |      ,p_ip_account_id                                             |
-- |      ,p_ownership_chg                                             |
-- |      ,p_item_id                                                   |
-- |      ,p_serialnbr                                                 |
-- |      ,p_location_id                                               |
-- |      ,p_party_id                                                  |
-- |      ,p_party_act_id                                              |
-- |      ,p_bill_to_id                                                |
-- |      ,p_ship_to_id                                                |
-- |      ,p_instance_typ                                              |
-- |      ,p_transaction_date                                          |
-- |                                                                   |
-- |  OUT: x_process_flag                                              |
-- | Returns : x_process_flag                                          |
-- +===================================================================+
PROCEDURE CALL_UPDATE_ITEM_INSTANCE(
                                    p_debug              IN  VARCHAR2
                                   ,p_instance_id        IN  NUMBER
                                   ,p_inst_party_id      IN  NUMBER
                                   ,p_ip_account_id      IN  NUMBER
                                   ,p_ownership_chg      IN  VARCHAR2
                                   ,p_item_id            IN  NUMBER
                                   ,p_serialnbr          IN  VARCHAR2
                                   ,p_location_id        IN  NUMBER
                                   ,p_party_id           IN  NUMBER
                                   ,p_party_act_id       IN  NUMBER
                                   ,p_bill_to_id         IN  NUMBER
                                   ,p_ship_to_id         IN  NUMBER
                                   ,p_instance_typ       IN  VARCHAR2
                                   ,p_transaction_date   IN  VARCHAR2
                                   ,x_process_flag       OUT VARCHAR2
                                   )
AS
--------------------------
-- Record Type Declaration
-------------------------
lr_instance_rec             csi_datastructures_pub.instance_rec;                 --Record to hold the attributes of an item instance
lr_ext_attrib_values_tbl    csi_datastructures_pub.extend_attrib_values_tbl;     --Record to hold the values of an item instances extended attributes.
lr_party_tbl                csi_datastructures_pub.party_tbl;                    --Record to hold information about an instance-party relationship
lr_account_tbl              csi_datastructures_pub.party_account_tbl;            --Record to hold information about a party-account relationship.
lr_pricing_attrib_tbl       csi_datastructures_pub.pricing_attribs_tbl;          --Record to hold the pricing attributes of an item instance.
lr_org_assignments_tbl      csi_datastructures_pub.organization_units_tbl;       --Record to hold information about an instance-org association
lr_asset_assignment_tbl     csi_datastructures_pub.instance_asset_tbl;           --Record to hold information about instance-asset association.
lr_transaction_rec          csi_datastructures_pub.transaction_rec;              --Record to hold the attributes of an Installed Base  transaction.
lr_miss_party_tbl           csi_datastructures_pub.party_tbl;                    --Record to hold Null information about an instance-party relationship
lr_miss_account_tbl         csi_datastructures_pub.party_account_tbl;            --Record to hold Null information about a party-account relationship.
lr_instance_id_lst          csi_datastructures_pub.id_tbl;                       --TABLE OF NUMBER INDEX BY BINARY_INTEGER;

-----------------------------
-- Local Variable Declaration
-----------------------------
lc_init_msg_list            VARCHAR2(240);                                       --Variable to get error message given by api
ln_validation_level         NUMBER;                                              --Variable for validation level
ln_msg_count                NUMBER:=0;                                           --Variable for error message count
lc_msg_data                 VARCHAR2(2000);                                      --Variable to store API error message
ln_version_nbr              NUMBER:=1;                                           --Variable for Default object version Number 1
lc_success                  VARCHAR2(1) :='T';                                   --Variable to check success flag of API
ln_version_num              NUMBER:=0;                                           --Variable to get object version number from table csi_item_instances
ln_party_version_num        NUMBER:=0;                                           --Variable to get object version number from table csi_i_parties


BEGIN
   gn_request_id               := fnd_global.conc_request_id;         -- Request Id of processing data
   gc_debug_flag               := p_debug;                            -- Debug Flag

   --------------------------------------------------------------
   --Get the current Object Version Number for the Item Instance
   --------------------------------------------------------------
   BEGIN
      SELECT CIT.object_version_number
      INTO   ln_version_num
      FROM   csi_item_instances CIT
      WHERE  CIT.instance_id = p_instance_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      gc_error_code :='IB-0';
      gc_error_msg  :='Item Instance has not been created ';
      gc_comments   :='Please check the Item Instance Details';
      INSERT_ERROR_PRC;
   WHEN OTHERS THEN
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Object Version Number for the Item Instance: '||SQLERRM);
   END;

   -------------------------------------------------------------------
   --Get the current Object Version Number for the Item Instance Party
   -------------------------------------------------------------------
   BEGIN
      SELECT CIP.object_version_number
      INTO   ln_party_version_num
      FROM   csi_i_parties CIP
      WHERE  CIP.instance_id = p_instance_id;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      gc_error_code :='IB-0';
      gc_error_msg  :='Item Instance has not been created ';
      gc_comments   :='Please check the Item Instance Details';
      INSERT_ERROR_PRC;
   WHEN OTHERS THEN
      FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in Deriving Object Version Number for the Item Instance Party: '||SQLERRM);
   END;

   --------------------------------------------------
   --If the transaction is for Ownership then
   --------------------------------------------------

   IF (p_ownership_chg ='ownership_stat_id') THEN

      -------------------------------------------------------------
      --Accounting class always defaulted to CUST_PROD
      --Not required to pass same value in update_item_instance Api
      -------------------------------------------------------------

   -- lr_instance_rec.accounting_class_code       := gc_acct_class_code;
      lr_instance_rec.instance_type_code          := p_instance_typ;
      lr_instance_rec.instance_id                 := p_instance_id ;
      lr_instance_rec.object_version_number       := ln_version_num ;


      -----------------------------------------------------------
      --Pass Party and Part Account Record as null
      --As they are not required while Ownership Transactions
      ------------------------------------------------------------
      lr_party_tbl                                :=lr_miss_party_tbl;
      lr_account_tbl                              :=lr_miss_account_tbl;
   ELSE
      --------------------------------------------------
      --If the transaction is for Company then
      --------------------------------------------------

      lr_instance_rec.instance_id                 := p_instance_id ;
      lr_instance_rec.location_id                 := p_location_id;
      lr_instance_rec.object_version_number       := ln_version_num;
      lr_instance_rec.install_location_id         := p_location_id;

      --------------------
      --For Parties
      --------------------
      lr_party_tbl(1).instance_party_id           := p_inst_party_id;
      lr_party_tbl(1).instance_id                 := p_instance_id;
      lr_party_tbl(1).party_id                    := p_party_id;
      lr_party_tbl(1).object_version_number       := ln_party_version_num;

      --------------------
      --For Party Account
      --------------------
      lr_account_tbl(1).ip_account_id             := p_ip_account_id;
      lr_account_tbl(1).instance_party_id         := p_inst_party_id;
      lr_account_tbl(1).party_account_id          := p_party_act_id;
      lr_account_tbl(1).object_version_number     := ln_party_version_num;
      lr_account_tbl(1).bill_to_address           := p_bill_to_id;
      lr_account_tbl(1).ship_to_address           := p_ship_to_id;
   END IF;

   -------------------------
   --For Transaction Records
   --------------------------
      lr_transaction_rec.transaction_date         := TO_DATE(p_transaction_date,'DD/MM/RRRR HH:MI:SS AM');
      lr_transaction_rec.source_transaction_date  := NVL(TO_DATE(p_transaction_date,'DD/MM/RRRR HH:MI:SS AM'),SYSDATE);
      lr_transaction_rec.transaction_type_id      := gn_transaction_id;
      lr_transaction_rec.object_version_number    := ln_version_nbr;

   --***********************************
   -- Calling Update Item Instance Api
   --***********************************
   BEGIN
      fnd_msg_pub.Initialize;
      csi_item_instance_pub.update_item_instance(
                                                 p_api_version            => 1.0
                                                ,p_commit                 => fnd_api.g_false
                                                ,p_init_msg_list          => lc_init_msg_list
                                                ,p_validation_level       => ln_validation_level
                                                ,p_instance_rec           => lr_instance_rec
                                                ,p_ext_attrib_values_tbl  => lr_ext_attrib_values_tbl
                                                ,p_party_tbl              => lr_party_tbl
                                                ,p_account_tbl            => lr_account_tbl
                                                ,p_pricing_attrib_tbl     => lr_pricing_attrib_tbl
                                                ,p_org_assignments_tbl    => lr_org_assignments_tbl
                                                ,p_asset_assignment_tbl   => lr_asset_assignment_tbl
                                                ,p_txn_rec                => lr_transaction_rec
                                                ,x_instance_id_lst        => lr_instance_id_lst
                                                ,x_return_status          => x_process_flag
                                                ,x_msg_count              => ln_msg_count
                                                ,x_msg_data               => lc_msg_data
                                               );

      IF  (x_process_flag != APPS.FND_API.G_RET_STS_SUCCESS) THEN

          lc_msg_data:= APPS.FND_MSG_PUB.Get(
                                              p_msg_index   => APPS.FND_MSG_PUB.G_LAST
                                             ,p_encoded     => APPS.FND_API.G_FALSE
                                            );
         gc_error_code       := 'API-Error';
         gc_error_msg        :=  lc_msg_data ;
         insert_error_prc ;
         lc_success := 'F';
      END IF;
      gc_log_msg:='Status returned by the csi_item_instance_pub.update_item_instance API against Transaction Id '||lr_transaction_rec.transaction_id||' is '||x_process_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   END;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_CSI_INSTALL_BASE_CONV_PK.CALL_UPDATE_ITEM_INSTANCE: ' || SQLERRM);
END CALL_UPDATE_ITEM_INSTANCE;

END XXHA_CSI_INSTALL_BASE_CONV_PK ;

/
