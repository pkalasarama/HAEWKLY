CREATE OR REPLACE PACKAGE      XXHA_FF_UTILITIES_V2 AS

-- ======================================================================+
-- ======================================================================+
--
-- PROGRAM NAME  : XXHA_FF_UTILITIES_V2
--
-- Description   : The package contains functions used by CWB fast formulas
-- Change History:
-- ---------------
-- Version Date        Author          Remarks
-- ------- ----------- --------------- ---------------
-- 1.0     04-Jan-2010  Kbace          Initial Version
-- 1.1     27-Jan-2010  Kbace          Updated code for Deceased Employees
-- 1.2     30-Apr-2014  Ram Pudupet (DI) Procs to support 2014 CWB rollout in R12

-- ======================================================================+

-- This function evaluates the new hire eligibility

FUNCTION check_new_hire_elig (
                              p_assignment_id number,
                              p_effective_date   date
                              ) 
RETURN varchar2;

-- This function returns the prorated salary for merit plan

FUNCTION get_prorated_salary (
                              p_assignment_id number,
                              p_effective_date   date
                              ) 
RETURN number;

-- This function returns the recommended merit amount 

FUNCTION get_mer_rec_amt (
                          p_assignment_id number,
                          p_effective_date   date
                          )
RETURN number;    

-- This function returns the corporate component of the prorated bonus

FUNCTION get_prorated_bonus_corp (
                                 p_assignment_id number,
                                 p_effective_date   date
                                 ) 
RETURN number;

-- This function returns the region component of the prorated bonus

FUNCTION get_prorated_bonus_reg (
                                  p_assignment_id number,
                                  p_effective_date   date
                                  ) 
RETURN number;

-- This function returns the individual component of the prorated bonus

FUNCTION get_prorated_bonus_ind (
                                  p_assignment_id number,
                                  p_effective_date   date
                                  ) 
RETURN number;

-- This function returns the prorated bonus

FUNCTION get_prorated_bonus (
                              p_assignment_id number,
                              p_effective_date  date
                              ) 
RETURN number;

FUNCTION get_bonus_prorated_salary (
                              p_assignment_id number,
                              p_effective_date   date
                              ) RETURN NUMBER;

-- This function evaluates the eligibility for employees on LOA

FUNCTION get_loa_elig (p_assignment_id number
                      ,p_effective_date date
                      )
RETURN varchar2;                      

-- This function returns the bonus target percentage

FUNCTION get_bonus_target_pct (p_assignment_id number
                              ,p_effective_date date
                              )
RETURN number;                      

-- This function returns the bonus override amount

FUNCTION get_bonus_ovrd_amt (p_assignment_id number
                            ,p_effective_date date
                            )
RETURN number; 

--This function returns the business group id for the group plan

FUNCTION get_group_pl_bg_id (
           p_effective_date IN DATE
         , p_pl_id          IN NUMBER
         ) RETURN NUMBER;

-- This function returns  the currency code for an elemen tgiven its name and bg
FUNCTION get_elem_input_currency_code (
           p_business_group_id IN NUMBER
         , p_effective_date    IN DATE
         , p_element_name      IN VARCHAR2                                      
         ) RETURN VARCHAR2;  

-- This function returns  the currency code for emp's salary element
FUNCTION get_emp_sal_currency_code (
           p_assignment_id     IN NUMBER
         , p_effective_date    IN DATE
         ) RETURN VARCHAR2;
         
--Fetches a table value from a different BG
FUNCTION get_table_value_in_bg (
           p_effective_date    IN DATE
         , p_business_group_id IN NUMBER
         , p_table_name        IN VARCHAR2
         , p_column_name       IN VARCHAR2
         , p_row_value         IN VARCHAR2
         ) RETURN VARCHAR2;                                              

--debug function to dbms_output
FUNCTION pl (p_msg IN VARCHAR2) RETURN NUMBER;                     

END XXHA_FF_UTILITIES_V2;
/


CREATE OR REPLACE PACKAGE BODY      XXHA_FF_UTILITIES_V2 AS

-- ======================================================================+
-- ======================================================================+
--
-- PROGRAM NAME  : XXHA_FF_UTILITIES_V2
--
-- Description   : The package contains functions used by CWB fast formulas
-- Change History:
-- ---------------
-- Version Date        Author          Remarks
-- ------- ----------- --------------- ---------------
-- 1.0     04-Jan-2010  Kbace          Initial Version
-- 1.1     27-Jan-2010  Kbace             Revision Based on Deceased Employees
-- 1.2     24-Feb-2011  Dave Lund      Changed date on individual calc to use year end date
--                                     Removed hard coding for sales org this is now in elig profile    
-- 1.3     30-Apr-2014  Ram Pudupet (DI) Procs to support 2014 CWB rollout in R12
-- ======================================================================+

-- This function evaluates the new hire eligibility

FUNCTION check_new_hire_elig (
                              p_assignment_id NUMBER,
                              p_effective_date  DATE
                              ) 
RETURN varchar2 is

CURSOR get_hire_date (c_assignment_id NUMBER
                     ,c_effective_date DATE)
IS
SELECT pps.date_start
FROM per_periods_of_service pps, per_all_assignments_f asg
WHERE c_effective_date BETWEEN asg.effective_start_date AND asg.effective_end_date
AND   pps.actual_termination_date IS NULL
AND   asg.person_id = pps.person_id
AND   asg.assignment_id = c_assignment_id;

CURSOR get_country_code (c_assignment_id number
                        ,c_effective_date date)
IS
SELECT loc.country
FROM hr_locations loc, per_all_assignments_f asg
WHERE asg.location_id = loc.location_id
AND  c_effective_date BETWEEN asg.effective_start_date AND asg.effective_end_date
AND asg.assignment_id = c_assignment_id;                        

l_year varchar2(4);
l_merit_elig_dt_chr varchar2(6);
l_merit_elig_dt date;
l_hire_date date;
l_business_group_id number;
l_country_code varchar2(10);
l_hire_dt_exclude_list varchar2(200);

BEGIN


    -- set the corp business group

    select business_group_id
    into l_business_group_id
    from per_business_groups
    where name = 'BG_US';
   
    -- get the country code based on the location
    
    OPEN get_country_code (p_assignment_id,p_effective_date);
    FETCH get_country_code INTO l_country_code;
    CLOSE get_country_code;
    
    -- pad the country code with commas
    
    l_country_code := ','||l_country_code||',';
    
    -- get the list of countries to be excluded from the hire date validation 
    
    SELECT global_value
    INTO l_hire_dt_exclude_list
    FROM ff_globals_f 
    WHERE p_effective_date BETWEEN effective_start_date AND effective_end_date
    AND   business_group_id = l_business_group_id
    AND GLOBAL_NAME LIKE 'HAE_CWB_ELIG_DATE_EXCEPTION';

    -- replace any extra spaces from the list of countries stored in the global value 
    
    l_hire_dt_exclude_list := replace(l_hire_dt_exclude_list,' ',''); 

    -- if the country code exists in the list to be excluded then return Y else evaluate the hire date logic

    IF INSTR(l_hire_dt_exclude_list,l_country_code) > 0 THEN
    
        RETURN 'Y';
    
    ELSE

    -- set the year

        l_year := to_char(p_effective_date,'YYYY');

    -- get the hire date cutoff stored in DD-MON format from the global value 
    
        SELECT global_value
        INTO l_merit_elig_dt_chr
        FROM ff_globals_f 
        WHERE p_effective_date BETWEEN effective_start_date AND effective_end_date
        AND   business_group_id = l_business_group_id
        AND GLOBAL_NAME LIKE 'HAE_CWB_MERIT_BON_ELIG_DATE';

    -- set the merit elig date
     
        l_merit_elig_dt := to_date (l_merit_elig_dt_chr||'-'||l_year,'DD-MON-YYYY');

    -- get the hire date for the person being evaluated
    
        OPEN get_hire_date (p_assignment_id,p_effective_date);
        FETCH get_hire_date INTO l_hire_date;
        CLOSE get_hire_date;

    -- IF hire date on or after the merit elig date, then return N else return Y

        IF l_hire_date >= l_merit_elig_dt THEN

            RETURN 'N';

        ELSE

            RETURN 'Y';

        END IF;
        
    END IF;    

    RETURN 'Y';


END check_new_hire_elig;
                     

-- This function returns the prorated salary for merit plan

FUNCTION get_prorated_salary (
                              p_assignment_id NUMBER,
                              p_effective_date   DATE
                              ) 
RETURN number is

cursor get_person_xtra_info (c_assignment_id number,
                             c_effective_date date
                             )
is 
SELECT pei_information1 
FROM per_people_extra_info pei, per_all_assignments_f asg  
WHERE information_type LIKE 'HAE_CWB_PRORATE_MERIT'
and asg.person_id = pei.person_id
and c_effective_date between asg.effective_start_date and asg.effective_end_date
and asg.assignment_id = c_assignment_id;

cursor c_salary is    
    select round(pp.proposed_salary_n,2) proposed_salary_n
    from   per_all_assignments_f paf
          ,per_pay_proposals pp
    where  pp.assignment_id = paf.assignment_id    
    and    paf.assignment_id = p_assignment_id
    and    pp.date_to between paf.effective_start_date and paf.effective_end_date
    and    p_effective_date between pp.change_date and pp.date_to; 

CURSOR get_hire_date (c_assignment_id NUMBER
                     ,c_effective_date DATE)
IS
SELECT pps.date_start
FROM per_periods_of_service pps, per_all_assignments_f asg
WHERE c_effective_date BETWEEN asg.effective_start_date AND asg.effective_end_date
AND   pps.actual_termination_date IS NULL
AND   asg.person_id = pps.person_id
AND   asg.assignment_id = c_assignment_id;

CURSOR get_fin_yr_dates
is
select min(glp1.start_date) fin_yr_start_date,max(glp2.end_date) fin_yr_end_date
from gl_periods glp1,gl_periods glp2
where glp1.period_set_name = 'HAE_GLOBAL_CAL'
and glp1.period_set_name = glp2.period_set_name 
and glp1.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'))
and glp2.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'));


l_year varchar2(4);
l_hire_date date;
l_fin_yrp_rec get_fin_yr_dates%ROWTYPE;
l_prrt_ovrride_flg VARCHAR2(1);
l_salary number;

l_fin_yr_end_dt date;

begin


-- get the financial year start and end dates

OPEN get_fin_yr_dates;
FETCH get_fin_yr_dates INTO l_fin_yrp_rec;
CLOSE get_fin_yr_dates;

-- get the hire date for the employee

OPEN get_hire_date (p_assignment_id,p_effective_date);
FETCH get_hire_date INTO l_hire_date;
CLOSE get_hire_date;

-- get the latest salary

open c_salary;
fetch c_salary into l_salary;
close c_salary;

-- if hired after the financial year start date, then check the eit 

IF l_hire_date >  l_fin_yrp_rec.fin_yr_start_date THEN

    OPEN get_person_xtra_info (p_assignment_id,p_effective_date);
    FETCH get_person_xtra_info INTO l_prrt_ovrride_flg;
    CLOSE get_person_xtra_info;

-- if the override flag is set then return the current salary
    
    IF l_prrt_ovrride_flg = 'Y' THEN
    
        RETURN l_salary;
        
    ELSE
    
-- if the override is not set, then calculate and return the number of months between financial year end date and hire date 

        IF to_number(to_char(l_hire_date,'DD')) <= 15 THEN 
        
            l_hire_date := trunc(l_hire_date,'MM'); 
            
        ELSE
        
            l_hire_date := last_day(l_hire_date)+1;
            
        END IF;
        
        IF to_number(to_char(l_fin_yrp_rec.fin_yr_end_date,'DD')) < 15 THEN 
        
            l_fin_yr_end_dt := trunc(l_fin_yrp_rec.fin_yr_end_date,'MM'); 
            
        ELSE
        
            l_fin_yr_end_dt := last_day(l_fin_yrp_rec.fin_yr_end_date)+1;
            
        END IF;
        
        RETURN (months_between (trunc(l_fin_yr_end_dt,'MM'),l_hire_date) * l_salary)/12;
    
    
    END IF;
    

ELSE     

-- return the current salary if hired prior to the financial year begin date

        RETURN l_salary;


END IF;

END get_prorated_salary; 


--this function returns the merit recommended amount 

FUNCTION get_mer_rec_amt (p_assignment_id number,
                          p_effective_date date)
RETURN NUMBER is

CURSOR get_country_code (c_assignment_id number
                        ,c_effective_date date)
IS
SELECT loc.country
FROM hr_locations loc, per_all_assignments_f asg
WHERE asg.location_id = loc.location_id
AND  c_effective_date BETWEEN asg.effective_start_date AND asg.effective_end_date
AND asg.assignment_id = c_assignment_id;


l_prorated_salary number;
l_rec_pct number;
l_business_group_id number;
l_country_code varchar2(10);

BEGIN

-- set the corporate business group

select business_group_id
into l_business_group_id
from per_business_groups
where name = 'BG_US';

-- get the country code

OPEN get_country_code (p_assignment_id,p_effective_date);
FETCH get_country_code INTO l_country_code;
CLOSE get_country_code;

-- get the prorated salary

l_prorated_salary := get_prorated_salary (p_assignment_id,p_effective_date);

-- get the percenatge from the user defined table

select nvl(hruserdt.get_table_value (l_business_group_id,'HAE_MERIT_REC_PCT','Percent',l_country_code,p_effective_date),0) 
into l_rec_pct
from dual; 

-- return the prorated salary

RETURN l_prorated_salary * l_rec_pct/100;  


END get_mer_rec_amt;                          


-- this function returns the prorated corporate component (bonus)

FUNCTION get_prorated_bonus_corp (
                              p_assignment_id NUMBER,
                              p_effective_date   DATE
                              ) 
RETURN number is

CURSOR get_fin_yr_dates
is
select min(glp1.start_date) fin_yr_start_date,max(glp2.end_date) fin_yr_end_date
from gl_periods glp1,gl_periods glp2
where glp1.period_set_name = 'HAE_GLOBAL_CAL'
and glp1.period_set_name = glp2.period_set_name 
and glp1.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'))
and glp2.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'));

 
cursor get_grade_info (c_assignment_id number, c_effective_start_date date)
is
select grd.name grade_name,asg.effective_start_date, asg.effective_end_date, 
       grd.grade_id,grd.attribute1 corp,grd.attribute2 region,grd.attribute4 ind,grd.attribute6 target
       ,pgp.segment1 pgp_region,asg.organization_id,typ.per_system_status, pgd.segment3 grade_segment
from   per_grades grd, per_all_assignments_f asg, pay_people_groups pgp, per_assignment_status_types typ,
       per_grade_definitions pgd
where  asg.grade_id = grd.grade_id 
and    asg.people_group_id = pgp.people_group_id
and    asg.assignment_status_type_id = typ.assignment_status_type_id
and    c_effective_start_date <= asg.effective_end_date
and    asg.assignment_id = c_assignment_id
and    asg.employment_category in ('FR','PR')
and    grd.grade_definition_id = pgd.grade_definition_id
order by asg.effective_end_date asc; 

cursor get_org_name (c_org_id number)
is
select org.name
from hr_all_organization_units org
where org.organization_id = c_org_id;

cursor get_hire_date (c_assignment_id number
                     ,c_effective_date date)
is
select pps.date_start
from per_periods_of_service pps, per_all_assignments_f asg
where c_effective_date between asg.effective_start_date and asg.effective_end_date
and   asg.person_id = pps.person_id
and   asg.assignment_id = c_assignment_id
order by pps.date_start desc;

cursor get_salary (c_assignment_id number, c_effective_date date)
is    
select round(pp.proposed_salary_n,2) salary,pp.change_date,pp.date_to
from   per_all_assignments_f paf
      ,per_pay_proposals pp
where  pp.assignment_id = paf.assignment_id    
and    paf.assignment_id = c_assignment_id
and    pp.approved = 'Y'
and    pp.date_to between paf.effective_start_date and paf.effective_end_date
and    c_effective_date <= pp.date_to
order by pp.change_date asc; 


CURSOR get_bonus_ovrr  
is 
SELECT to_number(pei_information5) 
FROM per_people_extra_info pei, per_all_assignments_f asg  
WHERE information_type LIKE 'HAE_EE_BONUS_VIEW'
and asg.person_id = pei.person_id
and pei_information3 like 'WW Non-Sales Bonus'
and p_effective_date between asg.effective_start_date and asg.effective_end_date
AND p_effective_date  between to_date(pei_information1,'YYYY/MM/DD HH24:MI:SS') and NVL(to_date(pei_information2,'YYYY/MM/DD HH24:MI:SS'),p_effective_date +1) 
and asg.assignment_id = p_assignment_id;


l_hire_date date;
l_num_of_months  number;
l_prorated_salary number;
l_target_bonus number;
l_corp_comp number;
l_sal_start_date date;
l_sal_end_date date;
l_business_group_id number;
l_corp_oi_hr_pct number;
l_corp_oi_fi_pct number;
l_corp_rev_hr_pct number;
l_corp_rev_fi_pct number;
l_merit_inc_dt_chr  varchar2(10);
l_merit_inc_dt date;
l_year varchar2(4);
l_bonus_override number;
i integer;

l_org_name hr_all_organization_units.name%TYPE;


l_fin_yrp_rec get_fin_yr_dates%ROWTYPE;
l_grade_info_rec get_grade_info%ROWTYPE;

BEGIN

-- set the corp business group

select business_group_id
into l_business_group_id
from per_business_groups
where name = 'BG_US';


--set the year for the salary

l_year := to_char(to_char(p_effective_date,'YYYY')-1);

-- get the date stored in DD-MON format

SELECT global_value
INTO l_merit_inc_dt_chr
FROM ff_globals_f 
WHERE p_effective_date BETWEEN effective_start_date AND effective_end_date
AND business_group_id = l_business_group_id
AND GLOBAL_NAME LIKE 'HAE_CWB_SAL_DTE_FOR_BON_PLAN';

-- set the date as of which salary should be evaluated

l_merit_inc_dt := to_date (l_merit_inc_dt_chr||'-'||l_year,'DD-MON-YYYY');

-- get the financial year start and end dates

OPEN get_fin_yr_dates;
FETCH get_fin_yr_dates INTO l_fin_yrp_rec;
CLOSE get_fin_yr_dates;

-- get the hire date

OPEN get_hire_date (p_assignment_id,p_effective_date);
FETCH get_hire_date INTO l_hire_date;
CLOSE get_hire_date;

-- initialize the corp component

l_corp_comp := 0;

-- open the assignment changes cursor and loop through the records

FOR grd_rec in get_grade_info (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date))

LOOP


    l_num_of_months  := 0;
    l_prorated_salary := 0;
    l_target_bonus := 0;
     
-- open the sal cursor
    
    FOR sal_rec in get_salary (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date,l_merit_inc_dt))   

    LOOP

        l_sal_start_date := NULL;
        l_sal_end_date   := NULL; 

-- set the salary start date        
        
            IF sal_rec.change_date <= l_merit_inc_dt THEN
            
                l_sal_start_date := greatest (l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
                                            
            ELSE
        
                  l_sal_start_date := greatest(sal_rec.change_date,l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
            
            END IF;


-- set the sal end date

            IF to_number(to_char(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'DD')) < 15 THEN 
        
                l_sal_end_date := trunc(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'MM'); 
            
            ELSE
        
                l_sal_end_date := last_day(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date))+1;
            
            END IF;


-- adjust the salary start date

            IF to_number(to_char(l_sal_start_date,'DD')) <=15 THEN
            
                l_sal_start_date := trunc(l_sal_start_date,'MM');
                
            ELSE
            
                l_sal_start_date := last_day(l_sal_start_date)+1 ;
                
            END IF;    

-- get the number of months                

            l_num_of_months := greatest(months_between (l_sal_end_date,l_sal_start_date ),0);
            
            l_bonus_override := NULL;
            
-- get the bonus override if any

            OPEN get_bonus_ovrr;
            FETCH get_bonus_ovrr INTO l_bonus_override;
            CLOSE get_bonus_ovrr;
            
-- calculate the prorated salary

            l_prorated_salary := l_num_of_months/12 * NVL(l_bonus_override,sal_rec.salary);  
        
-- calculate the target bonus
            
            if l_bonus_override is null then

              l_target_bonus := l_prorated_salary * grd_rec.target/100;
            
            else
            
              l_target_bonus := l_prorated_salary;
              
            end if;  
            /*
            dbms_output.put_line('Prorated Salary1: ' || l_prorated_salary);
            dbms_output.put_line('Target Bonus2: ' || l_target_bonus);
            dbms_output.put_line('Grade Rec Target3: ' || grd_rec.target);
            dbms_output.put_line('Num of Months4: ' || l_num_of_months);
            dbms_output.put_line('Salary Start Date5: ' ||TO_CHAR(l_sal_start_date,'YYYYMMDD'));
            dbms_output.put_line('salary End Date6: ' ||TO_CHAR(l_sal_end_date,'YYYYMMDD'));
           */
-- get the organization name

            open get_org_name (grd_rec.organization_id);
            fetch get_org_name into l_org_name;
            close get_org_name;
            
-- zero out the target bonus for sales org

--            if l_org_name = 'Sales (6000)_HAE' or grd_rec.per_system_status = 'TERM_ASSIGN' then
            
--                l_target_bonus := 0;
                           
--            end if;
            
-- get the corp oi hr pct from the udt  

            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','Others','CORP_OI_HR_PCT',l_sal_end_date),0)
            into l_corp_oi_hr_pct
            from dual; 

            
-- get the corp oi fi pct from the udt
                    
            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','Others','CORP_OI_FI_PCT',l_sal_end_date),0)
            into l_corp_oi_fi_pct
            from dual;


-- get the rev hr pct from the udt

            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','Others','CORP_REV_FI_PCT',l_sal_end_date),0)
            into l_corp_rev_hr_pct
            from dual;

            
-- get the rev fi pct from the udt
            
            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','Others','CORP_REV_HR_PCT',l_sal_end_date),0)
            into l_corp_rev_fi_pct
            from dual;
            /*
            dbms_output.put_line('Target Bonus7: ' || l_target_bonus);
            dbms_output.put_line('Grade Rec corp7: ' || grd_rec.corp);
            dbms_output.put_line('OI HR PCT 7: ' || l_corp_oi_hr_pct);
            dbms_output.put_line('OI_FI_PCT 10: ' || l_corp_oi_fi_pct);
            dbms_output.put_line('REV_HR_PCT 11: ' || l_corp_rev_hr_pct);
            dbms_output.put_line('REV_FI_PCT 12: ' || l_corp_rev_fi_pct);
            dbms_output.put_line('Corp Component 13: ' || l_corp_comp);
           */

-- calculate the corp component            
            l_corp_comp := (l_target_bonus * grd_rec.corp/100) * ((l_corp_oi_hr_pct * l_corp_oi_fi_pct) + (l_corp_rev_hr_pct * l_corp_rev_fi_pct)) + l_corp_comp;
    
    END LOOP;

            
END LOOP;

-- return the corp component

RETURN round(l_corp_comp,2);

END get_prorated_bonus_corp;

-- this function returns the prorated regional component (Bonus)

function get_prorated_bonus_reg (
                              p_assignment_id number,
                              p_effective_date   date
                              ) 
return number is

cursor get_fin_yr_dates
is
select min(glp1.start_date) fin_yr_start_date,max(glp2.end_date) fin_yr_end_date
from gl_periods glp1,gl_periods glp2
where glp1.period_set_name = 'HAE_GLOBAL_CAL'
and glp1.period_set_name = glp2.period_set_name 
and glp1.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'))
and glp2.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'));


cursor get_grade_info (c_assignment_id number, c_effective_start_date date)
is
select grd.name grade_name,asg.effective_start_date, asg.effective_end_date, 
       grd.grade_id,grd.attribute1 corp,grd.attribute2 region,grd.attribute4 ind,grd.attribute6 target
       ,pgp.segment1 pgp_region,asg.organization_id,typ.per_system_status, pgd.segment3 grade_segment
from   per_grades grd, per_all_assignments_f asg, pay_people_groups pgp, per_assignment_status_types typ,
       per_grade_definitions pgd
where  asg.grade_id = grd.grade_id 
and    asg.people_group_id = pgp.people_group_id
and    asg.assignment_status_type_id = typ.assignment_status_type_id
and    c_effective_start_date <= asg.effective_end_date
and    asg.assignment_id = c_assignment_id
and    asg.employment_category in ('FR','PR')
and    grd.grade_definition_id = pgd.grade_definition_id
order by asg.effective_end_date asc; 


cursor get_org_name (c_org_id number)
is
select org.name
from hr_all_organization_units org
where org.organization_id = c_org_id;

cursor get_hire_date (c_assignment_id number
                     ,c_effective_date date)
is
select pps.date_start
from per_periods_of_service pps, per_all_assignments_f asg
where c_effective_date between asg.effective_start_date and asg.effective_end_date
and   asg.person_id = pps.person_id
and   asg.assignment_id = c_assignment_id
order by pps.date_start desc;


cursor get_salary (c_assignment_id number, c_effective_date date)
is    
select round(pp.proposed_salary_n,2) salary,pp.change_date,pp.date_to
from   per_all_assignments_f paf
      ,per_pay_proposals pp
where  pp.assignment_id = paf.assignment_id    
and    paf.assignment_id = c_assignment_id
and    pp.approved = 'Y'
and    pp.date_to between paf.effective_start_date and paf.effective_end_date
and    c_effective_date <= pp.date_to
order by pp.change_date asc; 


cursor get_bonus_ovrr  
is 
select to_number(pei_information5) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_EE_BONUS_VIEW'
and asg.person_id = pei.person_id
and pei_information3 like 'WW Non-Sales Bonus'
and p_effective_date between asg.effective_start_date and asg.effective_end_date
AND p_effective_date  between to_date(pei_information1,'YYYY/MM/DD HH24:MI:SS') and NVL(to_date(pei_information2,'YYYY/MM/DD HH24:MI:SS'),p_effective_date +1) 
and asg.assignment_id = p_assignment_id;


CURSOR get_ind_achmnt_pct  
is 
select to_number(pei_information9) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_BONUS_GLB'
and asg.person_id = pei.person_id
and pei_information1 = to_char(p_effective_date,'YYYY')
and pei_information1 = to_char(to_char(p_effective_date,'YYYY')-1) -- this needs to be changed after crp
and p_effective_date between asg.effective_start_date and asg.effective_end_date
and asg.assignment_id = p_assignment_id;


l_hire_date date;
l_num_of_months  number;
l_prorated_salary number;
l_target_bonus number;
l_reg_comp number;

l_reg_target number;

l_sal_start_date date;
l_sal_end_date date;
l_business_group_id number;
l_reg_oi_hr_pct number;
l_reg_oi_fi_pct number;
l_reg_rev_hr_pct number;
l_reg_rev_fi_pct number;

l_merit_inc_dt_chr  varchar2(10);
l_merit_inc_dt date;
l_year varchar2(4);
l_bonus_override number;
i integer;
l_org_name hr_all_organization_units.name%TYPE;

l_fin_yrp_rec get_fin_yr_dates%ROWTYPE;
l_grade_info_rec get_grade_info%ROWTYPE;

begin

-- set the corp business group

select business_group_id
into l_business_group_id
from per_business_groups
where name = 'BG_US';


--set the year for salary

l_year := to_char(to_char(p_effective_date,'YYYY')-1);

select global_value
into l_merit_inc_dt_chr
from ff_globals_f 
where p_effective_date between effective_start_date and effective_end_date
and business_group_id = l_business_group_id
and global_name like 'HAE_CWB_SAL_DTE_FOR_BON_PLAN';

-- set the merit increase date

l_merit_inc_dt := to_date (l_merit_inc_dt_chr||'-'||l_year,'DD-MON-YYYY');

-- get the financial year start and end dates

open get_fin_yr_dates;
fetch get_fin_yr_dates into l_fin_yrp_rec;
close get_fin_yr_dates;

-- get the hire date

open get_hire_date (p_assignment_id,p_effective_date);
fetch get_hire_date into l_hire_date;
close get_hire_date;

 
l_reg_comp := 0;

-- loop through the assignment changes 

for grd_rec in get_grade_info (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date))

loop

    l_num_of_months  := 0;
    l_prorated_salary := 0;
    l_target_bonus := 0;
  

-- loop through the salary changes cursor   
    
    for sal_rec in get_salary (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date,l_merit_inc_dt))   

    loop



        l_sal_start_date := NULL;
        l_sal_end_date   := NULL; 
        
-- set the record start date
        
            if sal_rec.change_date <= l_merit_inc_dt then
            
                l_sal_start_date := greatest (l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
            
                                
            else

                l_sal_start_date := greatest(sal_rec.change_date,l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
            
            end if;


-- set the salary end date 

            if to_number(to_char(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'DD')) < 15 then 
        
                l_sal_end_date := trunc(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'MM'); 
            
            else
        
                l_sal_end_date := last_day(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date))+1;
            
            end if;

-- set the salary end date

            if to_number(to_char(l_sal_start_date,'DD')) <=15 then
            
                l_sal_start_date := trunc(l_sal_start_date,'MM');
                
            else
            
                l_sal_start_date := last_day(l_sal_start_date)+1 ;
                
            end if;    

                
-- calculate the number of months between start and end dates

            l_num_of_months := greatest(months_between (l_sal_end_date,l_sal_start_date ),0);
            

-- get the bonus override

            l_bonus_override := NULL;
            
            open get_bonus_ovrr;
            fetch get_bonus_ovrr into l_bonus_override;
            close get_bonus_ovrr;
            
-- calculate the prorated salary

            l_prorated_salary := l_num_of_months/12 * NVL(l_bonus_override,sal_rec.salary);  

--calculate the target bonus            

            if l_bonus_override is null then

              l_target_bonus := l_prorated_salary * grd_rec.target/100;
            
            else
            
              l_target_bonus := l_prorated_salary;
              
            end if;  
            
-- get the organization name

            open get_org_name (grd_rec.organization_id);
            fetch get_org_name into l_org_name;
            close get_org_name;
            
-- zero out the target bonus for sales org

--            if l_org_name = 'Sales (6000)_HAE' or grd_rec.per_system_status = 'TERM_ASSIGN' then
            
--                l_target_bonus := 0;
                            
--            end if;
            
            
-- calculate the regular target

            l_reg_target := l_target_bonus * grd_rec.region/100; 
            

-- get region oi hr pct
            
            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','Others','BU_OI_HR_PCT',l_sal_end_date),0)
            into l_reg_oi_hr_pct
            from dual; 

-- get region oi fi pct
            
            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','OI Payout PCT',grd_rec.pgp_region,l_sal_end_date),0)
            into l_reg_oi_fi_pct
            from dual;
            
-- get region rev hr pct

            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','Others','BU_REV_HR_PCT',l_sal_end_date),0)
            into l_reg_rev_hr_pct
            from dual;
            
-- get region rev fi pct

            select NVL(hruserdt.get_table_value (l_business_group_id,'HAE WW Bonus Table','Rev Payout PCT',grd_rec.pgp_region,l_sal_end_date),0)
            into l_reg_rev_fi_pct
            from dual;

-- calculate the region component

            l_reg_comp := l_reg_target * ((l_reg_oi_hr_pct * l_reg_oi_fi_pct) + (l_reg_rev_hr_pct * l_reg_rev_fi_pct)) + l_reg_comp;

            
    
    end loop;

            
end loop;

-- return the region component

return round(l_reg_comp,2);


end get_prorated_bonus_reg;

-- this function return the prorated individual component (Bonus)

function get_prorated_bonus_ind (
                              p_assignment_id number,
                              p_effective_date   date
                              ) 
return number is

cursor get_fin_yr_dates
is
select min(glp1.start_date) fin_yr_start_date,max(glp2.end_date) fin_yr_end_date
from gl_periods glp1,gl_periods glp2
where glp1.period_set_name = 'HAE_GLOBAL_CAL'
and glp1.period_set_name = glp2.period_set_name 
and glp1.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'))
and glp2.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'));


cursor get_grade_info (c_assignment_id number, c_effective_start_date date)
is
select grd.name grade_name,asg.effective_start_date, asg.effective_end_date, 
       grd.grade_id, nvl(to_number(grd.attribute1),0) corp, nvl(to_number(grd.attribute2),0) region, nvl(to_number(grd.attribute4),0) ind, nvl(to_number(grd.attribute6),0) target
       ,pgp.segment1 pgp_region,asg.organization_id,typ.per_system_status, pgd.segment3 grade_segment
from   per_grades grd, per_all_assignments_f asg, pay_people_groups pgp, per_assignment_status_types typ,
       per_grade_definitions pgd
where  asg.grade_id = grd.grade_id 
and    asg.people_group_id = pgp.people_group_id
and    asg.assignment_status_type_id = typ.assignment_status_type_id
and    c_effective_start_date <= asg.effective_end_date
and    asg.assignment_id = c_assignment_id
and    asg.employment_category in ('FR','PR')
and    grd.grade_definition_id = pgd.grade_definition_id
order by asg.effective_end_date asc; 

cursor get_org_name (c_org_id number)
is
select org.name
from hr_all_organization_units org
where org.organization_id = c_org_id;


cursor get_hire_date (c_assignment_id number
                     ,c_effective_date date)
is
select pps.date_start
from per_periods_of_service pps, per_all_assignments_f asg
where c_effective_date between asg.effective_start_date and asg.effective_end_date
and   asg.person_id = pps.person_id
and   asg.assignment_id = c_assignment_id
order by pps.date_start desc;

cursor get_salary (c_assignment_id number, c_effective_date date)
is    
select round(pp.proposed_salary_n,2) salary,pp.change_date,pp.date_to
from   per_all_assignments_f paf
      ,per_pay_proposals pp
where  pp.assignment_id = paf.assignment_id    
and    paf.assignment_id = c_assignment_id
and    pp.approved = 'Y'
and    pp.date_to between paf.effective_start_date and paf.effective_end_date
and    c_effective_date <= pp.date_to
order by pp.change_date asc; 


cursor get_bonus_ovrr  
is 
select to_number(pei_information5) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_EE_BONUS_VIEW'
and asg.person_id = pei.person_id
and pei_information3 like 'WW Non-Sales Bonus'
and p_effective_date between asg.effective_start_date and asg.effective_end_date
and p_effective_date  between to_date(pei_information1,'YYYY/MM/DD HH24:MI:SS') and NVL(to_date(pei_information2,'YYYY/MM/DD HH24:MI:SS'),p_effective_date +1) 
and asg.assignment_id = p_assignment_id;


CURSOR get_ind_achmnt_pct  
is 
select to_number(pei_information9) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_BONUS_GLB'
and asg.person_id = pei.person_id
and pei_information1 = to_char(p_effective_date,'YYYY')
and p_effective_date between asg.effective_start_date and asg.effective_end_date
and asg.assignment_id = p_assignment_id;


l_hire_date date;
l_num_of_months  number;
l_prorated_salary number;
l_target_bonus number;
l_ind_comp number;
l_ind_comp_guarantee number;
l_ind_achmnt_pct number;
l_ind_achmnt_amt number;
l_ind_target number;

l_sal_start_date date;
l_sal_end_date date;
l_business_group_id number;
l_corp_oi_fi_pct_ee number;
l_HAE_IND_FUND_PCT number;
l_merit_inc_dt_chr  varchar2(10);
l_merit_inc_dt date;
l_year varchar2(4);
l_bonus_override number;
i integer;
l_org_name hr_all_organization_units.name%TYPE;

l_fin_yrp_rec get_fin_yr_dates%ROWTYPE;
l_grade_info_rec get_grade_info%ROWTYPE;
j PLS_INTEGER := 0;

BEGIN

-- set the corp business group

select business_group_id
into l_business_group_id
from per_business_groups
where name = 'BG_US';


--set the date for salary

l_year := to_char(to_char(p_effective_date,'YYYY')-1);

select global_value
into l_merit_inc_dt_chr
from ff_globals_f 
where p_effective_date between effective_start_date and effective_end_date
and business_group_id = l_business_group_id
and global_name like 'HAE_CWB_SAL_DTE_FOR_BON_PLAN';

l_merit_inc_dt := to_date (l_merit_inc_dt_chr||'-'||l_year,'DD-MON-YYYY');

-- get the financial year start and end dates

open get_fin_yr_dates;
fetch get_fin_yr_dates into l_fin_yrp_rec;
close get_fin_yr_dates;

-- get the hire date

open get_hire_date (p_assignment_id,p_effective_date);
fetch get_hire_date into l_hire_date;
close get_hire_date;


l_ind_comp := 0;
l_ind_comp_guarantee := 0;

-- loop through the assignment changes
--dbms_output.put_line('get grade date: '||to_char(greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date),'DD-MON-YYYY'));
for grd_rec in get_grade_info (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date))

loop

    l_num_of_months  := 0;
    l_prorated_salary := 0;
    l_target_bonus := 0;
--    l_ind_comp := 0;
  

-- loop through the salary changes
--dbms_output.put_line('get salary date: '||to_char(greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date,l_merit_inc_dt),'DD-MON-YYYY'));
--dbms_output.put_line('asg effective start date: '||to_char(grd_rec.effective_start_date,'DD-MON-YYYY'));
--dbms_output.put_line('asg effective end date: '||to_char(grd_rec.effective_end_date,'DD-MON-YYYY'));
        
    for sal_rec in get_salary (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date,l_merit_inc_dt))   


    loop

        j := j + 1;
        l_sal_start_date := NULL;
        l_sal_end_date   := NULL; 
        
-- set the salary start date

--dbms_output.put_line('salary change date: '||to_char(sal_rec.change_date,'D-MON-YYYY'));
--dbms_output.put_line('merit inc date: '||to_char(l_merit_inc_dt,'D-MON-YYYY'));

            if sal_rec.change_date <= l_merit_inc_dt then
            
                l_sal_start_date := greatest (l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
            
                                
            else
        
                  l_sal_start_date := greatest(sal_rec.change_date,l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
            
            end if;
--dbms_output.put_line('salary start date: '||to_char(l_sal_start_date,'D-MON-YYYY'));
-- set the salary end date

            if to_number(to_char(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'DD')) < 15 then 
        
                l_sal_end_date := trunc(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'MM'); 
            
            else
        
                l_sal_end_date := last_day(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date))+1;
            
            end if;

--dbms_output.put_line('salary end date: '||to_char(l_sal_end_date,'D-MON-YYYY'));

-- adjust the salary start date

            if to_number(to_char(l_sal_start_date,'DD')) <=15 then
            
                l_sal_start_date := trunc(l_sal_start_date,'MM');
                
            else
            
                l_sal_start_date := last_day(l_sal_start_date)+1 ;
                
            end if;    

--dbms_output.put_line('salary start date: '||to_char(l_sal_start_date,'D-MON-YYYY'));

-- calculate the number of months                

            l_num_of_months := greatest(months_between (l_sal_end_date,l_sal_start_date ),0);

--dbms_output.put_line('num of months: '||to_char(l_num_of_months));

-- set the bonus override if any
            
            l_bonus_override := NULL;
            
            open get_bonus_ovrr;
            fetch get_bonus_ovrr into l_bonus_override;
            close get_bonus_ovrr;
            
--dbms_output.put_line('l_bonus_override: '||to_char(l_bonus_override));            
-- calculate the prorated salary 

            l_prorated_salary := l_num_of_months/12 * NVL(l_bonus_override,sal_rec.salary);  
--dbms_output.put_line('l_prorated_salary: '||to_char(l_prorated_salary));            
            
-- calculate the target bonus
            
            if l_bonus_override is null then

              l_target_bonus := l_prorated_salary * grd_rec.target/100;
            
            else
            
              l_target_bonus := l_prorated_salary;
              
            end if;  
--dbms_output.put_line('l_target_bonus: '||to_char(l_target_bonus));            
            
-- get the organization name

            open get_org_name (grd_rec.organization_id);
            fetch get_org_name into l_org_name;
            close get_org_name;
            
-- zero out the target bonus for sales org

--            if l_org_name = 'Sales (6000)_HAE' or grd_rec.per_system_status = 'TERM_ASSIGN' then
            
--                l_target_bonus := 0;
                            
--            end if;
            
--dbms_output.put_line('l_org_name: '||l_org_name);            
--dbms_output.put_line('l_target_bonus: '||to_char(l_target_bonus));            
            
-- calculate the individual target

            l_ind_target := l_target_bonus * grd_rec.ind/100; 
            /*
            -- now set the guaranteed amount
            if grd_rec.grade_segment in (
              '01','02','03','04','05','06','07','08','09','10',
              '11','12','13','14','15','16','17','18','19','20',
              '21','22','23','24','25','26','27'
              ) then
              l_ind_comp_guarantee := (l_ind_target * 50/100) + l_ind_comp_guarantee;
            else
              l_ind_comp_guarantee := (l_ind_target * 25/100) + l_ind_comp_guarantee;
            end if;
            */
            
--dbms_output.put_line('l_ind_target: '||to_char(l_ind_target));            

-- fetch the individual achievement percentage
            
            open get_ind_achmnt_pct;
            fetch get_ind_achmnt_pct into l_ind_achmnt_pct;
            close get_ind_achmnt_pct;
            
-- calculate the individual ach amount 
--dbms_output.put_line('l_ind_achmnt_pct: '||to_char(l_ind_achmnt_pct));            
                
            l_ind_achmnt_amt := l_ind_target * NVL(l_ind_achmnt_pct,100)/100;
    
            dbms_output.put_line(j || ': Grade Name: ' || grd_rec.grade_name);
            dbms_output.put_line(j || ': Assignment Start: ' || TO_CHAR(grd_rec.effective_start_date,'YYYYMMDD'));
            dbms_output.put_line(j || ': Assignment End: ' || TO_CHAR(grd_rec.effective_end_date,'YYYYMMDD'));            
            dbms_output.put_line(j || ': Grade Rec Target: ' || grd_rec.target);
            dbms_output.put_line(j || ': Grade Rec Ind: ' || grd_rec.ind);
           
            
            dbms_output.put_line(j || ': Salary Eff Start Date: ' ||TO_CHAR(l_sal_start_date,'YYYYMMDD'));
            dbms_output.put_line(j || ': Salary Eff End Date: ' ||TO_CHAR(l_sal_end_date,'YYYYMMDD'));
            dbms_output.put_line(j || ': Num of Months: ' || l_num_of_months);

            dbms_output.put_line(j || ': Prorated Salary: ' || l_prorated_salary);
            dbms_output.put_line(j || ': Bonus Override: ' || l_bonus_override);                        
            dbms_output.put_line(j || ': Target Bonus: ' || l_target_bonus);
            dbms_output.put_line(j || ': Ind Target: ' || l_ind_target);
            
            dbms_output.put_line(j || ': Org Name: ' || l_org_name);
            
            dbms_output.put_line(j || ': Ind Achievement Pct: ' || l_ind_achmnt_pct);
            dbms_output.put_line(j || ': Ind Achievement Amt: ' || l_ind_achmnt_amt);
           
--dbms_output.put_line('l_ind_achmnt_amt: '||to_char(l_ind_achmnt_amt));            
-- get the ee corp oi fi percentage    

            select NVL(hruserdt.get_table_value 
              (l_business_group_id,'HAE WW Bonus Table','Others','CORP_OI_FI_PCT_EE',p_effective_date),0)--l_sal_end_date),0)
            into l_corp_oi_fi_pct_ee
            from dual;      
--dbms_output.put_line('l_corp_oi_fi_pct_ee: '||to_char(l_corp_oi_fi_pct_ee));            

-- get the HAE_IND_FUND_PCT percentage    

            select NVL(hruserdt.get_table_value 
              (l_business_group_id,'HAE WW Bonus Table','Others','HAE_IND_FUND_PCT',p_effective_date),0)--l_sal_end_date),0)
            into l_HAE_IND_FUND_PCT
            from dual;      
--dbms_output.put_line('l_HAE_IND_FUND_PCT: '||to_char(l_HAE_IND_FUND_PCT));            

-- if the corp component is non zero then set the multipler to 1 as the oi fi is already applied with corporate component

--            if grd_rec.corp > 0 then
--                 l_corp_oi_fi_pct_ee := 1; 
--            end if;     
        
-- calculate the individual component 

--            l_ind_comp := (l_ind_achmnt_amt * l_corp_oi_fi_pct_ee) + l_ind_comp;
--dbms_output.put_line('grd_rec.ind: '||to_char(grd_rec.ind));            
            
            dbms_output.put_line(j || ': CORP_OI_FI_PCT_EE: ' || l_corp_oi_fi_pct_ee);
            dbms_output.put_line(j || ': HAE_IND_FUND_PCT: ' || l_HAE_IND_FUND_pct);
           

            if grd_rec.ind < 100 then
                 l_ind_comp := ((l_ind_achmnt_amt * l_HAE_IND_FUND_PCT)) + l_ind_comp;
                 dbms_output.put_line(j || ': Ind Component Contr: ' || (l_ind_achmnt_amt * l_HAE_IND_FUND_PCT));

            else
                 l_ind_comp := (l_ind_achmnt_amt * l_corp_oi_fi_pct_ee) + l_ind_comp;
                 dbms_output.put_line(j || ': Ind Component Contr: ' || (l_ind_achmnt_amt * l_corp_oi_fi_pct_ee));
            end if;
--dbms_output.put_line('l_ind_comp: '||to_char(l_ind_comp));            

    end loop;

            
end loop;

-- return individual component

return round(GREATEST(l_ind_comp, l_ind_comp_guarantee),2);

end get_prorated_bonus_ind;

-- this function calculates the total prorated bonus

function get_prorated_bonus (
                              p_assignment_id number,
                              p_effective_date   date
                              )
return number is

l_corp_comp number := 0;
l_reg_comp number := 0;
l_ind_comp number := 0;

l_prorated_bonus number :=0;

begin

-- get the corp component
l_corp_comp := get_prorated_bonus_corp (
                              p_assignment_id,
                              p_effective_date
                              );


-- get the regional component
l_reg_comp := get_prorated_bonus_reg (
                              p_assignment_id,
                              p_effective_date
                              );

--get the individual component                              
l_ind_comp := get_prorated_bonus_ind (
                              p_assignment_id,
                              p_effective_date
                              );
--return the prorated bonus
                                
l_prorated_bonus := ceil(nvl(l_corp_comp,0) + nvl(l_reg_comp,0) + nvl(l_ind_comp,0));                                                    

return l_prorated_bonus;

end get_prorated_bonus;

function get_bonus_prorated_salary (
                              p_assignment_id number,
                              p_effective_date   date
                              ) 
return number is

cursor get_fin_yr_dates
is
select min(glp1.start_date) fin_yr_start_date,max(glp2.end_date) fin_yr_end_date
from gl_periods glp1,gl_periods glp2
where glp1.period_set_name = 'HAE_GLOBAL_CAL'
and glp1.period_set_name = glp2.period_set_name 
and glp1.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'))
and glp2.PERIOD_YEAR = to_number(to_char(p_effective_date,'YYYY'));


cursor get_grade_info (c_assignment_id number, c_effective_start_date date)
is
select grd.name grade_name,asg.effective_start_date, asg.effective_end_date, 
       grd.grade_id, nvl(to_number(grd.attribute1),0) corp, nvl(to_number(grd.attribute2),0) region, nvl(to_number(grd.attribute4),0) ind, nvl(to_number(grd.attribute6),0) target
       ,pgp.segment1 pgp_region,asg.organization_id,typ.per_system_status, pgd.segment3 grade_segment
from   per_grades grd, per_all_assignments_f asg, pay_people_groups pgp, per_assignment_status_types typ,
       per_grade_definitions pgd
where  asg.grade_id = grd.grade_id 
and    asg.people_group_id = pgp.people_group_id
and    asg.assignment_status_type_id = typ.assignment_status_type_id
and    c_effective_start_date <= asg.effective_end_date
and    asg.assignment_id = c_assignment_id
and    asg.employment_category in ('FR','PR')
and    grd.grade_definition_id = pgd.grade_definition_id
order by asg.effective_end_date asc; 

cursor get_org_name (c_org_id number)
is
select org.name
from hr_all_organization_units org
where org.organization_id = c_org_id;


cursor get_hire_date (c_assignment_id number
                     ,c_effective_date date)
is
select pps.date_start
from per_periods_of_service pps, per_all_assignments_f asg
where c_effective_date between asg.effective_start_date and asg.effective_end_date
and   asg.person_id = pps.person_id
and   asg.assignment_id = c_assignment_id
order by pps.date_start desc;

cursor get_salary (c_assignment_id number, c_effective_date date)
is    
select round(pp.proposed_salary_n,2) salary,pp.change_date,pp.date_to
from   per_all_assignments_f paf
      ,per_pay_proposals pp
where  pp.assignment_id = paf.assignment_id    
and    paf.assignment_id = c_assignment_id
and    pp.approved = 'Y'
and    pp.date_to between paf.effective_start_date and paf.effective_end_date
and    c_effective_date <= pp.date_to
order by pp.change_date asc; 


cursor get_bonus_ovrr  
is 
select to_number(pei_information5) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_EE_BONUS_VIEW'
and asg.person_id = pei.person_id
and pei_information3 like 'WW Non-Sales Bonus'
and p_effective_date between asg.effective_start_date and asg.effective_end_date
and p_effective_date  between to_date(pei_information1,'YYYY/MM/DD HH24:MI:SS') and NVL(to_date(pei_information2,'YYYY/MM/DD HH24:MI:SS'),p_effective_date +1) 
and asg.assignment_id = p_assignment_id;


CURSOR get_ind_achmnt_pct  
is 
select to_number(pei_information9) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_BONUS_GLB'
and asg.person_id = pei.person_id
and pei_information1 = to_char(p_effective_date,'YYYY')
and p_effective_date between asg.effective_start_date and asg.effective_end_date
and asg.assignment_id = p_assignment_id;


l_hire_date date;
l_num_of_months  number;
l_prorated_salary number;
l_target_bonus number;
l_ind_comp number;
l_ind_comp_guarantee number;
l_ind_achmnt_pct number;
l_ind_achmnt_amt number;
l_ind_target number;
l_total_prorated_salary number;

l_sal_start_date date;
l_sal_end_date date;
l_business_group_id number;
l_corp_oi_fi_pct_ee number;
l_HAE_IND_FUND_PCT number;
l_merit_inc_dt_chr  varchar2(10);
l_merit_inc_dt date;
l_year varchar2(4);
l_bonus_override number;
i integer;
l_org_name hr_all_organization_units.name%TYPE;

l_fin_yrp_rec get_fin_yr_dates%ROWTYPE;
l_grade_info_rec get_grade_info%ROWTYPE;
j PLS_INTEGER := 0;

BEGIN

-- set the corp business group

select business_group_id
into l_business_group_id
from per_business_groups
where name = 'BG_US';


--set the date for salary

l_year := to_char(to_char(p_effective_date,'YYYY')-1);

select global_value
into l_merit_inc_dt_chr
from ff_globals_f 
where p_effective_date between effective_start_date and effective_end_date
and business_group_id = l_business_group_id
and global_name like 'HAE_CWB_SAL_DTE_FOR_BON_PLAN';

l_merit_inc_dt := to_date (l_merit_inc_dt_chr||'-'||l_year,'DD-MON-YYYY');

-- get the financial year start and end dates

open get_fin_yr_dates;
fetch get_fin_yr_dates into l_fin_yrp_rec;
close get_fin_yr_dates;

-- get the hire date

open get_hire_date (p_assignment_id,p_effective_date);
fetch get_hire_date into l_hire_date;
close get_hire_date;

l_total_prorated_salary := 0;

-- loop through the assignment changes
--dbms_output.put_line('get grade date: '||to_char(greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date),'DD-MON-YYYY'));
for grd_rec in get_grade_info (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date))

loop

    l_num_of_months  := 0;
    l_prorated_salary := 0;
    l_target_bonus := 0;
--    l_ind_comp := 0;
  

-- loop through the salary changes
--dbms_output.put_line('get salary date: '||to_char(greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date,l_merit_inc_dt),'DD-MON-YYYY'));
--dbms_output.put_line('asg effective start date: '||to_char(grd_rec.effective_start_date,'DD-MON-YYYY'));
--dbms_output.put_line('asg effective end date: '||to_char(grd_rec.effective_end_date,'DD-MON-YYYY'));
        
    for sal_rec in get_salary (p_assignment_id, greatest(l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date,l_merit_inc_dt))   


    loop

        j := j + 1;
        l_sal_start_date := NULL;
        l_sal_end_date   := NULL; 
        
-- set the salary start date

--dbms_output.put_line('salary change date: '||to_char(sal_rec.change_date,'D-MON-YYYY'));
--dbms_output.put_line('merit inc date: '||to_char(l_merit_inc_dt,'D-MON-YYYY'));

            if sal_rec.change_date <= l_merit_inc_dt then
            
                l_sal_start_date := greatest (l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
            
                                
            else
        
                  l_sal_start_date := greatest(sal_rec.change_date,l_fin_yrp_rec.fin_yr_start_date,l_hire_date,grd_rec.effective_start_date);
            
            end if;
--dbms_output.put_line('salary start date: '||to_char(l_sal_start_date,'D-MON-YYYY'));
-- set the salary end date

            if to_number(to_char(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'DD')) < 15 then 
        
                l_sal_end_date := trunc(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date),'MM'); 
            
            else
        
                l_sal_end_date := last_day(least(sal_rec.date_to,l_fin_yrp_rec.fin_yr_end_date,grd_rec.effective_end_date))+1;
            
            end if;

--dbms_output.put_line('salary end date: '||to_char(l_sal_end_date,'D-MON-YYYY'));

-- adjust the salary start date

            if to_number(to_char(l_sal_start_date,'DD')) <=15 then
            
                l_sal_start_date := trunc(l_sal_start_date,'MM');
                
            else
            
                l_sal_start_date := last_day(l_sal_start_date)+1 ;
                
            end if;    

--dbms_output.put_line('salary start date: '||to_char(l_sal_start_date,'D-MON-YYYY'));

-- calculate the number of months                

            l_num_of_months := greatest(months_between (l_sal_end_date,l_sal_start_date ),0);

--dbms_output.put_line('num of months: '||to_char(l_num_of_months));

-- set the bonus override if any
            
            l_bonus_override := NULL;
            
            open get_bonus_ovrr;
            fetch get_bonus_ovrr into l_bonus_override;
            close get_bonus_ovrr;
            
--dbms_output.put_line('l_bonus_override: '||to_char(l_bonus_override));            
-- calculate the prorated salary 

            l_prorated_salary := l_num_of_months/12 * NVL(l_bonus_override,sal_rec.salary);  
--dbms_output.put_line('l_prorated_salary: '||to_char(l_prorated_salary));            
            

            dbms_output.put_line(j || ': Grade Name: ' || grd_rec.grade_name);
            dbms_output.put_line(j || ': Assignment Start: ' || TO_CHAR(grd_rec.effective_start_date,'YYYYMMDD'));
            dbms_output.put_line(j || ': Assignment End: ' || TO_CHAR(grd_rec.effective_end_date,'YYYYMMDD'));            
            dbms_output.put_line(j || ': Salary Eff Start Date: ' ||TO_CHAR(l_sal_start_date,'YYYYMMDD'));
            dbms_output.put_line(j || ': Salary Eff End Date: ' ||TO_CHAR(l_sal_end_date,'YYYYMMDD'));
            dbms_output.put_line(j || ': Num of Months: ' || l_num_of_months);
            dbms_output.put_line(j || ': Base Salary: ' || sal_rec.salary);
            dbms_output.put_line(j || ': Bonus Override: ' || l_bonus_override);
            dbms_output.put_line(j || ': Prorated Salary: ' || l_prorated_salary);
                                
            l_total_prorated_salary := l_total_prorated_salary + l_prorated_salary;

    end loop;

            
end loop;

-- return total prorated salary

return round(l_total_prorated_salary,2);

end get_bonus_prorated_salary;

-- this function evaluates the loa eligibility

function get_loa_elig (p_assignment_id number
                      ,p_effective_date date
                      )
return varchar2 is

cursor get_asgt_status (c_assignment_id number
                       ,c_effective_date date
                       )
is
select typ.user_status
from per_assignment_status_types typ, per_all_assignments_f asg
where typ.assignment_status_type_id = asg.assignment_status_type_id
and     c_effective_date between asg.effective_start_date and asg.effective_end_date
and   asg.assignment_id = c_assignment_id;

cursor get_loa_rsn (c_assignment_id number
                   ,c_effective_date date
                   )
is
select  asg.change_reason
from    per_all_assignments_f asg
where   c_effective_date between asg.effective_start_date and asg.effective_end_date
and     asg.assignment_id = c_assignment_id;
                       
cursor get_country_code (c_assignment_id number
                        ,c_effective_date date)
is
select loc.country
from hr_locations loc, per_all_assignments_f asg
where asg.location_id = loc.location_id
and  c_effective_date between asg.effective_start_date and asg.effective_end_date
and asg.assignment_id = c_assignment_id;                        

                       

cursor c_lookup_values(c_effective_date date,
                       c_loa_rsn varchar2,
                       c_country_code varchar2
                       )
    is
    select 'Y'
    from fnd_lookup_values lkp
    where lookup_type like 'HAE_LOA_ELIG_LOOKUP'
    and lkp.attribute1 = c_loa_rsn
    and instr(lkp.attribute2,','||c_country_code||',') > 0
    and c_effective_date between lkp.start_date_active and nvl(lkp.end_date_active,c_effective_date +1)
    and lkp.enabled_flag = 'Y';
    
    
l_return varchar2(1);
l_country_code hr_locations.country%TYPE;
l_asg_status per_assignment_status_types.user_status%TYPE;
l_loa_rsn  fnd_lookup_values.lookup_code%TYPE;


begin

--get the assignemnt status

open get_asgt_status (p_assignment_id,p_effective_date);
fetch get_asgt_status into l_asg_status;
close get_asgt_status;

-- if on leave then

    if upper(l_asg_status) like 'LEAVE%' then

        -- check the loa reason in assingnent change reason
        
        open get_loa_rsn (p_assignment_id,p_effective_date);
        fetch get_loa_rsn into l_loa_rsn;
        close get_loa_rsn;
        
        l_return := 'N';
        
        open get_country_code (p_assignment_id,p_effective_date);
        fetch get_country_code into l_country_code;
        close get_country_code;
    
        
        open c_lookup_values (p_effective_date,l_loa_rsn,l_country_code);
        fetch c_lookup_values into l_return;
        close c_lookup_values;
        
        -- if match found then return Y, else return N                

        return nvl(l_return,'N');
        
            
    else
            

        return 'Y';

    end if;

end get_loa_elig;                       

-- returns the bonus target percentage stored in the grade segment 6 

function get_bonus_target_pct (p_assignment_id number
                      ,p_effective_date date
                      )
return number is                      


cursor get_target_bonus (c_assignment_id number, c_effective_date date)
is
select to_number(grd.attribute6) target
from   per_grades grd, per_all_assignments_f asg
where  asg.grade_id = grd.grade_id 
and    c_effective_date between asg.effective_start_date and  asg.effective_end_date
and    asg.assignment_id = c_assignment_id
and    asg.employment_category in ('FR','PR');
 
l_return number := 0;

begin

--fetch and return the target percentage

open get_target_bonus (p_assignment_id, p_effective_date);
fetch get_target_bonus into l_return;
close get_target_bonus;

return nvl(l_return,0);

end get_bonus_target_pct;


-- this function returns the bonus override amount 

function get_bonus_ovrd_amt (p_assignment_id number
                      ,p_effective_date date
                      )
return number is

cursor get_bonus_override_amt (c_assignment_id number,
                             c_effective_date date
                             )
is 
select to_number(pei_information5) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_EE_BONUS_VIEW'
and asg.person_id = pei.person_id
and pei_information3 like 'WW Non-Sales Bonus'
and c_effective_date between asg.effective_start_date and asg.effective_end_date
and c_effective_date  between to_date(pei_information1,'YYYY/MM/DD HH24:MI:SS') and NVL(to_date(pei_information2,'YYYY/MM/DD HH24:MI:SS'),c_effective_date +1) 
and asg.assignment_id = c_assignment_id;

cursor get_sales_bonus_amt (c_assignment_id number,
                             c_effective_date date
                             )
is 
select to_number(pei_information3) 
from per_people_extra_info pei, per_all_assignments_f asg  
where information_type like 'HAE_SALES_BONUS_GLB'
and asg.person_id = pei.person_id
and c_effective_date between asg.effective_start_date and asg.effective_end_date
and c_effective_date  between to_date(pei_information1,'YYYY/MM/DD HH24:MI:SS') and NVL(to_date(pei_information4,'YYYY/MM/DD HH24:MI:SS'),p_effective_date +1)
and asg.assignment_id = c_assignment_id;

l_bonus_ovrd_amt number;
l_sales_bonus_amt number;

begin

l_bonus_ovrd_amt := null;
l_sales_bonus_amt := null;

--fetch the bonus pverride amount 

    open  get_bonus_override_amt (p_assignment_id,p_effective_date);
    fetch get_bonus_override_amt into l_bonus_ovrd_amt;
    close get_bonus_override_amt;

-- fetch the sales bonus amount

    open  get_sales_bonus_amt (p_assignment_id,p_effective_date);
    fetch get_sales_bonus_amt into l_sales_bonus_amt;
    close get_sales_bonus_amt;

--return sales bonus amount, if null return bonus override amount

    return nvl(l_sales_bonus_amt,l_bonus_ovrd_amt);


end get_bonus_ovrd_amt;                       

--Fetches a table value from a different BG
FUNCTION get_table_value_in_bg (
           p_effective_date    IN DATE
         , p_business_group_id IN NUMBER
         , p_table_name        IN VARCHAR2
         , p_column_name       IN VARCHAR2
         , p_row_value         IN VARCHAR2
         ) RETURN VARCHAR2   
IS
  
BEGIN
  /*
  v := pl (p_business_group_id||':' ||
                          p_table_name||':' ||
                          p_column_name||':' ||
                          p_row_value||':' ||
                          TO_CHAR(p_effective_date, 'YYYYMMDDHH24MISS'));
  */                         
  RETURN hruserdt.get_table_value (
           p_bus_group_id   => p_business_group_id
         , p_table_name     => p_table_name
         , p_col_name       => p_column_name
         , p_row_value      => p_row_value
         , p_effective_date => p_effective_date
         );
END get_table_value_in_bg;

--This function returns the business group id for the group plan

FUNCTION get_group_pl_bg_id (
           p_effective_date IN DATE
         , p_pl_id          IN NUMBER
         ) RETURN NUMBER 
IS
    v_n_retval NUMBER := NULL;
    
    CURSOR csr_get_group_pl_bg_id
    IS
    SELECT NVL(gpl.business_group_id, pl.business_group_id)
    FROM   ben_pl_f pl, ben_pl_f gpl
    WHERE  TRUNC(p_effective_date) BETWEEN 
               pl.effective_start_date AND pl.effective_end_date
    AND    pl.pl_id = p_pl_id
    AND    pl.group_pl_id = gpl.pl_id(+)
    AND    TRUNC(p_effective_date) BETWEEN 
               gpl.effective_start_date(+) AND gpl.effective_end_date(+);
             
BEGIN
    OPEN  csr_get_group_pl_bg_id;
    FETCH csr_get_group_pl_bg_id INTO v_n_retval;
    CLOSE csr_get_group_pl_bg_id;
    
    RETURN v_n_retval;

END get_group_pl_bg_id;

-- This function returns  the currency code for an element given its name and bg
FUNCTION get_elem_input_currency_code (
           p_business_group_id IN NUMBER
         , p_effective_date    IN DATE
         , p_element_name      IN VARCHAR2                                      
         ) RETURN VARCHAR2
IS
    v_s_retval fnd_currencies.currency_code%TYPE := NULL;
  
    CURSOR csr_get_element_input_currency
    IS
    SELECT elt.input_currency_code
    FROM   pay_element_types_f elt
    WHERE  TRUNC(p_effective_date) BETWEEN 
               elt.effective_start_date AND elt.effective_end_date
    AND    elt.business_group_id = p_business_group_id
    AND    elt.element_name = p_element_name;
  
BEGIN
    
    OPEN  csr_get_element_input_currency;
    FETCH csr_get_element_input_currency INTO v_s_retval;
    CLOSE csr_get_element_input_currency;    
    
    RETURN v_s_retval;
END get_elem_input_currency_code;  

-- This function returns  the currency code for emp's salary element
FUNCTION get_emp_sal_currency_code (
           p_assignment_id     IN NUMBER
         , p_effective_date    IN DATE
         ) RETURN VARCHAR2
IS
    v_s_retval fnd_currencies.currency_code%TYPE := NULL;

    CURSOR csr_emp_salary_currency
    IS
    SELECT  pet.input_currency_code
    FROM    
            per_all_assignments_f                  asg
    ,       per_pay_bases                          ppb
    ,       pay_input_values_f                     piv
    ,       pay_element_types_f                    pet
    ,       pay_rates                              pr
    WHERE   p_effective_date BETWEEN 
               asg.effective_start_date AND asg.effective_end_date
    AND     asg.assignment_id                 = p_assignment_id
    AND     asg.primary_flag                  = 'Y'
    AND     asg.assignment_type IN ('E', 'C')
    AND     ppb.pay_basis_id               (+)= asg.pay_basis_id
    AND     piv.input_value_id             (+)= ppb.input_value_id
    AND     p_effective_date BETWEEN 
               NVL (piv.effective_start_date, p_effective_date) AND 
                  NVL (piv.effective_end_date, p_effective_date)
    AND     pet.element_type_id             (+)= piv.element_type_id
    AND     p_effective_date BETWEEN 
              NVL (pet.effective_start_date, p_effective_date) AND
                   NVL (pet.effective_end_date, p_effective_date)
    AND     pr.rate_id                      (+)= ppb.rate_id;       
 
  
BEGIN
    
    OPEN  csr_emp_salary_currency;
    FETCH csr_emp_salary_currency INTO v_s_retval;
    CLOSE csr_emp_salary_currency;    
    
    RETURN v_s_retval;
END get_emp_sal_currency_code;  

FUNCTION pl (p_msg IN VARCHAR2) RETURN NUMBER
IS
BEGIN
  DBMS_OUTPUT.PUT_LINE(TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') || 
                           '::::' ||p_msg);
  RETURN 0;
END pl;   

END XXHA_FF_UTILITIES_V2;
/
