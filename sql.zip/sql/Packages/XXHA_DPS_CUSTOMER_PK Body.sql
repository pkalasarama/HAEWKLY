create or replace PACKAGE BODY XXHA_DPS_CUSTOMER_PK AS

/*********************************************************************************************
* Package Name : XXHA_DPS_CUSTOMER_PK                                                        *
* Purpose      : This package provides functions to retrieve Contact, Title, Phone, Fax      *
*                 and Email Address.                                                         *
*                                                                                            *
* Used By      : View XXHA_DPS_CUSTOMER_V                                                    *
*                                                                                            *
* PROCEDURE    : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        04-MAY-2016     B. Marcoux           Initial Package Creation                   *
*                                                                                            *
*********************************************************************************************/

FUNCTION PROCESS_DATA (
                        p_Cust_Account_Id      IN  NUMBER
                      , p_object_id            IN  NUMBER
                      , p_cust_acct_site_id    IN  NUMBER
                      , p_Index                IN  NUMBER
                      ) RETURN VARCHAR2 IS

l_Cust_Account_Id                   hz_cust_accounts.Cust_Account_Id%TYPE;
l_cust_acct_site_id                 hz_cust_acct_sites_all.cust_acct_site_id%TYPE;
l_rel_party_id                      hz_parties.party_id%TYPE;                        
l_subject_id                        hz_relationships.subject_id%TYPE;
l_object_id                         hz_relationships.object_id%TYPE;

l_contact_first_name                HZ_parties.person_first_name%TYPE;               
l_contact_middle_name               HZ_parties.person_middle_name%TYPE;
l_contact_last_name                 HZ_parties.person_last_name%TYPE;
l_contact_suffix                    HZ_parties.person_name_suffix%TYPE;
l_contact_title                     hz_org_contacts.job_title%TYPE;

l_contact_email                     hz_contact_points.Email_Address%TYPE;
l_PHONE                             VARCHAR(2500):= NULL;
l_FAX                               VARCHAR(2500):= NULL;
l_DATA                              VARCHAR(2500):= NULL;

l_last_update_date_contact          hz_parties.last_update_date%TYPE            := NULL;
l_last_update_date_email            hz_contact_points.last_update_date%TYPE     := NULL;
l_last_update_date_phone            hz_contact_points.last_update_date%TYPE     := NULL;
l_last_update_date_fax              hz_contact_points.last_update_date%TYPE     := NULL;

-- Find most recent Contact
CURSOR cur_1 (p_Cust_Account_Id hz_cust_accounts.Cust_Account_Id%TYPE, p_object_id hz_relationships.object_id%TYPE, p_cust_acct_site_id hz_cust_acct_sites_all.cust_acct_site_id%TYPE)
IS
SELECT
    party.person_first_name                  contact_first_name
  , party.person_middle_name                 contact_middle_name
  , party.person_last_name                   contact_last_name
  , party.person_name_suffix                 contact_suffix
  , org_cont.job_title                       contact_job_title
  , rel.subject_id
  , rel.object_id
  , rel_party.party_id                       rel_party_id
  , party.last_update_date
FROM    
    hz_cust_account_roles                    acct_role
  , hz_parties                               party
  , hz_parties                               rel_party
  , hz_relationships                         rel
  , hz_org_contacts                          org_cont
  , hz_cust_accounts                         role_acct
  , hz_contact_restrictions                  cont_res
  , hz_cust_acct_sites_all                   hcasa
WHERE   
    acct_role.party_id                     = rel.party_id
and acct_role.role_type                    = 'CONTACT'
and org_cont.party_relationship_id         = rel.relationship_id
and rel.subject_id                         = party.party_id
and rel_party.party_id                     = rel.party_id
AND acct_role.cust_account_id              = p_Cust_Account_Id
and acct_role.cust_account_id              = role_acct.cust_account_id
and role_acct.party_id                     = rel.object_id
AND rel.object_id                          = p_object_id
and party.party_id                         = cont_res.subject_id(+)
and cont_res.subject_table(+)              = 'HZ_PARTIES'
and role_acct.cust_account_id              = hcasa.cust_account_id
and hcasa.cust_acct_site_id                = acct_role.cust_acct_site_id
AND acct_role.cust_acct_site_id            = p_cust_acct_site_id
AND nvl(org_cont.STATUS,'A')               = 'A'
AND PARTY.STATUS                           = 'A'
AND rel_party.STATUS                       = 'A'
AND role_acct.STATUS                       = 'A'
AND ACCT_ROLE.CURRENT_ROLE_STATE           = 'A'
order by
    party.creation_date desc
;

-- Retrieve EMail Address
CURSOR cur_2 (p_Cust_Account_Id hz_cust_accounts.Cust_Account_Id%TYPE, p_object_id hz_relationships.object_id%TYPE, p_cust_acct_site_id hz_cust_acct_sites_all.cust_acct_site_id%TYPE, p_rel_party_id hz_parties.party_id%TYPE)
IS
SELECT
    cont_point.Email_Address
  , cont_point.last_update_date
FROM    
    hz_contact_points                        cont_point
  , hz_cust_account_roles                    acct_role
  , hz_parties                               party
  , hz_parties                               rel_party
  , hz_relationships                         rel
  , hz_org_contacts                          org_cont
  , hz_cust_accounts                         role_acct
  , hz_contact_restrictions                  cont_res
  , hz_cust_acct_sites_all                   hcasa
WHERE   
    acct_role.party_id                     = rel.party_id
and acct_role.role_type                    = 'CONTACT'
and org_cont.party_relationship_id         = rel.relationship_id
and rel.subject_id                         = party.party_id
and rel_party.party_id                     = rel.party_id
and cont_point.owner_table_id(+)           = rel_party.party_id
AND rel_party.party_id                     = p_rel_party_id
and cont_point.contact_point_type(+)       in ('EMAIL')
AND cont_point.primary_flag                = 'Y'
AND acct_role.cust_account_id              = p_Cust_Account_Id
and acct_role.cust_account_id              = role_acct.cust_account_id
and role_acct.party_id                     = rel.object_id
AND rel.object_id                          = p_object_id
and party.party_id                         = cont_res.subject_id(+)
and cont_res.subject_table(+)              = 'HZ_PARTIES'
and role_acct.cust_account_id              = hcasa.cust_account_id
and hcasa.cust_acct_site_id                = acct_role.cust_acct_site_id
AND acct_role.cust_acct_site_id            = p_cust_acct_site_id
AND nvl(org_cont.STATUS,'A')               = 'A'
AND PARTY.STATUS                           = 'A'
AND rel_party.STATUS                       = 'A'
AND role_acct.STATUS                       = 'A'
;

-- Retrieve Phone Number
CURSOR cur_3 (p_Cust_Account_Id hz_cust_accounts.Cust_Account_Id%TYPE, p_object_id hz_relationships.object_id%TYPE, p_cust_acct_site_id hz_cust_acct_sites_all.cust_acct_site_id%TYPE, p_rel_party_id hz_parties.party_id%TYPE)
IS
SELECT
    LTRIM(RTRIM(TRANSLATE((cont_point.phone_area_code || ' ' || cont_point.phone_number || ' ' || cont_point.phone_extension), chr(1)||chr(2)||chr(3)||chr(4)||chr(5)||chr(6)||chr(7)||chr(8)||chr(9)||chr(11)||chr(12)||chr(13)||chr(14)||chr(15)||chr(16)||chr(17)||chr(18)||chr(19)||chr(20)||chr(21)||chr(22)||chr(23)||chr(24)||chr(25)||chr(26)||chr(27)||chr(28)||chr(29)||chr(30)||chr(31)||chr(127), ' ')))
  , cont_point.last_update_date
FROM    
    hz_contact_points                        cont_point
  , hz_cust_account_roles                    acct_role
  , hz_parties                               party
  , hz_parties                               rel_party
  , hz_relationships                         rel
  , hz_org_contacts                          org_cont
  , hz_cust_accounts                         role_acct
  , hz_contact_restrictions                  cont_res
  , hz_cust_acct_sites_all                   hcasa

WHERE   
    acct_role.party_id                     = rel.party_id
and acct_role.role_type                    = 'CONTACT'
and org_cont.party_relationship_id         = rel.relationship_id
and rel.subject_id                         = party.party_id
and rel_party.party_id                     = rel.party_id
and cont_point.owner_table_id(+)           = rel_party.party_id
AND rel_party.party_id                     = p_rel_party_id
and cont_point.contact_point_type(+)       in ('PHONE')
and cont_point.phone_line_type             in ('GEN')
AND cont_point.primary_flag                = 'Y'
AND acct_role.cust_account_id              = p_Cust_Account_Id
and acct_role.cust_account_id              = role_acct.cust_account_id
and role_acct.party_id                     = rel.object_id
AND rel.object_id                          = p_object_id
and party.party_id                         = cont_res.subject_id(+)
and cont_res.subject_table(+)              = 'HZ_PARTIES'
and role_acct.cust_account_id              = hcasa.cust_account_id
and hcasa.cust_acct_site_id                = acct_role.cust_acct_site_id
AND acct_role.cust_acct_site_id            = p_cust_acct_site_id
AND nvl(org_cont.STATUS,'A')               = 'A'
AND PARTY.STATUS                           = 'A'
AND rel_party.STATUS                       = 'A'
AND role_acct.STATUS                       = 'A'
;

-- Retrieve Fax Number
CURSOR cur_4 (p_Cust_Account_Id hz_cust_accounts.Cust_Account_Id%TYPE, p_object_id hz_relationships.object_id%TYPE, p_cust_acct_site_id hz_cust_acct_sites_all.cust_acct_site_id%TYPE, p_rel_party_id hz_parties.party_id%TYPE)
IS
SELECT
    LTRIM(RTRIM(TRANSLATE((cont_point.phone_area_code || ' ' || cont_point.phone_number || ' ' || cont_point.phone_extension), chr(1)||chr(2)||chr(3)||chr(4)||chr(5)||chr(6)||chr(7)||chr(8)||chr(9)||chr(11)||chr(12)||chr(13)||chr(14)||chr(15)||chr(16)||chr(17)||chr(18)||chr(19)||chr(20)||chr(21)||chr(22)||chr(23)||chr(24)||chr(25)||chr(26)||chr(27)||chr(28)||chr(29)||chr(30)||chr(31)||chr(127), ' ')))
  , cont_point.last_update_date
FROM    
    hz_contact_points                        cont_point
  , hz_cust_account_roles                    acct_role
  , hz_parties                               party
  , hz_parties                               rel_party
  , hz_relationships                         rel
  , hz_org_contacts                          org_cont
  , hz_cust_accounts                         role_acct
  , hz_contact_restrictions                  cont_res
  , hz_cust_acct_sites_all                   hcasa
WHERE   
    acct_role.party_id                     = rel.party_id
and acct_role.role_type                    = 'CONTACT'
and org_cont.party_relationship_id         = rel.relationship_id
and rel.subject_id                         = party.party_id
and rel_party.party_id                     = rel.party_id
and cont_point.owner_table_id(+)           = rel_party.party_id
AND rel_party.party_id                     = p_rel_party_id
and cont_point.contact_point_type(+)       in ('PHONE')
and cont_point.phone_line_type             in ('FAX')
AND acct_role.cust_account_id              = p_Cust_Account_Id
and acct_role.cust_account_id              = role_acct.cust_account_id
and role_acct.party_id                     = rel.object_id
AND rel.object_id                          = p_object_id
and party.party_id                         = cont_res.subject_id(+)
and cont_res.subject_table(+)              = 'HZ_PARTIES'
and role_acct.cust_account_id              = hcasa.cust_account_id
and hcasa.cust_acct_site_id                = acct_role.cust_acct_site_id
AND acct_role.cust_acct_site_id            = p_cust_acct_site_id
AND nvl(org_cont.STATUS,'A')               = 'A'
AND PARTY.STATUS                           = 'A'
AND rel_party.STATUS                       = 'A'
AND role_acct.STATUS                       = 'A'
ORDER BY
    cont_point.last_update_date desc
;

BEGIN

   -- Determine if a contact exists
   OPEN cur_1 (p_Cust_Account_Id, p_object_id, p_cust_acct_site_id);
   FETCH cur_1 INTO l_contact_first_name, l_contact_middle_name, l_contact_last_name, l_contact_suffix, l_contact_title, l_subject_id, l_object_id, l_rel_party_id, l_last_update_date_contact;

   -- If Contact exists, retrieve all attributes
   IF cur_1%FOUND THEN
      -- Retrieve EMail
      OPEN cur_2 (p_Cust_Account_Id, p_object_id, p_cust_acct_site_id, l_rel_party_id);
      FETCH cur_2 INTO l_contact_email, l_last_update_date_email;
      CLOSE cur_2;

      -- Retrieve Phone
      OPEN cur_3 (p_Cust_Account_Id, p_object_id, p_cust_acct_site_id, l_rel_party_id);
      FETCH cur_3 INTO l_PHONE, l_last_update_date_phone;
      CLOSE cur_3;

      -- Retrieve Fax
      OPEN cur_4 (p_Cust_Account_Id, p_object_id, p_cust_acct_site_id, l_rel_party_id);
      FETCH cur_4 INTO l_FAX, l_last_update_date_fax;
      CLOSE cur_4;

      IF p_Index = 1 THEN
         l_DATA := LTRIM((l_contact_first_name || ' ' || l_contact_last_name || ' ' || l_contact_suffix));
      ELSIF p_Index = 2 THEN
         l_DATA := (l_contact_title);
      ELSIF p_Index = 3 THEN
         l_DATA := (l_PHONE);
      ELSIF p_Index = 4 THEN
         l_DATA := (l_FAX);
      ELSIF p_Index = 5 THEN
         l_DATA := (l_contact_email);
      END IF;

   END IF;

   CLOSE cur_1;

   RETURN l_DATA;

END PROCESS_DATA;

END XXHA_DPS_CUSTOMER_PK;