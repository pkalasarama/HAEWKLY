CREATE OR REPLACE PACKAGE XXHA_GET_CUSTOMER_BALANCE_PKG AUTHID CURRENT_USER AS
 /* $Header: arxcobls.pls 120.3 2005/10/30 04:42:54 appldev ship $ */
/*************************************************************************************************************
* Package Name : XXHA_GET_CUSTOMER_BALANCE_PKG                                                               *
*                                                                                                            *
* Procedures   : ar_get_customer_balance                                                                     *
*                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)            *
* - XXHA_AR_CUSTOMER_BALANCE_ITF      U                                                                      *
* - hz_cust_accounts                  S                                                                      *
* - hz_parties party                  S                                                                      *
* - hz_cust_acct_sites                S                                                                      *
* - hz_party_sites                    S                                                                      *
* - hz_locations                      S                                                                      *
* - hz_cust_site_uses                 S                                                                      *
* - ar_payment_schedules              S                                                                      *
* - hr_all_organization_units         S                                                                      *
* - hr_operating_units                S                                                                      *
* - ar_system_parameters              S                                                                      *
* - fnd_languages                     S                                                                      *
* - gl_sets_of_books                  S                                                                      *
* - ar_receivable_applications        S                                                                      *
* - ar_adjustments                    S                                                                      *
* - ar_cash_receipts                  S                                                                      *
* - ar_cash_receipt_history           S                                                                      *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver        Date            Author                     Description                                          *
* ------     -----------     -----------------          ---------------                                      *
* 1.0        04-Oct-2012     Venkatesh Sarangam, Rolta  R12 Upgrade                                          *
* 1.1        07-May-2014     DBROWNE                    Fix for moac, R12 Upgrade                            *
*                                                                                                            *
**************************************************************************************************************/

g_org_id number := FND_PROFILE.VALUE('ORG_ID');

 procedure ar_get_customer_balance( p_request_id number
 				,p_set_of_books_id number
                                ,p_as_of_date in date
                                ,p_customer_name_from in varchar
                                ,p_customer_name_to in varchar
                                ,p_customer_number_low in varchar
                                ,p_customer_number_high in varchar
                                ,p_currency in varchar
                                ,p_min_invoice_balance in number
                                ,p_min_open_balance in number
                                ,p_account_credits varchar
                                ,p_account_receipts varchar
                                ,p_unapp_receipts varchar
                                ,p_uncleared_receipts varchar
                                ,p_ref_no in varchar
                                ,p_debug_flag in  varchar
                                ,p_trace_flag in varchar);

 end XXHA_GET_CUSTOMER_BALANCE_PKG;
/


CREATE OR REPLACE PACKAGE BODY      xxha_get_customer_balance_pkg
AS
   /* $Header: arxcoblb.pls 120.7 2005/08/18 06:38:36 salladi ship $ */
   /*------------------------------------------------------------------------------
   Procedure AR_GET_CUSTOMER_BALANCE calulates the customer balance
   based on the parameters entered. It then inserts one row for each invoice,
   credit memo, unapplied receipts,on account receipts and uncleared receipts
   used for calculating the customer balance into the table AR_CUSTOMER_BALANCE_ITF
   --------------------------------------------------------------------------------*/
   /* bug2466471 : Re-create PROCEDURE ar_get_customer_balance.
    At first, get amount_due_original of ps of transactions.
    After that, get application and adjustment information of which gl_date is earliner than p_as_of_date in order to get invoice balance as of p_as_of_date.
    Also, get unapplied and on-account receipts of which gl_date is earlier than p_as_of_date. (Of course, don't get application , unapplied and on-account information of uncleared receipt if p_uncleared_receipts is not 'Y'.)
    And get customer balance on basis of unapplied and on-account receipts and invoice balance as of p_as_of_date.
    Finally, insert these record into AR_CUSTOMER_BALANCE_ITF table.
   */
   /* bug 2657118 Changed the logic, instead of comparing as_of_date  with gl_date of
   transactions and as well as receipts , we'll now compare  as_of_date with trx_date and apply_date whatever may be applicable.
   */
   
/*************************************************************************************************************
* Package Name : XXHA_GET_CUSTOMER_BALANCE_PKG                                                               *
*                                                                                                            *
* Procedures   : ar_get_customer_balance                                                                     *
*                                                                                                            *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)            *
* - XXHA_AR_CUSTOMER_BALANCE_ITF      U                                                                      *
* - hz_cust_accounts                  S                                                                      *
* - hz_parties party                  S                                                                      *
* - hz_cust_acct_sites                S                                                                      *
* - hz_party_sites                    S                                                                      *
* - hz_locations                      S                                                                      *
* - hz_cust_site_uses                 S                                                                      *
* - ar_payment_schedules              S                                                                      *
* - hr_all_organization_units         S                                                                      *
* - hr_operating_units                S                                                                      *
* - ar_system_parameters              S                                                                      *
* - fnd_languages                     S                                                                      *
* - gl_sets_of_books                  S                                                                      *
* - ar_receivable_applications        S                                                                      *
* - ar_adjustments                    S                                                                      *
* - ar_cash_receipts                  S                                                                      *
* - ar_cash_receipt_history           S                                                                      *
*                                                                                                            *
* Change History                                                                                             *
*                                                                                                            *
* Ver        Date            Author                     Description                                          *
* ------     -----------     -----------------          ---------------                                      *
* 1.0        04-Oct-2012     Venkatesh Sarangam, Rolta  R12 Upgrade                                          *
* 1.1        07-May-2014     DBROWNE                    Fix for moac, R12 Upgrade                            *
*                                                                                                            *
**************************************************************************************************************/

   PROCEDURE ar_get_customer_balance (
      p_request_id             IN   NUMBER,
      p_set_of_books_id        IN   NUMBER,
      p_as_of_date             IN   DATE,
      p_customer_name_from     IN   VARCHAR,
      p_customer_name_to       IN   VARCHAR,
      p_customer_number_low    IN   VARCHAR,
      p_customer_number_high   IN   VARCHAR,
      p_currency               IN   VARCHAR,
      p_min_invoice_balance    IN   NUMBER,
      p_min_open_balance       IN   NUMBER,
      p_account_credits             VARCHAR,
      p_account_receipts            VARCHAR,
      p_unapp_receipts              VARCHAR,
      p_uncleared_receipts          VARCHAR,
      p_ref_no                      VARCHAR,
      p_debug_flag             IN   VARCHAR,
      p_trace_flag             IN   VARCHAR
   )
   IS
/* R12 Upgrade Modified on 10/04/2012 by Venkatesh Sarangam, Rolta */
/*l_organization_name gl_sets_of_books.name%type;
  l_functional_currency_code gl_sets_of_books.currency_code%TYPE;*/
      l_organization_name             gl_ledgers.NAME%TYPE;
      l_functional_currency_code      gl_ledgers.currency_code%TYPE;
      l_organization_loc_id           hr_all_organization_units.location_id%TYPE;
      l_session_language              VARCHAR2 (40);    /* For MLS changes */
      l_base_language                 VARCHAR2 (40);     /*For MLS  changes*/
      l_cus_open_bal                  NUMBER;
      l_inv_open_bal                  NUMBER;
      l_amount_adj                    NUMBER;
      l_amount_applied                NUMBER;
      l_earned_discount_taken         NUMBER;
      l_unearned_discount_taken       NUMBER;
      l_rev_amount_applied            NUMBER;
      l_rev_earned_discount_taken     NUMBER;
      l_rev_unearned_discount_taken   NUMBER;
      l_amount_credited               NUMBER;
      l_on_acct_receipts              NUMBER;
      l_unapp_receipts                NUMBER;
      l_rev_on_acct_receipts          NUMBER;
      l_rev_unapp_receipts            NUMBER;
      l_amount_applied_cm             NUMBER;                  /*bug4502121*/

      --  Selects the customer id in the given range of parameters
      CURSOR cusinfo
      IS
         SELECT cust_acct.cust_account_id customer_id,
                cust_acct.account_number, party.party_name,
                party.tax_reference
           FROM hz_cust_accounts cust_acct, hz_parties party
          WHERE cust_acct.party_id = party.party_id
            AND (   p_customer_name_from IS NULL
                 OR UPPER (party.party_name) >= UPPER (p_customer_name_from)
                )
            AND (   p_customer_name_to IS NULL
                 OR UPPER (party.party_name) <= UPPER (p_customer_name_to)
                )
            AND (   p_customer_number_low IS NULL
                 OR UPPER (cust_acct.account_number) >=
                                                 UPPER (p_customer_number_low)
                )
            AND (   p_customer_number_high IS NULL
                 OR UPPER (cust_acct.account_number) <=
                                                UPPER (p_customer_number_high)
                );

      CURSOR siteinfo (p_customer_id ar_payment_schedules.customer_id%TYPE)
      IS
         SELECT site_uses.site_use_id, acct_site.translated_customer_name,
                loc.address1, loc.address2, loc.address3, loc.address4,
                loc.city, loc.state, loc.postal_code, loc.country,
                loc.LANGUAGE
           FROM hz_cust_acct_sites acct_site,
                hz_party_sites party_site,
                hz_locations loc,
                hz_cust_site_uses site_uses
          WHERE acct_site.cust_account_id = p_customer_id
            AND NVL (acct_site.status, 'A') = 'A'
            AND acct_site.bill_to_flag IN ('Y', 'P')
            AND acct_site.party_site_id = party_site.party_site_id
            AND loc.location_id = party_site.location_id
            AND NVL (site_uses.status, 'A') = 'A'
            AND acct_site.cust_acct_site_id = site_uses.cust_acct_site_id
            AND site_uses.site_use_code = 'BILL_TO';

--       AND  nvl(loc.language,p_base_language)=p_session_language;
  --Selects all the currency for a customer site
      CURSOR curinfo (
         p_customer_id   ar_payment_schedules.customer_id%TYPE,
         p_site_use_id   ar_payment_schedules.customer_site_use_id%TYPE
      )
      IS
         SELECT DISTINCT (invoice_currency_code) currency_code
                    FROM ar_payment_schedules ps
                   WHERE ps.customer_id = p_customer_id
                     AND ps.customer_site_use_id = p_site_use_id
                     AND ps.invoice_currency_code =
                                    NVL (p_currency, ps.invoice_currency_code);

      --selects invoices
      CURSOR tot_inv (
         p_customer_id   ar_payment_schedules.customer_id%TYPE,
         p_site_use_id   ar_payment_schedules.customer_site_use_id%TYPE,
         p_currency      ar_payment_schedules.invoice_currency_code%TYPE,
         p_as_of_date    ar_payment_schedules.trx_date%TYPE
      )
      IS
         SELECT payment_schedule_id, CLASS, trx_number, trx_date,
                customer_trx_id, invoice_currency_code, amount_due_original
           FROM ar_payment_schedules ps
          WHERE TRUNC (ps.trx_date) <= p_as_of_date
            AND ps.CLASS NOT IN
                        ('PMT', DECODE (p_account_credits, 'Y', 'PMT', 'CM'))
            AND ps.invoice_currency_code = p_currency
            AND ps.customer_id = p_customer_id
            AND ps.customer_site_use_id = p_site_use_id
            AND ps.actual_date_closed > p_as_of_date;
   --AR CUSTOMER BALANCE PROC BEGINS
   BEGIN
      SELECT hou.location_id
        INTO l_organization_loc_id
        FROM hr_all_organization_units hou,
             hr_operating_units ho,
             ar_system_parameters ar
       WHERE ho.set_of_books_id = ar.set_of_books_id
         AND ho.organization_id = hou.organization_id;

      SELECT SUBSTRB (USERENV ('LANG'), 1, 4)
        INTO l_session_language
        FROM DUAL;

      SELECT language_code
        INTO l_base_language
        FROM fnd_languages
       WHERE installed_flag = 'B';

/* R12 Upgrade Modified on 10/04/2012 by Venkatesh Sarangam, Rolta */
/*  SELECT  sob.name
      INTO  l_organization_name
      FROM  gl_sets_of_books sob,ar_system_parameters ar
     WHERE  sob.set_of_books_id  = ar.set_of_books_id;*/
/*   SELECT  currency_code
      INTO  l_functional_currency_code
      from  gl_sets_of_books sob,ar_system_parameters ar
     WHERE  sob.set_of_books_id  = ar.set_of_books_id;*/
      SELECT gl.NAME
        INTO l_organization_name
        FROM gl_ledgers gl, ar_system_parameters ar
       WHERE gl.ledger_id = ar.set_of_books_id;

      SELECT currency_code
        INTO l_functional_currency_code
        FROM gl_ledgers sob, ar_system_parameters ar
       WHERE sob.ledger_id = ar.set_of_books_id;

      -- customer
      FOR cusinfo_rec IN cusinfo
      LOOP
         -- site
         FOR siteinfo_rec IN siteinfo (cusinfo_rec.customer_id)
         LOOP
            -- currency
            FOR currency_rec IN curinfo (cusinfo_rec.customer_id,
                                         siteinfo_rec.site_use_id
                                        )
            LOOP
               l_cus_open_bal := 0;
               l_unapp_receipts := 0;
               l_on_acct_receipts := 0;
               l_rev_unapp_receipts := 0;
               l_rev_on_acct_receipts := 0;

               -- invoice
               FOR tot_inv_rec IN tot_inv (cusinfo_rec.customer_id,
                                           siteinfo_rec.site_use_id,
                                           currency_rec.currency_code,
                                           p_as_of_date
                                          )
               LOOP
                  BEGIN
                     l_inv_open_bal := 0;
                     l_amount_applied := 0;
                     l_earned_discount_taken := 0;
                     l_unearned_discount_taken := 0;
                     l_rev_amount_applied := 0;
                     l_rev_earned_discount_taken := 0;
                     l_rev_unearned_discount_taken := 0;
                     l_amount_credited := 0;
                     l_amount_applied_cm := 0;                 /*bug4502121*/

                     -- For CM, get application
                     SELECT NVL (SUM (amount_applied), 0) amount_applied
                       INTO l_amount_applied_cm                 /*bug4502121*/
                       FROM ar_receivable_applications
                      WHERE payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                        AND apply_date <= p_as_of_date
                        AND status || '' = 'APP';

                     IF UPPER (p_uncleared_receipts) = 'Y'
                     THEN
                        -- Cash Application
                        SELECT NVL (SUM (amount_applied), 0) amount_applied,
                               NVL (SUM (earned_discount_taken), 0)
                                                        earned_discount_taken,
                               NVL (SUM (unearned_discount_taken), 0)
                                                      unearned_discount_taken
                          INTO l_amount_applied,
                               l_earned_discount_taken,
                               l_unearned_discount_taken
                          FROM ar_receivable_applications ra
                         WHERE applied_payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                           AND apply_date <= p_as_of_date
                           AND status || '' = 'APP'
                           AND application_type = 'CASH'
                           AND NOT EXISTS (
                                  SELECT 'reversed'
                                    FROM ar_cash_receipt_history crh
                                   WHERE ra.cash_receipt_id =
                                                           crh.cash_receipt_id
                                     AND crh.status = 'REVERSED'
                                     AND crh.trx_date + 0 <= p_as_of_date);
                     ELSE
                        -- Cash Application
                        SELECT NVL (SUM (amount_applied), 0) amount_applied,
                               NVL (SUM (earned_discount_taken), 0)
                                                        earned_discount_taken,
                               NVL (SUM (unearned_discount_taken), 0)
                                                      unearned_discount_taken
                          INTO l_amount_applied,
                               l_earned_discount_taken,
                               l_unearned_discount_taken
                          FROM ar_receivable_applications ra
                         WHERE applied_payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                           AND apply_date <= p_as_of_date
                           AND status || '' = 'APP'
                           AND application_type = 'CASH'
                           AND NOT EXISTS (
                                  SELECT 'reversed'
                                    FROM ar_cash_receipt_history crh
                                   WHERE ra.cash_receipt_id =
                                                           crh.cash_receipt_id
                                     AND crh.status = 'REVERSED'
                                     AND crh.trx_date + 0 <= p_as_of_date)
                           AND EXISTS (
                                  SELECT 'cleared'
                                    FROM ar_cash_receipt_history crh
                                   WHERE ra.cash_receipt_id =
                                                           crh.cash_receipt_id
                                     AND crh.status = 'CLEARED'
                                     AND crh.trx_date + 0 <= p_as_of_date);
                     END IF;

                     l_amount_applied :=
                                       l_amount_applied + l_rev_amount_applied;

                     -- CM Application
                     SELECT NVL (SUM (amount_applied), 0) amount_applied
                       INTO l_amount_credited
                       FROM ar_receivable_applications
                      WHERE applied_payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                        AND apply_date <= p_as_of_date
                        AND status || '' = 'APP'
                        AND application_type = 'CM';

                     -- Adjustment
                     SELECT NVL (SUM (amount), 0)
                       INTO l_amount_adj
                       FROM ar_adjustments
                      WHERE payment_schedule_id =
                                               tot_inv_rec.payment_schedule_id
                        AND apply_date + 0 <= p_as_of_date
                        AND status = 'A';

                     -- invoice balance
                     l_inv_open_bal :=
                          tot_inv_rec.amount_due_original
                        - l_amount_applied
                        - l_earned_discount_taken
                        - l_unearned_discount_taken
                        - l_amount_credited
                        + l_amount_applied_cm                   /*bug4502121*/
                        + l_amount_adj;

                     -- p_min_invoice_balance is not effective in on-account cm
                     IF    (    l_inv_open_bal >=
                                                NVL (p_min_invoice_balance, 0)
                            AND l_inv_open_bal <> 0
                           )
                        OR (tot_inv_rec.CLASS = 'CM')
                     THEN
                        l_cus_open_bal := l_cus_open_bal + l_inv_open_bal;

                        INSERT INTO xxha_ar_customer_balance_itf
                                    (request_id, as_of_date,
                                     organization_name,
                                     org_location_id,
                                     functional_currency_code,
                                     customer_name,
                                     customer_number,
                                     tax_reference_num,
                                     address_line1,
                                     address_line2,
                                     address_line3,
                                     address_line4,
                                     city, state,
                                     zip,
                                     country,
                                     LANGUAGE,
                                     trans_type,
                                     trx_number,
                                     transaction_date,
                                     customer_trx_id,
                                     trx_currency_code,
                                     trans_amount,
                                     trans_amount_remaining,
                                     receipt_amount,
                                     adjustment_amount,
                                     earned_discount_amount,
                                     unearned_discount_amount,
                                     invoice_credit_amount, bank_charge,
                                     on_account_credit_amount,
                                     on_account_receipts, unapplied_receipts
                                    )
                             VALUES (p_request_id, p_as_of_date,
                                     l_organization_name,
                                     l_organization_loc_id,
                                     l_functional_currency_code,
                                     NVL
                                        (siteinfo_rec.translated_customer_name,
                                         cusinfo_rec.party_name
                                        ),
                                     cusinfo_rec.account_number,
                                     cusinfo_rec.tax_reference,
                                     siteinfo_rec.address1,
                                     siteinfo_rec.address2,
                                     siteinfo_rec.address3,
                                     siteinfo_rec.address4,
                                     siteinfo_rec.city, siteinfo_rec.state,
                                     siteinfo_rec.postal_code,
                                     siteinfo_rec.country,
                                     siteinfo_rec.LANGUAGE,
                                     tot_inv_rec.CLASS,
                                     tot_inv_rec.trx_number,
                                     tot_inv_rec.trx_date,
                                     tot_inv_rec.customer_trx_id,
                                     tot_inv_rec.invoice_currency_code,
                                     DECODE
                                        (tot_inv_rec.CLASS,
                                         'CM', 0,
                                         NVL (tot_inv_rec.amount_due_original,
                                              0
                                             )
                                        ),
                                     DECODE (tot_inv_rec.CLASS,
                                             'CM', 0,
                                             NVL (l_inv_open_bal, 0)
                                            ),
                                     NVL (l_amount_applied, 0),
                                     NVL (l_amount_adj, 0),
                                     NVL (l_earned_discount_taken, 0),
                                     NVL (l_unearned_discount_taken, 0),
                                     NVL (l_amount_credited, 0), 0,
                                     DECODE (tot_inv_rec.CLASS,
                                             'CM', NVL (l_inv_open_bal, 0),
                                             0
                                            ),
                                     0, 0
                                    );
                     END IF;
                  END;
               -- tot_inv
               END LOOP;

               -- unapplied receipt and on account receipt
               IF UPPER (p_uncleared_receipts) = 'Y'
               THEN
                  SELECT NVL (SUM (DECODE (ra.status,
                                           'ACC', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             ),
                         NVL (SUM (DECODE (ra.status,
                                           'UNAPP', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             )
                    INTO l_on_acct_receipts,
                         l_unapp_receipts
                    FROM ar_receivable_applications ra, ar_cash_receipts cr
                   WHERE ra.cash_receipt_id = cr.cash_receipt_id
                     AND cr.pay_from_customer = cusinfo_rec.customer_id
                     AND cr.customer_site_use_id = siteinfo_rec.site_use_id
                     AND cr.currency_code = currency_rec.currency_code
                     AND ra.apply_date + 0 <= p_as_of_date
                     AND ra.status IN ('ACC', 'UNAPP')
                     AND NOT EXISTS (
                            SELECT 'reversed'
                              FROM ar_cash_receipt_history crh
                             WHERE ra.cash_receipt_id = crh.cash_receipt_id
                               AND crh.status = 'REVERSED'
                               AND crh.trx_date + 0 <= p_as_of_date);
               ELSE
                  /* bug3692732 : Added cr.pay_from_customer = cusinfo_rec.customer_id to where clause
                                  to prevent FTS on table ar_cash_receipts */
                  SELECT NVL (SUM (DECODE (ra.status,
                                           'ACC', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             ),
                         NVL (SUM (DECODE (ra.status,
                                           'UNAPP', amount_applied,
                                           0
                                          )
                                  ),
                              0
                             )
                    INTO l_on_acct_receipts,
                         l_unapp_receipts
                    FROM ar_receivable_applications ra, ar_cash_receipts cr
                   WHERE ra.cash_receipt_id = cr.cash_receipt_id
                     AND cr.pay_from_customer = cusinfo_rec.customer_id
                     AND cr.currency_code = currency_rec.currency_code
                     AND cr.customer_site_use_id = siteinfo_rec.site_use_id
                     AND apply_date + 0 <= p_as_of_date
                     AND ra.status IN ('ACC', 'UNAPP')
                     AND NOT EXISTS (
                            SELECT 'reversed'
                              FROM ar_cash_receipt_history crh
                             WHERE ra.cash_receipt_id = crh.cash_receipt_id
                               AND crh.status = 'REVERSED'
                               AND crh.trx_date + 0 <= p_as_of_date)
                     AND EXISTS (
                            SELECT 'cleared'
                              FROM ar_cash_receipt_history crh
                             WHERE ra.cash_receipt_id = crh.cash_receipt_id
                               AND crh.status = 'CLEARED'
                               AND crh.trx_date + 0 <= p_as_of_date);
               END IF;

               IF UPPER (p_account_receipts) = 'Y'
               THEN
                  l_on_acct_receipts :=
                                  l_on_acct_receipts + l_rev_on_acct_receipts;
               ELSE
                  l_on_acct_receipts := 0;
               END IF;

               IF UPPER (p_unapp_receipts) = 'Y'
               THEN
                  l_unapp_receipts := l_unapp_receipts + l_rev_unapp_receipts;
               ELSE
                  l_unapp_receipts := 0;
               END IF;

               l_cus_open_bal :=
                        l_cus_open_bal - l_on_acct_receipts - l_unapp_receipts;

               IF (l_unapp_receipts <> 0) OR (l_on_acct_receipts <> 0)
               THEN
                  INSERT INTO xxha_ar_customer_balance_itf
                              (request_id, as_of_date,
                               organization_name, org_location_id,
                               functional_currency_code,
                               customer_name,
                               customer_number,
                               tax_reference_num,
                               address_line1, address_line2,
                               address_line3, address_line4,
                               city, state,
                               zip,
                               country, LANGUAGE,
                               trans_type, trx_number, transaction_date,
                               customer_trx_id, trx_currency_code,
                               trans_amount, trans_amount_remaining,
                               receipt_amount, adjustment_amount,
                               earned_discount_amount,
                               unearned_discount_amount,
                               invoice_credit_amount, bank_charge,
                               on_account_credit_amount,
                               on_account_receipts,
                               unapplied_receipts
                              )
                       VALUES (p_request_id, p_as_of_date,
                               l_organization_name, l_organization_loc_id,
                               l_functional_currency_code,
                               NVL (siteinfo_rec.translated_customer_name,
                                    cusinfo_rec.party_name
                                   ),
                               cusinfo_rec.account_number,
                               cusinfo_rec.tax_reference,
                               siteinfo_rec.address1, siteinfo_rec.address2,
                               siteinfo_rec.address3, siteinfo_rec.address4,
                               siteinfo_rec.city, siteinfo_rec.state,
                               siteinfo_rec.postal_code,
                               siteinfo_rec.country, siteinfo_rec.LANGUAGE,
                               'PMT', 'On Account Receipt', p_as_of_date,
                               0, currency_rec.currency_code,
                               0, 0,
                               0, 0,
                               0,
                               0,
                               0, 0,
                               0,
                               l_on_acct_receipts * (-1),
                               l_unapp_receipts * (-1)
                              );
               END IF;

               IF     (l_cus_open_bal >= NVL (p_min_open_balance, 0))
                  AND (l_cus_open_bal <> 0)
               THEN
                  COMMIT;
               ELSE
                  -- rollback for all inserted record for this site.
                  ROLLBACK;
               END IF;
            -- currency
            END LOOP;
         -- siteinfo
         END LOOP;
      -- cusinfo
      END LOOP;
   END;
--End AR_CUSTOMER_BALANCE
END xxha_get_customer_balance_pkg;
/
