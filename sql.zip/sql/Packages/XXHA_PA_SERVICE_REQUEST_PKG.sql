CREATE OR REPLACE PACKAGE XXHA_PA_SERVICE_REQUEST_PKG AS

-- Procedure to initiate "XXHA Project Service Request" workflow and 
-- this procedure will be called from a trigger on xxha_pa_tasks_alert table
PROCEDURE Initiate(p_task_id          IN NUMBER,
                   p_task_number      IN VARCHAR2,
                   p_project_id       IN NUMBER,
                   p_allow_chares     IN VARCHAR2,
                   p_task_manager     IN NUMBER,
                   P_initiator        IN NUMBER,
                   p_last_update_date IN VARCHAR2,
                   p_itemkey          OUT VARCHAR2);

-- Procedure will be called from "XXHA Project Service Request" workflow to get the workflow attributes
PROCEDURE Get_Attribute_Values(itemtype  in varchar2,
                         itemkey   in varchar2,
                         actid     in number,
                         funcmode  in varchar2,
                         resultout in out varchar2);

-- Procedure will be called from "XXHA Project Service Request" workflow to 
-- validate the change and decide to whom the notification should be sent
Procedure validate_change (itemtype  in varchar2,
                         itemkey   in varchar2,
                         actid     in number,
                         funcmode  in varchar2,
                         resultout in out varchar2);
                        
-- Procedure to Initiate "XXHA Project Service Request" workflow and 
-- this procedure will be called from a trigger on xxha_pa_resource_assignments table
PROCEDURE Budget_Initiate(p_budget_version_id     IN NUMBER,
                          p_project_id            IN NUMBER,
                          p_task_id               IN NUMBER,
                          p_budget_type_code      IN VARCHAR2,
                          p_budget_status_code    IN VARCHAR2,
                          p_initiator             IN NUMBER,
                          p_itemkey               OUT VARCHAR2);    
                          
-- Procedure will be called from "XXHA Project Service Request" workflow to get the workflow attributes
-- and validate the budget status and decide to whom the notification should be sent
PROCEDURE get_budget_attr_values(itemtype  in varchar2,
                                 itemkey   in varchar2,
                                 actid     in number,
                                 funcmode  in varchar2,
                                 resultout in out varchar2);

-- Procedure to copy the pa_tasks information to xxha_pa_tasks_alert to maintain audit information
PROCEDURE insert_tasks(p_task_id number,
                       p_project_id number);
                       
                       
                      
PROCEDURE insert_budget_data(p_budget_version_id NUMBER,
                             p_budget_status_code VARCHAR2,
                             p_project_id NUMBER,
                             p_last_update_date VARCHAR2);                       
                               
                                
                                       
END  XXHA_PA_SERVICE_REQUEST_PKG;                
/


CREATE OR REPLACE PACKAGE BODY XXHA_PA_SERVICE_REQUEST_PKG AS

-- Procedure to copy the pa_budget_versions, pa_resource_assignments and pa_budget_lines information
-- to xxha_pa_budget_versions, xxha_pa_resource_assignments and xxha_pa_budget_lines to maintain audit information
PROCEDURE insert_budget_data(p_budget_version_id NUMBER,
                             p_budget_status_code VARCHAR2,
                             p_project_id NUMBER,
                             p_last_update_date VARCHAR2) as
  ln_obudget_version_id  NUMBER;
  ld_version_last_update VARCHAR2(30);
  lv_obudget_status_code VARCHAR2(1);
  lv_new    varchar2(1) := 'N';
  lv_sqlerrm             VARCHAR2(2000);
  ln_rowcount  NUMBER;
BEGIN
  --insert into xxha_temp values (1, sysdate, 'NEW RECORD:'||' '||p_last_update_date);
 BEGIN
   SELECT budget_version_id,
          TO_CHAR(last_update_date, 'DD-MON-RRRR HH24:MI:SS') last_update_date
   INTO   ln_obudget_version_id,
          ld_version_last_update
   FROM   xxha_pa_budget_versions xpdv
   WHERE  xpdv.last_update_date = (       SELECT MAX(xpd.last_update_date)
                                          FROM   xxha_pa_budget_versions xpd
                                          WHERE  xpd.budget_version_id = p_budget_version_id
                                          AND    xpd.last_update_date < TO_DATE(p_last_update_date, 'DD-MON-RRRR HH24:MI:SS')
                                          AND    xpd.budget_status_code <> p_budget_status_code);
   --insert into xxha_temp values (1, sysdate, 'PREVIOUS RECORD:'||' '||ld_version_last_update);
 EXCEPTION WHEN NO_DATA_FOUND THEN
   lv_new := 'Y';
   ld_version_last_update := '01-JAN-1001 00:00:00';
   --insert into xxha_temp values (1, sysdate, 'INSERT BUDGET NEW RECORD:'||' '||ld_version_last_update);
   WHEN OTHERS THEN
   lv_sqlerrm := SQLERRM;
   --insert into xxha_temp values (1, sysdate, 'WHEN OTHERS'||' '||lv_SQLERRM);
 END;
 BEGIN
    SELECT budget_status_code
    INTO   lv_obudget_status_code
    FROM   xxha_pa_budget_versions xpdv
    WHERE  xpdv.last_update_date = (       SELECT MAX(xpd.last_update_date)
                                           FROM   xxha_pa_budget_versions xpd
                                           WHERE  xpd.budget_version_id = p_budget_version_id
                                           AND    xpd.last_update_date < TO_DATE(p_last_update_date, 'DD-MON-RRRR HH24:MI:SS'));
    --insert into xxha_temp values (1, sysdate, 'PREVIOUS RECORD BUDGET STATUS:'||' '||lv_obudget_status_code);
 EXCEPTION WHEN NO_DATA_FOUND THEN
    NULL;
 END;
 IF (lv_new = 'Y' and  p_budget_status_code = 'S') OR  (lv_obudget_status_code <> p_budget_status_code) THEN
 BEGIN
   --insert into xxha_temp values (1, sysdate, '-'||lv_new||'-'||lv_obudget_status_code||'-'||p_budget_status_code);
   insert into xxha_pa_budget_versions
   select budget_version_id,
          pbv.project_id,
          budget_type_code,
          budget_status_code,
          current_flag,
          baselined_by_person_id,
          pbv.last_update_date,
          pbv.last_updated_by,
          pbv.creation_date,
          pbv.created_by
     from pa_budget_versions pbv
    where budget_version_id = p_budget_version_id;
 EXCEPTION WHEN OTHERS THEN
    lv_sqlerrm := SQLERRM;
    --insert into xxha_temp values (1, sysdate, 'INSERT BUDGET_VERSION:'||' '||lv_SQLERRM);
    RETURN;
 END;
 BEGIN
   INSERT INTO xxha_pa_resource_assignments xpb
	SELECT resource_assignment_id,
	       budget_version_id,
	       project_id,
	       task_id,
	       resource_list_member_id,
	       to_date(p_last_update_date, 'DD-MON-RRRR HH24:MI:SS') last_update_date,
	       last_updated_by,
	       creation_date,
	       created_by,
	       last_update_login,
	       unit_of_measure,
	       track_as_labor_flag,
	       standard_bill_rate,
	       average_bill_rate,
	       average_cost_rate,
	       project_assignment_id,
	       plan_error_code,
	       total_plan_revenue,
	       total_plan_raw_cost,
	       total_plan_burdened_cost,
	       total_plan_quantity,
	       average_discount_percentage,
	       total_borrowed_revenue,
	       total_tp_revenue_in,
	       total_tp_revenue_out,
	       total_revenue_adj,
	       total_lent_resource_cost,
	       total_tp_cost_in,
	       total_tp_cost_out,
	       total_cost_adj,
	       total_unassigned_time_cost,
	       total_utilization_percent,
	       total_utilization_hours,
	       total_utilization_adj,
	       total_capacity,
	       total_head_count,
	       total_head_count_adj,
	       resource_assignment_type,
	       total_project_raw_cost,
	       total_project_burdened_cost,
	       total_project_revenue,
	       parent_assignment_id,
	       wbs_element_version_id,
	       rbs_element_id,
	       planning_start_date,
	       planning_end_date,
	       spread_curve_id,
	       etc_method_code,
	       res_type_code,
	       attribute_category,
	       attribute1,
	       attribute2,
	       attribute3,
	       attribute4,
	       attribute5,
	       attribute6,
	       attribute7,
	       attribute8,
	       attribute9,
	       attribute10,
	       attribute11,
	       attribute12,
	       attribute13,
	       attribute14,
	       attribute15,
	       attribute16,
	       attribute17,
	       attribute18,
	       attribute19,
	       attribute20,
	       attribute21,
	       attribute22,
	       attribute23,
	       attribute24,
	       attribute25,
	       attribute26,
	       attribute27,
	       attribute28,
	       attribute29,
	       attribute30,
	       fc_res_type_code,
	       resource_class_code,
	       organization_id,
	       job_id,
	       person_id,
	       expenditure_type,
	       expenditure_category,
	       revenue_category_code,
	       event_type,
	       supplier_id,
	       project_role_id,
	       person_type_code,
	       non_labor_resource,
	       bom_resource_id,
	       inventory_item_id,
	       item_category_id,
	       record_version_number,
	       billable_percent,
	       transaction_source_code,
	       mfc_cost_type_id,
	       procure_resource_flag,
	       assignment_description,
	       incurred_by_res_flag,
	       rate_job_id,
	       rate_expenditure_type,
	       ta_display_flag,
	       sp_fixed_date,
	       rate_based_flag,
	       use_task_schedule_flag,
	       rate_exp_func_curr_code,
	       rate_expenditure_org_id,
	       incur_by_res_class_code,
	       incur_by_role_id,
	       resource_class_flag,
	       named_role,
	       txn_accum_header_id,
	       pm_product_code,
	       pm_res_assignment_reference,
	       schedule_start_date,
	       schedule_end_date,
	       unplanned_flag,
	       scheduled_delay,
	       resource_rate_based_flag
	  FROM pa_resource_assignments pra
        WHERE  pra.budget_version_id = p_budget_version_id
        AND    pra.project_id = p_project_id
        AND    pra.budget_version_id in (select budget_version_id
                                         from   pa_budget_versions pbv
                                         where  pbv.budget_version_id = pra.budget_version_id
                                         and    pbv.budget_status_code <> 'B')
        AND    ((pra.resource_assignment_id in  (SELECT  pbl.resource_assignment_id
                                                 FROM   pa_budget_lines pbl
                                                 WHERE  EXISTS (select 1
                                                                from   pa_resource_assignments pra1
                                                                where  pra1.budget_version_id = p_budget_version_id
                                                                and    pra1.project_id = p_project_id
                                                                and    pbl.resource_assignment_id = pra1.resource_assignment_id
		                                               )
                                                  AND    pbl.last_update_date BETWEEN TO_DATE(ld_version_last_update, 'DD-MON-RRRR HH24:MI:SS')
                                                                              AND TO_DATE(p_last_update_date, 'DD-MON-RRRR HH24:MI:SS')
                                               )
	        )
	    OR (pra.resource_assignment_id in (select pra2.resource_assignment_id
	                                       from xxha_pa_resource_assignments pra2,
	                                            pa_budget_versions pbv
	                                       where pra2.budget_version_id = p_budget_version_id
	                                       and   pra2.project_id = p_project_id
	                                       and   pra.budget_version_id = pbv.budget_version_id
	                                       and   pbv.budget_status_code <> 'S'
	                                       and   pbv.budget_type_code = 'SR Approved Revenue Budget'
	                                       and   pra2.last_update_date BETWEEN TO_DATE(ld_version_last_update, 'DD-MON-RRRR HH24:MI:SS')
                                                                              AND TO_DATE(p_last_update_date, 'DD-MON-RRRR HH24:MI:SS')
                                              )
	        ));

    ln_rowcount := SQL%ROWCOUNT;
   --insert into xxha_temp values (1, sysdate, 'inserted in resource assignment'||' '||ln_rowcount);
   INSERT INTO xxha_pa_budget_lines xpl
        SELECT *
        FROM   pa_budget_lines pbl
        WHERE  EXISTS  (select 1
                        FROM   pa_resource_assignments pra
                        WHERE  pra.budget_version_id = p_budget_version_id
                        AND    pra.project_id = p_project_id
                        AND    pbl.resource_assignment_id = pra.resource_assignment_id)
        AND    pbl.last_update_date BETWEEN TO_DATE(ld_version_last_update, 'DD-MON-RRRR HH24:MI:SS')
                                        AND TO_DATE(p_last_update_date, 'DD-MON-RRRR HH24:MI:SS');
    ln_rowcount := SQL%ROWCOUNT;
   --insert into xxha_temp values (1, sysdate, 'inserted in budget lines'||' '||ln_rowcount);
 EXCEPTION WHEN OTHERS THEN
       lv_sqlerrm := SQLERRM;
       --insert into xxha_temp values (1, sysdate, 'INSERT RESOURCE ASSIGNMENT AND LINES:'||' '||lv_sqlerrm);
 END;
 END IF;
EXCEPTION WHEN OTHERS THEN
   NULL;
END insert_budget_data;
-- Procedure to copy the pa_tasks information to xxha_pa_tasks_alert to maintain audit information
PROCEDURE insert_tasks(p_task_id number,
                       p_project_id number) as
BEGIN
INSERT INTO  XXHA_PA_TASKS_ALERT XPT
	SELECT *
	FROM PA_TASKS PT
	WHERE PT.PROJECT_ID = p_project_id
	AND   PT.TASK_ID = p_task_id;
EXCEPTION when others then
  NULL;
END insert_tasks;
-- Procedure to initiate "XXHA Project Service Request" workflow and
-- this procedure will be called from a trigger on xxha_pa_tasks_alert table
PROCEDURE Initiate(p_task_id          IN NUMBER,
                   p_task_number      IN VARCHAR2,
                   p_project_id       IN NUMBER,
                   p_allow_chares     IN VARCHAR2,
                   p_task_manager     IN NUMBER,
                   P_initiator        IN NUMBER,
                   p_last_update_date IN VARCHAR2,
                   p_itemkey          OUT VARCHAR2) as
   lv_item_type           VARCHAR2(20) := 'XXHASCPR';
   ln_itemkey             NUMBER:=0;
   lv_initiator      FND_USER.USER_NAME%TYPE;
   lv_project_number PA_PROJECTS_ALL.SEGMENT1%TYPE;
BEGIN
     SELECT FU.user_name
     INTO   lv_initiator
     FROM   fnd_user FU
     WHERE  FU.user_id = p_initiator;
     SELECT xxha_prjsc_wf_seq.nextval
     INTO   ln_itemkey
     FROM   DUAL;
     select segment1
     INTO   lv_project_number
     from   pa_projects_all
     where  project_id = p_project_id;
     dbms_output.put_line(p_last_update_date);
     WF_ENGINE.CreateProcess(itemtype   => lv_item_type,
                             itemkey    => ln_itemkey,
                             process    => 'XXHASCPROCESS',
                             user_key   => lv_project_number||' '||SUBSTR(p_task_number, 1, 10),
                             owner_role => lv_initiator);
     WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                 itemkey  => ln_itemkey,
                                 aname    => 'TASK_ID',
                                 avalue   => p_task_id);
      WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                itemkey  => ln_itemkey,
                                aname    => 'ALLOW_CHARGES',
                                avalue   => p_allow_chares);
      WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'TASK_MANAGER_PERSON_ID',
                                  avalue   => p_task_manager);
      WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                                  itemkey  => ln_itemkey,
                                  aname    => 'INITIATOR_USER_ID',
                                  avalue   => P_initiator);
      WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                itemkey  => ln_itemkey,
                                aname    => 'LAST_UPDATE_DATE',
                                avalue   => p_last_update_date);
      WF_ENGINE.StartProcess(itemtype => lv_item_type,
                             itemkey  => ln_itemkey);
      p_itemkey :=  ln_itemkey;
END   Initiate;
-- Procedure will be called from "XXHA Project Service Request" workflow to get the workflow attributes
PROCEDURE Get_Attribute_Values(itemtype  in varchar2,
                         itemkey   in varchar2,
                         actid     in number,
                         funcmode  in varchar2,
                         resultout in out varchar2
                        ) AS

   p_task_id            NUMBER;
   p_allow_chares       VARCHAR2(10);
   p_task_manager       NUMBER;
   P_initiator          NUMBER;
   p_last_update_date   VARCHAR2(25);
   ln_otm_person_id        PER_ALL_PEOPLE_F.PERSON_ID%TYPE;
   lv_Ochargeable_flag     PA_TASKS.CHARGEABLE_FLAG%TYPE;
   lv_Otask_status         PA_WORK_TYPES_TL.NAME%TYPE;
   lv_Otask_number         PA_TASKS.TASK_NUMBER%TYPE;
   lv_new_task            VARCHAR2(1) := 'N';
   lv_item_type           VARCHAR2(20) := itemtype;
   ln_itemkey             NUMBER:= itemkey;
   ln_tm_person_id        PER_ALL_PEOPLE_F.PERSON_ID%TYPE;
   lv_tm_username         FND_USER.USER_NAME%TYPE;
   lv_tm_fullname         PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
   ln_pm_person_id        PER_ALL_PEOPLE_F.PERSON_ID%TYPE;
   lv_pm_username         FND_USER.USER_NAME%TYPE;
   lv_pm_fullname   	  PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
   ln_pa_person_id        PER_ALL_PEOPLE_F.PERSON_ID%TYPE;
   lv_pa_username         FND_USER.USER_NAME%TYPE;
   lv_pa_fullname   	  PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
   ln_sa_person_id        PER_ALL_PEOPLE_F.PERSON_ID%TYPE;
   lv_sa_username         FND_USER.USER_NAME%TYPE;
   lv_sa_fullname   	  PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
   lv_project_number      PA_PROJECTS_ALL.SEGMENT1%TYPE;
   ln_project_id          PA_PROJECTS_ALL.PROJECT_ID%TYPE;
   lv_task_number         PA_TASKS.TASK_NUMBER%TYPE;
   ln_task_id             PA_TASKS.TASK_ID%TYPE;
   lv_chargeable_flag     PA_TASKS.CHARGEABLE_FLAG%TYPE;
   lv_task_status         PA_WORK_TYPES_TL.NAME%TYPE;
   lv_project_type        PA_PROJECTS_ALL.PROJECT_TYPE%TYPE;
   lv_initiator           FND_USER.USER_NAME%TYPE;
   lv_error               VARCHAR2(1):= 'N';
   lv_error_subject       VARCHAR2(2000) := 'ERROR:';
   lv_error_message       VARCHAR2(32000):= NULL;
  BEGIN
   p_task_id         := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'TASK_ID');
   p_allow_chares    := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'ALLOW_CHARGES');
   p_task_manager    :=  WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'TASK_MANAGER_PERSON_ID');
   P_initiator       :=  WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'INITIATOR_USER_ID');
   p_last_update_date  :=  WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'LAST_UPDATE_DATE');
   BEGIN
     SELECT FU.user_name
     INTO   lv_initiator
     FROM   fnd_user FU
     WHERE  FU.user_id = p_initiator;
     WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'INITIATOR',
                               avalue   => lv_initiator);
   EXCEPTION WHEN OTHERS THEN
     lv_error := 'Y';
     lv_error_subject := lv_error_subject||'Fetching Initiator User Information';
     lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||SQLERRM ;
   END;
   BEGIN
     SELECT  distinct xpt.task_manager_person_id
	    ,xpt.chargeable_flag
	    ,pwt.name   task_status
	    ,xpt.task_number
      INTO   ln_Otm_person_id
            ,lv_Ochargeable_flag
            ,lv_Otask_status
            ,lv_Otask_number
      FROM   xxha_pa_tasks_alert xpt
            ,pa_projects_all pp
 	    ,pa_work_types_tl pwt
     WHERE   pp.project_id = xpt.project_id
     AND     xpt.work_type_id = pwt.work_type_id (+)
     AND     pwt.language (+) = 'US'
     AND     pp.project_type = 'SR Project Type'
     AND     xpt.task_id = p_task_id
     AND     xpt.last_update_date =  (SELECT MAX(xpt1.last_update_date)
                                      FROM   xxha_pa_tasks_alert xpt1
                                      WHERE  xpt.task_id = xpt1.task_id
                                      AND    xpt1.last_update_date  < TO_DATE(TRIM(p_last_update_date), 'DD-MON-RRRR HH24:MI:SS'));
   EXCEPTION WHEN NO_DATA_FOUND THEN
     lv_new_task := 'Y';
     WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'NEW_TASK',
                               avalue   => 'Y');
   END;
   BEGIN
     SELECT distinct
	     xpt.task_manager_person_id
            ,xpt.chargeable_flag
            ,pwt.name   task_status
            ,pp.project_id
            ,pp.segment1 project_number
            ,xpt.task_number
      INTO   ln_tm_person_id
            ,lv_chargeable_flag
            ,lv_task_status
            ,ln_project_id
            ,lv_project_number
            ,lv_task_number
      FROM   xxha_pa_tasks_alert xpt
            ,pa_projects_all pp
            ,pa_work_types_tl pwt
     WHERE   pp.project_id = xpt.project_id
     AND     xpt.work_type_id = pwt.work_type_id (+)
     AND     pwt.language (+) = 'US'
     AND     pp.project_type = 'SR Project Type'
     AND     xpt.task_id = p_task_id
     AND     xpt.last_update_date =  to_date(TRIM(p_last_update_date), 'DD-MON-RRRR HH24:MI:SS');
     lv_error_subject := lv_error_subject||' '||lv_project_number||' :';		-- Version 2.0
     lv_error_message := lv_error_message||' '||lv_project_number||' :'||CHR(10);	-- Version 2.0
   EXCEPTION WHEN OTHERS THEN
      lv_error := 'Y';
      lv_error_subject := lv_error_subject||' '||' Fetching Task Details';
      lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||SQLERRM ;
   END;
   BEGIN
      SELECT  ppp1.person_id PM_person_id
 	     ,ppf1.full_name PM_Name
	     ,fu1.user_name PM_Username
       INTO   ln_PM_person_id
             ,lv_PM_fullname
             ,lv_PM_username
       FROM   pa_project_players ppp1
             ,per_all_people_f ppf1
             ,fnd_user fu1
             ,pa_project_role_types_tl pprt1
             ,pa_project_role_types_b ppr1
      WHERE   ppr1.project_role_type = ppp1.project_role_type
      AND     pprt1.project_role_id = ppr1.project_role_id
      AND     ppp1.person_id = ppf1.person_id
      AND     ppf1.person_id = fu1.employee_id
      AND     pprt1.language = 'US'
      AND     pprt1.Meaning = 'Project Manager'
      AND     sysdate between ppf1.effective_start_date and ppf1.effective_end_date
      AND    sysdate between ppp1.start_date_active and nvl(ppp1.end_date_active, sysdate+1)
      AND     ppp1.project_id = ln_project_id
      AND     ROWNUM = 1
      ORDER BY FU1.CREATION_DATE;
   EXCEPTION WHEN OTHERS THEN
      lv_error := 'Y';
      lv_error_subject := lv_error_subject||' '||' Fetching Project Manager Information';
      lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Project Manager'||' '||SQLERRM ;
   END;
   IF ln_tm_person_id IS NOT NULL THEN
     BEGIN
       SELECT fu.user_name
             ,ppf.full_name
       INTO   lv_tm_username
             ,lv_tm_fullname
       FROM   per_all_people_f PPF
             ,fnd_user FU
       WHERE  PPF.person_id = FU.employee_id
       AND    sysdate between PPF.effective_start_date and PPF.effective_end_date
       AND    ppf.person_id =  ln_tm_person_id
       AND    ROWNUM = 1
       ORDER BY FU.CREATION_DATE;
     EXCEPTION WHEN OTHERS THEN
      lv_error := 'Y';
      lv_error_subject := lv_error_subject||' '||' Fetching Task Manager Information';
      lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Task Manager'||' '||SQLERRM ;
     END;
   END IF;
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'TASK_MANAGER_USERNAME',
                               avalue   => lv_tm_username);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'TASK_MANAGER_FULLNAME',
                               avalue   => lv_tm_fullname);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'PM_USERNAME',
                               avalue   => lv_pm_username);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'PM_NAME',
                               avalue   => lv_pm_fullname);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'PROJECT_NUMBER',
                               avalue   => lv_project_number);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'TASK_NUMBER',
                               avalue   => lv_task_number);
   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'PROJECT_ID',
                               avalue   => ln_project_id);
   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'TASK_ID',
                               avalue   => p_task_id);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'TASK_STATUS',
                               avalue   => lv_task_status);
   IF  lv_Otask_number <> lv_task_number and ln_otm_person_id IS NULL THEN
     lv_new_task := 'Y';
     WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'NEW_TASK',
                               avalue   => 'Y');
   END IF;
   IF  lv_new_task = 'Y' THEN
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'NEW_TASK',
                                   avalue   => 'Y');
         IF lv_error = 'N' THEN
           RESULTOUT := 'COMPLETE:SUCCESS';
           RETURN;
         ELSE
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_SUBJECT',
                                     avalue   => lv_error_subject);
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_MESSAGE',
                                     avalue   => lv_error_message);
           RESULTOUT := 'COMPLETE:FAIL';
           RETURN;
         END IF;
   ELSIF NVL(lv_new_task, 'N') = 'N' THEN
      --insert into xxha_temp values (1, sysdate, 'new task no');
      IF NVL(ln_otm_person_id, -1) <> NVL(ln_tm_person_id, -1) and NVL(lv_task_status, '-') = 'Assigned' THEN
         --insert into xxha_temp values (2, sysdate, 'ASSIGNED');
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'TASK_MANAGER_ASSIGNED',
                                   avalue   => 'Y');
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'STATUS_CHANGED',
                                   avalue   => 'ASSIGNED');
         IF lv_error = 'N' THEN
           RESULTOUT := 'COMPLETE:SUCCESS';
           RETURN;
         ELSIF lv_error = 'Y' THEN
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_SUBJECT',
                                     avalue   => lv_error_subject);
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_MESSAGE',
                                     avalue   => lv_error_message);
           RESULTOUT := 'COMPLETE:FAIL';
           RETURN;
         END IF;
       ELSIF lv_Ochargeable_flag = 'Y' and lv_chargeable_flag = 'N' THEN
	--insert into xxha_temp values (3, sysdate, 'CHARGEABLE');
         BEGIN
           SELECT  ppp1.person_id PM_person_id
     	          ,ppf1.full_name PM_Name
	           ,fu1.user_name PM_Username
            INTO   ln_sa_person_id
                  ,lv_sa_fullname
                  ,lv_sa_username
            FROM   pa_project_players ppp1
                  ,per_all_people_f ppf1
                  ,fnd_user fu1
                  ,pa_project_role_types_tl pprt1
                  ,pa_project_role_types_b ppr1
           WHERE   ppr1.project_role_type = ppp1.project_role_type
           AND     pprt1.project_role_id = ppr1.project_role_id
           AND     ppp1.person_id = ppf1.person_id
           AND     ppf1.person_id = fu1.employee_id
           AND     pprt1.language = 'US'
           AND     pprt1.meaning = 'Sales Admin'     				-- Version 2.0
           AND     sysdate between ppf1.effective_start_date and ppf1.effective_end_date
           AND    sysdate between ppp1.start_date_active and nvl(ppp1.end_date_active, sysdate+1)
           AND     ppp1.project_id = ln_project_id
           AND     ROWNUM = 1
           ORDER BY FU1.CREATION_DATE;
         EXCEPTION WHEN OTHERS THEN
           lv_error := 'Y';
           lv_error_subject := lv_error_subject||' '||' Fetching Sales Admin Information';
           lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Sales Admin:'||' '||SQLERRM ;
         END;
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'CHARGEABLE_FLAG_CHANGED',
                                   avalue   => 'Y');
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'SALES_ADMIN_USERNAME',
                               avalue   => lv_sa_username);
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'SALES_ADMIN_FULLNAME',
                               avalue   => lv_sa_fullname);
         IF lv_error = 'N' THEN
           RESULTOUT := 'COMPLETE:SUCCESS';
           RETURN;
         ELSIF lv_error = 'Y' THEN
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_SUBJECT',
                                     avalue   => lv_error_subject);
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_MESSAGE',
                                     avalue   => lv_error_message);
           RESULTOUT := 'COMPLETE:FAIL';
           RETURN;
         END IF;
       ELSIF NVL(lv_Otask_status, '-') <>  NVL(lv_task_status, '-') AND NVL(lv_task_status, '-') = 'Completed' THEN
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'STATUS_CHANGED',
                                   avalue   => 'COMPLETED');
         IF lv_error = 'N' THEN
           RESULTOUT := 'COMPLETE:SUCCESS';
           RETURN;
         ELSIF lv_error = 'Y' THEN
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_SUBJECT',
                                     avalue   => lv_error_subject);
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_MESSAGE',
                                     avalue   => lv_error_message);
           RESULTOUT := 'COMPLETE:FAIL';
           RETURN;
         END IF;
       ELSIF NVL(lv_Otask_status, '-') <>  NVL(lv_task_status, '-') AND NVL(lv_task_status, '-') = 'Customer Accepted' THEN
         BEGIN
          SELECT   ppp1.person_id PM_person_id
                  ,ppf1.full_name PM_Name
                  ,fu1.user_name PM_Username
           INTO    ln_PA_person_id
                  ,lv_PA_fullname
                  ,lv_PA_username
           FROM    pa_project_players ppp1
                  ,per_all_people_f ppf1
                  ,fnd_user fu1
                  ,pa_project_role_types_tl pprt1
                  ,pa_project_role_types_b ppr1
           WHERE   ppr1.project_role_type = ppp1.project_role_type
           AND     pprt1.project_role_id = ppr1.project_role_id
           AND     ppp1.person_id = ppf1.person_id
           AND     ppf1.person_id = fu1.employee_id
           AND     pprt1.language = 'US'
           AND     pprt1.meaning = 'Project Accountant'    			-- Version 2.0
           AND     sysdate between ppf1.effective_start_date and ppf1.effective_end_date
           AND     sysdate between ppp1.start_date_active and nvl(ppp1.end_date_active, sysdate+1)
           AND     ppp1.project_id = ln_project_id
           AND     ROWNUM = 1
           ORDER BY FU1.CREATION_DATE;
         EXCEPTION WHEN OTHERS THEN
           lv_error := 'Y';
           lv_error_subject := lv_error_subject||' '||' Fetching Project Accountant Information';
           lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Project Accountant'||' '||SQLERRM ;
         END;
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'PROJ_ACCOUNTANT_USERNAME',
                                   avalue   => lv_PA_username);
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'PROJ_ACCOUNTANT_FULLNAME',
                                   avalue   => lv_PA_fullname);
         WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                   itemkey  => ln_itemkey,
                                   aname    => 'STATUS_CHANGED',
                                   avalue   => 'CUSTOMER ACCEPTED');
         IF lv_error = 'N' THEN
           RESULTOUT := 'COMPLETE:SUCCESS';
           RETURN;
         ELSIF lv_error = 'Y' THEN
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_SUBJECT',
                                     avalue   => lv_error_subject);
           WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                                     itemkey  => ln_itemkey,
                                     aname    => 'ERROR_MESSAGE',
                                     avalue   => lv_error_message);
           RESULTOUT := 'COMPLETE:FAIL';
           RETURN;
         END IF;
       ELSE
         RESULTOUT := 'COMPLETE:NOCHANGE';
         RETURN;
       END IF;
   END IF;
  END Get_Attribute_Values;
-- Procedure will be called from "XXHA Project Service Request" workflow to
-- validate the change and decide to whom the notification should be sent
  PROCEDURE validate_change (itemtype  in varchar2,
                             itemkey   in varchar2,
                             actid     in number,
                             funcmode  in varchar2,
                             resultout in out varchar2) AS

    lv_newtask          VARCHAR2(1);
    lv_status_changed   VARCHAR2(50);
    lv_chargeable_flag_changed  VARCHAR2(1);
    lv_task_manager_assigned VARCHAR2(1);
  BEGIN
   lv_newtask := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'NEW_TASK');
   lv_status_changed := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'STATUS_CHANGED');
   lv_task_manager_assigned := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'TASK_MANAGER_ASSIGNED');
   lv_chargeable_flag_changed := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'CHARGEABLE_FLAG_CHANGED');
   IF NVL(lv_newtask, 'N')  = 'Y' THEN
    RESULTOUT := 'COMPLETE:NEWTASK';
   ELSIF NVL(lv_status_changed, '-') = 'ASSIGNED' and NVL(lv_task_manager_assigned, 'N') = 'Y' THEN
    RESULTOUT := 'COMPLETE:TASKMANAGER';
   ELSIF NVL(lv_status_changed, '-') = 'COMPLETED' THEN
    RESULTOUT := 'COMPLETE:TASKCOMPLETE';
   ELSIF NVL(lv_status_changed, '-') = 'CUSTOMER ACCEPTED' THEN
    RESULTOUT := 'COMPLETE:CUSTOMER_ACCEPTED';
   ELSIF NVL(lv_chargeable_flag_changed, 'N') = 'Y' THEN
    RESULTOUT := 'COMPLETE:ALLOWCHARGES';
   END IF;
   RETURN;
  END VALIDATE_CHANGE;
-- Procedure to Initiate "XXHA Project Service Request" workflow and
-- this procedure will be called from a trigger on xxha_pa_resource_assignments table
PROCEDURE Budget_Initiate(p_budget_version_id     IN NUMBER,
                          p_project_id            IN NUMBER,
                          p_task_id               IN NUMBER,
                          p_budget_type_code      IN VARCHAR2,
                          p_budget_status_code    IN VARCHAR2,
                          p_initiator             IN NUMBER,
                          p_itemkey               OUT VARCHAR2) as
   lv_item_type      VARCHAR2(20) := 'XXHASCPR';
   ln_itemkey        NUMBER:=0;
   lv_initiator      FND_USER.USER_NAME%TYPE;
   lv_project_number PA_PROJECTS_ALL.SEGMENT1%TYPE;
   lv_task_number    PA_TASKS.TASK_NUMBER%TYPE;
   ln_prevbudversion  NUMBER;
   ln_wf_budversion  NUMBER;
   ln_wf_prevbudversion  NUMBER;
  BEGIN
   SELECT FU.user_name
   INTO   lv_initiator
   FROM   fnd_user FU
   WHERE  FU.user_id = p_initiator;
   SELECT xxha_prjsc_wf_seq.nextval
   INTO   ln_itemkey
   FROM   DUAL;
   SELECT segment1
   INTO   lv_project_number
   FROM   pa_projects_all
   WHERE  project_id = p_project_id;
   SELECT task_number
   INTO   lv_task_number
   FROM   pa_tasks PT
   WHERE  PT.task_id = p_task_id;
   WF_ENGINE.CreateProcess(itemtype   => lv_item_type,
                           itemkey    => ln_itemkey,
                           process    => 'XXHASBUDGETPROCESS',
                           user_key   => lv_project_number||' '||lv_task_number,
                           owner_role => lv_initiator);
   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'PROJECT_ID',
                               avalue   => p_project_id);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                             itemkey  => ln_itemkey,
                             aname    => 'PROJECT_NUMBER',
                             avalue   => lv_project_number);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                             itemkey  => ln_itemkey,
                             aname    => 'TASK_NUMBER',
                             avalue   => lv_task_number);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                             itemkey  => ln_itemkey,
                             aname    => 'BUDGET_TYPE_CODE',
                             avalue   => p_budget_type_code);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                             itemkey  => ln_itemkey,
                             aname    => 'BUDGET_STATUS_CODE',
                             avalue   => p_budget_status_code);
   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                             itemkey  => ln_itemkey,
                             aname    => 'INITIATOR',
                             avalue   => lv_initiator);
   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'BUDGET_VERSION_ID',
                               avalue   => p_budget_version_id);
   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'INITIATOR_USER_ID',
                               avalue   => P_initiator);
   WF_ENGINE.StartProcess(itemtype => lv_item_type,
                          itemkey  => ln_itemkey);
   p_itemkey := ln_itemkey;
  END Budget_Initiate;
-- Procedure will be called from "XXHA Project Service Request" workflow to get the workflow attributes
-- and validate the budget status and decide to whom the notification should be sent
  PROCEDURE get_budget_attr_values(itemtype  in varchar2,
                                   itemkey   in varchar2,
                                   actid     in number,
                                   funcmode  in varchar2,
                                   resultout in out varchar2)  AS
     ln_budget_version_id    PA_BUDGET_VERSIONS.BUDGET_VERSION_ID%TYPE;
     lv_budget_status_code   PA_BUDGET_VERSIONS.BUDGET_STATUS_CODE%TYPE;
     lv_budget_type_code     PA_BUDGET_VERSIONS.BUDGET_TYPE_CODE%TYPE;
     ln_project_id           PA_PROJECTS_ALL.PROJECT_ID%TYPE;
     lv_sa_username          FND_USER.USER_NAME%TYPE;
     lv_sa_fullname          PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
     lv_pm_username          FND_USER.USER_NAME%TYPE;
     lv_pm_fullname          PER_ALL_PEOPLE_F.FULL_NAME%TYPE;
     lv_prebudget_status     VARCHAR2(20);
     lv_project_number       PA_PROJECTS_ALL.SEGMENT1%TYPE;
     lv_last_update_date     VARCHAR2(20);
     lv_error                VARCHAR2(1) := 'N';
     lv_error_subject        VARCHAR2(2000);
     lv_error_message        VARCHAR2(32000);
  BEGIN
     ln_budget_version_id := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                         itemkey  => itemkey,
                                                         aname    => 'BUDGET_VERSION_ID');
     lv_budget_status_code := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                        itemkey  => itemkey,
                                                        aname    => 'BUDGET_STATUS_CODE');
     lv_budget_type_code :=   WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                        itemkey  => itemkey,
                                                        aname    => 'BUDGET_TYPE_CODE');
     ln_project_id :=    WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                   itemkey  => itemkey,
                                                   aname    => 'PROJECT_ID');
     lv_project_number := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'PROJECT_NUMBER');
     lv_error_subject := 'Error for Project: '||lv_project_number;	-- Version 2.0
     lv_error_message := lv_project_number||CHR(10);			-- Version 2.0
     IF  lv_budget_status_code = 'B' THEN
     BEGIN
        SELECT max(xpv.budget_version_id),
               max(xpv.last_update_date)
        INTO   ln_budget_version_id,
	       lv_last_update_date
        FROM   pa_budget_versions xpv
        WHERE  version_number = (SELECT max(version_number)
                                 FROM   pa_budget_versions xpv1
   		                 WHERE  xpv1.project_id = xpv.project_id
   		                 AND    xpv1.budget_type_code = 'SR Approved Revenue Budget'
   		                 AND    xpv1.budget_status_code = 'B')
        AND    xpv.project_id = ln_project_id
        AND    xpv.budget_type_code = 'SR Approved Revenue Budget';
        WF_ENGINE.SetItemAttrNumber(itemtype => itemtype,
                                    itemkey  => itemkey,
                                    aname    => 'BUDGET_VERSION_ID',
                                    avalue   => ln_budget_version_id);
     EXCEPTION WHEN OTHERS THEN
       lv_error := 'Y';
       lv_error_subject := lv_error_subject||'Fetching Baselined Version ID';
       lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Baseline: '||SQLERRM;
     END;
     END IF;
     BEGIN
        SELECT SEGMENT1
        INTO   lv_project_number
        FROM   PA_PROJECTS_ALL PP
        WHERE  PROJECT_ID = ln_project_id;
        WF_ENGINE.SetItemAttrText(itemtype => itemtype,
	                          itemkey  => itemkey,
                                  aname    => 'PROJECT_NUMBER',
                                  avalue   => lv_project_number);
     EXCEPTION WHEN OTHERS THEN
       lv_error := 'Y';
       lv_error_subject := lv_error_subject||' '||'Fetching Project Details';
       lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Project Details: '||SQLERRM;
     END;
     BEGIN
       SELECT fu.user_name,
              ppf.full_name
       INTO   lv_sa_username,
              lv_sa_fullname
       FROM   pa_project_players ppp
             ,per_all_people_f ppf
             ,fnd_user fu
             ,pa_project_role_types_tl pprt
             ,pa_project_role_types_b ppr
       where  ppp.person_id = ppf.person_id
       and    fu.employee_id = ppf.person_id
       AND    ppr.project_role_type = ppp.project_role_type
       AND    pprt.project_role_id = ppr.project_role_id
       AND    pprt.language = 'US'
       AND    pprt.meaning = 'Sales Admin'         					-- Version 2.0
       and    sysdate between ppf.effective_start_date and ppf.effective_end_date
       AND    sysdate between ppp.start_date_active and nvl(ppp.end_date_active, sysdate+1)
       and    ppp.project_id = ln_project_id;
       WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                               itemkey  => itemkey,
                               aname    => 'SALES_ADMIN_USERNAME',
                               avalue   => lv_sa_username);
       WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                 itemkey  => itemkey,
                                 aname    => 'SALES_ADMIN_FULLNAME',
                                 avalue   => lv_sa_fullname);
    EXCEPTION WHEN OTHERS THEN
       lv_error := 'Y';
       lv_error_subject := lv_error_subject||' '||'Fetching Sales Admin Details';
       lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Sales Admin :'||SQLERRM;
    END;
    BEGIN
       SELECT fu.user_name,
              ppf.full_name
       INTO   lv_pm_username,
              lv_pm_fullname
       FROM   pa_project_players ppp
             ,per_all_people_f ppf
             ,fnd_user fu
             ,pa_project_role_types_tl pprt
             ,pa_project_role_types_b ppr
       where  ppp.person_id = ppf.person_id
       and    fu.employee_id = ppf.person_id
       AND    ppr.project_role_type = ppp.project_role_type
       AND    pprt.project_role_id = ppr.project_role_id
       AND    pprt.language = 'US'
       AND    pprt.meaning = 'Project Manager'         					-- Version 2.0
       and    sysdate between ppf.effective_start_date and ppf.effective_end_date
       AND    sysdate between ppp.start_date_active and nvl(ppp.end_date_active, sysdate+1)
       and    ppp.project_id = ln_project_id;
       WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                               itemkey  => itemkey,
                               aname    => 'PM_USERNAME',
                               avalue   => lv_pm_username);
       WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                               itemkey  => itemkey,
                               aname    => 'PM_NAME',
                               avalue   => lv_pm_fullname);
    EXCEPTION WHEN OTHERS THEN
       lv_error := 'Y';
       lv_error_subject := lv_error_subject||' '||'Fetching Project Manager Details';
       lv_error_message := NVL(lv_error_message, '')||CHR(10)||CHR(10)||'Project Manager :'||SQLERRM;
    END;
    IF lv_error = 'N' THEN
      IF  lv_budget_status_code = 'B' THEN
          resultout := 'COMPLETE:BUDGETBASELINED';
          RETURN;
      ELSIF lv_budget_status_code = 'S' THEN
         resultout := 'COMPLETE:NEW/UPDATEBUDGET';
         RETURN;
      END IF;
    ELSIF
      lv_error = 'Y' THEN
      WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                itemkey  => itemkey,
                                aname    => 'ERROR_SUBJECT',
                                avalue   => lv_error_subject);
      WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                               itemkey  => itemkey,
                               aname    => 'ERROR_MESSAGE',
                               avalue   => lv_error_message);
      resultout := 'COMPLETE:ERROR_OCCURED';
      RETURN;
    END IF;
  END;
END XXHA_PA_SERVICE_REQUEST_PKG;
/
