CREATE OR REPLACE package xxha_oh_sr_control_reciept_pkg
as
    PROCEDURE MAIN(
	       err_buf      out  VARCHAR2
              ,ret_code     OUT  VARCHAR2
              ,p_transaction_type_name IN VARCHAR2
              ,p_commit_flag  IN   VARCHAR2 DEFAULT 'Y'
              );
end xxha_oh_sr_control_reciept_pkg;

/


CREATE OR REPLACE package body XXHA_OH_SR_CONTROL_RECIEPT_PKG
as
    PROCEDURE MAIN(
	       err_buf      out  VARCHAR2
              ,ret_code     OUT  VARCHAR2
              ,p_transaction_type_name IN VARCHAR2
              ,p_commit_flag  IN   VARCHAR2 DEFAULT 'Y'
              ) is

        Cursor c_transaction_data is
        SELECT mp.organization_id,
               item.inventory_item_id,
               rc.revision,
               item.primary_uom_code,
               sub.secondary_inventory_name,
               rc.locator,
               rc.transaction_qty,
               rc.serial_number
        FROM HAEMO.XXHA_OH_SERIAL_CONTROL_RECEIPT rc,
             mtl_parameters mp,
             mtl_secondary_inventories sub,
             mtl_system_items_b item
        WHERE  1= 1
        AND   rc.segment1 = item.segment1
        and   rc.organization_code = mp.organization_code
        and   item.organization_id = mp.organization_id
        and   rc.subinventory_code = sub.secondary_inventory_name
        and   sub.organization_id = mp.organization_id;

 
  lc_code_combination_id   number;
  lc_transaction_type_id   number;
  lc_transaction_action_id number;
  lc_transaction_source_type_id  number;
  lc_material_transactions_id number;
  lc_count number := 0;
  lc_locator_id   number;
  lc_reason_id    number;

BEGIN


select code_combination_id
into lc_code_combination_id
from gl_code_combinations_kfv
where concatenated_segments = '100.000.000.0000.0000.131400.000.000000.000000';



select transaction_type_id, 
       transaction_action_id, 
       transaction_source_type_id
into   lc_transaction_type_id,
       lc_transaction_action_id,
       lc_transaction_source_type_id
from mtl_transaction_types
where transaction_type_name = p_transaction_type_name;


begin
    select reason_id 
    into   lc_reason_id
    from MTL_TRANSACTION_REASONS 
    where reason_name = 'SN CNV';
   
    exception
    when others
    then null;
end;

for r_transaction_data in c_transaction_data
loop

   lc_locator_id := null;  -- Added by R. George on 4/27/2009

   SELECT mtl_material_transactions_s.nextval
   INTO   lc_material_transactions_id
   FROM   DUAL;

   if (r_transaction_data.locator is not null and r_transaction_data.locator != '..' )
   then
   begin
   select distinct loc.inventory_location_id
   into lc_locator_id
   from mtl_item_locations_kfv loc
   where 1=1 
        and   loc.concatenated_segments =  r_transaction_data.locator
        and   loc.organization_id = r_transaction_data.organization_id
        and   loc.subinventory_code = r_transaction_data.secondary_inventory_name;

   exception
   when others
   then
       FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in deriving locator_id '||sqlerrm);
       --raise;
   end;
   else
       lc_locator_id := null;
   end if;



   insert into mtl_transactions_interface
	(
                                                     last_update_date
                                                    ,last_updated_by
                                                    ,creation_date
                                                    ,created_by
                                                    ,source_code
                                                    ,source_line_id
                                                    ,source_header_id
                                                    ,process_flag
                                                    ,transaction_mode
                                                    ,lock_flag
                                                    ,inventory_item_id
                                                    ,revision
                                                    ,organization_id
                                                    ,subinventory_code
                                                    ,locator_id
                                                    ,transaction_quantity
                                                    ,transaction_uom
                                                    ,transaction_date
                                                    ,transaction_type_id
                                                    ,distribution_account_id
                                                    ,transaction_interface_id
                                                    ,validation_required
                                                    ,transaction_source_name
                                                    , reason_id
                                                    )
                                             VALUES(
                                                    SYSDATE
                                                   ,fnd_global.user_id
                                                   ,SYSDATE
                                                   ,fnd_global.user_id
                                                   ,'INV ADJ'
                                                   ,1
                                                   ,1
                                                   ,1
                                                   ,3
                                                   ,2
                                                   ,r_transaction_data.inventory_item_id
                                                   ,r_transaction_data.revision
                                                   ,r_transaction_data.organization_id
                                                   ,r_transaction_data.secondary_inventory_name
                                                   ,lc_locator_id
                                                   ,decode(p_transaction_type_name,'Miscellaneous receipt',1,-1*r_transaction_data.transaction_qty)
                                                   ,r_transaction_data.primary_uom_code
                                                   ,sysdate
                                                   ,lc_transaction_type_id
                                                   ,lc_code_combination_id
                                                   ,lc_material_transactions_id
                                                   ,1
                                                   ,null
                                                   ,lc_reason_id
                                                  );

   if p_transaction_type_name = 'Miscellaneous receipt'
   then
		INSERT INTO mtl_serial_numbers_interface(
                                                       last_update_date
                                                      ,last_updated_by
                                                      ,creation_date
                                                      ,created_by
                                                      ,transaction_interface_id
                                                      ,fm_serial_number
						      ,to_serial_number
						       ,source_code
                                                      )
                                               VALUES(
                                                      SYSDATE
                                                     ,fnd_global.user_id
                                                     ,SYSDATE
                                                     ,fnd_global.user_id
                                                     ,lc_material_transactions_id
                                                     ,r_transaction_data.serial_number
						     ,r_transaction_data.serial_number
						     ,'INV ADJ'
                                                     );

   end if;
   lc_count := lc_count + 1;
end loop;
if (p_commit_flag = 'Y')
then
   commit;
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Committed');

else
   rollback;
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Rolled Back');
end if;

FND_FILE.PUT_LINE(FND_FILE.LOG,'Number of records processed '||lc_count);


EXCEPTION
WHEN OTHERS
THEN
    FND_FILE.PUT_LINE(FND_FILE.LOG,'Error :'||substr(sqlerrm,1,80));
    ret_code := 3;   
    rollback;    
END MAIN;
end XXHA_OH_SR_CONTROL_RECIEPT_PKG;
/
