CREATE OR REPLACE PACKAGE XXHA_ADDRESS_COMPRESS_PK AS

/*********************************************************************************************
* Package Name : XXHA_ADDRESS_COMPRESS_PK                                                    *
* Purpose      : This package provides functions to remove blank lines in an Address.        *
*                                                                                            *
* Used By      : XXHA: Sales Order Acknowledgment Report XX                                  *
*                                                                                            *
* PROCEDURE    : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        11-MAY-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
*********************************************************************************************/

PROCEDURE PROCESS_DATA (p_Addr1_I  IN OUT VARCHAR2
                      , p_Addr2_I  IN OUT VARCHAR2
                      , p_Addr3_I  IN OUT VARCHAR2
                      , p_Addr4_I  IN OUT VARCHAR2
                      , p_Addr5_I  IN OUT VARCHAR2
                      , p_Addr6_I  IN OUT VARCHAR2
                      , p_Addr7_I  IN OUT VARCHAR2
                      , p_Addr8_I  IN OUT VARCHAR2
                      , p_Addr9_I  IN OUT VARCHAR2
                      , p_Addr10_I IN OUT VARCHAR2
                      );

END XXHA_ADDRESS_COMPRESS_PK;
/


CREATE OR REPLACE PACKAGE BODY XXHA_ADDRESS_COMPRESS_PK AS

/*********************************************************************************************
* Package Name : XXHA_ADDRESS_COMPRESS_PK                                                    *
* Purpose      : This package provides functions to remove blank lines in an Address.        *
*                                                                                            *
* Used By      : XXHA: Sales Order Acknowledgment Report XX                                  *
*                                                                                            *
* PROCEDURE    : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        11-MAY-2011     B. Marcoux           Initial Package Creation                   *
*                                                 Incident# 49731                            *
*                                                                                            *
*********************************************************************************************/

  PROCEDURE PROCESS_DATA (p_Addr1_I  IN OUT VARCHAR2
                        , p_Addr2_I  IN OUT VARCHAR2
                        , p_Addr3_I  IN OUT VARCHAR2
                        , p_Addr4_I  IN OUT VARCHAR2
                        , p_Addr5_I  IN OUT VARCHAR2
                        , p_Addr6_I  IN OUT VARCHAR2
                        , p_Addr7_I  IN OUT VARCHAR2
                        , p_Addr8_I  IN OUT VARCHAR2
                        , p_Addr9_I  IN OUT VARCHAR2
                        , p_Addr10_I IN OUT VARCHAR2          
                        ) IS

    TYPE ADDRESS IS TABLE OF VARCHAR2(240) INDEX BY VARCHAR2(2);
    v_addressin  ADDRESS;
    v_addressout ADDRESS;

    v_index_I    INTEGER  := 1;
    v_index_O    INTEGER  := 1;
    v_max        INTEGER  := 10;

  BEGIN
--  Move Parameter Address Data to AddressIn
    v_addressin(1)  := p_Addr1_I;
    v_addressin(2)  := p_Addr2_I;
    v_addressin(3)  := p_Addr3_I;
    v_addressin(4)  := p_Addr4_I;
    v_addressin(5)  := p_Addr5_I;
    v_addressin(6)  := p_Addr6_I;
    v_addressin(7)  := p_Addr7_I;
    v_addressin(8)  := p_Addr8_I;
    v_addressin(9)  := p_Addr9_I;
    v_addressin(10) := p_Addr10_I;

--  Initialize AddressOut
    v_addressout(1)  := null;
    v_addressout(2)  := null;
    v_addressout(3)  := null;
    v_addressout(4)  := null;
    v_addressout(5)  := null;
    v_addressout(6)  := null;
    v_addressout(7)  := null;
    v_addressout(8)  := null;
    v_addressout(9)  := null;
    v_addressout(10) := null;

--  Loop through data and populate AddressOut(index) only
--  when there's data in AddressIn(index)
    LOOP
       IF v_addressin(v_index_I) IS NULL OR v_addressin(v_index_I) = ' ' THEN
          v_index_I := v_index_I + 1;
       ELSE
          v_addressout(v_index_O) := v_addressin(v_index_I);
          v_index_O := v_index_O + 1;
          v_index_I := v_index_I + 1;
       END IF;
    EXIT WHEN v_index_I > v_max;
    END LOOP;

--  Move AddressOut to Parameter Address Data
    p_Addr1_I   := v_addressout(1);
    p_Addr2_I   := v_addressout(2);
    p_Addr3_I   := v_addressout(3);
    p_Addr4_I   := v_addressout(4);
    p_Addr5_I   := v_addressout(5);
    p_Addr6_I   := v_addressout(6);
    p_Addr7_I   := v_addressout(7);
    p_Addr8_I   := v_addressout(8);
    p_Addr9_I   := v_addressout(9);
    p_Addr10_I  := v_addressout(10);

  END PROCESS_DATA;

END XXHA_ADDRESS_COMPRESS_PK;
/
