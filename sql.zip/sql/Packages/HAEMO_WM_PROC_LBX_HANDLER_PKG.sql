CREATE OR REPLACE PACKAGE HAEMO_WM_PROC_LBX_HANDLER_PKG IS
----------------------------------------------------------------------------------------------
-- Procedure to determine calling parameters for Process Lockbox Concurrent Request
-- Takes in the mandatory and optional parameters required for Process Lockbox Concurrent Request
-- Author: Eric Rossing, Haemonetics
--
-- Change log
-- 2010-04-23	Eric Rossing	Initial creation
-- 2013-10-23 Eric Rossing  Fixed to work with Oracle R12
----------------------------------------------------------------------------------------------

PROCEDURE HAEMO_WM_HANDLE_PROC_LOCKBOX(
	p_user_responsibility	IN VARCHAR,
	p_user					IN VARCHAR,
	v_status				OUT VARCHAR,
	v_request_id			OUT NUMBER,
	o_message				OUT VARCHAR,
	v_errmsg				OUT VARCHAR,
	p_transmission_name		IN VARCHAR2,
	p_data_file				IN VARCHAR2,
	p_cntrl_file			IN VARCHAR2,
	p_transmission_format	IN VARCHAR2,
	p_bank_origination_num	IN VARCHAR2,
	p_lockbox_number		IN VARCHAR2,
	p_org_id				IN NUMBER
	);


END HAEMO_WM_PROC_LBX_HANDLER_PKG;
/


CREATE OR REPLACE PACKAGE BODY HAEMO_WM_PROC_LBX_HANDLER_PKG IS
----------------------------------------------------------------------------------------------
-- Procedure to determine calling parameters for Process Lockbox Concurrent Request
-- Takes in the mandatory and optional parameters required for Process Lockbox Concurrent Request
-- Author: Eric Rossing, Haemonetics
--
-- Change log
-- 2010-04-23      Eric Rossing         Initial creation
-- 2013-10-23     Eric Rossing  Fixed to work with Oracle R12
-- 2013-12-18    Vijay Samba  Added code fnd_request.set_org_id(fnd_global.org_id) ; to set ORG_ID to make the progarm run with MOAC enabled responsibility in R12
----------------------------------------------------------------------------------------------

PROCEDURE HAEMO_WM_HANDLE_PROC_LOCKBOX(
                p_user_responsibility    IN VARCHAR,
                p_user                                                                  IN VARCHAR,
                v_status                                                               OUT VARCHAR,
                v_request_id                                     OUT NUMBER,
                o_message                                                         OUT VARCHAR,
                v_errmsg                                                             OUT VARCHAR,
                p_transmission_name                   IN VARCHAR2,
                p_data_file                                                         IN VARCHAR2,
                p_cntrl_file                                         IN VARCHAR2,
                p_transmission_format                IN VARCHAR2,
                p_bank_origination_num            IN VARCHAR2,
                p_lockbox_number                        IN VARCHAR2,
                p_org_id                                                              IN NUMBER
                )
                IS
                v_program                                                                          VARCHAR2(20):='ARLPLB'; -- Process Lockboxes
                v_application                                                     VARCHAR2(20):='AR'; -- Application
                v_application_id                                               NUMBER;
                v_user_id                                                                            NUMBER;
                v_user_responsibility_id              NUMBER;
                v_new_transmission                                      VARCHAR2(1):='Y';
                v_submit_import                                                             VARCHAR2(1):='Y';
                v_transmission_format_id          NUMBER;
                v_submit_validation                                       VARCHAR2(1):='Y';
                v_pay_unrelated_invoices          VARCHAR2(1):='N';
                v_lockbox_id                                                     NUMBER;
                v_report_format                                                             VARCHAR2(1):='A';
                v_complete_batches_only                          VARCHAR2(1):='N';
                v_submit_postbatch                                      VARCHAR2(1):='Y';
                v_alternate_name_search                          VARCHAR2(1):='N';
                v_ignore_invalid_txn_num  VARCHAR(1):='Y';
BEGIN

                -- Fetch Application id for Application
                v_errmsg:='Fetching the Application Id';

                SELECT application_id
                INTO   v_application_id
                FROM   fnd_application
                WHERE  application_short_name = v_application;

                -- Fetch the User Id
                v_errmsg:='Fetching the User Id';
                v_user_id:=wm_conc_request_pkg.get_user_id(p_user);

                -- Fetch the Responsibility Id
                v_errmsg:='Fetching the Responsibility Id';

                v_user_responsibility_id:= wm_conc_request_pkg.get_user_responsibility_id( p_user_responsibility);

                v_errmsg:='Fetching the Transmission Format ID';

                IF p_transmission_format IS NOT NULL THEN
                                SELECT transmission_format_id
                                INTO   v_transmission_format_id
                                FROM   ar_transmission_formats
                                WHERE  format_name = p_transmission_format;
                END IF;

                v_errmsg:='Fetching the Lockbox ID';

                IF p_bank_origination_num IS NOT NULL AND p_lockbox_number IS NOT NULL THEN
                                SELECT lockbox_id
                                INTO   v_lockbox_id
                                FROM   ar_lockboxes_all
                                WHERE  bank_origination_number = p_bank_origination_num
                                AND    lockbox_number = p_lockbox_number;
                END IF;

                Fnd_Global.Apps_Initialize(V_User_Id,V_User_Responsibility_Id,V_Application_Id);
                --Fnd_Request.Set_Org_Id(Fnd_Global.Org_Id) ; -- Added by VSAMBA for R12 Upgrade bug fix  on 12/18/2013
                mo_global.set_policy_context('S',p_org_id);
                fnd_request.set_org_id(p_org_id) ; -- Added by VSAMBA for R12 Upgrade bug fix  on 12/18/2013


                -- Call to submit request
                v_errmsg:='Submitting the Concurrent Request';

                Wm_Conc_Request_Pkg.wm_request_submit(v_application_id,
                                v_user_responsibility_id,
                                v_user_id,
                                v_application,
                                v_program,
                                v_status,
                                v_request_id,
                                NULL,
                                NULL,
                                o_message,
                                v_errmsg,
                                -- beginning of parameters
                                v_new_transmission,
                                NULL,
                                NULL,
                                p_transmission_name,
                                v_submit_import,
                                p_data_file,
                                p_cntrl_file,
                                v_transmission_format_id,
                                v_submit_validation,
                                v_pay_unrelated_invoices,
                                v_lockbox_id,
                                NULL,
                                v_report_format,
                                v_complete_batches_only,
                                v_submit_postbatch,
                                v_alternate_name_search,
                                v_ignore_invalid_txn_num,
                                NULL,
                                p_org_id,
                                'N',
                                1,
                                'L',
                                NULL
                                );

EXCEPTION
                WHEN OTHERS THEN
                                v_errmsg:=v_errmsg||SQLERRM;

END HAEMO_WM_HANDLE_PROC_LOCKBOX;

END HAEMO_WM_PROC_LBX_HANDLER_PKG;
/
