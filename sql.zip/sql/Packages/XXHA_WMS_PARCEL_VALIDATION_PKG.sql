create or replace PACKAGE "XXHA_WMS_PARCEL_VALIDATION_PKG"
  /*******************************************************************************************************
  * Object Name: XXHA_WMS_PARCEL_VALIDATION_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package will be used in verification process
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    16-JAN-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
AS
   FUNCTION XXHA_WMS_PARCEL_VALIDATION(
      p_delivery_id NUMBER)
    RETURN VARCHAR2;
END XXHA_WMS_PARCEL_VALIDATION_PKG;
/
create or replace PACKAGE BODY "XXHA_WMS_PARCEL_VALIDATION_PKG"
/*******************************************************************************************************
  * Object Name: XXHA_WMS_PARCEL_VALIDATION_PKG
  * Object Type: PACKAGE
  *
  * Description: This Package will be used in verification process
  *
  * Modification Log:
  * Developer          Date                 Description
  *-----------------   ------------------   ------------------------------------------------
  * Apps Associates    16-JAN-2015          Initial object creation.
  *
  *
  *******************************************************************************************************/
AS
FUNCTION "XXHA_WMS_PARCEL_VALIDATION"(
    p_delivery_id NUMBER)
  RETURN VARCHAR2
AS
  l_status VARCHAR2(100);
  l_count  NUMBER;
  l_count1 NUMBER;
BEGIN
  BEGIN
    SELECT COUNT(distinct wnd.delivery_id)
    INTO l_count
    FROM wsh_new_deliveries wnd,
      wsh_delivery_assignments wda,
      wsh_delivery_details wdd
    WHERE wda.delivery_Detail_id = wdd.delivery_Detail_id
    AND wda.delivery_id          = wnd.delivery_id
    AND wnd.delivery_id          =p_delivery_id
    AND EXISTS
      (SELECT 1
      FROM wsh_container_items wci
      WHERE wci.master_organization_id = wdd.organization_id
      AND wci.load_item_id             = wdd.inventory_item_id
      );
  EXCEPTION
  WHEN no_data_found THEN
    l_status:='N';
  END;
  IF l_count =1 THEN
    l_status:='Y';
    RETURN l_status;
  ELSE
    l_status:='N';
  END IF;
  BEGIN
    SELECT COUNT(DISTINCT wnd.delivery_id)
    INTO l_count1
    FROM wsh_new_deliveries wnd,
      wsh_delivery_assignments wda,
      wsh_delivery_details wdd
    WHERE wda.delivery_Detail_id = wdd.delivery_Detail_id
    AND wda.delivery_id          = wnd.delivery_id
    AND wnd.delivery_id          =p_delivery_id
    AND EXISTS
      (SELECT 1
      FROM WSH_CARRIERS_V
      WHERE upper(CARRIER_NAME) LIKE '%FEDEX%'
      AND carrier_id=wnd.carrier_id
      )
    AND EXISTS
      (SELECT 1
      FROM hz_locations hl
      WHERE hl.location_id=wdd.ship_to_location_id
      AND hl.country NOT IN ('US','CA')
      );
  EXCEPTION
  WHEN no_data_found THEN
    l_status:='N';
  END;
  IF l_count1 =1 THEN
    l_status :='Y';
    RETURN l_status;
  ELSE
    l_status:='N';
  END IF;
 RETURN l_status;
END;
END XXHA_WMS_PARCEL_VALIDATION_PKG;
/


