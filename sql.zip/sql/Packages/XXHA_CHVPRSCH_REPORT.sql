CREATE OR REPLACE PACKAGE XXHA_CHVPRSCH_REPORT AUTHID CURRENT_USER AS

/*****************************************************************************************
* Package Name : XXHA_CHVPRSCH_REPORT                                                    *
* Purpose      : This package provides functions to retrieve counts for records in the   *
*                table 'chv_horizontal_schedules'.  This package will be used by the     *
*                XML Report 'Printed Planning Schedule Report'.                          *
*                                                                                        *
* Procedures   :  P_Count_All_Rows                                                       *
*                 P_Count_Row_1                                                          *
*                 P_Count_Row_2                                                          *
*                 P_Count_Row_3                                                          *
*                 P_Count_Row_4                                                          *
*                 P_Count_Row_5                                                          *
*                 P_Count_Row_6                                                          *
*                                                                                        *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*    chv_horizontal_schedules	      S                                                    *
*                                                                                        *
* Change History                                                                         *
*                                                                                        *
* Ver        Date            Author               Description                            *
* ------     -----------     -----------------    ---------------                        *
* 1.0        25-SEP-2009     B. Marcoux           Initial Version                        *
*****************************************************************************************/

/* globals for cache */
gv_count              NUMBER           := NULL;

/* ************************************************************************************ */
PROCEDURE P_Count_All_Rows (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                            P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                            P_count             OUT NUMBER) ;                    

FUNCTION F_Rows_All  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                      P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER;

/* ************************************************************************************ */
PROCEDURE P_Count_Row1 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER) ;                    

FUNCTION F_Row1  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER;

/* ************************************************************************************ */
PROCEDURE P_Count_Row2 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER) ;                    

FUNCTION F_Row2  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER;

/* ************************************************************************************ */
PROCEDURE P_Count_Row3 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER) ;                    

FUNCTION F_Row3  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER;

/* ************************************************************************************ */
PROCEDURE P_Count_Row4 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER) ;                    

FUNCTION F_Row4  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER;

/* ************************************************************************************ */
PROCEDURE P_Count_Row5 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER) ;                    

FUNCTION F_Row5  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER;

/* ************************************************************************************ */
PROCEDURE P_Count_Row6 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER) ;                    

FUNCTION F_Row6  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER;

END XXHA_CHVPRSCH_REPORT;
/


CREATE OR REPLACE PACKAGE BODY XXHA_CHVPRSCH_REPORT AS

PROCEDURE P_Count_All_Rows (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                            P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                            P_count             OUT NUMBER)  AS
BEGIN

SELECT

SUM
(
NVL(chs.column1,0)  + 
NVL(chs.column2,0)  +
NVL(chs.column3,0)  +
NVL(chs.column4,0)  +
NVL(chs.column5,0)  +
NVL(chs.column6,0)  + 
NVL(chs.column7,0)  +
NVL(chs.column8,0)  +
NVL(chs.column9,0)  +
NVL(chs.column10,0) +
NVL(chs.column11,0) + 
NVL(chs.column12,0) +
NVL(chs.column13,0) +
NVL(chs.column14,0) +
NVL(chs.column15,0) +
NVL(chs.column16,0) + 
NVL(chs.column17,0) +
NVL(chs.column18,0) +
NVL(chs.column19,0) +
NVL(chs.column20,0) +
NVL(chs.column21,0) + 
NVL(chs.column22,0) +
NVL(chs.column23,0) +
NVL(chs.column24,0) +
NVL(chs.column25,0) +
NVL(chs.column26,0) + 
NVL(chs.column27,0) +
NVL(chs.column28,0) +
NVL(chs.column29,0) +
NVL(chs.column30,0) +
NVL(chs.column31,0) + 
NVL(chs.column32,0) +
NVL(chs.column33,0) +
NVL(chs.column34,0) +
NVL(chs.column35,0) +
NVL(chs.column36,0) + 
NVL(chs.column37,0) +
NVL(chs.column38,0) +
NVL(chs.column39,0) +
NVL(chs.column40,0) +
NVL(chs.column41,0) + 
NVL(chs.column42,0) +
NVL(chs.column43,0) +
NVL(chs.column44,0) +
NVL(chs.column45,0) +
NVL(chs.column46,0) + 
NVL(chs.column47,0) +
NVL(chs.column48,0) +
NVL(chs.column49,0) +
NVL(chs.column50,0) +
NVL(chs.column51,0) + 
NVL(chs.column52,0) +
NVL(chs.column53,0) +
NVL(chs.column54,0) +
NVL(chs.column55,0) +
NVL(chs.column56,0) + 
NVL(chs.column57,0) +
NVL(chs.column58,0) +
NVL(chs.column59,0) +
NVL(chs.column60,0)
)

INTO
    p_count

FROM 
    apps.chv_horizontal_schedules  chs
,   apps.po_lookup_codes           plcr1
,   apps.po_lookup_codes           plcr2

WHERE 
    chs.row_type              not in ('BUCKET_DESCRIPTOR', 'BUCKET_END_DATE')
AND chs.schedule_id           = P_schedule_id
AND chs.schedule_item_id      = P_schedule_item_id
AND chs.row_type              = plcr1.lookup_code
AND chs.row_type              = plcr2.lookup_code
AND plcr1.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND plcr2.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND chs.row_select_order      in (3,4,5) -- Row 2 has the dates (which we ignore) AND Rows 3-5 have quantities, Row 6 has Totals (which we ignore)
;

END P_Count_All_Rows;

FUNCTION F_Rows_All  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                      P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_All_Rows(P_schedule_id, P_schedule_item_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Rows_All;

--------------------------------------------------------------------------------
PROCEDURE P_Count_Row1 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER)  AS
BEGIN

SELECT

SUM
(
NVL(chs.column1,0)  + 
NVL(chs.column2,0)  +
NVL(chs.column3,0)  +
NVL(chs.column4,0)  +
NVL(chs.column5,0)  +
NVL(chs.column6,0)  + 
NVL(chs.column7,0)  +
NVL(chs.column8,0)  +
NVL(chs.column9,0)  +
NVL(chs.column10,0) 
)

INTO
    p_count

FROM 
    apps.chv_horizontal_schedules  chs
,   apps.po_lookup_codes           plcr1
,   apps.po_lookup_codes           plcr2

WHERE 
    chs.row_type              not in ('BUCKET_DESCRIPTOR', 'BUCKET_END_DATE')
AND chs.schedule_id           = P_schedule_id
AND chs.schedule_item_id      = P_schedule_item_id
AND chs.row_type              = plcr1.lookup_code
AND chs.row_type              = plcr2.lookup_code
AND plcr1.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND plcr2.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND chs.row_select_order      in (3,4,5) -- Row 2 has the dates (which we ignore) AND Rows 3-5 have quantities, Row 6 has Totals (which we ignore)
;

END P_Count_Row1;

FUNCTION F_Row1  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_Row1(P_schedule_id, P_schedule_item_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Row1;

--------------------------------------------------------------------------------
PROCEDURE P_Count_Row2 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER)  AS
BEGIN

SELECT

SUM
(
NVL(chs.column11,0) + 
NVL(chs.column12,0) +
NVL(chs.column13,0) +
NVL(chs.column14,0) +
NVL(chs.column15,0) +
NVL(chs.column16,0) + 
NVL(chs.column17,0) +
NVL(chs.column18,0) +
NVL(chs.column19,0) +
NVL(chs.column20,0) 
)

INTO
    p_count

FROM 
    apps.chv_horizontal_schedules  chs
,   apps.po_lookup_codes           plcr1
,   apps.po_lookup_codes           plcr2

WHERE 
    chs.row_type              not in ('BUCKET_DESCRIPTOR', 'BUCKET_END_DATE')
AND chs.schedule_id           = P_schedule_id
AND chs.schedule_item_id      = P_schedule_item_id
AND chs.row_type              = plcr1.lookup_code
AND chs.row_type              = plcr2.lookup_code
AND plcr1.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND plcr2.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND chs.row_select_order      in (3,4,5) -- Row 2 has the dates (which we ignore) AND Rows 3-5 have quantities, Row 6 has Totals (which we ignore)
;

END P_Count_Row2;

FUNCTION F_Row2  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_Row2(P_schedule_id, P_schedule_item_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Row2;

--------------------------------------------------------------------------------
PROCEDURE P_Count_Row3 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER)  AS
BEGIN

SELECT

SUM
(
NVL(chs.column21,0) + 
NVL(chs.column22,0) +
NVL(chs.column23,0) +
NVL(chs.column24,0) +
NVL(chs.column25,0) +
NVL(chs.column26,0) + 
NVL(chs.column27,0) +
NVL(chs.column28,0) +
NVL(chs.column29,0) +
NVL(chs.column30,0)
)

INTO
    p_count

FROM 
    apps.chv_horizontal_schedules  chs
,   apps.po_lookup_codes           plcr1
,   apps.po_lookup_codes           plcr2

WHERE 
    chs.row_type              not in ('BUCKET_DESCRIPTOR', 'BUCKET_END_DATE')
AND chs.schedule_id           = P_schedule_id
AND chs.schedule_item_id      = P_schedule_item_id
AND chs.row_type              = plcr1.lookup_code
AND chs.row_type              = plcr2.lookup_code
AND plcr1.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND plcr2.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND chs.row_select_order      in (3,4,5) -- Row 2 has the dates (which we ignore) AND Rows 3-5 have quantities, Row 6 has Totals (which we ignore)
;

END P_Count_Row3;

FUNCTION F_Row3  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_Row3(P_schedule_id, P_schedule_item_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Row3;

--------------------------------------------------------------------------------
PROCEDURE P_Count_Row4 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER)  AS

BEGIN

SELECT

SUM
(
NVL(chs.column31,0) + 
NVL(chs.column32,0) +
NVL(chs.column33,0) +
NVL(chs.column34,0) +
NVL(chs.column35,0) +
NVL(chs.column36,0) + 
NVL(chs.column37,0) +
NVL(chs.column38,0) +
NVL(chs.column39,0) +
NVL(chs.column40,0)
)

INTO
    p_count

FROM 
    apps.chv_horizontal_schedules  chs
,   apps.po_lookup_codes           plcr1
,   apps.po_lookup_codes           plcr2

WHERE 
    chs.row_type              not in ('BUCKET_DESCRIPTOR', 'BUCKET_END_DATE')
AND chs.schedule_id           = P_schedule_id
AND chs.schedule_item_id      = P_schedule_item_id
AND chs.row_type              = plcr1.lookup_code
AND chs.row_type              = plcr2.lookup_code
AND plcr1.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND plcr2.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND chs.row_select_order      in (3,4,5) -- Row 2 has the dates (which we ignore) AND Rows 3-5 have quantities, Row 6 has Totals (which we ignore)
;

END P_Count_Row4;

FUNCTION F_Row4  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_Row4(P_schedule_id, P_schedule_item_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Row4;

--------------------------------------------------------------------------------
PROCEDURE P_Count_Row5 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER)  AS
BEGIN

SELECT

SUM
(
NVL(chs.column41,0) + 
NVL(chs.column42,0) +
NVL(chs.column43,0) +
NVL(chs.column44,0) +
NVL(chs.column45,0) +
NVL(chs.column46,0) + 
NVL(chs.column47,0) +
NVL(chs.column48,0) +
NVL(chs.column49,0) +
NVL(chs.column50,0)
)

INTO
    p_count

FROM 
    apps.chv_horizontal_schedules  chs
,   apps.po_lookup_codes           plcr1
,   apps.po_lookup_codes           plcr2

WHERE 
    chs.row_type              not in ('BUCKET_DESCRIPTOR', 'BUCKET_END_DATE')
AND chs.schedule_id           = P_schedule_id
AND chs.schedule_item_id      = P_schedule_item_id
AND chs.row_type              = plcr1.lookup_code
AND chs.row_type              = plcr2.lookup_code
AND plcr1.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND plcr2.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND chs.row_select_order      in (3,4,5) -- Row 2 has the dates (which we ignore) AND Rows 3-5 have quantities, Row 6 has Totals (which we ignore)
;

END P_Count_Row5;

FUNCTION F_Row5  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_Row5(P_schedule_id, P_schedule_item_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Row5;

--------------------------------------------------------------------------------
PROCEDURE P_Count_Row6 (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                        P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE,
                        P_count             OUT NUMBER)  AS
BEGIN

SELECT

SUM
(
NVL(chs.column51,0) + 
NVL(chs.column52,0) +
NVL(chs.column53,0) +
NVL(chs.column54,0) +
NVL(chs.column55,0) +
NVL(chs.column56,0) + 
NVL(chs.column57,0) +
NVL(chs.column58,0) +
NVL(chs.column59,0) +
NVL(chs.column60,0)
)

INTO
    p_count

FROM 
    apps.chv_horizontal_schedules  chs
,   apps.po_lookup_codes           plcr1
,   apps.po_lookup_codes           plcr2

WHERE 
    chs.row_type              not in ('BUCKET_DESCRIPTOR', 'BUCKET_END_DATE')
AND chs.schedule_id           = P_schedule_id
AND chs.schedule_item_id      = P_schedule_item_id
AND chs.row_type              = plcr1.lookup_code
AND chs.row_type              = plcr2.lookup_code
AND plcr1.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND plcr2.lookup_type         = 'SCHEDULE_ROW_TYPE'
AND chs.row_select_order      in (3,4,5) -- Row 2 has the dates (which we ignore) AND Rows 3-5 have quantities, Row 6 has Totals (which we ignore)
;

END P_Count_Row6;

FUNCTION F_Row6  (P_schedule_id       IN chv_horizontal_schedules.schedule_id%TYPE,
                  P_schedule_item_id  IN chv_horizontal_schedules.schedule_item_id%TYPE)
RETURN NUMBER AS
BEGIN

    P_Count_Row6(P_schedule_id, P_schedule_item_id, gv_count);

    RETURN(gv_count);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       RETURN 0;
  WHEN OTHERS THEN
       RETURN 0;

END F_Row6;

END XXHA_CHVPRSCH_REPORT;
/
