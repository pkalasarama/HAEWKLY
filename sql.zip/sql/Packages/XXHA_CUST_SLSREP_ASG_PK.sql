CREATE OR REPLACE package      XXHA_CUST_SLSREP_ASG_PK
as
-- +=============================================================================+
-- | Name             :  XXHA_CUST_SLSREP_ASG_PK
-- | Description      :  This package supports the processing of files containing
-- |                     records representing updates to the salesrep assigned at
-- |                     customer site use level.
-- |                     The main program spawns a host concurrent program which
-- |                     uses SQL*Loader to upload the records to a custom
-- |                     staging table.  After loading is completed, it then
-- |                     spawns a pl/sql concurrent program to process the staged
-- |                     data.
-- |                     Processing first validates the records - any errors are
-- |                     logged in the XXHA_COMMON_ERRORS table.  Next, valid
-- |                     records are then scanned to invoke a seeded API for
-- |                     updating the customer site use records.  Finally, an
-- |                     error report is launched if any errors were logged
-- |                     previously.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-01-09  L.Richards     Initial release
-- +=============================================================================+

-------------------------------------------------------------------------
--The Global Variables
-------------------------------------------------------------------------
gc_attribute1            xxha_common_errors.attribute1%type;                                             --Attribute1 insert in common error table
gc_attribute2            xxha_common_errors.attribute2%type;                                             --Attribute2 insert in common error table
gc_attribute3            xxha_common_errors.attribute3%type;                                             --Attribute3 insert in common error table
gc_attribute4            xxha_common_errors.attribute4%type;                                             --Attribute4 insert in common error table
gc_attribute5            xxha_common_errors.attribute5%type;                                             --Attribute5 insert in common error table
gc_conc_name             fnd_concurrent_programs.concurrent_program_name%type :='XXHACUSTSLSREPASG';     --Concurrent program name to delete the records from common error table
gc_comments              xxha_common_errors.comments%type;                                               --Comments   insert in common error table
gc_error_code            xxha_common_errors.error_code%type;                                             --Error_code insert in common error table
gc_error_msg             xxha_common_errors.error_msg%type;                                              --Error_msg  insert in common error table
gc_log_message           VARCHAR2(2000);                                                                 --Variable to hold Log Messages
gc_record_identifier     xxha_common_errors.record_identifier%type;                                      --Record identifier of staging table
gc_status                VARCHAR2(2);                                                                    --Variable to get the Status of the Error Table insertion procedure
gc_table_name            xxha_common_errors.table_name%type :='XXHA_CUST_SLSREP_ASG_STG';                --Variable to get Staging Table Name
gn_login_id              fnd_logins.login_id%type := FND_GLOBAL.LOGIN_ID;                                --Login name for running conversion program
gn_request_id            fnd_concurrent_requests.request_id%type      := FND_GLOBAL.CONC_REQUEST_ID;     --Variable to buffer request id of Main Conc Program
gn_child_request1_id     fnd_concurrent_requests.request_id%type      := FND_GLOBAL.CONC_REQUEST_ID;     --Variable to buffer request id of Loader Conc Program
gn_child_request2_id     fnd_concurrent_requests.request_id%type      := FND_GLOBAL.CONC_REQUEST_ID;     --Variable to buffer request id of Record Processing Conc Program
gc_file_name             VARCHAR2(100);                                                                  --Variable to hold the file name
gn_record_number         xxha_cust_slsrep_asg_stg.rec_num%type:=NULL;                                    --Record_number of staging table
gn_user_id               fnd_user.user_id%type := FND_GLOBAL.USER_ID;                                    --User name for running Interface program
gn_ou_org_id             hr_operating_units.organization_id%type;                                        --Variable to buffer specified OU Org ID (input parameter)
gc_ou_name               hr_operating_units.name%type;                                                   --Variable to buffer OU Name matched to specified OU Org ID (input parameter)
gc_debug_flag            varchar2(1);

-- Procedure to purge the staging table
-- This procedure is called from the Host concurrent program which runs SQL*Loader
procedure PURGE_STAGING_TABLE (
         p_ou_org_id  in  number
        );

-- Procedure to update the staging table
-- This procedure is called from the Host concurrent program which runs SQL*Loader
procedure UPDATE_STAGING_TABLE (
         p_file_name  in  varchar2
        ,p_request_id  in  number
        ,p_ou_org_id  in  number
        );

-- Procedure to Validate and process ADP to GL Journal records
procedure PROCESS_RECORDS (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_ou_org_id  in  number
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
        );

-- Procedure to sumbit the host (Loader) and Process Records concurrent programs.
procedure MAIN (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_ou_org_id  in  number
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
        );

END XXHA_CUST_SLSREP_ASG_PK;

/


CREATE OR REPLACE package body      XXHA_CUST_SLSREP_ASG_PK
as
-- +=============================================================================+
-- | Name             :  XXHA_CUST_SLSREP_ASG_PK
-- | Description      :  This package supports the processing of files containing
-- |                     records representing updates to the salesrep assigned at
-- |                     customer site use level.
-- |                     The main program spawns a host concurrent program which
-- |                     uses SQL*Loader to upload the records to a custom
-- |                     staging table.  After loading is completed, it then
-- |                     spawns a pl/sql concurrent program to process the staged
-- |                     data.
-- |                     Processing first validates the records - any errors are
-- |                     logged in the XXHA_COMMON_ERRORS table.  Next, valid
-- |                     records are then scanned to invoke a seeded API for
-- |                     updating the customer site use records.  Finally, an
-- |                     error report is launched if any errors were logged
-- |                     previously.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-01-09  L.Richards     Initial release
-- |  1.1      2008-03-21  L.Richards     PreProduction : if site is inactive,
-- |                                      allow reassignment to go forward
-- +=============================================================================+


-- +=========================================================================
-- |  This procedure logs errors into error table
-- +=========================================================================
PROCEDURE log_error_for_report
          is
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gn_child_request2_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                             );
EXCEPTION
  when others then
     fnd_file.put_line(fnd_file.log,'Error in procedure LOG_ERROR_FOR_REPORT : ' ||SQLERRM);
END log_error_for_report;


-- +=========================================================================
-- |  This procedure updates assignments for successfully validated
-- |  records in the staging table
-- +=========================================================================
PROCEDURE update_assignments (
         x_cnt_notupdated  out  number
        ) is
  ln_cnt_read  number := 0;
  ln_cnt_update_ok  number := 0;
  ln_cnt_update_notok  number := 0;
  ln_cnt_nochng  number := 0;
  lc_errcode  varchar2(30);
  lc_errmsg  varchar2(2000);
  lc_update_status  varchar2(2);

  -- declaration for API hz_cust_account_site_v2pub.update_cust_site_use
  lr_cust_site_use_rec  hz_cust_account_site_v2pub.cust_site_use_rec_type;

  -- other variables for API call
  ln_ovn  number;  -- object version number
  ln_count  number;
  lc_data  varchar2(4000);
  lc_api_status  varchar2(20);
  lc_prefix  varchar2(30);

  -- Cursor for new records
  cursor c_val (
           q_ou_name  varchar2
          ) is
    select  stg.*
           ,stg.rowid
    from    xxha_cust_slsrep_asg_stg  stg
    where   stg.status = 'VS'
    and     stg.ou_name = q_ou_name;

BEGIN
   gc_log_message := 'Performing Assignment Update';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);

   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,rpad('-',50,'-'));
   fnd_file.put_line(fnd_file.output,' ');


   for valrec in c_val (gc_ou_name)
   loop
      ln_cnt_read := ln_cnt_read + 1;

      gc_record_identifier:= valrec.file_name;
      gn_record_number := valrec.rec_num;
      lc_errcode := null;
      lc_errmsg := null;
      lc_update_status := null;

      gc_log_message  :='Updating record '||valrec.rec_num||' ... CustNo='||valrec.customer_number
                                                              ||' SiteNo='||valrec.site_number
                                                                    ||' ('||upper(valrec.site_use)||')'
                                                           ||' SalerepNo='||valrec.salesrep_number;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);


      -- if new salesrep is the same as old, then no need to reassign
      -- otherwise, call the API to update the assignment
      if (valrec.salesrep_id_new = valrec.salesrep_id_old) then

         lc_update_status := 'PS';             -- flag as successful
         ln_cnt_nochng := ln_cnt_nochng + 1;

      else
         --prep for API call
         lr_cust_site_use_rec := null;
         lr_cust_site_use_rec.site_use_id := valrec.site_use_id;
         lr_cust_site_use_rec.primary_salesrep_id := valrec.salesrep_id_new;
         ln_ovn := valrec.site_use_ovn;

         -- call API to set new value
         hz_cust_account_site_v2pub.update_cust_site_use (
                   p_init_msg_list => FND_API.G_FALSE
                  ,p_cust_site_use_rec => lr_cust_site_use_rec
                  ,p_object_version_number => ln_ovn
                  ,x_return_status => lc_api_status
                  ,x_msg_count => ln_count
                  ,x_msg_data => lc_data
                  );

         if (lc_api_status = FND_API.G_RET_STS_SUCCESS) then
            lc_update_status := 'PS';
            ln_cnt_update_ok := ln_cnt_update_ok + 1;
         else
            -- must be an error ...
            lc_update_status := 'PE';
            ln_cnt_update_notok := ln_cnt_update_notok + 1;

            gc_error_code := 'CSA60';
            if (ln_count >= 1) then
               for i in 1..ln_count
               loop
                  gc_error_msg := substr(fnd_msg_pub.get(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                  fnd_file.put_line(fnd_file.output,gc_error_msg);
               end loop;
            end if;
            gc_comments := 'Call to API hz_cust_account_site_v2pub.UPDATE_CUST_SITE_USE';
            log_error_for_report;

            gc_log_message := gc_error_code||' - '||gc_error_msg;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);
         end if;
      end if;

      update  xxha_cust_slsrep_asg_stg
      set     status = lc_update_status
      where   rowid = valrec.rowid;

      commit;

      if (lc_update_status = 'PS') then
         if (valrec.salesrep_id_new = valrec.salesrep_id_old) then
            lc_prefix := 'Update skipped   :';
         else
            lc_prefix := 'Update succeeded :';
         end if;
      else  -- must be 'PE'
         lc_prefix := 'Update failed    :';
      end if;
      --fnd_file.put_line(fnd_file.output,lc_prefix||' RecNum='||valrec.rec_num
      --                                           ||' CustNo='||valrec.customer_number
      --                                           ||' SiteNo='||valrec.site_number
      --                                                 ||' ('||upper(valrec.site_use)||')'
      --                                        ||' SalerepNo='||valrec.salesrep_number
      --                                      ||' SalerepName='||valrec.salesrep_name
      --                 );
   end loop;

   -------------------------------------------------------------------------
   -- Summary Of Assignments Update Process
   -------------------------------------------------------------------------
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Assignments Update Summary');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Records Processed      :   ' ||ln_cnt_read);
   fnd_file.put_line(fnd_file.output,'  Salesreps Unchanged  :   ' ||ln_cnt_nochng);
   fnd_file.put_line(fnd_file.output,'  Updates Succeeded    :   ' ||ln_cnt_update_ok);
   fnd_file.put_line(fnd_file.output,'  Updates Failed       :   ' ||ln_cnt_update_notok);
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));

   x_cnt_notupdated := ln_cnt_update_notok;

END update_assignments;


-- +====================================================================
-- |  This function validates the Customer Number and returns the
-- |  corresponding CUST_ACCOUNT_ID
-- +====================================================================
function valid_customer (
         p_customer_number  in  varchar2
        ,x_cust_account_id  out  number
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is

  e_null_customer  exception;

BEGIN
   if (p_customer_number is null) then
      raise e_null_customer;
   end if;

   select  ca.cust_account_id
   into    x_cust_account_id
   from    hz_cust_accounts  ca
   where   ca.account_number = p_customer_number;

   return(true);
EXCEPTION
   when e_null_customer then
      x_errcode := 'CSA20';
      x_errmsg := 'Missing Customer Number';
      return(false);
   when no_data_found then
      x_errcode := 'CSA21';
      --x_errmsg := 'Invalid Customer Number ('||p_customer_number||')';
      x_errmsg := 'Invalid Customer Number';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'Customer Check: '||SQLERRM;
      return(false);
END valid_customer;


-- +====================================================================
-- |  This function validates the Site Number is valid and is for the
-- |  and Customer.  It returns the corresponding CUST_ACCOUNT_SITE_ID.
-- +====================================================================
function valid_site (
         p_site_number  in  varchar2
        ,p_cust_account_id  in  number
        ,x_cust_acct_site_id  out  number
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is

  ln_party_site_id  hz_party_sites.party_site_id%type;
  ln_cust_account_id  hz_cust_acct_sites_all.cust_account_id%type;

  e_null_site  exception;
  e_site  exception;
  e_cust  exception;
  e_org  exception;

BEGIN
   if (p_site_number is null) then
      raise e_null_site;
   end if;

   begin  -- check the site
      select  ps.party_site_id
      into    ln_party_site_id
      from    hz_party_sites  ps
      where   ps.party_site_number = p_site_number;

   exception
      when no_data_found then
         raise e_site;
   end;

   begin  -- check the customer site
      select  cas.cust_acct_site_id
             ,cas.cust_account_id
      into    x_cust_acct_site_id
             ,ln_cust_account_id
      from    hz_cust_acct_sites_all  cas
      where   cas.party_site_id = ln_party_site_id
      and     cas.org_id = gn_ou_org_id;

      -- check that site belongs to right customer
      if (ln_cust_account_id <> p_cust_account_id) then
         x_cust_acct_site_id := null;
         raise e_cust;
      end if;

   exception
      when no_data_found then
         raise e_org;
   end;

   return(true);

EXCEPTION
   when e_null_site then
      x_errcode := 'CSA30';
      x_errmsg := 'Missing Site Number';
      return(false);
   when e_site then
      x_errcode := 'CSA31';
      --x_errmsg := 'Invalid Site Number ('||p_site_number||')';
      x_errmsg := 'Invalid Site Number';
      return(false);
   when e_cust then
      x_errcode := 'CSA32';
      --x_errmsg := 'Site '||p_site_number||' belongs to a different customer';
      x_errmsg := 'Site belongs to a different customer';
      return(false);
   when e_org then
      x_errcode := 'CSA33';
      --x_errmsg := 'Site '||p_site_number||' not found for the OU';
      x_errmsg := 'Site not found for the OU';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'Site Check: '||SQLERRM;
      return(false);
END valid_site;


-- +====================================================================
-- |  This function validates that the Site Use already exists and
-- |  returns the currently assigned SALESREP_ID
-- |  and Customer.  It returns the corresponding CUST_ACCOUNT_SITE_ID.
-- +====================================================================
function valid_siteuse (
         p_site_use  in  varchar2
        ,p_cust_acct_site_id  in  number
        ,x_site_use_id  out  number
        ,x_site_use_ovn  out  number
        ,x_salesrep_id_old  out  number
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is

  lc_status  hz_cust_site_uses_all.status%type;

  e_null_siteuse  exception;
  e_status  exception;
  e_siteuse  exception;

BEGIN
   if (p_site_use is null) then
      raise e_null_siteuse;
   end if;

   begin
      select  csu.site_use_id
             ,csu.object_version_number
             ,csu.primary_salesrep_id
             ,csu.status
      into    x_site_use_id
             ,x_site_use_ovn
             ,x_salesrep_id_old
             ,lc_status
      from    hz_cust_site_uses_all  csu
      where   csu.cust_acct_site_id = p_cust_acct_site_id
      and     csu.site_use_code = upper(p_site_use)
      and     csu.org_id = gn_ou_org_id;

      -- <Rev 1.1 : For inactive site, allow update to continue
      -- if (lc_status <> 'A') then
      --    raise e_status;
      -- end if;
      -- Rev 1.1>

   exception
      when no_data_found then
         raise e_siteuse;
   end;

   return(true);

EXCEPTION
   when e_null_siteuse then
      x_errcode := 'CSA40';
      x_errmsg := 'Missing Site Use';
      return(false);
   when e_status then
      x_errcode := 'CSA41';
      x_errmsg := upper(p_site_use)||' usage is not Active';
      return(false);
   when e_siteuse then
      x_errcode := 'CSA42';
      x_errmsg := upper(p_site_use)||' usage not defined for Site';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'Site Use Check: '||SQLERRM;
      return(false);
END valid_siteuse;


-- +====================================================================
-- |  This function validates that Salesrep exists and is active in
-- |  the OU.  It returns the SALESREP_ID for the new salesrep.
-- +====================================================================
function valid_salesrep (
         p_salesrep_number  in  varchar2
        ,p_salesrep_name  in  varchar2
        ,x_salesrep_id_new  out  number
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is

  lc_salesrep_name  ra_salesreps_all.name%type;
  lc_status  ra_salesreps_all.status%type;
  ld_start_date_active  ra_salesreps_all.start_date_active%type;
  ld_end_date_active  ra_salesreps_all.end_date_active%type;

  e_no_salesrep_num  exception;
  e_no_salesrep_name  exception;
  e_number  exception;
  e_name  exception;
  e_inactive  exception;

BEGIN
   if (p_salesrep_number is null) then
      raise e_no_salesrep_num;
   end if;
   if (p_salesrep_name is null) then
      raise e_no_salesrep_name;
   end if;

   begin
      select  sr.salesrep_id
             ,sr.name
             ,sr.status
             ,sr.start_date_active
             ,sr.end_date_active
      into    x_salesrep_id_new
             ,lc_salesrep_name
             ,lc_status
             ,ld_start_date_active
             ,ld_end_date_active
      from    ra_salesreps_all  sr
      where   sr.salesrep_number = p_salesrep_number
      and     sr.org_id = gn_ou_org_id;

      if (upper(lc_salesrep_name) <> upper(p_salesrep_name)) then
         raise e_name;
      end if;
      if (nvl(lc_status,'X') <> 'A') then
         raise e_inactive;
      end if;
      if (not sysdate between nvl(ld_start_date_active,sysdate) and nvl(ld_end_date_active,sysdate) ) then
         raise e_inactive;
      end if;

   exception
      when no_data_found then
         raise e_number;
   end;

   return(true);

EXCEPTION
   when e_no_salesrep_num then
      x_errcode := 'CSA50';
      x_errmsg := 'Missing Salesrep Number';
      return(false);
   when e_no_salesrep_name then
      x_errcode := 'CSA51';
      x_errmsg := 'Missing Salesrep Name';
      return(false);
   when e_number then
      x_errcode := 'CSA52';
      --x_errmsg := 'Salesrep Number '||p_salesrep_number||' not found under the OU';
      x_errmsg := 'Salesrep Number not found under the OU';
      return(false);
   when e_name then
      x_errcode := 'CSA53';
      x_errmsg := 'Salesrep Name does not match to the Salesrep Number';
      return(false);
   when e_inactive then
      x_errcode := 'CSA54';
      x_errmsg := 'Salesrep is inactive by either Status or Date Range';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'Salesrep Check: '||SQLERRM;
      return(false);
END valid_salesrep;


-- +=========================================================================
-- |  This procedures validates newly staged records.
-- |  Note:  This is not invoked if the file level validation detects errors
-- +=========================================================================
PROCEDURE validate_records (
         x_cnt_invalid  out  number
        ) is
  ln_cnt_read  number := 0;
  ln_cnt_valid  number := 0;
  ln_cnt_invalid  number := 0;
  lc_errcode  varchar2(30);
  lc_errmsg  varchar2(2000);
  lc_validation_status  varchar2(2);
  ln_cust_account_id  number;
  ln_cust_acct_site_id  number;
  ln_site_use_id  number;
  ln_site_use_ovn  number;
  ln_salesrep_id_old  number;
  ln_salesrep_id_new  number;

  e_error  exception;

  -- Cursor for new records
  cursor c_new (
           q_ou_name  varchar2
          ) is
    select  stg.*
           ,stg.rowid
    from    xxha_cust_slsrep_asg_stg  stg
    where   stg.status = 'NEW'
    and     stg.ou_name = q_ou_name;

  -- Cursor for errored records
  cursor c_err (
           q_request_id  xxha_common_errors.request_id%type
          ,q_table_name  xxha_common_errors.table_name%type
          ) is
    select  ce.error_code
           ,ce.error_msg
           ,count(1)  cnt
    from    xxha_common_errors  ce
    where   ce.request_id = q_request_id
    and     ce.table_name = q_table_name
    group by ce.error_code
            ,ce.error_msg
    order by 1;

BEGIN
   gc_log_message := 'Performing Record Validation';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);

   for newrec in c_new (gc_ou_name)
   loop
      ln_cnt_read := ln_cnt_read + 1;

      gc_record_identifier := newrec.file_name;
      gn_record_number := newrec.rec_num;
      lc_errcode := null;
      lc_errmsg := null;
      lc_validation_status := null;
      ln_cust_account_id := null;
      ln_cust_acct_site_id := null;
      ln_site_use_id := null;
      ln_site_use_ovn := null;
      ln_salesrep_id_old := null;
      ln_salesrep_id_new := null;

      begin
         if (not valid_customer(newrec.customer_number
                      ,ln_cust_account_id, lc_errcode, lc_errmsg) )  then
            raise e_error;
         end if;
         if (not valid_site(newrec.site_number, ln_cust_account_id
                      ,ln_cust_acct_site_id, lc_errcode, lc_errmsg) ) then
            raise e_error;
         end if;
         if (not valid_siteuse(newrec.site_use, ln_cust_acct_site_id
                      ,ln_site_use_id, ln_site_use_ovn, ln_salesrep_id_old, lc_errcode, lc_errmsg) ) then
            raise e_error;
         end if;
         if (not valid_salesrep(newrec.salesrep_number, newrec.salesrep_name
                      ,ln_salesrep_id_new, lc_errcode, lc_errmsg) ) then
            raise e_error;
         end if;

         -- at this point, all validations have been successful
         lc_validation_status := 'VS';
         ln_cnt_valid := ln_cnt_valid + 1;

      exception
         when e_error then
            lc_validation_status := 'VE';
            ln_cnt_invalid := ln_cnt_invalid + 1;
            gc_error_code := lc_errcode;
            gc_error_msg := lc_errmsg;
            gc_comments := null;
            log_error_for_report;

            gc_log_message := gc_error_code||' - '||gc_error_msg;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);

            fnd_file.put_line(fnd_file.output,'Invalid record   : RecNum='||newrec.rec_num
                                                              ||' CustNo='||newrec.customer_number
                                                              ||' SiteNo='||newrec.site_number
                                                                    ||' ('||upper(newrec.site_use)||')'
                                                          ||' SalesrepNo='||newrec.salesrep_number
                                                        ||' SalesrepName='||newrec.salesrep_name
                             );
      end;

      update  xxha_cust_slsrep_asg_stg
      set     status = lc_validation_status
             ,org_id = gn_ou_org_id
             ,cust_account_id = ln_cust_account_id
             ,site_use_id = ln_site_use_id
             ,site_use_ovn = ln_site_use_ovn
             ,salesrep_id_old = ln_salesrep_id_old
             ,salesrep_id_new = ln_salesrep_id_new
      where   rowid = newrec.rowid;

      commit;

   end loop;

   -------------------------------------------------------------------------
   -- Summary Of Records Validation Process
   -------------------------------------------------------------------------
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Validation Summary');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Records Validated       : ' ||ln_cnt_read);
   fnd_file.put_line(fnd_file.output,'  Passed                : ' ||ln_cnt_valid);
   fnd_file.put_line(fnd_file.output,'  Failed                : ' ||ln_cnt_invalid);
   if (ln_cnt_invalid > 0) then
      fnd_file.put_line(fnd_file.output,' ');
      fnd_file.put_line(fnd_file.output,'Summary by Error Type');
      fnd_file.put_line(fnd_file.output,'---------------------');
      for errrec in c_err (gn_child_request2_id,gc_table_name)
      loop
         fnd_file.put_line(fnd_file.output,'  '||errrec.error_code||'  '||errrec.error_msg||'   '||errrec.cnt);
      end loop;
      fnd_file.put_line(fnd_file.output,' ');
   end if;
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Validation errors (if any) can be viewed in request XXHA: Error Report');

   x_cnt_invalid := ln_cnt_invalid;

END validate_records;


-- +=========================================================================
-- |  This procedures performs file level validation.
-- |  Note:  File level errors cause the program to stop prior to
-- |         record level processing
-- +=========================================================================
PROCEDURE validate_file (
         x_err_many_orgs  out  varchar2
        ,x_err_diff_org  out  varchar2
        ) is
  ln_cnt_ou  number := 0;
  ln_cnt_ou_mismatch  number := 0;
  ln_cnt_invalid  number := 0;

  cursor c_f1 is
    select  stg.file_name
           ,count(distinct  stg.ou_name)  cnt
    from    xxha_cust_slsrep_asg_stg  stg
    where   stg.status = 'NEW'
    group by stg.file_name;

  cursor c_f2 is
    select  distinct
            stg.file_name
           ,stg.ou_name
    from    xxha_cust_slsrep_asg_stg  stg
    where   stg.status = 'NEW'
    and     stg.ou_name <> gc_ou_name;

BEGIN
   -- File validation #1 - ensure that records within a file are for a single OU
   gc_log_message := 'Performing File Validation #1';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);

   for f1rec in c_f1
   loop
      if (f1rec.cnt > 1) then
         gc_record_identifier := f1rec.file_name;
         gc_error_code := 'CSA10';
         gc_error_msg := 'All records staged must be for the same Operating Unit';
         gc_comments := 'Correct file(s) and resubmit.';
         log_error_for_report;

         gc_log_message := 'CSA10 - '||f1rec.file_name||' ... '||gc_error_msg;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);
         x_err_many_orgs := 'Y';
      end if;
   end loop;

   -- File validation #2 - ensure that records match the specified OU
   gc_log_message := 'Performing File Validation #2';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);

   for f2rec in c_f2
   loop
      gc_record_identifier := f2rec.file_name;
      gc_error_code := 'CSA15';
      gc_error_msg := f2rec.ou_name||'  does not match the submitting operating unit  '||gc_ou_name;
      gc_comments := 'Correct file(s) and resubmit  or  Switch responsibility and resubmit.';
      log_error_for_report;

      gc_log_message := 'CSA15 - '||f2rec.file_name||' ... '||gc_error_msg;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);
      x_err_diff_org := 'Y';
   end loop;

END validate_file;


/**************************************************
**  Public procedures start here
**************************************************/

-- +==============================================================================
-- | Name       : update_staging_table
-- |
-- | Description: Procedure to update staging table records
-- |
-- | Call From  : Loader Concurrent Program
-- |
-- | Parameters:
-- |   IN: p_file_name
-- |       p_request_id
-- |       p_ou_org_id
-- |  OUT:
-- |
-- | Scope: PUBLIC
-- |
-- +==============================================================================
PROCEDURE update_staging_table (
         p_file_name  in  varchar2
        ,p_request_id  in  number
        ,p_ou_org_id  in  number
        ) is
BEGIN
   update  XXHA_CUST_SLSREP_ASG_STG
   set     file_name = p_file_name
          ,loader_request_id = p_request_id
          ,ou_org_id = p_ou_org_id
   where   status = 'NEW'
   and     loader_request_id is null;

   commit;

END update_staging_table;


-- +==============================================================================
-- | Name       : purge_staging_table
-- |
-- | Description: Procedure to purge staging table records
-- |
-- | Call From  : Loader Concurrent Program
-- |
-- | Parameters:
-- |   IN: p_file_name
-- |       p_request_id
-- |       p_ou_org_id
-- |  OUT:
-- |
-- | Scope: PUBLIC
-- |
-- +==============================================================================
PROCEDURE purge_staging_table (
         p_ou_org_id  in  number
        ) is
BEGIN
   delete  XXHA_CUST_SLSREP_ASG_STG
   where   ou_org_id = p_ou_org_id;

   commit;

END purge_staging_table;


-- +==============================================================================+
-- | Name       : process_records
-- |
-- | Description: Procedure to process staged assignment updates.  It drives the
-- |              following actions:
-- |               . Checks of specified OU (input parameter)
-- |               . File level validation
-- |                   > records must be for a single OU
-- |                   > records must be for specified OU (input parameter)
-- |               . Record level validation
-- |                   > check customer, site, site use, salesrep
-- |               . Update assignment for valid records
-- |               . Call launch program for reporting errors (if any)
-- |
-- | Call From  : Main Concurrent Program
-- |
-- | PARAMETERS:
-- |   IN: p_ou_org_id
-- |       p_debug_flag
-- |       p_purge_flag
-- |  OUT: x_err_buf
-- |       x_ret_code
-- |
-- | SCOPE: PUBLIC
-- |
-- +==============================================================================+
PROCEDURE process_records (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_ou_org_id  in  number
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
        )
IS
--The Local Variables
lc_err_setup  varchar2(1) := 'N';       -- Variable flag for setup error flag
lc_err_many_orgs  varchar2(1) := 'N';   -- Variable flag for file error when more than one OU found
lc_err_diff_org  varchar2(1) := 'N';    -- Variable flag for file error when staged records are not for OU specified
ln_cnt_invalid  number;                 -- Variable to count invalid records
ln_cnt_notupdated  number;              -- Variable to count records passing validation but failing on assignment update

e_error  exception;
e_abort  exception;

BEGIN

   gn_record_number := null;
   gn_ou_org_id := p_ou_org_id;
   gc_attribute4 := gc_conc_name;
   gc_attribute5 := p_ou_org_id;

   -- Purging the Error Table Data
   gc_log_message := 'Purging the Error Table data';
   xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);

   if ( p_purge_flag = 'Y' ) then

      begin
         -- This utility is expected to be used infrequently and concurrent requests
         -- may be purged between runs.  Therefore instead of calling
         -- XXHA_COMMON_UTILITIES_PKG.DELETE_ERROR_PRC which drives purging thru
         -- FND_CONCURRENT_REQUESTS, use this SQL to directly delete from error table.
         -- Also ... purge only for the specific OU only.

         delete  xxha_common_errors  xce
         where   xce.attribute4 = gc_conc_name
         and     xce.attribute5 = gn_ou_org_id;

         commit;
      end;
   end if;

   -- Check OU Org_ID parameter and file level errors
   begin

      -- OU Name Fetch
      gc_log_message := 'Fetching OU Name matching input ORG_ID';
      xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);

      begin
         -- Get OU Name for parameter specified OU Org ID
         select  hou.name
         into    gc_ou_name
         from    hr_operating_units  hou
         where   hou.organization_id = gn_ou_org_id;

      exception
         when no_data_found then
            gc_error_code := 'CSA05';
            gc_error_msg := 'No match for OU Org ID ('||gn_ou_org_id||')';
            gc_comments := 'Check value for profile "MO: Operating Unit" (ORG_ID).  Retransfer file(s) and Resubmit.';
            log_error_for_report;

            gc_log_message := 'CSA05 - '||gc_error_msg;
            xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);
            lc_err_setup := 'Y';
            raise e_error;
      end;

      -- Initiate file checks for
      --   . multiple OUs in file
      --   . OUs whcih do not match the OU input parameter
      validate_file (lc_err_many_orgs, lc_err_diff_org);

      if (lc_err_many_orgs = 'Y'  or  lc_err_diff_org = 'Y') then
         raise e_error;
      end if;

   exception
      when e_error then
         -------------------------------------------------------------------------
         -- Remove the newly staged records
         -------------------------------------------------------------------------
         delete  xxha_cust_slsrep_asg_stg  stg
         where   stg.status = 'NEW';
         commit;

         -------------------------------------------------------------------------
         -- Summary Of File Validation Process
         -- Note: This only prints when file level errors stop record level processing
         -------------------------------------------------------------------------
         fnd_file.put_line(fnd_file.output,rpad('*',80,'*'));
         fnd_file.put_line(fnd_file.output,'Validation Summary');
         fnd_file.put_line(fnd_file.output,rpad('*',80,'*'));
         if (lc_err_setup = 'Y') then
            fnd_file.put_line(fnd_file.output,'Unable to match Operating Unit for ORG_ID '||gn_ou_org_id||' - Processing Aborted.');
         end if;
         if (lc_err_many_orgs = 'Y') then
            fnd_file.put_line(fnd_file.output,'All records must be for the same Operating Unit - Processing Aborted.');
         end if;
         if (lc_err_diff_org = 'Y') then
            fnd_file.put_line(fnd_file.output,'Staged record(s) are not for '||gc_ou_name||' - Processing Aborted.');
         end if;
         fnd_file.put_line(fnd_file.output,' ');
         fnd_file.put_line(fnd_file.output,'NOTE:  Records staged from ALL transferred files have been purged.');
         fnd_file.put_line(fnd_file.output,' ');
         fnd_file.put_line(fnd_file.output,rpad('*',80,'*'));

         -------------------------------------------------------------------------
         -- Launch Error Report
         -------------------------------------------------------------------------
         xxha_common_utilities_pkg.launch_error_report_prc(gn_child_request2_id,'Customer Salesrep Assignments Update','Input File');
         fnd_file.put_line(fnd_file.output,' ');
         fnd_file.put_line(fnd_file.output,'Validation errors (if any) can be viewed in request XXHA: Error Report');

         raise e_abort;
   end;


   ------------------------------------------------------------------------------------
   -- At this point, file level validations have succeeded.  Record processing is next.
   ------------------------------------------------------------------------------------

   validate_records(ln_cnt_invalid);

   update_assignments(ln_cnt_notupdated);

   if (ln_cnt_invalid > 0  or  ln_cnt_notupdated > 0) then
      x_ret_code := 1;  -- Set completion status to Warning
      xxha_common_utilities_pkg.launch_error_report_prc(gn_child_request2_id,'Customer Salesrep Assignments Update','Input File');
   end if;

EXCEPTION
   when e_abort then
      x_ret_code := 2;  -- Set completion status to Error

END process_records;


-- +==============================================================================+
-- | Name       : main
-- |
-- | Description: Procedure to submit Loader and Record Processing programs
-- |
-- | Call From  : Main Concurrent Program
-- |
-- | PARAMETERS:
-- |   IN: p_ou_org_id
-- |       p_debug_flag
-- |       p_purge_flag
-- |  OUT: x_err_buf
-- |       x_ret_code
-- |
-- |
-- | SCOPE: PUBLIC
-- |
-- +==============================================================================+
PROCEDURE main (
          x_err_buf  out  varchar2
         ,x_ret_code  out  varchar2
         ,p_ou_org_id  in  number
         ,p_debug_flag  in  varchar2
         ,p_purge_flag  in  varchar2
         ) is

  --The Local variables
  ln_loaded_rec_count  number := 0;          -- variable to hold the no of records loaded from loader program
  lc_loader_status_code  varchar2(10);       -- variable to hold the Loader program status code
  lc_processing_status_code  varchar2(10);   -- variable to hold the Validation program status code
  lc_phase_code  varchar2(10);               -- variable to hold the phase code of a concurrent program
  lc_logfile  varchar2(100);                 -- variable to hold the log file name

  e_error  exception;

BEGIN
   gc_debug_flag := p_debug_flag;

   gc_log_message := 'Submitting .... XXHA: Customer Salesrep Assignments Loader';
   xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);

   --Submitting the Loader Concurrent Program
   gn_child_request1_id := fnd_request.submit_request(
                                       Application => 'HAEMO'
                                      ,Program => 'XXHACUSTSLSREPASGSTG'
                                      ,description => 'XXHA: Customer Salesrep Assignments Staging'
                                      ,start_time => to_char(sysdate,'DD-MON-YYYY HH24:MI:SS')
                                      ,sub_request => FALSE
                                      ,Argument1 => p_ou_org_id
                                      );
   commit;

   loop  -- child request 1
      begin
         select  fcr.logfile_name
                ,fcr.status_code
                ,fcr.phase_code
         into    lc_logfile
                ,lc_loader_status_code
                ,lc_phase_code
         from    fnd_concurrent_requests  fcr
         where   fcr.request_id = gn_child_request1_id
         and     fcr.phase_code = 'C';

         exit when lc_logfile is not null;

      exception
         when no_data_found then
            null;
      end;
   end loop; -- end loop for child request 1

   select  count(1)
   into    ln_loaded_rec_count
   from    XXHA_CUST_SLSREP_ASG_STG
   where   status = 'NEW'
   and     loader_request_id = gn_child_request1_id;

   if not (lc_phase_code = 'C'  and  ln_loaded_rec_count > 0) then
      raise e_error;
   end if;

   gc_log_message := 'Submitting .... XXHA: Customer Salesrep Assignments Processing';
   xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);

   --Submitting the Records Processing Concurrent Program
   gn_child_request2_id := fnd_request.submit_request(
                                       Application => 'HAEMO'
                                      ,Program => 'XXHACUSTSLSREPASGPRC'
                                      ,description =>  'XXHA: Customer Salesrep Assignments Processing'
                                      ,start_time =>  to_Char (sysdate,'DD-MON-YYYY HH24:MI:SS')
                                      ,sub_request =>  FALSE
                                      ,Argument1 =>  p_ou_org_id
                                      ,Argument2 =>  p_debug_flag
                                      ,Argument3 =>  p_purge_flag
                                      );
   commit;

   loop  -- child request 2
      begin
         select  fcr.logfile_name
                ,fcr.status_code
         into    lc_logfile
                ,lc_processing_status_code
         from    fnd_concurrent_requests  fcr
         where   fcr.request_id = gn_child_request2_id
         and     fcr.phase_code = 'C';

         exit when lc_logfile is not null;

      exception
         when no_data_found then
            null;
      end;
   end loop; -- end loop for child request 2

   if ( lc_loader_status_code = 'E'  or  lc_processing_status_code = 'E' ) then
      raise e_error;
   elsif ( lc_loader_status_code = 'C'  and  lc_processing_status_code = 'G' ) then
      x_ret_code := 1;   -- setting the concurrent program status to Warning
   elsif ( lc_loader_status_code = 'C'  and  lc_processing_status_code = 'C' ) then
      x_ret_code := 0;   -- setting the concurrent program status to Normal
   end if;

EXCEPTION
   when e_error then
      x_ret_code := 2;   -- setting the concurrent program status to Error
END main;


END XXHA_CUST_SLSREP_ASG_PK;

/
