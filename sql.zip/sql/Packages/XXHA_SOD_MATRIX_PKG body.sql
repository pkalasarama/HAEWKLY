create or replace PACKAGE BODY XXHA_SOD_MATRIX_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_SOD_MATRIX_PKG                                                                                    *
* Purpose      : This package will be utilized to capture all conflicting responsibilities and to define the            *
*                  SOD conflict.                                                                                        *
*                                                                                                                       *
* PROCEDURES   : PROCESS_DATA                                                                                           *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        02-OCT-2017     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

--------------------------------------------------------------------------------
-- PROCEDURE PROCESS_DATA
PROCEDURE PROCESS_DATA(
                      p_REPORT_TYPE    IN  VARCHAR2
                    , p_DATE           IN  DATE
                    , p_SEQUENCE       OUT NUMBER
                      )
IS

   l_Record_ID                         NUMBER := 0;
   l_Count1                            NUMBER := 0;
   l_Count2                            NUMBER := 0;

   l_User_ID                           APPS.fnd_user.User_ID%TYPE;
   l_user_name                         APPS.fnd_user.User_NAME%TYPE;
   l_FULL_NAME                         APPS.per_people_x.FULL_NAME%TYPE;
   l_JOB_TITLE                         APPS.Per_Job_Definitions.SEGMENT1%TYPE;
   l_DEPARTMENT                        APPS.hr_all_organization_units.name%TYPE;
   l_SUPERVISOR                        APPS.per_people_x.FULL_NAME%TYPE;

   CURSOR CUR_RESP
   IS
   SELECT
       xx.RESPONSIBILITY
   ,   xx.CONFLICTING_RESPONSIBILITY
   ,   xx.SOD_RULE_CONFLICT_DESCRIPTION
   FROM
       HAEMO.XXHA_SOD_RESP_CONFLICTS xx
   WHERE
       TRUNC(p_DATE) BETWEEN TRUNC(xx.EFFECTIVE_START_DATE) AND NVL(TRUNC(xx.EFFECTIVE_END_DATE), (TRUNC(p_DATE)))
   ORDER BY
       xx.RESPONSIBILITY
   ,   xx.CONFLICTING_RESPONSIBILITY
   ;

   CURSOR CUR_DATA (p_Responsibility_Name fnd_Responsibility_tl.Responsibility_Name%TYPE)
   IS
   SELECT DISTINCT
       frg.User_ID
   ,   fu.user_name
   ,   frt.Responsibility_Name
   ,   fat.application_name
   ,   sec.security_group_name
   ,   urg.description
   ,   urg.start_date
   ,   urg.end_date
   ,   urg.creation_date
   ,   urg.last_update_date

   FROM
       APPS.FND_USER_RESP_GROUPS_ALL         frg
   ,   APPS.fnd_Responsibility_tl            frt
   ,   APPS.fnd_responsibility               fr
   ,   APPS.FND_APPLICATION_TL               fat
   ,   APPS.fnd_user                         fu
   ,   APPS.FND_USER_RESP_GROUPS_DIRECT      urg
   ,   APPS.fnd_security_groups_vl           sec

   WHERE 
       frg.Responsibility_Application_ID   = fat.application_id
   AND fat.language                        = 'US'
   AND frg.Responsibility_ID               = frt.Responsibility_ID
   AND frg.Responsibility_Application_ID   = frt.Application_ID
   AND frt.language                        = 'US'
   AND fr.responsibility_id                = frt.responsibility_id
   AND TRUNC(p_DATE)                       BETWEEN TRUNC(fr.Start_date) AND NVL(TRUNC(fr.End_date), (TRUNC(p_DATE))) -- Check Responsibilty Start and End Dates
   AND frg.User_ID                         = fu.user_id
   AND TRUNC(p_DATE)                       BETWEEN TRUNC(fu.Start_Date) AND NVL(TRUNC(fu.End_Date), (TRUNC(p_DATE))) -- Check User's FND_User Start and End Dates
   AND fu.user_id                          = urg.user_id
   AND TRUNC(p_DATE)                       BETWEEN TRUNC(urg.Start_Date) AND NVL(TRUNC(urg.End_Date), (TRUNC(p_DATE))) -- Check User's Responsibilty Start and End Dates
   AND urg.responsibility_id               = frt.Responsibility_ID
   AND urg.security_group_id               = frg.security_group_id
   AND frg.security_group_id               = sec.security_group_id
   AND UPPER(frt.Responsibility_Name)      LIKE '%' || UPPER(p_Responsibility_Name) || '%'
   ORDER BY
   2,3
   ;

   CURSOR CUR_DATA1 (p_User_ID fnd_user.User_ID%TYPE, p_Responsibility_Name fnd_Responsibility_tl.Responsibility_Name%TYPE)
   IS
   SELECT DISTINCT
       frg1.User_ID
   ,   fu1.user_name
   ,   frt1.Responsibility_Name
   ,   fat1.application_name
   ,   sec1.security_group_name
   ,   urg1.description
   ,   urg1.start_date
   ,   urg1.end_date
   ,   urg1.creation_date
   ,   urg1.last_update_date

   FROM
       APPS.FND_USER_RESP_GROUPS_ALL         frg1
   ,   APPS.fnd_Responsibility_tl            frt1
   ,   APPS.fnd_responsibility               fr1
   ,   APPS.FND_APPLICATION_TL               fat1
   ,   APPS.fnd_user                         fu1
   ,   APPS.FND_USER_RESP_GROUPS_DIRECT      urg1
   ,   APPS.fnd_security_groups_vl           sec1

   WHERE
       frg1.Responsibility_Application_ID  = fat1.application_id
   AND fat1.language                       = 'US'
   AND frg1.Responsibility_ID              = frt1.Responsibility_ID
   AND frg1.Responsibility_Application_ID  = frt1.Application_ID
   AND frt1.language                       = 'US'
   AND fr1.responsibility_id               = frt1.responsibility_id
   AND TRUNC(p_DATE)                       BETWEEN TRUNC(fr1.Start_date) AND NVL(TRUNC(fr1.End_date), (TRUNC(p_DATE))) -- Check Responsibilty Start and End Dates
   AND frg1.User_ID                        = fu1.user_id
   AND TRUNC(p_DATE)                       BETWEEN TRUNC(fu1.Start_Date) AND NVL(TRUNC(fu1.End_Date), (TRUNC(p_DATE))) -- Check User's FND_User Start and End Dates
   AND fu1.user_id                         = urg1.user_id
   AND TRUNC(p_DATE)                       BETWEEN TRUNC(urg1.Start_Date) AND NVL(TRUNC(urg1.End_Date), (TRUNC(p_DATE))) -- Check User's Responsibilty Start and End Dates
   AND urg1.responsibility_id              = frt1.Responsibility_ID
   AND urg1.security_group_id              = frg1.security_group_id
   AND frg1.security_group_id              = sec1.security_group_id
   AND UPPER(frt1.Responsibility_Name)     LIKE '%' || UPPER(p_Responsibility_Name) || '%'
   AND frg1.User_ID                        = p_User_ID
   ORDER BY
   2,3
   ;

   CURSOR CUR_RESP_CONFLICT_DATA (p_User_ID fnd_user.User_ID%TYPE, p_Responsibility fnd_Responsibility_tl.Responsibility_Name%TYPE, p_RESP_SECURITY_GROUP fnd_security_groups_vl.SECURITY_GROUP_NAME%TYPE, p_Conflicting_Responsibility fnd_Responsibility_tl.Responsibility_Name%TYPE, p_CONFL_RESP_SECURITY_GROUP fnd_security_groups_vl.SECURITY_GROUP_NAME%TYPE)
   IS
   SELECT
       NVL(COUNT(*),0)
   FROM
       HAEMO.XXHA_SOD_RESP_CONFLICTS_RPT  xxha
   WHERE
       xxha.User_ID                        = p_User_ID
   AND xxha.RESPONSIBILITY                 = p_Responsibility
   AND xxha.RESP_SECURITY_GROUP_NAME       = p_RESP_SECURITY_GROUP
   AND xxha.CONFLICTING_RESPONSIBILITY     = p_Conflicting_Responsibility
   AND xxha.CONFL_RESP_SECURITY_GROUP_NAME = p_CONFL_RESP_SECURITY_GROUP
   ;

   CURSOR CUR_HR_DATA (p_User_ID fnd_user.User_ID%TYPE)
   IS
   SELECT
       USR.User_ID
   ,   USR.user_name
   ,   PPX.FULL_NAME
   ,   JD.SEGMENT1
   ,   haou.name
   ,   sup.FULL_NAME
   FROM
       APPS.fnd_user                  USR
   ,   APPS.Per_People_x              PPX
   ,   APPS.PER_ASSIGNMENTS_X         PAX
   ,   APPS.PER_PEOPLE_X              SUP
   ,   APPS.Per_Jobs                  J
   ,   APPS.Per_Job_Definitions       JD
   ,   APPS.hr_all_organization_units haou
   WHERE
       USR.User_ID                  = p_User_ID
   AND PPX.Person_Id                = USR.Employee_Id
   AND PPX.PERSON_ID                = PAX.PERSON_ID
   AND PAX.Job_Id                   = J.Job_Id(+)
   AND J.Job_Definition_Id          = Jd.Job_Definition_Id(+)
   AND PAX.Supervisor_Id            = Sup.Person_Id(+)
   AND haou.organization_id(+)      = PAX.organization_id
   ;

BEGIN

   l_Count1 := 0;
   l_Count2 := 0;

   SELECT HAEMO.XXHA_SOD_RESP_CONFLICTS_RPT_S.NEXTVAL INTO l_Record_ID FROM DUAL;

   -- If NOT running Full Reporting
   IF p_REPORT_TYPE = 'N' THEN

      FOR CUR_RESP_DTA IN CUR_RESP 
      LOOP

         FOR CUR_DATA_DTA IN CUR_DATA(CUR_RESP_DTA.RESPONSIBILITY)
         LOOP

            FOR CUR_DATA1_DTA IN CUR_DATA1(CUR_DATA_DTA.User_ID, CUR_RESP_DTA.CONFLICTING_RESPONSIBILITY)
            LOOP

               -- Make sure this User/Responsibility/Conflicting Responsibility and User/Conflicting Responsibility/Responsibility was not already reported (check both combinations)
               l_Count1 := 0;
               l_Count2 := 0;
               OPEN CUR_RESP_CONFLICT_DATA(CUR_DATA_DTA.User_ID, CUR_DATA_DTA.Responsibility_Name, CUR_DATA_DTA.SECURITY_GROUP_NAME, CUR_DATA1_DTA.Responsibility_Name, CUR_DATA1_DTA.SECURITY_GROUP_NAME);
               FETCH CUR_RESP_CONFLICT_DATA INTO l_Count1;
               CLOSE CUR_RESP_CONFLICT_DATA;
               OPEN CUR_RESP_CONFLICT_DATA(CUR_DATA_DTA.User_ID, CUR_DATA1_DTA.Responsibility_Name, CUR_DATA1_DTA.SECURITY_GROUP_NAME, CUR_DATA_DTA.Responsibility_Name, CUR_DATA_DTA.SECURITY_GROUP_NAME);
               FETCH CUR_RESP_CONFLICT_DATA INTO l_Count2;
               CLOSE CUR_RESP_CONFLICT_DATA;
               -- If this User/Responsibility/Conflicting Responsibility or User/Conflicting Responsibility/Responsibility was not already reported then create record in table 
               IF (l_Count1 = 0 AND l_Count2 = 0) THEN
                  OPEN CUR_HR_DATA(CUR_DATA_DTA.User_ID);
                  FETCH CUR_HR_DATA INTO l_User_ID, l_user_name, l_FULL_NAME, l_JOB_TITLE, l_DEPARTMENT, l_SUPERVISOR;
                  -- If no HR Record exists, ignore it
                  IF CUR_HR_DATA%FOUND THEN
                     INSERT INTO HAEMO.XXHA_SOD_RESP_CONFLICTS_RPT
                     (
                        RECORD_ID
                     ,  FULL_NAME
                     ,  USER_NAME
                     ,  USER_ID
                     ,  JOB_TITLE
                     ,  DEPARTMENT
                     ,  SUPERVISOR
                     ,  RESPONSIBILITY
                     ,  RESP_SECURITY_GROUP_NAME
                     ,  RESPONSIBILITY_START_DATE
                     ,  RESPONSIBILITY_END_DATE
                     ,  CONFLICTING_RESPONSIBILITY
                     ,  CONFL_RESP_SECURITY_GROUP_NAME
                     ,  CONFLICTING_RESP_START_DATE
                     ,  CONFLICTING_RESP_END_DATE
                     ,  SOD_RULE_CONFLICT_DESCRIPTION
                     ,  REQ_PROCESS_DATE
                     ,  PROCESS_DATE
                     )
                     VALUES
                     (
                        l_Record_ID
                     ,  l_FULL_NAME
                     ,  l_user_name
                     ,  l_User_ID
                     ,  l_JOB_TITLE
                     ,  l_DEPARTMENT
                     ,  l_SUPERVISOR
                     ,  CUR_DATA_DTA.Responsibility_Name
                     ,  CUR_DATA_DTA.SECURITY_GROUP_NAME
                     ,  CUR_DATA_DTA.Start_Date
                     ,  CUR_DATA_DTA.End_Date
                     ,  CUR_DATA1_DTA.Responsibility_Name
                     ,  CUR_DATA1_DTA.SECURITY_GROUP_NAME
                     ,  CUR_DATA1_DTA.Start_Date
                     ,  CUR_DATA1_DTA.End_Date
                     ,  CUR_RESP_DTA.SOD_RULE_CONFLICT_DESCRIPTION
                     ,  p_DATE
                     ,  TRUNC(SYSDATE)
                     );
                     COMMIT;
                  END IF;
                  -- Close the Cursor
                  CLOSE CUR_HR_DATA;
               END IF;

         END LOOP;

      END LOOP;

   END LOOP;

   -- If running AD HOC Report
   ELSE

      FOR CUR_RESP_DTA IN CUR_RESP 
      LOOP

         FOR CUR_DATA_DTA IN CUR_DATA(CUR_RESP_DTA.RESPONSIBILITY)
         LOOP

            FOR CUR_DATA1_DTA IN CUR_DATA1(CUR_DATA_DTA.User_ID, CUR_RESP_DTA.CONFLICTING_RESPONSIBILITY)
            LOOP

               OPEN CUR_HR_DATA(CUR_DATA_DTA.User_ID);
               FETCH CUR_HR_DATA INTO l_User_ID, l_user_name, l_FULL_NAME, l_JOB_TITLE, l_DEPARTMENT, l_SUPERVISOR;
               -- If no HR Record exists, ignore it
               IF CUR_HR_DATA%FOUND THEN
                  INSERT INTO HAEMO.XXHA_SOD_RESP_CONFLICTS_RPT
                  (
                     RECORD_ID
                  ,  FULL_NAME
                  ,  USER_NAME
                  ,  USER_ID
                  ,  JOB_TITLE
                  ,  DEPARTMENT
                  ,  SUPERVISOR
                  ,  RESPONSIBILITY
                  ,  RESP_SECURITY_GROUP_NAME
                  ,  RESPONSIBILITY_START_DATE
                  ,  RESPONSIBILITY_END_DATE
                  ,  CONFLICTING_RESPONSIBILITY
                  ,  CONFL_RESP_SECURITY_GROUP_NAME
                  ,  CONFLICTING_RESP_START_DATE
                  ,  CONFLICTING_RESP_END_DATE
                  ,  SOD_RULE_CONFLICT_DESCRIPTION
                  ,  REQ_PROCESS_DATE
                  ,  PROCESS_DATE
                  )
                  VALUES
                  (
                     l_Record_ID
                  ,  l_FULL_NAME
                  ,  l_user_name
                  ,  l_User_ID
                  ,  l_JOB_TITLE
                  ,  l_DEPARTMENT
                  ,  l_SUPERVISOR
                  ,  CUR_DATA_DTA.Responsibility_Name
                  ,  CUR_DATA_DTA.SECURITY_GROUP_NAME
                  ,  CUR_DATA_DTA.Start_Date
                  ,  CUR_DATA_DTA.End_Date
                  ,  CUR_DATA1_DTA.Responsibility_Name
                  ,  CUR_DATA1_DTA.SECURITY_GROUP_NAME
                  ,  CUR_DATA1_DTA.Start_Date
                  ,  CUR_DATA1_DTA.End_Date
                  ,  CUR_RESP_DTA.SOD_RULE_CONFLICT_DESCRIPTION
                  ,  p_DATE
                  ,  TRUNC(SYSDATE)
                  );
                  COMMIT;
               END IF;
               -- Close the Cursor
               CLOSE CUR_HR_DATA;

            END LOOP;

         END LOOP;

      END LOOP;

   END IF;

   p_SEQUENCE := l_Record_ID;

END PROCESS_DATA;

END XXHA_SOD_MATRIX_PKG;