CREATE OR REPLACE package xxha_cme_update_date as
--
procedure do_main ( errbuf OUT varchar2
                   ,retcode OUT number
                   ,p_validate varchar2 default null
                   ,p_effective_date varchar2 default null
                   ,p_certtification_id number default null
                   ,p_person_id number default null
                  );
--
end xxha_cme_update_date;
/


CREATE OR REPLACE package body xxha_cme_update_date as
--
/*
* Change History: xxha_cme_update_date.pkb
*
* Name          Date          Description 
* ------------------------------------------- 
* HMirchandani  01-Oct-2009   Initial version
* PReddy        04-Nov-2009   Updated cursor get_cme to not pick up unsubscribed certifications   
* HMirchandani  01-Apr-2011   Correct Issue:  SR 3-2074512521: End Dated Certification Components Remain - after unsubscribe/subscribe
*/
--
procedure do_main ( errbuf OUT varchar2
                   ,retcode OUT number
                   ,p_validate varchar2 default null
                   ,p_effective_date varchar2 default null
                   ,p_certtification_id number default null
                   ,p_person_id number default null
                  ) is
-- 
ld_effective_date              date;
ln_cert_prd_enrollment_id      number;
ln_old_cert_prd_enrollment_id  number;
ln_ovn                         number;
lv_certification_status_code   varchar2 (100);
ln_validate                    boolean;
--
cursor get_cme (cp_effective_date date,
                cp_certification_id number,
                cp_person_id number
               ) is
select cme.*, 
      ppf.full_name person_name, 
      crt.name certification_name,
      tav.version_name course_name
FROM ota_cert_enrollments cre,
     ota_cert_prd_enrollments cpe,
     ota_certifications_vl crt,
     ota_certification_members cmb,
     ota_cert_mbr_enrollments cme,
     per_all_people_f ppf,
     ota_activity_versions_vl tav
where tav.activity_version_id = cmb.object_id
  and cp_effective_date between tav.start_date and nvl(tav.end_date,trunc(sysdate))
  and cp_effective_date between cmb.start_date_active and nvl(cmb.end_date_active,trunc(sysdate))
  and cp_effective_date between ppf.effective_start_date and ppf.effective_end_date
  and ppf.person_id = cre.person_id
  and nvl(cp_certification_id,cre.certification_id) = cre.certification_id
  and cme.cert_member_id = cmb.certification_member_id
  and cme.member_status_code not in ('COMPLETED','CANCELLED')
  and cpe.period_status_code <> 'CANCELLED'
  and cme.cert_prd_enrollment_id = cpe.cert_prd_enrollment_id
  and cp_effective_date between cpe.cert_period_start_date and nvl(cpe.cert_period_end_date,trunc(sysdate))
  and cpe.cert_enrollment_id = cre.cert_enrollment_id
  and nvl(cp_person_id, cre.person_id) = cre.person_id
  and cp_effective_date between crt.start_date_active and nvl(crt.end_date_active,trunc(sysdate))
  and cre.certification_id = crt.certification_id
  and nvl(cmb.attribute1,'Y') = 'Y'
  and nvl(crt.attribute1,'Y') = 'Y';
--
r_cme                          get_cme%rowtype;
--
begin
  fnd_file.put_line(fnd_file.log,'Start Process HAE Synch Certification Member Completion');
  if p_effective_date is null then
    ld_effective_date := trunc(sysdate);
  else
    ld_effective_date := fnd_date.canonical_to_date(p_effective_date);
  end if;
  --
  if p_validate = 'Y' then
    ln_validate := true;
  else
    ln_validate := false;
  end if;
  --
  ln_ovn := null;
  for rec_cme in get_cme (ld_effective_date, p_certtification_id, p_person_id)
  loop
    ln_ovn := rec_cme.object_version_number;
    begin
      OTA_CERT_MBR_ENROLLMENT_API.update_cert_mbr_enrollment
        (p_effective_date               =>  ld_effective_date --in     date
        ,p_cert_mbr_enrollment_id       =>  rec_cme.cert_mbr_enrollment_id --in     number
        ,p_object_version_number        =>  ln_ovn --in out nocopy number
        ,p_cert_prd_enrollment_id       =>  rec_cme.cert_prd_enrollment_id --in     number
        ,p_cert_member_id               =>  rec_cme.cert_member_id --in     number
        ,p_member_status_code           =>  'ACTIVE'--in     varchar2
        ,p_validate                     =>  ln_validate --in     boolean          default false
         );
    exception
      when others then
        fnd_file.put_line(fnd_file.log,'ERROR: Unable to update the certification member for Certification: '||rec_cme.Certification_name||' 
                          | Person: '||rec_cme.person_name||' | Course: '||rec_cme.course_name);
        retcode := 1;
    end;
    --
    fnd_file.put_line(fnd_file.log,'SUCCESS: Updated the certification member for Certification: '||rec_cme.Certification_name||' 
                      | Person: '||rec_cme.person_name||' | Course: '||rec_cme.course_name);
    lv_certification_status_code := null;
    if ln_validate then
      savepoint cpe_status_update;
    end if;
    begin
      ota_cpe_util.update_cpe_status(p_cert_prd_enrollment_id => rec_cme.cert_prd_enrollment_id,
                         p_certification_status_code => lv_certification_status_code,
                         p_child_update_flag => 'N' );
    exception
      when others then
        fnd_file.put_line(fnd_file.log,'ERROR: Unable to update the certification period for Certification: '||rec_cme.Certification_name||' 
                          | Person: '||rec_cme.person_name);
        retcode := 1;
    end;
    fnd_file.put_line(fnd_file.log,'SUCCESS: Updated the certification period for Certification: '||rec_cme.Certification_name||' 
                      | Person: '||rec_cme.person_name);
    if ln_validate then
      rollback to cpe_status_update;
    end if;
  end loop;
  fnd_file.put_line(fnd_file.log,'End Process HAE Synch Certification Member Completion');
end do_main;
--
end xxha_cme_update_date;
/
