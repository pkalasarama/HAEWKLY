CREATE OR REPLACE PACKAGE XXHA_STOCK_LOCATORS_PKG AS 
-- +=====================================================================================+
-- | Name        : XXHA_STOCK_LOCATORS_PKG                                               |
-- | Purpose     : Used by Web ADI to upload stock locators                              |
-- |                                                                                     |
-- | History                                                                             |
-- | =======                                                                             |
-- | When      Rev  Who               What                                               |
-- | --------  ---  ----------------  ----------------------------------------           |
-- | 20130415  1.0  Sreeram Boppana   Initial version                                    |
-- +=====================================================================================+

PROCEDURE MAIN_PROC(ERRBUF OUT VARCHAR2 ,
                    RETCODE OUT VARCHAR2,
                    p1 in varchar2);
                    GC_ERROR_MESSAGE VARCHAR2(2000);
PROCEDURE FLEX_FIELD_VALUE_LOAD(P_VALUE_SET_NAME IN VARCHAR2,
                                P_FLEX_VALUE IN VARCHAR2);   
PROCEDURE MAIN_PROC_ADI (
                    P_ORG_CODE IN VARCHAR2,
                    P_SUB_CODE IN VARCHAR2,
                    P_LOC_CODE IN VARCHAR2,
                    P_FUT_CODE IN VARCHAR2,
                    P_FUT_CODE1 IN VARCHAR2
                    ) ;
                    --GC_ERROR_MESSAGE VARCHAR2(2000);
END XXHA_STOCK_LOCATORS_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_STOCK_LOCATORS_PKG AS 
-- +=====================================================================================+
-- | Name        : XXHA_STOCK_LOCATORS_PKG                                               |
-- | Purpose     : Used by Web ADI to upload stock locators                              |
-- |                                                                                     |
-- | History                                                                             |
-- | =======                                                                             |
-- | When      Rev  Who               What                                               |
-- | --------  ---  ----------------  ----------------------------------------           |
-- | 20130415  1.0  Sreeram Boppana   Initial version                                    |
-- +=====================================================================================+
PROCEDURE main_proc (ERRBUF OUT VARCHAR2 ,
                    RETCODE OUT VARCHAR2,
                    P1 IN VARCHAR2) IS
L_RETURN_STATUS VARCHAR2(2);
L_MSG_COUNT NUMBER;
L_MSG_DATA VARCHAR2(2000);
L_INVENTORY_LOCATION_ID NUMBER;
L_LOCATOR_EXISTS VARCHAR2(2);
L_ORGANIZATION_ID NUMBER;
L_SUBINVENTORY_CODE NUMBER;
L_CONCATENATED_SEG NUMBER;
L_FLAG BOOLEAN;
L_SL_NO NUMBER;
L_ORG_CODE VARCHAR2(25) := NULL;
L_SUB_CODE VARCHAR2(30) := NULL;
L_CODE VARCHAR2(240) := NULL;
L_DESCRIPTION VARCHAR2(2000) := NULL;
l_flex_value varchar2(2000) := null;
--cursor loc_cur is select * from xxha_stock_loc_stg where record_status is null;
BEGIN
L_ORGANIZATION_ID := 0;
L_SUBINVENTORY_CODE := 0;
L_CONCATENATED_SEG := 0;
L_FLAG := FALSE;
L_ORG_CODE := SUBSTR(P1,1,(INSTR(P1,',',1))-1);
L_SUB_CODE := SUBSTR(P1,(INSTR(P1,',',1,1)+1),((INSTR(P1,',',1,2))-(INSTR(P1,',',1,1)))-1);
SELECT DECODE((SUBSTR(P1,(INSTR(P1,',',1,3)),1)),',',(SUBSTR(P1,(INSTR(P1,',',1,2)+1),((INSTR(P1,',',1,3))-(INSTR(P1,',',1,2)))-1)),(SUBSTR(P1,(INSTR(P1,',',1,2)+1))))
INTO L_CODE FROM DUAL;
SELECT DECODE((SUBSTR(P1,(INSTR(P1,',',1,3)),1)),',',SUBSTR(P1,(INSTR(P1,',',1,3)+1)),NULL)
INTO L_DESCRIPTION FROM DUAL;
l_flex_value := substr(L_CODE,1,INSTR(L_CODE,'.',1,1)-1); 

--FOR LOC_REC IN LOC_CUR
--LOOP
DBMS_OUTPUT.PUT_LINE('org code:'||L_ORG_CODE);
DBMS_OUTPUT.PUT_LINE('subcode:'||L_SUB_CODE);
DBMS_OUTPUT.PUT_LINE('code:'||L_CODE);
DBMS_OUTPUT.PUT_LINE('description:'||L_DESCRIPTION);
DBMS_OUTPUT.PUT_LINE('flex vaule:'||l_flex_value);
BEGIN
SELECT ORGANIZATION_ID
into L_ORGANIZATION_ID
FROM MTL_PARAMETERS
WHERE ORGANIZATION_CODE = L_ORG_CODE;--LOC_REC.ORG_CODE;
EXCEPTION
WHEN NO_DATA_FOUND THEN
GC_ERROR_MESSAGE := 'organization code '||L_ORG_CODE||' is not have valid in Oracle';
L_FLAG := TRUE;
WHEN OTHERS THEN
GC_ERROR_MESSAGE := 'validation error : '||SQLERRM;
l_flag := true;
END;
BEGIN
SELECT 1
INTO L_SUBINVENTORY_CODE
FROM MTL_SECONDARY_INVENTORIES
WHERE SECONDARY_INVENTORY_NAME = L_SUB_CODE--LOC_REC.SUBINVENTORY_CODE1 
and organization_id = l_organization_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
GC_ERROR_MESSAGE := 'sub inventory code '||L_SUB_CODE||' is not have valid in Oracle';
L_FLAG := TRUE;
WHEN OTHERS THEN
GC_ERROR_MESSAGE := 'validation error : '||SQLERRM;
L_FLAG := TRUE;
END;
BEGIN
SELECT 1
INTO L_CONCATENATED_SEG
FROM MTL_ITEM_LOCATIONS
WHERE SUBINVENTORY_CODE = L_SUB_CODE--LOC_REC.SUBINVENTORY_CODE1 
AND ORGANIZATION_ID = L_ORGANIZATION_ID
AND SEGMENT1||'.'||
    SEGMENT2||'.'||
    SEGMENT3 = L_CODE;--LOC_REC.CODE;
GC_ERROR_MESSAGE := 'concatenated segemnts '||L_CODE||' is already exist in Oracle';
L_FLAG := TRUE;    
EXCEPTION
WHEN NO_DATA_FOUND THEN
null;
WHEN OTHERS THEN
GC_ERROR_MESSAGE := 'validation error : '||SQLERRM;
L_FLAG := TRUE;
END;
XXHA_STOCK_LOCATORS_PKG.FLEX_FIELD_VALUE_LOAD('HAE_STOCK_LOCATORS_LOCATION',l_flex_value);
IF L_FLAG = FALSE THEN
DBMS_OUTPUT.PUT_LINE('Enter');
   INV_LOC_WMS_PUB.CREATE_LOCATOR(
x_return_status => L_RETURN_STATUS,
x_msg_count => L_MSG_COUNT,
x_msg_data => L_MSG_DATA,
x_inventory_location_id => L_INVENTORY_LOCATION_ID,
x_locator_exists => L_LOCATOR_EXISTS,
P_ORGANIZATION_ID => L_ORGANIZATION_ID,
P_ORGANIZATION_CODE => L_ORG_CODE,
P_CONCATENATED_SEGMENTS => L_CODE,
p_description => L_DESCRIPTION,--null,
p_inventory_location_type => null, -- Storage locator
p_picking_order => NULL,
P_LOCATION_MAXIMUM_UNITS => NULL,
P_SUBINVENTORY_CODE => L_SUB_CODE, 
p_location_weight_uom_code => NULL,
p_max_weight => NULL,
p_volume_uom_code => NULL,
p_max_cubic_area => NULL,
p_x_coordinate => NULL,
p_y_coordinate => NULL,
p_z_coordinate => NULL,
p_physical_location_id => NULL,
p_pick_uom_code => NULL,
p_dimension_uom_code => NULL,
p_length => NULL,
p_width => NULL,
p_height => NULL,
p_status_id => 1, -- Default status 'Active'
P_DROPPING_ORDER => NULL
);
commit;
  END IF;
IF L_RETURN_STATUS IS NULL THEN
DBMS_OUTPUT.PUT_LINE('error :'|| GC_ERROR_MESSAGE);
end if;
DBMS_OUTPUT.PUT_LINE('Return Status '||L_RETURN_STATUS);
IF l_return_status IN ('E', 'U') THEN
DBMS_OUTPUT.PUT_LINE('# of Errors '||L_MSG_COUNT); 
commit;
IF l_msg_count = 1 THEN
DBMS_OUTPUT.PUT_LINE('Error '||L_MSG_DATA);
ELSE
FOR i IN 1..l_msg_count LOOP
DBMS_OUTPUT.PUT_LINE('Error '||FND_MSG_PUB.GET(I, 'F'));
END LOOP;
END IF;
ELSE
DBMS_OUTPUT.PUT_LINE('Locator Id is '||L_INVENTORY_LOCATION_ID);
END IF;
EXCEPTION
WHEN OTHERS THEN
ROLLBACK;
DBMS_OUTPUT.PUT_LINE('Error: '||SQLERRM);
END;
PROCEDURE FLEX_FIELD_VALUE_LOAD(P_VALUE_SET_NAME IN VARCHAR2,P_FLEX_VALUE IN VARCHAR2) IS
LN_FLEX_VALUE_SET_ID    NUMBER;
LN_FLEX_VALUE_ID        VARCHAR2(100); 
LC_ERROR_MSG            VARCHAR2(1000);
l_flag1 boolean;
BEGIN
LN_FLEX_VALUE_SET_ID := 0;
LN_FLEX_VALUE_ID := NULL;
LC_ERROR_MSG := null;
l_flag1 := false;
BEGIN  
                SELECT flex_value_set_id 
                  INTO ln_flex_value_set_id
                  FROM FND_FLEX_VALUE_SETS 
                 WHERE UPPER(flex_value_set_name) = UPPER(p_VALUE_SET_NAME) ;
           EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                 lc_error_msg := 'Error : value set not found : '||p_VALUE_SET_NAME;
                 LN_FLEX_VALUE_SET_ID := NULL;
                 --LN_FLEX_VALUE_SET_ID := 0;
                 l_flag1 := true;
                 WHEN OTHERS THEN
                 LN_FLEX_VALUE_SET_ID := NULL;
                 --LN_FLEX_VALUE_SET_ID := 0;
                 l_flag1 := true;
           END;
           IF LN_FLEX_VALUE_SET_ID  IS NOT NULL THEN                                  
           --IF LN_FLEX_VALUE_SET_ID <> 0 then 
                BEGIN  -- CHECK FOR FLEX VALUE EXISTANCE
                        SELECT flex_value_id
                        INTO ln_flex_value_id
                        FROM FND_FLEX_VALUES 
                        WHERE upper(flex_value)= upper(P_FLEX_VALUE)
                        AND flex_value_set_id = ln_flex_value_set_id;
               EXCEPTION
                     WHEN NO_DATA_FOUND THEN                     
                     l_flag1 := false;
                     when too_many_rows then
                     lc_error_msg := 'Error : Too many Flex values found : '||ln_flex_value_set_id;
                     FND_FILE.PUT_LINE(FND_FILE.LOG,LC_ERROR_MSG);                  
                     l_flag1 := true;
                     WHEN OTHERS THEN                
                     lc_error_msg := 'Error : Invlaid Flex value : '||ln_flex_value_set_id;
                     FND_FILE.PUT_LINE(FND_FILE.LOG,LC_ERROR_MSG);                   
                     l_flag1 := true;
               END;
               
                  IF LN_FLEX_VALUE_ID IS NULL THEN                    
                     l_flag1 := false;
                  ELSE 
                     lc_error_msg := 'Error : flex value already exist : '||p_flex_value;
                     FND_FILE.PUT_LINE(FND_FILE.LOG,LC_ERROR_MSG);                    
                     l_flag1 := true;                   
                  END IF;
                  end if;                   
                   IF  l_flag1 = false THEN
                   fnd_flex_loader_apis.up_value_set_value(  p_upload_phase =>'BEGIN',
                                               p_upload_mode                =>'',
                                               p_custom_mode                =>'',
                                               p_flex_value_set_name        => p_VALUE_SET_NAME,
                                               p_parent_flex_value_low      =>'',
                                               p_flex_value                 =>p_FLEX_VALUE,
                                               p_owner                      =>'',
                                               p_last_update_date           => to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'),
                                               p_enabled_flag               =>'Y',
                                               p_summary_flag               =>'N',
                                               p_start_date_active          =>'',
                                               p_end_date_active            =>'',
                                               p_parent_flex_value_high     =>'',
                                               p_rollup_flex_value_set_name =>'',
                                               p_rollup_hierarchy_code      =>'',
                                               p_hierarchy_level            =>'',
                                               p_compiled_value_attributes  =>'',
                                               p_value_category             =>'',
                                               p_attribute1                 =>'',
                                               p_attribute2                 =>'',
                                               p_attribute3                 =>'',
                                               p_attribute4                 =>'',
                                               p_attribute5                 =>'',
                                               p_attribute6                 =>'',
                                               p_attribute7                 =>'',
                                               p_attribute8                 =>'',
                                               p_attribute9                 =>'',
                                               p_attribute10                =>'',
                                               p_attribute11                =>'',
                                               p_attribute12                =>'',
                                               p_attribute13                =>'',
                                               p_attribute14                =>'',
                                               p_attribute15                =>'',
                                               p_attribute16                =>'',
                                               p_attribute17                =>'',
                                               p_attribute18                =>'',
                                               p_attribute19                =>'',
                                               p_attribute20                =>'',
                                               p_attribute21                =>'',
                                               p_attribute22                =>'',
                                               p_attribute23                =>'',
                                               p_attribute24                =>'',
                                               p_attribute25                =>'',
                                               p_attribute26                =>'',
                                               p_attribute27                =>'',
                                               p_attribute28                =>'',
                                               p_attribute29                =>'',
                                               p_attribute30                =>'',
                                               p_attribute31                =>'',
                                               p_attribute32                =>'',
                                               p_attribute33                =>'',
                                               p_attribute34                =>'',
                                               p_attribute35                =>'',
                                               p_attribute36                =>'',
                                               p_attribute37                =>'',
                                               p_attribute38                =>'',
                                               p_attribute39                =>'',
                                               p_attribute40                =>'',
                                               p_attribute41                =>'',
                                               p_attribute42                =>'',
                                               p_attribute43                =>'',
                                               p_attribute44                =>'',
                                               p_attribute45                =>'',
                                               p_attribute46                =>'',
                                               p_attribute47                =>'',
                                               p_attribute48                =>'',
                                               P_ATTRIBUTE49                =>'',
                                               P_ATTRIBUTE50                =>'',
                                               P_FLEX_VALUE_MEANING         =>NULL,
                                               P_DESCRIPTION                =>NULL);
commit;                                               
DBMS_OUTPUT.PUT_LINE('Flex Field Value Loaded');                                               
END IF;
IF L_FLAG1 = TRUE THEN
DBMS_OUTPUT.PUT_LINE(LC_ERROR_MSG);
END IF;
--commented by sreeram to throw the error if a record fails
EXCEPTION
WHEN OTHERS THEN
 
DBMS_OUTPUT.PUT_LINE('Value is not inserted'); 
RAISE_APPLICATION_ERROR (-20098,
                            'Flexfield value is not created' || SQLERRM);

--FND_FILE.PUT_LINE(FND_FILE.LOG,'Error: '||SQLERRM);                   
END;

PROCEDURE MAIN_PROC_ADI (
                    P_ORG_CODE IN VARCHAR2,
                    P_SUB_CODE IN VARCHAR2,
                    P_LOC_CODE IN VARCHAR2,
                    P_FUT_CODE IN VARCHAR2,
                    P_FUT_CODE1 IN VARCHAR2
                    ) IS
L_RETURN_STATUS VARCHAR2(2);
L_MSG_COUNT NUMBER;
L_MSG_DATA VARCHAR2(2000);
L_INVENTORY_LOCATION_ID NUMBER;
L_LOCATOR_EXISTS VARCHAR2(2);
L_ORGANIZATION_ID NUMBER;
L_SUBINVENTORY_CODE NUMBER;
L_CONCATENATED_SEG NUMBER;
L_FLAG BOOLEAN;
L_SL_NO NUMBER;
L_ORG_CODE VARCHAR2(25) := NULL;
L_SUB_CODE VARCHAR2(30) := NULL;
L_CODE VARCHAR2(240) := NULL;
L_DESCRIPTION VARCHAR2(2000) := NULL;
L_FLEX_VALUE VARCHAR2(2000) := NULL;
UNHANDLED_EXCEPTION exception;
--cursor loc_cur is select * from xxha_stock_loc_stg where record_status is null;
BEGIN
L_ORGANIZATION_ID := 0;
L_SUBINVENTORY_CODE := 0;
L_CONCATENATED_SEG := 0;
L_FLAG := FALSE;
DBMS_OUTPUT.PUT_LINE('org code:'||P_ORG_CODE);
DBMS_OUTPUT.PUT_LINE('subcode:'||P_SUB_CODE);
DBMS_OUTPUT.PUT_LINE('code:'||P_LOC_CODE);
--DBMS_OUTPUT.PUT_LINE('description:'||L_DESCRIPTION);
--DBMS_OUTPUT.PUT_LINE('flex vaule:'||l_flex_value);
BEGIN


SELECT ORGANIZATION_ID
into L_ORGANIZATION_ID
FROM MTL_PARAMETERS
WHERE ORGANIZATION_CODE = P_ORG_CODE;--LOC_REC.ORG_CODE;
EXCEPTION
WHEN NO_DATA_FOUND THEN
GC_ERROR_MESSAGE := 'organization code '||P_ORG_CODE||' is not have valid in Oracle';
L_FLAG := TRUE;
WHEN OTHERS THEN
GC_ERROR_MESSAGE := 'validation error : '||SQLERRM;
l_flag := true;
END;
BEGIN
SELECT 1
INTO L_SUBINVENTORY_CODE
FROM MTL_SECONDARY_INVENTORIES
WHERE SECONDARY_INVENTORY_NAME = P_SUB_CODE--LOC_REC.SUBINVENTORY_CODE1 
and organization_id = l_organization_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
GC_ERROR_MESSAGE := 'sub inventory code '||P_SUB_CODE||' is not have valid in Oracle';
L_FLAG := TRUE;
WHEN OTHERS THEN
GC_ERROR_MESSAGE := 'validation error : '||SQLERRM;
L_FLAG := TRUE;
END;
BEGIN
SELECT 1
INTO L_CONCATENATED_SEG
FROM MTL_ITEM_LOCATIONS
WHERE SUBINVENTORY_CODE = P_SUB_CODE--LOC_REC.SUBINVENTORY_CODE1 
AND ORGANIZATION_ID = L_ORGANIZATION_ID
AND SEGMENT1||'.'||
    SEGMENT2||'.'||
    SEGMENT3 = P_LOC_CODE||'.'||
               P_FUT_CODE||'.'||
               P_FUT_CODE1;--LOC_REC.CODE;
GC_ERROR_MESSAGE := 'concatenated segemnts '||P_LOC_CODE||'.'||
               P_FUT_CODE||'.'||
               P_FUT_CODE1||' is already exist in Oracle';
L_FLAG := TRUE;    
EXCEPTION
WHEN NO_DATA_FOUND THEN
null;
WHEN OTHERS THEN
GC_ERROR_MESSAGE := 'validation error : '||SQLERRM;
L_FLAG := TRUE;
END;
XXHA_STOCK_LOCATORS_PKG.FLEX_FIELD_VALUE_LOAD('HAE_STOCK_LOCATORS_LOCATION',P_LOC_CODE);
DBMS_OUTPUT.PUT_LINE('Flex value'||P_LOC_CODE);
DBMS_OUTPUT.PUT_LINE('Completed value creation');
IF L_FLAG = FALSE THEN --FALSE
DBMS_OUTPUT.PUT_LINE('Enter');
   INV_LOC_WMS_PUB.CREATE_LOCATOR(
x_return_status => L_RETURN_STATUS,
x_msg_count => L_MSG_COUNT,
x_msg_data => L_MSG_DATA,
x_inventory_location_id => L_INVENTORY_LOCATION_ID,
x_locator_exists => L_LOCATOR_EXISTS,
P_ORGANIZATION_ID => L_ORGANIZATION_ID,
P_ORGANIZATION_CODE => P_ORG_CODE,
P_CONCATENATED_SEGMENTS => P_LOC_CODE||'.'||P_FUT_CODE||'.'||P_FUT_CODE1,
p_description => null,--L_DESCRIPTION
p_inventory_location_type => null, -- Storage locator
p_picking_order => NULL,
P_LOCATION_MAXIMUM_UNITS => NULL,
P_SUBINVENTORY_CODE => P_SUB_CODE, 
p_location_weight_uom_code => NULL,
p_max_weight => NULL,
p_volume_uom_code => NULL,
p_max_cubic_area => NULL,
p_x_coordinate => NULL,
p_y_coordinate => NULL,
p_z_coordinate => NULL,
p_physical_location_id => NULL,
p_pick_uom_code => NULL,
p_dimension_uom_code => NULL,
p_length => NULL,
p_width => NULL,
p_height => NULL,
p_status_id => 1, -- Default status 'Active'
P_DROPPING_ORDER => NULL
);
commit;
  END IF;
--UPDATE XXHA_STOCK_LOC_STG SET RECORD_STATUS = L_RETURN_STATUS 
--where sr_no = loc_rec.sr_no ;  
IF L_RETURN_STATUS IS NULL THEN
DBMS_OUTPUT.PUT_LINE('error :'|| GC_ERROR_MESSAGE);
end if;
DBMS_OUTPUT.PUT_LINE('Return Status '||L_RETURN_STATUS);
--FND_FILE.PUT_LINE(FND_FILE.LOG,'Return Status : '||L_RETURN_STATUS);
IF l_return_status IN ('E', 'U') THEN
DBMS_OUTPUT.PUT_LINE('# of Errors '||L_MSG_COUNT); 
--RAISE UNHANDLED_EXCEPTION;
END IF;
IF L_FLAG = TRUE
THEN 
DBMS_OUTPUT.PUT_LINE('locator is already existing'); 
raise_application_error (-20099,
                            'locator is already existing' || SQLERRM);
end if;

DBMS_OUTPUT.PUT_LINE('Error: '||SQLERRM);
END;


end XXHA_STOCK_LOCATORS_PKG;
/
