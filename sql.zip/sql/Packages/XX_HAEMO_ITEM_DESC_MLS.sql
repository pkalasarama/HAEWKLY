CREATE OR REPLACE package xx_haemo_item_desc_mls
IS
  PROCEDURE item_desc(errbuf OUT VARCHAR2, retcode OUT VARCHAR2, p_lang VARCHAR2);
END xx_haemo_item_desc_mls;

/


CREATE OR REPLACE PACKAGE BODY xx_haemo_item_desc_mls
IS
  PROCEDURE item_desc(errbuf OUT VARCHAR2, retcode OUT VARCHAR2, p_lang VARCHAR2) IS
      v_item_id NUMBER;
      CURSOR cur_items IS
        SELECT *
        FROM   xx_haemo_item_desc_mls_tab;
  BEGIN
	  FOR rec_items IN cur_items LOOP
          BEGIN
		  	   SELECT DISTINCT inventory_item_id
          	   INTO   v_item_id
          	   FROM   mtl_system_items_b msib
          	   WHERE  msib.segment1 = TO_CHAR(TRIM(' ' FROM rec_items.item_segment));
			   UPDATE xx_haemo_item_desc_mls_tab
          	   SET    inventory_item_id = v_item_id
          	   WHERE  item_segment = TO_CHAR(TRIM(' ' FROM rec_items.item_segment));
		  EXCEPTION
		  		   WHEN OTHERS THEN
				   		v_item_id := NULL;
		  END;
	  END LOOP;
      FOR rec_items IN cur_items LOOP
	  	  IF rec_items.item_description_lang IS NOT NULL THEN
		  	 UPDATE mtl_system_items_tl
          	 SET    description = rec_items.item_description_lang
          	 WHERE  inventory_item_id = rec_items.inventory_item_id
                 	AND language = UPPER(p_lang);
		  END IF;
      END LOOP;
      COMMIT;
  END item_desc;
END xx_haemo_item_desc_mls;
/
