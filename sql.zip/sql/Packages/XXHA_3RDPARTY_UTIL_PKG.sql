CREATE OR REPLACE PACKAGE XXHA_3RDPARTY_UTIL_PKG AS

/***********************************************************************************************
* Package Name : XXHA_3RDPARTY_UTIL_PKG                                                        *
*                Change Request: ERPxxxxxx                                                     *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to initialize the column 'attribute3' in the                    *
*                   Site Use Table (hz_cust_site_uses_all).                                    *
*                 - Processing to update the column 'attribute3" in the Site Use Table         *
*                   (hz_cust_site_uses_all) with the value retrieved from Haemo Load Table     *
*                   (HAEMO.XXHA_THIRD_PARTY_LOAD).                                             *
*                                                                                              *
* Procedures   : p_initialize                                                                  *
*                p_load_data                                                                   *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*  APPS.HZ_Cust_Site_Uses_All      U                                                           *
*  HAEMO.XXHA_Third_Party_Load     S                                                           *
*  HAEMO.XXHA_Third_Party_XREF     U                                                           *
*  HAEMO.XXHA_Third_Party_XREF     S                                                           *
*                                                                                              *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        02-Dec-2009     B. Marcoux           Initial Version                              *
***********************************************************************************************/

/* ****************************************************************************************** */
PROCEDURE p_initialize (
                        errbuf             OUT  VARCHAR2
                      , retcode            OUT  NUMBER
                      , p_update_flag      IN   VARCHAR2
                      , p_org_id           IN   hr_Operating_Units.organization_id%TYPE
                       ) ; 

/* ****************************************************************************************** */
PROCEDURE p_load_data  (
                        errbuf             OUT  VARCHAR2
                      , retcode            OUT  NUMBER
                      , p_update_flag      IN   VARCHAR2
                      , p_org_id           IN   hr_Operating_Units.organization_id%TYPE
                       ) ; 

END XXHA_3RDPARTY_UTIL_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_3RDPARTY_UTIL_PKG AS

/***********************************************************************************************
* Package Name : XXHA_3RDPARTY_UTIL_PKG                                                        *
*                Change Request: ERPxxxxxx                                                     *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to initialize the column 'attribute3' in the                    *
*                   Site Use Table (hz_cust_site_uses_all).                                    *
*                 - Processing to update the column 'attribute3" in the Site Use Table         *
*                   (hz_cust_site_uses_all) with the value retrieved from Haemo Load Table     *
*                   (HAEMO.XXHA_THIRD_PARTY_LOAD).                                             *
*                                                                                              *
* Procedures   : p_initialize                                                                  *
*                p_load_data                                                                   *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
*  APPS.HZ_Cust_Site_Uses_All      U                                                           *
*  HAEMO.XXHA_Third_Party_Load     S                                                           *
*  HAEMO.XXHA_Third_Party_XREF     U                                                           *
*  HAEMO.XXHA_Third_Party_XREF     S                                                           *
*                                                                                              *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        02-Dec-2009     B. Marcoux           Initial Version                              *
***********************************************************************************************/

/* ****************************************************************************************** */
/* This procedure will initialize all records in hz_cust_site_uses_all                        */
PROCEDURE p_initialize (
                        errbuf             OUT  VARCHAR2
                      , retcode            OUT  NUMBER
                      , p_update_flag      IN   VARCHAR2
                      , p_org_id           IN   hr_Operating_Units.organization_id%TYPE
                       ) 
IS

l_count NUMBER;

BEGIN

SELECT
     COUNT(*)

INTO
     l_count

FROM
     apps.hz_cust_site_uses_all su

WHERE
     su.attribute3 is not null
;

FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Number of rows in table "hz_cust_site_uses_all" that have data in Attribute3: '|| l_count);

IF p_update_flag = 'Y' THEN

   UPDATE apps.hz_cust_site_uses_all su
   SET    su.attribute3 = NULL
   WHERE  su.attribute3 IS NOT NULL;

   COMMIT;

END IF;

END p_initialize;

/* ****************************************************************************************** */
/* This procedure will update all records in hz_cust_site_uses_all                            */

/* ****************************************************************************************** */
/* This procedure will initialize all records in hz_cust_site_uses_all                        */
PROCEDURE p_load_data  (
                        errbuf             OUT  VARCHAR2
                      , retcode            OUT  NUMBER
                      , p_update_flag      IN   VARCHAR2
                      , p_org_id           IN   hr_Operating_Units.organization_id%TYPE
                       ) 
IS

l_count NUMBER;

BEGIN

SELECT
     COUNT(*)

INTO
     l_count

FROM
      apps.hz_cust_accounts            cust
,     apps.hz_cust_acct_sites_all      cas      --acct_site
,     apps.hz_cust_site_uses_all       su       --site_uses
,     apps.hz_party_sites              ps       --party_site
,     apps.hr_Operating_Units          OpUnit
,     v$database                       b

WHERE
      cust.Cust_Account_ID           = cas.cust_account_ID
AND   cas.Cust_acct_site_ID          = su.cust_acct_site_ID
AND   cas.Org_ID                     = OpUnit.Organization_ID
AND   cas.Party_site_ID              = ps.party_site_ID
AND   su.Site_Use_Code               = 'SHIP_TO'
AND   cas.Org_ID                     = p_org_id
AND   EXISTS (SELECT HAEMO.XXHA_Third_Party_Load.Site_number
                FROM HAEMO.XXHA_Third_Party_Load
               WHERE PS.Party_Site_Number = HAEMO.XXHA_Third_Party_Load.Site_number
                 AND CUST.Account_Number  = HAEMO.XXHA_Third_Party_Load.CUSTOMER_ACCOUNT_NBR)
;

FND_FILE.PUT_LINE(FND_FILE.OUTPUT,'Number of rows in table "hz_cust_site_uses_all" to be updated: '|| l_count);

------------------------------------------------------
-- Load data into table 'HAEMO.XXHA_Third_Party_XREF'
------------------------------------------------------

-- Purge data from table 'XXHA_Third_Party_XREF'
DELETE FROM HAEMO.XXHA_Third_Party_XREF;
COMMIT;

-- Re-load data into table 'XXHA_Third_Party_XREF'
INSERT INTO HAEMO.XXHA_Third_Party_XREF
(SELECT 
      cas.Org_ID
,     OpUnit.Name
,     CUST.Account_Number
,     su.Site_Use_Code
,     su.Location
,     su.attribute1
,     su.attribute3
,     PS.Party_Site_Number
,     su.cust_acct_site_ID
,     su.Site_Use_ID

FROM
      apps.hz_cust_accounts            cust
,     apps.hz_cust_acct_sites_all      cas      --acct_site
,     apps.hz_cust_site_uses_all       su       --site_uses
,     apps.hz_party_sites              ps       --party_site
,     apps.hr_Operating_Units          OpUnit

WHERE
      cust.Cust_Account_ID           = cas.cust_account_ID
AND   cas.Cust_acct_site_ID          = su.cust_acct_site_ID
AND   cas.Org_ID                     = OpUnit.Organization_ID
AND   cas.Party_site_ID              = ps.party_site_ID
AND   su.Site_Use_Code               = 'SHIP_TO'
AND   cas.Org_ID                     = p_org_id
AND   EXISTS (SELECT HAEMO.XXHA_Third_Party_Load.Site_number
                FROM HAEMO.XXHA_Third_Party_Load
               WHERE PS.Party_Site_Number = HAEMO.XXHA_Third_Party_Load.Site_number
                 AND CUST.Account_Number  = HAEMO.XXHA_Third_Party_Load.CUSTOMER_ACCOUNT_NBR)
)
;
COMMIT;

-- Update table 'XXHA_Third_Party_XREF' with data from column Attribute3 in table 'XXHA_Third_Party_Load'
UPDATE HAEMO.XXHA_Third_Party_XREF
SET    HAEMO.XXHA_Third_Party_XREF.Attribute3 =
      (SELECT HAEMO.XXHA_Third_Party_Load.ATTRIBUTE3
         FROM HAEMO.XXHA_Third_Party_Load
        WHERE HAEMO.XXHA_Third_Party_Load.CUSTOMER_ACCOUNT_NBR = HAEMO.XXHA_Third_Party_XREF.ACCOUNT_NUMBER
          AND HAEMO.XXHA_Third_Party_Load.SITE_NUMBER          = HAEMO.XXHA_Third_Party_XREF.PARTY_SITE_NUMBER)
;
COMMIT;

-- If Update_Flag = 'YES', then process the data!
IF p_update_flag = 'Y' THEN

-- Update table 'hz_cust_site_uses_all' with data from column Attribute3 in table 'XXHA_Third_Party_XREF'
   UPDATE apps.hz_cust_site_uses_all
   SET    apps.hz_cust_site_uses_all.attribute3 =
         (SELECT ATTRIBUTE3
            FROM HAEMO.XXHA_Third_Party_XREF
           WHERE HAEMO.XXHA_Third_Party_XREF.Cust_Acct_site_ID    = APPS.hz_cust_site_uses_all.Cust_Acct_site_ID
             AND HAEMO.XXHA_Third_Party_XREF.Site_Use_ID          = APPS.hz_cust_site_uses_all.Site_Use_ID)
                 WHERE EXISTS
                      (SELECT ATTRIBUTE3
                         FROM HAEMO.XXHA_Third_Party_XREF
                        WHERE HAEMO.XXHA_Third_Party_XREF.Cust_Acct_site_ID    = APPS.hz_cust_site_uses_all.Cust_Acct_site_ID
                          AND HAEMO.XXHA_Third_Party_XREF.Site_Use_ID          = APPS.hz_cust_site_uses_all.Site_Use_ID);
   COMMIT;

END IF;

END p_load_data;

END XXHA_3RDPARTY_UTIL_PKG;
/
