CREATE OR REPLACE package      XXHA_TM_ORDER_PKG
as
-- +=============================================================================+
-- | Name             :  XXHA_BOM_CONV_BLL_PK
-- | Description      :  This package supports the processing of BOM routings and
-- |                     bills information staged for conversion.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-07-09  L.Richards     Initial release
-- +=============================================================================+

-- +=====================
-- | Global variables
-- +=====================

   -----------------------------------
   -- Common Errors placeholders
   -----------------------------------
   gn_request_id            xxha_common_errors.request_id%type := fnd_global.conc_request_id;  --Request ID of running concurrent program
   gn_record_number         xxha_common_errors.record_number%type;       --Record number of staged record
   gc_record_identifier     xxha_common_errors.record_identifier%type;   --Record identifier of staged record
   gc_error_code            xxha_common_errors.error_code%type;          --Error Code for detected error
   gc_error_msg             xxha_common_errors.error_msg%type;           --Description of error
   gc_comments              xxha_common_errors.comments%type;            --Comment related to error
   gc_table_name            xxha_common_errors.table_name%type;          --Staging table name
   gc_attribute1            xxha_common_errors.attribute1%type;          --Attribute1
   gc_attribute2            xxha_common_errors.attribute2%type;          --Attribute2
   gc_attribute3            xxha_common_errors.attribute3%type;          --Attribute3
   gc_attribute4            xxha_common_errors.attribute4%type;          --Attribute4 stores the concurrent program name
   gc_attribute5            xxha_common_errors.attribute5%type;          --Attribute5 stores the validated (eg. ROUTING, OPERATION, RESOURCE, BILL, INVCOMP, SUBCOMP)
   gc_error_logged  varchar2(1);
   -----------------------------------
   -- Constants
   -----------------------------------
   gc_table_RTG             xxha_common_errors.table_name%type := 'XXHA_BOM_ROUTING_OPS_STG';  --Staging table for routings
   gc_table_RTGOP           xxha_common_errors.table_name%type := 'XXHA_BOM_ROUTING_OPS_STG';  --Staging table for routing operations
   gc_table_OPRES           xxha_common_errors.table_name%type := 'XXHA_BOM_OP_RESOURCES_STG'; --Staging table for operation resources
   gc_table_BILL            xxha_common_errors.table_name%type := 'XXHA_BOM_INV_COMPS_STG';    --Staging table for bills
   gc_table_INVCOMP         xxha_common_errors.table_name%type := 'XXHA_BOM_INV_COMPS_STG';    --Staging table for bill components
   gc_table_SUBCOMP         xxha_common_errors.table_name%type := 'XXHA_BOM_SUB_COMPS_STG';    --Staging table for substitute components
   gc_conc_name_BILL        xxha_common_errors.attribute4%type := 'XXHA_BOM_BILLS_CONV';       --CP name for Bills conversion
   gc_conc_name_RTG         xxha_common_errors.attribute4%type := 'XXHA_BOM_RTGS_CONV';        --CP name for Routings conversion
   gc_valtype_RTG           xxha_common_errors.attribute5%type := 'ROUTING';                   --Validation type for routings
   gc_valtype_RTGOP         xxha_common_errors.attribute5%type := 'OPERATION';                 --Validation type for routing operations
   gc_valtype_OPRES         xxha_common_errors.attribute5%type := 'RESOURCE';                  --Validation type for operation resources
   gc_valtype_BILL          xxha_common_errors.attribute5%type := 'BILL';                      --Validation type for bills
   gc_valtype_INVCOMP       xxha_common_errors.attribute5%type := 'INVCOMP';                   --Validation type for bill components
   gc_valtype_SUBCOMP       xxha_common_errors.attribute5%type := 'SUBCOMP';                   --Validation type for substitute components
   gc_org_code_MST          mtl_parameters.organization_code%type := 'MST';                   --Master Organization Code
   gn_org_id_MST            mtl_parameters.organization_id%type := 103;                     --Master Organization Id
   gc_language_code         fnd_languages.language_code%type := 'US';                    --Language_code
   gc_assembly_item_number   varchar2 (2000);
   -----------------------------------
   -- Other placeholder variables
   -----------------------------------
   gc_org_code              mtl_parameters.organization_code%type;        --Current Org being processed
   gc_debug_flag            VARCHAR2(1);                                  --Debug_flag for display debug
   gc_conc_name             xxha_common_errors.attribute4%type;           --CP name placeholder to delete the records from common error table
   gn_user_id               fnd_user.user_id%type := FND_GLOBAL.USER_ID;  --User name for running conversion program
   gc_log_msg               VARCHAR2(1000);                               --Log_msg to display msgs
   gc_error_report          VARCHAR2(1) := 'N';                           --Error_report launch if its <>'N'
   --gc_program_name          VARCHAR2(50) := 'Item Conversion';          --Program Name In parameter for launch_error_prc procedure
   --gc_rec_identifier        VARCHAR2(50) := 'Item Number';              --Record identifier In parameter for launch_error_prc procedure
   --gc_starting_revision     mtl_parameters.starting_revision%type;      --Variable to get staring revision against the Inventory Orgs

   gc_now                   date;
   gc_status                VARCHAR2(2);                              --Variable to get status flag of data insertion in common error table
   gc_transaction_type      mtl_system_items_interface.transaction_type%type := 'CREATE';   --Default transaction_type
   gc_process_flag          mtl_system_items_interface.process_flag%type := '1';            --Default process_flag

-- +==============================================================================+
-- | Name       : convert_so
-- |
-- | Description: Procedure to process staged Bill info in preparation for
-- |              importing.  It drives the following actions:
-- |               . Validate staged records
-- |               . Update staged records with internal IDs matching user-friendly values
-- |               . Call launch program for reporting errors (if any)
-- |               . Populate interface tables if no errors found
-- |
-- | PARAMETERS:
-- |   IN: p_org_code
-- |       p_debug_flag
-- |       p_purge_flag
-- |  OUT: x_err_buf
-- |       x_ret_code
-- |
-- | SCOPE: PUBLIC
-- |
-- +==============================================================================+

PROCEDURE convert_so (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_batch_number  in  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
		,p_commit      in   varchar2
        ) ;



END XXHA_TM_ORDER_PKG;  -- package spec

/


CREATE OR REPLACE package body      XXHA_TM_ORDER_PKG
as
-- +=============================================================================+
-- | Name             :  XXHA_TM_ORDER_PKG
-- | Description      :  This package creates indirect sales orders
-- |                     from trade management data
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-09-09  Palash Kundu     Initial release
-- |  2.0      2010-09-21  David Lund       Added logic to pass payment terms
-- |  3.0      2011-08-10  David Lund       Added logic to allow partial batch processing
-- +=============================================================================+

  -- Cursor for errored records
  /*cursor c_err (
           q_request_id  xxha_common_errors.request_id%type
          ,q_table_name  xxha_common_errors.table_name%type
          ,q_conc_name  xxha_common_errors.attribute4%type
          ,q_validation_type  xxha_common_errors.attribute5%type
          ) is
    select  ce.error_code
           ,ce.error_msg
           ,count(1)  cnt
    from    xxha_common_errors  ce
    where   ce.request_id = q_request_id
    and     ce.table_name = q_table_name
    and     ce.attribute4 = q_conc_name
    and     ce.attribute5 = q_validation_type
    group by ce.error_code
            ,ce.error_msg
    order by 1;
*/
---------------------------------------------------------------------------
---Error Handling
---------------------------------------------------------------------------
TYPE XX_COMMON_ERROR_Tbl_Type IS TABLE OF XXHA_COMMON_ERRORS%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_COMMON_ERROR_TBL		XX_COMMON_ERROR_Tbl_Type;
	TYPE XX_TM_SO_STG_Tbl_Type IS TABLE OF XXHA_TM_SO_STG%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_TM_SO_STG_TBL		XX_TM_SO_STG_Tbl_Type;
	TYPE XX_TM_SO_SUCCESS_STG_Tbl_Type IS TABLE OF XXHA_TM_SO_STG%ROWTYPE
            INDEX BY BINARY_INTEGER;
	XX_TM_SO_SUCCESS_STG_TBL		XX_TM_SO_SUCCESS_STG_Tbl_Type;
procedure populate_tm_so_stg_tbl(party_site_number varchar2) is
  l_tm_so_counter number;
begin
   l_tm_so_counter :=XX_TM_SO_STG_TBL.count;
			 XX_TM_SO_STG_TBL(l_tm_so_counter+1).party_site_number := party_site_number;
end populate_tm_so_stg_tbl;
procedure populate_common_error(error_msg varchar2,error_code varchar2,error_comments varchar2,record_number number,record_identifier varchar2) is
  l_error_counter number;
begin
gc_error_logged := 'Y';
dbms_output.put_line(' popu err large '||substr(error_msg,1,2000));
   l_error_counter := XX_COMMON_ERROR_TBL.count;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_msg := substr(error_msg,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).request_id := gn_request_id;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_number := record_number;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).error_code := substr(error_code,1,20);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).record_identifier := record_identifier;
			 XX_COMMON_ERROR_TBL(l_error_counter+1).comments := substr(error_comments,1,2000);
			 XX_COMMON_ERROR_TBL(l_error_counter+1).attribute4 := gc_attribute4;
             populate_tm_so_stg_tbl(record_number);
end populate_common_error;
procedure populate_tm_so_success_stg_tbl(party_site_number varchar2) is
  l_tm_so_succ_counter number;
begin
   l_tm_so_succ_counter :=XX_TM_SO_SUCCESS_STG_TBL.count;
			 XX_TM_SO_SUCCESS_STG_TBL(l_tm_so_succ_counter+1).party_site_number := party_site_number;
end populate_tm_so_success_stg_tbl;
procedure log_error
          is
begin
   gc_error_logged := 'Y';
   xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,gc_comments
                            ,gc_table_name
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
	dbms_output.put_line('error '||gc_error_code||gc_error_msg||gc_comments);
exception
   when others then
      populate_common_error(substr(sqlerrm,1,2000),'log error','When Others Log Error',gn_record_number,gc_record_identifier);
	  fnd_file.put_line(fnd_file.log,'Error in XXHA_TM_ORDER_PKG.INSERT_ERROR_PRC. Error is: ' ||SQLERRM);
end log_error;
procedure log_all_errors IS
l_error_occured boolean := FALSE;
a number;
b number;
BEGIN
a := XX_COMMON_ERROR_TBL.COUNT;
b:= XX_TM_SO_STG_TBL.COUNT;
  dbms_output.put_line('All Error '||xx_common_error_tbl.count);
FOR i IN 1..XX_COMMON_ERROR_TBL.COUNT LOOP
     l_error_occured := TRUE;
     gn_request_id :=  XX_COMMON_ERROR_TBL(i).request_id;
     gn_record_number := XX_COMMON_ERROR_TBL(i).record_number;
     gc_record_identifier := XX_COMMON_ERROR_TBL(i).record_identifier ;
     gc_error_code := XX_COMMON_ERROR_TBL(i).error_code;
     gc_error_msg := XX_COMMON_ERROR_TBL(i).error_msg;
     gc_comments  :=  XX_COMMON_ERROR_TBL(i).comments;
     gc_table_name :=  XX_COMMON_ERROR_TBL(i).table_name;
     gc_attribute1 :=  XX_COMMON_ERROR_TBL(i).attribute1;
     gc_attribute2 :=  XX_COMMON_ERROR_TBL(i).attribute2;
     gc_attribute3:=  XX_COMMON_ERROR_TBL(i).attribute3;
     gc_attribute4 :=  XX_COMMON_ERROR_TBL(i).attribute4;
     gc_attribute5 :=  XX_COMMON_ERROR_TBL(i).attribute5;
log_error;
ENd LOOP;
IF NOT l_error_occured THEN
 xxha_common_utilities_pkg.insert_error_prc(
                             gn_request_id
                            ,gn_record_number
                            ,gc_record_identifier
                            ,gc_error_code
                            ,gc_error_msg
                            ,'No Error Occured'
                            ,'XXHA_TM_SO_STG'
                            ,gc_attribute1
                            ,gc_attribute2
                            ,gc_attribute3
                            ,gc_attribute4
                            ,gc_attribute5
                            ,gc_status
                            );
    gc_error_logged := 'N';
	dbms_output.put_line('No err ');
  ELSE
    FOR i IN 1..XX_TM_SO_STG_TBL.COUNT LOOP
	  IF XX_TM_SO_STG_TBL(i).legacy_invoice_number IS NOT NULL THEN
	    dbms_output.put_line('VE------A '||XX_TM_SO_STG_TBL(i).party_site_number);
		update xxha_tm_so_stg
	    set status = 'VE'
		where party_site_number = XX_TM_SO_STG_TBL(i).party_site_number
		and status <> 'VE';
	  END IF;
	END LOOP;
  END IF;
END log_all_errors;
-----------------------------------------------------------------------------
----CALL_BOM_API
-----------------------------------------------------------------------------
PROCEDURE CALL_OM_API
	 		   				   	 ( p_header_rec OE_ORDER_PUB.Header_Rec_Type
		                          ,p_line_tbl OE_ORDER_PUB.Line_Tbl_Type
								  ) IS
l_header_rec OE_ORDER_PUB.Header_Rec_Type;
		l_line_tbl OE_ORDER_PUB.Line_Tbl_Type;
		l_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type;
		l_header_adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type;
		l_line_adj_tbl OE_ORDER_PUB.line_adj_tbl_Type;
		l_header_scr_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type;
		l_line_scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type;
		l_return_status VARCHAR2(1000);
		l_msg_count NUMBER;
		l_msg_data VARCHAR2(1000);
		p_api_version_number NUMBER :=1.0;
		p_init_msg_list VARCHAR2(10) := FND_API.G_FALSE;
		p_return_values VARCHAR2(10) := FND_API.G_FALSE;
		p_action_commit VARCHAR2(10) := FND_API.G_FALSE;
		x_return_status VARCHAR2(1);
		x_msg_count NUMBER;
		x_msg_data VARCHAR2(100);
		p_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type :=
		oe_order_pub.G_MISS_REQUEST_TBL;
		x_header_val_rec OE_ORDER_PUB.Header_Val_Rec_Type;
		x_Header_Adj_tbl OE_ORDER_PUB.Header_Adj_Tbl_Type;
		x_Header_Adj_val_tbl OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
		x_Header_price_Att_tbl OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
		x_Header_Adj_Att_tbl OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
		x_Header_Adj_Assoc_tbl OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
		x_Header_Scredit_tbl OE_ORDER_PUB.Header_Scredit_Tbl_Type;
		x_Header_Scredit_val_tbl OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
		x_line_val_tbl OE_ORDER_PUB.Line_Val_Tbl_Type;
		x_Line_Adj_tbl OE_ORDER_PUB.Line_Adj_Tbl_Type;
		x_Line_Adj_val_tbl OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
		x_Line_price_Att_tbl OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
		x_Line_Adj_Att_tbl OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
		x_Line_Adj_Assoc_tbl OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
		x_Line_Scredit_tbl OE_ORDER_PUB.Line_Scredit_Tbl_Type;
		x_Line_Scredit_val_tbl OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
		x_Lot_Serial_tbl OE_ORDER_PUB.Lot_Serial_Tbl_Type;
		x_Lot_Serial_val_tbl OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type;
		x_action_request_tbl OE_ORDER_PUB.Request_Tbl_Type;
		X_DEBUG_FILE VARCHAR2(100);
		l_action_request_tbl_index NUMBER;
		l_msg_index_out NUMBER(10);
BEGIN
  	   dbms_output.put_line('Call API '	);
	   DBMS_APPLICATION_INFO.SET_CLIENT_INFO(102);
	   fnd_client_info.set_org_context(102);
	   --FND_GLOBAL.APPS_INITIALIZE(USER_ID=>-1,RESP_ID=>50237,RESP_APPL_ID=>660);
	   oe_msg_pub.initialize;
       oe_debug_pub.initialize;
       X_DEBUG_FILE := OE_DEBUG_PUB.Set_Debug_Mode('TABLE');
       oe_debug_pub.SetDebugLevel(0); -- Use 5 for the most debuging output, I warn you its a lot
	 --IF nvl(gc_assembly_item_number,'N')<>l_bom_header_rec.assembly_item_name THEN
	   dbms_output.put_line('START OF NEW DEBUG');
-------------------------------------------------------------------------------------------
        l_action_request_tbl(1) := oe_order_pub.g_miss_request_rec;
OE_ORDER_PUB.process_order(
		p_api_version_number => 1.0
		, p_init_msg_list => fnd_api.g_false
		, p_return_values => fnd_api.g_false
		, p_action_commit => fnd_api.g_false
		, x_return_status => l_return_status
		, x_msg_count => l_msg_count
		, x_msg_data => l_msg_data
		--, p_action_request_tbl => l_action_request_tbl
		,p_header_rec=>p_header_rec
		,p_line_tbl=>p_line_tbl
		-- OUT PARAMETERS
		, x_header_rec => l_header_rec
		, x_header_val_rec => x_header_val_rec
		, x_Header_Adj_tbl => x_Header_Adj_tbl
		, x_Header_Adj_val_tbl => x_Header_Adj_val_tbl
		, x_Header_price_Att_tbl => x_Header_price_Att_tbl
		, x_Header_Adj_Att_tbl => x_Header_Adj_Att_tbl
		, x_Header_Adj_Assoc_tbl => x_Header_Adj_Assoc_tbl
		, x_Header_Scredit_tbl => x_Header_Scredit_tbl
		, x_Header_Scredit_val_tbl => x_Header_Scredit_val_tbl
		, x_line_tbl => l_line_tbl
		, x_line_val_tbl => x_line_val_tbl
		, x_Line_Adj_tbl => x_Line_Adj_tbl
		, x_Line_Adj_val_tbl => x_Line_Adj_val_tbl
		, x_Line_price_Att_tbl => x_Line_price_Att_tbl
		, x_Line_Adj_Att_tbl => x_Line_Adj_Att_tbl
		, x_Line_Adj_Assoc_tbl => x_Line_Adj_Assoc_tbl
		, x_Line_Scredit_tbl => x_Line_Scredit_tbl
		, x_Line_Scredit_val_tbl => x_Line_Scredit_val_tbl
		, x_Lot_Serial_tbl => x_Lot_Serial_tbl
		, x_Lot_Serial_val_tbl => x_Lot_Serial_val_tbl
		, x_action_request_tbl => l_action_request_tbl
		);
		dbms_output.put_line('OM Debug file: ' ||oe_debug_pub.G_DIR||'/'||oe_debug_pub.G_FILE);
		FOR i IN 1 .. l_msg_count LOOP
		Oe_Msg_Pub.get( p_msg_index => i
		, p_encoded => Fnd_Api.G_FALSE
		, p_data => l_msg_data
		, p_msg_index_out => l_msg_index_out
		);
populate_common_error(l_msg_data,l_return_status,'OM_API__ERROR'||p_header_rec.sold_to_org_id||p_header_rec.blanket_number||p_line_tbl(p_line_tbl.count).blanket_number||'a'||p_line_tbl.count,gn_record_number,gc_record_identifier);
		DBMS_OUTPUT.PUT_LINE('message is: ' || l_msg_data);
		DBMS_OUTPUT.PUT_LINE('message index is: ' || l_msg_index_out);
		END LOOP;
-- Check the return status
  IF l_return_status = FND_API.G_RET_STS_SUCCESS THEN
			dbms_output.put_line('Process Order Success'||l_header_rec.order_number);
			--commit;
			--l_line_id := l_line_tbl(1).line_id;
			---------------
update xxha_tm_so_stg
			set order_number = l_header_rec.order_number
			,status = 'PS'
			where party_site_number = gn_record_number;
			l_action_request_tbl(1) := oe_order_pub.g_miss_request_rec;
			l_action_request_tbl_index :=1;
			-- action request
			l_action_request_tbl(l_action_request_tbl_index).request_type := oe_globals.g_book_order;
			l_action_request_tbl(l_action_request_tbl_index).entity_code := oe_globals.g_entity_header;
			l_action_request_tbl(l_action_request_tbl_index).entity_id := l_header_rec.header_id;
			dbms_output.put_line('Header id'||l_header_rec.header_id);
			OE_ORDER_PUB.process_order(
			p_api_version_number => 1.0
			, p_init_msg_list => fnd_api.g_false
			, p_return_values => fnd_api.g_false
			, p_action_commit => fnd_api.g_false
			, x_return_status => l_return_status
			, x_msg_count => l_msg_count
			, x_msg_data => l_msg_data
			, p_action_request_tbl => l_action_request_tbl
			--,p_header_rec=>p_header_rec
			--,p_line_tbl=>p_line_tbl
			-- OUT PARAMETERS
			, x_header_rec => l_header_rec
			, x_header_val_rec => x_header_val_rec
			, x_Header_Adj_tbl => x_Header_Adj_tbl
			, x_Header_Adj_val_tbl => x_Header_Adj_val_tbl
			, x_Header_price_Att_tbl => x_Header_price_Att_tbl
			, x_Header_Adj_Att_tbl => x_Header_Adj_Att_tbl
			, x_Header_Adj_Assoc_tbl => x_Header_Adj_Assoc_tbl
			, x_Header_Scredit_tbl => x_Header_Scredit_tbl
			, x_Header_Scredit_val_tbl => x_Header_Scredit_val_tbl
			, x_line_tbl => l_line_tbl
			, x_line_val_tbl => x_line_val_tbl
			, x_Line_Adj_tbl => x_Line_Adj_tbl
			, x_Line_Adj_val_tbl => x_Line_Adj_val_tbl
			, x_Line_price_Att_tbl => x_Line_price_Att_tbl
			, x_Line_Adj_Att_tbl => x_Line_Adj_Att_tbl
			, x_Line_Adj_Assoc_tbl => x_Line_Adj_Assoc_tbl
			, x_Line_Scredit_tbl => x_Line_Scredit_tbl
			, x_Line_Scredit_val_tbl => x_Line_Scredit_val_tbl
			, x_Lot_Serial_tbl => x_Lot_Serial_tbl
			, x_Lot_Serial_val_tbl => x_Lot_Serial_val_tbl
			, x_action_request_tbl => l_action_request_tbl
			);
IF l_return_status = FND_API.G_RET_STS_SUCCESS			THEN
			  dbms_output.put_line('Book Order Success');
			  populate_tm_so_success_stg_tbl(gn_record_number);
			--commit;
			ELSE
			   FOR i IN 1 .. l_msg_count LOOP
			     Oe_Msg_Pub.get( p_msg_index => i
			     , p_encoded => Fnd_Api.G_FALSE
			     , p_data => l_msg_data
			     , p_msg_index_out => l_msg_index_out
			     );
populate_common_error(l_msg_data,l_return_status,'OM_API_ERROR_BOOK_ORDER',gn_record_number,gc_record_identifier);
				 DBMS_OUTPUT.PUT_LINE('message is: ' || l_msg_data);
			     DBMS_OUTPUT.PUT_LINE('message index is: ' || l_msg_index_out);
			   END LOOP;
dbms_output.put_line('Book Order Fail');
			END IF;
-->----
---------------
ELSE
		dbms_output.put_line('Failed');
		  FOR i IN 1 .. l_msg_count LOOP
		     Oe_Msg_Pub.get( p_msg_index => i
		     , p_encoded => Fnd_Api.G_FALSE
		     , p_data => l_msg_data
		     , p_msg_index_out => l_msg_index_out
		     );
populate_common_error(l_msg_data,l_return_status,'OM_API_ERROR.',gn_record_number,gc_record_identifier);
		  END LOOP;
  END IF;
-- debug output
dbms_output.put_line('Debug Output'||l_header_rec.order_number||p_header_rec.blanket_number);
FOR i in 1..OE_DEBUG_PUB.g_debug_count
LOOP
dbms_output.put_line(OE_DEBUG_PUB.G_debug_tbl(i));
END LOOP;
dbms_output.put_line(l_return_status);
EXCEPTION
    when others then
	    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others Call OM API',gn_record_number,gc_record_identifier);
	  dbms_output.put_line('Call API Exception '	);
END CALL_OM_API;
PROCEDURE Validate_Ord_Data
IS
  cursor c_ord_data is
  select *
  from xxha_tm_so_stg
  where status <> 'PS';
  l_sold_to_org_id number;
  l_ship_to_org_id number;
  l_invoice_to_org_id number;
  l_order_type_id number;
  l_order_type_line_id number;
  l_inventory_item_id number;
  l_price_list_id number;
  l_ship_from_org_id number;
  l_blanket_line_number number;
  l_order_source_id number;
BEGIN
  FOR v_ord_data in c_ord_data LOOP
    gn_record_number := to_number(v_ord_data.party_site_number);
	gc_record_identifier := v_ord_data.customer_po_number||' TM Order Number / Bsa No '||v_ord_data.line_bsa_no;
    begin
	  IF v_ord_data.party_site_number IS NULL THEN

	    raise no_data_found;
	  end if;

	  /*select customer_id,site_use_id,bill_to_site_use_id   ---11i code modified
	  into l_sold_to_org_id,l_ship_to_org_id,l_invoice_to_org_id
	  from ra_addresses_all adr,ra_site_uses_all uses
	  where site_NUMBER  = v_ord_data.party_site_NUMBER
	  and adr.address_id = uses.address_id
    and uses.attribute3 is not null
	  and site_use_code = 'SHIP_TO';*/
    ---R12 Remediated
  select ---customer_id,
      hcasa.cust_account_id,
      uses.site_use_id,
      uses.bill_to_site_use_id
into l_sold_to_org_id,l_ship_to_org_id,l_invoice_to_org_id
from ---ra_addresses_all adr,
    hz_party_sites HPS,
    hz_locations hl,
    hz_cust_acct_sites_all hcasa,
    ---ra_site_uses_all uses
    hz_cust_site_uses_all uses
where hps.party_site_number  = v_ord_data.party_site_number
	  ---and adr.address_id = uses.address_id
    and hcasa.cust_acct_site_id = uses.cust_acct_site_id
    and hps.location_id               = hl.location_id
    and hps.party_site_id             = hcasa.party_site_id
    and uses.attribute3 is not null
	  and uses.site_use_code = 'SHIP_TO';
update xxha_tm_so_stg
	  set sold_to_org_id = l_sold_to_org_id
	  ,ship_to_org_id = l_ship_to_org_id
	  ,invoice_to_org_id = l_invoice_to_org_id
	  where party_site_number = v_ord_data.party_site_number;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.customer_po_number||' TM Order Number / Bsa No '||v_ord_data.line_bsa_no;
	   --gc_record_identifier := v_ord_data.party_site_number;
	   populate_common_error(substr(sqlerrm,1,2000),'Party Site Id Not Found' ,'Party Site ID Not Found',gn_record_number,gc_record_identifier);
	end;
	begin
	  select transaction_type_id
	  into l_order_type_line_id
	  from oe_transaction_types_tl
	  where language = 'US'
	  and name  = v_ord_data.line_type;
	  update xxha_tm_so_stg
	  set line_type_id = l_order_type_line_id
	  where line_type = v_ord_data.line_type;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.Line_type;
	   populate_common_error(substr(sqlerrm,1,2000),'Line Order Type Not Found' ,'Line Order Type ID Not Found',gn_record_number,gc_record_identifier);

	end;
	begin
	  select order_source_id
	  into l_order_source_id
	  from oe_order_Sources
	  where name = '3rd_Party_Tracing';
	  update xxha_tm_so_stg
	  set order_source_id = l_order_source_id;
	exception
	 when no_data_found then
	   gc_record_identifier := '3rd_Party_Tracing' || 'Order Source';
	   populate_common_error(substr(sqlerrm,1,2000),'Order Source Not Found' ,'Order Source ID Not Found',gn_record_number,gc_record_identifier);

	end;
begin
	  select transaction_type_id
	  into l_order_type_id
	  from oe_transaction_types_tl
	  where language = 'US'
	  and name  = v_ord_data.order_type;
	  update xxha_tm_so_stg
	  set order_type_id = l_order_type_id
	  where order_type = v_ord_data.order_type;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.Order_type;
	   populate_common_error(substr(sqlerrm,1,2000),'Order Type Not Found' ,'Order Type ID Not Found',gn_record_number,gc_record_identifier);

	end;
	begin
	  select inventory_item_id
	  into l_inventory_item_id
	  from mtl_system_items
	  where organization_id = 103
	  and segment1  = v_ord_data.item;
	  update xxha_tm_so_stg
	  set inventory_item_id = l_inventory_item_id
	  where item = v_ord_data.item;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.item;
	   populate_common_error(substr(sqlerrm,1,2000),'Item Not Found' ,'Item Not Found',gn_record_number,gc_record_identifier);

	end;
/*	begin
	  select price_list_id
	    into l_price_list_id
		from oe_blanket_headers_all
		where order_number = v_ord_data.line_bsa_no;
	  update xxha_tm_so_stg
	  set line_price_list_id = l_price_list_id
	  where line_bsa_no = v_ord_data.line_bsa_no;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.line_bsa_no;
	   populate_common_error(substr(sqlerrm,1,2000),'Line BSA Price List Not Found' ,'Line BSA Price List Not Found',gn_record_number,gc_record_identifier);
end;
	begin
	  select price_list_id
	    into l_price_list_id
		from oe_blanket_headers_all
		where order_number = v_ord_data.hdr_bsa_no;
	  update xxha_tm_so_stg
	  set hdr_price_list_id = l_price_list_id
	  where hdr_bsa_no = v_ord_data.hdr_bsa_no;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.hdr_bsa_no;
	   populate_common_error(substr(sqlerrm,1,2000),'HDR BSA Price List Not Found' ,'Hdr BSA Price List Not Found',gn_record_number,gc_record_identifier);
end;*/
	IF to_number(v_ord_data.quantity) < 0 THEN
	begin

	  select organization_id
	    into l_ship_from_org_id
		from mtl_parameters
		where organization_code = v_ord_data.return_warehouse;
	  update xxha_tm_so_stg
	  set ship_from_org_id = l_ship_from_org_id
	  where return_warehouse = v_ord_data.return_warehouse;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.return_warehouse;
	   populate_common_error(substr(sqlerrm,1,2000),'Warehouse Not Found' ,'Warehouse Not Found',gn_record_number,gc_record_identifier);
end;
    END IF;
/*	begin

	  select line_number
	  into l_blanket_line_number
	  from oe_blanket_headers_all bl_hdr,oe_blanket_lines_all bl_line
	  where bl_hdr.header_id = bl_line.header_id
	  and ordered_item = v_ord_data.item
	  and bl_hdr.order_number = v_ord_data.line_bsa_no;
	  update xxha_tm_so_stg
	  set blanket_line_number = l_blanket_line_number
	  where line_bsa_no = v_ord_data.line_bsa_no
	  and item = v_ord_data.item;
	exception
	 when no_data_found then
	   gc_record_identifier := v_ord_data.return_warehouse;
	   populate_common_error(substr(sqlerrm,1,2000),'Warehouse Not Found' ,'Warehouse Not Found',gn_record_number,gc_record_identifier);
end;*/
  END LOOP;
 EXCEPTION
 When Others then
 populate_common_error(substr(sqlerrm,1,2000),'Validate Ord Failed' ,'When Others Validate SO',gn_record_number,gc_record_identifier);
END;
-----------------------------------------------------------------------------
----Populate BOM Component
-----------------------------------------------------------------------------
PROCEDURE populate_order_lines
		  					 	(l_line_tbl        IN OUT          OE_ORDER_PUB.Line_Tbl_Type
								 ,p_party_site_number   Varchar2
								--,l_sold_to_org_id     IN               VARCHAR2
								--,l_hdr_bsa_no     IN              VARCHAR2
								)

	IS
	     -- Cursor for validated bills comp
		  cursor c_ord_lines (
           		 			q_party_site_number varchar2
							--q_sold_to_org_id  VARCHAR2
							--,q_hdr_bsa_no VARCHAR2
							) is
    		select  ord_lines.*
    	   	from    xxha_tm_so_stg ord_lines
    		where   status <> 'PS'
    		and party_site_number = q_party_site_number
			--and     sold_to_org_id = q_sold_to_org_id
			--and hdr_bsa_no = q_hdr_bsa_no
			;

			v_org_code                 VARCHAR2(1000);
  			v_out_item_id  			 NUMBER;
  			v_err_cd    				 VARCHAR2(1000);
  			v_err_msg    				 VARCHAR2(1000);
  			v_out_item_at_org  			 BOOLEAN;
  			v_comp_sequence_id  		 NUMBER;
  			v_out_comp_found 			 BOOLEAN;
			l_x_sub_comp_exist           BOOLEAN;
			l_x_return_status            VARCHAR2(1000);
  			l_x_msg_count                NUMBER;
			l_trx_type                   VARCHAR2(1000);
			l_x_effectivity_date         DATE;
            l_line_tbl_counter           NUMBER;
  l_terms_id  NUMBER;
	BEGIN
	  dbms_output.put_line('Populate Bom Component '	);
	   l_line_tbl_counter := 0;
	   l_line_tbl.delete;

	   FOR v_ord_lines in c_ord_lines (p_party_site_number) loop

      --DL 9/21/2010 added to pull in payment terms
      begin
          select l.payment_term_id
          into l_terms_id
          from oe_blanket_headers_all h, oe_blanket_lines_all l
          where h.order_number = v_ord_lines.line_bsa_no
          and h.header_id = l.header_id
          and l.line_number = v_ord_lines.blanket_line_number;
      exception when others then
          l_terms_id := null;
      end;
      --DL end of changes
 dbms_output.put_line('Print sold to org id Item '||p_party_site_number);
		    l_line_tbl_counter := l_line_tbl_counter + 1;
l_line_tbl(l_line_tbl_counter)              	    := OE_ORDER_PUB.G_MISS_LINE_REC;
			l_line_tbl(l_line_tbl_counter).org_id             := 102;
			l_line_tbl(l_line_tbl_counter).cust_po_number     := v_ord_lines.customer_po_number;
			l_line_tbl(l_line_tbl_counter).line_type_id       := v_ord_lines.line_type_id;
			l_line_tbl(l_line_tbl_counter).blanket_number     := to_number(v_ord_lines.line_bsa_no);
			l_line_tbl(l_line_tbl_counter).order_source_id    := v_ord_lines.order_source_id ;
			l_line_tbl(l_line_tbl_counter).inventory_item_id  := v_ord_lines.inventory_item_id;
      --DL 9/21/2010 added to pull in payment terms
			l_line_tbl(l_line_tbl_counter).payment_term_id    := l_terms_id;
      --DL end of changes
			l_line_tbl(l_line_tbl_counter).line_number        := l_line_tbl_counter;

			l_line_tbl(l_line_tbl_counter).ordered_quantity := v_ord_lines.quantity;
			--l_line_tbl(l_line_tbl_counter).blanket_number := v_ord_lines.line_bsa_no ;
			l_line_tbl(l_line_tbl_counter).sold_to_org_id := v_ord_lines.sold_to_org_id;
			l_line_tbl(l_line_tbl_counter).operation        		:= OE_GLOBALS.G_OPR_CREATE;
			l_line_tbl(l_line_tbl_counter).price_list_id := v_ord_lines.line_price_list_id;
			l_line_tbl(l_line_tbl_counter).request_date := to_date(v_ord_lines.request_date,'DD/MON/YYYY');
			IF to_number(v_ord_lines.quantity) < 0 THEN
			  l_line_tbl(l_line_tbl_counter).ship_from_org_id := v_ord_lines.ship_from_org_id;
			  l_line_tbl(l_line_tbl_counter).return_reason_code := v_ord_lines.return_reason;
			ELSE
			 l_line_tbl(l_line_tbl_counter).pricing_quantity := v_ord_lines.quantity;
			ENd IF;
			l_line_tbl(l_line_tbl_counter).blanket_line_number := v_ord_lines.blanket_line_number;

END LOOP;
	Exception
	When Others Then
	    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others populate order lines',gn_record_number,gc_record_identifier);
	END populate_order_lines;
-----------------------------------------------------------------------------
----Populate BOM Header
-----------------------------------------------------------------------------
PROCEDURE populate_order_header
	IS
	     -- Cursor for validated bills
		  cursor c_ord_hdr --(
		           --q_org_code  varchar2
		          --)
				  is
		    select  distinct
		            party_site_number
					--ord_hdr.customer_number
		           --,ord_hdr.line_bsa_no
				   --,bom_hdr.record_id
		    from    xxha_tm_so_stg  ord_hdr
		    where   ord_hdr.status <> 'PS'
			order by party_site_number desc
		    ;

			cursor c_ord_hdr_details (
           		 			q_party_site_number varchar2
							--q_customer_number  VARCHAR2
							--,q_hdr_bsa_no VARCHAR2
							) is
select  distinct
			         order_type_id
			        ,salesrep_id
					,hdr_bsa_no
					,party_site_number
			        ,hdr_price_list_id
					,customer_po_number
					,customer_number
					,sold_to_org_id
					,order_source_id
					,hdr_attribute1
					,hdr_attribute2
					,hdr_attribute3
					,hdr_attribute4
					,hdr_attribute5
					--,record_id
			from    xxha_tm_so_stg
    		where   status <> 'PS'
    	    and     party_site_number = q_party_site_number
		--	and     customer_number = q_customer_number
    	--	and     hdr_bsa_no = q_hdr_bsa_no
    		;

                        v_org_code                 VARCHAR2(1000);
  			v_out_item_id  			 NUMBER;
  			v_err_cd    				 VARCHAR2(1000);
  			v_err_msg    				 VARCHAR2(1000);
  			v_out_item_at_org  			 BOOLEAN;
  			v_bill_sequence_id  		 NUMBER;
  			v_out_bill_found 			 BOOLEAN;
			l_bom_component_tbl          Bom_Bo_Pub.Bom_Comps_Tbl_Type;
			l_chk_comp_error             BOOLEAN;
			l_bom_header_rec             Bom_Bo_Pub.Bom_Head_Rec_Type;
			l_bom_revision_tbl         Bom_Bo_Pub.Bom_Revision_Tbl_Type;
			l_bom_ref_designator_tbl   Bom_Bo_Pub.Bom_Ref_Designator_Tbl_type;
			l_bom_sub_component_tbl    Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type;
			l_x_bom_header_rec          Bom_Bo_Pub.bom_Head_Rec_Type;
			l_x_bom_revision_tbl        Bom_Bo_Pub.Bom_Revision_Tbl_Type;
  			l_x_bom_component_tbl       Bom_Bo_pub.Bom_Comps_Tbl_Type;
  			l_x_bom_ref_designator_tbl  Bom_Bo_Pub.Bom_Ref_Designator_Tbl_Type;
		    l_x_bom_sub_component_tbl   Bom_Bo_Pub.Bom_Sub_Component_Tbl_Type;
			l_x_return_status           Varchar2(2000);
			l_x_msg_count           NUMBER;
			l_trx_type               VARCHAR2(1000);
			l_component_number       NUMBER;
			l_ord_header_rec OE_ORDER_PUB.Header_Rec_Type;
			l_line_tbl                  OE_ORDER_PUB.Line_Tbl_Type;
			l_one_pass_only boolean;
			l_cnt number:= 1;
BEGIN
	  dbms_output.put_line('Populate Ord Header '	);
	  l_one_pass_only := false;
	   FOR v_ord_hdr in c_ord_hdr loop
   	   	   l_one_pass_only := false;
		   gn_record_number := to_number(v_ord_hdr.party_site_number);
		 FOR v_ord_hdr_details in c_ord_hdr_details (v_ord_hdr.party_site_number) LOOP
	   	   --gc_record_identifier := '1'||gc_record_identifier;
		   IF NOT l_one_pass_only THEN
			   --gn_record_number := to_number(v_ord_hdr_details.party_site_number);
	           gc_record_identifier := v_ord_hdr_details.customer_po_number||' TM Order Number / Bsa No '||v_ord_hdr_details.hdr_bsa_no;--v_ord_hdr_details.customer_number||' Cust No / Bsa No '||v_ord_hdr_details.hdr_bsa_no;
			   dbms_output.put_line('----record id'||v_ord_hdr_details.party_site_number||gc_record_identifier);
		   l_ord_header_rec             := oe_order_pub.g_miss_header_rec;
		   l_ord_header_rec.blanket_number  :=v_ord_hdr_details.hdr_bsa_no ;
		   --l_ord_header_rec.salesrep_id := v_ord_hdr_details.salesrep_id;
		   l_ord_header_rec.order_source_id := v_ord_hdr_details.order_source_id;
		   l_ord_header_rec.order_type_id :=   v_ord_hdr_details.order_type_id;
		   l_ord_header_rec.price_list_id :=   v_ord_hdr_details.hdr_price_list_id;
		   l_ord_header_rec.cust_po_number :=   v_ord_hdr_details.customer_po_number;
		   l_ord_header_rec.blanket_number :=   v_ord_hdr_details.hdr_bsa_no;
		   l_ord_header_rec.transactional_curr_code := 'USD' ;
		   l_ord_header_rec.flow_status_code := 'ENTERED' ;
		   l_ord_header_rec.sold_to_org_id :=  v_ord_hdr_details.sold_to_org_id;
		   l_ord_header_rec.operation        		:= OE_GLOBALS.G_OPR_CREATE;
           --l_ord_header_rec.lock_control    := 5;
		   l_ord_header_rec.Fulfillment_Set_Name          := Null;
		   l_ord_header_rec.Line_Set_Name          := Null;
/*	populate_order_lines
		  					 	(l_line_tbl
								 ,v_ord_hdr_details.party_site_number
								-- ,v_ord_hdr_details.sold_to_org_id
								-- ,v_ord_hdr_details.hdr_bsa_no
								);*/
gc_record_identifier := 	v_ord_hdr.party_site_number||'Call OM API'||gc_record_identifier;
								/* CALL_OM_API
	 		   				   	 ( l_ord_header_rec
		                          ,l_line_tbl
								  );	*/
---------------------------------------------------------------

----------------------------------------------------------------
			   l_one_pass_only := true;
			   END IF;
			   END LOOP;
		 --gc_record_identifier := to_char(l_cnt)||gn_record_number;
		         populate_order_lines
		  					 	(l_line_tbl
								 ,v_ord_hdr.party_site_number
								-- ,v_ord_hdr_details.sold_to_org_id
								-- ,v_ord_hdr_details.hdr_bsa_no
								);
				  CALL_OM_API
	 		   				   	 ( l_ord_header_rec
		                          ,l_line_tbl
								  );

		   l_cnt := l_cnt + 1;
END LOOP;
	Exception
	When Others then
	    populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others populate ord hdr',gn_record_number,gc_record_identifier);
	END populate_order_header;
-----------------------------------------------------------------------------
----CONVERT BOM
-----------------------------------------------------------------------------
PROCEDURE convert_so (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_batch_number  in  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
		,p_commit      in   varchar2
        ) IS
	l_error_message_list       Error_handler.error_tbl_type;
	l_chk_eror					BOOLEAN;
	conc_request boolean;
BEGIN
     dbms_output.put_line('convert_so');
	 gc_error_logged := 'N';
   xxha_3rdparty_tm_file_pkg.process_web_adi_trace_file(p_batch_number);
	 validate_ord_data;
	 commit;
	 populate_order_header;
     IF p_commit = 'Y' then --AND nvl(gc_error_logged,'N') <> 'Y' THEN
dbms_output.put_line('Commit');
	    FOR i IN 1..XX_TM_SO_SUCCESS_STG_TBL.COUNT LOOP
	      IF XX_TM_SO_SUCCESS_STG_TBL(i).party_site_number IS NOT NULL THEN
	        update xxha_tm_so_stg
	        set status = 'PS'
		    where party_site_number = XX_TM_SO_SUCCESS_STG_TBL(i).party_site_number
		    and status <> 'PS';
	      END IF;
	    END LOOP;
		Commit;
	 ELSE
	   Rollback;
	   dbms_output.put_line('Roll');
	   FOR i IN 1..XX_TM_SO_SUCCESS_STG_TBL.COUNT LOOP
	      dbms_output.put_line('VS------');
		  IF XX_TM_SO_SUCCESS_STG_TBL(i).party_site_number IS NOT NULL THEN
	        update xxha_tm_so_stg
	        set status = 'VS'
		    where party_site_number = XX_TM_SO_SUCCESS_STG_TBL(i).party_site_number
		    and status <> 'VS';
	      END IF;
	    END LOOP;

	 END IF;
	 log_all_errors;
	 commit;
IF nvl(gc_error_logged,'N') = 'Y' THEN
	   CONC_REQUEST := fnd_concurrent.set_completion_status('WARNING',substrb((fnd_message.get_string('OM','EXCEPTION_OCCURED_CHK_COMMON_ERROR_TBL')),1,240));
	   xxha_common_utilities_pkg.launch_error_report_prc(gn_request_id,'Process 3rd Party SO','Party Site Id');
	 END IF;
Exception
When Others Then
  populate_common_error(substr(sqlerrm,1,2000),'When Others' ,'When Others Convert SO',gn_record_number,gc_record_identifier);
  Rollback;
  log_all_errors;
  commit;
END Convert_SO;
END XXHA_TM_ORDER_PKG;  -- package body
/
