CREATE OR REPLACE package      XXHA_PM_UPDATE_SR 
as
-- +=====================================================================================+
-- | Name        : XXHA_PM_UPDATE_SR                                                     |
-- | Purpose     : Support the Preventive Maintenance Scheduler.                         |
-- |                                                                                     |
-- | Description : This will be a scheduled concurrent program executed to update        |
-- |               attributes of only service requests created automatically by the      |
-- |               PM Scheduler and since the last time this program was ran             |
-- |               successfully.                                                         |
-- |                                                                                     |
-- |                                                                                     |
-- |                                                                                     |
-- | Comment     : This package launches standard APIs from CS_ServiceRequest_PUB.       |
-- |                                                                                     |
-- | History                                                                             |
-- | =======                                                                             |
-- | When      Rev  Who                  What                                            |
-- | --------  ---  --------             ------------------------------------------------|
-- | 20120207  1.0  Vasil S. Valkov      Initial version                                 |
-- +=====================================================================================+

	  
procedure update_pm_service_request
			(
			  x_errbuf out varchar2
			, x_retcode out varchar2
			);

end XXHA_PM_UPDATE_SR;
/


CREATE OR REPLACE package body      XXHA_PM_UPDATE_SR
as
-- +=====================================================================================+
-- | Name        : XXHA_PM_UPDATE_SR                                                     |
-- | Purpose     : Support the Preventive Maintenance Scheduler.                         |
-- |                                                                                     |
-- | Description : This will be a scheduled concurrent program executed to update        |
-- |               attributes of only service requests created automatically by the      |
-- |               PM Scheduler and since the last time this program was ran             |
-- |               successfully.                                                         |
-- |                                                                                     |
-- |                                                                                     |
-- |                                                                                     |
-- | Comment     : This package launches standard APIs from CS_ServiceRequest_PUB.       |
-- |                                                                                     |
-- | History                                                                             |
-- | =======                                                                             |
-- | When      Rev  Who                  What                                            |
-- | --------  ---  --------             ------------------------------------------------|
-- | 20120207  1.0  Vasil S. Valkov      Initial version                                 |
-- | 20120531  1.1  Vasil S. Valkov      Added new code to retrieve translated strings   |
-- |                                     for problem summary and note from Profile       |
-- |                                     Options - 'HAE: CS PM Problem Summary' and      |
-- |                                     'HAE: CS PM Problem Description'.               |
-- |                                      Also, added logic for populating Incident      |
-- |                                      Occurred Date.
-- +=====================================================================================+
procedure update_pm_service_request (
			  x_errbuf out varchar2
			, x_retcode out varchar2 )
is
	l_service_request_rec_type CS_ServiceRequest_PUB.service_request_rec_type;

	l_last_date varchar2(25);

	l_problem_summary varchar2(240);
	l_p_summary_string varchar2(240); -- the string for problem summary coming from the Profile Option "HAE: CS PM Problem Summary"
	l_note varchar2(240);
	l_note_string varchar2(240); -- the string for note coming from the Profile Option "HAE: CS PM Problem Description"
	l_problem_code varchar2(50);
	l_incident_type varchar2(30);
	l_incident_group varchar2(60);
	l_incident_owner varchar(360);
	l_incident_country_code varchar2(60);
	l_creation_date date;
	l_incident_date date;
	l_item_number varchar2(40);
	l_task_subject varchar2(80); -- task_name
	l_task_context varchar2(150); -- attribute_category
	l_task_status varchar2(30); -- task_status
	l_task_object_ver_num number; -- task object_version_number
	l_operating_unit_id number;
	l_stat boolean;
	l_country_code varchar2(60);
	l_item varchar2(40);
	l_return_status VARCHAR2(1);
	l_msg_count NUMBER;
	l_msg_data VARCHAR2(1000);
	l_msg_index_out NUMBER;
	l_service_request_rec cs_servicerequest_pub.service_request_rec_type;
	l_sr_update_out_rec cs_servicerequest_pub.sr_update_out_rec_type;
	l_notes_table cs_servicerequest_pub.notes_table;
	l_contacts_tab cs_servicerequest_pub.contacts_table;
	l_request_id NUMBER;
	l_incident_object_ver_num number; -- incident object_version_number
	l_incident_country varchar2(60);
	l_temp varchar2(40);
	ln_line_index number := 0;
   -- Cursor to get the new pm calls created
/*	CURSOR l_pm_service_calls
	IS
	SELECT al1.*
	FROM haemo.xxha_pm_field_service_data al1,
		(select d1al1.debrief_header_id
		 from apps.csf_debrief_lines d1al1, apps.cs_txn_billing_types d1al2
		 where d1al1.transaction_type_id = d1al2.transaction_type_id and d1al2.billing_type <>'M') al2
	WHERE al1.debrief_header_id = al2.debrief_header_id(+)
	AND operating_unit_id = l_operating_unit_id
	AND TRUNC(creation_date) BETWEEN TRUNC(NVL(TO_DATE(l_last_date), TRUNC(sysdate))) AND TRUNC(sysdate)
--	and incident_number = '586532'
	;
*/
-- Cursor to get the new pm calls created
	CURSOR l_pm_service_calls
	is
	SELECT cs.incident_id,
		   cs.incident_number,
		   hou.organization_id operating_unit_id,
		   hou.name operating_unit,
		   cii.instance_number,
		   cii.serial_number,
		   cs.contract_number,
		   cst.task_id,
		   cst.planned_start_date,
		   msi.segment1 item_number
	FROM cs_incident_links link,
		 cs_incidents_all_vl cs,
		 hr_operating_units hou,
		 csi_item_instances cii,
		 mtl_system_items_b msi,
		 cs_sr_tasks_v cst
	WHERE link.subject_id = cs.incident_id
	and cs.org_id = hou.organization_id
	and cs.CUSTOMER_PRODUCT_ID = cii.INSTANCE_ID(+)
	and cs.INVENTORY_ITEM_ID = msi.INVENTORY_ITEM_ID(+)
	and cs.INV_ORGANIZATION_ID = msi.ORGANIZATION_ID(+)
	and cs.INCIDENT_ID = cst.SOURCE_OBJECT_ID(+)
	and cs.INCIDENT_NUMBER = cst.SOURCE_OBJECT_NAME(+)
	and link.subject_type = 'SR'
	and link.link_type_id = 6
	and link.object_type = 'AHL_UMP_EFF'
	and hou.organization_id = l_operating_unit_id
--	AND TRUNC(cs.creation_date) BETWEEN TRUNC(NVL(TO_DATE(l_last_date), TRUNC(sysdate))) AND TRUNC(sysdate)
	and cs.creation_date > NVL(TO_DATE(l_last_date, 'DD-MON-YYYY HH24:MI:SS'), sysdate) and cs.creation_date <= sysdate
--	and cs.incident_number = '772981'
	;
cursor l_country_set( p_country_code varchar2 )
	is
	SELECT ffvl.flex_value
	FROM apps.fnd_flex_value_sets ffvs,
		 apps.fnd_flex_values_vl ffvl
	WHERE ffvs.flex_value_set_name = 'XXHA_CS_PM_DEPOT_COUNTRY_LIST'
	AND ffvl.flex_value_set_id = ffvs.flex_value_set_id
	and trunc(sysdate) between trunc( nvl( ffvl.start_date_active, sysdate ) ) and trunc( nvl( ffvl.start_date_active, sysdate ) )
	AND NVL( ffvl.enabled_flag, 'N' ) = 'Y'
	and ffvl.flex_value = p_country_code;

	cursor l_item_set( p_item_number varchar2 )
	is
	SELECT ffvl.flex_value
	FROM apps.fnd_flex_value_sets ffvs,
		 apps.fnd_flex_values_vl ffvl
	WHERE ffvs.flex_value_set_name = 'XXHA_CS_PM_DEPOT_ITEM_NUMBERS'
	AND ffvl.flex_value_set_id = ffvs.flex_value_set_id
	and trunc(sysdate) between trunc( nvl( ffvl.start_date_active, sysdate ) ) and trunc( nvl( ffvl.start_date_active, sysdate ) )
	AND NVL( ffvl.enabled_flag, 'N' ) = 'Y'
	and ffvl.flex_value = p_item_number;
BEGIN
l_last_date := fnd_profile.value( 'XXHA_CS_PM_UPDATE_START_DATE' );
	FND_FILE.PUT_LINE(FND_FILE.LOG, 'Start Date is: ' || l_last_date);
	if l_last_date is null then
l_last_date := fnd_profile.value( 'XXHA_CS_PM_GO_LIVE_DATE' );
		FND_FILE.PUT_LINE(FND_FILE.LOG, 'No Start Date. Go live date: ' || l_last_date);
end if;
-- l_operating_unit_id := fnd_profile.value( 'ORG_ID' ); Commented for R12
   l_operating_unit_id := MO_GLOBAL.get_current_org_id; -- Added  for R12
	dbms_output.put_line( 'Operating Unit Id: ' || l_operating_unit_id );
	FND_FILE.PUT_LINE(FND_FILE.LOG, 'Operating Unit Id: ' || l_operating_unit_id);
	-- Process the records
	FOR l_pm_sr_rec IN l_pm_service_calls LOOP
	l_task_object_ver_num := null;
		l_task_status := null;
		l_problem_summary := null;
		l_p_summary_string := null;
		l_note := null;
		l_note_string := null;
		l_problem_code := null;
		l_task_subject := null;
		l_task_context := null;
		l_country_code := null;
		l_item := null;
		l_incident_type := null;
		l_incident_group := null;
		l_incident_owner := null;
		l_return_status := null;
		l_msg_count := null;
		l_msg_data := null;
		l_request_id := null;
		l_incident_object_ver_num := null;
		l_incident_country := null;
		l_creation_date := null;
		l_incident_date := null;
		l_temp := null;
		begin
		select task_status_id, object_version_number
				into l_task_status, l_task_object_ver_num
			from apps.jtf_tasks_vl
			where source_object_type_code = 'SR'
			and source_object_id = l_pm_sr_rec.incident_id;
	select cs.incident_type_id, cs.owner_group_id, cs.incident_owner_id, cs.object_version_number, decode( cs.incident_location_type, 'HZ_LOCATION', hl1.country, 'HZ_PARTY_SITE', hl2.country, 'INTERNAL_SITE', hrl.country, 'INVENTORY', hrl.country, 'VENDOR_SITE', pvs.country, null ), cs.creation_date, cs.incident_date
				into l_incident_type, l_incident_group, l_incident_owner, l_incident_object_ver_num, l_incident_country, l_creation_date, l_incident_date
			from cs_incidents_all_vl cs,
				 hz_locations hl1,
				 hz_party_sites hps,
				 hz_locations hl2,
				 hr_locations_all hrl,
				 ---po_vendor_sites_all pvs---11i code modified
         ap_supplier_sites_all pvs ---R12 Remediated
			where incident_id = l_pm_sr_rec.incident_id
			and cs.incident_location_id = hl1.location_id(+)
			and cs.incident_location_id = hps.party_site_id(+)
			and hps.location_id = hl2.location_id(+)
			and cs.incident_location_id = hrl.location_id(+)
			and cs.incident_location_id = pvs.vendor_site_id(+)
			;
		exception
		when others then
			null;
		end;
	dbms_output.put_line( 'Incident: ' || l_pm_sr_rec.incident_number );
	l_p_summary_string := fnd_profile.value( 'XXHA_CS_PM_PROBLEM_SUMMARY' );
-- VV: added for ver. 1.1 20120531
--		l_problem_summary := 'Serial ' || l_pm_sr_rec.serial_number || ' PM Due on ' || to_char( l_pm_sr_rec.planned_start_date, 'DD-MON-YYYY' );
		l_p_summary_string := replace( l_p_summary_string, 'XXXXX', l_pm_sr_rec.serial_number );
		l_problem_summary := replace( l_p_summary_string, 'VVVVV', to_char( l_pm_sr_rec.planned_start_date, 'DD-MON-YYYY' ) );
l_note_string := fnd_profile.value( 'XXHA_CS_PM_PROBLEM_DESCRIPTION' );
		l_note := replace( l_note_string, 'XXXXX', l_pm_sr_rec.serial_number );
	l_problem_code := fnd_profile.value( 'XXHA_CS_SR_PM_PROBLEM_CODE' );
	l_task_subject := l_problem_summary;
	l_task_context := 'None';
	l_temp := 'no status chagne';
	-- Check if Incident_Country_Code is in the country value set.
		OPEN l_country_set( l_incident_country );
			FETCH l_country_set
				INTO l_country_code;
					IF l_country_set%NOTFOUND THEN
						l_country_code := l_incident_country;
					ELSE
						open l_item_set( l_pm_sr_rec.item_number );
							fetch l_item_set
								into l_item;
									if l_item_set%NOTFOUND then
										l_item := l_pm_sr_rec.item_number;
									else
					l_task_status := fnd_profile.value( 'XXHA_CS_SR_PM_TASK_CANCELLATION_STATUS' );

					l_incident_type := fnd_profile.value( 'XXHA_CS_SR_PM_DEPOT_INCIDENT_TYPE' );
					l_incident_group := fnd_profile.value( 'XXHA_CS_PM_SR_OWNER_GROUP' );
					l_incident_owner := fnd_profile.value( 'XXHA_CS_PM_SR_OWNER' );
					l_temp := 'incident status changed';
					end if;
					close l_item_set;
					END IF;
		CLOSE l_country_set;
		-- update a task through the public API
		begin
		jtf_tasks_pub.update_task(
				p_api_version => 1.0 ,
				p_init_msg_list => fnd_api.g_true,
				p_commit => fnd_api.g_false,
				p_object_version_number => l_task_object_ver_num,
				p_task_id => l_pm_sr_rec.task_id,
				p_task_name => l_task_subject,
				p_task_status_id => l_task_status,
				p_attribute_category => l_task_context,
				x_return_status => l_return_status,
				x_msg_count => l_msg_count,
				x_msg_data => l_msg_data
			);
IF l_return_status <> fnd_api.g_ret_sts_success THEN
				IF l_msg_count > 0 THEN
					l_msg_data := NULL;
					FOR i IN 1..l_msg_count LOOP
						l_msg_data := l_msg_data || ' ' || fnd_msg_pub.get(1, 'F');
					END LOOP;
					fnd_message.set_encoded(l_msg_data);
					FND_FILE.PUT_LINE( FND_FILE.LOG, substr( l_msg_data, 1.1, 200 ) );
				END IF;
				ROLLBACK;
			ELSE
				COMMIT;
			end if;
		EXCEPTION
		WHEN OTHERS THEN
			FND_FILE.PUT_LINE( FND_FILE.LOG, 'Error: ' || SQLERRM );
		end;
	 -- update a SR through the public API.
		begin
		-- Set Line Index to 1
			ln_line_index := 1;
			l_return_status := null;
			l_msg_count := null;
			l_msg_data := null;
cs_servicerequest_pub.initialize_rec( l_service_request_rec );
l_request_id := l_pm_sr_rec.incident_id;
l_service_request_rec.type_id := l_incident_type;
			l_service_request_rec.problem_code := l_problem_code;
			l_service_request_rec.summary := l_problem_summary;
			l_service_request_rec.owner_group_id := l_incident_group;
			l_service_request_rec.owner_id := l_incident_owner;
			l_service_request_rec.group_type := 'RS_GROUP';
			l_service_request_rec.request_context := 'N';
-- VV: added for ver. 1.1 20120531
			if( l_creation_date >= l_incident_date ) then
				l_service_request_rec.incident_occurred_date := l_incident_date;
			else
				l_service_request_rec.incident_occurred_date := l_creation_date;
			end if;
			l_notes_table( ln_line_index ).note := l_note;
			l_notes_table( ln_line_index ).note_type := 'CS_PROBLEM';
	  cs_servicerequest_pub.update_servicerequest (
				p_api_version => 4.0,
				p_init_msg_list => FND_API.G_TRUE,
				p_commit => FND_API.G_TRUE,
				x_return_status => l_return_status,
				x_msg_count => l_msg_count,
				x_msg_data => l_msg_data,
				p_request_id => l_request_id,
				p_object_version_number => l_incident_object_ver_num,
				p_last_updated_by => NULL,
				p_last_update_date => sysdate,
				p_service_request_rec => l_service_request_rec,
				p_notes => l_notes_table,
				p_contacts => l_contacts_tab,
				x_sr_update_out_rec => l_sr_update_out_rec
			);
  IF (l_return_status <> FND_API.G_RET_STS_SUCCESS) THEN
				IF (FND_MSG_PUB.Count_Msg > 1) THEN
					--Display all the error messages
					FOR j IN 1..FND_MSG_PUB.Count_Msg LOOP
						FND_MSG_PUB.Get( p_msg_index => j, p_encoded => 'F', p_data => l_msg_data, p_msg_index_out => l_msg_index_out);
						FND_FILE.PUT_LINE( FND_FILE.LOG, substr( l_msg_data, 1.1, 200 ) );
					END LOOP;
				else --Only one error
					FND_MSG_PUB.Get(p_msg_index => 1, p_encoded => 'F', p_data => l_msg_data, p_msg_index_out => l_msg_index_out);
					FND_FILE.PUT_LINE( FND_FILE.LOG, substr( l_msg_data, 1.1, 200 ) );
				end if;
			END IF;
		exception
		when others then
			FND_FILE.PUT_LINE( FND_FILE.LOG, 'Error: ' || SQLERRM );
		end;
FND_FILE.PUT_LINE( FND_FILE.LOG, 'SR #: ' || l_pm_sr_rec.incident_number );
		FND_FILE.PUT_LINE( FND_FILE.LOG, 'Contract #: ' || l_pm_sr_rec.contract_number );
		FND_FILE.PUT_LINE( FND_FILE.LOG, 'Instance #: ' || l_pm_sr_rec.instance_number );
		FND_FILE.PUT_LINE( FND_FILE.LOG, 'Item #: ' || l_item );
		FND_FILE.PUT_LINE( FND_FILE.LOG, 'Serial #: ' || l_pm_sr_rec.serial_number );
		FND_FILE.PUT_LINE( FND_FILE.LOG, 'Country: ' || l_country_code );
		FND_FILE.PUT_LINE( FND_FILE.LOG, l_temp );
		FND_FILE.PUT_LINE( FND_FILE.LOG, '----------------------------------------------' );
END LOOP; -- End of main loop

--	l_stat := fnd_profile.save( 'XXHA_CS_PM_UPDATE_START_DATE', to_char( trunc(sysdate), 'dd-MON-yyyy' ), 'SITE' );
	l_stat := fnd_profile.save( 'XXHA_CS_PM_UPDATE_START_DATE', to_char( sysdate, 'DD-MON-YYYY HH24:MI:SS' ), 'RESP', fnd_global.resp_id );
	commit;
if l_stat then
		FND_FILE.PUT_LINE( FND_FILE.LOG, 'Date SAVED.' );
	else
		FND_FILE.PUT_LINE( FND_FILE.LOG, 'Date NOT SAVED.' );
	end if;
EXCEPTION
   WHEN OTHERS THEN
        x_retcode := 2 ;
        x_errbuf := 'Error: ' || SQLERRM;
		FND_FILE.PUT_LINE( FND_FILE.LOG, x_errbuf );
END update_pm_service_request;
END XXHA_PM_UPDATE_SR;
/
