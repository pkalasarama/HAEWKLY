create or replace PACKAGE BODY XXHA_BSWIFT_PKG AS

/**********************************************************************************************************************************
 *
 * Package Name : XXHA_BSWIFT_PKG
 * Description:  This function will determine the most recent change date for Benefit Class Date, Time Status Effective Date,
 *                  Location Effective Date and Custom Employment Field Effective Date.
 *               It is used by the view, 'APPS.XXHA_BSWIFT_V'.
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 * -------------   -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      14-JUN-2017     Initial Object Creation
 * BMarcoux        2.0      21-AUG-2017     Added function for replacing special characters in names (REPLACE_SPECIAL_CHAR and ASCII_CHAR)
 *                                          Added function for determining actual Hire Date (HIRE_DATE)
 *                                          Added function for determining actual LOA Dates (LOA_DATES) and LOA_Status
 * BMarcoux        3.0      14-NOV-2017     Added function for Rehires (REHIRE)
 *                                          Added function for determining Contingent Worker Conversions (CONTINGENT_WORKER)
 *                                          Added function for determining Employee Acquisitions (ACQUISITIONS)
 *
 **********************************************************************************************************************************/

--------------------------------------------------------------------------------
-- FUNCTION BENEFIT_CLASS_DATE

FUNCTION BENEFIT_CLASS_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE IS

l_effective_start_date            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_date                            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_First_Time                      VARCHAR2(01)                                      := NULL;
l_Keyx                            VARCHAR2(250)                                     := NULL;

-- Retrieve Record
CURSOR cur_1(c_PERSON_ID NUMBER, c_DATE IN DATE)
IS
SELECT
    NVL(g.attribute3,0)         ClassCode
--, NVL(paa.normal_hours,40)    NormalHours
  , loc.LOCATION_CODE           LocCode
  , PAA.effective_start_date
FROM
    per_all_assignments_f       PAA
 ,  hr_locations                loc
 ,  per_grades                  g
WHERE
    PAA.person_id                    = c_PERSON_ID
AND PAA.grade_id                     = g.grade_id(+)
AND PAA.Location_Id                  = Loc.Location_Id(+)
AND TRUNC(PAA.effective_start_date) <= TRUNC(c_DATE)
ORDER BY
    PAA.effective_start_date DESC
;

BEGIN

   l_effective_start_date    := NULL;
   l_date                    := NULL;
   l_Keyx                    := NULL;
   l_First_Time              := 'N';

   -- Cursor to retrieve Data
   FOR dta1 IN cur_1(P_PERSON_ID, P_DATE) LOOP
      -- Setup Break Processing
      IF l_First_Time = 'N' THEN
         l_First_Time            := 'Y';
         l_Keyx                  := (dta1.ClassCode || '_' || dta1.LocCode);
--         l_Keyx                  := (dta1.ClassCode || '_' || dta1.NormalHours || '_' || dta1.LocCode);
         l_effective_start_date  := dta1.effective_start_date;
      END IF;

      -- If we hit a break, then take previous start date (as this is when the new change started) AND exit loop
      IF (dta1.ClassCode || '_' || dta1.LocCode) <> l_Keyx THEN
--      IF (dta1.ClassCode || '_' || dta1.NormalHours || '_' || dta1.LocCode) <> l_Keyx THEN
         l_date                  := l_effective_start_date;
         EXIT;
      ELSE
         l_Keyx                  := (dta1.ClassCode || '_' || dta1.LocCode);
--         l_Keyx                  := (dta1.ClassCode || '_' || dta1.NormalHours || '_' || dta1.LocCode);
         l_effective_start_date  := dta1.effective_start_date;
         l_date                  := dta1.effective_start_date;
      END IF;
   END LOOP;

   RETURN l_date;

END BENEFIT_CLASS_DATE;

--------------------------------------------------------------------------------
-- FUNCTION TIME_STATUS_EFFECTIVE_DATE

FUNCTION TIME_STATUS_EFFECTIVE_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE IS

l_employment_category             per_all_assignments_f.employment_category%TYPE    := NULL;
l_effective_start_date            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_date                            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_First_Time                      VARCHAR2(01)                                      := NULL;

-- Retrieve Record
CURSOR cur_1(c_PERSON_ID NUMBER, c_DATE IN DATE)
IS
SELECT
    NVL(PAA.employment_category,'XXXX')  Employment_Category                    -- Time Status Effective Date
  , PAA.effective_start_date
FROM
    per_all_assignments_f                PAA
WHERE
    PAA.person_id                      = c_PERSON_ID
AND TRUNC(PAA.effective_start_date)   <= TRUNC(c_DATE)
ORDER BY
    PAA.effective_start_date DESC
;

BEGIN

   l_employment_category     := NULL;
   l_effective_start_date    := NULL;
   l_date                    := NULL;
   l_First_Time              := 'N';

   -- Cursor to retrieve Data
   FOR dta1 IN cur_1(P_PERSON_ID, P_DATE) LOOP
      -- Setup Break Processing
      IF l_First_Time = 'N' THEN
         l_First_Time              := 'Y';
         l_employment_category     := dta1.employment_category;
         l_effective_start_date    := dta1.effective_start_date;
      END IF;

      -- If we hit a break, then take previous start date (as this is when the new change started) AND exit loop
      IF dta1.employment_category <> l_employment_category THEN
         l_date                    := l_effective_start_date;
         EXIT;
      ELSE
         l_employment_category     := dta1.employment_category;
         l_effective_start_date    := dta1.effective_start_date;
      END IF;
   END LOOP;

   RETURN l_date;

END TIME_STATUS_EFFECTIVE_DATE;

--------------------------------------------------------------------------------
-- FUNCTION LOCATION_EFFECTIVE_DATE

FUNCTION LOCATION_EFFECTIVE_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE IS

l_Location_Id                     per_all_assignments_f.Location_Id%TYPE            := NULL;
l_effective_start_date            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_date                            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_First_Time                      VARCHAR2(01)                                      := NULL;

-- Retrieve Record
CURSOR cur_1(c_PERSON_ID NUMBER, c_DATE IN DATE)
IS
SELECT
    NVL(PAA.Location_Id,-99999)        Location_ID                              -- Location Effective Date
  , PAA.effective_start_date
FROM
    per_all_assignments_f PAA
WHERE
    PAA.person_id                    = c_PERSON_ID
AND TRUNC(PAA.effective_start_date) <= TRUNC(c_DATE)
ORDER BY
    PAA.effective_start_date DESC
;

BEGIN

   l_Location_Id             := NULL;
   l_effective_start_date    := NULL;
   l_date                    := NULL;
   l_First_Time              := 'N';

   -- Cursor to retrieve Data
   FOR dta1 IN cur_1(P_PERSON_ID, P_DATE) LOOP
      -- Setup Break Processing
      IF l_First_Time = 'N' THEN
         l_First_Time              := 'Y';
         l_Location_Id             := dta1.Location_Id;
         l_effective_start_date    := dta1.effective_start_date;
      END IF;

      -- If we hit a break, then take previous start date (as this is when the new change started) AND exit loop
      IF dta1.Location_Id <> l_Location_Id THEN
         l_date                    := l_effective_start_date;
         EXIT;
      ELSE
         l_Location_Id             := dta1.Location_Id;
         l_effective_start_date    := dta1.effective_start_date;
      END IF;
   END LOOP;

   RETURN l_date;

END LOCATION_EFFECTIVE_DATE;

--------------------------------------------------------------------------------
-- FUNCTION CUSTOM_EMPLOY_FIELD_EFF_DATE

FUNCTION CUSTOM_EMPLOY_FIELD_EFF_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE IS

l_Soft_Coding_Keyflex_Id          per_all_assignments_f.Soft_Coding_Keyflex_Id%TYPE := NULL;
l_effective_start_date            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_date                            per_all_assignments_f.effective_start_date%TYPE   := NULL;
l_First_Time                      VARCHAR2(01)                                      := NULL;

-- Retrieve Record
CURSOR cur_1(c_PERSON_ID NUMBER, c_DATE IN DATE)
IS
SELECT
    NVL(PAA.Soft_Coding_Keyflex_Id,-99999)  Soft_Coding_Keyflex_Id   -- Custom Employment Field Effective Date
  , PAA.effective_start_date
FROM
    per_all_assignments_f       PAA
WHERE
    PAA.person_id                    = c_PERSON_ID
AND TRUNC(PAA.effective_start_date) <= TRUNC(c_DATE)
ORDER BY
    PAA.effective_start_date DESC
;

BEGIN

   l_Soft_Coding_Keyflex_Id  := NULL;
   l_effective_start_date    := NULL;
   l_date                    := NULL;
   l_First_Time              := 'N';

   -- Cursor to retrieve Data
   FOR dta1 IN cur_1(P_PERSON_ID, P_DATE) LOOP
      -- Setup Break Processing
      IF l_First_Time = 'N' THEN
         l_First_Time              := 'Y';
         l_Soft_Coding_Keyflex_Id  := dta1.Soft_Coding_Keyflex_Id;
         l_effective_start_date    := dta1.effective_start_date;
      END IF;

      -- If we hit a break, then take previous start date (as this is when the new change started) AND exit loop
      IF dta1.Soft_Coding_Keyflex_Id <> l_Soft_Coding_Keyflex_Id THEN
         l_date                    := l_effective_start_date;
         EXIT;
      ELSE
         l_Soft_Coding_Keyflex_Id  := dta1.Soft_Coding_Keyflex_Id;
         l_effective_start_date    := dta1.effective_start_date;
      END IF;
   END LOOP;

   RETURN l_date;

END CUSTOM_EMPLOY_FIELD_EFF_DATE;

--------------------------------------------------------------------------------
-- FUNCTION FORMAT_PHONE_NUMBER

FUNCTION FORMAT_PHONE_NUMBER(P_PHONE IN VARCHAR2) RETURN VARCHAR2 IS

l_text                            VARCHAR2(250)                                 := NULL;
l_char                            VARCHAR2(03)                                  := NULL;
i                                 INTEGER                                       := 0;

BEGIN

    -- Set variable to input text
    l_text := P_PHONE;

    -- Remove unneccesary characters (Spaces, hyphens, parathesis, periods, etc.)
    l_text := REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(l_text,'(0)',''),'+1',''),'+44',''),'+41',''),'(',''),')',''),'.',''),'-',''),'/',''),' ','');

    -- If first character is a 1 then remove it, but only if length of the value is greater than 10
    IF length(l_text) > 10 THEN 
       IF SUBSTR(l_text, 1, 1) = '1' THEN
          l_text := SUBSTR(l_text, 2, length(l_text));
       END If;
    END If;

    -- Only return the first 10 characters
    RETURN SUBSTR(l_text,1,10);

END FORMAT_PHONE_NUMBER;

--------------------------------------------------------------------------------
-- FUNCTION DECODE_LOOKUP

FUNCTION DECODE_LOOKUP(P_LOOKUP_TYPE VARCHAR2, P_LOOKUP_CODE VARCHAR2) RETURN VARCHAR2 IS

l_reason                          FND_LOOKUP_VALUES_VL.ATTRIBUTE2%TYPE          := NULL;

-- Retrieve Record
CURSOR cur_1(c_LOOKUP_TYPE VARCHAR2, c_LOOKUP_CODE VARCHAR2)
IS
SELECT
    ATTRIBUTE2
FROM
    FND_LOOKUP_VALUES_VL
WHERE 
    lookup_type = c_lookup_type
AND lookup_code = c_lookup_code;

BEGIN

   -- Only open the cursor if the parameters are going to retrieve anything
   IF p_lookup_type IS NOT NULL AND p_lookup_code IS NOT NULL THEN
      OPEN cur_1(P_LOOKUP_TYPE,P_LOOKUP_CODE);
      FETCH cur_1 INTO l_reason;
      CLOSE cur_1;
   END IF;

   RETURN l_reason;

END DECODE_LOOKUP;

--------------------------------------------------------------------------------
-- FUNCTION REPLACE_SPECIAL_CHAR

FUNCTION REPLACE_SPECIAL_CHAR(P_TEXT VARCHAR2) RETURN VARCHAR2 IS

l_text                            VARCHAR2 (250)                                := NULL;
l_char                            VARCHAR2 (3 byte)                             := NULL;
i                                 INTEGER                                       := 0;

BEGIN

    -- Set variable to input text
    l_text := p_text;

    -- Replace special characters (regular characters are ASCII BETWEEN 48 AND 122 AND space is ASCII 32)
    IF LENGTH(l_text) > 0 THEN
       FOR i IN 1..LENGTH(l_text) 
       LOOP
           l_char := SUBSTR((l_text),i,1);
           IF (ASCII (l_char) NOT BETWEEN 48 AND 122) AND (ASCII (l_char) != 32) THEN
              l_text := REPLACE(l_text, l_char, XXHA_BSWIFT_PKG.ASCII_CHAR(l_char));
           END IF;
       END LOOP;
    END IF;

    RETURN l_text;

END REPLACE_SPECIAL_CHAR;

--------------------------------------------------------------------------------
-- FUNCTION ASCII_CHAR

FUNCTION ASCII_CHAR(P_TEXT VARCHAR2) RETURN VARCHAR2 IS
 
l_char                            VARCHAR2 (3 byte)                             := NULL;

BEGIN

  SELECT
         DESCRIPTION
    INTO 
         l_char
    FROM
         APPS.FND_LOOKUP_VALUES_VL flv
   WHERE 
         flv.lookup_type = 'XXHA_FIDELITY_SPECIAL_CHR_XREF'
     AND flv.Meaning   = P_TEXT
     AND NVL(flv.enabled_flag,'N') = 'Y'
     AND TRUNC(SYSDATE) BETWEEN TRUNC(flv.Start_date_active) AND NVL(TRUNC(flv.end_date_active), TRUNC(SYSDATE));

    RETURN l_char;

EXCEPTION
    WHEN OTHERS THEN
         l_char := NULL;
         RETURN l_char;

END ASCII_CHAR;

--------------------------------------------------------------------------------
-- FUNCTION HIRE_DATE

FUNCTION HIRE_DATE(P_PERSON_ID IN NUMBER) RETURN DATE IS

l_person_id                       per_all_people_f.person_id%TYPE               := NULL;
l_person_type_id                  per_all_people_f.person_type_id%TYPE          := NULL;
l_latest_hire_date                per_all_people_f.effective_start_date%TYPE    := NULL;
l_original_hire_date              per_all_people_f.effective_start_date%TYPE    := NULL;
l_person_type                     NVARCHAR2(250)                                := NULL;

BEGIN

   SELECT 
     person_id
   , person_type_id
   , user_person_type                                                           -- PERSON_TYPE
   , MAX(date_start)                                                            -- LATEST_HIRE_DATE
   , MIN(date_start)                                                            -- ORIGINAL_HIRE_DATE
   INTO
     l_person_id 
   , l_person_type_id
   , l_person_type
   , l_latest_hire_date
   , l_original_hire_date
   FROM
      (SELECT 
              person_id
            , pptu.person_type_id
            , ppos.date_start
            , ppt.user_person_type
         FROM 
              apps.per_all_people_f p JOIN apps.per_periods_of_service ppos USING (person_id)
              JOIN per_person_type_usages_f pptu USING (person_id)
              JOIN per_person_types ppt ON ppt.person_type_id = pptu.person_type_id
        WHERE 
              date_start BETWEEN p.effective_start_date    AND p.effective_end_date
          AND date_start BETWEEN pptu.effective_start_date AND pptu.effective_end_date
          --AND p.person_type_id = ppt.person_type_id
          AND person_id = P_PERSON_ID)
   WHERE user_person_type = 'Employee'
   GROUP BY 
     person_id
   , person_type_id
   , user_person_type;

   RETURN l_original_hire_date;

EXCEPTION
    WHEN OTHERS THEN
         l_original_hire_date := NULL;
         RETURN l_original_hire_date;

END HIRE_DATE;

--------------------------------------------------------------------------------
-- FUNCTION LOA_DATES

FUNCTION LOA_DATES(P_PERSON_ID IN NUMBER) RETURN VARCHAR2 IS

l_LOA_Start                       per_all_people_f.effective_start_date%TYPE    := NULL;
l_LOA_End                         per_all_people_f.effective_start_date%TYPE    := NULL;
l_LOA_Status                      hr_lookups.lookup_code%TYPE                   := NULL;
l_LOA_Record_Found                NVARCHAR2(01)                                 := NULL;
l_Count                           NUMBER                                        := 0;

CURSOR cur_2
IS
SELECT 
    NVL(COUNT(*),0)
FROM 
    apps.per_all_people_f p JOIN apps.per_all_assignments_f a USING (person_id)
    JOIN apps.per_assignment_status_types pas ON pas.assignment_status_type_id = a.assignment_status_type_id
    JOIN apps.hr_lookups hl ON a.CHANGE_REASON = hl.lookup_code
WHERE
    TRUNC(SYSDATE)                BETWEEN TRUNC(p.effective_start_date) AND TRUNC(p.effective_end_date)
AND hl.meaning                    LIKE 'LOA%'
AND pas.assignment_status_type_id = 55049
AND lookup_type                   = 'EMP_ASSIGN_REASON'
AND current_employee_flag         = 'Y'
AND person_id                     = P_PERSON_ID
;

CURSOR cur_3
IS
SELECT 
    p.full_name
 ,  p.employee_number
 ,  pas.assignment_status_type_id
 ,  hl.meaning                    CHANGE_REASON
 ,  a.effective_start_date        LOA_START
 ,  a.effective_end_date          LOA_END
FROM apps.per_all_people_f p JOIN apps.per_all_assignments_f a USING (person_id)
    JOIN apps.per_assignment_status_types pas on pas.assignment_status_type_id = a.assignment_status_type_id
    JOIN apps.hr_lookups hl on a.CHANGE_REASON = hl.lookup_code
WHERE
    TRUNC(SYSDATE)                BETWEEN TRUNC(p.effective_start_date) AND TRUNC(p.effective_end_date)
AND lookup_type                   = 'EMP_ASSIGN_REASON'
AND current_employee_flag         = 'Y'
AND person_id                     = P_PERSON_ID
ORDER BY
  person_id
, a.effective_start_date desc;

BEGIN

   OPEN cur_2;
   FETCH cur_2 INTO l_Count;
   CLOSE cur_2;

   -- Set l_LOA_Record_Found to 'N'
   l_LOA_Record_Found := 'N';

   -- If employee has LOA Records then read through to retrieve LOA Start AND LOA End Dates
   IF l_Count > 0 THEN
      FOR dta003 IN cur_3
      LOOP
         -- Is this an LOA Record?
         IF (dta003.assignment_status_type_id = 55049) AND (dta003.CHANGE_REASON LIKE 'LOA%') THEN
            -- If we encountered an LOA Record previously then only update l_LOA_Start
            IF l_LOA_Record_Found = 'Y' THEN
               l_LOA_Start            := dta003.LOA_START;
               l_LOA_Status           := dta003.CHANGE_REASON;
            ELSE
            -- If we have not encountered an LOA Record previously then update l_LOA_Start AND l_LOA_End AND set l_LOA_Record_Found
               l_LOA_Record_Found     := 'Y';
               l_LOA_Start            := dta003.LOA_START;
               l_LOA_End              := dta003.LOA_END;
               l_LOA_Status           := dta003.CHANGE_REASON;
            END IF;
         ELSE
             -- If not an LOA Record AND we already encountered an LOA Record previously then exit the processing
            IF l_LOA_Record_Found = 'Y' THEN 
               EXIT;
            END IF;
         END IF;
      END LOOP;
   END IF;

   IF l_LOA_Start IS NOT NULL THEN
      RETURN (TO_CHAR(l_LOA_Start, 'MM/DD/YYYY') || '|' || TO_CHAR(l_LOA_End, 'MM/DD/YYYY') || '|' || l_LOA_Status);
   ELSE
      RETURN NULL;
   END IF;

EXCEPTION
    WHEN OTHERS THEN
         RETURN NULL;

END LOA_DATES;

--------------------------------------------------------------------------------
-- FUNCTION ACQUISITIONS

FUNCTION ACQUISITIONS(P_PERSON_ID IN NUMBER) RETURN VARCHAR2 IS

l_Record_Found                    NVARCHAR2(01)                                 := NULL;

-- Retrieve Record
CURSOR cur_4(c_PERSON_ID NUMBER)
IS
SELECT
'Y'
FROM 
  per_all_people_f       papf
, per_all_assignments_f  paaf
, per_people_extra_info  ppei
, per_periods_of_service pos
WHERE 1=1
AND papf.PERSON_ID        = c_PERSON_ID
AND papf.person_id        = ppei.person_id
AND papf.person_id        = paaf.person_id
AND ppei.information_type = 'HAE_ACQUISITION'
AND ppei.pei_information1 IS NOT NULL
AND pos.person_id         = papf.person_id
AND SYSDATE               BETWEEN paaf.effective_start_date AND paaf.effective_end_date
AND SYSDATE               BETWEEN papf.effective_start_date AND papf.effective_end_date
AND papf.person_id IN
   (SELECT papf2.person_id 
      FROM apps.per_all_people_F papf2 
     WHERE papf2.current_employee_flag = 'Y'
       AND SYSDATE BETWEEN papf2.effective_start_date AND papf2.effective_end_date)
;

BEGIN

   -- Initialize l_Record_Found
   l_Record_Found := NULL;

   OPEN cur_4(P_PERSON_ID);
   FETCH cur_4 INTO l_Record_Found;
   CLOSE cur_4;

   RETURN l_Record_Found;

END ACQUISITIONS;

--------------------------------------------------------------------------------
-- FUNCTION CONTINGENT_WORKER

FUNCTION CONTINGENT_WORKER(P_PERSON_ID IN NUMBER) RETURN VARCHAR2 IS

l_Record_Found                    NVARCHAR2(01)                                 := NULL;

-- Retrieve Record
CURSOR cur_5(c_PERSON_ID NUMBER)
IS
SELECT
'Y'
FROM 
     apps.per_all_people_f p 
JOIN apps.per_all_assignments_f a  ON p.person_id = a.person_id
JOIN Per_Person_Type_Usages_f pptu ON pptu.person_id = p.person_id
JOIN per_person_types ppt          ON ppt.person_type_id = pptu.person_type_id
WHERE 1=1
AND p.PERSON_ID            = c_PERSON_ID
AND current_employee_flag  = 'Y'
AND ppt.user_person_type   = 'Employee'
AND employment_category    IN ('PR', 'FR')
AND p.business_group_id    = 0
AND SYSDATE                BETWEEN p.effective_start_date AND p.effective_end_date
AND SYSDATE                BETWEEN a.effective_start_date AND a.effective_end_date
AND p.person_id IN 
   (SELECT DISTINCT p2.person_id 
      FROM apps.per_all_people_f p2
      JOIN Per_Person_Type_Usages_f pptu2 ON pptu2.person_id = p2.person_id
      JOIN per_person_types ppt2          ON ppt2.person_type_id = pptu2.person_type_id
     WHERE ppt2.user_person_type          LIKE '%Contingent Worker'
       AND p2.business_group_id = 0)
;

BEGIN

   -- Initialize l_Record_Found
   l_Record_Found := NULL;

   OPEN cur_5(P_PERSON_ID);
   FETCH cur_5 INTO l_Record_Found;
   CLOSE cur_5;

   RETURN l_Record_Found;

END CONTINGENT_WORKER;

--------------------------------------------------------------------------------
-- FUNCTION REHIRE

FUNCTION REHIRE(P_PERSON_ID IN NUMBER) RETURN VARCHAR2 IS

l_Record_Found                    NVARCHAR2(01)                                 := NULL;

-- Retrieve Record
CURSOR cur_6(c_PERSON_ID NUMBER)
IS
SELECT
'Y'
FROM 
     apps.per_all_people_f p
JOIN apps.per_all_assignments_f a  ON p.person_id = a.person_id
JOIN Per_Person_Type_Usages_f pptu ON pptu.person_id = p.person_id
JOIN per_person_types ppt          ON ppt.person_type_id = pptu.person_type_id
WHERE 1=1 
AND p.PERSON_ID           = c_PERSON_ID
AND current_employee_flag = 'Y'
AND ppt.user_person_type  = 'Employee'
AND employment_category   IN ('PR', 'FR')
AND p.business_group_id   = 0
AND SYSDATE               BETWEEN p.effective_start_date AND p.effective_end_date
AND SYSDATE               BETWEEN a.effective_start_date AND a.effective_end_date
AND p.person_id IN 
   (SELECT DISTINCT p2.person_id 
      FROM apps.per_all_people_f p2
      JOIN Per_Person_Type_Usages_f pptu2 ON pptu2.person_id = p2.person_id
      JOIN per_person_types ppt2          ON ppt2.person_type_id = pptu2.person_type_id
     WHERE ppt2.user_person_type = 'Ex-employee')
;

BEGIN

   -- Initialize l_Record_Found
   l_Record_Found := NULL;

   OPEN cur_6(P_PERSON_ID);
   FETCH cur_6 INTO l_Record_Found;
   CLOSE cur_6;

   RETURN l_Record_Found;

END REHIRE;

END XXHA_BSWIFT_PKG;