CREATE OR REPLACE PACKAGE XXHA_PICKCONFIRM_HANDLER_PKG
AS
   PROCEDURE XXHA_PICK_CONFIRM_API(
                                                                 v_status             OUT VARCHAR2
                                                            ,    o_message             OUT VARCHAR2
                                                            ,    v_errmsg              OUT VARCHAR2
                                                            ,    x_line_id            OUT VARCHAR2
                                                            ,    x_move_order_number        OUT VARCHAR2
                                                            ,    x_move_order_type_name        OUT VARCHAR2
                                                            ,    x_inventory_item_code        OUT VARCHAR2
                                                            ,    x_organization_name        OUT VARCHAR2
                                                            ,    x_item_revision_number        OUT VARCHAR2
                                                            ,    x_project_name            OUT VARCHAR2
                                                            ,    x_task_name            OUT VARCHAR2
                                                            ,    x_transaction_type        OUT VARCHAR2
                                                            ,    x_source_subinventory        OUT VARCHAR2
                                                            ,    x_source_locator        OUT VARCHAR2
                                                            ,    x_destination_subinventory    OUT VARCHAR2
                                                            ,    x_destination_locator        OUT VARCHAR2
                                                            ,    x_lot_number            OUT VARCHAR2
                                                            ,    x_pick_slix_number        OUT VARCHAR2
                                                            ,    x_sales_order_num        OUT VARCHAR2
                                                            ,    p_line_id            IN VARCHAR2
                                                            ,    p_move_order_number        IN VARCHAR2
                                                            ,    p_move_order_type_name        IN VARCHAR2
                                                            ,    p_inventory_item_code        IN VARCHAR2
                                                            ,    p_organization_name        IN VARCHAR2
                                                            ,    p_item_revision_number        IN VARCHAR2
                                                            ,    p_project_name            IN VARCHAR2
                                                            ,    p_task_name            IN VARCHAR2
                                                            ,    p_transaction_type        IN VARCHAR2
                                                            ,    p_source_subinventory        IN VARCHAR2
                                                            ,    p_source_locator        IN VARCHAR2
                                                            ,    p_destination_subinventory    IN VARCHAR2
                                                            ,    p_destination_locator        IN VARCHAR2
                                                            ,    p_lot_number            IN VARCHAR2
                                                            ,    p_pick_slip_number        IN VARCHAR2
                                                            ,    p_sales_order_num        IN VARCHAR2
                                                            ,    p_user_responsibility    IN VARCHAR
                                                            ,    p_user                        IN VARCHAR
                                                            );
END XXHA_PICKCONFIRM_HANDLER_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_PICKCONFIRM_HANDLER_PKG
AS

    PROCEDURE XXHA_PICK_CONFIRM_API(
                                                              v_status             OUT VARCHAR2
                                                        ,    o_message             OUT VARCHAR2
                                                        ,    v_errmsg              OUT VARCHAR2
                                                        ,    x_line_id            OUT VARCHAR2
                                                        ,    x_move_order_number        OUT VARCHAR2
                                                        ,    x_move_order_type_name        OUT VARCHAR2
                                                        ,    x_inventory_item_code        OUT VARCHAR2
                                                        ,    x_organization_name        OUT VARCHAR2
                                                        ,    x_item_revision_number        OUT VARCHAR2
                                                        ,    x_project_name            OUT VARCHAR2
                                                        ,    x_task_name            OUT VARCHAR2
                                                        ,    x_transaction_type        OUT VARCHAR2
                                                        ,    x_source_subinventory        OUT VARCHAR2
                                                        ,    x_source_locator        OUT VARCHAR2
                                                        ,    x_destination_subinventory    OUT VARCHAR2
                                                        ,    x_destination_locator        OUT VARCHAR2
                                                        ,    x_lot_number            OUT VARCHAR2
                                                        ,    x_pick_slix_number        OUT VARCHAR2
                                                        ,    x_sales_order_num        OUT VARCHAR2
                                                        ,    p_line_id            IN VARCHAR2
                                                        ,    p_move_order_number        IN VARCHAR2
                                                        ,    p_move_order_type_name        IN VARCHAR2
                                                        ,    p_inventory_item_code        IN VARCHAR2
                                                        ,    p_organization_name        IN VARCHAR2
                                                        ,    p_item_revision_number        IN VARCHAR2
                                                        ,    p_project_name            IN VARCHAR2
                                                        ,    p_task_name            IN VARCHAR2
                                                        ,    p_transaction_type        IN VARCHAR2
                                                        ,    p_source_subinventory        IN VARCHAR2
                                                        ,    p_source_locator        IN VARCHAR2
                                                        ,    p_destination_subinventory    IN VARCHAR2
                                                        ,    p_destination_locator        IN VARCHAR2
                                                        ,    p_lot_number            IN VARCHAR2
                                                        ,    p_pick_slip_number        IN VARCHAR2
                                                        ,    p_sales_order_num        IN VARCHAR2
                                                        ,    p_user_responsibility    IN VARCHAR
                                                        ,    p_user                        IN VARCHAR
                                                           )
                IS
    v_application                               VARCHAR2(20):='INV'; -- Application
    v_application_id                          NUMBER;
    v_user_id                                   NUMBER;
    v_user_responsibility_id               NUMBER;
    BEGIN

              -- Fetch Application id for Application
              v_errmsg:='Fetching the Application Id';

              SELECT application_id
              INTO   v_application_id
              FROM   fnd_application
              WHERE  application_short_name = v_application;

              -- Fetch the User Id
              v_errmsg:='Fetching the User Id';
              v_user_id:=wm_conc_request_pkg.get_user_id(p_user);

              -- Fetch the Responsibility Id
              v_errmsg:='Fetching the Responsibility Id';

              v_user_responsibility_id:= wm_conc_request_pkg.get_user_responsibility_id( p_user_responsibility);

              Fnd_Global.apps_initialize(v_user_id,v_user_responsibility_id,v_application_id);
              fnd_request.set_org_id(fnd_global.org_id) ; -- Added by VSAMBA for R12 Upgrade bug fix  on 12/18/2013

              Wm_Pickconfirm_Handler_Pkg.Wm_Pick_Confirm_Api( v_status
                                                                                        ,    o_message
                                                                                        ,    v_errmsg
                                                                                        ,    x_line_id
                                                                                        ,    x_move_order_number
                                                                                        ,    x_move_order_type_name
                                                                                        ,    x_inventory_item_code
                                                                                        ,    x_organization_name
                                                                                        ,    x_item_revision_number
                                                                                        ,    x_project_name
                                                                                        ,    x_task_name
                                                                                        ,    x_transaction_type
                                                                                        ,    x_source_subinventory
                                                                                        ,    x_source_locator
                                                                                        ,    x_destination_subinventory
                                                                                        ,    x_destination_locator
                                                                                        ,    x_lot_number
                                                                                        ,    x_pick_slix_number
                                                                                        ,    x_sales_order_num
                                                                                        ,    p_line_id
                                                                                        ,    p_move_order_number
                                                                                        ,    p_move_order_type_name
                                                                                        ,    p_inventory_item_code
                                                                                        ,    p_organization_name
                                                                                        ,    p_item_revision_number
                                                                                        ,    p_project_name
                                                                                        ,    p_task_name
                                                                                        ,    p_transaction_type
                                                                                        ,    p_source_subinventory
                                                                                        ,    p_source_locator
                                                                                        ,    p_destination_subinventory
                                                                                        ,    p_destination_locator
                                                                                        ,    p_lot_number
                                                                                        ,    p_pick_slip_number
                                                                                        ,    p_sales_order_num
                                                                                             );

    END XXHA_PICK_CONFIRM_API;

END XXHA_PICKCONFIRM_HANDLER_PKG;
/
