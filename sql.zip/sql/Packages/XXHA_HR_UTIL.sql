CREATE OR REPLACE PACKAGE xxha_hr_util AUTHID CURRENT_USER
IS
/*****************************************************************************
*
*  ORACLE CONSULTING
*
*  Package:  XXHA_HR_UTIL
*  Description:
*      This package contains various common routines used by Haemo CEMLIs.
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  08-Dec-2008       Ralph Sneep       Created New.
*
******************************************************************************/

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_Emp
-- Description: Is the person an employee? (not a 'COE Use Record' or 'HAE Contingent Worker')
-----------------------------------------------------------------------------------
FUNCTION person_is_emp ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE)  RETURN VARCHAR2;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_Ex_Emp
-- Description: Is the person an ex-employee? (not a 'HAE Ex-contingent Worker')
-----------------------------------------------------------------------------------
FUNCTION person_is_ex_emp ( p_person_id      IN  NUMBER
                           ,p_effective_date IN  DATE) RETURN VARCHAR2;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_CWK
-- Description: Is the person a HAE Contingent Worker?
-----------------------------------------------------------------------------------
FUNCTION person_is_cwk ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE) RETURN VARCHAR2;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_Ex_CWK
-- Description: Is the person a HAE Ex-contingent Worker?
-----------------------------------------------------------------------------------
FUNCTION person_is_ex_cwk ( p_person_id      IN  NUMBER
                           ,p_effective_date IN  DATE) RETURN VARCHAR2;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_APL
-- Description: Is the person an Applicant?
-----------------------------------------------------------------------------------
FUNCTION person_is_apl ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE) RETURN VARCHAR2;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_COE
-- Description: Is the person a COE Use Record?
-----------------------------------------------------------------------------------
FUNCTION person_is_coe ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE) RETURN VARCHAR2;

END xxha_hr_util;

/


CREATE OR REPLACE PACKAGE BODY      xxha_hr_util
IS
/*****************************************************************************
*  ORACLE CONSULTING
*
*  Package:  XXHA_HR_UTIL
*  Description:
*      This package contains various common routines used by Haemo CEMLIs.
*
*  Change History:
*  ----------------------------------------------------------------------------
*  Date              By                Description
*  -----------       --------------    ----------------------------------------
*  08-Dec-2008       Ralph Sneep       Created New.
*
******************************************************************************/

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_Emp
-- Description: Is the person an employee? (not a 'COE Use Record' or 'HAE Contingent Worker')
-----------------------------------------------------------------------------------
FUNCTION person_is_emp ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE)
RETURN VARCHAR2
IS

lc_test  VARCHAR2(1) := 'N';

BEGIN

select 'Y'
  INTO lc_test
  from per_person_types ppt
      ,per_person_type_usages_f pptu
 where ppt.person_type_id = pptu.person_type_id
   and pptu.person_id = p_person_id
   and ppt.system_person_type = 'EMP'
   and ppt.user_person_type not in ('COE Use Record', 'HAE Contingent Worker')
   and p_effective_date between pptu.effective_start_date and pptu.effective_end_date;

   RETURN lc_test;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';

END person_is_emp;


-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_Ex_Emp
-- Description: Is the person an ex-employee? (not a 'HAE Ex-contingent Worker')
-----------------------------------------------------------------------------------
FUNCTION person_is_ex_emp ( p_person_id      IN  NUMBER
                           ,p_effective_date IN  DATE)
RETURN VARCHAR2
IS

lc_test  VARCHAR2(1) := 'N';

BEGIN

select 'Y'
  INTO lc_test
  from per_person_types ppt
      ,per_person_type_usages_f pptu
 where ppt.person_type_id = pptu.person_type_id
   and pptu.person_id = p_person_id
   and ppt.system_person_type = 'EX_EMP'
   and ppt.user_person_type not in ('HAE Ex-contingent Worker')
   and p_effective_date between pptu.effective_start_date and pptu.effective_end_date;

   RETURN lc_test;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';

END person_is_ex_emp;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_CWK
-- Description: Is the person a HAE Contingent Worker?
-----------------------------------------------------------------------------------
FUNCTION person_is_cwk ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE)

RETURN VARCHAR2
IS

lc_test  VARCHAR2(1) := 'N';

BEGIN

select 'Y'
  INTO lc_test
  from per_person_types ppt
      ,per_person_type_usages_f pptu
 where ppt.person_type_id = pptu.person_type_id
   and pptu.person_id = p_person_id
   and ppt.system_person_type = 'EMP'
   and ppt.user_person_type in ('HAE Contingent Worker')
   and p_effective_date between pptu.effective_start_date and pptu.effective_end_date;

   RETURN lc_test;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';

END person_is_cwk;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_Ex_CWK
-- Description: Is the person a HAE Ex-contingent Worker?
-----------------------------------------------------------------------------------
FUNCTION person_is_ex_cwk ( p_person_id      IN  NUMBER
                           ,p_effective_date IN  DATE)

RETURN VARCHAR2
IS

lc_test  VARCHAR2(1) := 'N';

BEGIN

select 'Y'
  INTO lc_test
  from per_person_types ppt
      ,per_person_type_usages_f pptu
 where ppt.person_type_id = pptu.person_type_id
   and pptu.person_id = p_person_id
   and ppt.system_person_type = 'EX_EMP'
   and ppt.user_person_type in ('HAE Ex-contingent Worker')
   and p_effective_date between pptu.effective_start_date and pptu.effective_end_date;

   RETURN lc_test;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';

END person_is_ex_cwk;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_APL
-- Description: Is the person an Applicant?
-----------------------------------------------------------------------------------
FUNCTION person_is_apl ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE)
RETURN VARCHAR2
IS

lc_test  VARCHAR2(1) := 'N';

BEGIN

select 'Y'
  INTO lc_test
  from per_person_types ppt
      ,per_person_type_usages_f pptu
 where ppt.person_type_id = pptu.person_type_id
   and pptu.person_id = p_person_id
   and ppt.system_person_type = 'APL'
   and p_effective_date between pptu.effective_start_date and pptu.effective_end_date;

   RETURN lc_test;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';

END person_is_apl;

-----------------------------------------------------------------------------------
-- F U N C T I O N
-- Name: Person_Is_COE
-- Description: Is the person a COE Use Record?
-----------------------------------------------------------------------------------
FUNCTION person_is_coe ( p_person_id      IN  NUMBER
                        ,p_effective_date IN  DATE)
RETURN VARCHAR2
IS

lc_test  VARCHAR2(1) := 'N';

BEGIN

select 'Y'
  INTO lc_test
  from per_person_types ppt
      ,per_person_type_usages_f pptu
 where ppt.person_type_id = pptu.person_type_id
   and pptu.person_id = p_person_id
   and ppt.system_person_type = 'EMP'
   and ppt.user_person_type in ('COE Use Record')
   and p_effective_date between pptu.effective_start_date and pptu.effective_end_date;

   RETURN lc_test;

EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';

END person_is_coe;

END xxha_hr_util;

/
