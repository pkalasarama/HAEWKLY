CREATE OR REPLACE PACKAGE XXHA_BOM_EXTRACT_PKG AUTHID CURRENT_USER AS 

/************************************************************************************************************************
* Package Name : XXHA_BOM_EXTRACT_PKG                                                                                   *
* Purpose      : This package provides a process load the table, 'APPS.XXHA_BOM_EXPLOSION_TEMP' for the BOM Extract.    *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*                XXHA_LOAD_BOM                                                                                          * 
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        04-FEB-2016     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

   PROCEDURE XXHA_PROCESS_DATA(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2);

   PROCEDURE XXHA_LOAD_BOM(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2);

END XXHA_BOM_EXTRACT_PKG;