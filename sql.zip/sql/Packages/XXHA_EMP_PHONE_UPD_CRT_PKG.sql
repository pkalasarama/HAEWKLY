CREATE OR REPLACE PACKAGE XXHA_EMP_PHONE_UPD_CRT_PKG AS

/***********************************************************************************************
* Package Name : XXHA_EMP_PHONE_UPD_CRT_PKG                                                    *
*                                                                                              *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to update or create a Phone Number.                             *
*                                                                                              *
* Procedures   : p_phn_upd_crt                                                                 *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
* per_all_people_f                 S                                                           *
* per_periods_of_service           S                                                           *
* per_assignments_f                S                                                           *
* fnd_user                         S                                                           *
* per_phones                       S                                                           *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        19-JUL-2013     B. Marcoux           Initial Version                              *
*                                                                                              *
***********************************************************************************************/

/* ****************************************************************************************** */
/* This procedure will Create or Update the Phone Number                                      */

PROCEDURE p_phn_upd_crt (p_Person_ID          IN   per_all_people_f.person_id%TYPE
                       , p_Phone_Value        IN   VARCHAR2
                        ); 

END XXHA_EMP_PHONE_UPD_CRT_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_EMP_PHONE_UPD_CRT_PKG AS

/***********************************************************************************************
* Package Name : XXHA_EMP_PHONE_UPD_CRT_PKG                                                    *
*                                                                                              *
* Purpose      : This package provides the following functions:                                *
*                 - Processing to update or create a Phone Number.                             *
*                                                                                              *
* Procedures   : p_phn_upd_crt                                                                 *
*                                                                                              *
* Tables Accessed                  Access Type(I - Insert, S - Select, U - Update, D - Delete) *
* per_all_people_f                 S                                                           *
* per_periods_of_service           S                                                           *
* per_assignments_f                S                                                           *
* fnd_user                         S                                                           *
* per_phones                       S                                                           *
*                                                                                              *
* Change History                                                                               *
*                                                                                              *
* Ver        Date            Author               Description                                  *
* ------     -----------     -----------------    ---------------                              *
* 1.0        19-JUL-2013     B. Marcoux           Initial Version                              *
*                                                                                              *
***********************************************************************************************/

/* ****************************************************************************************** */
/* This procedure will Create or Update the Phone Number                                      */

PROCEDURE p_phn_upd_crt (p_Person_ID          IN   per_all_people_f.person_id%TYPE
                       , p_Phone_Value        IN   VARCHAR2
                       ) IS

-- Variables
   l_Full_Name                                 per_all_people_f.full_name%TYPE;
   l_Employee_Number                           per_all_people_f.employee_number%TYPE;
   l_person_id                                 per_all_people_f.person_id%TYPE;
   l_ppf_effective_start_date                  per_all_people_f.effective_start_date%TYPE;
   l_ppf_effective_end_date                    per_all_people_f.effective_end_date%TYPE;
   l_paf_effective_start_date                  per_assignments_f.effective_start_date%TYPE;
   l_paf_effective_end_date                    per_assignments_f.effective_end_date%TYPE;
   l_PHONE_ID                                  PER_PHONES.PHONE_ID%TYPE;
   l_PHONE_IDS                                 PER_PHONES.PHONE_ID%TYPE;
   l_parent_id                                 PER_PHONES.parent_id%TYPE;
   l_Phone_Number                              PER_PHONES.Phone_Number%TYPE;
   l_Phone_DATE_FROM                           PER_PHONES.DATE_FROM%TYPE;
   l_PPH_OBJECT_VERSION_NUMBER                 PER_PHONES.OBJECT_VERSION_NUMBER%TYPE;

   lc_employee_number                          per_all_people_f.employee_number%TYPE;
   lc_object_version_number                    per_all_people_f.OBJECT_VERSION_NUMBER%TYPE;
   lc_effective_start_date                     per_all_people_f.EFFECTIVE_START_DATE%TYPE;
   lc_effective_end_date                       per_all_people_f.EFFECTIVE_END_DATE%TYPE;
   lc_full_name                                per_all_people_f.FULL_NAME%TYPE;
   lc_comment_id                               per_all_people_f.COMMENT_ID%TYPE;
   lc_phone_id                                 PER_PHONES.phone_id%TYPE;

-- ERRORS
   gc_request_id                               xxha_common_errors.request_id%TYPE             := fnd_global.conc_request_id;
   gc_record_identifier                        xxha_common_errors.record_identifier%TYPE;
   gc_record_number                            xxha_common_errors.record_number%TYPE;
   gc_error_code                               xxha_common_errors.error_code%TYPE;
   gc_error_msg                                xxha_common_errors.error_msg%TYPE;
   gc_comments                                 xxha_common_errors.comments%TYPE;
   gc_attribute1                               xxha_common_errors.attribute1%TYPE;
   gc_attribute2                               xxha_common_errors.attribute2%TYPE;
   gc_attribute3                               xxha_common_errors.attribute3%TYPE;
   gc_attribute4                               xxha_common_errors.attribute4%TYPE;
   gc_attribute5                               xxha_common_errors.attribute5%TYPE;
   gc_table_name                               xxha_common_errors.TABLE_NAME%TYPE             := 'XXHA_UPDATE_EMP_PHONE';
   gc_status                                   VARCHAR2(2);
   lc_status                                   VARCHAR2(1000);

-- Cursor to retrieve data
   CURSOR C1
   IS
   SELECT
         ppf.full_name
      ,  ppf.employee_number
      ,  ppf.person_id
      ,  ppf.effective_start_date
      ,  ppf.effective_end_date
      ,  paf.effective_start_date
      ,  paf.effective_end_date
      ,  PHONES.PHONE_ID
      ,  PHONES.parent_id
      ,  PHONES.DATE_FROM
      ,  PHONES.PHONE_NUMBER
      ,  PHONES.OBJECT_VERSION_NUMBER
   FROM
         per_all_people_f                      ppf
      ,  per_periods_of_service                ppos
      ,  per_assignments_f                     paf
      ,  fnd_user                              usr
      ,  (SELECT 
              phn.PHONE_ID
           ,  phn.parent_id
           ,  phn.DATE_FROM
           ,  phn.PHONE_NUMBER
           ,  phn.OBJECT_VERSION_NUMBER
          FROM 
              PER_PHONES          PHN
          WHERE 
              PHN.PHONE_TYPE(+) = SUBSTR(p_Phone_Value, 1, (INSTR(p_Phone_Value, '.', 1, 1)-1))
          AND TRUNC(sysdate)    BETWEEN PHN.DATE_FROM and NVL(PHN.DATE_TO, TRUNC(sysdate))
          AND PHN.PARENT_TABLE  = 'PER_ALL_PEOPLE_F') PHONES
   WHERE
         paf.period_of_service_id    = ppos.period_of_service_id
     AND paf.person_id               = ppf.person_id
     AND SYSDATE                     BETWEEN paf.effective_start_date and paf.effective_end_date
     AND SYSDATE                     BETWEEN ppf.effective_start_date and ppf.effective_end_date
     AND ppf.person_id               = usr.employee_id(+)
     AND Ppf.PERSON_ID               = PHONES.PARENT_ID(+)
     AND paf.person_id               = p_person_id
     ;

-- Cursor to check if Phone exists
   CURSOR C2(P_PARENT_ID NUMBER, P_PHONE_ID NUMBER)
       IS
   SELECT phn.PHONE_ID
     FROM PER_PHONES PHN
    WHERE PHN.PHONE_TYPE    = SUBSTR(p_Phone_Value, 1, (INSTR(p_Phone_Value, '.', 1, 1)-1))
      AND TRUNC(sysdate)    BETWEEN PHN.DATE_FROM and NVL(PHN.DATE_TO, TRUNC(sysdate))
      AND PHN.PARENT_TABLE  = 'PER_ALL_PEOPLE_F'
      AND PHN.PARENT_ID     = P_PARENT_ID
      AND PHN.PHONE_ID      = P_PHONE_ID
      ;

BEGIN

       OPEN C1;

       FETCH
         C1
       INTO
         l_Full_Name
       , l_Employee_Number
       , l_Person_id
       , l_ppf_Effective_start_date
       , l_ppf_Effective_end_date
       , l_paf_Effective_start_date
       , l_paf_Effective_end_date
       , l_PHONE_ID
       , l_parent_id
       , l_Phone_Date_From
       , l_Phone_Number
       , l_PPH_OBJECT_VERSION_NUMBER
       ;

       BEGIN

         OPEN C2 (l_parent_id, l_PHONE_ID);

         FETCH
           C2
         INTO
           l_PHONE_IDS
         ;

         IF C2%NOTFOUND THEN
            -- Create Phone Record
            hr_phone_api.create_or_update_phone 
            (
              p_date_from                    => TRUNC(SYSDATE)
            , p_phone_type                   => SUBSTR(p_Phone_Value, 1, (INSTR(p_Phone_Value, '.', 1, 1)-1))
            , p_phone_number                 => SUBSTR(p_Phone_Value, (INSTR(p_Phone_Value, '.' ,1 ,1) + 1), LENGTH(p_Phone_Value) - INSTR(p_Phone_Value,'.' ,1 ,1))
            , p_parent_id                    => p_Person_ID                     --l_parent_id       04-sep-2013
            , p_parent_table                 => 'PER_ALL_PEOPLE_F'
            , p_effective_date               => TRUNC(SYSDATE)
            -- Input/Output data elements 
            , p_phone_id                     => lc_phone_id
            , p_object_version_number        => lc_object_version_number 
            );
         ELSE
            -- Update Phone Record
            hr_phone_api.create_or_update_phone 
            (
              p_date_from                    => TRUNC(l_Phone_Date_From)
            , p_phone_type                   => SUBSTR(p_Phone_Value, 1, (INSTR(p_Phone_Value, '.', 1, 1)-1))
            , p_phone_number                 => SUBSTR(p_Phone_Value, (INSTR(p_Phone_Value, '.' ,1 ,1) + 1), LENGTH(p_Phone_Value) - INSTR(p_Phone_Value,'.' ,1 ,1))
            , p_parent_id                    => l_parent_id
            , p_parent_table                 => 'PER_ALL_PEOPLE_F'
            , p_effective_date               => TRUNC(SYSDATE)
            -- Input/Output data elements 
            , p_phone_id                     => l_PHONE_ID
            , p_object_version_number        => l_PPH_OBJECT_VERSION_NUMBER
            );

         END IF;

         EXCEPTION
         WHEN OTHERS THEN
         GC_RECORD_NUMBER                := 1;
         GC_RECORD_IDENTIFIER            := l_person_id;
         GC_ERROR_CODE                   := 'EP1';
         GC_ERROR_MSG                    := 'ERROR - hr_phone_api.create_or_update_phone';
         GC_COMMENTS                     := l_Employee_Number;
         GC_ATTRIBUTE1                   := l_Full_Name;
         GC_ATTRIBUTE2                   := l_parent_id;
         GC_ATTRIBUTE3                   := SUBSTR(p_Phone_Value, 1, (INSTR(p_Phone_Value, '.', 1, 1)-1));
         GC_ATTRIBUTE4                   := SUBSTR(p_Phone_Value, (INSTR(p_Phone_Value, '.' ,1 ,1) + 1), LENGTH(p_Phone_Value) - INSTR(p_Phone_Value,'.' ,1 ,1));
         GC_ATTRIBUTE5                   := NVL(l_PHONE_ID,lc_phone_id);
         XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);
         RAISE;

       END;

END;
-- END for BEGIN

END XXHA_EMP_PHONE_UPD_CRT_PKG;
/
