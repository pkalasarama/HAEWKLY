create or replace PACKAGE XXHA_WD_EMPLOYEE_CHANGES_PKG AUTHID CURRENT_USER AS 

/************************************************************************************************************************
* Package Name : XXHA_WD_EMPLOYEE_CHANGES_PKG                                                                           *
* Purpose      : This Package will process New Employee Records created by Workday.                                     *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*              : XXHA_PROCESS_EDITS                                                                                     *
*              : XXHA_PROCESS_TERMINATIONS                                                                              *
*              : XXHA_WD_EMPLOYEE_TERMINATE                                                                             *
*              : XXHA_PROCESS_REVERSE_TERMS                                                                             *
*              : XXHA_WD_EMPLOYEE_REVERSE_TERM                                                                          *
*              : XXHA_PROCESS_CHANGES                                                                                   *
*              : XXHA_WD_EMPLOYEE_REC_UPD                                                                               *
*              : XXHA_WD_EMPLOYEE_PHONE_UPD                                                                             *
*              : XXHA_WD_EMPLOYEE_ASSGN_REC_UPD                                                                         *
*              : XXHA_WD_EMPLOYEE_COST                                                                                  *
*              : XXHA_WD_EMPLOYEE_CREATE_JOB                                                                            *
*              : XXHA_WD_EMPLOYEE_CRT_VALUESET                                                                          *
*              : XXHA_WD_EMPLOYEE_CREATE_GRADE                                                                          *
*              : XXHA_CHECK_FOR_NON_NUMERIC                                                                             *
*              : XXHA_BACKUP_DATA                                                                                       *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        30-MAR-2018     BMarcoux             Initial Package creation.                                             *
* 2.0        05-MAY-2018     BMarcoux             Correction to Code:                                                   *
*                                                 - Changed value for Title when creating/updating Employee             *
*                                                 - Corrected processing for Job Name when the Job Name contains a      *
*                                                   period.  The period will be removed if one exists in the name.      *
*                                                 - Changed Leave Reason processing due to values being sent from       *
*                                                   Work Day.                                                           *
* 3.0        15-MAY-2018     BMarcoux             Correction to Code:                                                   *
*                                                 - Corrected processing for Job Name when the Job Name contains a      *
*                                                   period.                                                             *
*                                                 - Changed code to allow Terminations without needing all edited       *
*                                                   fields entered and validated.  We only need a valid PERSON_ID,      *
*                                                   a valid LAST_DAY_WORKED and a valid Leave Reason (if entered).      *
*                                                 New Code:                                                             *
*                                                 - Processing for Reverse Terminations                                 *
* 4.0        21-MAY-2018     BMarcoux             Correction to Code:                                                   *
*                                                 - Ensure Terminations and Reverse Terminations are not picked up      *
*                                                   by the Procedure, 'XXHA_PROCESS_CHANGES' since these records        *
*                                                   bypass the Procedure, 'XXHA_PROCESS_EDITS'.                         *
*                                                                                                                       *
************************************************************************************************************************/

   PROCEDURE XXHA_PROCESS_DATA(
             errbuf                         OUT VARCHAR2
            ,errcode                        OUT VARCHAR2);

   PROCEDURE XXHA_PROCESS_EDITS(
             errbuf                         OUT VARCHAR2
            ,errcode                        OUT VARCHAR2
            ,p_Process_Start_Date           OUT DATE);

   PROCEDURE XXHA_PROCESS_TERMINATIONS(
             errbuf                         OUT VARCHAR2
            ,errcode                        OUT VARCHAR2);

   PROCEDURE XXHA_PROCESS_REVERSE_TERMS(
             errbuf                         OUT VARCHAR2
            ,errcode                        OUT VARCHAR2);

   PROCEDURE XXHA_PROCESS_CHANGES(
             errbuf                         OUT VARCHAR2
            ,errcode                        OUT VARCHAR2);

   PROCEDURE XXHA_WD_EMPLOYEE_REC_UPD(
             p_RECORD_ID                    IN  NUMBER);

   PROCEDURE XXHA_WD_EMPLOYEE_PHONE_UPD(
             p_RECORD_ID                    IN  NUMBER);

   PROCEDURE XXHA_WD_EMPLOYEE_ASSGN_REC_UPD(
             p_RECORD_ID                    IN  NUMBER);

   PROCEDURE XXHA_WD_EMPLOYEE_COST(
             p_RECORD_ID                    IN  NUMBER);

   PROCEDURE XXHA_WD_EMPLOYEE_CREATE_JOB(
             p_RECORD_ID                    IN  NUMBER
            ,p_BG_ID                        IN  NUMBER
            ,p_EMPLOYEE_NUMBER              IN  VARCHAR2
            ,p_JOB_NAME                     IN  VARCHAR2
            ,p_BG_COUNTRY_CODE              IN  VARCHAR2);

   PROCEDURE XXHA_WD_EMPLOYEE_CRT_VALUESET(
             p_RECORD_ID                    IN  NUMBER
            ,p_EMPLOYEE_NUMBER              IN  VARCHAR2
            ,p_JOB_NAME                     IN  VARCHAR2);

   PROCEDURE XXHA_WD_EMPLOYEE_CREATE_GRADE(
             p_RECORD_ID                    IN  NUMBER
            ,p_BG_ID                        IN  NUMBER
            ,p_GRADE_ORACLE                 IN  VARCHAR2);

   PROCEDURE XXHA_WD_EMPLOYEE_VALID_GRADES(
             p_RECORD_ID                    IN  NUMBER
            ,p_BUSINESS_GROUP_ID            IN  NUMBER
            ,p_GRADE_ID                     IN  NUMBER
            ,p_JOB_ID                       IN  NUMBER);

   PROCEDURE XXHA_WD_EMPLOYEE_TERMINATE(
             p_RECORD_ID                    IN  NUMBER);

   PROCEDURE XXHA_WD_EMPLOYEE_REVERSE_TERM(
             p_RECORD_ID                    IN  NUMBER);

   PROCEDURE XXHA_CHECK_FOR_NON_NUMERIC(
             p_Value_In                     IN  VARCHAR2
            ,p_Value_Out                    OUT VARCHAR2);

   PROCEDURE XXHA_BACKUP_DATA(
             errbuf                         OUT VARCHAR2
            ,errcode                        OUT VARCHAR2
            ,p_Process_Start_Date           IN  DATE);

END XXHA_WD_EMPLOYEE_CHANGES_PKG;