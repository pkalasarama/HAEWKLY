CREATE OR REPLACE PACKAGE XXHA_SUPERVISOR_EMP_PKG AUTHID CURRENT_USER AS

/************************************************************************************************************************
* Package Name : XXHA_SUPERVISOR_EMP_PKG                                                                                *
* Purpose      : This package provides a function to create/purge rows from the table 'XXHA_SUPERVISOR_EMP_COUNT_TBL'.  *
*                This package will be used by the XML Report 'XXHA: Supervisor Alert'.                                  *
*                It is called from within 'Report Triggers' > 'Before Report' and 'Report Triggers' > 'After Report'.   *
*                                                                                                                       *
* Procedures   : XXHA_SUPERVISOR_EMP_COUNT                                                                              *
*              : XXHA_SUPERVISOR_EMP_PURGE                                                                              *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
* - XXHA_SUPERVISOR_EMP_COUNT_TBL     I/D                                                                               *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        24-APR-2014     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/
 
--------------------------------------------------------------------------------
-- PROCEDURE XXHA_SUPERVISOR_EMP_COUNT

PROCEDURE XXHA_SUPERVISOR_EMP_COUNT( 
          p_request_id    IN NUMBER
         ,p_date          IN DATE);
 
--------------------------------------------------------------------------------
-- PROCEDURE XXHA_SUPERVISOR_EMP_PURGE

PROCEDURE XXHA_SUPERVISOR_EMP_PURGE( 
          p_request_id    IN NUMBER
         ,p_date          IN DATE
         ,p_purge_days    IN NUMBER);

end XXHA_SUPERVISOR_EMP_PKG;
/


CREATE OR REPLACE PACKAGE BODY XXHA_SUPERVISOR_EMP_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_SUPERVISOR_EMP_PKG                                                                                *
* Purpose      : This package provides a function to create/purge rows from the table 'XXHA_SUPERVISOR_EMP_COUNT_TBL'.  *
*                This package will be used by the XML Report 'XXHA: Supervisor Alert'.                                  *
*                It is called from within 'Report Triggers' > 'Before Report' and 'Report Triggers' > 'After Report'.   *
*                                                                                                                       *
* Procedures   : XXHA_SUPERVISOR_EMP_COUNT                                                                              *
*              : XXHA_SUPERVISOR_EMP_PURGE                                                                              *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
* - XXHA_SUPERVISOR_EMP_COUNT_TBL     I/D                                                                               *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        24-APR-2014     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/
 
--------------------------------------------------------------------------------
-- PROCEDURE XXHA_SUPERVISOR_EMP_COUNT

PROCEDURE XXHA_SUPERVISOR_EMP_COUNT( 
          p_request_id    IN NUMBER
         ,p_date          IN DATE) IS

--------------------------------------------------------------------------------
-- Retrieve Number of Employees for a Supervisor 
CURSOR cur_1 IS
SELECT 
      sup.person_id              SUPERVISOR_ID
    , COUNT(*)                   COUNTER
  FROM
      HR_ALL_ORGANIZATION_UNITS  HOUT
    , per_business_groups        pbg
    , PER_JOBS                   JOBS
    , per_job_definitions        jd
    , hr_locations               loc
    , per_periods_of_service     ppos
    , per_people_x               ppf
    , per_assignments_x          paf
    , per_people_x               sup
 WHERE
      paf.period_of_service_id   = ppos.period_of_service_id(+)
  AND paf.person_id              = ppf.person_id
  AND paf.supervisor_id          = sup.person_id
  AND paf.organization_id        = HOUT.organization_id(+)
  AND paf.business_group_id      = pbg.business_group_id
  AND PAF.JOB_ID                 = JOBS.JOB_ID(+)
  AND jobs.job_definition_id     = jd.job_definition_id(+)
  AND paf.LOCATION_ID            = LOC.LOCATION_ID(+)
  AND paf.assignment_type        = 'E'
  AND paf.primary_flag           = 'Y'
  AND sup.email_address          IS NOT NULL
  AND SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE (TRUNC(SYSDATE),PPF.PERSON_ID)),1,8) IN ('EMPLOYEE')
GROUP BY
      sup.person_id;

BEGIN

  FOR DET IN cur_1 
  LOOP
    INSERT INTO HAEMO.XXHA_SUPERVISOR_EMP_COUNT_TBL
    (
      Request_id
    , PROCESS_DATE
    , SUPERVISOR_ID
    , EMP_COUNT
    )
    VALUES
    (
      p_request_id
    , p_date
    , det.SUPERVISOR_ID
    , det.COUNTER
    );
  END LOOP;

COMMIT;

END XXHA_SUPERVISOR_EMP_COUNT;


--------------------------------------------------------------------------------
-- PROCEDURE XXHA_SUPERVISOR_EMP_PURGE

PROCEDURE XXHA_SUPERVISOR_EMP_PURGE( 
          p_request_id    IN NUMBER
         ,p_date          IN DATE
         ,p_purge_days    IN NUMBER) IS

  BEGIN

    -- Delete data from table for current submission or if records are >= a number of days old (as defined in p_purge_days)
    DELETE FROM HAEMO.XXHA_SUPERVISOR_EMP_COUNT_TBL hae
    WHERE hae.Request_id = p_request_id
       OR (TRUNC(p_date) - TRUNC(hae.PROCESS_DATE)) >= p_purge_days;

    COMMIT;

  END XXHA_SUPERVISOR_EMP_PURGE;

END XXHA_SUPERVISOR_EMP_PKG;
/
