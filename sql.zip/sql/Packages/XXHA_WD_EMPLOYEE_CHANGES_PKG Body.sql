create or replace PACKAGE BODY XXHA_WD_EMPLOYEE_CHANGES_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_WD_EMPLOYEE_CHANGES_PKG                                                                           *
* Purpose      : This Package will process New Employee Records created by Workday.                                     *
*                                                                                                                       *
* Procedures   : XXHA_PROCESS_DATA                                                                                      *
*              : XXHA_PROCESS_EDITS                                                                                     *
*              : XXHA_PROCESS_TERMINATIONS                                                                              *
*              : XXHA_WD_EMPLOYEE_TERMINATE                                                                             *
*              : XXHA_PROCESS_REVERSE_TERMS                                                                             *
*              : XXHA_WD_EMPLOYEE_REVERSE_TERM                                                                          *
*              : XXHA_PROCESS_CHANGES                                                                                   *
*              : XXHA_WD_EMPLOYEE_REC_UPD                                                                               *
*              : XXHA_WD_EMPLOYEE_PHONE_UPD                                                                             *
*              : XXHA_WD_EMPLOYEE_ASSGN_REC_UPD                                                                         *
*              : XXHA_WD_EMPLOYEE_COST                                                                                  *
*              : XXHA_WD_EMPLOYEE_CREATE_JOB                                                                            *
*              : XXHA_WD_EMPLOYEE_CRT_VALUESET                                                                          *
*              : XXHA_WD_EMPLOYEE_CREATE_GRADE                                                                          *
*              : XXHA_CHECK_FOR_NON_NUMERIC                                                                             *
*              : XXHA_BACKUP_DATA                                                                                       *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        30-MAR-2018     BMarcoux             Initial Package creation.                                             *
* 2.0        05-MAY-2018     BMarcoux             Correction to Code:                                                   *
*                                                 - Changed value for Title when creating/updating Employee             *
*                                                 - Corrected processing for Job Name when the Job Name contains a      *
*                                                   period.  The period will be removed if one exists in the name.      *
*                                                 - Changed Leave Reason processing due to values being sent from       *
*                                                   Work Day.                                                           *
* 3.0        15-MAY-2018     BMarcoux             Correction to Code:                                                   *
*                                                 - Corrected processing for Job Name when the Job Name contains a      *
*                                                   period.                                                             *
*                                                 - Changed code to allow Terminations without needing all edited       *
*                                                   fields entered and validated.  We only need a valid PERSON_ID,      *
*                                                   a valid LAST_DAY_WORKED and a valid Leave Reason (if entered).      *
*                                                 New Code:                                                             *
*                                                 - Processing for Reverse Terminations                                 *
* 4.0        21-MAY-2018     BMarcoux             Correction to Code:                                                   *
*                                                 - Ensure Terminations and Reverse Terminations are not picked up      *
*                                                   by the Procedure, 'XXHA_PROCESS_CHANGES' since these records        *
*                                                   bypass the Procedure, 'XXHA_PROCESS_EDITS'.                         *
*                                                                                                                       *
************************************************************************************************************************/


--------------------------------------------------------------------------------
PROCEDURE XXHA_PROCESS_DATA(
          errbuf                            OUT VARCHAR2
         ,errcode                           OUT VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables
   l_Process_Start_Date                     DATE := NULL;

   BEGIN

      -- Processing for Employee's being terminated.  If an employee is processed by Procedure 'XXHA_WD_EMPLOYEE_TERMINATE' because they were termed
      -- the employee record will bypass XXHA_PROCESS_CHANGES as it will select records from HAEMO.XXHA_WD_EMPLOYEE_CHANGES where STATUS = 'PASS'
      -- Moved to before edits as we only need a valid PERSON_ID, a valid LAST_DAY_WORKED and a valid Leave Reason (if entered) -- 2018/05/15
      XXHA_PROCESS_TERMINATIONS(errbuf,errcode);

      -- Process for Reverse Terminations                                       -- 2018/05/15
      XXHA_PROCESS_REVERSE_TERMS(errbuf,errcode);                               -- 2018/05/15

      -- Process Edits
      XXHA_PROCESS_EDITS(errbuf,errcode,l_Process_Start_Date);

      -- Processing for Employee's being terminated.  If an employee is processed by Procedure 'XXHA_WD_EMPLOYEE_TERMINATE' because they were termed
      -- the employee record will bypass XXHA_PROCESS_CHANGES as it will select records from HAEMO.XXHA_WD_EMPLOYEE_CHANGES where STATUS = 'PASS'
--      XXHA_PROCESS_TERMINATIONS(errbuf,errcode); -- 2018/05/15

      -- Process Changes
      XXHA_PROCESS_CHANGES(errbuf,errcode);

      -- SET XXHA.STATUS for No Errors
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
         SET XXHA.STATUS         = 'PASS'
       WHERE XXHA.STATUS         = 'PROCESSED'
          OR XXHA.STATUS_MESSAGE IS NULL;

      -- Remove last ' / ' at end of STATUS_MESSAGE if populated
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
         SET XXHA.STATUS_MESSAGE = SUBSTR(XXHA.STATUS_MESSAGE,1,(LENGTH(XXHA.STATUS_MESSAGE)-3))
       WHERE LENGTH(XXHA.STATUS_MESSAGE) > 0;

      -- Record End Date of Processing
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
         SET XXHA.PROCESSED_END_DATE = SYSDATE;

      -- Backup Processed Data
      XXHA_BACKUP_DATA(errbuf,errcode,l_Process_Start_Date);

   COMMIT;

   END;

END XXHA_PROCESS_DATA;


--------------------------------------------------------------------------------
PROCEDURE XXHA_PROCESS_EDITS(
          errbuf                            OUT VARCHAR2
         ,errcode                           OUT VARCHAR2
         ,p_Process_Start_Date              OUT DATE) AS

BEGIN

DECLARE

   -- Local Variables
   errcode                                  VARCHAR2(2000);

   l_ERROR_MSG                              VARCHAR2(4000);
   l_ERROR                                  VARCHAR2(4000);
   l_FOUND                                  VARCHAR2(10);
   l_CREATE_JOB                             VARCHAR2(10);
   l_JOB_FOUND                              VARCHAR2(10);
   l_EXCEPTION                              EXCEPTION;
   l_Count                                  NUMBER;
   l_LENGTH                                 NUMBER;
   l_WD_RECORD_ID                           HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE   := NULL;
   l_errcode                                VARCHAR2(2000)                                     := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE         := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;

   l_Value_In                               VARCHAR2(20)                                       := NULL;
   l_Value_Out                              VARCHAR2(20)                                       := NULL;
   l_location_Id_Num                        APPS.HR_LOCATIONS_V.location_id%TYPE               := NULL;

   l_Record_Count                           NUMBER;
   l_ATTRIBUTE_WD1                          HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD1%TYPE;
   l_ATTRIBUTE_WD2                          HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD2%TYPE;
   l_ATTRIBUTE_ORACLE1                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE1%TYPE;
   l_ATTRIBUTE_ORACLE2                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE2%TYPE;

   l_LOCATION_EXISTS                        VARCHAR2(02);
   l_COUNTRY_EXISTS                         VARCHAR2(02);
   l_EMPLOYEE_EXISTS                        VARCHAR2(02);
   l_SUPERVISOR_EXISTS                      VARCHAR2(02);
   l_Process_Start_Date                     DATE;
   l_Process_End_Date                       DATE;

   l_business_group_id                      APPS.per_business_groups.business_group_id%TYPE;
   l_bg_name                                APPS.per_business_groups.name%TYPE;
   l_organization_country                   APPS.HR_LOCATIONS_V.country%TYPE;
   l_location_id                            APPS.HR_LOCATIONS_V.location_id%TYPE;
   l_person_type_id                         APPS.PER_PERSON_TYPES.PERSON_TYPE_ID%TYPE;
   l_Organization_ID                        APPS.HR_ALL_ORGANIZATION_UNITS.Organization_ID%TYPE;
   l_ASSIGNMENT_DESCRIPTION                 APPS.hr_lookups.Description%TYPE;
   l_ASSIGNMENT_CATEGORY                    APPS.hr_lookups.LOOKUP_CODE%TYPE;
   l_ASSIGNMENT_ID                          APPS.PER_ASSIGNMENTS_X.ASSIGNMENT_ID%TYPE;
   l_COST_ALLOCATION_KEYFLEX_ID             APPS.pay_cost_allocation_keyflex.COST_ALLOCATION_KEYFLEX_ID%TYPE;
   l_COST_ACCOUNT                           VARCHAR2(240);
   l_CODE_COMBINATION_ID                    APPS.GL_CODE_COMBINATIONS.CODE_COMBINATION_ID%TYPE;
   l_EXPENSE_ACCOUNT                        VARCHAR2(240);
   l_GRADE_ID                               APPS.per_grades.GRADE_ID%TYPE;
   l_GRADE_ORACLE                           APPS.per_grades.NAME%TYPE;
   l_JOB_NAME                               APPS.per_jobs.NAME%TYPE;
   l_JOB_NAME_WD                            APPS.per_jobs.NAME%TYPE;
   l_JOB_ID                                 APPS.per_jobs.JOB_ID%TYPE;
   l_JOB_DEFINITION_ID                      APPS.per_jobs.JOB_DEFINITION_ID%TYPE;
   l_LEAVE_REASON_CODE                      APPS.hr_lookups.LOOKUP_CODE%TYPE;
   l_ASSIGNMENT_STATUS_TYPE_ID              APPS.PER_ASSIGNMENT_STATUS_TYPES.ASSIGNMENT_STATUS_TYPE_ID%TYPE;
   l_TITLE_CODE                             APPS.hr_lookups.LOOKUP_CODE%TYPE;
   l_TITLE_CODE_CHK                         APPS.hr_lookups.LOOKUP_CODE%TYPE;
   l_JOB_NAME_ORACLE                        HAEMO.XXHA_WD_EMPLOYEE_CHANGES.JOB_NAME_ORACLE%TYPE;
   l_CONTRACT_END_DATE                      APPS.PER_ALL_ASSIGNMENTS_F.EFFECTIVE_START_DATE%TYPE;

   l_C_CODE_COMBINATION_ID                  APPS.GL_CODE_COMBINATIONS.CODE_COMBINATION_ID%TYPE;             
   l_C_EXPENSE_ACCOUNT                      VARCHAR2(240);
   l_C_COST_ALLOCATION_KEYFLEX_ID           APPS.pay_cost_allocation_keyflex.COST_ALLOCATION_KEYFLEX_ID%TYPE;
   l_C_COST_ACCOUNT                         VARCHAR2(240);

-- Retrieve data in table HAEMO.XXHA_WD_EMPLOYEE_CHANGES and view XXHA_WD_EMPLOYEE_V
-- This is used to determine what transactions are not allowed to occur
-- I.E. No changes to Terminated Emps, No change in Business Group, No Employee to CWK, No CWK to Employee, No Reverse Terminations
CURSOR cur_0080
IS
SELECT
    CURR.PERSON_ID
  , CURR.EMPLOYEE_NUMBER    "CURR_EMPLOYEE_NUMBER"
  , CHG.EMPLOYEE_NUMBER     "CHG_EMPLOYEE_NUMBER"
  , CURR.FIRST_NAME
  , CURR.MIDDLE_NAMES
  , CURR.LAST_NAME
  , CURR.LOCATION_ID        "CURR_LOCATION_ID"
  , CURR.LOCATION           "CURR_LOCATION"
  , CURR.BUSINESS_GROUP     "CURR_BG_NAME"
  , CURR.BUSINESS_GROUP_ID  "CURR_BG_GROUP_ID"
  , CHG.LOCATION_ID         "CHG_LOCATION_ID"
  , CHG.LOCATION            "CHG_LOCATION"
  , CHG.BUSINESS_GROUP      "CHG_BG_NAME"
  , CHG.BUSINESS_GROUP_ID   "CHG_BG_GROUP_ID"
  , CHG.USER_STATUS         "CHG_USER_STATUS"
  , CHG.PERSON_TYPE_WD      "CHG_PERSON_TYPE_WD"
  , CHG.TIME_TYPE_WD        "CHG_TIME_TYPE_WD"
  , CHG.PERSON_TYPE         "CHG_PERSON_TYPE"
  , CHG.ASSIGNMENT_CATEGORY "CHG_ASSIGNMENT_CATEGORY"
  , CHG.USER_STATUS         "CURR_USER_STATUS"
  , CURR.USER_PERSON_TYPE   "CURR_USER_PERSON_TYPE"
  , CHG.CONTRACT_END_DATE
  , CHG.SUP_PERSON_ID
  , CHG.SUP_EMPLOYEE_NUMBER
  , CHG.STATUS
  , CHG.STATUS_MESSAGE
  , CHG.WD_RECORD_ID

FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES CHG
  , APPS.XXHA_WD_EMPLOYEE_V        CURR

WHERE
    CHG.PERSON_ID                = CURR.PERSON_ID
AND NVL(CHG.STATUS,'PASS')       NOT IN ('FAIL_TERM','FAIL_RTERM','PROCESSED')  -- New Code - 2018/05/15 (The termination process will update with either 'FAIL_TERM' OR 'PROCESSED')
;

-- Retrieve data in table HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100 (c_Status HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE)
IS
SELECT
    CHG.PERSON_ID
  , CHG.EMPLOYEE_NUMBER
  , CHG.TITLE
  , CHG.TITLE_CODE
  , CHG.FIRST_NAME
  , CHG.MIDDLE_NAMES
  , CHG.LAST_NAME
  , CHG.SUFFIX
  , CHG.FULL_NAME
  , CHG.KNOWN_AS
  , CHG.ORIGINAL_DATE_OF_HIRE
  , CHG.ORIGINAL_DATE_OF_HIRE_CHAR
  , CHG.START_DATE
  , CHG.START_DATE_CHAR
  , CHG.HAEMO_EMAIL_REQUIRED
  , CHG.NON_HAEMO_EMAIL_ADDRESS
  , CHG.BUSINESS_GROUP_ID
  , CHG.BUSINESS_GROUP
  , CHG.BUSINESS_GROUP_COUNTRY_CODE
  , CHG.PERSON_TYPE_WD
  , CHG.PERSON_TYPE
  , CHG.PERSON_TYPE_ID
  , CHG.TIME_TYPE_WD
  , CHG.ASSIGNMENT_CATEGORY
  , CHG.ASSIGNMENT_DESCRIPTION
  , CHG.ASSIGNMENT_STATUS_TYPE_ID
  , CHG.PHONE_WORK
  , CHG.PHONE_FAX
  , CHG.PHONE_MOBILE
  , CHG.USER_NAME
  , CHG.EMPLOYEE_EXISTS
  , CHG.ASSIGNMENT_ID
  , CHG.ORGANIZATION_ID
  , CHG.ORGANIZATION
  , CHG.JOB_ID
  , CHG.JOB_NAME
  , CHG.JOB_FAMILY
  , CHG.JOB_DEFINITION_ID
  , CHG.GRADE_ID
  , CHG.GRADE
  , CHG.GRADE_ORACLE
  , CHG.LOCATION_ID
  , CHG.LOCATION
  , CHG.LOCATION_EXISTS
  , CHG.COUNTRY
  , CHG.COUNTRY_EXISTS
  , CHG.USER_STATUS
  , CHG.SUP_PERSON_ID
  , CHG.SUP_EMPLOYEE_NUMBER
  , CHG.SUPERVISOR_EXISTS
  , CHG.CONTRACT_END_DATE
  , CHG.CONTRACT_END_DATE_CHAR
  , CHG.CODE_COMBINATION_ID
  , CHG.EXPENSE_ACCOUNT
  , CHG.COST_ALLOCATION_KEYFLEX_ID
  , CHG.COST_ACCOUNT
  , CHG.LEAVE_REASON
  , CHG.LEAVE_REASON_CODE
  , CHG.LAST_DAY_WORKED
  , CHG.LAST_DAY_WORKED_CHAR
  , CHG.OPERATING_UNIT_ID
  , CHG.OPERATING_UNIT_NAME
  , CHG.CREATION_DATE
  , CHG.STATUS
  , CHG.STATUS_MESSAGE
  , CHG.PROCESSED_START_DATE
  , CHG.PROCESSED_END_DATE
  , CHG.WD_RECORD_ID
  , CASE WHEN INSTR(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, CHG.PERSON_ID),'.', 1, 1) > 0 THEN
         SUBSTR(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, CHG.PERSON_ID), 1, INSTR(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, CHG.PERSON_ID),'.', 1, 1) - 1)
    ELSE
         HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, CHG.PERSON_ID)
    END "USER_PERSON_TYPE"
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES CHG
WHERE 1=1
AND NVL(CHG.STATUS,'PASS')   = NVL(c_Status,'PASS')
ORDER BY
    CHG.WD_RECORD_ID ASC
;

-- Retrieve data in APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0110 (c_PERSON_ID APPS.PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    CURR.PERSON_ID
  , CURR.EMPLOYEE_NUMBER
  , CURR.DATE_OF_BIRTH
  , CURR.NATIONAL_IDENTIFIER
  , CURR.TITLE
  , CURR.TITLE_CODE
  , CURR.FIRST_NAME
  , CURR.MIDDLE_NAMES
  , CURR.LAST_NAME
  , CURR.SUFFIX
  , CURR.FULL_NAME
  , CURR.KNOWN_AS
  , CURR.ORIGINAL_DATE_OF_HIRE
  , CURR.START_DATE
  , CURR.HAEMO_EMAIL_REQUIRED
  , CURR.NON_HAEMO_EMAIL_ADDRESS
  , CURR.BUSINESS_GROUP_ID
  , CURR.BUSINESS_GROUP
  , CURR.PERSON_TYPE_ID
  , CURR.PERSON_TYPE
  , CURR.PHONE_WORK
  , CURR.PHONE_WORK_PHONE_ID
  , CURR.PHONE_WORK_PARENT_ID
  , CURR.PHONE_WORK_LAST_UPDATE_DATE
  , CURR.PHONE_WORK_DATE_FROM
  , CURR.PHONE_WORK_DATE_TO
  , CURR.PHONE_FAX
  , CURR.PHONE_FAX_PHONE_ID
  , CURR.PHONE_FAX_PARENT_ID
  , CURR.PHONE_FAX_LAST_UPDATE_DATE
  , CURR.PHONE_FAX_DATE_FROM
  , CURR.PHONE_FAX_DATE_TO
  , CURR.PHONE_MOBILE
  , CURR.PHONE_MOBILE_PHONE_ID
  , CURR.PHONE_MOBILE_PARENT_ID
  , CURR.PHONE_MOBILE_LAST_UPDATE_DATE
  , CURR.PHONE_MOBILE_DATE_FROM
  , CURR.PHONE_MOBILE_DATE_TO
  , CURR.USER_NAME
-- PER_ASSIGNMENTS_X
  , CURR.ASSIGNMENT_ID
  , CURR.ORGANIZATION_ID
  , CURR.ORGANIZATION
  , CURR.JOB_ID
  , CURR.JOB_FAMILY
  , CURR.JOB_NAME
  , CURR.JOB_DEFINITION_ID
  , CURR.GRADE_ID
  , CURR.GRADE
  , CURR.LOCATION_ID
  , CURR.LOCATION
  , CURR.COUNTRY
  , CURR.ASSIGNMENT_MEANING
  , CURR.ASSIGNMENT_CATEGORY
  , CURR.ASSIGNMENT_DESCRIPTION
  , CURR.ASSIGNMENT_STATUS_TYPE_ID
  , CURR.USER_STATUS
  , CURR.SUP_PERSON_ID
  , CURR.SUP_EMPLOYEE_NUMBER
  , CURR.SUP_FULL_NAME
  , CURR.CODE_COMBINATION_ID
  , CURR.EXPENSE_ACCOUNT
  , CURR.COST_ALLOCATION_KEYFLEX_ID
  , CURR.COST_ACCOUNT
--
  , CURR.HOURLY_SALARIED_CODE
  , CURR.SOFT_CODING_KEYFLEX_ID
  , CURR.PAYROLL_ID
  , CURR.PAYROLL_NAME
  , CURR.PAY_BASIS_ID
  , CURR.SALARY_PAY_BASIS
  , CURR.SET_OF_BOOKS_ID
  , CURR.LEDGER
  , CURR.ACTUAL_TERM_DATE
  , CURR.LEAVING_REASON
  , CURR.TERM_REASON
  , CURR.LAST_WORKING_DAY
  , CURR.ASS_ATTRIBUTE_CATEGORY
  , CURR.ASS_ATTRIBUTE1
  , CURR.ASS_ATTRIBUTE7
  , CURR.ASS_ATTRIBUTE8
  , CURR.POSITION_NAME
  , CURR.POSITION_GENERIC_TITLE
  , CURR.EMAIL_ADDRESS
  , CURR.PPX_OBJECT_VERSION_NUMBER
  , CURR.PPX_EFFECTIVE_START_DATE
  , CURR.PPX_EFFECTIVE_END_DATE
  , CURR.PPX_LAST_UPDATE_DATE
  , CURR.PAX_OBJECT_VERSION_NUMBER
  , CURR.PAX_EFFECTIVE_START_DATE
  , CURR.PAX_EFFECTIVE_END_DATE
  , CURR.PAX_LAST_UPDATE_DATE
  , CURR.USER_PERSON_TYPE
  , CURR.VENDOR
FROM
    APPS.XXHA_WD_EMPLOYEE_V CURR
WHERE
    CURR.PERSON_ID = c_PERSON_ID
;

-- Retrieve data in APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0111 (c_PERSON_ID APPS.PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    CURR.CODE_COMBINATION_ID
  , CURR.EXPENSE_ACCOUNT
  , CURR.COST_ALLOCATION_KEYFLEX_ID
  , CURR.COST_ACCOUNT
FROM
    APPS.XXHA_WD_EMPLOYEE_V CURR
WHERE 
    CURR.PERSON_ID = c_PERSON_ID
;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP
CURSOR cur_0130 (c_ATTRIBUTE_CATEGORY HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_CATEGORY%TYPE
                ,c_ATTRIBUTE_WD1      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD1%TYPE
                ,c_ATTRIBUTE_WD2      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD2%TYPE)
IS
SELECT
    maps.ATTRIBUTE_ORACLE1
  , maps.ATTRIBUTE_ORACLE2
FROM
    HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP maps
WHERE
    maps.ATTRIBUTE_CATEGORY        = c_ATTRIBUTE_CATEGORY
AND maps.ATTRIBUTE_WD1             = NVL(c_ATTRIBUTE_WD1,'XXX')
AND NVL(maps.ATTRIBUTE_WD2,'XXX')  = NVL(c_ATTRIBUTE_WD2,'XXX')
;

-- Verify LOCATION_CODE
CURSOR cur_0200 (c_location_ID APPS.HR_LOCATIONS_V.LOCATION_ID%TYPE)
IS
SELECT
    NVL(COUNT(*),0)
FROM 
    APPS.HR_LOCATIONS_V       hlv
WHERE 
    hlv.location_id         = NVL(c_location_ID, -9999)
;

-- Retrieve business_group_id, business_group_name and location_id from LOCATION_ID
CURSOR cur_0300 (c_LOCATION APPS.HR_LOCATIONS_V.LOCATION_ID%TYPE)
IS
SELECT
    bg.business_group_id
  , bg.name
  , hlv.country
  , hlv.location_id
FROM 
    APPS.HR_LOCATIONS_V       hlv
  , APPS.PER_BUSINESS_GROUPS  bg
WHERE 
    bg.name                 = hlv.attribute6
AND hlv.LOCATION_ID         = c_LOCATION
;

-- Retrieve PERSON_TYPE_ID
CURSOR cur_0400 (c_business_group_id APPS.per_business_groups.business_group_id%TYPE
                ,c_USER_PERSON_TYPE  APPS.PER_PERSON_TYPES.USER_PERSON_TYPE%TYPE)
IS
SELECT 
    PT.PERSON_TYPE_ID
FROM 
    APPS.PER_PERSON_TYPES   PT
WHERE
    PT.USER_PERSON_TYPE   = c_USER_PERSON_TYPE
AND pt.BUSINESS_GROUP_ID  = c_business_group_id
AND PT.ACTIVE_FLAG        = 'Y'
;

-- Retrieve Organization_ID
CURSOR cur_0500 (c_business_group_id APPS.HR_ALL_ORGANIZATION_UNITS.business_group_id%TYPE
                ,c_ORGANIZATION      APPS.HR_ALL_ORGANIZATION_UNITS.name%TYPE)
IS
SELECT
    hou.Organization_ID
FROM 
    APPS.HR_ALL_ORGANIZATION_UNITS hou
WHERE
    hou.location_ID              IS NULL
AND hou.BUSINESS_GROUP_ID        = c_business_group_id
AND hou.name                     = c_ORGANIZATION
; 

-- Retrieve ASSIGNMENT_DESCRIPTION and ASSIGNMENT_CATEGORY
CURSOR cur_0600 (c_lookup_Code APPS.hr_lookups.lookup_Code%TYPE)
IS
SELECT 
    hrl.lookup_Code
  , hrl.MEANING
FROM 
    APPS.HR_LOOKUPS       hrl 
WHERE 
    hrl.lookup_type(+)  = 'EMP_CAT' 
AND hrl.Enabled_Flag    = 'Y' 
AND TRUNC(SYSDATE)      BETWEEN NVL(TRUNC(hrl.START_DATE_ACTIVE), TRUNC(SYSDATE)-1) AND NVL(TRUNC(hrl.END_DATE_ACTIVE), TRUNC(SYSDATE)+1) 
AND hrl.lookup_Code       = c_lookup_Code
;

-- Retrieve ASSIGNMENT_ID 
CURSOR cur_0700 (c_Person_id APPS.per_people_x.Person_id%TYPE)
IS
SELECT
    PAX.assignment_id 
FROM
    APPS.PER_PEOPLE_X        PPX
  , APPS.PER_ASSIGNMENTS_X   PAX
WHERE
    PPX.PERSON_ID          = PAX.PERSON_ID
AND PPX.PERSON_ID          = c_Person_id
;

-- Retrieve COST_ACCOUNT
CURSOR cur_0800 (c_ACCOUNT VARCHAR2)
IS
SELECT
    GLCC.CODE_COMBINATION_ID
FROM 
    APPS.XXHA_WD_EMPLOYEE_COST_V GLCC
WHERE 1=1
AND GLCC.segment1 || '.' || GLCC.segment3 || '.' || GLCC.segment4 || '.' || GLCC.segment5 || '.' || GLCC.segment6 = c_ACCOUNT
;

-- Retrieve CODE_COMBINATION_ID
CURSOR cur_0900 (c_ACCOUNT VARCHAR2)
IS
SELECT
    GLCC.CODE_COMBINATION_ID
FROM 
    APPS.XXHA_WD_EMPLOYEE_EXP_V GLCC
WHERE 1=1
AND GLCC.segment1 || '.' || GLCC.segment2 || '.' || GLCC.segment3 || '.' || GLCC.segment4 || '.' || GLCC.segment5 || '.' || GLCC.segment6 || '.' || GLCC.segment7 || '.' || GLCC.segment8 || '.' || GLCC.segment9 = c_ACCOUNT
;

-- Retrieve EXPENSE_ACCOUNT
CURSOR cur_0901 (c_CODE_COMBINATION_ID APPS.GL_CODE_COMBINATIONS.CODE_COMBINATION_ID%TYPE)
IS
SELECT
    GLCC.segment1 || '.' || GLCC.segment2 || '.' || GLCC.segment3 || '.' || GLCC.segment4 || '.' || GLCC.segment5 || '.' || GLCC.segment6 || '.' || GLCC.segment7 || '.' || GLCC.segment8 || '.' || GLCC.segment9
FROM 
    APPS.GL_CODE_COMBINATIONS   GLCC
WHERE
    GLCC.enabled_flag         = 'Y'
AND GLCC.CODE_COMBINATION_ID  = c_CODE_COMBINATION_ID
;

-- Retrieve GRADE_ID
CURSOR cur_1000 (c_GRADE             APPS.per_grades.NAME%TYPE
                ,c_business_group_id APPS.HR_ALL_ORGANIZATION_UNITS.business_group_id%TYPE)
IS
SELECT
    pg.GRADE_ID
FROM
    APPS.PER_GRADES         pg 
WHERE 
    pg.NAME               = c_GRADE
AND pg.Business_Group_ID  = c_business_group_id
AND TRUNC(SYSDATE)        BETWEEN NVL(pg.DATE_FROM,TRUNC(SYSDATE)-1) AND NVL(pg.DATE_TO,TRUNC(SYSDATE)+1)
;

-- Retrieve JOB_ID and JOB_DEFINITION_ID
CURSOR cur_1100 (c_NAME              APPS.per_jobs.NAME%TYPE
                ,c_business_group_id APPS.HR_ALL_ORGANIZATION_UNITS.business_group_id%TYPE)
IS
SELECT
    pj.JOB_ID 
  , pj.JOB_DEFINITION_ID
FROM
    APPS.PER_JOBS          pj 
WHERE 
    pj.NAME              = c_NAME
AND pj.BUSINESS_GROUP_ID = c_BUSINESS_GROUP_ID
AND TRUNC(SYSDATE)       BETWEEN NVL(pj.DATE_FROM,TRUNC(SYSDATE)-1) AND NVL(pj.DATE_TO,TRUNC(SYSDATE)+1)
;

-- Retrieve MAX(pj.JOB_ID) to retrieve the most recent job created in Oracle that matches the fuzzy search
CURSOR cur_1101 (c_NAME              APPS.per_jobs.NAME%TYPE
                ,c_business_group_id APPS.HR_ALL_ORGANIZATION_UNITS.business_group_id%TYPE)
IS
SELECT
    NVL(MAX(pj.JOB_ID), -99999)
FROM
    APPS.PER_JOBS          pj 
WHERE 
    pj.NAME              LIKE (c_NAME || '.%')
AND pj.BUSINESS_GROUP_ID = c_BUSINESS_GROUP_ID
AND TRUNC(SYSDATE)        BETWEEN NVL(pj.DATE_FROM,TRUNC(SYSDATE)-1) AND NVL(pj.DATE_TO,TRUNC(SYSDATE)+1)
;

-- Retrieve JOB_NAME and JOB_DEFINITION_ID
CURSOR cur_1102 (c_JOB_ID            APPS.per_jobs.JOB_ID%TYPE
                ,c_business_group_id APPS.HR_ALL_ORGANIZATION_UNITS.business_group_id%TYPE)
IS
SELECT
    pj.NAME
  , pj.JOB_DEFINITION_ID
FROM
    APPS.PER_JOBS          pj 
WHERE 
    pj.JOB_ID            = c_JOB_ID
AND pj.BUSINESS_GROUP_ID = c_BUSINESS_GROUP_ID
AND TRUNC(SYSDATE)       BETWEEN NVL(pj.DATE_FROM,TRUNC(SYSDATE)-1) AND NVL(pj.DATE_TO,TRUNC(SYSDATE)+1)
;

-- Retrieve LEAVE_REASON_CODE
CURSOR cur_1200 (c_LEAVE_REASON APPS.hr_lookups.LOOKUP_CODE%TYPE)               -- 2018/05/03 - changed from 'hr_lookups.Meaning%TYPE' to 'hr_lookups.LOOKUP_CODE%TYPE'
IS
SELECT 
    hrl.LOOKUP_CODE
FROM
    APPS.HR_LOOKUPS     hrl 
WHERE 
    hrl.lookup_type   = 'LEAV_REAS' 
AND hrl.LOOKUP_CODE   = c_LEAVE_REASON                                          -- 2018/05/03 - changed from 'hrl.Meaning' to 'hrl.LOOKUP_CODE'
;

-- Verify COUNTRY
CURSOR cur_1300 (c_COUNTRY APPS.FND_TERRITORIES_VL.TERRITORY_SHORT_NAME%TYPE)
IS
SELECT
    NVL(COUNT(*),0)
FROM
    APPS.FND_TERRITORIES_VL terr
WHERE 
    terr.TERRITORY_CODE   = c_COUNTRY
;

-- Verify EMPLOYEE_EXISTS/SUPERVISOR_EXISTS (Combination of Person_id and Employee_Number)
CURSOR cur_1400 (c_Person_id       APPS.per_people_x.Person_id%TYPE
                ,c_Employee_Number APPS.per_people_x.Employee_Number%TYPE)
IS
SELECT
    NVL(COUNT(*),0)
FROM
    APPS.PER_PEOPLE_X     PPX
WHERE
    PPX.PERSON_ID       = c_Person_id
AND PPX.EMPLOYEE_NUMBER = c_Employee_Number
;

-- Retrieve USER_STATUS_ID
CURSOR cur_1500 (c_USER_STATUS       APPS.per_assignment_status_types.User_Status%TYPE
                ,c_business_group_id APPS.HR_ALL_ORGANIZATION_UNITS.business_group_id%TYPE)
IS
SELECT
    ast.ASSIGNMENT_STATUS_TYPE_ID
FROM
    APPS.PER_ASSIGNMENT_STATUS_TYPES ast
WHERE
    ast.User_Status                                = c_USER_STATUS
AND NVL(ast.business_group_id,c_BUSINESS_GROUP_ID) = c_BUSINESS_GROUP_ID
;

-- Retrieve TITLE Code
CURSOR cur_1600 (c_lookup_code APPS.hr_standard_lookups.lookup_code%TYPE)
IS
SELECT
    hrl.lookup_code
FROM
    apps.hr_standard_lookups hrl
WHERE
    hrl.lookup_type        = 'TITLE'
AND hrl.lookup_code        = c_lookup_code
;

-- Retrieve data in table HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_1700 (c_WD_RECORD_ID HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE)
IS
SELECT
    chg.JOB_ID
,   chg.GRADE_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES CHG
WHERE
    CHG.WD_RECORD_ID             = c_WD_RECORD_ID
;

BEGIN

   -- Record Start Date of Processing
   l_Process_Start_Date := SYSDATE;
   UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
      SET XXHA.PROCESSED_START_DATE = l_Process_Start_Date;
   COMMIT;

--------------------------------------------------------------------------------
-- Ensure WD_RECORD_ID contains a value and that the value is unique
-- If error then abort processing without going further on.
--------------------------------------------------------------------------------

   -- Initialize Values
   l_Count   := 0;
   l_errcode := NULL;

   -- WD_RECORD_ID must contain a value
   BEGIN
      SELECT COUNT(*)
        INTO l_Count
        FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES
       WHERE WD_RECORD_ID IS NULL;
   EXCEPTION
        WHEN NO_DATA_FOUND THEN
             l_Count := 0;
   END;

   BEGIN
      IF NVL(l_Count,0) > 0 THEN
         l_errcode := 'WD_RECORD_ID in table ''HAEMO.XXHA_WD_EMPLOYEE_CHANGES'' is null - Abnormal End';
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_errcode);
         RAISE l_EXCEPTION;
      END IF;
   EXCEPTION
        WHEN OTHERS THEN
             errcode := l_errcode;
             RETURN;
   END;

   -- Initialize Values
   l_Count        := 0;
   l_errcode      := NULL;
   l_WD_RECORD_ID := 0;

   -- WD_RECORD_ID must be unique
   BEGIN
      SELECT DISTINCT WD_RECORD_ID, COUNT(*)
        INTO l_WD_RECORD_ID, l_Count
        FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES
       GROUP BY
             WD_RECORD_ID
      HAVING COUNT(*) > 1;
   EXCEPTION
        WHEN NO_DATA_FOUND THEN
             l_Count := 0;
   END;

   BEGIN
      IF NVL(l_Count,0) > 0 THEN
         l_errcode := 'WD_RECORD_ID in table ''HAEMO.XXHA_WD_EMPLOYEE_CHANGES'' must be unique - Abnormal End';
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_errcode);
         RAISE l_EXCEPTION;
      END IF;
   EXCEPTION
        WHEN OTHERS THEN
             errcode := l_errcode;
             RETURN;
   END;

--------------------------------------------------------------------------------
-- Before anything, Retrieve BUSINESS_GROUP_ID, BUSINESS_GROUP_NAME and 
-- BUSINESS_GROUP_COUNTRY_CODE from LOCATION (which is the Oracle Location ID that WD sends)
-- We will also create Jobs in Oracle if a Job was created in Workday and does not exist in Oracle
-- This data is critical for retrieving future data
--------------------------------------------------------------------------------

   -- Initialize Value
   l_Status := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   FOR dta0100 IN cur_0100 (l_Status)
   LOOP

      -- Initialize Values
      l_business_group_id    := NULL;
      l_bg_name              := NULL;
      l_organization_country := NULL;
      l_location_id          := NULL;
      l_Value_Out            := NULL;

      -- Retrieve BUSINESS_GROUP_ID, BUSINESS_GROUP_NAME and BUSINESS_GROUP_COUNTRY_CODE from LOCATION (which is the Oracle Location ID that WD sends)
      -- Code placed here as we need these values to be populated to check for unallowed transactions
      BEGIN
         XXHA_CHECK_FOR_NON_NUMERIC(dta0100.LOCATION, l_Value_Out);
         -- Check to see if dta0100.LOCATION contains characters.  If not, proceed with retrieve
         IF l_Value_Out = 'Valid' THEN
              OPEN cur_0300(dta0100.LOCATION);
             FETCH cur_0300 INTO l_business_group_id, l_bg_name, l_organization_country, l_location_id;
                IF cur_0300%FOUND THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.BUSINESS_GROUP_ID           = l_business_group_id
                 , XXHA.BUSINESS_GROUP              = l_bg_name
                 , XXHA.BUSINESS_GROUP_COUNTRY_CODE = l_organization_country
                 , XXHA.LOCATION_ID                 = l_location_id
             WHERE XXHA.WD_RECORD_ID                = dta0100.WD_RECORD_ID;
            COMMIT;
               END IF;
             CLOSE cur_0300;
         END IF;
      END;

      -- Initialize Value
      l_LENGTH               := 0;
      l_organization_country := NULL;

      -- Determine BUSINESS_GROUP_COUNTRY_CODE from BUSINESS_GROUP 
      IF l_Value_Out = 'Valid' THEN
         -- Determine where the first decimanl underscore ('_') occurs in l_bg_name
         l_LENGTH := (instr(l_bg_name,'_',1,1));
         -- Retrieve from first character to where underscore ('_') occurs
         l_organization_country := SUBSTR(l_bg_name,(l_LENGTH+1),5);
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.BUSINESS_GROUP_COUNTRY_CODE = l_organization_country
          WHERE XXHA.WD_RECORD_ID                = dta0100.WD_RECORD_ID;
         COMMIT;       
      END IF;

      l_GRADE_ORACLE := NULL;
      -- Translate Grade
      IF SUBSTR(dta0100.GRADE,4,1) = 'H' THEN 
         l_GRADE_ORACLE := SUBSTR(dta0100.GRADE,1,2) || '.' || l_organization_country || 'N-N';
      ELSIF SUBSTR(dta0100.GRADE,4,1) = 'S' THEN 
         l_GRADE_ORACLE := SUBSTR(dta0100.GRADE,1,2) || '.' || l_organization_country || '-S';
      ELSE 
         l_GRADE_ORACLE := SUBSTR(dta0100.GRADE,1,2) || '.' || l_organization_country || '-N';
      END IF;

      -- Even though no period was in the last position of the Oracle Grade Name when created programmatically, 
      -- it will be created with the period in the last position so we need to account for that when processing and retrieving
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
         SET XXHA.GRADE_ORACLE = l_GRADE_ORACLE
       WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
      COMMIT;

   END LOOP;

   COMMIT;

--------------------------------------------------------------------------------
-- Convert Dates
--------------------------------------------------------------------------------

   -- Initialize Value
   l_Status    := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   FOR dta0100 IN cur_0100 (l_Status)
   LOOP

      -- Initialize Value
      l_ERROR_MSG := NULL;

      -- Convert ORIGINAL_DATE_OF_HIRE_CHAR to Oracle format
      BEGIN
         IF dta0100.ORIGINAL_DATE_OF_HIRE_CHAR IS NOT NULL THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES xxha
               SET xxha.ORIGINAL_DATE_OF_HIRE = TO_DATE(dta0100.ORIGINAL_DATE_OF_HIRE_CHAR,'YYYY-MM-DD')
             WHERE XXHA.WD_RECORD_ID          = dta0100.WD_RECORD_ID;
            COMMIT;
         ELSE
            l_ERROR_MSG := l_ERROR_MSG || ('ORIGINAL_DATE_OF_HIRE is NULL.' || ' / ');
         END IF;
      END;

      -- Convert START_DATE_CHAR to Oracle format
      BEGIN
         IF dta0100.START_DATE_CHAR IS NOT NULL THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES xxha
               SET xxha.START_DATE   = TO_DATE(dta0100.START_DATE_CHAR,'YYYY-MM-DD')
             WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
            COMMIT;
         ELSE
            l_ERROR_MSG := l_ERROR_MSG || ('START_DATE is NULL.' || ' / ');
         END IF;
      END;

      -- Convert CONTRACT_END_DATE_CHAR to Oracle format
      BEGIN
         IF dta0100.CONTRACT_END_DATE_CHAR IS NOT NULL THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES xxha
               SET xxha.CONTRACT_END_DATE = TO_DATE(dta0100.CONTRACT_END_DATE_CHAR,'YYYY-MM-DD')
             WHERE XXHA.WD_RECORD_ID          = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;
      END;

      -- Convert LAST_DAY_WORKED_CHAR to Oracle format (not a required field)
      BEGIN
         IF dta0100.LAST_DAY_WORKED_CHAR IS NOT NULL THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES xxha
               SET xxha.LAST_DAY_WORKED = TO_DATE(dta0100.LAST_DAY_WORKED_CHAR,'YYYY-MM-DD')
             WHERE XXHA.WD_RECORD_ID    = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;
      END;

      -- Perform update to HAEMO.XXHA_WD_EMPLOYEE_CHANGES if Errors were discovered
      IF l_ERROR_MSG IS NOT NULL THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_ERROR_MSG
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
         COMMIT;
      END IF;

   END LOOP;

   COMMIT;

--------------------------------------------------------------------------------
-- Catch any transactions not allowed via Workday to Oracle Interface
--------------------------------------------------------------------------------

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   FOR dta0080 IN cur_0080
   LOOP

      -- Initialize value
      l_ERROR_MSG         := NULL;

      -- cur_0080 retrieves both Current and Change Employee Data by linking with PERSON_ID
      -- If Employee Numbers do not match, call out error
      IF dta0080.CHG_EMPLOYEE_NUMBER <> dta0080.CURR_EMPLOYEE_NUMBER THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Current Employee Number: ' || dta0080.CURR_EMPLOYEE_NUMBER || ' and Change Employee Number: ' ||  dta0080.CHG_EMPLOYEE_NUMBER || ' do not match in Oracle for PERSON_ID: ' || dta0080.PERSON_ID || ' / ');
      END IF;

      -- Changes are not allowed for Terminated Employees (CURR_USER_PERSON_TYPE like 'Ex-%' or like 'HAE Ex-%')
      IF (dta0080.CURR_USER_PERSON_TYPE LIKE 'Ex-%') OR (dta0080.CURR_USER_PERSON_TYPE LIKE 'HAE Ex-%') THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Changes are not allowed for Terminated Employees. Oracle Person Type: ' || dta0080.CURR_USER_PERSON_TYPE || '.' || ' / ');
      END IF;

      -- Changes are not allowed for Terminated Employees (nor Future Terminated)
      IF SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE), dta0080.PERSON_ID)),1,8) IN ('EMPLOYEE','HAE CONT') THEN
         IF SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE((TRUNC(SYSDATE)+365), dta0080.PERSON_ID)),1,8) IN ('EX-EMPLO','HAE EX-C') THEN
            l_ERROR_MSG := l_ERROR_MSG || ('Changes are not allowed for Future Terminated Employees.' || ' / ');
         END IF;
      END IF;

      -- Ensure that Supervisor is an Employee
      IF SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE), dta0080.SUP_PERSON_ID)),1,8) NOT IN ('EMPLOYEE','HAE CONT') THEN
            l_ERROR_MSG := l_ERROR_MSG || ('Supervisor: ' || dta0080.SUP_EMPLOYEE_NUMBER || ' is required to be an employee.  Oracle Person Type: ' || (HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(TRUNC(SYSDATE), dta0080.SUP_PERSON_ID)) || '.' || ' / ');
      END IF;

      -- Change in Business Group is not allowed
      IF (dta0080.CURR_BG_GROUP_ID <> dta0080.CHG_BG_GROUP_ID) THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Change in Business Group from: ' || dta0080.CURR_BG_GROUP_ID || ' to: ' || dta0080.CHG_BG_GROUP_ID || ' is not allowed.' || ' / ');
      END IF;

      -- Translate PERSON_TYPE_WD/TIME_TYPE_WD to PERSON_TYPE/ASSIGNMENT_CATEGORY
      l_ATTRIBUTE_ORACLE1 := NULL;
      l_ATTRIBUTE_ORACLE2 := NULL;
      BEGIN
           OPEN cur_0130('PERSON_ASSIGNMENT', dta0080.CHG_PERSON_TYPE_WD, dta0080.CHG_TIME_TYPE_WD);
          FETCH cur_0130 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
             IF cur_0130%NOTFOUND THEN
                l_ERROR_MSG := l_ERROR_MSG || ('Person Type (Worker Type)/Time Type: ' || dta0080.CHG_PERSON_TYPE_WD || '/' || dta0080.CHG_TIME_TYPE_WD || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ');
           ELSE
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.PERSON_TYPE         = l_ATTRIBUTE_ORACLE1
              , XXHA.ASSIGNMENT_CATEGORY = l_ATTRIBUTE_ORACLE2
          WHERE XXHA.WD_RECORD_ID        = dta0080.WD_RECORD_ID;
         COMMIT;
            END IF;
          CLOSE cur_0130;
      END;

      -- Change in Employee Type is not allowed (I.E. 'Employee to CWK' or 'CWK to Employee')
      IF (dta0080.CURR_USER_PERSON_TYPE = 'Employee') AND (dta0080.CHG_PERSON_TYPE = 'HAE Contingent Worker') OR
         (dta0080.CURR_USER_PERSON_TYPE = 'HAE Contingent Worker') AND (dta0080.CHG_PERSON_TYPE = 'Employee') THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Change in Employee Type is not allowed. i.e. Employee to CWK or CWK to Employee.' || ' / ');
      END IF;

      -- Check to ensure PERSON_ID is not NULL as this is the key to Oracle HR records
      IF dta0080.PERSON_ID IS NULL THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Person ID is NULL.' || ' / ');
      END IF;

      -- Perform update to HAEMO.XXHA_WD_EMPLOYEE_CHANGES if Errors were discovered
      IF l_ERROR_MSG IS NOT NULL THEN
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = dta0080.WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = (l_STATUS_MESSAGE || l_ERROR_MSG)             -- 2018/05/15
--            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_ERROR_MSG || ' / ')  -- 2018/05/15
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = dta0080.WD_RECORD_ID;
         COMMIT;
      END IF;

   END LOOP;

   COMMIT;

--------------------------------------------------------------------------------
-- Translate values from Workday to Oracle to validate required values
-- At this point, we are omitting any other failures that occurred as those are 
-- considered 'hard' errors that won't benefit from any additional editing.
--
-- Only Process if there were no errors (XXHA.STATUS IS NULL)
--
--------------------------------------------------------------------------------

   -- Initialize Value
   l_Status := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   FOR dta0100 IN cur_0100 (l_Status)
   LOOP

      -- Initialize value
      l_ERROR_MSG := NULL;

      -- Last Day Worked is required if we are terminating an employee
      IF (dta0100.USER_STATUS = 'Terminate Assignment') AND (dta0100.LAST_DAY_WORKED_CHAR IS NULL) THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Terminate Assignment requires a value in LAST_DAY_WORKED.' || ' / ');
      END IF;

      -- Audit BUSINESS_GROUP_ID
      IF dta0100.BUSINESS_GROUP_ID IS NULL THEN
         l_ERROR_MSG := l_ERROR_MSG || ('BUSINESS_GROUP_ID is NULL.' || ' / ');
      END IF;

      -- Initialize Value
      l_Value_Out := NULL;

      -- Check Location value for non-numeric values
      XXHA_CHECK_FOR_NON_NUMERIC(dta0100.LOCATION, l_Value_Out);

      -- Check to see if valid or not
      IF l_Value_Out = 'Invalid' THEN
         l_ERROR_MSG := l_ERROR_MSG || ('Location contains non-numeric value: ' || dta0100.LOCATION || ' / ');
      ELSE
         -- Translate LOCATION
         l_ATTRIBUTE_ORACLE1 := NULL;
         l_ATTRIBUTE_ORACLE2 := NULL;
         BEGIN
              OPEN cur_0130('LOCATION', dta0100.LOCATION, NULL);
             FETCH cur_0130 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
                IF cur_0130%NOTFOUND THEN
                   l_ERROR_MSG := l_ERROR_MSG || ('Location: ' || dta0100.LOCATION || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ');
              ELSE
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.LOCATION_ID  = TO_NUMBER(l_ATTRIBUTE_ORACLE1)
             WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
            COMMIT;
               END IF;
             CLOSE cur_0130;
         END;
      END IF;

      -- Initialize Values
      l_ATTRIBUTE_ORACLE1 := NULL;
      l_ATTRIBUTE_ORACLE2 := NULL;

      -- Translate JOB FAMILY (only care if something found, not used in any processing)
      BEGIN
           OPEN cur_0130('JOB_FAMILY', dta0100.JOB_FAMILY, NULL);
          FETCH cur_0130 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
             IF cur_0130%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.JOB_FAMILY   = l_ATTRIBUTE_ORACLE1
          WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
         COMMIT;
            END IF;
          CLOSE cur_0130;
      END;

      -- Initialize Values
      l_ATTRIBUTE_ORACLE1 := NULL;
      l_ATTRIBUTE_ORACLE2 := NULL;

      -- Translate Leave Reason (not a required entry)
      BEGIN
         IF dta0100.LEAVE_REASON IS NOT NULL THEN
              OPEN cur_0130('LEAVE_REASON', dta0100.LEAVE_REASON, NULL);
             FETCH cur_0130 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
                IF cur_0130%NOTFOUND THEN
                   l_ERROR_MSG := l_ERROR_MSG || ('Leave Reason: ' || dta0100.LEAVE_REASON || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ');
              ELSE
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.LEAVE_REASON = l_ATTRIBUTE_ORACLE1
             WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
            COMMIT;
               END IF;
             CLOSE cur_0130;
         END IF;
      END;

      -- Initialize Values
      l_ATTRIBUTE_ORACLE1 := NULL; -- Title Value
      l_ATTRIBUTE_ORACLE2 := NULL; -- No value

      -- Translate Title (not a required entry for all Business Groups)
      BEGIN
         IF dta0100.TITLE IS NOT NULL THEN
            IF dta0100.COUNTRY NOT IN ('JP','KR') THEN   -- Japan and Korea have no Title
                 OPEN cur_0130('TITLE', dta0100.COUNTRY, dta0100.TITLE);
                FETCH cur_0130 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
                   IF cur_0130%NOTFOUND THEN
                      l_ERROR_MSG := l_ERROR_MSG || ('Title: ' || dta0100.TITLE || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ');
                 ELSE
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
                  SET XXHA.TITLE_CODE   = l_ATTRIBUTE_ORACLE1
                WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
               COMMIT;
                  END IF;
                CLOSE cur_0130;
            END IF;
         END IF;
      END;

      -- Initialize Values
      l_ATTRIBUTE_ORACLE1 := NULL;
      l_ATTRIBUTE_ORACLE2 := NULL;

      -- User Status
      BEGIN
           OPEN cur_0130('USER_STATUS', dta0100.USER_STATUS, NULL);
          FETCH cur_0130 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
             IF cur_0130%NOTFOUND THEN
                l_ERROR_MSG := l_ERROR_MSG || ('User Status: ' || dta0100.USER_STATUS || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ');
           ELSE
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.USER_STATUS  = l_ATTRIBUTE_ORACLE1
          WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
         COMMIT;
            END IF;
          CLOSE cur_0130;
      END;

      -- Initialize Values
      l_person_type_id := NULL;

      -- Retrieve PERSON_TYPE_ID
      BEGIN
           OPEN cur_0400(dta0100.BUSINESS_GROUP_ID, dta0100.PERSON_TYPE);
          FETCH cur_0400 INTO l_person_type_id;
             IF cur_0400%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.PERSON_TYPE_ID = l_person_type_id
          WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('PERSON_TYPE is Invalid: ' || dta0100.PERSON_TYPE || ' / ');
            END IF;
          CLOSE cur_0400;
      END;

      -- Initialize Values
      l_Organization_ID := NULL;

      -- Retrieve ORGANIZATION_ID
      BEGIN
           OPEN cur_0500(dta0100.BUSINESS_GROUP_ID, dta0100.ORGANIZATION);
          FETCH cur_0500 INTO l_Organization_ID;
             IF cur_0500%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.ORGANIZATION_ID = l_Organization_ID
          WHERE XXHA.WD_RECORD_ID    = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('BUSINESS_GROUP_ID/ORGANIZATION is Invalid: ' || dta0100.BUSINESS_GROUP_ID || '/' || dta0100.ORGANIZATION || ' / ');
            END IF;
          CLOSE cur_0500;
      END;

      -- Initialize Values
      l_ASSIGNMENT_CATEGORY    := NULL;
      l_ASSIGNMENT_DESCRIPTION := NULL;

      -- Retrieve ASSIGNMENT_CATEGORY and ASSIGNMENT_DESCRIPTION
      BEGIN
           OPEN cur_0600(dta0100.ASSIGNMENT_CATEGORY);                          --i.e. External Support Supplier
          FETCH cur_0600 INTO l_ASSIGNMENT_CATEGORY, l_ASSIGNMENT_DESCRIPTION;
             IF cur_0600%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.ASSIGNMENT_CATEGORY    = l_ASSIGNMENT_CATEGORY
              , XXHA.ASSIGNMENT_DESCRIPTION = l_ASSIGNMENT_DESCRIPTION
          WHERE XXHA.WD_RECORD_ID           = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('ASSIGNMENT_CATEGORY is Invalid: ' || dta0100.ASSIGNMENT_CATEGORY || ' / ');
            END IF;
          CLOSE cur_0600;
      END;

      -- Initialize Values
      l_ASSIGNMENT_ID := NULL;

      -- Retrieve ASSIGNMENT_ID 
      BEGIN
           OPEN cur_0700(dta0100.PERSON_ID);
          FETCH cur_0700 INTO l_ASSIGNMENT_ID;
             IF cur_0700%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.ASSIGNMENT_ID  = l_ASSIGNMENT_ID
          WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('No Assignment Record exists.' || ' / ');
            END IF;
          CLOSE cur_0700;
      END;

      -- Initialize Values
      l_C_CODE_COMBINATION_ID         := NULL;
      l_C_EXPENSE_ACCOUNT             := NULL;
      l_C_COST_ALLOCATION_KEYFLEX_ID  := NULL;
      l_C_COST_ACCOUNT                := NULL;
      l_COST_ALLOCATION_KEYFLEX_ID    := NULL;

      -- Retrieve Current Values for COST and EXPENSE so we can compare values so we save from retrieving if no change
      BEGIN
          OPEN cur_0111(dta0100.PERSON_ID);
         FETCH cur_0111 INTO l_C_CODE_COMBINATION_ID, l_C_EXPENSE_ACCOUNT, l_C_COST_ALLOCATION_KEYFLEX_ID, l_C_COST_ACCOUNT;
         CLOSE cur_0111;
      END;

      -- If Change COST_ACCOUNT <> Current COST_ACCOUNT, then retrieve COST_ALLOCATION_KEYFLEX_ID (this adds significant time to the processing)
      BEGIN
         IF NVL(dta0100.COST_ACCOUNT,'*-XXX-*') <> NVL(l_C_COST_ACCOUNT,'*-XXX-*') THEN
              OPEN cur_0800(dta0100.COST_ACCOUNT);
             FETCH cur_0800 INTO l_COST_ALLOCATION_KEYFLEX_ID;
                IF cur_0800%FOUND THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.COST_ALLOCATION_KEYFLEX_ID = l_COST_ALLOCATION_KEYFLEX_ID
             WHERE
                   XXHA.PERSON_ID                  = dta0100.PERSON_ID
               AND XXHA.WD_RECORD_ID               = dta0100.WD_RECORD_ID;
            COMMIT;
               END IF;
             CLOSE cur_0800;
         ELSE
                   l_COST_ALLOCATION_KEYFLEX_ID   := l_C_COST_ALLOCATION_KEYFLEX_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.COST_ALLOCATION_KEYFLEX_ID = l_COST_ALLOCATION_KEYFLEX_ID
             WHERE
                   XXHA.PERSON_ID                  = dta0100.PERSON_ID
               AND XXHA.WD_RECORD_ID               = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;
      END;

      -- Audit COST_ACCOUNT
      IF l_COST_ALLOCATION_KEYFLEX_ID IS NULL THEN
         -- HAE Contingent Workers who are 'Consultant','Ext Support Supplier-Fractional','External Support Supplier','Temporary Worker', do not require COST_ACCOUNT
         IF (dta0100.PERSON_TYPE = 'HAE Contingent Worker') AND (dta0100.Assignment_Description IN ('Consultant','Ext Support Supplier-Fractional','External Support Supplier','Temporary Worker')) THEN 
            NULL;
         ELSE
            l_ERROR_MSG := l_ERROR_MSG || ('COST_ACCOUNT is Invalid: ' || dta0100.COST_ACCOUNT || ' / l_COST_ALLOCATION_KEYFLEX_ID: ' || l_COST_ALLOCATION_KEYFLEX_ID || ' / ');
         END IF;
      END IF;

      -- Initialize Values
      l_CODE_COMBINATION_ID := NULL;

      -- If Change EXPENSE_ACCOUNT <> Current EXPENSE_ACCOUNT, then retrieve CODE_COMBINATION_ID (this adds significant time to the processing)
      BEGIN
         IF NVL(dta0100.EXPENSE_ACCOUNT,'*-XXX-*') <> NVL(l_C_EXPENSE_ACCOUNT,'*-XXX-*') THEN
              OPEN cur_0900(dta0100.EXPENSE_ACCOUNT);
             FETCH cur_0900 INTO l_CODE_COMBINATION_ID;
                IF cur_0900%FOUND THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.CODE_COMBINATION_ID = l_CODE_COMBINATION_ID
             WHERE XXHA.WD_RECORD_ID        = dta0100.WD_RECORD_ID;
               END IF;
            COMMIT;
             CLOSE cur_0900;
         ELSE
                   l_CODE_COMBINATION_ID   := l_C_CODE_COMBINATION_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.CODE_COMBINATION_ID = l_CODE_COMBINATION_ID
             WHERE XXHA.WD_RECORD_ID        = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;
      END;

      -- Audit EXPENSE_ACCOUNT
      IF l_CODE_COMBINATION_ID IS NULL THEN
         -- HAE Contingent Workers who are 'Consultant','Ext Support Supplier-Fractional','External Support Supplier','Temporary Worker', do not require EXPENSE_ACCOUNT
         IF (dta0100.PERSON_TYPE = 'HAE Contingent Worker') AND (dta0100.Assignment_Description IN ('Consultant','Ext Support Supplier-Fractional','External Support Supplier','Temporary Worker')) THEN 
            NULL;
         ELSE
            l_ERROR_MSG := l_ERROR_MSG || ('EXPENSE_ACCOUNT is Invalid: ' || dta0100.EXPENSE_ACCOUNT || ' / l_CODE_COMBINATION_ID: ' || l_CODE_COMBINATION_ID || ' / ');
         END IF;
      END IF;

      -- Initialize Values
      l_LEAVE_REASON_CODE := NULL;

      -- Retrieve LEAVE_REASON_CODE
      BEGIN
         IF dta0100.LEAVE_REASON IS NOT NULL THEN
              OPEN cur_1200(dta0100.LEAVE_REASON);
             FETCH cur_1200 INTO l_LEAVE_REASON_CODE;
                IF cur_1200%FOUND THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.LEAVE_REASON_CODE = l_LEAVE_REASON_CODE
             WHERE XXHA.WD_RECORD_ID      = dta0100.WD_RECORD_ID;
            COMMIT;
              ELSE
                   l_ERROR_MSG := l_ERROR_MSG || ('LEAVE_REASON is Invalid: ' || dta0100.LEAVE_REASON || ' / ');
               END IF;
             CLOSE cur_1200;
         END IF;
      END;

      -- Initialize Values
      l_COUNTRY_EXISTS := NULL;
      l_Record_Count   := NULL;

      -- Verify COUNTRY
      BEGIN
           OPEN cur_1300(dta0100.COUNTRY);
          FETCH cur_1300 INTO l_Record_Count;
             IF l_Record_Count > 0 THEN 
                l_COUNTRY_EXISTS := 'Y';
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.COUNTRY_EXISTS = l_COUNTRY_EXISTS
          WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('COUNTRY is Invalid: ' || dta0100.COUNTRY || ' / ');
            END IF;
          CLOSE cur_1300;
      END;

      -- Initialize Values
      l_EMPLOYEE_EXISTS := NULL;
      l_Record_Count    := NULL;

      -- Verify EMPLOYEE_EXISTS (Combination of Person_id and Employee_Number)
      BEGIN
           OPEN cur_1400(dta0100.PERSON_ID, dta0100.EMPLOYEE_NUMBER);
          FETCH cur_1400 INTO l_Record_Count;
             IF l_Record_Count > 0 THEN 
                l_EMPLOYEE_EXISTS := 'Y';
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.EMPLOYEE_EXISTS = l_EMPLOYEE_EXISTS
          WHERE XXHA.WD_RECORD_ID    = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('EMPLOYEE_NUMBER/PERSON_ID is Invalid: ' || dta0100.EMPLOYEE_NUMBER || '/' || dta0100.PERSON_ID || ' / ');
            END IF;
          CLOSE cur_1400;
      END;

      -- Initialize Values
      l_SUPERVISOR_EXISTS := NULL;
      l_Record_Count      := NULL;

      -- Verify SUPERVISOR_EXISTS (Combination of Supervisor Person_id and Supervisor Employee_Number)
      BEGIN
           OPEN cur_1400(dta0100.SUP_PERSON_ID, dta0100.SUP_EMPLOYEE_NUMBER);
          FETCH cur_1400 INTO l_Record_Count;
             IF l_Record_Count > 0 THEN 
                l_SUPERVISOR_EXISTS   := 'Y'; 
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.SUPERVISOR_EXISTS = l_SUPERVISOR_EXISTS
          WHERE XXHA.WD_RECORD_ID      = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('SUPERVISOR EMPLOYEE_NUMBER/PERSON_ID is Invalid: ' || dta0100.SUP_EMPLOYEE_NUMBER || '/' || dta0100.SUP_PERSON_ID || ' / ');
            END IF;
          CLOSE cur_1400;
      END;

      -- Initialize Values
      l_ASSIGNMENT_STATUS_TYPE_ID := NULL;

      -- Retrieve USER_STATUS_ID
      BEGIN
           OPEN cur_1500(dta0100.USER_STATUS, dta0100.BUSINESS_GROUP_ID);
          FETCH cur_1500 INTO l_ASSIGNMENT_STATUS_TYPE_ID;
             IF cur_1500%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.ASSIGNMENT_STATUS_TYPE_ID = l_ASSIGNMENT_STATUS_TYPE_ID
          WHERE XXHA.WD_RECORD_ID              = dta0100.WD_RECORD_ID;
         COMMIT;
           ELSE
                l_ERROR_MSG := l_ERROR_MSG || ('USER_STATUS/BUSINESS_GROUP_ID is Invalid: ' || dta0100.USER_STATUS || '/' || dta0100.BUSINESS_GROUP_ID || ' / ');
            END IF;
          CLOSE cur_1500;
      END;

      -- Initialize Values
      l_TITLE_CODE_CHK := NULL;

      -- Retrieve TITLE (not a required field)
      BEGIN
         IF dta0100.TITLE_CODE IS NOT NULL THEN
              OPEN cur_1600(dta0100.TITLE_CODE);
             FETCH cur_1600 INTO l_TITLE_CODE_CHK;
                IF cur_1600%FOUND THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.TITLE_CODE     = l_TITLE_CODE_CHK
             WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
            COMMIT;
              ELSE
                   l_ERROR_MSG := l_ERROR_MSG || ('TITLE does not exist in Oracle: ' || dta0100.TITLE_CODE || ' / ');
               END IF;
             CLOSE cur_1600;
         END IF;
      END;

      -- Initialize Value
      l_LENGTH               := 0;

      -- Oracle doesn't like Job Names that contain a period ('.') because a Job in Oracle contains two segments (Job and HRTMS Code)
      -- When Oracle tries to process a Job Name that contains a period (i.e. Sr. Director, Strategic Operations and Support)
      -- the process believes that 'Sr' is the first segment and 'Director, Strategic Operations and Support' is the second segment
      -- This process will remove the period ('.') from the Job Name 
      l_LENGTH   := (INSTR(dta0100.JOB_NAME,'.', 1, 1));                        -- 2018/05/03 - new code
      IF l_LENGTH > 0 THEN                                                      -- 2018/05/03 - new code
         dta0100.JOB_NAME := REPLACE(dta0100.JOB_NAME,'.','');                  -- 2018/05/03 - new code
         COMMIT;                                                                -- 2018/05/03 - new code
      END IF;                                                                   -- 2018/05/03 - new code

      -- Perform update to HAEMO.XXHA_WD_EMPLOYEE_CHANGES if Errors were discovered
      BEGIN
         IF l_ERROR_MSG IS NOT NULL THEN
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = (l_STATUS_MESSAGE || l_ERROR_MSG)
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
            COMMIT;
         END IF;
      END;

   END LOOP;

   COMMIT;

--------------------------------------------------------------------------------
-- Only Process Grades and Jobs if there were no errors (XXHA.STATUS IS NULL)
--------------------------------------------------------------------------------

   -- Initialize Value
   l_Status := NULL;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   FOR dta0100 IN cur_0100 (l_Status)
   LOOP

      -- Initialize Values
      l_GRADE_ID := NULL;
      l_FOUND    := 'NO';

      -- Retrieve GRADE_ID
      BEGIN
           OPEN cur_1000((dta0100.GRADE_ORACLE||'.'), dta0100.BUSINESS_GROUP_ID);
          FETCH cur_1000 INTO l_GRADE_ID;
             IF cur_1000%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.GRADE_ID     = l_GRADE_ID
          WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
                l_FOUND          := 'YES';
         COMMIT;
            END IF;
          CLOSE cur_1000;
      END;

      -- Retrieve GRADE_ID without period ('.') at the end
      IF (NVL(l_FOUND, 'NO') = 'NO') THEN
         BEGIN
                   l_GRADE_ID := NULL;
              OPEN cur_1000(dta0100.GRADE_ORACLE, dta0100.BUSINESS_GROUP_ID);
             FETCH cur_1000 INTO l_GRADE_ID;
                IF cur_1000%FOUND THEN
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.GRADE_ID     = l_GRADE_ID
             WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
                   l_FOUND          := 'YES';
            COMMIT;
               END IF;
             CLOSE cur_1000;
         END;
      END IF;

      -- If Grade was not found, then we will create it
      -- Note that HAEMO.XXHA_WD_EMPLOYEE_CHANGES will be updated in XXHA_WD_EMPLOYEE_CREATE_GRADE
      BEGIN
         IF (NVL(l_FOUND, 'NO') = 'NO') THEN
            XXHA_WD_EMPLOYEE_CREATE_GRADE(dta0100.WD_RECORD_ID, dta0100.BUSINESS_GROUP_ID, dta0100.GRADE_ORACLE);
         END IF;
      END;

      -- Initialize Values
      l_JOB_ID            := NULL;
      l_JOB_DEFINITION_ID := NULL;
      l_CREATE_JOB        := 'NO';
      l_JOB_FOUND         := NULL;
      l_JOB_NAME_WD       := NULL;
      l_JOB_NAME_ORACLE   := NULL;

      -- Retrieve JOB_ID and JOB_DEFINITION_ID using JOB_NAME and BUSINESS_GROUP_ID.
      -- In this case JOB_NAME is the actual value passed from Workday (i.e. 'Accounts Payable Representative')
      BEGIN

         -- Determine if Job Name contains a period
         l_LENGTH   := (INSTR(dta0100.JOB_NAME,'.', 1, 1));                     -- 2018/05/03 - new code
         IF l_LENGTH > 0 THEN                                                   -- 2018/05/03 - new code
            l_JOB_NAME_WD := REPLACE(dta0100.JOB_NAME,'.','');                  -- 2018/05/03 - new code
            COMMIT;                                                             -- 2018/05/03 - new code
         ELSE
            l_JOB_NAME_WD := dta0100.JOB_NAME;                                  -- 2018/05/15 - new code
         END IF;                                                                -- 2018/05/03 - new code

         -- Initialize Values (Oracle Job requires two segments)                -- 2018/05/03 - Commented out code
         --l_JOB_NAME_WD       := dta0100.JOB_NAME;                             -- 2018/05/03 - Commented out code

         -- Find Job
           OPEN cur_1100(l_JOB_NAME_WD, dta0100.BUSINESS_GROUP_ID); 
          FETCH cur_1100 INTO l_JOB_ID, l_JOB_DEFINITION_ID;
             IF cur_1100%FOUND THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.JOB_NAME_ORACLE   = dta0100.JOB_NAME
              , XXHA.JOB_ID            = l_JOB_ID
              , XXHA.JOB_DEFINITION_ID = l_JOB_DEFINITION_ID
          WHERE XXHA.WD_RECORD_ID      = dta0100.WD_RECORD_ID;
                l_JOB_FOUND := 'YES';
           ELSE
                l_JOB_FOUND := 'NO';
            END IF;
          CLOSE cur_1100;
      END;

      -- In this case JOB_NAME is the actual value passed from Workday but performing a fuzzy search (i.e. 'Accounts Payable Representative.%')
      IF (NVL(l_JOB_FOUND, 'YES') = 'NO') THEN
      BEGIN

         -- Initialize Values
         l_JOB_ID            := NULL;
         l_JOB_NAME_ORACLE   := NULL;
         l_JOB_DEFINITION_ID := NULL;
         l_JOB_FOUND         := NULL;

          OPEN cur_1101(l_JOB_NAME_WD, dta0100.BUSINESS_GROUP_ID); 
         FETCH cur_1101 INTO l_JOB_ID;
            -- Will return -99999 if NotFound
            IF l_JOB_ID <> -99999 THEN
               -- JOB_NAME was found with the fuzzy search then we need to retrieve JOB_NAME and JOB_DEFINITION_ID info using l_JOB_ID and BUSINESS_GROUP_ID
               OPEN cur_1102(l_JOB_ID, dta0100.BUSINESS_GROUP_ID); 
              FETCH cur_1102 INTO l_JOB_NAME_ORACLE, l_JOB_DEFINITION_ID;
             UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
                SET XXHA.JOB_NAME_ORACLE   = l_JOB_NAME_ORACLE
                  , XXHA.JOB_ID            = l_JOB_ID
                  , XXHA.JOB_DEFINITION_ID = l_JOB_DEFINITION_ID
              WHERE XXHA.WD_RECORD_ID      = dta0100.WD_RECORD_ID;
                    l_JOB_FOUND := 'YES';
              CLOSE cur_1102;
            ELSE
                    l_JOB_FOUND := 'NO';
            END IF;
         CLOSE cur_1101;
      END;
      END IF;

      -- Initialize Values
      l_JOB_NAME_WD       := NULL;

      -- If JOB_NAME was not retrieved using the actual value passed from Workday (i.e. 'Accounts Payable Representative')
      -- and was not retrieved using the fuzzy search (i.e. 'Accounts Payable Representative.%')
      -- then we will need to create the JOB_NAME in Oracle
      IF (NVL(l_JOB_FOUND, 'YES') = 'NO') THEN
         BEGIN

            -- Initialize Value (Oracle Job requires two segments)
--            l_JOB_NAME_WD       := (dta0100.JOB_NAME);                        -- 2018/05/03 - Commented out code
--            l_JOB_NAME_WD       := (dta0100.JOB_NAME || '.Workday');          -- 2018/05/03 - Commented out code

            -- If Job Name contains a period, remove it
            l_LENGTH   := (INSTR(dta0100.JOB_NAME,'.', 1, 1));                  -- 2018/05/03 - new code
            IF l_LENGTH > 0 THEN                                                -- 2018/05/03 - new code
               l_JOB_NAME_WD := REPLACE(dta0100.JOB_NAME,'.','');               -- 2018/05/03 - new code
               COMMIT;                                                          -- 2018/05/03 - new code
            ELSE
            -- If Job Name doesn't contains a period, set to JOB_NAME
               l_JOB_NAME_WD := dta0100.JOB_NAME;                               -- 2018/05/15 - new code
            END IF;                                                             -- 2018/05/03 - new code

            -- Create Job from Workday in Oracle
            -- Note that HAEMO.XXHA_WD_EMPLOYEE_CHANGES will be updated in XXHA_WD_EMPLOYEE_CREATE_JOB 
            XXHA_WD_EMPLOYEE_CREATE_JOB(dta0100.WD_RECORD_ID, dta0100.BUSINESS_GROUP_ID, dta0100.EMPLOYEE_NUMBER, l_JOB_NAME_WD, dta0100.BUSINESS_GROUP_COUNTRY_CODE);

         END;
      END IF;

      -- Since we don't know if the Grade or the Job was created within this Package
      -- we need to retrieve GRADE_ID and GRADE_ID from the table, 'HAEMO.XXHA_WD_EMPLOYEE_CHANGES'
      BEGIN

         -- Initialize Values
         l_JOB_ID    := NULL;
         l_GRADE_ID  := NULL;

         -- Retrieve JOB_ID and GRADE_ID from the table, 'HAEMO.XXHA_WD_EMPLOYEE_CHANGES'
         OPEN cur_1700(dta0100.WD_RECORD_ID); 
         FETCH cur_1700 INTO l_JOB_ID, l_GRADE_ID;
         CLOSE cur_1700;

         -- Ensure that Grade is valid for the job by checking to see if a record exists in PER_VALID_GRADES
         -- for BUSINESS_GROUP_ID, GRADE_ID and JOB_ID.  If not found then it will be created in PER_VALID_GRADES
         XXHA_WD_EMPLOYEE_VALID_GRADES(dta0100.WD_RECORD_ID, dta0100.BUSINESS_GROUP_ID, l_GRADE_ID, l_JOB_ID);

      END;

   END LOOP;

   COMMIT;

   -- SET XXHA.STATUS for No Errors but only if not processed thru Terminations or Reverse Terminations
   UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
      SET XXHA.STATUS = 'PASS'
    WHERE XXHA.STATUS_MESSAGE IS NULL
      AND NVL(XXHA.STATUS, 'XXXXX') NOT IN ('FAIL_TERM','FAIL_RTERM','PROCESSED');                    -- New Code - 21-MAY-2018  

   -- Return the Process_Start_Date so it can be used to select records to backup (XXHA_BACKUP_DATA)
   p_Process_Start_Date := l_Process_Start_Date;

END;

END XXHA_PROCESS_EDITS;


--------------------------------------------------------------------------------
PROCEDURE XXHA_PROCESS_TERMINATIONS(
          errbuf                            OUT VARCHAR2
         ,errcode                           OUT VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables 
   l_Return                                 VARCHAR2(2000)                      := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;
   l_ERROR_MSG                              VARCHAR2(4000);                     -- New Code - 2018/05/15

   l_ATTRIBUTE_ORACLE1                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE1%TYPE;  -- New Code - 2018/05/15
   l_ATTRIBUTE_ORACLE2                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE2%TYPE;  -- New Code - 2018/05/15
   l_ASSIGNMENT_ID                          APPS.PER_ASSIGNMENTS_X.ASSIGNMENT_ID%TYPE;                -- New Code - 2018/05/15

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , USER_STATUS                                                                 -- 'Leave of Absence', 'Terminate Assignment', 'Active Assignment'
  , WD_RECORD_ID
  , LAST_DAY_WORKED                                                             -- New Code - 2018/05/15
  , LAST_DAY_WORKED_CHAR                                                        -- New Code - 2018/05/15
  , LEAVE_REASON                                                                -- New Code - 2018/05/15
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    NVL(STATUS,'PASS') = 'PASS'
ORDER BY
    WD_RECORD_ID ASC
;

-- Retrieve data in APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0200 (c_PERSON_ID PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , USER_STATUS
FROM
    APPS.XXHA_WD_EMPLOYEE_V VW
WHERE 1=1
AND PERSON_ID = c_PERSON_ID;


-- Retrieve ASSIGNMENT_ID 
CURSOR cur_0300 (c_Person_id APPS.per_people_x.Person_id%TYPE)
IS
SELECT
    PAX.assignment_id 
FROM
    APPS.PER_PEOPLE_X        PPX
  , APPS.PER_ASSIGNMENTS_X   PAX
WHERE
    PPX.PERSON_ID          = PAX.PERSON_ID
AND PPX.PERSON_ID          = c_Person_id
;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP
CURSOR cur_0400 (c_ATTRIBUTE_CATEGORY HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_CATEGORY%TYPE
                ,c_ATTRIBUTE_WD1      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD1%TYPE
                ,c_ATTRIBUTE_WD2      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_WD2%TYPE)
IS
SELECT
    maps.ATTRIBUTE_ORACLE1
  , maps.ATTRIBUTE_ORACLE2
FROM
    HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP maps
WHERE
    maps.ATTRIBUTE_CATEGORY        = c_ATTRIBUTE_CATEGORY
AND maps.ATTRIBUTE_WD1             = NVL(c_ATTRIBUTE_WD1,'XXX')
AND NVL(maps.ATTRIBUTE_WD2,'XXX')  = NVL(c_ATTRIBUTE_WD2,'XXX')
;

BEGIN

-- New Code Start - 2018/05/15

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES for Edits
   FOR dta0100 IN cur_0100
   LOOP

      -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)
      FOR dta0200 IN cur_0200(dta0100.PERSON_ID)
      LOOP

         -- Process Terminations
         IF (dta0100.USER_STATUS = 'Terminate Assignment') AND (dta0200.USER_STATUS = 'Active Assignment') THEN

            l_ERROR_MSG := NULL;

            -- Convert LAST_DAY_WORKED_CHAR to Oracle format (required field)
            BEGIN
               IF dta0100.LAST_DAY_WORKED_CHAR IS NOT NULL THEN
                  UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES xxha
                     SET xxha.LAST_DAY_WORKED = TO_DATE(dta0100.LAST_DAY_WORKED_CHAR,'YYYY-MM-DD')
                   WHERE XXHA.WD_RECORD_ID    = dta0100.WD_RECORD_ID;
                  COMMIT;
               ELSE
                  l_ERROR_MSG := l_ERROR_MSG || ('Terminate Assignment requires a value in LAST_DAY_WORKED.' || ' / ');
               END IF;
            END;

            -- Translate Leave Reason (not a required entry)
            BEGIN
               IF dta0100.LEAVE_REASON IS NOT NULL THEN
                    OPEN cur_0400('LEAVE_REASON', dta0100.LEAVE_REASON, NULL);
                   FETCH cur_0400 INTO l_ATTRIBUTE_ORACLE1, l_ATTRIBUTE_ORACLE2;
                      IF cur_0400%NOTFOUND THEN
                         l_ERROR_MSG := l_ERROR_MSG || ('Leave Reason: ' || dta0100.LEAVE_REASON || ' not in translation table, HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP' || ' / ');
                    ELSE
                  UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
                     SET XXHA.LEAVE_REASON = l_ATTRIBUTE_ORACLE1
                   WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
                  COMMIT;
                     END IF;
                   CLOSE cur_0400;
               END IF;
            END;

            -- Check to ensure PERSON_ID is not NULL as this is the key to Oracle HR records
            IF dta0100.PERSON_ID IS NULL THEN
               l_ERROR_MSG := l_ERROR_MSG || ('Person ID is NULL.' || ' / ');
            END IF;

            -- Initialize Values
            l_ASSIGNMENT_ID := NULL;

            -- Retrieve ASSIGNMENT_ID 
            BEGIN
                 OPEN cur_0300(dta0100.PERSON_ID);
                FETCH cur_0300 INTO l_ASSIGNMENT_ID;
                   IF cur_0300%FOUND THEN
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
                  SET XXHA.ASSIGNMENT_ID  = l_ASSIGNMENT_ID
                WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
               COMMIT;
                 ELSE
                      l_ERROR_MSG := l_ERROR_MSG || ('No Assignment Records exist.' || ' / ');
                  END IF;
                CLOSE cur_0300;
            END;

            IF SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE((TRUNC(SYSDATE)+365), dta0100.PERSON_ID)),1,8) IN ('EX-EMPLO','HAE EX-C') THEN
               l_ERROR_MSG := l_ERROR_MSG || ('The termination must not occur before any future changes for the person specified.' || ' / ');
            END IF;

            IF l_ERROR_MSG IS NOT NULL THEN
               l_STATUS_MESSAGE := NULL;
               SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = (l_STATUS_MESSAGE || l_ERROR_MSG)
                 , XXHA.STATUS         = 'FAIL_TERM'
               WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
               COMMIT;
            END IF;

         END IF; -- IF (dta0100.USER_STATUS = 'Terminate Assignment') AND (dta0200.USER_STATUS = 'Active Assignment') 

      END LOOP; -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)

   END LOOP; -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES

   COMMIT;

-- New Code End - 2018/05/15

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES (only where there were no errors (XXHA.STATUS = NULL))
   FOR dta0100 IN cur_0100
   LOOP

      -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)
      FOR dta0200 IN cur_0200(dta0100.PERSON_ID)
      LOOP

         -- Process Terminations
         IF (dta0100.USER_STATUS = 'Terminate Assignment') AND (dta0200.USER_STATUS = 'Active Assignment') THEN
            -- Ensure that there is no Future Termination for this employee
            IF SUBSTR(UPPER(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE((TRUNC(SYSDATE)+365), dta0100.PERSON_ID)),1,8) NOT IN ('EX-EMPLO','HAE EX-C') THEN
               XXHA_WD_EMPLOYEE_TERMINATE(dta0100.WD_RECORD_ID); 
            ELSE
               l_STATUS_MESSAGE := NULL;
               SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('The termination must not occur before any future changes for the person specified.' || ' / ')
                 , XXHA.STATUS         = 'FAIL'
               WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
               COMMIT;
            END IF;
         END IF;

      END LOOP; -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)

   END LOOP; -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES

   COMMIT;

END;

END XXHA_PROCESS_TERMINATIONS;


-- New Code Start - 2018/05/15
--------------------------------------------------------------------------------
PROCEDURE XXHA_PROCESS_REVERSE_TERMS(
          errbuf                            OUT VARCHAR2
         ,errcode                           OUT VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables 
   l_Return                                 VARCHAR2(2000)                      := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;
   l_ERROR_MSG                              VARCHAR2(4000);

   l_ATTRIBUTE_ORACLE1                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE1%TYPE;
   l_ATTRIBUTE_ORACLE2                      HAEMO.XXHA_WD_EMPLOYEE_VALUE_MAP.ATTRIBUTE_ORACLE2%TYPE;
   l_ASSIGNMENT_ID                          APPS.PER_ASSIGNMENTS_X.ASSIGNMENT_ID%TYPE;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , USER_STATUS                                                                 -- 'Leave of Absence', 'Terminate Assignment', 'Active Assignment'
  , WD_RECORD_ID
  , LAST_DAY_WORKED
  , LAST_DAY_WORKED_CHAR
  , LEAVE_REASON
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    NVL(STATUS,'PASS') = 'PASS'
ORDER BY
    WD_RECORD_ID ASC
;

-- Retrieve data in APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0200 (c_PERSON_ID PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , USER_STATUS
FROM
    APPS.XXHA_WD_EMPLOYEE_V VW
WHERE 1=1
AND PERSON_ID = c_PERSON_ID;


-- Retrieve ASSIGNMENT_ID 
CURSOR cur_0300 (c_Person_id APPS.per_people_x.Person_id%TYPE)
IS
SELECT
    PAX.assignment_id 
FROM
    APPS.PER_PEOPLE_X        PPX
  , APPS.PER_ASSIGNMENTS_X   PAX
WHERE
    PPX.PERSON_ID          = PAX.PERSON_ID
AND PPX.PERSON_ID          = c_Person_id
;

BEGIN

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES for Edits
   FOR dta0100 IN cur_0100
   LOOP

      -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)
      FOR dta0200 IN cur_0200(dta0100.PERSON_ID)
      LOOP

         -- Process Reverse Terminations  (User status in HAEMO.XXHA_WD_EMPLOYEE_CHANGES: 'Active Assignment' and Current User Status in Oracle: 'Terminate Assignment')
         IF (dta0100.USER_STATUS = 'Active Assignment') AND (dta0200.USER_STATUS = 'Terminate Assignment') THEN

            l_ERROR_MSG := NULL;

            -- Convert LAST_DAY_WORKED_CHAR to Oracle format (required field)
            BEGIN
               IF dta0100.LAST_DAY_WORKED_CHAR IS NOT NULL THEN
                  UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES xxha
                     SET xxha.LAST_DAY_WORKED = TO_DATE(dta0100.LAST_DAY_WORKED_CHAR,'YYYY-MM-DD')
                   WHERE XXHA.WD_RECORD_ID    = dta0100.WD_RECORD_ID;
                  COMMIT;
               ELSE
                  l_ERROR_MSG := l_ERROR_MSG || ('Reverse Termination requires a value in LAST_DAY_WORKED.' || ' / ');
               END IF;
            END;

            -- Check to ensure PERSON_ID is not NULL as this is the key to Oracle HR records
            IF dta0100.PERSON_ID IS NULL THEN
               l_ERROR_MSG := l_ERROR_MSG || ('Person ID is NULL.' || ' / ');
            END IF;

            -- Initialize Values
            l_ASSIGNMENT_ID := NULL;

            -- Retrieve ASSIGNMENT_ID 
            BEGIN
                 OPEN cur_0300(dta0100.PERSON_ID);
                FETCH cur_0300 INTO l_ASSIGNMENT_ID;
                   IF cur_0300%FOUND THEN
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
                  SET XXHA.ASSIGNMENT_ID  = l_ASSIGNMENT_ID
                WHERE XXHA.WD_RECORD_ID   = dta0100.WD_RECORD_ID;
               COMMIT;
                 ELSE
                      l_ERROR_MSG := l_ERROR_MSG || ('No Assignment Records exist.' || ' / ');
                  END IF;
                CLOSE cur_0300;
            END;

            IF l_ERROR_MSG IS NOT NULL THEN
               l_STATUS_MESSAGE := NULL;
               SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = dta0100.WD_RECORD_ID;
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = (l_STATUS_MESSAGE || l_ERROR_MSG)
                 , XXHA.STATUS         = 'FAIL_RTERM'
               WHERE XXHA.WD_RECORD_ID = dta0100.WD_RECORD_ID;
               COMMIT;
            END IF;

         END IF; -- IF (dta0100.USER_STATUS = 'Active Assignment') AND (dta0200.USER_STATUS = 'Terminate Assignment') 

      END LOOP; -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)

   END LOOP; -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES

   COMMIT;

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES (only where there were no errors (where XXHA.STATUS = NULL))
   FOR dta0100 IN cur_0100
   LOOP

      -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)
      FOR dta0200 IN cur_0200(dta0100.PERSON_ID)
      LOOP

         -- Process Reverse Terminations (User status in HAEMO.XXHA_WD_EMPLOYEE_CHANGES: 'Active Assignment' and Current User Status in Oracle: 'Terminate Assignment')
         IF (dta0100.USER_STATUS = 'Active Assignment') AND (dta0200.USER_STATUS = 'Terminate Assignment') THEN
            XXHA_WD_EMPLOYEE_REVERSE_TERM(dta0100.WD_RECORD_ID); 
         END IF;

      END LOOP; -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)

   END LOOP; -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES

   COMMIT;

END;

END XXHA_PROCESS_REVERSE_TERMS;
-- New Code End - 2018/05/15


--------------------------------------------------------------------------------
PROCEDURE XXHA_PROCESS_CHANGES(
          errbuf                            OUT VARCHAR2
         ,errcode                           OUT VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables 
   l_Record_Count                           NUMBER                              := NULL;
   l_Return                                 VARCHAR2(2000)                      := NULL;

   l_TITLE                                  APPS.XXHA_WD_EMPLOYEE_V.TITLE%TYPE;
   l_FIRST_NAME                             APPS.XXHA_WD_EMPLOYEE_V.FIRST_NAME%TYPE;
   l_MIDDLE_NAMES                           APPS.XXHA_WD_EMPLOYEE_V.MIDDLE_NAMES%TYPE;
   l_LAST_NAME                              APPS.XXHA_WD_EMPLOYEE_V.LAST_NAME%TYPE;
   l_SUFFIX                                 APPS.XXHA_WD_EMPLOYEE_V.SUFFIX%TYPE;
   l_FULL_NAME                              APPS.XXHA_WD_EMPLOYEE_V.FULL_NAME%TYPE;
   l_KNOWN_AS                               APPS.XXHA_WD_EMPLOYEE_V.KNOWN_AS%TYPE;
   l_ORIGINAL_DATE_OF_HIRE                  APPS.XXHA_WD_EMPLOYEE_V.ORIGINAL_DATE_OF_HIRE%TYPE;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , TITLE
  , TITLE_CODE
  , FIRST_NAME
  , MIDDLE_NAMES
  , LAST_NAME
  , SUFFIX
  , FULL_NAME
  , KNOWN_AS
  , ORIGINAL_DATE_OF_HIRE
  , START_DATE
-- Phone Records
  , PHONE_WORK
  , PHONE_FAX
  , PHONE_MOBILE
-- Assignment Records
  , ASSIGNMENT_ID
  , ORGANIZATION_ID
  , ORGANIZATION
  , JOB_ID
  , JOB_NAME
  , JOB_FAMILY
  , JOB_DEFINITION_ID
  , GRADE_ID
  , GRADE
  , LOCATION_ID
  , LOCATION
  , SUP_PERSON_ID
  , SUP_EMPLOYEE_NUMBER
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
-- Costing Records
  , COST_ALLOCATION_KEYFLEX_ID
  , COST_ACCOUNT
-- Columns not being processed at this time
  , HAEMO_EMAIL_REQUIRED
  , NON_HAEMO_EMAIL_ADDRESS
  , BUSINESS_GROUP_ID
  , BUSINESS_GROUP
  , PERSON_TYPE_ID
  , PERSON_TYPE                                                                 -- 'Employee', 'Ex-employee', 'HAE Contingent Worker', 'HAE Ex-Contingent Worker', 'HAE Ex-contingent Worker', 'Retiree'
  , ASSIGNMENT_CATEGORY
  , ASSIGNMENT_DESCRIPTION
  , ASSIGNMENT_STATUS_TYPE_ID
  , USER_NAME
  , COUNTRY
  , USER_STATUS                                                                 -- 'Leave of Absence', 'Terminate Assignment', 'Active Assignment'
  , CONTRACT_END_DATE
  , LEAVE_REASON
  , LEAVE_REASON_CODE
  , LAST_DAY_WORKED
  , OPERATING_UNIT_ID
  , OPERATING_UNIT_NAME
  , CREATION_DATE
  , STATUS
  , STATUS_MESSAGE
  , PROCESSED_START_DATE
  , PROCESSED_END_DATE
  , WD_RECORD_ID
  , CASE WHEN INSTR(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, PERSON_ID),'.', 1, 1) > 0 THEN
       SUBSTR(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, PERSON_ID), 1, INSTR(HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, PERSON_ID),'.', 1, 1) - 1)
    ELSE
       HR_PERSON_TYPE_USAGE_INFO.GET_USER_PERSON_TYPE(SYSDATE, PERSON_ID)
    END "USER_PERSON_TYPE"
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    NVL(STATUS,'PASS') = 'PASS'
ORDER BY
    WD_RECORD_ID ASC
;

-- Retrieve data in APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0200 (c_PERSON_ID PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
-- PER_PEOPLE_X
------------------------------
    PERSON_ID
  , EMPLOYEE_NUMBER
  , TITLE
  , FIRST_NAME
  , MIDDLE_NAMES
  , LAST_NAME
  , SUFFIX
  , FULL_NAME
  , KNOWN_AS
  , ORIGINAL_DATE_OF_HIRE
  , START_DATE
  , CONTRACT_END_DATE
  , HAEMO_EMAIL_REQUIRED
  , NON_HAEMO_EMAIL_ADDRESS
  , BUSINESS_GROUP_ID
  , BUSINESS_GROUP
  , PERSON_TYPE_ID
  , PERSON_TYPE
  , PHONE_WORK
  , PHONE_WORK_PHONE_ID
  , PHONE_WORK_PARENT_ID
  , PHONE_WORK_LAST_UPDATE_DATE
  , PHONE_WORK_DATE_FROM
  , PHONE_WORK_DATE_TO
  , PHONE_FAX
  , PHONE_FAX_PHONE_ID
  , PHONE_FAX_PARENT_ID
  , PHONE_FAX_LAST_UPDATE_DATE
  , PHONE_FAX_DATE_FROM
  , PHONE_FAX_DATE_TO
  , PHONE_MOBILE
  , PHONE_MOBILE_PHONE_ID
  , PHONE_MOBILE_PARENT_ID
  , PHONE_MOBILE_LAST_UPDATE_DATE
  , PHONE_MOBILE_DATE_FROM
  , PHONE_MOBILE_DATE_TO
  , USER_NAME
-- PER_ASSIGNMENTS_X
  ------------------------------
  , ASSIGNMENT_ID
  , ORGANIZATION_ID
  , ORGANIZATION
  , JOB_ID
  , JOB_FAMILY
  , JOB_NAME
  , JOB_DEFINITION_ID
  , GRADE_ID
  , GRADE
  , LOCATION_ID
  , LOCATION
  , COUNTRY
  , ASSIGNMENT_MEANING
  , ASSIGNMENT_CATEGORY
  , ASSIGNMENT_DESCRIPTION
  , ASSIGNMENT_STATUS_TYPE_ID
  , USER_STATUS
  , SUP_PERSON_ID
  , SUP_EMPLOYEE_NUMBER
  , SUP_FULL_NAME
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
  , COST_ALLOCATION_KEYFLEX_ID
  , COST_ACCOUNT
--
  , HOURLY_SALARIED_CODE
  , SOFT_CODING_KEYFLEX_ID
  , PAYROLL_ID
  , PAYROLL_NAME
  , PAY_BASIS_ID
  , SALARY_PAY_BASIS
  , SET_OF_BOOKS_ID
  , LEDGER
  , PERIOD_OF_SERVICE_ID
  , ACTUAL_TERM_DATE
  , LEAVING_REASON
  , TERM_REASON
  , LAST_WORKING_DAY
--
  , EMAIL_ADDRESS
  , PPX_EFFECTIVE_START_DATE
  , PPX_EFFECTIVE_END_DATE
  , PPX_LAST_UPDATE_DATE
  , PAX_EFFECTIVE_START_DATE
  , PAX_EFFECTIVE_END_DATE
  , PAX_LAST_UPDATE_DATE
  , USER_PERSON_TYPE
  , VENDOR
FROM
    APPS.XXHA_WD_EMPLOYEE_V VW
WHERE 1=1
AND PERSON_ID = c_PERSON_ID;

BEGIN

   -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   FOR dta0100 IN cur_0100
   LOOP

      -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)
      FOR dta0200 IN cur_0200(dta0100.PERSON_ID)
      LOOP

         -- Initialize values
         l_TITLE                 := NULL;
         l_FIRST_NAME            := NULL;
         l_MIDDLE_NAMES          := NULL;
         l_LAST_NAME             := NULL;
         l_SUFFIX                := NULL;
         l_FULL_NAME             := NULL;
         l_KNOWN_AS              := NULL;
         l_ORIGINAL_DATE_OF_HIRE := NULL;

         -- Process Person Records
         IF NVL(dta0100.TITLE,'*-XXX-*') <> NVL(dta0200.TITLE,'*-XXX-*') THEN
            l_TITLE := dta0100.TITLE;
         END IF;

         IF NVL(dta0100.FIRST_NAME,'*-XXX-*') <> NVL(dta0200.FIRST_NAME,'*-XXX-*') THEN
            l_FIRST_NAME := dta0100.FIRST_NAME;
         END IF;

         IF NVL(dta0100.MIDDLE_NAMES,'*-XXX-*') <> NVL(dta0200.MIDDLE_NAMES,'*-XXX-*') THEN
            l_MIDDLE_NAMES := dta0100.MIDDLE_NAMES;
         END IF;

         IF NVL(dta0100.LAST_NAME,'*-XXX-*') <> NVL(dta0200.LAST_NAME,'*-XXX-*') THEN
            l_LAST_NAME := dta0100.LAST_NAME;
         END IF;

         IF NVL(dta0100.SUFFIX,'*-XXX-*') <> NVL(dta0200.SUFFIX,'*-XXX-*') THEN
            l_SUFFIX := dta0100.SUFFIX;
         END IF;

         IF NVL(dta0100.KNOWN_AS,'*-XXX-*') <> NVL(dta0200.KNOWN_AS,'*-XXX-*') THEN
            l_KNOWN_AS := dta0100.KNOWN_AS;
         END IF;

-- 2018/05/15 - Do not allow change to Original Hire Date via interface, should be handled manually
--       IF NVL(dta0100.ORIGINAL_DATE_OF_HIRE, TRUNC(SYSDATE)) <> NVL(dta0200.ORIGINAL_DATE_OF_HIRE, TRUNC(SYSDATE)) THEN
--          l_ORIGINAL_DATE_OF_HIRE := dta0100.ORIGINAL_DATE_OF_HIRE;
--       END IF;

         -- If we found differences then we either update or correct the Person Data
         IF (l_TITLE IS NOT NULL) OR (l_FIRST_NAME IS NOT NULL) OR (l_MIDDLE_NAMES IS NOT NULL) OR (l_LAST_NAME IS NOT NULL) 
         OR (l_SUFFIX IS NOT NULL) OR (l_KNOWN_AS IS NOT NULL) OR (l_ORIGINAL_DATE_OF_HIRE IS NOT NULL)
         OR NVL(dta0100.CONTRACT_END_DATE, TRUNC(SYSDATE)) <> NVL(dta0200.CONTRACT_END_DATE, TRUNC(SYSDATE))
         -- Default Purchasing Acct (Segment11 on Per_People) is derived from EXPENSE_ACCOUNT so update if there's a change
         OR (NVL(dta0100.EXPENSE_ACCOUNT,'*-XXX-*')    <> NVL(dta0200.EXPENSE_ACCOUNT,'*-XXX-*')) THEN
            XXHA_WD_EMPLOYEE_REC_UPD(dta0100.WD_RECORD_ID);
         END IF;

         -- Process Phones (only if change phone has a value, Oracle does not allow to update phone with NULL Value)
         IF ((dta0100.PHONE_WORK   IS NOT NULL) AND (NVL(dta0100.PHONE_WORK,'*-XXX-*')   <> NVL(dta0200.PHONE_WORK,'*-XXX-*'))
         OR  (dta0100.PHONE_FAX    IS NOT NULL) AND (NVL(dta0100.PHONE_FAX,'*-XXX-*')    <> NVL(dta0200.PHONE_FAX,'*-XXX-*'))
         OR  (dta0100.PHONE_MOBILE IS NOT NULL) AND (NVL(dta0100.PHONE_MOBILE,'*-XXX-*') <> NVL(dta0200.PHONE_MOBILE,'*-XXX-*'))) THEN
            XXHA_WD_EMPLOYEE_PHONE_UPD(dta0100.WD_RECORD_ID); 
         END IF;

         -- Process Assignment Records
         IF (NVL(dta0100.ORGANIZATION,'*-XXX-*')    <> NVL(dta0200.ORGANIZATION,'*-XXX-*')
         OR  NVL(dta0100.LOCATION,'*-XXX-*')        <> NVL(TO_CHAR(dta0200.LOCATION_ID),'*-XXX-*') 
         OR  NVL(dta0100.JOB_NAME,'*-XXX-*')        <> NVL(dta0200.JOB_NAME,'*-XXX-*')
         OR  NVL(dta0100.GRADE,'*-XXX-*')           <> NVL(dta0200.GRADE,'*-XXX-*')
         OR  NVL(dta0100.EXPENSE_ACCOUNT,'*-XXX-*') <> NVL(dta0200.EXPENSE_ACCOUNT,'*-XXX-*')) THEN
            XXHA_WD_EMPLOYEE_ASSGN_REC_UPD(dta0100.WD_RECORD_ID); 
         END IF;

         IF NVL(dta0100.COST_ACCOUNT,'*-XXX-*')    <> NVL(dta0200.COST_ACCOUNT,'*-XXX-*') THEN
            XXHA_WD_EMPLOYEE_COST(dta0100.WD_RECORD_ID); 
         END IF;

      END LOOP; -- Cursor to retrieve data in APPS.XXHA_WD_EMPLOYEE_V (Current Data)

   END LOOP; -- Cursor to retrieve data in HAEMO.XXHA_WD_EMPLOYEE_CHANGES

   COMMIT;

END;

END XXHA_PROCESS_CHANGES;


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_REC_UPD(
          p_RECORD_ID                       IN NUMBER) AS

   -- Local Variables 
   ln_object_version_number                 APPS.PER_ALL_PEOPLE_F.OBJECT_VERSION_NUMBER%TYPE  := NULL;
   lc_employee_number                       APPS.PER_ALL_PEOPLE_F.EMPLOYEE_NUMBER%TYPE        := NULL;
   lc_dt_ud_mode                            VARCHAR2(100)                                     := NULL; 

   l_Return                                 VARCHAR2(2000)                                    := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE        := NULL;
   l_decimal                                NUMBER                                            := 0;
   l_EXPENSE_ACCOUNT_FIRST_SIX              VARCHAR2(100)                                     := NULL;

   -- Out Variables for Find Date Track Mode API 
   lb_correction                            BOOLEAN; 
   lb_update                                BOOLEAN; 
   lb_update_override                       BOOLEAN;  
   lb_update_change_insert                  BOOLEAN;

   -- Out Variables for Update Employee API 
   ld_effective_start_date                  DATE; 
   ld_effective_end_date                    DATE; 
   lc_full_name                             APPS.PER_ALL_PEOPLE_F.FULL_NAME%TYPE; 
   ln_comment_id                            APPS.PER_ALL_PEOPLE_F.COMMENT_ID%TYPE;  
   lb_name_combination_warning              BOOLEAN; 
   lb_assign_payroll_warning                BOOLEAN; 
   lb_orig_hire_warning                     BOOLEAN;

   -- Cursor data from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   l_PERSON_ID                              APPS.PER_PEOPLE_X.PERSON_ID%TYPE;
   l_employee_number                        APPS.PER_PEOPLE_X.employee_number%TYPE;
--   l_TITLE                                  APPS.PER_PEOPLE_X.TITLE%TYPE;     -- 2018/05/03
   l_TITLE_CODE                             APPS.PER_PEOPLE_X.TITLE%TYPE;       -- 2018/05/03
   l_FIRST_NAME                             APPS.PER_PEOPLE_X.FIRST_NAME%TYPE;
   l_MIDDLE_NAMES                           APPS.PER_PEOPLE_X.MIDDLE_NAMES%TYPE;
   l_LAST_NAME                              APPS.PER_PEOPLE_X.LAST_NAME%TYPE;
   l_SUFFIX                                 APPS.PER_PEOPLE_X.SUFFIX%TYPE;
   l_KNOWN_AS                               APPS.PER_PEOPLE_X.KNOWN_AS%TYPE;
   l_EXPENSE_ACCOUNT                        APPS.PER_PEOPLE_X.attribute11%TYPE;
   l_ORIGINAL_DATE_OF_HIRE                  APPS.PER_PEOPLE_X.ORIGINAL_DATE_OF_HIRE%TYPE;
   l_START_DATE                             APPS.PER_PEOPLE_X.START_DATE%TYPE;
   l_CONTRACT_END_DATE                      APPS.PER_PEOPLE_X.START_DATE%TYPE;
   l_STATUS_MESSAGE                         APPS.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE;
   l_attribute12                            APPS.PER_PEOPLE_X.attribute12%TYPE;               -- CONTRACT_END_DATE

   lc_USER_PERSON_TYPE                      APPS.XXHA_WD_EMPLOYEE_V.USER_PERSON_TYPE%TYPE;
   lc_ORIGINAL_DATE_OF_HIRE                 APPS.PER_PEOPLE_X.ORIGINAL_DATE_OF_HIRE%TYPE;
   lc_START_DATE                            APPS.PER_PEOPLE_X.START_DATE%TYPE;

   -- Cursor data from APPS.per_People_X
   l_OBJECT_VERSION_NUMBER                  APPS.PER_PEOPLE_X.OBJECT_VERSION_NUMBER%TYPE;

-- Cursor to retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100(c_RECORD_ID HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
--  , TITLE                                                                     -- 2018/05/03
  , TITLE_CODE                                                                  -- 2018/05/03
  , FIRST_NAME
  , MIDDLE_NAMES
  , LAST_NAME
  , SUFFIX
  , KNOWN_AS
  , EXPENSE_ACCOUNT
  , ORIGINAL_DATE_OF_HIRE
  , START_DATE
  , CONTRACT_END_DATE
  , STATUS_MESSAGE
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    WD_RECORD_ID = c_RECORD_ID
;

-- Cursor to retrieve record from APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0200(c_PERSON_ID XXHA_WD_EMPLOYEE_V.PERSON_ID%TYPE)
IS
SELECT
    PPX_OBJECT_VERSION_NUMBER
  , USER_PERSON_TYPE
  , ORIGINAL_DATE_OF_HIRE
  , START_DATE
FROM
    APPS.XXHA_WD_EMPLOYEE_V
WHERE
    Person_ID = c_PERSON_ID
;

BEGIN

   -- Initialize Values
   l_PERSON_ID              := NULL;
   l_EMPLOYEE_NUMBER        := NULL;
--   l_TITLE                  := NULL;                                          -- 2018/05/03
   l_TITLE_CODE             := NULL;                                            -- 2018/05/03
   l_FIRST_NAME             := NULL;
   l_MIDDLE_NAMES           := NULL;
   l_LAST_NAME              := NULL;
   l_SUFFIX                 := NULL;
   l_KNOWN_AS               := NULL;
   l_EXPENSE_ACCOUNT        := NULL;
   l_ORIGINAL_DATE_OF_HIRE  := NULL;
   l_START_DATE             := NULL;
   l_CONTRACT_END_DATE      := NULL;
   l_STATUS_MESSAGE         := NULL;
   l_OBJECT_VERSION_NUMBER  := NULL;
   lc_USER_PERSON_TYPE      := NULL;
   lc_ORIGINAL_DATE_OF_HIRE := NULL;
   lc_START_DATE            := NULL;

   -- Retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES for Record_ID
   BEGIN
        OPEN cur_0100(p_RECORD_ID);
       FETCH cur_0100 INTO l_PERSON_ID,l_EMPLOYEE_NUMBER,l_TITLE_CODE,l_FIRST_NAME,l_MIDDLE_NAMES,l_LAST_NAME,l_SUFFIX,l_KNOWN_AS,l_EXPENSE_ACCOUNT -- 2018/05/03 - Changed l_TITLE to l_TITLE_CODE
                          ,l_ORIGINAL_DATE_OF_HIRE,l_START_DATE,l_CONTRACT_END_DATE,l_STATUS_MESSAGE;                       

       CLOSE cur_0100;
   END;

   -- Retrieve record from APPS.per_People_X for Person_ID
   BEGIN
        OPEN cur_0200(l_PERSON_ID);
       FETCH cur_0200 INTO l_OBJECT_VERSION_NUMBER,lc_USER_PERSON_TYPE,lc_ORIGINAL_DATE_OF_HIRE,lc_START_DATE;
       CLOSE cur_0200;
   END;

   -- Initialize Value
   lc_dt_ud_mode := NULL;

   -- Call API to Find Date Track Mode
   dt_api.find_dt_upd_modes
   (
      -- INPUT
      p_effective_date                 => TO_DATE(SYSDATE)
    , p_base_table_name                => 'PER_ALL_PEOPLE_F'
    , p_base_key_column                => 'PERSON_ID'
    , p_base_key_value                 => l_PERSON_ID
      -- OUTPUT
    , p_correction                     => lb_correction
    , p_update                         => lb_update
    , p_update_override                => lb_update_override
    , p_update_change_insert           => lb_update_change_insert
   );

   IF (lb_update_override = TRUE OR lb_update_change_insert = TRUE) THEN
      lc_dt_ud_mode := 'UPDATE_OVERRIDE';
   END IF;

   IF (lb_correction = TRUE) THEN
      lc_dt_ud_mode := 'CORRECTION';
   END IF;

   IF ( lb_update = TRUE ) THEN
      lc_dt_ud_mode := 'UPDATE';
   END IF;

   -- Initialize Values
   l_Return                    := NULL;
   l_Status                    := NULL;
   l_decimal                   := 0;
   l_EXPENSE_ACCOUNT_FIRST_SIX := NULL;
   l_attribute12               := NULL;

   -- Determine where the sixth (6th) decimanl ('.') occurs in l_EXPENSE_ACCOUNT
   l_decimal := (instr(l_EXPENSE_ACCOUNT,'.',1,6));

   -- Retrieve first six (6) Segments
   l_EXPENSE_ACCOUNT_FIRST_SIX := SUBSTR(l_EXPENSE_ACCOUNT,1,(l_decimal-1));

   BEGIN

   -- Set CWK Termination Date from CONTRACT_END_DATE
   IF lc_USER_PERSON_TYPE LIKE 'HAE Contingent%' THEN
      l_attribute12 := to_char(l_CONTRACT_END_DATE, 'YYYY/MM/DD HH:MI:SS');
   ELSE
      l_attribute12 := NULL;
   END IF;

   -- Call API to Update Person
   hr_person_api.update_person
   (
     -- INPUT
     p_effective_date                 => TO_DATE(SYSDATE)
   , p_datetrack_update_mode          => lc_dt_ud_mode
   , p_person_id                      => l_PERSON_ID
   , p_title                          => l_TITLE_CODE                           -- 2018/05/03 - Changed l_TITLE to l_TITLE_CODE
   , p_LAST_NAME                      => l_LAST_NAME
   , p_FIRST_NAME                     => l_FIRST_NAME
   , p_KNOWN_AS                       => l_KNOWN_AS
   , p_MIDDLE_NAMES                   => l_MIDDLE_NAMES
   , p_SUFFIX                         => l_SUFFIX
--   , p_ORIGINAL_DATE_OF_HIRE          => l_ORIGINAL_DATE_OF_HIRE              -- 2018/05/15 - Do not allow change to Original Date of Hire via interface, should be handled manually
   , p_attribute11                    => l_EXPENSE_ACCOUNT_FIRST_SIX
   , p_attribute12                    => l_attribute12                          --  CONTRACT_END_DATE
     -- OUTPUT
   , p_employee_number                => l_employee_number
   , p_object_version_number          => l_OBJECT_VERSION_NUMBER
   , p_effective_start_date           => ld_effective_start_date
   , p_effective_end_date             => ld_effective_end_date
   , p_full_name                      => lc_full_name
   , p_comment_id                     => ln_comment_id
   , p_name_combination_warning       => lb_name_combination_warning
   , p_assign_payroll_warning         => lb_assign_payroll_warning
   , p_orig_hire_warning              => lb_orig_hire_warning
   );
   EXCEPTION
        WHEN OTHERS THEN
             ROLLBACK;
             l_Status := 'FAIL';
             l_Return := ('API Error: hr_person_api.update_person: ' || SQLERRM);
   END;

   -- Check for errors
   IF NVL(l_Status,'PASS') = 'PASS' THEN
      COMMIT;
   ELSE
      FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
      l_STATUS_MESSAGE := NULL;
      SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
         SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
           , XXHA.STATUS         = 'FAIL'
       WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
      COMMIT;
   END IF;

END XXHA_WD_EMPLOYEE_REC_UPD;


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_PHONE_UPD(
          p_RECORD_ID                       IN  NUMBER) AS

BEGIN

DECLARE

   -- Local Variables 
   l_Return                                 VARCHAR2(2000)                             := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE := NULL;

   l_OBJECT_VERSION_NUMBER                  APPS.PER_PHONES.OBJECT_VERSION_NUMBER%TYPE;
   l_phone_id                               APPS.PER_PHONES.PHONE_ID%TYPE;

   -- Cursor data from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
   l_PERSON_ID                              APPS.XXHA_WD_EMPLOYEE_V.PERSON_ID%TYPE;
   l_employee_number                        APPS.XXHA_WD_EMPLOYEE_V.employee_number%TYPE;
   l_PHONE_WORK                             APPS.XXHA_WD_EMPLOYEE_V.PHONE_WORK%TYPE;
   l_PHONE_FAX                              APPS.XXHA_WD_EMPLOYEE_V.PHONE_FAX%TYPE;
   l_PHONE_MOBILE                           APPS.XXHA_WD_EMPLOYEE_V.PHONE_MOBILE%TYPE;
   l_STATUS_MESSAGE                         APPS.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE;

   lc_PHONE_WORK                            APPS.XXHA_WD_EMPLOYEE_V.PHONE_WORK%TYPE;
   lc_PHONE_WORK_PHONE_ID                   APPS.XXHA_WD_EMPLOYEE_V.PHONE_WORK_PHONE_ID%TYPE;
   lc_PHONE_WORK_PARENT_ID                  APPS.XXHA_WD_EMPLOYEE_V.PHONE_WORK_PARENT_ID%TYPE;
   lc_PHONE_WORK_LAST_UPD_DATE              APPS.XXHA_WD_EMPLOYEE_V.PHONE_WORK_LAST_UPDATE_DATE%TYPE;
   lc_PHONE_WORK_DATE_FROM                  APPS.XXHA_WD_EMPLOYEE_V.PHONE_WORK_DATE_FROM%TYPE;
   lc_PHONE_WORK_DATE_TO                    APPS.XXHA_WD_EMPLOYEE_V.PHONE_WORK_DATE_TO%TYPE;
   lc_PHONE_FAX                             APPS.XXHA_WD_EMPLOYEE_V.PHONE_FAX%TYPE;
   lc_PHONE_FAX_PHONE_ID                    APPS.XXHA_WD_EMPLOYEE_V.PHONE_FAX_PHONE_ID%TYPE;
   lc_PHONE_FAX_PARENT_ID                   APPS.XXHA_WD_EMPLOYEE_V.PHONE_FAX_PARENT_ID%TYPE;
   lc_PHONE_FAX_LAST_UPD_DATE               APPS.XXHA_WD_EMPLOYEE_V.PHONE_FAX_LAST_UPDATE_DATE%TYPE;
   lc_PHONE_FAX_DATE_FROM                   APPS.XXHA_WD_EMPLOYEE_V.PHONE_FAX_DATE_FROM%TYPE;
   lc_PHONE_FAX_DATE_TO                     APPS.XXHA_WD_EMPLOYEE_V.PHONE_FAX_DATE_TO%TYPE;
   lc_PHONE_MOBILE                          APPS.XXHA_WD_EMPLOYEE_V.PHONE_MOBILE%TYPE;
   lc_PHONE_MOBILE_PHONE_ID                 APPS.XXHA_WD_EMPLOYEE_V.PHONE_MOBILE_PHONE_ID%TYPE;
   lc_PHONE_MOBILE_PARENT_ID                APPS.XXHA_WD_EMPLOYEE_V.PHONE_MOBILE_PARENT_ID%TYPE;
   lc_PHONE_MOBILE_LAST_UPD_DATE            APPS.XXHA_WD_EMPLOYEE_V.PHONE_MOBILE_LAST_UPDATE_DATE%TYPE;
   lc_PHONE_MOBILE_DATE_FROM                APPS.XXHA_WD_EMPLOYEE_V.PHONE_MOBILE_DATE_FROM%TYPE;
   lc_PHONE_MOBILE_DATE_TO                  APPS.XXHA_WD_EMPLOYEE_V.PHONE_MOBILE_DATE_TO%TYPE;
   lc_OBJECT_VERSION_NUMBER                 APPS.PER_PHONES.OBJECT_VERSION_NUMBER%TYPE;

-- Cursor to retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100(c_RECORD_ID HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , PHONE_WORK
  , PHONE_FAX
  , PHONE_MOBILE
  , STATUS_MESSAGE
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    WD_RECORD_ID = c_RECORD_ID
;

-- Cursor to retrieve record from APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0200(c_PERSON_ID XXHA_WD_EMPLOYEE_V.PERSON_ID%TYPE)
IS
SELECT
    PHONE_WORK
  , PHONE_WORK_PHONE_ID
  , PHONE_WORK_PARENT_ID
  , PHONE_WORK_LAST_UPDATE_DATE
  , PHONE_WORK_DATE_FROM
  , PHONE_WORK_DATE_TO
  , PHONE_FAX
  , PHONE_FAX_PHONE_ID
  , PHONE_FAX_PARENT_ID
  , PHONE_FAX_LAST_UPDATE_DATE
  , PHONE_FAX_DATE_FROM
  , PHONE_FAX_DATE_TO
  , PHONE_MOBILE
  , PHONE_MOBILE_PHONE_ID
  , PHONE_MOBILE_PARENT_ID
  , PHONE_MOBILE_LAST_UPDATE_DATE
  , PHONE_MOBILE_DATE_FROM
  , PHONE_MOBILE_DATE_TO
FROM
    APPS.XXHA_WD_EMPLOYEE_V
WHERE
    Person_ID = c_PERSON_ID
;

-- Cursor to retrieve object_version_number for phone record
CURSOR cur_0300(c_phone_id Per_Phones.phone_id%TYPE, c_Phone_Type Per_Phones.Phone_Type%TYPE)
IS
SELECT 
    Pp1.OBJECT_VERSION_NUMBER
FROM
    apps.Per_Phones  Pp1
WHERE
    Pp1.phone_id   = c_phone_id
AND Pp1.Phone_Type = c_Phone_Type
;

BEGIN

   -- Initialize Values
   l_PERSON_ID       := NULL;
   l_EMPLOYEE_NUMBER := NULL;
   l_PHONE_WORK      := NULL;
   l_PHONE_FAX       := NULL;
   l_PHONE_MOBILE    := NULL;
   l_STATUS_MESSAGE  := NULL;

   -- Retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES for Record_ID
   BEGIN
        OPEN cur_0100(p_RECORD_ID);
       FETCH cur_0100 INTO l_PERSON_ID, l_EMPLOYEE_NUMBER, l_PHONE_WORK, l_PHONE_FAX, l_PHONE_MOBILE, l_STATUS_MESSAGE;
       CLOSE cur_0100;
   END;

   -- Initialize Values
   lc_PHONE_WORK                 := NULL;
   lc_PHONE_WORK_PHONE_ID        := NULL;
   lc_PHONE_WORK_PARENT_ID       := NULL;
   lc_PHONE_WORK_LAST_UPD_DATE   := NULL;
   lc_PHONE_WORK_DATE_FROM       := NULL;
   lc_PHONE_WORK_DATE_TO         := NULL;
   lc_PHONE_FAX                  := NULL;
   lc_PHONE_FAX_PHONE_ID         := NULL;
   lc_PHONE_FAX_PARENT_ID        := NULL;
   lc_PHONE_FAX_LAST_UPD_DATE    := NULL;
   lc_PHONE_FAX_DATE_FROM        := NULL;
   lc_PHONE_FAX_DATE_TO          := NULL;
   lc_PHONE_MOBILE               := NULL;
   lc_PHONE_MOBILE_PHONE_ID      := NULL;
   lc_PHONE_MOBILE_PARENT_ID     := NULL;
   lc_PHONE_MOBILE_LAST_UPD_DATE := NULL;
   lc_PHONE_MOBILE_DATE_FROM     := NULL;
   lc_PHONE_MOBILE_DATE_TO       := NULL;

   -- Retrieve record from APPS.XXHA_WD_EMPLOYEE_V for Person_ID (Current data)
   BEGIN
        OPEN cur_0200(l_PERSON_ID);
       FETCH cur_0200 INTO lc_PHONE_WORK, lc_PHONE_WORK_PHONE_ID, lc_PHONE_WORK_PARENT_ID, lc_PHONE_WORK_LAST_UPD_DATE, lc_PHONE_WORK_DATE_FROM, lc_PHONE_WORK_DATE_TO, 
                           lc_PHONE_FAX, lc_PHONE_FAX_PHONE_ID, lc_PHONE_FAX_PARENT_ID, lc_PHONE_FAX_LAST_UPD_DATE, lc_PHONE_FAX_DATE_FROM, lc_PHONE_FAX_DATE_TO, 
                           lc_PHONE_MOBILE, lc_PHONE_MOBILE_PHONE_ID, lc_PHONE_MOBILE_PARENT_ID, lc_PHONE_MOBILE_LAST_UPD_DATE, lc_PHONE_MOBILE_DATE_FROM, lc_PHONE_MOBILE_DATE_TO;
       CLOSE cur_0200;
   END;


--------------------------------------------------------------------------------
-- Creates
--------------------------------------------------------------------------------

   -- WORK PHONE PROCESSING (Creates)
   IF l_PHONE_WORK IS NOT NULL THEN
   IF NVL(l_PHONE_WORK,'*-XXX-*') <> NVL(lc_PHONE_WORK,'*-XXX-*') THEN
      IF lc_PHONE_WORK_PHONE_ID IS NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_WORK_PHONE_ID,'W1');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to Create Phone work phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'W1'
         , p_phone_number              => l_PHONE_WORK
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_WORK): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;

   -- FAX PHONE PROCESSING (Creates)
   IF l_PHONE_FAX IS NOT NULL THEN
   IF NVL(l_PHONE_FAX,'*-XXX-*') <> NVL(lc_PHONE_FAX,'*-XXX-*') THEN
      IF lc_PHONE_FAX_PHONE_ID IS NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_FAX_PHONE_ID,'WF');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to Create Phone fax phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'WF'
         , p_phone_number              => l_PHONE_FAX
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_FAX): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;

   -- MOBILE PHONE PROCESSING (Creates)
   IF l_PHONE_MOBILE IS NOT NULL THEN
   IF (NVL(l_PHONE_MOBILE,'*-XXX-*') <> NVL(lc_PHONE_MOBILE,'*-XXX-*')) THEN
       IF lc_PHONE_MOBILE_PHONE_ID IS NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_MOBILE_PHONE_ID,'MW');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to Create Phone mobile phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'MW'
         , p_phone_number              => l_PHONE_MOBILE
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_MOBILE): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;


--------------------------------------------------------------------------------
-- Corrections
--------------------------------------------------------------------------------

   -- WORK PHONE PROCESSING (Corrections)
   IF l_PHONE_WORK IS NOT NULL THEN
   IF NVL(l_PHONE_WORK,'*-XXX-*') <> NVL(lc_PHONE_WORK,'*-XXX-*') AND (lc_PHONE_WORK_DATE_FROM = TRUNC(SYSDATE)) THEN
      IF lc_PHONE_WORK_PHONE_ID IS NOT NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_WORK_PHONE_ID,'W1');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to Update current work phone record
         hr_phone_api.update_phone
         (
           -- INPUT
           p_phone_id                  => lc_PHONE_WORK_PHONE_ID
         , p_date_from                 => lc_PHONE_WORK_DATE_FROM
         , p_date_to                   => lc_PHONE_WORK_DATE_TO
         , p_phone_number              => l_PHONE_WORK
         , p_effective_date            => lc_PHONE_WORK_LAST_UPD_DATE
           -- INPUT/OUTPUT
         , p_object_version_number     => lc_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.update_phone (PHONE_WORK): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;

   -- FAX PHONE PROCESSING (Corrections)
   IF l_PHONE_FAX IS NOT NULL THEN
   IF NVL(l_PHONE_FAX,'*-XXX-*') <> NVL(lc_PHONE_FAX,'*-XXX-*') AND (lc_PHONE_FAX_DATE_FROM = TRUNC(SYSDATE)) THEN
      IF lc_PHONE_FAX_PHONE_ID IS NOT NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_FAX_PHONE_ID,'WF');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API To Update current fax phone record
         hr_phone_api.update_phone
         (
           -- INPUT
           p_phone_id                  => lc_PHONE_FAX_PHONE_ID
         , p_date_from                 => lc_PHONE_FAX_DATE_FROM
         , p_date_to                   => lc_PHONE_FAX_DATE_TO
         , p_phone_number              => l_PHONE_FAX
         , p_effective_date            => lc_PHONE_FAX_LAST_UPD_DATE
           -- INPUT/OUTPUT
         , p_object_version_number     => lc_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.update_phone (PHONE_FAX): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;

   -- MOBILE PHONE PROCESSING (Corrections)
   IF l_PHONE_MOBILE IS NOT NULL THEN
   IF (NVL(l_PHONE_MOBILE,'*-XXX-*') <> NVL(lc_PHONE_MOBILE,'*-XXX-*')) AND (lc_PHONE_MOBILE_DATE_FROM = TRUNC(TO_DATE(SYSDATE))) THEN
       IF lc_PHONE_MOBILE_PHONE_ID IS NOT NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_MOBILE_PHONE_ID,'MW');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to Update current mobile phone record
         hr_phone_api.update_phone
         (
           -- INPUT
           p_phone_id                  => lc_PHONE_MOBILE_PHONE_ID
         , p_date_from                 => lc_PHONE_MOBILE_DATE_FROM
         , p_date_to                   => lc_PHONE_MOBILE_DATE_TO
         , p_phone_number              => l_PHONE_MOBILE
         , p_effective_date            => lc_PHONE_MOBILE_LAST_UPD_DATE
           -- INPUT/OUTPUT
         , p_object_version_number     => lc_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.update_phone (PHONE_MOBILE): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;


--------------------------------------------------------------------------------
-- Update/Create
--------------------------------------------------------------------------------

   -- WORK PHONE PROCESSING (Update/Create)
   IF l_PHONE_WORK IS NOT NULL THEN
   IF NVL(l_PHONE_WORK,'*-XXX-*') <> NVL(lc_PHONE_WORK,'*-XXX-*') AND (TRUNC(lc_PHONE_WORK_DATE_FROM) <> TRUNC(SYSDATE)) THEN
      IF lc_PHONE_WORK_PHONE_ID IS NOT NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_WORK_PHONE_ID,'W1');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to End-date current work phone record
         hr_phone_api.update_phone
         (
           -- INPUT
           p_phone_id                  => lc_PHONE_WORK_PHONE_ID
         , p_date_from                 => lc_PHONE_WORK_DATE_FROM
         , p_date_to                   => TO_DATE(SYSDATE)-1
         , p_phone_number              => lc_PHONE_WORK
         , p_effective_date            => TO_DATE(SYSDATE)
           -- INPUT/OUTPUT
         , p_object_version_number     => lc_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.update_phone (PHONE_WORK): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Call API to Create Phone work phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'W1'
         , p_phone_number              => l_PHONE_WORK
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_WORK): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      ELSE -- IF lc_PHONE_WORK_PHONE_ID IS NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Call API to Create Phone work phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'W1'
         , p_phone_number              => l_PHONE_WORK
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_WORK): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;

   -- FAX PHONE PROCESSING (Update/Create)
   IF l_PHONE_FAX IS NOT NULL THEN
   IF NVL(l_PHONE_FAX,'*-XXX-*') <> NVL(lc_PHONE_FAX,'*-XXX-*') AND (TRUNC(lc_PHONE_FAX_DATE_FROM) <> TRUNC(SYSDATE)) THEN
      IF lc_PHONE_FAX_PHONE_ID IS NOT NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_FAX_PHONE_ID,'WF');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to End-date current fax phone record
         hr_phone_api.update_phone
         (
           -- INPUT
           p_phone_id                  => lc_PHONE_FAX_PHONE_ID
         , p_date_from                 => lc_PHONE_FAX_DATE_FROM
         , p_date_to                   => TO_DATE(SYSDATE)-1
         , p_phone_number              => lc_PHONE_FAX
         , p_effective_date            => TO_DATE(SYSDATE)
           -- INPUT/OUTPUT
         , p_object_version_number     => lc_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.update_phone (PHONE_FAX): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Call API to Create Phone fax phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'WF'
         , p_phone_number              => l_PHONE_FAX
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_FAX): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      ELSE -- IF lc_PHONE_FAX_PHONE_ID IS NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Call API to Create Phone fax phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'WF'
         , p_phone_number              => l_PHONE_FAX
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_FAX): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;

   -- MOBILE PHONE PROCESSING (Update/Create)
   IF l_PHONE_MOBILE IS NOT NULL THEN
   IF NVL(l_PHONE_MOBILE,'*-XXX-*') <> NVL(lc_PHONE_MOBILE,'*-XXX-*') AND (TRUNC(lc_PHONE_MOBILE_DATE_FROM) <> TRUNC(SYSDATE)) THEN
       IF lc_PHONE_MOBILE_PHONE_ID IS NOT NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         lc_OBJECT_VERSION_NUMBER := NULL;

         -- Cursor to retrieve object_version_number for phone record
          OPEN cur_0300(lc_PHONE_MOBILE_PHONE_ID,'MW');
         FETCH cur_0300 INTO lc_OBJECT_VERSION_NUMBER;
         CLOSE cur_0300;

         -- Call API to End-date current mobile phone record
         hr_phone_api.update_phone
         (
           -- INPUT
           p_phone_id                  => lc_PHONE_MOBILE_PHONE_ID
         , p_date_from                 => lc_PHONE_MOBILE_DATE_FROM
         , p_date_to                   => TO_DATE(SYSDATE)-1
         , p_phone_number              => lc_PHONE_MOBILE
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_object_version_number     => lc_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.update_phone (PHONE_MOBILE): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Call API to Create Phone mobile phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'MW'
         , p_phone_number              => l_PHONE_MOBILE
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_MOBILE): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      ELSE -- IF lc_PHONE_MOBILE_PHONE_ID IS NULL THEN

         BEGIN

         -- Initialize Values
         l_Return                 := NULL;
         l_Status                 := NULL;
         l_object_version_number  := NULL;
         l_phone_id               := NULL;

         -- Call API to Create Phone mobile phone record
         hr_phone_api.create_phone
         (
           -- INPUT
           p_date_from                 => TO_DATE(SYSDATE)
         , p_date_to                   => NULL
         , p_phone_type                => 'MW'
         , p_phone_number              => l_PHONE_MOBILE
         , p_parent_id                 => l_PERSON_ID
         , p_parent_table              => 'PER_ALL_PEOPLE_F'
         , p_effective_date            => TO_DATE(SYSDATE)
           -- OUTPUT
         , p_phone_id                  => l_phone_id
         , p_object_version_number     => l_object_version_number
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_Return := ('API Error: hr_phone_api.create_phone (PHONE_MOBILE): ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF;

   END IF;
   END IF;

END;

END XXHA_WD_EMPLOYEE_PHONE_UPD;


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_ASSGN_REC_UPD(
          p_RECORD_ID                       IN  NUMBER) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                             := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE := NULL;

   lc_PERSON_ID                             APPS.PER_PEOPLE_X.Person_ID%TYPE;
   lc_EMPLOYEE_NUMBER                       APPS.PER_PEOPLE_X.EMPLOYEE_NUMBER%TYPE;
   lc_FIRST_NAME                            APPS.PER_PEOPLE_X.FIRST_NAME%TYPE;
   lc_MIDDLE_NAMES                          APPS.PER_PEOPLE_X.MIDDLE_NAMES%TYPE;
   lc_LAST_NAME                             APPS.PER_PEOPLE_X.LAST_NAME%TYPE;
   lc_ASSIGNMENT_ID                         APPS.PER_ASSIGNMENTS_X.ASSIGNMENT_ID%TYPE;
   lc_ORGANIZATION_ID                       APPS.PER_ASSIGNMENTS_X.ORGANIZATION_ID%TYPE;
   lc_ORGANIZATION                          APPS.HR_ALL_ORGANIZATION_UNITS.name%TYPE;
   lc_JOB_ID                                APPS.PER_ASSIGNMENTS_X.JOB_ID%TYPE;
   lc_JOB_FAMILY                            APPS.per_jobs.Job_Information9%TYPE;
   lc_JOB_NAME                              APPS.per_jobs.name%TYPE;
   lc_JOB_DEFINITION_ID                     APPS.per_jobs.job_definition_id%TYPE;
   lc_GRADE_ID                              APPS.PER_ASSIGNMENTS_X.GRADE_ID%TYPE;
   lc_GRADE                                 APPS.per_grades.name%TYPE;
   lc_LOCATION_ID                           APPS.HR_LOCATIONS_V.location_id%TYPE;
   lc_LOCATION                              APPS.HR_LOCATIONS_V.location_code%TYPE;
   lc_ASSIGNMENT_DESCRIPTION                APPS.hr_lookups.Description%TYPE;
   lc_ASSIGNMENT_CATEGORY                   APPS.hr_lookups.LOOKUP_CODE%TYPE;
   lc_ASSIGNMENT_MEANING                    APPS.hr_lookups.MEANING%TYPE;
   lc_ASSIGNMENT_STATUS_TYPE_ID             APPS.PER_ASSIGNMENT_STATUS_TYPES.ASSIGNMENT_STATUS_TYPE_ID%TYPE;
   lc_USER_STATUS                           APPS.per_assignment_status_types.User_Status%TYPE;
   lc_SUP_PERSON_ID                         APPS.PER_PEOPLE_X.Person_ID%TYPE;
   lc_SUP_EMPLOYEE_NUMBER                   APPS.PER_PEOPLE_X.EMPLOYEE_NUMBER%TYPE;
   lc_CONTRACT_END_DATE                     DATE;
   lc_CODE_COMBINATION_ID                   APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   lc_EXPENSE_ACCOUNT                       VARCHAR2(240);
   lc_COST_ALLOCATION_KEYFLEX_ID            APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   lc_COST_ACCOUNT                          VARCHAR2(240);
   lc_LEAVE_REASON_CODE                     APPS.hr_lookups.LOOKUP_CODE%TYPE;
   lc_LEAVE_REASON                          APPS.hr_lookups.MEANING%TYPE;
   lc_LAST_DAY_WORKED                       DATE;
   lc_WD_RECORD_ID                          HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE;
   lc_ESTABLISHMENT_ID                      NUMBER;

   lc_dt_ud_mode                            VARCHAR2(100)                                := NULL; 

   -- Out Variables for Find Date Track Mode API 
   lb_correction                            BOOLEAN; 
   lb_update                                BOOLEAN; 
   lb_update_override                       BOOLEAN;  
   lb_update_change_insert                  BOOLEAN;

   l_asg_object_version_number              APPS.per_all_assignments_f.object_version_number%TYPE;
   l_pep_object_version_number              APPS.per_all_people_f.object_version_number%TYPE;
   l_assignment_id                          APPS.per_all_assignments_f.assignment_id%TYPE;

   l_PERSON_ID                              APPS.per_all_people_f.PERSON_ID%TYPE;
   l_EMPLOYEE_NUMBER                        APPS.per_all_people_f.EMPLOYEE_NUMBER%TYPE;
   l_CODE_COMBINATION_ID                    APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   l_COST_ALLOCATION_KEYFLEX_ID             APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   l_SET_OF_BOOKS_ID                        APPS.PER_ASSIGNMENTS_X.SET_OF_BOOKS_ID%TYPE;
   l_HOURLY_SALARIED_CODE                   APPS.PER_ASSIGNMENTS_X.HOURLY_SALARIED_CODE%TYPE;
   l_PAYROLL_ID                             APPS.PER_ASSIGNMENTS_X.PAYROLL_ID%TYPE;
   l_PAY_BASIS_ID                           APPS.PER_ASSIGNMENTS_X.PAY_BASIS_ID%TYPE;
   l_ORGANIZATION_ID                        APPS.PER_ASSIGNMENTS_X.ORGANIZATION_ID%TYPE;
   l_LOCATION_ID                            APPS.HR_LOCATIONS_V.location_id%TYPE;
   l_STATUS_MESSAGE                         APPS.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE;

   -- hr_assignment_api.update_emp_asg
   -- INPUT
   l_asg_effective_start_date               APPS.PER_ASSIGNMENTS_X.effective_start_date%TYPE;
   l_ass_attribute_category                 APPS.PER_ASSIGNMENTS_X.ASS_ATTRIBUTE_CATEGORY%TYPE := NULL;
   l_ass_attribute1                         APPS.PER_ASSIGNMENTS_X.ASS_ATTRIBUTE1%TYPE         := NULL;
   l_ass_attribute7                         APPS.PER_ASSIGNMENTS_X.ASS_ATTRIBUTE7%TYPE         := NULL;
   l_ass_attribute8                         APPS.PER_ASSIGNMENTS_X.ASS_ATTRIBUTE8%TYPE         := NULL;
   l_segment1                               VARCHAR2(60);
   l_segment2                               VARCHAR2(60);
   l_segment3                               VARCHAR2(60);
   l_segment4                               VARCHAR2(60);
   l_segment8                               VARCHAR2(60);
   l_segment20                              VARCHAR2(60);
   l_segment21                              VARCHAR2(60);
   l_concatenated_segments                  VARCHAR2 (1000);                    -- out nocopy varchar2
   l_soft_coding_keyflex_id                 NUMBER;                             -- in out nocopy number
   -- OUTPUT
   l_comment_id                             NUMBER;
   l_effective_start_date                   DATE;
   l_effective_end_date                     DATE;
   l_no_managers_warning                    BOOLEAN;
   l_other_manager_warning                  BOOLEAN;
   l_employee_category                      VARCHAR2 (100);
   l_hourly_salaried_warning                BOOLEAN;
   l_cagr_concatenated_segments             VARCHAR2 (1000);
   l_cagr_grade_def_id                      NUMBER;

   -- hr_assignment_api.update_emp_asg_criteria
   -- OUTPUT
   io_people_group_id                       NUMBER;                             --  in out nocopy number
   io_special_ceiling_step_id               NUMBER;                             --  in out nocopy number
   io_soft_coding_keyflex_id                NUMBER;                             --  in out nocopy number
   o_group_name                             VARCHAR2 (255);                     --  out nocopy varchar2
   o_effective_start_date                   DATE;                               --  out nocopy date
   o_effective_end_date                     DATE;                               --  out nocopy date
   o_org_now_no_manager_warning             BOOLEAN;                            --  out nocopy boolean
   o_other_manager_warning                  BOOLEAN;                            --  out nocopy boolean
   o_spp_delete_warning                     BOOLEAN;                            --  out nocopy boolean
   o_entries_changed_warning                VARCHAR2 (1000);                    --  out nocopy varchar2
   o_tax_district_changed_warning           BOOLEAN;                            --  out nocopy boolean
   o_concatenated_segments                  VARCHAR2 (100);
   o_gsp_post_process_warning               VARCHAR2 (100);

-- Cursor to retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100(c_RECORD_ID HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , FIRST_NAME
  , MIDDLE_NAMES
  , LAST_NAME
  , ASSIGNMENT_ID
  , ORGANIZATION_ID
  , ORGANIZATION
  , JOB_ID
  , JOB_FAMILY
  , JOB_NAME
  , JOB_DEFINITION_ID
  , GRADE_ID
  , GRADE
  , LOCATION_ID
  , LOCATION
  , ASSIGNMENT_CATEGORY
  , ASSIGNMENT_DESCRIPTION 
  , ASSIGNMENT_STATUS_TYPE_ID
  , USER_STATUS
  , SUP_PERSON_ID
  , SUP_EMPLOYEE_NUMBER
  , CONTRACT_END_DATE
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
  , COST_ALLOCATION_KEYFLEX_ID
  , COST_ACCOUNT
  , LEAVE_REASON_CODE
  , LEAVE_REASON
  , LAST_DAY_WORKED
--
  , WD_RECORD_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    WD_RECORD_ID = c_RECORD_ID
;

-- Retrieve object_version_number for assignment_id
CURSOR cur_0200 (c_person_id APPS.per_all_assignments_f.assignment_id%TYPE)
IS
SELECT 
    pax.object_version_number
  , pax.Assignment_id
  , pax.Effective_Start_Date
FROM
    apps.per_assignments_x pax
WHERE
    pax.person_id        = c_person_id
;

-- Retrieve object_version_number for per_all_people_f
CURSOR cur_0210 (c_person_id APPS.per_all_people_f.person_id%TYPE)
IS
SELECT 
    pap.object_version_number
FROM
    apps.per_all_people_f pap
WHERE
    pap.person_id       = c_person_id
;

-- Retrieve data in HAEMO.XXHA_WD_EMPLOYEE_MAPPPING
CURSOR cur_0300 (c_LOCATION apps.HR_LOCATIONS_V.location_code%TYPE)
IS
SELECT
    BUSINESS_GROUP
  , BUSINESS_GROUP_ID
  , LOCATION
  , LOCATION_ID
  , SEX
  , DATE_OF_BIRTH
  , ORGANIZATION_ID
  , ORGANIZATION_NAME
  , ORGANIZATION_COUNTRY
  , JOB_ID
  , JOB_FAMILY
  , JOB_NAME
  , JOB_DEFINITION_ID
  , JOB_GRADE_ID
  , JOB_GRADE
  , PAYROLL_ID
  , PAYROLL_NAME
  , SET_OF_BOOKS_ID
  , LEDGER
  , PAY_BASIS_ID
  , SALARY_PAY_BASIS
  , HOURLY_SALARIED_CODE
  , HOURLY_SALARIED_MEANING
  , SOFT_CODING_KEYFLEX_ID
  , SOFT_CODING_KEYFLEX_MEANING
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
  , NATIONALITY
  , CORRESPONDENCE_LANGUAGE
  , ATTRIBUTE_CATEGORY
  , PER_INFORMATION_CATEGORY
  , PER_INFORMATION1
  , PER_INFORMATION2
  , PER_INFORMATION3
  , PER_INFORMATION4
  , PER_INFORMATION5
  , PER_INFORMATION6
  , PER_INFORMATION7
  , PER_INFORMATION8
  , PER_INFORMATION9
  , PER_INFORMATION10
  , PER_INFORMATION18
  , PER_INFORMATION19
  , ASS_ATTRIBUTE_CATEGORY
  , ASS_ATTRIBUTE1
  , ASS_ATTRIBUTE7
  , ASS_ATTRIBUTE8
  , EMPLOYEE_CATEGORY
  , SEGMENT8
  , ESTABLISHMENT_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_MAPPPING
WHERE
    LOCATION = c_LOCATION
;

-- Retrieve data in APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0300 (c_PERSON_ID apps.PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , DATE_OF_BIRTH
  , NATIONAL_IDENTIFIER
  , TITLE
  , TITLE_CODE
  , FIRST_NAME
  , MIDDLE_NAMES
  , LAST_NAME
  , SUFFIX
  , FULL_NAME
  , KNOWN_AS
  , ORIGINAL_DATE_OF_HIRE
  , START_DATE
  , HAEMO_EMAIL_REQUIRED
  , NON_HAEMO_EMAIL_ADDRESS
  , BUSINESS_GROUP_ID
  , BUSINESS_GROUP
  , PERSON_TYPE_ID
  , PERSON_TYPE
  , PHONE_WORK
  , PHONE_WORK_PHONE_ID
  , PHONE_WORK_PARENT_ID
  , PHONE_WORK_LAST_UPDATE_DATE
  , PHONE_WORK_DATE_FROM
  , PHONE_WORK_DATE_TO
  , PHONE_FAX
  , PHONE_FAX_PHONE_ID
  , PHONE_FAX_PARENT_ID
  , PHONE_FAX_LAST_UPDATE_DATE
  , PHONE_FAX_DATE_FROM
  , PHONE_FAX_DATE_TO
  , PHONE_MOBILE
  , PHONE_MOBILE_PHONE_ID
  , PHONE_MOBILE_PARENT_ID
  , PHONE_MOBILE_LAST_UPDATE_DATE
  , PHONE_MOBILE_DATE_FROM
  , PHONE_MOBILE_DATE_TO
  , USER_NAME
-- PER_ASSIGNMENTS_X
  , ASSIGNMENT_ID
  , ORGANIZATION_ID
  , ORGANIZATION
  , JOB_ID
  , JOB_FAMILY
  , JOB_NAME
  , JOB_DEFINITION_ID
  , GRADE_ID
  , GRADE
  , LOCATION_ID
  , LOCATION
  , COUNTRY
  , ASSIGNMENT_MEANING
  , ASSIGNMENT_CATEGORY
  , ASSIGNMENT_DESCRIPTION
  , ASSIGNMENT_STATUS_TYPE_ID
  , USER_STATUS
  , SUP_PERSON_ID
  , SUP_EMPLOYEE_NUMBER
  , SUP_FULL_NAME
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
  , COST_ALLOCATION_KEYFLEX_ID
  , COST_ACCOUNT
--
  , HOURLY_SALARIED_CODE
  , SOFT_CODING_KEYFLEX_ID
  , PAYROLL_ID
  , PAYROLL_NAME
  , PAY_BASIS_ID
  , SALARY_PAY_BASIS
  , SET_OF_BOOKS_ID
  , LEDGER
  , ACTUAL_TERM_DATE
  , LEAVING_REASON
  , TERM_REASON
  , LAST_WORKING_DAY
--
  , EMAIL_ADDRESS
  , PPX_OBJECT_VERSION_NUMBER
  , PPX_EFFECTIVE_START_DATE
  , PPX_EFFECTIVE_END_DATE
  , PPX_LAST_UPDATE_DATE
  , PAX_OBJECT_VERSION_NUMBER
  , PAX_EFFECTIVE_START_DATE
  , PAX_EFFECTIVE_END_DATE
  , PAX_LAST_UPDATE_DATE
  , USER_PERSON_TYPE
  , VENDOR
FROM
   APPS.XXHA_WD_EMPLOYEE_V
WHERE
   PERSON_ID = c_PERSON_ID
;

-- Retrieve data in APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0400 (c_PERSON_ID apps.PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , SOFT_CODING_KEYFLEX_ID
  , CODE_COMBINATION_ID
  , COST_ALLOCATION_KEYFLEX_ID
  , SET_OF_BOOKS_ID
  , PAYROLL_ID
  , PAY_BASIS_ID
  , HOURLY_SALARIED_CODE
  , ASS_ATTRIBUTE_CATEGORY
  , ASS_ATTRIBUTE1
  , ASS_ATTRIBUTE7
  , ASS_ATTRIBUTE8
  , ORGANIZATION_ID
  , LOCATION_ID
FROM
   APPS.XXHA_WD_EMPLOYEE_V
WHERE
   PERSON_ID = c_PERSON_ID
;

BEGIN

   -- Initialize Values
   l_Status                       := NULL;
   l_Return                       := NULL;
   lc_PERSON_ID                   := NULL;
   lc_EMPLOYEE_NUMBER             := NULL;
   lc_FIRST_NAME                  := NULL;
   lc_MIDDLE_NAMES                := NULL;
   lc_LAST_NAME                   := NULL;
   lc_ASSIGNMENT_ID               := NULL;
   lc_ORGANIZATION_ID             := NULL;
   lc_ORGANIZATION                := NULL;
   lc_JOB_ID                      := NULL;
   lc_JOB_FAMILY                  := NULL;
   lc_JOB_NAME                    := NULL;
   lc_JOB_DEFINITION_ID           := NULL;
   lc_GRADE_ID                    := NULL;
   lc_GRADE                       := NULL;
   lc_LOCATION_ID                 := NULL;
   lc_LOCATION                    := NULL;
   lc_ASSIGNMENT_CATEGORY         := NULL;
   lc_ASSIGNMENT_DESCRIPTION      := NULL;
   lc_ASSIGNMENT_STATUS_TYPE_ID   := NULL;
   lc_USER_STATUS                 := NULL;
   lc_SUP_PERSON_ID               := NULL;
   lc_SUP_EMPLOYEE_NUMBER         := NULL;
   lc_CONTRACT_END_DATE           := NULL;
   lc_CODE_COMBINATION_ID         := NULL;
   lc_EXPENSE_ACCOUNT             := NULL;
   lc_COST_ALLOCATION_KEYFLEX_ID  := NULL;
   lc_COST_ACCOUNT                := NULL;
   lc_LEAVE_REASON_CODE           := NULL;
   lc_LEAVE_REASON                := NULL;
   lc_LAST_DAY_WORKED             := NULL;
   lc_WD_RECORD_ID                := NULL;

   -- Retrieve data from XXHA_WD_EMPLOYEE_CHANGES for Record_ID
   BEGIN
       OPEN cur_0100(p_RECORD_ID);
      FETCH cur_0100 INTO lc_PERSON_ID, lc_EMPLOYEE_NUMBER, lc_FIRST_NAME, lc_MIDDLE_NAMES, lc_LAST_NAME, lc_ASSIGNMENT_ID, lc_ORGANIZATION_ID, lc_ORGANIZATION, 
                          lc_JOB_ID, lc_JOB_FAMILY, lc_JOB_NAME, lc_JOB_DEFINITION_ID, lc_GRADE_ID, lc_GRADE, lc_LOCATION_ID, lc_LOCATION, 
                          lc_ASSIGNMENT_CATEGORY, lc_ASSIGNMENT_DESCRIPTION, lc_ASSIGNMENT_STATUS_TYPE_ID, lc_USER_STATUS, 
                          lc_SUP_PERSON_ID, lc_SUP_EMPLOYEE_NUMBER, lc_CONTRACT_END_DATE, lc_CODE_COMBINATION_ID, lc_EXPENSE_ACCOUNT,
                          lc_COST_ALLOCATION_KEYFLEX_ID, lc_COST_ACCOUNT, lc_LEAVE_REASON_CODE, lc_LEAVE_REASON, lc_LAST_DAY_WORKED, lc_WD_RECORD_ID;
         IF cur_0100%NOTFOUND THEN
            l_Status := 'FAIL';
            l_Return := ('p_RECORD_ID not found in table, HAEMO.XXHA_WD_EMPLOYEE_CHANGES');
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
         END IF;
      CLOSE cur_0100;
   END;

   -- If no errors then continue on
   IF NVL(l_Status, 'PASS') = 'PASS' THEN

      -- Inialize Values
      l_asg_object_version_number := NULL;
      l_assignment_id             := NULL;
      l_asg_Effective_Start_Date  := NULL;

      -- Retrieve Object_Version_Number, Assignment_ID and Effective_Start_Date for assignment_id using Person_ID
      BEGIN
           OPEN cur_0200(lc_PERSON_ID);
          FETCH cur_0200 INTO l_asg_object_version_number, l_assignment_id, l_asg_Effective_Start_Date;
             IF cur_0200%NOTFOUND THEN
                l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = lc_WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Error retrieving asg.object_version_number: ' || l_asg_object_version_number || ' / ')
              , XXHA.STATUS         = 'FAIL'        
          WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
                l_Return := l_Return || ('Error retrieving asg.object_version_number: ' || l_asg_object_version_number || '/');
         COMMIT;
            END IF;
          CLOSE cur_0200;
      END;

      BEGIN

         -- Inialize Values
         lc_dt_ud_mode := NULL;

         -- Call API to Find Date Track Mode
         dt_api.find_dt_upd_modes
         (
           -- INPUT
           p_effective_date            => TO_DATE(SYSDATE)
         , p_base_table_name           => 'PER_ALL_ASSIGNMENTS_F'
         , p_base_key_column           => 'ASSIGNMENT_ID'
         , p_base_key_value            => l_assignment_id
           -- OUTPUT
         , p_correction                => lb_correction
         , p_update                    => lb_update
         , p_update_override           => lb_update_override
         , p_update_change_insert      => lb_update_change_insert
         );

         IF (lb_update_override = TRUE OR lb_update_change_insert = TRUE) THEN
            lc_dt_ud_mode := 'UPDATE_OVERRIDE';
         END IF;

         IF (lb_correction = TRUE) THEN
            lc_dt_ud_mode := 'CORRECTION';
         END IF;

         IF (lb_update = TRUE) THEN
            lc_dt_ud_mode := 'UPDATE';
         END IF;

         -- Initialize Values
         l_segment1                     := '';
         l_segment2                     := '';
         l_segment3                     := '';
         l_segment4                     := '';
         l_segment8                     := '';
         l_segment20                    := '';
         l_segment21                    := '';
         l_concatenated_segments        := NULL;
         l_soft_coding_keyflex_id       := NULL;
         l_comment_id                   := NULL;
         l_effective_start_date         := NULL;
         l_effective_end_date           := NULL;
         l_no_managers_warning          := FALSE;
         l_other_manager_warning        := FALSE;
         l_Status                       := NULL;
         l_Return                       := NULL;

         l_PERSON_ID                    := NULL;
         l_EMPLOYEE_NUMBER              := NULL;
         l_SOFT_CODING_KEYFLEX_ID       := NULL;
         l_CODE_COMBINATION_ID          := NULL;
         l_COST_ALLOCATION_KEYFLEX_ID   := NULL;
         l_SET_OF_BOOKS_ID              := NULL;
         l_PAYROLL_ID                   := NULL;
         l_PAY_BASIS_ID                 := NULL;
         l_HOURLY_SALARIED_CODE         := NULL;
         l_ASS_ATTRIBUTE_CATEGORY       := NULL;
         l_ASS_ATTRIBUTE1               := NULL;
         l_ASS_ATTRIBUTE7               := NULL;
         l_ASS_ATTRIBUTE8               := NULL;
         l_ORGANIZATION_ID              := NULL;
         l_LOCATION_ID                  := NULL;

         -- Retrieve data from XXHA_WD_EMPLOYEE_V for Record_ID
         BEGIN
             OPEN cur_0400(lc_PERSON_ID);
            FETCH cur_0400 INTO l_PERSON_ID,l_EMPLOYEE_NUMBER,l_SOFT_CODING_KEYFLEX_ID,l_CODE_COMBINATION_ID,l_COST_ALLOCATION_KEYFLEX_ID,l_SET_OF_BOOKS_ID,
                                l_PAYROLL_ID, l_PAY_BASIS_ID, l_HOURLY_SALARIED_CODE,l_ASS_ATTRIBUTE_CATEGORY,l_ASS_ATTRIBUTE1,l_ASS_ATTRIBUTE7,l_ASS_ATTRIBUTE8,
                                l_ORGANIZATION_ID,l_LOCATION_ID;
               IF cur_0400%NOTFOUND THEN
                  l_Status := 'FAIL';
                  l_Return := l_Return || ('lc_PERSON_ID not found in table, HAEMO.XXHA_WD_EMPLOYEE_V' || '/');
               END IF;
               IF cur_0400%FOUND THEN
                  l_Status := 'PASS';
               END IF;
            CLOSE cur_0400;
         END;

         -- Call API to update Employee Assignments (i.e. Supervisor, GL Code, Set of Books, Hourly/Salaried, SOFT_CODING_KEYFLEX_ID, Employee Category, etc.)
         -- ORA-20001: HR_500161_ASG_INV_SOB_DCC
         --     There is no value in the Oracle Assignment record for Purchase Order Information - Ledger
         hr_assignment_api.update_emp_asg
         ( 
           p_validate                       => FALSE
         , p_effective_date                 => TO_DATE(SYSDATE)
         , p_datetrack_update_mode          => lc_dt_ud_mode
         , p_assignment_id                  => l_assignment_id
         , p_object_version_number          => l_asg_object_version_number
         , p_supervisor_id                  => lc_SUP_PERSON_ID
         , p_default_code_comb_id           => lc_CODE_COMBINATION_ID
         , p_hourly_salaried_code           => l_HOURLY_SALARIED_CODE
         , p_ass_attribute_category         => l_ASS_ATTRIBUTE_CATEGORY
         , p_ass_attribute1                 => l_ASS_ATTRIBUTE1
         , p_ass_attribute7                 => l_ASS_ATTRIBUTE7
         , p_ass_attribute8                 => l_ASS_ATTRIBUTE8
         , p_segment1                       => l_segment1
         , p_segment2                       => l_segment2
         , p_segment3                       => l_segment3
         , p_segment4                       => l_segment4
         , p_segment8                       => l_segment8
         , p_segment20                      => l_segment20
         , p_segment21                      => l_segment21
         , p_concatenated_segments          => l_concatenated_segments
         , p_soft_coding_keyflex_id         => l_SOFT_CODING_KEYFLEX_ID
         , p_comment_id                     => l_comment_id
         , p_effective_start_date           => l_effective_start_date
         , p_effective_end_date             => l_effective_end_date
         , p_no_managers_warning            => l_no_managers_warning
         , p_other_manager_warning          => l_other_manager_warning
         , p_employee_category              => NULL
         , p_hourly_salaried_warning        => l_hourly_salaried_warning
         , p_cagr_concatenated_segments     => l_cagr_concatenated_segments
         , p_cagr_grade_def_id              => l_cagr_grade_def_id                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       --v6.4
         );
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL';
                l_Return := 'API Error: hr_assignment_api.update_emp_asg: ' || SQLERRM;
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = lc_WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
         COMMIT;
      END IF;

      -- If no errors, continue on
      IF NVL(l_Status,'PASS') = 'PASS' THEN

         -- Initialize Values
         io_people_group_id                := NULL;
         io_special_ceiling_step_id        := NULL;
         o_group_name                      := NULL;
         o_effective_start_date            := NULL;
         o_effective_end_date              := NULL;
         o_org_now_no_manager_warning      := FALSE;
         o_other_manager_warning           := FALSE;
         o_spp_delete_warning              := FALSE;
         o_entries_changed_warning         := NULL;
         o_tax_district_changed_warning    := FALSE;
         o_concatenated_segments           := NULL;
         o_gsp_post_process_warning        := NULL;
         io_soft_coding_keyflex_id         := NULL;

         -- Inialize Values
         l_asg_object_version_number       := NULL;
         l_assignment_id                   := NULL;
         l_Effective_Start_Date            := NULL;

         -- Retrieve Object_Version_Number, Assignment_ID and Effective_Start_Date for assignment_id using Person_ID
         BEGIN
              OPEN cur_0200(lc_PERSON_ID);
             FETCH cur_0200 INTO l_asg_object_version_number, l_assignment_id, l_Effective_Start_Date;
                IF cur_0200%NOTFOUND THEN
                   l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = lc_WD_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Error retrieving asg.object_version_number for Person_ID.' || ' / ')
                 , XXHA.STATUS         = 'FAIL'        
             WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
            COMMIT;
               END IF;
             CLOSE cur_0200;
         END;

         -- Continue on but only if l_asg_object_version_number was retrieved
         IF l_asg_object_version_number IS NOT NULL THEN

            BEGIN

            -- Inialize Values
            l_Status        := NULL;
            l_Return        := NULL;
            lc_dt_ud_mode   := NULL;

            -- Call API to Find Date Track Mode
            dt_api.find_dt_upd_modes
            (
              -- INPUT
              p_effective_date         => TO_DATE(SYSDATE)        
            , p_base_table_name        => 'PER_ALL_ASSIGNMENTS_F'
            , p_base_key_column        => 'ASSIGNMENT_ID'
            , p_base_key_value         => l_assignment_id
              -- OUTPUT
            , p_correction             => lb_correction
            , p_update                 => lb_update
            , p_update_override        => lb_update_override
            , p_update_change_insert   => lb_update_change_insert
            );

            IF (lb_update_override = TRUE OR lb_update_change_insert = TRUE) THEN
               lc_dt_ud_mode := 'UPDATE_OVERRIDE';
            END IF;

            IF (lb_correction = TRUE) THEN
               lc_dt_ud_mode := 'CORRECTION';
            END IF;

            IF ( lb_update = TRUE ) THEN
               lc_dt_ud_mode := 'UPDATE';
            END IF;

            -- Call API to Update JOB_GRADE_ID, JOB_ID, PAYROLL_ID, LOCATION_ID, ORGANIZATION_ID, PAY_BASIS_ID, ASSIGNMENT_LOOKUP_CODE,
            -- ESTABLISHMENT_ID and SOFT_CODING_KEYFLEX_ID
            hr_assignment_api.update_emp_asg_criteria
            (
              -- INPUT
              p_effective_date                => TO_DATE(SYSDATE)
            , p_validate                      => FALSE
            , p_datetrack_update_mode         => lc_dt_ud_mode
            , p_object_version_number         => l_asg_object_version_number
            , p_assignment_id                 => l_assignment_id
            , p_grade_id                      => lc_GRADE_ID
            , p_position_id                   => NULL
            , p_job_id                        => lc_JOB_ID
            , p_payroll_id                    => l_PAYROLL_ID
            , p_location_id                   => lc_LOCATION_ID
            , p_organization_id               => lc_ORGANIZATION_ID
            , p_pay_basis_id                  => l_PAY_BASIS_ID
            , p_employment_category           => lc_ASSIGNMENT_CATEGORY
            , p_establishment_id              => lc_ESTABLISHMENT_ID
            , p_people_group_id               => io_people_group_id
            , p_soft_coding_keyflex_id        => io_SOFT_CODING_KEYFLEX_ID
            , p_special_ceiling_step_id       => io_special_ceiling_step_id
              -- OUTPUT
            , p_group_name                    => o_group_name
            , p_effective_start_date          => o_effective_start_date
            , p_effective_end_date            => o_effective_end_date
            , p_org_now_no_manager_warning    => o_org_now_no_manager_warning
            , p_other_manager_warning         => o_other_manager_warning
            , p_spp_delete_warning            => o_spp_delete_warning
            , p_entries_changed_warning       => o_entries_changed_warning
            , p_tax_district_changed_warning  => o_tax_district_changed_warning
            , p_concatenated_segments         => o_concatenated_segments
            , p_gsp_post_process_warning      => o_gsp_post_process_warning
            );
            EXCEPTION
                 WHEN OTHERS THEN
                      ROLLBACK;
                      l_Status := 'FAIL';
                      l_Return := 'API Error: hr_assignment_api.update_emp_asg_criteria: ' || SQLERRM;
            END;

            -- Check for errors
            IF NVL(l_Status,'PASS') = 'PASS' THEN
               COMMIT;
            ELSE
               FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
               l_STATUS_MESSAGE := NULL;
               SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
                  SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
                    , XXHA.STATUS         = 'FAIL'
                WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
               COMMIT;
            END IF;

         END IF; -- IF l_asg_object_version_number IS NOT NULL

      END IF; -- IF NVL(l_Status, 'PASS') = 'PASS'

   END IF; -- IF NVL(l_Status, 'PASS') = 'PASS'

   END;

END XXHA_WD_EMPLOYEE_ASSGN_REC_UPD;


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_COST(
          p_RECORD_ID                       IN  NUMBER) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                                     := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE         := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;
   l_decimal1                               NUMBER := 0;
   l_decimal2                               NUMBER := 0;
   l_decimal3                               NUMBER := 0;
   l_decimal4                               NUMBER := 0;

   -- Cursor cur_0100
   lc_PERSON_ID                             APPS.PER_PEOPLE_X.Person_ID%TYPE;
   lc_EMPLOYEE_NUMBER                       APPS.PER_PEOPLE_X.EMPLOYEE_NUMBER%TYPE;
   lc_FIRST_NAME                            APPS.PER_PEOPLE_X.FIRST_NAME%TYPE;
   lc_MIDDLE_NAMES                          APPS.PER_PEOPLE_X.MIDDLE_NAMES%TYPE;
   lc_LAST_NAME                             APPS.PER_PEOPLE_X.LAST_NAME%TYPE;
   lc_ASSIGNMENT_ID                         APPS.PER_ASSIGNMENTS_X.ASSIGNMENT_ID%TYPE;
   lc_ORGANIZATION_ID                       APPS.PER_ASSIGNMENTS_X.ORGANIZATION_ID%TYPE;
   lc_ORGANIZATION                          APPS.HR_ALL_ORGANIZATION_UNITS.name%TYPE;
   lc_JOB_ID                                APPS.PER_ASSIGNMENTS_X.JOB_ID%TYPE;
   lc_JOB_FAMILY                            APPS.per_jobs.Job_Information9%TYPE;
   lc_JOB_NAME                              APPS.per_jobs.name%TYPE;
   lc_JOB_DEFINITION_ID                     APPS.per_jobs.job_definition_id%TYPE;
   lc_GRADE_ID                              APPS.PER_ASSIGNMENTS_X.GRADE_ID%TYPE;
   lc_GRADE                                 APPS.per_grades.name%TYPE;
   lc_LOCATION_ID                           APPS.HR_LOCATIONS_V.location_id%TYPE;
   lc_LOCATION                              APPS.HR_LOCATIONS_V.location_code%TYPE;
   lc_ASSIGNMENT_DESCRIPTION                APPS.hr_lookups.Description%TYPE;
   lc_ASSIGNMENT_CATEGORY                   APPS.hr_lookups.LOOKUP_CODE%TYPE;
   lc_ASSIGNMENT_MEANING                    APPS.hr_lookups.MEANING%TYPE;
   lc_ASSIGNMENT_STATUS_TYPE_ID             APPS.PER_ASSIGNMENT_STATUS_TYPES.ASSIGNMENT_STATUS_TYPE_ID%TYPE;
   lc_USER_STATUS                           APPS.per_assignment_status_types.User_Status%TYPE;
   lc_SUP_PERSON_ID                         APPS.PER_PEOPLE_X.Person_ID%TYPE;
   lc_SUP_EMPLOYEE_NUMBER                   APPS.PER_PEOPLE_X.EMPLOYEE_NUMBER%TYPE;
   lc_CONTRACT_END_DATE                     DATE;
   lc_CODE_COMBINATION_ID                   APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   lc_EXPENSE_ACCOUNT                       VARCHAR2(240);
   lc_COST_ALLOCATION_KEYFLEX_ID            APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   lc_COST_ACCOUNT                          VARCHAR2(240);
   lc_LEAVE_REASON_CODE                     APPS.hr_lookups.LOOKUP_CODE%TYPE;
   lc_LEAVE_REASON                          APPS.hr_lookups.MEANING%TYPE;
   lc_LAST_DAY_WORKED                       DATE;
   lc_WD_RECORD_ID                          HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE;
   lc_ESTABLISHMENT_ID                      NUMBER;

   -- Cursor cur_0200
   lv_PERSON_ID                             APPS.XXHA_WD_EMPLOYEE_V.Person_ID%TYPE;
   lv_BUSINESS_GROUP_ID                     APPS.XXHA_WD_EMPLOYEE_V.BUSINESS_GROUP_ID%TYPE;
   lv_ASSIGNMENT_ID                         APPS.XXHA_WD_EMPLOYEE_V.ASSIGNMENT_ID%TYPE;
   lv_PCAK_OBJECT_VERSION_NUMBER            APPS.XXHA_WD_EMPLOYEE_V.PCAK_OBJECT_VERSION_NUMBER%TYPE;
   lv_CODE_COMBINATION_ID                   APPS.XXHA_WD_EMPLOYEE_V.CODE_COMBINATION_ID%TYPE;
   lv_EXPENSE_ACCOUNT                       APPS.XXHA_WD_EMPLOYEE_V.EXPENSE_ACCOUNT%TYPE;
   lv_COST_ALLOCATION_ID                    APPS.XXHA_WD_EMPLOYEE_V.COST_ALLOCATION_ID%TYPE;
   lv_COST_ALLOCATION_KEYFLEX_ID            APPS.XXHA_WD_EMPLOYEE_V.COST_ALLOCATION_KEYFLEX_ID%TYPE;
   lv_COST_ACCOUNT                          APPS.XXHA_WD_EMPLOYEE_V.COST_ACCOUNT%TYPE;

   -- PAY_COST_ALLOCATION_API
   -- IN variables
   l_assignment_id                          APPS.PER_ASSIGNMENTS_X.assignment_id%TYPE                        := NULL;
   l_proportion                             APPS.pay_cost_allocations_f.proportion%TYPE                      := 1;
   l_segment1                               APPS.pay_cost_allocation_keyflex.segment1%TYPE                   := NULL;
   l_segment2                               APPS.pay_cost_allocation_keyflex.segment2%TYPE                   := NULL;
   l_segment3                               APPS.pay_cost_allocation_keyflex.segment3%TYPE                   := NULL;
   l_segment4                               APPS.pay_cost_allocation_keyflex.segment4%TYPE                   := NULL;
   l_segment5                               APPS.pay_cost_allocation_keyflex.segment5%TYPE                   := NULL;
   l_segment6                               APPS.pay_cost_allocation_keyflex.segment6%TYPE                   := NULL;
   l_segment7                               APPS.pay_cost_allocation_keyflex.segment7%TYPE                   := NULL;
   l_segment8                               APPS.pay_cost_allocation_keyflex.segment8%TYPE                   := NULL;
   l_segment9                               APPS.pay_cost_allocation_keyflex.segment9%TYPE                   := NULL;
   -- OUT variables
   l_combination_name                       VARCHAR2(240);
   l_cost_effective_start_date              DATE;
   l_cost_effective_end_date                DATE;
   l_Cost_Allocation_Keyflex_id             APPS.pay_cost_allocation_keyflex.cost_allocation_keyflex_id%type;
   l_cost_obj_version_number                NUMBER;
   l_cost_allocation_id                     NUMBER;

-- Cursor to retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100(c_RECORD_ID HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , FIRST_NAME
  , MIDDLE_NAMES
  , LAST_NAME
  , ASSIGNMENT_ID
  , ORGANIZATION_ID
  , ORGANIZATION
  , JOB_ID
  , JOB_FAMILY
  , JOB_NAME
  , JOB_DEFINITION_ID
  , GRADE_ID
  , GRADE
  , LOCATION_ID
  , LOCATION
  , ASSIGNMENT_CATEGORY
  , ASSIGNMENT_DESCRIPTION 
  , ASSIGNMENT_STATUS_TYPE_ID
  , USER_STATUS
  , SUP_PERSON_ID
  , SUP_EMPLOYEE_NUMBER
  , CONTRACT_END_DATE
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
  , COST_ALLOCATION_KEYFLEX_ID
  , COST_ACCOUNT
  , LEAVE_REASON_CODE
  , LEAVE_REASON
  , LAST_DAY_WORKED
  , WD_RECORD_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    WD_RECORD_ID = c_RECORD_ID
;

-- Cursor to retrieve record from APPS.XXHA_WD_EMPLOYEE_V
CURSOR cur_0200(c_PERSON_ID APPS.XXHA_WD_EMPLOYEE_V.PERSON_ID%TYPE)
IS
SELECT
    PERSON_ID
  , BUSINESS_GROUP_ID
  , ASSIGNMENT_ID
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
  , COST_ALLOCATION_ID
  , PCAK_OBJECT_VERSION_NUMBER
  , COST_ALLOCATION_KEYFLEX_ID
  , COST_ACCOUNT
FROM
    APPS.XXHA_WD_EMPLOYEE_V
WHERE
    Person_ID = c_PERSON_ID
;

BEGIN

   -- Initialize Values
   l_Status                       := NULL;
   l_Return                       := NULL;
   lc_PERSON_ID                   := NULL;
   lc_EMPLOYEE_NUMBER             := NULL;
   lc_FIRST_NAME                  := NULL;
   lc_MIDDLE_NAMES                := NULL;
   lc_LAST_NAME                   := NULL;
   lc_ASSIGNMENT_ID               := NULL;
   lc_ORGANIZATION_ID             := NULL;
   lc_ORGANIZATION                := NULL;
   lc_JOB_ID                      := NULL;
   lc_JOB_FAMILY                  := NULL;
   lc_JOB_NAME                    := NULL;
   lc_JOB_DEFINITION_ID           := NULL;
   lc_GRADE_ID                    := NULL;
   lc_GRADE                       := NULL;
   lc_LOCATION_ID                 := NULL;
   lc_LOCATION                    := NULL;
   lc_ASSIGNMENT_CATEGORY         := NULL;
   lc_ASSIGNMENT_DESCRIPTION      := NULL;
   lc_ASSIGNMENT_STATUS_TYPE_ID   := NULL;
   lc_USER_STATUS                 := NULL;
   lc_SUP_PERSON_ID               := NULL;
   lc_SUP_EMPLOYEE_NUMBER         := NULL;
   lc_CONTRACT_END_DATE           := NULL;
   lc_CODE_COMBINATION_ID         := NULL;
   lc_EXPENSE_ACCOUNT             := NULL;
   lc_COST_ALLOCATION_KEYFLEX_ID  := NULL;
   lc_COST_ACCOUNT                := NULL;
   lc_LEAVE_REASON_CODE           := NULL;
   lc_LEAVE_REASON                := NULL;
   lc_LAST_DAY_WORKED             := NULL;
   lc_WD_RECORD_ID                := NULL;

   -- Retrieve data from XXHA_WD_EMPLOYEE_CHANGES for Record_ID
   BEGIN
       OPEN cur_0100(p_RECORD_ID);
      FETCH cur_0100 INTO lc_PERSON_ID, lc_EMPLOYEE_NUMBER, lc_FIRST_NAME, lc_MIDDLE_NAMES, lc_LAST_NAME, lc_ASSIGNMENT_ID, lc_ORGANIZATION_ID, lc_ORGANIZATION, 
                          lc_JOB_ID, lc_JOB_FAMILY, lc_JOB_NAME, lc_JOB_DEFINITION_ID, lc_GRADE_ID, lc_GRADE, lc_LOCATION_ID, lc_LOCATION, 
                          lc_ASSIGNMENT_CATEGORY, lc_ASSIGNMENT_DESCRIPTION, lc_ASSIGNMENT_STATUS_TYPE_ID, lc_USER_STATUS, 
                          lc_SUP_PERSON_ID, lc_SUP_EMPLOYEE_NUMBER, lc_CONTRACT_END_DATE, lc_CODE_COMBINATION_ID, lc_EXPENSE_ACCOUNT,
                          lc_COST_ALLOCATION_KEYFLEX_ID, lc_COST_ACCOUNT, lc_LEAVE_REASON_CODE, lc_LEAVE_REASON, lc_LAST_DAY_WORKED, lc_WD_RECORD_ID;
         IF cur_0100%NOTFOUND THEN
            l_Status := 'FAIL';
            l_Return := ('p_RECORD_ID not found in table, HAEMO.XXHA_WD_EMPLOYEE_CHANGES' || '/');
         END IF;
      CLOSE cur_0100;
   END;

   -- Initialize Values
   lv_PERSON_ID                   := NULL;
   lv_BUSINESS_GROUP_ID           := NULL;
   lv_ASSIGNMENT_ID               := NULL;
   lv_CODE_COMBINATION_ID         := NULL;
   lv_EXPENSE_ACCOUNT             := NULL;
   lv_COST_ALLOCATION_ID          := NULL;
   lv_PCAK_OBJECT_VERSION_NUMBER  := NULL;
   lv_COST_ALLOCATION_KEYFLEX_ID  := NULL;
   lv_COST_ACCOUNT                := NULL;

   -- Retrieve data from APPS.XXHA_WD_EMPLOYEE_V for Person_ID
   BEGIN
       OPEN cur_0200(lc_PERSON_ID);
      FETCH cur_0200 INTO lv_PERSON_ID, lv_BUSINESS_GROUP_ID, lv_ASSIGNMENT_ID, lv_CODE_COMBINATION_ID, lv_EXPENSE_ACCOUNT, 
                          lv_COST_ALLOCATION_ID, lv_PCAK_OBJECT_VERSION_NUMBER, lv_COST_ALLOCATION_KEYFLEX_ID, lv_COST_ACCOUNT;
         IF cur_0200%NOTFOUND THEN
            l_Status := 'FAIL';
            l_Return := ('lc_PERSON_ID not found in table, HAEMO.XXHA_WD_EMPLOYEE_CHANGES' || '/');
         END IF;
      CLOSE cur_0200;
   END;

   -- Initialize Values   '710.100.4014.6000.600010'
   l_decimal1 := 0;
   l_decimal2 := 0;
   l_decimal3 := 0;
   l_decimal4 := 0;
   l_segment1 := NULL;
   l_segment3 := NULL;
   l_segment4 := NULL;
   l_segment5 := NULL;
   l_segment6 := NULL;

   -- Determine where '.' occurs in lc_COST_ACCOUNT
   l_decimal1 := (instr(lc_COST_ACCOUNT,'.',1,1));
   l_decimal2 := (instr(lc_COST_ACCOUNT,'.',1,2));
   l_decimal3 := (instr(lc_COST_ACCOUNT,'.',1,3));
   l_decimal4 := (instr(lc_COST_ACCOUNT,'.',1,4));

   -- Retrieve each segment
   l_segment1 := SUBSTR(lc_COST_ACCOUNT,1,(l_decimal1)-1);
   l_segment3 := SUBSTR(lc_COST_ACCOUNT,((l_decimal1)+1),((l_decimal2)+0)-((l_decimal1)+1)); 
   l_segment4 := SUBSTR(lc_COST_ACCOUNT,((l_decimal2)+1),((l_decimal3)+0)-((l_decimal2)+1));
   l_segment5 := SUBSTR(lc_COST_ACCOUNT,((l_decimal3)+1),((l_decimal4)+0)-((l_decimal3)+1));
   l_segment6 := SUBSTR(lc_COST_ACCOUNT,((l_decimal4)+1),10);

   IF lv_COST_ALLOCATION_KEYFLEX_ID IS NOT NULL THEN
--   IF lc_COST_ALLOCATION_KEYFLEX_ID IS NOT NULL THEN

      BEGIN

      -- Call API to Update Cost Allocation
      pay_cost_allocation_api.update_cost_allocation
      (
        -- INPUT
        p_validate                     => FALSE
      , p_effective_date               => TO_DATE(SYSDATE)
      , p_datetrack_update_mode        => 'UPDATE'
      , p_cost_allocation_id           => lv_COST_ALLOCATION_ID
      , p_proportion                   => l_proportion
      , p_segment1                     => l_segment1                            -- LEGAL_ENTITY
      --, p_segment2                     => l_segment2                          -- PRODUCT_LINE
      , p_segment3                     => l_segment3                            -- BUSINESS_UNIT
      , p_segment4                     => l_segment4                            -- MANAGAMENT_UNIT
      , p_segment5                     => l_segment5                            -- DEPARTMENT
      , p_segment6                     => l_segment6                            -- ACCOUNT
      --, p_segment7                     => l_segment7                          -- INTERCOMPANY
      --, p_segment8                     => l_segment8                          -- FUTURE1
      --, p_segment9                     => l_segment9                          -- FUTURE2
        -- INPUT/OUTPUT
      , p_cost_allocation_keyflex_id   => lc_COST_ALLOCATION_KEYFLEX_ID
      , p_object_version_number        => lv_PCAK_OBJECT_VERSION_NUMBER
        -- OUTPUT
      , p_effective_start_date         => l_cost_effective_start_date
      , p_effective_end_date           => l_cost_effective_end_date
      , p_combination_name             => l_combination_name
      );
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL';
                l_Return := 'API Error: pay_cost_allocation_api.update_cost_allocation: ' || SQLERRM;
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = lc_WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
         COMMIT;
      END IF;

   ELSE

      BEGIN

      -- Call API to Create Cost Allocation
      pay_cost_allocation_api.create_cost_allocation
      ( 
        -- INPUT
        p_validate                     => FALSE
      , p_effective_date               => TO_DATE(SYSDATE)
      , p_assignment_id                => lv_assignment_id
      , p_proportion                   => l_proportion
      , p_business_group_id            => lv_business_group_id
      , p_segment1                     => l_segment1                            -- LEGAL_ENTITY
      --, p_segment2                     => l_segment2                          -- PRODUCT_LINE
      , p_segment3                     => l_segment3                            -- BUSINESS_UNIT
      , p_segment4                     => l_segment4                            -- MANAGAMENT_UNIT
      , p_segment5                     => l_segment5                            -- DEPARTMENT
      , p_segment6                     => l_segment6                            -- ACCOUNT
      --, p_segment7                     => l_segment7                          -- INTERCOMPANY
      --, p_segment8                     => l_segment8                          -- FUTURE1
      --, p_segment9                     => l_segment9                          -- FUTURE2
        -- OUTPUT
      , p_combination_name             => l_combination_name 
      , p_cost_allocation_id           => l_cost_allocation_id  
      , p_effective_start_date         => l_cost_effective_start_date   
      , p_effective_end_date           => l_cost_effective_end_date               
      , p_object_version_number        => l_cost_obj_version_number  
        -- INPUT/OUTPUT
      , p_cost_allocation_keyflex_id   => l_cost_allocation_keyflex_id   
      );
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL';
                l_Return := 'API Error: pay_cost_allocation_api.create_cost_allocation: ' || SQLERRM;
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = lc_WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
         COMMIT;
      END IF;

   END IF;

END;

END XXHA_WD_EMPLOYEE_COST;


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_CREATE_JOB(
          p_RECORD_ID                       IN  NUMBER
         ,p_BG_ID                           IN  NUMBER
         ,p_EMPLOYEE_NUMBER                 IN  VARCHAR2
         ,p_JOB_NAME                        IN  VARCHAR2
         ,p_BG_COUNTRY_CODE                 IN  VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                                     := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE         := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;

   l_Attribute1                             VARCHAR(240);
   l_Attribute2                             VARCHAR(240);
   l_Job_Information1                       VARCHAR(240);
   l_Job_Information3                       VARCHAR(240);
   l_Job_Information9                       VARCHAR(240);
   l_Job_Information10                      VARCHAR(240);

   lv_group_name                            VARCHAR2(200)                                       := 'HR_';
   ln_business_group_id                     NUMBER;
   ln_job_name                              APPS.per_jobs.NAME%TYPE;
   ln_job_group_id                          NUMBER; 
   ln_job_id                                APPS.per_jobs.JOB_ID%TYPE;
   ln_object_version_number                 NUMBER;
   ln_job_definition_id                     APPS.per_jobs.JOB_DEFINITION_ID%TYPE;
   lv_job_name                              VARCHAR2(200);
   l_job_name                               APPS.per_jobs.NAME%TYPE;
   l_LENGTH                                 NUMBER;

-- Retrieve data for Value Set
CURSOR cur_0100 (c_JOB_NAME apps.fnd_flex_values.flex_value%TYPE)
IS
SELECT
    ffv.flex_value
FROM 
    apps.fnd_flex_value_sets      ffvs
  , apps.fnd_flex_values          ffv
  , apps.fnd_flex_values_tl       ffvt
WHERE
    ffvs.flex_value_set_id      = ffv.flex_value_set_id
AND ffv.flex_value_id           = ffvt.flex_value_id
AND ffvt.language               = ('US')
AND flex_value_set_name         = 'HAE_GLB_HR_JOB_TITLE_TEXT'
AND TRUNC(SYSDATE)              BETWEEN NVL(TRUNC(ffv.START_DATE_ACTIVE), TRUNC(SYSDATE)-1) AND NVL(TRUNC(ffv.END_DATE_ACTIVE), TRUNC(SYSDATE)+1) -- 2018/05/03 - Added code
AND NVL(ffv.ENABLED_FLAG,'Y')   = 'Y'
AND ffv.flex_value              = c_JOB_NAME
;

-- Retrieve data for job group details
CURSOR cur_0200 (c_internal_name apps.per_job_groups.internal_name%TYPE)
IS
SELECT
    pjg.business_group_id
  , pjg.job_group_id
FROM 
    apps.per_job_groups      pjg
WHERE
    pjg.internal_name      = c_internal_name
;

BEGIN

   BEGIN

      -- Initialize Value
      l_LENGTH    := 0;
      l_job_name  := NULL;
      ln_job_name := NULL;

      -- Get position of period ('.') in the JOB_NAME if it exists (i.e. 'Field Service Engineer II', 'Distribution Specialist USA', 'Site Services Specialist I.126611')
--      l_LENGTH   := (INSTR(p_JOB_NAME,'.', 1, 1));                            -- 2018/05/03 - Commented out code since we will no longer append '.WORKDAY' to the job

      --Determine l_job_name based upon p_JOB_NAME
--      IF l_LENGTH > 0 THEN                                                    -- 2018/05/03 - Commented out code since we will no longer append '.WORKDAY' to the job
--         l_job_name := SUBSTR(p_JOB_NAME,1,(l_LENGTH-1));                     -- 2018/05/03 - Commented out code since we will no longer append '.WORKDAY' to the job
--      ELSE                                                                    -- 2018/05/03 - Commented out code since we will no longer append '.WORKDAY' to the job
         l_job_name := p_JOB_NAME;
--      END IF;

      -- See if JOB_NAME already exists in Value Set: HAE_GLB_HR_JOB_TITLE_TEXT as it may have already been created when procesing another Business Group
       OPEN cur_0100(l_job_name);
      FETCH cur_0100 INTO ln_job_name;
         IF cur_0100%NOTFOUND THEN
            XXHA_WD_EMPLOYEE_CRT_VALUESET(p_RECORD_ID, p_EMPLOYEE_NUMBER, l_job_name);
        END IF;
      CLOSE cur_0100;
   END;

   BEGIN
      -- Initialize Value
      ln_business_group_id := NULL;
      ln_job_group_id      := NULL;

      -- Retrieve job group details
       OPEN cur_0200(lv_group_name || p_BG_ID);
      FETCH cur_0200 INTO ln_business_group_id, ln_job_group_id;
         IF cur_0200%NOTFOUND THEN
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || ('Error: Unable to retrieve job group details.' || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error: Unable to retrieve job group details.');
        END IF;
      CLOSE cur_0200;
   END;

   IF p_BG_ID = 0 THEN
      l_Attribute1              := '3437';
      l_Attribute2              := '24103';
      l_Job_Information1        := '5';
      l_Job_Information3        := 'EX';
      l_Job_Information9        := 'Administration';
      l_Job_Information10       := 'Indirect';
   END IF;

   IF p_BG_ID <> 0 THEN
      l_Attribute1              := '3437';
      l_Attribute2              := '24103';
      l_Job_Information1        := NULL;        
      l_Job_Information3        := NULL;     
      l_Job_Information9        := 'Administration';
      l_Job_Information10       := 'Indirect';      
   END IF;

   BEGIN

   l_job_name := (p_job_name||'.WORKDAY');                                      -- 2018/05/03 - Append '.WORKDAY' to the job here instead of when passing as parameter

   -- Call API to Create Job
   HR_JOB_API.CREATE_JOB
   ( 
     p_validate                        => FALSE
   , p_business_group_id               => ln_business_group_id
   , p_date_from                       => TO_DATE(SYSDATE)
   , p_comments                        => 'Created from Workday'
   , p_date_to                         => NULL
   , p_job_group_id                    => ln_job_group_id
   , p_job_information_category        => p_BG_COUNTRY_CODE                     -- 'US'
   , p_Attribute1                      => l_Attribute1                          -- '3437'                   -- ADP Job Code   (opt)
   , p_Attribute2                      => l_Attribute2                          -- '24103'                  -- HRTMS Job Code (opt)
   , p_Job_Information1                => l_Job_Information1                    -- '2'                      -- EEO Category   (reqd)
   , p_Job_Information3                => l_Job_Information3                    -- 'EX'                     -- FLSA Code      (reqd)
   , p_Job_Information9                => l_Job_Information9                    -- 'Information Technology' -- Job Family     (reqd)
   , p_Job_Information10               => l_Job_Information10                   -- 'Indirect'               -- Labor Category (reqd)
   , p_concat_segments                 => l_job_name                            -- 2018/05/03 - Changed from 'p_JOB_NAME' to 'l_job_name'
   , p_language_code                   => 'US'
   , p_job_id                          => ln_job_id
   , p_object_version_number           => ln_object_version_number
   , p_job_definition_id               => ln_job_definition_id
   , p_name                            => lv_job_name
   );
   EXCEPTION
        WHEN OTHERS THEN
             ROLLBACK;
             l_Status := 'FAIL';
             l_return := ('API Error: HR_JOB_API.CREATE_JOB: ' || l_job_name || ' /  BG_ID: ' || p_BG_ID || ' / ' || SQLERRM); -- 2018/05/03 - Changed 'p_JOB_NAME' to 'l_job_name'
   END;

   -- Check for errors
   IF NVL(l_Status,'PASS') = 'PASS' THEN
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
         SET XXHA.JOB_NAME_ORACLE   = l_job_name                                -- 2018/05/03 - Changed 'p_JOB_NAME' to 'l_job_name'
           , XXHA.JOB_ID            = ln_job_id
           , XXHA.JOB_DEFINITION_ID = ln_job_definition_id
       WHERE XXHA.WD_RECORD_ID      = p_RECORD_ID;
      COMMIT;
   ELSE
      FND_FILE.PUT_LINE(FND_FILE.LOG, l_return);
      l_STATUS_MESSAGE := NULL;
      SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
      UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
         SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_return || ' / ')
           , XXHA.STATUS         = 'FAIL'
       WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
       COMMIT;
   END IF;

END;

END XXHA_WD_EMPLOYEE_CREATE_JOB;     


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_CRT_VALUESET(
          p_RECORD_ID                       IN  NUMBER
         ,p_EMPLOYEE_NUMBER                 IN  VARCHAR2
         ,p_JOB_NAME                        IN  VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                                     := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE         := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;

   l_value_set_name                         VARCHAR2(50)                                       := 'HAE_GLB_HR_JOB_TITLE_TEXT';
   l_enabled_flag                           VARCHAR2(02)                                       := 'Y';
   l_summary_flag                           VARCHAR2(02)                                       := 'N';

BEGIN

   BEGIN

      -- Call API to Create Value in JOB_NAME to Value Set: 'HAE_GLB_HR_JOB_TITLE_TEXT'
      fnd_flex_loader_apis.up_value_set_value
      (
        p_upload_phase                 => 'BEGIN'
      , p_upload_mode                  => NULL
      , p_custom_mode                  => 'FORCE'
      , p_flex_value_set_name          => l_value_set_name
      , p_parent_flex_value_low        => NULL
      , p_flex_value                   => p_JOB_NAME
      , p_owner                        => NULL
      , p_last_update_date             => TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI:SS') -- 2018/05/03 - Was TO_DATE(SYSDATE)
      , p_enabled_flag                 => l_enabled_flag
      , p_summary_flag                 => l_summary_flag
      , p_start_date_active            => TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI:SS') -- 2018/05/03 - Was TO_DATE(SYSDATE)
      , p_end_date_active              => NULL
      , p_parent_flex_value_high       => NULL
      , p_rollup_flex_value_set_name   => NULL
      , p_rollup_hierarchy_code        => NULL
      , p_hierarchy_level              => NULL
      , p_compiled_value_attributes    => NULL
      , p_value_category               => 'VALUE_SET_NAME'                      -- 2018/05/03 - Was NULL 
      , p_attribute1                   => NULL
      , p_attribute2                   => NULL
      , p_attribute3                   => NULL
      , p_attribute4                   => NULL
      , p_attribute5                   => NULL
      , p_attribute6                   => NULL
      , p_attribute7                   => NULL
      , p_attribute8                   => NULL
      , p_attribute9                   => NULL
      , p_attribute10                  => NULL
      , p_attribute11                  => NULL
      , p_attribute12                  => NULL
      , p_attribute13                  => NULL
      , p_attribute14                  => NULL
      , p_attribute15                  => NULL
      , p_attribute16                  => NULL
      , p_attribute17                  => NULL
      , p_attribute18                  => NULL
      , p_attribute19                  => NULL
      , p_attribute20                  => NULL
      , p_attribute21                  => NULL
      , p_attribute22                  => NULL
      , p_attribute23                  => NULL
      , p_attribute24                  => NULL
      , p_attribute25                  => NULL
      , p_attribute26                  => NULL
      , p_attribute27                  => NULL
      , p_attribute28                  => NULL
      , p_attribute29                  => NULL
      , p_attribute30                  => NULL
      , p_attribute31                  => NULL
      , p_attribute32                  => NULL
      , p_attribute33                  => NULL
      , p_attribute34                  => NULL
      , p_attribute35                  => NULL
      , p_attribute36                  => NULL
      , p_attribute37                  => NULL
      , p_attribute38                  => NULL
      , p_attribute39                  => NULL
      , p_attribute40                  => NULL
      , p_attribute41                  => NULL
      , p_attribute42                  => NULL
      , p_attribute43                  => NULL
      , p_attribute44                  => NULL
      , p_attribute45                  => NULL
      , p_attribute46                  => NULL
      , p_attribute47                  => NULL
      , p_attribute48                  => NULL
      , p_attribute49                  => NULL
      , p_ATTRIBUTE50                  => NULL
      , p_flex_value_meaning           => p_JOB_NAME
      , p_description                  => NULL
      );
   EXCEPTION
        WHEN OTHERS THEN
             ROLLBACK;
             l_Status := 'FAIL';
             l_return := ('API Error: fnd_flex_loader_apis.up_value_set_value for HAE_GLB_HR_JOB_TITLE_TEXT: ' || SQLERRM);
   END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_return || ' / ')
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
         COMMIT;
      END IF;

   END;

END XXHA_WD_EMPLOYEE_CRT_VALUESET;    


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_CREATE_GRADE(
          p_RECORD_ID                       IN  NUMBER
         ,p_BG_ID                           IN  NUMBER
         ,p_GRADE_ORACLE                    IN  VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                                     := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE         := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;

   l_nextval                                NUMBER         := NULL;
   l_grade_id                               NUMBER         := NULL;
   l_object_version_number                  NUMBER         := NULL;
   l_grade_definition_id                    NUMBER         := NULL;
   l_sequence                               NUMBER         := 0;
   l_Segment                                VARCHAR2 (100) := NULL;
   l_segment3                               VARCHAR2 (25)  := NULL;
   l_segment2                               VARCHAR2 (25)  := NULL;
   l_segment4                               VARCHAR2 (25)  := NULL;
   l_first_decimal                          NUMBER         := 0;

   l_name                                   VARCHAR2 (500) := NULL;
   l_name_out                               VARCHAR2 (500) := NULL;
   l_err_msg                                VARCHAR2 (500) := NULL;
   l_create_grade_definition                VARCHAR2 (10)  := NULL;
   l_Create_Value_set                       VARCHAR2 (10)  := NULL;
   l_Year                                   VARCHAR2 (100) := NULL;

   l_value_set_name1                        VARCHAR2(50)   := 'HAE_GLB_HR_GRADE';
   l_value_set_name2                        VARCHAR2(50)   := 'HAE_GLB_COUNTRY_ISO_CODE';
   l_enabled_flag                           VARCHAR2(02)   := 'Y';
   l_summary_flag                           VARCHAR2(02)   := 'N';

   lv_grade_definition_id                   APPS.per_grade_definitions.grade_definition_id%TYPE;
   lv_segment3                              APPS.per_grade_definitions.segment3%TYPE;
   lv_segment2                              APPS.per_grade_definitions.segment2%TYPE;
   lv_segment4                              APPS.per_grade_definitions.segment4%TYPE;

-- Retrieve Max Grade Sequence from per_grades
CURSOR cur_0200 (c_business_group_id APPS.per_grades.business_group_id%TYPE)
IS
SELECT
   MAX(pg.sequence)
FROM
   apps.per_grades        pg
WHERE
   pg.business_group_id = c_business_group_id
;

-- Retrieve values from per_grade_definitions
CURSOR cur_0300 (c_segment3 APPS.per_grade_definitions.segment3%TYPE            -- Grade
                ,c_segment2 APPS.per_grade_definitions.segment2%TYPE            -- Legislation Code (i.e. 'CA-N')
                ,c_segment4 APPS.per_grade_definitions.segment4%TYPE)           -- YES/NO/NULL
IS
SELECT
    pgd.grade_definition_id
  , pgd.segment3
  , pgd.segment2
  , pgd.segment4
FROM
    apps.per_grade_definitions     pgd
WHERE
    pgd.segment3                 = c_segment3
AND pgd.segment2                 = c_segment2
AND NVL(pgd.segment4,'XXX')      = NVL(c_segment4,'XXX')
;

-- Retrieve nextval for PER_GRADE_DEFINITIONS
CURSOR cur_0400
IS
SELECT
   PER_GRADE_DEFINITIONS_s.nextval 
FROM 
   sys.dual
;

-- Retrieve data for Value Set: HAE_GLB_HR_GRADE
CURSOR cur_0500 (c_flex_value APPS.fnd_flex_values.flex_value%TYPE)
IS
SELECT
    ffv.flex_value
FROM 
    apps.fnd_flex_value_sets      ffvs
  , apps.fnd_flex_values          ffv
  , apps.fnd_flex_values_tl       ffvt
WHERE
    ffvs.flex_value_set_id      = ffv.flex_value_set_id
AND ffv.flex_value_id           = ffvt.flex_value_id
AND ffvt.language               = ('US')
AND flex_value_set_name         = 'HAE_GLB_HR_GRADE'
AND TRUNC(SYSDATE)              BETWEEN NVL(TRUNC(ffv.START_DATE_ACTIVE), TRUNC(SYSDATE)-1) AND NVL(TRUNC(ffv.END_DATE_ACTIVE), TRUNC(SYSDATE)+1) -- 2018/05/03 - Added code
AND NVL(ffv.ENABLED_FLAG,'Y')   = 'Y'
AND ffv.flex_value              = c_flex_value
;

-- Retrieve data for Value Set: HAE_GLB_COUNTRY_ISO_CODE
CURSOR cur_0600 (c_flex_value APPS.fnd_flex_values.flex_value%TYPE)
IS
SELECT
    ffv.flex_value
FROM 
    apps.fnd_flex_value_sets      ffvs
  , apps.fnd_flex_values          ffv
  , apps.fnd_flex_values_tl       ffvt
WHERE
    ffvs.flex_value_set_id      = ffv.flex_value_set_id
AND ffv.flex_value_id           = ffvt.flex_value_id
AND ffvt.language               = ('US')
AND flex_value_set_name         = 'HAE_GLB_COUNTRY_ISO_CODE'
AND TRUNC(SYSDATE)              BETWEEN NVL(TRUNC(ffv.START_DATE_ACTIVE), TRUNC(SYSDATE)-1) AND NVL(TRUNC(ffv.END_DATE_ACTIVE), TRUNC(SYSDATE)+1) -- 2018/05/03 - Added code
AND NVL(ffv.ENABLED_FLAG,'Y')   = 'Y'
AND ffv.flex_value              = c_flex_value
;

BEGIN

   -- Initialize Values (to parse out value: '70.CA-N.')
   l_Segment        := NULL;
   l_first_decimal  := 0;
   l_segment3       := NULL;
   l_segment2       := NULL;
   l_segment4       := NULL;                         

   -- Update Segment values
   l_Segment        := p_GRADE_ORACLE;
   l_first_decimal  := (INSTR(l_Segment, '.', 1, 1));
   l_segment3       := SUBSTR(l_Segment, 1,((l_first_decimal)-1));                    -- Grade
   l_segment2       := SUBSTR(l_Segment, ((l_first_decimal)+1), LENGTH(l_Segment));   -- Legislation Code (i.e. 'CA-N.') 
   l_segment4       := NULL;                                                          -- YES/NO/NULL

   -- Initialize Values
   l_sequence                := 0;
   l_grade_id                := NULL;
   l_object_version_number   := NULL;
   l_create_grade_definition := 'NO';

   -- Retrieve Max Grade Sequence from per_grades
   BEGIN
       OPEN cur_0200(p_BG_ID);
      FETCH cur_0200 INTO l_sequence;
      CLOSE cur_0200;
   END;

   -- Initialize Values
   lv_grade_definition_id    := NULL;
   lv_segment3               := NULL;
   lv_segment2               := NULL;
   lv_segment4               := NULL;
   l_create_grade_definition := NULL;

   -- Determine if values exist in per_grade_definitions
   BEGIN
       OPEN cur_0300(l_segment3, l_segment2, l_segment4);
      FETCH cur_0300 INTO lv_grade_definition_id, lv_segment3, lv_segment2, lv_segment4;
      IF cur_0300%NOTFOUND THEN 
         l_create_grade_definition := 'YES'; 
      ELSE
         l_create_grade_definition := 'NO'; 
      END IF;
      CLOSE cur_0300;
   END;

   -- If we need to create values in PER_GRADE_DEFINITIONS, retrieve nextval for PER_GRADE_DEFINITIONS and then create record in PER_GRADE_DEFINITIONS
   IF l_create_grade_definition = 'YES' THEN

      -- Retrieve nextval for PER_GRADE_DEFINITIONS
       OPEN cur_0400;
      FETCH cur_0400 INTO l_nextval;
      CLOSE cur_0400;

      -- Create record in PER_GRADE_DEFINITIONS
      BEGIN
         INSERT INTO PER_GRADE_DEFINITIONS
                    (GRADE_DEFINITION_ID,ID_FLEX_NUM,SUMMARY_FLAG,ENABLED_FLAG,START_DATE_ACTIVE,END_DATE_ACTIVE,SEGMENT1,SEGMENT2,SEGMENT3,SEGMENT4,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATED_BY,CREATION_DATE,OBJECT_VERSION_NUMBER)
                VALUES
                    (l_nextval,101,'N','Y',TO_DATE(SYSDATE),NULL,NULL,l_segment2,l_segment3,l_segment4,TO_DATE(SYSDATE),-1,-1,TO_DATE(SYSDATE),NULL);
         COMMIT;
      END;

      BEGIN
         -- Initialize Values
         l_Create_Value_set := 'NO';

         -- See if value already exists in Value Set: HAE_GLB_HR_GRADE as it may have already been created when procesing another Business Group
          OPEN cur_0500(l_segment3);
         FETCH cur_0500 INTO lv_segment3;
            IF cur_0500%NOTFOUND THEN
               l_Create_Value_set := 'YES';
           END IF;
         CLOSE cur_0500;
      END;

      IF l_Create_Value_set = 'YES' THEN

         BEGIN

         -- Call API to Create Value in GRADE to Value Set: 'HAE_GLB_HR_GRADE'
         fnd_flex_loader_apis.up_value_set_value
         (
           p_upload_phase                => 'BEGIN' 
         , p_upload_mode                 => NULL
         , p_custom_mode                 => 'FORCE'
         , p_flex_value_set_name         => l_value_set_name1
         , p_parent_flex_value_low       => NULL
         , p_flex_value                  => l_segment3                          -- GRADE
         , p_owner                       => NULL
         , p_last_update_date            => TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI:SS') -- 2018/05/03 - Was TO_DATE(SYSDATE)
         , p_enabled_flag                => l_enabled_flag
         , p_summary_flag                => l_summary_flag
         , p_start_date_active           => TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI:SS') -- 2018/05/03 - Was TO_DATE(SYSDATE)
         , p_end_date_active             => NULL
         , p_parent_flex_value_high      => NULL
         , p_rollup_flex_value_set_name  => NULL
         , p_rollup_hierarchy_code       => NULL
         , p_hierarchy_level             => NULL
         , p_compiled_value_attributes   => NULL
         , p_value_category              => 'VALUE_SET_NAME'                    -- 2018/05/03 - Was NULL 
         , p_attribute1                  => NULL
         , p_attribute2                  => NULL
         , p_attribute3                  => NULL
         , p_attribute4                  => NULL
         , p_attribute5                  => NULL
         , p_attribute6                  => NULL
         , p_attribute7                  => NULL
         , p_attribute8                  => NULL
         , p_attribute9                  => NULL
         , p_attribute10                 => NULL
         , p_attribute11                 => NULL
         , p_attribute12                 => NULL
         , p_attribute13                 => NULL
         , p_attribute14                 => NULL
         , p_attribute15                 => NULL
         , p_attribute16                 => NULL
         , p_attribute17                 => NULL
         , p_attribute18                 => NULL
         , p_attribute19                 => NULL
         , p_attribute20                 => NULL
         , p_attribute21                 => NULL
         , p_attribute22                 => NULL
         , p_attribute23                 => NULL
         , p_attribute24                 => NULL
         , p_attribute25                 => NULL
         , p_attribute26                 => NULL
         , p_attribute27                 => NULL
         , p_attribute28                 => NULL
         , p_attribute29                 => NULL
         , p_attribute30                 => NULL
         , p_attribute31                 => NULL
         , p_attribute32                 => NULL
         , p_attribute33                 => NULL
         , p_attribute34                 => NULL
         , p_attribute35                 => NULL
         , p_attribute36                 => NULL
         , p_attribute37                 => NULL
         , p_attribute38                 => NULL
         , p_attribute39                 => NULL
         , p_attribute40                 => NULL
         , p_attribute41                 => NULL
         , p_attribute42                 => NULL
         , p_attribute43                 => NULL
         , p_attribute44                 => NULL
         , p_attribute45                 => NULL
         , p_attribute46                 => NULL
         , p_attribute47                 => NULL
         , p_attribute48                 => NULL
         , p_attribute49                 => NULL
         , p_ATTRIBUTE50                 => NULL
         , p_flex_value_meaning          => l_segment3                          -- GRADE
         , p_description                 => NULL
         );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_return := ('API Error: fnd_flex_loader_apis.up_value_set_value for HAE_GLB_HR_GRADE:  ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF; -- IF l_Create_Value_set = 'YES'
   END IF; -- l_create_grade_definition = 'YES'

   IF NVL(l_Status,'PASS') = 'PASS' THEN
      BEGIN
         -- Initialize Values
         l_Create_Value_set := 'NO';
         lv_segment2        := NULL;

         -- See if value already exists in Value Set: HAE_GLB_COUNTRY_ISO_CODE as it may have already been created
          OPEN cur_0600(l_segment2);
         FETCH cur_0600 INTO lv_segment2;
            IF cur_0600%NOTFOUND THEN
               l_Create_Value_set := 'YES';
           END IF;
         CLOSE cur_0600;
      END;

      IF l_Create_Value_set = 'YES' THEN
         BEGIN

            -- Call API to add Legislation Code to Value Set: 'HAE_GLB_COUNTRY_ISO_CODE'
            fnd_flex_loader_apis.up_value_set_value
            (
              p_upload_phase                => 'BEGIN'
            , p_upload_mode                 => NULL
            , p_custom_mode                 => 'FORCE'
            , p_flex_value_set_name         => l_value_set_name2
            , p_parent_flex_value_low       => NULL
            , p_flex_value                  => l_segment2                       -- Legislation Code (i.e. 'CA-N') 
            , p_owner                       => NULL
            , p_last_update_date            => TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI:SS') -- 2018/05/03 - Was TO_DATE(SYSDATE)
            , p_enabled_flag                => l_enabled_flag
            , p_summary_flag                => l_summary_flag
            , p_start_date_active           => TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI:SS') -- 2018/05/03 - Was TO_DATE(SYSDATE)
            , p_end_date_active             => NULL
            , p_parent_flex_value_high      => NULL
            , p_rollup_flex_value_set_name  => NULL
            , p_rollup_hierarchy_code       => NULL
            , p_hierarchy_level             => NULL
            , p_compiled_value_attributes   => NULL
            , p_value_category              => 'VALUE_SET_NAME'                 -- 2018/05/03 - Was NULL 
            , p_attribute1                  => NULL
            , p_attribute2                  => NULL
            , p_attribute3                  => NULL
            , p_attribute4                  => NULL
            , p_attribute5                  => NULL
            , p_attribute6                  => NULL
            , p_attribute7                  => NULL
            , p_attribute8                  => NULL
            , p_attribute9                  => NULL
            , p_attribute10                 => NULL
            , p_attribute11                 => NULL
            , p_attribute12                 => NULL
            , p_attribute13                 => NULL
            , p_attribute14                 => NULL
            , p_attribute15                 => NULL
            , p_attribute16                 => NULL
            , p_attribute17                 => NULL
            , p_attribute18                 => NULL
            , p_attribute19                 => NULL
            , p_attribute20                 => NULL
            , p_attribute21                 => NULL
            , p_attribute22                 => NULL
            , p_attribute23                 => NULL
            , p_attribute24                 => NULL
            , p_attribute25                 => NULL
            , p_attribute26                 => NULL
            , p_attribute27                 => NULL
            , p_attribute28                 => NULL
            , p_attribute29                 => NULL
            , p_attribute30                 => NULL
            , p_attribute31                 => NULL
            , p_attribute32                 => NULL
            , p_attribute33                 => NULL
            , p_attribute34                 => NULL
            , p_attribute35                 => NULL
            , p_attribute36                 => NULL
            , p_attribute37                 => NULL
            , p_attribute38                 => NULL
            , p_attribute39                 => NULL
            , p_attribute40                 => NULL
            , p_attribute41                 => NULL
            , p_attribute42                 => NULL
            , p_attribute43                 => NULL
            , p_attribute44                 => NULL
            , p_attribute45                 => NULL
            , p_attribute46                 => NULL
            , p_attribute47                 => NULL
            , p_attribute48                 => NULL
            , p_attribute49                 => NULL
            , p_ATTRIBUTE50                 => NULL
            , p_flex_value_meaning          => l_segment2                       -- Legislation Code (i.e. 'CA-N') 
            , p_description                 => NULL
            );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_return := ('API Error: fnd_flex_loader_apis.up_value_set_value for HAE_GLB_COUNTRY_ISO_CODE: ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

      END IF; -- IF l_Create_Value_set = 'YES'

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN

         BEGIN

            -- Initialize Values
            l_name     := l_segment;
            l_name_out := l_segment;
            l_Year     := to_char(SYSDATE,'YYYY');

            -- Call API to Create Grade
            HR_GRADE_API.create_grade
            (
              -- INPUT
              p_validate               => FALSE
            , p_business_group_id      => p_BG_ID                               -- Business Group ID
            , p_date_from              => TO_DATE(SYSDATE)
            , p_sequence               => (l_sequence + 10)
            , p_effective_date         => TO_DATE(SYSDATE)
            , p_segment1               => NULL
            , p_segment2               => l_segment2                            -- i.e. 'US-N', 'CA-N'         -- Segments Defined in Grade KFF
            , p_segment3               => l_segment3                            -- i.e. '70'                   -- Segments Defined in Grade KFF
            , p_segment4               => l_segment4                            -- i.e. NULL, 'Yes', 'No'      -- Segments Defined in Grade KFF
            , p_attribute1             => '0.00'                                -- Corporate Target
            , p_attribute2             => '0.00'                                -- Region Target
            , p_attribute3             => NULL                                  -- Commission Target
            , p_attribute4             => '0.00'                                -- Individual Target
            , p_attribute5             => l_Year                                -- Year
            , p_attribute6             => '0.00'                                -- WW Bonus Potential
            , p_short_name             => NULL
              -- OUTPUT
            , p_grade_id               => l_grade_id
            , p_object_version_number  => l_object_version_number
              -- INPUT/OUTPUT
            , p_grade_definition_id    => l_grade_definition_id
            , p_name                   => l_name_out
            );
         EXCEPTION
              WHEN OTHERS THEN
                   ROLLBACK;
                   l_Status := 'FAIL';
                   l_return := ('API Error: HR_GRADE_API.create_grade: ' || ' Name: ' || l_segment || '; Segments: ' || (l_segment3||l_segment2||l_segment4) || '; for BG:' || p_BG_ID || ' / ' || SQLERRM);
         END;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            COMMIT;
         ELSE
            FND_FILE.PUT_LINE(FND_FILE.LOG, l_return);
            l_STATUS_MESSAGE := NULL;
            SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
            UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
               SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_return || ' / ')
                 , XXHA.STATUS         = 'FAIL'
             WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
            COMMIT;
         END IF;

         -- Check for errors
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            -- Update record with created Grade_ID
            BEGIN
               UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
                  SET XXHA.GRADE_ID     = l_GRADE_ID
                WHERE XXHA.WD_RECORD_ID = p_RECORD_ID;
               COMMIT;
            END;
         END IF;

         -- Correct Grade Name in tables 'HR.PER_GRADES_TL' AND 'APPS.PER_GRADES' (TEMPORARY)
         IF NVL(l_Status,'PASS') = 'PASS' THEN
            IF l_name <> l_name_out THEN
               UPDATE HR.PER_GRADES_TL           pgtl
                  SET pgtl.NAME                = l_name
                WHERE pgtl.GRADE_ID            = l_grade_id;
               COMMIT;
               UPDATE APPS.PER_GRADES            pg
                  SET pg.NAME                  = l_name
                WHERE pg.GRADE_ID              = l_grade_id
                  AND pg.object_version_number = l_object_version_number;
               COMMIT;
            END IF;
         END IF;

      END IF; -- IF NVL(l_Status,'PASS') = 'PASS' 

   END IF; -- IF NVL(l_Status,'PASS') = 'PASS'

END;

END XXHA_WD_EMPLOYEE_CREATE_GRADE;


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_VALID_GRADES(
          p_RECORD_ID                       IN  NUMBER
         ,p_BUSINESS_GROUP_ID               IN  NUMBER
         ,p_GRADE_ID                        IN  NUMBER
         ,p_JOB_ID                          IN  NUMBER) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                                     := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE         := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;

   l_FOUND                                  VARCHAR2(10)                                       := NULL;
   l_BUSINESS_GROUP_ID                      APPS.PER_VALID_GRADES.BUSINESS_GROUP_ID%TYPE       := NULL;
   l_GRADE_ID                               APPS.PER_VALID_GRADES.GRADE_ID%TYPE                := NULL;
   l_JOB_ID                                 APPS.PER_VALID_GRADES.JOB_ID%TYPE                  := NULL;
   l_VALID_GRADE_ID1                        APPS.PER_VALID_GRADES.VALID_GRADE_ID%TYPE          := NULL;

   -- per_valid_grades_pkg2.insert_row
   l_rowid                                  VARCHAR2(200)                                      := NULL;
   l_valid_grade_id                         APPS.PER_VALID_GRADES.VALID_GRADE_ID%TYPE          := NULL;

-- Cursor to retrieve record from PER_VALID_GRADES
CURSOR cur_0100(c_BUSINESS_GROUP_ID APPS.PER_VALID_GRADES.BUSINESS_GROUP_ID%TYPE
               ,c_GRADE_ID          APPS.PER_VALID_GRADES.GRADE_ID%TYPE
               ,c_JOB_ID            APPS.PER_VALID_GRADES.JOB_ID%TYPE)
IS
SELECT
    pvg.VALID_GRADE_ID
FROM
    APPS.PER_VALID_GRADES   pvg
WHERE
    pvg.business_group_id = c_business_group_id
AND pvg.GRADE_ID          = c_GRADE_ID
AND pvg.JOB_ID            = c_JOB_ID
AND TRUNC(SYSDATE)        BETWEEN NVL(pvg.DATE_FROM,TRUNC(SYSDATE)-1) AND NVL(pvg.DATE_TO,TRUNC(SYSDATE)+1)
;

BEGIN

   -- Initialize Values
   l_FOUND             := NULL;
   l_BUSINESS_GROUP_ID := NULL;
   l_GRADE_ID          := NULL;
   l_JOB_ID            := NULL;
   l_VALID_GRADE_ID1   := NULL;

   -- Retrieve data from APPS.PER_VALID_GRADES for BUSINESS_GROUP_ID, GRADE_ID and JOB_ID
   BEGIN
        OPEN cur_0100(p_BUSINESS_GROUP_ID, p_GRADE_ID, p_JOB_ID);
       FETCH cur_0100 INTO l_VALID_GRADE_ID1;
          IF cur_0100%NOTFOUND THEN
             l_FOUND := 'NO';
          ELSE
             l_FOUND := 'YES';
          END IF;
       CLOSE cur_0100;
   END;

   -- API to Create Valid Grade for Job
   IF NVL(l_FOUND, 'YES') = 'NO' THEN
      BEGIN

         -- Initialize Values
         l_BUSINESS_GROUP_ID := p_BUSINESS_GROUP_ID;
         l_GRADE_ID          := p_GRADE_ID;
         l_JOB_ID            := p_JOB_ID;

         per_valid_grades_pkg2.insert_row
         (
           -- INPUT/OUTPUT
           x_rowid                     => l_rowid
         , x_valid_grade_id            => l_valid_grade_id
           -- INPUT
         , x_business_group_id         => l_BUSINESS_GROUP_ID
         , x_grade_id                  => l_GRADE_ID
         , x_date_from                 => TO_DATE(SYSDATE)
         , x_comments                  => NULL
         , x_date_to                   => NULL
         , x_job_id                    => l_JOB_ID
         , x_position_id               => NULL
         , x_attribute_category        => NULL
         , x_attribute1                => NULL
         , x_attribute2                => NULL
         , x_attribute3                => NULL
         , x_attribute4                => NULL
         , x_attribute5                => NULL
         , x_attribute6                => NULL
         , x_attribute7                => NULL
         , x_attribute8                => NULL
         , x_attribute9                => NULL
         , x_attribute10               => NULL
         , x_attribute11               => NULL
         , x_attribute12               => NULL
         , x_attribute13               => NULL
         , x_attribute14               => NULL
         , x_attribute15               => NULL
         , x_attribute16               => NULL
         , x_attribute17               => NULL
         , x_attribute18               => NULL
         , x_attribute19               => NULL
         , x_attribute20               => NULL
         , x_end_of_time               => NULL
         , x_pst1_date_end             => NULL
         , x_pst1_date_effective       => TO_DATE(SYSDATE)
         );
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL';
                l_Return := 'API Error: per_valid_grades_pkg2.insert_row: ' || SQLERRM;
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
              , XXHA.STATUS         = 'FAIL'
          WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
         COMMIT;
      END IF;

   END IF;

END;

END XXHA_WD_EMPLOYEE_VALID_GRADES;


--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_TERMINATE(
          p_RECORD_ID                       IN  NUMBER) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                                     := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE         := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE := NULL;

   -- CURSOR cur_0100
   lc_PERSON_ID                             APPS.PER_PEOPLE_X.Person_ID%TYPE;
   lc_EMPLOYEE_NUMBER                       APPS.PER_PEOPLE_X.EMPLOYEE_NUMBER%TYPE;
   lc_FIRST_NAME                            APPS.PER_PEOPLE_X.FIRST_NAME%TYPE;
   lc_MIDDLE_NAMES                          APPS.PER_PEOPLE_X.MIDDLE_NAMES%TYPE;
   lc_LAST_NAME                             APPS.PER_PEOPLE_X.LAST_NAME%TYPE;
   lc_ASSIGNMENT_ID                         APPS.PER_ASSIGNMENTS_X.ASSIGNMENT_ID%TYPE;
   lc_ORGANIZATION_ID                       APPS.PER_ASSIGNMENTS_X.ORGANIZATION_ID%TYPE;
   lc_ORGANIZATION                          APPS.HR_ALL_ORGANIZATION_UNITS.name%TYPE;
   lc_JOB_ID                                APPS.PER_ASSIGNMENTS_X.JOB_ID%TYPE;
   lc_JOB_FAMILY                            APPS.per_jobs.Job_Information9%TYPE;
   lc_JOB_NAME                              APPS.per_jobs.name%TYPE;
   lc_JOB_DEFINITION_ID                     APPS.per_jobs.job_definition_id%TYPE;
   lc_GRADE_ID                              APPS.PER_ASSIGNMENTS_X.GRADE_ID%TYPE;
   lc_GRADE                                 APPS.per_grades.name%TYPE;
   lc_LOCATION_ID                           APPS.HR_LOCATIONS_V.location_id%TYPE;
   lc_LOCATION                              APPS.HR_LOCATIONS_V.location_code%TYPE;
   lc_ASSIGNMENT_DESCRIPTION                APPS.hr_lookups.Description%TYPE;
   lc_ASSIGNMENT_CATEGORY                   APPS.hr_lookups.LOOKUP_CODE%TYPE;
   lc_ASSIGNMENT_MEANING                    APPS.hr_lookups.MEANING%TYPE;
   lc_ASSIGNMENT_STATUS_TYPE_ID             APPS.PER_ASSIGNMENT_STATUS_TYPES.ASSIGNMENT_STATUS_TYPE_ID%TYPE;
   lc_USER_STATUS                           APPS.per_assignment_status_types.User_Status%TYPE;
   lc_SUP_PERSON_ID                         APPS.PER_PEOPLE_X.Person_ID%TYPE;
   lc_SUP_EMPLOYEE_NUMBER                   APPS.PER_PEOPLE_X.EMPLOYEE_NUMBER%TYPE;
   lc_CONTRACT_END_DATE                     DATE;
   lc_CODE_COMBINATION_ID                   APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   lc_EXPENSE_ACCOUNT                       VARCHAR2(240);
   lc_COST_ALLOCATION_KEYFLEX_ID            APPS.GL_CODE_COMBINATIONS.Code_Combination_ID%TYPE;
   lc_COST_ACCOUNT                          VARCHAR2(240);
   lc_LEAVE_REASON_CODE                     APPS.hr_lookups.LOOKUP_CODE%TYPE;
   lc_LEAVE_REASON                          APPS.hr_lookups.MEANING%TYPE;
   lc_LAST_DAY_WORKED                       DATE;
   lc_WD_RECORD_ID                          HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE;

   -- CURSOR cur_0200
   l_person_id                              APPS.PER_PEOPLE_X.person_id%TYPE;
   l_person_type_id                         APPS.PER_PEOPLE_X.person_type_id%TYPE;
   l_period_of_service_id                   apps.per_periods_of_service.period_of_service_id%TYPE;
   l_object_version_number                  apps.per_periods_of_service.object_version_number%TYPE;
   l_date_start                             apps.per_periods_of_service.date_start%TYPE;

   -- CURSOR cur_0300
   lv_Emp_Name                              APPS.per_all_people_f.full_name%TYPE;
   lv_Emp_Number                            APPS.per_all_people_f.employee_number%TYPE;
   lv_Organization                          APPS.hr_all_organization_units_tl.name%TYPE;
   lv_Job                                   APPS.per_jobs_tl.name%TYPE;
   lv_Location                              APPS.hr_locations_all_tl.location_code%TYPE;
   lv_Business_Group_ID                     APPS.per_business_groups.Business_Group_ID%TYPE;
   lv_BUSINESS_GROUP_NAME                   APPS.per_business_groups.name%TYPE;
   lv_period_of_service_id                  APPS.per_periods_of_service.period_of_service_id%TYPE;
   lv_person_id                             APPS.per_all_people_f.person_id%TYPE;
   lv_person_type_id                        APPS.per_person_types.person_type_id%TYPE;
   lv_person_type_id_ptu                    APPS.per_person_type_usages_f.person_type_id%TYPE;
   lv_user_person_type                      APPS.per_person_types.user_person_type%TYPE;
   lv_person_type_usage_id                  APPS.per_person_type_usages_f.person_type_usage_id%TYPE;
   lv_person_type_id_term                   APPS.per_person_types.person_type_id%TYPE;
   lv_person_type_id_terms                  APPS.per_person_types.person_type_id%TYPE;
   lv_PPF_OBJECT_VERSION_NUMBER             APPS.per_all_people_f.OBJECT_VERSION_NUMBER%TYPE;
   lv_PAF_OBJECT_VERSION_NUMBER             APPS.per_assignments_f.OBJECT_VERSION_NUMBER%TYPE;
   lv_PPOS_OBJECT_VERSION_NUMBER            APPS.per_periods_of_service.OBJECT_VERSION_NUMBER%TYPE;
   lv_PTU_OBJECT_VERSION_NUMBER             APPS.per_person_type_usages_f.OBJECT_VERSION_NUMBER%TYPE;
   lv_ppf_effective_start_date              VARCHAR2(100);
   lv_ppf_effective_end_date                VARCHAR2(100);
   lv_paf_effective_start_date              VARCHAR2(100);
   lv_paf_effective_end_date                VARCHAR2(100);
   lv_ptu_effective_start_date_in           VARCHAR2(100);
   lv_ptu_effective_end_date_in             VARCHAR2(100);

   l_validate                               BOOLEAN                             := False;
   l_supervisor_warning                     BOOLEAN;
   l_event_warning                          BOOLEAN;
   l_interview_warning                      BOOLEAN;
   l_review_warning                         BOOLEAN;
   l_recruiter_warning                      BOOLEAN;
   l_asg_future_changes_warning             BOOLEAN;
   l_f_asg_future_changes_warning           BOOLEAN;
   l_pay_proposal_warning                   BOOLEAN;
   l_dod_warning                            BOOLEAN;
   l_org_now_no_manager_warning             BOOLEAN;
   l_entries_changed_warning                VARCHAR2(255);
   l_f_entries_changed_warning              VARCHAR2(255);
   l_alu_change_warning                     VARCHAR2(255);
   l_last_std_process_date_out              DATE;                               -- This should be a termination date
   l_last_standard_process_date             DATE;
   l_final_process_date                     DATE;

-- Cursor to retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100(c_RECORD_ID HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE)
IS
SELECT
    PERSON_ID
  , EMPLOYEE_NUMBER
  , FIRST_NAME
  , MIDDLE_NAMES
  , LAST_NAME
  , ASSIGNMENT_ID
  , ORGANIZATION_ID
  , ORGANIZATION
  , JOB_ID
  , JOB_FAMILY
  , JOB_NAME
  , JOB_DEFINITION_ID
  , GRADE_ID
  , GRADE
  , LOCATION_ID
  , LOCATION
  , ASSIGNMENT_CATEGORY
  , ASSIGNMENT_DESCRIPTION 
  , ASSIGNMENT_STATUS_TYPE_ID
  , USER_STATUS
  , SUP_PERSON_ID
  , SUP_EMPLOYEE_NUMBER
  , CONTRACT_END_DATE
  , CODE_COMBINATION_ID
  , EXPENSE_ACCOUNT
  , COST_ALLOCATION_KEYFLEX_ID
  , COST_ACCOUNT
  , LEAVE_REASON_CODE
  , LEAVE_REASON
  , LAST_DAY_WORKED
  , WD_RECORD_ID
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    WD_RECORD_ID = c_RECORD_ID
;

-- Retrieve data
CURSOR cur_0200 (c_PERSON_ID APPS.PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    paf.person_id
  , paf.person_type_id
  , pos.period_of_service_id
  , pos.object_version_number
  , pos.date_start
FROM
    apps.per_people_x           paf
  , apps.per_periods_of_service pos
WHERE 
    paf.person_id             = c_PERSON_ID
AND paf.person_id             = pos.person_id
;

-- Retrieve data
CURSOR cur_0300 (c_PERSON_ID APPS.PER_PEOPLE_X.PERSON_ID%TYPE)
IS
SELECT
    ppf.full_name                         Emp_Name
  , ppf.employee_number                   Emp_Number
  , houT.name                             Organization
  , jbt.name                              Job
  , hlT.location_code                     Location
  , PBG.BUSINESS_GROUP_ID                 BUSINESS_GROUP_ID
  , pbg.name                              Business_group_name
  , ppos.period_of_service_id             period_of_service_id
  , ppf.person_id                         person_id
  , ppt.person_type_id                    person_type_id
  , ptu.person_type_id                    person_type_id_ptu
  , ppt.user_person_type                  user_person_type
  , ptu.person_type_usage_id              person_type_usage_id
  , ppts.person_type_id                   person_type_id_term
  , pptss.person_type_id                  person_type_id_terms
  , ppf.OBJECT_VERSION_NUMBER             ppf_OBJECT_VERSION_NUMBER
  , paf.OBJECT_VERSION_NUMBER             paf_OBJECT_VERSION_NUMBER
  , ppos.OBJECT_VERSION_NUMBER            ppos_OBJECT_VERSION_NUMBER
  , ptu.OBJECT_VERSION_NUMBER             PTU_OBJECT_VERSION_NUMBER
  , to_char(ppf.effective_start_date, 'YYYYMMDD')
  , to_char(ppf.effective_end_date, 'YYYYMMDD')
  , to_char(paf.effective_start_date, 'YYYYMMDD')
  , to_char(paf.effective_end_date, 'YYYYMMDD')
  , to_char(ptu.effective_start_date, 'YYYYMMDD')
  , to_char(ptu.effective_end_date, 'YYYYMMDD')
FROM  
    apps.hr_all_organization_units_tl     houT
  , apps.per_business_groups              pbg
  , apps.per_jobs_tl                      jbt
  , apps.per_all_people_f                 ppf
  , apps.hr_locations_all_tl              hlT
  , apps.per_periods_of_service           ppos
  , apps.per_assignments_f                paf
  , apps.fnd_user                         usr
  , apps.per_person_types                 ppt
  , apps.per_person_type_usages_f         ptu
  , (SELECT ptu1.business_group_id
          , ptu1.person_type_id
       FROM apps.per_person_types  ptu1
      WHERE user_person_type  LIKE '%HAE Ex-contingent%') ppts
  , (SELECT ptu1.business_group_id
          , ptu1.person_type_id
       FROM apps.per_person_types  ptu1
      WHERE user_person_type  = 'Ex-employee') pptss
WHERE 
    paf.period_of_service_id            = ppos.period_of_service_id
AND paf.person_id                       = ppf.person_id
AND paf.business_group_id               = pbg.business_group_id
AND paf.organization_id                 = houT.organization_id
AND houT.language                       = userenv('LANG')
AND paf.job_id                          = jbt.job_id(+)
AND jbt.language (+)                    = userenv('LANG')
AND paf.location_id                     = hlT.location_id(+)
AND hlT.language (+)                    = userenv('LANG')
AND SYSDATE                             BETWEEN paf.effective_start_date AND paf.effective_end_date
AND SYSDATE                             BETWEEN ppf.effective_start_date AND ppf.effective_end_date
AND SYSDATE                             BETWEEN ptu.effective_start_date AND ptu.effective_end_date
AND ppf.person_id                       = usr.employee_id(+)
AND ppf.PERSON_TYPE_ID                  = ppt.PERSON_TYPE_ID
AND paf.business_group_id               = ppt.BUSINESS_GROUP_ID
AND paf.business_group_id               = ppts.BUSINESS_GROUP_ID(+)
AND paf.business_group_id               = pptss.BUSINESS_GROUP_ID(+)
AND paf.person_id                       = ptu.person_id
AND paf.person_id                       = c_PERSON_ID
;

BEGIN

   -- Initialize Values
   l_Status                       := NULL;
   l_Return                       := NULL;
   lc_PERSON_ID                   := NULL;
   lc_EMPLOYEE_NUMBER             := NULL;
   lc_FIRST_NAME                  := NULL;
   lc_MIDDLE_NAMES                := NULL;
   lc_LAST_NAME                   := NULL;
   lc_ASSIGNMENT_ID               := NULL;
   lc_ORGANIZATION_ID             := NULL;
   lc_ORGANIZATION                := NULL;
   lc_JOB_ID                      := NULL;
   lc_JOB_FAMILY                  := NULL;
   lc_JOB_NAME                    := NULL;
   lc_JOB_DEFINITION_ID           := NULL;
   lc_GRADE_ID                    := NULL;
   lc_GRADE                       := NULL;
   lc_LOCATION_ID                 := NULL;
   lc_LOCATION                    := NULL;
   lc_ASSIGNMENT_CATEGORY         := NULL;
   lc_ASSIGNMENT_DESCRIPTION      := NULL;
   lc_ASSIGNMENT_STATUS_TYPE_ID   := NULL;
   lc_USER_STATUS                 := NULL;
   lc_SUP_PERSON_ID               := NULL;
   lc_SUP_EMPLOYEE_NUMBER         := NULL;
   lc_CONTRACT_END_DATE           := NULL;
   lc_CODE_COMBINATION_ID         := NULL;
   lc_EXPENSE_ACCOUNT             := NULL;
   lc_COST_ALLOCATION_KEYFLEX_ID  := NULL;
   lc_COST_ACCOUNT                := NULL;
   lc_LEAVE_REASON_CODE           := NULL;
   lc_LEAVE_REASON                := NULL;
   lc_LAST_DAY_WORKED             := NULL;
   lc_WD_RECORD_ID                := NULL;

   -- Retrieve data from XXHA_WD_EMPLOYEE_CHANGES for Record_ID
   BEGIN
       OPEN cur_0100(p_RECORD_ID);
      FETCH cur_0100 INTO lc_PERSON_ID, lc_EMPLOYEE_NUMBER, lc_FIRST_NAME, lc_MIDDLE_NAMES, lc_LAST_NAME, lc_ASSIGNMENT_ID, lc_ORGANIZATION_ID, lc_ORGANIZATION, 
                          lc_JOB_ID, lc_JOB_FAMILY, lc_JOB_NAME, lc_JOB_DEFINITION_ID, lc_GRADE_ID, lc_GRADE, lc_LOCATION_ID, lc_LOCATION, 
                          lc_ASSIGNMENT_CATEGORY, lc_ASSIGNMENT_DESCRIPTION, lc_ASSIGNMENT_STATUS_TYPE_ID, lc_USER_STATUS, 
                          lc_SUP_PERSON_ID, lc_SUP_EMPLOYEE_NUMBER, lc_CONTRACT_END_DATE, lc_CODE_COMBINATION_ID, lc_EXPENSE_ACCOUNT,
                          lc_COST_ALLOCATION_KEYFLEX_ID, lc_COST_ACCOUNT, lc_LEAVE_REASON_CODE, lc_LEAVE_REASON, lc_LAST_DAY_WORKED, lc_WD_RECORD_ID;
         IF cur_0100%NOTFOUND THEN
            l_Status := 'FAIL_TERM';
            l_Return := l_Return || ('p_RECORD_ID not found in table, HAEMO.XXHA_WD_EMPLOYEE_CHANGES' || '/');
         END IF;
      CLOSE cur_0100;
   END;

   -- Initialize Values
   l_PERSON_ID                    := NULL;
   l_person_type_id               := NULL;
   l_period_of_service_id         := NULL;
   l_object_version_number        := NULL;
   l_date_start                   := NULL;
   l_Status                       := NULL;
   l_Return                       := NULL;

   -- Retrieve data from APPS.XXHA_WD_EMPLOYEE_V for PERSON_ID
   BEGIN
       OPEN cur_0200(lc_PERSON_ID);
      FETCH cur_0200 INTO l_PERSON_ID, l_person_type_id, l_period_of_service_id, l_object_version_number, l_date_start;
         IF cur_0200%NOTFOUND THEN
            l_Status := 'FAIL_TERM';
            l_Return := l_Return || ('lc_PERSON_ID not found in view, APPS.XXHA_WD_EMPLOYEE_V' || '/');
         END IF;
      CLOSE cur_0200;
   END;

   -- Initialize Values
   l_Status                       := NULL;
   l_Return                       := NULL;
   lv_Emp_Name                    := NULL;
   lv_Emp_Number                  := NULL;
   lv_Organization                := NULL;
   lv_Job                         := NULL;
   lv_Location                    := NULL;
   lv_BUSINESS_GROUP_ID           := NULL;
   lv_business_group_name         := NULL;
   lv_period_of_service_id        := NULL;
   lv_person_id                   := NULL;
   lv_person_type_id              := NULL;
   lv_person_type_id_ptu          := NULL;
   lv_user_person_type            := NULL;
   lv_person_type_usage_id        := NULL;
   lv_person_type_id_term         := NULL;
   lv_person_type_id_terms        := NULL;
   lv_PPF_OBJECT_VERSION_NUMBER   := NULL;
   lv_PAF_OBJECT_VERSION_NUMBER   := NULL;
   lv_PPOS_OBJECT_VERSION_NUMBER  := NULL;
   lv_PTU_OBJECT_VERSION_NUMBER   := NULL;
   lv_ppf_effective_start_date    := NULL;
   lv_ppf_effective_end_date      := NULL;
   lv_paf_effective_start_date    := NULL;
   lv_paf_effective_end_date      := NULL;
   lv_ptu_effective_start_date_in := NULL;
   lv_ptu_effective_end_date_in   := NULL;

   -- Retrieve data
   BEGIN
       OPEN cur_0300(lc_PERSON_ID);
      FETCH cur_0300 INTO lv_Emp_Name, lv_Emp_Number, lv_Organization, lv_Job, lv_Location, lv_BUSINESS_GROUP_ID, lv_business_group_name
                        , lv_period_of_service_id, lv_person_id, lv_person_type_id, lv_person_type_id_ptu, lv_user_person_type
                        , lv_person_type_usage_id, lv_person_type_id_term, lv_person_type_id_terms, lv_PPF_OBJECT_VERSION_NUMBER
                        , lv_PAF_OBJECT_VERSION_NUMBER, lv_PPOS_OBJECT_VERSION_NUMBER, lv_PTU_OBJECT_VERSION_NUMBER
                        , lv_ppf_effective_start_date, lv_ppf_effective_end_date, lv_paf_effective_start_date, lv_paf_effective_end_date
                        , lv_ptu_effective_start_date_in, lv_ptu_effective_end_date_in;
         IF cur_0300%NOTFOUND THEN
            l_Status := 'FAIL_TERM';
            l_Return := l_Return || ('PERSON_ID not found in cur_0300' || '/');
         END IF;
      CLOSE cur_0300;
   END;

   BEGIN

      -- Initialize Values
      l_Status        := NULL;
      l_Return        := NULL;

      /*This API terminates an employee.
      * This API converts a person of type Employee > to a person of type Ex-Employee. 
      * The person's period of service and any employee assignments are ended.
      */
      hr_ex_employee_api.actual_termination_emp
      (
        -- INPUT
        p_validate                     => l_validate
      , p_effective_date               => lc_LAST_DAY_WORKED
      , p_period_of_service_id         => l_period_of_service_id
      , p_object_version_number        => l_object_version_number
      , p_actual_termination_date      => lc_LAST_DAY_WORKED
      , p_last_standard_process_date   => l_last_standard_process_date
      , p_person_type_id               => lv_person_type_id_terms
      , p_leaving_reason               => lc_LEAVE_REASON_CODE
        -- OUTPUT
      , p_last_std_process_date_out    => l_last_std_process_date_out
      , p_supervisor_warning           => l_supervisor_warning
      , p_event_warning                => l_event_warning
      , p_interview_warning            => l_interview_warning
      , p_review_warning               => l_review_warning
      , p_recruiter_warning            => l_recruiter_warning
      , p_asg_future_changes_warning   => l_asg_future_changes_warning
      , p_entries_changed_warning      => l_entries_changed_warning
      , p_pay_proposal_warning         => l_pay_proposal_warning
      , p_dod_warning                  => l_dod_warning
      , p_alu_change_warning           => l_alu_change_warning
      );
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL_TERM';
                l_Return := 'API Error: hr_ex_employee_api.actual_termination_emp: ' || SQLERRM;
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = lc_WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
              , XXHA.STATUS         = 'FAIL_TERM'
          WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
         COMMIT;
      END IF;

   IF NVL(l_Status,'PASS') = 'PASS' THEN
   BEGIN

      -- Initialize Values
      l_Status        := NULL;
      l_Return        := NULL;

      /*This API updates employee termination information.
      * The ex-employee must exist in the relevant business group
      */
      hr_ex_employee_api.update_term_details_emp
      (
        p_validate                     => l_validate
      , p_effective_date               => lc_LAST_DAY_WORKED
      , p_period_of_service_id         => l_period_of_service_id
      , p_notified_termination_date    => lc_LAST_DAY_WORKED
      , p_projected_termination_date   => lc_LAST_DAY_WORKED
        -- INPUT/OUTPUT 
      , p_object_version_number        => l_object_version_number
      , p_leaving_reason               => lc_LEAVE_REASON_CODE
      );                                                  
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL_TERM';
                l_Return := 'API Error: hr_ex_employee_api.update_term_details_emp: ' || SQLERRM;
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = NULL
              , XXHA.STATUS         = 'PROCESSED'
          WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
          -- By setting this to PROCESSED, it will be ignored by Procedure 'XXHA_PROCESS_CHANGES'
          -- as that procedure will select records from HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE STATUS = 'PASS'
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_Return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = lc_WD_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_Return || ' / ')
              , XXHA.STATUS         = 'FAIL_TERM'
          WHERE XXHA.WD_RECORD_ID   = lc_WD_RECORD_ID;
         COMMIT;
      END IF;

   END IF;

--   This processing WILL date-effectively delete all employee assignments as of the final process date so we do not want this!
--      /*This API set the final process date for a terminated employee.
--      * This API covers the second step in terminating a period of service and all
--      * current assignments for an employee. It updates the period of service
--      * details and date-effectively deletes all employee assignments as of the final process date.
--      */
--      hr_ex_employee_api.final_process_emp

END;

END XXHA_WD_EMPLOYEE_TERMINATE;


-- New Code Start - 2018/05/15
--------------------------------------------------------------------------------
PROCEDURE XXHA_WD_EMPLOYEE_REVERSE_TERM(
          p_RECORD_ID                       IN  NUMBER) AS

BEGIN

DECLARE

   -- Local Variables
   l_Return                                 VARCHAR2(2000)                                           := NULL;
   l_Status                                 HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS%TYPE               := NULL;
   l_STATUS_MESSAGE                         HAEMO.XXHA_WD_EMPLOYEE_CHANGES.STATUS_MESSAGE%TYPE       := NULL;

   l_sys_person_type                        apps.per_person_types.system_person_type%TYPE            := NULL;
   l_person_id                              apps.per_all_people_f.person_id%TYPE                     := NULL;
   l_LAST_DAY_WORKED                        HAEMO.XXHA_WD_EMPLOYEE_CHANGES.LAST_DAY_WORKED%TYPE      := NULL;
   l_LAST_DAY_WORKED_CHAR                   HAEMO.XXHA_WD_EMPLOYEE_CHANGES.LAST_DAY_WORKED_CHAR%TYPE := NULL;

   --- Declare variables for reverse termination API
   l_act_term_date                          apps.per_periods_of_service.actual_termination_date%TYPE;
   l_clear_details                          VARCHAR2(1)                                        := 'Y';
   l_fut_actns_exist_warning                BOOLEAN;               

-- Cursor to retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES
CURSOR cur_0100(c_RECORD_ID HAEMO.XXHA_WD_EMPLOYEE_CHANGES.WD_RECORD_ID%TYPE)
IS
SELECT
    PERSON_ID
  , LAST_DAY_WORKED
  , LAST_DAY_WORKED_CHAR
FROM
    HAEMO.XXHA_WD_EMPLOYEE_CHANGES
WHERE
    WD_RECORD_ID = c_RECORD_ID
;

-- Retrieve Person Type
CURSOR cur_0200 (c_person_id per_all_people_f.person_id%TYPE)
IS
SELECT 
    ppt.system_person_type
FROM 
    per_people_x           ppx
  , per_person_types       ppt                                  
WHERE 
    ppx.person_type_id   = ppt.person_type_id
AND ppx.person_id        = c_person_id  
;

-- Retrieve Actual Termination Date
CURSOR cur_0300 (c_person_id per_all_people_f.person_id%TYPE)
IS
SELECT
    pos.actual_termination_date                                  
FROM 
    per_people_x           ppx
  , per_periods_of_service pos
WHERE
    pos.person_id        = ppx.person_id
AND ppx.person_id        = c_person_id
;

BEGIN

   -- Initialize Values
   l_person_id            := NULL;
   l_LAST_DAY_WORKED      := NULL;
   l_LAST_DAY_WORKED_CHAR := NULL;

   -- Retrieve record from HAEMO.XXHA_WD_EMPLOYEE_CHANGES for Record_ID
   BEGIN
        OPEN cur_0100(p_RECORD_ID);
       FETCH cur_0100 INTO l_PERSON_ID, l_LAST_DAY_WORKED, l_LAST_DAY_WORKED_CHAR;                       

       CLOSE cur_0100;
   END;

   -- Initialize Values
   l_sys_person_type      := NULL;

   -- Retrieve Person Type
   BEGIN
       OPEN cur_0200(l_person_id);
      FETCH cur_0200 INTO l_sys_person_type;
      CLOSE cur_0200;
   END;

   -- Initialize Values
   l_act_term_date        := NULL;

   -- If Ex-employee and NOT a Contingent Worker
   IF l_sys_person_type LIKE 'EX_EMP%' THEN
      
      -- Retrieve Actual Termination Date
      BEGIN
          OPEN cur_0300(l_person_id);
         FETCH cur_0300 INTO l_act_term_date;
         CLOSE cur_0300;
      END;

      BEGIN
         -- This API is not published, hence not meant for public calls.
         hr_ex_employee_api.reverse_terminate_employee
         ( 
           p_validate                       =>  FALSE
         , p_person_id                      =>  l_person_id
         , p_actual_termination_date        =>  l_act_term_date
         , p_clear_details                  =>  l_clear_details
         );
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL_RTERM';
                l_return := ('API Error: hr_ex_employee_api.reverse_terminate_employee: ' || SQLERRM);
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = NULL
              , XXHA.STATUS         = 'PROCESSED'
          WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
          -- By setting this to PROCESSED, it will be ignored by Procedure 'XXHA_PROCESS_CHANGES'
          -- as that procedure will select records from HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE STATUS = 'PASS'
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_return || ' / ')
              , XXHA.STATUS         = 'FAIL_RTERM'
          WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
         COMMIT;
      END IF;

   ELSE

      -- Retrieve Actual Termination Date
      BEGIN
          OPEN cur_0300(l_person_id);
         FETCH cur_0300 INTO l_act_term_date;
         CLOSE cur_0300;
      END;

      BEGIN
         -- This API reverses a contingent worker termination.
         -- This API removes the end date from the period of placement and the
         -- contingent worker assignments, and reverts the person type to Contingent Worker
         hr_contingent_worker_api.reverse_terminate_placement
         ( 
           p_validate                       =>  FALSE
         , p_person_id                      =>  l_person_id
         , p_actual_termination_date        =>  l_act_term_date
         , p_clear_details                  =>  l_clear_details
         , p_fut_actns_exist_warning        =>  l_fut_actns_exist_warning
         ); 
      EXCEPTION
           WHEN OTHERS THEN
                ROLLBACK;
                l_Status := 'FAIL_RTERM';
                l_return := ('API Error: hr_contingent_worker_api.reverse_terminate_placement: ' || SQLERRM);
      END;

      -- Check for errors
      IF NVL(l_Status,'PASS') = 'PASS' THEN
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = NULL
              , XXHA.STATUS         = 'PROCESSED'
          WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
          -- By setting this to PROCESSED, it will be ignored by Procedure 'XXHA_PROCESS_CHANGES'
          -- as that procedure will select records from HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE STATUS = 'PASS'
         COMMIT;
      ELSE
         FND_FILE.PUT_LINE(FND_FILE.LOG, l_return);
         l_STATUS_MESSAGE := NULL;
         SELECT STATUS_MESSAGE INTO l_STATUS_MESSAGE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES WHERE WD_RECORD_ID = p_RECORD_ID;
         UPDATE HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
            SET XXHA.STATUS_MESSAGE = l_STATUS_MESSAGE || (l_return || ' / ')
              , XXHA.STATUS         = 'FAIL_RTERM'
          WHERE XXHA.WD_RECORD_ID   = p_RECORD_ID;
         COMMIT;
      END IF;          

   END IF;

END;

END XXHA_WD_EMPLOYEE_REVERSE_TERM;
-- New Code End - 2018/05/15


--------------------------------------------------------------------------------
PROCEDURE XXHA_CHECK_FOR_NON_NUMERIC(
          p_Value_In                        IN  VARCHAR2
         ,p_Value_Out                       OUT VARCHAR2) AS

BEGIN

DECLARE

   -- Local Variables
   l_Value_In                               VARCHAR2(20) := NULL;                  

   BEGIN

      l_Value_In := LENGTH(TRIM(TRANSLATE(p_Value_In, ' 0123456789', ' ')));

      IF LENGTH(l_Value_In) <> LENGTH(p_Value_In) THEN
         p_Value_Out := 'Invalid';
      ELSE
         p_Value_Out := 'Valid';
      END IF;

   END;

END XXHA_CHECK_FOR_NON_NUMERIC;


--------------------------------------------------------------------------------
PROCEDURE XXHA_BACKUP_DATA(
          errbuf                            OUT VARCHAR2
         ,errcode                           OUT VARCHAR2
         ,p_Process_Start_Date              IN  DATE) AS

BEGIN

DECLARE

   BEGIN

      -- Backup Data
      INSERT INTO HAEMO.XXHA_WD_EMPLOYEE_CHANGES_BKP
      (
       PERSON_ID,EMPLOYEE_NUMBER,TITLE,TITLE_CODE,FIRST_NAME,MIDDLE_NAMES,LAST_NAME,SUFFIX,FULL_NAME,KNOWN_AS,ORIGINAL_DATE_OF_HIRE,ORIGINAL_DATE_OF_HIRE_CHAR
      ,START_DATE,START_DATE_CHAR,HAEMO_EMAIL_REQUIRED,NON_HAEMO_EMAIL_ADDRESS,BUSINESS_GROUP_ID,BUSINESS_GROUP,BUSINESS_GROUP_COUNTRY_CODE,PERSON_TYPE_WD,PERSON_TYPE,PERSON_TYPE_ID
      ,TIME_TYPE_WD,ASSIGNMENT_CATEGORY,ASSIGNMENT_DESCRIPTION,ASSIGNMENT_STATUS_TYPE_ID,PHONE_WORK,PHONE_FAX,PHONE_MOBILE,USER_NAME,EMPLOYEE_EXISTS,ASSIGNMENT_ID,ORGANIZATION_ID,ORGANIZATION
      ,JOB_ID,JOB_FAMILY,JOB_NAME,JOB_NAME_ORACLE,JOB_DEFINITION_ID,GRADE_ID,GRADE,GRADE_ORACLE,LOCATION_ID,LOCATION,LOCATION_EXISTS,COUNTRY,COUNTRY_EXISTS,USER_STATUS,SUP_PERSON_ID,SUP_EMPLOYEE_NUMBER,SUPERVISOR_EXISTS
      ,CONTRACT_END_DATE,CONTRACT_END_DATE_CHAR,CODE_COMBINATION_ID,EXPENSE_ACCOUNT,COST_ALLOCATION_KEYFLEX_ID,COST_ACCOUNT,LEAVE_REASON,LEAVE_REASON_CODE,LAST_DAY_WORKED,LAST_DAY_WORKED_CHAR
      ,OPERATING_UNIT_ID,OPERATING_UNIT_NAME,CREATION_DATE,STATUS,STATUS_MESSAGE,PROCESSED_START_DATE,PROCESSED_END_DATE,WD_RECORD_ID
      ) 
      SELECT
       PERSON_ID,EMPLOYEE_NUMBER,TITLE,TITLE_CODE,FIRST_NAME,MIDDLE_NAMES,LAST_NAME,SUFFIX,FULL_NAME,KNOWN_AS,ORIGINAL_DATE_OF_HIRE,ORIGINAL_DATE_OF_HIRE_CHAR
      ,START_DATE,START_DATE_CHAR,HAEMO_EMAIL_REQUIRED,NON_HAEMO_EMAIL_ADDRESS,BUSINESS_GROUP_ID,BUSINESS_GROUP,BUSINESS_GROUP_COUNTRY_CODE,PERSON_TYPE_WD,PERSON_TYPE,PERSON_TYPE_ID
      ,TIME_TYPE_WD,ASSIGNMENT_CATEGORY,ASSIGNMENT_DESCRIPTION,ASSIGNMENT_STATUS_TYPE_ID,PHONE_WORK,PHONE_FAX,PHONE_MOBILE,USER_NAME,EMPLOYEE_EXISTS,ASSIGNMENT_ID,ORGANIZATION_ID,ORGANIZATION
      ,JOB_ID,JOB_FAMILY,JOB_NAME,JOB_NAME_ORACLE,JOB_DEFINITION_ID,GRADE_ID,GRADE,GRADE_ORACLE,LOCATION_ID,LOCATION,LOCATION_EXISTS,COUNTRY,COUNTRY_EXISTS,USER_STATUS,SUP_PERSON_ID,SUP_EMPLOYEE_NUMBER,SUPERVISOR_EXISTS
      ,CONTRACT_END_DATE,CONTRACT_END_DATE_CHAR,CODE_COMBINATION_ID,EXPENSE_ACCOUNT,COST_ALLOCATION_KEYFLEX_ID,COST_ACCOUNT,LEAVE_REASON,LEAVE_REASON_CODE,LAST_DAY_WORKED,LAST_DAY_WORKED_CHAR
      ,OPERATING_UNIT_ID,OPERATING_UNIT_NAME,CREATION_DATE,STATUS,STATUS_MESSAGE,PROCESSED_START_DATE,PROCESSED_END_DATE,WD_RECORD_ID
      FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES
      WHERE NVL(PROCESSED_START_DATE, '01-JAN-1900') = p_Process_Start_Date;
      COMMIT;

      -- Delete data that was processed and backed up
      DELETE FROM HAEMO.XXHA_WD_EMPLOYEE_CHANGES XXHA
      WHERE NVL(XXHA.PROCESSED_START_DATE, '01-JAN-1900') = p_Process_Start_Date;
      COMMIT;

   END;

END XXHA_BACKUP_DATA;

END XXHA_WD_EMPLOYEE_CHANGES_PKG;