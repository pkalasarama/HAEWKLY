CREATE OR REPLACE
PACKAGE BODY XXHA_EFFECTIVE_END_DATE_PKG AS

/************************************************************************************************************************
* Package Name : XXHA_EFFECTIVE_END_DATE_PKG                                                                            *
* Purpose      : This package provides a function to retrieve the latest Effective End Date from PER_ALL_ASSIGNMENTS_F  *
*                  and PER_ALL_PEOPLE_F.                                                                                *
*                This package will be used by the View 'XXHA_IDM_RECON_V'.                                              *
*                                                                                                                       *
* Functions    : ASSIGNMENT                                                                                             *
* Functions    : PEOPLE                                                                                                 *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
* - PER_ALL_ASSIGNMENTS_F     S                                                                                         *
* - PER_ALL_PEOPLE_F          S                                                                                         *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        11-JAN-2016     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

--------------------------------------------------------------------------------
-- FUNCTION ASSIGNMENT

FUNCTION ASSIGNMENT(
         p_PERSON_ID     IN PER_ALL_ASSIGNMENTS_F.PERSON_ID%TYPE)
         RETURN DATE IS

   l_Effective_End_Date DATE := NULL;

BEGIN

   SELECT
         MAX(asg.Effective_End_Date)
     INTO 
         l_Effective_End_Date
     FROM
         PER_ALL_ASSIGNMENTS_F   ASG
    WHERE
         ASG.PERSON_ID         = p_PERSON_ID;

  RETURN l_Effective_End_Date;

END ASSIGNMENT;

--------------------------------------------------------------------------------
-- FUNCTION PEOPLE

FUNCTION PEOPLE(
         p_PERSON_ID     IN PER_ALL_PEOPLE_F.PERSON_ID%TYPE)
         RETURN DATE IS

   l_Effective_End_Date DATE := NULL;

BEGIN

   SELECT
         MAX(PAF.Effective_End_Date)
     INTO 
         l_Effective_End_Date
     FROM
         PER_ALL_PEOPLE_F        PAF
    WHERE
         PAF.PERSON_ID         = p_PERSON_ID;

  RETURN l_Effective_End_Date;

END PEOPLE;

END XXHA_EFFECTIVE_END_DATE_PKG;