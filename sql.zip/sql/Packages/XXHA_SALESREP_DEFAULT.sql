CREATE OR REPLACE package XXHA_SALESREP_DEFAULT as
Function XXHA_Get_Order_SalesRep_ID(p_inv_item_id in number
    ,p_org_id IN number
    ,p_ship_from_org_id in number
    ,p_ship_to_org_id in number    
    ,p_bill_to_site_id IN NUMBER
    ,p_header_id in number)
return number;
end XXHA_SALESREP_DEFAULT;
/


CREATE OR REPLACE package body xxha_salesrep_default as
/**********************************************************************
    This procedure will load the mobile device tracking spreadsheet into
		an EIT attached to the person.
    This EIT is displayed through Haemonetics Employee Self Service and
    allows an employee to view his/her upgrade eligible date

*Modification Log:
*Developer             Date                     Description
*-----------------   ------------------   ------------------------------------------------
* David Lund		      02-MAY-2011         Created this Package
* David Lund		      15-SEP-2012         Changed logic for US order with CA address
**********************************************************************/

Function XXHA_Get_Order_SalesRep_id(p_inv_item_id in number
 ,p_org_id IN number
 ,p_ship_from_org_id in number
 ,p_ship_to_org_id in number
 ,p_bill_to_site_id IN NUMBER
 ,p_header_id in number)
return number
IS
l_sales_rep_id number;
l_prod_line VARCHAR2(100) := NULL;
l_order_type VARCHAR2(300) := NULL;
l_country varchar2(10) := null;
l_zip VARCHAR2(10) := NULL;
l_end_date DATE := to_date(NULL);
BEGIN
IF p_org_id IN (102,234) THEN --US or CA operating units
    l_sales_rep_id := to_number(null);
    begin
select segment1
        into l_prod_line
        from MTL_ITEM_CATEGORIES_V
        where inventory_item_id = p_inv_item_id
        and organization_id = p_ship_from_org_id
        AND category_set_name  = 'Inventory';
SELECT t.NAME
        INTO l_order_type
        FROM oe_order_headers_all h
        , OE_TRANSACTION_TYPES_TL t
        WHERE h.header_id = p_header_id
        AND h.order_type_id = t.transaction_type_id
        AND t.language = 'US';
exception when others then
        l_prod_line := NULL;
        l_order_type := null;
    end;
IF l_prod_line IS NOT NULL
    and l_order_type not in ('CA Service', 'CA Internal Order', 'US Service', 'US Internal Order') then
begin --ship_to_site logic
select m.salesrep_id
      into l_sales_rep_id
      from haemo.XXHA_SALESREP_MAPPING m, JTF_RS_SALESREPS r
      where m.product_line = l_prod_line
      and m.ship_to_site_id = p_ship_to_org_id
      and r.salesrep_id = m.salesrep_id;
exception when others then
     l_sales_rep_id := to_number(null);
end; --ship_to_site
if l_sales_rep_id is null then --no ship_to
begin --zip
/*select a.country, a.postal_code  ---11i code modified
      into l_country, l_zip
      from ra_addresses_all a, RA_SITE_USES_ALL su
      WHERE su.SITE_USE_ID = p_ship_to_org_id
      and su.address_id = a.address_id;*/
     --- R12 Remediated
 select ---a.country,
              hl.country ,
              ---a.postal_code
              hl.postal_code
      into l_country, l_zip
      from ---ra_addresses_all a,
            hz_party_sites hps
           ,hz_locations hl
           ,hz_cust_acct_sites_all hcasa
           ---RA_SITE_USES_ALL su
           ,hz_cust_site_uses_all su
      where su.site_use_id = p_ship_to_org_id
      ---and su.address_id = a.address_id;
      AND hcasa.cust_acct_site_id = su.cust_acct_site_id
      and hps.location_id         = hl.location_id
      and hps.party_site_id       = hcasa.party_site_id;
--commented out and added new if statement - DL 15-SEP-2012
  --if l_country in ('US','CA') and l_zip is not null then
  if (p_org_id = 102 and l_country = 'US' and l_zip is not null)
          or (p_org_id = 234 and l_country = 'CA' and l_zip is not null) then
   select m.salesrep_id
            into l_sales_rep_id
            from haemo.XXHA_SALESREP_MAPPING m, JTF_RS_SALESREPS r
            where m.product_line = l_prod_line
            and m.country = l_country
            and l_zip between m.zip_min and m.zip_max
            and r.salesrep_id = m.salesrep_id;
     end if;
    exception WHEN others THEN
      l_sales_rep_id := to_number(null);
    end; --zip
    end if; --no ship_to
END IF; --prod line
  if l_sales_rep_id is not null then
BEGIN
        SELECT end_date_active
        into l_end_date
        FROM  JTF_RS_SALESREPS r
        WHERE salesrep_id = l_sales_rep_id;
     IF nvl(l_end_date,SYSDATE) < SYSDATE THEN
            l_sales_rep_id := to_number(null);
        end if;
exception WHEN others THEN
        l_sales_rep_id := to_number(NULL);
      END;
end if;
  elsif  p_org_id in (136,158,132,237,157,134,130,159,162,155) then --Euopean operating units
      l_sales_rep_id := to_number(null);
      begin --europe
        select segment1
        into l_prod_line
        from MTL_ITEM_CATEGORIES_V
        where inventory_item_id = p_inv_item_id
        and organization_id = p_ship_from_org_id
        and category_set_name  = 'Inventory';
  if l_prod_line is not null then --prod line
begin -- shipto
            select m.salesrep_id
            into l_sales_rep_id
            from haemo.XX_HAEMO_SLS_REP_OVERRIDE m, JTF_RS_SALESREPS r
            where m.product_line = l_prod_line
            and m.shipto_site_use_id = p_ship_to_org_id
            and r.salesrep_id = m.salesrep_id;
        exception when others then
            l_sales_rep_id := to_number(null);
        end; --shipto
if l_sales_rep_id is null then --billto
        begin -- billto
            select m.salesrep_id
            into l_sales_rep_id
            from haemo.XX_HAEMO_SLS_REP_OVERRIDE m, JTF_RS_SALESREPS r
            where m.product_line = l_prod_line
            and m.billto_site_use_id = p_bill_to_site_id
            and r.salesrep_id = m.salesrep_id;
        exception when others then
            l_sales_rep_id := to_number(null);
        end; --billto
      end if; --billto
      end if; --prod line
        exception when others then
            l_sales_rep_id := to_number(null);
        end; --europe
  end if; --org_id
    if l_sales_rep_id is not null then
BEGIN
        SELECT end_date_active
        into l_end_date
        FROM  JTF_RS_SALESREPS r
        WHERE salesrep_id = l_sales_rep_id;
  IF nvl(l_end_date,SYSDATE) < SYSDATE THEN
            l_sales_rep_id := to_number(null);
        end if;
 exception WHEN others THEN
        l_sales_rep_id := to_number(NULL);
      END;
 END IF;
return l_sales_rep_id;
END;
end xxha_salesrep_default;
/
