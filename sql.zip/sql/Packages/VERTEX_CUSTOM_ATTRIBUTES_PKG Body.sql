create or replace PACKAGE BODY vertex_custom_attributes_pkg
AS
/* ======================================================================*
 | Global Data Types                                                     |
 * ======================================================================*/

/*REM |====================================================================+
  REM |body version 5.1200.0000.4.0                                        |
  REM |-- -Copyright 2006 Vertex Inc.  All rights reserved.                |
  REM |                       All rights reserved.                         |
  REM |====================================================================+
  REM |Start of Comments                                                   |
  REM |Package Name:- P_VERTEX_ETAX_PKG                                    |
  REM |Description : This function return request ID                       |
  REM |                                                                    |
  REM |                                                                    |
  REM |Version : Initial Version 4.1.2.0                                   |
  REM |                                                                    |
  REM |Modification History:                                               |
  REM | 24/05/2008   Amita Kamath   Created                                |
  REM | 13-APR-2017  Bruce Marcoux  Customizations for Haemonetics.        |
  REM | 22-JUN-2017  Bruce Marcoux  Correction to code to truncate Product |
  REM |                              class as well as stripping '�' from   |
  REM |                              Item descriptions.                    |
  REM | 06-JUL-2017  Bruce Marcoux  Correction to code to truncate Product |
  REM |                              class as well as stripping 'TM' from  |
  REM |                              Item descriptions.                    |
  REM |                             Change Item Description to 30 chars.   |
  REM |====================================================================+*/

v_pkg_name                CONSTANT VARCHAR2 (30)    := 'VERTEX_CUSTOM_ATTRIBUTES_PKG';
v_current_runtime_level   CONSTANT NUMBER           := P_VTX_WRITE_LOG.l_current_runtime_level;
v_level_unexpected        CONSTANT NUMBER           := P_VTX_WRITE_LOG.l_level_unexpected;
v_level_error             CONSTANT NUMBER           := P_VTX_WRITE_LOG.l_level_error;
v_level_exception         CONSTANT NUMBER           := P_VTX_WRITE_LOG.l_level_exception;
v_level_event             CONSTANT NUMBER           := P_VTX_WRITE_LOG.l_level_event;
v_level_procedure         CONSTANT NUMBER           := P_VTX_WRITE_LOG.l_level_procedure;
v_level_statement         CONSTANT NUMBER           := P_VTX_WRITE_LOG.l_level_statement;
v_module_name             CONSTANT VARCHAR2 (30)    := 'VERTEX_CUSTOM_ATTRIBUTES_PKG.';
v_Application_code                 VARCHAR2 (03)    := NULL;
v_RA_Customer_trx_exists           VARCHAR2 (01)    := NULL;
x_transaction_id_trxs              NUMBER           := NULL;
x_transaction_line_id_trxs         NUMBER           := NULL;
x_adjustment_trxs                  VARCHAR2 (01)    := NULL;
l_api_name                         VARCHAR2 (30);

-- AUDIT
GC_REQUEST_ID                      XXHA_COMMON_ERRORS.REQUEST_ID%TYPE           := FND_GLOBAL.CONC_REQUEST_ID;
GC_RECORD_IDENTIFIER               XXHA_COMMON_ERRORS.RECORD_IDENTIFIER%TYPE;    
GC_RECORD_NUMBER                   XXHA_COMMON_ERRORS.RECORD_NUMBER%TYPE;
GC_ERROR_CODE                      XXHA_COMMON_ERRORS.ERROR_CODE%TYPE;
GC_ERROR_MSG                       XXHA_COMMON_ERRORS.ERROR_MSG%TYPE;
GC_COMMENTS                        XXHA_COMMON_ERRORS.COMMENTS%TYPE;
GC_ATTRIBUTE1                      XXHA_COMMON_ERRORS.ATTRIBUTE1%TYPE;
GC_ATTRIBUTE2                      XXHA_COMMON_ERRORS.ATTRIBUTE2%TYPE;
GC_ATTRIBUTE3                      XXHA_COMMON_ERRORS.ATTRIBUTE3%TYPE;
GC_ATTRIBUTE4                      XXHA_COMMON_ERRORS.ATTRIBUTE4%TYPE;
GC_ATTRIBUTE5                      XXHA_COMMON_ERRORS.ATTRIBUTE5%TYPE;
GC_TABLE_NAME                      XXHA_COMMON_ERRORS.TABLE_NAME%TYPE           := 'VERTEX_CUSTOM_ATTRIBUTES';
GC_STATUS                          VARCHAR2(02);

-----------------------------------------------------------------------
-- PROCEDURE vtx_before_commit

   PROCEDURE vtx_before_commit (
      v_tax_transaction   IN       zx_tax_partner_pkg.trx_tbl_type
   )
   AS
   BEGIN
 
      NULL;

   END vtx_before_commit;


-----------------------------------------------------------------------
-- PROCEDURE vtx_before_sync

   PROCEDURE vtx_before_sync
   AS
   BEGIN

      NULL;

   END vtx_before_sync;


-----------------------------------------------------------------------
-- PROCEDURE vtx_after_sync

   PROCEDURE vtx_after_sync
   AS
   BEGIN

      NULL;

   END;


-----------------------------------------------------------------------
-- FUNCTION get_gl_date

   FUNCTION get_gl_date (
      p_transaction_id        IN       NUMBER,
      p_transaction_line_id   IN       NUMBER
   )
      RETURN DATE
   IS
      op_gl_date   DATE;
   BEGIN

      SELECT lgd.gl_date
        INTO op_gl_date
        FROM ra_customer_trx_lines_all    il,
             ra_customer_trx_all          ih,
             ra_cust_trx_line_gl_dist_all lgd
       WHERE il.customer_trx_id         = ih.customer_trx_id
         AND il.customer_trx_line_id    = lgd.customer_trx_line_id(+)
         AND il.customer_trx_id         = lgd.customer_trx_id(+)
         AND ih.customer_trx_id         = p_transaction_id
         AND il.customer_trx_line_id    = p_transaction_line_id;

      RETURN (op_gl_date);

   EXCEPTION
        WHEN OTHERS THEN
             RETURN NULL;

   END;


-----------------------------------------------------------------------
-- PROCEDURE get_fob_value

   PROCEDURE get_fob_value (
      v_transaction_id         IN       NUMBER,
      x_fob_value              OUT      VARCHAR2 
   )
   IS

   BEGIN

      l_api_name := 'GET_FOB_VALUE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_fob_value   := NULL;

      SELECT
          FLV.attribute1
      INTO
          x_fob_value
      FROM
          oe_order_headers_all       ooha
        , ra_customer_trx_all        rcta
        , FND_LOOKUP_VALUES          FLV
      WHERE
          rcta.customer_trx_id     = v_transaction_id
      --AND ooha.header_id           = rcta.interface_header_attribute1
      AND ooha.ORG_ID              = rcta.Org_id
      AND ooha.order_number        = rcta.interface_header_attribute1
      AND ooha.fob_point_code      = FLV.LOOKUP_CODE
      AND FLV.lookup_type          = 'FOB'
      AND FLV.attribute_category   = 'FOB'
      AND FLV.language             = 'US'
      AND FLV.view_application_id  = 222;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             P_VTX_WRITE_LOG.write_log(
                             v_module_name,
                             'get_fob_value' || SQLERRM
                             );

   END get_fob_value;


-----------------------------------------------------------------------
-- PROCEDURE get_fob_value_om

   PROCEDURE get_fob_value_om (
      v_transaction_id         IN       NUMBER,
      x_fob_value              OUT      VARCHAR2 
   )
   IS

   BEGIN

      l_api_name := 'GET_FOB_VALUE_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_fob_value   := NULL;

      SELECT
          FLV.attribute1
      INTO
          x_fob_value
      FROM
          oe_order_headers_all       ooha
        , FND_LOOKUP_VALUES          FLV
      WHERE
          ooha.header_id           = v_transaction_id
      AND ooha.fob_point_code      = FLV.LOOKUP_CODE
      AND FLV.lookup_type          = 'FOB'
      AND FLV.attribute_category   = 'FOB'
      AND FLV.language             = 'US'
      AND FLV.view_application_id  = 222;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             P_VTX_WRITE_LOG.write_log(
                             v_module_name,
                             'get_fob_value_om' || SQLERRM
                             );

   END get_fob_value_om;


-----------------------------------------------------------------------
-- PROCEDURE get_ra_line_number

   PROCEDURE get_ra_line_number (
      v_transaction_id         IN       NUMBER,
      v_transaction_line_id    IN       NUMBER,
      x_ra_line_number         OUT      VARCHAR2,
      x_err_status             OUT      VARCHAR2,
      x_err_msg                OUT      VARCHAR2
   )
   IS

   BEGIN

      l_api_name := 'GET_RA_LINE_NUMBER';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status             := 'S';
      x_err_msg                := NULL;
      x_ra_line_number         := NULL;

      SELECT
          rctla.Line_Number
      INTO
          x_ra_line_number
      FROM
          ra_customer_trx_all               rcta
        , ra_customer_trx_lines_all         rctla
      WHERE
          rcta.org_id                     = rctla.org_id
      AND rcta.CUSTOMER_TRX_ID            = rctla.customer_trx_id
      AND rcta.customer_trx_id            = v_transaction_id
      AND rctla.customer_trx_line_id      = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_ra_line_number := NULL;

   END get_ra_line_number;


-----------------------------------------------------------------------
-- PROCEDURE get_ra_customer_trx

   PROCEDURE get_ra_customer_trx (
      v_transaction_id         IN       NUMBER,
      v_transaction_line_id    IN       NUMBER,
      x_RA_Customer_trx_exists OUT      VARCHAR2,
      x_err_status             OUT      VARCHAR2,
      x_err_msg                OUT      VARCHAR2
   )
   IS

   l_Count                    NUMBER                       := NULL;

   BEGIN

      l_api_name := 'GET_RA_CUSTOMER_TRX';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status             := 'S';
      x_err_msg                := NULL;
      x_RA_Customer_trx_exists := NULL;
      l_Count                  := NULL;

      SELECT
          NVL(COUNT(*),0)
      INTO
          l_Count
      FROM
          ra_customer_trx_all               rcta
        , ra_customer_trx_lines_all         rctla
      WHERE
          rcta.org_id                     = rctla.org_id
      AND rcta.CUSTOMER_TRX_ID            = rctla.customer_trx_id
      AND rcta.customer_trx_id            = v_transaction_id
      AND rctla.customer_trx_line_id      = v_transaction_line_id;

      IF l_Count > 0 THEN
         x_RA_Customer_trx_exists := 'Y';
      ELSE
         x_RA_Customer_trx_exists := 'N';
      END IF;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_RA_Customer_trx_exists := NULL;

   END get_ra_customer_trx;


-----------------------------------------------------------------------
-- PROCEDURE get_Application_Code

   PROCEDURE get_Application_Code (
      v_extn_rec              IN       vertex_etax_types_pkg.vertex_processing_record,
      x_Application_Code      OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

   BEGIN

      l_api_name := 'GET_APPLICATION_CODE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_Application_Code  := NULL;

      x_Application_Code := (LTRIM(RTRIM(UPPER(v_extn_rec.application_code))));

      --IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'AR' ) THEN
      --   x_Application_Code := 'AR';
      --END IF;

      --IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'ONT' ) THEN
      --   x_Application_Code := 'ONT';
      --END IF;

   END get_Application_Code;


-----------------------------------------------------------------------
-- PROCEDURE get_Customer_code

   PROCEDURE get_Customer_code (
      v_transaction_id        IN       NUMBER,
      x_Account_Number        OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

   x_party_id                 HZ_PARTIES.party_id%TYPE     := NULL;
   l_Count                    NUMBER                       := NULL;

   BEGIN

      l_api_name := 'GET_CUSTOMER_CODE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_Account_Number    := NULL;
      x_party_id          := NULL;

      -- Is this Account part of a 'Buying Group'?
      SELECT
          NVL(COUNT(*),0)
      INTO
          l_Count
      FROM
          HZ_PARTIES                    HP
        , hz_cust_accounts              hca
        , hz_cust_site_uses_all         rsua
        , hz_party_sites                hps
        , hz_cust_acct_sites_all        hcasa
        , ra_customer_trx_all           rcta
        , hz_party_relationship_v       hzpr
      WHERE
          rcta.SHIP_TO_SITE_USE_ID    = rsua.site_use_id
      AND rsua.cust_acct_site_id      = hcasa.cust_acct_site_id
      AND HCASA.PARTY_SITE_ID         = HPS.PARTY_SITE_ID
      AND HCASA.CUST_ACCOUNT_ID       = HCA.CUST_ACCOUNT_ID
      AND hca.party_id                = hp.party_id
      AND hp.party_id                 = hzpr.object_Party_id
      AND hzpr.RELATIONSHIP_TYPE_CODE = 'BUYING_GROUP_FOR'
      AND TRUNC(SYSDATE)              BETWEEN TRUNC(hzpr.start_Date) AND NVL(TRUNC(hzpr.end_Date), TRUNC(SYSDATE+1))
      AND rcta.customer_trx_id        = v_transaction_id;

      IF l_Count > 0 THEN
         SELECT
             hca.Account_Number
         INTO
             x_Account_Number
         FROM
             HZ_PARTIES                    HP
           , hz_cust_accounts              hca
           , hz_cust_site_uses_all         rsua
           , hz_party_sites                hps
           , hz_cust_acct_sites_all        hcasa
           , ra_customer_trx_all           rcta
           , hz_party_relationship_v       hzpr
         WHERE
             rcta.SHIP_TO_SITE_USE_ID    = rsua.site_use_id
         AND rsua.cust_acct_site_id      = hcasa.cust_acct_site_id
         AND HCASA.PARTY_SITE_ID         = HPS.PARTY_SITE_ID
         AND HCASA.CUST_ACCOUNT_ID       = HCA.CUST_ACCOUNT_ID
         AND hca.party_id                = hp.party_id
         AND hp.party_id                 = hzpr.object_Party_id
         AND hzpr.RELATIONSHIP_TYPE_CODE = 'BUYING_GROUP_FOR'
         AND TRUNC(SYSDATE)              BETWEEN TRUNC(hzpr.start_Date) AND NVL(TRUNC(hzpr.end_Date), TRUNC(SYSDATE+1))
         AND rcta.customer_trx_id        = v_transaction_id;
      ELSE
         SELECT
             hca.Account_Number
         INTO
             x_Account_Number
         FROM
             HZ_PARTIES                   HP
           , hz_cust_accounts             hca
           , hz_cust_site_uses_all        rsua
           , hz_party_sites               hps
           , HZ_LOCATIONS                 HL
           , hz_cust_acct_sites_all       hcasa
           , ra_customer_trx_all          rcta
         WHERE
             rcta.bill_to_site_use_id   = rsua.site_use_id
         AND rsua.cust_acct_site_id     = hcasa.cust_acct_site_id 
         AND HCASA.PARTY_SITE_ID        = HPS.PARTY_SITE_ID
         AND hps.location_id            = hl.location_id 
         AND HCASA.CUST_ACCOUNT_ID      = HCA.CUST_ACCOUNT_ID
         AND hca.party_id               = hp.party_id
         AND rcta.customer_trx_id       = v_transaction_id;
      END IF;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Account_Number := NULL;

   END get_Customer_code;


-----------------------------------------------------------------------
-- PROCEDURE get_Customer_code_OM

   PROCEDURE get_Customer_code_OM (
      v_transaction_id        IN       NUMBER,
      x_Account_Number        OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

   x_party_id                 HZ_PARTIES.party_id%TYPE     := NULL;
   l_Count                    NUMBER                       := NULL;

   BEGIN

      l_api_name := 'GET_CUSTOMER_CODE_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_Account_Number    := NULL;
      x_party_id          := NULL;

      -- Is this Account part of a 'Buying Group'?
      SELECT
          NVL(COUNT(*),0)
      INTO
          l_Count
      FROM
          HZ_PARTIES                    HP
        , hz_cust_accounts              hca
        , hz_cust_site_uses_all         rsua
        , hz_party_sites                hps
        , hz_cust_acct_sites_all        hcasa
        , oe_order_headers_all          ooha
        , hz_party_relationship_v       hzpr
      WHERE
          ooha.SHIP_TO_ORG_ID         = rsua.site_use_id
      AND rsua.cust_acct_site_id      = hcasa.cust_acct_site_id
      AND HCASA.PARTY_SITE_ID         = HPS.PARTY_SITE_ID
      AND HCASA.CUST_ACCOUNT_ID       = HCA.CUST_ACCOUNT_ID
      AND hca.party_id                = hp.party_id
      AND hp.party_id                 = hzpr.object_Party_id
      AND hzpr.RELATIONSHIP_TYPE_CODE = 'BUYING_GROUP_FOR'
      AND TRUNC(SYSDATE)              BETWEEN TRUNC(hzpr.start_Date) AND NVL(TRUNC(hzpr.end_Date), TRUNC(SYSDATE+1))
      AND ooha.header_id              = v_transaction_id;

      IF l_Count > 0 THEN
         SELECT
             hca.Account_Number
         INTO
             x_Account_Number
         FROM
             HZ_PARTIES                    HP
           , hz_cust_accounts              hca
           , hz_cust_site_uses_all         rsua
           , hz_party_sites                hps
           , hz_cust_acct_sites_all        hcasa
           , oe_order_headers_all          ooha
           , hz_party_relationship_v       hzpr
         WHERE
             ooha.SHIP_TO_ORG_ID         = rsua.site_use_id
         AND rsua.cust_acct_site_id      = hcasa.cust_acct_site_id
         AND HCASA.PARTY_SITE_ID         = HPS.PARTY_SITE_ID
         AND HCASA.CUST_ACCOUNT_ID       = HCA.CUST_ACCOUNT_ID
         AND hca.party_id                = hp.party_id
         AND hp.party_id                 = hzpr.object_Party_id
         AND hzpr.RELATIONSHIP_TYPE_CODE = 'BUYING_GROUP_FOR'
         AND TRUNC(SYSDATE)              BETWEEN TRUNC(hzpr.start_Date) AND NVL(TRUNC(hzpr.end_Date), TRUNC(SYSDATE+1))
         AND ooha.header_id              = v_transaction_id;
      ELSE
         SELECT
             hca.Account_Number
         INTO
             x_Account_Number
         FROM
             HZ_PARTIES                 HP
           , hz_cust_accounts           hca
           , hz_cust_site_uses_all      rsua
           , hz_party_sites             hps
           , HZ_LOCATIONS               HL
           , hz_cust_acct_sites_all     hcasa
           , oe_order_headers_all       ooha
         WHERE
             ooha.INVOICE_TO_ORG_ID   = rsua.site_use_id
         AND rsua.cust_acct_site_id   = hcasa.cust_acct_site_id
         AND HCASA.PARTY_SITE_ID      = HPS.PARTY_SITE_ID
         AND hps.location_id          = hl.location_id
         AND HCASA.CUST_ACCOUNT_ID    = HCA.CUST_ACCOUNT_ID
         AND hca.party_id             = hp.party_id
         AND ooha.header_id           = v_transaction_id;
      END IF;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Account_Number := NULL;

   END get_Customer_code_OM;


-----------------------------------------------------------------------
-- PROCEDURE get_BT_Customer_Name_Acct

   PROCEDURE get_BT_Customer_Name_Acct (
      v_transaction_id        IN       NUMBER,
      x_BT_Customer_Name      OUT      VARCHAR2,
      x_BT_Account_Number     OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_BT_CUSTOMER_NAME_ACCT';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_BT_Customer_Name  := NULL;
      x_BT_Account_Number := NULL;

      SELECT
          SUBSTR(hp.party_name, 1, 40) Customer_Name -- Must not exceed 40 characters
        , hca.Account_Number
      INTO
          x_BT_Customer_Name
        , x_BT_Account_Number
      FROM
          HZ_PARTIES                   HP
        , hz_cust_accounts             hca
        , hz_cust_site_uses_all        rsua
        , hz_party_sites               hps
        , HZ_LOCATIONS                 HL
        , hz_cust_acct_sites_all       hcasa
        , ra_customer_trx_all          rcta
      WHERE
          rcta.bill_to_site_use_id   = rsua.site_use_id
      AND rsua.cust_acct_site_id     = hcasa.cust_acct_site_id 
      AND HCASA.PARTY_SITE_ID        = HPS.PARTY_SITE_ID
      AND hps.location_id            = hl.location_id 
      AND HCASA.CUST_ACCOUNT_ID      = HCA.CUST_ACCOUNT_ID
      AND hca.party_id               = hp.party_id
      AND rcta.customer_trx_id       = v_transaction_id;
      
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_BT_Customer_Name  := NULL;
             x_BT_Account_Number := NULL;

   END get_BT_Customer_Name_Acct;


-----------------------------------------------------------------------
-- PROCEDURE get_BT_Customer_Name_Acct_OM

   PROCEDURE get_BT_Customer_Name_Acct_OM (
      v_transaction_id        IN       NUMBER,
      x_BT_Customer_Name      OUT      VARCHAR2,
      x_BT_Account_Number     OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_BT_CUSTOMER_NAME_ACCT_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_BT_Customer_Name  := NULL;
      x_BT_Account_Number := NULL;

      SELECT
          SUBSTR(hp.party_name, 1, 40) Customer_Name -- Must not exceed 40 characters
        , hca.Account_Number
      INTO
          x_BT_Customer_Name
        , x_BT_Account_Number
      FROM
          HZ_PARTIES                   HP
        , hz_cust_accounts             hca
        , hz_cust_site_uses_all        rsua
        , hz_party_sites               hps
        , HZ_LOCATIONS                 HL
        , hz_cust_acct_sites_all       hcasa
        , oe_order_headers_all         ooha
      WHERE
          ooha.INVOICE_TO_ORG_ID     = rsua.site_use_id
      AND rsua.cust_acct_site_id     = hcasa.cust_acct_site_id
      AND HCASA.PARTY_SITE_ID        = HPS.PARTY_SITE_ID
      AND hps.location_id            = hl.location_id
      AND HCASA.CUST_ACCOUNT_ID      = HCA.CUST_ACCOUNT_ID
      AND hca.party_id               = hp.party_id
      AND ooha.header_id             = v_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_BT_Customer_Name  := NULL;
             x_BT_Account_Number := NULL;

   END get_BT_Customer_Name_Acct_OM;


-----------------------------------------------------------------------
-- PROCEDURE get_ST_Customer_Name_Acct

   PROCEDURE get_ST_Customer_Name_Acct (
      v_transaction_id        IN       NUMBER,
      x_ST_Customer_Name      OUT      VARCHAR2,
      x_ST_Account_Number     OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_ST_CUSTOMER_NAME_ACCT';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_ST_Customer_Name  := NULL;
      x_ST_Account_Number := NULL;

      SELECT
          SUBSTR(hp.party_name, 1, 40) Customer_Name -- Must not exceed 40 characters
        , hca.Account_Number
      INTO 
          x_ST_Customer_Name
        , x_ST_Account_Number
      FROM
          HZ_PARTIES                 HP
        , hz_cust_accounts           hca
        , hz_cust_site_uses_all      rsua
        , hz_party_sites             hps
        , HZ_LOCATIONS               HL
        , hz_cust_acct_sites_all     hcasa
        , ra_customer_trx_all        rcta
      WHERE
          rcta.SHIP_TO_SITE_USE_ID = rsua.site_use_id
      AND rsua.cust_acct_site_id   = hcasa.cust_acct_site_id
      AND HCASA.PARTY_SITE_ID      = HPS.PARTY_SITE_ID
      AND hps.location_id          = hl.location_id
      AND HCASA.CUST_ACCOUNT_ID    = HCA.CUST_ACCOUNT_ID
      AND hca.party_id             = hp.party_id
      AND rcta.customer_trx_id     = v_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_ST_Customer_Name  := NULL;
             x_ST_Account_Number := NULL;

   END get_ST_Customer_Name_Acct;


-----------------------------------------------------------------------
-- PROCEDURE get_ST_Customer_Name_Acct_OM

   PROCEDURE get_ST_Customer_Name_Acct_OM (
      v_transaction_id        IN       NUMBER,
      x_ST_Customer_Name      OUT      VARCHAR2,
      x_ST_Account_Number     OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_ST_CUSTOMER_NAME_ACCT_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_ST_Customer_Name  := NULL;
      x_ST_Account_Number := NULL;

      SELECT
          SUBSTR(hp.party_name, 1, 40) Customer_Name -- Must not exceed 40 characters
        , hca.Account_Number
      INTO 
          x_ST_Customer_Name
        , x_ST_Account_Number
      FROM
          HZ_PARTIES                 HP
        , hz_cust_accounts           hca
        , hz_cust_site_uses_all      rsua
        , hz_party_sites             hps
        , HZ_LOCATIONS               HL
        , hz_cust_acct_sites_all     hcasa
        , oe_order_headers_all       ooha
      WHERE
          ooha.SHIP_TO_ORG_ID      = rsua.site_use_id
      AND rsua.cust_acct_site_id   = hcasa.cust_acct_site_id
      AND HCASA.PARTY_SITE_ID      = HPS.PARTY_SITE_ID
      AND hps.location_id          = hl.location_id
      AND HCASA.CUST_ACCOUNT_ID    = HCA.CUST_ACCOUNT_ID
      AND hca.party_id             = hp.party_id
      AND ooha.header_id           = v_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_ST_Customer_Name  := NULL;
             x_ST_Account_Number := NULL;

   END get_ST_Customer_Name_Acct_OM;


-----------------------------------------------------------------------
-- PROCEDURE get_Description

   PROCEDURE get_Description (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_Description           OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

   l_Description                       VARCHAR2(240)            := NULL;

   BEGIN

      l_api_name := 'GET_DESCRIPTION';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status     := 'S';
      x_err_msg        := NULL;
      x_Description    := NULL;
      l_Description    := NULL;

      SELECT
          SUBSTR(RCTLA.DESCRIPTION, 1, 30) -- Must not exceed 30 characters
      INTO
          l_Description
      FROM
          ra_customer_trx_all            rcta
        , ra_customer_trx_lines_all      rctla
      WHERE
          rcta.org_id                  = rctla.org_id
      AND rcta.CUSTOMER_TRX_ID         = rctla.customer_trx_id
      AND rcta.customer_trx_id         = v_transaction_id
      AND rctla.customer_trx_line_id   = v_transaction_line_id;

      -- Strip off '�' from description
      x_Description := REPLACE(l_Description,'�','');
      -- Strip off '�' from description
      x_Description := REPLACE(l_Description,'�','');

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Description  := NULL;

   END get_Description;


-----------------------------------------------------------------------
-- PROCEDURE get_Description_OM

   PROCEDURE get_Description_OM (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_Description           OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

   l_Description                       VARCHAR2(240)            := NULL;

   BEGIN

      l_api_name := 'GET_DESCRIPTION_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status     := 'S';
      x_err_msg        := NULL;
      x_Description    := NULL;
      l_Description    := NULL;

      SELECT
          SUBSTR(NVL(oola.USER_ITEM_DESCRIPTION, itm.Description), 1, 30) -- Must not exceed 30 characters
      INTO
          l_Description
      FROM
          oe_order_headers_all    ooha
        , oe_order_lines_all      oola
        , mtl_system_items_b      itm
      WHERE
          ooha.header_id        = oola.header_id
      AND oola.ORDERED_ITEM_ID  = ITM.INVENTORY_ITEM_ID
      AND oola.ship_from_org_id = itm.organization_id
      AND ooha.header_id        = v_transaction_id
      AND oola.LINE_ID          = v_transaction_line_id;

      -- Strip off '�' from description
      x_Description := REPLACE(l_Description,'�','');
      -- Strip off '�' from description
      x_Description := REPLACE(l_Description,'�','');

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Description  := NULL;

   END get_Description_OM;


-----------------------------------------------------------------------
-- PROCEDURE get_Delivery_Type

   PROCEDURE get_Delivery_Type(
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_Delivery_Type         OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_DELIVERY_TYPE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_Delivery_Type     := NULL;

      -- Retrieve Shipping Method Code from oe_order_lines_all, if no value retrieve from oe_order_headers_all
      SELECT
          NVL(oola.shipping_method_code, ooha.shipping_method_code)
      INTO
          x_Delivery_Type
      FROM
          ra_customer_trx_all               rcta
        , ra_customer_trx_lines_all         rctla
        , oe_order_headers_all              ooha
        , oe_order_lines_all                oola
      WHERE
          rcta.Org_id                     = OOHA.Org_ID
      AND ooha.header_id                  = oola.HEADER_ID
      AND rctla.org_id                    = rcta.org_id
      AND TO_CHAR(OOHA.Order_Number)      = rcta.CT_REFERENCE
      AND rctla.INTERFACE_LINE_ATTRIBUTE6 = TO_CHAR(oola.line_id)
      AND rcta.customer_trx_id            = v_transaction_id
      AND rctla.customer_trx_line_id      = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Delivery_Type := NULL;

   END get_Delivery_Type;


-----------------------------------------------------------------------
-- PROCEDURE get_Delivery_Type_OM

   PROCEDURE get_Delivery_Type_OM(
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_Delivery_Type         OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_DELIVERY_TYPE_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_Delivery_Type     := NULL;

      -- Retrieve Shipping Method Code from oe_order_lines_all, if no value retrieve from oe_order_headers_all
      SELECT
          NVL(oola.shipping_method_code, ooha.shipping_method_code)
      INTO
          x_Delivery_Type
      FROM
          oe_order_headers_all    ooha
        , oe_order_lines_all      oola
      WHERE
          OOHA.Org_ID           = oola.org_ID
      AND ooha.header_id        = oola.HEADER_ID
      AND ooha.header_id        = v_transaction_id
      AND oola.LINE_ID          = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Delivery_Type := NULL;

   END get_Delivery_Type_OM;


-----------------------------------------------------------------------
-- PROCEDURE get_Transaction_Type

   PROCEDURE get_Transaction_Type (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_Transaction_Type      OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_TRANSACTION_TYPE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_Transaction_Type  := NULL;

      SELECT
          rctta.NAME
      INTO
          x_Transaction_Type
      FROM
          RA_CUST_TRX_TYPES_ALL        rctta
        , ra_customer_trx_all          rcta
        , ra_customer_trx_lines_all    rctla
      WHERE
          rcta.org_id                = rctla.org_id 
      AND rcta.CUSTOMER_TRX_ID       = rctla.customer_trx_id
      AND rcta.cust_trx_type_id      = rctta.cust_trx_type_id
      AND rcta.org_id                = rctta.org_id
      AND rcta.customer_trx_id       = v_transaction_id
      AND rctla.customer_trx_line_id = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Transaction_Type := NULL;

   END get_Transaction_Type;


-----------------------------------------------------------------------
-- PROCEDURE get_AR_Source

   PROCEDURE get_AR_Source (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_AR_Source             OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_AR_SOURCE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status        := 'S';
      x_err_msg           := NULL;
      x_AR_Source         := NULL;

      SELECT
          UPPER(rbsa.name)                                                      -- MANUAL-OTHER, OKS_CONTRACTS, Order Management, PROJECTS INVOICES
      INTO
          x_AR_Source
      FROM
          ra_customer_trx_all          rcta
        , ra_customer_trx_lines_all    rctla
        , RA_BATCH_SOURCES_ALL         rbsa
      WHERE
          RCTA.BATCH_SOURCE_ID       = rbsa.BATCH_SOURCE_ID
      AND rcta.org_id                = rbsa.org_id
      AND rcta.org_id                = rctla.org_id 
      AND rcta.CUSTOMER_TRX_ID       = rctla.customer_trx_id
      AND rcta.customer_trx_id       = v_transaction_id
      AND rctla.customer_trx_line_id = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_AR_Source := NULL;

   END get_AR_Source;


-----------------------------------------------------------------------
-- PROCEDURE get_Project_Data

   PROCEDURE get_Project_Data (
      v_transaction_id        IN       NUMBER,
      x_Project_Number        OUT      VARCHAR2,
      x_Project_Description   OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_PROJECT_DATA';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status          := 'S';
      x_err_msg             := NULL;
      x_Project_Number      := NULL;
      x_Project_Description := NULL;

      SELECT
          PRJ.Name               Project_Name
        , PRJ.segment1           Project_Number
      INTO
          x_Project_Description
        , x_Project_Number
      FROM
          ra_customer_trx_all    rcta
        , PA_PROJECTS_ALL        PRJ
      WHERE
          rcta.customer_trx_id = v_transaction_id
      AND rcta.org_id          = PRJ.ORG_ID
      AND rcta.CT_REFERENCE    = PRJ.segment1;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Project_Number      := NULL;
             x_Project_Description := NULL;

   END get_Project_Data;


-----------------------------------------------------------------------
-- PROCEDURE get_Contract_Data

   PROCEDURE get_Contract_Data (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_Contract_Number       OUT      VARCHAR2,
      x_Contract_Modifier     OUT      VARCHAR2,
      x_Order_Number          OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_CONTRACT_DATA';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status          := 'S';
      x_err_msg             := NULL;
      x_Order_Number        := NULL;
      x_Contract_Number     := NULL;
      x_Contract_Modifier   := NULL;

      SELECT
          NULL                  OrderNumber                                     -- as per JoAnn, return NULL Value, no Order# for Contracts
--        rcta.CT_REFERENCE                OrderNumber
        , NVL(rctla.INTERFACE_LINE_ATTRIBUTE1, rcta.INTERFACE_HEADER_ATTRIBUTE1) ContractNumber
        , NVL(rctla.INTERFACE_LINE_ATTRIBUTE2, rcta.INTERFACE_HEADER_ATTRIBUTE2) ContractModifier
      INTO
          x_Order_Number
        , x_Contract_Number
        , x_Contract_Modifier
      FROM
          apps.ra_customer_trx_all          rcta
        , apps.ra_customer_trx_lines_all    rctla
      WHERE
          rcta.org_id                     = rctla.org_id 
      AND rcta.CUSTOMER_TRX_ID            = rctla.customer_trx_id
      AND rcta.customer_trx_id            = v_transaction_id
      AND Rctla.customer_trx_line_id      = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Order_Number        := NULL;
             x_Contract_Number     := NULL;
             x_Contract_Modifier   := NULL;

   END get_Contract_Data;


-----------------------------------------------------------------------
-- PROCEDURE get_OrderEntry_Data

   PROCEDURE get_OrderEntry_Data (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_Order_Number          OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_ORDERENTRY_DATA';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status          := 'S';
      x_err_msg             := NULL;
      x_Order_Number        := NULL;

      SELECT
          NVL(rctla.INTERFACE_LINE_ATTRIBUTE1, rcta.INTERFACE_HEADER_ATTRIBUTE1) OrderNumber
      INTO
          x_Order_Number
      FROM
          apps.ra_customer_trx_all        rcta
        , apps.ra_customer_trx_lines_all  rctla
      WHERE
          rcta.org_id                     = rctla.org_id 
      AND rcta.CUSTOMER_TRX_ID            = rctla.customer_trx_id
      AND rcta.customer_trx_id            = v_transaction_id
      AND Rctla.customer_trx_line_id      = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_Order_Number := NULL;

   END get_OrderEntry_Data;


-----------------------------------------------------------------------
-- PROCEDURE get_OrgID

   PROCEDURE get_OrgID (
      v_transaction_id        IN       NUMBER,
      x_OrgID                 OUT      NUMBER,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_ORGID';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status          := 'S';
      x_err_msg             := NULL;
      x_OrgID               := NULL;

      SELECT
          rcta.Org_Id
      INTO
          x_OrgID
      FROM
          apps.ra_customer_trx_all  rcta
      WHERE
          rcta.customer_trx_id    = v_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_OrgID := NULL;

   END get_OrgID;


-----------------------------------------------------------------------
-- PROCEDURE get_OrgID_OM

   PROCEDURE get_OrgID_OM (
      v_transaction_id        IN       NUMBER,
      x_OrgID                 OUT      NUMBER,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_ORGID_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status          := 'S';
      x_err_msg             := NULL;
      x_OrgID               := NULL;

      SELECT
          ooha.Org_Id
      INTO
          x_OrgID
      FROM
          oe_order_headers_all    ooha
      WHERE
          ooha.header_id        = v_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_OrgID := NULL;

   END get_OrgID_OM;


-----------------------------------------------------------------------
-- PROCEDURE Update_Global_Attr19

   PROCEDURE Update_Global_Attr19 (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      v_ship_to_taid          IN       NUMBER,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'UPDATE_GLOBAL_ATTR19';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status          := 'S';
      x_err_msg             := NULL;

      UPDATE
          apps.ra_customer_trx_lines_all  rctla
      SET
          rctla.Global_Attribute19      = v_ship_to_taid
      WHERE
          rctla.customer_trx_id         = v_transaction_id
      AND rctla.customer_trx_line_id    = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_err_status  := 'E';
             x_err_msg     := SQLERRM;
        COMMIT;

   END Update_Global_Attr19;


-----------------------------------------------------------------------
-- PROCEDURE Update_Global_Attr20

   PROCEDURE Update_Global_Attr20 (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      v_product_class         IN       vertex_etx_txn_details.line_char17%TYPE,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'UPDATE_GLOBAL_ATTR20';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status          := 'S';
      x_err_msg             := NULL;

      UPDATE
          apps.ra_customer_trx_lines_all  rctla
      SET
          rctla.Global_Attribute20      = v_product_class
      WHERE
          rctla.customer_trx_id         = v_transaction_id
      AND rctla.customer_trx_line_id    = v_transaction_line_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_err_status  := 'E';
             x_err_msg     := SQLERRM;
        COMMIT;

   END Update_Global_Attr20;


-----------------------------------------------------------------------
-- PROCEDURE get_division_code_OM

   PROCEDURE get_division_code_OM (
      v_transaction_id        IN       NUMBER,
      x_division_code         OUT      vertex_etx_txn_details.line_char15%TYPE,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_DIVISION_CODE_OM';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status    := 'S';
      x_err_msg       := NULL;
      x_division_code := NULL;

      SELECT
          gcc.segment1                       legal_entity 
      INTO
          x_division_code
      FROM
          oe_order_headers_all               ooha
       ,  oe_transaction_types_all           oetta
       ,  gl_code_combinations_kfv           gcc
      WHERE
          ooha.org_id                      = oetta.org_id
      AND ooha.order_type_id               = oetta.transaction_type_id
      AND oetta.cost_of_goods_sold_account = gcc.code_combination_id
      AND ooha.header_id                   = v_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_division_code := NULL;

   END get_division_code_OM;


-----------------------------------------------------------------------
-- PROCEDURE get_original_tax

   PROCEDURE get_original_tax (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_tax_exists            OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

      x_meaning                         fnd_lookup_values.MEANING%TYPE := NULL;
      x_previous_customer_trx_id        ra_customer_trx_all.previous_customer_trx_id%TYPE := NULL;
      x_previous_customer_trx_ln_id     ra_customer_trx_lines_all.previous_customer_trx_line_id%TYPE := NULL;
      x_line_number                     ra_customer_trx_lines_all.line_number%TYPE := NULL;
      x_tax_amount                      ra_customer_trx_lines_all.extended_amount%TYPE := NULL;

   BEGIN

      l_api_name := 'GET_ORIGINAL_TAX';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );
      x_err_status  := 'S';
      x_err_msg     := NULL;
      x_meaning     := NULL;
      x_line_number := NULL;
      x_tax_amount  := NULL;
      x_tax_exists  := NULL;

      SELECT
          al.meaning
      INTO
          x_meaning
      FROM
          ra_customer_trx_all     rcta
       ,  RA_CUST_TRX_TYPES_ALL   rctp
       ,  fnd_lookup_values       al 
      WHERE
          rcta.customer_trx_id  = v_transaction_id
      AND rcta.CUST_TRX_TYPE_ID = rctp.CUST_TRX_TYPE_ID 
      AND rcta.org_id           = rctp.ORG_ID
      AND rctp.type             = al.LOOKUP_CODE 
      AND al.LOOKUP_TYPE        = 'INV/CM/ADJ'
      AND al.LANGUAGE           = 'US';

      IF UPPER(x_meaning) = 'CREDIT MEMO' THEN
         -- Using Input Customer TRX_ID and Customer TRX_LINE_ID from CM, retrieve original Customer trx_id and Customer trx_line_id
         SELECT
             rcta.Previous_Customer_trx_id
           , rctla.Previous_Customer_trx_line_id
         INTO
             x_previous_customer_trx_id
           , x_previous_customer_trx_ln_id
         FROM
             ra_customer_trx_all       rcta
           , ra_customer_trx_lines_all rctla
         WHERE
             rcta.org_id                = rctla.org_id
         AND rcta.CUSTOMER_TRX_ID       = rctla.customer_trx_id
         AND rcta.customer_trx_id       = v_transaction_id
         AND rctla.customer_trx_line_id = v_transaction_line_id;

         -- Retrieve Original Invoice data using Previous Customer TRX_ID and Customer trx_line_id to retrieve the Line Number
         SELECT
             rctla.Line_number
         INTO
             x_line_number
         FROM
             ra_customer_trx_all       rcta
           , ra_customer_trx_lines_all rctla
         WHERE
             rcta.org_id                = rctla.org_id
         AND rcta.CUSTOMER_TRX_ID       = rctla.customer_trx_id
         AND rcta.customer_trx_id       = x_previous_customer_trx_id
         AND rctla.customer_trx_line_id = x_previous_customer_trx_ln_id
         ;

         -- Now sum up 'TAX' Records for that Customer trx_id and Line Number
         SELECT 
             NVL(SUM(rctla.extended_amount),0)
         INTO
             x_tax_amount
         FROM
             ra_customer_trx_all       rcta
           , ra_customer_trx_lines_all rctla
         WHERE
             rcta.org_id                = rctla.org_id
         AND rcta.CUSTOMER_TRX_ID       = rctla.customer_trx_id
         AND rcta.customer_trx_id       = x_previous_customer_trx_id
         AND rctla.Line_number          = x_line_number
         AND UPPER(rctla.Line_type)     = 'TAX';

         -- If tax amount > 0 then return 'Y'
         IF x_tax_amount > 0 THEN
            x_tax_exists := 'Y';
         ELSE
            x_tax_exists := 'N';
         END IF;
      END IF;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
            x_tax_exists := NULL;

   END get_original_tax;


-----------------------------------------------------------------------
-- PROCEDURE get_credit_memo_date

   PROCEDURE get_credit_memo_date (
      v_transaction_id        IN       NUMBER,
      x_cr_trx_date           OUT      VARCHAR2,
      x_trx_number            OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

      x_meaning                    fnd_lookup_values.MEANING%TYPE := NULL;
      x_previous_customer_trx_id   ra_customer_trx_all.previous_customer_trx_id%TYPE := NULL;

   BEGIN

      l_api_name := 'GET_CREDIT_MEMO_DATE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );
      x_err_status  := 'S';
      x_err_msg     := NULL;
      x_cr_trx_date := NULL;
      x_meaning     := NULL;
      x_trx_number  := NULL;

      SELECT
          al.meaning
       ,  rcta.trx_date
      INTO
          x_meaning
       ,  x_cr_trx_date
      FROM
          ra_customer_trx_all     rcta
       ,  RA_CUST_TRX_TYPES_ALL   rctp
       ,  fnd_lookup_values       al 
      WHERE
          rcta.customer_trx_id  = v_transaction_id
      AND rcta.CUST_TRX_TYPE_ID = rctp.CUST_TRX_TYPE_ID 
      AND rcta.org_id           = rctp.ORG_ID
      AND rctp.type             = al.LOOKUP_CODE 
      AND al.LOOKUP_TYPE        = 'INV/CM/ADJ'
      AND al.LANGUAGE           = 'US';

      IF UPPER(x_meaning) = 'CREDIT MEMO' THEN
         -- Retrieve previous customer trx id
         SELECT
             rcta.previous_customer_trx_id
         INTO
             x_previous_customer_trx_id
         FROM
             ra_customer_trx_all     rcta
         WHERE
             rcta.customer_trx_id  = v_transaction_id;

         -- Retrieve Original Invoice Number using previous customer trx id
         SELECT
             rcta.TRX_NUMBER
         INTO
             x_trx_number
         FROM
             ra_customer_trx_all     rcta
         WHERE
             rcta.customer_trx_id  = x_previous_customer_trx_id;
      END IF;

      -- If transaction is not a Credit Memo, set x_trx_date to NULL
      IF UPPER(x_meaning) <> 'CREDIT MEMO' THEN
         x_cr_trx_date := NULL;
      END IF;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
            x_cr_trx_date := NULL;
            x_trx_number  := NULL;

   END get_credit_memo_date;


-----------------------------------------------------------------------
-- PROCEDURE get_customer_trx_id

   PROCEDURE get_customer_trx_id (
      v_transaction_id        IN       NUMBER,
      x_transaction_id_trx    OUT      NUMBER,
      x_transaction_line_id   OUT      NUMBER,
      x_trx_number            OUT      VARCHAR2,
      x_adjustment_trx        OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS

      x_count                 NUMBER := NULL;

   BEGIN

      l_api_name := 'GET_CUSTOMER_TRX_ID';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );
      x_err_status          := 'S';
      x_err_msg             := NULL;
      x_transaction_id_trx  := NULL;
      x_trx_number          := NULL;
      x_count               := 0;
      x_adjustment_trx      := 'N';

      -- Deteremine if record exists
      SELECT NVL(COUNT(*),0)
      INTO
          x_count
      FROM
          AR_ADJUSTMENTS_ALL ARA
      WHERE
          ara.adjustment_id = v_transaction_id;

      -- If we found a record, return the customer_trx_id from AR_ADJUSTMENTS_ALL
      IF NVL(x_count,0) > 0 THEN
         SELECT
             customer_trx_id
           , 'Y'
         INTO
             x_transaction_id_trx
           , x_adjustment_trx
         FROM
             AR_ADJUSTMENTS_ALL   ARA
         WHERE
             ara.adjustment_id  = v_transaction_id;

      -- Return the Original Invoice Number and Customer Trx Line ID using x_transaction_id_trx
         SELECT
             rcta.trx_number
           , rctla.customer_trx_line_id
         INTO
             x_trx_number
           , x_transaction_line_id
         FROM
             ra_customer_trx_all       rcta
           , ra_customer_trx_lines_all rctla
         WHERE
             rcta.org_id             = rctla.org_id
         AND rcta.CUSTOMER_TRX_ID    = rctla.customer_trx_id
         AND rcta.customer_trx_id    = x_transaction_id_trx
         AND ROWNUM                  = 1;
      END IF;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_transaction_id_trx  := NULL;
             x_transaction_line_id := NULL;
             x_trx_number          := NULL;
             x_adjustment_trx      := NULL;

   END get_customer_trx_id;


-----------------------------------------------------------------------
-- PROCEDURE get_ar_adjustment_date

   PROCEDURE get_ar_adjustment_date (
      v_transaction_id        IN       NUMBER,
      x_ar_adjustment_date    OUT      VARCHAR2,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_AR_ADJUSTMENT_DATE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );
      x_err_status         := 'S';
      x_err_msg            := NULL;
      x_ar_adjustment_date := NULL;

      SELECT
          ara.apply_date
      INTO
          x_ar_adjustment_date
      FROM
          AR_ADJUSTMENTS_ALL   ARA
      WHERE
          ara.adjustment_id  = v_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_ar_adjustment_date  := NULL;

   END get_ar_adjustment_date;


-----------------------------------------------------------------------
-- PROCEDURE get_transaction_date

   PROCEDURE get_transaction_date (
      v_trx_date     IN       DATE,
      x_trx_date     OUT      VARCHAR2,
      x_err_status   OUT      VARCHAR2,
      x_err_msg      OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_TRANSACTION_DATE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );
      x_err_status := 'S';
      x_err_msg    := NULL;
      x_trx_date   := NULL;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   END get_transaction_date;


-----------------------------------------------------------------------
-- PROCEDURE get_company_code 

   PROCEDURE get_company_code (
      v_company_code          IN       vertex_etx_txn_header.legal_entity_number%TYPE,
      x_company_code          OUT      vertex_etx_txn_header.legal_entity_number%TYPE,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_COMPANY_CODE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status   := 'S';
      x_err_msg      := NULL;
      x_company_code := NULL;

      SELECT
          pov.profile_option_value
      INTO
          x_company_code
      FROM
          fnd_profile_options       po
        , fnd_profile_option_values pov
        , hr_operating_units        org
      WHERE
          po.profile_option_name  = 'VERTEX_COMPANY_CODE'
      AND po.application_id       = pov.application_id
      AND po.profile_option_id    = pov.profile_option_id
      AND pov.level_value         = org.organization_id
      AND pov.level_value         = v_company_code;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_company_code := NULL;

   END get_company_code;


-----------------------------------------------------------------------
-- PROCEDURE get_division_code

   PROCEDURE get_division_code (
      v_transaction_id        IN       NUMBER,
      v_transaction_line_id   IN       NUMBER,
      x_division_code         OUT      vertex_etx_txn_details.line_char15%TYPE,
      x_err_status            OUT      VARCHAR2,
      x_err_msg               OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_DIVISION_CODE';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status    := 'S';
      x_err_msg       := NULL;
      x_division_code := NULL;

      SELECT
          gcc.segment1                  legal_entity 
      INTO
          x_division_code
      FROM
          ra_customer_trx_all           rcta
        , ra_customer_trx_lines_all     rctla
        , ra_cust_trx_line_gl_dist_all  rctgl
        , gl_code_combinations_kfv      gcc
      WHERE
          rcta.org_id                 = rctla.org_id
      AND rcta.CUSTOMER_TRX_ID        = rctla.customer_trx_id
      AND rctla.customer_trx_id       = rctgl.customer_trx_id
      AND rctla.customer_trx_line_id  = rctgl.customer_trx_line_id
      AND rctgl.code_combination_id   = gcc.code_combination_id
      AND rcta.customer_trx_id        = v_transaction_id
      AND rctla.customer_trx_line_id  = v_transaction_line_id
      AND ROWNUM                      = 1;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_division_code := NULL;

   END get_division_code;


-----------------------------------------------------------------------
-- PROCEDURE get_exemption_number

   PROCEDURE get_exemption_number (
      v_exemption_number   OUT      vertex_etx_txn_details.exempt_certificate_number%TYPE,
      x_exemption_number   OUT      vertex_etx_txn_details.exempt_certificate_number%TYPE,
      x_err_status         OUT      VARCHAR2,
      x_err_msg            OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_EXEMPTION_NUMBER';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status       := 'S';
      x_err_msg          := NULL;
      x_exemption_number := NULL;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   END get_exemption_number;


-----------------------------------------------------------------------
-- PROCEDURE get_product_class

   PROCEDURE get_product_class (
      x_product_class   OUT      vertex_etx_txn_details.line_char17%TYPE,
      x_err_status      OUT      VARCHAR2,
      x_err_msg         OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_product_CLASS';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status    := 'S';
      x_err_msg       := NULL;
      x_product_class := NULL;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   END get_product_class;
 

-----------------------------------------------------------------------
-- PROCEDURE get_customer_class

   PROCEDURE get_customer_class (
      x_customer_class   OUT      vertex_etx_txn_details.line_char13%TYPE,
      x_err_status       OUT      VARCHAR2,
      x_err_msg          OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'GET_CUSTOMER_CLASS';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status     := 'S';
      x_err_msg        := NULL;
      x_customer_class := NULL;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   END get_customer_class;
 

-----------------------------------------------------------------------
-- PROCEDURE get_product_class

   PROCEDURE get_product_class (
      v_product_id      IN       vertex_etx_txn_details.product_id%TYPE,
      x_product_class   IN OUT   vertex_etx_txn_details.line_char17%TYPE,
      x_err_status      OUT      VARCHAR2,
      x_err_msg         OUT      VARCHAR2
   )
   IS

      v_org_id                   NUMBER;
      v_product_class            VARCHAR2(400) := NULL;

   BEGIN

      l_api_name := 'GET_product_CLASS';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status    := 'S';
      x_err_msg       := NULL;
      x_product_class := NULL;
      v_product_class := NULL;

      SELECT
          mcb.segment1 || '.' ||
          mcb.segment2 || '.' ||
          mcb.segment3 || '.' ||
          mcb.segment4
      INTO
          v_product_class
      FROM
          mtl_system_items_b          msib
       ,  mtl_system_items_tl         msit
       ,  mtl_item_categories         mic
       ,  mtl_categories_b            mcb
      WHERE
          msib.inventory_item_id    = v_product_id
      AND msib.inventory_item_id    = mic.inventory_item_id
      AND msib.organization_id      = mic.organization_id
      AND msit.language             = 'US'
      AND msit.inventory_item_id    = msib.inventory_item_id
      AND msit.organization_id      = msib.organization_id
      AND mic.category_id           = mcb.category_id
      AND msib.organization_id      = 103
      AND mic.category_set_id       = 1;

      x_product_class := SUBSTR(v_product_class, 1, 40); -- Must not exceed 40 characters

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           'product class' || x_product_class
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   EXCEPTION
        WHEN OTHERS THEN
             x_product_class := 'UNKNOWN';

   END get_product_class;


-----------------------------------------------------------------------
-- PROCEDURE get_trx_line_type

   PROCEDURE get_trx_line_type (
      v_trx_line_type   IN       vertex_etx_txn_details.trx_level_type%TYPE,
      x_trx_line_type   OUT      vertex_etx_txn_details.trx_level_type%TYPE,
      x_err_status      OUT      VARCHAR2,
      x_err_msg         OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'get_trx_line_type';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status    := 'S';
      x_err_msg       := NULL;
      x_trx_line_type := NULL;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   END get_trx_line_type;


-----------------------------------------------------------------------
-- PROCEDURE get_product_code

   PROCEDURE get_product_code (
      v_product_id     IN       vertex_etx_txn_details.product_id%TYPE,
      x_product_code   OUT      vertex_etx_txn_details.product_code%TYPE,
      x_err_status     OUT      VARCHAR2,
      x_err_msg        OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'get_product_code';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status   := 'S';
      x_err_msg      := NULL;
      x_product_code := NULL;

      SELECT
          msib.segment1
      INTO
          x_product_code
      FROM
          mtl_system_items_b          msib
       ,  mtl_system_items_tl         msit
      WHERE
          msib.inventory_item_id    = v_product_id
      AND msit.inventory_item_id    = msib.inventory_item_id
      AND msit.organization_id      = msib.organization_id
      AND msib.organization_id      = oe_profile.value_specific('SO_ORGANIZATION_ID')
      AND msit.language             = 'US';

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_product_code := NULL;

   END get_product_code;


-----------------------------------------------------------------------
-- PROCEDURE set_audit_flag

   PROCEDURE set_audit_flag (
      x_audit_flag   OUT      vertex_etx_txn_details.line_char8%TYPE,
      x_err_status   OUT      VARCHAR2,
      x_err_msg      OUT      VARCHAR2
   )
   IS
   BEGIN

      l_api_name := 'SET_AUDIT_FLAG';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      x_err_status := 'S';
      x_err_msg    := NULL;
      x_audit_flag := NULL;
      x_audit_flag := 'Y';

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.END',
                           v_pkg_name || ': ' || l_api_name || '(-)'
                           );

   END set_audit_flag;


-----------------------------------------------------------------------
-- FUNCTION p_get_country_code

   FUNCTION p_get_country_code (p_location_id IN NUMBER)
      RETURN VARCHAR2
   IS
      p_country_code   VARCHAR2 (3) := NULL;
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'p_get_country_code_hr' || p_location_id
                           );

      SELECT LTRIM(RTRIM(country))
        INTO p_country_code
        FROM hz_locations
       WHERE location_id = p_location_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'p_get_country_CODE' || p_country_code
                           );
      RETURN p_country_code;

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             RETURN p_country_code;

   END;


-----------------------------------------------------------------------
-- FUNCTION p_get_country_code_hr

   FUNCTION p_get_country_code_hr (p_location_id IN NUMBER)
      RETURN VARCHAR2
   IS
      p_country_code   VARCHAR2 (3) := NULL;
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'p_get_country_code_hr' || p_location_id
                           );

      SELECT LTRIM(RTRIM(country))
        INTO p_country_code
        FROM hr_locations
       WHERE location_id = p_location_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'p_get_country_code_hr' || p_country_code
                           );

      RETURN p_country_code;

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             RETURN p_country_code;

   END;


-----------------------------------------------------------------------
-- PROCEDURE get_hr_address

   PROCEDURE get_hr_address (
      p_loc_id        IN       NUMBER,
      x_country       OUT      hr_locations.country%TYPE,
      x_state         OUT      hr_locations.region_2%TYPE,
      x_county        OUT      hr_locations.region_1%TYPE,
      x_city          OUT      hr_locations.town_or_city%TYPE,
      x_postal_code   OUT      hr_locations.postal_code%TYPE
   )
   IS
   BEGIN

      SELECT country, town_or_city, region_1, region_2, postal_code
        INTO x_country, x_city, x_county, x_state, x_postal_code
        FROM hr_locations
       WHERE location_id = p_loc_id;

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_country     := NULL;
             x_city        := NULL;
             x_county      := NULL;
             x_state       := NULL;
             x_postal_code := NULL;

   END get_hr_address;


-----------------------------------------------------------------------
-- PROCEDURE get_hz_address

   PROCEDURE get_hz_address (
      p_loc_id        IN       NUMBER,
      x_country       IN OUT   hz_locations.country%TYPE,
      x_state         IN OUT   hz_locations.state%TYPE,
      x_county        IN OUT   hz_locations.county%TYPE,
      x_city          IN OUT   hz_locations.city%TYPE,
      x_postal_code   IN OUT   hz_locations.postal_code%TYPE
   )
   IS
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'get_hz_address(+)'
                           );

      SELECT country, state, county, city, postal_code
        INTO x_country, x_state, x_county, x_city, x_postal_code
        FROM hz_locations
       WHERE location_id = p_loc_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'get_hz_address' || x_country
                           );

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'get_hz_address(+)'
                           );

   -- Catch any Errors
   EXCEPTION
        WHEN OTHERS THEN
             x_country     := NULL;
             x_city        := NULL;
             x_county      := NULL;
             x_state       := NULL;
             x_postal_code := NULL;

   END get_hz_address;


-----------------------------------------------------------------------
-- PROCEDURE p_derive_tax_area_ids

   PROCEDURE p_derive_tax_area_ids (
      ship_to_loc_id     IN       NUMBER,
      bill_to_loc_id     IN       NUMBER,
      ship_from_loc_id   IN       NUMBER,
      bill_from_loc_id   IN       NUMBER,
      poa_loc_id         IN       NUMBER,
      poo_loc_id         IN       NUMBER,
      ship_to_taid       OUT      NUMBER,
      bill_to_taid       OUT      NUMBER,
      ship_from_taid     OUT      NUMBER,
      bill_from_taid     OUT      NUMBER,
      poa_taid           OUT      NUMBER,
      poo_taid           OUT      NUMBER,
      x_error_stat       IN OUT   VARCHAR2,
      x_error_msg        IN OUT   VARCHAR2
   )
   AS
      l_api_name   VARCHAR2 (100) := 'p_derive_taid';
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name,
                           'TAIDERROR' || ship_to_loc_id
                           );
      BEGIN
         SELECT sales_tax_geocode
           INTO ship_to_taid
           FROM hz_locations
          WHERE location_id = ship_to_loc_id;

      EXCEPTION
           WHEN OTHERS THEN 
                NULL;

      END;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name,
                           'SHIP TO TAID' || ship_to_taid
                           );

      BEGIN
         SELECT sales_tax_geocode
           INTO bill_to_taid
           FROM hz_locations
          WHERE location_id = bill_to_loc_id;

      EXCEPTION
           WHEN OTHERS THEN 
                NULL;

      END;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name,
                           'BILL TO TAID' || bill_to_taid
                           );

      BEGIN
         SELECT loc_information13
           INTO ship_from_taid
           FROM hr_locations
          WHERE location_id = ship_from_loc_id;

      EXCEPTION
           WHEN OTHERS THEN 
                NULL;

      END;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name,
                           'SHIP FROM TAID' || ship_from_taid
                           );

      BEGIN
         SELECT loc_information13
           INTO bill_from_taid
           FROM hr_locations
          WHERE location_id = bill_from_loc_id;

      EXCEPTION
           WHEN OTHERS THEN 
                NULL;

      END;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name,
                           'bill from TAID' || bill_from_taid
                           );

      BEGIN
         SELECT loc_information13
           INTO poa_taid
           FROM hr_locations
          WHERE location_id = poa_loc_id;

      EXCEPTION
           WHEN OTHERS THEN 
                NULL;

      END;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name,
                           'poa TAID' || poa_taid
                           );

      BEGIN
         SELECT loc_information13
           INTO poo_taid
           FROM hr_locations
          WHERE location_id = poo_loc_id;

      EXCEPTION
           WHEN OTHERS THEN 
                NULL;

      END;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name,
                           'poo loc id' || poo_taid
                           );

   END p_derive_tax_area_ids;


-----------------------------------------------------------------------
-- PROCEDURE set_oic_config_tbl

   PROCEDURE set_oic_config_tbl (
      x_ret_status    OUT      VARCHAR2,
      x_ret_message   OUT      VARCHAR2
   )
   IS
     PRAGMA AUTONOMOUS_TRANSACTION;

      v_user             vertex_tax_regime_user.ver_user_name%TYPE;
      v_pwd              vertex_tax_regime_user.ver_pwd%TYPE;
      v_instance         vertex_service_endpoint.ver_oracle_instance%TYPE;
      v_service_end_pt   vertex_service_endpoint.ver_service_end_pt%TYPE;
      p_user             vertex_oic_configuration.username%TYPE;
      p_pwd              vertex_oic_configuration.PASSWORD%TYPE;
      p_end_pt           vertex_oic_configuration.service_end_point%TYPE;
   BEGIN

      x_ret_status  := 'S';
      x_ret_message := NULL;

      SELECT ver_user_name
           , ver_pwd
        INTO v_user
           , v_pwd
        FROM vertex_tax_regime_user
       WHERE ver_tax_regime_code = LTRIM(RTRIM(zx_tax_partner_pkg.g_tax_regime_code));

      v_instance := vertex_utility_pkg.get_instance;

      SELECT ver_service_end_pt
        INTO v_service_end_pt
        FROM vertex_service_endpoint
       WHERE ver_oracle_instance = LTRIM(RTRIM(v_instance));

      SELECT username
           , PASSWORD
           , service_end_point
        INTO p_user
           , p_pwd
           , p_end_pt
        FROM vertex_oic_configuration;

      IF LTRIM(RTRIM(v_user)) <> LTRIM(RTRIM(p_user)) 
      OR LTRIM(RTRIM(v_pwd))  <> LTRIM(RTRIM(p_pwd)) 
      OR LTRIM(RTRIM(v_service_end_pt)) <> LTRIM(RTRIM(p_end_pt)) THEN
         UPDATE vertex_oic_configuration
            SET service_end_point = v_service_end_pt,
                username          = v_user,
                PASSWORD          = v_pwd;
      END IF;

     COMMIT;

   EXCEPTION
        WHEN OTHERS THEN
             x_ret_status  := 'E';
             x_ret_message := SQLERRM;
        COMMIT;

   END set_oic_config_tbl;


-----------------------------------------------------------------------
-- PROCEDURE get_quantity

   PROCEDURE get_quantity (
      transaction_line_quantity     IN OUT   vertex_etx_txn_details.transaction_line_quantity%TYPE,
      adjusted_doc_transaction_id   IN       vertex_etx_txn_details.adjusted_doc_transaction_id%TYPE,
      adjusted_doc_line_id          IN       vertex_etx_txn_details.adjusted_doc_line_id%TYPE,
      x_error_stat                  IN OUT   VARCHAR2,
      x_error_msg                   IN OUT   VARCHAR2
   )
   IS
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'GET_QUANTITY(+)'
                           );

      x_error_msg  := NULL;
      x_error_stat := 'S';

      SELECT quantity_credited
        INTO transaction_line_quantity
        FROM ra_customer_trx_lines
       WHERE customer_trx_line_id = adjusted_doc_line_id
         AND customer_trx_id      = adjusted_doc_transaction_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'QUANTITY:-' || transaction_line_quantity
                           );

      P_VTX_WRITE_LOG.write_log(
                            v_module_name,
                            'GET_QUANTITY(-)'
                            );
   EXCEPTION
        WHEN OTHERS THEN
             x_error_stat := 'E';
             x_error_msg  := 'ERROR IN get_quantity ' || SQLERRM;

   END get_quantity;


-----------------------------------------------------------------------
-- FUNCTION f_get_orig_currency

   FUNCTION f_get_orig_currency (p_org_id IN NUMBER)
      RETURN VARCHAR2
   AS
      x_orig_currency   VARCHAR2 (5)   := NULL;
      l_api_name        VARCHAR2 (100) := 'f_get_orig_currency';
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           l_api_name || '(+)'
                           );

      SELECT sb.currency_code
        INTO x_orig_currency
        FROM gl_sets_of_books sb, hr_operating_units op
       WHERE sb.set_of_books_id = op.set_of_books_id
         AND op.organization_id = p_org_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'returning ' || x_orig_currency
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           l_api_name || '()'
                           );
      RETURN x_orig_currency;

   EXCEPTION
        WHEN OTHERS THEN
             P_VTX_WRITE_LOG.write_log(
                              v_module_name,
                              'Exception' || SQLERRM
                              );

   END;


-----------------------------------------------------------------------
-- FUNCTION f_get_source_type

   FUNCTION f_get_source_type (
      p_transaction_id        IN       NUMBER,
      p_transaction_line_id   IN       NUMBER
   )
      RETURN VARCHAR2
   IS
      v_source_type   VARCHAR2 (10)  := 'INTERNAL';
      l_api_name      VARCHAR2 (100) := 'f_get_dispatcher';
   BEGIN

      v_source_type := 'INTERNAL';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           l_api_name || '(+)'
                           );

      SELECT NVL('INTERNAL', UPPER(source_type_code))
        INTO v_source_type
        FROM oe_order_lines
       WHERE header_id = p_transaction_id 
         AND line_id   = p_transaction_line_id;


      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           l_api_name || '(-)'
                           );
      RETURN v_source_type;

   EXCEPTION
        WHEN OTHERS THEN
             RETURN v_source_type;

   P_VTX_WRITE_LOG.write_log(
                             v_module_name,
                             l_api_name || 'EXCEPTION' || SQLERRM
                             );

   END f_get_source_type;


-----------------------------------------------------------------------
-- FUNCTION p_get_vendor

   FUNCTION p_get_vendor (
      p_transaction_id        IN       NUMBER,
      p_transaction_line_id   IN       NUMBER
   )
      RETURN VARCHAR2
   IS
      l_api_name        VARCHAR2 (100) := 'p_get_extn_attr';
      v_vendor_number   VARCHAR2 (25)  := NULL;
   BEGIN

      SELECT ven.segment1
        INTO v_vendor_number
        FROM po_vendors ven,
             po_headers poh,
             oe_drop_ship_sources drp
       WHERE poh.vendor_id    = ven.vendor_id
         AND drp.po_header_id = poh.po_header_id
         AND drp.line_id      = p_transaction_line_id
         AND drp.header_id    = p_transaction_id;

      RETURN v_vendor_number;

   EXCEPTION
        WHEN OTHERS THEN
             RETURN v_vendor_number;

   END p_get_vendor;


-----------------------------------------------------------------------
-- FUNCTION f_get_registration_hr

   FUNCTION f_get_registration_hr (p_location_id IN NUMBER)
      RETURN VARCHAR2
   IS
      p_registration   VARCHAR2 (25) := 'NO_REG';
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'location' || p_location_id
                           );

      SELECT NVL(loc_information14, 'NO_REG')
        INTO p_registration
        FROM hr_locations
       WHERE location_id = p_location_id 
         AND ROWNUM = 1;

      RETURN p_registration;

   EXCEPTION
        WHEN OTHERS THEN
             RETURN p_registration;

   END;


-----------------------------------------------------------------------
-- FUNCTION f_get_registration

   FUNCTION f_get_registration (p_location_id IN NUMBER)
      RETURN VARCHAR2
   IS
      p_registration   VARCHAR2 (25) := 'NO_REG';
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'location' || p_location_id
                           );

      SELECT NVL(attribute1, 'NO_REG')
        INTO p_registration
        FROM hz_party_sites
       WHERE location_id = p_location_id 
         AND ROWNUM = 1;


      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'registration' || p_registration
                           );

      RETURN p_registration;

   EXCEPTION
        WHEN OTHERS THEN
             RETURN p_registration;

   END;


-----------------------------------------------------------------------
-- PROCEDURE p_del_extn

   PROCEDURE p_del_extn (
      v_extn_rec   IN OUT   vertex_etax_types_pkg.vertex_processing_record
   )
   IS
   BEGIN

      DELETE FROM vertex_txn_headers_extn
            WHERE transaction_id   = v_extn_rec.transaction_id
              AND document_type_id = v_extn_rec.document_type_id
              AND org_id           = v_extn_rec.internal_organization_id;

      DELETE FROM vertex_txn_details_extn
            WHERE transaction_id   = v_extn_rec.transaction_id
              AND document_type_id = v_extn_rec.document_type_id
              AND org_id           = v_extn_rec.internal_organization_id;

   EXCEPTION
        WHEN NO_DATA_FOUND THEN
             NULL;
        WHEN OTHERS THEN
             NULL;

   END;


-----------------------------------------------------------------------
-- FUNCTION f_get_del_term

   FUNCTION f_get_del_term (p_transaction_id IN NUMBER)
      RETURN VARCHAR2
   IS
      v_del_term   VARCHAR2 (3) := NULL;
   BEGIN

      SELECT ord.fob_point_code
        INTO v_del_term
        FROM oe_order_headers ord
           , ra_customer_trx  trx
       WHERE ord.header_id                = trx.interface_header_attribute1
         AND trx.interface_header_context LIKE 'ORDER%ENTRY%'
         AND customer_trx_id              = p_transaction_id;

      RETURN v_del_term;

   EXCEPTION
        WHEN OTHERS THEN
             RETURN v_del_term;

   END f_get_del_term;


-----------------------------------------------------------------------
-- PROCEDURE get_currency

   PROCEDURE get_currency ( 
      p_iso_country_code IN      VARCHAR2,
      p_currency_code    OUT     VARCHAR2 
   )
   IS

l_api_name VARCHAR2(30) := 'GET_CURRENCY'; 

CURSOR get_tax_currency_c( p_tax IN VARCHAR2) IS 
SELECT
    tax.tax_currency_code 
FROM
    apps.zx_sco_taxes_b_v tax 
WHERE
    tax.tax_regime_code = zx_tax_partner_pkg.G_TAX_REGIME_CODE
AND tax.tax = p_tax;

lc_tax_name VARCHAR2(100); 

BEGIN

   p_vtx_write_log.write_log( v_module_name || '.' || l_api_name ,'Begin(+)' ); 
   p_vtx_write_log.write_log( v_module_name || '.' || l_api_name ,'p_iso_country_code ' || p_iso_country_code ); 
   p_vtx_write_log.write_log( v_module_name || '.' || l_api_name ,'zx_tax_partner_pkg.G_TAX_REGIME_CODE ' || zx_tax_partner_pkg.G_TAX_REGIME_CODE ); 

   p_currency_code := NULL; 

   IF ( TRIM( UPPER( p_iso_country_code ) ) = 'US' ) THEN 
      lc_tax_name := 'STATE'; 
   ELSE 
      lc_tax_name := 'COUNTRY' || TRIM( UPPER( p_iso_country_code ) ) || 'OUTPUT'; 
   END IF; 

   p_vtx_write_log.write_log( v_module_name || '.' || l_api_name ,'lc_tax_name ' || lc_tax_name ); 

   OPEN get_tax_currency_c( lc_tax_name ); 
   FETCH get_tax_currency_c INTO p_currency_code; 
   CLOSE get_tax_currency_c; 

   p_vtx_write_log.write_log( v_module_name || '.' || l_api_name ,'tax p_currency_code ' || p_currency_code ); 
   p_vtx_write_log.write_log( v_module_name || '.' || l_api_name ,'End(-)' ); 

   EXCEPTION
        WHEN OTHERS THEN
             p_currency_code := NULL;
             p_vtx_write_log.write_log( v_module_name || '.' || l_api_name ,'exception ' || SQLERRM ); 

END get_currency;


-----------------------------------------------------------------------
-- PROCEDURE gl_conversion_rates

   PROCEDURE gl_conversion_rates (
      p_from_currency   IN       VARCHAR2,
      p_to_currency     IN       VARCHAR2,
      p_conv_date       IN       DATE,
      x_conversion_rt   IN OUT   NUMBER
   )
   IS
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'gl_conversion_rates(+)'
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'from_curr' || p_from_currency
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'to_currency' || p_to_currency
                           );

      x_conversion_rt := 1;

      SELECT NVL(conversion_rate, 1)
        INTO x_conversion_rt
        FROM gl_daily_rates
       WHERE from_currency          = p_from_currency
         AND p_to_currency          = to_currency
         AND conversion_type        = 'Corporate'
         AND TRUNC(conversion_date) = TRUNC(p_conv_date);

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'conversion' || x_conversion_rt
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'gl_conversion_rates(-)'
                           );

   EXCEPTION
        WHEN OTHERS THEN
             P_VTX_WRITE_LOG.write_log(
                              v_module_name,
                              'gl_conversion_rates exception' || SQLERRM
                              );

   END gl_conversion_rates;


-----------------------------------------------------------------------
-- PROCEDURE p_get_exchange_date_ar

   PROCEDURE p_get_exchange_date_ar (
      v_tran_id           IN       NUMBER,
      v_organization_id   IN       NUMBER,
      x_exchange_date     OUT      DATE
   )
   AS
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'p_get_exchange_date_ar' || '(+)'
                           );

      SELECT NVL(trx.exchange_date, trx.trx_date)
        INTO x_exchange_date
        FROM ra_customer_trx_all trx
       WHERE trx.customer_trx_id = v_tran_id
         AND trx.org_id          = v_organization_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'exchange date' || x_exchange_date
                           );

   EXCEPTION
        WHEN OTHERS THEN
             P_VTX_WRITE_LOG.write_log(
                              v_module_name,
                              'p_get_exchange_date_ar' || SQLERRM
                              );

   END p_get_exchange_date_ar;


-----------------------------------------------------------------------
-- PROCEDURE p_get_exchange_date_ont

   PROCEDURE p_get_exchange_date_ont (
      v_tran_id           IN       NUMBER,
      v_organization_id   IN       NUMBER,
      x_exchange_date     OUT      DATE
   )
   AS
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'p_get_exchange_date_ont' || '(+)'
                           );

      SELECT NVL(trx.conversion_rate_date, trx.ordered_date)
        INTO x_exchange_date
        FROM oe_order_headers_all trx
       WHERE trx.header_id = v_tran_id 
         AND trx.org_id    = v_organization_id;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'exchange date' || x_exchange_date
                           );

   EXCEPTION
        WHEN OTHERS THEN
             P_VTX_WRITE_LOG.write_log(
                             v_module_name,
                             'p_get_exchange_date_ont' || SQLERRM
                             );

   END p_get_exchange_date_ont;


-----------------------------------------------------------------------
-- PROCEDURE p_get_extn_attr

   PROCEDURE p_get_extn_attr (
      v_extn_rec      IN OUT   vertex_etax_types_pkg.vertex_processing_record,
      r_header_attr   IN OUT   vertex_etax_types_pkg.tax_header_extn_rec,
      r_line_attr     IN OUT   vertex_etax_types_pkg.tax_line_extn_rec,
      loop_ind        IN       NUMBER
   )
   IS

      l_api_name               VARCHAR2(100) := 'P_GET_EXTN_ATTR';
      p_currency               VARCHAR2(5);
      p_exchange_date          DATE;

   BEGIN

      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'Begin(+)');
      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'v_extn_rec.application_code: ' || v_extn_rec.application_code);

      IF ( loop_ind = 1 ) THEN
         p_del_extn( v_extn_rec );
      END IF; -- IF ( loop_ind = 1 ) THEN

      IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'AR' ) THEN
         p_get_exchange_date_ar (v_extn_rec.transaction_id,v_extn_rec.internal_organization_id,p_exchange_date);
      END IF; -- IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'AR' ) THEN

      IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'ONT' ) THEN
         p_get_exchange_date_ont (v_extn_rec.transaction_id
                                 ,v_extn_rec.internal_organization_id
                                 ,p_exchange_date
                                  );
      END IF; -- IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'ONT' ) THEN

   r_header_attr := NULL;
   r_line_attr := NULL;
   r_header_attr.document_type_id := v_extn_rec.document_type_id;
   r_header_attr.transaction_id := v_extn_rec.transaction_id;
   r_header_attr.org_id := v_extn_rec.internal_organization_id;
   r_header_attr.delivery_terms := UPPER( SUBSTR( v_extn_rec.fob_point, 1, 3 ) );

   IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'AR' ) THEN
      r_header_attr.delivery_terms := UPPER( SUBSTR( f_get_del_term ( v_extn_rec.transaction_id ), 1, 3 ) );
   END IF; -- IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'AR' ) THEN

   --MTH temp solution to solve problem with delivery terms   
   --r_header_attr.delivery_terms := 'FOB';

   -- HAEMO CODE - START
   IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'AR' ) THEN
      get_fob_value  (v_extn_rec.transaction_id, r_header_attr.delivery_terms);
   END IF;

   IF ( LTRIM( RTRIM( UPPER( v_extn_rec.application_code ) ) ) = 'ONT' ) THEN
      get_fob_value_om  (v_extn_rec.transaction_id, r_header_attr.delivery_terms);
   END IF;

   --GC_RECORD_NUMBER          := v_extn_rec.transaction_id;
   --GC_RECORD_IDENTIFIER      := v_extn_rec.internal_organization_id;
   --GC_ERROR_CODE             := 'VERTEX';
   --GC_ERROR_MSG              := 'GET_FOB_VALUE';
   --GC_COMMENTS               := '0010';
   --GC_ATTRIBUTE1             := r_header_attr.delivery_terms;
   --GC_ATTRIBUTE2             := v_extn_rec.application_code;
   --GC_ATTRIBUTE3             := NULL;
   --GC_ATTRIBUTE4             := NULL;
   --GC_ATTRIBUTE5             := NULL;
   --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);
   -- HAEMO CODE - END

   r_header_attr.iso_currency_code_alpha := v_extn_rec.trx_currency_code;
   r_header_attr.original_currency_code_alpha := f_get_orig_currency ( v_extn_rec.internal_organization_id );
   r_header_attr.dispatcher_main_code := NULL;

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'shipfromlocid ' || v_extn_rec.ship_from_loc_id);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'billfromlocid ' || v_extn_rec.bill_from_loc_id);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'Get phys orig reg id');

   r_header_attr.cus_phys_orig_reg_id := f_get_registration_hr( NVL( v_extn_rec.ship_from_loc_id, v_extn_rec.bill_from_loc_id ) );

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_phys_orig_reg_id: ' || r_header_attr.cus_phys_orig_reg_id);

   IF ( r_header_attr.cus_phys_orig_reg_id = 'NO_REG' ) THEN
      r_header_attr.cus_phys_orig_reg_id := NULL;
   ELSE -- IF ( r_header_attr.cus_phys_orig_reg_id = 'NO_REG' ) THEN
      r_header_attr.cus_phys_orig_iso_ctry_code := p_get_country_code_hr( NVL( v_extn_rec.ship_from_loc_id, v_extn_rec.bill_from_loc_id ) );
   END IF; -- IF ( r_header_attr.cus_phys_orig_reg_id = 'NO_REG' ) THEN

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_phys_orig_iso_ctry_code: ' || r_header_attr.cus_phys_orig_iso_ctry_code);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'Get adm orig reg id');

   r_header_attr.cus_adm_orig_reg_id := f_get_registration_hr( v_extn_rec.poa_loc_id );

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_adm_orig_reg_id: ' || r_header_attr.cus_adm_orig_reg_id);

   IF ( r_header_attr.cus_adm_orig_reg_id = 'NO_REG' ) THEN
      r_header_attr.cus_adm_orig_reg_id := NULL;
   ELSE -- IF ( r_header_attr.cus_adm_orig_reg_id = 'NO_REG' ) THEN
      r_header_attr.cus_adm_orig_iso_ctry_code := p_get_country_code_hr ( v_extn_rec.poa_loc_id );
   END IF; -- IF ( r_header_attr.cus_adm_orig_reg_id = 'NO_REG' ) THEN

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_adm_orig_iso_ctry_code: ' || r_header_attr.cus_adm_orig_iso_ctry_code);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'Get dest reg id');

   r_header_attr.cus_dest_reg_id := NVL( f_get_registration( NVL( v_extn_rec.ship_to_loc_id, v_extn_rec.bill_to_loc_id ) ), 0 );
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_dest_reg_id: ' || r_header_attr.cus_dest_reg_id);

   IF ( r_header_attr.cus_dest_reg_id = 'NO_REG' ) THEN
      r_header_attr.cus_dest_reg_id := NULL;
   END IF; -- IF ( r_header_attr.cus_dest_reg_id = 'NO_REG' ) THEN

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_dest_reg_id: ' || r_header_attr.cus_dest_reg_id);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'v_extn_rec.ship_to_loc_id: ' || v_extn_rec.ship_to_loc_id);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'v_extn_rec.bill_to_loc_id: ' || v_extn_rec.bill_to_loc_id);

   r_header_attr.cus_dest_iso_ctry_code := p_get_country_code( NVL( v_extn_rec.ship_to_loc_id, v_extn_rec.bill_to_loc_id ) );

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_dest_iso_ctry_code: ' || r_header_attr.cus_dest_iso_ctry_code);

   r_header_attr.dis_phys_orig_reg_id        := NULL;
   r_header_attr.dis_phys_orig_iso_ctry_code := NULL;
   r_header_attr.dis_adm_orig_reg_id         := NULL;
   r_header_attr.dis_adm_orig_iso_ctry_code  := NULL;
   r_header_attr.customs_status_phys_orig    := NULL;
   r_header_attr.customs_status_adm_orig     := NULL;
   r_header_attr.customs_status_dest         := NULL;
   r_header_attr.dispatcher_main_code        := NULL;
   p_currency                                := NULL;

   IF ( NVL( r_header_attr.dis_phys_orig_iso_ctry_code, r_header_attr.cus_phys_orig_iso_ctry_code ) IS NOT NULL ) THEN
      get_currency (NVL( r_header_attr.dis_phys_orig_iso_ctry_code, r_header_attr.cus_phys_orig_iso_ctry_code ), p_currency);
      r_line_attr.curr_iso_code_phys_orig := p_currency;
      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_iso_code_phys_orig: ' || r_line_attr.curr_iso_code_phys_orig);

      IF ( r_line_attr.curr_iso_code_phys_orig IS NOT NULL ) THEN
         gl_conversion_rates (
         r_header_attr.iso_currency_code_alpha
        ,r_line_attr.curr_iso_code_phys_orig
        ,p_exchange_date
        ,r_line_attr.curr_conv_rate_phys_orig
        );
      END IF; -- IF ( r_line_attr.curr_iso_code_phys_orig IS NOT NULL ) THEN

      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_conv_rate_phys_orig: ' || r_line_attr.curr_conv_rate_phys_orig);

      IF ( r_line_attr.curr_iso_code_phys_orig IS NULL OR r_line_attr.curr_conv_rate_phys_orig IS NULL ) THEN
         r_line_attr.curr_iso_code_phys_orig  := NULL;
         r_line_attr.curr_conv_rate_phys_orig := NULL;
      END IF; -- IF ( r_line_attr.curr_iso_code_phys_orig IS NULL OR r_line_attr.curr_conv_rate_phys_orig IS NULL ) THEN

      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_iso_code_phys_orig: ' || r_line_attr.curr_iso_code_phys_orig);
      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_conv_rate_phys_orig: ' || r_line_attr.curr_conv_rate_phys_orig);

   END IF; -- IF ( NVL( r_header_attr.dis_phys_orig_iso_ctry_code, r_header_attr.cus_phys_orig_iso_ctry_code ) IS NOT NULL ) THEN

   p_currency := NULL;

   IF ( NVL( r_header_attr.dis_adm_orig_iso_ctry_code, r_header_attr.cus_adm_orig_iso_ctry_code ) IS NOT NULL ) THEN
      get_currency (NVL( r_header_attr.dis_adm_orig_iso_ctry_code, r_header_attr.cus_adm_orig_iso_ctry_code ), p_currency);
      r_line_attr.curr_iso_code_adm_orig := p_currency;
      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_iso_code_adm_orig: ' || r_line_attr.curr_iso_code_adm_orig);

      IF ( r_line_attr.curr_iso_code_adm_orig IS NOT NULL ) THEN
         gl_conversion_rates (
         r_header_attr.iso_currency_code_alpha
        ,r_line_attr.curr_iso_code_adm_orig
        ,p_exchange_date
        ,r_line_attr.curr_conv_rate_adm_orig
        );
      END IF; -- IF ( r_line_attr.curr_iso_code_adm_orig IS NOT NULL ) THEN

      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_conv_rate_adm_orig: ' || r_line_attr.curr_conv_rate_adm_orig);

      IF ( r_line_attr.curr_iso_code_adm_orig IS NULL OR r_line_attr.curr_conv_rate_adm_orig IS NULL ) THEN
         r_line_attr.curr_iso_code_adm_orig  := NULL;
         r_line_attr.curr_conv_rate_adm_orig := NULL;
      END IF; -- IF ( r_line_attr.curr_iso_code_adm_orig IS NULL OR r_line_attr.curr_conv_rate_adm_orig IS NULL ) THEN

      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_iso_code_adm_orig: ' || r_line_attr.curr_iso_code_adm_orig);
      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_conv_rate_adm_orig: ' || r_line_attr.curr_conv_rate_adm_orig);

   END IF; -- IF ( NVL( r_header_attr.dis_adm_orig_iso_ctry_code, r_header_attr.cus_adm_orig_iso_ctry_code ) IS NOT NULL ) THEN

   p_currency := NULL;

   IF ( r_header_attr.cus_dest_iso_ctry_code IS NOT NULL ) THEN
      get_currency (r_header_attr.cus_dest_iso_ctry_code, p_currency);

      r_line_attr.curr_iso_code_dest := LTRIM( RTRIM ( p_currency ) );
      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_iso_code_dest: ' || r_line_attr.curr_iso_code_dest);

      IF ( r_line_attr.curr_iso_code_dest IS NOT NULL ) THEN
         gl_conversion_rates (
         r_header_attr.iso_currency_code_alpha
        ,r_line_attr.curr_iso_code_dest
        ,p_exchange_date
        ,r_line_attr.curr_conv_rate_dest
        );
      END IF; -- IF ( r_line_attr.curr_iso_code_dest IS NOT NULL ) THEN

      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_conv_rate_dest: ' || r_line_attr.curr_conv_rate_dest);

      IF ( r_line_attr.curr_iso_code_dest IS NULL OR r_line_attr.curr_conv_rate_dest IS NULL ) THEN
         r_line_attr.curr_iso_code_dest  := NULL;
         r_line_attr.curr_conv_rate_dest := NULL;
      END IF; -- IF ( r_line_attr.curr_iso_code_dest IS NULL OR r_line_attr.curr_conv_rate_dest IS NULL ) THEN

      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_iso_code_dest: ' || r_line_attr.curr_iso_code_dest);
      p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.curr_conv_rate_dest: ' || r_line_attr.curr_conv_rate_dest);

   END IF; -- IF ( r_header_attr.cus_dest_iso_ctry_code IS NOT NULL ) THEN

   IF ( r_header_attr.cus_dest_reg_id IS NULL ) THEN
      r_header_attr.cus_dest_iso_ctry_code := NULL;
   END IF; -- IF ( r_header_attr.cus_dest_reg_id IS NULL ) THEN

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_header_attr.cus_dest_iso_ctry_code: ' || r_header_attr.cus_dest_iso_ctry_code);

   r_line_attr.document_type_id             := v_extn_rec.document_type_id;
   r_line_attr.transaction_id               := v_extn_rec.transaction_id;
   r_line_attr.transaction_line_id          := v_extn_rec.transaction_line_id;
   r_line_attr.org_id                       := v_extn_rec.internal_organization_id;
   r_line_attr.delivery_terms               := r_header_attr.delivery_terms;
   r_line_attr.iso_currency_code_alpha      := v_extn_rec.trx_currency_code;
   r_line_attr.original_currency_code_alpha := r_header_attr.original_currency_code_alpha;
   r_line_attr.dispatcher_main_code         := NULL;
   r_line_attr.cus_phys_orig_reg_id         := r_header_attr.cus_phys_orig_reg_id;
   r_line_attr.cus_phys_orig_iso_ctry_code  := r_header_attr.cus_phys_orig_iso_ctry_code;

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.cus_phys_orig_reg_id: ' || r_line_attr.cus_phys_orig_reg_id);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'r_line_attr.cus_phys_orig_iso_ctry_code: ' || r_line_attr.cus_phys_orig_iso_ctry_code);
   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'step3');

   r_line_attr.cus_adm_orig_reg_id          := r_header_attr.cus_adm_orig_reg_id;
   r_line_attr.cus_adm_orig_iso_ctry_code   := r_header_attr.cus_adm_orig_iso_ctry_code;
   r_line_attr.cus_dest_reg_id              := r_header_attr.cus_dest_reg_id;
   r_line_attr.cus_dest_iso_ctry_code       := r_header_attr.cus_dest_iso_ctry_code;
   r_line_attr.dis_phys_orig_reg_id         := NULL;
   r_line_attr.dis_phys_orig_iso_ctry_code  := NULL;
   r_line_attr.dis_adm_orig_reg_id          := NULL;
   r_line_attr.dis_adm_orig_iso_ctry_code   := NULL;
   r_line_attr.customs_status_phys_orig     := NULL;
   r_line_attr.customs_status_adm_orig      := NULL;
   r_line_attr.customs_status_dest          := NULL;

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'Before insert ');

   IF ( loop_ind = 1 ) THEN
      INSERT INTO vertex_txn_headers_extn_o2c_v
      VALUES r_header_attr;
   END IF; -- IF ( loop_ind = 1 ) THEN

   INSERT INTO vertex_txn_details_extn_o2c_v
   VALUES r_line_attr;

   p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'End(-)');

   EXCEPTION
        WHEN OTHERS THEN
             p_vtx_write_log.write_log (v_module_name || '.' || l_api_name,'Exception: ' || SUBSTR( SQLERRM, 1, 200 ));

END p_get_extn_attr;


-----------------------------------------------------------------------
-- FUNCTION f_not_present

   FUNCTION f_not_present (
      p_transaction_id   IN       NUMBER,
      p_org_id           IN       NUMBER,
      p_doc_type_id      IN       NUMBER
   )
      RETURN VARCHAR2
   AS
      v_exist_flag   VARCHAR2 (1) := 'Y';
   BEGIN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'v_exist_flag(+)'
                           );

      SELECT'N'
        INTO v_exist_flag
        FROM vertex_etx_txn_header
       WHERE transaction_id           = p_transaction_id
         AND internal_organization_id = p_org_id
         AND document_type_id         = p_doc_type_id;

      P_VTX_WRITE_LOG.write_log(
                             v_module_name,
                             'v_exist_flag(-)'
                             );
      RETURN v_exist_flag;

   EXCEPTION
        WHEN OTHERS THEN
             P_VTX_WRITE_LOG.write_log(
                             v_module_name,
                             'v_exist_flag exception' || SQLERRM
                             );

   RETURN v_exist_flag;

   END f_not_present;


-----------------------------------------------------------------------
-- PROCEDURE main_rounter

   PROCEDURE main_rounter (
      p_oracle_rec        IN OUT   v_process_rec_tbl,
      p_tax_header_extn   IN OUT   vertex_etax_types_pkg.tax_header_extn_tbl_type,
      p_tax_line_extn     IN OUT   vertex_etax_types_pkg.tax_line_extn_tbl_type,
      x_error_stat        IN OUT   VARCHAR2,
      x_error_msg         IN OUT   VARCHAR2
   )
   IS
      v_instance_name        VARCHAR2 (25);
      v_ship_to_taid         NUMBER                                             := NULL;
      v_bill_to_taid         NUMBER                                             := NULL;
      v_ship_from_taid       NUMBER                                             := NULL;
      v_bill_from_taid       NUMBER                                             := NULL;
      v_poo_taid             NUMBER                                             := NULL;
      v_poa_taid             NUMBER                                             := NULL;
      l_api_name             VARCHAR2 (100)                                     := 'main_rounter';
      mod_product_code       vertex_etx_txn_details.product_code%TYPE;
      mod_company_code       vertex_etx_txn_header.legal_entity_number%TYPE;
      mod_division_code      vertex_etx_txn_details.line_char15%TYPE;
      mod_audit_flag         VARCHAR2 (1);
      mod_customer_code      vertex_etx_txn_details.ship_to_party_number%TYPE;
      mod_customer_class     vertex_etx_txn_details.line_char13%TYPE;
      mod_trx_date           VARCHAR2 (10);
      mod_exempt_number      vertex_etx_txn_details.exempt_certificate_number%TYPE;
      mod_trx_level_type     vertex_etx_txn_details.trx_level_type%TYPE;
      v_tax_only             NUMBER ;
      v_allow_tax_calc       varchar2(1) ;
      p_transaction_number   vertex_etx_txn_header.transaction_number%TYPE      := NULL;
   BEGIN

      x_error_stat    := 'S';
      x_error_msg     := NULL;
      v_instance_name := vertex_utility_pkg.get_instance;

      P_VTX_WRITE_LOG.write_log(
                           v_module_name,
                           'INSIDE MAIN ROUNTER instance name ' || v_instance_name
                           );

      IF p_oracle_rec.COUNT > 0 THEN
         IF UPPER(LTRIM(RTRIM(p_oracle_rec (1).application_code))) = 'AR' THEN
            BEGIN
               SELECT trx_number
                 INTO p_transaction_number
                 FROM ra_customer_trx
                WHERE customer_trx_id = p_oracle_rec (1).transaction_id;
            EXCEPTION
                 WHEN OTHERS THEN
                      P_VTX_WRITE_LOG.write_log(
                                       v_module_name,
                                       'exception in tran number' || SQLERRM
                                       );
            END;
         END IF;

         FOR i IN p_oracle_rec.FIRST .. p_oracle_rec.LAST
         LOOP
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'calling the p_get_extn_attr'
                                 );

            IF vertex_etax_types_pkg.v_vtx_tax_type = 'VAT' THEN 
               p_get_extn_attr (p_oracle_rec (i), p_tax_header_extn, p_tax_line_extn, i);
            END IF;

            p_oracle_rec (i).line_char1  := NULL;
            p_oracle_rec (i).line_char2  := NULL;
            p_oracle_rec (i).line_char3  := NULL;
            p_oracle_rec (i).line_char4  := NULL;
            p_oracle_rec (i).line_char5  := NULL;
            p_oracle_rec (i).line_char6  := NULL;
            p_oracle_rec (i).line_char7  := NULL;
            p_oracle_rec (i).line_char8  := NULL;
            p_oracle_rec (i).line_char9  := NULL;
            p_oracle_rec (i).line_char10 := NULL;
            p_oracle_rec (i).line_char11 := NULL;
            p_oracle_rec (i).line_char12 := NULL;
            p_oracle_rec (i).line_char13 := NULL;
            p_oracle_rec (i).line_char14 := NULL;
            p_oracle_rec (i).line_char15 := NULL;
            p_oracle_rec (i).line_char16 := NULL;
            p_oracle_rec (i).line_char17 := NULL;
            p_oracle_rec (i).line_char18 := NULL;
            p_oracle_rec (i).line_char19 := NULL;
            p_oracle_rec (i).line_char20 := NULL;
            p_oracle_rec (i).line_char21 := NULL;
            p_oracle_rec (i).line_char22 := NULL;
            p_oracle_rec (i).line_char23 := NULL;
            p_oracle_rec (i).line_char24 := NULL;
            p_oracle_rec (i).line_char25 := NULL;
            p_oracle_rec (i).line_char26 := NULL;
            p_oracle_rec (i).line_char27 := NULL;
            p_oracle_rec (i).line_char28 := NULL;
            p_oracle_rec (i).line_char29 := NULL;
            p_oracle_rec (i).line_char30 := NULL;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'exempt reason code' || p_oracle_rec (i).exempt_reason
                                 );

            IF p_oracle_rec (i).exempt_reason IS NOT NULL THEN
               p_oracle_rec (i).exempt_reason := SUBSTR(p_oracle_rec (i).exempt_reason, 1, 4);
            END IF;

            IF UPPER(LTRIM(RTRIM(p_oracle_rec (i).application_code))) = 'AR' THEN
               p_oracle_rec (i).transaction_number := p_transaction_number;
            END IF;

            IF p_oracle_rec (i).ship_to_geography_value6 IS NOT NULL THEN
               p_oracle_rec (i).ship_to_geography_value6 := SUBSTR(p_oracle_rec (i).ship_to_geography_value6, 1, 100);
            END IF;

            IF p_oracle_rec (i).bill_to_geography_value6 IS NOT NULL THEN
               p_oracle_rec (i).bill_to_geography_value6 := SUBSTR(p_oracle_rec (i).bill_to_geography_value6, 1, 100);
            END IF;

            IF p_oracle_rec (i).poo_geography_value6 IS NOT NULL THEN
               p_oracle_rec (i).poo_geography_value6 := SUBSTR(p_oracle_rec (i).poo_geography_value6, 1, 100);
            END IF;

            IF p_oracle_rec (i).poa_geography_value6 IS NOT NULL THEN
               p_oracle_rec (i).poa_geography_value6 := SUBSTR(p_oracle_rec (i).poa_geography_value6, 1, 100);
            END IF;

            IF p_oracle_rec (i).bill_to_geography_value7 IS NOT NULL THEN
               p_oracle_rec (i).bill_to_geography_value7 := SUBSTR(p_oracle_rec (i).bill_to_geography_value7, 1, 100);
            END IF;

            IF p_oracle_rec (i).bill_to_geography_value8 IS NOT NULL THEN
               p_oracle_rec (i).bill_to_geography_value8 := SUBSTR(p_oracle_rec (i).bill_to_geography_value8, 1, 100);
            END IF;

            IF p_oracle_rec (i).ship_to_geography_value7 IS NOT NULL THEN
               p_oracle_rec (i).ship_to_geography_value7 := SUBSTR(p_oracle_rec (i).ship_to_geography_value7, 1, 100);
            END IF;

            IF p_oracle_rec (i).ship_to_geography_value8 IS NOT NULL THEN
               p_oracle_rec (i).ship_to_geography_value8 := SUBSTR(p_oracle_rec (i).ship_to_geography_value8, 1, 100);
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'shiptolocid' || p_oracle_rec (i).ship_to_loc_id
                                 );

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'document type id' || p_oracle_rec (i).document_type_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'line lvel action' || p_oracle_rec (i).line_level_action
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'doc level action' || p_oracle_rec (i).document_level_action
                                 );

            IF p_oracle_rec (i).line_level_action = 'RECORD_WITH_NO_TAX' AND p_oracle_rec (i).document_type_id = 6 THEN
               p_oracle_rec (i).document_level_action := 'CREATE';
            END IF;

            IF p_oracle_rec (i).document_type_id = 8 AND p_oracle_rec (i).line_amt_includes_tax_flag <> 'A' THEN
               p_oracle_rec (i).line_level_action := 'RECORD_WITH_NO_TAX';
            END IF;

            IF p_oracle_rec (i).line_amt_includes_tax_flag = 'A' THEN
               p_oracle_rec (i).line_amt_includes_tax_flag := 'T';
            END IF;

            IF p_oracle_rec (i).ship_to_loc_id IS NOT NULL THEN
               get_hz_address (p_oracle_rec (i).ship_to_loc_id,
                               p_oracle_rec (i).ship_to_geography_value1,
                               p_oracle_rec (i).ship_to_geography_value2,
                               p_oracle_rec (i).ship_to_geography_value3,
                               p_oracle_rec (i).ship_to_geography_value4,
                               p_oracle_rec (i).ship_to_geography_value5
                              );
               p_oracle_rec (i).ship_to_geography_type1 := 'COUNTRY';
               p_oracle_rec (i).ship_to_geography_type4 := 'CITY';
               p_oracle_rec (i).ship_to_geography_type2 := 'STATE';
               p_oracle_rec (i).ship_to_geography_type5 := 'POSTAL_CODE';
               p_oracle_rec (i).ship_to_geography_type3 := 'COUNTY';
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'billtolocid' || p_oracle_rec (i).bill_to_loc_id
                                 );

            IF p_oracle_rec (i).bill_to_loc_id IS NOT NULL THEN
               get_hz_address (p_oracle_rec (i).bill_to_loc_id,
                               p_oracle_rec (i).bill_to_geography_value1,
                               p_oracle_rec (i).bill_to_geography_value2,
                               p_oracle_rec (i).bill_to_geography_value3,
                               p_oracle_rec (i).bill_to_geography_value4,
                               p_oracle_rec (i).bill_to_geography_value5
                              );
               p_oracle_rec (i).bill_to_geography_type1 := 'COUNTRY';
               p_oracle_rec (i).bill_to_geography_type4 := 'CITY';
               p_oracle_rec (i).bill_to_geography_type2 := 'STATE';
               p_oracle_rec (i).bill_to_geography_type5 := 'POSTAL_CODE';
               p_oracle_rec (i).bill_to_geography_type3 := 'COUNTY';
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'shipfromlocid' || p_oracle_rec (i).ship_from_loc_id
                                 );

            IF p_oracle_rec (i).ship_from_loc_id IS NOT NULL THEN
               get_hr_address (p_oracle_rec (i).ship_from_loc_id,
                               p_oracle_rec (i).ship_from_geography_value1,
                               p_oracle_rec (i).ship_from_geography_value2,
                               p_oracle_rec (i).ship_from_geography_value3,
                               p_oracle_rec (i).ship_from_geography_value4,
                               p_oracle_rec (i).ship_from_geography_value5
                              );
               p_oracle_rec (i).ship_from_geography_type1 := 'COUNTRY';
               p_oracle_rec (i).ship_from_geography_type4 := 'CITY';
               p_oracle_rec (i).ship_from_geography_type2 := 'STATE';
               p_oracle_rec (i).ship_from_geography_type5 := 'POSTAL_CODE';
               p_oracle_rec (i).ship_from_geography_type3 := 'COUNTY';
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'billfromlocid' || p_oracle_rec (i).bill_from_loc_id
                                 );

            IF p_oracle_rec (i).bill_from_loc_id IS NOT NULL THEN
               get_hr_address (p_oracle_rec (i).bill_from_loc_id,
                               p_oracle_rec (i).bill_from_geography_value1,
                               p_oracle_rec (i).bill_from_geography_value2,
                               p_oracle_rec (i).bill_from_geography_value3,
                               p_oracle_rec (i).bill_from_geography_value4,
                               p_oracle_rec (i).bill_from_geography_value5
                              );
               p_oracle_rec (i).bill_from_geography_type1 := 'COUNTRY';
               p_oracle_rec (i).bill_from_geography_type4 := 'CITY';
               p_oracle_rec (i).bill_from_geography_type2 := 'STATE';
               p_oracle_rec (i).bill_from_geography_type5 := 'POSTAL_CODE';
               p_oracle_rec (i).bill_from_geography_type3 := 'COUNTY';
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'poatolocid' || p_oracle_rec (i).poa_loc_id
                                 );

            IF p_oracle_rec (i).poa_loc_id IS NOT NULL THEN
               get_hr_address (p_oracle_rec (i).poa_loc_id,
                               p_oracle_rec (i).poa_geography_value1,
                               p_oracle_rec (i).poa_geography_value2,
                               p_oracle_rec (i).poa_geography_value3,
                               p_oracle_rec (i).poa_geography_value4,
                               p_oracle_rec (i).poa_geography_value5
                              );
               p_oracle_rec (i).poa_geography_type1 := 'COUNTRY';
               p_oracle_rec (i).poa_geography_type4 := 'CITY';
               p_oracle_rec (i).poa_geography_type2 := 'STATE';
               p_oracle_rec (i).poa_geography_type5 := 'POSTAL_CODE';
               p_oracle_rec (i).poa_geography_type3 := 'COUNTY';
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'pootolocid' || p_oracle_rec (i).poo_loc_id
                                 );

            IF p_oracle_rec (i).poo_loc_id IS NOT NULL THEN
               get_hr_address (p_oracle_rec (i).poo_loc_id,
                               p_oracle_rec (i).poo_geography_value1,
                               p_oracle_rec (i).poo_geography_value2,
                               p_oracle_rec (i).poo_geography_value3,
                               p_oracle_rec (i).poo_geography_value4,
                               p_oracle_rec (i).poo_geography_value5
                              );
               p_oracle_rec (i).poo_geography_type1 := 'COUNTRY';
               p_oracle_rec (i).poo_geography_type4 := 'CITY';
               p_oracle_rec (i).poo_geography_type2 := 'STATE';
               p_oracle_rec (i).poo_geography_type5 := 'POSTAL_CODE';
               p_oracle_rec (i).poo_geography_type3 := 'COUNTY';
            END IF;

            p_oracle_rec (i).header_char1 := p_oracle_rec (i).ship_to_geography_value1;
            p_oracle_rec (i).header_char2 := p_oracle_rec (i).bill_to_geography_value1;
            p_oracle_rec (i).header_char3 := p_oracle_rec (i).ship_from_geography_value1;
            p_oracle_rec (i).header_char4 := p_oracle_rec (i).bill_from_geography_value1;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name,
                                 'INSIDE LOOP'
                                 );

            IF NVL(v_ship_to_taid, v_bill_to_taid) IS NULL THEN
               set_oic_config_tbl (x_error_stat, x_error_msg);
               P_VTX_WRITE_LOG.write_log(
                                    v_module_name || l_api_name,
                                    'CALLING TAID'
                                    );

               IF x_error_stat = 'S' THEN
                  p_derive_tax_area_ids (p_oracle_rec (i).ship_to_loc_id,
                                         p_oracle_rec (i).bill_to_loc_id,
                                         p_oracle_rec (i).ship_from_loc_id,
                                         p_oracle_rec (i).bill_from_loc_id,
                                         p_oracle_rec (i).poa_loc_id,
                                         p_oracle_rec (i).poo_loc_id,
                                         v_ship_to_taid,
                                         v_bill_to_taid,
                                         v_ship_from_taid,
                                         v_bill_from_taid,
                                         v_poa_taid,
                                         v_poo_taid,
                                         x_error_stat,
                                         x_error_msg
                                        );
               END IF;
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'BEFORE ASSIGNING TAID'
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'SHIP_TO_LOC_ID' || p_oracle_rec (i).ship_to_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'ship_from_loc_id' || p_oracle_rec (i).ship_from_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'bill_TO_LOC_ID' || p_oracle_rec (i).bill_to_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'bill_from_loc_id' || p_oracle_rec (i).bill_from_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'poa_loc_id' || p_oracle_rec (i).poa_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'poo_loc_id' || p_oracle_rec (i).poo_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'document_level_action' || p_oracle_rec (i).document_level_action
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'line_level_action' || p_oracle_rec (i).line_level_action
                                 );

            p_oracle_rec (i).ship_to_loc_id   := NULL;
            p_oracle_rec (i).ship_from_loc_id := NULL;
            p_oracle_rec (i).poa_loc_id       := NULL;
            p_oracle_rec (i).bill_to_loc_id   := NULL;
            p_oracle_rec (i).bill_from_loc_id := NULL;
            p_oracle_rec (i).poo_loc_id       := NULL;
            p_oracle_rec (i).ship_to_loc_id   := v_ship_to_taid;
            p_oracle_rec (i).ship_from_loc_id := v_ship_from_taid;
            p_oracle_rec (i).poa_loc_id       := v_poa_taid;
            p_oracle_rec (i).poo_loc_id       := v_poo_taid;
            p_oracle_rec (i).bill_to_loc_id   := v_bill_to_taid;
            p_oracle_rec (i).bill_from_loc_id := v_bill_from_taid;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'SHIP_TO_LOC_ID' || p_oracle_rec (i).ship_to_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'ship_from_loc_id' || p_oracle_rec (i).ship_from_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'bill_TO_LOC_ID' || p_oracle_rec (i).bill_to_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'bill_from_loc_id' || p_oracle_rec (i).bill_from_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'poa_loc_id' || p_oracle_rec (i).poa_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'poo_loc_id' || p_oracle_rec (i).poo_loc_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'AFTER ASSIGNING TAID'
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'document type id' || p_oracle_rec (i).document_type_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'transaction_id ' || p_oracle_rec (i).transaction_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'transaction_line_id' || p_oracle_rec (i).transaction_line_id
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'trx_date ' || p_oracle_rec (i).trx_date
                                 );
            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'transaction_line_date  ' || p_oracle_rec (i).transaction_line_date
                                 );

            IF (p_oracle_rec (i).transaction_line_quantity) IS NULL THEN
               get_quantity (p_oracle_rec (i).transaction_line_quantity,
                             p_oracle_rec (i).transaction_id,
                             p_oracle_rec (i).transaction_line_id,
                             x_error_stat,
                             x_error_msg
                            );
            END IF;

            IF (p_oracle_rec (i).transaction_line_quantity = 0) OR p_oracle_rec (i).transaction_line_quantity IS NULL THEN
               P_VTX_WRITE_LOG.write_log(
                                    v_module_name || l_api_name || '.BEGIN',
                                    'LINE AMOUNT' || p_oracle_rec (i).line_amount
                                    );
               p_oracle_rec (i).transaction_line_quantity := 1;
            END IF;

            get_product_class (p_oracle_rec (i).product_id, p_oracle_rec (i).line_char17,  x_error_stat, x_error_msg);

            --------------------------------------------------------------------
            -- HAEMO CUSTOMIZATIONS START

            get_ra_customer_trx  (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, v_RA_Customer_trx_exists, x_error_stat, x_error_msg);
            --GC_RECORD_NUMBER          := p_oracle_rec (i).transaction_id;
            --GC_RECORD_IDENTIFIER      := p_oracle_rec (i).transaction_line_id;
            --GC_ERROR_CODE             := 'VERTEX';
            --GC_ERROR_MSG              := 'GET_RA_CUSTOMER_TRX';
            --GC_COMMENTS               := '0100';
            --GC_ATTRIBUTE1             := v_RA_Customer_trx_exists;
            --GC_ATTRIBUTE2             := x_error_stat;
            --GC_ATTRIBUTE3             := x_error_msg;
            --GC_ATTRIBUTE4             := NULL;
            --GC_ATTRIBUTE5             := NULL;
            --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

            get_Application_Code (p_oracle_rec (i), v_Application_code, x_error_stat, x_error_msg);
            --GC_RECORD_NUMBER          := p_oracle_rec (i).transaction_id;
            --GC_RECORD_IDENTIFIER      := p_oracle_rec (i).transaction_line_id;
            --GC_ERROR_CODE             := 'VERTEX';
            --GC_ERROR_MSG              := 'GET_APPLICATION_CODE';
            --GC_COMMENTS               := '0200';
            --GC_ATTRIBUTE1             := v_Application_code;
            --GC_ATTRIBUTE2             := x_error_stat;
            --GC_ATTRIBUTE3             := x_error_msg;
            --GC_ATTRIBUTE4             := NULL;
            --GC_ATTRIBUTE5             := NULL;
            --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

            get_company_code          (p_oracle_rec (i).Internal_Organization_ID, p_oracle_rec (i).legal_entity_number, x_error_stat, x_error_msg);
            get_product_code          (p_oracle_rec (i).product_id, p_oracle_rec (i).product_code, x_error_stat, x_error_msg);
            get_credit_memo_date      (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_date1, p_oracle_rec (i).line_char7, x_error_stat, x_error_msg);

            get_original_tax          (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char23, x_error_stat, x_error_msg);
            --GC_RECORD_NUMBER          := p_oracle_rec (i).transaction_id;
            --GC_RECORD_IDENTIFIER      := p_oracle_rec (i).transaction_line_id;
            --GC_ERROR_CODE             := 'VERTEX';
            --GC_ERROR_MSG              := 'GET_ORIGINAL_TAX';
            --GC_COMMENTS               := '0210';
            --GC_ATTRIBUTE1             := p_oracle_rec (i).line_char23;
            --GC_ATTRIBUTE2             := x_error_stat;
            --GC_ATTRIBUTE3             := x_error_msg;
            --GC_ATTRIBUTE4             := NULL;
            --GC_ATTRIBUTE5             := NULL;
            --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

            -- Processing where record exists in ra_customer_trx_all
            IF v_RA_Customer_trx_exists = 'Y' THEN

               get_AR_Source             (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char9, x_error_stat, x_error_msg);

               Update_Global_Attr20(p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char17, x_error_stat, x_error_msg);

               get_division_code         (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char15, x_error_stat, x_error_msg);
               --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
               --GC_RECORD_IDENTIFIER       := p_oracle_rec (i).transaction_line_id;
               --GC_ERROR_CODE              := 'VERTEX';
               --GC_ERROR_MSG               := 'GET_DIVISION_CODE';
               --GC_COMMENTS                := '0300';
               --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char15;
               --GC_ATTRIBUTE2              := x_error_stat;
               --GC_ATTRIBUTE3              := x_error_msg;
               --GC_ATTRIBUTE4              := p_oracle_rec (i).line_char9;
               --GC_ATTRIBUTE5              := NULL;
               --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

               get_BT_Customer_Name_Acct (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char1, p_oracle_rec (i).line_char2, x_error_stat, x_error_msg);
               get_ST_Customer_Name_Acct (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char4, p_oracle_rec (i).line_char5, x_error_stat, x_error_msg);
               get_Description           (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char6, x_error_stat, x_error_msg);
               get_Transaction_Type      (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char8, x_error_stat, x_error_msg); 

               get_Customer_code         (p_oracle_rec (i).transaction_id, p_oracle_rec (i).bill_to_party_number, x_error_stat, x_error_msg);
               --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
               --GC_RECORD_IDENTIFIER       := p_oracle_rec (i).transaction_line_id;
               --GC_ERROR_CODE              := 'VERTEX';
               --GC_ERROR_MSG               := 'GET_CUSTOMER_CODE';
               --GC_COMMENTS                := '0310';
               --GC_ATTRIBUTE1              := p_oracle_rec (i).bill_to_party_number;
               --GC_ATTRIBUTE2              := x_error_stat;
               --GC_ATTRIBUTE3              := x_error_msg;
               --GC_ATTRIBUTE4              := NULL;
               --GC_ATTRIBUTE5              := NULL;
               --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

               get_OrgID                 (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char22, x_error_stat, x_error_msg);
               get_ra_line_number        (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).trx_line_number, x_error_stat, x_error_msg);

               --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
               --GC_RECORD_IDENTIFIER       := p_oracle_rec (i).transaction_line_id;
               --GC_ERROR_CODE              := 'VERTEX';
               --GC_ERROR_MSG               := 'GET_AR_SOURCE';
               --GC_COMMENTS                := '0400';
               --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char9;
               --GC_ATTRIBUTE2              := x_error_stat;
               --GC_ATTRIBUTE3              := x_error_msg;
               --GC_ATTRIBUTE4              := NULL;
               --GC_ATTRIBUTE5              := NULL;
               --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

               -- AR Invoice (Source is Order Management)
               IF p_oracle_rec (i).line_char9 = 'ORDER MANAGEMENT' AND v_Application_code = 'AR' THEN
                  get_OrderEntry_Data    (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char14, x_error_stat, x_error_msg);
                  Update_Global_Attr19(p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, v_ship_to_taid, x_error_stat, x_error_msg);
               END IF;

               -- PROJECTS INVOICES
               IF p_oracle_rec (i).line_char9 = 'PROJECTS INVOICES' THEN
                  get_Project_Data       (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char10, p_oracle_rec (i).line_char11, x_error_stat, x_error_msg);
                  Update_Global_Attr19(p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, v_ship_to_taid, x_error_stat, x_error_msg);
               END IF;

               -- OKS CONTRACTS
               IF p_oracle_rec (i).line_char9 = 'OKS_CONTRACTS' THEN
                  get_Contract_Data      (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char12, p_oracle_rec (i).line_char13, p_oracle_rec (i).line_char14, x_error_stat, x_error_msg);
               END IF;

               -- MANUAL-OTHER
               IF p_oracle_rec (i).line_char9 = 'MANUAL-OTHER' THEN
                  Update_Global_Attr19(p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, v_ship_to_taid, x_error_stat, x_error_msg);
               END IF;
            ELSE
               -- OM Order (Source is Order Management) (If there is no record in ra_customer_trx_all then assume to get from order tables)

               -- Retrieve:
               -- Transaction_id (into x_transaction_id_trxs)
               -- Transaction_line_id (into x_transaction_line_id_trxs)
               -- Original Invoice Number (into p_oracle_rec (i).line_char7) from AR_ADJUSTMENTS_ALL
               -- We use x_transaction_id_trxs in place of 'p_oracle_rec (i).transaction_id' and x_transaction_line_id_trxs in place of p_oracle_rec (i).transaction_line_id
               -- as this is the actual transaction_id to retrieve Oracle Data with
               get_customer_trx_id          (p_oracle_rec (i).transaction_id, x_transaction_id_trxs, x_transaction_line_id_trxs, p_oracle_rec (i).line_char7, x_adjustment_trxs, x_error_stat, x_error_msg);
               --GC_RECORD_NUMBER           := x_transaction_id_trxs;
               --GC_RECORD_IDENTIFIER       := x_transaction_line_id_trxs;
               --GC_ERROR_CODE              := 'VERTEX';
               --GC_ERROR_MSG               := 'GET_CUSTOMER_TRX_ID';
               --GC_COMMENTS                := '0600';
               --GC_ATTRIBUTE1              := x_adjustment_trxs;
               --GC_ATTRIBUTE2              := x_error_stat;
               --GC_ATTRIBUTE3              := x_error_msg;
               --GC_ATTRIBUTE4              := p_oracle_rec (i).line_char7;
               --GC_ATTRIBUTE5              := p_oracle_rec (i).transaction_id;
               --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

               -- If AR Adjustment
               IF x_adjustment_trxs = 'Y' THEN
                  get_division_code         (x_transaction_id_trxs, x_transaction_line_id_trxs, p_oracle_rec (i).line_char15, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := x_transaction_id_trxs;
                  --GC_RECORD_IDENTIFIER       := x_transaction_line_id_trxs;     
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_DIVISION_CODE';
                  --GC_COMMENTS                := '0700';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char15;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := p_oracle_rec (i).transaction_id;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_BT_Customer_Name_Acct (x_transaction_id_trxs, p_oracle_rec (i).line_char1, p_oracle_rec (i).line_char2, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := x_transaction_id_trxs;
                  --GC_RECORD_IDENTIFIER       := x_transaction_line_id_trxs;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_BT_CUSTOMER_NAME_ACCT';
                  --GC_COMMENTS                := '0710';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char1;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := p_oracle_rec (i).line_char2;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_ST_Customer_Name_Acct (x_transaction_id_trxs, p_oracle_rec (i).line_char4, p_oracle_rec (i).line_char5, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := x_transaction_id_trxs;
                  --GC_RECORD_IDENTIFIER       := x_transaction_line_id_trxs;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_ST_CUSTOMER_NAME_ACCT';
                  --GC_COMMENTS                := '0720';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char4;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := p_oracle_rec (i).line_char5;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_Description           (x_transaction_id_trxs, x_transaction_line_id_trxs, p_oracle_rec (i).line_char6, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := x_transaction_id_trxs;
                  --GC_RECORD_IDENTIFIER       := x_transaction_line_id_trxs;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_DESCRIPTION';
                  --GC_COMMENTS                := '0800';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char6;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := p_oracle_rec (i).transaction_id;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_Customer_code         (x_transaction_id_trxs, p_oracle_rec (i).bill_to_party_number, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := x_transaction_id_trxs;
                  --GC_RECORD_IDENTIFIER       := x_transaction_line_id_trxs;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_CUSTOMER_CODE';
                  --GC_COMMENTS                := '0810';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).bill_to_party_number;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := NULL;
                  --GC_ATTRIBUTE5              := NULL;
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_OrgID                 (x_transaction_id_trxs, p_oracle_rec (i).line_char22, x_error_stat, x_error_msg);

                  get_ar_adjustment_date    (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_date1, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
                  --GC_RECORD_IDENTIFIER       := NULL;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_AR_ADJUSTMENT_DATE';
                  --GC_COMMENTS                := '0820';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_date1;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := NULL;
                  --GC_ATTRIBUTE5              := NULL;
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

               -- If NOT AR Adjustment
               ELSE
                  get_division_code_OM         (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char15, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
                  --GC_RECORD_IDENTIFIER       := p_oracle_rec (i).transaction_line_id;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_DIVISION_CODE_OM';
                  --GC_COMMENTS                := '0900';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char15;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := NULL;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_BT_Customer_Name_Acct_OM (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char1, p_oracle_rec (i).line_char2, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
                  --GC_RECORD_IDENTIFIER       := p_oracle_rec (i).transaction_line_id;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_BT_CUSTOMER_NAME_ACCT_OM';
                  --GC_COMMENTS                := '0910';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char1;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := p_oracle_rec (i).line_char2;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_ST_Customer_Name_Acct_OM (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char4, p_oracle_rec (i).line_char5, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
                  --GC_RECORD_IDENTIFIER       := p_oracle_rec (i).transaction_line_id;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_ST_CUSTOMER_NAME_ACCT_OM';
                  --GC_COMMENTS                := '0920';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char4;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := p_oracle_rec (i).line_char5;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_Description_OM           (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id, p_oracle_rec (i).line_char6, x_error_stat, x_error_msg);
                  --GC_RECORD_NUMBER           := p_oracle_rec (i).transaction_id;
                  --GC_RECORD_IDENTIFIER       := p_oracle_rec (i).transaction_line_id;
                  --GC_ERROR_CODE              := 'VERTEX';
                  --GC_ERROR_MSG               := 'GET_DESCRIPTION_OM';
                  --GC_COMMENTS                := '1000';
                  --GC_ATTRIBUTE1              := p_oracle_rec (i).line_char6;
                  --GC_ATTRIBUTE2              := x_error_stat;
                  --GC_ATTRIBUTE3              := x_error_msg;
                  --GC_ATTRIBUTE4              := NULL;
                  --GC_ATTRIBUTE5              := 'Order Management';
                  --XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_PRC(GC_REQUEST_ID, GC_RECORD_NUMBER, GC_RECORD_IDENTIFIER, GC_ERROR_CODE, GC_ERROR_MSG, GC_COMMENTS, GC_TABLE_NAME, GC_ATTRIBUTE1, GC_ATTRIBUTE2, GC_ATTRIBUTE3, GC_ATTRIBUTE4, GC_ATTRIBUTE5, GC_STATUS);

                  get_Customer_code_OM         (p_oracle_rec (i).transaction_id, p_oracle_rec (i).bill_to_party_number, x_error_stat, x_error_msg);
                  get_OrgID_OM                 (p_oracle_rec (i).transaction_id, p_oracle_rec (i).line_char22, x_error_stat, x_error_msg);
               END IF;
            END IF;

            -- HAEMO CUSTOMIZATIONS END
            --------------------------------------------------------------------

            p_oracle_rec (i).bill_to_party_name := p_oracle_rec (i).bill_to_party_number;

            IF p_oracle_rec (i).document_level_action = 'UPDATE' AND f_not_present(p_oracle_rec (i).transaction_id, p_oracle_rec (i).internal_organization_id, p_oracle_rec (i).document_type_id) = 'Y' THEN
               p_oracle_rec (i).document_level_action := 'CREATE';
               p_oracle_rec (i).line_level_action     := 'CREATE';
            END IF;

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'DOCUMENT TYPE  ' || p_oracle_rec (i).DOCUMENT_TYPE_ID
                                 );

            P_VTX_WRITE_LOG.write_log(
                                 v_module_name || l_api_name,
                                 'LINE QUANTITY ' || p_oracle_rec (i).TRANSACTION_LINE_QUANTITY
                                 );

            IF p_oracle_rec(i).document_type_id = 6 THEN
               BEGIN

                  SELECT allow_tax_calculation
                    INTO v_allow_tax_calc
                    FROM vertex_etx_txn_header
                   WHERE transaction_id           = p_oracle_rec(i).transaction_id 
                     AND internal_organization_id = p_oracle_rec(i).internal_organization_id;

                  P_VTX_WRITE_LOG.write_log(
                                       v_module_name || l_api_name,
                                       'TAX CALC FLAG' || v_allow_tax_calc
                                       );

                  IF LTRIM(RTRIM(UPPER(v_allow_tax_calc))) ='N' THEN
                     p_oracle_rec (i).line_level_action   := 'NO_TAX_CALC';
                  END IF;

               EXCEPTION
                    WHEN OTHERS THEN
                         NULL;

               END;

            END IF;

            v_tax_only := 0;

            BEGIN

               SELECT 1
                 INTO v_tax_only
                 FROM vertex_etx_txn_details
                WHERE transaction_id      = p_oracle_rec (i).transaction_id
                  AND transaction_line_id = p_oracle_rec (i).transaction_line_id
                  AND LTRIM(RTRIM(UPPER(trx_line_description))) LIKE 'TAX%ONLY%';

               IF v_tax_only = 1 THEN
                  p_oracle_rec (i).line_level_action := 'NO_CALC_TAX_ONLY';
               END IF;

            EXCEPTION
                 WHEN OTHERS THEN
                      NULL;
            END;

            p_oracle_rec (i).ship_to_party_name   := SUBSTR(p_oracle_rec (i).ship_to_party_name, 1, 40);
            p_oracle_rec (i).bill_to_party_name   := SUBSTR(p_oracle_rec (i).bill_to_party_name, 1, 40);
            p_oracle_rec (i).ship_from_party_name := SUBSTR(p_oracle_rec (i).ship_from_party_name, 1, 40);
            p_oracle_rec (i).bill_from_party_name := SUBSTR(p_oracle_rec (i).bill_from_party_name, 1, 40);
            p_oracle_rec (i).line_char3           := v_instance_name;

            P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           'gl date   :-' ||  get_gl_date (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id
                           ));

            p_oracle_rec (i).header_date1 := get_gl_date (p_oracle_rec (i).transaction_id, p_oracle_rec (i).transaction_line_id);

         END LOOP; --  FOR i IN p_oracle_rec.FIRST .. p_oracle_rec.LAST
      END IF; --  IF p_oracle_rec.COUNT > 0 THEN

      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           'ship to taid  :-' || v_ship_to_taid
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           'ship from taid :-' || v_ship_from_taid
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           'bill to taid :-' || v_bill_to_taid
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           'bill from taid :-' || v_bill_from_taid
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           'poa taid :-' || v_poa_taid
                           );
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );
   EXCEPTION
        WHEN OTHERS THEN
             x_error_stat := 'E';
             x_error_msg  := 'Err in custom sourcing' || SQLERRM;

   END main_rounter;


-----------------------------------------------------------------------
-- PROCEDURE vtx_after_calc

   PROCEDURE vtx_after_calc (
      p_tax_line   IN OUT   zx_tax_partner_pkg.tax_lines_tbl_type
   )
   IS
      v_legal_justification_text1   VARCHAR2 (200);
      v_legal_justification_text2   VARCHAR2 (200);
      v_legal_justification_text3   VARCHAR2 (200);
   BEGIN

      l_api_name := 'vtx_after_calc ';
      P_VTX_WRITE_LOG.write_log(
                           v_module_name || l_api_name || '.BEGIN',
                           v_pkg_name || ': ' || l_api_name || '(+)'
                           );

      IF NVL(p_tax_line.transaction_id.COUNT, 0) > 0 THEN
         IF vertex_etax_types_pkg.v_vtx_tax_type = 'VAT' THEN
            NULL;
         END IF;
      END IF;

   EXCEPTION
        WHEN OTHERS THEN
             NULL;

   END;

END vertex_custom_attributes_pkg;