CREATE OR REPLACE package XXHA_AMENDMENTWF_PKG AS


PROCEDURE Initiate(p_document_id          IN NUMBER,
                   p_attached_document_id IN NUMBER,
                   p_created_by           IN NUMBER
				  );


Procedure PREPARE_NOTIF (itemtype  in varchar2,
                         itemkey   in varchar2,
                         actid     in number,
                         funcmode  in varchar2,
                         resultout in out varchar2
                        );

Procedure GET_NEXT_APPROVER
       (itemtype  in varchar2,
        itemkey   in varchar2,
        actid     in number,
        funcmode  in varchar2,
        resultout in out varchar2
	   );

Procedure UPDATE_REJECT_STATUS
          (itemtype  in varchar2,
           itemkey   in varchar2,
           actid     in number,
           funcmode  in varchar2,
           resultout in out varchar2
		  );

Procedure insert_workflow_status(p_transaction_id          IN NUMBER,
                                 p_transaction_type_id     IN NUMBER,
								 p_transaction_phase_code  IN VARCHAR2,
								 p_role              IN VARCHAR2,
								 p_approver_sequence IN NUMBER,
								 p_approval_status   IN VARCHAR2
								);

Procedure update_workflow_status(p_transaction_id    IN NUMBER,
                                 p_approver_sequence IN NUMBER,
                                 p_approval_status   IN VARCHAR2
								);

PROCEDURE notif_attach_procedure ( document_id   IN VARCHAR2
                                  ,display_type  IN VARCHAR2
                                  ,document      IN OUT BLOB
                                  ,document_type IN OUT VARCHAR2
                                 );

PROCEDURE notif_initator_text ( document_id   IN VARCHAR2
                               ,display_type  IN VARCHAR2
                               ,document      IN OUT VARCHAR2
                               ,document_type IN OUT VARCHAR2
                                 );

end XXHA_AMENDMENTWF_PKG;

/


CREATE OR REPLACE PACKAGE BODY xxha_amendmentwf_pkg AS
/*******************************************************************************************
*Name: xxha_amendmentwf_pkg
*
*Description: This package is used by the BSA workflow approvals
*
*Created By: 
*Date:   
*
*Modification Log:
*Developer             Date                     Description
*-----------------   ------------------   ------------------------------------------------
* David Lund		     Dec-23-2013          Changed PREPARE_NOTIF procedure to have exception handling for no categories
*******************************************************************************************/

Procedure PREPARE_NOTIF(itemtype  IN VARCHAR2,
                        itemkey   IN VARCHAR2,
                        actid     IN NUMBER,
                        funcmode  IN VARCHAR2,
                        resultout IN OUT VARCHAR2) as

lv_order_number        VARCHAR2(20);
lv_transaction_type    VARCHAR2(50);
lv_order_category_code VARCHAR2(50);
ld_expiration_date     DATE;
ln_order_id            NUMBER;
ln_org_id              NUMBER;
lv_initiator           VARCHAR2(20);

lv_approver_username   VARCHAR2(20);
lv_approver_fullname   VARCHAR2(50);
ln_approver_ranking    NUMBER;

ln_transaction_type_id      NUMBER;
lv_transaction_phase_code   VARCHAR2(5);
ln_user_id              NUMBER;

ln_media_id             NUMBER;
lv_content_type         VARCHAR2(50);
ld_document             BLOB;
lv_document_type        VARCHAR2(100);

ln_attached_document_id  NUMBER:=0;

lv_init_role_name       VARCHAR2(20):='AMEND_INITIATOR';
lv_init_role_dispname   VARCHAR2(50) := 'Amendment Workflow Initiator';


  CURSOR cur_appr_list(c_org_id IN NUMBER) IS
  SELECT DISTINCT fu.user_name,
         ppf.full_name,
         xoa.approver_ranking
  FROM   xxha_oe_bsa_approval_lst XOA,
         per_all_people_f PPF,
         fnd_user FU
  WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
  AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
  AND    FU.employee_id = PPF.person_id
  AND    XOA.clause_type = 'BSA Other'
  AND    org_id = c_org_id
  order by APPROVER_RANKING, FULL_NAME;

  lv_appr_list cur_appr_list%ROWTYPE;

  lv_initiator_html VARCHAR2(4000);

  ln_cnt    NUMBER:=1;

  ln_cnt_approver NUMBER:=0;

  lv_category     VARCHAR2(30):='NOT AMENDMENT';

BEGIN


  ln_order_id := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                             itemkey  => itemkey,
                                             aname    => 'HEADER_ID');

  ln_attached_document_id := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                         itemkey  => itemkey,
                                                         aname    => 'ATTACHED_DOCUMENT_ID');

  lv_initiator := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                            itemkey  => itemkey,
                                            aname    => 'INITIATOR');


   select UPPER(fdct.user_name)
   into   lv_category
   from   fnd_document_categories fdc,
          fnd_document_categories_tl fdct,
          fnd_application fa,
          fnd_attached_documents  fad
   where  fdc.category_id = fdct.category_id
   and    fdc.application_id = fa.application_id
   and    fad.category_id = fdc.category_id
   and    fa.application_short_name = 'OKC'
   and    language = 'US'
   and    fad.attached_document_id = ln_attached_document_id;


   IF upper(lv_category) = 'AMENDMENT' THEN



   ln_user_id := XXHA_OE_APPROVALS_WF.get_user_id;

   SELECT OBH.order_number,
          OTT.name Transaction_type,
          OBH.expiration_date,
          OTTA.order_category_code,
          OBH.org_id
   INTO   lv_order_number,
          lv_transaction_type,
          ld_expiration_date,
          lv_order_category_code,
          ln_org_id
   FROM   oe_blanket_headers_all OBH,
          oe_transaction_types_tl OTT,
          oe_transaction_types_all OTTA,
          fnd_user fu
   WHERE  OBH.created_by = FU.user_id
   and    OBH.order_type_id = OTT.transaction_type_id
   AND    ott.transaction_type_id = otta.transaction_type_id
   and    OTT.language = 'US'
   and    OBH.header_id = ln_order_id;

   WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                             itemkey  => itemkey,
                             aname    => 'SALES_DOCUMENT_TYPE',
                             avalue   => lv_transaction_type);

   WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                             itemkey  => itemkey,
                             aname    => 'SALES_DOCUMENT_TYPE_CODE',
                             avalue   => lv_order_category_code);

   WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                             itemkey  => itemkey,
                             aname    => 'ORDER_NUMBER',
                             avalue   => lv_order_number);

   WF_ENGINE.SetItemAttrDate(itemtype => itemtype,
                             itemkey  => itemkey,
                             aname    => 'EXPIRATION_DATE',
                             avalue   => ld_expiration_date);

   WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                             itemkey  => itemkey,
                             aname    => 'ORG_ID',
                             avalue   => ln_org_id);

   WF_DIRECTORY.RemoveUsersFromAdHocRole(Role_name => lv_init_role_name);

   WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, lv_initiator);

   WF_DIRECTORY.AddUsersToAdHocRole(lv_init_role_name, 'HAEAUT');


   WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                             itemkey  => itemkey,
                             aname    => 'INITIATOR_ROLE',
                             avalue   => lv_init_role_name);

   BEGIN


       SELECT   approver_ranking, count(XOA.employee_number)
       INTO     ln_approver_ranking, ln_cnt_approver
       FROM     xxha_oe_bsa_approval_lst XOA
       where    XOA.clause_type = 'BSA Other'
       AND      org_id = ln_org_id
       and      approver_ranking  = (SELECT MIN(XOA1.APPROVER_RANKING)
                                     FROM   xxha_oe_bsa_approval_lst XOA1
		                     WHERE  XOA1.clause_type = XOA.clause_type
                                     AND    XOA1.org_id = XOA.org_id)
       GROUP by APPROVER_RANKING;

       IF ln_cnt_approver > 1 THEN

           SELECT DISTINCT fu.user_name,
                  ppf.full_name,
                  xoa.approver_ranking
           INTO   lv_approver_username,
                  lv_approver_fullname,
                  ln_approver_ranking
           FROM   xxha_oe_bsa_approval_lst XOA,
                  per_all_people_f PPF,
                  fnd_user FU
           WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
           AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
           AND    FU.employee_id = PPF.person_id
           AND    XOA.clause_type = 'BSA Other'
           AND    org_id = ln_org_id
           AND    xoa.employee_number = (SELECT MIN(XOA1.employee_number)
                                         FROM   xxha_oe_bsa_approval_lst XOA1
           				 WHERE  XOA1.clause_type = xoa.clause_type
                                         AND    XOA1.org_id = xoa.org_id
                                         AND    XOA1.approver_ranking = ln_approver_ranking);


          WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                    itemkey  => itemkey,
                                    aname    => 'MULTIUSER_SAMERANKING',
                                    avalue   => 'Y');


       ELSE

           SELECT DISTINCT fu.user_name,
                  ppf.full_name,
                  xoa.approver_ranking
           INTO   lv_approver_username,
                  lv_approver_fullname,
                  ln_approver_ranking
           FROM   xxha_oe_bsa_approval_lst XOA,
                  per_all_people_f PPF,
                  fnd_user FU
           WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
           AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
           AND    FU.employee_id = PPF.person_id
           AND    XOA.clause_type = 'BSA Other'
           AND    org_id = ln_org_id
           AND    XOA.approver_ranking = ln_approver_ranking;


          WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                    itemkey  => itemkey,
                                    aname    => 'MULTIUSER_SAMERANKING',
                                    avalue   => 'N');


       END IF;


--        SELECT fu.user_name,
--               ppf.full_name,
--               xoa.approver_ranking
--        INTO   lv_approver_username,
--               lv_approver_fullname,
--               ln_approver_ranking
--        FROM   xxha_oe_bsa_approval_lst XOA,
--               per_all_people_f PPF,
--               fnd_user FU
--        WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
--        AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
--        AND    FU.employee_id = PPF.person_id
--        AND    XOA.clause_type = 'BSA Other'
--        AND    org_id = ln_org_id
--        AND    approver_ranking  = (SELECT MIN(XOA1.APPROVER_RANKING)
--                                    FROM   xxha_oe_bsa_approval_lst XOA1
-- 		                   WHERE  XOA1.clause_type = XOA.clause_type
--                                    AND    XOA1.org_id = XOA.org_id);
--
--        AND    ROWNUM = 1;

       BEGIN

       	     SELECT OBH.transaction_phase_code,
       	            OBH.order_type_id
       	     INTO   lv_transaction_phase_code,
       	            ln_transaction_type_id
       	     FROM   oe_blanket_headers_all OBH
       	     WHERE  header_id = ln_order_id
       	     AND    ORG_ID = ln_org_id;


              insert_workflow_status(itemkey,
                                     ln_transaction_type_id,
                                     lv_transaction_phase_code,
                                     lv_approver_username,
                                     1,
                                     NULL);

       END;

       BEGIN

             SELECT fd.media_id,
                    fl.file_content_type
             INTO   ln_media_id,
                    lv_content_type
             FROM   fnd_attached_documents  fad,
                    okc_contract_docs ocd,
                    fnd_documents_tl  fd,
                    fnd_lobs fl
             WHERE  fad.attached_document_id = ocd.attached_document_id
             and    fad.document_id = fd.document_id
             and    fd.media_id = fl.file_id
             and    ocd.attached_document_id = ln_attached_document_id
             and    fd.language  = 'US';


             WF_ENGINE.SetItemAttrDocument(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'CONTRACT_DOCUMENT',
                                           documentid   => 'PLSQLBLOB:xxha_amendmentwf_pkg.notif_attach_procedure/'||to_char(ln_media_id));


             WF_ENGINE.SetItemAttrDocument(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'INITIATOR_HTML_MESSAGE',
                                           documentid   => 'PLSQL:xxha_amendmentwf_pkg.notif_initator_text/'||to_char(ln_org_id));


       END;

    EXCEPTION WHEN NO_DATA_FOUND THEN

       RESULTOUT := 'COMPLETE:N';

    END;

    WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'NOTIFICATION_APPROVER',
                              avalue   => lv_approver_username);

    WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                              itemkey  => itemkey,
                              aname    => 'NOTIFICATION_APPROVER_NAME',
                              avalue   => lv_approver_fullname);

    WF_ENGINE.SetItemAttrNumber(itemtype => itemtype,
                                itemkey  => itemkey,
                                aname    => 'NOTIFICATION_APPROVER_RANKING',
                                avalue   => ln_approver_ranking);

    WF_ENGINE.SetItemAttrNumber(itemtype => itemtype,
                                itemkey  => itemkey,
                                aname    => 'APPROVER_SEQUENCE',
                                avalue   => 1);


   RESULTOUT := 'COMPLETE:Y';

ELSE

   RESULTOUT := 'COMPLETE:NOT';
   RETURN;

END IF;

EXCEPTION WHEN NO_DATA_FOUND THEN

       RESULTOUT := 'COMPLETE:N';
       RETURN;
END PREPARE_NOTIF;


Procedure GET_NEXT_APPROVER(itemtype  IN VARCHAR2,
                            itemkey   IN VARCHAR2,
                            actid     IN NUMBER,
                            funcmode  IN VARCHAR2,
                            resultout IN OUT VARCHAR2) as

ln_order_id            NUMBER := 0;
lv_approver_username   VARCHAR2(20);
lv_approver_fullname   VARCHAR2(50);
ln_approver_ranking    NUMBER := 0;
ln_org_id              NUMBER := 0;
ln_approver_sequence   NUMBER := 0;

ln_transaction_type_id      NUMBER;
lv_transaction_phase_code   VARCHAR2(5);
ln_user_id              NUMBER;

ln_cnt_approver NUMBER:=0;

lv_current_approver   VARCHAR2(20);

lv_multiuser_sameranking  VARCHAR2(1);

lv_currappr_enumber    VARCHAR2(20);

ln_sql_appr_ranking   NUMBER;


BEGIN


  ln_order_id := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                             itemkey  => itemkey,
                                             aname    => 'HEADER_ID');

  ln_approver_ranking := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                     itemkey  => itemkey,
                                                     aname    => 'NOTIFICATION_APPROVER_RANKING');

  ln_org_id := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'ORG_ID');

  ln_approver_sequence := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                      itemkey  => itemkey,
                                                      aname    => 'APPROVER_SEQUENCE');

  lv_current_approver  := WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'NOTIFICATION_APPROVER');

  lv_multiuser_sameranking :=  WF_ENGINE.GetItemAttrText(itemtype => itemtype,
                                                    itemkey  => itemkey,
                                                    aname    => 'MULTIUSER_SAMERANKING');

    BEGIN

       update_workflow_status(itemkey, ln_approver_sequence, 'APPROVED');


    END;

    BEGIN

        SELECT employee_number
        INTO   lv_currappr_enumber
        FROM   per_all_people_f ppf,
               fnd_user fu
        WHERE  fu.employee_id = ppf.person_id
        AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
        AND    fu.user_name = lv_current_approver
        AND    ROWNUM = 1;


    IF lv_multiuser_sameranking = 'Y' THEN

       SELECT   xoa.approver_ranking, count(XOA.employee_number)
       INTO     ln_sql_appr_ranking, ln_cnt_approver
       FROM     xxha_oe_bsa_approval_lst XOA
       where    XOA.clause_type = 'BSA Other'
       AND      org_id = ln_org_id
       AND      xoa.approver_ranking = ln_approver_ranking
       and      xoa.employee_number  > lv_currappr_enumber
       GROUP BY xoa.approver_ranking;


    ELSIF lv_multiuser_sameranking = 'N' THEN

       SELECT   approver_ranking, count(XOA.employee_number)
       INTO     ln_sql_appr_ranking, ln_cnt_approver
       FROM     xxha_oe_bsa_approval_lst XOA
       where    XOA.clause_type = 'BSA Other'
       AND      org_id = ln_org_id
       and      xoa.approver_ranking  = (SELECT MIN(xoa1.approver_ranking)
                                        FROM   xxha_oe_bsa_approval_lst XOA1
   		                        WHERE  XOA1.clause_type = XOA.clause_type
                                        AND    XOA1.org_id = XOA.org_id
                                        AND    XOA1.approver_ranking > ln_approver_ranking)
       group by xoa.approver_ranking;

    END IF;

    IF ln_cnt_approver > 1 THEN

        WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                  itemkey  => itemkey,
                                  aname    => 'MULTIUSER_SAMERANKING',
                                  avalue   => 'Y');

       IF ln_sql_appr_ranking = ln_approver_ranking THEN


        SELECT DISTINCT fu.user_name,
               ppf.full_name,
               xoa.approver_ranking
        INTO   lv_approver_username,
               lv_approver_fullname,
               ln_approver_ranking
        FROM   xxha_oe_bsa_approval_lst XOA,
               per_all_people_f PPF,
               fnd_user FU
        WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
        AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
        AND    FU.employee_id = PPF.person_id
        AND    XOA.clause_type = 'BSA Other'
        AND    org_id = ln_org_id
        AND    xoa.employee_number = (SELECT MIN(XOA1.employee_number)
                                      FROM   xxha_oe_bsa_approval_lst XOA1
                                      WHERE  XOA1.clause_type = xoa.clause_type
                                      AND    XOA1.org_id = xoa.org_id
                                      AND    XOA1.approver_ranking = ln_sql_appr_ranking
                                      AND    XOA1.employee_number  > to_number(lv_currappr_enumber));

       ELSIF ln_sql_appr_ranking <> ln_approver_ranking THEN

        SELECT DISTINCT fu.user_name,
               ppf.full_name,
               xoa.approver_ranking
        INTO   lv_approver_username,
               lv_approver_fullname,
               ln_approver_ranking
        FROM   xxha_oe_bsa_approval_lst XOA,
               per_all_people_f PPF,
               fnd_user FU
        WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
        AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
        AND    FU.employee_id = PPF.person_id
        AND    XOA.clause_type = 'BSA Other'
        AND    org_id = ln_org_id
        AND    xoa.employee_number = (SELECT MIN(XOA1.employee_number)
                                      FROM   xxha_oe_bsa_approval_lst XOA1
                                      WHERE  XOA1.clause_type = xoa.clause_type
                                      AND    XOA1.org_id = xoa.org_id
                                      AND    XOA1.approver_ranking = ln_sql_appr_ranking);

       END IF;


     ELSIF ln_cnt_approver = 1 THEN

        WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                  itemkey  => itemkey,
                                  aname    => 'MULTIUSER_SAMERANKING',
                                  avalue   => 'N');

        SELECT DISTINCT fu.user_name,
               ppf.full_name,
               xoa.approver_ranking
        INTO   lv_approver_username,
               lv_approver_fullname,
               ln_approver_ranking
        FROM   xxha_oe_bsa_approval_lst XOA,
               per_all_people_f PPF,
               fnd_user FU
        WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
        AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
        AND    FU.employee_id = PPF.person_id
        AND    XOA.clause_type = 'BSA Other'
        AND    org_id = ln_org_id
        AND    XOA.approver_ranking = ln_sql_appr_ranking
        AND    PPF.employee_number > to_number(lv_currappr_enumber);


     ELSIF ln_cnt_approver = 0 THEN

        RESULTOUT := 'COMPLETE:N';
        RETURN;

     END IF;


--        SELECT fu.user_name,
--               ppf.full_name,
--               xoa.approver_ranking
--        INTO   lv_approver_username,
--               lv_approver_fullname,
--               ln_approver_ranking
--        FROM   xxha_oe_bsa_approval_lst XOA,
--               per_all_people_f PPF,
--               fnd_user FU
--        WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
--        AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
--        AND    FU.employee_id = PPF.person_id
--        AND    XOA.clause_type = 'BSA Other'
--        AND    org_id = ln_org_id
--        AND    approver_ranking = (SELECT MIN(XOA1.approver_ranking)
--                                   FROM   xxha_oe_bsa_approval_lst XOA1
-- 				     WHERE  XOA1.clause_type = 'BSA Other'
--                                   AND    XOA1.org_id = ln_org_id
--                                   AND    XOA1.approver_ranking > ln_approver_ranking + 1)
--        AND    rownum = 1;


       BEGIN

             ln_approver_sequence := ln_approver_sequence + 1;

       	     SELECT OBH.transaction_phase_code,
       	            OBH.order_type_id
       	     INTO   lv_transaction_phase_code,
       	            ln_transaction_type_id
       	     FROM   oe_blanket_headers_all OBH
       	     WHERE  header_id = ln_order_id
       	     AND    ORG_ID = ln_org_id;

             insert_workflow_status(itemkey,
                                    ln_transaction_type_id,
                                    lv_transaction_phase_code,
                                    lv_approver_username,
                                    ln_approver_sequence,
                                    NULL);
      END;


      WF_ENGINE.SetItemAttrNumber(itemtype => itemtype,
                                  itemkey  => itemkey,
                                  aname    => 'NOTIFICATION_APPROVER_RANKING',
                                  avalue   => ln_sql_appr_ranking);

      WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                  itemkey  => itemkey,
                                  aname    => 'NOTIFICATION_APPROVER',
                                  avalue   => lv_approver_username);

      WF_ENGINE.SetItemAttrText(itemtype => itemtype,
                                  itemkey  => itemkey,
                                  aname    => 'NOTIFICATION_APPROVER_NAME',
                                  avalue   => lv_approver_fullname);

      WF_ENGINE.SetItemAttrNumber(itemtype => itemtype,
                                  itemkey  => itemkey,
                                  aname    => 'APPROVER_SEQUENCE',
                                  avalue   => ln_approver_sequence);

    EXCEPTION WHEN NO_DATA_FOUND THEN

       RESULTOUT := 'COMPLETE:N';
       RETURN;

    END;

RESULTOUT := 'COMPLETE:Y';

END GET_NEXT_APPROVER;


Procedure UPDATE_REJECT_STATUS (itemtype  in varchar2,
                               itemkey   in varchar2,
                               actid     in number,
                               funcmode  in varchar2,
                               resultout in out varchar2) is

ln_order_id            NUMBER := 0;
lv_approver_username   VARCHAR2(20);
ln_approver_ranking    NUMBER := 0;
ln_org_id              NUMBER := 0;
ln_approver_sequence   NUMBER := 0;

BEGIN

  ln_order_id := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                             itemkey  => itemkey,
                                             aname    => 'HEADER_ID');

  ln_approver_ranking := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                     itemkey  => itemkey,
                                                     aname    => 'NOTIFICATION_APPROVER_RANKING');

  ln_org_id := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                           itemkey  => itemkey,
                                           aname    => 'ORG_ID');

  ln_approver_sequence := WF_ENGINE.GetItemAttrNumber(itemtype => itemtype,
                                                      itemkey  => itemkey,
                                                      aname    => 'APPROVER_SEQUENCE');

    BEGIN

       update_workflow_status(itemkey, ln_approver_sequence, 'REJECTED');

    END;

    RESULTOUT := 'COMPLETE';


END UPDATE_REJECT_STATUS;


PROCEDURE Initiate(p_document_id          IN NUMBER,
                   p_attached_document_id IN NUMBER,
                   p_created_by           IN NUMBER) AS

lv_item_type           VARCHAR2(20) := 'XXHAMAPR';
lv_order_number        VARCHAR2(20);
lv_initiator           VARCHAR2(50);
lv_transaction_type    VARCHAR2(50);
lv_order_catetory_code VARCHAR2(50);
ld_expiration_date     DATE;
ln_itemkey             NUMBER;

lv_category            VARCHAR2(30);

lv_test           varchar2(50);

BEGIN



   SELECT OBH.order_number
   INTO   lv_order_number
   FROM   oe_blanket_headers_all OBH
   WHERE  OBH.header_id = p_document_id;

   SELECT FU.user_name
   INTO   lv_initiator
   FROM   fnd_user fu
   where  user_id = p_created_by;

   SELECT xxha_blkamend_wf_seq.nextval
   INTO   ln_itemkey
   FROM   DUAL;

   WF_ENGINE.CreateProcess(itemtype   => lv_item_type,
                           itemkey    => ln_itemkey,
                           process    => 'XXHA_NEWAMEND_NOTIFCATION',
                           user_key   => lv_order_number,
                           owner_role => lv_initiator);

   WF_ENGINE.SetItemAttrText(itemtype => lv_item_type,
                             itemkey  => ln_itemkey,
                             aname    => 'INITIATOR',
                             avalue   => lv_initiator);

   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'HEADER_ID',
                               avalue   => p_document_id);

   WF_ENGINE.SetItemAttrNumber(itemtype => lv_item_type,
                               itemkey  => ln_itemkey,
                               aname    => 'ATTACHED_DOCUMENT_ID',
                               avalue   => p_attached_document_id);

   WF_ENGINE.StartProcess(itemtype => 'XXHAMAPR',
                          itemkey  => ln_itemkey);


END Initiate;

Procedure insert_workflow_status(p_transaction_id          IN NUMBER,
                                 p_transaction_type_id     IN NUMBER,
                                 p_transaction_phase_code  IN VARCHAR2,
                                 p_role      	           IN VARCHAR2,
                                 p_approver_sequence       IN NUMBER,
                                 p_approval_status         IN VARCHAR2) IS

ln_user_id    NUMBER;

BEGIN

    ln_user_id := XXHA_OE_APPROVALS_WF.get_user_id;

    INSERT INTO OE_APPROVER_TRANSACTIONS
    (
      TRANSACTION_ID
     ,TRANSACTION_TYPE_ID   --?? Do we need this. evalute
     ,TRANSACTION_PHASE_CODE
     ,ROLE
     ,APPROVER_SEQUENCE
     ,APPROVAL_STATUS
     ,CREATION_DATE
     ,CREATED_BY
     ,LAST_UPDATE_DATE
     ,LAST_UPDATED_BY
     ,LAST_UPDATE_LOGIN
     )
    VALUES
     (p_transaction_id
     ,p_transaction_type_id
     ,p_transaction_phase_code
     ,p_role
     ,p_approver_sequence
     ,p_approval_status --APPROVAL_STATUS
     ,SYSDATE
     ,ln_user_id
     ,SYSDATE
     ,ln_user_id
     ,ln_user_id
    );

EXCEPTION WHEN OTHERS THEN NULL;
END insert_workflow_status;



Procedure update_workflow_status(p_transaction_id    IN NUMBER,
                                 p_approver_sequence IN NUMBER,
                                 p_approval_status   IN VARCHAR2) IS

ln_user_id    NUMBER;

BEGIN

    ln_user_id := XXHA_OE_APPROVALS_WF.get_user_id;

    UPDATE OE_APPROVER_TRANSACTIONS
    SET    APPROVAL_STATUS   = p_approval_status
    WHERE  transaction_id     = p_transaction_id
    AND    approver_sequence = p_approver_sequence;


EXCEPTION WHEN OTHERS THEN NULL;

END update_workflow_status;

PROCEDURE notif_attach_procedure
  (
    document_id   IN VARCHAR2
   ,display_type  IN VARCHAR2
   ,document      IN OUT BLOB
   ,document_type IN OUT VARCHAR2
  ) IS

    lob_id       NUMBER;
    bdoc         BLOB;
    content_type VARCHAR2(100);
    filename     VARCHAR2(300);

  BEGIN
--    set_debug_context('xx_notif_attach_procedure');

    lob_id := to_number(document_id);

    -- Obtain the BLOB version of the document
    SELECT file_name
          ,file_content_type
          ,file_data
    INTO   filename
          ,content_type
          ,bdoc
    FROM   fnd_lobs
    WHERE  file_id = lob_id;

    document_type := content_type || ';name=' || filename;
    dbms_lob.copy(document, bdoc, dbms_lob.getlength(bdoc));
  EXCEPTION
    WHEN OTHERS THEN
--      debug('ERROR ^^^^0018 ' || SQLERRM);
      wf_core.CONTEXT('XXHA_AMENDMENTWF_PKG'
                     ,'notif_attach_procedure'
                     ,document_id
                     ,display_type);
      RAISE;
  END notif_attach_procedure;


PROCEDURE notif_initator_text ( document_id   IN VARCHAR2
                               ,display_type  IN VARCHAR2
                               ,document      IN OUT VARCHAR2
                               ,document_type IN OUT VARCHAR2
                                 ) is

  CURSOR cur_appr_list(c_org_id IN NUMBER) IS
  SELECT DISTINCT fu.user_name,
         ppf.full_name,
         xoa.approver_ranking,
         ppf.employee_number
  FROM   xxha_oe_bsa_approval_lst XOA,
         per_all_people_f PPF,
         fnd_user FU
  WHERE  TO_CHAR(XOA.EMPLOYEE_NUMBER) = PPF.EMPLOYEE_NUMBER
  AND    SYSDATE between effective_start_date and nvl(effective_end_date, sysdate + 1)
  AND    FU.employee_id = PPF.person_id
  AND    XOA.clause_type = 'BSA Other'
  AND    org_id = c_org_id
  order by APPROVER_RANKING, PPF.employee_number;

  lv_appr_list cur_appr_list%ROWTYPE;

  lv_initiator_html VARCHAR2(4000);
  ln_cnt    NUMBER:=1;

BEGIN


   lv_initiator_html := '<body>';
   lv_initiator_html := lv_initiator_html||'<br><br><br>';
   lv_initiator_html := lv_initiator_html||'New Document has been attached to the BSA   and workflow initiated for approval <br><br><br>';
   lv_initiator_html := lv_initiator_html||'<table border="1" width="50%">';
   lv_initiator_html := lv_initiator_html||'<tr><th>Sl No</th><th>Approver User Name</th><th>Approver Name</th><th>Approver Ranking</th></tr>';

   OPEN cur_appr_list(document_id);
   LOOP

      FETCH cur_appr_list INTO lv_appr_list;
      EXIT WHEN cur_appr_list%NOTFOUND;

      lv_initiator_html := lv_initiator_html||'<tr><td>'||to_char(ln_cnt)||'</td>';
      lv_initiator_html := lv_initiator_html||'<td>'||lv_appr_list.user_name||'</td>';
      lv_initiator_html := lv_initiator_html||'<td>'||lv_appr_list.full_name||'</td>';
      lv_initiator_html := lv_initiator_html||'<td>'||lv_appr_list.approver_ranking||'</td></tr>';

      ln_cnt := ln_cnt + 1;

   END LOOP;
   CLOSE cur_appr_list;
   lv_initiator_html := lv_initiator_html||'</table></body>';


   document := lv_initiator_html;


end notif_initator_text;

end XXHA_AMENDMENTWF_PKG;
/
