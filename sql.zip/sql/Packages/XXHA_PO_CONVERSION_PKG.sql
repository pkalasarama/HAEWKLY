CREATE OR REPLACE PACKAGE XXHA_PO_CONVERSION_PKG AS

--Global variables
--gn_record_number         xxha_common_errors.record_number%TYPE;                   --Variable to store Oracle Identifier of the record
gn_record_number         po_headers_all.segment1%type;                   --Variable to store Oracle Identifier of the record
gc_record_identifier     xxha_common_errors.record_identifier%TYPE;               --Variable to store Record identifier of the record
--gc_record_identifier     po_headers_all.segment1%TYPE;               --Variable to store Record identifier of the record
gc_error_code            xxha_common_errors.error_code%TYPE;                      --Variable to store Error Code of the record
gc_error_msg             xxha_common_errors.error_msg%TYPE;                       --Variable to store Error Message of the record
gc_comments              xxha_common_errors.comments%TYPE;                        --Variable to store Error Comments of the record
gc_table_name            xxha_common_errors.table_name%TYPE;                      --Variable to store Table Name
gc_attribute1            xxha_common_errors.attribute1%TYPE;                      --Variable to store Attribute1
gc_attribute2            xxha_common_errors.attribute2%TYPE;                      --Variable to store Attribute2
gc_attribute3            xxha_common_errors.attribute3%TYPE;                      --Variable to store Attribute3
gc_attribute4            xxha_common_errors.attribute4%TYPE;                      --Variable to store Attribute4
gc_attribute5            xxha_common_errors.attribute5%TYPE;                      --Variable to store Attribute5
gn_request_id            xxha_common_errors.request_id%TYPE                       := FND_GLOBAL.CONC_REQUEST_ID;           -- Variable to store the Concurrent Request Id
gc_record_identify       xxha_common_errors.record_identifier%TYPE                :='Purchase Order';                         -- Variable to store the Record identifier of the Program that appears as Column in the Common Error Report
gc_program_name          VARCHAR2(1000)                                           :='Purchase Order Conversion';              -- Variable to store the Concurrent Program Name that appears as Heading in the Common Error Report
gc_operating_unit        po_headers_ALL.org_id%TYPE                               := FND_PROFILE.VALUE('ORG_ID');          -- Variable to store the Operating Unit
gc_operating_unit_name   hr_operating_units.name%TYPE ;                                      -- Variable to store the Operating Unit Name
gn_sob_id                gl_sets_of_books.set_of_books_id%TYPE                    := FND_PROFILE.VALUE('GL_SET_OF_BKS_ID');-- Variable to store the Set Of Books Id
gc_freight_terms_code    FND_lookups.lookup_code%TYPE                             :='TBD';                                 -- Variable to store the default freight terms look up code
gc_freight_terms_type    FND_lookups.lookup_type%TYPE                             :='FREIGHT_TERMS';                       -- Variable to store the freight terms look up type
gc_shipping_method_type  fnd_lookup_values_vl.lookup_type%TYPE                    :='SHIP_METHOD';                         -- Variable to store the default freight terms look up type
gc_payment_terms_code    ra_terms_vl.name%TYPE                                    :='IMMEDIATE';                           -- Variable to store the default payment terms code if given values are invalid
gc_operation_code        oe_headers_iface_all.operation_code%TYPE                 :='CREATE';                              -- Variable to store the default Operation Code
gc_document_type_code    po_headers_interface.document_type_code%TYPE             :='STANDARD';    -- Variable to store the default PO type
gc_approval_status       po_headers_interface.approval_status%type                := 'APPROVED'; -- default approval status for PO
gc_incomplete_status     po_headers_interface.approval_status%type                := 'INCOMPLETE'; -- default approval status for PO
gc_action                po_lines_interface.action%type                           := 'ORIGINAL'; --DEfault action for line i.e. original for new line creation
gc_conversion_type       gl_daily_rates.conversion_type%type                      :='Corporate';                           -- Variable to store the default Conversion type
gc_con_prg_shot_name     fnd_concurrent_programs.concurrent_program_name%TYPE     :='XXHA_PURCHASE_ORDER_CONV';               -- Variable to store the Concurrent Program Short Name
gn_user_id               fnd_user.user_id%TYPE                                    := FND_GLOBAL.USER_ID; -- Variable to store the User Id
gc_record_error          xxha_po_conv_header_stg.record_status%type              :='E';
gc_record_success        xxha_po_conv_header_stg.record_status%type              :='S';
gc_record_interfaced     xxha_po_conv_header_stg.record_status%type              :='I';
gc_debug_flag            VARCHAR2(1);                                             --Variable to store the Debug Flag
gc_log_msg               VARCHAR2(3000);                                          --Variable to store the Log Message
gc_status                VARCHAR2(2);                                             --Variable to store status of data insertion in Common Error table
gc_sysdate               date                                                     := trunc(SYSDATE);
gv_commit_limit          NUMBER                                                   := 1000;

  /* TODO enter package declarations (types, exceptions, methods etc) here */
---------------------------------------------------------
   -- Proc 1. Map procedure
--------------------------------------------------------
    PROCEDURE map_Val_po_data( p_error_status           OUT VARCHAR2);
---------------------------------------------------------
   -- Proc 3. Load PO procedure
--------------------------------------------------------
PROCEDURE load_standard_data(
      p_error_status           OUT VARCHAR2);

---------------------------------------------------------
--    Proc 4.
--    "main_proc" is the main procedure that calls
--    the mapping, validate, loading
--    The p_entity_name is 'PO' for Standard PO.
--    This loads the Standard PO into the Interface tables.
---------------------------------------------------------


      PROCEDURE main_proc(
      ERRBUF                  OUT VARCHAR2 ,
      RETCODE                 OUT VARCHAR2,
      p_debug_flag          IN  VARCHAR2 DEFAULT 'N',
      p_purge_flag             IN  VARCHAR2 DEFAULT 'N',
      p_load_flag           IN  VARCHAR2 DEFAULT 'N',
      p_reset_errors           IN  VARCHAR2 DEFAULT 'N');



PROCEDURE purge_staging_table (
         p_ou_org_id  in  number
        ) ;
------------------------------------------------------------------
--  update_received_qty procedure is used to update the received quantity with the quantity ordered
--  these po's are the dummy po's created to track the un accounted PO's
--  PO will be identified with the comment field in the PO header, containing text
--  'PO Received but Not Invoiced'
------------------------------------------------------------------
PROCEDURE update_received_qty (
         ERRBUF                  OUT VARCHAR2 ,
         RETCODE                 OUT VARCHAR2
         --p_ou_org_id  in  number
        );

END XXHA_PO_CONVERSION_PKG;

/


CREATE OR REPLACE PACKAGE BODY XXHA_PO_CONVERSION_PKG AS
   l_start_program_time     VARCHAR2(30)  := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');
   l_end_program_time    VARCHAR2 (30) := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');
   --add operating unit code as another field in the data file like US/SLD
   --Ebiz_Requestor get the employee number from apps
-- +==============================================================================
-- | Name       : purge_staging_table
-- |
-- | Description: Procedure to purge staging table records
-- |
-- | Call From  : Loader Concurrent Program
-- |
-- | Parameters:
-- |   IN: p_file_name
-- |       p_request_id
-- |       p_ou_org_id
-- |  OUT:
-- |
-- | Scope: PUBLIC
-- |
-- +==============================================================================
PROCEDURE purge_staging_table (
         p_ou_org_id  in  number
        ) is
begin
   DELETE  xxha_po_bpcs_stg8
   WHERE ebiz_org in (SELECT organization_code FROM
org_organization_definitions where operating_unit = p_ou_org_id)
  and      record_status = 'S';
   commit;
END purge_staging_table;
-- +========================================================================+
-- | Name       :   INSERT_ERROR_MSG                                        |
-- | Description:   Procedure to call xxsc_common_utilities                 |
-- |                to insert errors into error table                       |
-- |                records                                                 |
-- |                                                                        |
-- | Call From  :   The Procedure is called                                               |
-- | Parameters :   NONE                                                    |
-- | Returns    :   NONE                                                    |
-- |                                                                        |
-- |                                                                        |
-- +========================================================================+
PROCEDURE INSERT_ERROR_MSG
IS
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gn_request_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                            );
FND_FILE.PUT_LINE(FND_FILE.LOG,'insert cmpleted' ||gn_record_number);
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in xxha_common_utilities_pkg.INSERT_ERROR_MSG. Error is: ' ||SQLERRM);
END INSERT_ERROR_MSG;
PROCEDURE reset_record_status
IS
begin
    UPDATE xxha_po_conv_header_stg
       SET record_status = null
           ,error_message = NULL
     WHERE record_status = gc_record_error
     and org_id = gc_operating_unit;
    UPDATE xxha_po_conv_lines_stg2
       SET record_status = null
           ,error_message = NULL
    where interface_header_id in ( select interface_header_id
                                 FROM xxha_po_conv_header_stg
                                WHERE record_status is null );
    UPDATE xxha_po_conv_distr_stg
       SET record_status = null
           ,error_message = NULL
     where interface_header_id in ( select interface_header_id
                                 FROM xxha_po_conv_header_stg
                                WHERE record_status is null );
  fnd_concurrent.af_commit;
EXCEPTION
  WHEN OTHERS THEN
    RAISE;
end reset_record_status;
PROCEDURE Load_temp_data(l_operating_unit IN varchar2)
IS
l_po_number Varchar2(6);
l_stg_headers_next  Number;
l_stg_lines_next    Number;
l_stg_records       number;
l_stg_header_records number;
l_stg_line_records   number;
l_supplier_number po_vendors.segment1%type;
l_comment           po_headers_interface.comments%type;
v_org_id   number;
v_set_of_books_id VARCHAR2(50);
   CURSOR l_get_po_cur (l_operating_unit varchar2)
      IS
         select  distinct PO_NUMBER,TYPE_OF_PO,DOC_DATE,SUBSTR(SUPPLIER_PLANT,1,6) LEGACY_SUPP_CODE,SUPPLIER_NUMBER,SUPPLIER_NAME,EBIZ_FOB_CODE,
            ebiz_ship_to_location,buyer,ebiz_currency_code,ebiz_terms_code,ebiz_org,supplier_site,po_description,ACCEPTANCE_REQUIRED
     from xxha_po_bpcs_stg8
      WHERE DECODE(Ebiz_ship_to_location,'USJ1','PRR','USC1','COV','USC2','TJP','USE2','RXP') in (SELECT organization_code
                          FROM  org_organization_definitions
                        where operating_unit = l_operating_unit)  --gc_operating_unit_name
         and (HAEZRC = 'I' or HAEZRC = 'E')
       --  AND QTY_TO_DELIVERED > 0
         AND record_status IS NULL;
CURSOR l_get_po_line_cur(l_po_number Varchar2 ,l_operating_unit varchar2)
      IS
         select *
           from xxha_po_bpcs_stg8
      WHERE DECODE(Ebiz_ship_to_location,'USJ1','PRR','USC1','COV','USC2','TJP','USE2','RXP')  in (SELECT organization_code
                            FROM org_organization_definitions
                          where operating_unit = l_operating_unit)  --gc_operating_unit
      and  po_number = l_po_number
      and (HAEZRC = 'I' or HAEZRC = 'E')
        -- AND QTY_TO_DELIVERED > 0
      and record_status is null;
begin
Fnd_File.PUT_LINE(Fnd_File.LOG,'l_operating_unit'||l_operating_unit);
Fnd_File.PUT_LINE(Fnd_File.LOG,'l_po_number'||l_po_number);
l_comment := NULL;
Fnd_File.PUT_LINE(Fnd_File.LOG,'In temp data load 1');
select name
INTO gc_operating_unit_name
from hr_operating_units
WHERE organization_id = gc_operating_unit;
FND_FILE.PUT_LINE(FND_FILE.log,'gc_operating_unit_name'||GC_OPERATING_UNIT_NAME);
update XXHA_PO_BPCS_STG8 set CHARGE_ACCOUNT=SUBSTR((CHARGE_ACCOUNT),1,46)
where CHARGE_ACCOUNT is not null;
select count(*)
into l_stg_records
from xxha_po_bpcs_stg8
WHERE DECODE(Ebiz_ship_to_location,'USJ1','PRR','USC1','COV','USC2','TJP','USE2','RXP') in (SELECT organization_code FROM
org_organization_definitions where operating_unit=l_operating_unit) --gc_operating_unit_name
AND record_status IS NULL;
Fnd_File.PUT_LINE(Fnd_File.LOG,'l_stg_records'||l_stg_records);
l_stg_header_records := 0;
l_stg_line_records   := 0;
    FOR l_po_rec IN l_get_po_cur(gc_operating_unit)  LOOP
     SELECT xxha_po_headers_interface_s.nextval
        INTO l_stg_headers_next
        from dual;

  insert into xxha_po_conv_header_stg
                                    (interface_header_id,
                                     document_type_code,
                                     CURRENCY_CODE,
                                     RATE_TYPE,
                                     RATE_TYPE_CODE,
                                     rate_date,
                                     agent_name,
                                     VENDOR_NAME,
                                     vendor_site_code,
                                     vendor_contact,
                                     ship_to_location,
                                     terms_code,
                                     fob,
                                     approval_status,
                                     document_num,
                                     vendor_doc_num,
                                     creation_date,
                                     created_by,
                                     last_update_date,
                                     last_updated_by,
                                     org_id,
                                     REQUEST_ID,
                                  --   attribute1,
                                     comments)
               values
                                    (l_stg_headers_next,
                                     decode(l_po_rec.type_of_po,'NB',gc_document_type_code,'LP',gc_document_type_code,'FO',gc_document_type_code),
                                     L_PO_REC.EBIZ_CURRENCY_CODE,
                                     DECODE(L_PO_REC.EBIZ_CURRENCY_CODE,'USD',NULL,'Corporate'),
                                     DECODE(L_PO_REC.EBIZ_CURRENCY_CODE,'USD',NULL,'Corporate'),
                                     DECODE(L_PO_REC.EBIZ_CURRENCY_CODE,'USD',NULL,L_PO_REC.DOC_DATE),
                                    -- decode(L_PO_REC.EBIZ_CURRENCY_CODE,'USD',null,'29-DEC-2012'),
                                     (L_PO_REC.BUYER),--'468','213094','477','214161','481','213020','529','213543','451','212946','449','213420','450','213365','452','213877','454','213579',
--'455','213519','457','212901','460','212901','678','212901','446','212901','458','214161','528','212901','676','214161','677','214161'),
                              --       L_PO_REC.SUPPLIER_NAME,
                                     --L_PO_REC.SUPPLIER,
                                     L_PO_REC.SUPPLIER_NUMBER,
                                     DECODE(L_PO_REC.SUPPLIER_SITE,'2-Way','P','3-Way','R'),
                                     --l_po_rec.legacy_supp_code,
                                     L_PO_REC.SUPPLIER_NUMBER,
                                     DECODE(L_PO_REC.EBIZ_SHIP_TO_LOCATION,'USJ1','PRR','USC1','COV','USC2','TJP','USE2','RXP'),
                                     L_PO_REC.EBIZ_TERMS_CODE,--'Z110','1% 10 Days/Net 30','Z1N3','1% 10 Days/Net 30','NT00','Immediate','Z087','Immediate','NT10','Net 10','NT15','Net 15','NT30','Net 30','NT40','Net 40','NT45','Net 45',
--'NT50','Net 50','NT60','Net 60','29','Net 21','21','2% 10 Days/Net 30','IN14','10% Imm/Net 30','','Net 15','IN32','Immediate','NT55','Net 55','NT70','Net 70','Z083','Immediate','Z099','Net 45','Z553','Net 30',l_po_rec.ebiz_terms_code),
                                     l_po_rec.ebiz_fob_code,
                                     GC_APPROVAL_STATUS,
                                     L_PO_REC.PO_NUMBER,
                                --     LPAD(L_PO_REC.PO_NUMBER,(length(L_PO_REC.PO_NUMBER)+1),'A'),
                                --       replace(L_PO_REC.PO_NUMBER,'S','B'),
                                     L_PO_REC.PO_NUMBER,
                            --         lpad(l_po_rec.po_number,(length(l_po_rec.po_number)+1),'A'),
                                 --     replace(L_PO_REC.PO_NUMBER,'S','B'),
                                     l_po_rec.doc_date,
                                     gn_user_id,
                                     l_po_rec.doc_date,
                                     gn_user_id,
                                     gc_operating_unit,
                                     GN_REQUEST_ID,
                                  --   decode(l_po_rec.record_id,'P2','P2',null),
                                     --decode(l_po_rec.ACCEPTANCE_REQUIRED,'XX','PO Received but Not Invoiced',decode(l_po_rec.po_description,'0',null,l_po_rec.po_description)));
                                     decode(l_po_rec.po_description,'0',null,l_po_rec.po_description));
l_stg_header_records := l_stg_header_records+1;
Fnd_File.PUT_LINE(Fnd_File.LOG,'After header data load ');
   FOR l_po_line_rec IN l_get_po_line_cur(l_po_rec.po_number, gc_operating_unit ) LOOP
        Fnd_File.PUT_LINE(Fnd_File.LOG,'In temp data LINE load ');
   SELECT xxha_po_lines_interface_s.nextval
        INTO l_stg_lines_next
        FROM DUAL;
       fnd_file.put_line(fnd_file.log,'At Line temp data LINE load');
   insert into xxha_po_conv_lines_stg2
                                     (interface_line_id,
                                      interface_header_id,
                                      action,
                                      line_num,
                                      shipment_num,
                                      item,
                                      item_description,
                                      item_revision,
                                      category,
                                      unit_of_measure,
                                      unit_price,
                                      quantity,
                                      per,
                                      PROMISED_DATE,
                                      need_by_date,
                                      INSPECTION_REQUIRED_FLAG,
                                      receipt_required_flag,
                                      creation_date,
                                      created_by,
                                      last_update_date,
                                      last_updated_by ,
                                      request_id)
               values                (l_stg_lines_next,
                                      l_stg_headers_next,
                                      gc_action,
                                      to_number(l_po_line_rec.line_number),
                                      TO_NUMBER(L_PO_LINE_REC.LINE_NUMBER),
                                 --     l_po_line_rec.item,
                                     decode(l_po_line_rec.item,'0',null,l_po_line_rec.item),
                                      L_PO_LINE_REC.ITEM_DESCRIPTION,
                                 --    l_po_line_rec.ebiz_item_revision,
                                      DECODE(L_PO_LINE_REC.EBIZ_ITEM_REVISION,'0',NULL,L_PO_LINE_REC.EBIZ_ITEM_REVISION),
                                  --   l_po_line_rec.ebiz_item_category,
                                      DECODE(L_PO_LINE_REC.EBIZ_ITEM_CATEGORY,'0',NULL,L_PO_LINE_REC.EBIZ_ITEM_CATEGORY),
                                      l_po_line_rec.ebiz_uom,--'EA','Each','ROL','ROL','FT','Foot','KG','Kg','FT2','Square Feet','FT3','Cubic Ft.','LB','Pounds','HR','Hour','AU','Amount','GAL','GL','ML','ML','DZ','DO','GAL','GL','YD','Yard','G','Grams','L','L','M','m','PAC','Pak','PAL','Pal','CV','Case','H','Hour',l_po_line_rec.ebiz_uom),--'Ea',
                                      TO_NUMBER(L_PO_LINE_REC.UNIT_PRICE),
                                      --decode(l_po_line_rec.ACCEPTANCE_REQUIRED,'XX',l_po_line_rec.to_be_inv,to_number(l_po_line_rec.qty_to_delivered)),
                                      l_po_line_rec.QUANTITY,
                                      L_PO_LINE_REC.PER,
                                      --L_PO_LINE_REC.PROMISED_DATE,
                                      decode(L_PO_LINE_REC.PROMISED_DATE,'0',null,L_PO_LINE_REC.PROMISED_DATE),
                                      l_po_line_rec.need_by_date,
                                --       decode(l_po_line_rec.need_by_date,'0',to_char(L_PO_LINE_REC.PROMISED_DATE)),
                                      'N',
                                      decode(l_po_line_rec.invoice_match_option,'2-Way','N','3-Way','Y'),
                                      l_po_line_rec.doc_date,
                                      gn_user_id,
                                      l_po_line_rec.doc_date,
                                      gn_user_id,
                                      gn_request_id
                );
 fnd_file.put_line(fnd_file.log,'At distr temp data load');
    insert into xxha_po_conv_distr_stg
                                     (interface_line_id,
                                      interface_header_id,
                                      interface_distribution_id,
                                      distribution_num,
                                      ORG_ID,
                                --      deliver_to_person_full_name,
                                      set_of_books_id,
                                      CHARGE_ACCOUNT,
                                      ACCURAL_ACCOUNT,
                                      creation_date,
                                      created_by,
                                      last_update_date,
                                      last_updated_by,
                                      REQUEST_ID,
                                      attribute1,
                                      attribute2
                                     )
                  values             (l_stg_lines_next,
                                      l_stg_headers_next,
                                      l_stg_lines_next,
                                      1,
                                      GC_OPERATING_UNIT,
                                 --     l_po_line_rec.req_number,
                                      GN_SOB_ID,
                                      --L_PO_LINE_REC.CHARGE_ACCOUNT,
                                      DECODE(L_PO_LINE_REC.ACCEPTANCE_REQUIRED,'XX',null,L_PO_LINE_REC.CHARGE_ACCOUNT),
                                      decode(L_PO_LINE_REC.ACCEPTANCE_REQUIRED,'XX',L_PO_LINE_REC.CHARGE_ACCOUNT,null),
                                   --   replace(L_PO_LINE_REC.CHARGE_ACCOUNT,chr(13),''),
                                      l_po_line_rec.doc_date,
                                      gn_user_id,
                                      l_po_line_rec.doc_date,
                                      GN_USER_ID,
                                      GN_REQUEST_ID ,
                                      l_po_line_rec.cost_ctr,
                                     l_po_line_rec.order_val  );
 Fnd_File.PUT_LINE(Fnd_File.LOG,'After distr temp data load');
 l_stg_line_records   := l_stg_line_records+1;
   update xxha_po_bpcs_stg8
      set record_status = gc_record_success
    where po_number = l_po_line_rec.po_number;
   END Loop;
    END LOOP;
    Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'***********************Staging table Load report  *****************');
    Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of records in primary staging'||l_stg_records);
    Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of header PO records inserted in header staging'||l_stg_header_records);
    Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of header PO records inserted in lines staging'||l_stg_line_records);
    Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of header PO records inserted in distribution staging'||l_stg_line_records);
    Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'***********************Staging table Load report end *****************');
  --COMMIT;
  fnd_concurrent.af_commit;
EXCEPTION
  WHEN OTHERS THEN
   Fnd_File.PUT_LINE(Fnd_File.LOG,'eXCEPTION IN tEMP DATA LOAD'||sqlerrm);
    RAISE;
END Load_temp_data;
PROCEDURE map_Val_po_data( p_error_status           OUT VARCHAR2)
   is
   l_header_status          xxha_po_conv_header_stg.record_status%type :=null;
   l_head_app_status          po_headers_interface.approval_status%type :=null;
   l_line_status          xxha_po_conv_header_stg.record_status%type :=null;
   l_distr_status          xxha_po_conv_header_stg.record_status%type :=null;
   l_vendor_id             po_headers_interface.vendor_id%type;
   l_vendor_site_id        po_headers_interface.vendor_site_id%type;
   l_fob                   po_headers_interface.fob%type;
   l_term_id               ap_terms.term_id%type;
   L_CURRENCY_CODE         FND_CURRENCIES.CURRENCY_CODE%TYPE;
   l_rate                  GL_DAILY_RATES_V.show_conversion_rate%type;
   l_category_id           mtl_categories.category_id%type;
   l_category_id1           mtl_categories.category_id%type;
   L_UOM_CODE              MTL_UNITS_OF_MEASURE.UOM_CODE%TYPE;
   l_uom                   MTL_UNITS_OF_MEASURE.UNIT_OF_MEASURE%TYPE;
   l_bpcs_uom              mtl_units_of_measure.uom_code%type;
   l_location_id           hr_locations.location_id%type;
   l_agent_id              po_agents.agent_id%type;
   l_agent_id1              po_agents.agent_id%type;
   l_freight_carrier       wsh_carriers.freight_code%type;
   l_item_id               mtl_system_items.inventory_item_id%type;
   l_item_desc             mtl_system_items.description%type;
   l_organization_id       mtl_parameters.organization_id%type;
   L_CHARGE_ACC_ID         GL_CODE_COMBINATIONS_KFV.CODE_COMBINATION_ID%TYPE;
   l_accural_acc_id         gl_code_combinations_kfv.code_combination_id%type;
   l_rec_error             xxha_po_conv_header_stg.error_message%type;
   l_header_err        xxha_po_conv_header_stg.error_message%type;
   l_revision              mtl_item_revisions.revision%type;
   l_purch_flag            mtl_system_items.purchasing_enabled_flag%TYPE;
   l_operating_unit        org_organization_definitions.operating_unit%type;
   l_org_code              org_organization_definitions.organization_code%type;
   l_coa_id                gl_sets_of_books.chart_of_accounts_id    % type;
   l_category              varchar2(40);
   temp                    number;
         -- open cursor to get the headers info
      CURSOR l_po_header_cur
      IS
      select *
      FROM
      xxha_po_conv_header_stg xhs
      where org_id = gc_operating_unit --Modified Venkatesh
      and record_status is null;
      -- open cursor to get the headers info
      CURSOR l_po_line_cur (l_po_header_id NUMBER)
      IS
      select *
      from
      xxha_po_conv_lines_stg2 xhs
      where interface_header_id = l_po_header_id
      and record_status is null;
      CURSOR l_po_dist_cur (l_po_header_id NUMBER, l_po_line_id NUMBER)
      IS
      select *
      from
      xxha_po_conv_distr_stg xds
      where interface_header_id = l_po_header_id
      and   interface_line_id = l_po_line_id
      and record_status is null;
   BEGIN
      -- initialize hard coded values for mapping
      -- add other hard coded values here
      -- end of initilize hard coded values
      -- Update default values and direct mapping values
/*
                               M A P  and V A L I D A T E   P U R C H A S E   O R D E R S
*/
            p_error_status := null;
            gc_log_msg:='START of Mapping-Validation Process'||gc_operating_unit;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
  FOR l_po_headers_rec IN l_po_header_cur
     LOOP
     gc_log_msg:='before initiation';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
     l_header_status      := gc_record_success;
     gc_error_msg         := null;
     gc_error_code        := null;
     gc_comments          := null;
     gn_record_number     := l_po_headers_rec.document_num;
     gc_record_identifier := l_po_headers_rec.interface_header_id;
     l_head_app_status    := gc_approval_status;
     gc_log_msg:='in the loop';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
     l_rec_error          := null;
     l_header_err         := null;
     gc_log_msg:='after assignment';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   --Initialize header variables
     l_vendor_id          := null;
     l_vendor_site_id     := null;
     l_location_id        := null;
     l_agent_id           := null;
     l_fob                := null;
     l_term_id            := null;
     l_freight_carrier    := null;
     L_CURRENCY_CODE      := NULL;
     l_rate               := null;
     l_organization_id    := null;
     l_operating_unit     := null;
     l_coa_id             := null;
        BEGIN
           --1. Organization code
           begin
           select ood.operating_unit,ood.organization_code,ood.organization_id
           into   l_operating_unit,l_org_code,l_organization_id
           from mtl_parameters mp,
                org_organization_definitions ood
           where 1 = 1
           and mp.organization_code = l_po_headers_rec.ship_to_location
           and mp.organization_id = ood.organization_id;
           IF l_operating_unit IS NULL THEN
           gc_error_code       :='PO01';
           gc_error_msg        :='Organization Code : '||l_po_headers_rec.ship_to_location||' doesnot have valid in Oracle';
           gc_comments         :='Please Give a Valid Organization Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END IF;
           EXCEPTION WHEN OTHERS THEN
           gc_error_code       :='PO01';
           gc_error_msg        :='Organization Code : '||l_po_headers_rec.ship_to_location||' doesnot have valid in Oracle'||Sqlerrm;
           gc_comments         :='Please Give a Valid Organization Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           end ;

           --2. Vendor ID
          /* BEGIN
           select vendor_id
           INTO   l_vendor_id
           FROM po_vendors pv
           where 1 = 1
         --  and UPPER(PV.VENDOR_NAME) = UPPER(TRIM(' ' from L_PO_HEADERS_REC.VENDOR_NAME))
           and pv.segment1 = trim(' ' from l_po_headers_rec.vendor_name)
           and nvl(end_date_active,trunc(sysdate)) >=trunc(sysdate);
           if l_vendor_id is null then
           GC_ERROR_CODE       :='PO02';
           gc_error_msg        :='Vendor : '||l_po_headers_rec.vendor_name||' is not have valid in Oracle';
           gc_comments         :='Please Give a Valid vendor';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END IF;
           EXCEPTION WHEN OTHERS THEN
           GC_ERROR_CODE       :='PO02';
           gc_error_msg        :='Vendor : '||l_po_headers_rec.vendor_name||' is not have valid in Oracle'||Sqlerrm;
           gc_comments         :='Please Give a Valid vendor';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           L_HEADER_STATUS := GC_RECORD_ERROR;
           END;*/

           --3. Vendor Site ID , first returned vendor site will be used in that operating unit
           --P - 2-Way , R - 3-Way
           BEGIN
           SELECT VENDOR_SITE_ID,vendor_id
           INTO   l_vendor_site_id,l_vendor_id
           FROM po_vendor_sites_all pvs
           WHERE 1 = 1
          -- and pvs.vendor_id = l_vendor_id
           AND PVS.ORG_ID = GC_OPERATING_UNIT
           AND PVS.ATTRIBUTE1 = L_PO_HEADERS_REC.VENDOR_CONTACT
           and PVS.MATCH_OPTION = L_PO_HEADERS_REC.vendor_site_code
           and pvs.purchasing_site_flag = 'Y'
           and nvl(inactive_date,trunc(sysdate)) >=trunc(sysdate)
           AND ROWNUM = 1;
           if l_vendor_site_id is null then
           GC_ERROR_CODE       :='PO03';
           GC_ERROR_MSG        :='Vendor Site  : for '||L_PO_HEADERS_REC.VENDOR_NAME||'and sap code '||l_po_headers_rec.vendor_contact||'  doesnot have valid purchasing site defined in Oracle';
           gc_comments         :='Invalid vendor site';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END IF;
           exception when others then
           GC_ERROR_CODE       :='PO03';
           gc_error_msg        :='Vendor Site  : for '||L_PO_HEADERS_REC.VENDOR_NAME||'and sap code '||l_po_headers_rec.vendor_contact||'  doesnot have valid purchasing site defined in Oracle'||Sqlerrm;
           gc_comments         :='Please Give a Valid vendor site';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           end ;

           --4. Ship To Location ID
           BEGIN
           if (l_po_headers_rec.ship_to_location <> 'TJP' and l_po_headers_rec.ship_to_location <> 'COV') then
           SELECT location_id
           into   l_location_id
           FROM hr_locations
           WHERE 1 = 1
           AND inventory_organization_id = (SELECT organization_id
                                            from org_organization_definitions
                                            where organization_code = upper(l_po_headers_rec.ship_to_location))
           AND SHIP_TO_SITE_FLAG = 'Y';
           elsif l_po_headers_rec.ship_to_location = 'TJP' THEN
           SELECT location_id
           into   l_location_id
           FROM hr_locations
           WHERE 1 = 1
           AND inventory_organization_id = (SELECT organization_id
                                            from org_organization_definitions
                                            where organization_code = upper(l_po_headers_rec.ship_to_location))
           and ship_to_site_flag = 'Y'
           AND TOWN_OR_CITY = 'San Diego';
           elsif l_po_headers_rec.ship_to_location = 'COV' THEN
           SELECT location_id
           into   l_location_id
           FROM hr_locations
           WHERE 1 = 1
           AND inventory_organization_id = (SELECT organization_id
                                            from org_organization_definitions
                                            where organization_code = upper(l_po_headers_rec.ship_to_location))
           AND SHIP_TO_SITE_FLAG = 'Y'
           and location_code = 'US HAE Mfg Inc Covina';

           END IF;
           gc_log_msg:='after location';
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
           if l_location_id  is null then
           gc_error_code       :='PO04';
           gc_error_msg        :='Ship To location  : '||l_po_headers_rec.ship_to_location||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Ship to location ';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           END IF;
           EXCEPTION WHEN OTHERS THEN
           gc_error_code       :='PO04';
           gc_error_msg        :='Ship To location  : '||l_po_headers_rec.ship_to_location||' is not valid in Oracle'||Sqlerrm;
           gc_comments         :='Please Give a Valid Ship to location ';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_header_status := gc_record_error;
           end ;

           -- 5. Agent ID
           --Employee number of the requester is better to get in the file
       begin
          SELECT poa.agent_id
          INTO l_agent_id
          FROM per_people_f ppf,
                PO_AGENTS POA
          WHERE --ppf.employee_number = l_po_headers_rec.agent_name
          ppf.full_name = l_po_headers_rec.agent_name
          AND PPF.PERSON_ID = POA.AGENT_ID
          --AND TRUNC(SYSDATE) BETWEEN to_date(PPF.START_DATE,'DD-MON-YY') AND  to_date(nvl(PPF.EFFECTIVE_END_DATE,trunc(sysdate)),'DD-MON-YY')
          and (trunc(SYSDATE) BETWEEN trunc(ppf.start_date)
          AND TRUNC(NVL(PPF.EFFECTIVE_END_DATE,SYSDATE)));
         gc_log_msg:='after agent';
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         if l_agent_id is null  then
         gc_error_code       :='PO05';
         gc_error_msg        :='Buyer-requester  : '||l_po_headers_rec.agent_name||' is not valid in Oracle';
         gc_comments         :='Please Give a Valid buyer-requester Name';
         l_rec_error         := l_rec_error||' '||gc_error_msg;
         INSERT_ERROR_MSG;
         l_header_status := gc_record_error;
         END IF;
         exception when others then
         gc_error_code       :='PO05';
         gc_error_msg        :='Buyer-requester  : '||l_po_headers_rec.agent_name||' is not valid in Oracle'||Sqlerrm;
         gc_comments         :='Please Give a Valid buyer-requester Name';
         l_rec_error         := l_rec_error||' '||gc_error_msg;
         INSERT_ERROR_MSG;
         l_header_status := gc_record_error;
         end ;

         --  6.FOB
        -- IF l_po_headers_rec.fob IS NOT NULL THEN
         if to_char(L_PO_HEADERS_REC.FOB) <> to_char('0') then
           begin
            select plc.lookup_code
            into l_fob
            FROM po_lookup_codes plc
            WHERE plc.lookup_type = 'FOB'
            and (plc.inactive_date > sysdate or plc.inactive_date is null)
            and upper(plc.lookup_code) = upper(l_po_headers_rec.fob);
            gc_log_msg:='after fob';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            if l_fob is null then
            gc_error_code       :='PO06';
            gc_error_msg        :='FOB code  : '||l_po_headers_rec.fob||' is not valid in Oracle';
            gc_comments         :='Please Give a Valid FOB Name';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            insert_error_msg;
            l_header_status := gc_record_error;
            end if;
            exception when others then
            gc_error_code       :='PO06';
            gc_error_msg        :='FOB code  : '||l_po_headers_rec.fob||' is not valid in Oracle'||sqlerrm;
            gc_comments         :='Please Give a Valid FOB Name';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            insert_error_msg;
            l_header_status := gc_record_error;
            end;
            else
              l_fob := null;
            end if;

           --7. Terms ID
           Begin
            SELECT term_id
            INTO l_term_id
            FROM ap_terms
            WHERE upper(name) LIKE upper(l_po_headers_rec.terms_code)
            AND enabled_flag = 'Y'
            AND ((SYSDATE BETWEEN start_date_active AND end_date_active)
            OR (SYSDATE >= START_DATE_ACTIVE AND END_DATE_ACTIVE IS NULL))
            and rownum < 2;
            if l_term_id is null then
            gc_error_code       :='PO07';
            gc_error_msg        :='Terms code  : '||l_po_headers_rec.terms_code||' is not valid in Oracle';
            gc_comments         :='Please Give a Valid Terms Code';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            insert_error_msg;
            l_header_status := gc_record_error;
            end if;
            exception when others then
            gc_error_code       :='PO07';
            gc_error_msg        :='Terms code  : '||l_po_headers_rec.terms_code||' is not valid in Oracle'||sqlerrm;
            gc_comments         :='Please Give a Valid Terms Code';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            insert_error_msg;
            l_header_status := gc_record_error;
            end;

     --8. Currency Code
         Begin
            select currency_code
            into l_currency_code
            from fnd_currencies  fc
            where fc.enabled_flag = 'Y'
            and   fc.currency_code = l_po_headers_rec.currency_code;
             IF l_currency_code is null THEN
            select currency_code
            into l_currency_code
            from fnd_currencies  fc
            where fc.enabled_flag = 'Y'
            and   fc.currency_code = 'USD';
            gc_error_code       :='PO08';
            gc_error_msg        :='Currency Code is set to :USD ';
            gc_comments         :='Please change if not correct';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            INSERT_ERROR_MSG;
            l_header_status := 'W';
            end if;
            exception when others then
            gc_error_code       :='PO08';
            gc_error_msg        :='Currency Code  : '||l_po_headers_rec.currency_code||' is not valid in Oracle'||sqlerrm;
            gc_comments         :='Please Give a Valid Currency Code';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            insert_error_msg;
            l_header_status := gc_record_error;
            END;

            IF l_po_headers_rec.currency_code != 'USD' then
            BEGIN
            SELECT 1
            into l_rate
            FROM GL_DAILY_RATES_V
            WHERE FROM_CURRENCY=l_po_headers_rec.currency_code
            AND TO_CURRENCY='USD'
            --AND CONVERSION_DATE='29-DEC-2012'--sysdate
            AND trunc(CONVERSION_DATE)=trunc(l_po_headers_rec.rate_date)
            AND CONVERSION_TYPE='Corporate';
            IF L_RATE IS NULL THEN
            GC_ERROR_CODE       :='PO081';
            gc_error_msg        :='Conversion rate from Currency Code is not valid ';
            gc_comments         :='Please change if not correct';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            INSERT_ERROR_MSG;
            l_header_status := 'W';
            end if;
            exception when others then
            GC_ERROR_CODE       :='PO08';
            gc_error_msg        :='Conversion rate From Currency : '||l_po_headers_rec.currency_code||' is not valid in Oracle'||sqlerrm;
            gc_comments         :='Please Give a Valid Currency Code';
            l_rec_error         := l_rec_error||' '||gc_error_msg;
            INSERT_ERROR_MSG;
            l_header_status := gc_record_error;
            END;
            end if;

        p_error_status := l_header_status;
        gc_log_msg:='before header update';
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
        l_header_err      := l_rec_error;
       for l_po_lines_rec in l_po_line_cur (l_po_headers_rec.interface_header_id) loop
        l_category_id  := null;
        l_category_id1 := null;
        l_item_id      := null;
        l_revision     := null;
        l_item_desc    := null;
        L_UOM_CODE     := NULL;
        l_uom          := null;
        l_purch_flag   := null;
        l_bpcs_uom     := null;
       BEGIN
       gc_log_msg:='Inside lines validation';
       xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
       l_line_status   :=null;
       l_rec_error     :=null;
       gc_record_identifier := l_po_lines_rec.interface_line_id;

      if  L_PO_LINES_REC.ITEM is null   then
      --  IF  to_char(l_po_lines_rec.item) = to_char('0')   THEN
         begin
           gc_log_msg:='before Category';
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
           l_item_id  := null;
           l_revision := null;
           l_item_desc := l_po_lines_rec.item;
          SELECT category_id
          into l_category_id
          FROM mtl_categories_b mcb
          where (trunc(mcb.disable_date) > trunc(sysdate) or mcb.disable_date is null)
          and  upper(mcb.segment1) = upper(nvl(l_po_lines_rec.category,'MISC'));
          if l_category_id is null then
           gc_error_code       :='PO09';
           gc_error_msg        :='Category Code  : '||l_po_lines_rec.Category||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Item category Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
           END IF;
           exception when no_data_found then
           gc_error_code       :='PO09';
           gc_error_msg        :='Category Code  : '||l_po_lines_rec.Category||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Item category Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
           END        ;

else
          BEGIN
          gc_log_msg:='before Item';
           XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(GC_DEBUG_FLAG,GC_LOG_MSG);
          SELECT INVENTORY_ITEM_ID,DESCRIPTION,PRIMARY_UOM_CODE,PURCHASING_ENABLED_FLAG,PRIMARY_UNIT_OF_MEASURE
          INTO l_item_id,l_item_desc,l_uom_code,l_purch_flag,l_uom
          FROM mtl_system_items msi
          where  msi.segment1  = l_po_lines_rec.item
          and  msi.organization_id = l_organization_id  ;
          if l_item_id is null then
           gc_error_code       :='PO10';
           gc_error_msg        :='Item  : '||l_po_lines_rec.item||'  is not valid in Oracle';
           gc_comments         :='Please Give a Valid Item ';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
           END IF;
           exception when no_data_found then
           gc_error_code       :='PO10';
           gc_error_msg        :='Item  : '||l_po_lines_rec.item||'  is not valid in Oracle';
           gc_comments         :='Please Give a Valid Item ';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
          end;
         gc_log_msg:='before purchase flag';
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
          BEGIN
                  if l_purch_flag = 'N' then
                  gc_error_code       :='PO11';
                  gc_error_msg        :='Item  : '||l_po_lines_rec.item||'  is not enabled for purchasing  ';
                  gc_comments         :='Please enable Item for purchasing ';
                  l_rec_error         := l_rec_error||' '||gc_error_msg;
                  INSERT_ERROR_MSG;
                  l_line_status := gc_record_error;
                  END IF;
         END;
         if l_po_lines_rec.item_revision is not null then
         gc_log_msg:='before revision';
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
          begin
           select revision
           into l_revision
           from mtl_item_revisions
           where organization_id = l_organization_id
           and revision = l_po_lines_rec.item_revision
           and inventory_item_id = l_item_id;
           IF l_revision is null THEN
           GC_ERROR_CODE       :='PO12';
           GC_ERROR_MSG        :='Revision  : '||L_PO_LINES_REC.ITEM_REVISION||'for Item '||L_PO_LINES_REC.ITEM||'  is not valid in Oracle so set to null';
           gc_comments         :='set Item Revision to null';
           L_REC_ERROR         := L_REC_ERROR||' '||GC_ERROR_MSG;
           INSERT_ERROR_MSG;
           --l_line_status := gc_record_error;
           l_revision := null;
           END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           GC_ERROR_CODE       :='PO12';
           GC_ERROR_MSG        :='Revision  : '||L_PO_LINES_REC.ITEM_REVISION||'for Item '||L_PO_LINES_REC.ITEM||'  is not valid in Oracle so set to null';
           gc_comments         :='ITEM Revision has been set to null';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           --l_line_status := gc_record_error;
           l_revision := null;
          END;
       end if;

           BEGIN
              SELECT mc.CATEGORY_ID
              INTO l_category_id
              FROM MTL_ITEM_CATEGORIES MIC,MTL_CATEGORIES MC
              WHERE MIC.INVENTORY_ITEM_ID  = L_ITEM_ID
              AND  mc.category_id = mic.category_id
              AND mc.structure_id = 201
              AND  ROWNUM <2
              and (trunc(mc.disable_date) > trunc(sysdate) or mc.disable_date is null);
              if  l_category_id is null then
              gc_error_code       :='PO13';
              gc_error_msg        :='Category Code  : '||l_po_lines_rec.Category||' is not valid in Oracle';
              gc_comments         :='Please Give a Valid Item category Code';
              l_rec_error         := l_rec_error||' '||gc_error_msg;
              INSERT_ERROR_MSG;
              l_line_status := gc_record_error;
              end if;
              exception when no_data_found then
              gc_error_code       :='PO13';
              gc_error_msg        :='purcashing Category Code  for : '||l_po_lines_rec.item||' is not assigned in Oracle';
              gc_comments         :='Please assign the purchasing Item category to the item';
              l_rec_error         := l_rec_error||' '||gc_error_msg;
              insert_error_msg;
              l_line_status := gc_record_error;
              end;
      end if;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         Begin
             SELECT uom_code
             into l_bpcs_uom
             FROM mtl_units_of_measure muml
             WHERE upper(muml.unit_of_measure) = upper(l_po_lines_rec.unit_of_measure)
             AND (trunc(muml.disable_date) > trunc(SYSDATE) OR muml.disable_date IS NULL);
             if l_bpcs_uom is null then
             gc_error_code       :='PO14';
             gc_error_msg        :='Unit of Measure  : '||l_po_lines_rec.unit_of_measure||' is not valid in Oracle';
             gc_comments         :='Please Give a Valid Unit of Measure Code';
             l_rec_error         := l_rec_error||' '||gc_error_msg;
             insert_error_msg;
             l_line_status := gc_record_error;
             end if;
             exception when no_data_found then
             gc_error_code       :='PO14';
             gc_error_msg        :='Unit of Measure  : '||l_po_lines_rec.unit_of_measure||' is not valid in Oracle';
             gc_comments         :='Please Give a Valid Unit of Measure Code';
             l_rec_error         := l_rec_error||' '||gc_error_msg;
             insert_error_msg;
             l_line_status := gc_record_error;
             end;

            --12. Negative quantity
          gc_log_msg:='before Negative qty';
            XXHA_COMMON_UTILITIES_PKG.PRINT_MSG_PRC(GC_DEBUG_FLAG,GC_LOG_MSG);

         Begin
             if l_po_lines_rec.quantity <= 0 then
                         gc_error_code       :='PO15';
                         gc_error_msg        :='Negative Quantity not allowed : '||l_po_lines_rec.quantity;
                         gc_comments         :='Negative quantity PO wont be converted';
                         l_rec_error         := l_rec_error||' '||gc_error_msg;
                         INSERT_ERROR_MSG;
                         l_line_status := gc_record_error;
            end if;
         end;

         gc_log_msg:= 'item_id '||l_item_id||'  category_id '||l_category_id||
        ' uom_code '||l_bpcs_uom||' ship_to_organization_id '||l_organization_id;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
            gc_log_msg:='before lines update';
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
         update xxha_po_conv_lines_stg2 xls
            set record_status = nvl(l_line_status,gc_record_success)
           ,error_message    = l_rec_error
           ,item_id = l_item_id
           ,item_revision = decode(l_revision, null,l_po_lines_rec.item_revision,l_revision)
           ,line_type = decode(l_item_id, null,'Service','Goods')
           ,category_id = l_category_id
           ,uom_code = l_bpcs_uom
           ,ship_to_location_id = l_location_id
           ,ship_to_organization_id = l_organization_id
        where interface_line_id = l_po_lines_rec.interface_line_id;
      if l_item_desc is not null then
       update xxha_po_conv_lines_stg2 xls
          set item_description = l_item_desc
       where interface_line_id = l_po_lines_rec.interface_line_id;
      end if;
          gc_log_msg:='After lines update';
          xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
          p_error_status := nvl(p_error_status,l_line_status);
       for l_po_dist_rec in l_po_dist_cur (l_po_lines_rec.interface_header_id,
                                           l_po_lines_rec.interface_line_id)
       loop
        L_CHARGE_ACC_ID  := NULL;
        l_accural_acc_id := NULL;
        gc_log_msg :='In Distr validation';
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
        l_distr_status   :=null;
        l_rec_error      :=null;
        l_agent_id1      := null;
        l_category_id1   := null;
        l_category       := null;
        temp             := null;
        gc_record_identifier := l_po_dist_rec.interface_distribution_id;
       begin
       --l_category := l_po_lines_rec.category;
         --  13.Charge Account
     --if l_item_id is null and l_po_dist_rec.charge_account is not null  then
    --   if l_item_id is null  then
    if L_PO_DIST_REC.CHARGE_ACCOUNT is not null then
fnd_file.put_line(fnd_file.log,'L_PO_DIST_REC.CHARGE_ACCOUNT='||L_PO_DIST_REC.CHARGE_ACCOUNT);
        begin
         select bks.chart_of_accounts_id
         into l_coa_id
         from  gl_sets_of_books     bks
         where BKS.SET_OF_BOOKS_ID = GN_SOB_ID;
         fnd_file.put_line(fnd_file.log,'l_coa_id='||l_coa_id);
         l_charge_acc_id := fnd_flex_ext.get_ccid
                                               ('SQLGL'
                                                , 'GL#'
                                                , l_coa_id
                                                , TO_CHAR(sysdate,'DD-MON-YYYY')
                                                , L_PO_DIST_REC.CHARGE_ACCOUNT
                                                --SUBSTR((L_PO_DIST_REC.CHARGE_ACCOUNT),1,46)
                                              ) ;
fnd_file.put_line(fnd_file.log,'l_charge_acc_id='||l_charge_acc_id);
         if l_charge_acc_id is null then
         gc_error_code       :='PO16';
         gc_error_msg        :='Charge Account  : '||l_po_dist_rec.charge_account||' is not valid in Oracle';
         gc_comments         :='Please Give a Valid Charge Account';
         l_rec_error         := l_rec_error||' '||gc_error_msg;
         INSERT_ERROR_MSG;
         l_distr_status := gc_record_error;
         END IF;
         exception when no_data_found then
         gc_error_code       :='PO16';
         gc_error_msg        :='Charge Account  : '||l_po_dist_rec.charge_account||' is not valid in Oracle';
         gc_comments         :='Please Give a Valid Charge Account';
         l_rec_error         := l_rec_error||' '||gc_error_msg;
         insert_error_msg;
         l_distr_status := gc_record_error;
         end;
         END IF;
         if L_PO_DIST_REC.ACCURAL_ACCOUNT is not null then
fnd_file.put_line(fnd_file.log,'L_PO_DIST_REC.ACCURAL_ACCOUNT='||L_PO_DIST_REC.ACCURAL_ACCOUNT);
        begin
         select bks.chart_of_accounts_id
         into l_coa_id
         from  gl_sets_of_books     bks
         where BKS.SET_OF_BOOKS_ID = GN_SOB_ID;
         FND_FILE.PUT_LINE(FND_FILE.LOG,'l_coa_id='||L_COA_ID);
         l_accural_acc_id := fnd_flex_ext.get_ccid
                                               ('SQLGL'
                                                , 'GL#'
                                                , l_coa_id
                                                , TO_CHAR(sysdate,'DD-MON-YYYY')
                                                , L_PO_DIST_REC.ACCURAL_ACCOUNT
                                                --SUBSTR((L_PO_DIST_REC.CHARGE_ACCOUNT),1,46)
                                              ) ;
FND_FILE.PUT_LINE(FND_FILE.LOG,'l_accural_acc_id='||L_ACCURAL_ACC_ID);
         IF l_accural_acc_id IS NULL THEN
         GC_ERROR_CODE       :='PO17';
         GC_ERROR_MSG        :='Accural Account  : '||L_PO_DIST_REC.ACCURAL_ACCOUNT||' is not valid in Oracle';
         gc_comments         :='Please Give a Valid Accural Account';
         l_rec_error         := l_rec_error||' '||gc_error_msg;
         INSERT_ERROR_MSG;
         l_distr_status := gc_record_error;
         END IF;
         EXCEPTION WHEN NO_DATA_FOUND THEN
         GC_ERROR_CODE       :='PO17';
         GC_ERROR_MSG        :='Accural Account  : '||L_PO_DIST_REC.ACCURAL_ACCOUNT||' is not valid in Oracle';
         gc_comments         :='Please Give a Valid Accural Account';
         l_rec_error         := l_rec_error||' '||gc_error_msg;
         insert_error_msg;
         l_distr_status := gc_record_error;
         END;
         end if;
       /*  Begin
              SELECT code_combination_id
              INTO l_charge_acc_id
              from gl_code_combinations_kfv gck
                  ,gl_sets_of_books gsob
              where  gck.chart_of_accounts_id = gsob.chart_of_accounts_id
                and  GSOB.SET_OF_BOOKS_ID = GN_SOB_ID --1002
                and  CONCATENATED_SEGMENTS = L_PO_DIST_REC.CHARGE_ACCOUNT;
                IF l_charge_acc_id is null THEN
                gc_error_code       :='PO16';
               gc_error_msg        :='Charge Account  : '||l_po_dist_rec.charge_account||' is not valid in Oracle';
               gc_comments         :='Please Give a Valid Charge Account';
               l_rec_error         := l_rec_error||' '||gc_error_msg;
               INSERT_ERROR_MSG;
               l_distr_status := gc_record_error;
                END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           gc_error_code       :='PO16';
           gc_error_msg        :='Charge Account  : '||l_po_dist_rec.charge_account||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Charge Account';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           L_DISTR_STATUS := GC_RECORD_ERROR;
           END;
    end if;
    fnd_file.put_line(fnd_file.log,'l_charge_acc_id1='||l_charge_acc_id);
           --Requestor
    -- if l_item_id is null and l_charge_acc_id is null then
     /*  if l_item_id is null then
         begin
           select poa.agent_id
           into l_agent_id1
           from per_people_f ppf,
                 po_agents poa
           where ppf.employee_number = l_po_dist_rec.deliver_to_person_full_name
           and ppf.person_id = poa.agent_id
           and (trunc(sysdate) between trunc(ppf.start_date)
           and trunc(nvl(ppf.effective_end_date,sysdate)));
           if l_agent_id1 is null  then
           gc_error_code       :='P017';
           gc_error_msg        :='Buyer-requester  : '||l_po_dist_rec.deliver_to_person_full_name||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid buyer-requester Name';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_distr_status := gc_record_error;
           END IF;
           exception when others then
           gc_error_code       :='P017';
           gc_error_msg        :='Buyer-requester  : '||l_po_dist_rec.deliver_to_person_full_name||' is not valid in Oracle'||Sqlerrm;
           gc_comments         :='Please Give a Valid buyer-requester Name';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_distr_status := gc_record_error;
        end ;*/

       /* begin
           select category_id,1
           into l_category_id,temp   -- It is a temporary variable to update category id in lines table
           FROM mtl_categories_b mcb
           where (trunc(mcb.disable_date) > trunc(sysdate) or mcb.disable_date is null)
           AND  upper(mcb.segment1) = upper(l_category);
           IF l_category_id is null THEN
           gc_error_code       :='PO18';
           gc_error_msg        :='Category Code  : '||l_category||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Item category Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
           END IF;
           EXCEPTION WHEN NO_DATA_FOUND THEN
           gc_error_code       :='PO18';
           gc_error_msg        :='Category Code  : '||l_category||' is not valid in Oracle';
           gc_comments         :='Please Give a Valid Item category Code';
           l_rec_error         := l_rec_error||' '||gc_error_msg;
           INSERT_ERROR_MSG;
           l_line_status := gc_record_error;
       end;*/
    --end if;

       gc_log_msg:='before distr update';
       xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
        update xxha_po_conv_distr_stg xds
           set record_status = nvl( l_distr_status,gc_record_success)
          ,error_message    = l_rec_error
          , CHARGE_ACCOUNT_ID = L_CHARGE_ACC_ID
          , ACCRUAL_ACCOUNT_ID = l_accural_acc_id
        --  ,deliver_to_person_id = decode(l_item_id,null,l_agent_id1,null)
          ,destination_type_code =  decode(l_item_id,null,'EXPENSE','INVENTORY')-- Destination_code
        where interface_distribution_id = l_po_dist_rec.interface_distribution_id ;
      gc_log_msg:='After distr update';
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      p_error_status := nvl(p_error_status,l_distr_status);
     exception when others then
     gc_log_msg:='Error   '||sqlerrm||'    occured during PO distribution map and validate process for '||l_po_dist_rec.INTERFACE_DISTRIBUTION_ID;
     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      update xxha_po_conv_distr_stg xds
         set record_status = gc_record_error
        ,error_message    = gc_log_msg||' '||l_rec_error
      where interface_header_id = l_po_dist_rec.interface_distribution_id;
      p_error_status := l_line_status;
      END;
      end loop;  -- Close cursor for Standard PO Distribution
     /* if temp = 1 then
       update xxha_po_conv_lines_stg2 xls
      set record_status = nvl(l_line_status,gc_record_success)
      ,error_message    = l_rec_error
      ,category_id = l_category_id
      where interface_header_id = l_po_lines_rec.interface_line_id;
      end if;*/
      EXCEPTION WHEN OTHERS THEN
      gc_log_msg:='Error   '||sqlerrm||'    occured during PO Line map and validate process for '||l_po_lines_rec.interface_line_id;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
       update xxha_po_conv_lines_stg2 xls
          set record_status = gc_record_error
         ,error_message    = gc_log_msg||' '||l_rec_error
       where interface_header_id = l_po_lines_rec.interface_line_id;
      END;
      end loop; -- Close cursor for Standard PO Lines
       update xxha_po_conv_header_stg xhs
          set record_status =  nvl(l_header_status,gc_record_success)
         ,error_message    =  l_header_err
         ,org_id = l_operating_unit
         ,vendor_id = l_vendor_id
         ,agent_id = l_agent_id
         ,TERMS_ID = L_TERM_ID
         ,vendor_site_id = l_vendor_site_id
         ,ship_to_location_id = l_location_id
         ,fob = l_fob
         ,currency_code = l_currency_code
         ,approval_status = l_head_app_status
      where interface_header_id = l_po_headers_rec.interface_header_id;
      gc_log_msg:='after header update  -'||l_po_headers_rec.interface_header_id;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      EXCEPTION WHEN OTHERS THEN
      gc_log_msg:='Error  '||sqlerrm||'   occured during header map and validate process for '||l_po_headers_rec.interface_header_id||' - '||length(l_rec_error);
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
       update xxha_po_conv_header_stg xhs
          set record_status = gc_record_error
         ,error_message    = gc_log_msg||' '||l_rec_error
       where interface_header_id = l_po_headers_rec.interface_header_id;
      END;
      END LOOP; -- Close cursor for Standard PO Header
      fnd_concurrent.af_commit;
end map_val_po_data;
   ---------------------------------------------------------
   --  Proc 1. Main Loading Procedure
   ---------------------------------------------------------
   PROCEDURE main_proc(
      ERRBUF                  OUT VARCHAR2 ,
      RETCODE                 OUT VARCHAR2,
      p_debug_flag          IN  VARCHAR2 DEFAULT 'N',
      p_purge_flag             IN  VARCHAR2 DEFAULT 'N',
      p_load_flag           IN  VARCHAR2 DEFAULT 'N',
      p_reset_errors           IN  VARCHAR2 DEFAULT 'N')
   IS
      l_map_data_status               NUMBER;
      l_validate_records_status       VARCHAR2(5);
      l_load_data_status              NUMBER;
      l_requestid                     NUMBER;
      --l_userid                        number;
   BEGIN
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_debug_flag'||p_debug_flag);
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_purge_flag'||p_purge_flag);
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_load_flag'||p_load_flag);
      Fnd_File.PUT_LINE(Fnd_File.LOG,'p_reset_errors'||p_reset_errors);

      Fnd_File.PUT_LINE(Fnd_File.LOG,'gc_operating_unit'||gc_operating_unit);

     gc_debug_flag := p_debug_flag;
      l_start_program_time := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');
      fnd_file.put_line(fnd_file.log, 'Begin  PO Conversion Main : '||l_start_program_time);
      IF p_reset_errors = 'Y' THEN
         BEGIN
           reset_record_status;
         EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From main_proc/block reset_record_status');
             RAISE;
         END;
      END IF;
      IF p_purge_flag = 'Y' THEN
         BEGIN
           purge_staging_table(gc_operating_unit);
         EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From main_proc/block purge_staging_table');
             RAISE;
         END;
      END IF;
      BEGIN
         fnd_file.put_line(fnd_file.log,'Begin temp data load');
           Load_Temp_data(gc_operating_unit);
         EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From main_proc/block Load temp data');
             RAISE;
     END;
      BEGIN
           map_val_po_data( l_validate_records_status );
         EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,'Exception Raised From main_proc/block map_po_records'||sqlerrm);
             RAISE;
      END;
      IF (p_load_flag = 'Y') THEN
          BEGIN
            load_standard_data (l_load_data_status);
          EXCEPTION
            WHEN OTHERS THEN
              RAISE;
          END;
      END IF;
      IF l_load_data_status = 1  THEN
     Fnd_File.PUT_LINE(Fnd_File.LOG,'Error in loading the data into the Interface tables, Transaction(s) Rollbacked');
         retcode:=1;
      END IF;
      l_end_program_time := TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS');
      Fnd_File.PUT_LINE(Fnd_File.LOG, 'End of PO Conversion Main : '||l_end_program_time);
   EXCEPTION
     WHEN OTHERS THEN
       Fnd_File.PUT_LINE(Fnd_File.LOG,'Program ended unsuccessfully');
       retcode:=-1;
       errbuf := SQLCODE||':'||SQLERRM;
   END main_proc;    -- end of main_proc
  ---------------------------------------------------------
   --Proc 10.   procedure to load Standard PO records
   ---------------------------------------------------------
   PROCEDURE load_standard_data(p_error_status OUT VARCHAr2)
   IS
   l_std_distr_records       number :=0;
   l_std_header_records number :=0;
   l_std_line_records   number :=0;
   l_type    varchar2(50) := null;
      -- Open Cursor to load data into  PO_HEADERS_INTERFACE table
      CURSOR l_std_headers_cur
      IS
         SELECT        interface_header_id,
                       document_type_code,
                       CURRENCY_CODE,
                       RATE_TYPE,
                       RATE_TYPE_CODE,
                       rate_date,
                       agent_id,
                       vendor_id,
                       vendor_site_id,
                       SHIP_TO_LOCATION_id,
                       terms_id,
                       fob,
                       approval_status,
                       document_num,
                       vendor_doc_num,
                       creation_date,
                       created_by,
                       last_update_date,
                       last_updated_by,
                       ORG_ID,
                     --  attribute1,
                       comments
           FROM xxha_po_conv_header_stg xhs
      WHERE (record_status = gc_record_success or
             record_status = 'W' )
            -- dws the following should be redundant
            and not exists (select 1
                             from xxha_po_conv_lines_stg2 xls
                             where xls.interface_header_id = xhs.interface_header_id
                               and (xls.record_status = gc_record_error
                                or  xls.record_status is null))
            AND not exists (select 1
                             from xxha_po_conv_distr_stg xds
                             where xds.interface_header_id = xhs.interface_header_id
                               and (xds.record_status = gc_record_error
                                or xds.record_status is null))
            AND xhs.org_id = gc_operating_unit ;
      -- Open Cursor to load data in PO_LINES_INTERFACE
       CURSOR l_std_lines_cur (p_header_id    NUMBER)
      IS
SELECT                   interface_line_id,
                         action,
                         po_header_id,
                         po_line_id,
                         line_num,
                         shipment_num,
                         line_type,
                         line_type_id,
                         item_id,
                         item_description,
                         Item_revision,
                         category_id,
                         uom_code,
                         unit_price,
                         ship_to_location_id,
                         ship_to_organization_id,
                         quantity,
                         per,
                         PROMISED_DATE,
                         need_by_date,
                         INSPECTION_REQUIRED_FLAG,
                         receipt_required_flag,
                         creation_date,
                         created_by,
                         last_update_date,
                         last_updated_by
           FROM xxha_po_conv_lines_stg2
          WHERE interface_header_id = p_header_id;
      cursor l_std_dist_cur (p_header_id    number,
                             p_line_id          NUMBER)
      is
     select             interface_distribution_id,
                        distribution_num,
                        org_id,
                        quantity_ordered,
                        set_of_books_id,
                        CHARGE_ACCOUNT_ID,
                        ACCRUAL_ACCOUNT_ID,
                     --   deliver_to_person_id,
                        creation_date,
                        created_by,
                        last_update_date,
                        last_updated_by,
                        GL_ENCUMBERED_DATE,
                        DESTINATION_TYPE_CODE,
                        attribute1,
                        attribute2
       FROM xxha_po_conv_distr_stg
      WHERE interface_header_id = p_header_id
        AND interface_line_id     = p_line_id;
      l_headers_next                   po_headers_interface.interface_header_id%TYPE;
      l_lines_next                     po_lines_interface.interface_line_id%TYPE;
      l_distribution_next              po_distributions_interface.interface_distribution_id%TYPE;
      l_distribution_num               po_distributions_interface.distribution_num%type;
      l_line_type_id                   po_line_types.line_type_id%type;
      l_accrual_account_id             po_distributions_interface.accrual_account_id%TYPE;
      lv_hd_insert_counter             NUMBER := 0;
      lv_destination_organization      po_distributions_interface.destination_organization%TYPE;
      lv_destination_context           po_distributions_interface.destination_context%TYPE;
      lv_destination_subinventory      po_distributions_interface.destination_subinventory%TYPE;
      lv_destination_type_code         po_distributions_interface.destination_type_code%TYPE;
      gv_commit_count                  number :=0;
      um                               varchar2(12);
   BEGIN
     FOR l_std_headers_rec IN l_std_headers_cur
     LOOP
        SAVEPOINT insert_header;
        BEGIN -- transaction block
      lv_hd_insert_counter := lv_hd_insert_counter + 1;
          select po_headers_interface_s.nextval
            into l_headers_next
          FROM DUAL;
      INSERT INTO po_headers_interface
                  (interface_header_id,
                   action,
                   document_type_code,
                   CURRENCY_CODE,
                   RATE_TYPE,
                   RATE_TYPE_CODE,
                   RATE_DATE,
                   agent_id,
                   vendor_id,
                   vendor_site_id,
                   ship_to_location_id,
                   terms_id,
                   fob,
                   approval_status,
                   approved_date,
                   document_num,
                   vendor_doc_num,
                   creation_date,
                   created_by,
                   last_update_date,
                   last_updated_by,
                   comments,
                   org_id
)
               values
                  (l_headers_next,
                   gc_action,
                   l_std_headers_rec.document_type_code,
                   L_STD_HEADERS_REC.CURRENCY_CODE,
                   L_STD_HEADERS_REC.RATE_TYPE,
                   L_STD_HEADERS_REC.RATE_TYPE_CODE,
                   L_STD_HEADERS_REC.RATE_DATE,
                   l_std_headers_rec.agent_id,
                   l_std_headers_rec.vendor_id,
                   l_std_headers_rec.vendor_site_id,
                   l_std_headers_rec.ship_to_location_id,
                   l_std_headers_rec.terms_id,
                   upper(l_std_headers_rec.fob),
                   l_std_headers_rec.approval_status, --'APPROVED' ,
                   sysdate,
                   l_std_headers_rec.document_num,
                   l_std_headers_rec.document_num,
                   l_std_headers_rec.creation_date,
                   gn_user_id,
                   l_std_headers_rec.last_update_date,
                   GN_USER_ID,
                   L_STD_HEADERS_REC.COMMENTS,
              --     decode(l_std_headers_rec.attribute1,'P2','PO Received but Not Invoiced',l_std_headers_rec.comments),
                   gc_operating_unit
                   );
                   l_std_header_records  := l_std_header_records+1;

         for l_std_lines_rec in l_std_lines_cur (l_std_headers_rec.interface_header_id) loop
          select po_lines_interface_s.nextval
            into l_lines_next
          from dual;
          SELECT line_type_id
            INTO l_line_type_id
          FROM po_line_types
          where upper(line_type) = upper( decode(l_std_lines_rec.item_id, null,'Service','Goods'));
  insert into po_lines_interface (interface_line_id,
                                  interface_header_id,
                                  action,
                                  line_num,
                                  line_type,
                                  line_type_id,
                                  item_id,
                                  item_description,
                                  item_revision,
                                  category_id,
                                  uom_code,
                                  unit_price,
                                  ship_to_location_id,
                                  ship_to_organization_id,
                                  quantity,
                                  promised_date,
                                  need_by_date,
                                  creation_date,
                                  created_by,
                                  last_update_date,
                                  last_updated_by ,
                                  INSPECTION_REQUIRED_FLAG,
                                  receipt_required_flag
)
               values            (l_lines_next,
                                  l_headers_next,
                                  gc_action,
                                  l_std_lines_rec.line_num,
                                  decode(l_std_lines_rec.item_id, null,'Service','Goods'),
                                  l_line_type_id,
                                  l_std_lines_rec.item_id,
                                  l_std_lines_rec.item_description,
                                  decode(l_std_lines_rec.item_id, null,null,l_std_lines_rec.item_revision),
                                  l_std_lines_rec.category_id,
                                  DECODE(L_STD_LINES_REC.ITEM_ID,null,'AMT',L_STD_LINES_REC.UOM_CODE),
                                  --decode(l_std_lines_rec.item_id, null,1,(l_std_lines_rec.unit_price/l_std_lines_rec.per)),
                                  l_std_lines_rec.unit_price,
                                  l_std_lines_rec.ship_to_location_id,
                                  L_STD_LINES_REC.SHIP_TO_ORGANIZATION_ID,
                               -- abs(decode(l_std_lines_rec.item_id, null,((l_std_lines_rec.quantity*l_std_lines_rec.unit_price)/l_std_lines_rec.per),l_std_lines_rec.quantity)),
                                abs(decode(l_std_lines_rec.item_id, null,((l_std_lines_rec.quantity*l_std_lines_rec.unit_price)),l_std_lines_rec.quantity)),
                            --      decode(l_std_headers_rec.attribute1,'P2',abs(decode(l_std_lines_rec.item_id, null,((l_std_lines_rec.quantity*l_std_lines_rec.unit_price)/l_std_lines_rec.per),l_std_lines_rec.quantity)),decode(l_std_lines_rec.item_id, null,((l_std_lines_rec.quantity*l_std_lines_rec.unit_price)/l_std_lines_rec.per),l_std_lines_rec.quantity)),
                                  nvl(l_std_lines_rec.promised_date,l_std_lines_rec.need_by_date),
                                  l_std_lines_rec.need_by_date,
                         --        L_STD_LINES_REC.PROMISED_DATE,
                            --      nvl(l_std_lines_rec.need_by_date,L_STD_LINES_REC.PROMISED_DATE),
                                  l_std_lines_rec.creation_date,
                                  gn_user_id,
                                  l_std_lines_rec.last_update_date,
                                  gn_user_id ,
                                  'N',
                               --   'N'
                                   l_std_lines_rec.receipt_required_flag
                              --   decode(l_std_headers_rec.attribute1,'P2','N','Y')
                                  );
        l_std_line_records   :=l_std_line_records+1;
        l_type := null;
        l_distribution_num := 0;
       for l_std_dist_rec in l_std_dist_cur (l_std_headers_rec.interface_header_id,
                                             l_std_lines_rec.interface_line_id)
       LOOP
         l_distribution_num := l_distribution_num + 1;
         SELECT po_distributions_interface_s.NEXTVAL
           INTO l_distribution_next
         from dual;
     insert into po_distributions_interface
                              (interface_line_id,
                               interface_header_id,
                               interface_distribution_id,
                               distribution_num,
                               org_id,
                               quantity_ordered,
                               set_of_books_id,
                               CHARGE_ACCOUNT_ID,
                               ACCRUAL_ACCOUNT_ID,
                         --      deliver_to_person_id,
                               creation_date,
                               created_by,
                               last_update_date,
                               last_updated_by,
                               GL_ENCUMBERED_DATE,
                               DESTINATION_TYPE_CODE,
                               ATTRIBUTE11,
                               ATTRIBUTE12
                               )
                  values      (l_lines_next,
                               l_headers_next,
                               l_distribution_next,
                               l_distribution_num,
                               GC_OPERATING_UNIT,
                               abs(decode(l_std_lines_rec.item_id, null,((l_std_lines_rec.quantity*l_std_lines_rec.unit_price)/l_std_lines_rec.per),l_std_lines_rec.quantity)),
                           --   decode(l_std_headers_rec.attribute1,'P2',abs(decode(l_std_lines_rec.item_id, null,((l_std_lines_rec.quantity*l_std_lines_rec.unit_price)/l_std_lines_rec.per),l_std_lines_rec.quantity)),decode(l_std_lines_rec.item_id, null,((l_std_lines_rec.quantity*l_std_lines_rec.unit_price)/l_std_lines_rec.per),l_std_lines_rec.quantity)),
                               GN_SOB_ID,
                               L_STD_DIST_REC.CHARGE_ACCOUNT_ID,
                               L_STD_DIST_REC.ACCRUAL_ACCOUNT_ID,
                          --     decode(l_std_lines_rec.item_id,null,L_STD_DIST_REC.CHARGE_ACCOUNT_ID,null),
                          --     l_std_dist_rec.deliver_to_person_id,
                               l_std_dist_rec.creation_date,
                               gn_user_id,
                               l_std_dist_rec.last_update_date,
                               gn_user_id,
                               GC_SYSDATE,
                               L_STD_DIST_REC.DESTINATION_TYPE_CODE,
                               L_STD_DIST_REC.ATTRIBUTE1,
                               l_std_dist_rec.attribute2
                            );
              l_std_distr_records := l_std_distr_records+1;
  update xxha_po_conv_distr_stg
     set record_status = gc_record_interfaced
  where interface_header_id = l_std_headers_rec.interface_header_id
    and interface_line_id = l_std_lines_rec.interface_line_id
    and interface_distribution_id = l_std_dist_rec.interface_distribution_id;
  end loop;  -- Close cursor for Standard PO Distribution
  update xxha_po_conv_lines_stg2
     set record_status = gc_record_interfaced
  where interface_header_id = l_std_headers_rec.interface_header_id
    and interface_line_id = l_std_lines_rec.interface_line_id;
  end loop; -- Close cursor for Standard PO Lines
  update xxha_po_conv_header_stg
     set record_status = gc_record_interfaced
  where interface_header_id = l_std_headers_rec.interface_header_id;
         EXCEPTION
           WHEN OTHERS THEN
             Fnd_File.PUT_LINE(Fnd_File.LOG,' ! ! ! exception raised inserting standard tables - rollbacked - processing continued!!!');
             Fnd_File.PUT_LINE(Fnd_File.LOG,'       exception raised inserting standard tables - rollbacked, Document: '||l_std_headers_rec.document_num);
           p_error_status := 1;
             ROLLBACK TO insert_header;
         END; -- end transactions block
         IF gv_commit_count = gv_commit_limit THEN
           fnd_concurrent.af_commit;
           gv_commit_count := 0;
         ELSE
           gv_commit_count := gv_commit_count + 1;
         END IF;
       END LOOP; -- Close cursor for Standard PO Header
       p_error_status := 0;
       fnd_concurrent.af_commit;
        Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'***********************Interface table Load report  *****************');
       Fnd_File.PUT_LINE(Fnd_File.LOG,' ');
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,' ');
       Fnd_File.PUT_LINE(Fnd_File.LOG,'Number of Header proccessed by insert procedure: '||to_char(lv_hd_insert_counter));
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of Headers insertedinto interface: '||to_char( l_std_header_records));
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of Lines inserted into interface: '||to_char( l_std_line_records));
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'Number of Distributions inserted into interface: '||to_char( l_std_distr_records));
       Fnd_File.PUT_LINE(Fnd_File.LOG,' ');
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,' ');
       Fnd_File.PUT_LINE(Fnd_File.OUTPUT,'***********************Interface table Load report End  *****************');
   EXCEPTION
     WHEN OTHERS
      THEN
         p_error_status := 1;
           Fnd_File.PUT_LINE(Fnd_File.LOG,'Raise Error From load_standard_data exception handler');
            RAISE;
   END load_standard_data;    -- End of Procedure Load Standard PO Data.
   -- +==============================================================================
-- | Name       : purge_staging_table
-- |
-- | Description: Procedure to purge staging table records
-- |
-- | Call From  : Loader Concurrent Program
-- |
-- | Parameters:
-- |   IN: p_file_name
-- |       p_request_id
-- |       p_ou_org_id
-- |  OUT:
-- |
-- | Scope: PUBLIC
-- |
-- +==============================================================================
PROCEDURE UPDATE_RECEIVED_QTY (
         ERRBUF                  OUT VARCHAR2 ,
         RETCODE                 OUT VARCHAR2
         --p_ou_org_id  in  number
        ) is
BEGIN

UPDATE PO_LINE_LOCATIONS_ALL
SET MATCH_OPTION  = 'P'
WHERE PO_LINE_ID IN (SELECT PLL.PO_LINE_ID
  FROM PO_HEADERS_ALL PH,PO_LINES_ALL PL, po_line_locations_all pll,XXHA_PO_BPCS_STG8 xpo
WHERE PH.PO_HEADER_ID = PL.PO_HEADER_ID
AND   PL.PO_LINE_ID = PLL.PO_LINE_ID
AND ((NVL(PLL.RECEIPT_REQUIRED_FLAG, 'N')= 'N'
 AND NVL(PLL.INSPECTION_REQUIRED_FLAG, 'N')= 'N'
     AND PLL.MATCH_OPTION = 'R'))
AND  PH.SEGMENT1 = XPO.PO_NUMBER
AND  PL.LINE_NUM =   XPO.LINE_NUMBER
and XPO.po_number not like '%XX');

Fnd_File.PUT_LINE(Fnd_File.LOG,'      updated the match_option to P for the 2 way POs'||SQL%ROWCOUNT );
commit;

UPDATE PO_LINE_LOCATIONS_ALL
SET MATCH_OPTION  = 'R'
WHERE PO_LINE_ID IN (SELECT PLL.PO_LINE_ID
  FROM PO_HEADERS_ALL PH,PO_LINES_ALL PL, po_line_locations_all pll,XXHA_PO_BPCS_STG8 xpo
WHERE PH.PO_HEADER_ID = PL.PO_HEADER_ID
AND   PL.PO_LINE_ID = PLL.PO_LINE_ID
AND ( (NVL(PLL.RECEIPT_REQUIRED_FLAG, 'N')= 'Y'
 AND NVL(PLL.INSPECTION_REQUIRED_FLAG, 'N')= 'N'
     AND PLL.MATCH_OPTION = 'P'))
AND  PH.SEGMENT1 = XPO.PO_NUMBER
AND  PL.LINE_NUM =   XPO.LINE_NUMBER
AND XPO.PO_NUMBER NOT LIKE '%XX'
);

Fnd_File.PUT_LINE(Fnd_File.LOG,'      updated the match_option to R for the 3 way POs'||SQL%ROWCOUNT );
commit;
update po_line_locations
SET QUANTITY_RECEIVED = QUANTITY
,match_option = 'P'
where po_header_id  in ( select po_header_id
                           FROM PO_HEADERS_ALL
                           WHERE SEGMENT1 LIKE '%XX');--COMMENTS =  'PO Received but Not Invoiced'
                           --    and org_id = p_ou_org_id);

Fnd_File.PUT_LINE(Fnd_File.LOG,'      updated the match_option to P for the XX POs'||SQL%ROWCOUNT );
   commit;
END UPDATE_RECEIVED_QTY ;
end xxha_po_conversion_pkg;

/
