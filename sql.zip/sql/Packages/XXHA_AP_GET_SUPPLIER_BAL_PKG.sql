CREATE OR REPLACE PACKAGE      xxha_ap_get_supplier_bal_pkg AUTHID CURRENT_USER
AS
/**********************************************************************************************************************************
*
* Trigger:     xxha_ap_get_supplier_bal_pkg
* Description:  copy of seeded oracle package fixed for moac
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    19-AUG-2014  Initial Creation
*
**********************************************************************************************************************************/
/* $Header: apxsobls.pls 120.3.12010000.3 2011/09/15 07:23:44 lkarna ship $ */
   PROCEDURE ap_get_supplier_balance (
      p_request_id            IN   NUMBER,
      p_set_of_books_id            NUMBER,
      p_as_of_date            IN   DATE,
      p_supplier_name_from    IN   VARCHAR2,
      p_supplier_name_to      IN   VARCHAR2,
      p_currency              IN   VARCHAR2,
      p_min_invoice_balance   IN   NUMBER,
      p_min_open_balance      IN   NUMBER,
      p_include_prepayments   IN   VARCHAR2,
      p_reference_number      IN   VARCHAR2,
      p_debug_flag            IN   VARCHAR2,
      p_trace_flag            IN   VARCHAR2
   );
END xxha_ap_get_supplier_bal_pkg;
/


CREATE OR REPLACE PACKAGE BODY      xxha_ap_get_supplier_bal_pkg
AS
/**********************************************************************************************************************************
*
* Trigger:     xxha_ap_get_supplier_bal_pkg
* Description:  copy of seeded oracle package fixed for moac
* Notes:
*
* Modified:     Ver    Date         Modification
*-------------  -----  -----------  ----------------------------------------------------------------------------------------------
* Dbrowne       1.0    19-AUG-2014  Initial Creation
*
**********************************************************************************************************************************/
/* $Header: apxsoblb.pls 120.14.12010000.10 2012/02/17 07:12:50 kpasikan ship $ */
   PROCEDURE ap_get_supplier_balance (
      p_request_id            IN   NUMBER,
      p_set_of_books_id            NUMBER,
      p_as_of_date            IN   DATE,
      p_supplier_name_from    IN   VARCHAR2,
      p_supplier_name_to      IN   VARCHAR2,
      p_currency              IN   VARCHAR2,
      p_min_invoice_balance   IN   NUMBER,
      p_min_open_balance      IN   NUMBER,
      p_include_prepayments   IN   VARCHAR2,
      p_reference_number      IN   VARCHAR2,
      p_debug_flag            IN   VARCHAR2,
      p_trace_flag            IN   VARCHAR2
   )
   IS
      l_amount_remaining        ap_invoices.invoice_amount%TYPE;
      l_session_language        VARCHAR2 (40);          /* For MLS changes */
      l_base_language           VARCHAR2 (40);           /*For MLS  changes*/
      l_organization_name       hr_organization_units.NAME%TYPE;
      l_payment_cross_rate      ap_invoices_all.payment_cross_rate%TYPE;
      l_invoice_currency_code   ap_invoices_all.invoice_currency_code%TYPE;
      l_invoice_amount          ap_invoices_all.invoice_amount%TYPE;
      l_payment_amount          ap_invoices_all.amount_paid%TYPE;
      l_discount_taken          ap_invoices_all.discount_amount_taken%TYPE;
      l_discount_avail          ap_invoices_all.discount_amount_taken%TYPE;

--The cursor vendorinfo holds all the information about the vendor and vendor site
      CURSOR vendorinfo (
         p_base_language      po_vendor_sites_all.LANGUAGE%TYPE,
         p_session_language   po_vendor_sites_all.LANGUAGE%TYPE
      )
      IS
         SELECT pv.vendor_id, pv.vendor_name supplier_name,
                pv.segment1 supplier_number, pv.num_1099 tax_payer_id,
                pv.vat_code vat_registration_number,
                pvs.vendor_site_code supplier_site_code, pvs.vendor_site_id,
                pvs.address_line1, pvs.address_line2, pvs.address_line3,
                pvs.city, pvs.state, pvs.zip postal_code, pvs.province,
                pvs.country
           FROM ap_suppliers pv, ap_supplier_sites pvs
          WHERE
                --bug 12927165
                --upper(pv.vendor_name) between upper(nvl(p_supplier_name_from,'A'))
                --and upper(nvl(p_supplier_name_to,'Z'))
                UPPER (pv.vendor_name)
                   BETWEEN UPPER (NVL (p_supplier_name_from, pv.vendor_name))
                       AND UPPER (NVL (p_supplier_name_to, pv.vendor_name))
            AND pvs.vendor_id = pv.vendor_id
            AND NVL (pvs.LANGUAGE, p_base_language) = p_session_language;

--Cursor invinfo holds data about invoices for the parameters entered
      CURSOR invinfo (
         p_vendor_id        ap_invoices.vendor_id%TYPE,
         p_vendor_site_id   ap_invoices.vendor_site_id%TYPE,
         p_currency         ap_invoices.invoice_currency_code%TYPE
      )
      IS
         SELECT DISTINCT ai.invoice_id, ai.payment_cross_rate,
                         lkv.meaning trans_type, ai.invoice_num trans_num,
                         ai.invoice_date trans_date, ai.invoice_currency_code,
                         ai.invoice_amount invoice_amount,
                         NVL (ai.amount_paid, 0) payment_amount,
                         NVL (ai.discount_amount_taken, 0) discount_taken,
                         gl.currency_code                         --bug9050332
                    FROM ap_invoices ai,
                         fnd_lookup_types_vl lkp,
                         fnd_lookup_values_vl lkv,
                         gl_ledgers gl                            --bug9050332
                   WHERE ai.set_of_books_id = gl.ledger_id        --bug9050332
                     AND lkp.lookup_type = 'INVOICE TYPE'
                     AND lkp.application_id = 200
                     AND lkv.view_application_id = 200           --bug13716228
                     AND lkv.lookup_code = ai.invoice_type_lookup_code
                     AND lkv.lookup_type = lkp.lookup_type
                     AND ai.invoice_type_lookup_code <> 'PREPAYMENT'
                     AND TRUNC (ai.invoice_date) <= TRUNC (p_as_of_date)
                     AND ai.vendor_id = p_vendor_id
                     AND ai.vendor_site_id = p_vendor_site_id
                     AND ai.invoice_currency_code =
                                    NVL (p_currency, ai.invoice_currency_code)
                     AND ap_invoices_utility_pkg.get_approval_status
                                                  (ai.invoice_id,
                                                   ai.invoice_amount,
                                                   ai.payment_status_flag,
                                                   ai.invoice_type_lookup_code
                                                  ) = 'APPROVED';

--Cursor to get the data of distinct invoice currency codes
      CURSOR curinfo (p_supplier_id po_vendors.vendor_id%TYPE)
      IS
         SELECT DISTINCT (invoice_currency_code) invoice_currency_code
                    FROM ap_invoices ai
                   WHERE ai.vendor_id = p_supplier_id
                     AND ai.invoice_currency_code =
                                    NVL (p_currency, ai.invoice_currency_code);

--3641604 : New cursor to get sum of discount available for invoice
      CURSOR ps_cursor (p_invoice_id NUMBER)
      IS
         SELECT payment_num
           FROM ap_payment_schedules
          WHERE invoice_id = p_invoice_id;
   BEGIN                                                                  --#1
      -- bug#1721165 Get the session language
      SELECT SUBSTR (USERENV ('LANGUAGE'),
                     1,
                     INSTR (USERENV ('LANGUAGE'), '_') - 1
                    )
        INTO l_session_language
        FROM DUAL;

      -- Get the base language
      SELECT nls_language
        INTO l_base_language
        FROM fnd_languages
       WHERE installed_flag = 'B';

      /* For bug 2113775
      Selecting the organization from gl_sets_of_books
      in case of single org since the org_id will be
      null in hr_organization_units*/
      --BEGIN
      --   SELECT NAME
      --     INTO l_organization_name
      --     FROM hr_organization_units
      --    WHERE organization_id = fnd_profile.VALUE ('ORG_ID');
      --EXCEPTION
      --   WHEN NO_DATA_FOUND
      --   THEN
            BEGIN
               SELECT NAME
                 INTO l_organization_name
                 FROM gl_sets_of_books
                WHERE set_of_books_id = p_set_of_books_id;
            EXCEPTION
               WHEN OTHERS
               THEN
                  NULL;
            END;
      --END;

      BEGIN                                            --#2 Begin Vendor Block
         FOR vendor_rec IN vendorinfo (l_base_language, l_session_language)
         LOOP
            BEGIN                                   --#3 Begin Currency Block
               FOR currency_rec IN curinfo (vendor_rec.vendor_id)
               LOOP
                  BEGIN                            --#4  Begin Invoices Block
                     FOR inv_rec IN
                        invinfo (vendor_rec.vendor_id,
                                 vendor_rec.vendor_site_id,
                                 currency_rec.invoice_currency_code
                                )
                     LOOP
                        -- get total dist amount including prepay applications
                        SELECT   ai.payment_cross_rate,
                                 ai.invoice_currency_code,
                                 NVL (SUM (NVL (aid.amount, 0)), 0)
                            INTO l_payment_cross_rate,
                                 l_invoice_currency_code,
                                 l_invoice_amount
                            FROM ap_invoice_distributions aid, ap_invoices ai
                           WHERE ai.invoice_id = aid.invoice_id
                             AND ai.invoice_id = inv_rec.invoice_id
                             AND (   aid.prepay_distribution_id IS NULL
                                  OR TRUNC (aid.accounting_date) <=
                                                          TRUNC (p_as_of_date)
                                 )
                        GROUP BY ai.payment_cross_rate,
                                 ai.invoice_currency_code;

                        -- get payment amount along with the discount taken
                        SELECT NVL (SUM (NVL (aip.amount, 0)), 0),
                               NVL (SUM (NVL (aip.discount_taken, 0)), 0)
                          INTO l_payment_amount,
                               l_discount_taken
                          FROM ap_invoice_payments aip, ap_invoices ai
                         WHERE aip.invoice_id = ai.invoice_id
                           AND ai.invoice_id = inv_rec.invoice_id
                           AND TRUNC (aip.accounting_date) <=
                                                          TRUNC (p_as_of_date);

                        -- if invoice is open
                        IF ap_utilities_pkg.ap_round_currency
                                                ((  l_invoice_amount
                                                  - (  (  l_payment_amount
                                                        + l_discount_taken
                                                       )
                                                     / NVL
                                                          (l_payment_cross_rate,
                                                           1
                                                          )
                                                    )
                                                 ),
                                                 l_invoice_currency_code
                                                ) <> 0
                        THEN
                           l_discount_avail := 0;

                           -- get available discounts if any
                           FOR ps_rec IN ps_cursor (inv_rec.invoice_id)
                           LOOP
                              BEGIN
                                 l_discount_avail :=
                                      l_discount_avail
                                    + ap_payment_schedules_pkg.get_discount_available
                                                (inv_rec.invoice_id,
                                                 ps_rec.payment_num,
                                                 SYSDATE,
                                                 inv_rec.invoice_currency_code
                                                );
                              EXCEPTION
                                 WHEN NO_DATA_FOUND
                                 THEN
                                    l_discount_avail := l_discount_avail + 0;
                              END;
                           END LOOP;

                           --calculate amount remaining by also considering future available discounts
                           l_amount_remaining :=
                              ap_utilities_pkg.ap_round_currency
                                          ((  l_invoice_amount
                                            - (  (  l_payment_amount
                                                  + inv_rec.discount_taken
                                                  + l_discount_avail
                                                 )
                                               / NVL
                                                    (inv_rec.payment_cross_rate,
                                                     1
                                                    )
                                              )
                                           ),
                                           inv_rec.invoice_currency_code
                                          );

                           IF l_amount_remaining >=
                                                NVL (p_min_invoice_balance, 0)
                           THEN
                              INSERT INTO ap_supplier_balance_itf
                                          (request_id, as_of_date,
                                           organization_name,
                                           functional_currency_code,
                                           supplier_name,
                                           supplier_number,
                                           vat_registration_number,
                                           supplier_site_code,
                                           address_line1,
                                           address_line2,
                                           address_line3,
                                           city,
                                           state,
                                           zip,
                                           country,
                                           invoice_type,
                                           invoice_num,
                                           invoice_date,
                                           invoice_currency_code,
                                           invoice_amount,
                                           amount_remaining,
                                           payment_amount,
                                           discount_taken,
                                           discount_amount_available
                                          )
                                   VALUES (p_request_id, p_as_of_date,
                                           l_organization_name,
                                           inv_rec.currency_code,
                                              --bug9050332 fucntional currency
                                           vendor_rec.supplier_name,
                                           vendor_rec.supplier_number,
                                           vendor_rec.vat_registration_number,
                                           vendor_rec.supplier_site_code,
                                           vendor_rec.address_line1,
                                           vendor_rec.address_line2,
                                           vendor_rec.address_line3,
                                           vendor_rec.city,
                                           vendor_rec.state,
                                           vendor_rec.postal_code,
                                           vendor_rec.country,
                                           inv_rec.trans_type,
                                           inv_rec.trans_num,
                                           inv_rec.trans_date,
                                           inv_rec.invoice_currency_code,
                                           inv_rec.invoice_amount,
                                           l_amount_remaining,
                                           inv_rec.payment_amount,
                                           inv_rec.discount_taken,
                                           l_discount_avail
                                          );
                           END IF;                   --End amount remaining if
                        END IF;           -- End Invoice is open on As Of date
                     END LOOP;                                  --inv_rec loop
                  EXCEPTION
                     WHEN NO_DATA_FOUND
                     THEN
                        EXIT;
                     WHEN OTHERS
                     THEN
                        app_exception.raise_exception;
                  END;                               --#4   End Invoices Block

                  /*Bug 2431936 made the following changes to SQL below:
                  1. Original and remaining amounts were switched. Corrected.
                  2. Was excluding Partially paid.  According to doc, only paid
                  should be selected.
                  3. Was not restricting by minimun invoice balance. According to
                  doc, the minimum should restrict the transactions in the report.
                  4. SQL was selecting from vendor tables.  Since we are within
                  the vendor loop, we can get values from cursor instead of from
                  the tables, so the SQL is simpler.*/
                  IF (NVL (p_include_prepayments, 'N') = 'Y')
                  THEN                                            --bug6800315
                     --bug13716228
                     --Issue 1 - prepay dist total is multipled by no.of applications
                     --Issue 2 - fnd_lookup_values results in multiple rows as when the same value
                     --          defined for multiple applications
                     INSERT INTO ap_supplier_balance_itf
                                 (request_id, as_of_date, organization_name,
                                  functional_currency_code, supplier_name,
                                  supplier_number, vat_registration_number,
                                  supplier_site_code, address_line1,
                                  address_line2, address_line3, city, state,
                                  zip, country, invoice_type, invoice_num,
                                  invoice_date, invoice_currency_code,
                                  prepay_amount_original,
                                  prepay_amount_remaining,
                                  prepay_amount_applied, invoice_amount,
                                                      -- 8217987 3 Cols added
                                  amount_remaining, payment_amount)
                        SELECT DISTINCT p_request_id, p_as_of_date,
                                        l_organization_name,
                                        pp_inv.currency_code,    --bug9050332
                                        vendor_rec.supplier_name,
                                        vendor_rec.supplier_number,
                                        vendor_rec.vat_registration_number,
                                        vendor_rec.supplier_site_code,
                                        vendor_rec.address_line1,
                                        vendor_rec.address_line2,
                                        vendor_rec.address_line3,
                                        vendor_rec.city, vendor_rec.state,
                                        vendor_rec.postal_code,
                                        vendor_rec.country, pp_inv.meaning,
                                        pp_inv.invoice_num,
                                        pp_inv.invoice_date,
                                        pp_inv.invoice_currency_code,
                                        pp_inv.dist_total,
                                          pp_inv.dist_total
                                        + pp_inv.appl_dist_total,
                                        -pp_inv.appl_dist_total, NULL, NULL,
                                        pp_inv.amount_paid
                                   FROM (SELECT DISTINCT ai.invoice_id,
                                                         aid1.invoice_distribution_id,
                                                         gl.currency_code,
                                                         lkv.meaning,
                                                         ai.invoice_num,
                                                         ai.invoice_date,
                                                         ai.invoice_currency_code,
                                                         ai.amount_paid,
                                                         SUM
                                                            (NVL (aid1.amount,
                                                                  0
                                                                 )
                                                            ) OVER (PARTITION BY ai.invoice_id)
                                                                   dist_total,
                                                         SUM
                                                            (SUM
                                                                (CASE
                                                                    WHEN TRUNC
                                                                           (pd.accounting_date
                                                                           ) <=
                                                                           TRUNC
                                                                              (p_as_of_date
                                                                              )
                                                                       THEN pd.amount
                                                                    ELSE 0
                                                                 END
                                                                )
                                                            ) OVER (PARTITION BY ai.invoice_id)
                                                              appl_dist_total
                                                    FROM ap_invoices ai,
                                                         ap_invoice_distributions aid1,
                                                         ap_invoice_distributions pd,
                                                                 --bug13411905
                                                         fnd_lookup_types_vl lkp,
                                                         fnd_lookup_values_vl lkv,
                                                         gl_ledgers gl
                                                                  --bug9050332
                                                   WHERE 1 = 1
                                                     AND ai.invoice_type_lookup_code =
                                                                  'PREPAYMENT'
                                                     AND ai.payment_status_flag =
                                                                           'Y'
                                                     AND lkp.lookup_type =
                                                                'INVOICE TYPE'
                                                     AND lkp.application_id =
                                                                           200
                                                     AND lkv.view_application_id =
                                                                           200
                                                     AND lkp.lookup_type =
                                                               lkv.lookup_type
                                                     AND lkv.lookup_code =
                                                            ai.invoice_type_lookup_code
                                                     AND ai.vendor_id =
                                                            vendor_rec.vendor_id
                                                     AND ai.vendor_site_id =
                                                            vendor_rec.vendor_site_id
                                                     AND TRUNC
                                                              (ai.invoice_date) <=
                                                            TRUNC
                                                                 (p_as_of_date)
                                                     AND ai.invoice_currency_code =
                                                            NVL
                                                               (currency_rec.invoice_currency_code,
                                                                ai.invoice_currency_code
                                                               )  --bug6800315
                                                     AND ai.set_of_books_id =
                                                            gl.ledger_id
                                                                  --bug9050332
                                                     AND ai.invoice_id =
                                                               aid1.invoice_id
                                                     AND aid1.line_type_lookup_code IN
                                                            ('ITEM',
                                                             'ACCRUAL', 'ERV',
                                                             'TIPV', 'TERV',
                                                             'TRV', 'REC_TAX',
                                                             'NONREC_TAX',
                                                             'TAX')
                                                                -- bug13411905
                                                     AND NVL
                                                            (aid1.reversal_flag,
                                                             'N'
                                                            ) <>
                                                            'Y'
                                                          --bug6500253/6800315
                                                     AND pd.prepay_distribution_id(+) =
                                                            aid1.invoice_distribution_id
                                                GROUP BY ai.invoice_id,
                                                         ai.invoice_num,
                                                         ai.invoice_date,
                                                         ai.invoice_currency_code,
                                                         ai.amount_paid,
                                                         aid1.invoice_distribution_id,
                                                         NVL (aid1.amount, 0),
                                                         gl.currency_code,
                                                         lkv.meaning) pp_inv
                                  WHERE pp_inv.dist_total >=
                                           NVL
                                              (p_min_invoice_balance, 0)
                                                                  --bug6800315
                                    AND   pp_inv.dist_total
                                        + pp_inv.appl_dist_total >
                                                        0
                                                         -- added bug 13411905
                                                         ;
                  END IF;                   --p_include_prepayments bug6800315
               END LOOP;                                   --currency_rec loop
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  NULL;
               WHEN OTHERS
               THEN
                  --APP_EXCEPTION.RAISE_EXCEPTION;
                  NULL;
            END;                                       --#3 End Currency Block
         END LOOP;                                           --vendor_rec loop
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            NULL;
         WHEN OTHERS
         THEN
            app_exception.raise_exception;
      END;                                               --#2 End Vendor Block
   EXCEPTION
      WHEN OTHERS
      THEN
         app_exception.raise_exception;
   END ap_get_supplier_balance;                                           --#1
END xxha_ap_get_supplier_bal_pkg;
/
