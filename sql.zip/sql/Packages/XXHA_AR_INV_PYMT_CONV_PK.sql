CREATE OR REPLACE PACKAGE
  XXHA_AR_INV_PYMT_CONV_PK AUTHID CURRENT_USER
AS
-- +==========================================================================
-- |                        Oracle NAIO (India)                              |
-- |                         Bangalore, India                                |
-- +==========================================================================
-- |                                                                         | 
-- | $Id$                                                                    |
-- |                                                                         |
-- |Description  Package to convert Invoices and Payments                    |
-- |             from legasys to oracle base table                           |
-- |                                                                         |
-- |                                                                         |
-- |Change Record:                                                           |
-- |===============                                                          |
-- |Version  Date         Author          Remarks                            |
-- |=======  ===========  ==============  ============================       |
-- |DRAFT 1A 18-Nov-2006  Subramanya S.N  Initial draft version              |
-- |2.00     14-Mar-2011  BMarcoux        Modified Batch Source for          |
-- |                                      Conversion_Inv1 and                |
-- |                                      Conversion_CM1.                    |
-- |2.10     22-JUL-2011  BMarcoux        Modified to allow processing of    |
-- |                                       TaxCode and for Deferred Tax      |
-- |                                       Processing.                       |
-- |3.00     19-MAR-2013  BMarcoux        Modifications for RxC Processing.  |
-- +==========================================================================

   --GlobalVariables
   gc_request_id            xxha_common_errors.request_id%TYPE:= fnd_global.conc_request_id;
   gc_error_code            xxha_common_errors.error_code%TYPE;
   gc_program_name          VARCHAR2(1000):='AR Conversion';

   gc_record_identify       xxha_common_errors.record_identifier%TYPE:='Invoice';                   --Record identifier of staging table
   gc_record_number         xxha_common_errors.record_number%TYPE;                                     --Record_number of staging table
   gc_record_identifier     xxha_common_errors.record_identifier%TYPE;                                 --Record identifier of staging table
   gc_egc_batch_namerror_code            xxha_common_errors.error_code%TYPE;                                        --Error_code insert in common error table
   gc_error_msg             xxha_common_errors.error_msg%TYPE;                                         --Error_msg  insert in common error table
   gc_comments              xxha_common_errors.comments%TYPE;                                          --Comments   insert in common error table
   gc_attribute1            xxha_common_errors.attribute1%TYPE;                                        --Attribute1 insert in common error table
   gc_attribute2            xxha_common_errors.attribute2%TYPE;                                        --Attribute2 insert in common error table
   gc_attribute3            xxha_common_errors.attribute3%TYPE;                                        --Attribute3 insert in common error table
   gc_attribute4            xxha_common_errors.attribute4%TYPE;                                        --Attribute4 insert in common error table
   gc_attribute5            xxha_common_errors.attribute5%TYPE;                                        --Attribute5 insert in common error table
   gc_status                VARCHAR2(2);                                                               -- Variable to get status falg of data insertion in common error table
   gc_con_prg_shot_name     fnd_concurrent_programs.concurrent_program_name%TYPE:='XXHA_AR_INV_CONV';
   gc_table_name            xxha_common_errors.TABLE_NAME%TYPE:='USBPCS_AR_CLEANED';
   gc_debug_flag            VARCHAR2(1);
   gc_log_msg               VARCHAR2(3000);
   gc_operating_unit_name   hr_operating_units.NAME%TYPE;


   --Local variables for incoice
   gc_batch_name           ra_batch_sources.name%TYPE;
   gc_batch_source_type    ra_batch_sources.batch_source_type%TYPE:='FOREIGN';
   gc_tax_code             ar_vat_tax_all.tax_code%TYPE:='Conversion'   ;
   gc_flex_context_code    fnd_descr_flex_contexts_vl.descriptive_flex_context_code%TYPE :='Conversion';

   gc_batch_name_inv       ra_batch_sources_all.name%TYPE:='Conversion_Inv_RX';    -- 3.00 Modifications for RxC Processing
   gc_batch_name_cm        ra_batch_sources_all.name%TYPE:='Conversion_CM_RX';     -- 3.00 Modifications for RxC Processing
--   gc_batch_name_inv       ra_batch_sources_all.name%TYPE:='Conversion_Inv1';    -- 2.00 Bmarcoux
--   gc_batch_name_cm        ra_batch_sources_all.name%TYPE:='Conversion_CM1';     -- 2.00 BMarcoux
--   gc_batch_name_inv       ra_batch_sources_all.name%TYPE:='Conversion_Inv';   -- 2.00 Bmarcoux
--   gc_batch_name_cm        ra_batch_sources_all.name%TYPE:='Conversion_CM';    -- 2.00 BMarcoux

   gc_trx_type_inv         ra_interface_lines_all.cust_trx_type_name%TYPE;
   gc_trx_type_cm          ra_interface_lines_all.cust_trx_type_name%TYPE;
   gc_trx_type_inv_id      ra_interface_lines_all.cust_trx_type_id%TYPE;
   gc_trx_type_cm_id       ra_interface_lines_all.cust_trx_type_id%TYPE;

   gn_org_id               hr_operating_units.organization_id%TYPE;
   gc_org_name             hr_operating_units.name%TYPE;
   gc_currency_code        gl_sets_of_books.currency_code%TYPE;
   gc_set_of_books_id      hr_operating_units.set_of_books_id%TYPE;
   gn_application_id       fnd_application.application_id%TYPE;
   gn_chart_of_accounts_id gl_sets_of_books.chart_of_accounts_id%TYPE;
   gc_conv_type            ra_interface_lines_all.conversion_type%TYPE:='User';
   gc_line_lookup          fnd_lookup_values.lookup_type%TYPE:='LINE';
   gc_tax_lookup           fnd_lookup_values.lookup_type%TYPE:='TAX';
   gc_freight_lookup       fnd_lookup_values.lookup_type%TYPE:='FREIGHT';
   gc_territory_name       ar_system_parameters.ai_territory_key_left_prompt%TYPE:='Region';
   gn_ccid                 NUMBER;
   gn_receipt_method_id    ar_receipt_methods.receipt_method_id%TYPE;
   gn_receipt_method_name  ar_receipt_methods.name%TYPE;
   gd_gl_date              DATE;
   gc_country_code         VARCHAR2(10);


   --Procedure to validate records
   PROCEDURE validate_invoice_data (x_errbuf       OUT VARCHAR2
                                   ,x_retcode      OUT VARCHAR2
                                   ,p_debug        IN  VARCHAR2
                                   ,p_purge_data   IN  VARCHAR2
                                  );


   --Procedure to insert records into interface table
   PROCEDURE process_invoice_data (x_errbuf        OUT VARCHAR2
                                    ,x_retcode     OUT VARCHAR2
                                  );


   --Procedure to validate payments records
   PROCEDURE VALIDATE_PAYMENT_DATA (
                                 x_errbuf          OUT VARCHAR2
                                ,x_retcode         OUT VARCHAR2
                                ,p_debug           IN  VARCHAR2
                                ,p_gl_date         IN  VARCHAR2
                             );


   --Procedure to process payment records
   PROCEDURE PROCESS_PAYMENT_DATA (
                                x_errbuf           OUT VARCHAR2
                               ,x_retcode          OUT VARCHAR2
                               );


END XXHA_AR_INV_PYMT_CONV_PK;
/


CREATE OR REPLACE PACKAGE BODY
   XXHA_AR_INV_PYMT_CONV_PK
-- +===================================================================+
-- |                        Oracle NAIO (India)                        |
-- |                         Bangalore, India                          |
-- +===================================================================+
-- |                                                                   |
-- |Name         :XXHA_AR_INV_PYMT_CONV_PK                             |
-- |                                                                   |
-- |Description  :Package to convert Invoices and Payments             |
-- |              from legacy to oracle base table                     |
-- |                                                                   |
-- |                                                                   |
-- |Change Record:                                                     |
-- |===============                                                    |
-- |Version   Date        Author           Remarks                     |
-- |=======   ==========  =============    ============================|
-- |DRAFT 1A 18-Nov-2006  Subramanya S.N    Initial draft version      |
-- |1.0      29-Jan-2007  Subramanya S.N    Added validation logic     |
-- |                                        for Offset segment         |
-- |1.1      09-Feb-2007   Subramanya S.N    Commented logic that gets
-- |                                      shipto info for Rec
-- |1.2      13-Feb-2007  Subbu           Modified Err Msg
-- |1.3      24-FEB-2007  Subbu           Added condition to check for
-- |                                      operating unit for vat tax .
-- |                                      Commented out c_tax_type <>'SALES_TAX'
-- |
-- |1.4      08-Mar-2007 Subbu            Added logic to validate INVOICEDATE
-- |                                       and pass it as TRX_DATE
-- |         26-Mar-2007 Subbu            Commented period chck for sysdate
-- |1.5      30-Mar-2007 subbu           Added condition to check invoicenumber for
-- |                                     oracletransactiontype 'P'
-- |                                     Logic to pass the oracleidentifir as recipt number
-- |1.6      04-Apr-2007 Subbu           Added standard functionABS to pass positive amount
-- |                                     Pass oracleidentifier to partial pay API .receipt number
-- |                                     Modified the mapping between Conversion rat and Conversion type
-- |1.7      24-Apr-2007 Subbu           added logic to pass dateposted/invoice date to receipt date parameter
-- |                                     Removed duplicate check cursor for payments
-- |1.8      26-JUN-2007 P.Rajack        Modified validation to allow duplicate inv numbers with batch source and ou
-- |1.9      30-JUN-2007 P.Rajack        Modified validation for dup chk of inv number on staging table
-- |1.10     05-JUL-2007 P.Rajack        Passed parameter date to receipt date in api
-- |2.00     14-MAR-2011 BMarcoux        Modified Batch Source for Conversion_Inv1 and Conversion_CM1.
-- |2.10     22-JUL-2011 BMarcoux        Modified to allow processing of TaxCode and for Deferred Tax Processing
-- |3.00     19-MAR-2013 BMarcoux        Modifications for RxC Processing.
-- +===================================================================+
AS

-- +===================================================================+
-- | Name        :  UPDATE_RECORD_STATUS                               |
-- | Description :  Procedure to update  the status of processd        |
-- |                records                                            |
-- | Parameters  :  p_orc_identifier                                   |
-- |                p_status_flag                                      |
-- |                                                                   |
-- | Returns     :  NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
PROCEDURE UPDATE_RECORD_STATUS(
                               p_orc_identifier  IN      VARCHAR2
                              ,p_status_flag     IN      VARCHAR2
                              )
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   UPDATE  usbpcs_ar_cleaned HC
   SET     HC.charuserfld4     =   p_status_flag
   WHERE   HC.oracleidentifier =   p_orc_identifier;

   COMMIT;
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Error in XXHA_AR_INV_PYMT_CONV_PK.UPDATE_RECORD_STATUS: ' || SQLERRM);
   RAISE;
END UPDATE_RECORD_STATUS;

-- +===================================================================+
-- | Name       :   INSERT_ERROR_MSG                                   |
-- | Description:   Procedure to call xxsc_common_utilities            |
-- |                to insert errors into error table                  |
-- |                records                                            |
-- | Parameters :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- | Returns    :   NONE                                               |
-- |                ;                                                  |
-- |                                                                   |
-- +===================================================================+
PROCEDURE INSERT_ERROR_MSG
IS
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gc_request_id
                                             ,gc_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                            );

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_COMMON_UTILITIES_PKG.INSERT_ERROR_MSG. Error is: ' ||SQLERRM);
END INSERT_ERROR_MSG;

-- +===================================================================+
-- | Name       :   CHECK_INVOICE_SETUP                                |
-- |                                                                   |
-- | Description:   Function to check setup`s for Invoice/Payments     |
-- |                                                                   |
-- |                                                                   |
-- | Parameters :   NONE                                               |
-- |                                                                   |
-- |                                                                   |
-- | Returns    :   Returns Y/N                                        |
-- |                                                                   |
-- |                                                                   |
-- +===================================================================+
FUNCTION CHECK_INVOICE_SETUP RETURN VARCHAR2
IS
   lc_sourcename_flag            VARCHAR2(1):='Y';
   lc_profile_flag               VARCHAR2(1):='N';
   lc_profile_err_flag           VARCHAR2(1):='Y';
   lc_desc_flex_att1_flag        VARCHAR2(1):='Y';
   lc_desc_flex_att2_flag        VARCHAR2(1):='Y';
   lc_desc_flex_link_att1_flag   VARCHAR2(1):='Y';
   lc_desc_flex_link_att2_flag   VARCHAR2(1):='Y';
   lc_conv_type_flag             VARCHAR2(1):='Y';
   lc_terr_name_flag             VARCHAR2(1):='Y';
   lc_gl_date_flag               VARCHAR2(1):='Y';
   lc_linetypeline_flag          VARCHAR2(1):='Y';
   lc_chk_recpt_mtd_flag         VARCHAR2(1):='Y';
   lc_linetypefrgt_flag          VARCHAR2(1):='Y';
   lc_tax_cal_flag               VARCHAR2(1):='Y';
   lc_linetypetax_flag           VARCHAR2(1):='Y';
   lc_desflex_flag               VARCHAR2(1):='Y';
   lc_transtype_flag_inv         VARCHAR2(1):='Y';
   lc_transtype_flag_cm          VARCHAR2(1):='Y';
   lc_application_flag           VARCHAR2(1):='Y';
   lc_taxcode_flag               VARCHAR2(1):='Y';
   lc_taxcode_flag_def           VARCHAR2(1):='Y';
   lc_sourcename_inv_flag        VARCHAR2(1):='Y';
   lc_sourcename_cm_flag         VARCHAR2(1):='Y';
   lc_desflex_enable_flag        VARCHAR2(1):='Y';
   lc_deslink_enable_flag        VARCHAR2(1):='Y';
   lc_rec_exist_flag             VARCHAR2(1):='Y';
   lc_country_code               VARCHAR2(100);
   ln_rec_cnt                    NUMBER:=0;
   lc_tax_type                   AR_VAT_TAX_ALL.TAX_TYPE%TYPE;
   lc_adhoc                      AR_VAT_TAX_ALL.validate_flag%TYPE;
   lc_post_to_gl_flag            RA_CUST_TRX_TYPES_ALL.post_to_gl%TYPE;

   -------------------------------------------------------------
   --Cursor to check if records exist in the Staging table
   -------------------------------------------------------------
   CURSOR lcu_chk_data_exist
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned;

   ---------------------------------------------------
   -- Cursor to get Current Operating Unit Information
   ---------------------------------------------------
   CURSOR  lcu_get_org_info
   IS
   SELECT  HOU.organization_id
          ,HOU.name
          ,HOU.set_of_books_id
          ,GL.currency_code
          ,GL.chart_of_accounts_id
   FROM    hr_operating_units   HOU
          ,gl_sets_of_books     GL
   WHERE   HOU.organization_id =FND_PROFILE.VALUE('ORG_ID')
   AND     GL.set_of_books_id  =HOU.set_of_books_id;

   ---------------------------------------------------
   -- Cursor to get Current Application Id
   ---------------------------------------------------
   CURSOR lcu_get_appl_id
   IS
   SELECT FA.application_id
   FROM   fnd_application FA
   WHERE  FA.application_short_name ='SQLGL';

   -----------------------------------------------------------------------
   -- Cursor to derive the country code based on the opearating unit name
   ----------------------------------------------------------------------
   CURSOR lcu_get_country_code
   IS
   SELECT charuserfld1
   FROM   usbpcs_ar_cleaned UAC
   WHERE  operatingunit=gc_org_name
   AND    ROWNUM=1;

   -------------------------------------------------------
   --Cursor to check if Batch Source Names are defined
   -------------------------------------------------------
   CURSOR  lcu_chk_source_name(p_source_name VARCHAR2)
   IS
   SELECT 'Y'
   FROM   ra_batch_sources RBS
   WHERE  RBS.batch_source_type   =   gc_batch_source_type
   AND    RBS.name                =   p_source_name
   AND    RBS.org_id              =   FND_PROFILE.VALUE ('ORG_ID');

   -----------------------------------------------------------------------------------
   -- Cursor to check if Profile option "Tax:Allow Override of Customers Exemption"
   -- has been set to 'N'
   ------------------------------------------------------------------------------------
   CURSOR  lcu_chk_profile_value
   IS
   SELECT FPOV.profile_option_value
   FROM   fnd_profile_options FPO
         ,fnd_profile_option_values FPOV
   WHERE  FPO.profile_option_name  ='AR_ALLOW_TRX_LINE_EXEMPTIONS'
   AND    FPO.profile_option_id    =FPOV.PROFILE_OPTION_ID;

   --------------------------------------------
   --Cursor to check for LINE TYPE lookup codes
   --------------------------------------------
   CURSOR lcu_chk_linetype_lookup(p_line_type VARCHAR2)
   IS
   SELECT 'Y'
   FROM   fnd_lookup_values FLV
   WHERE  FLV.lookup_code=p_line_type
   AND    FLV.lookup_type='STD_LINE_TYPE'
   AND    FLV.language='US'
   AND    SYSDATE BETWEEN NVL(FLV.start_date_active,SYSDATE)
   AND    NVL(FLV.end_date_active,SYSDATE);

   ---------------------------------------------
   --Cursor to check CONVERSION TYPE lookup code
   ---------------------------------------------
   CURSOR lcu_chk_convtype_lookup
   IS
   SELECT 'Y'
   FROM   fnd_lookup_values FLV
   WHERE  FLV.lookup_code='U'
   AND    FLV.lookup_type='CURRENCY_CONVERSION_TYPE'
   AND    FLV.language='US'
   AND    SYSDATE BETWEEN NVL(FLV.start_date_active,SYSDATE)
   AND    NVL(FLV.end_date_active,SYSDATE);

   ---------------------------------------------------
   --Cursor to check if TRANSACTION TYPE`s are Defined
   ---------------------------------------------------
   --Changes made by subbu as on Jan9 2007
   --Added tax_calculation_flag
   CURSOR lcu_chk_tran_type(p_tran_type VARCHAR2)
   IS
   SELECT 'Y'
         ,RCTT.post_to_gl
         ,RCTT.CUST_TRX_TYPE_ID
         ,tax_calculation_flag
   FROM   ra_cust_trx_types RCTT
   WHERE  RCTT.name = p_tran_type
   AND    SYSDATE BETWEEN NVL(RCTT.start_date ,SYSDATE)
   AND    NVL(RCTT.end_date,SYSDATE);

   -----------------------------------------------------
   -- Cursor to check if Receipt Class methods are defined
   -----------------------------------------------------
   CURSOR lcu_chk_recpt_mtd(p_receipt_name VARCHAR2)
   IS
   SELECT ARM.receipt_method_id
   FROM   ar_receipt_methods ARM
   WHERE  ARM.name =p_receipt_name;

   --------------------------------------------------------
   --Cursor to check if Tax Code ('Conversion' (aka gc_tax_code)) has been defined
   -------------------------------------------------------
   CURSOR lcu_chk_tax_code
   IS
   SELECT 'Y'
          ,AVTA.tax_type
          ,AVTA.validate_flag
   FROM   ar_vat_tax_all  AVTA
   WHERE  AVTA.tax_code = gc_tax_code
   AND    SYSDATE BETWEEN NVL(AVTA.start_date,SYSDATE)
   AND    NVL(AVTA.end_date,SYSDATE)
   --Start of changes 1.3
   AND    AVTA.org_id=gn_org_id;
   --End of changes 1.3


   --------------------------------------------------------------------
   --Cursor to check if Interface Line Context 'Conversion_Inv','Conversion_CM'
   --has been Defined
   --------------------------------------------------------------------
   CURSOR lcu_chk_desc_flex
   IS
   SELECT FDFCV.enabled_flag
   FROM   fnd_descr_flex_contexts_vl FDFCV
   WHERE  FDFCV.descriptive_flex_context_code=gc_flex_context_code
   AND    FDFCV.descriptive_flexfield_name='RA_INTERFACE_LINES';


   ---------------------------------------------------
   --Cursor to check if Link to the above line Context
   -- has been Defined
   ---------------------------------------------------
   CURSOR lcu_chk_desc_flex_link(p_desc_flex_name VARCHAR2)
   IS
   SELECT FDFCV.enabled_flag
   FROM  fnd_descr_flex_contexts_vl FDFCV
   WHERE FDFCV.descriptive_flex_context_code=gc_flex_context_code
   AND   FDFCV.descriptive_flexfield_name=p_desc_flex_name;


   -------------------------------------------------------------------------------
   -- Cursor to Check if the attrbutes INTERFACE_LINE_ATTRIBUTE1 ,INTERFACE_LINE_ATTRIBUTE2
   -- are defined for Line context
   ------------------------------------------------------------------------------
   CURSOR chk_desc_flex_segment_att1
   IS
   SELECT 'Y'
   FROM   fnd_descr_flex_col_usage_vl FDFCUV
   WHERE  FDFCUV.descriptive_flexfield_name    ='RA_INTERFACE_LINES'
   AND    FDFCUV.descriptive_flex_context_code =gc_flex_context_code
   AND    FDFCUV.application_column_name       ='INTERFACE_LINE_ATTRIBUTE1';

   CURSOR chk_desc_flex_segment_att2
   IS
   SELECT 'Y'
   FROM   fnd_descr_flex_col_usage_vl FDFCUV
   WHERE  FDFCUV.descriptive_flexfield_name    ='RA_INTERFACE_LINES'
   AND    FDFCUV.descriptive_flex_context_code =gc_flex_context_code
   AND    FDFCUV.application_column_name       ='INTERFACE_LINE_ATTRIBUTE2';


   -------------------------------------------------------------------------------
   -- Check if the attrbutes LINK_TO_LINE_ATTRIBUTE2 ,LINK_TO_LINE_ATTRIBUTE2
   -- are defined for Line context
   ------------------------------------------------------------------------------
   CURSOR chk_desc_flex_link_att1
   IS
   SELECT 'Y'
   FROM   fnd_descr_flex_col_usage_vl FDFCUV
   WHERE  FDFCUV.descriptive_flexfield_name     ='RA_INTERFACE_LINK_TO'
   AND    FDFCUV.descriptive_flex_context_code  =gc_flex_context_code
   AND    FDFCUV.application_column_name        ='LINK_TO_LINE_ATTRIBUTE1';

   CURSOR chk_desc_flex_link_att2
   IS
   SELECT 'Y'
   FROM   fnd_descr_flex_col_usage_vl FDFCUV
   WHERE  FDFCUV.descriptive_flexfield_name     ='RA_INTERFACE_LINK_TO'
   AND    FDFCUV.descriptive_flex_context_code  =gc_flex_context_code
   AND    FDFCUV.application_column_name        ='LINK_TO_LINE_ATTRIBUTE2';


   ------------------------------------------------------------
   --Cursor to Check if Territory name has beed set to 'Region'
   -------------------------------------------------------------
   CURSOR lcu_chk_territory_name
   IS
   SELECT 'Y'
   FROM   ar_system_parameters ASP
   WHERE  ASP.ai_territory_key_left_prompt=gc_territory_name;


   -------------------------------------------------------------------------
   -- Cursor to check if Current Transaction date is Opened in the GL Periods
   -------------------------------------------------------------------------
   CURSOR lcu_chk_gl_date
   IS
   SELECT 'Y'
   FROM  gl_period_statuses GPS
         ,fnd_application FA
   WHERE GPS.closing_status ='O'
   AND   TRUNC(SYSDATE) BETWEEN NVL(TRUNC(GPS.start_date),TRUNC(SYSDATE))
   AND   NVL(TRUNC(GPS.end_date),TRUNC(SYSDATE))
   --AND GPS.application_id=gn_application_id
    AND FA.application_short_name='AR'
   AND GPS.set_of_books_id=gc_set_of_books_id;

BEGIN

    --------------------------------------------
    --Check if records exist in the Staging table
    ---------------------------------------------
    OPEN lcu_chk_data_exist;
    FETCH lcu_chk_data_exist INTO ln_rec_cnt;
    CLOSE lcu_chk_data_exist;

    IF ln_rec_cnt =0 THEN
       --Log error
       gc_error_code :='SETUP-Error';
       gc_error_msg  :='There exist no records in the staging table';
       gc_comments   :='Please provide some Data';
       INSERT_ERROR_MSG;
       lc_rec_exist_flag:='N';
    END IF;

    -----------------------------------------
    --Get Operating unit Information
    -----------------------------------------
    OPEN  lcu_get_org_info;
    FETCH lcu_get_org_info INTO gn_org_id,gc_org_name,gc_set_of_books_id,gc_currency_code,gn_chart_of_accounts_id;
    CLOSE lcu_get_org_info;

   --------------------
   --Get Application Id
   --------------------
   OPEN  lcu_get_appl_id;
   FETCH lcu_get_appl_id INTO gn_application_id;
      IF lcu_get_appl_id%NOTFOUND THEN
         --Log error
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='Application Short name SQLGL(GL_TOP) is not defined';
         gc_comments   :='Please define this Application TOP';
         INSERT_ERROR_MSG;
         lc_application_flag:='N';
      END IF;
   CLOSE lcu_get_appl_id;

   -------------------------------------------------------------------------------
   --Check if Batch Source Names "Conversion_Inv" and "Conversion_CM" are defined
   -------------------------------------------------------------------------------
   --Conversion_Inv

   OPEN  lcu_chk_source_name(gc_batch_name_inv);
   FETCH lcu_chk_source_name INTO lc_sourcename_inv_flag;
      IF lcu_chk_source_name%NOTFOUND THEN
         --Log error
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='Batch Source: '||gc_batch_name_inv||' is not defined';
         gc_comments   :='Please define this Batch source ';
         INSERT_ERROR_MSG;
         lc_sourcename_inv_flag:='N';
      END IF;
   CLOSE lcu_chk_source_name;
   gc_log_msg:='Flag returned by the Batch source for Conversion_Inv: '||lc_sourcename_inv_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --Conversion_CM

   OPEN  lcu_chk_source_name(gc_batch_name_cm);
   FETCH lcu_chk_source_name INTO lc_sourcename_cm_flag;
      IF lcu_chk_source_name%NOTFOUND THEN
         --Log error
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='Batch Source: '||gc_batch_name_cm||' is not defined';
         gc_comments   :='Please define this Batch source ';
         INSERT_ERROR_MSG;
         lc_sourcename_cm_flag:='N';
      END IF;
   CLOSE lcu_chk_source_name;
   gc_log_msg:='Flag returned by the Batch source for Conversion_CM: '||lc_sourcename_cm_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ---------------------------------------------------------------------------
   --Check if Profile option value "Tax:Allow Override of Customers Exemption "
   -- has been set to 'N'
   ----------------------------------------------------------------------------
   lc_profile_flag     :='N';
   lc_profile_err_flag :='Y';
   OPEN  lcu_chk_profile_value;
   FETCH lcu_chk_profile_value INTO lc_profile_flag;
   CLOSE lcu_chk_profile_value;

   IF  lc_profile_flag ='N' THEN
       --Log error
       gc_error_code   :='SETUP-Error';
       gc_error_msg    :='Profile "Tax:Allow Override of Customers Exemption" has been set as Y';
       gc_comments     :='Please set the value to N ';
       INSERT_ERROR_MSG;
       lc_profile_err_flag:='N';
   END IF;
   gc_log_msg:='Flag returned by the Profile Option cursor: '||lc_profile_err_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ------------------------------------
   --Check if LINE_TYPE LINE is Define
   ------------------------------------
   OPEN  lcu_chk_linetype_lookup(gc_line_lookup);
   FETCH lcu_chk_linetype_lookup INTO  lc_linetypeline_flag;
      IF lcu_chk_linetype_lookup%NOTFOUND THEN
         --Log err
         gc_error_code:='SETUP-Error';
         gc_error_msg :='Line Type :'||gc_line_lookup||' is not defined in the Lookup table';
         gc_comments  :='Please define this Line Type';
         INSERT_ERROR_MSG;
         lc_linetypeline_flag:='N';
      END IF;
   CLOSE lcu_chk_linetype_lookup;
   gc_log_msg:='Flag returned by the Lookup code cursor for line type LINE:'||lc_linetypeline_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ------------------------------------
   --Check if LINE_TYPE TAX is Define
   ------------------------------------
   OPEN  lcu_chk_linetype_lookup(gc_tax_lookup);
   FETCH lcu_chk_linetype_lookup INTO  lc_linetypetax_flag;
      IF lcu_chk_linetype_lookup%NOTFOUND THEN
         --Log err
         gc_error_code:='SETUP-Error';
         gc_error_msg :='Line Type :'||gc_tax_lookup||' is not defined in the Lookup table';
         gc_comments  :='Please define this Line Type';
         INSERT_ERROR_MSG;
         lc_linetypetax_flag:='N';
      END IF;
   CLOSE lcu_chk_linetype_lookup;
   gc_log_msg:='Flag returned by the Lookup code cursor for line type TAX:'||lc_linetypetax_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ------------------------------------
   --Check if LINE_TYPE FREIGHT is Define
   ------------------------------------
   OPEN  lcu_chk_linetype_lookup(gc_freight_lookup);
   FETCH lcu_chk_linetype_lookup INTO  lc_linetypefrgt_flag;
      IF lcu_chk_linetype_lookup%NOTFOUND THEN
         --Log err
         gc_error_code:='SETUP-Error';
         gc_error_msg :='Line Type :'||gc_freight_lookup||' is not defined in the Lookup table';
         gc_comments  :='Please define this Line Type';
         INSERT_ERROR_MSG;
         lc_linetypefrgt_flag:='N';
      END IF;
   CLOSE lcu_chk_linetype_lookup;
   gc_log_msg:='Flag returned by the Lookup code cursor for line type FREIGHT:'||lc_linetypefrgt_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ---------------------------------------------
   --Cursor to check CONVERSION TYPE lookup code
   ---------------------------------------------
   OPEN lcu_chk_convtype_lookup;
   FETCH lcu_chk_convtype_lookup INTO lc_conv_type_flag;
      IF lcu_chk_convtype_lookup%NOTFOUND THEN
          --Log err
          gc_error_code:='SETUP-Error';
          gc_error_msg :='Conversion Type User is not defined in the Lookup table';
          gc_comments  :='Please define this Conversion Type';
          INSERT_ERROR_MSG;
          lc_conv_type_flag:='N';
      END IF;
   CLOSE lcu_chk_convtype_lookup;
   gc_log_msg:='Flag returned by the Lookup code cursor for  Conversion type :'||lc_conv_type_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --------------------------------------------
   --Check if if TRANSACTION TYPE`s are Defined
   --------------------------------------------

   ---------------------------------------------
   --Get the country code from the staging table
   --based on the operating unit name
   --------------------------------------------
   OPEN  lcu_get_country_code;
   FETCH lcu_get_country_code INTO  lc_country_code;
   CLOSE lcu_get_country_code;

   IF  lc_country_code IS NOT NULL THEN ----Added by subbu as on Jan08

       gc_trx_type_inv:='Convrsion RxC AR Inv';    -- 3.00 Modifications for RxC Processing
       gc_trx_type_cm :='Convrsion RxC Credit';    -- 3.00 Modifications for RxC Processing
       --gc_trx_type_inv:=lc_country_code||' Conv Inv';
       --gc_trx_type_cm :=lc_country_code||' Conv CM';
       --Check for XX Conv Inv
       OPEN  lcu_chk_tran_type(gc_trx_type_inv);
       FETCH lcu_chk_tran_type INTO lc_transtype_flag_inv,lc_post_to_gl_flag,gc_trx_type_inv_id,lc_tax_cal_flag;
          IF lcu_chk_tran_type%NOTFOUND THEN
             --Log error
             gc_error_code       :='SETUP-Error';
             gc_error_msg        :='Transaction Type: '||gc_trx_type_inv||' is not defined';
             gc_comments         :='Please define this Transaction type';
             INSERT_ERROR_MSG;
             lc_transtype_flag_inv:='N';
          ELSE

             IF  lc_post_to_gl_flag ='Y' THEN
                 --Log error
                 gc_error_code       :='SETUP-Error';
                 gc_error_msg        :='Post to GL option for Transaction Type: '||gc_trx_type_inv||' has been set to Y';
                 gc_comments         :='Please disable this option';
                 INSERT_ERROR_MSG;
                 lc_transtype_flag_inv:='N';
             END IF;


             IF  lc_tax_cal_flag <>'N' THEN
             	  --Log error
             	  gc_error_code       :='SETUP-Error';
             	  gc_error_msg        :='Tax Calculation option for Transaction Type: '||gc_trx_type_inv||' has been set to Y';
             	  gc_comments         :='Please disable this option';
             	  INSERT_ERROR_MSG;
             	  lc_transtype_flag_inv:='N';

             END IF;

          END IF;

       CLOSE lcu_chk_tran_type;
       gc_log_msg:='Flag returned by the Transaction Type  cursor for XX Conv Inv :'||lc_transtype_flag_inv;
       xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


      --Check for XX Conv CM
      lc_post_to_gl_flag:=NULL;
      OPEN  lcu_chk_tran_type(gc_trx_type_cm);
      FETCH lcu_chk_tran_type INTO lc_transtype_flag_cm,lc_post_to_gl_flag,gc_trx_type_cm_id,lc_tax_cal_flag;
         IF lcu_chk_tran_type%NOTFOUND THEN
            --Log error
            gc_error_code       :='SETUP-Error';
            gc_error_msg        :='Transaction Type: '||gc_trx_type_cm||' is not defined';
            gc_comments         :='Please define this Transaction type';
            INSERT_ERROR_MSG;
            lc_transtype_flag_cm:='N';
         ELSE


           IF  lc_post_to_gl_flag ='Y' THEN
               --Log error
               gc_error_code       :='SETUP-Error';
               gc_error_msg        :='Post to GL option for Transaction Type: '||gc_trx_type_cm||' has been set to Y';
               gc_comments         :='Please disable this option';
               INSERT_ERROR_MSG;
               lc_transtype_flag_cm:='N';
           END IF;

           IF  lc_tax_cal_flag <>'N' THEN
           	  --Log error
           	  gc_error_code       :='SETUP-Error';
           	  gc_error_msg        :='Tax Calculation option for Transaction Type: '||gc_trx_type_cm||' has been set to Y';
           	  gc_comments         :='Please disable this option';
           	  INSERT_ERROR_MSG;
           	  lc_transtype_flag_inv:='N';
           END IF;

     END IF;

      CLOSE lcu_chk_tran_type;
      gc_log_msg:='Flag returned by the Transaction Type cursor XX Conv CM:'||lc_transtype_flag_cm;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

      -------------------------------------------------
      -- Check if Receipt Class methods are defined
      -------------------------------------------------
      lc_chk_recpt_mtd_flag :='Y';
      gn_receipt_method_name:=lc_country_code||' Conv Receipts';
      OPEN  lcu_chk_recpt_mtd(gn_receipt_method_name);
      FETCH lcu_chk_recpt_mtd INTO gn_receipt_method_id ;
         IF lcu_chk_recpt_mtd%NOTFOUND THEN
            --Log error
            gc_error_code       :='SETUP-Error';
            gc_error_msg        :='Receipt Class Method :'||gn_receipt_method_name||' is not defined';
            gc_comments         :='Please Enable this Receipt Method';
            INSERT_ERROR_MSG;
            lc_chk_recpt_mtd_flag:='N';
         END IF;
      CLOSE lcu_chk_recpt_mtd;
      gc_log_msg:='Flag returned by the Transaction Type cursor XX Conv CM:'||lc_chk_recpt_mtd_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


  ELSE
       --Log error
       gc_error_code       :='SETUP-Error';
       gc_error_msg        :='No Country code found for the Operating unit '||gc_org_name;
       gc_comments         :='Please provide a country code';
       INSERT_ERROR_MSG;
       lc_transtype_flag_inv:='N';
  END IF; --Added by subbu as on Jan08

  ------------------------------------
  --Check if Tax Code (gc_tax_code) has been Defined
  ------------------------------------
  lc_taxcode_flag :=NULL;
  lc_adhoc        :=NULL;
  OPEN  lcu_chk_tax_code;
  FETCH lcu_chk_tax_code INTO lc_taxcode_flag,lc_tax_type,lc_adhoc;
     IF lcu_chk_tax_code%NOTFOUND THEN
        gc_error_code       :='SETUP-Error';
        gc_error_msg        :='Tax Code: '||gc_tax_code||' not Defined';
        gc_comments         :='Please Define this Tax Code';
        INSERT_ERROR_MSG;
        lc_taxcode_flag:='N';
     ELSE
         --Start of changes 1.3
        --IF lc_tax_type <>'SALES_TAX' THEN
         IF lc_tax_type NOT IN ('SALES_TAX','VAT') THEN
          --End of changes 1.3
           gc_error_code       :='SETUP-Error';
           gc_error_msg        :='Tax type of Tax Code: '||gc_tax_code||' is not a SALES TAX';
           gc_comments         :='Please Define this as SALES TAX type';
           INSERT_ERROR_MSG;
            lc_taxcode_flag:='N';
         END IF;

         IF lc_adhoc <>'Y' THEN
              gc_error_code       :='SETUP-Error';
              gc_error_msg        :='The Adhoc option of Tax Code: '||gc_tax_code||' is not enabled';
              gc_comments         :='Please enable the Adhoc option';
              INSERT_ERROR_MSG;
              lc_taxcode_flag:='N';
         END IF;

     END IF;
  CLOSE lcu_chk_tax_code;
  gc_log_msg:='Flag returned by the Tax Code Cursor :'||lc_taxcode_flag;
  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


  --Changes as on Jan 08 by subbu

  FOR I IN 1..2 LOOP
     IF I=1 THEN
        gc_flex_context_code:='Conversion_Inv_RX';  -- 3.00 Modifications for RxC Processing
--        gc_flex_context_code:='Conversion_Inv1';  -- 2.00 Bmarcoux
--        gc_flex_context_code:='Conversion_Inv';  -- 2.00 Bmarcoux
     ELSE
        gc_flex_context_code:='Conversion_CM_RX';   -- 3.00 Modifications for RxC Processing
--        gc_flex_context_code:='Conversion_CM1';   -- 2.00 Bmarcoux
--        gc_flex_context_code:='Conversion_CM';   -- 2.00 Bmarcoux
     END IF;

     -------------------------------------------------
     --Check if Descriptive flexfield has been Defined
     -------------------------------------------------
 	OPEN  lcu_chk_desc_flex;
 	FETCH lcu_chk_desc_flex INTO lc_desflex_enable_flag;
 	IF lcu_chk_desc_flex%NOTFOUND THEN
 	      gc_error_code       :='SETUP-Error';
 	      gc_error_msg        :='Interface Line Context: '||gc_flex_context_code||' not Defined';
 	      gc_comments         :='Please define this Descriptive flexfield';
 	      INSERT_ERROR_MSG;
 	      lc_desflex_flag:='N';
 	   ELSE
 	      -----------------------------------
 	      --Check if the flexfield is Enabled
 	      -----------------------------------
 	      IF lc_desflex_enable_flag <>'Y' THEN
 	         gc_error_code       :='SETUP-Error';
 	         gc_error_msg        :='Interface Line Context: '||gc_flex_context_code||' is not Enabled';
 	         gc_comments         :='Please Enable the Interface Line Context';
 	         INSERT_ERROR_MSG;
 	         lc_desflex_flag:='N';
 	      END IF;
 	      ------------------------------------------------------------------------------
 	      --Check if the attrbutes INTERFACE_LINE_ATTRIBUTE1 ,INTERFACE_LINE_ATTRIBUTE2
 	      -- are defined for Line context
 	      ------------------------------------------------------------------------------
 	      OPEN  chk_desc_flex_segment_att1;
 	      FETCH chk_desc_flex_segment_att1 INTO lc_desc_flex_att1_flag;
 	         IF chk_desc_flex_segment_att1%NOTFOUND THEN
 	             gc_error_code       :='SETUP-Error';
 	             gc_error_msg        :='Segment INTERFACE_LINE_ATTRIBUTE1 has not attached to the Descriptive flexfield Context: '||gc_flex_context_code;
 	             gc_comments         :='Please attach the Segment INTERFACE_LINE_ATTRIBUTE1';
 	             INSERT_ERROR_MSG;
 	             lc_desc_flex_att1_flag:='N';
 	         END IF;
 	      CLOSE chk_desc_flex_segment_att1;
 	      gc_log_msg:='Flag returned by the Descriptive Flexfield INTERFACE_LINE_ATTRIBUTE1 Cursor :'||lc_desc_flex_att1_flag;
 	      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

 	      OPEN  chk_desc_flex_segment_att2;
 	      FETCH chk_desc_flex_segment_att2 INTO lc_desc_flex_att2_flag;
 	         IF chk_desc_flex_segment_att2%NOTFOUND THEN
 	              gc_error_code       :='SETUP-Error';
 	              gc_error_msg        :='Segment INTERFACE_LINE_ATTRIBUTE2 has not attached to the Descriptive flexfield Context: '||gc_flex_context_code;
 	              gc_comments         :='Please attach the Segment INTERFACE_LINE_ATTRIBUTE1';
 	              INSERT_ERROR_MSG;
 	              lc_desc_flex_att2_flag:='N';
 	         END IF;
 	      CLOSE chk_desc_flex_segment_att2;
 	      gc_log_msg:='Flag returned by the Descriptive Flexfield INTERFACE_LINE_ATTRIBUTE2 Cursor :'||lc_desc_flex_att2_flag;
 	      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

 	      ----------------------------------------------
 	      --Check if Link for flexfield has been defined
 	      ----------------------------------------------
 	      OPEN  lcu_chk_desc_flex_link('RA_INTERFACE_LINK_TO');
 	      FETCH lcu_chk_desc_flex_link INTO lc_deslink_enable_flag;
 	         IF lcu_chk_desc_flex_link%NOTFOUND THEN
 	            gc_error_code       :='SETUP-Error';
 	            gc_error_msg        :='Link for Interface Line Context: '||gc_flex_context_code||' is not Defined';
 	            gc_comments         :='Please create a Link for Interface Line Context';
 	            INSERT_ERROR_MSG;
 	            lc_desflex_flag:='N';
 	         ELSE
 	            ------------------------
 	            --Check if it is Enabled
 	            ------------------------
 	            IF lc_deslink_enable_flag<>'Y' THEN
 	               gc_error_code       :='SETUP-Error';
 	               gc_error_msg        :='Link for Interface Line Context: '||gc_flex_context_code||' is not Enabled';
 	               gc_comments         :='Please Enable the Link for Interface Line Context';
 	               INSERT_ERROR_MSG;
 	               lc_desflex_flag:='N';
 	            END IF;

 	            ------------------------------------------------------------------------------
 	            --Check if the attrbutes LINK_TO_LINE_ATTRIBUTE1 ,LINK_TO_LINE_ATTRIBUTE2
 	            -- are defined for the link
 	            ------------------------------------------------------------------------------
 	            OPEN  chk_desc_flex_link_att1;
 	            FETCH chk_desc_flex_link_att1 INTO lc_desc_flex_link_att1_flag;
 	               IF chk_desc_flex_link_att1%NOTFOUND THEN
 	                   gc_error_code       :='SETUP-Error';
 	                   gc_error_msg        :='Segment LINK_TO_LINE_ATTRIBUTE1 has not attached to the Descriptive flexfield Context: '||gc_flex_context_code;
 	                   gc_comments         :='Please attach the Segment LINK_TO_LINE_ATTRIBUTE1';
 	                   INSERT_ERROR_MSG;
 	                   lc_desc_flex_link_att1_flag:='N';
 	               END IF;
 	            CLOSE chk_desc_flex_link_att1;
 	            gc_log_msg:='Flag returned by the Descriptive Flexfield LINK_TO_LINE_ATTRIBUTE1 Cursor :'||lc_desc_flex_link_att1_flag;
 	            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

 	            OPEN  chk_desc_flex_link_att2;
 	            FETCH chk_desc_flex_link_att2 INTO lc_desc_flex_link_att2_flag;
 	               IF chk_desc_flex_link_att2%NOTFOUND THEN
 	                   gc_error_code       :='SETUP-Error';
 	                   gc_error_msg        :='Segment LINK_TO_LINE_ATTRIBUTE2 has not attached to the Descriptive flexfield Context: '||gc_flex_context_code;
 	                   gc_comments         :='Please attach the Segment LINK_TO_LINE_ATTRIBUTE2';
 	                   INSERT_ERROR_MSG;
 	                   lc_desc_flex_link_att2_flag:='N';
 	               END IF;
 	            CLOSE chk_desc_flex_link_att2;
 	            gc_log_msg:='Flag returned by the Descriptive Flexfield LINK_TO_LINE_ATTRIBUTE1 Cursor :'||lc_desc_flex_link_att2_flag;
 	            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

 	         END IF; --IF lcu_chk_desc_flex_link%NOTFOUND THEN
 	      CLOSE lcu_chk_desc_flex_link;
 	   END IF; --IF lcu_chk_desc_flex%NOTFOUND
 	CLOSE lcu_chk_desc_flex;
 	gc_log_msg:='Flag returned by the Descriptive Flexfield Cursor :'||lc_desflex_flag;
 	xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
 END LOOP;


  ---------------------------------------------------
  -- Check if Territory name has been set to 'Region'
  ---------------------------------------------------

  OPEN  lcu_chk_territory_name;
  FETCH lcu_chk_territory_name INTO lc_terr_name_flag;
     IF lcu_chk_territory_name%NOTFOUND THEN
        --Log error
        gc_error_code :='SETUP-Error';
        gc_error_msg  :='Territory name : '||gc_territory_name||' is not defined';
        gc_comments   :='Please define this Territory name under System Options-->Trans and Customer section ';
        INSERT_ERROR_MSG;
        lc_terr_name_flag:='N';
     END IF;
  CLOSE lcu_chk_territory_name ;
   gc_log_msg:='Flag returned by the Teritory name Cursor :'||lc_terr_name_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --------------------------------------------------------------
   -- Check if Current Transaction date is Opened in the GL dates
   --------------------------------------------------------------
   --Start of Changes 1.4
   /*OPEN  lcu_chk_gl_date;
   FETCH lcu_chk_gl_date INTO lc_gl_date_flag;
      IF lcu_chk_gl_date%NOTFOUND  THEN
         --Log error
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='Current Transaction Date(sysdate) is not opened in Accounting Periods';
         gc_comments   :='Please Open the Current Transaction Date';
         INSERT_ERROR_MSG;
         lc_gl_date_flag:='N';
      END IF;
   CLOSE lcu_chk_gl_date; */
   gc_log_msg:='Flag returned by the GL Date Cursor :'||lc_gl_date_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   --End of Changes 1.4


  ---------------------------------------------------------------
  --If any of the above setup`s are missing, eror out the program
  ---------------------------------------------------------------
  IF (  lc_taxcode_flag             <>'Y' OR
        lc_desflex_flag             <>'Y' OR
        lc_transtype_flag_cm        <>'Y' OR
        lc_transtype_flag_inv       <>'Y' OR
        lc_linetypefrgt_flag        <>'Y' OR
        lc_linetypetax_flag         <>'Y' OR
        lc_linetypeline_flag        <>'Y' OR
        lc_profile_err_flag         <>'Y' OR
        lc_sourcename_cm_flag       <>'Y' OR
        lc_sourcename_inv_flag      <>'Y' OR
        lc_desc_flex_link_att1_flag <>'Y' OR
        lc_desc_flex_link_att2_flag <>'Y' OR
        lc_desc_flex_att1_flag      <>'Y' OR
        lc_desc_flex_att2_flag      <>'Y' OR
        lc_conv_type_flag           <>'Y' OR
        lc_application_flag         <>'Y' OR
        lc_terr_name_flag           <>'Y' OR   --
        lc_gl_date_flag             <>'Y' OR
        lc_chk_recpt_mtd_flag       <>'Y' OR
        lc_rec_exist_flag           <>'Y') THEN      --

      RETURN 'N';
  ELSE
      RETURN 'Y';
   END IF;

EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG, 'Unexpected error encountered while checking Setup in the function CHECK_INVOICE_SETUP  '||SQLERRM);
   RAISE;
END CHECK_INVOICE_SETUP;

-- +===================================================================+
-- | Name          : VALIDATE_INVOICE_DATA                             |
-- | Description   : Procedure to validate invoice records             |
-- |                                                                   |
-- | Parameters    : x_errbuf   OUT                                    |
-- |                 x_errbuf   OUT                                    |
-- |                 p_debug    IN                                     |
-- | Returns       : NONE;                                             |
-- |                                                                   |
-- +===================================================================+
PROCEDURE VALIDATE_INVOICE_DATA (
                              x_errbuf       OUT VARCHAR2
                             ,x_retcode      OUT VARCHAR2
                             ,p_debug         IN VARCHAR2
                             ,p_purge_data    IN VARCHAR2
                             )
IS
   --Local Valribles
   lc_setup_err_flag        VARCHAR2(1):='N';
   lc_mast_prc_err_flag     VARCHAR2(1):='N';
   lc_mast_err_flag         VARCHAR2(1):='N';
   lc_invoice_exist_flag    VARCHAR2(1):='N';
   lc_terms_err_flag        VARCHAR2(1):='N';
   lc_currency_err_flag     VARCHAR2(1):='N';
   lc_bill_err_flag         VARCHAR2(1):='N';
   lc_ship_err_flag         VARCHAR2(1):='N';
   lc_trns_neg_flag         VARCHAR2(1):='N';
   lc_retcode               VARCHAR2(1);
   lc_sales_err_flag        VARCHAR2(1):='N';
   lc_item_flag             VARCHAR2(1):='N';
   lc_concat_segments       VARCHAR2(1000);
   lc_setup_exist           VARCHAR2(1);
   ln_segment_no            NUMBER := 1;
   ln_valid_segment_count   NUMBER := 0;
   lc_seg_values_exists     VARCHAR2(1);
   lc_account_segment_flag  VARCHAR2(1);
   lc_account_offseg_flag   VARCHAR2(1);
   ln_rec_fetched           NUMBER:=0;
   ln_rec_validated         NUMBER:=0;
   ln_rec_errored           NUMBER:=0;
   ln_commit_point          NUMBER:=0;
   ln_lne_cnt               NUMBER;
   lc_invoice               usbpcs_ar_cleaned.invoicenumber%TYPE          :='+0+9';
   lc_transaction           usbpcs_ar_cleaned.oracletransactiontype%TYPE  :='+0+9';
   lc_batch_name            ra_batch_sources.name%TYPE ;
   ln_salesrep_id           ra_salesreps.salesrep_id%TYPE;
   lc_salesrep_number       ra_salesreps.salesrep_number%TYPE;
   ln_sales_credit_type_id  so_sales_credit_types.sales_credit_type_id%TYPE;
   lc_sales_credit          so_sales_credit_types.name%TYPE;
   ln_seqno                 usbpcs_ar_cleaned.sequencenumber%TYPE;
   lc_item_uom              mtl_system_items_b.primary_uom_code%TYPE;
   lc_item_desc             mtl_system_items_b.description%TYPE;
   ln_bcust_acct_site_id    hz_cust_acct_sites_all.cust_acct_site_id%TYPE;
   ln_bcust_account_id      hz_cust_accounts.cust_account_id%TYPE;
   lc_badd_orig_sys_ref     hz_cust_acct_sites_all.orig_system_reference%TYPE;
   lc_bcst_orig_sys_ref     hz_cust_accounts.orig_system_reference%TYPE;
   ln_scust_acct_site_id    hz_cust_acct_sites_all.cust_acct_site_id%TYPE;
   ln_scust_account_id      hz_cust_accounts.cust_account_id%TYPE;
   lc_sadd_orig_sys_ref     hz_cust_acct_sites_all.orig_system_reference%TYPE;
   lc_scst_orig_sys_ref     hz_cust_accounts.orig_system_reference%TYPE;
   lc_seg_value             usbpcs_ar_cleaned.oraclesegment1%TYPE;
   lc_flex_value            fnd_flex_values_vl.flex_value%TYPE;
   lc_segment1              usbpcs_ar_cleaned.oraclesegment1%TYPE;
   lc_segment2              usbpcs_ar_cleaned.oraclesegment2%TYPE;
   lc_segment3              usbpcs_ar_cleaned.oraclesegment3%TYPE;
   lc_segment4              usbpcs_ar_cleaned.oraclesegment4%TYPE;
   lc_segment5              usbpcs_ar_cleaned.oraclesegment5%TYPE;
   lc_segment6              usbpcs_ar_cleaned.oraclesegment6%TYPE;
   lc_segment7              usbpcs_ar_cleaned.oraclesegment7%TYPE;
   lc_segment8              usbpcs_ar_cleaned.oraclesegment8%TYPE;
   lc_segment9              usbpcs_ar_cleaned.oraclesegment9%TYPE;
   ln_terms_id              ra_terms.term_id%TYPE;
   lc_terms_name            ra_terms.name%TYPE;
   ln_rec_accnt_check       NUMBER:=0;
   lc_inv_no                usbpcs_ar_cleaned.invoicenumber%TYPE:='+3+9+1';
   lc_tran_type		    usbpcs_ar_cleaned.oracletransactiontype%TYPE:='+9+';
   lc_oraclesegdummy1       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy2       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy3       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy4       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy5       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy6       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy7       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy8       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   lc_oraclesegdummy9       usbpcs_ar_cleaned.oracleoffsetsegment1%TYPE;
   ld_inv_date              DATE;
   lv_inv_dte_flag          VARCHAR2(1):='N';
   
   lc_taxcodes_err_flag     VARCHAR2(1):='N';                                   -- 2.10 BMarcoux
   ln_taxcodes_id           ar_vat_tax_all.vat_tax_id%TYPE;                     -- 2.10 BMarcoux
   lc_taxcodes_name         ar_vat_tax_all.tax_code%TYPE;                       -- 2.10 BMarcoux

-- 2.10 this is new - START
   lc_dt_tax_type           ar_vat_tax_all.tax_type%TYPE;                       -- 2.10 BMarcoux
   lc_dt_segment1           gl_code_combinations.segment1%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment2           gl_code_combinations.segment2%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment3           gl_code_combinations.segment3%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment4           gl_code_combinations.segment4%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment5           gl_code_combinations.segment5%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment6           gl_code_combinations.segment6%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment7           gl_code_combinations.segment7%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment8           gl_code_combinations.segment8%TYPE;                 -- 2.10 BMarcoux
   lc_dt_segment9           gl_code_combinations.segment9%TYPE;                 -- 2.10 BMarcoux
-- 2.10 this is new - END
   --------------------------------------------------------
   -- Cursor to get all the records from the staging table
   --------------------------------------------------------
   CURSOR lcu_get_invoice_rec
   IS
   SELECT *
   FROM   usbpcs_ar_cleaned UAC
   WHERE UAC.CharUserFld4 is NULL
   AND   UAC.operatingunit  =gc_org_name
 --  AND   UAC.invoicenumber  in (6179201) --8883861
   AND   UAC.oracletransactiontype in ('I','C')
   ORDER BY UAC.invoicenumber
           ,UAC.oracletransactiontype
           ,UAC.sequencenumber;

   -----------------------------------
   --Get Count for total no of records
   -----------------------------------
   CURSOR lcu_get_rec_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('I','C')
   AND   UAC.operatingunit =gc_org_name;
  -- AND   UAC.invoicenumber in (   6179201);

   ----------------------------------------------
   --Get Count for total no of records  Validated
   ----------------------------------------------
   CURSOR lcu_get_rec_val_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('I','C')
   AND   UAC.operatingunit =gc_org_name
 --  AND   UAC.invoicenumber in ( 6179201)
   AND   UAC.CharUserFld4 ='VS';

   ----------------------------------------------
   --Get Count for total no of records  Errored
   ----------------------------------------------
   CURSOR lcu_get_rec_err_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('I','C')
   AND   UAC.operatingunit =gc_org_name
  -- AND   UAC.invoicenumber in ( 6179201)
   AND   UAC.CharUserFld4  ='VE';

   -------------------------------------------------------------------
   -- Cursor to check if Invouice number already exist in the System
   -- modified jun-26 prajack
   -- add org_id to where clause
   -------------------------------------------------------------------
   CURSOR  lcu_chk_invoice_exist(p_trx_no VARCHAR2,p_batch_source VARCHAR2)
   IS
   SELECT   'N'
   FROM     ra_customer_trx_all RCTA
           ,ra_batch_sources  RBS
   WHERE    RCTA.trx_number     =p_trx_no
   AND      RBS.name            =p_batch_source
   AND      RCTA.batch_source_id=RBS.batch_source_id
   AND      RBS.ORG_ID  = FND_PROFILE.VALUE ('ORG_ID');
   -----------------------------------------------------------
   --Cursor to get the sales rep id and sales credit type name
   -----------------------------------------------------------
   CURSOR lcu_get_sales_rep_info(p_salesrep_name VARCHAR2)
   IS
   SELECT  RS.salesrep_id
          ,RS.salesrep_number
          ,SSCT.sales_credit_type_id
          ,SSCT.name
   FROM    ra_salesreps           RS
          ,so_sales_credit_types  SSCT
   WHERE   RS.name                =p_salesrep_name
   AND     RS.status              ='A'
   AND     RS.org_id              =gn_org_id
   AND     RS.sales_credit_type_id=SSCT.sales_credit_type_id
   AND     SYSDATE BETWEEN NVL(RS.start_date_active,SYSDATE)
   AND     NVL(RS.end_date_active,SYSDATE);

   ----------------------------------------------
   --Cursor to check if valid currency code exist
   ----------------------------------------------
   CURSOR lcu_chk_currency(p_currency VARCHAR2)
   IS
   SELECT 'N'
   FROM   fnd_currencies FC
   WHERE  SYSDATE BETWEEN NVL(FC.start_date_active, SYSDATE)
   AND    NVL(FC.end_date_active, SYSDATE)
   AND    FC.currency_code = UPPER(p_currency)
   AND    FC.enabled_flag  = 'Y';

   ---------------------------------------------
   --Cursor to Derive the Term id and Term name
   ---------------------------------------------
   CURSOR lcu_get_term_info (p_term VARCHAR2)
   IS
   SELECT  RT.term_id,RT.name
   FROM    ra_terms RT
          ,haemo_terms_code HTC
   --WHERE   HTC.bpcs_term_code  =TRIM(p_term)
   WHERE   UPPER(HTC.bpcs_term_code_desc)  =UPPER(TRIM(p_term))  --Changed by subbu as on Jan 29
   AND ROWNUM=1
   AND     RT.name             = HTC.oracle_term_code;



--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
   -- 2.10 BMarcoux
   --------------------------------------------------
   -- Cursor to check if tax code exists (Only called if TaxCode is not NULL)
   -------------------------------------------------
  CURSOR lcu_chk_taxcodes_exist(p_taxcodes VARCHAR2)
  IS
  SELECT ttx.tax_code
       , ttx.vat_tax_id
-- 2.10 this is new - START
       , ttx.tax_type
       , gcc.segment1
       , gcc.segment2
       , gcc.segment3
       , gcc.segment4
       , gcc.segment5
       , gcc.segment6
       , gcc.segment7
       , gcc.segment8
       , gcc.segment9
-- 2.10 this is new - END
  FROM   ar_vat_tax_all        ttx
       , gl_code_combinations  gcc                                              -- 2.10 this is new
  WHERE  ttx.tax_code          = p_taxcodes
  AND    ttx.org_id            = gn_org_id
  AND    ttx.TAX_ACCOUNT_ID    = gcc.code_combination_id;                       -- 2.10 this is new

   --------------------------------------------------------
   -- Cursor to derive BILL_TO Customer and Location info
   -------------------------------------------------------
   CURSOR lcu_get_billto_info(p_bill VARCHAR2)
   IS
   SELECT  HCASA.cust_acct_site_id
          ,HCASA.orig_system_reference
          ,HCA.cust_account_id
          ,HCA.orig_system_reference
   FROM    hz_cust_site_uses HCSU
          ,hz_cust_acct_sites_all HCASA
          ,hz_cust_accounts HCA
   WHERE   HCSU.attribute1            =p_bill
   --WHERE   HCSU.site_use_id            =p_bill
   AND     HCSU.cust_acct_site_id      =HCASA.cust_acct_site_id
   AND     HCASA.cust_account_id       =HCA.cust_account_id
   AND     HCSU.site_use_code          ='BILL_TO';

   --------------------------------------------------------
   -- Cursor to derive SHIP_TO Customer and Location info
   -------------------------------------------------------
   --Start of Changes V1.1
  /*
  CURSOR lcu_get_shipto_info(p_ship VARCHAR2)
   IS
   SELECT  HCASA.cust_acct_site_id
          ,HCASA.orig_system_reference
          ,HCA.cust_account_id
          ,HCA.orig_system_reference
   FROM    hz_cust_site_uses HCSU
          ,hz_cust_acct_sites_all HCASA
          ,hz_cust_accounts HCA
  WHERE   HCSU.attribute1            =p_ship
  --WHERE   HCSU.site_use_id            =p_ship
   AND     HCSU.cust_acct_site_id      =HCASA.cust_acct_site_id
   AND     HCASA.cust_account_id       =HCA.cust_account_id
   AND     HCSU.site_use_code          ='SHIP_TO';
   */
   --End of Changes V1.1

   -------------------------------------------------
   -- Cursor to get the GL Flexfield value set names
   -------------------------------------------------
   CURSOR   lcu_vs
   IS
   SELECT   FFVS.flex_value_set_name
   FROM     fnd_id_flex_segments FIFS
           ,fnd_flex_value_sets FFVS
   WHERE    FIFS.flex_value_set_id = FFVS.flex_value_set_id
   AND      FIFS.id_flex_code      ='GL#'
   AND      FIFS.id_flex_num       =gn_chart_of_accounts_id
   AND      FIFS.application_id    =gn_application_id
   ORDER BY FIFS.application_column_name;

   --------------------------------------------------
   -- Cursor to check if item exist
   -------------------------------------------------
  CURSOR lcu_chk_item_exist(p_item VARCHAR2)
  IS
  SELECT 'N'
        ,MSI.primary_uom_code
        ,MSI.description
  FROM  mtl_system_items MSI
        ,mtl_parameters   MP
  WHERE MSI.SEGMENT1=p_item
  AND   MP.organization_id=MSI.organization_id
  AND   MP.master_organization_id=MP.organization_id
  AND   MP.organization_code='MST';
  --AND ORGANIZATION_ID= gn_org_id;


  ---------------------------------------------------------
  --Check if there are more than one line type for 'line'
  --for the same invoice
  --------------------------------------------------------
  CURSOR lcu_chk_line_type_line(p_inv VARCHAR2,p_trantype VARCHAR2)
  IS
  SELECT COUNT('1')
  FROM usbpcs_ar_cleaned UAC
  WHERE UAC.invoicenumber=p_inv
  AND   UAC.oracletransactiontype=p_trantype
  AND   UAC.operatingunit = gc_org_name            -- added pr jun-30
  AND   UAC.linetype='LINE';


BEGIN


   gc_log_msg:='Start of AR Validation';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --Assign the depug parameter to the global variable
   gc_debug_flag:=p_debug;

   gc_record_number    :=NULL;
   gc_record_identifier:=NULL;

   ----------------------------------------
   -- Purge the record from the error table
   ----------------------------------------
   IF (NVL(p_purge_data,'N') = 'Y') THEN
      xxha_common_utilities_pkg.delete_error_prc(p_conc_name=>gc_con_prg_shot_name);
   END IF;

   ----------------
   --Validate setup
   ----------------
   --Call the function "CHECK_INVOICE_SETUP" to check if Setup`s exist
   lc_setup_exist:=check_invoice_setup;

   gc_log_msg:='Status returned by the Setup function CHECK_INVOICE_SETUP :'||lc_setup_exist;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   --If setup`s exist then validate the records from the staging table ,else error out the program
   IF (lc_setup_exist='Y') THEN
      FOR lr_get_invoice_rec IN lcu_get_invoice_rec
      LOOP
         --Re Initialise the variables
          lc_currency_err_flag   :='N';

         gc_record_number       :=lr_get_invoice_rec.oracleidentifier;
         gc_record_identifier   :=lr_get_invoice_rec.invoicenumber||' - Transaction Type: '||lr_get_invoice_rec.oracletransactiontype;



         --Start of Changes V1.4
         lv_inv_dte_flag:='N';
         IF lr_get_invoice_rec.invoicedate IS NOT NULL THEN
           BEGIN
              ld_inv_date:=TO_DATE(lr_get_invoice_rec.invoicedate,'YYYY-MM-DD');
           EXCEPTION
           WHEN OTHERS THEN
             	gc_error_code       :='AR22';
             	gc_error_msg        :='Invalid Invoice Date(INVOICEDATE) :'||lr_get_invoice_rec.invoicedate||' Cannot convert to data format for Invoice no: '||lr_get_invoice_rec.invoicenumber;
             	gc_comments         :='Please provide a valid Invoice Date ';
             	INSERT_ERROR_MSG;
             	lv_inv_dte_flag:='Y';
           END;
         ELSE
             gc_error_code       :='AR22';
             gc_error_msg        :='Invoice Date(INVOICEDATE) cannot be Null';
             gc_comments         :='Please provide a valid Invoice Date ';
             INSERT_ERROR_MSG;
             lv_inv_dte_flag:='Y';
         END IF;
         --End of Changes V1.4



         -----------------------------------------------------------
         -- Check for Duplicate Invoice number in the staging table
         -----------------------------------------------------------
         lc_invoice_exist_flag:='N';
         IF (lr_get_invoice_rec.invoicenumber IS NOT NULL) THEN                  --1
            IF (lc_invoice       <>lr_get_invoice_rec.invoicenumber) OR
               (lc_transaction   <>lr_get_invoice_rec.oracletransactiontype) OR
               (ln_seqno         <> lr_get_invoice_rec.sequencenumber) THEN      --2
               -------------------------------------------------------------
               --Check if the Invoice number already exist in the Base table
               -------------------------------------------------------------
               IF UPPER(lr_get_invoice_rec.oracletransactiontype) ='I' THEN      --3
                  lc_batch_name:=gc_batch_name_inv;
               ELSE
                  lc_batch_name:=gc_batch_name_cm;
               END IF;                                                           --3

               --Check if invoice exist for that batch name
               IF (lc_invoice       <> lr_get_invoice_rec.invoicenumber) OR      --4
                  (lc_transaction   <>lr_get_invoice_rec.oracletransactiontype) THEN
                  OPEN  lcu_chk_invoice_exist(lr_get_invoice_rec.invoicenumber,lc_batch_name);
                  FETCH lcu_chk_invoice_exist INTO lc_invoice_exist_flag;
                     IF lcu_chk_invoice_exist%FOUND THEN                         --5
                        --Log error message
                        gc_error_code       :='AR01';
                        gc_error_msg        :='Invoice Number: '||lr_get_invoice_rec.invoicenumber||' already exists for the Batch Source Name '||lc_batch_name;
                        gc_comments         :='Please use a different Invoice Number';
                        INSERT_ERROR_MSG;
                        lc_invoice_exist_flag:='Y';
                     END IF;                                                     --5
                  CLOSE lcu_chk_invoice_exist;

                   --Check if the First sequence of the record has LINE TYPE 'LINE'
                   IF lr_get_invoice_rec.linetype <>'LINE' THEN                  --6
                      --Log error message
                      gc_error_code       :='AR01';
                      --gc_error_msg        :='This Invoice no does not have LINETYPE LINE: ';
                      gc_error_msg        :='Invoice no: '||lr_get_invoice_rec.invoicenumber||' does not have linetype LINE: ';
                      gc_comments         :='Please provide a record with linetype LINE';
                      INSERT_ERROR_MSG;
                      lc_invoice_exist_flag:='Y';
                   ELSE
                      --Check if there are more then once record with the linetype LINE for a Invoice
                      OPEN  lcu_chk_line_type_line(lr_get_invoice_rec.invoicenumber,lr_get_invoice_rec.oracletransactiontype);
                      FETCH lcu_chk_line_type_line  INTO ln_lne_cnt;
                      CLOSE lcu_chk_line_type_line;
                         IF ln_lne_cnt>1 THEN                                     --7
                            --ERROR
                             gc_error_code       :='AR01';
                             --gc_error_msg        :='This Invoice no has more than one record with linetype LINE: ';
                             gc_error_msg        :='Invoice no: '||lr_get_invoice_rec.invoicenumber||' has more than one record with linetype LINE: ';
                             gc_comments         := NULL;
                             INSERT_ERROR_MSG;
                             lc_invoice_exist_flag:='Y';
                         END IF;                                                  --7
                   END IF;                                                        --6
               END IF;                                                            --4
               lc_invoice     :=lr_get_invoice_rec.invoicenumber;
               lc_transaction :=lr_get_invoice_rec.oracletransactiontype;
               ln_seqno       :=lr_get_invoice_rec.sequencenumber;
            ELSE
               gc_error_code       :='AR02';
               gc_error_msg        :='Duplicate Invoice Number: '||lr_get_invoice_rec.invoicenumber||' in the Staging table';
               gc_comments         :='Please use a different Invoice Number';
               INSERT_ERROR_MSG;
               lc_invoice_exist_flag:='Y';
            END IF;                                                                -- 2
         ELSE
            --Log error message
            gc_error_code       :='AR03';
            gc_error_msg        :='Field Invoicenumber cannot be NULL in the staging table';
            gc_comments         :='Please provide the Invoice Number';
            INSERT_ERROR_MSG;
            lc_invoice_exist_flag:='Y';
         END IF;                                                                  --1
         gc_log_msg:='Flag returned by the Invoice Number vlidation cursor :'||lc_invoice_exist_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         -------------------------------------------------------------------------
         --Check if the Credit Memo transaction types records have negative amounts
         -------------------------------------------------------------------------
         lc_trns_neg_flag:='N';
         IF lr_get_invoice_rec.oracletransactiontype='C' THEN
            IF lr_get_invoice_rec.originalamount > 0 THEN
                --Log error message
                gc_error_code       :='AR04';
                gc_error_msg        :='Field originalamount has a Positive amount for this Credit memo transaction type for the Invoice number: '||lr_get_invoice_rec.invoicenumber;
                gc_comments         :='The document created must have a non-positive total amount because the creation sign for this  transaction type is negative Sign. Please provide a negative figure';
                INSERT_ERROR_MSG;
                lc_trns_neg_flag:='Y';
            END IF;
         ELSE


            IF lr_get_invoice_rec.originalamount <=0 AND lr_get_invoice_rec.linetype <>'TAX' THEN
               --Log error message
               gc_error_code       :='AR05';
               gc_error_msg        :='Invalid Amount for the Invoice Number: '||lr_get_invoice_rec.invoicenumber;
               gc_comments         :='Please provide a Valid amount';
               INSERT_ERROR_MSG;
               lc_trns_neg_flag:='Y';
            END IF;
         END IF;
         gc_log_msg:='Flag returned for Amount checking condition :'||lc_trns_neg_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ---------------
         --Validate Item
         ---------------
         lc_item_flag:='N';
         lc_item_uom :=NULL;
         lc_item_desc:=NULL;

         IF lr_get_invoice_rec.referencenumber is not null then                  --1
            OPEN  lcu_chk_item_exist(lr_get_invoice_rec.referencenumber);
            FETCH lcu_chk_item_exist INTO lc_item_flag,lc_item_uom,lc_item_desc;
               IF lcu_chk_item_exist%NOTFOUND THEN                              --2
                   --Log error message
                  gc_error_code       :='AR06';
                  --gc_error_msg        :='Item no '||lr_get_invoice_rec.referencenumber||' does not exist';
                  gc_error_msg        :='Item no: '||lr_get_invoice_rec.referencenumber||' does not exist for the Invoice Number: '||lr_get_invoice_rec.invoicenumber;
                  gc_comments         :='Please define this Item';
                  INSERT_ERROR_MSG;
                  lc_item_flag:='Y';
               END IF ;                                                         --2
            CLOSE lcu_chk_item_exist;
         END IF;                                                                --1
         gc_log_msg:='Flag returned by the Item cursor :'||lc_item_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         ----------------------------------
         --Derive the Term id and Term name
         ----------------------------------
         lc_terms_err_flag:='N';
         ln_terms_id      :=NULL;
         lc_terms_name    :=NULL;

         IF (UPPER(lr_get_invoice_rec.oracletransactiontype) ='I') THEN --1
            IF (lr_get_invoice_rec.termscode IS NOT NULL) THEN          --2
               OPEN  lcu_get_term_info(lr_get_invoice_rec.termscode);
               FETCH lcu_get_term_info INTO ln_terms_id,lc_terms_name;
                  IF lcu_get_term_info%NOTFOUND THEN                    --3
                     --Log error message
                     gc_error_code       :='AR07';
                     gc_error_msg        :='No Payment Terms exist for the term code '||lr_get_invoice_rec.termscode||' for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
                     gc_comments         :='Please provide a valid Term Code';
                     INSERT_ERROR_MSG;
                     lc_terms_err_flag:='Y';
                  END IF;                                               --3
               CLOSE lcu_get_term_info;

            ELSE

               --Log error message
               gc_error_code       :='AR08';
               gc_error_msg        :='Field  termscode is Null for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
               gc_comments         :='Please provide a valid Value';
               INSERT_ERROR_MSG;
               lc_terms_err_flag:='Y';
            END IF;
         END IF;                                                         --1
         gc_log_msg:='Flag returned by the Payment term cursor :'||lc_terms_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
         -- 2.10 BMarcoux
         ----------------------------------
         -- Validate Tax Code
         ----------------------------------
         lc_taxcodes_err_flag := 'N';
         lc_taxcodes_name     := NULL;
         ln_taxcodes_id       := NULL;
         lc_dt_tax_type       := NULL;                                          -- 2.10 this is new
         lc_dt_segment1       := NULL;                                          -- 2.10 this is new
         lc_dt_segment2       := NULL;                                          -- 2.10 this is new
         lc_dt_segment3       := NULL;                                          -- 2.10 this is new
         lc_dt_segment4       := NULL;                                          -- 2.10 this is new
         lc_dt_segment5       := NULL;                                          -- 2.10 this is new
         lc_dt_segment6       := NULL;                                          -- 2.10 this is new
         lc_dt_segment7       := NULL;                                          -- 2.10 this is new
         lc_dt_segment8       := NULL;                                          -- 2.10 this is new
         lc_dt_segment9       := NULL;                                          -- 2.10 this is new

            IF lr_get_invoice_rec.taxcode IS NOT NULL THEN 
               OPEN  lcu_chk_taxcodes_exist(lr_get_invoice_rec.taxcode);
               FETCH lcu_chk_taxcodes_exist INTO lc_taxcodes_name, ln_taxcodes_id, lc_dt_tax_type, lc_dt_segment1, lc_dt_segment2, lc_dt_segment3, lc_dt_segment4, lc_dt_segment5, lc_dt_segment6, lc_dt_segment7, lc_dt_segment8, lc_dt_segment9;
                  IF lcu_chk_taxcodes_exist%NOTFOUND THEN
                     --Log error message
                     gc_error_code       :='AR16';
                     gc_error_msg        :='No Tax Code exists for the taxcode '|| lr_get_invoice_rec.taxcode || ' for the Invoice Number: ' || lr_get_invoice_rec.invoicenumber;
                     gc_comments         :='Please provide a valid Tax Code';
                     INSERT_ERROR_MSG;
                     lc_taxcodes_err_flag:='Y';
-- 2.10 this is new - START
                  ELSE
                     -- 2.10 - New code to save data to 'usbpcs_ar_cleaned'
                     UPDATE usbpcs_ar_cleaned
                     SET    TAXCODEID          = ln_taxcodes_id
                          , TAXTYPE            = lc_dt_tax_type
                          , INTERIMTAXSEGMENT1 = lc_dt_segment1
                          , INTERIMTAXSEGMENT2 = lc_dt_segment2
                          , INTERIMTAXSEGMENT3 = lc_dt_segment3
                          , INTERIMTAXSEGMENT4 = lc_dt_segment4
                          , INTERIMTAXSEGMENT5 = lc_dt_segment5
                          , INTERIMTAXSEGMENT6 = lc_dt_segment6
                          , INTERIMTAXSEGMENT7 = lc_dt_segment7
                          , INTERIMTAXSEGMENT8 = lc_dt_segment8
                          , INTERIMTAXSEGMENT9 = lc_dt_segment9
                     WHERE  oracleidentifier   = lr_get_invoice_rec.oracleidentifier;
-- 2.10 this is new - END
                  END IF;
               CLOSE lcu_chk_taxcodes_exist;

--            ELSE
--               --Log error message
--               gc_error_code       :='AR17';
--               gc_error_msg        :='Field taxcode is Null for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
--               gc_comments         :='Please provide a valid Value';
--               INSERT_ERROR_MSG;
--               lc_terms_err_flag:='Y';

            END IF;
         gc_log_msg:='Flag returned by the Tax Code cursor :' || lc_taxcodes_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


         ----------------------------------------------------
         --Derive the Sales rep id and sales credit type name
         ----------------------------------------------------
         lc_sales_err_flag         :='N';
         ln_salesrep_id            :=NULL;
         lc_salesrep_number        :=NULL;
         ln_sales_credit_type_id   :=NULL;
         lc_sales_credit           :=NULL;

         IF (lr_get_invoice_rec.charuserfld2 IS NOT NULL) THEN          --1
            OPEN  lcu_get_sales_rep_info(lr_get_invoice_rec.charuserfld2);
            FETCH lcu_get_sales_rep_info INTO ln_salesrep_id,lc_salesrep_number,ln_sales_credit_type_id,lc_sales_credit;
               IF lcu_get_sales_rep_info%NOTFOUND THEN                  --2
                   --Log error message
                   gc_error_code       :='AR09';
                   gc_error_msg        :='No Salerep Info exist in oracle for the Sales name :'||lr_get_invoice_rec.charuserfld2||' for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
                   gc_comments         :='Please provide a valid Sales name';
                   INSERT_ERROR_MSG;
                   lc_sales_err_flag:='Y';
               END IF;                                                  --2
            CLOSE lcu_get_sales_rep_info;
         ELSE
            --Log error message
            gc_error_code       :='AR10';
            gc_error_msg        :='Field charuserfld2(Salesman name) is NULL for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
            gc_comments         :='Please provide a valid Sales name';
            INSERT_ERROR_MSG;
            lc_sales_err_flag:='Y';
         END IF;                                                        --1
         gc_log_msg:='Flag returned by the Salesrep cursor :'||lc_sales_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         --------------------------
         --Currency code validation
         --------------------------
         IF lr_get_invoice_rec.oraclecurrencycode IS NOT NULL THEN
            lc_currency_err_flag:='N';
            OPEN  lcu_chk_currency(lr_get_invoice_rec.oraclecurrencycode);
            FETCH lcu_chk_currency INTO lc_currency_err_flag;
               IF lcu_chk_currency%NOTFOUND THEN                                        --1
                  --Log error message
                   gc_error_code       :='AR11';
                   gc_error_msg        :='Currency code: '||lr_get_invoice_rec.oraclecurrencycode||' does not exist or Invalid for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
                   gc_comments         :='Please define this currency code';
                   INSERT_ERROR_MSG;
                   lc_currency_err_flag:='Y';
               ELSE
                   IF gc_currency_code <> lr_get_invoice_rec.oraclecurrencycode THEN    --2
                      IF lr_get_invoice_rec.currencyconversionrate  IS NULL THEN        --3
                          --Log error message
                           gc_error_code       :='AR12';
                           gc_error_msg        :='Field currencyconversionrate is NULL for the Invoice Number: '||lr_get_invoice_rec.invoicenumber;
                           gc_comments         :='Please provide value for currencyconversionrate ';
                           INSERT_ERROR_MSG;
                           lc_currency_err_flag:='Y';
                      END IF;                                                            --3
                   END IF;                                                               --2
               END IF;                                                                   --1
            CLOSE lcu_chk_currency;
         ELSE
            --Log error message
             gc_error_code       :='AR13';
             gc_error_msg        :='Field currencycode cannot be NULL for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
             gc_comments         :='Please provide a Currrency code';
             INSERT_ERROR_MSG;
             lc_currency_err_flag:='Y';
        END IF;
        gc_log_msg:='Flag returned by the Currency code validation cursor: '||lc_currency_err_flag;
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

        --------------------------------------------
        -- Derive BILL_TO Customer and Location info
        --------------------------------------------
        lc_bill_err_flag         := 'N';
        ln_bcust_acct_site_id    := NULL;
        lc_badd_orig_sys_ref     := NULL;
        ln_bcust_account_id      := NULL;
        lc_bcst_orig_sys_ref     := NULL;

        IF (lr_get_invoice_rec.customernumber is NOT  NULL) THEN     --1
           OPEN  lcu_get_billto_info(lr_get_invoice_rec.customernumber);
           FETCH lcu_get_billto_info INTO ln_bcust_acct_site_id,lc_badd_orig_sys_ref,ln_bcust_account_id,lc_bcst_orig_sys_ref;
              IF lcu_get_billto_info%NOTFOUND THEN                   --2
                 --Log error message
                  gc_error_code       :='AR14';
                  gc_error_msg        :='No Bill to Information exist for the customernumber field: '||lr_get_invoice_rec.customernumber||' for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
                 gc_comments         :='Please provide a valid value for customernumber';
                 INSERT_ERROR_MSG;
                 lc_bill_err_flag:='Y';
              END IF;                                                --2
           CLOSE lcu_get_billto_info;
        ELSE
            --Log error message
             gc_error_code       :='AR15';
             gc_error_msg        :='Field customernumber is NULL for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
             gc_comments         :='Please provide a valid value for customernumber field';
             INSERT_ERROR_MSG;
             lc_bill_err_flag:='Y';
        END IF;
        gc_log_msg:='Flag returned by the Bill to Cursor :'||lc_bill_err_flag;
        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

        --------------------------------------------
        -- Derive SHIP_TO Customer and Location info
        --------------------------------------------
        lc_ship_err_flag        :='N';
        ln_scust_acct_site_id    :=NULL;
        lc_sadd_orig_sys_ref     :=NULL;
        ln_scust_account_id      :=NULL;
        lc_scst_orig_sys_ref     :=NULL;

       --Start of Changes V1.1
       /* IF (lr_get_invoice_rec.charuserfld3 is NOT  NULL) THEN     --1
           OPEN  lcu_get_shipto_info(lr_get_invoice_rec.charuserfld3);
           FETCH lcu_get_shipto_info INTO ln_scust_acct_site_id,lc_sadd_orig_sys_ref,ln_scust_account_id,lc_scst_orig_sys_ref;
              IF lcu_get_shipto_info%NOTFOUND THEN                 --2
                 --Log error message
                  gc_error_code       :='AR16';
                  gc_error_msg        :='No Ship to Information exist for the charuserfld3 field: '||lr_get_invoice_rec.charuserfld3;
                 gc_comments         :='Please provide a valid value for charuserfld3(SHIP_TO)';
                 INSERT_ERROR_MSG;
                 lc_ship_err_flag:='Y';
              END IF;                                               --2
           CLOSE lcu_get_shipto_info;
        ELSE
            --Log error message
             gc_error_code       :='AR17';
             gc_error_msg        :='Filed charuserfld3 is NULL';
             gc_comments         :='Please provide a valid value for charuserfld3(SHIP_TO) field';
             INSERT_ERROR_MSG;
             lc_ship_err_flag:='Y';
        END IF;*/
        --gc_log_msg:='Flag returned by the Ship to Cursor :'||lc_ship_err_flag;
        --xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
        --End of Changes V1.1


        -------------------------------------------------------------------------------------------------------
        --Check if all the lines for an Invlice or Credit Memo has same Offset segments (Receivable Account)
        -------------------------------------------------------------------------------------------------------
        IF lc_inv_no    <>lr_get_invoice_rec.invoicenumber OR
           lc_tran_type <>lr_get_invoice_rec.oracletransactiontype THEN

           lc_inv_no    :=lr_get_invoice_rec.invoicenumber;
           lc_tran_type :=lr_get_invoice_rec.oracletransactiontype;

           lc_oraclesegdummy1  :=NULL;
           lc_oraclesegdummy2  :=NULL;
           lc_oraclesegdummy3  :=NULL;
           lc_oraclesegdummy4  :=NULL;
           lc_oraclesegdummy5  :=NULL;
           lc_oraclesegdummy6  :=NULL;
           lc_oraclesegdummy7  :=NULL;
           lc_oraclesegdummy8  :=NULL;
           lc_oraclesegdummy9  :=NULL;
           lc_account_offseg_flag :='N';
           ln_segment_no :=1;

	   BEGIN
	   SELECT DISTINCT oracleoffsetsegment1
		 ,oracleoffsetsegment2
		 ,oracleoffsetsegment3
		 ,oracleoffsetsegment4
		 ,oracleoffsetsegment5
		 ,oracleoffsetsegment6
		 ,oracleoffsetsegment7
		 ,oracleoffsetsegment8
		 ,oracleoffsetsegment9
	    INTO lc_oraclesegdummy1
		,lc_oraclesegdummy2
		,lc_oraclesegdummy3
		,lc_oraclesegdummy4
		,lc_oraclesegdummy5
		,lc_oraclesegdummy6
		,lc_oraclesegdummy7
		,lc_oraclesegdummy8
		,lc_oraclesegdummy9
	    FROM usbpcs_ar_cleaned OAC
	    WHERE OAC.oracletransactiontype=DECODE(lr_get_invoice_rec.oracletransactiontype ,'I' ,'I','C')
            AND OAC.operatingunit = gc_org_name                    -- pr jun-30
	    AND OAC.invoicenumber=lr_get_invoice_rec.invoicenumber;

	    IF  lc_oraclesegdummy1 IS NOT NULL AND
		lc_oraclesegdummy2 IS NOT NULL AND
		lc_oraclesegdummy3 IS NOT NULL AND
		lc_oraclesegdummy4 IS NOT NULL AND
		lc_oraclesegdummy5 IS NOT NULL AND
		lc_oraclesegdummy6 IS NOT NULL AND
		lc_oraclesegdummy7 IS NOT NULL AND
		lc_oraclesegdummy8 IS NOT NULL AND
		lc_oraclesegdummy9 IS NOT NULL THEN

		FOR lr_vs IN lcu_vs
		LOOP
		   BEGIN
		     SELECT DECODE(ln_segment_no ,1,lr_get_invoice_rec.oracleoffsetsegment1,
						  2,lr_get_invoice_rec.oracleoffsetsegment2,
						  3,lr_get_invoice_rec.oracleoffsetsegment3,
						  4,lr_get_invoice_rec.oracleoffsetsegment4,
						  5,lr_get_invoice_rec.oracleoffsetsegment5,
						  6,lr_get_invoice_rec.oracleoffsetsegment6,
						  7,lr_get_invoice_rec.oracleoffsetsegment7,
						  8,lr_get_invoice_rec.oracleoffsetsegment8,
						  9,lr_get_invoice_rec.oracleoffsetsegment9)
		     INTO lc_seg_value
		     FROM DUAL;



		     gc_log_msg:='Oracle Identifier :'||lr_get_invoice_rec.oracleidentifier;
		     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

		     gc_log_msg:='lc_seg_value :'||lc_seg_value;
		     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

		     gc_log_msg:='flex_value_set_name :'||lr_vs.flex_value_set_name;
		     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);




		     SELECT  FFVV.flex_value
		     INTO    lc_flex_value
		     FROM    fnd_flex_values_vl FFVV
			    ,fnd_flex_value_sets FFVS
		     WHERE   FFVS.flex_value_set_name = lr_vs.flex_value_set_name
		     AND     FFVV.flex_value_set_id =  FFVS.flex_value_set_id
		     AND     FFVV.flex_value = lc_seg_value
		     AND     FFVV.enabled_flag = 'Y'
		     AND     SYSDATE BETWEEN NVL (FFVV.start_date_active, SYSDATE)
		     AND     NVL (FFVV.end_date_active, SYSDATE);

		     ln_valid_segment_count := ln_valid_segment_count + 1;

		   EXCEPTION
		      WHEN NO_DATA_FOUND THEN
			 gc_error_code := 'AR18';
			 gc_error_msg  := 'Invalid value set value '||lc_seg_value||' for the segment'||ln_segment_no||' Attached to the Invoice '||lr_get_invoice_rec.invoicenumber ;
			 gc_comments   := 'Please check the value set value for the segment'||ln_segment_no ;
			 INSERT_ERROR_MSG;
			 lc_account_offseg_flag:='Y';
		      WHEN OTHERS THEN
			 gc_error_code := 'AR19';
			 gc_error_msg  := 'Unexpected error encountered while validating accounting segments for the Invoice Number: '||lr_get_invoice_rec.invoicenumber||' -- '||SQLERRM;
			 gc_comments   := 'Please check the value set value for the segment'||ln_segment_no ;
			 INSERT_ERROR_MSG;
			 lc_account_offseg_flag:='Y';
		   END;
		   ln_segment_no  := ln_segment_no  + 1;

		   IF (ln_valid_segment_count = 9) THEN       --1
		       lc_seg_values_exists := 'Y';
		   ELSE
		       lc_seg_values_exists := 'N';
		   END IF;                                    --1
		END LOOP;          --end of value sets loop
		IF lc_account_offseg_flag ='N' THEN          --2
		   IF ( lc_seg_values_exists = 'Y' ) THEN     --3
		      BEGIN

			 lc_segment1 := lr_get_invoice_rec.oracleoffsetsegment1;
			 lc_segment2 := lr_get_invoice_rec.oracleoffsetsegment2;
			 lc_segment3 := lr_get_invoice_rec.oracleoffsetsegment3;
			 lc_segment4 := lr_get_invoice_rec.oracleoffsetsegment4;
			 lc_segment5 := lr_get_invoice_rec.oracleoffsetsegment5;
			 lc_segment6 := lr_get_invoice_rec.oracleoffsetsegment6;
			 lc_segment7 := lr_get_invoice_rec.oracleoffsetsegment7;
			 lc_segment8 := lr_get_invoice_rec.oracleoffsetsegment8;
			 lc_segment9 := lr_get_invoice_rec.oracleoffsetsegment9;

			 lc_concat_segments := lc_segment1||'.'||lc_segment2||'.'||lc_segment3||'.'||lc_segment4||'.'||
					       lc_segment5||'.'||lc_segment6||'.'||lc_segment7||'.'||lc_segment8||'.'||
						lc_segment9;

			 gn_ccid := FND_FLEX_EXT.GET_CCID(
						       'SQLGL'
						       ,'GL#'
						       ,gn_chart_of_accounts_id
						       ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
						       ,lc_concat_segments
							);
			 lc_seg_values_exists := 'N';
			 IF gn_ccid = 0 THEN                   --4
			    gc_error_code := 'AR20';
			    gc_error_msg  := 'Invalid Account Code Combination '||lc_concat_segments||' for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
			    gc_comments   := 'Please check the Account Code Combination';
			    INSERT_ERROR_MSG;
			    lc_account_offseg_flag:='Y';
			 END IF;                               --4

		      EXCEPTION
			 WHEN OTHERS THEN
			    gc_error_code       := SQLCODE;
			    gc_error_msg        := 'Unexpected error encountered when trying to get the Code Combination Id for the Invoice:'||lr_get_invoice_rec.invoicenumber||' -- '||SQLERRM;
			    INSERT_ERROR_MSG;
			    lc_account_offseg_flag:='Y';
			  END;
		   ELSE
		       gn_ccid := 0;
		   END IF; -- lc_seg_values_exists = 'Y'  --3
		END IF;   --lc_account_segment_flag ='N'  --2
	      ELSE
		 gc_error_code := 'AR07';
		 gc_error_msg  := 'One of the Accounting Segment is holding null for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
		 gc_comments   := 'Please check the Account Segments(Oraclesegment1-9)';
		 INSERT_ERROR_MSG;
		 lc_account_offseg_flag:='Y';
	      END IF;   --IF lr_get_invoice_rec.oraclesegment1 IS NOT NULL AND


	 EXCEPTION
	    WHEN TOO_MANY_ROWS THEN
		  gc_error_code := 'AR21';
		  gc_error_msg  := 'Too many rows returned for value set value: '||lc_seg_value||' for the segment: '||ln_segment_no||' Attached to the Invoice: '||lr_get_invoice_rec.invoicenumber ;
		  gc_comments   := 'Please check the value set value for the segment'||ln_segment_no ;
		  INSERT_ERROR_MSG;
		  lc_account_offseg_flag:='Y';
	 END;
    END IF;


         -------------------------------------------------------
         --Validate the Account Code Combination Segment values for Freight,Line ,TAX
         ------------------------------------------------------
         lc_account_segment_flag := 'N';
         ln_segment_no           := 1;
         lc_seg_value	           := NULL;
         lc_flex_value	         := NULL;
         ln_valid_segment_count	 := 0;
         lc_segment1 	           := NULL;
         lc_segment2 	           := NULL;
         lc_segment3 	           := NULL;
         lc_segment4 	  	       := NULL;
         lc_segment5 	   	       := NULL;
         lc_segment6 	  	       := NULL;
         lc_segment7 	  	       := NULL;
         lc_segment8 	  	       := NULL;
         lc_segment9 	   	       := NULL;
         lc_concat_segments	     := NULL;
         gn_ccid	     	         := NULL;

         IF lr_get_invoice_rec.oraclesegment1 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment2 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment3 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment4 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment5 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment6 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment7 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment8 IS NOT NULL AND
            lr_get_invoice_rec.oraclesegment9 IS NOT NULL THEN

            FOR lr_vs IN lcu_vs
            LOOP
               BEGIN
                 SELECT DECODE(ln_segment_no ,1,lr_get_invoice_rec.oraclesegment1,
                                              2,lr_get_invoice_rec.oraclesegment2,
                                              3,lr_get_invoice_rec.oraclesegment3,
                                              4,lr_get_invoice_rec.oraclesegment4,
                                              5,lr_get_invoice_rec.oraclesegment5,
                                              6,lr_get_invoice_rec.oraclesegment6,
                                              7,lr_get_invoice_rec.oraclesegment7,
                                              8,lr_get_invoice_rec.oraclesegment8,
                                              9,lr_get_invoice_rec.oraclesegment9)
                 INTO lc_seg_value
                 FROM DUAL;


                 gc_log_msg:='Oracle Identifier :'||lr_get_invoice_rec.oracleidentifier;
                 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                 gc_log_msg:='lc_seg_value :'||lc_seg_value;
                 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                 gc_log_msg:='flex_value_set_name :'||lr_vs.flex_value_set_name;
                 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


                 SELECT  FFVV.flex_value
                 INTO    lc_flex_value
                 FROM    fnd_flex_values_vl FFVV
                        ,fnd_flex_value_sets FFVS
                 WHERE   FFVS.flex_value_set_name = lr_vs.flex_value_set_name
                 AND     FFVV.flex_value_set_id =  FFVS.flex_value_set_id
                 AND     FFVV.flex_value = lc_seg_value
                 AND     FFVV.enabled_flag = 'Y'
                 AND     SYSDATE BETWEEN NVL (FFVV.start_date_active, SYSDATE)
                 AND     NVL (FFVV.end_date_active, SYSDATE);

                 ln_valid_segment_count := ln_valid_segment_count + 1;

               EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     gc_error_code := 'AR18';
                     gc_error_msg  := 'Invalid value set value '||lc_seg_value||' for the Offsegment: '||ln_segment_no||' Attached to the Invoice: '||lr_get_invoice_rec.invoicenumber ;
                     gc_comments   := 'Please check the value set value for the segment'||ln_segment_no ;
                     INSERT_ERROR_MSG;
                     lc_account_segment_flag:='Y';
                  WHEN OTHERS THEN
                     gc_error_code := 'AR19';
                     gc_error_msg  := 'Unexpected error encountered while validating accounting segments for the Invoice Number: '||lr_get_invoice_rec.invoicenumber||' -- '||SQLERRM;
                     gc_comments   := 'Please check the value set value for the segment'||ln_segment_no ;
                     INSERT_ERROR_MSG;
                     lc_account_segment_flag:='Y';
               END;
               ln_segment_no  := ln_segment_no  + 1;

               IF (ln_valid_segment_count = 9) THEN       --1
                   lc_seg_values_exists := 'Y';
               ELSE
                   lc_seg_values_exists := 'N';
               END IF;                                    --1
            END LOOP;          --end of value sets loop
            IF lc_account_segment_flag ='N' THEN          --2
               IF ( lc_seg_values_exists = 'Y' ) THEN     --3
                  BEGIN

                     lc_segment1 := lr_get_invoice_rec.oraclesegment1;
                     lc_segment2 := lr_get_invoice_rec.oraclesegment2;
                     lc_segment3 := lr_get_invoice_rec.oraclesegment3;
                     lc_segment4 := lr_get_invoice_rec.oraclesegment4;
                     lc_segment5 := lr_get_invoice_rec.oraclesegment5;
                     lc_segment6 := lr_get_invoice_rec.oraclesegment6;
                     lc_segment7 := lr_get_invoice_rec.oraclesegment7;
                     lc_segment8 := lr_get_invoice_rec.oraclesegment8;
                     lc_segment9 := lr_get_invoice_rec.oraclesegment9;

                     lc_concat_segments := lc_segment1||'.'||lc_segment2||'.'||lc_segment3||'.'||lc_segment4||'.'||
                                           lc_segment5||'.'||lc_segment6||'.'||lc_segment7||'.'||lc_segment8||'.'||
                                            lc_segment9;

                     gn_ccid := FND_FLEX_EXT.GET_CCID(
                                                   'SQLGL'
                                                   ,'GL#'
                                                   ,gn_chart_of_accounts_id
                                                   ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS')
                                                   ,lc_concat_segments
                                                    );
                     lc_seg_values_exists := 'N';
                     IF gn_ccid = 0 THEN                   --4
                        gc_error_code := 'AR20';
                        gc_error_msg  := 'Invalid Account Code Combination '||lc_concat_segments||' for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
                        gc_comments   := 'Please check the Account Code Combination';
                        INSERT_ERROR_MSG;
                        lc_account_segment_flag:='Y';
                     END IF;                               --4

                  EXCEPTION
                     WHEN OTHERS THEN
                        gc_error_code       := SQLCODE;
                        gc_error_msg        := 'Unexpected error encountered when trying to get the Code Combination Id for the Invoice:'||lr_get_invoice_rec.invoicenumber||' -- '||SQLERRM;
                        INSERT_ERROR_MSG;
                        lc_account_segment_flag:='Y';
                      END;
               ELSE
                   gn_ccid := 0;
               END IF; -- lc_seg_values_exists = 'Y'  --3
            END IF;   --lc_account_segment_flag ='N'  --2
         ELSE
             gc_error_code := 'AR07';
             gc_error_msg  := 'One of the Accounting Segment is holding null  for the Invoice Number: '||lr_get_invoice_rec.invoicenumber ;
             gc_comments   := 'Please check the Account Segments(Oraclesegment1-9)';
             INSERT_ERROR_MSG;
             lc_account_segment_flag:='Y';
         END IF;   --IF lr_get_invoice_rec.oraclesegment1 IS NOT NULL AND


         -- If  there exist any errors in the above validations then update the status of the records
         IF (lc_account_segment_flag<>'N' OR
             lc_account_offseg_flag <>'N' OR
             lc_ship_err_flag       <>'N' OR
             lc_bill_err_flag       <>'N' OR
             lc_currency_err_flag   <>'N' OR
             lc_sales_err_flag      <>'N' OR
             lc_terms_err_flag      <>'N' OR
             lc_taxcodes_err_flag   <>'N' OR -- 2.10 BMarcoux
             lc_item_flag           <>'N' OR
             lc_trns_neg_flag       <>'N' OR
             lv_inv_dte_flag        <>'N' OR
             lc_invoice_exist_flag  <>'N') THEN

             --lc_mast_prc_err_flag:='Y';
             lc_mast_err_flag    :='Y';

             --If any errors in the above validation then update the status of the record to VE
             UPDATE usbpcs_ar_cleaned
             SET    CharUserFld4   ='VE'
                   ,DecUserFld1    =gc_request_id
             WHERE  oracleidentifier=lr_get_invoice_rec.oracleidentifier;

         ELSE
            --If NO errors in the above validation then update the status of the record to VS
            UPDATE usbpcs_ar_cleaned
            SET    CharUserFld4='VS'
                  ,ORACLEINTFLD1   =DECODE(lr_get_invoice_rec.oracletransactiontype,'I',gc_trx_type_inv_id
                                                                                 ,'C',gc_trx_type_cm_id)
                  ,oracleintfld2   =ln_terms_id
                  ,oracleintfld3   =ln_bcust_acct_site_id
                  ,oracleintfld4   =ln_bcust_account_id
                  --Start of Changes V1.1
                    --,oracleintfld5   =ln_scust_acct_site_id
                    --,oracleintfld6   =ln_scust_account_id
                  --End of Changes V1.1
                  ,oracleintfld7   =ln_salesrep_id
                  ,oraclecharfld1  =DECODE(lr_get_invoice_rec.oracletransactiontype,'I',gc_trx_type_inv
                                                                                  ,'C',gc_trx_type_cm )
                  ,oraclecharfld2  =lc_terms_name
                  ,oraclecharfld3  =lc_badd_orig_sys_ref
                  ,oraclecharfld4  =lc_bcst_orig_sys_ref
                  --Start of Changes V1.1
                    --,oraclecharfld5  =lc_sadd_orig_sys_ref
                    --,oraclecharfld6  =lc_scst_orig_sys_ref
                  --End of Changes V1.1
                  ,oraclecharfld7  =lc_salesrep_number --lr_get_invoice_rec.charuserfld2
                  ,oraclecharfld8  =lc_sales_credit
                 -- ,charuserfld5    = lr_get_invoice_rec.referencenumber ---need to identify ther column
                  ,charuserfld6    = lc_item_uom
                  ,charuserfld7    = lc_item_desc
            WHERE  oracleidentifier=lr_get_invoice_rec.oracleidentifier;

         END IF; --IF (lc_account_segment_flag<>'N' OR
      END LOOP; --End of main loop
   ELSE --setup check
      lc_mast_err_flag:='Y';
   END IF; -- IF lc_setup_exist='Y'
   COMMIT;

   --Get Count for the total no of records
   OPEN  lcu_get_rec_count;
   FETCH lcu_get_rec_count INTO ln_rec_fetched;
   CLOSE lcu_get_rec_count;

   --Get Count for total no of records Validated
   OPEN  lcu_get_rec_val_count;
   FETCH lcu_get_rec_val_count INTO ln_rec_validated;
   CLOSE lcu_get_rec_val_count;

   --Get Count for total no of records Errored
   OPEN  lcu_get_rec_err_count;
   FETCH lcu_get_rec_err_count INTO ln_rec_errored;
   CLOSE lcu_get_rec_err_count;

   --Summary information of Records Validated
   --===============================================
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Summary information of Records Validated ');
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
   fnd_file.put_line(fnd_file.log,'Total Records Validated             :    ' ||ln_rec_validated);
   fnd_file.put_line(fnd_file.log,'Total Records Errored               :    ' ||ln_rec_errored);

   IF (lc_mast_err_flag='Y') THEN      --If any kind of errors (setup or validation)
      xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);

      IF (lc_setup_exist <>'Y') THEN   --If setup`s are missing then error out the program
         xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);   --HERE
         x_retcode:=2;
         RETURN;
      ELSE                           --If validation error then set the status of the prog to warning

         xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);   --HERE
         x_retcode:=1;
         RETURN;
      END IF ;
   ELSE --If no errors the call the process procedure
       PROCESS_INVOICE_DATA (
                             x_errbuf   =>x_errbuf
                            ,x_retcode  =>x_retcode
                            );

       IF x_retcode <> 0  THEN
          xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);
       END IF;

   END IF;--(lc_mast_err_flag='Y') THEN*/
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_AR_INV_PYMT_CONV_PK.VALIDATE_INVOICE_DATA. Error is: ' ||SQLERRM);
   x_errbuf:=SQLERRM;
   x_retcode:=2;
   ROLLBACK;
END VALIDATE_INVOICE_DATA;


-- +===================================================================+
-- | Name            : PROCESS_INVOICE_DATA                            |
-- | Description     : Procedure to insert invoice records             |
-- |                   into  Standard Interdace Tables                 |
-- |                                                                   |
-- |                                                                   |
-- | Parameters      : NONE                                            |
-- |                                                                   |
-- |                                                                   |
-- | Returns         : NONE                                            |
-- |                                                                   |
-- +===================================================================+

PROCEDURE PROCESS_INVOICE_DATA (
                                x_errbuf   OUT VARCHAR2
                               ,x_retcode  OUT VARCHAR2
                               )
IS
   lc_batch_name              ra_interface_lines_all.BATCH_SOURCE_NAME%TYPE;
   lc_description             ra_interface_lines_all.DESCRIPTION%TYPE;
   lc_uom_code                ra_interface_lines_all.UOM_CODE%TYPE;
   lc_item                    ra_interface_lines_all.MTL_SYSTEM_ITEMS_SEG1%TYPE;
   lc_curr_conv_rate          ra_interface_lines_all.CONVERSION_RATE%TYPE;
   lc_tax_code                ra_interface_lines_all.TAX_CODE%TYPE;
   lc_int_line_attribute1     ra_interface_lines_all.INTERFACE_LINE_ATTRIBUTE1%TYPE;
   lc_int_line_attribute2     ra_interface_lines_all.INTERFACE_LINE_ATTRIBUTE2%TYPE;
   lc_int_link_attribute1     ra_interface_lines_all.LINK_TO_LINE_ATTRIBUTE1%TYPE;
   lc_int_link_attribute2     ra_interface_lines_all.LINK_TO_LINE_ATTRIBUTE2%TYPE;
   lc_int_link_context        ra_interface_lines_all.LINK_TO_LINE_CONTEXT%TYPE;
   lc_invnum                  ra_interface_lines_all.TRX_NUMBER%TYPE:='-9-9-9';
   lc_trans                   ra_interface_lines_all.CUST_TRX_TYPE_NAME%TYPE:='-9-9-9';
   ln_seq                     usbpcs_ar_cleaned.sequencenumber%TYPE;
   lc_account_class           ra_interface_distributions_all.account_class%TYPE;
   ln_total_rec_amount        ra_interface_distributions_all.AMOUNT%TYPE:=0;
   lc_dist_int_err_flag       VARCHAR2(1):='N';
   lc_sales_int_err_flag      VARCHAR2(1):='N';
   lc_lines_int_err_flag      VARCHAR2(1):='N';
   lc_mst_err_flag            VARCHAR2(1):='N';
   ln_rec_fetched             NUMBER:=0;
   ln_rec_inserted            NUMBER:=0;
   ln_rec_errored             NUMBER:=0;
   ln_tot_inv_lines           NUMBER:=0;
   ln_line_counter            NUMBER:=0;

--2.10 - BMarcoux
-- 2.10 this is new - START
   lc_segment1_interim      gl_code_combinations.segment1%TYPE;                 -- 2.10 BMarcoux
   lc_segment2_interim      gl_code_combinations.segment2%TYPE;                 -- 2.10 BMarcoux
   lc_segment3_interim      gl_code_combinations.segment3%TYPE;                 -- 2.10 BMarcoux
   lc_segment4_interim      gl_code_combinations.segment4%TYPE;                 -- 2.10 BMarcoux
   lc_segment5_interim      gl_code_combinations.segment5%TYPE;                 -- 2.10 BMarcoux
   lc_segment6_interim      gl_code_combinations.segment6%TYPE;                 -- 2.10 BMarcoux
   lc_segment7_interim      gl_code_combinations.segment7%TYPE;                 -- 2.10 BMarcoux
   lc_segment8_interim      gl_code_combinations.segment8%TYPE;                 -- 2.10 BMarcoux
   lc_segment9_interim      gl_code_combinations.segment9%TYPE;                 -- 2.10 BMarcoux
   lc_segment1_1            usbpcs_ar_cleaned.oraclesegment1%TYPE;              -- 2.10 BMarcoux
   lc_segment2_1            usbpcs_ar_cleaned.oraclesegment2%TYPE;              -- 2.10 BMarcoux
   lc_segment3_1            usbpcs_ar_cleaned.oraclesegment3%TYPE;              -- 2.10 BMarcoux
   lc_segment4_1            usbpcs_ar_cleaned.oraclesegment4%TYPE;              -- 2.10 BMarcoux
   lc_segment5_1            usbpcs_ar_cleaned.oraclesegment5%TYPE;              -- 2.10 BMarcoux
   lc_segment6_1            usbpcs_ar_cleaned.oraclesegment6%TYPE;              -- 2.10 BMarcoux
   lc_segment7_1            usbpcs_ar_cleaned.oraclesegment7%TYPE;              -- 2.10 BMarcoux
   lc_segment8_1            usbpcs_ar_cleaned.oraclesegment8%TYPE;              -- 2.10 BMarcoux
   lc_segment9_1            usbpcs_ar_cleaned.oraclesegment9%TYPE;              -- 2.10 BMarcoux
-- 2.10 this is new - END


    -- Cursor to get all the records from the staging table
    --------------------------------------------------------
   CURSOR lcu_get_invoice_rec
   IS
   SELECT *
   FROM   usbpcs_ar_cleaned UAC
   WHERE UPPER(UAC.oracletransactiontype) IN('I','C')
   AND   charuserfld4='VS'
   AND   UAC.operatingunit=gc_org_name
   --AND   UAC.invoicenumber in (8883861 ,6179201)
   ORDER BY UAC.invoicenumber
           ,UAC.sequencenumber;


   --------------------------------------------------------
   --Get Count for total no of records fetched for insert
   -------------------------------------------------------
   CURSOR lcu_get_rec_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('I','C')
   AND   UAC.operatingunit=gc_org_name ;
 --  AND   UAC.invoicenumber in (8883861 ,6179201)
   --AND   charuserfld4='VS';


   --------------------------------------------
   --Get Count for total no of records Inserted
   --------------------------------------------
   CURSOR lcu_get_rec_ins_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('I','C')
   AND   UAC.operatingunit=gc_org_name
 --  AND   UAC.invoicenumber in (8883861 ,6179201)
   AND   UAC.CharUserFld4='PS';


   ----------------------------------------------
   --Get Count for total no of records Errored
   ----------------------------------------------
   CURSOR lcu_get_rec_err_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('I','C')
   AND   UAC.operatingunit=gc_org_name
  -- AND   UAC.invoicenumber in (8883861 ,6179201)
   AND   UAC.CharUserFld4='PE';


   -------------------------------------------
   --Get total lines for an Invoice and transaction
   -------------------------------------------
   CURSOR lcu_get_tot_inv_lines(p_inv VARCHAR2,p_trans VARCHAR2)
   IS
   SELECT COUNT(*)
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.INVOICENUMBER=p_inv
   AND   UAC.oracletransactiontype=p_trans;


BEGIN
   gc_log_msg:='*************START OF INSERTING RECORDS*************';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   FOR lr_get_invoice_rec IN lcu_get_invoice_rec
   LOOP
      gc_record_number       :=lr_get_invoice_rec.oracleidentifier;
      gc_record_identifier   :=lr_get_invoice_rec.invoicenumber||' - Transaction Type: '||lr_get_invoice_rec.oracletransactiontype;

      --Insert into RA_INTERFACE_LINES_ALL
      BEGIN
         lc_batch_name         := NULL;
         lc_dist_int_err_flag  := 'N';
         lc_sales_int_err_flag := 'N';
         lc_lines_int_err_flag := 'N';


         --Get total lines for an Invoice
         OPEN  lcu_get_tot_inv_lines(lr_get_invoice_rec.invoicenumber,lr_get_invoice_rec.oracletransactiontype);
         FETCH lcu_get_tot_inv_lines INTO ln_tot_inv_lines;
         CLOSE lcu_get_tot_inv_lines;


         IF   lr_get_invoice_rec.oracletransactiontype='I' THEN
              lc_batch_name :=gc_batch_name_inv;
              gc_flex_context_code:='Conversion_Inv_RX';  -- 3.00 Modifications for RxC Processing
--              gc_flex_context_code :='Conversion_Inv1';  -- 2.00 Bmarcoux
--              gc_flex_context_code :='Conversion_Inv';  -- 2.00 Bmarcoux              
         ELSE
              lc_batch_name :=gc_batch_name_cm;
              gc_flex_context_code :='Conversion_CM_RX';   -- 3.00 Modifications for RxC Processing
--              gc_flex_context_code :='Conversion_CM1';   -- 2.00 Bmarcoux
--              gc_flex_context_code :='Conversion_CM';   -- 2.00 Bmarcoux
         END IF;


         --Pass the Description of the Item if exist, else use the default description
         IF  lr_get_invoice_rec.referencenumber IS NOT NULL THEN ---SUBBU CHANGES THIS TO ITEMNUMB
             lc_description:=lr_get_invoice_rec.charuserfld7;
             lc_uom_code   :=lr_get_invoice_rec.charuserfld6;
             lc_item       :=lr_get_invoice_rec.referencenumber;
         ELSE
             lc_description:='Historical Data Conversion';
             lc_uom_code   :=NULL;
             lc_item       :=NULL;
         END IF;


         --Pass the Currency conversion rate if NON US
         IF gc_currency_code <>lr_get_invoice_rec.oraclecurrencycode THEN
            lc_curr_conv_rate :=lr_get_invoice_rec.CurrencyConversionRate;
         ELSE
            lc_curr_conv_rate:=1;
         END IF;

         lc_tax_code := NULL;                                -- 2.10 BMarcoux

         IF  lr_get_invoice_rec.linetype = 'TAX' THEN
             IF lr_get_invoice_rec.taxcode IS NOT NULL THEN  -- 2.10 BMarcoux
                lc_tax_code := lr_get_invoice_rec.taxcode;   -- 2.10 BMarcoux
             ELSE                                            -- 2.10 BMarcoux
    	          lc_tax_code := gc_tax_code;
             END IF;                                         -- 2.10 BMarcoux
         END IF;                                             -- 2.10 BMarcoux

         -- 2.10 BMarcoux (Don't apply if linetype is NOT 'TAX')
--         IF  lr_get_invoice_rec.linetype = 'LINE' THEN
--             IF lr_get_invoice_rec.taxcode IS NOT NULL THEN
--	              lc_tax_code := lr_get_invoice_rec.taxcode;
--             END IF;
--         END IF;

-- 2.10 BMarcoux
--       ELSE                         
--           lc_tax_code:=NULL;
--       END IF;

         --Line the link if Line type is TAX or FREIGHT
         IF  (lr_get_invoice_rec.invoicenumber         <> lc_invnum) OR
             (lr_get_invoice_rec.oracletransactiontype <> lc_trans)  OR
             (lr_get_invoice_rec.sequencenumber        <>ln_seq) THEN


             lc_invnum:=lr_get_invoice_rec.invoicenumber;
             lc_trans :=lr_get_invoice_rec.oracletransactiontype;
             ln_seq   :=lr_get_invoice_rec.sequencenumber;
             IF lr_get_invoice_rec.linetype='LINE' THEN
                lc_int_line_attribute1 := lr_get_invoice_rec.invoicenumber;
                lc_int_line_attribute2 := lr_get_invoice_rec.sequencenumber;
                lc_int_link_attribute1:=NULL;
                lc_int_link_attribute2:=NULL;
                lc_int_link_context   :=NULL;

             ELSE
                 IF lr_get_invoice_rec.linetype<>'LINE'  THEN
                    lc_int_link_context    :=gc_flex_context_code;
                    lc_int_link_attribute1 :=lc_int_line_attribute1;
                    lc_int_link_attribute2 :=lc_int_line_attribute2;
                 END IF;
             END IF; --IF lr_get_invoice_rec.linetype='LINE' THEN
         END IF; --  IF  (lr_get_invoice_rec.invoicenumber         <> lc_invnum) OR


         INSERT INTO RA_INTERFACE_LINES_ALL
                                        (INTERFACE_LINE_CONTEXT         --1
                                        ,INTERFACE_LINE_ATTRIBUTE1      --2
                                        ,INTERFACE_LINE_ATTRIBUTE2      --3
                                        ,BATCH_SOURCE_NAME              --4
                                        ,SET_OF_BOOKS_ID                --5
                                        ,LINE_TYPE                      --6
                                        ,DESCRIPTION                    --7
                                        ,CURRENCY_CODE                  --8
                                        ,AMOUNT                         --9
                                        ,CUST_TRX_TYPE_ID               --10
                                        ,TERM_ID                        --11
                                        ,ORIG_SYSTEM_BILL_ADDRESS_REF   --12
                                        ,ORIG_SYSTEM_BILL_CUSTOMER_REF  --13
                                        ,ORIG_SYSTEM_BILL_ADDRESS_id    --14
                                        ,ORIG_SYSTEM_BILL_CUSTOMER_id   --15
                                        ,CONVERSION_TYPE                --16
                                        ,CONVERSION_RATE                --17
                                        ,TRX_DATE                       --18
                                        ,TRX_NUMBER                     --19
                                        ,QUANTITY                       --20
                                        ,QUANTITY_ORDERED               --21
                                        ,PRINTING_OPTION                --22
                                        ,TAX_CODE                       --23
                                        ,PRIMARY_SALESREP_ID            --24
                                        ,PRIMARY_SALESREP_NUMBER        --25
                                        ,CREATED_BY                     --26
                                        ,CREATION_DATE                  --27
                                        ,LAST_UPDATED_BY                --28
                                        ,LAST_UPDATE_DATE               --29
                                        ,ORG_ID                         --30
                                        ,AMOUNT_INCLUDES_TAX_FLAG       --31
                                        ,CUST_TRX_TYPE_NAME             --32
                                        ,TERM_NAME                      --33
                                       --Start of Changes 1.1
                                        --,ORIG_SYSTEM_SHIP_ADDRESS_REF   --34
                                        --,ORIG_SYSTEM_SHIP_CUSTOMER_REF  --35
                                        --,ORIG_SYSTEM_SHIP_ADDRESS_id    --36
                                        --,ORIG_SYSTEM_SHIP_CUSTOMER_id   --37
                                       --End of Changes 1.1
                                        ,MTL_SYSTEM_ITEMS_SEG1          --38
                                        ,UOM_CODE                       --39
                                        ,LINK_TO_LINE_CONTEXT           --40
                                        ,LINK_TO_LINE_ATTRIBUTE1        --41
                                        ,LINK_TO_LINE_ATTRIBUTE2        --41

                                       )
                                 VALUES
                                     (  gc_flex_context_code                     --1
                                       ,lr_get_invoice_rec.invoicenumber         --2
                                       ,lr_get_invoice_rec.sequencenumber        --3
                                       ,DECODE(lr_get_invoice_rec.oracletransactiontype,'I',gc_batch_name_inv
                                                                                       ,'C',gc_batch_name_cm
                                              )                                         --4 need if
                                       ,gc_set_of_books_id                       --5
                                       ,lr_get_invoice_rec.linetype              --6
                                       ,lc_description                           --7  need if
                                       ,lr_get_invoice_rec.oraclecurrencycode    --8
                                       ,lr_get_invoice_rec.originalamount        --9  need if
                                       ,lr_get_invoice_rec.oracleintfld1         --10
                                       --DECODE(lr_get_invoice_rec.ORACLETRANSACTIONTYPE,'I',lr_get_invoice_rec.oracleintfld2,NULL)         --11
                                       ,lr_get_invoice_rec.oracleintfld2         --11
                                       ,lr_get_invoice_rec.oraclecharfld3        --12
                                       ,lr_get_invoice_rec.oraclecharfld4        --13
                                       ,lr_get_invoice_rec.oracleintfld3         --14
                                       ,lr_get_invoice_rec.oracleintfld4         --15
                                       ,gc_conv_type                             --16
                                       ,lc_curr_conv_rate                        --17 need if
                                       -- Start of Changes V1.4
                                       --,sysdate                                  --18
                                       ,TO_DATE(lr_get_invoice_rec.invoicedate,'YYYY-MM-DD')
                                       -- End of Changes V1.4
                                       ,lr_get_invoice_rec.invoicenumber         --19
                                       ,1                                        --20
                                       ,1                                        --21
                                       ,'PRI'                                    --22
                                       ,lc_tax_code --tax                        --23  need if
                                       ,lr_get_invoice_rec.oracleintfld7         --24
                                       ,lr_get_invoice_rec.oraclecharfld7        --25
                                       ,FND_GLOBAL.USER_ID                       --26
                                       ,sysdate                                  --27
                                       ,FND_GLOBAL.USER_ID                       --28
                                       ,sysdate                                  --29
                                       , gn_org_id                               --30
                                       ,'N'                                      --31
                                       ,lr_get_invoice_rec.oraclecharfld1        --32
                                       --,DECODE(lr_get_invoice_rec.ORACLETRANSACTIONTYPE,'I',lr_get_invoice_rec.ORACLECHARFLD2,NULL)         --33
                                       ,lr_get_invoice_rec.ORACLECHARFLD2       --33
                                       --Start of Changes 1.1
                                      -- ,lr_get_invoice_rec.oraclecharfld5       --34
                                      -- ,lr_get_invoice_rec.oraclecharfld6        --35
                                      -- ,lr_get_invoice_rec.oracleintfld5         --36
                                      -- ,lr_get_invoice_rec.oracleintfld6         --37
                                      --End of Changes 1.1
                                       ,lc_item                                  --38
                                       ,lc_uom_code                              --39
                                       ,lc_int_link_context                      --40
                                       ,lc_int_link_attribute1                   --41
                                       ,lc_int_link_attribute2                   --42
                                      );
      EXCEPTION
          WHEN OTHERS THEN
             --Log error message
             gc_error_code       :='AR-20';
             gc_error_msg        :='Unexpected error encountered while inserting records into RA_INTERFACE_LINES_ALL table';
             gc_comments         :=SQLERRM;
             INSERT_ERROR_MSG;
             lc_lines_int_err_flag:='Y';
      END;
      gc_log_msg:='Flag returned by the RA_INTERFACE_LINES_ALL table :'||lc_lines_int_err_flag;
      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


      IF lr_get_invoice_rec.linetype='LINE' THEN
         BEGIN
            --Insert into RA_INTERFACE_SALESCREDITS_ALL table only for LINE TYPE 'LINE'
            INSERT INTO RA_INTERFACE_SALESCREDITS_ALL
                                                (INTERFACE_LINE_CONTEXT                      --1
                                                ,INTERFACE_LINE_ATTRIBUTE1                   --2
                                                ,INTERFACE_LINE_ATTRIBUTE2                   --3
                                                ,SALES_CREDIT_PERCENT_SPLIT                  --4
                                                ,SALES_CREDIT_TYPE_NAME                      --5
                                                ,SALESREP_ID                                 --6
                                                ,SALESREP_NUMBER                             --7
                                                )
                                         VALUES(
                                                gc_flex_context_code                        --1
                                                ,lr_get_invoice_rec.invoicenumber            --2
                                                ,lr_get_invoice_rec.sequencenumber           --3
                                                ,'100'                                       --4
                                                ,lr_get_invoice_rec.oraclecharfld8           --5
                                                ,lr_get_invoice_rec.oracleintfld7            --6
                                                ,lr_get_invoice_rec.oraclecharfld7           --7
                                               );
         EXCEPTION
            WHEN OTHERS THEN
                  --Log error message
                 gc_error_code       :='AR-20';
                 gc_error_msg        :='Unexpected error encountered while inserting records into RA_INTERFACE_SALESCREDITS_ALL table'  ;
                 gc_comments         :=SQLERRM;
                 INSERT_ERROR_MSG;
                 lc_sales_int_err_flag:='Y';

         END;
         gc_log_msg:='Flag returned by the RA_INTERFACE_SALESCREDITS_ALL table :'||lc_sales_int_err_flag;
         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
      END IF;


      BEGIN
          IF     lr_get_invoice_rec.linetype='LINE' THEN
                 lc_account_class:='REV';
          ELSIF  lr_get_invoice_rec.linetype='TAX' THEN
                 lc_account_class:='TAX';
          ELSE
                 lc_account_class:='FREIGHT';
          END IF;


-- 2.10 BMarcoux New Code - START
         lc_segment1_1       := NULL;
         lc_segment2_1       := NULL;
         lc_segment3_1       := NULL;
         lc_segment4_1       := NULL;
         lc_segment5_1       := NULL;
         lc_segment6_1       := NULL;
         lc_segment7_1       := NULL;
         lc_segment8_1       := NULL;
         lc_segment9_1       := NULL;
         lc_segment1_interim := NULL;
         lc_segment2_interim := NULL;
         lc_segment3_interim := NULL;
         lc_segment4_interim := NULL;
         lc_segment5_interim := NULL;
         lc_segment6_interim := NULL;
         lc_segment7_interim := NULL;
         lc_segment8_interim := NULL;
         lc_segment9_interim := NULL;

-- Set up Segment Values for 'DEFERRED' Tax Type
-- Roberto:
-- When inserting into RA_INTERFACE_DISTRIBUTIONS_ALL for ACCOUNT_CLASS = 'TAX', if it is for deferred tax code (AR_VAT_TAX_ALL_B.TAX_TYPE = DEFERRED), 
-- then columns interim_tax_segment1...interim_tax_segment9 need to be populated with segment values from the input data (table usbpcs_ar_cleaned)
-- and segmen1...segment9 must get the values derived through AR_VAT_TAX_ALL_B.TAX_ACCOUNT_ID.
          IF lc_account_class = 'TAX' AND UPPER(lr_get_invoice_rec.TAXTYPE) = 'DEFERRED' THEN
             lc_segment1_1       := lr_get_invoice_rec.interimTAXSEGMENT1;
             lc_segment2_1       := lr_get_invoice_rec.interimTAXSEGMENT2;
             lc_segment3_1       := lr_get_invoice_rec.interimTAXSEGMENT3;
             lc_segment4_1       := lr_get_invoice_rec.interimTAXSEGMENT4;
             lc_segment5_1       := lr_get_invoice_rec.interimTAXSEGMENT5;
             lc_segment6_1       := lr_get_invoice_rec.interimTAXSEGMENT6;
             lc_segment7_1       := lr_get_invoice_rec.interimTAXSEGMENT7;
             lc_segment8_1       := lr_get_invoice_rec.interimTAXSEGMENT8;
             lc_segment9_1       := lr_get_invoice_rec.interimTAXSEGMENT9;
             lc_segment1_interim := lr_get_invoice_rec.oraclesegment1;
             lc_segment2_interim := lr_get_invoice_rec.oraclesegment2;
             lc_segment3_interim := lr_get_invoice_rec.oraclesegment3;
             lc_segment4_interim := lr_get_invoice_rec.oraclesegment4;
             lc_segment5_interim := lr_get_invoice_rec.oraclesegment5;
             lc_segment6_interim := lr_get_invoice_rec.oraclesegment6;
             lc_segment7_interim := lr_get_invoice_rec.oraclesegment7;
             lc_segment8_interim := lr_get_invoice_rec.oraclesegment8;
             lc_segment9_interim := lr_get_invoice_rec.oraclesegment9;
-- Roberto:
-- For normal tax code (TAX_TYPE <> DEFERRED) then (as what is currently done now) segment1...segment9 are populated with segment values 
-- from the input data and interim_tax_segment1...interim_tax_segment9 must be null.
          ELSE
             lc_segment1_1       := lr_get_invoice_rec.oraclesegment1;
             lc_segment2_1       := lr_get_invoice_rec.oraclesegment2;
             lc_segment3_1       := lr_get_invoice_rec.oraclesegment3;
             lc_segment4_1       := lr_get_invoice_rec.oraclesegment4;
             lc_segment5_1       := lr_get_invoice_rec.oraclesegment5;
             lc_segment6_1       := lr_get_invoice_rec.oraclesegment6;
             lc_segment7_1       := lr_get_invoice_rec.oraclesegment7;
             lc_segment8_1       := lr_get_invoice_rec.oraclesegment8;
             lc_segment9_1       := lr_get_invoice_rec.oraclesegment9;
             lc_segment1_interim := NULL;
             lc_segment2_interim := NULL;
             lc_segment3_interim := NULL;
             lc_segment4_interim := NULL;
             lc_segment5_interim := NULL;
             lc_segment6_interim := NULL;
             lc_segment7_interim := NULL;
             lc_segment8_interim := NULL;
             lc_segment9_interim := NULL;
          END IF;

         --Insert into RA_INTERFACE_DISTRIBUTIONS_ALL
         INSERT INTO RA_INTERFACE_DISTRIBUTIONS_ALL (
                                                      INTERFACE_LINE_CONTEXT              --1
                                                     ,INTERFACE_LINE_ATTRIBUTE1           --2
                                                     ,INTERFACE_LINE_ATTRIBUTE2           --3
                                                     ,ACCOUNT_CLASS                       --4
                                                     ,AMOUNT                              --5
                                                     ,SEGMENT1                            --6
                                                     ,SEGMENT2                            --7
                                                     ,SEGMENT3                            --8
                                                     ,SEGMENT4                            --9
                                                     ,SEGMENT5                            --10
                                                     ,SEGMENT6                            --11
                                                     ,SEGMENT7                            --12
                                                     ,SEGMENT8                            --13
                                                     ,SEGMENT9                            --14
                                                     ,INTERIM_TAX_SEGMENT1                --15         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT2                --16         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT3                --17         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT4                --18         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT5                --19         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT6                --20         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT7                --21         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT8                --22         -- 2.10 BMarcoux
                                                     ,INTERIM_TAX_SEGMENT9                --23         -- 2.10 BMarcoux
                                                     ,COMMENTS                            --24 --15    -- 2.10 BMarcoux
                                                     ,PERCENT                             --25 --16    -- 2.10 BMarcoux
                                                    )
                                          VALUES   (
                                                     gc_flex_context_code                 --1
                                                    ,lr_get_invoice_rec.invoicenumber     --2
                                                    ,lr_get_invoice_rec.sequencenumber    --3
                                                    ,lc_account_class --'REV', need if    --4
                                                    ,lr_get_invoice_rec.originalamount    --5
                                                    ,lc_segment1_1 --lr_get_invoice_rec.oraclesegment1    --6        -- 2.10 BMarcoux
                                                    ,lc_segment2_1 --lr_get_invoice_rec.oraclesegment2    --7        -- 2.10 BMarcoux
                                                    ,lc_segment3_1 --lr_get_invoice_rec.oraclesegment3    --8        -- 2.10 BMarcoux
                                                    ,lc_segment4_1 --lr_get_invoice_rec.oraclesegment4    --9        -- 2.10 BMarcoux
                                                    ,lc_segment5_1 --lr_get_invoice_rec.oraclesegment5    --10       -- 2.10 BMarcoux
                                                    ,lc_segment6_1 --lr_get_invoice_rec.oraclesegment6    --11       -- 2.10 BMarcoux
                                                    ,lc_segment7_1 --lr_get_invoice_rec.oraclesegment7    --12       -- 2.10 BMarcoux
                                                    ,lc_segment8_1 --lr_get_invoice_rec.oraclesegment8    --13       -- 2.10 BMarcoux
                                                    ,lc_segment9_1 --lr_get_invoice_rec.oraclesegment9    --14       -- 2.10 BMarcoux
                                                    ,lc_segment1_interim                                  --15       -- 2.10 BMarcoux
                                                    ,lc_segment2_interim                                  --16       -- 2.10 BMarcoux
                                                    ,lc_segment3_interim                                  --17       -- 2.10 BMarcoux
                                                    ,lc_segment4_interim                                  --18       -- 2.10 BMarcoux
                                                    ,lc_segment5_interim                                  --19       -- 2.10 BMarcoux
                                                    ,lc_segment6_interim                                  --20       -- 2.10 BMarcoux
                                                    ,lc_segment7_interim                                  --21       -- 2.10 BMarcoux
                                                    ,lc_segment8_interim                                  --22       -- 2.10 BMarcoux
                                                    ,lc_segment9_interim                                  --23       -- 2.10 BMarcoux
                                                    ,'comments'                                           --24 --15  -- 2.10 BMarcoux
                                                    ,100                                                  --25 --16  -- 2.10 BMarcoux
                                                  );
       EXCEPTION
           WHEN OTHERS THEN
                --Log error message
                gc_error_code       :='AR-20';
                gc_error_msg        :='Unexpected error encountered while inserting records into RA_INTERFACE_DISTRIBUTIONS_ALL table' ;
                gc_comments         :=SQLERRM;
                INSERT_ERROR_MSG;
                lc_dist_int_err_flag:='Y';
       END;
       gc_log_msg:='Flag returned by the RA_INTERFACE_DISTRIBUTIONS_ALL table :'||lc_dist_int_err_flag;
       xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


       ln_line_counter:=ln_line_counter+1;
       --Totalling of the invoice for Receivable account
       ln_total_rec_amount:=lr_get_invoice_rec.originalamount+ln_total_rec_amount;
       IF ln_line_counter=ln_tot_inv_lines THEN
          ln_line_counter:=0;
          ln_tot_inv_lines:=0;

          --Insert record for receivable account
          BEGIN
             --Insert into RA_INTERFACE_DISTRIBUTIONS_ALL
             INSERT INTO RA_INTERFACE_DISTRIBUTIONS_ALL (
                                                         INTERFACE_LINE_CONTEXT               --1
                                                         ,INTERFACE_LINE_ATTRIBUTE1           --2
                                                         ,INTERFACE_LINE_ATTRIBUTE2           --3
                                                         ,ACCOUNT_CLASS                       --4
                                                         ,AMOUNT                              --5
                                                         ,SEGMENT1                            --6
                                                         ,SEGMENT2                            --7
                                                         ,SEGMENT3                            --8
                                                         ,SEGMENT4                            --9
                                                         ,SEGMENT5                            --10
                                                         ,SEGMENT6                            --11
                                                         ,SEGMENT7                            --12
                                                         ,SEGMENT8                            --13
                                                         ,SEGMENT9                            --14
                                                         ,COMMENTS                            --15
                                                         ,PERCENT                             --16
                                                        )
                                              VALUES   (
                                                         lc_int_link_context                  --1
                                                        ,lc_int_link_attribute1               --2
                                                        ,lc_int_link_attribute2               --3
                                                        ,'REC'                               --4
                                                        ,ln_total_rec_amount                 --5
                                                        ,lr_get_invoice_rec.oracleoffsetsegment1    --6  --Changed the segment pointing to offset segment :SUBBU/29/Jan
                                                        ,lr_get_invoice_rec.oracleoffsetsegment2    --7
                                                        ,lr_get_invoice_rec.oracleoffsetsegment3    --8
                                                        ,lr_get_invoice_rec.oracleoffsetsegment4    --9
                                                        ,lr_get_invoice_rec.oracleoffsetsegment5    --10
                                                        ,lr_get_invoice_rec.oracleoffsetsegment6    --11
                                                        ,lr_get_invoice_rec.oracleoffsetsegment7    --12
                                                        ,lr_get_invoice_rec.oracleoffsetsegment8    --13
                                                        ,lr_get_invoice_rec.oracleoffsetsegment9    --14
                                                        ,'comments'                           --15
                                                        ,100                                  --16
                                                      );
                                                      ln_total_rec_amount:=0;

          EXCEPTION
              WHEN OTHERS THEN
                    --Log error message
                    gc_error_code       :='AR-20';
                    gc_error_msg        :='Unexpected error encountered while inserting records for receivable into RA_INTERFACE_DISTRIBUTIONS_ALL table' ;
                    gc_comments         :=SQLERRM;
                    INSERT_ERROR_MSG;
                    lc_dist_int_err_flag:='Y';
          END;

       END IF;
               --Any error by API,update the status of the reocrds
        IF (lc_sales_int_err_flag<>'N' OR
            lc_lines_int_err_flag<>'N' OR
            lc_dist_int_err_flag <>'N' ) THEN
            lc_mst_err_flag:='Y';
            --Call the update procedure for updae the rrecord status which will run as a Autonomous transaction
            update_record_status(p_orc_identifier => lr_get_invoice_rec.oracleidentifier
                                ,p_status_flag    =>'PE'
                                );
        ELSE
            update_record_status(p_orc_identifier => lr_get_invoice_rec.oracleidentifier
                                ,p_status_flag    =>'PS'
                                );

        END IF;
   END LOOP;-- End of main loop

   --Get the total no of records
   OPEN  lcu_get_rec_count;
   FETCH lcu_get_rec_count INTO ln_rec_fetched;
   CLOSE lcu_get_rec_count;

   --Get total no of records Inserted
   OPEN  lcu_get_rec_ins_count;
   FETCH lcu_get_rec_ins_count INTO ln_rec_inserted;
   CLOSE lcu_get_rec_ins_count;

   --Get total no of records Errored
   OPEN  lcu_get_rec_err_count;
   FETCH lcu_get_rec_err_count INTO ln_rec_errored;
   CLOSE lcu_get_rec_err_count;

   --Summary information of Records Inserted
   --===============================================
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Summary information of Records Inserted into Interface Tables ');
   fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
   fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
   fnd_file.put_line(fnd_file.log,'Total Records Inserted              :    ' ||ln_rec_inserted);
   fnd_file.put_line(fnd_file.log,'Total Records Errored               :    ' ||ln_rec_errored);

   --Call the error report if any errors
   IF (lc_mst_err_flag <>'N') THEN
      --xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);
      x_retcode:=1;
      ROLLBACK;
   ELSE
     COMMIT;
     x_retcode:=0;
   END IF;


EXCEPTION
WHEN OTHERS THEN
   ROLLBACK;
   gc_error_code       :='API';
   gc_error_msg        :='Unexpected error encountered in procedure process_invoice_data '||SQLERRM;
   gc_comments         :=NULL;
   INSERT_ERROR_MSG;
   x_retcode:=2;
END PROCESS_INVOICE_DATA;

-- +===================================================================+
-- | Name            : PROCESS_PAYMENT_DATA                            |
-- | Description     : Procedure to process payments records           |
-- |                                                                   |
-- |                                                                   |
-- |                                                                   |
-- | Parameters      : NONE                                            |
-- |                                                                   |
-- |                                                                   |
-- | Returns         : NONE                                            |
-- |                                                                   |
-- +===================================================================+

PROCEDURE PROCESS_PAYMENT_DATA (
                                x_errbuf       OUT VARCHAR2
                               ,x_retcode      OUT VARCHAR2
                                )
IS
lc_return_status VARCHAR2(2);
ln_msg_count     NUMBER;
lc_msg_data VARCHAR2(2400);
ln_count NUMBER;
ln_cash_receipt_id NUMBER;
lc_msg_data_out VARCHAR2(2400);
lc_mesg VARCHAR2(1000);
lc_invoice_exist_flag VARCHAR2(1):='N';
lc_get_cust_flag      VARCHAR2(1):='N';
lc_api_err_flag      VARCHAR2(1):='N';
lc_api_mst_err_flag  VARCHAR2(1):='N';
lc_customer_no hz_cust_accounts.account_number%TYPE;

ln_rec_fetched            NUMBER:=0;
ln_rec_processed          NUMBER:=0;
ln_rec_errored            NUMBER:=0;
lc_currencyconversionrate  usbpcs_ar_cleaned.currencyconversionrate%TYPE;
lc_currencyconversiontype VARCHAR2(4);
lc_receipt_num  varchar2(10000);
lc_temp_msg VARCHAR2(2400);



CURSOR lcu_get_payment_rec
IS
SELECT *
FROM   usbpcs_ar_cleaned UAC
WHERE  UAC.oracletransactiontype IN ('P','O','U')
AND   UAC.operatingunit=gc_org_name
AND   UAC.charuserfld4='VS';

---------------------------------------
--Cursor to check Invoice in the system
---------------------------------------
CURSOR lcu_chk_invoice_exist(p_invoice VARCHAR2)
IS
SELECT   'N'
   from dual;

-----------------------------------------------
-- Cursor to derive the Customer no
-------------------------------------------
CURSOR lcu_get_customer_no(p_customer_id NUMBER)
IS
SELECT account_number
FROM   hz_cust_accounts HCA
WHERE HCA.cust_account_id=p_customer_id;


-----------------------------------
--Get Count for total no of records
-----------------------------------
CURSOR lcu_get_rec_count
IS
SELECT COUNT('1')
FROM  usbpcs_ar_cleaned UAC
WHERE UAC.oracletransactiontype in ('P','O','U')
AND   UAC.operatingunit=gc_org_name;


----------------------------------------------
--Get Count for total no of records  Validated
----------------------------------------------
CURSOR lcu_get_rec_prc_count
IS
SELECT COUNT('1')
FROM  usbpcs_ar_cleaned UAC
WHERE UAC.oracletransactiontype in ('P','O','U')
AND   UAC.operatingunit=gc_org_name
AND   UAC.CharUserFld4='PS';

----------------------------------------------
--Get Count for total no of records  Errored
----------------------------------------------
CURSOR lcu_get_rec_err_count
IS
SELECT COUNT('1')
FROM  usbpcs_ar_cleaned UAC
WHERE UAC.oracletransactiontype in ('P','O','U')
AND   UAC.operatingunit=gc_org_name
AND   UAC.CharUserFld4='PE';

---------------------------------------------------
-- Cursor to check if the Receipt for the
-- combinetion Recp no,recpt date,custome and amount
-- already exist in the system
---------------------------------------------------

CURSOR lcu_chk_unapp_exist(p_recpt VARCHAR,p_date DATE,p_amount NUMBER,p_CUSTOMER VARCHAR)
IS
SELECT   cash_receipt_id --changes 1.6
FROM      ar_cash_receipts_v ACR
WHERE     ACR.receipt_number                      =p_recpt
AND       TO_DATE(ACR.receipt_date,'DD-MON-YYYY') =TO_DATE(p_date,'DD-MON-YYYY')
AND       ACR.amount                              =p_amount
AND       NVL(ACR.customer_number,1)              =NVL(p_CUSTOMER,1);






BEGIN



   gc_log_msg:='*************START OF PROCESS PROCEDURE*************';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   FOR lr_get_payment_rec IN lcu_get_payment_rec
   LOOP
      gc_record_number       :=lr_get_payment_rec.oracleidentifier;
      gc_record_identifier   :=lr_get_payment_rec.invoicenumber||' - Transaction Type: '||lr_get_payment_rec.oracletransactiontype;
      lc_receipt_num:=NULL;
      --lc_receipt_num:=gc_country_code||' - '||lr_get_payment_rec.CUSTOMERNUMBER||' - '||lr_get_payment_rec.ORACLEIDENTIFIER;
      lc_receipt_num:=  lr_get_payment_rec.oracleidentifier;

      --Re Initialise variables
      lc_api_err_flag  :='N';
      ln_msg_count     :=NULL;
      lc_msg_data      :=NULL;
      lc_return_status :=NULL;

        IF gc_currency_code <> lr_get_payment_rec.oraclecurrencycode THEN
            lc_currencyconversionrate:=lr_get_payment_rec.currencyconversionrate;
            lc_currencyconversiontype:=gc_conv_type;
        ELSE
            lc_currencyconversionrate:=NULL;
            lc_currencyconversiontype:=NULL;


        END IF;


            gc_log_msg:='**************ORACLEIDENTIFIER****************'||lr_get_payment_rec.ORACLEIDENTIFIER;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

            gc_log_msg:='**************RECEIPT DATE****************'||NVL(TO_DATE(lr_get_payment_rec.dateposted,'YYYY-MM-DD'),NVL(TO_DATE(lr_get_payment_rec.invoicedate,'YYYY-MM-DD'),SYSDATE)) ;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

         IF lr_get_payment_rec.oracletransactiontype='P' THEN

            --Call the Partial payment API
            AR_RECEIPT_API_PUB.create_and_apply
                                            ( p_api_version       => 1.0
                                             ,p_init_msg_list     => FND_API.G_TRUE
                                             ,p_commit            => FND_API.G_FALSE
                                             ,p_validation_level  => FND_API.G_VALID_LEVEL_FULL
                                             ,x_return_status     => lc_return_status
                                             ,x_msg_count         => ln_msg_count
                                             ,x_msg_data          => lc_msg_data
                                             ,p_currency_code     => lr_get_payment_rec.oraclecurrencycode
                                                                    --Start of changes V1.6
                                             ,p_amount            => ABS(lr_get_payment_rec.originalamount)
                                             ,p_receipt_number    => lc_receipt_num --lr_get_payment_rec.invoicenumber
                                                                 --End of changes V1.6
                                                                  --Start of changes V1.7
                                             ,p_receipt_date      => NVL(TO_DATE(lr_get_payment_rec.dateposted,'YYYY-MM-DD'),NVL(TO_DATE(lr_get_payment_rec.invoicedate,'YYYY-MM-DD'),SYSDATE))
                                                                   --End of changes V1.7
                                             ,p_gl_date           => to_date(gd_gl_date,'DD-MON-RRRR')
                                             ,p_customer_number   => lr_get_payment_rec.oraclecharfld4
                                             --,p_location          => lr_get_payment_rec.oracleintfld3
                                             ,p_receipt_method_id  => gn_receipt_method_id
                                             ,p_trx_number        => lr_get_payment_rec.invoicenumber
                                             ,p_cr_id             => ln_cash_receipt_id
                                             ,p_exchange_rate_type =>lc_currencyconversiontype --'User'
                                             ,p_exchange_rate      =>lc_currencyconversionrate  --lr_get_payment_rec.currencyconversionrate
                                             );
            gc_log_msg:='Status returned by the create_and_apply '||lc_return_status;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


            IF lc_return_status<>'S' THEN
               lc_api_err_flag:='Y';
               IF ln_msg_count = 1 Then
                  gc_error_code := 'API-AR01';
                  gc_error_msg  := lc_msg_data;
                  gc_comments   := NULL;
                  INSERT_ERROR_MSG;
                  gc_log_msg:='API ERR MSG1'||lc_msg_data;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               ELSIF ln_msg_count > 1 Then
                  LOOP
                     --ln_count := ln_count + 1;
                     lc_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                     lc_temp_msg:=lc_temp_msg||lc_msg_data;
                     gc_log_msg:='API ERR MSG1 '||lc_msg_data;
                     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                     IF lc_msg_data is NULL Then
                        EXIT;
                     END IF;
                  END LOOP;
                  gc_error_code := 'API-AR02';
                  gc_error_msg  := lc_temp_msg;
                  lc_temp_msg:=null;
                  gc_comments   := NULL;
                  INSERT_ERROR_MSG;
               END IF;
            END IF;
            ln_cash_receipt_id:=NULL;

         ELSIF lr_get_payment_rec.oracletransactiontype='U'   THEN
               --Call the Unapplied API
               AR_RECEIPT_API_PUB.create_cash
                                          (   p_api_version        => 1.0
                                             ,p_init_msg_list      => FND_API.G_TRUE
                                             ,p_commit             => FND_API.G_FALSE
                                             ,p_validation_level   => FND_API.G_VALID_LEVEL_FULL
                                             ,x_return_status      => lc_return_status
                                             ,x_msg_count          => ln_msg_count
                                             ,x_msg_data           => lc_msg_data
                                             ,p_currency_code      => lr_get_payment_rec.oraclecurrencycode
                                                                      --Start of changes V1.6
                                             ,p_amount             => ABS(lr_get_payment_rec.remainingdue)
                                                                      --End of changes V1.6 Used ABS Function
                                             ,p_receipt_number     => lc_receipt_num --lr_get_payment_rec.invoicenumber
                                             ,p_receipt_date       => to_date(gd_gl_date,'DD-MON-RRRR')  -- jul-05-07
                                             ,p_customer_number    => lr_get_payment_rec.oraclecharfld4
                                             ,p_receipt_method_id  => gn_receipt_method_id
                                             ,p_cr_id              => ln_cash_receipt_id
                                             ,p_exchange_rate_type =>lc_currencyconversiontype
                                             ,p_exchange_rate      =>lc_currencyconversionrate
                                             );
                gc_log_msg:='Status returned by the create_cash '||lc_return_status;
                xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

               IF lc_return_status<>'S' THEN
                  lc_api_err_flag:='Y';
                  IF ln_msg_count = 1 Then
                      gc_error_code := 'API-AR01';
                      gc_error_msg  := lc_msg_data;
                      gc_comments   := NULL;
                      INSERT_ERROR_MSG;
                       gc_log_msg:='API ERR MSG2'||lc_msg_data;
                       xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                  ELSIF ln_msg_count > 1 Then
                      LOOP
                         --ln_count := ln_count + 1;
                         lc_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                         lc_temp_msg:=lc_temp_msg||lc_msg_data;
                          gc_log_msg:='API ERR MSG2 '||lc_msg_data;
                          xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


                          gc_log_msg:='API ERR MSG 2'||lc_msg_data;
                          xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                         IF lc_msg_data is NULL Then
                            EXIT;
                         END IF;
                      END LOOP;
                      gc_error_code := 'API-AR02';
                      gc_error_msg  := lc_temp_msg;
                      lc_temp_msg :=null;
                      gc_comments   := NULL;
                      INSERT_ERROR_MSG;
                  END IF;
               END IF;
         ELSE  --IF lr_get_payment_rec.oracletransactiontype='O'   THEN

              gc_log_msg:='Before calling  create_cash for Onaccount'||lc_return_status;
              xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



            --lc_receipt_num:=gc_country_code||' - '||lr_get_payment_rec.CUSTOMERNUMBER||' - '||lr_get_payment_rec.ORACLEIDENTIFIER;
            --OPEN  lcu_chk_unapp_exist(lr_get_payment_rec.invoicenumber,SYSDATE,lr_get_payment_rec.remainingdue,lr_get_payment_rec.oraclecharfld4);
            OPEN  lcu_chk_unapp_exist(lc_receipt_num,SYSDATE,lr_get_payment_rec.remainingdue,lr_get_payment_rec.oraclecharfld4);
            FETCH lcu_chk_unapp_exist INTO ln_cash_receipt_id ;
               IF lcu_chk_unapp_exist%NOTFOUND THEN

               gc_log_msg:='***lcu_chk_unapp_exist%NOTFOUND***';
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                   --Call the Unapplied API to create

                    gc_log_msg:='lr_get_payment_rec.oraclecurrencycode******'||lr_get_payment_rec.oraclecurrencycode;
                    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                   gc_log_msg:='lr_get_payment_rec.remainingdue******'||lr_get_payment_rec.remainingdue;
                   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                    gc_log_msg:='lr_get_payment_rec.lc_receipt_num******'||lc_receipt_num;
                    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


                        gc_log_msg:='lr_get_payment_rec.oraclecharfld4******'||lr_get_payment_rec.oraclecharfld4;
                        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                      gc_log_msg:='gn_receipt_method_id******'||gn_receipt_method_id;
                      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                        gc_log_msg:='lc_currencyconversionrate'||lc_currencyconversionrate;
                        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                   	 gc_log_msg:='ln_cash_receipt_id'||ln_cash_receipt_id;
                   	 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                    gc_log_msg:='lc_currencyconversiontype'||lc_currencyconversiontype;
                    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


                   AR_RECEIPT_API_PUB.create_cash
                                              (   p_api_version        => 1.0
                                                 ,p_init_msg_list      => FND_API.G_TRUE
                                                 ,p_commit             => FND_API.G_FALSE
                                                 ,p_validation_level   => FND_API.G_VALID_LEVEL_FULL
                                                 ,x_return_status      => lc_return_status
                                                 ,x_msg_count          => ln_msg_count
                                                 ,x_msg_data           => lc_msg_data
                                                 ,p_currency_code      => lr_get_payment_rec.oraclecurrencycode
                                                                          --Start of changes V1.6
                                                 ,p_amount             => ABS(lr_get_payment_rec.remainingdue)
                                                                          --End  of changes V1.6 Used ABS Function
                                                 ,p_receipt_number     => lc_receipt_num --lr_get_payment_rec.invoicenumber
                                                 ,p_receipt_date       => to_date(gd_gl_date,'DD-MON-RRRR')
                                                 ,p_customer_number    => lr_get_payment_rec.oraclecharfld4
                                                 ,p_receipt_method_id  => gn_receipt_method_id
                                                 ,p_cr_id              => ln_cash_receipt_id
                                                 ,p_exchange_rate_type =>lc_currencyconversiontype
                                                 ,p_exchange_rate      =>lc_currencyconversionrate
                                                 );


                    gc_log_msg:='Status returned by the create_cash for Onaccount'||lc_return_status;
                    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



                   IF lc_return_status<>'S' THEN  --IF lc_return_status<>'S' THEN
                      lc_api_err_flag:='Y';
                      IF ln_msg_count = 1 Then    --1
                          gc_error_code := 'API-AR01';
                          gc_error_msg  := lc_msg_data;
                          gc_comments   := NULL;
                          INSERT_ERROR_MSG;

                           gc_log_msg:='API ERR MSG 3'||lc_msg_data;
                           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                      ELSIF ln_msg_count > 1 Then --1
                          LOOP
                             --ln_count := ln_count + 1;
                             lc_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                             lc_temp_msg:=lc_temp_msg||lc_msg_data;
                               gc_log_msg:='API ERR MSG 3'||lc_msg_data;
                               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



                             IF lc_msg_data is NULL THEN
                                EXIT;
                             END IF;
                          END LOOP;
                          gc_error_code := 'API-AR02';
                          gc_error_msg  := lc_temp_msg ; --lc_msg_data;
                          lc_temp_msg  :=NULL;
                          gc_comments   := NULL;
                          INSERT_ERROR_MSG;
                      END IF;                   --1
                   ELSE --IF lc_return_status<>'S' THEN

                         gc_log_msg:='Before calling  Apply_on_account for Onaccount'||lc_return_status;
                         xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                     lc_return_status:=NULL;
                     AR_RECEIPT_API_PUB.Apply_on_account
                                                       (  p_api_version       => 1.0,
                                                          p_init_msg_list     => FND_API.G_TRUE,
                                                          p_commit            => FND_API.G_FALSE,
                                                          p_validation_level  => FND_API.G_VALID_LEVEL_FULL,
                                                          x_return_status     => lc_return_status,
                                                          x_msg_count         => ln_msg_count,
                                                          x_msg_data          => lc_msg_data,
                                                          --p_receipt_number    => lr_get_payment_rec.invoicenumber,
                                                          p_cash_receipt_id   => ln_cash_receipt_id,
                                                          p_apply_date        => to_date(gd_gl_date,'DD-MON-RRRR'),  -- 05-jul-07
                                                                                 --Start of changes V1.6
                                                          p_amount_applied    => ABS(lr_get_payment_rec.remainingdue)
                                                                                 --End of changes V1.6  used ABS function
                                                         );

                     gc_log_msg:='Status returned by the Apply_on_account for Onaccount'||lc_return_status;
                     xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



                     IF lc_return_status<>'S' THEN --1
                         lc_api_err_flag:='Y';
                         IF ln_msg_count = 1 Then   --2
                             gc_error_code := 'API-AR01';
                             gc_error_msg  := lc_msg_data;
                             gc_comments   := NULL;
                             INSERT_ERROR_MSG;

                              gc_log_msg:='API ERR MSG4 '||lc_msg_data;
                              xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                         ELSIF ln_msg_count > 1 Then --2
                             LOOP
                                --ln_count := ln_count + 1;
                                lc_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                                lc_temp_msg:=lc_temp_msg||lc_msg_data;
                                 gc_log_msg:='API ERR MSG4 '||lc_msg_data;
                                 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                                IF lc_msg_data is NULL Then
                                   EXIT;
                                END IF;
                             END LOOP;
                             gc_error_code := 'API-AR02';
                             gc_error_msg  := lc_temp_msg;
                             lc_temp_msg:=NULL;
                             gc_comments   := NULL;
                             INSERT_ERROR_MSG;
                         END IF;                    --2
                     END IF;                        --1
                   END IF; -- IF lc_return_status<>'S' THEN

               ELSE --IF lcu_chk_receipt_exist%NOTFOUND THEN

                  gc_log_msg:='Status returned by the Apply_on_account for Onaccount if nothing is found'||lc_return_status;
                  xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                    lc_return_status:=NULL;
                   AR_RECEIPT_API_PUB.Apply_on_account
                                                     (  p_api_version       => 1.0,
                                                        p_init_msg_list     => FND_API.G_TRUE,
                                                        p_commit            => FND_API.G_FALSE,
                                                        p_validation_level  => FND_API.G_VALID_LEVEL_FULL,
                                                        x_return_status     => lc_return_status,
                                                        x_msg_count         => ln_msg_count,
                                                        x_msg_data          => lc_msg_data,
                                                        --p_receipt_number    => lr_get_payment_rec.invoicenumber,
                                                        p_cash_receipt_id   => ln_cash_receipt_id,
                                                        p_apply_date        => to_date(gd_gl_date,'DD-MON-RRRR'), -- 05-jul-07 SYSDATE
                                                                              --Start of changes V1.6
                                                        p_amount_applied    => ABS(lr_get_payment_rec.remainingdue)
                                                                              --End of changes V1.6  used ABS function
                                                       );

                   IF lc_return_status<>'S' THEN
                       lc_api_err_flag:='Y';
                       IF ln_msg_count = 1 Then
                           gc_error_code := 'API-AR01';
                           gc_error_msg  := lc_msg_data;
                           gc_comments   := NULL;
                           INSERT_ERROR_MSG;
                       ELSIF ln_msg_count > 1 Then
                           LOOP
                              --ln_count := ln_count + 1;
                              lc_msg_data := FND_MSG_PUB.Get(FND_MSG_PUB.G_NEXT,FND_API.G_FALSE);
                              lc_temp_msg:=lc_temp_msg||lc_msg_data;
                              IF lc_msg_data is NULL Then
                                 EXIT;
                              END IF;
                           END LOOP;
                           gc_error_code := 'API-AR02';
                           gc_error_msg  := lc_temp_msg;
                           lc_temp_msg:=NULL;
                           gc_comments   := NULL;
                           INSERT_ERROR_MSG;
                       END IF;
                   END IF;
               END IF; --IF lcu_chk_receipt_exist%NOTFOUND THEN
            CLOSE lcu_chk_unapp_exist;
        END IF;--  --IF lr_get_payment_rec.oracletransactiontype='O'   THEN
       --END IF;

           gc_log_msg:='Status lc_api_err_flag'|| lc_api_err_flag ;
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

           gc_log_msg:='Status lc_api_mst_err_flag'|| lc_api_mst_err_flag ;
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



            --Any error by API,update the status of the reocrds
            IF (lc_api_err_flag<>'N') THEN
                lc_api_mst_err_flag:='Y';

                 gc_log_msg:='Status lc_api_err_flag1'|| lc_api_err_flag ;
                 xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
                 --Call the update procedure for updae the rrecord status which will run as a Autonomous transaction
                 update_record_status(p_orc_identifier => lr_get_payment_rec.oracleidentifier
                                     ,p_status_flag    =>'PE'
                                      );
            ELSE

            gc_log_msg:='Status lc_api_mst_err_flag2'|| lc_api_mst_err_flag ;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                 update_record_status(p_orc_identifier => lr_get_payment_rec.oracleidentifier
                                     ,p_status_flag    =>'PS'
                                     );

            END IF;


   END LOOP;

    --Get the toal no of records
     OPEN  lcu_get_rec_count;
    FETCH lcu_get_rec_count INTO ln_rec_fetched;
    CLOSE lcu_get_rec_count;

    --Get total no of records Validated
    OPEN lcu_get_rec_prc_count;
    FETCH lcu_get_rec_prc_count INTO ln_rec_processed;
    CLOSE lcu_get_rec_prc_count;

    --Get total no of records Errored
    OPEN lcu_get_rec_err_count;
    FETCH lcu_get_rec_err_count INTO ln_rec_errored;
    CLOSE lcu_get_rec_err_count;


--Summary information of Records Processed
--===============================================
fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
fnd_file.put_line(fnd_file.log,'Summary information of Records processed ');
fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
fnd_file.put_line(fnd_file.log,'Total Records Processed             :    ' ||ln_rec_processed);
fnd_file.put_line(fnd_file.log,'Total Records Errored/Warning       :    ' ||ln_rec_errored);

--Call the error report if any errors
IF (lc_api_mst_err_flag <>'N') THEN
   --xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);
   x_retcode:=1;
   ROLLBACK;
ELSE
  COMMIT;
END IF;
EXCEPTION
WHEN OTHERS THEN
   ROLLBACK;
   gc_error_code       :='API';
   gc_error_msg        :='Unexpected error encountered in procedure process_payment_data '||SQLERRM;
   gc_comments         :=NULL;
   INSERT_ERROR_MSG;
   x_retcode:=2;
END PROCESS_PAYMENT_DATA;

-- +===================================================================+
-- | Name          : VALIDATE_PAYMENT_DATA                             |
-- | Description   : Procedure to validate Payments records            |
-- |                                                                   |
-- | Parameters    : x_errbuf   OUT                                    |
-- |                 x_errbuf   OUT                                    |
-- |                 p_debug    IN                                     |
-- | Returns       : NONE;                                             |
-- |                                                                   |
-- +===================================================================+
PROCEDURE VALIDATE_PAYMENT_DATA (
                              x_errbuf       OUT VARCHAR2
                             ,x_retcode      OUT VARCHAR2
                             ,p_debug         IN VARCHAR2
                             ,p_gl_date       IN VARCHAR2
                             )
IS
   --Local Valribles
   --for payments
   lc_invoice_exist_flag    VARCHAR2(1):='N';
   lc_receipt_exist_flag    VARCHAR2(1):='N';
   lc_amount_flag           VARCHAR2(1):='N';
   lc_gl_date_flag          VARCHAR2(1):='Y';
   lc_currency_err_flag     VARCHAR2(1):='N';
   lc_bill_err_flag         VARCHAR2(1):='N';
   lc_application_flag      VARCHAR2(1):='N';
   ln_rec_fetched           NUMBER:=0;
   ln_rec_validated         NUMBER:=0;
   ln_rec_errored           NUMBER:=0;
   ln_commit_point          NUMBER:=0;

   ln_amount                usbpcs_ar_cleaned.originalamount%TYPE;
   ln_amt                   usbpcs_ar_cleaned.originalamount%TYPE:=99999999999;
   ln_amt1                  usbpcs_ar_cleaned.originalamount%TYPE:=99999999999;
   ln_customernumber        usbpcs_ar_cleaned.customernumber%TYPE :='-9-9-9';
   lc_account_number        hz_cust_accounts.account_number%TYPE;





   lc_mast_err_flag          VARCHAR2(1):='N';
   lc_par_unp_dup_exist_flag VARCHAR2(1):='N';
   lc_item_flag              VARCHAR2(1):='N';
   lc_chk_recpt_mtd_flag     VARCHAR2(1):='N';
   ln_segment_no             NUMBER := 1;                --variable to hold the segment number
   ln_valid_segment_count    NUMBER := 0;                --variable to hold the valid segment count
   lc_seg_values_exists      VARCHAR2(1);
   lc_account_segment_flag   VARCHAR2(1);
   lc_concat_segments        VARCHAR2(1000);
   lc_setup_exist            VARCHAR2(1);
   lc_country_code           VARCHAR2(100);
   ln_inv_amt                NUMBER;
   lc_invoice                usbpcs_ar_cleaned.invoicenumber%TYPE          :='+0+9';
   lc_transaction            usbpcs_ar_cleaned.oracletransactiontype%TYPE  :='+0+9';
   lc_batch_name             ra_batch_sources.name%TYPE ;
   ln_salesrep_id            ra_salesreps.salesrep_id%TYPE;
   lc_salesrep_number        ra_salesreps.salesrep_number%TYPE;
   ln_sales_credit_type_id   so_sales_credit_types.sales_credit_type_id%TYPE;
   lc_sales_credit           so_sales_credit_types.name%TYPE;
   ln_seqno                  usbpcs_ar_cleaned.sequencenumber%TYPE;
   lc_item_uom               mtl_system_items_b.primary_uom_code%TYPE;
   lc_item_desc              mtl_system_items_b.description%TYPE;
   ln_bcust_acct_site_id     hz_cust_acct_sites_all.cust_acct_site_id%TYPE;
   ln_bcust_account_id       hz_cust_accounts.cust_account_id%TYPE;
   lc_badd_orig_sys_ref      hz_cust_acct_sites_all.orig_system_reference%TYPE;
   lc_bcst_orig_sys_ref      hz_cust_accounts.orig_system_reference%TYPE;
   ln_scust_acct_site_id     hz_cust_acct_sites_all.cust_acct_site_id%TYPE;
   ln_scust_account_id       hz_cust_accounts.cust_account_id%TYPE;
   lc_sadd_orig_sys_ref      hz_cust_acct_sites_all.orig_system_reference%TYPE;
   lc_scst_orig_sys_ref      hz_cust_accounts.orig_system_reference%TYPE;
   lc_seg_value              usbpcs_ar_cleaned.oraclesegment1%TYPE;
   lc_flex_value             fnd_flex_values_vl.flex_value%TYPE;
   lc_segment1               usbpcs_ar_cleaned.oraclesegment1%TYPE;
   lc_segment2               usbpcs_ar_cleaned.oraclesegment2%TYPE;
   lc_segment3               usbpcs_ar_cleaned.oraclesegment3%TYPE;
   lc_segment4               usbpcs_ar_cleaned.oraclesegment4%TYPE;
   lc_segment5               usbpcs_ar_cleaned.oraclesegment5%TYPE;
   lc_segment6               usbpcs_ar_cleaned.oraclesegment6%TYPE;
   lc_segment7               usbpcs_ar_cleaned.oraclesegment7%TYPE;
   lc_segment8               usbpcs_ar_cleaned.oraclesegment8%TYPE;
   lc_segment9               usbpcs_ar_cleaned.oraclesegment9%TYPE;
   ln_terms_id               ra_terms.term_id%TYPE;
   lc_terms_name             ra_terms.name%TYPE;

   --------------------------------------------------------
   -- Cursor to get all the records from the staging table
   --------------------------------------------------------
   CURSOR lcu_get_payment_rec
   IS
   SELECT *
   FROM   usbpcs_ar_cleaned UAC
   WHERE  UAC.CharUserFld4 is NULL
   AND    UAC.operatingunit=gc_org_name
   AND    UAC.oracletransactiontype in ('P','O','U')
   ORDER BY UAC.invoicenumber
           ,UAC.oracletransactiontype;


   -----------------------------------
   --Get Count for total no of records
   -----------------------------------
   CURSOR lcu_get_rec_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('P','O','U')
   AND   UAC.operatingunit=gc_org_name;
   --AND   UAC.invoicenumber in (8883861 )  ;

   ----------------------------------------------
   --Get Count for total no of records  Validated
   ----------------------------------------------
   CURSOR lcu_get_rec_val_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('P','O','U')
   AND   UAC.operatingunit=gc_org_name
   AND   UAC.CharUserFld4='VS';

   ----------------------------------------------
   --Get Count for total no of records  Errored
   ----------------------------------------------
   CURSOR lcu_get_rec_err_count
   IS
   SELECT COUNT('1')
   FROM  usbpcs_ar_cleaned UAC
   WHERE UAC.oracletransactiontype in ('P','O','U')
   AND   UAC.operatingunit=gc_org_name
   --AND   UAC.invoicenumber in (8883861 )
   AND   UAC.CharUserFld4='VE';

   ---------------------------------------------------
   -- Cursor to get current Operating Unit Information
   ---------------------------------------------------
   CURSOR  lcu_get_org_info
   IS
   SELECT  HOU.organization_id
          ,HOU.name
          ,HOU.set_of_books_id
          ,GL.currency_code
          ,GL.chart_of_accounts_id
   FROM    hr_operating_units  HOU
          ,gl_sets_of_books    GL
   WHERE   HOU.organization_id   =FND_PROFILE.VALUE('ORG_ID')
   AND     GL.set_of_books_id    =HOU.set_of_books_id;

   ----------------------------------------------
   --Cursor to check if valid currency code exist
   ----------------------------------------------
   CURSOR lcu_chk_currency(p_currency VARCHAR2)
   IS
   SELECT 'N'
   FROM   fnd_currencies FC
   WHERE  SYSDATE BETWEEN NVL(FC.start_date_active, SYSDATE)
   AND    NVL(FC.end_date_active, SYSDATE)
   AND    FC.currency_code = UPPER(p_currency)
   AND    FC.enabled_flag = 'Y';


   --------------------------------------------------------
   -- Cursor to derive BILL_TO Customer and Location info
   -------------------------------------------------------
   CURSOR lcu_get_billto_info(p_bill VARCHAR2)
   IS
   SELECT  HCA.account_number
   FROM    hz_cust_site_uses HCSU
          ,hz_cust_acct_sites_all HCASA
          ,hz_cust_accounts HCA
   WHERE   HCSU.attribute1            =p_bill
   --WHERE   HCSU.site_use_id            =p_bill
   AND     HCSU.cust_acct_site_id     =HCASA.cust_acct_site_id
   AND     HCASA.cust_account_id      =HCA.cust_account_id
   AND     HCSU.site_use_code         ='BILL_TO';


   ---------------------------------------
   --Cursor to check Invoice in the system
   -- MODIFIED JUN-26 prajack
   ---------------------------------------
   CURSOR  lcu_chk_invoice_exist(p_trx_no VARCHAR2)
   IS
   SELECT   'N'

           ,rctlgd.amount
   FROM     ra_customer_trx_all RCTA
           ,ra_batch_sources  RBS
           ,ra_cust_trx_line_gl_dist_v rctlgd
   WHERE    RCTA.trx_number=p_trx_no
   AND      RBS.name=gc_batch_name_inv
   AND      rctlgd.customer_trx_id=RCTA.customer_trx_id
   AND      rctlgd.account_class='REC'
   AND      RCTA.batch_source_id=RBS.batch_source_id
   AND      RBS.ORG_ID  = FND_PROFILE.VALUE ('ORG_ID');
   ---------------------------------------------------
   -- Cursor to check if the Receipt for the
   -- combinetion Recp no,recpt date,custome and amount
   -- already exist in the system
   ---------------------------------------------------

   CURSOR lcu_chk_receipt_exist(p_recpt VARCHAR,p_date DATE,p_amount NUMBER,p_CUSTOMER VARCHAR)
   IS
   SELECT   'N'
   FROM      ar_cash_receipts_v ACR
   WHERE     ACR.receipt_number          =p_recpt
   AND       TO_DATE(ACR.receipt_date,'DD-MON-YYYY')=TO_DATE(p_date,'DD-MON-YYYY')
   AND       ACR.amount                  =ABS(p_amount)
   AND       NVL(ACR.customer_number,1)  =NVL(P_CUSTOMER,1);



   -------------------------------------------------------------------------
   -- Cursor to check if Current Transaction date is Opened in the GL dates
   -------------------------------------------------------------------------
   CURSOR lcu_chk_gl_date(p_date    VARCHAR2)
   IS
   SELECT 'Y'
   FROM   gl_period_statuses GPS
   WHERE  GPS.closing_status ='O'
   AND TO_DATE(p_date,'DD-MON-YYYY')
   BETWEEN NVL(GPS.start_date,SYSDATE) AND
           NVL(GPS.end_date,SYSDATE)
--   BETWEEN NVL(GPS.start_date,SYSDATE) AND
--           NVL(GPS.end_date,SYSDATE)
   AND GPS.application_id=gn_application_id
   AND GPS.set_of_books_id=gc_set_of_books_id;

   ---------------------------------------------
   -- Cursor to check if Receipt Class method id
   ---------------------------------------------
   CURSOR lcu_chk_recpt_mtd(p_receipt_name VARCHAR2)
   IS
   SELECT ARM.receipt_method_id
   FROM   ar_receipt_methods ARM
   WHERE ARM.name =p_receipt_name;

  -----------------------------------------------------------------------
  -- Cursor to derive the countrycode based on the opearating unit name
  -----------------------------------------------------------------------
  CURSOR lcu_get_country_code
  IS
  SELECT charuserfld1
  FROM   usbpcs_ar_cleaned UAC
  WHERE  operatingunit=gc_org_name
  AND    ROWNUM=1;

  ----------------------------------
  -- Cursor to check for Duplication
  ----------------------------------
  CURSOR lcu_chk_dup_exist(p_amount NUMBER,p_invoicenumber VARCHAR2,p_customernumber VARCHAR2)
  IS
  SELECT 'Y'
  FROM usbpcs_ar_cleaned UAC
  WHERE UAC.oracletransactiontype in ('O','U')
  AND   ABS(UAC.remainingdue) =ABS(p_amount)
  AND   UAC.invoicenumber=p_invoicenumber
  AND   UAC.customernumber=p_customernumber
  AND   UAC.charuserfld4 IS NOT NULL
  UNION
  SELECT 'Y'
  FROM  usbpcs_ar_cleaned UAC1
  WHERE UAC1.oracletransactiontype in ('P')
  AND   ABS(UAC1.originalamount)=ABS(p_amount)
  --AND   UAC1.remainingdue =p_amount
  AND   UAC1.invoicenumber=p_invoicenumber
  AND   UAC1.customernumber=p_customernumber
  AND   UAC1.charuserfld4 IS NOT NULL ;



   ---------------------------------------------------
   -- Cursor to get Current Application Id
   ---------------------------------------------------
   CURSOR lcu_get_appl_id
   IS
   SELECT FA.application_id
   FROM   fnd_application FA
   WHERE  FA.application_short_name ='AR';


BEGIN
   gc_log_msg               :='Start of AR Payment Validation';
   gc_con_prg_shot_name     :='XXHA_AR_INVOICE_PAY_CONV';
   gc_program_name          :='AR  Payment Conversion';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
   gc_debug_flag:=p_debug;
   gd_gl_date:=   TO_DATE(p_gl_date,'DD-MON-YYYY');
 --  p_gl_date :=  TO_DATE(p_gl_date,'DD-MON-YYYY');

   gc_log_msg:='gd_gl_date'||gd_gl_date;
    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

     gc_log_msg:='p_gl_date'||TO_DATE(p_gl_date,'DD-MON-YYYY');
    xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



    --------------------
    --Get Application Id
    --------------------
    lc_application_flag:='Y';
    OPEN  lcu_get_appl_id;
    FETCH lcu_get_appl_id INTO gn_application_id;
       IF lcu_get_appl_id%NOTFOUND THEN
          --Log error
          gc_error_code :='SETUP-Error';
          gc_error_msg  :='Application Short name (AR) is not defined';
          gc_comments   :='Please define this Application TOP';
          INSERT_ERROR_MSG;
          lc_application_flag:='N';
       END IF;
    CLOSE lcu_get_appl_id;

   -----------------------------------------
   --Get Operating unit Information
   -----------------------------------------
   OPEN  lcu_get_org_info;
   FETCH lcu_get_org_info INTO gn_org_id,gc_org_name,gc_set_of_books_id,gc_currency_code,gn_chart_of_accounts_id;
   CLOSE lcu_get_org_info;

   ---------------------------------------------
   --Get the country code from the staging table
   --based on the operating unit name
   ---------------------------------------------
   OPEN  lcu_get_country_code;
   FETCH lcu_get_country_code INTO  lc_country_code;
   CLOSE lcu_get_country_code;

   --******************************8
   gc_country_code:= lc_country_code;

   -------------------------------------------------
   -- Check if Receipt Class methods are defined
   -------------------------------------------------
   lc_chk_recpt_mtd_flag :='Y';
   gn_receipt_method_name:=lc_country_code||' Conv Receipts';
   OPEN  lcu_chk_recpt_mtd(gn_receipt_method_name);
   FETCH lcu_chk_recpt_mtd INTO gn_receipt_method_id ;
      IF lcu_chk_recpt_mtd%NOTFOUND THEN
          --Log error
          gc_error_code       :='SETUP-Error';
          gc_error_msg        :='Receipt Class Method :'||gn_receipt_method_name||' is not defined';
          gc_comments         :='Please disable this Receipt Method';
          INSERT_ERROR_MSG;
          lc_chk_recpt_mtd_flag:='N';
      END IF;
   CLOSE lcu_chk_recpt_mtd;
   gc_log_msg:='Flag returned by the Transaction Type cursor XX Conv CM:'||lc_chk_recpt_mtd_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   ----------------------------------------------------------------
   -- Check if the selected GL date is Opened in Accounting Periods
   ----------------------------------------------------------------  
   OPEN  lcu_chk_gl_date(p_gl_date);
   FETCH lcu_chk_gl_date INTO lc_gl_date_flag;
      IF lcu_chk_gl_date%NOTFOUND  THEN
         --Log error
         gc_error_code :='SETUP-Error';
         gc_error_msg  :='GL Date: '||p_gl_date||' is not opened in Accounting Periods'||', Application_id: '||gn_application_id||', Set_of_books_id: '||gc_set_of_books_id;
         gc_comments   :='Please Open this Date';
         INSERT_ERROR_MSG;
         lc_gl_date_flag:='N';
      END IF;
   CLOSE lcu_chk_gl_date;
   gc_log_msg:='Flag returned by the GL Date Cursor :'||lc_gl_date_flag;
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

   IF lc_gl_date_flag<>'N'  AND lc_chk_recpt_mtd_flag <>'N'  AND lc_application_flag <>'N' THEN
      FOR lr_get_payment_rec IN lcu_get_payment_rec
      LOOP
          --Re Initialise the variables
           lc_currency_err_flag   :='N';
            lc_amount_flag        :='N';

           gc_record_number       :=NULL;
           gc_record_identifier   :=NULL;

           gc_record_number       :=lr_get_payment_rec.oracleidentifier;
           gc_record_identifier   :=lr_get_payment_rec.invoicenumber||' - Transaction Type: '||lr_get_payment_rec.oracletransactiontype;

           ----------------------------------------------------
           -- Check for Duplicate records in the staging table
           ----------------------------------------------------
           IF (lr_get_payment_rec.invoicenumber IS NOT NULL) THEN
               IF lr_get_payment_rec.oracletransactiontype ='P' THEN
                   --------------------------
                   --Check if amount is Valid
                   --------------------------
                  IF NVL(lr_get_payment_rec.originalamount,0) =0  THEN
                     --Log error message
                      gc_error_code       :='AR-P08';
                      gc_error_msg        :='Invalid Amount ';
                      gc_comments         :='Please provide a value amount';
                      INSERT_ERROR_MSG;
                      lc_amount_flag:='Y';
                  ELSE
                      --Start of changes V1.7
                     /* OPEN lcu_chk_dup_exist(lr_get_payment_rec.originalamount,lr_get_payment_rec.invoicenumber,lr_get_payment_rec.customernumber);
                      FETCH lcu_chk_dup_exist INTO lc_par_unp_dup_exist_flag;
                         IF lcu_chk_dup_exist%FOUND THEN
                            lc_par_unp_dup_exist_flag:='Y';
                            gc_error_code       :='AR01-1';
                            gc_error_msg        :='Duplicate Combinetion of records exist  for the Invoice number : '||lr_get_payment_rec.invoicenumber||' in the Staging table';
                            gc_comments         :='Please use a different Invoice Number';
                            INSERT_ERROR_MSG;
                         ELSE
                             lc_par_unp_dup_exist_flag:='N';
                         END IF;
                      CLOSE lcu_chk_dup_exist;	  */
                      --End of changes V1.7
                      NULL;
                  END IF;--IF NVL(lr_get_payment_rec.originalamount,-1)
               ELSE   --IF lr_get_payment_rec.oracletransactiontype ='P' THEN
                  IF NVL(lr_get_payment_rec.remainingdue, 0) =0 THEN
                      --Log error message
                       gc_error_code       :='AR-P08';
                       gc_error_msg        :='Invalid Amount ';
                       gc_comments         :='Please provide a value amount';
                       INSERT_ERROR_MSG;
                       lc_amount_flag:='Y';
                  ELSE
                      --Start of changes V1.7
                      /*OPEN lcu_chk_dup_exist(lr_get_payment_rec.remainingdue,lr_get_payment_rec.invoicenumber,lr_get_payment_rec.customernumber);
                      FETCH lcu_chk_dup_exist INTO lc_par_unp_dup_exist_flag;
                         IF lcu_chk_dup_exist%FOUND THEN
                            lc_par_unp_dup_exist_flag:='Y';
                            gc_error_code       :='AR01-1';
                            gc_error_msg        :='Duplicate Combinetion of records exist  for the Invoice number : '||lr_get_payment_rec.invoicenumber||' in the Staging table';
                            gc_comments         :='Please use a different Invoice Number';
                            INSERT_ERROR_MSG;
                         ELSE
                             lc_par_unp_dup_exist_flag:='N';
                         END IF;
                      CLOSE lcu_chk_dup_exist;
                      */
                      --End of changes V1.7
                      NULL;
                  END IF;--IF NVL(lr_get_payment_rec.remainingdue, -1) <=0 THEN
               END IF;-- IF lr_get_payment_rec.oracletransactiontype ='P'
               gc_log_msg:='Flag returned by the Duplicate vlidation cursor :'||lc_par_unp_dup_exist_flag;
               xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);
               --------------------------------------------
               -- Check if Invoice number exist in the Table
               ---------------------------------------------
               IF (lc_invoice       <>lr_get_payment_rec.invoicenumber) OR
                  (lc_transaction   <>lr_get_payment_rec.oracletransactiontype) THEN

                   lc_invoice       :=lr_get_payment_rec.invoicenumber;
                   lc_transaction   :=lr_get_payment_rec.oracletransactiontype;
                   lc_invoice_exist_flag:='N';
                   ln_inv_amt :=NULL;
                   --*****************************************************
                   IF lr_get_payment_rec.oracletransactiontype ='P' THEN  -- added by subbu as on Mar03


                   	OPEN  lcu_chk_invoice_exist(lr_get_payment_rec.invoicenumber);
                   	FETCH lcu_chk_invoice_exist INTO lc_invoice_exist_flag,ln_inv_amt;
                   	   IF lcu_chk_invoice_exist%NOTFOUND THEN
                   	       --Log error message
                   	       gc_error_code       :='AR-P01';
                   	       gc_error_msg        :='Invoice number :'||lr_get_payment_rec.invoicenumber||'does not Exist ';
                   	       gc_comments         :=NULL;
                   	       INSERT_ERROR_MSG;
                   	       lc_invoice_exist_flag:='Y';
                   	   ELSE
                   	      --Check if the Invoice amount is 0
                   	      IF lr_get_payment_rec.oracletransactiontype ='P' THEN
                   	         IF ln_inv_amt <=0 THEN
                   	            --Log error message
                   	            gc_error_code       :='AR-P01';
                   	            gc_error_msg        :='Invoice Amount is zero or negative for the Invoicenumber '||lr_get_payment_rec.invoicenumber;
                   	            gc_comments         :=NULL;
                   	            INSERT_ERROR_MSG;
                   	            lc_invoice_exist_flag:='Y';
                   	         ELSE

                   	            gc_log_msg:='Oracle Identifier:'||lr_get_payment_rec.oracleidentifier;
                   	            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                   	            gc_log_msg:='Oracle Original AMT IN IF:'||ln_inv_amt;
                   	            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                   	            ln_inv_amt:=ln_inv_amt-ABS(lr_get_payment_rec.originalamount);



                   	            gc_log_msg:='AMT after calcu In IF :'||ln_inv_amt;
                   	            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                   	         END IF;
                   	      END IF; --IF lr_get_payment_rec.oracletransactiontype ='P' THEN
                   	   END IF; --IF lcu_chk_invoice_exist%NOTFOUND THEN
                   	CLOSE lcu_chk_invoice_exist;
                  END IF;  -- added by subbu as on Mar03
                  --*****************************************************
               ELSE  --IF (lc_invoice       <>lr_get_invoice_rec.invoicenumber) OR
                  IF lr_get_payment_rec.oracletransactiontype ='P' THEN

                  	gc_log_msg:='Oracle Identifier:'||lr_get_payment_rec.oracleidentifier;
                  	xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

                  	gc_log_msg:='Oracle Original AMT OUT IF:'||ln_inv_amt;
                  	xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



/* -- pr 03-oct-2007

                     IF ln_inv_amt <=0 THEN
                         --Log error message
                        gc_error_code       :='AR-P01';
                        gc_error_msg        :='Partial Payment cannot be done as the Invoice Amount is zero or negative for the Invoicenumber '||lr_get_payment_rec.invoicenumber;
                        gc_comments         :=NULL;
                        INSERT_ERROR_MSG;
                        lc_invoice_exist_flag:='Y';
                     ELSE
                        ln_inv_amt:=ln_inv_amt-ABS(lr_get_payment_rec.originalamount);

                        gc_log_msg:='AMT after calcu OUT IF :'||ln_inv_amt;
                        xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);




                     END IF;
*/ -- pr 03-oct-2007

                  END IF;--IF lr_get_payment_rec.oracletransactiontype ='P'
               END IF;-- IF (lc_invoice       <>lr_get_invoice_rec.invoicenumber) OR

           ELSE
              --**************
              --Log error message
               --Start of changes V1.5
              IF lr_get_payment_rec.oracletransactiontype ='P' THEN
              		gc_error_code       :='AR01-2';
              		gc_error_msg        :='Field Invoicenumber cannot be NULL in the staging table';
              		gc_comments         :='Please provide the Invoice Number';
              		INSERT_ERROR_MSG;
              		lc_invoice_exist_flag:='Y';
              END IF; --
              NULL;
              --**************
               --Start of changes V1.5
           END IF; --if Invoice is not null
           gc_log_msg:='Flag returned by the Invoice vlidation cursor :'||lc_invoice_exist_flag;
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

           -------------------------
           --Validate Currency code
           -------------------------
           IF lr_get_payment_rec.oraclecurrencycode IS NOT NULL THEN
              lc_currency_err_flag:='N';
              OPEN  lcu_chk_currency(lr_get_payment_rec.oraclecurrencycode);
              FETCH lcu_chk_currency INTO lc_currency_err_flag;
                 IF lcu_chk_currency%NOTFOUND THEN
                    --Log error message
                     gc_error_code       :='AR-P02';
                     gc_error_msg        :='Currency code: '||lr_get_payment_rec.oraclecurrencycode||' does not exist or Invalid';
                     gc_comments         :='Please define this currency code';
                     INSERT_ERROR_MSG;
                     lc_currency_err_flag:='Y';
                 ELSE
                   IF gc_currency_code <> lr_get_payment_rec.oraclecurrencycode THEN
                      IF lr_get_payment_rec.currencyconversionrate  IS NULL THEN
                          --Log error message
                          gc_error_code       :='AR-P03';
                          gc_error_msg        :='Field currencyconversionrate cannot be NULL';
                          gc_comments         :='Please provide value for currencyconversionrate ';
                          INSERT_ERROR_MSG;
                          lc_currency_err_flag:='Y';
                      END IF;
                   END IF; --IF gc_currency_code <> lr_get_payment_
                 END IF; -- IF lcu_chk_currency%NOTFOUND THEN
              CLOSE lcu_chk_currency;
           ELSE
              --Log error message
              gc_error_code       :='AR-P04';
              gc_error_msg        :='Field currencycode cannot be NULL';
              gc_comments         :='Please provide a Currrency code';
              INSERT_ERROR_MSG;
              lc_currency_err_flag:='Y';
           END IF;
           gc_log_msg:='Flag returned by the Currency code validation cursor: '||lc_currency_err_flag;
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);

           --------------------------------------------
           -- Derive Customer based on BILL_TO Location
           --------------------------------------------
           lc_bill_err_flag        :='N';
           lc_account_number       :=NULL;
           IF (lr_get_payment_rec.customernumber is NOT  NULL) THEN
               OPEN  lcu_get_billto_info(lr_get_payment_rec.customernumber);
               FETCH lcu_get_billto_info INTO lc_account_number;
                  IF lcu_get_billto_info%NOTFOUND THEN
                     --Log error message
                      gc_error_code       :='AR-P05';
                      gc_error_msg        :='No Customer Number exist for the Bill to (customernumber): '||lr_get_payment_rec.customernumber;
                      gc_comments         :='Please provide a valid value for customernumber';
                      INSERT_ERROR_MSG;
                      lc_bill_err_flag:='Y';
                  END IF;
               CLOSE lcu_get_billto_info;
           ELSE --IF (lr_get_payment_rec.customernumber is NOT  NULL)
                --Log error message
                 gc_error_code       :='AR-P06';
                 gc_error_msg        :='Filed customernumber is NULL';
                 gc_comments         :='Please provide a valid value for customernumber field';
                 INSERT_ERROR_MSG;
                 lc_bill_err_flag:='Y';
           END IF;--IF (lr_get_payment_rec.customernumber is NOT  NULL)
           gc_log_msg:='Flag returned by the Bill to Cursor :'||lc_bill_err_flag;
           xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);


           ---------------------------------------------------
           -- Check if the Receipt for the
           -- combinetion of recpt no,recpt date,customer and amount
           -- already exist in the system
           ---------------------------------------------------
           IF lr_get_payment_rec.oracletransactiontype IN ( 'P','U') THEN

              IF lr_get_payment_rec.oracletransactiontype ='P' THEN
                              --Start of changes V1.6
                 ln_amount := ABS(lr_get_payment_rec.originalamount);
                               --End of changes V1.6  --used ABS function
              ELSIF lr_get_payment_rec.oracletransactiontype ='U' THEN
                 ln_amount := ABS(lr_get_payment_rec.remainingdue);
              END IF;

              lc_receipt_exist_flag:='N';
              --Start of changes V1.6
              OPEN  lcu_chk_receipt_exist(lr_get_payment_rec.oracleidentifier,SYSDATE,ln_amount,lc_account_number);
                                                             --End of changes V1.6 Replaced invoicenumber to oracleidentifier
              FETCH lcu_chk_receipt_exist INTO lc_receipt_exist_flag ;
                 IF lcu_chk_receipt_exist%FOUND THEN
                    --Log error message
                     gc_error_code       :='AR-P07';
                     gc_error_msg        :='A cash receipt with this Receipt number, date, amount and customer already exists';
                     gc_comments         :=' Please use a Different Cash receipt';
                     INSERT_ERROR_MSG;
                     lc_receipt_exist_flag:='Y';
                 END IF;
              CLOSE lcu_chk_receipt_exist;
              gc_log_msg:='Flag returned by Cash receipt exist cursor:'||lc_receipt_exist_flag;
              xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_msg);



           END IF;

           -- If  there exist any errors in the above validations then update the status of the records
           IF (lc_bill_err_flag       <>'N' OR
               lc_currency_err_flag   <>'N' OR
               lc_receipt_exist_flag  <>'N' OR
               lc_invoice_exist_flag  <>'N' OR
               lc_amount_flag         <>'N' OR
               lc_par_unp_dup_exist_flag <>'N') THEN --

                lc_mast_err_flag    :='Y';

              --If any errors in the above validation then update the status of the record to VE
              UPDATE usbpcs_ar_cleaned
              SET    CharUserFld4  ='VE'
                    ,DecUserFld1    =gc_request_id
              WHERE  oracleidentifier=lr_get_payment_rec.oracleidentifier;

           ELSE
             --If NO errors in the above validation then update the status of the record to VS
             UPDATE usbpcs_ar_cleaned
             SET    CharUserFld4='VS'
                    ,oraclecharfld4  =lc_account_number
             WHERE  oracleidentifier=lr_get_payment_rec.oracleidentifier;

           END IF;

         END LOOP; --End of main loop
         COMMIT;

         --Get the toal no of records
          OPEN  lcu_get_rec_count;
         FETCH lcu_get_rec_count INTO ln_rec_fetched;
         CLOSE lcu_get_rec_count;

         --Get total no of records Validated
         OPEN lcu_get_rec_val_count;
         FETCH lcu_get_rec_val_count INTO ln_rec_validated;
         CLOSE lcu_get_rec_val_count;

         --Get total no of records Errored
         OPEN lcu_get_rec_err_count;
         FETCH lcu_get_rec_err_count INTO ln_rec_errored;
         CLOSE lcu_get_rec_err_count;



          --Summary information of Payment records Validated
          --===============================================
          fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
          fnd_file.put_line(fnd_file.log,'Summary information of Records Validated ');
          fnd_file.put_line(fnd_file.log,RPAD('*',80,'*'));
          fnd_file.put_line(fnd_file.log,'Total Records Fetched               :    ' ||ln_rec_fetched);
          fnd_file.put_line(fnd_file.log,'Total Records Validated             :    ' ||ln_rec_validated);
          fnd_file.put_line(fnd_file.log,'Total Records Errored               :    ' ||ln_rec_errored);

   ELSE
      lc_mast_err_flag:='Y';
   END IF;

   IF (lc_mast_err_flag='Y') THEN      --If any kind of errors (setup or validation)
      xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);

      IF (lc_gl_date_flag <>'Y') THEN   --If setup`s are missing then error out the program
         x_retcode:=2;
         RETURN;
      ELSE                           --If validation error then set the status of the prog to warning

         x_retcode:=1;
         RETURN;
      END IF ;
   ELSE --If no errors the call the process procedure

       PROCESS_PAYMENT_DATA (
                             x_errbuf   =>x_errbuf
                            ,x_retcode  =>x_retcode
                            );
       IF x_retcode =1 THEN
       xxha_common_utilities_pkg.launch_error_report_prc(gc_request_id,gc_program_name,gc_record_identify);
       END IF;


   END IF;--(lc_mast_err_flag='Y') THEN
EXCEPTION
WHEN OTHERS THEN
   FND_FILE.PUT_LINE(FND_FILE.LOG,'Error in XXHA_AR_INV_PYMT_CONV_PK.VALIDATE_PAYMENT_DATA. Error is: ' ||SQLERRM);
   x_errbuf:=SQLERRM;
   x_retcode:=2;
   ROLLBACK;
END VALIDATE_PAYMENT_DATA;
END XXHA_AR_INV_PYMT_CONV_PK;
/
