create or replace PACKAGE XXHA_IP_BOM_EXTRACT_PKG AUTHID CURRENT_USER AS 

/************************************************************************************************************************
* Package Name : XXHA_IP_BOM_EXTRACT_PKG                                                                                *
* Purpose      : This package provides a function to process the BOM data.                                              *
*                                                                                                                       *
* Procedures   : XXHA_IP_BOM_EXPLODER                                                                                   *
*                XXHA_IP_BOM_EXPLODER_COMPONENTS                                                                        *
*                                                                                                                       *
* Tables Accessed                     Access Type(I - Insert, S - Select, U - Update, D - Delete)                       *
*                                                                                                                       *
* Change History                                                                                                        *
*                                                                                                                       *
* Ver        Date            Author               Description                                                           *
* ------     -----------     -----------------    ---------------                                                       *
* 1.0        22-SEP-2017     BMarcoux             Initial Package creation.                                             *
*                                                                                                                       *
************************************************************************************************************************/

   PROCEDURE XXHA_PROCESS_DATA(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2);

   PROCEDURE XXHA_IP_BOM_EXPLODER(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2);

   PROCEDURE XXHA_IP_BOM_EXPLODER_COMPONENT(
             errbuf            OUT VARCHAR2
            ,errcode           OUT VARCHAR2);

END XXHA_IP_BOM_EXTRACT_PKG;