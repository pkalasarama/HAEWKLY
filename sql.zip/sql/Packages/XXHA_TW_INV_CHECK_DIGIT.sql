CREATE OR REPLACE PACKAGE XXHA_TW_INV_CHECK_DIGIT AS

/*********************************************************************************************
* Package Name : XXHA_TW_INV_CHECK_DIGIT                                                     *
* Purpose      : This package provides functions to create the Taiwan Check Digit.           *
*                  This package will be used by the XML Report 'XXHA: AR Invoice Report TW'. *
*                  (Executable 'XXHA_RAXINV').  It is called from within the FUNCTION        *
*                  'CF_TW_INV_CHECK_DIGITFormula'.                                           *
*                                                                                            *
* Functions    : CHKDIGIT                                                                    *
*              : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        14-APR-2011     B. Marcoux           Incident# 56638                            *
*                                                 New Processing to create Check Digit from  *
*                                                   Invoice Number.                          *
*********************************************************************************************/

  FUNCTION PROCESS_DATA (P_AR_INVOICE_NUMBER   VARCHAR2) RETURN VARCHAR2;

END XXHA_TW_INV_CHECK_DIGIT;
/


CREATE OR REPLACE PACKAGE BODY XXHA_TW_INV_CHECK_DIGIT AS

/*********************************************************************************************
* Package Name : XXHA_TW_INV_CHECK_DIGIT                                                     *
* Purpose      : This package provides functions to create the Taiwan Check Digit.           *
*                  This package will be used by the XML Report 'XXHA: AR Invoice Report TW'. *
*                  (Executable 'XXHA_RAXINV').  It is called from within the FUNCTION        *
*                  'CF_TW_INV_CHECK_DIGITFormula'.                                           *
*                                                                                            *
* Functions    : CHKDIGIT                                                                    *
*              : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ---------------                            *
* 1.0        14-APR-2011     B. Marcoux           Incident# 56638                            *
*                                                 New Processing to create Check Digit from  *
*                                                   Invoice Number.                          *
*********************************************************************************************/

  FUNCTION CHKDIGIT(P_STRING VARCHAR2) RETURN NUMBER IS
    TYPE CHECKTABLE_TYPE IS TABLE OF NUMBER INDEX BY VARCHAR2(1);
    v_checktable CHECKTABLE_TYPE;
    v_counter    INTEGER := 0;
    v_number     INTEGER := 0;
    v_index      INTEGER := 0;
    v_value      INTEGER := 0;

  BEGIN
    v_checktable(0) := 0; v_checktable(1) := 1; v_checktable(2) := 2; v_checktable(3) := 3; v_checktable(4) := 4;
    v_checktable(5) := 5; v_checktable(6) := 6; v_checktable(7) := 7; v_checktable(8) := 8;

-- Start at position 1 and process each position (using v_counter)
    FOR v_counter IN 1..LENGTH(P_STRING) LOOP
        v_number  := SUBSTR(P_STRING,v_counter,1);
        v_index   := v_counter;
        v_value   := (v_checktable(v_index) * v_number) + v_value;
    END LOOP;
    RETURN (v_value);
  EXCEPTION
    WHEN OTHERS THEN
      RETURN -1;
  END;

  FUNCTION PROCESS_DATA(P_AR_INVOICE_NUMBER VARCHAR2) RETURN VARCHAR2 IS

    v_check_digit  VARCHAR2(100);

  BEGIN

    v_check_digit := CHKDIGIT(P_AR_INVOICE_NUMBER);
    RETURN v_check_digit;

  END;

END XXHA_TW_INV_CHECK_DIGIT;
/
