create or replace PACKAGE XXHA_DPS_VENDOR_PK AS

/*********************************************************************************************
* Package Name : XXHA_DPS_VENDOR_PK                                                          *
* Purpose      : This package provides functions to retrieve Contact, Title, Phone, Fax      *
*                 and Email Address.                                                         *
*                                                                                            *
* Used By      : View XXHA_DPS_VENDOR_V                                                      *
*                                                                                            *
* PROCEDURE    : PROCESS_DATA                                                                *
*                                                                                            *
* Tables Accessed            Access Type(I - Insert, S - Select, U - Update, D - Delete)     *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        04-MAY-2016     B. Marcoux           Initial Package Creation                   *
*                                                                                            *
*********************************************************************************************/

FUNCTION PROCESS_DATA (
                        p_party_site_id        IN  NUMBER
                      , p_Index                IN  NUMBER    
                      ) RETURN VARCHAR2;

END XXHA_DPS_VENDOR_PK;