CREATE OR REPLACE package      XXHA_CUST_GL_ACCOUNTS_PK
as
-- +=============================================================================+
-- | Name             :  XXHA_CUST_GL_ACCOUNTS_PK
-- | Description      :  This package supports the processing of files containing
-- |                     records representing updates to the GL Accounts assigned
-- |                     at customer site use level.
-- |                     The main program spawns a host concurrent program which
-- |                     uses SQL*Loader to upload the records to a custom
-- |                     staging table.  After loading is completed, it then
-- |                     spawns a pl/sql concurrent program to process the staged
-- |                     data.
-- |                     Processing first validates the records - any errors are
-- |                     logged in the XXHA_COMMON_ERRORS table.  Next, valid
-- |                     records are then scanned to invoke a seeded API for
-- |                     updating the customer site use records.  Finally, an
-- |                     error report is launched if any errors were logged
-- |                     previously.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-02-01  L.Richards     Initial release
-- +=============================================================================+

-------------------------------------------------------------------------
--The Global Variables
-------------------------------------------------------------------------
gc_attribute1            xxha_common_errors.attribute1%type;                                             --Attribute1 insert in common error table
gc_attribute2            xxha_common_errors.attribute2%type;                                             --Attribute2 insert in common error table
gc_attribute3            xxha_common_errors.attribute3%type;                                             --Attribute3 insert in common error table
gc_attribute4            xxha_common_errors.attribute4%type;                                             --Attribute4 insert in common error table
gc_attribute5            xxha_common_errors.attribute5%type;                                             --Attribute5 insert in common error table
gc_conc_name             fnd_concurrent_programs.concurrent_program_name%type :='XXHACUSTGLACCTS';       --Concurrent program name to delete the records from common error table
gc_comments              xxha_common_errors.comments%type;                                               --Comments   insert in common error table
gc_error_code            xxha_common_errors.error_code%type;                                             --Error_code insert in common error table
gc_error_msg             xxha_common_errors.error_msg%type;                                              --Error_msg  insert in common error table
gc_log_message           VARCHAR2(2000);                                                                 --Variable to hold Log Messages
gc_record_identifier     xxha_common_errors.record_identifier%type;                                      --Record identifier of staging table
gc_status                VARCHAR2(2);                                                                    --Variable to get the Status of the Error Table insertion procedure
gc_table_name            xxha_common_errors.table_name%type :='XXHA_CUST_GL_ACCOUNTS_STG';                --Variable to get Staging Table Name
gn_login_id              fnd_logins.login_id%type := FND_GLOBAL.LOGIN_ID;                                --Login name for running conversion program
gn_request_id            fnd_concurrent_requests.request_id%type      := FND_GLOBAL.CONC_REQUEST_ID;     --Variable to buffer request id of Main Conc Program
gn_child_request1_id     fnd_concurrent_requests.request_id%type      := FND_GLOBAL.CONC_REQUEST_ID;     --Variable to buffer request id of Loader Conc Program
gn_child_request2_id     fnd_concurrent_requests.request_id%type      := FND_GLOBAL.CONC_REQUEST_ID;     --Variable to buffer request id of Record Processing Conc Program
gc_file_name             VARCHAR2(100);                                                                  --Variable to hold the file name
gn_record_number         XXHA_CUST_GL_ACCOUNTS_STG.rec_num%type:=NULL;                                   --Record_number of staging table
gn_user_id               fnd_user.user_id%type := FND_GLOBAL.USER_ID;                                    --User name for running Interface program
gn_ou_org_id             hr_operating_units.organization_id%type;                                        --Variable to buffer specified OU Org ID (input parameter)
gc_ou_name               hr_operating_units.name%type;                                                   --Variable to buffer OU Name matched to specified OU Org ID (input parameter)
gc_debug_flag            varchar2(1);

-- Procedure to purge the staging table
-- This procedure is called from the Host concurrent program which runs SQL*Loader
procedure PURGE_STAGING_TABLE;

-- Procedure to update the staging table
-- This procedure is called from the Host concurrent program which runs SQL*Loader
procedure UPDATE_STAGING_TABLE (
         p_file_name  in  varchar2
        ,p_request_id  in  number
        );

-- Procedure to Validate and process Customer Site - GL Accounts assignment records
procedure PROCESS_RECORDS (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
        );

-- Procedure to sumbit the host (Loader) and Process Records concurrent programs.
procedure MAIN (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
        );

END XXHA_CUST_GL_ACCOUNTS_PK;

/


CREATE OR REPLACE package body      XXHA_CUST_GL_ACCOUNTS_PK
as
-- +=============================================================================+
-- | Name             :  XXHA_CUST_GL_ACCOUNTS_PK
-- | Description      :  This package supports the processing of files containing
-- |                     records representing updates to the GL Accounts assigned
-- |                     at customer site use level.
-- |                     The main program spawns a host concurrent program which
-- |                     uses SQL*Loader to upload the records to a custom
-- |                     staging table.  After loading is completed, it then
-- |                     spawns a pl/sql concurrent program to process the staged
-- |                     data.
-- |                     Processing first validates the records - any errors are
-- |                     logged in the XXHA_COMMON_ERRORS table.  Next, valid
-- |                     records are then scanned to invoke a seeded API for
-- |                     updating the customer site use records.  Finally, an
-- |                     error report is launched if any errors were logged
-- |                     previously.
-- |
-- |History:
-- |  Version  When        Who            What
-- |  -------  ----------  -------------  ---------------------------------------
-- |  1.0      2008-01-09  L.Richards     Initial release
-- +=============================================================================+
type gc_newCombinationRec is record (
     concatenated_segments  varchar2(200)
    ,code_combination_id  number
    );
type gc_newCombinationTabType is table of gc_newCombinationRec index by binary_integer;
-- Cursor for staged records
cursor gc_stg (
           q_status  varchar2
          ) is
  select  stg.*
         ,stg.rowid
  from    xxha_cust_gl_accounts_stg  stg
  where   stg.status = q_status;
e_skip  exception;
-- +=========================================================================
-- |  This procedure logs errors into error table
-- +=========================================================================
PROCEDURE log_error_for_report
          is
BEGIN
   xxha_common_utilities_pkg.insert_error_prc(
                                              gn_child_request2_id
                                             ,gn_record_number
                                             ,gc_record_identifier
                                             ,gc_error_code
                                             ,gc_error_msg
                                             ,gc_comments
                                             ,gc_table_name
                                             ,gc_attribute1
                                             ,gc_attribute2
                                             ,gc_attribute3
                                             ,gc_attribute4
                                             ,gc_attribute5
                                             ,gc_status
                                             );
EXCEPTION
  when others then
     fnd_file.put_line(fnd_file.log,'Error in procedure LOG_ERROR_FOR_REPORT : ' ||SQLERRM);
END log_error_for_report;
-- +=========================================================================
-- |  This procedure updates the gl_accounts on customer site use for
-- |  successfully validated records in the staging table
-- +=========================================================================
PROCEDURE update_gl_accounts (
         x_cnt_notupdated  out  number
        ) is
  ln_cnt_read  number := 0;
  ln_cnt_update_ok  number := 0;
  ln_cnt_update_notok  number := 0;
  ln_cnt_nochng  number := 0;
  lc_errcode  varchar2(30);
  lc_errmsg  varchar2(2000);
  lc_update_status  varchar2(2);
  lc_gl_id_set_old  varchar2(200);
  lc_gl_id_set_new  varchar2(200);
  -- declaration for API hz_cust_account_site_v2pub.update_cust_site_use
  lr_cust_site_use_rec  hz_cust_account_site_v2pub.cust_site_use_rec_type;
  -- other variables for API call
  ln_ovn  number;  -- object version number
  ln_count  number;
  lc_data  varchar2(4000);
  lc_api_status  varchar2(20);
  lc_prefix  varchar2(30);
BEGIN
   gc_log_message := 'Performing Assignment Update';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,rpad('-',50,'-'));
   fnd_file.put_line(fnd_file.output,' ');
   for valrec in gc_stg ('VS')
   loop
      ln_cnt_read := ln_cnt_read + 1;
      gc_record_identifier:= valrec.file_name;
      gn_record_number := valrec.rec_num;
      lc_errcode := null;
      lc_errmsg := null;
      lc_update_status := null;
     gc_log_message  :='Updating record '||valrec.rec_num||' ... CustNo='||valrec.customer_number
                                                              ||' SiteNo='||valrec.site_number
                                                                    ||' ('||upper(valrec.site_use)||')';

      xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);
      -- if new set of GL accounts is the same as old set, then no need to update
      -- otherwise, call the API to update the Customer Site Use
      lc_gl_id_set_new :=      valrec.gl_id_rec_new
                        ||'.'||valrec.gl_id_rev_new
                        ||'.'||valrec.gl_id_tax_new
                        ||'.'||valrec.gl_id_freight_new
                        ||'.'||valrec.gl_id_clearing_new
                        ||'.'||valrec.gl_id_unbilled_new
                        ||'.'||valrec.gl_id_unearned_new;
      lc_gl_id_set_old :=      valrec.gl_id_rec_old
                        ||'.'||valrec.gl_id_rev_old
                        ||'.'||valrec.gl_id_tax_old
                        ||'.'||valrec.gl_id_freight_old
                        ||'.'||valrec.gl_id_clearing_old
                        ||'.'||valrec.gl_id_unbilled_old
                        ||'.'||valrec.gl_id_unearned_old;

      if (lc_gl_id_set_new = lc_gl_id_set_old) then
         lc_update_status := 'PS';             -- flag as successful
         ln_cnt_nochng := ln_cnt_nochng + 1;
      else
         --prep for API call
         lr_cust_site_use_rec := null;
         lr_cust_site_use_rec.site_use_id := valrec.site_use_id;
         ln_ovn := valrec.site_use_ovn;
         -- set the GL_ID only if not null and different from original
         if (nvl(valrec.gl_id_rec_new,-98765) <> nvl(valrec.gl_id_rec_old,-98765)) then
            lr_cust_site_use_rec.gl_id_rec := valrec.gl_id_rec_new;
         end if;
         if (nvl(valrec.gl_id_rev_new,-98765) <> nvl(valrec.gl_id_rev_old,-98765)) then
            lr_cust_site_use_rec.gl_id_rev := valrec.gl_id_rev_new;
         end if;
         if (nvl(valrec.gl_id_tax_new,-98765) <> nvl(valrec.gl_id_tax_old,-98765)) then
            lr_cust_site_use_rec.gl_id_tax := valrec.gl_id_tax_new;
         end if;
         if (nvl(valrec.gl_id_freight_new,-98765) <> nvl(valrec.gl_id_freight_old,-98765)) then
            lr_cust_site_use_rec.gl_id_freight := valrec.gl_id_freight_new;
         end if;
         if (nvl(valrec.gl_id_clearing_new,-98765) <> nvl(valrec.gl_id_clearing_old,-98765)) then
            lr_cust_site_use_rec.gl_id_clearing := valrec.gl_id_clearing_new;
         end if;
         if (nvl(valrec.gl_id_unbilled_new,-98765) <> nvl(valrec.gl_id_unbilled_old,-98765)) then
            lr_cust_site_use_rec.gl_id_unbilled := valrec.gl_id_unbilled_new;
         end if;
         if (nvl(valrec.gl_id_unearned_new,-98765) <> nvl(valrec.gl_id_unearned_old,-98765)) then
            lr_cust_site_use_rec.gl_id_unearned := valrec.gl_id_unearned_new;
         end if;
         -- call API to set new value
         hz_cust_account_site_v2pub.update_cust_site_use (
                   p_init_msg_list => FND_API.G_FALSE
                  ,p_cust_site_use_rec => lr_cust_site_use_rec
                  ,p_object_version_number => ln_ovn
                  ,x_return_status => lc_api_status
                  ,x_msg_count => ln_count
                  ,x_msg_data => lc_data
                  );
         if (lc_api_status = FND_API.G_RET_STS_SUCCESS) then
            lc_update_status := 'PS';
            ln_cnt_update_ok := ln_cnt_update_ok + 1;
         else
            -- must be an error ...
            lc_update_status := 'PE';
            ln_cnt_update_notok := ln_cnt_update_notok + 1;

            gc_error_code := 'CSA60';
            if (ln_count >= 1) then
               for i in 1..ln_count
               loop
                  gc_error_msg := substr(fnd_msg_pub.get(p_msg_index => i,p_encoded => FND_API.G_FALSE),1,255);
                  fnd_file.put_line(fnd_file.output,gc_error_msg);
               end loop;
            end if;
            gc_comments := 'Call to API hz_cust_account_site_v2pub.UPDATE_CUST_SITE_USE';
            log_error_for_report;
            gc_log_message := gc_error_code||' - '||gc_error_msg;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);
         end if;
      end if;
      update  xxha_cust_gl_accounts_stg
      set     status = lc_update_status
      where   rowid = valrec.rowid;
      commit;
      if (lc_update_status = 'PS') then
         if (lc_gl_id_set_new = lc_gl_id_set_old) then
            lc_prefix := 'Update skipped   :';
         else
            lc_prefix := 'Update succeeded :';
         end if;
      else  -- must be 'PE'
         lc_prefix := 'Update failed    :';
      end if;
      fnd_file.put_line(fnd_file.output,lc_prefix||' RecNum='||valrec.rec_num
                                                 ||' CustNo='||valrec.customer_number
                                                 ||' SiteNo='||valrec.site_number
                                                       ||' ('||upper(valrec.site_use)||')'
                       );
   end loop;
   -------------------------------------------------------------------------
   -- Summary Of Assignments Update Process
   -------------------------------------------------------------------------
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Assignments Update Summary');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Records Processed      :   ' ||ln_cnt_read);
   fnd_file.put_line(fnd_file.output,'  Records Unchanged    :   ' ||ln_cnt_nochng);
   fnd_file.put_line(fnd_file.output,'  Updates Succeeded    :   ' ||ln_cnt_update_ok);
   fnd_file.put_line(fnd_file.output,'  Updates Failed       :   ' ||ln_cnt_update_notok);
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   x_cnt_notupdated := ln_cnt_update_notok;
END update_gl_accounts;
-- +====================================================================
-- |  This function validates the OU Name and buffers the
-- |  corresponding ORG_ID, SOB_ID, COA_ID
-- +====================================================================
function valid_OU (
         x_newrec  in out  gc_stg%rowtype
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is
  ln_sob_id  number;
  e_ou_null  exception;
  e_ou_mismatch  exception;
BEGIN
   if (x_newrec.ou_name is null) then
      raise e_ou_null;
   end if;
   -- validate OU Name and fetch ID for OU Organization and Set of Books
   select  ou.organization_id
          ,ou.set_of_books_id
   into    x_newrec.ou_org_id
          ,x_newrec.sob_id
   from    hr_operating_units  ou
   where   ou.name = x_newrec.ou_name
   and     sysdate between ou.date_from and nvl(ou.date_to,sysdate);
   -- fetch ID for Chart of Accounts
/* R12 Upgrade Modified on 10/05/2012 by Venkatesh Sarangam , Rolta */
   /*select  sob.chart_of_accounts_id
   into    x_newrec.coa_id
   from    gl_sets_of_books  sob
   where   sob.set_of_books_id = x_newrec.sob_id;*/

   select  sob.chart_of_accounts_id
   INTO    x_newrec.coa_id
   FROM    gl_ledgers  sob
   where   sob.ledger_id = x_newrec.sob_id;
   if (x_newrec.ou_org_id <> fnd_global.org_id) then
      raise e_ou_mismatch;
   end if;
   return(true);
EXCEPTION
   when e_ou_null then
      x_errcode := 'CGL10';
      x_errmsg := 'Missing Operating Unit';
      return(false);
   when e_ou_mismatch then
      x_errcode := 'CGL11';
      x_errmsg := 'Operating Unit does not match to user responsibility';
      return(false);
   when no_data_found then
      x_errcode := 'CGL12';
      x_errmsg := 'Invalid Operating Unit ('||x_newrec.ou_name||')';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'OU Check: '||SQLERRM;
      return(false);
END valid_OU;
-- +====================================================================
-- |  This function validates the Customer Number and buffers the
-- |  corresponding CUST_ACCOUNT_ID
-- +====================================================================
function valid_customer (
         x_newrec  in out  gc_stg%rowtype
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is
  e_null_customer  exception;
BEGIN
   if (x_newrec.customer_number is null) then
      raise e_null_customer;
   end if;

   select  ca.cust_account_id
   into    x_newrec.cust_account_id
   from    hz_cust_accounts  ca
   where   ca.account_number = x_newrec.customer_number;
   return(true);
EXCEPTION
   when e_null_customer then
      x_errcode := 'CGL20';
      x_errmsg := 'Missing Customer Number';
      return(false);
   when no_data_found then
      x_errcode := 'CGL21';
      x_errmsg := 'Invalid Customer Number ('||x_newrec.customer_number||')';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'Customer Check: '||SQLERRM;
      return(false);
END valid_customer;
-- +====================================================================
-- |  This function validates the Site Number is valid and is for the
-- |  and Customer.  It buffers the corresponding CUST_ACCOUNT_SITE_ID.
-- +====================================================================
function valid_site (
         x_newrec  in out  gc_stg%rowtype
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is

  ln_party_site_id  hz_party_sites.party_site_id%type;
  ln_cust_account_id  hz_cust_acct_sites_all.cust_account_id%type;
  e_null_site  exception;
  e_site  exception;
  e_cust  exception;
  e_org  exception;
BEGIN
   if (x_newrec.site_number is null) then
      raise e_null_site;
   end if;
   begin  -- check the site
      select  ps.party_site_id
      into    ln_party_site_id
      from    hz_party_sites  ps
      where   ps.party_site_number = x_newrec.site_number;
   exception
      when no_data_found then
         raise e_site;
   end;
   begin  -- check the customer site
      select  cas.cust_acct_site_id
             ,cas.cust_account_id
      into    x_newrec.cust_acct_site_id
             ,ln_cust_account_id
      from    hz_cust_acct_sites_all  cas
      where   cas.party_site_id = ln_party_site_id
      and     cas.org_id = x_newrec.ou_org_id;

      -- check that site belongs to right customer
      if (ln_cust_account_id <> x_newrec.cust_account_id) then
         x_newrec.cust_acct_site_id := null;
         raise e_cust;
      end if;
   exception
      when no_data_found then
         raise e_org;
   end;
   return(true);
EXCEPTION
   when e_null_site then
      x_errcode := 'CGL30';
      x_errmsg := 'Missing Site Number';
      return(false);
   when e_site then
      x_errcode := 'CGL31';
      x_errmsg := 'Invalid Site Number ('||x_newrec.site_number||')';
      return(false);
   when e_cust then
      x_errcode := 'CGL32';
      x_errmsg := 'Site '||x_newrec.site_number||' belongs to a different customer';
      return(false);
   when e_org then
      x_errcode := 'CGL33';
      x_errmsg := 'Site '||x_newrec.site_number||' not found for the OU';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'Site Check: '||SQLERRM;
      return(false);
END valid_site;
-- +====================================================================
-- |  This function validates that the Site Use for the Site and OU.
-- |  It buffers the corresponding SITE_USE_ID, Object Version and
-- |  current GL Code Combination IDs.
-- +====================================================================
function valid_siteuse (
         x_newrec  in out  gc_stg%rowtype
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is
  lc_status  hz_cust_site_uses_all.status%type;
  e_null_siteuse  exception;
  e_status  exception;
  e_siteuse  exception;
BEGIN
   if (x_newrec.site_use is null) then
      raise e_null_siteuse;
   end if;
   begin
      select  csu.site_use_id
             ,csu.object_version_number
             ,csu.gl_id_rec
             ,csu.gl_id_rev
             ,csu.gl_id_tax
             ,csu.gl_id_freight
             ,csu.gl_id_clearing
             ,csu.gl_id_unbilled
             ,csu.gl_id_unearned
             ,csu.status
      into    x_newrec.site_use_id
             ,x_newrec.site_use_ovn
             ,x_newrec.gl_id_rec_old
             ,x_newrec.gl_id_rev_old
             ,x_newrec.gl_id_tax_old
             ,x_newrec.gl_id_freight_old
             ,x_newrec.gl_id_clearing_old
             ,x_newrec.gl_id_unbilled_old
             ,x_newrec.gl_id_unearned_old
             ,lc_status
      from    hz_cust_site_uses_all  csu
      where   csu.cust_acct_site_id = x_newrec.cust_acct_site_id
      and     csu.site_use_code = upper(x_newrec.site_use)
      and     csu.org_id = x_newrec.ou_org_id;

      if (lc_status <> 'A') then
         raise e_status;
      end if;
   exception
      when no_data_found then
         raise e_siteuse;
   end;
   return(true);
EXCEPTION
   when e_null_siteuse then
      x_errcode := 'CGL40';
      x_errmsg := 'Missing Site Use';
      return(false);
   when e_status then
      x_errcode := 'CGL41';
      x_errmsg := upper(x_newrec.site_use)||' usage is not Active';
      return(false);
   when e_siteuse then
      x_errcode := 'CGL42';
      x_errmsg := upper(x_newrec.site_use)||' usage not defined for Site';
      return(false);
   when others then
      x_errcode := SQLCODE;
      x_errmsg := 'Site Use Check: '||SQLERRM;
      return(false);
END valid_siteuse;
-- +====================================================================
-- |  This procedure adds an item to a list
-- +====================================================================
procedure add_to_list (
         p_item  in varchar2
        ,x_list  in out  varchar2
        ) is
begin
  if (p_item is not null) then
     if (x_list is not null) then
        x_list := x_list||', ';
     end if;
     x_list := x_list||p_item;
  end if;
end add_to_list;
-- +====================================================================
-- |  This procedure buffers a code combination id into the appropriate
-- |  place holder variable depending on the code combination number
-- |  (p_cc_no) passed in.  Each CC No maps to a specific GL Account.
-- +====================================================================
procedure buffer_ccid (
         x_newrec  in out  gc_stg%rowtype
        ,p_cc_no  in  number
        ,p_ccid  in  number
        ) is
  lc_concat  varchar2(250);
begin
  if (p_cc_no = 1) then
     x_newrec.gl_id_rec_new := p_ccid;
  elsif (p_cc_no = 2) then
     x_newrec.gl_id_rev_new := p_ccid;
  elsif (p_cc_no = 3) then
     x_newrec.gl_id_tax_new := p_ccid;
  elsif (p_cc_no = 4) then
     x_newrec.gl_id_freight_new := p_ccid;
  elsif (p_cc_no = 5) then
     x_newrec.gl_id_clearing_new := p_ccid;
  elsif (p_cc_no = 6) then
     x_newrec.gl_id_unbilled_new := p_ccid;
  elsif (p_cc_no = 7) then
     x_newrec.gl_id_unearned_new := p_ccid;
  end if;
end buffer_ccid;
-- +====================================================================
-- |  This procedure trims account segments in case whitespace was
-- |  inadvertently added during worksheet manipulation
-- +====================================================================
procedure trim_segments (
         x_newrec  in out  gc_stg%rowtype
        ) is
begin
  x_newrec.gl_rec_segment1 := trim(x_newrec.gl_rec_segment1);
  x_newrec.gl_rec_segment2 := trim(x_newrec.gl_rec_segment2);
  x_newrec.gl_rec_segment3 := trim(x_newrec.gl_rec_segment3);
  x_newrec.gl_rec_segment4 := trim(x_newrec.gl_rec_segment4);
  x_newrec.gl_rec_segment5 := trim(x_newrec.gl_rec_segment5);
  x_newrec.gl_rec_segment6 := trim(x_newrec.gl_rec_segment6);
  x_newrec.gl_rec_segment7 := trim(x_newrec.gl_rec_segment7);
  x_newrec.gl_rec_segment8 := trim(x_newrec.gl_rec_segment8);
  x_newrec.gl_rec_segment9 := trim(x_newrec.gl_rec_segment9);
  x_newrec.gl_rev_segment1 := trim(x_newrec.gl_rev_segment1);
  x_newrec.gl_rev_segment2 := trim(x_newrec.gl_rev_segment2);
  x_newrec.gl_rev_segment3 := trim(x_newrec.gl_rev_segment3);
  x_newrec.gl_rev_segment4 := trim(x_newrec.gl_rev_segment4);
  x_newrec.gl_rev_segment5 := trim(x_newrec.gl_rev_segment5);
  x_newrec.gl_rev_segment6 := trim(x_newrec.gl_rev_segment6);
  x_newrec.gl_rev_segment7 := trim(x_newrec.gl_rev_segment7);
  x_newrec.gl_rev_segment8 := trim(x_newrec.gl_rev_segment8);
  x_newrec.gl_rev_segment9 := trim(x_newrec.gl_rev_segment9);
  x_newrec.gl_tax_segment1 := trim(x_newrec.gl_tax_segment1);
  x_newrec.gl_tax_segment2 := trim(x_newrec.gl_tax_segment2);
  x_newrec.gl_tax_segment3 := trim(x_newrec.gl_tax_segment3);
  x_newrec.gl_tax_segment4 := trim(x_newrec.gl_tax_segment4);
  x_newrec.gl_tax_segment5 := trim(x_newrec.gl_tax_segment5);
  x_newrec.gl_tax_segment6 := trim(x_newrec.gl_tax_segment6);
  x_newrec.gl_tax_segment7 := trim(x_newrec.gl_tax_segment7);
  x_newrec.gl_tax_segment8 := trim(x_newrec.gl_tax_segment8);
  x_newrec.gl_tax_segment9 := trim(x_newrec.gl_tax_segment9);
  x_newrec.gl_freight_segment1 := trim(x_newrec.gl_freight_segment1);
  x_newrec.gl_freight_segment2 := trim(x_newrec.gl_freight_segment2);
  x_newrec.gl_freight_segment3 := trim(x_newrec.gl_freight_segment3);
  x_newrec.gl_freight_segment4 := trim(x_newrec.gl_freight_segment4);
  x_newrec.gl_freight_segment5 := trim(x_newrec.gl_freight_segment5);
  x_newrec.gl_freight_segment6 := trim(x_newrec.gl_freight_segment6);
  x_newrec.gl_freight_segment7 := trim(x_newrec.gl_freight_segment7);
  x_newrec.gl_freight_segment8 := trim(x_newrec.gl_freight_segment8);
  x_newrec.gl_freight_segment9 := trim(x_newrec.gl_freight_segment9);
  x_newrec.gl_clearing_segment1 := trim(x_newrec.gl_clearing_segment1);
  x_newrec.gl_clearing_segment2 := trim(x_newrec.gl_clearing_segment2);
  x_newrec.gl_clearing_segment3 := trim(x_newrec.gl_clearing_segment3);
  x_newrec.gl_clearing_segment4 := trim(x_newrec.gl_clearing_segment4);
  x_newrec.gl_clearing_segment5 := trim(x_newrec.gl_clearing_segment5);
  x_newrec.gl_clearing_segment6 := trim(x_newrec.gl_clearing_segment6);
  x_newrec.gl_clearing_segment7 := trim(x_newrec.gl_clearing_segment7);
  x_newrec.gl_clearing_segment8 := trim(x_newrec.gl_clearing_segment8);
  x_newrec.gl_clearing_segment9 := trim(x_newrec.gl_clearing_segment9);
  x_newrec.gl_unbilled_segment1 := trim(x_newrec.gl_unbilled_segment1);
  x_newrec.gl_unbilled_segment2 := trim(x_newrec.gl_unbilled_segment2);
  x_newrec.gl_unbilled_segment3 := trim(x_newrec.gl_unbilled_segment3);
  x_newrec.gl_unbilled_segment4 := trim(x_newrec.gl_unbilled_segment4);
  x_newrec.gl_unbilled_segment5 := trim(x_newrec.gl_unbilled_segment5);
  x_newrec.gl_unbilled_segment6 := trim(x_newrec.gl_unbilled_segment6);
  x_newrec.gl_unbilled_segment7 := trim(x_newrec.gl_unbilled_segment7);
  x_newrec.gl_unbilled_segment8 := trim(x_newrec.gl_unbilled_segment8);
  x_newrec.gl_unbilled_segment9 := trim(x_newrec.gl_unbilled_segment9);
  x_newrec.gl_unearned_segment1 := trim(x_newrec.gl_unearned_segment1);
  x_newrec.gl_unearned_segment2 := trim(x_newrec.gl_unearned_segment2);
  x_newrec.gl_unearned_segment3 := trim(x_newrec.gl_unearned_segment3);
  x_newrec.gl_unearned_segment4 := trim(x_newrec.gl_unearned_segment4);
  x_newrec.gl_unearned_segment5 := trim(x_newrec.gl_unearned_segment5);
  x_newrec.gl_unearned_segment6 := trim(x_newrec.gl_unearned_segment6);
  x_newrec.gl_unearned_segment7 := trim(x_newrec.gl_unearned_segment7);
  x_newrec.gl_unearned_segment8 := trim(x_newrec.gl_unearned_segment8);
  x_newrec.gl_unearned_segment9 := trim(x_newrec.gl_unearned_segment9);
end trim_segments;
-- +====================================================================
-- |  This procedure concatenates segment values for a particular
-- |  Gl Account identified by the code combination number (p_cc_no)
-- |  parameter.  Each CC No maps to a specific GL Account.
-- |    1 - Receivable
-- |    2 - Revenue
-- |    3 - Tax
-- |    4 - Freight
-- |    5 - Clearing
-- |    6 - Unbilled Receivable
-- |    7 - Unearned Revenue
-- |  The procedure returns the GL Account 'name' and concatenated
-- |  segment string.
-- +====================================================================
procedure concatenate_segments (
         p_newrec  in  gc_stg%rowtype
        ,p_cc_no  in  number
        ,x_cc_name  out  varchar2
        ,x_concat_segments  out  varchar2
        ) is
  lc_concat  varchar2(250);
begin
  if (p_cc_no = 1) then
     x_cc_name := 'Receivable';
     lc_concat :=       p_newrec.gl_rec_segment1||'.'||p_newrec.gl_rec_segment2||'.'||p_newrec.gl_rec_segment3
                 ||'.'||p_newrec.gl_rec_segment4||'.'||p_newrec.gl_rec_segment5||'.'||p_newrec.gl_rec_segment6
                 ||'.'||p_newrec.gl_rec_segment7||'.'||p_newrec.gl_rec_segment8||'.'||p_newrec.gl_rec_segment9;
  elsif (p_cc_no = 2) then
     x_cc_name := 'Revenue';
     lc_concat :=       p_newrec.gl_rev_segment1||'.'||p_newrec.gl_rev_segment2||'.'||p_newrec.gl_rev_segment3
                 ||'.'||p_newrec.gl_rev_segment4||'.'||p_newrec.gl_rev_segment5||'.'||p_newrec.gl_rev_segment6
                 ||'.'||p_newrec.gl_rev_segment7||'.'||p_newrec.gl_rev_segment8||'.'||p_newrec.gl_rev_segment9;
  elsif (p_cc_no = 3) then
     x_cc_name := 'Tax';
     lc_concat :=       p_newrec.gl_tax_segment1||'.'||p_newrec.gl_tax_segment2||'.'||p_newrec.gl_tax_segment3
                 ||'.'||p_newrec.gl_tax_segment4||'.'||p_newrec.gl_tax_segment5||'.'||p_newrec.gl_tax_segment6
                 ||'.'||p_newrec.gl_tax_segment7||'.'||p_newrec.gl_tax_segment8||'.'||p_newrec.gl_tax_segment9;
  elsif (p_cc_no = 4) then
     x_cc_name := 'Freight';
     lc_concat :=       p_newrec.gl_freight_segment1||'.'||p_newrec.gl_freight_segment2||'.'||p_newrec.gl_freight_segment3
                 ||'.'||p_newrec.gl_freight_segment4||'.'||p_newrec.gl_freight_segment5||'.'||p_newrec.gl_freight_segment6
                 ||'.'||p_newrec.gl_freight_segment7||'.'||p_newrec.gl_freight_segment8||'.'||p_newrec.gl_freight_segment9;
  elsif (p_cc_no = 5) then
     x_cc_name := 'Clearing';
     lc_concat :=       p_newrec.gl_clearing_segment1||'.'||p_newrec.gl_clearing_segment2||'.'||p_newrec.gl_clearing_segment3
                 ||'.'||p_newrec.gl_clearing_segment4||'.'||p_newrec.gl_clearing_segment5||'.'||p_newrec.gl_clearing_segment6
                 ||'.'||p_newrec.gl_clearing_segment7||'.'||p_newrec.gl_clearing_segment8||'.'||p_newrec.gl_clearing_segment9;
  elsif (p_cc_no = 6) then
     x_cc_name := 'Unbilled Receivable';
     lc_concat :=       p_newrec.gl_unbilled_segment1||'.'||p_newrec.gl_unbilled_segment2||'.'||p_newrec.gl_unbilled_segment3
                 ||'.'||p_newrec.gl_unbilled_segment4||'.'||p_newrec.gl_unbilled_segment5||'.'||p_newrec.gl_unbilled_segment6
                 ||'.'||p_newrec.gl_unbilled_segment7||'.'||p_newrec.gl_unbilled_segment8||'.'||p_newrec.gl_unbilled_segment9;
  elsif (p_cc_no = 7) then
     x_cc_name := 'Unearned Revenue';
     lc_concat :=       p_newrec.gl_unearned_segment1||'.'||p_newrec.gl_unearned_segment2||'.'||p_newrec.gl_unearned_segment3
                 ||'.'||p_newrec.gl_unearned_segment4||'.'||p_newrec.gl_unearned_segment5||'.'||p_newrec.gl_unearned_segment6
                 ||'.'||p_newrec.gl_unearned_segment7||'.'||p_newrec.gl_unearned_segment8||'.'||p_newrec.gl_unearned_segment9;
  end if;
  if (lc_concat = '........') then
     lc_concat := null;
  end if;
  x_concat_segments := lc_concat;
end concatenate_segments;
-- +====================================================================
-- |  This function validates GL Account segment combinations.  If the
-- |  combination is new, it will be created.  It buffers the GL Code
-- |  Combination IDs for the new combinations to be assigned.
-- +====================================================================
function valid_combinations (
         x_newrec  in out  gc_stg%rowtype
        ,x_newCombinationTab  in out  gc_newCombinationTabType
        ,x_valid_cc_cnt  out  number
        ,x_errcode  out  varchar2
        ,x_errmsg  out  varchar2
        ) return boolean is
  c_cc_count  number := 7;
  ln_max_ccid  number;
  lc_cc_name  varchar2(30);
  lc_concat_segments  varchar2(250);
  ln_ccid  number;
  lc_invalid_list  varchar2(200);
  ln_valid_cc_cnt  number := 0;
  ln_newIndex  binary_integer;
  lb_status  boolean;
BEGIN
   ln_newIndex := x_newCombinationTab.count;
   select  max(code_combination_id)
   into    ln_max_ccid
   from    gl_code_combinations
   where   chart_of_accounts_id = x_newrec.coa_id;
   trim_segments(x_newrec);
   for i in 1..c_cc_count
   loop
      begin
         concatenate_segments(x_newrec,i,lc_cc_name,lc_concat_segments);
         if (lc_concat_segments is null) then
            raise e_skip;
         end if;
         ln_ccid := fnd_flex_ext.get_ccid(
                                    'SQLGL'
                                   ,'GL#'
                                   ,x_newrec.coa_id
                                   ,to_char(sysdate,'YYYY/MM/DD hh24:mi:ss')
                                   ,lc_concat_segments
                                   );
         -- is combination invalid?
         if (ln_ccid = 0) then
            add_to_list(lc_cc_name,lc_invalid_list);
         else  -- must be valid
            ln_valid_cc_cnt := ln_valid_cc_cnt + 1;
            buffer_ccid(x_newrec,i,ln_ccid);
            -- is it a new combination
            if (ln_ccid > ln_max_ccid) then
               -- buffer for reporting later
               ln_newIndex := ln_newIndex + 1;
               x_newCombinationTab(ln_newIndex).concatenated_segments := lc_concat_segments;
               x_newCombinationTab(ln_newIndex).code_combination_id := ln_ccid;
               -- buffer new CC_ID as max CC_ID
               ln_max_ccid := ln_ccid;
            end if;
         end if;
      exception
         when e_skip then
            null;
      end;
   end loop;
   if (lc_invalid_list is not null) then
      x_errcode := 'CGL50';
      x_errmsg := 'Invalid combination(s) for '||lc_invalid_list;
      lb_status := FALSE;
   else
      lb_status := TRUE;
   end if;
   x_valid_cc_cnt := ln_valid_cc_cnt;
   return(lb_status);
END valid_combinations;
-- +=========================================================================
-- |  This procedures validates newly staged records.
-- +=========================================================================
PROCEDURE validate_records (
         x_cnt_invalid  out  number
        ) is
  ln_cnt_read  number := 0;
  ln_cnt_valid  number := 0;
  ln_cnt_invalid  number := 0;  -- number of record found to be invalid
  ln_valid_cc_cnt  number;  -- number of valid code combinations on a record
  lc_errcode  varchar2(30);
  lc_errmsg  varchar2(2000);
  lc_validation_status  varchar2(2);
  newCombinationTab  gc_newCombinationTabType;
  lc_invalid_list varchar2(200);
  e_error  exception;
  -- Cursor for new records
  cursor c_new
            is
    select  stg.*
           ,stg.rowid
    from    xxha_cust_gl_accounts_stg  stg
    where   stg.status = 'NEW';
BEGIN
   gc_log_message := 'Performing Record Validation';
   xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);
   for newrec in gc_stg ('NEW')
   loop
      ln_cnt_read := ln_cnt_read + 1;
      gc_record_identifier := newrec.file_name;
      gn_record_number := newrec.rec_num;
      lc_errcode := null;
      lc_errmsg := null;
      lc_validation_status := null;
      begin
         if (not valid_ou(newrec, lc_errcode, lc_errmsg) )  then
            raise e_error;
         end if;
         if (not valid_customer(newrec, lc_errcode, lc_errmsg) )  then
            raise e_error;
         end if;
         if (not valid_site(newrec, lc_errcode, lc_errmsg) ) then
            raise e_error;
         end if;
         if (not valid_siteuse(newrec, lc_errcode, lc_errmsg) ) then
            raise e_error;
         end if;
         if (not valid_combinations(newrec, newCombinationTab, ln_valid_cc_cnt, lc_errcode, lc_errmsg) ) then
            raise e_error;
         end if;
         -- at this point, all validations have been successful
         lc_validation_status := 'VS';
         ln_cnt_valid := ln_cnt_valid + 1;
      exception
         when e_error then
            lc_validation_status := 'VE';
            ln_cnt_invalid := ln_cnt_invalid + 1;
            gc_error_code := lc_errcode;
            gc_error_msg := lc_errmsg;
            gc_comments := null;
            -- Also invalid code combination was found but at least one valid combo was found,
            -- override and flag as 'Validated Successfully' so that customer profile can
            -- be updated for the valid GL account.
            -- Also set comment for error message
            if (gc_error_code = 'CGL50') then
               lc_validation_status := 'VS';
               gc_comments := 'Code Combination(s) must be valid, enabled and active';
            end if;
            log_error_for_report;

            gc_log_message := gc_error_code||' - '||gc_error_msg;
            xxha_common_utilities_pkg.print_msg_prc(gc_debug_flag,gc_log_message);

            fnd_file.put_line(fnd_file.output,'Invalid record   : RecNum='||newrec.rec_num
                                                              ||' CustNo='||newrec.customer_number
                                                              ||' SiteNo='||newrec.site_number
                                                                    ||' ('||upper(newrec.site_use)||')'
                             );
      end;
      update  xxha_cust_gl_accounts_stg
      set     status = lc_validation_status
             ,ou_org_id = newrec.ou_org_id
             ,cust_account_id = newrec.cust_account_id
             ,cust_acct_site_id = newrec.cust_acct_site_id
             ,site_use_id = newrec.site_use_id
             ,site_use_ovn = newrec.site_use_ovn
             ,gl_id_rec_old = newrec.gl_id_rec_old
             ,gl_id_rev_old = newrec.gl_id_rev_old
             ,gl_id_tax_old = newrec.gl_id_tax_old
             ,gl_id_freight_old = newrec.gl_id_freight_old
             ,gl_id_clearing_old = newrec.gl_id_clearing_old
             ,gl_id_unbilled_old = newrec.gl_id_unbilled_old
             ,gl_id_unearned_old = newrec.gl_id_unearned_old
             ,gl_id_rec_new = newrec.gl_id_rec_new
             ,gl_id_rev_new = newrec.gl_id_rev_new
             ,gl_id_tax_new = newrec.gl_id_tax_new
             ,gl_id_freight_new = newrec.gl_id_freight_new
             ,gl_id_clearing_new = newrec.gl_id_clearing_new
             ,gl_id_unbilled_new = newrec.gl_id_unbilled_new
             ,gl_id_unearned_new = newrec.gl_id_unearned_new
      where   rowid = newrec.rowid;
      commit;
   end loop;
   -------------------------------------------------------------------------
   -- Summary Of Records Validation Process
   -------------------------------------------------------------------------
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Validation Summary');
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,'Records Validated       : ' ||ln_cnt_read);
   fnd_file.put_line(fnd_file.output,'  Passed                : ' ||ln_cnt_valid);
   fnd_file.put_line(fnd_file.output,'  Records with Errors   : ' ||ln_cnt_invalid);
   fnd_file.put_line(fnd_file.output,rpad('*',50,'*'));
   fnd_file.put_line(fnd_file.output,' ');
   fnd_file.put_line(fnd_file.output,'Validation errors (if any) can be viewed in request XXHA: Error Report');
   if (newCombinationTab.count > 0) then
      fnd_file.put_line(fnd_file.output,' ');
      fnd_file.put_line(fnd_file.output,' ');
      fnd_file.put_line(fnd_file.output,'The following new code combinations were created:');
      for i in 1..newCombinationTab.count
      loop
         fnd_file.put_line(fnd_file.output,'      '||newCombinationTab(i).concatenated_segments
                                        ||'   (ID='||newCombinationTab(i).code_combination_id
                                              ||')'
                          );
      end loop;
   end if;
   x_cnt_invalid := ln_cnt_invalid;
END validate_records;
/**************************************************
**  Public procedures start here
**************************************************/
-- +==============================================================================
-- | Name       : update_staging_table
-- |
-- | Description: Procedure to update staging table records
-- |
-- | Call From  : Loader Concurrent Program
-- |
-- | Parameters:
-- |   IN: p_file_name
-- |       p_request_id
-- |       p_ou_org_id
-- |  OUT:
-- |
-- | Scope: PUBLIC
-- |
-- +==============================================================================
PROCEDURE update_staging_table (
         p_file_name  in  varchar2
        ,p_request_id  in  number
        ) is
BEGIN
   update  xxha_cust_gl_accounts_stg
   set     file_name = p_file_name
          ,loader_request_id = p_request_id
   where   status = 'NEW'
   and     loader_request_id is null;
   commit;
END update_staging_table;
-- +==============================================================================
-- | Name       : purge_staging_table
-- |
-- | Description: Procedure to purge staging table records
-- |
-- | Call From  : Loader Concurrent Program
-- |
-- | Parameters:
-- |   IN:
-- |  OUT:
-- |
-- | Scope: PUBLIC
-- |
-- +==============================================================================
PROCEDURE purge_staging_table
          is
BEGIN
   delete  xxha_cust_gl_accounts_stg;
   commit;
END purge_staging_table;
-- +==============================================================================+
-- | Name       : process_records
-- |
-- | Description: Procedure to process staged assignment updates.  It drives the
-- |              following actions:
-- |               . Record level validation
-- |                   > check OU, customer, site, site use, GL account segments
-- |               . Update GL Accounts for valid records
-- |               . Call launch program for reporting errors (if any)
-- |
-- | Call From  : Main Concurrent Program
-- |
-- | PARAMETERS:
-- |   IN: p_debug_flag
-- |       p_purge_flag
-- |  OUT: x_err_buf
-- |       x_ret_code
-- |
-- | SCOPE: PUBLIC
-- |
-- +==============================================================================+
PROCEDURE process_records (
         x_err_buf  out  varchar2
        ,x_ret_code  out  varchar2
        ,p_debug_flag  in  varchar2
        ,p_purge_flag  in  varchar2
        )
IS
--The Local Variables
lc_err_setup  varchar2(1) := 'N';       -- Variable flag for setup error flag
ln_cnt_invalid  number;                 -- Variable to count invalid records
ln_cnt_notupdated  number;              -- Variable to count records passing validation but failing on assignment update

e_error  exception;
e_abort  exception;
BEGIN
   gn_record_number := null;
   gc_attribute4 := gc_conc_name;

   -- Purging the Error Table Data
   gc_log_message := 'Purging the Error Table data';
   xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);

   if ( p_purge_flag = 'Y' ) then

      begin
         -- This utility is expected to be used infrequently and concurrent requests
         -- may be purged between runs.  Therefore instead of calling
         -- XXHA_COMMON_UTILITIES_PKG.DELETE_ERROR_PRC which drives purging thru
         -- FND_CONCURRENT_REQUESTS, use this SQL to directly delete from error table.
         delete  xxha_common_errors  xce
         where   xce.attribute4 = gc_conc_name;
         commit;
      end;
   end if;
   validate_records(ln_cnt_invalid);
   update_gl_accounts(ln_cnt_notupdated);
   if (ln_cnt_invalid > 0  or  ln_cnt_notupdated > 0) then
      x_ret_code := 1;  -- Set completion status to Warning
      xxha_common_utilities_pkg.launch_error_report_prc(gn_child_request2_id,'Customer GL Accounts Update','Input File');
   end if;
EXCEPTION
   when e_abort then
      x_ret_code := 2;  -- Set completion status to Error
END process_records;
-- +==============================================================================+
-- | Name       : main
-- |
-- | Description: Procedure to submit Loader and Record Processing programs
-- |
-- | Call From  : Main Concurrent Program
-- |
-- | PARAMETERS:
-- |   IN: p_debug_flag
-- |       p_purge_flag
-- |  OUT: x_err_buf
-- |       x_ret_code
-- |
-- |
-- | SCOPE: PUBLIC
-- |
-- +==============================================================================+
PROCEDURE main (
          x_err_buf  out  varchar2
         ,x_ret_code  out  varchar2
         ,p_debug_flag  in  varchar2
         ,p_purge_flag  in  varchar2
         ) is
  --The Local variables
  ln_loaded_rec_count  number := 0;          -- variable to hold the no of records loaded from loader program
  lc_loader_status_code  varchar2(10);       -- variable to hold the Loader program status code
  lc_processing_status_code  varchar2(10);   -- variable to hold the Validation program status code
  lc_phase_code  varchar2(10);               -- variable to hold the phase code of a concurrent program
  lc_logfile  varchar2(100);                 -- variable to hold the log file name
  e_error  exception;
BEGIN
   gc_debug_flag := p_debug_flag;
   gc_log_message := 'Submitting .... XXHA: Customer GL Accounts Loader';
   xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);
   --Submitting the Loader Concurrent Program
   gn_child_request1_id := fnd_request.submit_request(
                                       Application => 'HAEMO'
                                      ,Program => 'XXHACUSTGLACCTSSTG'
                                      ,description => 'XXHA: Customer GL Accounts Staging'
                                      ,start_time => to_char(sysdate,'DD-MON-YYYY HH24:MI:SS')
                                      ,sub_request => FALSE
                                      ,Argument1 => NULL
                                      );
   commit;
   loop  -- child request 1
      begin
         select  fcr.logfile_name
                ,fcr.status_code
                ,fcr.phase_code
         into    lc_logfile
                ,lc_loader_status_code
                ,lc_phase_code
         from    fnd_concurrent_requests  fcr
         where   fcr.request_id = gn_child_request1_id
         and     fcr.phase_code = 'C';
         exit when lc_logfile is not null;
      exception
         when no_data_found then
            null;
      end;
   end loop; -- end loop for child request 1
   select  count(1)
   into    ln_loaded_rec_count
   from    xxha_cust_gl_accounts_stg
   where   status = 'NEW'
   and     loader_request_id = gn_child_request1_id;
   if not (lc_phase_code = 'C'  and  ln_loaded_rec_count > 0) then
      raise e_error;
   end if;
   gc_log_message := 'Submitting .... XXHA: Customer GL Accounts Processing';
   xxha_common_utilities_pkg.print_msg_prc(p_debug_flag,gc_log_message);
   --Submitting the Records Processing Concurrent Program
   gn_child_request2_id := fnd_request.submit_request(
                                       Application => 'HAEMO'
                                      ,Program => 'XXHACUSTGLACCTSPRC'
                                      ,description =>  'XXHA: Customer GL Accounts Processing'
                                      ,start_time =>  to_Char (sysdate,'DD-MON-YYYY HH24:MI:SS')
                                      ,sub_request =>  FALSE
                                      ,Argument1 =>  p_debug_flag
                                      ,Argument2 =>  p_purge_flag
                                      );
   commit;
   loop  -- child request 2
      begin
         select  fcr.logfile_name
                ,fcr.status_code
         into    lc_logfile
                ,lc_processing_status_code
         from    fnd_concurrent_requests  fcr
         where   fcr.request_id = gn_child_request2_id
         and     fcr.phase_code = 'C';
         exit when lc_logfile is not null;
      exception
         when no_data_found then
            null;
      end;
   end loop; -- end loop for child request 2
   if ( lc_loader_status_code = 'E'  or  lc_processing_status_code = 'E' ) then
      raise e_error;
   elsif ( lc_loader_status_code = 'C'  and  lc_processing_status_code = 'G' ) then
      x_ret_code := 1;   -- setting the concurrent program status to Warning
   elsif ( lc_loader_status_code = 'C'  and  lc_processing_status_code = 'C' ) then
      x_ret_code := 0;   -- setting the concurrent program status to Normal
   end if;
EXCEPTION
   when e_error then
      x_ret_code := 2;   -- setting the concurrent program status to Error
END main;
END XXHA_CUST_GL_ACCOUNTS_PK;
/
