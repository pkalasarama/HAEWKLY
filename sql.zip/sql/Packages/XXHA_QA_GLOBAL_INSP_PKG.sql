CREATE OR REPLACE package      XXHA_QA_GLOBAL_INSP_PKG
-- +=====================================================================================+
-- | Name        : XXHA_ECO_PROCESS_ECO                      		                 |
-- | Purpose     : Support the Interface of ECO into EBS.    				 |
-- |                                                             	                 |
-- | Description : Inspection record report by part number (inspection criteria, results,|
-- |			tied to lot number assignment with approval)	                 |
-- |               						 		         |
-- |               		                        	                         |
-- |               						                         |
-- | Comment     : This package provides data for the "Global Inspection Record Report"  |
-- |		   program to run and provide results for audit.			 |
-- |               				                           . 		 |
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who            What                                                  |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 20100324  1.0  Raj Reddy	   Initial Version                                       |
-- | 											 |
-- +=====================================================================================+
AS
	PROCEDURE process_main
			(x_errbuf   out  varchar2
			,x_retcode  out  varchar2
			,p_org   in  varchar2
			,p_item  in  varchar2
			,p_rev   in  varchar2
			,p_lot   in  varchar2
			,p_ser   in  varchar2
			,p_rct   in  varchar2
			,p_st_dt in  date
			,p_en_dt in  date
			,p_s_lot in  varchar2
			);

end XXHA_QA_GLOBAL_INSP_PKG;

/


CREATE OR REPLACE package body      XXHA_QA_GLOBAL_INSP_PKG
-- +=====================================================================================+
-- | Name        : XXHA_ECO_PROCESS_ECO                      		                 |
-- | Purpose     : Support the Interface of ECO into EBS.    				 |
-- |                                                             	                 |
-- | Description : Inspection record report by part number (inspection criteria, results,|
-- |			tied to lot number assignment with approval)	                 |
-- |               						 		         |
-- |               		                        	                         |
-- |               						                         |
-- | Comment     : This package provides data for the "Global Inspection Record Report"  |
-- |		   program to run and provide results for audit.			 |
-- |               				                           . 		 |
-- |                                                                           		 |
-- | History                                                                   		 |
-- | =======                                                                   		 |
-- | When      Rev  Who            What                                                  |
-- | --------  ---  --------  ------------------------------------------------ 		 |
-- | 3/24/2010  1.0  Raj Reddy	   Initial Version                                       |
-- | 11/3/2010  2.0  Dave Lund     increased the size of l_column_val to 200 (magic 76423)|
-- | 											 |
-- +=====================================================================================+
AS
PROCEDURE process_main
			(x_errbuf   out  varchar2
			,x_retcode  out  varchar2
			,p_org   in  varchar2
			,p_item  in  varchar2
			,p_rev   in  varchar2
			,p_lot   in  varchar2
			,p_ser   in  varchar2
			,p_rct   in  varchar2
			,p_st_dt in  date
			,p_en_dt in  date
			,p_s_lot in  varchar2
			)
	IS
TYPE item_rec IS RECORD (
		organization_id		Number,
		item_id			Number,
		item_revision		Varchar2(100),
		process_code		Varchar2(100),
		criteria_id		Number,
		transaction_id		Number);
Type item_tab IS TABLE OF item_rec INDEX BY BINARY_INTEGER;
l_items  item_rec;
l_items_tab item_tab;
cursor c_items (p_org_id  number)
	is
	select distinct
	       a.organization_id,
	       b.item_id,
	       b.item_revision,
	       a.process_code,
	       a.criteria_id,
	       null transaction_id
	 from qa_skiplot_rcv_criteria_v a,
	      qa_skiplot_rcv_results_v b
	where a.organization_id = p_org_id
	and a.item = nvl(p_item,a.item)
--	and a.item_revision = nvl(p_rev,a.item_revision)
	and sysdate between nvl(a.effective_from,sysdate-1) and nvl(a.effective_to,sysdate)
	and b.organization_id = a.organization_id
	and a.process_code = b.process_code
	and a.item_id = b.item_id
	and a.criteria_id = b.criteria_id
--	and a.item_revision = b.item_revision
        and b.item_revision = nvl(p_rev,b.item_revision)
	and b.inspection_status = 'Inspected'
	and b.last_insp_date between nvl(p_st_dt,trunc(b.last_insp_date)-1) and nvl(p_en_dt,sysdate) ;
cursor c_other_items (p_org_id number)
	is
	select distinct
	       b.organization_id
	      ,b.item_id
	      ,b.item_revision
	      ,b.process_code
	      ,a.criteria_id
	      ,e.transaction_id
	from qa_skiplot_rcv_criteria_v a
	    ,qa_skiplot_rcv_results_v b
	    ,rcv_shipment_headers c
	    ,rcv_transactions d
	    ,mtl_material_transactions e
	where a.organization_id = p_org_id
	  and a.process_code = b.process_code
	  and b.item = nvl(p_item,b.item)
	  and a.item_id = b.item_id
	--  and a.item_revision = b.item_revision
	  and a.criteria_id = b.criteria_id
	  and b.inspection_status = 'Inspected'
	  and b.shipment_header_id = c.shipment_header_id
	  and c.receipt_num = p_rct
	  and c.shipment_header_id = d.shipment_header_id
	  and d.transaction_type = 'DELIVER'
	  and d.transaction_id = e.rcv_transaction_id;
cursor c_lot_params (p_org_id number)
	is
	select distinct
	       b.organization_id
	      ,b.item_id
	      ,b.item_revision
	      ,b.process_code
	      ,a.criteria_id
	      ,e.transaction_id
	from qa_skiplot_rcv_criteria_v a
	    ,qa_skiplot_rcv_results_v b
	    ,rcv_shipment_headers c
	    ,rcv_transactions d
	    ,mtl_material_transactions e
	    ,mtl_transaction_lot_val_v f
	where a.organization_id = p_org_id
	  and a.process_code = b.process_code
	  and b.item = nvl(p_item,b.item)
	  and a.item_id = b.item_id
	--  and a.item_revision = b.item_revision
	  and a.criteria_id = b.criteria_id
	  and b.inspection_status = 'Inspected'
	  and b.shipment_header_id = c.shipment_header_id
	  and c.shipment_header_id = d.shipment_header_id
	  and d.transaction_type = 'DELIVER'
	  and d.transaction_id = e.rcv_transaction_id
	  and e.transaction_id = f.transaction_id
	  and f.lot_number = p_lot;
cursor c_s_lot_params (p_org_id number)
	is
	select distinct
	       b.organization_id
	      ,b.item_id
	      ,b.item_revision
	      ,b.process_code
	      ,a.criteria_id
	      ,e.transaction_id
	from qa_skiplot_rcv_criteria_v a
	    ,qa_skiplot_rcv_results_v b
	    ,rcv_shipment_headers c
	    ,rcv_transactions d
	    ,mtl_material_transactions e
	    ,mtl_transaction_lot_val_v f
	where a.organization_id = p_org_id
	  and a.process_code = b.process_code
	  and b.item = nvl(p_item,b.item)
	  and a.item_id = b.item_id
	--  and a.item_revision = b.item_revision
	  and a.criteria_id = b.criteria_id
	  and b.inspection_status = 'Inspected'
	  and b.shipment_header_id = c.shipment_header_id
	  and c.shipment_header_id = d.shipment_header_id
	  and d.transaction_type = 'DELIVER'
	  and d.transaction_id = e.rcv_transaction_id
	  and e.transaction_id = f.transaction_id
	  and f.supplier_lot_number = p_s_lot;
cursor c_ser_params (p_org_id number)
	is
	select distinct
	       b.organization_id
	      ,b.item_id
	      ,b.item_revision
	      ,b.process_code
	      ,a.criteria_id
	      ,e.transaction_id
	from qa_skiplot_rcv_criteria_v a
	    ,qa_skiplot_rcv_results_v b
	    ,rcv_shipment_headers c
	    ,rcv_transactions d
	    ,mtl_material_transactions e
	    ,mtl_unit_transactions_all_v g
	where a.organization_id = p_org_id
	  and a.process_code = b.process_code
	  and b.item = nvl(p_item,b.item)
	  and a.item_id = b.item_id
	--  and a.item_revision = b.item_revision
	  and a.criteria_id = b.criteria_id
	  and b.inspection_status = 'Inspected'
	  and b.shipment_header_id = c.shipment_header_id
	  and c.shipment_header_id = d.shipment_header_id
	  and d.transaction_type = 'DELIVER'
	  and d.transaction_id = e.rcv_transaction_id
	  and e.transaction_id = g.transaction_id
	  and g.serial_number = p_ser;
cursor c_rct_dtls (p_org_id number,
			  p_item_id number,
			  p_item_rev varchar2,
			  p_process_code varchar2,
			  p_criteria_id number,
			  p_trx number)
	is
	select b.organization_id
	      ,b.item
	      ,b.item_revision
	      ,b.process_code
	      ,b.inspection_status
	      ,b.inspection_result
	      ,(select segment1
	          from po_headers_all
	        where po_header_id = b.po_header_id) po_number
	      ,(select line_num
	          from po_lines_all
	         where po_line_id = b.po_line_id) po_line_num
	      ,c.receipt_num
	      ,d.primary_quantity lot_quantity
	      ,b.receipt_date
	      ,b.last_insp_date inspection_date
	      ,b.shipment_line_num
	      ,(select vendor_name
	          from ---po_vendors a1,---11i code modified
                 ap_suppliers a1, ---R12 Remediated
	               po_headers_all b1
	         where b1.po_header_id = b.po_header_id
	           and b1.vendor_id = a1.vendor_id) Supplier
	      ,(select vendor_site_code
	          from ---po_vendor_sites_all a1,---11i code modified
                 ap_supplier_sites_all a1, ---R12 Remediated
	               po_headers_all b1
	         where b1.po_header_id = b.po_header_id
	           and b1.vendor_site_id = a1.vendor_site_id) Supplier_Site
	      ,e.transaction_id
	   /*   ,( select vendor_lot_num
	      	 from rcv_shipment_lines
	      	 where shipment_header_id = d.shipment_header_id
            	   and shipment_line_id = d.shipment_line_id)
              , d.vendor_lot_num Supplier_lot_number  */
/*	      ,(select qa_collection_id
            	  from rcv_transactions
          	 where shipment_header_id = d.shipment_header_id
            	   and shipment_line_id = d.shipment_line_id
            	   and transaction_type in ('ACCEPT','REJECT')) collection_id*/
  , d.shipment_header_id
  , d.shipment_line_id
	from qa_skiplot_rcv_results_v b
	    ,rcv_shipment_headers c
	    ,rcv_transactions d
	    ,mtl_material_transactions e
	where b.organization_id = p_org_id
	  and b.process_code = p_process_code
	  and b.item_id = p_item_id
	  and b.item_revision = nvl(p_item_rev,b.item_revision)
	  and b.criteria_id = p_criteria_id
	  and b.inspection_status = 'Inspected'
	  and b.last_insp_date between nvl(p_st_dt,trunc(b.last_insp_date)-1) and nvl(p_en_dt,sysdate)
	  and b.shipment_header_id = c.shipment_header_id
	  and c.receipt_num = nvl(p_rct,c.receipt_num)
	  and c.shipment_header_id = d.shipment_header_id
	  and b.shipment_line_id = d.shipment_line_id
	  and d.transaction_type = 'DELIVER'
	  and d.transaction_id = e.rcv_transaction_id
	  and e.transaction_id  = nvl(p_trx,e.transaction_id);
cursor c_lots (p_trx_id number)
	is
	 select *
	   from mtl_transaction_lot_val_v
	  where transaction_id = p_trx_id
	    and lot_number = nvl(p_lot,lot_number)
	    and supplier_lot_number = nvl(p_s_lot,supplier_lot_number);
cursor c_lots1 (p_trx_id number)
	is
	 select *
	   from mtl_transaction_lot_val_v
	  where transaction_id = p_trx_id
	    and lot_number = p_lot;
cursor c_lots2 (p_trx_id number)
	is
	 select *
	   from mtl_transaction_lot_val_v
	  where transaction_id = p_trx_id
	    and supplier_lot_number = p_s_lot;
cursor c_serials (p_trx_id number)
	is
	 select *
	   from mtl_unit_transactions_all_v
	  where transaction_id = p_trx_id
	    and serial_number = nvl(p_ser,serial_number);
cursor c_serials1 (p_trx_id number)
	is
	 select *
	   from mtl_unit_transactions_all_v
	  where transaction_id = p_trx_id
	    and serial_number = p_ser;
cursor c_collection (--p_col_id number,
           p_ship_header_id number,
           p_ship_line_id number,
			     p_org_id number)
	is
	 select a.name plan_name
	      ,b.collection_id Collection
              ,(select user_name
                   from fnd_user
                 where user_id = b.qa_created_by
               ) Created_By
             ,b.last_update_date Entry_Date
             ,b.transaction_date
             ,b.quantity
             ,b.plan_id
             ,b.occurrence
             ,b.organization_id
	from qa_plans a,
	     qa_results b,
       rcv_transactions c
	where a.plan_id = b.plan_id
	  and a.organization_id = b.organization_id
	  and b.organization_id = p_org_id
	  and b.collection_id = c.qa_collection_id
    and c.shipment_header_id = p_ship_header_id
    and c.shipment_line_id = p_ship_line_id
   and c.transaction_type in ('ACCEPT','REJECT');
cursor c_col_elements (p_plan_id number)
	is
	select result_column_name, prompt
	  from qa_plan_chars_v
	 where plan_id = p_plan_id
	   and result_column_name like 'CHARACTER%'
	 order by prompt_sequence;
p_org_id number;
	p_item_id number;
	l_column_val varchar2(200);
	i number;
	j number;
	l_item varchar2(100);
	l_s_std varchar2(100);
	l_i_code varchar2(100);
	l_aql number;
BEGIN
		fnd_file.put_line(fnd_file.output,'=======================================================================');

		fnd_file.put_line(fnd_file.output,'XXHA: Global Inspection Record Report was submitted with below parameters. ');
		fnd_file.new_line(fnd_file.output,1);
		fnd_file.put_line(fnd_file.output,'Organization          : '||p_org);
		fnd_file.put_line(fnd_file.output,'Item Number           : '||p_item);
		fnd_file.put_line(fnd_file.output,'Item Revision         : '||p_rev);
		fnd_file.put_line(fnd_file.output,'Lot Number            : '||p_lot);
		fnd_file.put_line(fnd_file.output,'Serial Number         : '||p_ser);
		fnd_file.put_line(fnd_file.output,'Receipt Number        : '||p_rct);
		fnd_file.put_line(fnd_file.output,'Inspection Start Date : '||p_st_dt);
		fnd_file.put_line(fnd_file.output,'Inspection End Date   : '||p_en_dt);
		fnd_file.put_line(fnd_file.output,'Supplier Lot Number   : '||p_s_lot);
		fnd_file.new_line(fnd_file.output,1);

		fnd_file.put_line(fnd_file.output,'=======================================================================');
		fnd_file.new_line(fnd_file.output,1);
begin
			select organization_id
			  into p_org_id
			  from org_organization_definitions
			 where organization_code = p_org;
		end;
begin
			select inventory_item_id
			  into p_item_id
			from mtl_system_items_b
			where organization_id = 103
			  and segment1 = p_item;
		exception
		when others
		then
			null;
		end;
i:= 1;
if p_rct is not null then
FOR l_rec IN c_other_items(p_org_id)
			LOOP
				l_items_tab(i).organization_id := l_rec.organization_id;
				l_items_tab(i).item_id	       := l_rec.item_id;
				l_items_tab(i).item_revision   := l_rec.item_revision;
				l_items_tab(i).process_code    := l_rec.process_code;
				l_items_tab(i).criteria_id     := l_rec.criteria_id;
				l_items_tab(i).transaction_id  := l_rec.transaction_id;
i:=i+1;
			END LOOP;
		 elsif  p_lot is not null  then

			FOR l_rec IN c_lot_params(p_org_id)
			LOOP
 				l_items_tab(i).organization_id	:= l_rec.organization_id;
				l_items_tab(i).item_id	        := l_rec.item_id;
				l_items_tab(i).item_revision    := l_rec.item_revision;
				l_items_tab(i).process_code     := l_rec.process_code;
				l_items_tab(i).criteria_id      := l_rec.criteria_id;
				l_items_tab(i).transaction_id   := l_rec.transaction_id;
i:=i+1;
			END LOOP;
		 elsif p_ser is not null then
FOR l_rec IN c_ser_params(p_org_id)
			LOOP
				l_items_tab(i).organization_id  := l_rec.organization_id;
				l_items_tab(i).item_id	        := l_rec.item_id;
				l_items_tab(i).item_revision    := l_rec.item_revision;
				l_items_tab(i).process_code     := l_rec.process_code;
				l_items_tab(i).criteria_id      := l_rec.criteria_id;
				l_items_tab(i).transaction_id   := l_rec.transaction_id;
i:=i+1;
			END LOOP;
		elsif  p_s_lot is not null  then
FOR l_rec IN c_s_lot_params(p_org_id)
			LOOP
				l_items_tab(i).organization_id	:= l_rec.organization_id;
				l_items_tab(i).item_id	        := l_rec.item_id;
				l_items_tab(i).item_revision    := l_rec.item_revision;
				l_items_tab(i).process_code     := l_rec.process_code;
				l_items_tab(i).criteria_id      := l_rec.criteria_id;
				l_items_tab(i).transaction_id   := l_rec.transaction_id;
i:=i+1;
			END LOOP;
		else
			FOR l_rec IN c_items(p_org_id)
			LOOP
				l_items_tab(i).organization_id	:= l_rec.organization_id;
				l_items_tab(i).item_id	     	:= l_rec.item_id;
				l_items_tab(i).item_revision    := l_rec.item_revision;
				l_items_tab(i).process_code     := l_rec.process_code;
				l_items_tab(i).criteria_id      := l_rec.criteria_id;
				l_items_tab(i).transaction_id   := l_rec.transaction_id;
i:=i+1;
			END LOOP;
		end if;
i:= l_items_tab.COUNT;
	--	fnd_file.put_line(fnd_file.output,'Number of Items: '|| i);
IF i>0 THEN
			FOR j in l_items_tab.FIRST .. l_items_tab.LAST
			LOOP
				l_items.organization_id := l_items_tab(j).organization_id;
				l_items.item_id		:= l_items_tab(j).item_id;
				l_items.item_revision	:= l_items_tab(j).item_revision;
				l_items.process_code	:= l_items_tab(j).process_code ;
				l_items.criteria_id	:= l_items_tab(j).criteria_id ;
				l_items.transaction_id	:= l_items_tab(j).transaction_id;
begin
			select segment1
					  into l_item
					from   mtl_system_items_b
					where  organization_id = 103
					  and  inventory_item_id= l_items_tab(j).item_id;
				exception
				when others
				then
					null;
				end;

		fnd_file.put_line(fnd_file.output,'Item Number : '||l_item ||' Rev Number : '||l_items.item_revision);
				fnd_file.new_line(fnd_file.output,1);
begin
		select sampling_std_desc, insp_level_code ,aql
					  into l_s_std, l_i_code, l_aql
					  from  qa_sampling_plans_v a,
						qa_sp_criteria_association_v b
					 where a.sampling_plan_id = b.sampling_plan_id
					   and b.criteria_id = l_items.criteria_id;
exception
				when others then
					l_s_std  := null;
					l_i_code := null;
					l_aql    := null;
				end;
fnd_file.put_line(fnd_file.output,'Sampling Standard : '||l_s_std);
				fnd_file.put_line(fnd_file.output,'Inspection Level  : '||l_i_code);
				fnd_file.put_line(fnd_file.output,'Acceptable Quality Level : '||l_aql);
				fnd_file.new_line(fnd_file.output,1);
fnd_file.put_line(fnd_file.output,'Inspection Status |'
								||' Inspection Result |'
								||' PO Number |'
								||' PO Line Number |'
								||' Receipt Number |'
								||' Lot Quantity |'
								||' Receipt Date |'
								||' Inspection Date |'
								||' Shipment Line Number |'
								||' Supplier Name |'
								||' Supplier Site |'
								||' Supplier Lot Number');
				fnd_file.new_line(fnd_file.output,1);
for l_rct_dtls in c_rct_dtls (l_items.organization_id
							     ,l_items.item_id
							     ,l_items.item_revision
							     ,l_items.process_code
							     ,l_items.criteria_id
							     ,l_items.transaction_id)
loop
					fnd_file.put_line(fnd_file.output,l_rct_dtls.Inspection_Status||' | '
							||l_rct_dtls.Inspection_Result||' | '
							||l_rct_dtls.PO_Number||' | '
							||l_rct_dtls.PO_Line_Num||' | '
							||l_rct_dtls.Receipt_Num||' | '
							||l_rct_dtls.Lot_Quantity||' | '
							||l_rct_dtls.Receipt_Date||' | '
							||l_rct_dtls.Inspection_Date||' | '
							||l_rct_dtls.Shipment_Line_Num||' | '
							||l_rct_dtls.Supplier||' | '
							||l_rct_dtls.Supplier_Site);
fnd_file.new_line(fnd_file.output,1);
fnd_file.put_line(fnd_file.output,'Lot Numbers | '|| 'Expiration Date | '|| 'Supplier Lot Number');

		if p_lot is not null then
						for l_lots in c_lots1 (l_rct_dtls.transaction_id) loop
							fnd_file.put_line(fnd_file.output,l_lots.lot_number
											  ||' | '|| l_lots.expiration_date
											  ||' | '|| l_lots.supplier_lot_number);
			end loop;
elsif p_s_lot is not null then
						for l_lots in c_lots2 (l_rct_dtls.transaction_id) loop
							fnd_file.put_line(fnd_file.output,l_lots.lot_number
											  ||' | '|| l_lots.expiration_date
								||' | '|| l_lots.supplier_lot_number);
						end loop;
else
						for l_lots in c_lots (l_rct_dtls.transaction_id) loop
							fnd_file.put_line(fnd_file.output,l_lots.lot_number
											||' | '|| l_lots.expiration_date
								||' | '|| l_lots.supplier_lot_number);
						end loop;
					end if;
fnd_file.new_line(fnd_file.output,1);
					fnd_file.put_line(fnd_file.output,'Serial Numbers ');

					if p_ser is not null then
						for l_serials in c_serials1 (l_rct_dtls.transaction_id) loop
							fnd_file.put_line(fnd_file.output,l_serials.serial_number);
						end loop;
					else
						for l_serials in c_serials (l_rct_dtls.transaction_id) loop
							fnd_file.put_line(fnd_file.output,l_serials.serial_number);
						end loop;
					end if;

					fnd_file.new_line(fnd_file.output,1);
					fnd_file.put_line(fnd_file.output,'Collection Details :');

					for l_collection in c_collection(l_rct_dtls.shipment_header_id,
                   l_rct_dtls.shipment_line_id,
									 l_rct_dtls.organization_id) loop

						fnd_file.new_line(fnd_file.output,1);
						fnd_file.put_line(fnd_file.output,'Collection : ' || l_collection.collection);
						fnd_file.put_line(fnd_file.output,'Plan Name : ' || l_collection.plan_name);
						fnd_file.put_line(fnd_file.output,'Quantity : ' || l_collection.quantity);
						fnd_file.put_line(fnd_file.output,'Created By : ' || l_collection.Created_By);
						fnd_file.put_line(fnd_file.output,'Entry Date : ' || l_collection.Entry_Date);
						fnd_file.put_line(fnd_file.output,'Transaction Date : ' || l_collection.transaction_date);

						l_column_val := null;
						for l_col_elements in c_col_elements(l_collection.plan_id) loop

							execute immediate 'select '|| l_col_elements.result_column_name
								      ||' from qa_results
									where plan_id = :2
									and collection_id = :3
									and occurrence = :4'
									INTO l_column_val
									USING l_collection.plan_id,
									      l_collection.collection,
									      l_collection.occurrence;

							fnd_file.put_line(fnd_file.output, l_col_elements.prompt ||' : '||l_column_val);
						end loop;
					end loop;

					fnd_file.new_line(fnd_file.output,1);
fnd_file.put_line(fnd_file.output,'-----------------------------------------------------------------------');
				end loop;

fnd_file.put_line(fnd_file.output,'-----------------------------------------------------------------------');
				fnd_file.new_line(fnd_file.output,1);
			END LOOP;
		END IF;
	EXCEPTION
	WHEN OTHERS THEN
		fnd_file.put_line(fnd_file.output, 'Error while processing process_main :' ||substr(sqlerrm,1,100));
	END process_main;
END XXHA_QA_GLOBAL_INSP_PKG;
/
