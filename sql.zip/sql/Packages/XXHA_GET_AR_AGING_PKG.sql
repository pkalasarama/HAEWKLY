CREATE OR REPLACE PACKAGE XXHA_GET_AR_AGING_PKG
AUTHID CURRENT_USER AS
--Version 1.0
/************************************************************************************************
* Package Name : XXHA_GET_AR_AGING_PKG                                               		*
* Purpose      : This package populates and purges the haemo.xxha_ar_aging_rpt_tmp table 	*
*              : v2(12/02/09) - IPadela - ...and also the haemo.xx_haemo_unapp_rcpt_aging table       *
*											        *
* Ver        Date            Author               Description                            	*
* ------     -----------     -----------------    ---------------                        	*
* 1.0        15-Dec-2007     K Budziszewski       Initial Creation                       	*
* 2.0	     02-Dec-2009     IPadela		  Added code to age unapplied ar receipts too	*
*************************************************************************************************/
-- Procedure used to get the main data
--





  PROCEDURE age_data (x_errbuf               OUT VARCHAR2,
                      x_retcode              OUT VARCHAR2,
                      p_report_type          IN  VARCHAR2,
                      p_reporting_level      IN  VARCHAR2,
                      p_reporting_context    IN  VARCHAR2,
                      p_as_of_gl_date        IN  VARCHAR2,
                      p_Aging_Bucket_Name    IN  VARCHAR2,
                      p_Customer_Name_Low    IN  VARCHAR2,
                      p_Customer_Name_high   IN  VARCHAR2,
                      p_Customer_Number_Low  IN  VARCHAR2,
                      p_Customer_Number_high IN  VARCHAR2,
                      p_acct_low             IN  VARCHAR2,
                      p_acct_high            IN  VARCHAR2);

  PROCEDURE delete_data (x_errbuf          OUT VARCHAR2,
                         x_retcode         OUT VARCHAR2,
                         max_delete_date   IN  DATE DEFAULT SYSDATE - 1);


END;
/


CREATE OR REPLACE PACKAGE BODY XXHA_GET_AR_AGING_PKG AS
--Version 1.0
/************************************************************************************************
* Package Name : XXHA_GET_AR_AGING_PKG                                               		*
* Purpose      : This package populates and purges the haemo.xxha_ar_aging_rpt_tmp table 	*
*              : v2(12/02/09) - IPadela - ...and also the haemo.xx_haemo_rcpt_aging table       *
*											        *
* Ver        Date            Author               Description                            	*
* ------     -----------     -----------------    ---------------                        	*
* 1.0        15-Dec-2007     K Budziszewski       Initial Creation                       	*
* 1.1        27-Oct-2008     L RIchards           In procedure DELETE_DATA, truncate     	*
*                                                 table instead of delete                	*
* 2.0	       02-Dec-2009     IPadela		          Added code to age unapplied ar receipts too	*
* 3.0	       16-Jul-2010     IPadela		          Updated the SQL for the AR Aging data to fix  *
*						                                      an issue with the results when payments were  *
*						                                      made in installments.				*
* 4.0        29-Mar-2013     IPadela              1.added the user defined fields RxC Cust Billto
*                                                 and Shipto site cross reference               *
*                                                 2. added invoice type                         *
*************************************************************************************************/
-- Procedure used to get the main data
--
/* DEFINE THE "ROBERTO Query" - Provided by Tomek */
  CURSOR c_ar_data(p_as_of_gl_date        IN DATE,
                   p_Aging_Bucket_Name    IN VARCHAR2,
                   p_Customer_Name_Low    IN VARCHAR2,
                   p_Customer_Name_high   IN VARCHAR2,
                   p_Customer_Number_Low  IN VARCHAR2,
                   p_Customer_Number_high IN VARCHAR2,
                   p_reporting_context    IN VARCHAR2,
                   p_acct_low             IN VARCHAR2,
                   p_acct_high            IN VARCHAR2) IS
    SELECT cons_billing_number,
           bill_number,
           bill_name,
          /*(SELECT customer_category_meaning    ---11i code modified
FROM ar_customers_v
WHERE customer_number = bill_number
AND rownum            < 2
) cust_cat_meaning,*/
-----R12 Remediated
(select al.meaning customer_category_meaning
from   AR_LOOKUPS al,
       hz_parties hp,
       hz_cust_accounts hca
where hca.account_number = bill_number
  and hp.party_id        = hca.party_id
  and hp.CATEGORY_CODE = al.LOOKUP_CODE(+)
  AND al.LOOKUP_TYPE(+) = 'CUSTOMER_CATEGORY'
  AND rownum            < 2) cust_cat_meaning,
/*(SELECT customer_class_meaning  ---11i code modified
FROM ar_customers_v
WHERE customer_number = bill_number
AND rownum            < 2
) cust_class_meaning,*/
-----R12 Remediated
(select al.meaning customer_class_meaning
from   AR_LOOKUPS al,
       hz_parties hp,
       hz_cust_accounts hca
where hca.account_number = bill_number
  and hp.party_id        = hca.party_id
  AND hca.CUSTOMER_CLASS_CODE = al.LOOKUP_CODE(+)
  AND al.LOOKUP_TYPE(+) = 'CUSTOMER CLASS'
  AND rownum            < 2) cust_class_meaning,
/*(SELECT customer_type_meaning     ---11i code modified
FROM ar_customers_v
WHERE customer_number = bill_number
AND rownum            < 2
) cust_type_meaning,*/
-----R12 Remediated
(select al.meaning customer_type_meaning
from   AR_LOOKUPS al,
       hz_parties hp,
       hz_cust_accounts hca
where hca.account_number = bill_number
  and hp.party_id        = hca.party_id
  AND hca.CUSTOMER_TYPE = al.LOOKUP_CODE(+)
  AND al.LOOKUP_TYPE(+) = 'CUSTOMER_TYPE'
  AND rownum            < 2) cust_type_meaning,
           trx_class,
           trx_number,
           due_date,
           ceil(to_date(p_as_of_gl_date) - due_date)  days_past_due,
           invoice_currency_code,
           CASE WHEN ceil(to_date(p_as_of_gl_date) - due_date)  < 0 THEN amount_due_remaining ELSE 0 END  current_amount,
           CASE WHEN ceil(to_date(p_as_of_gl_date) - due_date) BETWEEN 0 AND 30 THEN amount_due_remaining ELSE 0 END  b1_1_31,
           CASE WHEN ceil(to_date(p_as_of_gl_date) - due_date) BETWEEN 31 AND 60 THEN amount_due_remaining ELSE 0 END b2_1_31,
           CASE WHEN ceil(to_date(p_as_of_gl_date) - due_date) BETWEEN 61 AND 90 THEN amount_due_remaining ELSE 0 END b3_1_31,
           CASE WHEN ceil(to_date(p_as_of_gl_date) - due_date) BETWEEN 91 AND 180 THEN amount_due_remaining ELSE 0 END  b4_1_31,
           CASE WHEN ceil(to_date(p_as_of_gl_date) - due_date) BETWEEN 181 AND 360 THEN amount_due_remaining ELSE 0 END b5_1_31,
           CASE WHEN ceil(to_date(p_as_of_gl_date) - due_date)  > 360 THEN amount_due_remaining ELSE 0 END  b6_360_plus,
           cc.segment1,
           cc.segment2,
           cc.segment3,
           cc.segment4,
           cc.segment5,
           cc.segment6,
           cc.segment7,
           cc.segment8,
           cc.segment9 ,
           source,
           primary_salesrep_id,
           salesrep_name,
           amount_due_original,
           applied_amount,
           applied_count,
           amount_due_remaining,
           bill_cust_id,
           bill_site_use_id,
           bill_site_number,
           bill_address1,
           bill_address2,
           bill_address3,
           bill_address4,
           bill_city,
           bill_postal_code,
           bill_county,
           bill_state,
           bill_country,
           customer_type_name,
           category_code,
           customer_class_code,
           orig_system_reference ,
           acctd_amount_due_remaining ,
           DECODE(amount_due_original,0,NULL, 1 - (amount_due_remaining / amount_due_original)) percent_unpaid,
           p_as_of_gl_date gl_as_of_date ,
           p_reporting_context org_id,
           trx_date,
           exchange_rate,
          (select name
             from hr_organization_units where organization_id  = p_reporting_context) org_name,
          --Rev 4.0
          trx_type,
          rxc_billto
          --end
      FROM
        (SELECT schedule.customer_trx_id,
                schedule.class,
                schedule.cons_inv_id,
                schedule.due_date,
                schedule.amount_adjusted_pending ,
                schedule.CONS_BILLING_NUMBER,
                schedule.exchange_rate,
                inv.trx_number,
                inv.trx_date,
                inv.doc_sequence_value,
                schedule.gl_date,
                invtype.type                                                     AS trx_class,
                sources.name                                                     AS source,
                inv.primary_salesrep_id,
                rep.salesrep_number,
                rep.name                                                         AS salesrep_name,
                inv.invoice_currency_code,
                schedule.amount_due_original                                     AS amount_due_original,
                NVL(activities.amount, 0)                                        AS applied_amount,
                NVL(activities.applied_count, 0)                                 AS applied_count,
                NVL(schedule.amount_due_original, 0) - NVL(activities.amount, 0) AS amount_due_remaining,
                billcust.cust_account_id                                         AS bill_cust_id,
                billcust.account_number                                          AS bill_number,
                shipcust.account_number                                          AS ship_number,
                billparty.party_name                                             AS bill_name,
                billuse.site_use_id                                              AS bill_site_use_id,
                billpartysite.party_site_number                                  AS bill_site_number,
                billloc.address1                                                 AS bill_address1,
                billloc.address2                                                 AS bill_address2,
                billloc.address3                                                 AS bill_address3,
                billloc.address4                                                 AS bill_address4,
                billloc.city                                                     AS bill_city,
                billloc.postal_code                                              AS bill_postal_code,
                billloc.county                                                   AS bill_county,
                billloc.state                                                    AS bill_state,
                billloc.country                                                  AS bill_country,
                CASE billcust.customer_type WHEN 'R' THEN 'External'
                                            WHEN 'I' THEN 'Internal'
                                            ELSE NULL END                        AS customer_type_name,
                billparty.category_code,
                billcust.customer_class_code,
                billcust.orig_system_reference                                   AS orig_system_reference ,
                nvl(schedule.acctd_amount_due_original, 0) - nvl(activities.acctd_amount, 0)
                                                                   as acctd_amount_due_remaining,
               -- Rev 4.0
                invtype.name                                                     AS trx_type,
                billuse.attribute5                                               as rxc_billto
                --end
           FROM
	     --IPadela Rev 3.0
             (SELECT ps.payment_schedule_id,
		     ps.customer_trx_id ,
                     ps.due_date,
                     ps.cons_inv_id ,
                     ps.amount_adjusted_pending ,
                     ps.exchange_rate,
                     CONS.CONS_BILLING_NUMBER,
		     --IPadela Rev 3.0
                     ps.amount_due_original                                      AS amount_due_original,
                     round(ps.amount_due_original * NVL(ps.exchange_rate, 1), 2) AS acctd_amount_due_original,
                     ps.gl_date,
                     ps.class
                FROM apps.ar_payment_schedules_all ps,
                     apps.ar_cons_inv_all cons
               WHERE ps.customer_trx_id IS NOT NULL
                 AND TRUNC(ps.gl_date)  <= p_as_of_gl_date
                 AND ps.class           <> 'PMT'
                 AND cons.cons_inv_id(+) = ps.cons_inv_id) schedule,
	     --IPadela Rev 3.0
             (SELECT payment_schedule_id ,
                     SUM(amount)        AS amount ,
                     SUM(acctd_amount)  AS acctd_amount ,
                     MAX(apply_date)    AS apply_date ,
                     MAX(gl_date)       AS gl_date ,
                     COUNT(*)           AS applied_count
                FROM
		  --IPadela Rev 3.0
                  (SELECT app.applied_payment_schedule_id AS payment_schedule_id ,
                          NVL(app.amount_applied,0) + NVL(app.earned_discount_taken, 0) +
                          NVL(app.unearned_discount_taken, 0)                                           AS amount ,
                          NVL(app.acctd_amount_applied_to, 0) + NVL(app.acctd_earned_discount_taken, 0) +
                          NVL(app.acctd_unearned_discount_taken, 0)                                     AS acctd_amount,
                          apply_date                                                                    AS apply_date ,
                          gl_date
                     FROM apps.ar_receivable_applications_all app
                    WHERE applied_payment_schedule_id IS NOT NULL
                      AND TRUNc(app.gl_date) <= p_as_of_gl_date
                UNION ALL
		   --IPadela Rev 3.0
                   SELECT app.payment_schedule_id
                       , -app.amount_applied          AS amount
                       , -app.acctd_amount_applied_to AS acctd_amount
                       , apply_date                   AS apply_date
                       , gl_date
                    FROM apps.ar_receivable_applications_all app
                   WHERE app.payment_schedule_id     IS NOT NULL
                     AND applied_payment_schedule_id IS NOT NULL
                     AND TRUNC(app.gl_date) <= p_as_of_gl_date
               UNION ALL
		  --IPadela Rev 3.0
                  SELECT adj.payment_schedule_id
                      , -adj.amount                   AS amount
                      , -adj.acctd_amount             AS acctd_amount
                      , apply_date                    AS apply_date
                      , gl_date
                   FROM apps.ar_adjustments_all adj
                  WHERE TRUNC(adj.gl_date) <= p_as_of_gl_date
                    AND adj.status = 'A' )
               GROUP BY payment_schedule_id ) activities,
           apps.RA_CUSTOMER_TRX_ALL inv,
           apps.ra_cust_trx_types_all  invtype,
           apps.ra_batch_sources_all   sources,
           apps.JTF_RS_SALESREPS       rep,
           apps.hz_cust_site_uses_all  billuse,
           apps.hz_cust_site_uses_all  shipuse,
           apps.hz_cust_acct_sites_all billcustsite,
           apps.hz_cust_acct_sites_all shipcustsite,
           apps.hz_party_sites         billpartysite,
           apps.hz_party_sites         shippartysite,
           apps.hz_locations           billloc,
           apps.hz_locations           shiploc,
           apps.hz_cust_accounts       billcust,
           apps.hz_cust_accounts       shipcust,
           apps.hz_parties             billparty ,
           apps.hz_parties             shipparty
        WHERE inv.org_id                   =  p_reporting_context
          AND inv.customer_trx_id(+)       = schedule.customer_trx_id
          --IPadela Rev 3.0
          AND schedule.payment_schedule_id     = activities.payment_schedule_id(+)
          AND inv.org_id                   = invtype.org_id(+)
          AND inv.cust_trx_type_id         = invtype.cust_trx_type_id(+)
          AND inv.org_id                   = sources.ORG_ID(+)
          AND inv.batch_source_id          = sources.batch_source_id(+)
          AND inv.org_id                   = rep.org_id(+)
          AND inv.primary_salesrep_id      = rep.salesrep_id(+)
          AND inv.bill_to_site_use_iD      = billuse.site_use_id(+)
          AND inv.ship_TO_SITE_USE_ID      = shipuse.site_use_id(+)
          AND billuse.cust_acct_site_id    = billcustsite.cust_acct_site_id(+)
          AND shipuse.cust_acct_site_id    = shipcustsite.cust_acct_site_id(+)
          AND billcustsite.party_site_id   = billpartysite.party_site_id(+)
          AND shipcustsite.party_site_id   = shippartysite.party_site_id(+)
          AND billpartysite.location_id    = billloc.location_id(+)
          AND shippartysite.location_id    = shiploc.location_id(+)
          AND billcustsite.cust_account_id = billcust.cust_account_id(+)
          AND shipcustsite.cust_account_id = shipcust.cust_account_id(+)
          AND billcust.party_id            = billparty.party_id(+)
          AND shipcust.party_id            = shipparty.party_id(+) )  the_data,
     ra_cust_trx_line_gl_dist_all  gld,
     gl_code_combinations cc
  WHERE gld.customer_trx_id = the_data.customer_trx_id
    AND account_class       = 'REC'
    AND gld.latest_rec_flag = 'Y'
    AND gld.code_combination_id = cc.code_combination_id
    AND amount_due_remaining <> 0
    AND (p_Customer_Number_Low  IS NULL OR  bill_number >= p_Customer_Number_Low )
    AND (p_Customer_Number_high IS NULL OR  bill_number <= p_Customer_Number_high )
    AND (p_acct_low             IS NULL OR  segment6    >= p_acct_low  )
    AND (p_acct_high            IS NULL OR  segment6    <= p_acct_high )
    AND (p_Customer_Name_Low    IS NULL OR  bill_name   >= p_acct_low  )
    AND (p_Customer_Name_High   IS NULL OR  bill_name   <= p_acct_low  ) ;
/* Rev 2.0 - cursor for unapplied receipts */
CURSOR c_recpt_data(p_as_of_gl_date       IN DATE,
                   p_Aging_Bucket_Name    IN VARCHAR2,
                   p_Customer_Name_Low    IN VARCHAR2,
                   p_Customer_Name_high   IN VARCHAR2,
                   p_Customer_Number_Low  IN VARCHAR2,
                   p_Customer_Number_high IN VARCHAR2,
                   p_reporting_context    IN VARCHAR2,
                   p_acct_low             IN VARCHAR2,
                   p_acct_high            IN VARCHAR2) IS
select
  ps.org_id,
  ou.name as org_name,
  cust.account_number as customer_number,
  party.party_name as customer_name,
  cust.customer_type as customer_type_code,
  party.category_code as customer_category_code,
  cust.customer_class_code,
  ps.invoice_currency_code as currency_code,
  trunc(cr.receipt_date) as receipt_date,
  cr.cash_receipt_id as receipt_id,
  sum(app.amount_applied) as Unapp_amount,
  ceil(to_date(p_as_of_gl_date) - cr.receipt_date)  days_unapplied,
  CASE WHEN ceil(to_date(p_as_of_gl_date) - cr.receipt_date)  < 0 THEN sum(app.amount_applied) ELSE 0 END  current_amount,
  CASE WHEN ceil(to_date(p_as_of_gl_date) - cr.receipt_date) BETWEEN 0 AND 30 THEN sum(app.amount_applied) ELSE 0 END  b1_1_30,
  CASE WHEN ceil(to_date(p_as_of_gl_date) - cr.receipt_date) BETWEEN 31 AND 60 THEN sum(app.amount_applied) ELSE 0 END b2_31_60,
  CASE WHEN ceil(to_date(p_as_of_gl_date) - cr.receipt_date) BETWEEN 61 AND 90 THEN sum(app.amount_applied) ELSE 0 END b3_61_90,
  CASE WHEN ceil(to_date(p_as_of_gl_date) - cr.receipt_date) BETWEEN 91 AND 180 THEN sum(app.amount_applied) ELSE 0 END  b4_91_180,
  CASE WHEN ceil(to_date(p_as_of_gl_date) - cr.receipt_date) BETWEEN 181 AND 360 THEN sum(app.amount_applied) ELSE 0 END b5_181_360,
  CASE WHEN ceil(to_date(p_as_of_gl_date) - cr.receipt_date)  > 360 THEN sum(app.amount_applied) ELSE 0 END  b6_360_plus,
  p_as_of_gl_date gl_as_of_date
from
  ar.ar_payment_schedules_all ps,
  ar.ar_receivable_applications_all app,
  ar.ar_cash_receipts_all cr,
  ar.hz_cust_accounts cust,
  ar.hz_parties party,
  apps.hr_operating_units ou
where
  ps.status = 'OP'
  and ps.org_id = ou.organization_id
  and ps.customer_id = cust.cust_account_id(+)
  and cust.party_id = party.party_id(+)
  and app.payment_schedule_id = ps.payment_schedule_id
  and app.cash_receipt_id = cr.cash_receipt_id
  and ps.cash_receipt_id = cr.cash_receipt_id
  and nvl(app.confirmed_flag, 'Y') = 'Y'
  and app.status <> 'APP'
  and TRUNC(cr.receipt_date) <= p_as_of_gl_date
  and ps.org_id = p_reporting_context
  AND (p_Customer_Number_Low  IS NULL OR  cust.account_number >= p_Customer_Number_Low )
  AND (p_Customer_Number_high IS NULL OR  cust.account_number <= p_Customer_Number_high )
  AND (p_Customer_Name_Low    IS NULL OR  party.party_name   >= p_Customer_Name_Low  )
  AND (p_Customer_Name_High   IS NULL OR  party.party_name   <= p_Customer_Name_High  )
group by
  ps.org_id,
  ou.name,
  cust.account_number,
  party.party_name,
  cust.customer_type,
  party.category_code,
  cust.customer_class_code,
  ps.invoice_currency_code,
  cr.receipt_date,
  cr.cash_receipt_id;
/* end Rev 2.0 */

/* Package global variables */
  v_user_name VARCHAR2(30);
  v_run_date  DATE         := SYSDATE;
 /* ***************************************************************************** */
  PROCEDURE delete_data (x_errbuf          OUT VARCHAR2,
                         x_retcode         OUT VARCHAR2,
                         max_delete_date   IN  DATE DEFAULT SYSDATE - 1) IS
BEGIN
    -- <Rev 1.1: Replace delete with truncate
    -- DELETE haemo.xxha_ar_aging_rpt_tmp
    -- WHERE report_date <= max_delete_date;

    execute immediate 'truncate table haemo.xxha_ar_aging_rpt_tmp';

    -- Rev 1.1>
    -- Rev 2.0 add the unapplied recipts table for purging
    execute immediate 'truncate table haemo.xx_haemo_unapp_rcpt_aging';
    -- end Rev 2.0
END;
  /* ***************************************************************************** */

/* ***************************************************************************** */
  PROCEDURE write_to_output(p_in_data IN OUT NOCOPY c_ar_data%ROWTYPE) IS
  BEGIN
    FND_FILE.PUT_line(FND_FILE.OUTPUT,
      p_in_data.bill_number            || CHR(9) ||
      p_in_data.bill_name              || CHR(9) ||
      p_in_data.cons_billing_number    || CHR(9) ||
      p_in_data.cust_cat_meaning       || CHR(9) ||
      p_in_data.cust_class_meaning     || CHR(9) ||
      p_in_data.cust_type_meaning      || CHR(9) ||
      p_in_data.trx_class              || CHR(9) ||
      p_in_data.trx_number             || CHR(9) ||
      p_in_data.due_date               || CHR(9) ||
      p_in_data.days_past_due          || CHR(9) ||
      p_in_data.invoice_currency_code  || CHR(9) ||
      p_in_data.amount_due_remaining   || CHR(9) ||
      p_in_data.current_amount         || CHR(9) ||
      p_in_data.b1_1_31                || CHR(9) ||
      p_in_data.b2_1_31                || CHR(9) ||
      p_in_data.b3_1_31                || CHR(9) ||
      p_in_data.b4_1_31                || CHR(9) ||
      p_in_data.b5_1_31                || CHR(9) ||
      p_in_data.b6_360_plus            || CHR(9) ||
      p_in_data.segment1               || CHR(9) ||
      p_in_data.segment2               || CHR(9) ||
      p_in_data.segment3               || CHR(9) ||
      p_in_data.segment4               || CHR(9) ||
      p_in_data.segment5               || CHR(9) ||
      p_in_data.segment6               || CHR(9) ||
      p_in_data.segment7               || CHR(9) ||
      p_in_data.segment8               || CHR(9) ||
      p_in_data.segment9 );
  END write_to_output;
  /* ***************************************************************************** */

  /* Rev 2.0 */
  /* ***************************************************************************** */
  PROCEDURE Rcpts_write_to_output(p_in_data IN OUT NOCOPY c_recpt_data%ROWTYPE) IS
  BEGIN
    FND_FILE.PUT_line(FND_FILE.OUTPUT,
      p_in_data.customer_number            || CHR(9) ||
      p_in_data.customer_name              || CHR(9) ||
      p_in_data.customer_type_code    	   || CHR(9) ||
      p_in_data.customer_category_code     || CHR(9) ||
      p_in_data.customer_class_code        || CHR(9) ||
      p_in_data.currency_code              || CHR(9) ||
      p_in_data.receipt_date 		   || CHR(9) ||
      p_in_data.receipt_id                 || CHR(9) ||
      p_in_data.Unapp_amount               || CHR(9) ||
      p_in_data.days_unapplied             || CHR(9) ||
      p_in_data.current_amount             || CHR(9) ||
      p_in_data.b1_1_30                    || CHR(9) ||
      p_in_data.b2_31_60                   || CHR(9) ||
      p_in_data.b3_61_90                   || CHR(9) ||
      p_in_data.b4_91_180                  || CHR(9) ||
      p_in_data.b5_181_360                 || CHR(9) ||
      p_in_data.b6_360_plus);
  END Rcpts_write_to_output;
  /* ***************************************************************************** */
  /* end Rev 2.0 */
 /* ***************************************************************************** */
  PROCEDURE insert_rec(p_in_data IN OUT NOCOPY c_ar_data%ROWTYPE) IS
  BEGIN
INSERT INTO haemo.xxha_ar_aging_rpt_tmp (
      report_user, report_date, cons_billing_number, bill_number, bill_name, cust_cat_meaning,
      cust_class_meaning, cust_type_meaning, trx_class, trx_number, due_date, invoice_currency_code,
      current_amount, b1_1_31, b2_1_31, b3_1_31, b4_1_31, b5_1_31, b6_360_plus, segment1, segment2,
      segment3, segment4, segment5, segment6, segment7, segment8, segment9, source, primary_salesrep_id,
      salesrep_name, amount_due_original, applied_count, amount_due_remaining, bill_cust_id, bill_site_use_id,
      bill_site_number, bill_address1, bill_address2, bill_address3, bill_address4, bill_city, bill_postal_code,
      bill_county, bill_state, bill_country, customer_type_name, category_code, customer_class_code, orig_system_reference,
      acctd_amount_due_remaining, days_past_due,
      percent_unpaid ,ORG_ID , gl_as_of_date, inv_date,org_name, exchange_rate, trx_type, RxC_billto)
    VALUES (
      v_user_name,
      v_run_date,
      p_in_data.cons_billing_number,
      p_in_data.bill_number,
      p_in_data.bill_name,
      p_in_data.cust_cat_meaning,
      p_in_data.cust_class_meaning,
      p_in_data.cust_type_meaning,
      p_in_data.trx_class,
      p_in_data.trx_number,
      p_in_data.due_date,
      p_in_data.invoice_currency_code,
      p_in_data.current_amount,
      p_in_data.b1_1_31,
      p_in_data.b2_1_31,
      p_in_data.b3_1_31,
      p_in_data.b4_1_31,
      p_in_data.b5_1_31,
      p_in_data.b6_360_plus,
      p_in_data.segment1,
      p_in_data.segment2,
      p_in_data.segment3,
      p_in_data.segment4,
      p_in_data.segment5,
      p_in_data.segment6,
      p_in_data.segment7,
      p_in_data.segment8,
      p_in_data.segment9,
      p_in_data.source,
      p_in_data.primary_salesrep_id,
      p_in_data.salesrep_name,
      p_in_data.amount_due_original,
      p_in_data.applied_count,
      p_in_data.amount_due_remaining,
      p_in_data.bill_cust_id,
      p_in_data.bill_site_use_id,
      p_in_data.bill_site_number,
      p_in_data.bill_address1,
      p_in_data.bill_address2,
      p_in_data.bill_address3,
      p_in_data.bill_address4,
      p_in_data.bill_city,
      p_in_data.bill_postal_code,
      p_in_data.bill_county,
      p_in_data.bill_state,
      p_in_data.bill_country,
      p_in_data.customer_type_name,
      p_in_data.category_code,
      p_in_data.customer_class_code,
      p_in_data.orig_system_reference,
      p_in_data.acctd_amount_due_remaining,
      p_in_data.days_past_due,
      p_in_data.percent_unpaid,
      p_in_data.ORG_ID ,
      p_in_data.gl_as_of_date,
      p_in_data.trx_date,
      p_in_data.org_name,
      p_in_data.exchange_rate,
      p_in_data.trx_type,
      p_in_data.RxC_billto);

  END insert_rec;
  /* ***************************************************************************** */
 /* Rev 2.0 */
  /* ***************************************************************************** */
  PROCEDURE insert_recpt_rec(p_in_data IN OUT NOCOPY c_recpt_data%ROWTYPE) IS
  BEGIN
INSERT INTO haemo.XX_HAEMO_UNAPP_RCPT_AGING (
      rpt_user, rpt_date, org_id, org_name, cust_number, cust_name, cust_type_code, cust_cat_code, cust_class_code, invoice_currency_code, rcpt_date, rcpt_id,
      unapp_amt, days_unapp, curr_amt, B1_1_30, B2_31_60, B3_61_90, B4_91_180, B5_181_360, B6_360_plus, gl_as_of_date)
    VALUES (
      v_user_name,
      v_run_date,
      p_in_data.org_id,
      p_in_data.org_name,
      p_in_data.customer_number,
      p_in_data.customer_name,
      p_in_data.customer_type_code,
      p_in_data.customer_category_code,
      p_in_data.customer_class_code,
      p_in_data.currency_code,
      p_in_data.receipt_date,
      p_in_data.receipt_id,
      p_in_data.Unapp_amount,
      p_in_data.days_unapplied,
      p_in_data.current_amount,
      p_in_data.b1_1_30,
      p_in_data.b2_31_60,
      p_in_data.b3_61_90,
      p_in_data.b4_91_180,
      p_in_data.b5_181_360,
      p_in_data.b6_360_plus,
      p_in_data.gl_as_of_date);
    END insert_recpt_rec;
  /* ***************************************************************************** */
  /* end Rev 2.0 */
/* ***************************************************************************** */
  PROCEDURE age_data (x_errbuf               OUT VARCHAR2,
                      x_retcode              OUT VARCHAR2,
                      p_report_type          IN  VARCHAR2,
                      p_reporting_level      IN  VARCHAR2,
                      p_reporting_context    IN  VARCHAR2,
                      p_as_of_gl_date        IN  VARCHAR2,
                      p_Aging_Bucket_Name    IN  VARCHAR2,
                      p_Customer_Name_Low    IN  VARCHAR2,
                      p_Customer_Name_high   IN  VARCHAR2,
                      p_Customer_Number_Low  IN  VARCHAR2,
                      p_Customer_Number_high IN  VARCHAR2,
                      p_acct_low             IN  VARCHAR2,
                      p_acct_high            IN  VARCHAR2) IS
 /* header record for data dumped to the conc request out file */
    v_excel_hdr VARCHAR2(2000) :=
       'Cust Number' || CHR(9) || 'Cust Name' || CHR(9) ||  'Cons Inv'  || CHR(9) ||
       'Cust Type' || CHR(9) || 'Cust Class' || CHR(9) || 'Cust Cat' || CHR(9) || 'Trx Type' || CHR(9) ||
       'Trx Number' || CHR(9) || 'Due Date' || CHR(9) || 'Days Past Due' || CHR(9) || 'Curr' || CHR(9) ||
       'Outstanding' || CHR(9) || 'Current' || CHR(9) || '1 to 30' || CHR(9) || '31 to 60' || CHR(9) ||
       '61 to 90' || CHR(9) || '91 to 180' || CHR(9) || '181 to 360' || CHR(9) || '361 +' || CHR(9) ||
       'Segment 1' || CHR(9) || 'Segment 2' || CHR(9) || 'Segment 3' || CHR(9) || 'Segment 4' || CHR(9) ||
       'Segment 5' || CHR(9) || 'Segment 6' || CHR(9) || 'Segment 7' || CHR(9) || 'Segment 8' || CHR(9) || 'Segment 9';
/* Rev 2.0 header record for unapp rcpts data in the conc request out file */
   v_rcpt_hdr varchar2(1000 char) :=
       'Cust Number' || CHR(9) || 'Cust Name' || CHR(9) || 'Cust Type' || CHR(9) || 'Cust Cat' || CHR(9) ||
       'Cust Class' || CHR(9) || 'Curr' || CHR(9) || 'Rcpt Date' || CHR(9) || 'Rcpt Id' || CHR(9) || 'Unapp Amt' || CHR(9) ||
       'Days UnApp' || CHR(9) || 'Curr Amt' || CHR(9) || '1 to 30' || CHR(9) || '31 to 60' || CHR(9) ||
       '61 to 90' || CHR(9) || '91 to 180' || CHR(9) || '181 to 360' || CHR(9) || '361 +';
   /* end Rev 2.0 */
 BEGIN
/* Get the user name for the insert */
    SELECT user_name
      INTO v_user_name
      FROM fnd_user
     WHERE user_id = fnd_global.user_id ;
/* write header record to conc request output */
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, v_excel_hdr);
/* Process Each record in the Roberto Query */
    FOR r_ar_data IN c_ar_data(TO_DATE(p_as_of_gl_date,'YYYY/MM/DD HH24:MI:SS'),
                               p_aging_Bucket_Name,
                               p_customer_name_Low,
                               p_customer_name_high,
                               p_customer_number_Low,
                               p_customer_number_high,
                               p_reporting_context,
                               p_acct_low,
                               p_acct_high) LOOP
/* Write data to the conc req out file */
      write_to_output(r_ar_data);
/* insert the record in the report tmp table */
      insert_rec(r_ar_data);
END LOOP; -- Main Loop on Roberto Query
 /* Rev 2.0 log and insert unapplied rcpt details*/
/* write header record to conc request output */
    FND_FILE.PUT_LINE(FND_FILE.OUTPUT, v_rcpt_hdr);
/* Process Each record in the unapp rcpts Query */
    FOR r_recpt_data IN c_recpt_data(TO_DATE(p_as_of_gl_date,'YYYY/MM/DD HH24:MI:SS'),
                               p_aging_Bucket_Name,
                               p_customer_name_Low,
                               p_customer_name_high,
                               p_customer_number_Low,
                               p_customer_number_high,
                               p_reporting_context,
                               p_acct_low,
                               p_acct_high) LOOP
/* Write data to the conc req out file */
      Rcpts_write_to_output(r_recpt_data);
/* insert the record in the unapplied receipts table */
      insert_recpt_rec(r_recpt_data);
 END LOOP; -- Main Loop on unapp rcpts Query
/* end Rev 2.0 */
end;
END;
/
