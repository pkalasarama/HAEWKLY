create or replace PACKAGE XXHA_WM_IP_BOM_EXTRACT_PKG
/*********************************************************************************************
* Package Name : XXHA_WM_IP_BOM_EXTRACT_PKG                                                  *
* Purpose      : This package provides a procedure to launch the XXHA: IP BOM Extract        *
*                Concurrent Request                                                          *
*                                                                                            *
* Used By      : webMethods Free Trade Agreement interface                                   *
*                                                                                            *
* Change History                                                                             *
*                                                                                            *
* Ver        Date            Author               Description                                *
* ------     -----------     -----------------    ------------------------------------------ *
* 1.0        22-SEP-2017     E. Rossing           Initial Package Creation                   *
*                                                                                            *
*********************************************************************************************/
AS
PROCEDURE WM_CALL_IP_BOM_EXTRACT( p_user_responsibility IN VARCHAR,
			    p_user IN VARCHAR,
			    v_status OUT VARCHAR,
			    v_request_id OUT NUMBER,
			    o_message OUT VARCHAR,
			    v_errmsg  OUT VARCHAR
			    ) ;

END XXHA_WM_IP_BOM_EXTRACT_PKG;