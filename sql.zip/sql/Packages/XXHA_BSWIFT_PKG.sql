create or replace PACKAGE XXHA_BSWIFT_PKG AS

/**********************************************************************************************************************************
 *
 * Package Name : XXHA_BSWIFT_PKG
 * Description:  This function will determine the most recent change date for Benefit Class Date, Time Status Effective Date,
 *                  Location Effective Date and Custom Employment Field Effective Date.
 *               It is used by the view, 'APPS.XXHA_BSWIFT_V'.
 * Notes:
 *
 * Modified:       Ver      Date            Modification
 * -------------   -----    -----------     ----------------------------------------------------------------------------------------
 * BMarcoux        1.0      14-JUN-2017     Initial Object Creation
 * BMarcoux        2.0      21-AUG-2017     Added function for replacing special characters in names (REPLACE_SPECIAL_CHAR and ASCII_CHAR)
 *                                          Added function for determining actual Hire Date (HIRE_DATE)
 *                                          Added function for determining actual LOA Dates (LOA_DATES) and LOA_Status
 * BMarcoux        3.0      14-NOV-2017     Added function for Rehires (REHIRE)
 *                                          Added function for determining Contingent Worker Conversions (CONTINGENT_WORKER)
 *                                          Added function for determining Employee Acquisitions (ACQUISITIONS)
 *
 **********************************************************************************************************************************/

--------------------------------------------------------------------------------
-- FUNCTION Benefit Class Date
FUNCTION BENEFIT_CLASS_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE;

-- FUNCTION Time Status Effective Date
FUNCTION TIME_STATUS_EFFECTIVE_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE;

-- FUNCTION Location Effective Date
FUNCTION LOCATION_EFFECTIVE_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE;

-- FUNCTION Custom Employment Field Effective Date
FUNCTION CUSTOM_EMPLOY_FIELD_EFF_DATE(P_PERSON_ID IN NUMBER, P_DATE IN DATE) RETURN DATE;

-- FUNCTION Format Phone Number
FUNCTION FORMAT_PHONE_NUMBER(P_PHONE IN VARCHAR2) RETURN VARCHAR2;

-- FUNCTION Decode Lookup (Get Alternate description for Term Reason)
FUNCTION DECODE_LOOKUP(P_LOOKUP_TYPE VARCHAR2, P_LOOKUP_CODE VARCHAR2) RETURN VARCHAR2;

-- FUNCTION REPLACE_SPECIAL_CHAR
FUNCTION REPLACE_SPECIAL_CHAR(P_TEXT VARCHAR2) RETURN VARCHAR2;

-- FUNCTION ASCII_CHAR
FUNCTION ASCII_CHAR(P_TEXT VARCHAR2) RETURN VARCHAR2;

-- FUNCTION HIRE_DATE
FUNCTION HIRE_DATE(P_PERSON_ID IN NUMBER) RETURN DATE;

-- FUNCTION LOA_DATES
FUNCTION LOA_DATES(P_PERSON_ID IN NUMBER) RETURN VARCHAR2;

-- FUNCTION ACQUISITIONS
FUNCTION ACQUISITIONS(P_PERSON_ID IN NUMBER) RETURN VARCHAR2;

-- FUNCTION CONTINGENT_WORKER
FUNCTION CONTINGENT_WORKER(P_PERSON_ID IN NUMBER) RETURN VARCHAR2;

-- FUNCTION REHIRE
FUNCTION REHIRE(P_PERSON_ID IN NUMBER) RETURN VARCHAR2;

END XXHA_BSWIFT_PKG;