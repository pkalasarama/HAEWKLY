--------------------------------------------------------
--  File created - Friday-December-12-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index XXHA_RXC_SALES_ISSUES_N2
--------------------------------------------------------

  CREATE INDEX "HAEMO"."XXHA_RXC_SALES_ISSUES_N2" ON "HAEMO"."XXHA_RXC_SALES_ISSUES" ("INVENTORY_PROCESSED") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "HAEMO" ;
