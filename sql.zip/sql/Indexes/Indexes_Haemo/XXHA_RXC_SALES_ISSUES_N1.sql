--------------------------------------------------------
--  File created - Friday-December-12-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index XXHA_RXC_SALES_ISSUES_N1
--------------------------------------------------------

  CREATE INDEX "HAEMO"."XXHA_RXC_SALES_ISSUES_N1" ON "HAEMO"."XXHA_RXC_SALES_ISSUES" ("PROCESSED") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "HAEMO" ;
