--------------------------------------------------------
--  File created - Friday-December-12-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index XXHA_OE_LINES_IFACE_U1
--------------------------------------------------------

  CREATE INDEX "HAEMO"."XXHA_OE_LINES_IFACE_U1" ON "HAEMO"."XXHA_OE_LINES_IFACE" ("ORDER_SOURCE_ID", "ORIG_SYS_DOCUMENT_REF", "ORIG_SYS_LINE_REF", "ORIG_SYS_SHIPMENT_REF", "SOLD_TO_ORG_ID", "SOLD_TO_ORG", "CHANGE_SEQUENCE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "HAEMO" ;
