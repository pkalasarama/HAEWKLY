--------------------------------------------------------
--  File created - Friday-December-12-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index XXHA_OE_HEADERS_IFACE_N1
--------------------------------------------------------

  CREATE INDEX "HAEMO"."XXHA_OE_HEADERS_IFACE_N1" ON "HAEMO"."XXHA_OE_HEADERS_IFACE" ("ORDER_SOURCE_ID", "ORIG_SYS_DOCUMENT_REF", "SOLD_TO_ORG_ID", "SOLD_TO_ORG", "CHANGE_SEQUENCE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "HAEMO" ;
