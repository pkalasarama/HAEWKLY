--------------------------------------------------------
--  File created - Wednesday-December-03-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index XXHA_PROJ_TASKS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "APPS"."XXHA_PROJ_TASKS_PK" ON "APPS"."XXHA_PROJ_TASK_ALERT" ("TASK_ID", "LAST_UPDATE_DATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 131072 NEXT 131072 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "APPS_TS_TX_DATA" ;
