--------------------------------------------------------
--  File created - Wednesday-December-03-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Index XXHA_GL_APPROVERS_IDX1
--------------------------------------------------------

  CREATE INDEX "APPS"."XXHA_GL_APPROVERS_IDX1" ON "APPS"."XXHA_GL_APPROVERS" ("WF_ITEM_KEY") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 131072 NEXT 131072 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "APPS_TS_TX_DATA" ;
